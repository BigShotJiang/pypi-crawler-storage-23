from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPCashFlowStatementData")


@_attrs_define
class FMPCashFlowStatementData:
    """FMP Cash Flow Statement Data.

    Attributes:
        period_ending (datetime.date): The end date of the reporting period.
        fiscal_period (None | str | Unset): The fiscal period of the report.
        fiscal_year (int | None | Unset): The fiscal year of the fiscal period.
        filing_date (datetime.date | None | Unset): The date of the filing.
        accepted_date (datetime.datetime | None | Unset): The date the filing was accepted.
        cik (None | str | Unset): The Central Index Key (CIK) assigned by the SEC, if applicable.
        symbol (None | str | Unset): The stock ticker symbol.
        reported_currency (None | str | Unset): The currency in which the cash flow statement was reported.
        net_income (int | None | Unset): Net income.
        depreciation_and_amortization (int | None | Unset): Depreciation and amortization.
        deferred_income_tax (int | None | Unset): Deferred income tax.
        stock_based_compensation (int | None | Unset): Stock-based compensation.
        change_in_working_capital (int | None | Unset): Change in working capital.
        change_in_account_receivables (int | None | Unset): Change in account receivables.
        change_in_inventory (int | None | Unset): Change in inventory.
        change_in_account_payable (int | None | Unset): Change in account payable.
        change_in_other_working_capital (int | None | Unset): Change in other working capital.
        change_in_other_non_cash_items (int | None | Unset): Change in other non-cash items.
        net_cash_from_operating_activities (int | None | Unset): Net cash from operating activities.
        purchase_of_property_plant_and_equipment (int | None | Unset): Purchase of property, plant and equipment.
        acquisitions (int | None | Unset): Acquisitions.
        purchase_of_investment_securities (int | None | Unset): Purchase of investment securities.
        sale_and_maturity_of_investments (int | None | Unset): Sale and maturity of investments.
        other_investing_activities (int | None | Unset): Other investing activities.
        net_cash_from_investing_activities (int | None | Unset): Net cash from investing activities.
        repayment_of_debt (int | None | Unset): Repayment of debt.
        issuance_of_common_equity (int | None | Unset): Issuance of common equity.
        repurchase_of_common_equity (int | None | Unset): Repurchase of common equity.
        net_common_equity_issuance (int | None | Unset): Net common equity issuance.
        net_preferred_equity_issuance (int | None | Unset): Net preferred equity issuance.
        net_equity_issuance (int | None | Unset): Net equity issuance.
        short_term_net_debt_issuance (int | None | Unset): Short term net debt issuance.
        long_term_net_debt_issuance (int | None | Unset): Long term net debt issuance.
        net_debt_issuance (int | None | Unset): Net debt issuance.
        common_dividends_paid (int | None | Unset): Payment of common dividends.
        preferred_dividends_paid (int | None | Unset): Payment of preferred dividends.
        net_dividends_paid (int | None | Unset): Net dividends paid.
        other_financing_activities (int | None | Unset): Other financing activities.
        net_cash_from_financing_activities (int | None | Unset): Net cash from financing activities.
        effect_of_exchange_rate_changes_on_cash (int | None | Unset): Effect of exchange rate changes on cash.
        net_change_in_cash_and_equivalents (int | None | Unset): Net change in cash and equivalents.
        cash_at_beginning_of_period (int | None | Unset): Cash at beginning of period.
        cash_at_end_of_period (int | None | Unset): Cash at end of period.
        operating_cash_flow (int | None | Unset): Operating cash flow.
        capital_expenditure (int | None | Unset): Capital expenditure.
        income_taxes_paid (int | None | Unset): Income taxes paid.
        interest_paid (int | None | Unset): Interest paid.
        free_cash_flow (int | None | Unset):
    """

    period_ending: datetime.date
    fiscal_period: None | str | Unset = UNSET
    fiscal_year: int | None | Unset = UNSET
    filing_date: datetime.date | None | Unset = UNSET
    accepted_date: datetime.datetime | None | Unset = UNSET
    cik: None | str | Unset = UNSET
    symbol: None | str | Unset = UNSET
    reported_currency: None | str | Unset = UNSET
    net_income: int | None | Unset = UNSET
    depreciation_and_amortization: int | None | Unset = UNSET
    deferred_income_tax: int | None | Unset = UNSET
    stock_based_compensation: int | None | Unset = UNSET
    change_in_working_capital: int | None | Unset = UNSET
    change_in_account_receivables: int | None | Unset = UNSET
    change_in_inventory: int | None | Unset = UNSET
    change_in_account_payable: int | None | Unset = UNSET
    change_in_other_working_capital: int | None | Unset = UNSET
    change_in_other_non_cash_items: int | None | Unset = UNSET
    net_cash_from_operating_activities: int | None | Unset = UNSET
    purchase_of_property_plant_and_equipment: int | None | Unset = UNSET
    acquisitions: int | None | Unset = UNSET
    purchase_of_investment_securities: int | None | Unset = UNSET
    sale_and_maturity_of_investments: int | None | Unset = UNSET
    other_investing_activities: int | None | Unset = UNSET
    net_cash_from_investing_activities: int | None | Unset = UNSET
    repayment_of_debt: int | None | Unset = UNSET
    issuance_of_common_equity: int | None | Unset = UNSET
    repurchase_of_common_equity: int | None | Unset = UNSET
    net_common_equity_issuance: int | None | Unset = UNSET
    net_preferred_equity_issuance: int | None | Unset = UNSET
    net_equity_issuance: int | None | Unset = UNSET
    short_term_net_debt_issuance: int | None | Unset = UNSET
    long_term_net_debt_issuance: int | None | Unset = UNSET
    net_debt_issuance: int | None | Unset = UNSET
    common_dividends_paid: int | None | Unset = UNSET
    preferred_dividends_paid: int | None | Unset = UNSET
    net_dividends_paid: int | None | Unset = UNSET
    other_financing_activities: int | None | Unset = UNSET
    net_cash_from_financing_activities: int | None | Unset = UNSET
    effect_of_exchange_rate_changes_on_cash: int | None | Unset = UNSET
    net_change_in_cash_and_equivalents: int | None | Unset = UNSET
    cash_at_beginning_of_period: int | None | Unset = UNSET
    cash_at_end_of_period: int | None | Unset = UNSET
    operating_cash_flow: int | None | Unset = UNSET
    capital_expenditure: int | None | Unset = UNSET
    income_taxes_paid: int | None | Unset = UNSET
    interest_paid: int | None | Unset = UNSET
    free_cash_flow: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        period_ending = self.period_ending.isoformat()

        fiscal_period: None | str | Unset
        if isinstance(self.fiscal_period, Unset):
            fiscal_period = UNSET
        else:
            fiscal_period = self.fiscal_period

        fiscal_year: int | None | Unset
        if isinstance(self.fiscal_year, Unset):
            fiscal_year = UNSET
        else:
            fiscal_year = self.fiscal_year

        filing_date: None | str | Unset
        if isinstance(self.filing_date, Unset):
            filing_date = UNSET
        elif isinstance(self.filing_date, datetime.date):
            filing_date = self.filing_date.isoformat()
        else:
            filing_date = self.filing_date

        accepted_date: None | str | Unset
        if isinstance(self.accepted_date, Unset):
            accepted_date = UNSET
        elif isinstance(self.accepted_date, datetime.datetime):
            accepted_date = self.accepted_date.isoformat()
        else:
            accepted_date = self.accepted_date

        cik: None | str | Unset
        if isinstance(self.cik, Unset):
            cik = UNSET
        else:
            cik = self.cik

        symbol: None | str | Unset
        if isinstance(self.symbol, Unset):
            symbol = UNSET
        else:
            symbol = self.symbol

        reported_currency: None | str | Unset
        if isinstance(self.reported_currency, Unset):
            reported_currency = UNSET
        else:
            reported_currency = self.reported_currency

        net_income: int | None | Unset
        if isinstance(self.net_income, Unset):
            net_income = UNSET
        else:
            net_income = self.net_income

        depreciation_and_amortization: int | None | Unset
        if isinstance(self.depreciation_and_amortization, Unset):
            depreciation_and_amortization = UNSET
        else:
            depreciation_and_amortization = self.depreciation_and_amortization

        deferred_income_tax: int | None | Unset
        if isinstance(self.deferred_income_tax, Unset):
            deferred_income_tax = UNSET
        else:
            deferred_income_tax = self.deferred_income_tax

        stock_based_compensation: int | None | Unset
        if isinstance(self.stock_based_compensation, Unset):
            stock_based_compensation = UNSET
        else:
            stock_based_compensation = self.stock_based_compensation

        change_in_working_capital: int | None | Unset
        if isinstance(self.change_in_working_capital, Unset):
            change_in_working_capital = UNSET
        else:
            change_in_working_capital = self.change_in_working_capital

        change_in_account_receivables: int | None | Unset
        if isinstance(self.change_in_account_receivables, Unset):
            change_in_account_receivables = UNSET
        else:
            change_in_account_receivables = self.change_in_account_receivables

        change_in_inventory: int | None | Unset
        if isinstance(self.change_in_inventory, Unset):
            change_in_inventory = UNSET
        else:
            change_in_inventory = self.change_in_inventory

        change_in_account_payable: int | None | Unset
        if isinstance(self.change_in_account_payable, Unset):
            change_in_account_payable = UNSET
        else:
            change_in_account_payable = self.change_in_account_payable

        change_in_other_working_capital: int | None | Unset
        if isinstance(self.change_in_other_working_capital, Unset):
            change_in_other_working_capital = UNSET
        else:
            change_in_other_working_capital = self.change_in_other_working_capital

        change_in_other_non_cash_items: int | None | Unset
        if isinstance(self.change_in_other_non_cash_items, Unset):
            change_in_other_non_cash_items = UNSET
        else:
            change_in_other_non_cash_items = self.change_in_other_non_cash_items

        net_cash_from_operating_activities: int | None | Unset
        if isinstance(self.net_cash_from_operating_activities, Unset):
            net_cash_from_operating_activities = UNSET
        else:
            net_cash_from_operating_activities = self.net_cash_from_operating_activities

        purchase_of_property_plant_and_equipment: int | None | Unset
        if isinstance(self.purchase_of_property_plant_and_equipment, Unset):
            purchase_of_property_plant_and_equipment = UNSET
        else:
            purchase_of_property_plant_and_equipment = self.purchase_of_property_plant_and_equipment

        acquisitions: int | None | Unset
        if isinstance(self.acquisitions, Unset):
            acquisitions = UNSET
        else:
            acquisitions = self.acquisitions

        purchase_of_investment_securities: int | None | Unset
        if isinstance(self.purchase_of_investment_securities, Unset):
            purchase_of_investment_securities = UNSET
        else:
            purchase_of_investment_securities = self.purchase_of_investment_securities

        sale_and_maturity_of_investments: int | None | Unset
        if isinstance(self.sale_and_maturity_of_investments, Unset):
            sale_and_maturity_of_investments = UNSET
        else:
            sale_and_maturity_of_investments = self.sale_and_maturity_of_investments

        other_investing_activities: int | None | Unset
        if isinstance(self.other_investing_activities, Unset):
            other_investing_activities = UNSET
        else:
            other_investing_activities = self.other_investing_activities

        net_cash_from_investing_activities: int | None | Unset
        if isinstance(self.net_cash_from_investing_activities, Unset):
            net_cash_from_investing_activities = UNSET
        else:
            net_cash_from_investing_activities = self.net_cash_from_investing_activities

        repayment_of_debt: int | None | Unset
        if isinstance(self.repayment_of_debt, Unset):
            repayment_of_debt = UNSET
        else:
            repayment_of_debt = self.repayment_of_debt

        issuance_of_common_equity: int | None | Unset
        if isinstance(self.issuance_of_common_equity, Unset):
            issuance_of_common_equity = UNSET
        else:
            issuance_of_common_equity = self.issuance_of_common_equity

        repurchase_of_common_equity: int | None | Unset
        if isinstance(self.repurchase_of_common_equity, Unset):
            repurchase_of_common_equity = UNSET
        else:
            repurchase_of_common_equity = self.repurchase_of_common_equity

        net_common_equity_issuance: int | None | Unset
        if isinstance(self.net_common_equity_issuance, Unset):
            net_common_equity_issuance = UNSET
        else:
            net_common_equity_issuance = self.net_common_equity_issuance

        net_preferred_equity_issuance: int | None | Unset
        if isinstance(self.net_preferred_equity_issuance, Unset):
            net_preferred_equity_issuance = UNSET
        else:
            net_preferred_equity_issuance = self.net_preferred_equity_issuance

        net_equity_issuance: int | None | Unset
        if isinstance(self.net_equity_issuance, Unset):
            net_equity_issuance = UNSET
        else:
            net_equity_issuance = self.net_equity_issuance

        short_term_net_debt_issuance: int | None | Unset
        if isinstance(self.short_term_net_debt_issuance, Unset):
            short_term_net_debt_issuance = UNSET
        else:
            short_term_net_debt_issuance = self.short_term_net_debt_issuance

        long_term_net_debt_issuance: int | None | Unset
        if isinstance(self.long_term_net_debt_issuance, Unset):
            long_term_net_debt_issuance = UNSET
        else:
            long_term_net_debt_issuance = self.long_term_net_debt_issuance

        net_debt_issuance: int | None | Unset
        if isinstance(self.net_debt_issuance, Unset):
            net_debt_issuance = UNSET
        else:
            net_debt_issuance = self.net_debt_issuance

        common_dividends_paid: int | None | Unset
        if isinstance(self.common_dividends_paid, Unset):
            common_dividends_paid = UNSET
        else:
            common_dividends_paid = self.common_dividends_paid

        preferred_dividends_paid: int | None | Unset
        if isinstance(self.preferred_dividends_paid, Unset):
            preferred_dividends_paid = UNSET
        else:
            preferred_dividends_paid = self.preferred_dividends_paid

        net_dividends_paid: int | None | Unset
        if isinstance(self.net_dividends_paid, Unset):
            net_dividends_paid = UNSET
        else:
            net_dividends_paid = self.net_dividends_paid

        other_financing_activities: int | None | Unset
        if isinstance(self.other_financing_activities, Unset):
            other_financing_activities = UNSET
        else:
            other_financing_activities = self.other_financing_activities

        net_cash_from_financing_activities: int | None | Unset
        if isinstance(self.net_cash_from_financing_activities, Unset):
            net_cash_from_financing_activities = UNSET
        else:
            net_cash_from_financing_activities = self.net_cash_from_financing_activities

        effect_of_exchange_rate_changes_on_cash: int | None | Unset
        if isinstance(self.effect_of_exchange_rate_changes_on_cash, Unset):
            effect_of_exchange_rate_changes_on_cash = UNSET
        else:
            effect_of_exchange_rate_changes_on_cash = self.effect_of_exchange_rate_changes_on_cash

        net_change_in_cash_and_equivalents: int | None | Unset
        if isinstance(self.net_change_in_cash_and_equivalents, Unset):
            net_change_in_cash_and_equivalents = UNSET
        else:
            net_change_in_cash_and_equivalents = self.net_change_in_cash_and_equivalents

        cash_at_beginning_of_period: int | None | Unset
        if isinstance(self.cash_at_beginning_of_period, Unset):
            cash_at_beginning_of_period = UNSET
        else:
            cash_at_beginning_of_period = self.cash_at_beginning_of_period

        cash_at_end_of_period: int | None | Unset
        if isinstance(self.cash_at_end_of_period, Unset):
            cash_at_end_of_period = UNSET
        else:
            cash_at_end_of_period = self.cash_at_end_of_period

        operating_cash_flow: int | None | Unset
        if isinstance(self.operating_cash_flow, Unset):
            operating_cash_flow = UNSET
        else:
            operating_cash_flow = self.operating_cash_flow

        capital_expenditure: int | None | Unset
        if isinstance(self.capital_expenditure, Unset):
            capital_expenditure = UNSET
        else:
            capital_expenditure = self.capital_expenditure

        income_taxes_paid: int | None | Unset
        if isinstance(self.income_taxes_paid, Unset):
            income_taxes_paid = UNSET
        else:
            income_taxes_paid = self.income_taxes_paid

        interest_paid: int | None | Unset
        if isinstance(self.interest_paid, Unset):
            interest_paid = UNSET
        else:
            interest_paid = self.interest_paid

        free_cash_flow: int | None | Unset
        if isinstance(self.free_cash_flow, Unset):
            free_cash_flow = UNSET
        else:
            free_cash_flow = self.free_cash_flow

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "period_ending": period_ending,
            }
        )
        if fiscal_period is not UNSET:
            field_dict["fiscal_period"] = fiscal_period
        if fiscal_year is not UNSET:
            field_dict["fiscal_year"] = fiscal_year
        if filing_date is not UNSET:
            field_dict["filing_date"] = filing_date
        if accepted_date is not UNSET:
            field_dict["accepted_date"] = accepted_date
        if cik is not UNSET:
            field_dict["cik"] = cik
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if reported_currency is not UNSET:
            field_dict["reported_currency"] = reported_currency
        if net_income is not UNSET:
            field_dict["net_income"] = net_income
        if depreciation_and_amortization is not UNSET:
            field_dict["depreciation_and_amortization"] = depreciation_and_amortization
        if deferred_income_tax is not UNSET:
            field_dict["deferred_income_tax"] = deferred_income_tax
        if stock_based_compensation is not UNSET:
            field_dict["stock_based_compensation"] = stock_based_compensation
        if change_in_working_capital is not UNSET:
            field_dict["change_in_working_capital"] = change_in_working_capital
        if change_in_account_receivables is not UNSET:
            field_dict["change_in_account_receivables"] = change_in_account_receivables
        if change_in_inventory is not UNSET:
            field_dict["change_in_inventory"] = change_in_inventory
        if change_in_account_payable is not UNSET:
            field_dict["change_in_account_payable"] = change_in_account_payable
        if change_in_other_working_capital is not UNSET:
            field_dict["change_in_other_working_capital"] = change_in_other_working_capital
        if change_in_other_non_cash_items is not UNSET:
            field_dict["change_in_other_non_cash_items"] = change_in_other_non_cash_items
        if net_cash_from_operating_activities is not UNSET:
            field_dict["net_cash_from_operating_activities"] = net_cash_from_operating_activities
        if purchase_of_property_plant_and_equipment is not UNSET:
            field_dict["purchase_of_property_plant_and_equipment"] = purchase_of_property_plant_and_equipment
        if acquisitions is not UNSET:
            field_dict["acquisitions"] = acquisitions
        if purchase_of_investment_securities is not UNSET:
            field_dict["purchase_of_investment_securities"] = purchase_of_investment_securities
        if sale_and_maturity_of_investments is not UNSET:
            field_dict["sale_and_maturity_of_investments"] = sale_and_maturity_of_investments
        if other_investing_activities is not UNSET:
            field_dict["other_investing_activities"] = other_investing_activities
        if net_cash_from_investing_activities is not UNSET:
            field_dict["net_cash_from_investing_activities"] = net_cash_from_investing_activities
        if repayment_of_debt is not UNSET:
            field_dict["repayment_of_debt"] = repayment_of_debt
        if issuance_of_common_equity is not UNSET:
            field_dict["issuance_of_common_equity"] = issuance_of_common_equity
        if repurchase_of_common_equity is not UNSET:
            field_dict["repurchase_of_common_equity"] = repurchase_of_common_equity
        if net_common_equity_issuance is not UNSET:
            field_dict["net_common_equity_issuance"] = net_common_equity_issuance
        if net_preferred_equity_issuance is not UNSET:
            field_dict["net_preferred_equity_issuance"] = net_preferred_equity_issuance
        if net_equity_issuance is not UNSET:
            field_dict["net_equity_issuance"] = net_equity_issuance
        if short_term_net_debt_issuance is not UNSET:
            field_dict["short_term_net_debt_issuance"] = short_term_net_debt_issuance
        if long_term_net_debt_issuance is not UNSET:
            field_dict["long_term_net_debt_issuance"] = long_term_net_debt_issuance
        if net_debt_issuance is not UNSET:
            field_dict["net_debt_issuance"] = net_debt_issuance
        if common_dividends_paid is not UNSET:
            field_dict["common_dividends_paid"] = common_dividends_paid
        if preferred_dividends_paid is not UNSET:
            field_dict["preferred_dividends_paid"] = preferred_dividends_paid
        if net_dividends_paid is not UNSET:
            field_dict["net_dividends_paid"] = net_dividends_paid
        if other_financing_activities is not UNSET:
            field_dict["other_financing_activities"] = other_financing_activities
        if net_cash_from_financing_activities is not UNSET:
            field_dict["net_cash_from_financing_activities"] = net_cash_from_financing_activities
        if effect_of_exchange_rate_changes_on_cash is not UNSET:
            field_dict["effect_of_exchange_rate_changes_on_cash"] = effect_of_exchange_rate_changes_on_cash
        if net_change_in_cash_and_equivalents is not UNSET:
            field_dict["net_change_in_cash_and_equivalents"] = net_change_in_cash_and_equivalents
        if cash_at_beginning_of_period is not UNSET:
            field_dict["cash_at_beginning_of_period"] = cash_at_beginning_of_period
        if cash_at_end_of_period is not UNSET:
            field_dict["cash_at_end_of_period"] = cash_at_end_of_period
        if operating_cash_flow is not UNSET:
            field_dict["operating_cash_flow"] = operating_cash_flow
        if capital_expenditure is not UNSET:
            field_dict["capital_expenditure"] = capital_expenditure
        if income_taxes_paid is not UNSET:
            field_dict["income_taxes_paid"] = income_taxes_paid
        if interest_paid is not UNSET:
            field_dict["interest_paid"] = interest_paid
        if free_cash_flow is not UNSET:
            field_dict["free_cash_flow"] = free_cash_flow

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        period_ending = isoparse(d.pop("period_ending")).date()

        def _parse_fiscal_period(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        fiscal_period = _parse_fiscal_period(d.pop("fiscal_period", UNSET))

        def _parse_fiscal_year(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        fiscal_year = _parse_fiscal_year(d.pop("fiscal_year", UNSET))

        def _parse_filing_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                filing_date_type_0 = isoparse(data).date()

                return filing_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        filing_date = _parse_filing_date(d.pop("filing_date", UNSET))

        def _parse_accepted_date(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                accepted_date_type_0 = isoparse(data)

                return accepted_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        accepted_date = _parse_accepted_date(d.pop("accepted_date", UNSET))

        def _parse_cik(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cik = _parse_cik(d.pop("cik", UNSET))

        def _parse_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol = _parse_symbol(d.pop("symbol", UNSET))

        def _parse_reported_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reported_currency = _parse_reported_currency(d.pop("reported_currency", UNSET))

        def _parse_net_income(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_income = _parse_net_income(d.pop("net_income", UNSET))

        def _parse_depreciation_and_amortization(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        depreciation_and_amortization = _parse_depreciation_and_amortization(
            d.pop("depreciation_and_amortization", UNSET)
        )

        def _parse_deferred_income_tax(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        deferred_income_tax = _parse_deferred_income_tax(d.pop("deferred_income_tax", UNSET))

        def _parse_stock_based_compensation(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        stock_based_compensation = _parse_stock_based_compensation(d.pop("stock_based_compensation", UNSET))

        def _parse_change_in_working_capital(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        change_in_working_capital = _parse_change_in_working_capital(d.pop("change_in_working_capital", UNSET))

        def _parse_change_in_account_receivables(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        change_in_account_receivables = _parse_change_in_account_receivables(
            d.pop("change_in_account_receivables", UNSET)
        )

        def _parse_change_in_inventory(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        change_in_inventory = _parse_change_in_inventory(d.pop("change_in_inventory", UNSET))

        def _parse_change_in_account_payable(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        change_in_account_payable = _parse_change_in_account_payable(d.pop("change_in_account_payable", UNSET))

        def _parse_change_in_other_working_capital(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        change_in_other_working_capital = _parse_change_in_other_working_capital(
            d.pop("change_in_other_working_capital", UNSET)
        )

        def _parse_change_in_other_non_cash_items(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        change_in_other_non_cash_items = _parse_change_in_other_non_cash_items(
            d.pop("change_in_other_non_cash_items", UNSET)
        )

        def _parse_net_cash_from_operating_activities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_cash_from_operating_activities = _parse_net_cash_from_operating_activities(
            d.pop("net_cash_from_operating_activities", UNSET)
        )

        def _parse_purchase_of_property_plant_and_equipment(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        purchase_of_property_plant_and_equipment = _parse_purchase_of_property_plant_and_equipment(
            d.pop("purchase_of_property_plant_and_equipment", UNSET)
        )

        def _parse_acquisitions(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        acquisitions = _parse_acquisitions(d.pop("acquisitions", UNSET))

        def _parse_purchase_of_investment_securities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        purchase_of_investment_securities = _parse_purchase_of_investment_securities(
            d.pop("purchase_of_investment_securities", UNSET)
        )

        def _parse_sale_and_maturity_of_investments(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        sale_and_maturity_of_investments = _parse_sale_and_maturity_of_investments(
            d.pop("sale_and_maturity_of_investments", UNSET)
        )

        def _parse_other_investing_activities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_investing_activities = _parse_other_investing_activities(d.pop("other_investing_activities", UNSET))

        def _parse_net_cash_from_investing_activities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_cash_from_investing_activities = _parse_net_cash_from_investing_activities(
            d.pop("net_cash_from_investing_activities", UNSET)
        )

        def _parse_repayment_of_debt(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        repayment_of_debt = _parse_repayment_of_debt(d.pop("repayment_of_debt", UNSET))

        def _parse_issuance_of_common_equity(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        issuance_of_common_equity = _parse_issuance_of_common_equity(d.pop("issuance_of_common_equity", UNSET))

        def _parse_repurchase_of_common_equity(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        repurchase_of_common_equity = _parse_repurchase_of_common_equity(d.pop("repurchase_of_common_equity", UNSET))

        def _parse_net_common_equity_issuance(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_common_equity_issuance = _parse_net_common_equity_issuance(d.pop("net_common_equity_issuance", UNSET))

        def _parse_net_preferred_equity_issuance(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_preferred_equity_issuance = _parse_net_preferred_equity_issuance(
            d.pop("net_preferred_equity_issuance", UNSET)
        )

        def _parse_net_equity_issuance(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_equity_issuance = _parse_net_equity_issuance(d.pop("net_equity_issuance", UNSET))

        def _parse_short_term_net_debt_issuance(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        short_term_net_debt_issuance = _parse_short_term_net_debt_issuance(d.pop("short_term_net_debt_issuance", UNSET))

        def _parse_long_term_net_debt_issuance(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        long_term_net_debt_issuance = _parse_long_term_net_debt_issuance(d.pop("long_term_net_debt_issuance", UNSET))

        def _parse_net_debt_issuance(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_debt_issuance = _parse_net_debt_issuance(d.pop("net_debt_issuance", UNSET))

        def _parse_common_dividends_paid(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        common_dividends_paid = _parse_common_dividends_paid(d.pop("common_dividends_paid", UNSET))

        def _parse_preferred_dividends_paid(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        preferred_dividends_paid = _parse_preferred_dividends_paid(d.pop("preferred_dividends_paid", UNSET))

        def _parse_net_dividends_paid(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_dividends_paid = _parse_net_dividends_paid(d.pop("net_dividends_paid", UNSET))

        def _parse_other_financing_activities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        other_financing_activities = _parse_other_financing_activities(d.pop("other_financing_activities", UNSET))

        def _parse_net_cash_from_financing_activities(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_cash_from_financing_activities = _parse_net_cash_from_financing_activities(
            d.pop("net_cash_from_financing_activities", UNSET)
        )

        def _parse_effect_of_exchange_rate_changes_on_cash(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        effect_of_exchange_rate_changes_on_cash = _parse_effect_of_exchange_rate_changes_on_cash(
            d.pop("effect_of_exchange_rate_changes_on_cash", UNSET)
        )

        def _parse_net_change_in_cash_and_equivalents(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        net_change_in_cash_and_equivalents = _parse_net_change_in_cash_and_equivalents(
            d.pop("net_change_in_cash_and_equivalents", UNSET)
        )

        def _parse_cash_at_beginning_of_period(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cash_at_beginning_of_period = _parse_cash_at_beginning_of_period(d.pop("cash_at_beginning_of_period", UNSET))

        def _parse_cash_at_end_of_period(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cash_at_end_of_period = _parse_cash_at_end_of_period(d.pop("cash_at_end_of_period", UNSET))

        def _parse_operating_cash_flow(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        operating_cash_flow = _parse_operating_cash_flow(d.pop("operating_cash_flow", UNSET))

        def _parse_capital_expenditure(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        capital_expenditure = _parse_capital_expenditure(d.pop("capital_expenditure", UNSET))

        def _parse_income_taxes_paid(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        income_taxes_paid = _parse_income_taxes_paid(d.pop("income_taxes_paid", UNSET))

        def _parse_interest_paid(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        interest_paid = _parse_interest_paid(d.pop("interest_paid", UNSET))

        def _parse_free_cash_flow(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        free_cash_flow = _parse_free_cash_flow(d.pop("free_cash_flow", UNSET))

        fmp_cash_flow_statement_data = cls(
            period_ending=period_ending,
            fiscal_period=fiscal_period,
            fiscal_year=fiscal_year,
            filing_date=filing_date,
            accepted_date=accepted_date,
            cik=cik,
            symbol=symbol,
            reported_currency=reported_currency,
            net_income=net_income,
            depreciation_and_amortization=depreciation_and_amortization,
            deferred_income_tax=deferred_income_tax,
            stock_based_compensation=stock_based_compensation,
            change_in_working_capital=change_in_working_capital,
            change_in_account_receivables=change_in_account_receivables,
            change_in_inventory=change_in_inventory,
            change_in_account_payable=change_in_account_payable,
            change_in_other_working_capital=change_in_other_working_capital,
            change_in_other_non_cash_items=change_in_other_non_cash_items,
            net_cash_from_operating_activities=net_cash_from_operating_activities,
            purchase_of_property_plant_and_equipment=purchase_of_property_plant_and_equipment,
            acquisitions=acquisitions,
            purchase_of_investment_securities=purchase_of_investment_securities,
            sale_and_maturity_of_investments=sale_and_maturity_of_investments,
            other_investing_activities=other_investing_activities,
            net_cash_from_investing_activities=net_cash_from_investing_activities,
            repayment_of_debt=repayment_of_debt,
            issuance_of_common_equity=issuance_of_common_equity,
            repurchase_of_common_equity=repurchase_of_common_equity,
            net_common_equity_issuance=net_common_equity_issuance,
            net_preferred_equity_issuance=net_preferred_equity_issuance,
            net_equity_issuance=net_equity_issuance,
            short_term_net_debt_issuance=short_term_net_debt_issuance,
            long_term_net_debt_issuance=long_term_net_debt_issuance,
            net_debt_issuance=net_debt_issuance,
            common_dividends_paid=common_dividends_paid,
            preferred_dividends_paid=preferred_dividends_paid,
            net_dividends_paid=net_dividends_paid,
            other_financing_activities=other_financing_activities,
            net_cash_from_financing_activities=net_cash_from_financing_activities,
            effect_of_exchange_rate_changes_on_cash=effect_of_exchange_rate_changes_on_cash,
            net_change_in_cash_and_equivalents=net_change_in_cash_and_equivalents,
            cash_at_beginning_of_period=cash_at_beginning_of_period,
            cash_at_end_of_period=cash_at_end_of_period,
            operating_cash_flow=operating_cash_flow,
            capital_expenditure=capital_expenditure,
            income_taxes_paid=income_taxes_paid,
            interest_paid=interest_paid,
            free_cash_flow=free_cash_flow,
        )

        fmp_cash_flow_statement_data.additional_properties = d
        return fmp_cash_flow_statement_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
