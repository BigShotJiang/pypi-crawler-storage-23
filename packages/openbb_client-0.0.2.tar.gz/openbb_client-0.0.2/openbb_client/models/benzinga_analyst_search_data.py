from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="BenzingaAnalystSearchData")


@_attrs_define
class BenzingaAnalystSearchData:
    """Benzinga Analyst Search Data.

    Attributes:
        name_full (str): Analyst full name.
        last_updated (datetime.datetime | None | Unset): Date of the last update.
        firm_name (None | str | Unset): Firm name of the analyst.
        name_first (None | str | Unset): Analyst first name.
        name_last (None | str | Unset): Analyst last name.
        analyst_id (None | str | Unset): ID of the analyst.
        firm_id (None | str | Unset): ID of the analyst firm.
        smart_score (float | None | Unset): A weighted average of the total_ratings_percentile,
            overall_avg_return_percentile, and overall_success_rate
        overall_success_rate (float | None | Unset): The percentage (normalized) of gain/loss ratings that resulted in a
            gain overall.
        overall_avg_return_percentile (float | None | Unset): The percentile (normalized) of this analyst's overall
            average return per rating in comparison to other analysts' overall average returns per rating.
        total_ratings_percentile (float | None | Unset): The percentile (normalized) of this analyst's total number of
            ratings in comparison to the total number of ratings published by all other analysts
        total_ratings (int | None | Unset): Number of recommendations made by this analyst.
        overall_gain_count (int | None | Unset): The number of ratings that have gained value since the date of
            recommendation
        overall_loss_count (int | None | Unset): The number of ratings that have lost value since the date of
            recommendation
        overall_average_return (float | None | Unset): The average percent (normalized) price difference per rating
            since the date of recommendation
        overall_std_dev (float | None | Unset): The standard deviation in percent (normalized) price difference in the
            analyst's ratings since the date of recommendation
        gain_count_1m (int | None | Unset): The number of ratings that have gained value over the last month
        loss_count_1m (int | None | Unset): The number of ratings that have lost value over the last month
        average_return_1m (float | None | Unset): The average percent (normalized) price difference per rating over the
            last month
        std_dev_1m (float | None | Unset): The standard deviation in percent (normalized) price difference in the
            analyst's ratings over the last month
        smart_score_1m (float | None | Unset): A weighted average smart score over the last month.
        success_rate_1m (float | None | Unset): The percentage (normalized) of gain/loss ratings that resulted in a gain
            over the last month
        gain_count_3m (int | None | Unset): The number of ratings that have gained value over the last 3 months
        loss_count_3m (int | None | Unset): The number of ratings that have lost value over the last 3 months
        average_return_3m (float | None | Unset): The average percent (normalized) price difference per rating over the
            last 3 months
        std_dev_3m (float | None | Unset): The standard deviation in percent (normalized) price difference in the
            analyst's ratings over the last 3 months
        smart_score_3m (float | None | Unset): A weighted average smart score over the last 3 months.
        success_rate_3m (float | None | Unset): The percentage (normalized) of gain/loss ratings that resulted in a gain
            over the last 3 months
        gain_count_6m (int | None | Unset): The number of ratings that have gained value over the last 6 months
        loss_count_6m (int | None | Unset): The number of ratings that have lost value over the last 6 months
        average_return_6m (float | None | Unset): The average percent (normalized) price difference per rating over the
            last 6 months
        std_dev_6m (float | None | Unset): The standard deviation in percent (normalized) price difference in the
            analyst's ratings over the last 6 months
        gain_count_9m (int | None | Unset): The number of ratings that have gained value over the last 9 months
        loss_count_9m (int | None | Unset): The number of ratings that have lost value over the last 9 months
        average_return_9m (float | None | Unset): The average percent (normalized) price difference per rating over the
            last 9 months
        std_dev_9m (float | None | Unset): The standard deviation in percent (normalized) price difference in the
            analyst's ratings over the last 9 months
        smart_score_9m (float | None | Unset): A weighted average smart score over the last 9 months.
        success_rate_9m (float | None | Unset): The percentage (normalized) of gain/loss ratings that resulted in a gain
            over the last 9 months
        gain_count_1y (int | None | Unset): The number of ratings that have gained value over the last 1 year
        loss_count_1y (int | None | Unset): The number of ratings that have lost value over the last 1 year
        average_return_1y (float | None | Unset): The average percent (normalized) price difference per rating over the
            last 1 year
        std_dev_1y (float | None | Unset): The standard deviation in percent (normalized) price difference in the
            analyst's ratings over the last 1 year
        smart_score_1y (float | None | Unset): A weighted average smart score over the last 1 year.
        success_rate_1y (float | None | Unset): The percentage (normalized) of gain/loss ratings that resulted in a gain
            over the last 1 year
        gain_count_2y (int | None | Unset): The number of ratings that have gained value over the last 2 years
        loss_count_2y (int | None | Unset): The number of ratings that have lost value over the last 2 years
        average_return_2y (float | None | Unset): The average percent (normalized) price difference per rating over the
            last 2 years
        std_dev_2y (float | None | Unset): The standard deviation in percent (normalized) price difference in the
            analyst's ratings over the last 2 years
        smart_score_2y (float | None | Unset): A weighted average smart score over the last 3 years.
        success_rate_2y (float | None | Unset): The percentage (normalized) of gain/loss ratings that resulted in a gain
            over the last 2 years
        gain_count_3y (int | None | Unset): The number of ratings that have gained value over the last 3 years
        loss_count_3y (int | None | Unset): The number of ratings that have lost value over the last 3 years
        average_return_3y (float | None | Unset): The average percent (normalized) price difference per rating over the
            last 3 years
        std_dev_3y (float | None | Unset): The standard deviation in percent (normalized) price difference in the
            analyst's ratings over the last 3 years
        smart_score_3y (float | None | Unset): A weighted average smart score over the last 3 years.
        success_rate_3y (float | None | Unset): The percentage (normalized) of gain/loss ratings that resulted in a gain
            over the last 3 years
    """

    name_full: str
    last_updated: datetime.datetime | None | Unset = UNSET
    firm_name: None | str | Unset = UNSET
    name_first: None | str | Unset = UNSET
    name_last: None | str | Unset = UNSET
    analyst_id: None | str | Unset = UNSET
    firm_id: None | str | Unset = UNSET
    smart_score: float | None | Unset = UNSET
    overall_success_rate: float | None | Unset = UNSET
    overall_avg_return_percentile: float | None | Unset = UNSET
    total_ratings_percentile: float | None | Unset = UNSET
    total_ratings: int | None | Unset = UNSET
    overall_gain_count: int | None | Unset = UNSET
    overall_loss_count: int | None | Unset = UNSET
    overall_average_return: float | None | Unset = UNSET
    overall_std_dev: float | None | Unset = UNSET
    gain_count_1m: int | None | Unset = UNSET
    loss_count_1m: int | None | Unset = UNSET
    average_return_1m: float | None | Unset = UNSET
    std_dev_1m: float | None | Unset = UNSET
    smart_score_1m: float | None | Unset = UNSET
    success_rate_1m: float | None | Unset = UNSET
    gain_count_3m: int | None | Unset = UNSET
    loss_count_3m: int | None | Unset = UNSET
    average_return_3m: float | None | Unset = UNSET
    std_dev_3m: float | None | Unset = UNSET
    smart_score_3m: float | None | Unset = UNSET
    success_rate_3m: float | None | Unset = UNSET
    gain_count_6m: int | None | Unset = UNSET
    loss_count_6m: int | None | Unset = UNSET
    average_return_6m: float | None | Unset = UNSET
    std_dev_6m: float | None | Unset = UNSET
    gain_count_9m: int | None | Unset = UNSET
    loss_count_9m: int | None | Unset = UNSET
    average_return_9m: float | None | Unset = UNSET
    std_dev_9m: float | None | Unset = UNSET
    smart_score_9m: float | None | Unset = UNSET
    success_rate_9m: float | None | Unset = UNSET
    gain_count_1y: int | None | Unset = UNSET
    loss_count_1y: int | None | Unset = UNSET
    average_return_1y: float | None | Unset = UNSET
    std_dev_1y: float | None | Unset = UNSET
    smart_score_1y: float | None | Unset = UNSET
    success_rate_1y: float | None | Unset = UNSET
    gain_count_2y: int | None | Unset = UNSET
    loss_count_2y: int | None | Unset = UNSET
    average_return_2y: float | None | Unset = UNSET
    std_dev_2y: float | None | Unset = UNSET
    smart_score_2y: float | None | Unset = UNSET
    success_rate_2y: float | None | Unset = UNSET
    gain_count_3y: int | None | Unset = UNSET
    loss_count_3y: int | None | Unset = UNSET
    average_return_3y: float | None | Unset = UNSET
    std_dev_3y: float | None | Unset = UNSET
    smart_score_3y: float | None | Unset = UNSET
    success_rate_3y: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name_full = self.name_full

        last_updated: None | str | Unset
        if isinstance(self.last_updated, Unset):
            last_updated = UNSET
        elif isinstance(self.last_updated, datetime.datetime):
            last_updated = self.last_updated.isoformat()
        else:
            last_updated = self.last_updated

        firm_name: None | str | Unset
        if isinstance(self.firm_name, Unset):
            firm_name = UNSET
        else:
            firm_name = self.firm_name

        name_first: None | str | Unset
        if isinstance(self.name_first, Unset):
            name_first = UNSET
        else:
            name_first = self.name_first

        name_last: None | str | Unset
        if isinstance(self.name_last, Unset):
            name_last = UNSET
        else:
            name_last = self.name_last

        analyst_id: None | str | Unset
        if isinstance(self.analyst_id, Unset):
            analyst_id = UNSET
        else:
            analyst_id = self.analyst_id

        firm_id: None | str | Unset
        if isinstance(self.firm_id, Unset):
            firm_id = UNSET
        else:
            firm_id = self.firm_id

        smart_score: float | None | Unset
        if isinstance(self.smart_score, Unset):
            smart_score = UNSET
        else:
            smart_score = self.smart_score

        overall_success_rate: float | None | Unset
        if isinstance(self.overall_success_rate, Unset):
            overall_success_rate = UNSET
        else:
            overall_success_rate = self.overall_success_rate

        overall_avg_return_percentile: float | None | Unset
        if isinstance(self.overall_avg_return_percentile, Unset):
            overall_avg_return_percentile = UNSET
        else:
            overall_avg_return_percentile = self.overall_avg_return_percentile

        total_ratings_percentile: float | None | Unset
        if isinstance(self.total_ratings_percentile, Unset):
            total_ratings_percentile = UNSET
        else:
            total_ratings_percentile = self.total_ratings_percentile

        total_ratings: int | None | Unset
        if isinstance(self.total_ratings, Unset):
            total_ratings = UNSET
        else:
            total_ratings = self.total_ratings

        overall_gain_count: int | None | Unset
        if isinstance(self.overall_gain_count, Unset):
            overall_gain_count = UNSET
        else:
            overall_gain_count = self.overall_gain_count

        overall_loss_count: int | None | Unset
        if isinstance(self.overall_loss_count, Unset):
            overall_loss_count = UNSET
        else:
            overall_loss_count = self.overall_loss_count

        overall_average_return: float | None | Unset
        if isinstance(self.overall_average_return, Unset):
            overall_average_return = UNSET
        else:
            overall_average_return = self.overall_average_return

        overall_std_dev: float | None | Unset
        if isinstance(self.overall_std_dev, Unset):
            overall_std_dev = UNSET
        else:
            overall_std_dev = self.overall_std_dev

        gain_count_1m: int | None | Unset
        if isinstance(self.gain_count_1m, Unset):
            gain_count_1m = UNSET
        else:
            gain_count_1m = self.gain_count_1m

        loss_count_1m: int | None | Unset
        if isinstance(self.loss_count_1m, Unset):
            loss_count_1m = UNSET
        else:
            loss_count_1m = self.loss_count_1m

        average_return_1m: float | None | Unset
        if isinstance(self.average_return_1m, Unset):
            average_return_1m = UNSET
        else:
            average_return_1m = self.average_return_1m

        std_dev_1m: float | None | Unset
        if isinstance(self.std_dev_1m, Unset):
            std_dev_1m = UNSET
        else:
            std_dev_1m = self.std_dev_1m

        smart_score_1m: float | None | Unset
        if isinstance(self.smart_score_1m, Unset):
            smart_score_1m = UNSET
        else:
            smart_score_1m = self.smart_score_1m

        success_rate_1m: float | None | Unset
        if isinstance(self.success_rate_1m, Unset):
            success_rate_1m = UNSET
        else:
            success_rate_1m = self.success_rate_1m

        gain_count_3m: int | None | Unset
        if isinstance(self.gain_count_3m, Unset):
            gain_count_3m = UNSET
        else:
            gain_count_3m = self.gain_count_3m

        loss_count_3m: int | None | Unset
        if isinstance(self.loss_count_3m, Unset):
            loss_count_3m = UNSET
        else:
            loss_count_3m = self.loss_count_3m

        average_return_3m: float | None | Unset
        if isinstance(self.average_return_3m, Unset):
            average_return_3m = UNSET
        else:
            average_return_3m = self.average_return_3m

        std_dev_3m: float | None | Unset
        if isinstance(self.std_dev_3m, Unset):
            std_dev_3m = UNSET
        else:
            std_dev_3m = self.std_dev_3m

        smart_score_3m: float | None | Unset
        if isinstance(self.smart_score_3m, Unset):
            smart_score_3m = UNSET
        else:
            smart_score_3m = self.smart_score_3m

        success_rate_3m: float | None | Unset
        if isinstance(self.success_rate_3m, Unset):
            success_rate_3m = UNSET
        else:
            success_rate_3m = self.success_rate_3m

        gain_count_6m: int | None | Unset
        if isinstance(self.gain_count_6m, Unset):
            gain_count_6m = UNSET
        else:
            gain_count_6m = self.gain_count_6m

        loss_count_6m: int | None | Unset
        if isinstance(self.loss_count_6m, Unset):
            loss_count_6m = UNSET
        else:
            loss_count_6m = self.loss_count_6m

        average_return_6m: float | None | Unset
        if isinstance(self.average_return_6m, Unset):
            average_return_6m = UNSET
        else:
            average_return_6m = self.average_return_6m

        std_dev_6m: float | None | Unset
        if isinstance(self.std_dev_6m, Unset):
            std_dev_6m = UNSET
        else:
            std_dev_6m = self.std_dev_6m

        gain_count_9m: int | None | Unset
        if isinstance(self.gain_count_9m, Unset):
            gain_count_9m = UNSET
        else:
            gain_count_9m = self.gain_count_9m

        loss_count_9m: int | None | Unset
        if isinstance(self.loss_count_9m, Unset):
            loss_count_9m = UNSET
        else:
            loss_count_9m = self.loss_count_9m

        average_return_9m: float | None | Unset
        if isinstance(self.average_return_9m, Unset):
            average_return_9m = UNSET
        else:
            average_return_9m = self.average_return_9m

        std_dev_9m: float | None | Unset
        if isinstance(self.std_dev_9m, Unset):
            std_dev_9m = UNSET
        else:
            std_dev_9m = self.std_dev_9m

        smart_score_9m: float | None | Unset
        if isinstance(self.smart_score_9m, Unset):
            smart_score_9m = UNSET
        else:
            smart_score_9m = self.smart_score_9m

        success_rate_9m: float | None | Unset
        if isinstance(self.success_rate_9m, Unset):
            success_rate_9m = UNSET
        else:
            success_rate_9m = self.success_rate_9m

        gain_count_1y: int | None | Unset
        if isinstance(self.gain_count_1y, Unset):
            gain_count_1y = UNSET
        else:
            gain_count_1y = self.gain_count_1y

        loss_count_1y: int | None | Unset
        if isinstance(self.loss_count_1y, Unset):
            loss_count_1y = UNSET
        else:
            loss_count_1y = self.loss_count_1y

        average_return_1y: float | None | Unset
        if isinstance(self.average_return_1y, Unset):
            average_return_1y = UNSET
        else:
            average_return_1y = self.average_return_1y

        std_dev_1y: float | None | Unset
        if isinstance(self.std_dev_1y, Unset):
            std_dev_1y = UNSET
        else:
            std_dev_1y = self.std_dev_1y

        smart_score_1y: float | None | Unset
        if isinstance(self.smart_score_1y, Unset):
            smart_score_1y = UNSET
        else:
            smart_score_1y = self.smart_score_1y

        success_rate_1y: float | None | Unset
        if isinstance(self.success_rate_1y, Unset):
            success_rate_1y = UNSET
        else:
            success_rate_1y = self.success_rate_1y

        gain_count_2y: int | None | Unset
        if isinstance(self.gain_count_2y, Unset):
            gain_count_2y = UNSET
        else:
            gain_count_2y = self.gain_count_2y

        loss_count_2y: int | None | Unset
        if isinstance(self.loss_count_2y, Unset):
            loss_count_2y = UNSET
        else:
            loss_count_2y = self.loss_count_2y

        average_return_2y: float | None | Unset
        if isinstance(self.average_return_2y, Unset):
            average_return_2y = UNSET
        else:
            average_return_2y = self.average_return_2y

        std_dev_2y: float | None | Unset
        if isinstance(self.std_dev_2y, Unset):
            std_dev_2y = UNSET
        else:
            std_dev_2y = self.std_dev_2y

        smart_score_2y: float | None | Unset
        if isinstance(self.smart_score_2y, Unset):
            smart_score_2y = UNSET
        else:
            smart_score_2y = self.smart_score_2y

        success_rate_2y: float | None | Unset
        if isinstance(self.success_rate_2y, Unset):
            success_rate_2y = UNSET
        else:
            success_rate_2y = self.success_rate_2y

        gain_count_3y: int | None | Unset
        if isinstance(self.gain_count_3y, Unset):
            gain_count_3y = UNSET
        else:
            gain_count_3y = self.gain_count_3y

        loss_count_3y: int | None | Unset
        if isinstance(self.loss_count_3y, Unset):
            loss_count_3y = UNSET
        else:
            loss_count_3y = self.loss_count_3y

        average_return_3y: float | None | Unset
        if isinstance(self.average_return_3y, Unset):
            average_return_3y = UNSET
        else:
            average_return_3y = self.average_return_3y

        std_dev_3y: float | None | Unset
        if isinstance(self.std_dev_3y, Unset):
            std_dev_3y = UNSET
        else:
            std_dev_3y = self.std_dev_3y

        smart_score_3y: float | None | Unset
        if isinstance(self.smart_score_3y, Unset):
            smart_score_3y = UNSET
        else:
            smart_score_3y = self.smart_score_3y

        success_rate_3y: float | None | Unset
        if isinstance(self.success_rate_3y, Unset):
            success_rate_3y = UNSET
        else:
            success_rate_3y = self.success_rate_3y

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name_full": name_full,
            }
        )
        if last_updated is not UNSET:
            field_dict["last_updated"] = last_updated
        if firm_name is not UNSET:
            field_dict["firm_name"] = firm_name
        if name_first is not UNSET:
            field_dict["name_first"] = name_first
        if name_last is not UNSET:
            field_dict["name_last"] = name_last
        if analyst_id is not UNSET:
            field_dict["analyst_id"] = analyst_id
        if firm_id is not UNSET:
            field_dict["firm_id"] = firm_id
        if smart_score is not UNSET:
            field_dict["smart_score"] = smart_score
        if overall_success_rate is not UNSET:
            field_dict["overall_success_rate"] = overall_success_rate
        if overall_avg_return_percentile is not UNSET:
            field_dict["overall_avg_return_percentile"] = overall_avg_return_percentile
        if total_ratings_percentile is not UNSET:
            field_dict["total_ratings_percentile"] = total_ratings_percentile
        if total_ratings is not UNSET:
            field_dict["total_ratings"] = total_ratings
        if overall_gain_count is not UNSET:
            field_dict["overall_gain_count"] = overall_gain_count
        if overall_loss_count is not UNSET:
            field_dict["overall_loss_count"] = overall_loss_count
        if overall_average_return is not UNSET:
            field_dict["overall_average_return"] = overall_average_return
        if overall_std_dev is not UNSET:
            field_dict["overall_std_dev"] = overall_std_dev
        if gain_count_1m is not UNSET:
            field_dict["gain_count_1m"] = gain_count_1m
        if loss_count_1m is not UNSET:
            field_dict["loss_count_1m"] = loss_count_1m
        if average_return_1m is not UNSET:
            field_dict["average_return_1m"] = average_return_1m
        if std_dev_1m is not UNSET:
            field_dict["std_dev_1m"] = std_dev_1m
        if smart_score_1m is not UNSET:
            field_dict["smart_score_1m"] = smart_score_1m
        if success_rate_1m is not UNSET:
            field_dict["success_rate_1m"] = success_rate_1m
        if gain_count_3m is not UNSET:
            field_dict["gain_count_3m"] = gain_count_3m
        if loss_count_3m is not UNSET:
            field_dict["loss_count_3m"] = loss_count_3m
        if average_return_3m is not UNSET:
            field_dict["average_return_3m"] = average_return_3m
        if std_dev_3m is not UNSET:
            field_dict["std_dev_3m"] = std_dev_3m
        if smart_score_3m is not UNSET:
            field_dict["smart_score_3m"] = smart_score_3m
        if success_rate_3m is not UNSET:
            field_dict["success_rate_3m"] = success_rate_3m
        if gain_count_6m is not UNSET:
            field_dict["gain_count_6m"] = gain_count_6m
        if loss_count_6m is not UNSET:
            field_dict["loss_count_6m"] = loss_count_6m
        if average_return_6m is not UNSET:
            field_dict["average_return_6m"] = average_return_6m
        if std_dev_6m is not UNSET:
            field_dict["std_dev_6m"] = std_dev_6m
        if gain_count_9m is not UNSET:
            field_dict["gain_count_9m"] = gain_count_9m
        if loss_count_9m is not UNSET:
            field_dict["loss_count_9m"] = loss_count_9m
        if average_return_9m is not UNSET:
            field_dict["average_return_9m"] = average_return_9m
        if std_dev_9m is not UNSET:
            field_dict["std_dev_9m"] = std_dev_9m
        if smart_score_9m is not UNSET:
            field_dict["smart_score_9m"] = smart_score_9m
        if success_rate_9m is not UNSET:
            field_dict["success_rate_9m"] = success_rate_9m
        if gain_count_1y is not UNSET:
            field_dict["gain_count_1y"] = gain_count_1y
        if loss_count_1y is not UNSET:
            field_dict["loss_count_1y"] = loss_count_1y
        if average_return_1y is not UNSET:
            field_dict["average_return_1y"] = average_return_1y
        if std_dev_1y is not UNSET:
            field_dict["std_dev_1y"] = std_dev_1y
        if smart_score_1y is not UNSET:
            field_dict["smart_score_1y"] = smart_score_1y
        if success_rate_1y is not UNSET:
            field_dict["success_rate_1y"] = success_rate_1y
        if gain_count_2y is not UNSET:
            field_dict["gain_count_2y"] = gain_count_2y
        if loss_count_2y is not UNSET:
            field_dict["loss_count_2y"] = loss_count_2y
        if average_return_2y is not UNSET:
            field_dict["average_return_2y"] = average_return_2y
        if std_dev_2y is not UNSET:
            field_dict["std_dev_2y"] = std_dev_2y
        if smart_score_2y is not UNSET:
            field_dict["smart_score_2y"] = smart_score_2y
        if success_rate_2y is not UNSET:
            field_dict["success_rate_2y"] = success_rate_2y
        if gain_count_3y is not UNSET:
            field_dict["gain_count_3y"] = gain_count_3y
        if loss_count_3y is not UNSET:
            field_dict["loss_count_3y"] = loss_count_3y
        if average_return_3y is not UNSET:
            field_dict["average_return_3y"] = average_return_3y
        if std_dev_3y is not UNSET:
            field_dict["std_dev_3y"] = std_dev_3y
        if smart_score_3y is not UNSET:
            field_dict["smart_score_3y"] = smart_score_3y
        if success_rate_3y is not UNSET:
            field_dict["success_rate_3y"] = success_rate_3y

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name_full = d.pop("name_full")

        def _parse_last_updated(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_updated_type_0 = isoparse(data)

                return last_updated_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_updated = _parse_last_updated(d.pop("last_updated", UNSET))

        def _parse_firm_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        firm_name = _parse_firm_name(d.pop("firm_name", UNSET))

        def _parse_name_first(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name_first = _parse_name_first(d.pop("name_first", UNSET))

        def _parse_name_last(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name_last = _parse_name_last(d.pop("name_last", UNSET))

        def _parse_analyst_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        analyst_id = _parse_analyst_id(d.pop("analyst_id", UNSET))

        def _parse_firm_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        firm_id = _parse_firm_id(d.pop("firm_id", UNSET))

        def _parse_smart_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        smart_score = _parse_smart_score(d.pop("smart_score", UNSET))

        def _parse_overall_success_rate(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        overall_success_rate = _parse_overall_success_rate(d.pop("overall_success_rate", UNSET))

        def _parse_overall_avg_return_percentile(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        overall_avg_return_percentile = _parse_overall_avg_return_percentile(
            d.pop("overall_avg_return_percentile", UNSET)
        )

        def _parse_total_ratings_percentile(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        total_ratings_percentile = _parse_total_ratings_percentile(d.pop("total_ratings_percentile", UNSET))

        def _parse_total_ratings(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_ratings = _parse_total_ratings(d.pop("total_ratings", UNSET))

        def _parse_overall_gain_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        overall_gain_count = _parse_overall_gain_count(d.pop("overall_gain_count", UNSET))

        def _parse_overall_loss_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        overall_loss_count = _parse_overall_loss_count(d.pop("overall_loss_count", UNSET))

        def _parse_overall_average_return(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        overall_average_return = _parse_overall_average_return(d.pop("overall_average_return", UNSET))

        def _parse_overall_std_dev(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        overall_std_dev = _parse_overall_std_dev(d.pop("overall_std_dev", UNSET))

        def _parse_gain_count_1m(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        gain_count_1m = _parse_gain_count_1m(d.pop("gain_count_1m", UNSET))

        def _parse_loss_count_1m(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        loss_count_1m = _parse_loss_count_1m(d.pop("loss_count_1m", UNSET))

        def _parse_average_return_1m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        average_return_1m = _parse_average_return_1m(d.pop("average_return_1m", UNSET))

        def _parse_std_dev_1m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        std_dev_1m = _parse_std_dev_1m(d.pop("std_dev_1m", UNSET))

        def _parse_smart_score_1m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        smart_score_1m = _parse_smart_score_1m(d.pop("smart_score_1m", UNSET))

        def _parse_success_rate_1m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        success_rate_1m = _parse_success_rate_1m(d.pop("success_rate_1m", UNSET))

        def _parse_gain_count_3m(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        gain_count_3m = _parse_gain_count_3m(d.pop("gain_count_3m", UNSET))

        def _parse_loss_count_3m(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        loss_count_3m = _parse_loss_count_3m(d.pop("loss_count_3m", UNSET))

        def _parse_average_return_3m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        average_return_3m = _parse_average_return_3m(d.pop("average_return_3m", UNSET))

        def _parse_std_dev_3m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        std_dev_3m = _parse_std_dev_3m(d.pop("std_dev_3m", UNSET))

        def _parse_smart_score_3m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        smart_score_3m = _parse_smart_score_3m(d.pop("smart_score_3m", UNSET))

        def _parse_success_rate_3m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        success_rate_3m = _parse_success_rate_3m(d.pop("success_rate_3m", UNSET))

        def _parse_gain_count_6m(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        gain_count_6m = _parse_gain_count_6m(d.pop("gain_count_6m", UNSET))

        def _parse_loss_count_6m(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        loss_count_6m = _parse_loss_count_6m(d.pop("loss_count_6m", UNSET))

        def _parse_average_return_6m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        average_return_6m = _parse_average_return_6m(d.pop("average_return_6m", UNSET))

        def _parse_std_dev_6m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        std_dev_6m = _parse_std_dev_6m(d.pop("std_dev_6m", UNSET))

        def _parse_gain_count_9m(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        gain_count_9m = _parse_gain_count_9m(d.pop("gain_count_9m", UNSET))

        def _parse_loss_count_9m(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        loss_count_9m = _parse_loss_count_9m(d.pop("loss_count_9m", UNSET))

        def _parse_average_return_9m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        average_return_9m = _parse_average_return_9m(d.pop("average_return_9m", UNSET))

        def _parse_std_dev_9m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        std_dev_9m = _parse_std_dev_9m(d.pop("std_dev_9m", UNSET))

        def _parse_smart_score_9m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        smart_score_9m = _parse_smart_score_9m(d.pop("smart_score_9m", UNSET))

        def _parse_success_rate_9m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        success_rate_9m = _parse_success_rate_9m(d.pop("success_rate_9m", UNSET))

        def _parse_gain_count_1y(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        gain_count_1y = _parse_gain_count_1y(d.pop("gain_count_1y", UNSET))

        def _parse_loss_count_1y(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        loss_count_1y = _parse_loss_count_1y(d.pop("loss_count_1y", UNSET))

        def _parse_average_return_1y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        average_return_1y = _parse_average_return_1y(d.pop("average_return_1y", UNSET))

        def _parse_std_dev_1y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        std_dev_1y = _parse_std_dev_1y(d.pop("std_dev_1y", UNSET))

        def _parse_smart_score_1y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        smart_score_1y = _parse_smart_score_1y(d.pop("smart_score_1y", UNSET))

        def _parse_success_rate_1y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        success_rate_1y = _parse_success_rate_1y(d.pop("success_rate_1y", UNSET))

        def _parse_gain_count_2y(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        gain_count_2y = _parse_gain_count_2y(d.pop("gain_count_2y", UNSET))

        def _parse_loss_count_2y(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        loss_count_2y = _parse_loss_count_2y(d.pop("loss_count_2y", UNSET))

        def _parse_average_return_2y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        average_return_2y = _parse_average_return_2y(d.pop("average_return_2y", UNSET))

        def _parse_std_dev_2y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        std_dev_2y = _parse_std_dev_2y(d.pop("std_dev_2y", UNSET))

        def _parse_smart_score_2y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        smart_score_2y = _parse_smart_score_2y(d.pop("smart_score_2y", UNSET))

        def _parse_success_rate_2y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        success_rate_2y = _parse_success_rate_2y(d.pop("success_rate_2y", UNSET))

        def _parse_gain_count_3y(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        gain_count_3y = _parse_gain_count_3y(d.pop("gain_count_3y", UNSET))

        def _parse_loss_count_3y(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        loss_count_3y = _parse_loss_count_3y(d.pop("loss_count_3y", UNSET))

        def _parse_average_return_3y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        average_return_3y = _parse_average_return_3y(d.pop("average_return_3y", UNSET))

        def _parse_std_dev_3y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        std_dev_3y = _parse_std_dev_3y(d.pop("std_dev_3y", UNSET))

        def _parse_smart_score_3y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        smart_score_3y = _parse_smart_score_3y(d.pop("smart_score_3y", UNSET))

        def _parse_success_rate_3y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        success_rate_3y = _parse_success_rate_3y(d.pop("success_rate_3y", UNSET))

        benzinga_analyst_search_data = cls(
            name_full=name_full,
            last_updated=last_updated,
            firm_name=firm_name,
            name_first=name_first,
            name_last=name_last,
            analyst_id=analyst_id,
            firm_id=firm_id,
            smart_score=smart_score,
            overall_success_rate=overall_success_rate,
            overall_avg_return_percentile=overall_avg_return_percentile,
            total_ratings_percentile=total_ratings_percentile,
            total_ratings=total_ratings,
            overall_gain_count=overall_gain_count,
            overall_loss_count=overall_loss_count,
            overall_average_return=overall_average_return,
            overall_std_dev=overall_std_dev,
            gain_count_1m=gain_count_1m,
            loss_count_1m=loss_count_1m,
            average_return_1m=average_return_1m,
            std_dev_1m=std_dev_1m,
            smart_score_1m=smart_score_1m,
            success_rate_1m=success_rate_1m,
            gain_count_3m=gain_count_3m,
            loss_count_3m=loss_count_3m,
            average_return_3m=average_return_3m,
            std_dev_3m=std_dev_3m,
            smart_score_3m=smart_score_3m,
            success_rate_3m=success_rate_3m,
            gain_count_6m=gain_count_6m,
            loss_count_6m=loss_count_6m,
            average_return_6m=average_return_6m,
            std_dev_6m=std_dev_6m,
            gain_count_9m=gain_count_9m,
            loss_count_9m=loss_count_9m,
            average_return_9m=average_return_9m,
            std_dev_9m=std_dev_9m,
            smart_score_9m=smart_score_9m,
            success_rate_9m=success_rate_9m,
            gain_count_1y=gain_count_1y,
            loss_count_1y=loss_count_1y,
            average_return_1y=average_return_1y,
            std_dev_1y=std_dev_1y,
            smart_score_1y=smart_score_1y,
            success_rate_1y=success_rate_1y,
            gain_count_2y=gain_count_2y,
            loss_count_2y=loss_count_2y,
            average_return_2y=average_return_2y,
            std_dev_2y=std_dev_2y,
            smart_score_2y=smart_score_2y,
            success_rate_2y=success_rate_2y,
            gain_count_3y=gain_count_3y,
            loss_count_3y=loss_count_3y,
            average_return_3y=average_return_3y,
            std_dev_3y=std_dev_3y,
            smart_score_3y=smart_score_3y,
            success_rate_3y=success_rate_3y,
        )

        benzinga_analyst_search_data.additional_properties = d
        return benzinga_analyst_search_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
