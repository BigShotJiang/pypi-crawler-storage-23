from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPCalendarIpoData")


@_attrs_define
class FMPCalendarIpoData:
    """FMP Earnings Calendar Data.

    Attributes:
        symbol (None | str | Unset): Symbol representing the entity requested in the data.
        ipo_date (datetime.date | None | Unset): The date of the IPO, when the stock first trades on a major exchange.
        exchange_date (datetime.datetime | None | Unset): Timezone information for the exchange and date of the IPO.
        name (None | str | Unset): The name of the entity going public.
        exchange (None | str | Unset): The exchange where the IPO is listed.
        actions (None | str | Unset): Actions related to the IPO, such as, Expected, Priced, Filed, Amended.
        shares (float | int | None | Unset): The number of shares being offered in the IPO.
        price_range (None | str | Unset): The expected price range for the IPO shares.
        market_cap (float | int | None | Unset): The estimated market capitalization of the company at the time of the
            IPO.
    """

    symbol: None | str | Unset = UNSET
    ipo_date: datetime.date | None | Unset = UNSET
    exchange_date: datetime.datetime | None | Unset = UNSET
    name: None | str | Unset = UNSET
    exchange: None | str | Unset = UNSET
    actions: None | str | Unset = UNSET
    shares: float | int | None | Unset = UNSET
    price_range: None | str | Unset = UNSET
    market_cap: float | int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        symbol: None | str | Unset
        if isinstance(self.symbol, Unset):
            symbol = UNSET
        else:
            symbol = self.symbol

        ipo_date: None | str | Unset
        if isinstance(self.ipo_date, Unset):
            ipo_date = UNSET
        elif isinstance(self.ipo_date, datetime.date):
            ipo_date = self.ipo_date.isoformat()
        else:
            ipo_date = self.ipo_date

        exchange_date: None | str | Unset
        if isinstance(self.exchange_date, Unset):
            exchange_date = UNSET
        elif isinstance(self.exchange_date, datetime.datetime):
            exchange_date = self.exchange_date.isoformat()
        else:
            exchange_date = self.exchange_date

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        exchange: None | str | Unset
        if isinstance(self.exchange, Unset):
            exchange = UNSET
        else:
            exchange = self.exchange

        actions: None | str | Unset
        if isinstance(self.actions, Unset):
            actions = UNSET
        else:
            actions = self.actions

        shares: float | int | None | Unset
        if isinstance(self.shares, Unset):
            shares = UNSET
        else:
            shares = self.shares

        price_range: None | str | Unset
        if isinstance(self.price_range, Unset):
            price_range = UNSET
        else:
            price_range = self.price_range

        market_cap: float | int | None | Unset
        if isinstance(self.market_cap, Unset):
            market_cap = UNSET
        else:
            market_cap = self.market_cap

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if ipo_date is not UNSET:
            field_dict["ipo_date"] = ipo_date
        if exchange_date is not UNSET:
            field_dict["exchange_date"] = exchange_date
        if name is not UNSET:
            field_dict["name"] = name
        if exchange is not UNSET:
            field_dict["exchange"] = exchange
        if actions is not UNSET:
            field_dict["actions"] = actions
        if shares is not UNSET:
            field_dict["shares"] = shares
        if price_range is not UNSET:
            field_dict["price_range"] = price_range
        if market_cap is not UNSET:
            field_dict["market_cap"] = market_cap

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol = _parse_symbol(d.pop("symbol", UNSET))

        def _parse_ipo_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                ipo_date_type_0 = isoparse(data).date()

                return ipo_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        ipo_date = _parse_ipo_date(d.pop("ipo_date", UNSET))

        def _parse_exchange_date(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                exchange_date_type_0 = isoparse(data)

                return exchange_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        exchange_date = _parse_exchange_date(d.pop("exchange_date", UNSET))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_exchange(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        exchange = _parse_exchange(d.pop("exchange", UNSET))

        def _parse_actions(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        actions = _parse_actions(d.pop("actions", UNSET))

        def _parse_shares(data: object) -> float | int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | int | None | Unset, data)

        shares = _parse_shares(d.pop("shares", UNSET))

        def _parse_price_range(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        price_range = _parse_price_range(d.pop("price_range", UNSET))

        def _parse_market_cap(data: object) -> float | int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | int | None | Unset, data)

        market_cap = _parse_market_cap(d.pop("market_cap", UNSET))

        fmp_calendar_ipo_data = cls(
            symbol=symbol,
            ipo_date=ipo_date,
            exchange_date=exchange_date,
            name=name,
            exchange=exchange,
            actions=actions,
            shares=shares,
            price_range=price_range,
            market_cap=market_cap,
        )

        fmp_calendar_ipo_data.additional_properties = d
        return fmp_calendar_ipo_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
