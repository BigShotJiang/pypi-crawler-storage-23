from enum import Enum


class EquityFundamentalBalanceProvider(str, Enum):
    AKSHARE = "akshare"
    FMP = "fmp"
    INTRINIO = "intrinio"
    POLYGON = "polygon"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
