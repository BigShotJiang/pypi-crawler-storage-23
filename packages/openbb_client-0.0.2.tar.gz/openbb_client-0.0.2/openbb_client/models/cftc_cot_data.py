from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="CftcCotData")


@_attrs_define
class CftcCotData:
    """CFTC Commitment of Traders Reports Data.

    Attributes:
        date (datetime.date): The date of the data.
        report_week (None | str | Unset): Report week for the year.
        market_and_exchange_names (None | str | Unset): Market and exchange names.
        cftc_contract_market_code (None | str | Unset): CFTC contract market code.
        cftc_market_code (None | str | Unset): CFTC market code.
        cftc_region_code (None | str | Unset): CFTC region code.
        cftc_commodity_code (None | str | Unset): CFTC commodity code.
        cftc_contract_market_code_quotes (None | str | Unset): CFTC contract market code quotes.
        cftc_market_code_quotes (None | str | Unset): CFTC market code quotes.
        cftc_commodity_code_quotes (None | str | Unset): CFTC commodity code quotes.
        cftc_subgroup_code (None | str | Unset): CFTC subgroup code.
        commodity (None | str | Unset): Commodity.
        commodity_group (None | str | Unset): Commodity group name.
        commodity_subgroup (None | str | Unset): Commodity subgroup name.
        futonly_or_combined (None | str | Unset): If the report is futures-only or combined.
        contract_units (None | str | Unset): Contract units.
    """

    date: datetime.date
    report_week: None | str | Unset = UNSET
    market_and_exchange_names: None | str | Unset = UNSET
    cftc_contract_market_code: None | str | Unset = UNSET
    cftc_market_code: None | str | Unset = UNSET
    cftc_region_code: None | str | Unset = UNSET
    cftc_commodity_code: None | str | Unset = UNSET
    cftc_contract_market_code_quotes: None | str | Unset = UNSET
    cftc_market_code_quotes: None | str | Unset = UNSET
    cftc_commodity_code_quotes: None | str | Unset = UNSET
    cftc_subgroup_code: None | str | Unset = UNSET
    commodity: None | str | Unset = UNSET
    commodity_group: None | str | Unset = UNSET
    commodity_subgroup: None | str | Unset = UNSET
    futonly_or_combined: None | str | Unset = UNSET
    contract_units: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        report_week: None | str | Unset
        if isinstance(self.report_week, Unset):
            report_week = UNSET
        else:
            report_week = self.report_week

        market_and_exchange_names: None | str | Unset
        if isinstance(self.market_and_exchange_names, Unset):
            market_and_exchange_names = UNSET
        else:
            market_and_exchange_names = self.market_and_exchange_names

        cftc_contract_market_code: None | str | Unset
        if isinstance(self.cftc_contract_market_code, Unset):
            cftc_contract_market_code = UNSET
        else:
            cftc_contract_market_code = self.cftc_contract_market_code

        cftc_market_code: None | str | Unset
        if isinstance(self.cftc_market_code, Unset):
            cftc_market_code = UNSET
        else:
            cftc_market_code = self.cftc_market_code

        cftc_region_code: None | str | Unset
        if isinstance(self.cftc_region_code, Unset):
            cftc_region_code = UNSET
        else:
            cftc_region_code = self.cftc_region_code

        cftc_commodity_code: None | str | Unset
        if isinstance(self.cftc_commodity_code, Unset):
            cftc_commodity_code = UNSET
        else:
            cftc_commodity_code = self.cftc_commodity_code

        cftc_contract_market_code_quotes: None | str | Unset
        if isinstance(self.cftc_contract_market_code_quotes, Unset):
            cftc_contract_market_code_quotes = UNSET
        else:
            cftc_contract_market_code_quotes = self.cftc_contract_market_code_quotes

        cftc_market_code_quotes: None | str | Unset
        if isinstance(self.cftc_market_code_quotes, Unset):
            cftc_market_code_quotes = UNSET
        else:
            cftc_market_code_quotes = self.cftc_market_code_quotes

        cftc_commodity_code_quotes: None | str | Unset
        if isinstance(self.cftc_commodity_code_quotes, Unset):
            cftc_commodity_code_quotes = UNSET
        else:
            cftc_commodity_code_quotes = self.cftc_commodity_code_quotes

        cftc_subgroup_code: None | str | Unset
        if isinstance(self.cftc_subgroup_code, Unset):
            cftc_subgroup_code = UNSET
        else:
            cftc_subgroup_code = self.cftc_subgroup_code

        commodity: None | str | Unset
        if isinstance(self.commodity, Unset):
            commodity = UNSET
        else:
            commodity = self.commodity

        commodity_group: None | str | Unset
        if isinstance(self.commodity_group, Unset):
            commodity_group = UNSET
        else:
            commodity_group = self.commodity_group

        commodity_subgroup: None | str | Unset
        if isinstance(self.commodity_subgroup, Unset):
            commodity_subgroup = UNSET
        else:
            commodity_subgroup = self.commodity_subgroup

        futonly_or_combined: None | str | Unset
        if isinstance(self.futonly_or_combined, Unset):
            futonly_or_combined = UNSET
        else:
            futonly_or_combined = self.futonly_or_combined

        contract_units: None | str | Unset
        if isinstance(self.contract_units, Unset):
            contract_units = UNSET
        else:
            contract_units = self.contract_units

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
            }
        )
        if report_week is not UNSET:
            field_dict["report_week"] = report_week
        if market_and_exchange_names is not UNSET:
            field_dict["market_and_exchange_names"] = market_and_exchange_names
        if cftc_contract_market_code is not UNSET:
            field_dict["cftc_contract_market_code"] = cftc_contract_market_code
        if cftc_market_code is not UNSET:
            field_dict["cftc_market_code"] = cftc_market_code
        if cftc_region_code is not UNSET:
            field_dict["cftc_region_code"] = cftc_region_code
        if cftc_commodity_code is not UNSET:
            field_dict["cftc_commodity_code"] = cftc_commodity_code
        if cftc_contract_market_code_quotes is not UNSET:
            field_dict["cftc_contract_market_code_quotes"] = cftc_contract_market_code_quotes
        if cftc_market_code_quotes is not UNSET:
            field_dict["cftc_market_code_quotes"] = cftc_market_code_quotes
        if cftc_commodity_code_quotes is not UNSET:
            field_dict["cftc_commodity_code_quotes"] = cftc_commodity_code_quotes
        if cftc_subgroup_code is not UNSET:
            field_dict["cftc_subgroup_code"] = cftc_subgroup_code
        if commodity is not UNSET:
            field_dict["commodity"] = commodity
        if commodity_group is not UNSET:
            field_dict["commodity_group"] = commodity_group
        if commodity_subgroup is not UNSET:
            field_dict["commodity_subgroup"] = commodity_subgroup
        if futonly_or_combined is not UNSET:
            field_dict["futonly_or_combined"] = futonly_or_combined
        if contract_units is not UNSET:
            field_dict["contract_units"] = contract_units

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        def _parse_report_week(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        report_week = _parse_report_week(d.pop("report_week", UNSET))

        def _parse_market_and_exchange_names(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        market_and_exchange_names = _parse_market_and_exchange_names(d.pop("market_and_exchange_names", UNSET))

        def _parse_cftc_contract_market_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cftc_contract_market_code = _parse_cftc_contract_market_code(d.pop("cftc_contract_market_code", UNSET))

        def _parse_cftc_market_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cftc_market_code = _parse_cftc_market_code(d.pop("cftc_market_code", UNSET))

        def _parse_cftc_region_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cftc_region_code = _parse_cftc_region_code(d.pop("cftc_region_code", UNSET))

        def _parse_cftc_commodity_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cftc_commodity_code = _parse_cftc_commodity_code(d.pop("cftc_commodity_code", UNSET))

        def _parse_cftc_contract_market_code_quotes(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cftc_contract_market_code_quotes = _parse_cftc_contract_market_code_quotes(
            d.pop("cftc_contract_market_code_quotes", UNSET)
        )

        def _parse_cftc_market_code_quotes(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cftc_market_code_quotes = _parse_cftc_market_code_quotes(d.pop("cftc_market_code_quotes", UNSET))

        def _parse_cftc_commodity_code_quotes(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cftc_commodity_code_quotes = _parse_cftc_commodity_code_quotes(d.pop("cftc_commodity_code_quotes", UNSET))

        def _parse_cftc_subgroup_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cftc_subgroup_code = _parse_cftc_subgroup_code(d.pop("cftc_subgroup_code", UNSET))

        def _parse_commodity(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        commodity = _parse_commodity(d.pop("commodity", UNSET))

        def _parse_commodity_group(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        commodity_group = _parse_commodity_group(d.pop("commodity_group", UNSET))

        def _parse_commodity_subgroup(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        commodity_subgroup = _parse_commodity_subgroup(d.pop("commodity_subgroup", UNSET))

        def _parse_futonly_or_combined(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        futonly_or_combined = _parse_futonly_or_combined(d.pop("futonly_or_combined", UNSET))

        def _parse_contract_units(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        contract_units = _parse_contract_units(d.pop("contract_units", UNSET))

        cftc_cot_data = cls(
            date=date,
            report_week=report_week,
            market_and_exchange_names=market_and_exchange_names,
            cftc_contract_market_code=cftc_contract_market_code,
            cftc_market_code=cftc_market_code,
            cftc_region_code=cftc_region_code,
            cftc_commodity_code=cftc_commodity_code,
            cftc_contract_market_code_quotes=cftc_contract_market_code_quotes,
            cftc_market_code_quotes=cftc_market_code_quotes,
            cftc_commodity_code_quotes=cftc_commodity_code_quotes,
            cftc_subgroup_code=cftc_subgroup_code,
            commodity=commodity,
            commodity_group=commodity_group,
            commodity_subgroup=commodity_subgroup,
            futonly_or_combined=futonly_or_combined,
            contract_units=contract_units,
        )

        cftc_cot_data.additional_properties = d
        return cftc_cot_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
