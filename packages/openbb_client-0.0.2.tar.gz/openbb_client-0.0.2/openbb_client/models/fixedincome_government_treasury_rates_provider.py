from enum import Enum


class FixedincomeGovernmentTreasuryRatesProvider(str, Enum):
    FEDERAL_RESERVE = "federal_reserve"
    FMP = "fmp"

    def __str__(self) -> str:
        return str(self.value)
