from enum import Enum


class EquityOwnershipInsiderTradingOwnershipTypeType0(str, Enum):
    D = "D"
    I = "I"

    def __str__(self) -> str:
        return str(self.value)
