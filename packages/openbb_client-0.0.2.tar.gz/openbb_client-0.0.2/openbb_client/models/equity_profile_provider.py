from enum import Enum


class EquityProfileProvider(str, Enum):
    AKSHARE = "akshare"
    FMP = "fmp"
    INTRINIO = "intrinio"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
