from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="FederalReservePrimaryDealerPositioningData")


@_attrs_define
class FederalReservePrimaryDealerPositioningData:
    """Federal Reserve Primary Dealer Positioning Data.

    Attributes:
        date (datetime.date): The date of the data.
        symbol (str): Symbol representing the entity requested in the data.
        value (int): The reported value of the net position (long - short), in millions of $USD.
        name (str): Short name for the series.
        title (str): Title of the series.
    """

    date: datetime.date
    symbol: str
    value: int
    name: str
    title: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        symbol = self.symbol

        value = self.value

        name = self.name

        title = self.title

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "symbol": symbol,
                "value": value,
                "name": name,
                "title": title,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        symbol = d.pop("symbol")

        value = d.pop("value")

        name = d.pop("name")

        title = d.pop("title")

        federal_reserve_primary_dealer_positioning_data = cls(
            date=date,
            symbol=symbol,
            value=value,
            name=name,
            title=title,
        )

        federal_reserve_primary_dealer_positioning_data.additional_properties = d
        return federal_reserve_primary_dealer_positioning_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
