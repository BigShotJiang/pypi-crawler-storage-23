from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FederalReserveSOFRData")


@_attrs_define
class FederalReserveSOFRData:
    """FederalReserve FED Data.

    Attributes:
        date (datetime.date): The date of the data.
        rate (float): Effective federal funds rate.
        percentile_1 (float | None | Unset): 1st percentile of the distribution.
        percentile_25 (float | None | Unset): 25th percentile of the distribution.
        percentile_75 (float | None | Unset): 75th percentile of the distribution.
        percentile_99 (float | None | Unset): 99th percentile of the distribution.
        volume (float | None | Unset): The trading volume.The notional volume of transactions (Billions of $).
    """

    date: datetime.date
    rate: float
    percentile_1: float | None | Unset = UNSET
    percentile_25: float | None | Unset = UNSET
    percentile_75: float | None | Unset = UNSET
    percentile_99: float | None | Unset = UNSET
    volume: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        rate = self.rate

        percentile_1: float | None | Unset
        if isinstance(self.percentile_1, Unset):
            percentile_1 = UNSET
        else:
            percentile_1 = self.percentile_1

        percentile_25: float | None | Unset
        if isinstance(self.percentile_25, Unset):
            percentile_25 = UNSET
        else:
            percentile_25 = self.percentile_25

        percentile_75: float | None | Unset
        if isinstance(self.percentile_75, Unset):
            percentile_75 = UNSET
        else:
            percentile_75 = self.percentile_75

        percentile_99: float | None | Unset
        if isinstance(self.percentile_99, Unset):
            percentile_99 = UNSET
        else:
            percentile_99 = self.percentile_99

        volume: float | None | Unset
        if isinstance(self.volume, Unset):
            volume = UNSET
        else:
            volume = self.volume

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "rate": rate,
            }
        )
        if percentile_1 is not UNSET:
            field_dict["percentile_1"] = percentile_1
        if percentile_25 is not UNSET:
            field_dict["percentile_25"] = percentile_25
        if percentile_75 is not UNSET:
            field_dict["percentile_75"] = percentile_75
        if percentile_99 is not UNSET:
            field_dict["percentile_99"] = percentile_99
        if volume is not UNSET:
            field_dict["volume"] = volume

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        rate = d.pop("rate")

        def _parse_percentile_1(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percentile_1 = _parse_percentile_1(d.pop("percentile_1", UNSET))

        def _parse_percentile_25(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percentile_25 = _parse_percentile_25(d.pop("percentile_25", UNSET))

        def _parse_percentile_75(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percentile_75 = _parse_percentile_75(d.pop("percentile_75", UNSET))

        def _parse_percentile_99(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percentile_99 = _parse_percentile_99(d.pop("percentile_99", UNSET))

        def _parse_volume(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        volume = _parse_volume(d.pop("volume", UNSET))

        federal_reserve_sofr_data = cls(
            date=date,
            rate=rate,
            percentile_1=percentile_1,
            percentile_25=percentile_25,
            percentile_75=percentile_75,
            percentile_99=percentile_99,
            volume=volume,
        )

        federal_reserve_sofr_data.additional_properties = d
        return federal_reserve_sofr_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
