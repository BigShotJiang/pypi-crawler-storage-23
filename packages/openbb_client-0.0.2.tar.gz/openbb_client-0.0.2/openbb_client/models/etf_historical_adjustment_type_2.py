from enum import Enum


class EtfHistoricalAdjustmentType2(str, Enum):
    SPLITS_AND_DIVIDENDS = "splits_and_dividends"
    SPLITS_ONLY = "splits_only"

    def __str__(self) -> str:
        return str(self.value)
