from enum import Enum


class EquityOwnershipShareStatisticsProvider(str, Enum):
    FMP = "fmp"
    INTRINIO = "intrinio"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
