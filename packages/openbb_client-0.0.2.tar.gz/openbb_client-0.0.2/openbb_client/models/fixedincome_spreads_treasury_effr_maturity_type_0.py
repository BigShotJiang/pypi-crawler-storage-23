from enum import Enum


class FixedincomeSpreadsTreasuryEffrMaturityType0(str, Enum):
    VALUE_0 = "3m"
    VALUE_1 = "6m"

    def __str__(self) -> str:
        return str(self.value)
