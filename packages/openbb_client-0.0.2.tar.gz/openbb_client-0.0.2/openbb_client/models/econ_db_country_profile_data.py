from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="EconDbCountryProfileData")


@_attrs_define
class EconDbCountryProfileData:
    """EconDB Country Profile Data.

    Attributes:
        country (str):
        population (int | None | Unset): Population.
        gdp_usd (float | None | Unset): Gross Domestic Product, in billions of USD.
        gdp_qoq (float | None | Unset): GDP growth quarter-over-quarter change, as a normalized percent.
        gdp_yoy (float | None | Unset): GDP growth year-over-year change, as a normalized percent.
        cpi_yoy (float | None | Unset): Consumer Price Index year-over-year change, as a normalized percent.
        core_yoy (float | None | Unset): Core Consumer Price Index year-over-year change, as a normalized percent.
        retail_sales_yoy (float | None | Unset): Retail Sales year-over-year change, as a normalized percent.
        industrial_production_yoy (float | None | Unset): Industrial Production year-over-year change, as a normalized
            percent.
        policy_rate (float | None | Unset): Short term policy rate, as a normalized percent.
        yield_10y (float | None | Unset): 10-year government bond yield, as a normalized percent.
        govt_debt_gdp (float | None | Unset): Government debt as a percent (normalized) of GDP.
        current_account_gdp (float | None | Unset): Current account balance as a percent (normalized) of GDP.
        jobless_rate (float | None | Unset): Unemployment rate, as a normalized percent.
    """

    country: str
    population: int | None | Unset = UNSET
    gdp_usd: float | None | Unset = UNSET
    gdp_qoq: float | None | Unset = UNSET
    gdp_yoy: float | None | Unset = UNSET
    cpi_yoy: float | None | Unset = UNSET
    core_yoy: float | None | Unset = UNSET
    retail_sales_yoy: float | None | Unset = UNSET
    industrial_production_yoy: float | None | Unset = UNSET
    policy_rate: float | None | Unset = UNSET
    yield_10y: float | None | Unset = UNSET
    govt_debt_gdp: float | None | Unset = UNSET
    current_account_gdp: float | None | Unset = UNSET
    jobless_rate: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        country = self.country

        population: int | None | Unset
        if isinstance(self.population, Unset):
            population = UNSET
        else:
            population = self.population

        gdp_usd: float | None | Unset
        if isinstance(self.gdp_usd, Unset):
            gdp_usd = UNSET
        else:
            gdp_usd = self.gdp_usd

        gdp_qoq: float | None | Unset
        if isinstance(self.gdp_qoq, Unset):
            gdp_qoq = UNSET
        else:
            gdp_qoq = self.gdp_qoq

        gdp_yoy: float | None | Unset
        if isinstance(self.gdp_yoy, Unset):
            gdp_yoy = UNSET
        else:
            gdp_yoy = self.gdp_yoy

        cpi_yoy: float | None | Unset
        if isinstance(self.cpi_yoy, Unset):
            cpi_yoy = UNSET
        else:
            cpi_yoy = self.cpi_yoy

        core_yoy: float | None | Unset
        if isinstance(self.core_yoy, Unset):
            core_yoy = UNSET
        else:
            core_yoy = self.core_yoy

        retail_sales_yoy: float | None | Unset
        if isinstance(self.retail_sales_yoy, Unset):
            retail_sales_yoy = UNSET
        else:
            retail_sales_yoy = self.retail_sales_yoy

        industrial_production_yoy: float | None | Unset
        if isinstance(self.industrial_production_yoy, Unset):
            industrial_production_yoy = UNSET
        else:
            industrial_production_yoy = self.industrial_production_yoy

        policy_rate: float | None | Unset
        if isinstance(self.policy_rate, Unset):
            policy_rate = UNSET
        else:
            policy_rate = self.policy_rate

        yield_10y: float | None | Unset
        if isinstance(self.yield_10y, Unset):
            yield_10y = UNSET
        else:
            yield_10y = self.yield_10y

        govt_debt_gdp: float | None | Unset
        if isinstance(self.govt_debt_gdp, Unset):
            govt_debt_gdp = UNSET
        else:
            govt_debt_gdp = self.govt_debt_gdp

        current_account_gdp: float | None | Unset
        if isinstance(self.current_account_gdp, Unset):
            current_account_gdp = UNSET
        else:
            current_account_gdp = self.current_account_gdp

        jobless_rate: float | None | Unset
        if isinstance(self.jobless_rate, Unset):
            jobless_rate = UNSET
        else:
            jobless_rate = self.jobless_rate

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "country": country,
            }
        )
        if population is not UNSET:
            field_dict["population"] = population
        if gdp_usd is not UNSET:
            field_dict["gdp_usd"] = gdp_usd
        if gdp_qoq is not UNSET:
            field_dict["gdp_qoq"] = gdp_qoq
        if gdp_yoy is not UNSET:
            field_dict["gdp_yoy"] = gdp_yoy
        if cpi_yoy is not UNSET:
            field_dict["cpi_yoy"] = cpi_yoy
        if core_yoy is not UNSET:
            field_dict["core_yoy"] = core_yoy
        if retail_sales_yoy is not UNSET:
            field_dict["retail_sales_yoy"] = retail_sales_yoy
        if industrial_production_yoy is not UNSET:
            field_dict["industrial_production_yoy"] = industrial_production_yoy
        if policy_rate is not UNSET:
            field_dict["policy_rate"] = policy_rate
        if yield_10y is not UNSET:
            field_dict["yield_10y"] = yield_10y
        if govt_debt_gdp is not UNSET:
            field_dict["govt_debt_gdp"] = govt_debt_gdp
        if current_account_gdp is not UNSET:
            field_dict["current_account_gdp"] = current_account_gdp
        if jobless_rate is not UNSET:
            field_dict["jobless_rate"] = jobless_rate

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        country = d.pop("country")

        def _parse_population(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        population = _parse_population(d.pop("population", UNSET))

        def _parse_gdp_usd(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        gdp_usd = _parse_gdp_usd(d.pop("gdp_usd", UNSET))

        def _parse_gdp_qoq(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        gdp_qoq = _parse_gdp_qoq(d.pop("gdp_qoq", UNSET))

        def _parse_gdp_yoy(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        gdp_yoy = _parse_gdp_yoy(d.pop("gdp_yoy", UNSET))

        def _parse_cpi_yoy(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        cpi_yoy = _parse_cpi_yoy(d.pop("cpi_yoy", UNSET))

        def _parse_core_yoy(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        core_yoy = _parse_core_yoy(d.pop("core_yoy", UNSET))

        def _parse_retail_sales_yoy(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        retail_sales_yoy = _parse_retail_sales_yoy(d.pop("retail_sales_yoy", UNSET))

        def _parse_industrial_production_yoy(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        industrial_production_yoy = _parse_industrial_production_yoy(d.pop("industrial_production_yoy", UNSET))

        def _parse_policy_rate(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        policy_rate = _parse_policy_rate(d.pop("policy_rate", UNSET))

        def _parse_yield_10y(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        yield_10y = _parse_yield_10y(d.pop("yield_10y", UNSET))

        def _parse_govt_debt_gdp(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        govt_debt_gdp = _parse_govt_debt_gdp(d.pop("govt_debt_gdp", UNSET))

        def _parse_current_account_gdp(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        current_account_gdp = _parse_current_account_gdp(d.pop("current_account_gdp", UNSET))

        def _parse_jobless_rate(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        jobless_rate = _parse_jobless_rate(d.pop("jobless_rate", UNSET))

        econ_db_country_profile_data = cls(
            country=country,
            population=population,
            gdp_usd=gdp_usd,
            gdp_qoq=gdp_qoq,
            gdp_yoy=gdp_yoy,
            cpi_yoy=cpi_yoy,
            core_yoy=core_yoy,
            retail_sales_yoy=retail_sales_yoy,
            industrial_production_yoy=industrial_production_yoy,
            policy_rate=policy_rate,
            yield_10y=yield_10y,
            govt_debt_gdp=govt_debt_gdp,
            current_account_gdp=current_account_gdp,
            jobless_rate=jobless_rate,
        )

        econ_db_country_profile_data.additional_properties = d
        return econ_db_country_profile_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
