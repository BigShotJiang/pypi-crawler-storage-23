from enum import Enum


class FixedincomeBondIndicesFrequencyType0(str, Enum):
    A = "a"
    BWEM = "bwem"
    BWEW = "bwew"
    D = "d"
    M = "m"
    Q = "q"
    W = "w"
    WEF = "wef"
    WEM = "wem"
    WESA = "wesa"
    WESU = "wesu"
    WETH = "weth"
    WETU = "wetu"
    WEW = "wew"

    def __str__(self) -> str:
        return str(self.value)
