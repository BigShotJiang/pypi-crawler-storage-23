from enum import Enum


class EquityFundamentalBalanceSortType0(str, Enum):
    FILING_DATE = "filing_date"
    PERIOD_OF_REPORT_DATE = "period_of_report_date"

    def __str__(self) -> str:
        return str(self.value)
