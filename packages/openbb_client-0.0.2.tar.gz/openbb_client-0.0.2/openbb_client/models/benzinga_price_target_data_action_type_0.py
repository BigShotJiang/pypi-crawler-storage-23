from enum import Enum


class BenzingaPriceTargetDataActionType0(str, Enum):
    ASSUMES = "Assumes"
    DOWNGRADES = "Downgrades"
    FIRM_DISSOLVED = "Firm Dissolved"
    INITIATES_COVERAGE_ON = "Initiates Coverage On"
    MAINTAINS = "Maintains"
    REINSTATES = "Reinstates"
    REITERATES = "Reiterates"
    REMOVES = "Removes"
    SUSPENDS = "Suspends"
    TERMINATES_COVERAGE_ON = "Terminates Coverage On"
    UPGRADES = "Upgrades"

    def __str__(self) -> str:
        return str(self.value)
