"""
Tests package for unimotifcomparator.

This package contains unit and integration tests for the unimotifcomparator project.
"""
