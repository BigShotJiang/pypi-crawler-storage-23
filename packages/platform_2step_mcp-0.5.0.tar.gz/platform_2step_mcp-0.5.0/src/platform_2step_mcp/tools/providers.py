"""Provider (service professional) tools for MCP."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from ..client import Platform2StepClient

PROVIDER_TOOLS: list[Tool] = [
    Tool(
        name="list_providers",
        description="List service professionals (providers) for a company. Returns providers with their IDs, names, locations, and availability.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID to list providers for",
                },
                "location_ids": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Filter by location IDs (optional)",
                },
                "active": {
                    "type": "boolean",
                    "description": "Filter by active status (optional)",
                },
                "public_name": {
                    "type": "string",
                    "description": "Filter by public name (optional)",
                },
                "service_ids": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "Filter by service IDs (optional)",
                },
                "page": {
                    "type": "integer",
                    "description": "Page number (default 1)",
                },
                "per_page": {
                    "type": "integer",
                    "description": "Results per page (default 25, max 100)",
                },
            },
            "required": ["company_id"],
        },
    ),
    Tool(
        name="get_provider",
        description="Get details of a specific service professional (provider).",
        inputSchema={
            "type": "object",
            "properties": {
                "provider_id": {
                    "type": "integer",
                    "description": "Provider ID",
                },
            },
            "required": ["provider_id"],
        },
    ),
]


async def handle_provider_tool(
    name: str,
    arguments: dict[str, Any],
    client: Platform2StepClient,
) -> list[TextContent]:
    """Handle provider tool calls.

    Args:
        name: Tool name.
        arguments: Tool arguments.
        client: Platform2Step HTTP client.

    Returns:
        List of TextContent with the result.
    """
    if name == "list_providers":
        result = await client.list_providers(
            company_id=arguments["company_id"],
            location_ids=arguments.get("location_ids"),
            active=arguments.get("active"),
            public_name=arguments.get("public_name"),
            service_ids=arguments.get("service_ids"),
            page=arguments.get("page", 1),
            per_page=arguments.get("per_page", 25),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "get_provider":
        result = await client.get_provider(
            provider_id=arguments["provider_id"],
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown provider tool: {name}")
