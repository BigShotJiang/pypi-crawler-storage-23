"""Booking tools for MCP."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from ..client import Platform2StepClient

BOOKING_TOOLS: list[Tool] = [
    Tool(
        name="list_bookings",
        description="List bookings for a company within a date range.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID",
                },
                "start_date": {
                    "type": "string",
                    "format": "date",
                    "description": "Start date (YYYY-MM-DD)",
                },
                "end_date": {
                    "type": "string",
                    "format": "date",
                    "description": "End date (YYYY-MM-DD)",
                },
                "location_id": {
                    "type": "integer",
                    "description": "Filter by location ID (optional). Returns all bookings at this location across all providers.",
                },
                "status_id": {
                    "type": "integer",
                    "enum": [1, 2, 3],
                    "description": "Filter by status ID: 1=Reservado (booked), 2=Confirmado (confirmed), 3=Cancelado (cancelled)",
                },
                "page": {
                    "type": "integer",
                    "description": "Page number (default 1)",
                },
                "per_page": {
                    "type": "integer",
                    "description": "Results per page (default 25, max 100)",
                },
            },
            "required": ["company_id", "start_date", "end_date"],
        },
    ),
    Tool(
        name="get_booking",
        description="Get details of a specific booking.",
        inputSchema={
            "type": "object",
            "properties": {
                "booking_id": {
                    "type": "integer",
                    "description": "Booking ID",
                },
            },
            "required": ["booking_id"],
        },
    ),
    # NOTE: create_booking and cancel_booking tools are disabled until
    # booking mutation routes exist in platform-2steps (currently only [:index, :show]).
]


async def handle_booking_tool(
    name: str,
    arguments: dict[str, Any],
    client: Platform2StepClient,
) -> list[TextContent]:
    """Handle booking tool calls.

    Args:
        name: Tool name.
        arguments: Tool arguments.
        client: Platform2Step HTTP client.

    Returns:
        List of TextContent with the result.
    """
    if name == "list_bookings":
        result = await client.list_bookings(
            company_id=arguments["company_id"],
            start_date=arguments["start_date"],
            end_date=arguments["end_date"],
            location_id=arguments.get("location_id"),
            status_id=arguments.get("status_id"),
            page=arguments.get("page", 1),
            per_page=arguments.get("per_page", 25),
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    elif name == "get_booking":
        result = await client.get_booking(
            booking_id=arguments["booking_id"],
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown booking tool: {name}")
