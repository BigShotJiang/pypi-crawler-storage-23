"""Tests for Platform-2Step MCP."""
