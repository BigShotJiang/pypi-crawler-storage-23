"""MCPProxy — connects to an MCP server over stdio or HTTP.

Wraps an MCP-compatible server started as a subprocess (stdio) or accessible
over HTTP (Streamable HTTP / SSE) and exposes its tools through a synchronous
Python API that integrates naturally with the threaded callite server.

Examples::

    # stdio — launch a subprocess
    proxy = MCPProxy("uvx", ["mcp-server-sqlite", "--db-path", "test.db"])
    proxy.connect()

    # HTTP — connect to a remote MCP server
    proxy = MCPProxy(url="http://localhost:8080/mcp")
    proxy.connect()

    tools = proxy.get_tools()
    result = proxy.call_tool("list_tables", {})

    proxy.disconnect()

The class keeps a background ``asyncio`` event loop so that every public
method is safe to call from ordinary (non-async) threads — including the
daemon threads that ``RPCServer`` spawns for each incoming request.
"""

import asyncio
import logging
import threading
from contextlib import AsyncExitStack
from typing import Any

logger = logging.getLogger(__name__)


class MCPProxy:
    """Manages an MCP server connection (stdio or HTTP) and exposes its tools.

    The proxy connects lazily on the first ``connect()`` (or on the first
    ``get_tools`` / ``call_tool`` invocation) and keeps the connection alive
    for the lifetime of the object.  If the connection is lost, the next
    ``call_tool`` attempt will transparently reconnect.

    Provide **either** ``command`` (for stdio) **or** ``url`` (for HTTP),
    not both.

    Args:
        command: Executable to start (e.g. ``"uvx"`` or ``"npx"``).
        args: Command-line arguments forwarded to the subprocess.
        env: Optional environment variables for the subprocess.
        url: HTTP endpoint of a remote MCP server.
        headers: Optional HTTP headers (only used with ``url``).
        call_timeout: Per-call timeout in seconds (``None`` = no timeout).
    """

    def __init__(
        self,
        command: str | None = None,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        *,
        url: str | None = None,
        headers: dict[str, str] | None = None,
        call_timeout: float | None = None,
    ):
        if command and url:
            raise ValueError("Provide either 'command' (stdio) or 'url' (HTTP), not both")
        if not command and not url:
            raise ValueError("Provide either 'command' (stdio) or 'url' (HTTP)")

        self.command = command
        self.args = args or []
        self.env = env
        self.url = url
        self.headers = headers
        self._call_timeout = call_timeout

        self._session: Any = None
        self._exit_stack: AsyncExitStack | None = None
        self._connected = False

        self._loop: asyncio.AbstractEventLoop | None = None
        self._loop_thread: threading.Thread | None = None
        self._connect_lock = threading.Lock()

        self._tools_cache: list[Any] | None = None

    @property
    def _target(self) -> str:
        """Human-readable connection target for log messages."""
        return self.url if self.url else f"{self.command} {' '.join(self.args)}"

    # ------------------------------------------------------------------
    # Event-loop helpers
    # ------------------------------------------------------------------

    def _ensure_loop(self) -> None:
        """Spin up a background event loop if one is not already running."""
        with self._connect_lock:
            if self._loop is not None and self._loop.is_running():
                logger.debug("MCPProxy event loop already running")
                return
            logger.debug("MCPProxy starting event loop")
            self._loop = asyncio.new_event_loop()
            self._loop_thread = threading.Thread(
                target=self._loop.run_forever,
                daemon=True,
                name="mcp-proxy-loop",
            )
            self._loop_thread.start()
            self._wait_event_loop()

    def _wait_event_loop(self):
        # Wait for the loop to actually start running
        import time
        for _ in range(50):  # Max 0.5 seconds wait
            if self._loop.is_running():
                break
            time.sleep(0.01)
        else:
            raise RuntimeError("Event loop failed to start")

    def _run_async(self, coro: Any, timeout: float | None = None) -> Any:
        """Submit *coro* to the background loop and block until it finishes.

        Callers must ensure the event loop is running before calling this
        method (via ``_ensure_loop()``).  Do **not** call this while holding
        ``_connect_lock`` unless ``_ensure_loop`` was called *before* the lock
        was acquired — ``_ensure_loop`` itself acquires the same lock.
        """
        assert self._loop is not None, "Event loop not started; call _ensure_loop() first"
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result(timeout=timeout)

    # ------------------------------------------------------------------
    # Async internals
    # ------------------------------------------------------------------

    async def _connect_async(self) -> None:
        try:
            from mcp import ClientSession
        except ImportError:
            raise ImportError(
                "MCPProxy requires the 'mcp' package. "
                "Install it with: pip install mcp"
            )

        self._exit_stack = AsyncExitStack()

        if self.url:
            read, write = await self._connect_http()
        else:
            read, write = await self._connect_stdio()

        self._session = await self._exit_stack.enter_async_context(
            ClientSession(read, write)
        )
        await self._session.initialize()
        self._connected = True
        logger.info("MCPProxy connected to %s", self._target)

    async def _connect_stdio(self) -> tuple[Any, Any]:
        from mcp import StdioServerParameters
        from mcp.client.stdio import stdio_client

        assert self.command is not None
        server_params = StdioServerParameters(
            command=self.command,
            args=self.args,
            env=self.env,
        )
        assert self._exit_stack is not None
        return await self._exit_stack.enter_async_context(
            stdio_client(server_params)
        )

    async def _connect_http(self) -> tuple[Any, Any]:
        assert self._exit_stack is not None
        assert self.url is not None

        # Try Streamable HTTP first, fall back to SSE.
        try:
            from mcp.client.streamable_http import streamable_http_client
            logger.debug("MCPProxy trying Streamable HTTP for %s", self.url)

            http_client = None
            if self.headers:
                import httpx
                http_client = httpx.AsyncClient(headers=self.headers)

            # streamable_http_client yields (read, write, get_session_id)
            result = await self._exit_stack.enter_async_context(
                streamable_http_client(self.url, http_client=http_client)
            )
            return result[0], result[1]
        except Exception:
            logger.debug(
                "Streamable HTTP failed for %s, falling back to SSE",
                self.url,
            )
            # Clean up the failed stack and create a fresh one.
            try:
                await self._exit_stack.aclose()
            except Exception:
                pass
            self._exit_stack = AsyncExitStack()

        from mcp.client.sse import sse_client
        return await self._exit_stack.enter_async_context(
            sse_client(self.url, headers=self.headers)
        )

    async def _disconnect_async(self) -> None:
        if self._exit_stack:
            try:
                await self._exit_stack.aclose()
            except Exception:
                pass
        self._session = None
        self._exit_stack = None
        self._connected = False
        self._tools_cache = None

    async def _reconnect_async(self) -> None:
        await self._disconnect_async()
        await self._connect_async()

    async def _get_tools_async(self) -> list[Any]:
        assert self._session is not None
        result = await self._session.list_tools()
        return result.tools

    async def _list_tools_async(self) -> list[Any]:
        return await self._get_tools_async()

    async def _list_prompts_async(self) -> list[Any]:
        assert self._session is not None
        result = await self._session.list_prompts()
        return result.prompts

    async def _get_prompt_async(self, name: str, arguments: dict[str, str] | None = None) -> Any:
        assert self._session is not None
        return await self._session.get_prompt(name, arguments)

    async def _list_resources_async(self) -> list[Any]:
        assert self._session is not None
        result = await self._session.list_resources()
        return result.resources

    async def _read_resource_async(self, uri: str) -> Any:
        assert self._session is not None
        from pydantic import AnyUrl
        return await self._session.read_resource(AnyUrl(uri))

    async def _list_resource_templates_async(self) -> list[Any]:
        assert self._session is not None
        result = await self._session.list_resource_templates()
        return result.resourceTemplates

    async def _send_ping_async(self) -> Any:
        assert self._session is not None
        return await self._session.send_ping()

    async def _call_tool_async(
        self, name: str, arguments: dict[str, Any]
    ) -> Any:
        assert self._session is not None
        result = await self._session.call_tool(name, arguments=arguments)

        if result.isError:
            error_text = "\n".join(
                c.text for c in result.content if hasattr(c, "text")
            )
            raise RuntimeError(f"MCP tool '{name}' error: {error_text}")

        # Extract text content from the result
        texts = [c.text for c in result.content if hasattr(c, "text")]
        if len(texts) == 1:
            return texts[0]
        return texts if texts else None

    # ------------------------------------------------------------------
    # Public synchronous API
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Connect to the MCP server and perform the handshake.

        Safe to call multiple times — subsequent calls are no-ops while the
        connection is alive.
        """
        logger.debug("MCPProxy connecting to %s", self._target)
        self._ensure_loop()
        with self._connect_lock:
            if self._connected:
                return
            self._run_async(self._connect_async())

    def _ensure_connected(self) -> None:
        if not self._connected:
            self.connect()

    def get_tools(self) -> list[Any]:
        """Return the list of tools published by the external MCP server.

        Results are cached after the first call.  Use ``refresh_tools()`` to
        force a re-fetch.
        """
        logger.debug("MCPProxy getting tools from %s", self._target)
        self._ensure_connected()
        if self._tools_cache is None:
            self._tools_cache = self._run_async(self._get_tools_async())
        return self._tools_cache

    def refresh_tools(self) -> list[Any]:
        """Re-fetch the tool list (clears the cache)."""
        self._tools_cache = None
        return self.get_tools()

    def call_tool(
        self, name: str, arguments: dict[str, Any] | None = None
    ) -> Any:
        """Execute a tool on the external MCP server.

        If the connection is lost, one automatic reconnect attempt is made
        before the error is propagated.

        Args:
            name: Tool name as published by the MCP server.
            arguments: Keyword arguments expected by the tool.

        Returns:
            The text content returned by the tool.  If there are multiple
            text blocks the return value is a ``list[str]``.
        """
        self._ensure_connected()
        try:
            return self._run_async(
                self._call_tool_async(name, arguments or {}),
                timeout=self._call_timeout,
            )
        except (ConnectionError, BrokenPipeError, OSError, EOFError):
            logger.warning(
                "MCPProxy connection to %s lost, reconnecting…",
                self._target,
            )
            with self._connect_lock:
                self._run_async(self._reconnect_async())
            return self._run_async(
                self._call_tool_async(name, arguments or {}),
                timeout=self._call_timeout,
            )

    def list_tools(self) -> list[Any]:
        """Return the list of tools via the MCP protocol ``list_tools`` method."""
        self._ensure_connected()
        return self._run_async(self._list_tools_async())

    def list_prompts(self) -> list[Any]:
        """Return the list of prompts via the MCP protocol ``list_prompts`` method."""
        self._ensure_connected()
        return self._run_async(self._list_prompts_async())

    def get_prompt(self, name: str, arguments: dict[str, str] | None = None) -> Any:
        """Retrieve a prompt by name via the MCP protocol ``get_prompt`` method."""
        self._ensure_connected()
        return self._run_async(self._get_prompt_async(name, arguments))

    def list_resources(self) -> list[Any]:
        """Return the list of resources via the MCP protocol ``list_resources`` method."""
        self._ensure_connected()
        return self._run_async(self._list_resources_async())

    def read_resource(self, uri: str) -> Any:
        """Read a resource by URI via the MCP protocol ``read_resource`` method."""
        self._ensure_connected()
        return self._run_async(self._read_resource_async(uri))

    def list_resource_templates(self) -> list[Any]:
        """Return the list of resource templates via the MCP protocol."""
        self._ensure_connected()
        return self._run_async(self._list_resource_templates_async())

    def send_ping(self) -> Any:
        """Send a ping via the MCP protocol ``send_ping`` method."""
        self._ensure_connected()
        return self._run_async(self._send_ping_async())

    def disconnect(self) -> None:
        """Disconnect and release all resources."""
        with self._connect_lock:
            if self._loop and self._connected:
                try:
                    self._run_async(self._disconnect_async())
                except Exception:
                    pass
            self._session = None
            self._exit_stack = None
            self._connected = False
            self._tools_cache = None
            if self._loop:
                self._loop.call_soon_threadsafe(self._loop.stop)
                self._loop = None
                self._loop_thread = None
            logger.info("MCPProxy disconnected from %s", self._target)
