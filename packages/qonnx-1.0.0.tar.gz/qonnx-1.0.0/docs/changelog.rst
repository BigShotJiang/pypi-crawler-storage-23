========================
Release Notes
========================

.. changelog::
    :pypi: https://pypi.org/project/qonnx/
