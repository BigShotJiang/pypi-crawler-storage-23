```{include} ../README.md
:relative-docs: docs/
```
