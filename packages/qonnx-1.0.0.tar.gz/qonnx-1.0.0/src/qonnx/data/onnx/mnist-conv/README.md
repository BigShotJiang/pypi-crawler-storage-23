
Source: https://github.com/onnx/models/tree/master/vision/classification/mnist#model
