# vd-dlt-salesforce

Salesforce connector for vd-dlt pipelines with automatic incremental loading.

## Installation

```bash
pip install vd-dlt-salesforce
```

## Features

- 15 standard Salesforce objects
- Incremental loading with SystemModstamp
- Full SOQL query support
- Automatic pagination

## Usage

See full documentation at https://github.com/accelerate-data/vd-dlt-connectors
