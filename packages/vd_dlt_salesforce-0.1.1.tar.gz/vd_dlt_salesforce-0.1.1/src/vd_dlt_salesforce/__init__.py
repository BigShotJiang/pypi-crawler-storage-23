"""
vd-dlt-salesforce: Salesforce connector for vd-dlt pipelines

Provides dlt sources for Salesforce objects using the REST API.
"""

__version__ = "0.1.1"

from .source import create_source

__all__ = ["create_source"]
