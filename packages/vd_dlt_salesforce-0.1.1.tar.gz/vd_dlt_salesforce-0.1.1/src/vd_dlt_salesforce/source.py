"""
Salesforce Connector Source

Provides dlt sources for Salesforce objects using the REST API.
Reads configuration from source YAML and builds dlt resources dynamically.
"""

from typing import Any, Dict, List, Optional

from dlt.sources.rest_api import rest_api_source

from vd_dlt.config_utils import (
    build_resource_config,
    find_base_resource,
    deep_merge,
)


# Default values (used if not specified in config hierarchy)
DEFAULT_WRITE_DISPOSITION = "merge"
DEFAULT_PRIMARY_KEY = "Id"
DEFAULT_SYNC_MODE = "incremental"

# Salesforce API configuration
SALESFORCE_API_VERSION = "v57.0"
SALESFORCE_LOGIN_URL = "https://login.salesforce.com/services/oauth2/token"


def _get_salesforce_access_token(
    username: str, password: str, security_token: str, client_id: str = None, client_secret: str = None
) -> tuple[str, str]:
    """
    Authenticate with Salesforce and get access token and instance URL.

    This uses the OAuth 2.0 Username-Password flow. Requires a Salesforce Connected App
    with OAuth settings enabled.

    Args:
        username: Salesforce username
        password: Salesforce password
        security_token: Salesforce security token
        client_id: OAuth Consumer Key from Connected App (optional, can use env var)
        client_secret: OAuth Consumer Secret from Connected App (optional, can use env var)

    Returns:
        Tuple of (access_token, instance_url)

    Raises:
        ValueError: If client_id or client_secret are not provided
        requests.HTTPError: If authentication fails
    """
    # Try to use simple-salesforce library if available (simpler approach)
    try:
        from simple_salesforce import Salesforce
        sf = Salesforce(
            username=username,
            password=password,
            security_token=security_token
        )
        # Extract instance URL as string
        instance_url = sf.sf_instance
        if not instance_url.startswith('http'):
            instance_url = f'https://{instance_url}'
        return sf.session_id, instance_url
    except ImportError:
        # Fallback to manual OAuth if simple-salesforce is not installed
        pass

    # Manual OAuth flow requires Connected App credentials
    import os
    client_id = client_id or os.getenv("SALESFORCE_CLIENT_ID")
    client_secret = client_secret or os.getenv("SALESFORCE_CLIENT_SECRET")

    if not client_id or not client_secret:
        raise ValueError(
            "Salesforce OAuth requires client_id and client_secret from a Connected App. "
            "Either install simple-salesforce (pip install simple-salesforce) or provide "
            "SALESFORCE_CLIENT_ID and SALESFORCE_CLIENT_SECRET environment variables."
        )

    # Salesforce requires password + security_token concatenated
    full_password = password + security_token

    payload = {
        "grant_type": "password",
        "client_id": client_id,
        "client_secret": client_secret,
        "username": username,
        "password": full_password,
    }

    response = requests.post(SALESFORCE_LOGIN_URL, data=payload)
    response.raise_for_status()

    auth_data = response.json()
    return auth_data["access_token"], auth_data["instance_url"]


def create_source(
    credentials: Dict[str, str],
    source_config: Dict[str, Any],
    connector_defaults: Optional[Dict[str, Any]] = None,
):
    """
    Create a Salesforce dlt source.

    This function is called by the PipelineRunner to create the source.
    It reads resources from source YAML and builds dlt-compatible resource configs.

    Args:
        credentials: Resolved credentials (must contain "user_name", "password", "security_token")
        source_config: Source configuration from YAML
        connector_defaults: Connector defaults from defaults.yml

    Returns:
        Configured dlt source
    """
    username = credentials.get("user_name")
    password = credentials.get("password")
    security_token = credentials.get("security_token")

    if not all([username, password, security_token]):
        raise ValueError(
            "Salesforce connector requires 'user_name', 'password', and 'security_token' credentials"
        )

    # Authenticate with Salesforce to get access token and instance URL
    access_token, instance_url = _get_salesforce_access_token(
        username, password, security_token
    )

    connector_defaults = connector_defaults or {}

    # Get table prefix from source config
    table_prefix = source_config.get("table_prefix", "")

    # Get source-level default_sync
    source_default_sync = source_config.get("default_sync", {})

    # Get resources from source config
    source_resources = source_config.get("resources", [])

    if not source_resources:
        raise ValueError("No resources configured in source YAML")

    # Build dlt resource configs
    dlt_resources = []
    for source_resource in source_resources:
        # Skip if explicitly disabled
        if not source_resource.get("enabled", True):
            continue

        resource_config = _build_dlt_resource(
            source_resource=source_resource,
            connector_defaults=connector_defaults,
            source_default_sync=source_default_sync,
            table_prefix=table_prefix,
            instance_url=instance_url,
        )

        if resource_config:
            dlt_resources.append(resource_config)

    if not dlt_resources:
        raise ValueError("No enabled resources found in source configuration")

    # Build rest_api_source config
    config = {
        "client": {
            "base_url": instance_url,
            "auth": {"type": "bearer", "token": access_token},
            "headers": {
                "Content-Type": "application/json",
            },
        },
        "resources": dlt_resources,
    }

    return rest_api_source(config)


def _build_dlt_resource(
    source_resource: Dict[str, Any],
    connector_defaults: Dict[str, Any],
    source_default_sync: Dict[str, Any],
    table_prefix: str = "",
    instance_url: str = "",
) -> Optional[Dict[str, Any]]:
    """
    Build a dlt resource configuration from source YAML resource.

    Args:
        source_resource: Resource config from source YAML
        connector_defaults: Connector defaults from defaults.yml
        source_default_sync: Source-level default_sync
        table_prefix: Prefix to add to table names
        instance_url: Salesforce instance URL

    Returns:
        DLT-compatible resource configuration
    """
    # Use build_resource_config from config_utils for hierarchy merging
    merged = build_resource_config(
        source_resource=source_resource,
        connector_defaults=connector_defaults,
        source_default_sync=source_default_sync,
        table_prefix=table_prefix,
    )

    # Build the final dlt resource config
    dlt_resource = {
        "name": merged.get("name"),
        "primary_key": merged.get("primary_key", DEFAULT_PRIMARY_KEY),
        "write_disposition": merged.get("write_disposition", DEFAULT_WRITE_DISPOSITION),
    }

    # Build endpoint
    endpoint = merged.get("endpoint", {})
    dlt_endpoint = {}

    if "path" in endpoint:
        # For Salesforce, we need to handle SOQL queries
        path = endpoint["path"]
        dlt_endpoint["path"] = path

    if "method" in endpoint:
        dlt_endpoint["method"] = endpoint["method"]

    if "data_selector" in endpoint:
        dlt_endpoint["data_selector"] = endpoint["data_selector"]

    # Handle params (like SOQL query parameter)
    if "params" in endpoint:
        dlt_endpoint["params"] = endpoint["params"]

    # Build JSON body (for POST requests or SOQL queries)
    if "json" in endpoint:
        dlt_endpoint["json"] = endpoint["json"]

    # Build paginator
    paginator = endpoint.get("paginator") or source_resource.get("paginator")
    if paginator:
        dlt_endpoint["paginator"] = _build_paginator(paginator)
    else:
        # Salesforce uses nextRecordsUrl for pagination
        dlt_endpoint["paginator"] = {
            "type": "cursor",
            "cursor_path": "nextRecordsUrl",
            "cursor_param": None,  # Salesforce provides full URL
        }

    dlt_resource["endpoint"] = dlt_endpoint

    # Build incremental config
    incremental = merged.get("incremental")
    if incremental:
        dlt_resource["endpoint"]["incremental"] = _build_dlt_incremental(incremental)

    return dlt_resource


def _build_paginator(paginator: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build dlt paginator configuration.

    YAML format:
        type: cursor
        cursor_path: nextRecordsUrl
        cursor_param: null

    Args:
        paginator: Paginator config from YAML

    Returns:
        DLT-compatible paginator config
    """
    paginator_type = paginator.get("type", "cursor")

    if paginator_type == "cursor":
        return {
            "type": "cursor",
            "cursor_path": paginator.get("cursor_path", "nextRecordsUrl"),
            "cursor_param": paginator.get("cursor_param"),
        }
    elif paginator_type == "offset":
        return {
            "type": "offset",
            "limit": paginator.get("limit", 100),
            "offset_param": paginator.get("offset_param", "offset"),
            "limit_param": paginator.get("limit_param", "limit"),
        }
    elif paginator_type == "page_number":
        return {
            "type": "page_number",
            "page_param": paginator.get("page_param", "page"),
            "total_path": paginator.get("total_path"),
        }
    else:
        # Pass through as-is
        return paginator


def _build_dlt_incremental(incremental: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build dlt incremental configuration.

    YAML format:
        field: SystemModstamp
        param_name: SystemModstamp
        format: iso8601
        initial_value: "1970-01-01T00:00:00Z"

    DLT format:
        cursor_path: SystemModstamp
        initial_value: "1970-01-01T00:00:00Z"

    Args:
        incremental: Incremental config from YAML

    Returns:
        DLT-compatible incremental config
    """
    dlt_incremental = {}

    # Map field -> cursor_path
    if "field" in incremental:
        dlt_incremental["cursor_path"] = incremental["field"]
    elif "cursor_path" in incremental:
        dlt_incremental["cursor_path"] = incremental["cursor_path"]

    # Pass through initial_value
    if "initial_value" in incremental:
        dlt_incremental["initial_value"] = incremental["initial_value"]

    return dlt_incremental
