import pytest
from faker import Faker
from faker_cn import PersonaProvider

@pytest.fixture
def fake():
    f = Faker('zh_CN')
    f.add_provider(PersonaProvider)
    return f

def test_era_name_1960s(fake):
    names = [fake.era_name(birth_year=1960) for _ in range(500)]
    traditional_chars = ["军", "国", "建", "华", "平", "兰", "梅", "英", "珍", "芬"]
    # 1960年代的传统名字概率极高，测试是否有充分命中
    match_count = sum(1 for name in names if any(c in name for c in traditional_chars))
    assert match_count > 50, f"Expected many traditional names in 1960s, got {match_count} out of 500"

def test_era_name_2010s(fake):
    names = [fake.era_name(birth_year=2015) for _ in range(500)]
    modern_chars = ["浩宇", "子轩", "宇轩", "梓涵", "欣怡", "梓萱", "沐宸", "梦瑶", "子涵", "紫涵"]
    # 2010年代的现代名字概率极高
    match_count = sum(1 for name in names if any(c in name for c in modern_chars))
    assert match_count > 50, f"Expected many modern names in 2010s, got {match_count} out of 500"

def test_native_name_override(fake):
    name = fake.name()
    assert isinstance(name, str)
    assert len(name) >= 2
    
    first_name = fake.first_name()
    assert isinstance(first_name, str)
    assert len(first_name) >= 1
    
    name_m = fake.name_male()
    assert isinstance(name_m, str)
    
    name_f = fake.name_female()
    assert isinstance(name_f, str)

def test_persona_name_era_alignment(fake):
    # 保证整个大类生成没有被破坏
    for _ in range(10):
        p = fake.persona()
        assert "name" in p
        assert isinstance(p["name"], str)
        assert len(p["name"]) >= 2
