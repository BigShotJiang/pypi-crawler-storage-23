from juriscraper.opinions.united_states.state import idaho_civil


class Site(idaho_civil.Site):
    # https://www.isc.idaho.gov/appeals-court/isc_criminal
    url_part = "isc_criminal"
