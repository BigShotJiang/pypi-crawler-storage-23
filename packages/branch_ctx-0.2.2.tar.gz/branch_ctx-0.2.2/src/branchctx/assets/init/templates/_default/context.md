# Branch: {{branch}}

Created: {{date}} by {{author}}

## Goal

What is the objective of this branch?

## Status

- [ ] In progress
- [ ] Ready for review
- [ ] Merged

## Notes

-

## Decisions

-

## Tasks

- [ ]

## Commits

<bctx:commits></bctx:commits>

## Changed Files

<bctx:files></bctx:files>
