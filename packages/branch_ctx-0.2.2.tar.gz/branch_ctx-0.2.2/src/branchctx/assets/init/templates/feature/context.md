# Feature: {{branch}}

Created: {{date}} by {{author}}

## Problem

What problem does this feature solve?

## Solution

How will it be implemented?

## Acceptance Criteria

- [ ]
- [ ]

## Status

- [ ] Design
- [ ] Implementation
- [ ] Testing
- [ ] Review

## Dependencies

-

## Tasks

- [ ]

## Commits

<bctx:commits></bctx:commits>

## Changed Files

<bctx:files></bctx:files>
