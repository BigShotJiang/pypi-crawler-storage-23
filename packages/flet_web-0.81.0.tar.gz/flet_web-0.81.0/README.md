# Flet Web client in Flutter

[![python](https://img.shields.io/badge/python-%3E%3D3.10-%2334D058)](https://pypi.org/project/flet-web)
[![docstring coverage](https://docs.flet.dev/assets/badges/docs-coverage/flet-web.svg)](https://docs.flet.dev/assets/badges/docs-coverage/flet-web.svg)

This package contains a compiled Flutter Flet web client.
