"""Data processing subpackage."""

from sdv.data_processing.data_processor import DataProcessor

__all__ = ('DataProcessor',)
