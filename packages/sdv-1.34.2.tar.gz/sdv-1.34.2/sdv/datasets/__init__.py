"""Dataset loading and managing module."""

from sdv.datasets import demo, local

__all__ = ['demo', 'local']
