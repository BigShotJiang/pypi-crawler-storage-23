## 利率数据

提供银行和政府公布的利率数据，日度更新。目前主要数据有：

- Shibor利率
- Shibor报价数据
- LPR贷款基础利率
- Libor利率
- Hibor利率