# Internal Model Example - Clinical Readmission Predictor

Demonstrates comprehensive MCA SDK usage for a traditional ML classification model with complete Registry API integration.

## Features Demonstrated

- ✅ GCP Authentication (Application Default Credentials)
- ✅ OTel Collector connectivity verification
- ✅ Registry API integration (filtering by model type + config fetch)
- ✅ Input/output capture with `@predict` decorator
- ✅ Manual prediction recording with threshold checking
- ✅ Custom operation tracing with `trace()` context manager
- ✅ Custom business metrics (counter, gauge, histogram)
- ✅ Error tracking and reporting
- ✅ Telemetry verification in GCP services

## Prerequisites

### 1. Install Dependencies

```bash
pip install mca-sdk[gcp,genai]>=0.6.1
```

### 2. Configure GCP Authentication

```bash
gcloud auth application-default login
```

This creates Application Default Credentials (ADC) that the SDK uses to:
- Authenticate with Registry API
- Verify GCP project access

### 3. VPN Connection (if outside GKE cluster)

The GCP dev OTel Collector (`10.164.76.8`) is only accessible from:
- Inside the GKE cluster
- Via VPN connection

**Connect to VPN before running this example if you're working outside the cluster.**

## Usage

### Run Against GCP Dev Collector (Default)

The example connects to the GCP dev collector by default:

```bash
python instrumented_model.py
```

**Note:** Requires VPN access if running outside the GKE cluster.

### Run Against Local Collector (Optional)

For local development without GCP access:

```bash
docker-compose up -d otel-collector
export MCA_COLLECTOR_ENDPOINT=http://localhost:4318
python instrumented_model.py
```

## Using GCP Development Infrastructure

To test against the real GCP dev environment instead of a local collector:

```bash
# Use Docker Compose override
docker-compose -f ../../docker-compose.yml -f ../../docker-compose.gcp-dev.yml up internal-model

# Or set environment variables for local testing
export MCA_COLLECTOR_ENDPOINT=http://10.164.76.8:4318
export MCA_ALLOW_INSECURE_COLLECTOR=true
python instrumented_model.py
```

See [GCP Dev Environment Guide](../../../docs/gcp-dev-environment.md) for complete setup instructions and troubleshooting.

### Verification

After running against GCP dev, verify telemetry in GCP Console:

```bash
# View logs
gcloud logging read "logName=projects/bhsf-ai-team-projects/logs/emms-model-telemetry" --limit=10

# View traces
gcloud trace list --project=bhsf-ai-team-projects --limit=10
```

Or use the GCP Console:
- **Logs**: [https://console.cloud.google.com/logs/query?project=bhsf-ai-team-projects](https://console.cloud.google.com/logs/query?project=bhsf-ai-team-projects)
- **Traces**: [https://console.cloud.google.com/traces/list?project=bhsf-ai-team-projects](https://console.cloud.google.com/traces/list?project=bhsf-ai-team-projects)

### Troubleshooting GCP Connectivity

**Cannot connect to 10.164.76.8:**
- Verify VPC connectivity or VPN access
- Test with: `curl http://10.164.76.8:4318/`

**Telemetry not appearing in GCP Console:**
- Verify collector endpoint is set correctly
- Check collector health: `curl http://10.164.76.8:13133/health/status`
- Wait 15 seconds for batch processing

## Expected Output

The script will:
1. Verify GCP authentication and collector connectivity
2. Filter registry for classification models (demonstrates discovery)
3. Fetch specific model configuration
4. Initialize SDK with registry config
5. Demonstrate input/output capture with `@predict` decorator
6. Record manual predictions with threshold checking
7. Create custom operation spans with `trace()`
8. Record custom metrics (counter, gauge, histogram)
9. Track errors with context
10. Flush telemetry to collector
11. Print verification URLs for GCP Console

## Monitoring

View metrics and traces in your configured backend:
- Prometheus (metrics)
- Cloud Logging (logs)
- Cloud Trace (traces)
- Grafana for dashboards

## Files

- `instrumented_model.py` - Main example script
- `requirements.txt` - Python dependencies
- `Dockerfile` - Containerized version

## Troubleshooting

### Connection Refused Error

If you see "Connection refused" errors:
- Ensure OpenTelemetry Collector is running
- Check collector endpoint: `http://localhost:4318`
- Verify Docker Compose services are up

### Import Errors

Ensure all dependencies are installed:
```bash
pip install -r requirements.txt
```
