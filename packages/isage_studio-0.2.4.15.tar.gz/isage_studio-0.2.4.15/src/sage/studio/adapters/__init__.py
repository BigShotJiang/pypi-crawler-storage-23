"""
SAGE Studio Adapters

Adapters for integrating different components with Studio (预留模块).
"""

__all__ = []
