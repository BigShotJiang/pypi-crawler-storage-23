# next_django/cli.py
import argparse
import re
import subprocess
import sys
from pathlib import Path

def patch_django_files(base_dir):
    settings_files = list(base_dir.glob('*/settings.py'))
    if not settings_files:
        print("⚠️ Aviso: Não encontrei o arquivo 'settings.py'.")
        return False
        
    settings_path = settings_files[0]
    urls_path = settings_path.parent / 'urls.py'

    # Modificando o SETTINGS.PY
    settings_content = settings_path.read_text(encoding='utf-8')
    
    if "'django_cotton'" not in settings_content:
        settings_content = re.sub(
            r'INSTALLED_APPS = \[',
            "INSTALLED_APPS = [\n    'django_cotton',\n    'models',",
            settings_content
        )
        
    if "BASE_DIR / 'app'" not in settings_content:
        settings_content = re.sub(
            r"'DIRS': \[\]",
            "'DIRS': [BASE_DIR / 'app', BASE_DIR]",
            settings_content
        )

    if "'next_django.context_processors.htmx'" not in settings_content:
        settings_content = re.sub(
            r"'django\.template\.context_processors\.request',",
            "'django.template.context_processors.request',\n                'next_django.context_processors.htmx',",
            settings_content
        )
        
    if "COTTON_DIR" not in settings_content:
        settings_content += "\n# Configuração de Componentes do Next-Django\nCOTTON_DIR = 'components'\n"
        
    settings_path.write_text(settings_content, encoding='utf-8')
    print(f"⚙️  {settings_path.name} atualizado: HTMX, Cotton e Rotas configurados!")

    # Modificando o URLS.PY
    if urls_path.exists():
        urls_content = urls_path.read_text(encoding='utf-8')
        if "generate_urlpatterns" not in urls_content:
            imports = "from next_django.router import generate_urlpatterns\nfrom django.conf import settings\n"
            urls_content = imports + urls_content + "\n# Roteamento Mágico do Next-Django\nurlpatterns += generate_urlpatterns(settings.BASE_DIR)\n"
            urls_path.write_text(urls_content, encoding='utf-8')
            print(f"🔗 {urls_path.name} atualizado: Auto-Router ativado!")

    return True

def run_initial_migrations(base_dir):
    """Executa python manage.py migrate para garantir que a Sessão do Django funcione logo de cara"""
    manage_py_path = base_dir / 'manage.py'
    
    if not manage_py_path.exists():
        print("⚠️ Aviso: 'manage.py' não encontrado. Pulei as migrações automáticas.")
        return

    print("🗄️  Executando migrações iniciais do banco de dados...")
    try:
        # Usa sys.executable para garantir que está rodando no mesmo ambiente virtual (venv)
        result = subprocess.run(
            [sys.executable, str(manage_py_path), "migrate"],
            capture_output=True,
            text=True,
            check=True
        )
        print("✅ Banco de dados configurado com sucesso!")
    except subprocess.CalledProcessError as e:
        print("❌ Erro ao executar migrações:")
        print(e.stderr)
        print("💡 Dica: Rode 'python manage.py migrate' manualmente depois.")

def create_boilerplate():
    base_dir = Path.cwd()
    print("🚀 Inicializando o Next-Django com Dashboard SPA...")

    if not patch_django_files(base_dir):
        return

    pastas = ["app", "components/ui", "models", "api"]
    for pasta in pastas:
        (base_dir / pasta).mkdir(parents=True, exist_ok=True)

    # ==========================================
    # 1. LAYOUT GLOBAL COM SIDEBAR FIXA
    # ==========================================
    layout_content = """{% if not is_htmx %}
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Next-Django App</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/htmx.org@1.9.10"></script>
    <style>
        .htmx-indicator { opacity: 0; transition: opacity 200ms ease-in; height: 3px; background: #10b981; position: fixed; top: 0; left: 0; width: 100%; z-index: 50; }
        .htmx-request .htmx-indicator { opacity: 1; }
        .htmx-request.htmx-indicator { opacity: 1; }
    </style>
</head>
<body class="bg-slate-900 text-slate-100 min-h-screen font-sans antialiased flex" hx-ext="preload">
    <div id="loading-bar" class="htmx-indicator"></div>

    <aside class="w-64 bg-slate-800 border-r border-slate-700 h-screen fixed flex flex-col p-6 shadow-xl z-10">
        <h2 class="text-2xl font-black mb-10 text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-blue-500">
            Next-Django
        </h2>
        <nav class="flex flex-col space-y-2">
            <c-ui.link href="/" class="p-3 rounded-lg hover:bg-slate-700 transition flex items-center font-medium">
                🏠 Home
            </c-ui.link>
            <c-ui.link href="/sobre/" class="p-3 rounded-lg hover:bg-slate-700 transition flex items-center font-medium">
                ℹ️ Sobre Nós
            </c-ui.link>
            <c-ui.link href="/formulario/" class="p-3 rounded-lg hover:bg-slate-700 transition flex items-center font-medium">
                📝 Formulário
            </c-ui.link>
        </nav>
        <div class="mt-auto pt-6 border-t border-slate-700 text-xs text-slate-500 text-center">
            v0.5.0 SPA Mode
        </div>
    </aside>

    <main class="ml-64 flex-1 min-h-screen relative">
        <div id="next-root" class="p-10 max-w-5xl mx-auto">
{% endif %}

            {% block content %}
            {% endblock %}

{% if not is_htmx %}
        </div>
    </main>
</body>
</html>
{% endif %}"""
    (base_dir / "app/layout.html").write_text(layout_content, encoding='utf-8')

    # ==========================================
    # 2. PÁGINA HOME
    # ==========================================
    page_py_home = "from django.shortcuts import render\n\ndef page(request):\n    return render(request, 'page.html')\n"
    (base_dir / "app/page.py").write_text(page_py_home, encoding='utf-8')

    page_html = """{% extends "layout.html" %}
{% block content %}
    <div class="bg-slate-800 p-8 rounded-2xl shadow-lg border border-slate-700 animate-fade-in">
        <h1 class="text-4xl font-bold mb-4">Bem-vindo ao Dashboard</h1>
        <p class="text-slate-400 text-lg">
            Clique nos links da sidebar esquerda. Você vai perceber que apenas esta caixa altera o conteúdo. 
            A navegação é instantânea, enviando o HTML já mastigado pelo Django.
        </p>
    </div>
{% endblock %}"""
    (base_dir / "app/page.html").write_text(page_html, encoding='utf-8')

    # ==========================================
    # 3. PÁGINA SOBRE
    # ==========================================
    (base_dir / "app/sobre").mkdir(parents=True, exist_ok=True)
    page_py_sobre = "from django.shortcuts import render\n\ndef page(request):\n    return render(request, 'sobre/page.html')\n"
    (base_dir / "app/sobre/page.py").write_text(page_py_sobre, encoding='utf-8')

    sobre_html = """{% extends "layout.html" %}
{% block content %}
    <div class="bg-slate-800 p-8 rounded-2xl shadow-lg border border-slate-700">
        <h1 class="text-4xl font-bold mb-4">Sobre Nós</h1>
        <p class="text-slate-400 text-lg">
            Essa é a prova real de que o sistema de roteamento baseado em pastas 
            <code class="bg-slate-900 px-2 py-1 rounded">app/sobre/page.py</code> funciona lindamente com HTMX!
        </p>
    </div>
{% endblock %}"""
    (base_dir / "app/sobre/page.html").write_text(sobre_html, encoding='utf-8')

    # ==========================================
    # 4. PÁGINA FORMULÁRIO
    # ==========================================
    (base_dir / "app/formulario").mkdir(parents=True, exist_ok=True)
    
    page_py_form = """from django.shortcuts import render
from django.contrib import messages
import math

def page(request):
    if 'itens' not in request.session:
        request.session['itens'] = [{'id': i, 'nome': f'Usuário Teste {i}'} for i in range(1, 13)]

    if request.method == 'POST':
        nome = request.POST.get('nome', 'Visitante')
        novo_id = len(request.session['itens']) + 1
        
        request.session['itens'].insert(0, {'id': novo_id, 'nome': nome})
        request.session.modified = True
        
        messages.success(request, f"Usuário {nome} adicionado com sucesso!")

    page_num = int(request.GET.get('page', 1))
    items_per_page = 5
    
    todos_itens = request.session['itens']
    total_items = len(todos_itens)
    total_pages = math.ceil(total_items / items_per_page) if total_items > 0 else 1
    
    start = (page_num - 1) * items_per_page
    end = start + items_per_page
    itens_paginados = todos_itens[start:end]

    max_pages_to_show = 5
    half_range = max_pages_to_show // 2
    start_page = max(1, page_num - half_range)
    end_page = min(total_pages, start_page + max_pages_to_show - 1)

    context = {
        'itens': itens_paginados,
        'total_pages': total_pages,
        'current_page': page_num,
        'items_per_page': items_per_page,
        'page_range': range(start_page, end_page + 1),
        'querystring': '',
    }

    return render(request, 'formulario/page.html', context)
"""
    (base_dir / "app/formulario/page.py").write_text(page_py_form, encoding='utf-8')

    form_html = """{% extends "layout.html" %}
{% block content %}
    <div class="max-w-4xl mx-auto space-y-8 animate-fade-in">
        
        <div class="bg-slate-800 p-8 rounded-2xl shadow-lg border border-slate-700">
            <h1 class="text-3xl font-bold mb-6">Adicionar Usuário</h1>
            
            {% if messages %}
                <div class="mb-6 space-y-2">
                    {% for message in messages %}
                        <div class="p-4 bg-emerald-500/20 border border-emerald-500 text-emerald-400 rounded-xl font-medium flex items-center">
                            ✅ {{ message }}
                        </div>
                    {% endfor %}
                </div>
            {% endif %}

            <form hx-post="/formulario/" hx-target="#next-root" hx-swap="innerHTML" class="space-y-4">
                {% csrf_token %}
                <div class="flex gap-4">
                    <div class="flex-1">
                        <input type="text" name="nome" required placeholder="Digite o nome..." 
                            class="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition">
                    </div>
                    <button type="submit" class="bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-8 rounded-xl transition-colors shadow-md transform hover:-translate-y-0.5 whitespace-nowrap">
                        Adicionar
                    </button>
                </div>
            </form>
        </div>

        <div class="bg-slate-800 p-8 rounded-2xl shadow-lg border border-slate-700">
            <h2 class="text-2xl font-bold mb-6">Usuários Cadastrados (SPA)</h2>
            
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left text-slate-300 mb-4">
                    <thead class="text-xs text-slate-400 uppercase bg-slate-900/80 rounded-t-lg">
                        <tr>
                            <th class="px-6 py-4 rounded-tl-lg w-20">ID</th>
                            <th class="px-6 py-4 rounded-tr-lg">Nome</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for item in itens %}
                        <tr class="border-b border-slate-700/50 hover:bg-slate-700 transition-colors">
                            <td class="px-6 py-4 font-bold text-slate-500">#{{ item.id }}</td>
                            <td class="px-6 py-4 text-white">{{ item.nome }}</td>
                        </tr>
                        {% empty %}
                        <tr>
                            <td colspan="2" class="px-6 py-8 text-center text-slate-500 italic">Nenhum usuário encontrado.</td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>

            <c-ui.pagination />

        </div>
    </div>
{% endblock %}"""
    (base_dir / "app/formulario/page.html").write_text(form_html, encoding='utf-8')

    # ==========================================
    # 5. COMPONENTES E CONFIGURAÇÕES BASE
    # ==========================================
    button_html = """<button class="bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2 px-6 rounded-lg shadow-md transition-all duration-200">
    {{ slot }}
</button>"""
    (base_dir / "components/ui/button.html").write_text(button_html, encoding='utf-8')

    link_html = """<a 
    href="{{ href }}" 
    hx-get="{{ href }}" 
    hx-push-url="true" 
    hx-target="#next-root" 
    hx-swap="innerHTML"
    hx-indicator="#loading-bar"
    class="cursor-pointer {{ class|default:'text-blue-500 hover:text-blue-400 underline transition-colors' }}"
>
    {{ slot }}
</a>"""
    (base_dir / "components/ui/link.html").write_text(link_html, encoding='utf-8')
    
    pagination_html = """
    <div class="flex flex-col-reverse md:flex-row justify-between items-center gap-4 py-6 border-t border-slate-700/50 mt-6">
    <span class="text-sm text-slate-400 font-medium">
        {% if total_pages <= 0 %}
            Mostrando a página 1 de 1
        {% else %}
            Mostrando a página {{ current_page }} de {{ total_pages }}
        {% endif %}
    </span>

    <nav aria-label="Paginação da Tabela">
        <ul class="inline-flex items-center -space-x-px text-sm shadow-sm rounded-lg overflow-hidden">
            
            {% if current_page > 1 %}
                <li>
                    <a hx-get="?page=1&items_per_page={{ items_per_page }}&{{ querystring }}" hx-target="#next-root" hx-push-url="true" title="Primeira página"
                       class="cursor-pointer flex items-center justify-center px-3 h-9 leading-tight text-slate-400 bg-slate-800 border border-slate-700 hover:bg-slate-700 hover:text-white transition-colors">
                        &laquo;
                    </a>
                </li>
                <li>
                    <a hx-get="?page={{ current_page|add:-1 }}&items_per_page={{ items_per_page }}&{{ querystring }}" hx-target="#next-root" hx-push-url="true"
                       class="cursor-pointer flex items-center justify-center px-3 h-9 leading-tight text-slate-400 bg-slate-800 border border-slate-700 hover:bg-slate-700 hover:text-white transition-colors">
                        &lsaquo;
                    </a>
                </li>
            {% else %}
                <li><span class="flex items-center justify-center px-3 h-9 leading-tight text-slate-600 bg-slate-800/50 border border-slate-700 cursor-not-allowed">&laquo;</span></li>
                <li><span class="flex items-center justify-center px-3 h-9 leading-tight text-slate-600 bg-slate-800/50 border border-slate-700 cursor-not-allowed">&lsaquo;</span></li>
            {% endif %}

            {% if total_pages <= 0 %}
                <li><span class="flex items-center justify-center px-4 h-9 leading-tight text-white bg-blue-600 border border-blue-600 font-bold">1</span></li>
            {% else %}
                {% for num in page_range %}
                    {% if num == current_page %}
                        <li><span class="flex items-center justify-center px-4 h-9 leading-tight text-white bg-blue-600 border border-blue-600 font-bold">{{ num }}</span></li>
                    {% else %}
                        <li>
                            <a hx-get="?page={{ num }}&items_per_page={{ items_per_page }}&{{ querystring }}" hx-target="#next-root" hx-push-url="true"
                               class="cursor-pointer flex items-center justify-center px-4 h-9 leading-tight text-slate-400 bg-slate-800 border border-slate-700 hover:bg-slate-700 hover:text-white transition-colors">
                                {{ num }}
                            </a>
                        </li>
                    {% endif %}
                {% endfor %}
            {% endif %}

            {% if current_page < total_pages %}
                <li>
                    <a hx-get="?page={{ current_page|add:1 }}&items_per_page={{ items_per_page }}&{{ querystring }}" hx-target="#next-root" hx-push-url="true"
                       class="cursor-pointer flex items-center justify-center px-3 h-9 leading-tight text-slate-400 bg-slate-800 border border-slate-700 hover:bg-slate-700 hover:text-white transition-colors">
                        &rsaquo;
                    </a>
                </li>
                <li>
                    <a hx-get="?page={{ total_pages }}&items_per_page={{ items_per_page }}&{{ querystring }}" hx-target="#next-root" hx-push-url="true" title="Última página"
                       class="cursor-pointer flex items-center justify-center px-3 h-9 leading-tight text-slate-400 bg-slate-800 border border-slate-700 hover:bg-slate-700 hover:text-white transition-colors">
                        &raquo;
                    </a>
                </li>
            {% else %}
                <li><span class="flex items-center justify-center px-3 h-9 leading-tight text-slate-600 bg-slate-800/50 border border-slate-700 cursor-not-allowed">&rsaquo;</span></li>
                <li><span class="flex items-center justify-center px-3 h-9 leading-tight text-slate-600 bg-slate-800/50 border border-slate-700 cursor-not-allowed">&raquo;</span></li>
            {% endif %}
        </ul>
    </nav>
</div>

<button type="button" onclick="window.scrollTo({ top: 0, behavior: 'smooth' })" id="backToTopBtn" title="Voltar ao topo" 
    class="fixed bottom-6 right-6 z-50 bg-blue-600 text-white font-bold py-2 px-4 rounded-full shadow-xl hover:bg-blue-500 transition-all duration-300 transform translate-y-10 opacity-0 pointer-events-none">
    ↑ Topo
</button>

<script>
    (function initBackToTop() {
        const btn = document.getElementById("backToTopBtn");
        if(!btn) return;

        const handleScroll = () => {
            if (window.scrollY > 20 || document.documentElement.scrollTop > 20) {
                // Mostra o botão
                btn.classList.remove("translate-y-10", "opacity-0", "pointer-events-none");
                btn.classList.add("translate-y-0", "opacity-100");
            } else {
                // Esconde o botão
                btn.classList.remove("translate-y-0", "opacity-100");
                btn.classList.add("translate-y-10", "opacity-0", "pointer-events-none");
            }
        };

        // Adiciona o evento de scroll
        window.addEventListener('scroll', handleScroll);

        // [MÁGICA DO HTMX] - Remove o evento antigo antes do HTMX trocar a página
        // Isso evita vazamento de memória e duplicação de scripts!
        document.body.addEventListener('htmx:beforeSwap', function cleanup(e) {
            if (e.detail.target.id === 'next-root') {
                window.removeEventListener('scroll', handleScroll);
                document.body.removeEventListener('htmx:beforeSwap', cleanup);
            }
        });
    })();
</script>
    """
    (base_dir / "components/ui/pagination.html").write_text(pagination_html, encoding='utf-8') 

    (base_dir / "models/__init__.py").write_text("# Registre seus modelos aqui\n", encoding='utf-8')
    apps_py = "from django.apps import AppConfig\n\nclass ModelsConfig(AppConfig):\n    default_auto_field = 'django.db.models.BigAutoField'\n    name = 'models'\n"
    (base_dir / "models/apps.py").write_text(apps_py, encoding='utf-8')

    api_py = "from ninja import Router\n\nrouter = Router()\n\n@router.get('/')\ndef hello(request):\n    return {'mensagem': 'API Next-Django rodando com sucesso!'}\n"
    (base_dir / "api/hello.py").write_text(api_py, encoding='utf-8')

    # ==========================================
    # EXECUTAR MIGRAÇÕES INICIAIS
    # ==========================================
    run_initial_migrations(base_dir)

    print("✅ Dashboard gerado com sucesso!")

def main():
    parser = argparse.ArgumentParser(description="CLI do Next-Django")
    parser.add_argument("command", choices=["init"], help="Inicializa a estrutura do projeto")
    args = parser.parse_args()
    if args.command == "init": create_boilerplate()

if __name__ == "__main__":
    main()