TEST_PATH = "test/resources/asr_test.wav"

PARAKEET_TEST_SEGMENT_START = 0.08

PARAKEET_TEST_SEGMENT_END = 1.26

PARAKEET_TEST_TRANSCRIPTION = "To embrace the chaos that they fought in this battle."

PARAKEET_TEST_CONFIDENCE = -248
