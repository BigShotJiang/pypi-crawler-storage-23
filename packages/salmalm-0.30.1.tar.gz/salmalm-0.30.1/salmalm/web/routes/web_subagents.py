"""Sub-agent REST API — list, spawn, detail, steer, kill, clear."""


class WebSubagentsMixin:
    GET_ROUTES = {
        "/api/subagents": "_get_subagents",
    }
    GET_PREFIX_ROUTES = [
        ("/api/subagents/", "_get_subagent_detail", None),
    ]
    POST_ROUTES = {
        "/api/subagents": "_post_spawn_subagent",
        "/api/subagents/clear": "_post_clear_subagents",
    }
    POST_PREFIX_ROUTES = [
        ("/api/subagents/", "_post_subagent_action", None),
    ]

    # ── GET ───────────────────────────────────────────────────────────────

    def _get_subagents(self):
        """GET /api/subagents — list all tasks (summary, no messages)."""
        _u = self._require_auth("user")
        if not _u:
            return
        owner_uid = str(_u.get("id") or _u.get("uid") or "")
        is_admin = _u.get("role") in ("admin", "owner")
        from salmalm.features.subagents import subagent_manager
        self._json({"tasks": subagent_manager.list_tasks(owner_uid=owner_uid, is_admin=is_admin)})

    def _get_subagent_detail(self):
        """GET /api/subagents/<id> — task + full message history."""
        _u = self._require_auth("user")
        if not _u:
            return
        owner_uid = str(_u.get("id") or _u.get("uid") or "")
        is_admin = _u.get("role") in ("admin", "owner")
        task_id = self.path.rstrip("/").split("/")[-1]
        from salmalm.features.subagents import subagent_manager
        task = subagent_manager.get_task(task_id, owner_uid=owner_uid, is_admin=is_admin)
        if not task:
            self._json({"error": f"Task {task_id} not found"}, 404)
            return
        self._json({"task": task.to_dict(include_messages=True)})

    # ── POST ──────────────────────────────────────────────────────────────

    def _post_spawn_subagent(self):
        """POST /api/subagents — spawn a new sub-agent."""
        _u = self._require_auth("user")
        if not _u:
            return
        body = self._body
        description = (body.get("description") or "").strip()
        if not description:
            self._json({"error": "description required"}, 400)
            return
        owner_uid = str(_u.get("id") or _u.get("uid") or "")
        try:
            max_turns = max(1, min(int(body.get("max_turns", 10)), 50))
        except (TypeError, ValueError):
            max_turns = 10
        try:
            timeout_s = max(10, min(int(body.get("timeout_s", 300)), 1800))
        except (TypeError, ValueError):
            timeout_s = 300

        parent_session = (body.get("parent_session") or "web").strip()
        if parent_session not in ("web", "local", "default") and owner_uid:
            from salmalm.core import _get_db

            conn = _get_db()
            _row = conn.execute(
                "SELECT 1 FROM session_store WHERE session_id=? AND user_id=?",
                (parent_session, int(owner_uid) if owner_uid.isdigit() else 0),
            ).fetchone()
            if not _row:
                parent_session = "web"

        _raw_model = (body.get("model") or "").strip()[:128]
        _ALLOWED_PREFIXES = ("anthropic/", "openai/", "google/", "xai/", "groq/", "openrouter/", "ollama/")
        _KNOWN_ALIASES = {"sonnet", "opus", "gemini", "gpt", "GPT", "Grok", "auto"}
        if _raw_model and _raw_model not in _KNOWN_ALIASES and not any(
            _raw_model.startswith(p) for p in _ALLOWED_PREFIXES
        ):
            _raw_model = None
        model = _raw_model or None

        from salmalm.features.subagents import subagent_manager
        task = subagent_manager.spawn(
            description=description,
            model=model,
            thinking_level=body.get("thinking_level") or None,
            label=(body.get("label") or "").strip() or None,
            max_turns=max_turns,
            timeout_s=timeout_s,
            parent_session=parent_session,
            owner_uid=owner_uid,
        )
        self._json({"task": task.to_dict()})

    def _post_subagent_action(self):
        """POST /api/subagents/<id>/steer|kill — dynamic sub-routes."""
        _u = self._require_auth("user")
        if not _u:
            return
        # path: /api/subagents/<id>/steer  or  /api/subagents/<id>/kill
        parts = [p for p in self.path.rstrip("/").split("/") if p]
        # parts: ['api', 'subagents', '<id>', 'steer']
        if len(parts) < 4:
            self._json({"error": "Not found"}, 404)
            return
        task_id = parts[2]
        action = parts[3]
        owner_uid = str(_u.get("id") or _u.get("uid") or "")
        is_admin = _u.get("role") in ("admin", "owner")
        from salmalm.features.subagents import subagent_manager
        if action == "steer":
            message = (self._body.get("message") or "").strip()
            if not message:
                self._json({"error": "message required"}, 400)
                return
            result = subagent_manager.steer(task_id, message, owner_uid=owner_uid, is_admin=is_admin)
            if result == "Access denied":
                self._json({"error": "Access denied"}, 403)
                return
            self._json({"ok": True, "result": result})
        elif action == "kill":
            result = subagent_manager.kill(task_id, owner_uid=owner_uid, is_admin=is_admin)
            if result == "Access denied":
                self._json({"error": "Access denied"}, 403)
                return
            self._json({"ok": True, "result": result})
        else:
            self._json({"error": f"Unknown action: {action}"}, 404)

    def _post_clear_subagents(self):
        """POST /api/subagents/clear — remove completed/failed tasks."""
        _u = self._require_auth("user")
        if not _u:
            return
        owner_uid = str(_u.get("id") or _u.get("uid") or "")
        is_admin = _u.get("role") in ("admin", "owner")
        from salmalm.features.subagents import subagent_manager
        count = subagent_manager.clear_completed(owner_uid=owner_uid, is_admin=is_admin)
        self._json({"ok": True, "removed": count})
