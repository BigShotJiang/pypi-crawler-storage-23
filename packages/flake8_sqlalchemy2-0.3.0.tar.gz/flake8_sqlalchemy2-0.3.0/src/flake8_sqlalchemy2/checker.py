from __future__ import annotations

import ast
from collections.abc import Generator
from importlib.metadata import version
from typing import Any

MAPPING_NAMES = {
    "association_proxy",
    "column_property",
    "composite",
    "mapped_column",
    "relationship",
    "synonym",
    "mapped_column",
}


def is_mapped_attribute(func_node: ast.expr) -> bool:
    """
    Placeholder for the logic that identifies SQLAlchemy
    constructs like `mapped_column()` or `Column()`.
    """
    # Simplified check for demonstration
    if isinstance(func_node, ast.Name):
        return func_node.id in MAPPING_NAMES
    elif isinstance(func_node, ast.Attribute):
        return func_node.attr in MAPPING_NAMES
    return False


class Checker:
    """
    Flake8 plugin to help you write SQLAlchemy2.
    """

    name = "flake8-sqlalchemy2"
    version = version("flake8-sqlalchemy2")

    __slots__ = ("tree",)

    def __init__(self, tree: ast.AST) -> None:
        self.tree = tree

    messages = {
        "SQLAlchemyMissingMappedTypeAnnotation": "SA201 Missing `Mapped` or other ORM container class type annotation",
        "SQLAlchemyLegacyCollection": "SA202 Use of legacy collection `DynamicMapped` consider using `WriteOnlyMapped` instead",
        "SQLAlchemyLegacyRelationship": "SA203 Use of legacy relationship `backref` consider using `back_populates` instead",
    }

    def run(self) -> Generator[tuple[int, int, str, type[Any]]]:
        for node in ast.walk(self.tree):
            if isinstance(node, ast.Call):
                if (
                    isinstance(node.func, ast.Attribute)
                    and node.func.attr == "relationship"
                    or isinstance(node.func, ast.Name)
                    and node.func.id == "relationship"
                ):
                    for keyword in node.keywords:
                        if keyword.arg == "backref":
                            yield (
                                keyword.lineno,
                                keyword.col_offset,
                                self.messages["SQLAlchemyLegacyRelationship"],
                                type(self),
                            )
                            break

            if isinstance(node, ast.AnnAssign):
                if not isinstance(node.annotation, ast.Subscript):
                    continue

                subscript = node.annotation

                value = subscript.value

                if (
                    isinstance(value, ast.Attribute)
                    and value.attr == "DynamicMapped"
                    or isinstance(value, ast.Name)
                    and value.id == "DynamicMapped"
                ):
                    yield (
                        subscript.lineno,
                        subscript.col_offset,
                        self.messages["SQLAlchemyLegacyCollection"],
                        type(self),
                    )

            if isinstance(node, ast.Assign):
                value = node.value
                targets = node.targets

                # Check if the value is a function call
                if isinstance(value, ast.Call):
                    if is_mapped_attribute(value.func):
                        # SQLAlchemy doesn't allow multiple targets (e.g., x = y = mapped_column())
                        if len(targets) != 1:
                            continue
                        target = targets[0]
                        yield (
                            target.lineno,
                            target.col_offset,
                            self.messages["SQLAlchemyMissingMappedTypeAnnotation"],
                            type(self),
                        )
