# Changelog

## 0.3.0 (21.02.2026)

Add rule `legacy-relationship` (SA203).

## 0.2.0 (20.02.2026)

Add second rule `legacy-collection` (SA202).

## 0.1.0 (15.02.2026)

Initial release, including first rule `missing-mapped-type-annotation` (SA201).
