from __future__ import annotations

import ast

from src.flake8_sqlalchemy2 import Checker


def test_complex():
    code = """\
from typing import List

from sqlalchemy import Integer, ForeignKey, String, func
from sqlalchemy.ext.associationproxy import association_proxy, AssociationProxy
from sqlalchemy.orm import (
    Mapped,
    mapped_column,
    DeclarativeBase,
    relationship,
    column_property,
    MappedSQLExpression,
    synonym,
    Synonym,
)


class Base(DeclarativeBase):
    pass


class Parent(Base):
    __tablename__ = "parent"

    id: Mapped[int] = mapped_column(primary_key=True)
    children: Mapped[List["Child"]] = relationship(back_populates="parent")

    name: Mapped[str]

    parent_name: Synonym[str] = synonym("name")


class Child(Base):
    __tablename__ = "child"

    id: Mapped[int] = mapped_column(primary_key=True)
    parent_id: Mapped[int] = mapped_column(ForeignKey("parent.id"))
    parent: Mapped["Parent"] = relationship(back_populates="children")

    parent_name: AssociationProxy[str] = association_proxy("parent", "name")

    first_name: Mapped[str] = mapped_column(String)
    last_name: Mapped[str] = mapped_column()

    name_length: MappedSQLExpression[int] = column_property(
        func.length(first_name + last_name)
    )


class Company(Base):
    __tablename__ = "company"

    id = mapped_column(Integer, primary_key=True)
    employees = relationship("Employee", back_populates="company")

    name = mapped_column(String)
    company_name = synonym("name")


class Employee(Base):
    __tablename__ = "employee"

    id = mapped_column(Integer, primary_key=True)
    company_id = mapped_column(ForeignKey("company.id"))
    company = relationship("Company", back_populates="employees")

    company_name = association_proxy("company", "name")

    first_name = mapped_column(String)
    last_name = mapped_column(String)

    name_length = column_property(func.length(first_name + last_name))
    """

    tree = ast.parse(code)
    plugin = Checker(tree)
    assert [f"{line}:{col + 1} {msg}" for line, col, msg, _ in plugin.run()] == [
        "52:5 SA201 Missing `Mapped` or other ORM container class type annotation",
        "53:5 SA201 Missing `Mapped` or other ORM container class type annotation",
        "55:5 SA201 Missing `Mapped` or other ORM container class type annotation",
        "56:5 SA201 Missing `Mapped` or other ORM container class type annotation",
        "62:5 SA201 Missing `Mapped` or other ORM container class type annotation",
        "63:5 SA201 Missing `Mapped` or other ORM container class type annotation",
        "64:5 SA201 Missing `Mapped` or other ORM container class type annotation",
        "66:5 SA201 Missing `Mapped` or other ORM container class type annotation",
        "68:5 SA201 Missing `Mapped` or other ORM container class type annotation",
        "69:5 SA201 Missing `Mapped` or other ORM container class type annotation",
        "71:5 SA201 Missing `Mapped` or other ORM container class type annotation",
    ]


def test_import_orm():
    code = """\
from sqlalchemy import Integer
from sqlalchemy import orm

class Base(orm.DeclarativeBase):
    pass


class Simple(Base):
    __tablename__ = "simple"

    id = orm.mapped_column(Integer, primary_key=True)
"""

    tree = ast.parse(code)
    plugin = Checker(tree)
    assert [f"{line}:{col + 1} {msg}" for line, col, msg, _ in plugin.run()] == [
        "11:5 SA201 Missing `Mapped` or other ORM container class type annotation",
    ]
