from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as arq:
    readme = arq.read()

setup(
    name='cybertron-spark',
    version='0.1.11',
    license='MIT',
    author='Gustavo Sartorio',
    author_email='strov3rl@gmail.com',
    description='Automação do Zendesk com Selenium, Zenpy e integração Cybertron',
    long_description=readme,
    long_description_content_type="text/markdown",
    keywords='zendesk selenium transformers cybertron',
    packages=find_packages(), 
    include_package_data=True,
    install_requires=[
        'selenium',
        'zenpy',
        'requests',
        'urllib3',
        'python-dotenv',
        'pandas',
        'pandas-gbq',
        'google-auth'
    ],
    python_requires='>=3.8',
)