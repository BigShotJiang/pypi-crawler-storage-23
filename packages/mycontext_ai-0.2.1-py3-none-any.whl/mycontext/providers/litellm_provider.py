"""
LiteLLM-backed provider -- unified interface for all LLM providers.

Uses litellm.completion() which routes to OpenAI, Anthropic, Google,
and 100+ providers via a single OpenAI-compatible interface.
"""

import time
from typing import Any, Optional

try:
    import litellm

    litellm.drop_params = True
    LITELLM_AVAILABLE = True
except ImportError:
    LITELLM_AVAILABLE = False

from .base import BaseProvider, ProviderResponse


def _litellm_model_name(provider: str, model: str) -> str:
    """Map (provider, model) to the litellm model string.

    LiteLLM uses bare names for OpenAI and Anthropic, but requires a
    ``gemini/`` prefix for Google models.
    """
    if provider in ("gemini", "google"):
        if not model.startswith("gemini/"):
            return f"gemini/{model}"
    return model


class LiteLLMProvider(BaseProvider):
    """Unified LLM provider powered by LiteLLM.

    Supports OpenAI, Anthropic, Google Gemini, and 100+ other providers
    through a single interface.
    """

    def __init__(
        self,
        model: str,
        provider: str = "openai",
        api_key: Optional[str] = None,
        **kwargs: Any,
    ):
        if not LITELLM_AVAILABLE:
            raise ImportError(
                "LiteLLM not installed. Install with: pip install litellm"
            )
        self._provider = provider
        self.api_key = api_key
        self.default_model = model

    def generate(
        self,
        context: "Context",
        user: Optional[str] = None,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        """Generate a response via LiteLLM."""
        model = model or self.default_model
        litellm_model = _litellm_model_name(self._provider, model)

        messages: list[dict[str, str]] = []
        system_prompt = context.assemble()
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        if user:
            messages.append({"role": "user", "content": user})

        api_key = kwargs.pop("api_key", self.api_key)

        call_kwargs: dict[str, Any] = {
            "model": litellm_model,
            "messages": messages,
            "temperature": temperature,
        }
        if api_key:
            call_kwargs["api_key"] = api_key
        if max_tokens:
            call_kwargs["max_tokens"] = max_tokens

        call_kwargs.update(kwargs)

        start = time.time()
        response = litellm.completion(**call_kwargs)
        latency_ms = int((time.time() - start) * 1000)

        content = response.choices[0].message.content or ""
        usage = response.usage
        tokens_used = usage.total_tokens if usage else 0
        input_tokens = usage.prompt_tokens if usage else 0
        output_tokens = usage.completion_tokens if usage else 0

        try:
            cost = litellm.completion_cost(completion_response=response)
        except Exception:
            cost = 0.0

        return ProviderResponse(
            response=content,
            tokens_used=tokens_used,
            cost_usd=cost,
            latency_ms=latency_ms,
            model=model,
            metadata={
                "litellm_model": litellm_model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "finish_reason": (
                    response.choices[0].finish_reason if response.choices else None
                ),
            },
        )

    def estimate_cost(self, tokens: int, model: Optional[str] = None) -> float:
        """Rough cost estimate using LiteLLM pricing tables."""
        model = model or self.default_model
        litellm_model = _litellm_model_name(self._provider, model)
        try:
            prompt_cost, completion_cost = litellm.cost_per_token(
                model=litellm_model,
                prompt_tokens=tokens // 2,
                completion_tokens=tokens // 2,
            )
            return prompt_cost + completion_cost
        except Exception:
            return 0.0

    @property
    def name(self) -> str:
        return self._provider

    @property
    def models(self) -> list[str]:
        """Return known models for this provider from LiteLLM registry."""
        try:
            return litellm.models_by_provider.get(self._provider, [])
        except Exception:
            return []
