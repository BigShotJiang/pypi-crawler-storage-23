"""
Pattern Suggester - Auto-suggest essential templates for any question.

Maps question intent/keywords to optimal patterns (all 85 free + enterprise).
Always suggests from full catalog; enterprise patterns show license note when include_enterprise=False.
"""

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple


from .pattern_catalog import (
    ENTERPRISE_LICENSE_NOTE,
    FULL_PATTERN_CATALOG,
    NAME_TO_CATEGORY,
    NAME_TO_DESCRIPTION,
    VALID_PATTERN_NAMES,
    PATTERN_CATALOG,
    CATALOG_FOR_LLM,
    PATTERN_MAP,
)


@dataclass
class PatternSuggestion:
    """A suggested pattern with reasoning."""
    name: str
    category: str  # "free" | "enterprise"
    reason: str
    confidence: float  # 0.0 to 1.0
    chain_position: Optional[int] = None  # 1, 2, 3... if part of chain

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary."""
        return asdict(self)


@dataclass
class SuggestionResult:
    """Result of pattern suggestion."""
    question: str
    suggested_patterns: List[PatternSuggestion] = field(default_factory=list)
    suggested_chain: Optional[List[str]] = None  # Ordered pattern names for chaining
    reasoning: str = ""
    source: str = "keyword"  # "keyword" | "llm" | "hybrid"
    llm_reasoning: Optional[str] = None  # LLM's explanation (when hybrid/llm)

    def to_dict(self) -> Dict[str, Any]:
        """Export as dictionary (for JSON, YAML, APIs)."""
        return {
            "question": self.question,
            "suggested_patterns": [s.to_dict() for s in self.suggested_patterns],
            "suggested_chain": self.suggested_chain,
            "reasoning": self.reasoning,
            "source": self.source,
            "llm_reasoning": self.llm_reasoning,
        }

    def to_markdown(self) -> str:
        """Export as human-readable Markdown (for display in notebooks, docs)."""
        lines = [f"### {self.question}\n"]
        lines.append(f"- **Source**: `{self.source}`")
        lines.append(f"- **Suggested**: `{', '.join(s.name for s in self.suggested_patterns)}`")
        if self.suggested_chain:
            lines.append(f"- **Workflow chain**: `{self.suggested_chain}`")
        else:
            lines.append("")
        lines.append("**Reasoning**:")
        for s in self.suggested_patterns:
            step = f" (step {s.chain_position})" if s.chain_position else ""
            lines.append(f"- `{s.name}`{step}: {s.reason}")
        if self.llm_reasoning:
            lines.append("\n**LLM raw**:")
            lines.append(f"> {self.llm_reasoning[:500]}{'...' if len(self.llm_reasoning) > 500 else ''}")
        return "\n".join(lines)

    def to_json(self) -> str:
        """Export as JSON string (for APIs, storage)."""
        import json
        return json.dumps(self.to_dict(), indent=2)

    def to_yaml(self) -> str:
        """Export as YAML string (for configs, pipelines)."""
        import yaml
        return yaml.dump(self.to_dict(), default_flow_style=False, sort_keys=False)

    def to_xml(self) -> str:
        """Export as XML string (for XML-based systems)."""
        from xml.etree.ElementTree import Element, SubElement, tostring
        from xml.dom import minidom
        root = Element("suggestion_result")
        SubElement(root, "question").text = self.question
        SubElement(root, "source").text = self.source
        SubElement(root, "reasoning").text = self.reasoning
        if self.llm_reasoning:
            SubElement(root, "llm_reasoning").text = self.llm_reasoning
        chain_elem = SubElement(root, "suggested_chain")
        if self.suggested_chain:
            for name in self.suggested_chain:
                SubElement(chain_elem, "pattern").text = name
        patterns_elem = SubElement(root, "suggested_patterns")
        for s in self.suggested_patterns:
            p = SubElement(patterns_elem, "pattern")
            SubElement(p, "name").text = s.name
            SubElement(p, "category").text = s.category
            SubElement(p, "reason").text = s.reason
            SubElement(p, "confidence").text = str(s.confidence)
            if s.chain_position is not None:
                SubElement(p, "chain_position").text = str(s.chain_position)
        rough = tostring(root, encoding="unicode")
        reparsed = minidom.parseString(rough)
        return reparsed.toprettyxml(indent="  ")

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SuggestionResult":
        """Create from dictionary (round-trip with to_dict)."""
        patterns = [
            PatternSuggestion(**p) if isinstance(p, dict) else p
            for p in data.get("suggested_patterns", [])
        ]
        return cls(
            question=data.get("question", ""),
            suggested_patterns=patterns,
            suggested_chain=data.get("suggested_chain"),
            reasoning=data.get("reasoning", ""),
            source=data.get("source", "keyword"),
            llm_reasoning=data.get("llm_reasoning"),
        )

    @classmethod
    def from_json(cls, json_str: str) -> "SuggestionResult":
        """Create from JSON string (round-trip with to_json)."""
        import json
        return cls.from_dict(json.loads(json_str))



def suggest_patterns(
    question: str,
    include_enterprise: bool = True,
    suggest_chain: bool = True,
    max_patterns: int = 5,
    mode: str = "keyword",
    llm_provider: str = "openai",
    temperature: float = 0,
    model: Optional[str] = None,
    **llm_kwargs: Any,
) -> SuggestionResult:
    """
    Suggest essential patterns for a given question.

    Always suggests from all 85 templates (free + enterprise). When include_enterprise=False,
    enterprise patterns still appear but with a note: "Requires enterprise license. Set include_enterprise=True to use."

    Args:
        question: The user's question or problem description
        include_enterprise: If False, enterprise patterns show license note (default True)
        suggest_chain: Suggest a chain order when multiple patterns apply
        max_patterns: Maximum patterns to suggest (default 5)
        mode: "keyword" (no LLM), "llm" (LLM only), "hybrid" (keyword + LLM merge)
        llm_provider: Provider for LLM mode ("openai", "anthropic", "gemini")
        temperature: LLM temperature (default 0 for determinism)
        model: Override model name
        **llm_kwargs: Extra kwargs passed to provider.generate()

    Returns:
        SuggestionResult with patterns, optional chain, and reasoning
    """
    keyword_result = _suggest_with_keywords(
        question, include_enterprise, suggest_chain, max_patterns
    )

    if mode == "keyword":
        return keyword_result

    if mode in ("llm", "hybrid"):
        kw_hints = [s.name for s in keyword_result.suggested_patterns]
        llm_selections, integration_note, llm_raw = _suggest_with_llm(
            question, llm_provider, temperature=temperature, model=model,
            keyword_hints=kw_hints if mode == "hybrid" else None,
            **llm_kwargs,
        )
        llm_names = [s[0] for s in llm_selections]
        llm_reasons = {s[0]: s[1] for s in llm_selections}

        if not llm_names and mode == "llm":
            return SuggestionResult(
                question=question,
                suggested_patterns=[],
                reasoning="LLM returned no valid patterns. Try keyword mode.",
                source="llm",
            )
        if mode == "llm":
            return _names_to_result(
                question, llm_names, suggest_chain, max_patterns, "llm",
                llm_raw, include_enterprise, llm_reasons, integration_note,
            )
        # hybrid: LLM selections are primary, keyword fills gaps
        kw_reasons = {s.name: s.reason for s in keyword_result.suggested_patterns}
        merged = llm_names + [n for n in kw_hints if n not in set(llm_names)]
        merged = merged[:max_patterns]
        merged_reasons = {**kw_reasons, **llm_reasons}
        return _names_to_result(
            question, merged, suggest_chain, max_patterns, "hybrid",
            llm_raw, include_enterprise, merged_reasons, integration_note,
        )

    return keyword_result


def _suggest_with_keywords(
    question: str,
    include_enterprise: bool,
    suggest_chain: bool,
    max_patterns: int,
) -> SuggestionResult:
    """Keyword-based suggestion. Always suggests from ALL patterns; adds license note for enterprise when include_enterprise=False."""
    question_lower = question.lower().strip()
    suggestions: List[PatternSuggestion] = []
    seen: set = set()

    for keywords, (pattern_name, category, reason) in PATTERN_MAP:
        if pattern_name in seen:
            continue
        for kw in keywords:
            if kw in question_lower:
                reason_text = f"Question mentions '{kw}' -> {reason}"
                if category == "enterprise" and not include_enterprise:
                    reason_text += ENTERPRISE_LICENSE_NOTE
                suggestions.append(PatternSuggestion(
                    name=pattern_name,
                    category=category,
                    reason=reason_text,
                    confidence=0.85,
                ))
                seen.add(pattern_name)
                break

    seen_unique: set = set()
    unique = []
    for s in suggestions:
        if s.name not in seen_unique:
            seen_unique.add(s.name)
            unique.append(s)
    suggestions = unique[:max_patterns]

    chain = None
    if suggest_chain and len(suggestions) >= 2:
        chain = _order_chain([s.name for s in suggestions])
        for s in suggestions:
            if s.name in chain:
                s.chain_position = chain.index(s.name) + 1
        by_name = {s.name: s for s in suggestions}
        suggestions = [by_name[n] for n in chain if n in by_name]

    reasoning_parts = []
    for s in suggestions:
        pos = f" (chain step {s.chain_position})" if s.chain_position else ""
        reasoning_parts.append(f"- {s.name}{pos}: {s.reason}")
    reasoning = "\n".join(reasoning_parts) if reasoning_parts else "No strong match. Try question_analyzer."

    return SuggestionResult(
        question=question,
        suggested_patterns=suggestions,
        suggested_chain=chain,
        reasoning=reasoning,
        source="keyword",
    )


def _suggest_with_llm(
    question: str,
    provider: str,
    temperature: float = 0,
    model: Optional[str] = None,
    keyword_hints: Optional[List[str]] = None,
    **kwargs: Any,
) -> tuple:
    """Call LLM to suggest patterns. Returns (list of (name, reason) tuples, integration_note, raw_text)."""
    from ..core import Context
    from ..foundation import Directive, Guidance

    hint_block = ""
    if keyword_hints:
        hint_block = (
            f"\nKeyword analysis already identified these candidates: {', '.join(keyword_hints)}\n"
            "You may keep, replace, or add to these. Think beyond the obvious.\n"
        )

    prompt = f"""USER QUESTION: "{question}"
{hint_block}
TEMPLATE CATALOG (85 cognitive reasoning frameworks):
{CATALOG_FOR_LLM}

INSTRUCTIONS:
Think step-by-step about which templates would best address this question.
1. Consider what TYPE of problem this is (diagnostic, decision, creative, analytical, ethical, etc.)
2. Select 3-5 templates from the catalog. Use EXACT template names.
3. Order them as a pipeline (what to apply first → last).
4. Explain WHY each template is needed for THIS specific question.
5. Describe how combining them creates deeper insight than any single template alone.

RESPOND IN THIS EXACT FORMAT:

TEMPLATE: exact_template_name
REASON: 1-2 sentences explaining why this is needed for the user's specific question

TEMPLATE: exact_template_name
REASON: 1-2 sentences...

(repeat for each)

INTEGRATION: 2-3 sentences explaining how these templates work together as a pipeline — what each stage contributes and why the combination produces better results than any single template."""

    try:
        ctx = Context(
            guidance=Guidance(
                role="Expert cognitive pattern architect. You reason deeply about which reasoning frameworks best fit a given question, selecting from a catalog of 85 templates.",
                rules=[
                    "Use ONLY template names from the catalog. Exact snake_case names.",
                    "Select 3-5 templates. Go beyond the obvious — consider less expected but powerful combinations.",
                    "Order them as a pipeline: analysis/investigation first, synthesis/integration last.",
                    "Each REASON must be specific to the user's question, not generic.",
                ],
            ),
            directive=Directive(content=prompt),
        )
        exec_kw = {"temperature": temperature, **kwargs}
        if model:
            exec_kw["model"] = model
        result = ctx.execute(provider=provider, **exec_kw)
        raw = result.response.strip()
        return _parse_llm_structured_response(raw)
    except Exception as e:
        return ([], "", str(e))


def _parse_llm_structured_response(raw: str) -> tuple:
    """Parse structured LLM response into (list of (name, reason), integration_note, raw_text)."""
    import re
    selections: List[tuple] = []
    integration = ""

    template_pattern = re.compile(r"TEMPLATE:\s*(\S+)", re.IGNORECASE)
    reason_pattern = re.compile(r"REASON:\s*(.+)", re.IGNORECASE)
    integration_pattern = re.compile(r"INTEGRATION:\s*(.+)", re.IGNORECASE | re.DOTALL)

    int_match = integration_pattern.search(raw)
    if int_match:
        integration = int_match.group(1).strip().split("\n")[0].strip()

    template_matches = list(template_pattern.finditer(raw))
    for i, tm in enumerate(template_matches):
        name = tm.group(1).strip().lower().replace("-", "_").replace(" ", "_")
        if name not in VALID_PATTERN_NAMES:
            continue
        search_start = tm.end()
        search_end = template_matches[i + 1].start() if i + 1 < len(template_matches) else (int_match.start() if int_match else len(raw))
        chunk = raw[search_start:search_end]
        rm = reason_pattern.search(chunk)
        reason = rm.group(1).strip() if rm else "Selected by AI"
        selections.append((name, reason))

    if not selections:
        for part in raw.replace("\n", ",").split(","):
            name = part.strip().lower().replace("-", "_").replace(" ", "_")
            if name in VALID_PATTERN_NAMES:
                selections.append((name, "Selected by AI"))

    return (selections[:5], integration, raw)


def _names_to_result(
    question: str,
    names: List[str],
    suggest_chain: bool,
    max_patterns: int,
    source: str,
    llm_reasoning: Optional[str] = None,
    include_enterprise: bool = True,
    per_template_reasons: Optional[dict] = None,
    integration_note: Optional[str] = None,
) -> SuggestionResult:
    """Convert list of pattern names to SuggestionResult. Adds license note when include_enterprise=False."""
    per_template_reasons = per_template_reasons or {}
    suggestions = []
    for name in names[:max_patterns]:
        cat = NAME_TO_CATEGORY.get(name, "free")
        reason = per_template_reasons.get(name, f"Selected by {source}")
        if cat == "enterprise" and not include_enterprise:
            reason += ENTERPRISE_LICENSE_NOTE
        suggestions.append(PatternSuggestion(
            name=name,
            category=cat,
            reason=reason,
            confidence=0.9 if source in ("llm", "hybrid") else 0.85,
        ))

    chain = _order_chain(names) if suggest_chain and len(names) >= 2 else None
    if chain:
        for s in suggestions:
            if s.name in chain:
                s.chain_position = chain.index(s.name) + 1
        by_chain = {s.name: s for s in suggestions}
        suggestions = [by_chain[n] for n in chain if n in by_chain]

    reasoning = integration_note or ""
    return SuggestionResult(
        question=question,
        suggested_patterns=suggestions,
        suggested_chain=chain,
        reasoning=reasoning,
        source=source,
        llm_reasoning=llm_reasoning,
    )


def _order_chain(pattern_names: List[str]) -> List[str]:
    """Order patterns into a sensible workflow chain."""
    order_priority = {
        "temporal_sequence_analyzer": 1,
        "historical_context_mapper": 2,
        "diagnostic_root_cause_analyzer": 3,
        "root_cause_analyzer": 3,  # free RCA
        "causal_reasoner": 4,
        "differential_diagnoser": 5,
        "future_scenario_planner": 6,
        "pattern_recognition_engine": 7,
        "cross_domain_synthesizer": 8,
        "holistic_integrator": 9,
    }
    others = [p for p in pattern_names if p not in order_priority]
    ordered = sorted(
        [p for p in pattern_names if p in order_priority],
        key=lambda x: order_priority[x],
    )
    return ordered + others

def get_pattern_class(pattern_name: str, include_enterprise: bool = True):
    """
    Get the Pattern class for a given pattern name.

    Delegates to the unified pattern registry. When include_enterprise=False
    and pattern is enterprise, returns None.
    """
    category = NAME_TO_CATEGORY.get(pattern_name)
    if category is None:
        return None
    if category == "enterprise" and not include_enterprise:
        return None
    from ..skills.pattern_registry import get_pattern_registry
    registry = get_pattern_registry()
    return registry.get(pattern_name)
