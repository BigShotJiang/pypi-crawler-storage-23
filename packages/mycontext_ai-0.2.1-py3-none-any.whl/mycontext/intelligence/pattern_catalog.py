"""
Pattern Catalog - Single source of truth for all 85 cognitive patterns.

Contains pattern metadata, keyword mappings, and derived lookup dicts.
Extracted from pattern_suggester.py for single-responsibility.
"""

from typing import List, Tuple


ENTERPRISE_LICENSE_NOTE = " Requires enterprise license. Set include_enterprise=True to use."


# (name, category, one-line description) for all 85 templates (all unique names)
FULL_PATTERN_CATALOG: List[Tuple[str, str, str]] = [
    # FREE - Analysis (2)
    ("question_analyzer", "free", "Decomposes a question into sub-questions, identifies assumptions, clarifies scope"),
    ("data_analyzer", "free", "Structured data analysis: extract patterns, trends, metrics, and actionable insights"),
    ("trend_identifier", "enterprise", "Identifies trends, inflection points, and patterns over time in data"),
    ("gap_analyzer", "enterprise", "Finds gaps between current state and desired state; identifies what's missing"),
    ("swot_analyzer", "enterprise", "Strengths, Weaknesses, Opportunities, Threats framework for strategic analysis"),
    ("anomaly_detector", "enterprise", "Detects outliers, anomalies, and unusual patterns in data or processes"),
    # FREE - Reasoning (3)
    ("root_cause_analyzer", "free", "Five Whys + Ishikawa root cause investigation for problems and failures"),
    ("step_by_step_reasoner", "free", "Breaks complex reasoning into explicit logical steps with justification"),
    ("causal_reasoner", "enterprise", "Traces cause-and-effect chains: why did X happen, what led to Y"),
    ("analogical_reasoner", "enterprise", "Draws parallels from similar domains or situations to generate insight"),
    ("hypothesis_generator", "free", "Generates testable hypotheses from observations and evidence"),
    # FREE - Creative (1)
    ("idea_generator", "enterprise", "Divergent thinking to generate novel ideas with structured evaluation"),
    ("brainstormer", "free", "Structured brainstorming with quantity, diversity, and no-judgment rules"),
    ("innovation_framework", "enterprise", "Innovation methodology: reframe problems, find novel approaches"),
    ("design_thinker", "enterprise", "Design thinking: empathize, define, ideate, prototype, test"),
    ("metaphor_generator", "enterprise", "Creates illuminating metaphors and analogies for complex concepts"),
    # FREE - Communication (2)
    ("technical_translator", "free", "Translates technical jargon into plain language for non-technical audiences"),
    ("simplification_engine", "enterprise", "Simplifies complex content while preserving accuracy and nuance"),
    ("persuasion_framework", "enterprise", "Structures persuasive arguments with evidence, logic, and emotional appeal"),
    ("narrative_builder", "enterprise", "Builds compelling narratives with story structure and engagement hooks"),
    ("feedback_composer", "enterprise", "Composes constructive, actionable feedback with specific examples"),
    ("clarity_optimizer", "enterprise", "Optimizes text for clarity, removing ambiguity and improving readability"),
    ("audience_adapter", "free", "Adapts content for specific audience expertise level and interests"),
    # FREE - Planning (2)
    ("stakeholder_mapper", "free", "Maps stakeholders by influence, interest, and impact; identifies key players"),
    ("scenario_planner", "free", "Creates multiple future scenarios with probabilities and contingency plans"),
    ("resource_allocator", "enterprise", "Optimal resource allocation across competing priorities and constraints"),
    ("priority_setter", "enterprise", "Ranks priorities using weighted criteria and urgency/importance matrix"),
    ("deadline_manager", "enterprise", "Creates timeline with milestones, dependencies, and buffer management"),
    # FREE - Specialized (6)
    ("code_reviewer", "free", "Systematic code review: security, performance, maintainability, best practices"),
    ("content_outliner", "enterprise", "Creates structured content outlines with hierarchy and flow"),
    ("socratic_questioner", "free", "Asks probing questions to uncover hidden assumptions and deepen understanding"),
    ("intent_recognizer", "free", "Identifies the core intent, goals, and motivations behind a query"),
    ("ambiguity_resolver", "enterprise", "Identifies and resolves ambiguous terms, phrases, and requirements"),
    ("risk_assessor", "free", "Evaluates risks by likelihood, impact, and suggests mitigation strategies"),
    ("risk_mitigator", "enterprise", "Develops specific risk mitigation plans with contingencies"),
    ("impact_assessor", "enterprise", "Assesses downstream effects and consequences of decisions or changes"),
    ("conflict_resolver", "free", "Mediates conflicts by identifying interests, finding common ground"),
    ("concept_explainer", "enterprise", "Explains complex concepts using layered depth: simple → technical → expert"),
    ("synthesis_builder", "free", "Synthesizes multiple sources into a coherent, integrated summary"),
    # ENTERPRISE - Decision (5)
    ("decision_framework", "enterprise", "Structured decision-making with weighted criteria, options evaluation, and recommendations"),
    ("comparative_analyzer", "enterprise", "Side-by-side comparison across multiple dimensions with explicit scoring"),
    ("tradeoff_analyzer", "enterprise", "Analyzes trade-offs with pros/cons, risk profiles, and recommended path"),
    ("multi_objective_optimizer", "enterprise", "Optimizes across multiple competing objectives using Pareto analysis"),
    ("cost_benefit_analyzer", "enterprise", "Comprehensive cost-benefit analysis with ROI, payback period, risk-adjusted returns"),
    # ENTERPRISE - Problem Solving (6)
    ("problem_decomposer", "enterprise", "Decomposes complex problems into manageable sub-problems with dependencies"),
    ("bottleneck_identifier", "enterprise", "Identifies bottlenecks and constraints limiting system performance"),
    ("constraint_optimizer", "enterprise", "Finds optimal solutions within hard and soft constraints"),
    ("dependency_mapper", "enterprise", "Maps dependencies between components, teams, and processes"),
    ("efficiency_analyzer", "enterprise", "Analyzes process efficiency: waste, redundancy, optimization opportunities"),
    ("trade_space_explorer", "enterprise", "Explores the design space of alternatives and their feasibility"),
    # ENTERPRISE - Temporal (3)
    ("temporal_sequence_analyzer", "enterprise", "Builds event timelines, identifies causal sequences and trigger points"),
    ("future_scenario_planner", "enterprise", "Creates 2x2 scenario matrices for strategic planning and what-if analysis"),
    ("historical_context_mapper", "enterprise", "Extracts lessons from historical precedents and analogous situations"),
    # ENTERPRISE - Diagnostic (3)
    ("diagnostic_root_cause_analyzer", "enterprise", "Full diagnostic: Five Whys + Ishikawa + fault tree + systemic failure analysis"),
    ("differential_diagnoser", "enterprise", "Systematically rules out hypotheses to arrive at most likely diagnosis"),
    ("system_health_auditor", "enterprise", "Comprehensive system audit across reliability, performance, security dimensions"),
    # ENTERPRISE - Synthesis (3)
    ("holistic_integrator", "enterprise", "Integrates multiple perspectives into unified, multi-dimensional analysis"),
    ("pattern_recognition_engine", "enterprise", "Identifies recurring patterns, correlations, and hidden structures in data"),
    ("cross_domain_synthesizer", "enterprise", "Borrows proven solutions from other industries and domains"),
    # ENTERPRISE - Systems Thinking (6)
    ("feedback_loop_identifier", "enterprise", "Identifies reinforcing and balancing feedback loops in complex systems"),
    ("leverage_point_finder", "enterprise", "Finds high-impact intervention points where small changes create large effects"),
    ("emergence_detector", "enterprise", "Detects emergent properties arising from system interactions"),
    ("system_archetype_analyzer", "enterprise", "Applies system archetypes (tragedy of commons, fixes that fail, etc.)"),
    ("causal_loop_diagrammer", "enterprise", "Creates causal loop diagrams showing system dynamics"),
    ("stock_flow_analyzer", "enterprise", "Analyzes stocks, flows, and accumulation in dynamic systems"),
    # ENTERPRISE - Metacognition (5)
    ("metacognitive_monitor", "enterprise", "Monitors and improves the thinking process itself"),
    ("self_regulation_framework", "enterprise", "Framework for self-regulation: plan, monitor, evaluate, adjust"),
    ("cognitive_strategy_selector", "enterprise", "Selects optimal cognitive strategies for different problem types"),
    ("learning_from_experience", "enterprise", "Structured after-action review to extract lessons learned"),
    ("error_detection_framework", "enterprise", "Detects reasoning errors, biases, and logical fallacies"),
    # ENTERPRISE - Ethical Reasoning (5)
    ("ethical_framework_analyzer", "enterprise", "Applies multiple ethical frameworks: deontological, utilitarian, virtue ethics"),
    ("moral_dilemma_resolver", "enterprise", "Navigates moral dilemmas with structured analysis of competing values"),
    ("stakeholder_ethics_assessor", "enterprise", "Assesses ethical impact on all stakeholders"),
    ("value_conflict_navigator", "enterprise", "Navigates conflicts between competing values and principles"),
    ("consequentialist_analyzer", "enterprise", "Analyzes decisions by their consequences across stakeholders"),
    # ENTERPRISE - Learning (5)
    ("scaffolding_framework", "enterprise", "Provides progressive learning scaffolding matched to skill level"),
    ("spaced_repetition_optimizer", "enterprise", "Optimizes retention through spaced repetition scheduling"),
    ("zone_of_proximal_development", "enterprise", "Identifies the learner's ZPD for optimal challenge level"),
    ("cognitive_load_manager", "enterprise", "Manages cognitive load to prevent overwhelm and optimize learning"),
    ("conceptual_change_analyzer", "enterprise", "Facilitates conceptual change by addressing misconceptions"),
    # ENTERPRISE - Evaluation (5)
    ("rubric_designer", "enterprise", "Designs assessment rubrics with clear criteria and performance levels"),
    ("formative_assessment_framework", "enterprise", "Creates formative assessments for continuous improvement"),
    ("summative_evaluator", "enterprise", "Comprehensive summative evaluation with criteria-based scoring"),
    ("peer_assessment_structure", "enterprise", "Structures effective peer assessment with calibration"),
    ("self_assessment_guide", "enterprise", "Guides self-assessment with reflection prompts and benchmarks"),
]

NAME_TO_CATEGORY = {name: cat for name, cat, _ in FULL_PATTERN_CATALOG}
NAME_TO_DESCRIPTION = {name: desc for name, _, desc in FULL_PATTERN_CATALOG}
VALID_PATTERN_NAMES = set(NAME_TO_CATEGORY.keys())
PATTERN_CATALOG = "\n".join(f"{n} [{c}]: {d}" for n, c, d in FULL_PATTERN_CATALOG)

# Compact grouped catalog for LLM reasoning — structured so the model can scan categories
_GROUPED: dict = {}
for _n, _c, _d in FULL_PATTERN_CATALOG:
    _group = _c
    _GROUPED.setdefault(_group, []).append((_n, _d))

CATALOG_FOR_LLM = ""
for _tier in ("free", "enterprise"):
    CATALOG_FOR_LLM += f"\n{'FREE' if _tier == 'free' else 'ENTERPRISE'} TEMPLATES:\n"
    for _n, _d in _GROUPED.get(_tier, []):
        CATALOG_FOR_LLM += f"  {_n}: {_d}\n"


# Keyword -> (pattern_name, category, reason_snippet) - ALL 85 templates
PATTERN_MAP: List[Tuple[List[str], Tuple[str, str, str]]] = [
    # FREE - Analysis
    (["question", "analyze", "clarify", "what is", "unclear"], ("question_analyzer", "free", "Question analysis")),
    (["data", "trend", "metrics", "numbers", "dataset", "csv"], ("data_analyzer", "free", "Data analysis")),
    (["trend", "trends", "over time", "pattern in data"], ("trend_identifier", "enterprise", "Trend identification")),
    (["gap", "gaps", "missing", "lacks", "shortfall"], ("gap_analyzer", "enterprise", "Gap analysis")),
    (["swot", "strengths", "weaknesses", "opportunities", "threats"], ("swot_analyzer", "enterprise", "SWOT analysis")),
    (["anomaly", "anomalies", "outlier", "outliers", "unusual"], ("anomaly_detector", "enterprise", "Anomaly detection")),
    # FREE - Reasoning
    (["step by step", "explain", "how does", "reasoning", "logic", "walk through"], ("step_by_step_reasoner", "free", "Step-by-step reasoning")),
    (["cause", "causes", "causal", "why", "because", "led to", "resulted in", "reason for", "what caused"], ("causal_reasoner", "enterprise", "Causal reasoning")),
    (["analogy", "analogous", "like", "similar to", "compare to"], ("analogical_reasoner", "enterprise", "Analogical reasoning")),
    (["hypothesis", "hypotheses", "test", "guess", "suppose"], ("hypothesis_generator", "free", "Hypothesis generation")),
    # FREE - Creative
    (["idea", "ideas", "brainstorm", "come up with"], ("idea_generator", "enterprise", "Idea generation")),
    (["brainstorm", "ideation", "creative"], ("brainstormer", "free", "Brainstorming")),
    (["innovate", "innovation", "new approach", "novel"], ("innovation_framework", "enterprise", "Innovation")),
    (["design thinking", "design", "user-centric"], ("design_thinker", "enterprise", "Design thinking")),
    (["metaphor", "metaphors", "like a", "analogy"], ("metaphor_generator", "enterprise", "Metaphor generation")),
    # FREE - Communication
    (["translate", "technical", "non-technical", "explain to"], ("technical_translator", "free", "Technical translation")),
    (["simplify", "simple", "simplification", "clearer"], ("simplification_engine", "enterprise", "Simplification")),
    (["persuade", "persuasion", "convince", "argue for"], ("persuasion_framework", "enterprise", "Persuasion")),
    (["narrative", "story", "storytelling"], ("narrative_builder", "enterprise", "Narrative building")),
    (["feedback", "give feedback", "constructive"], ("feedback_composer", "enterprise", "Feedback composition")),
    (["clarity", "clear", "lucid", "unclear"], ("clarity_optimizer", "enterprise", "Clarity optimization")),
    (["audience", "adapt", "tailor", "target"], ("audience_adapter", "free", "Audience adaptation")),
    # FREE - Planning
    (["stakeholder", "stakeholders", "who is involved"], ("stakeholder_mapper", "free", "Stakeholder mapping")),
    (["scenario", "scenarios", "plan for"], ("scenario_planner", "free", "Scenario planning")),
    (["resource", "resources", "allocate", "budget"], ("resource_allocator", "enterprise", "Resource allocation")),
    (["priority", "priorities", "prioritize", "rank"], ("priority_setter", "enterprise", "Priority setting")),
    (["deadline", "deadlines", "timeline", "due date"], ("deadline_manager", "enterprise", "Deadline management")),
    # FREE - Specialized
    (["code", "review", "pull request", "implementation", "codereview"], ("code_reviewer", "free", "Code review")),
    (["outline", "content", "structure"], ("content_outliner", "enterprise", "Content outlining")),
    (["socratic", "probe", "question", "explore"], ("socratic_questioner", "free", "Socratic questioning")),
    (["intent", "what do they want", "goal"], ("intent_recognizer", "free", "Intent recognition")),
    (["ambiguity", "ambiguous", "unclear meaning"], ("ambiguity_resolver", "enterprise", "Ambiguity resolution")),
    (["risk", "risks", "what could go wrong", "threat"], ("risk_assessor", "free", "Risk assessment")),
    (["mitigate", "mitigation", "reduce risk"], ("risk_mitigator", "enterprise", "Risk mitigation")),
    (["impact", "affect", "effect", "consequences"], ("impact_assessor", "enterprise", "Impact assessment")),
    (["conflict", "conflicts", "disagree", "dispute"], ("conflict_resolver", "free", "Conflict resolution")),
    (["concept", "concepts", "explain", "define"], ("concept_explainer", "enterprise", "Concept explanation")),
    (["synthesis", "synthesize", "combine"], ("synthesis_builder", "free", "Synthesis building")),
    # ENTERPRISE - Decision
    (["should we", "should i", "decide", "decision", "choose between"], ("decision_framework", "enterprise", "Decision framework")),
    (["compare", "versus", "vs", "better", "difference between"], ("comparative_analyzer", "enterprise", "Comparison analysis")),
    (["trade-off", "tradeoff", "trade off", "pros and cons"], ("tradeoff_analyzer", "enterprise", "Trade-off analysis")),
    (["multi-objective", "multiple goals", "pareto", "optimize"], ("multi_objective_optimizer", "enterprise", "Multi-objective optimization")),
    (["cost benefit", "cost-benefit", "roi", "payback"], ("cost_benefit_analyzer", "enterprise", "Cost-benefit analysis")),
    # ENTERPRISE - Problem Solving / FREE root cause
    (["problem", "fix", "solve", "issue", "troubleshoot", "outage", "failure", "crash", "bug", "broken", "went wrong"], ("root_cause_analyzer", "free", "Problem investigation (free RCA)")),
    (["decompose", "break down", "analyze parts", "components"], ("problem_decomposer", "enterprise", "Problem decomposition")),
    (["bottleneck", "bottlenecks", "constraint", "limiting"], ("bottleneck_identifier", "enterprise", "Bottleneck identification")),
    (["constraint", "constraints", "optimize within"], ("constraint_optimizer", "enterprise", "Constraint optimization")),
    (["dependency", "dependencies", "depends on"], ("dependency_mapper", "enterprise", "Dependency mapping")),
    (["efficiency", "efficient", "optimize process"], ("efficiency_analyzer", "enterprise", "Efficiency analysis")),
    (["trade space", "design space", "alternatives"], ("trade_space_explorer", "enterprise", "Trade space exploration")),
    # ENTERPRISE - Temporal
    (["timeline", "sequence", "when did", "order of events", "chronological", "over time"], ("temporal_sequence_analyzer", "enterprise", "Events/sequence analysis")),
    (["scenario", "future", "what if", "planning horizon", "5 years", "10 years"], ("future_scenario_planner", "enterprise", "Future scenario planning")),
    (["historical", "precedent", "past", "learn from history"], ("historical_context_mapper", "enterprise", "Historical context")),
    # ENTERPRISE - Diagnostic (full RCA, requires license)
    (["root cause", "root causes", "why did", "why is", "why does", "why was", "why are",
      "five whys", "fishbone", "ishikawa", "what caused", "spike", "drop",
      "churn", "decline", "incident", "outage", "degradation"], ("diagnostic_root_cause_analyzer", "enterprise", "Full diagnostic root cause analysis")),
    (["diagnose", "differential", "multiple possible", "hypothesis", "ruled out"], ("differential_diagnoser", "enterprise", "Differential diagnosis")),
    (["system health", "audit", "check", "status", "health check"], ("system_health_auditor", "enterprise", "System health audit")),
    # ENTERPRISE - Synthesis
    (["integrate", "holistic", "multiple perspectives", "combine", "synthesize"], ("holistic_integrator", "enterprise", "Multi-perspective synthesis")),
    (["pattern", "recognize", "recurring", "trend in data", "identify pattern"], ("pattern_recognition_engine", "enterprise", "Pattern recognition")),
    (["cross-domain", "borrow from", "analogy", "other industry", "innovation"], ("cross_domain_synthesizer", "enterprise", "Cross-domain synthesis")),
    # ENTERPRISE - Systems Thinking
    (["feedback loop", "reinforcing", "balancing", "system dynamics"], ("feedback_loop_identifier", "enterprise", "Feedback loop analysis")),
    (["leverage point", "intervention", "high impact", "where to act"], ("leverage_point_finder", "enterprise", "Leverage point identification")),
    (["emergence", "emergent", "emerging properties"], ("emergence_detector", "enterprise", "Emergence detection")),
    (["archetype", "system archetype"], ("system_archetype_analyzer", "enterprise", "System archetype analysis")),
    (["causal loop", "loop diagram"], ("causal_loop_diagrammer", "enterprise", "Causal loop diagramming")),
    (["stock", "flow", "accumulation", "stocks and flows"], ("stock_flow_analyzer", "enterprise", "Stock-flow analysis")),
    # ENTERPRISE - Metacognition
    (["metacogn", "self-monitor", "thinking about thinking"], ("metacognitive_monitor", "enterprise", "Metacognitive monitoring")),
    (["self-regulat", "self regulation", "regulate"], ("self_regulation_framework", "enterprise", "Self-regulation")),
    (["cognitive strategy", "strategy selection"], ("cognitive_strategy_selector", "enterprise", "Cognitive strategy selection")),
    (["learn from experience", "after action", "retrospective"], ("learning_from_experience", "enterprise", "Learning from experience")),
    (["error detection", "detect error", "mistake"], ("error_detection_framework", "enterprise", "Error detection")),
    # ENTERPRISE - Ethical Reasoning
    (["ethical", "ethics", "moral", "dilemma", "right or wrong"], ("ethical_framework_analyzer", "enterprise", "Ethical analysis")),
    (["moral dilemma", "ethical dilemma"], ("moral_dilemma_resolver", "enterprise", "Moral dilemma resolution")),
    (["stakeholder", "who is affected", "impact on"], ("stakeholder_ethics_assessor", "enterprise", "Stakeholder ethics")),
    (["value conflict", "values conflict"], ("value_conflict_navigator", "enterprise", "Value conflict navigation")),
    (["consequentialist", "consequences", "utilitarian"], ("consequentialist_analyzer", "enterprise", "Consequentialist analysis")),
    # ENTERPRISE - Learning
    (["learn", "teaching", "scaffold", "skill level", "zone of proximal"], ("scaffolding_framework", "enterprise", "Learning scaffolding")),
    (["spaced repetition", "spacing", "retention"], ("spaced_repetition_optimizer", "enterprise", "Spaced repetition")),
    (["zpd", "zone of proximal", "proximal development"], ("zone_of_proximal_development", "enterprise", "Zone of proximal development")),
    (["cognitive load", "load", "working memory"], ("cognitive_load_manager", "enterprise", "Cognitive load management")),
    (["conceptual change", "misconception", "conceptual"], ("conceptual_change_analyzer", "enterprise", "Conceptual change analysis")),
    # ENTERPRISE - Evaluation
    (["assess", "evaluate", "rubric", "criteria", "score"], ("rubric_designer", "enterprise", "Assessment rubric")),
    (["formative", "formative assessment"], ("formative_assessment_framework", "enterprise", "Formative assessment")),
    (["summative", "summative assessment", "final eval"], ("summative_evaluator", "enterprise", "Summative evaluation")),
    (["peer assess", "peer evaluation", "peer review"], ("peer_assessment_structure", "enterprise", "Peer assessment")),
    (["self assess", "self-assessment", "self eval"], ("self_assessment_guide", "enterprise", "Self-assessment")),
]
