"""
Template Integrator Agent - The Best of All Worlds

Intelligently merges multiple cognitive templates into a single unified
context, combining the strongest methodologies from each into one cohesive
reasoning framework tailored to a specific question.

Research Foundation:
- DSPy: Compiling Declarative LM Calls (arxiv 2310.03714)
- Agentic Context Engineering (arxiv 2510.04618)
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..intelligence.pattern_suggester import (
    NAME_TO_CATEGORY,
    NAME_TO_DESCRIPTION,
    VALID_PATTERN_NAMES,
    ENTERPRISE_LICENSE_NOTE,
)


@dataclass
class IntegrationResult:
    """Result of template integration."""

    question: str
    source_templates: List[str]
    integrated_context: str
    role: str = ""
    rules: List[str] = field(default_factory=list)
    directive: str = ""
    output_requirements: List[str] = field(default_factory=list)
    raw_llm_response: str = ""

    def to_context(self):
        """Convert to a mycontext Context object for direct execution."""
        from ..core import Context
        from ..foundation import Directive, Guidance, Constraints

        gkw = {}
        if self.role:
            gkw["role"] = self.role
        if self.rules:
            gkw["rules"] = self.rules

        return Context(
            guidance=Guidance(**gkw) if gkw else None,
            directive=Directive(
                content=self.directive or self.integrated_context
            ),
            constraints=Constraints(
                must_include=self.output_requirements
            ) if self.output_requirements else None,
            data={
                "integration_metadata": {
                    "source_templates": self.source_templates,
                    "question": self.question,
                    "agent": "TemplateIntegratorAgent",
                }
            },
        )


INTEGRATION_PROMPT_TEMPLATE = (
    'You are the Template Integrator Agent -- '
    '"The Best of All Worlds."\n\n'
    'USER QUESTION: "{question}"\n\n'
    'SELECTED TEMPLATES TO INTEGRATE:\n{summaries}\n\n'
    'YOUR TASK: Create ONE integrated context that merges the best '
    'methodologies from ALL selected templates into a single, powerful '
    'reasoning framework. Do NOT simply list each template approach '
    'separately -- weave them together.\n\n'
    'Respond in this EXACT format:\n\n'
    'ROLE: [A combined expert role embodying expertise from all templates]\n\n'
    'RULES:\n'
    '- [Key methodology rule adapted for integration]\n'
    '- [Cross-cutting rule leveraging multiple templates]\n'
    '- [Additional rules as needed, max 8]\n\n'
    'DIRECTIVE:\n'
    '[Detailed step-by-step instructions weaving together all template '
    'methodologies into one coherent analysis. Be specific to the user '
    'question.]\n\n'
    'OUTPUT MUST INCLUDE:\n'
    '- [Required output section 1]\n'
    '- [Required output section 2]\n'
    '- [More sections as appropriate]\n\n'
    'INTEGRATION RATIONALE:\n'
    '[2-3 sentences: why this combination is more powerful than any '
    'single template]'
)


class TemplateIntegratorAgent:
    """
    The Best of All Worlds - merges multiple cognitive templates into one.

    Given a user question and a set of template names, the agent:
    1. Gathers what each template brings (methodology, structure, focus)
    2. Asks the LLM to fuse them into a single integrated context
    3. Returns a structured IntegrationResult that can be used directly

    Enterprise gating: non-enterprise users cannot integrate enterprise
    templates unless include_enterprise=True.

    Usage (SDK):
        >>> agent = TemplateIntegratorAgent()
        >>> result = agent.integrate(
        ...     question="Should we migrate to microservices?",
        ...     template_names=["decision_framework", "risk_assessor"],
        ...     provider="openai",
        ... )
        >>> ctx = result.to_context()
        >>> ctx.execute(provider="openai")

    All-in-one (suggest + integrate):
        >>> result = agent.suggest_and_integrate(
        ...     question="Why did churn spike?",
        ...     provider="openai",
        ... )
    """

    TAGLINE = "The Best of All Worlds"

    def __init__(self, include_enterprise=True):
        self.include_enterprise = include_enterprise

    # ------------------------------------------------------------------ #
    #  Public API                                                         #
    # ------------------------------------------------------------------ #

    def integrate(
        self,
        question,
        template_names,
        provider="openai",
        selection_reasoning=None,
        temperature=0.2,
        model=None,
        **kwargs,
    ):
        """Merge multiple templates into one unified context."""
        self._validate(template_names)
        selection_reasoning = selection_reasoning or {}
        summaries = self._build_summaries(template_names, selection_reasoning)
        prompt = INTEGRATION_PROMPT_TEMPLATE.format(
            question=question, summaries=summaries
        )
        raw = self._call_llm(prompt, provider, temperature, model, **kwargs)
        return self._parse_result(question, template_names, raw)

    def suggest_and_integrate(
        self,
        question,
        provider="openai",
        max_patterns=5,
        mode="hybrid",
        **kwargs,
    ):
        """All-in-one: suggest the best templates AND integrate them."""
        from .pattern_suggester import suggest_patterns

        result = suggest_patterns(
            question,
            include_enterprise=self.include_enterprise,
            suggest_chain=True,
            max_patterns=max_patterns,
            mode=mode,
            llm_provider=provider,
            **kwargs,
        )
        names = (
            result.suggested_chain
            or [s.name for s in result.suggested_patterns]
        )
        reasoning = {s.name: s.reason for s in result.suggested_patterns}
        return self.integrate(
            question=question,
            template_names=names,
            provider=provider,
            selection_reasoning=reasoning,
            **kwargs,
        )

    # ------------------------------------------------------------------ #
    #  Internal helpers                                                   #
    # ------------------------------------------------------------------ #

    def _validate(self, template_names):
        invalid = [t for t in template_names if t not in VALID_PATTERN_NAMES]
        if invalid:
            raise ValueError("Unknown template(s): " + str(invalid))

        if not self.include_enterprise:
            ent = [
                t for t in template_names
                if NAME_TO_CATEGORY.get(t) == "enterprise"
            ]
            if ent:
                raise ValueError(
                    "Enterprise license required for: " + str(ent)
                    + ". " + ENTERPRISE_LICENSE_NOTE.strip()
                )

    def _build_summaries(self, names, reasoning):
        lines = []
        for name in names:
            cat = NAME_TO_CATEGORY.get(name, "free")
            desc = NAME_TO_DESCRIPTION.get(name, name)
            why = reasoning.get(name, "")
            line = "- " + name + " [" + cat + "]: " + desc
            if why:
                line += "\n  Why chosen: " + why
            lines.append(line)
        return "\n".join(lines)

    def _call_llm(self, prompt, provider, temperature, model, **kwargs):
        from ..core import Context
        from ..foundation import Directive, Guidance

        ctx = Context(
            guidance=Guidance(
                role=(
                    "Template Integrator Agent -- expert at fusing "
                    "multiple cognitive reasoning frameworks into one "
                    "unified, powerful context"
                ),
                rules=[
                    "Merge methodologies, do not just concatenate them.",
                    "Every element must be specific to the user question.",
                    "The result must be directly usable as an LLM prompt.",
                ],
            ),
            directive=Directive(content=prompt),
        )
        exec_kw = {"temperature": temperature}
        exec_kw.update(kwargs)
        if model:
            exec_kw["model"] = model
        result = ctx.execute(provider=provider, **exec_kw)
        return result.response.strip()

    def _parse_result(self, question, names, raw):
        import re

        role = ""
        rules = []
        directive = ""
        output_reqs = []

        role_m = re.search(r"ROLE:\s*(.+)", raw)
        if role_m:
            role = role_m.group(1).strip()

        rules_m = re.search(r"RULES:\s*\n((?:- .+\n?)+)", raw)
        if rules_m:
            rules = [
                line.lstrip("- ").strip()
                for line in rules_m.group(1).strip().split("\n")
                if line.strip().startswith("-")
            ]

        dir_m = re.search(
            r"DIRECTIVE:\s*\n([\s\S]+?)"
            r"(?=\nOUTPUT MUST INCLUDE:|\nINTEGRATION RATIONALE:|$)",
            raw,
        )
        if dir_m:
            directive = dir_m.group(1).strip()

        out_m = re.search(
            r"OUTPUT MUST INCLUDE:\s*\n((?:- .+\n?)+)", raw
        )
        if out_m:
            output_reqs = [
                line.lstrip("- ").strip()
                for line in out_m.group(1).strip().split("\n")
                if line.strip().startswith("-")
            ]

        return IntegrationResult(
            question=question,
            source_templates=names,
            integrated_context=raw,
            role=role,
            rules=rules,
            directive=directive,
            output_requirements=output_reqs,
            raw_llm_response=raw,
        )
