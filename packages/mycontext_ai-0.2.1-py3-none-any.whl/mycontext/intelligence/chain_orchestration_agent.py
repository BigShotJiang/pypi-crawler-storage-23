"""
Chain Orchestration Agent - LLM-driven workflow chain + chain_params generation.

Analyzes the user question, selects and orders patterns from the full catalog,
and produces both workflow_chain and chain_params automatically. Uses temperature=0
for deterministic output and supports LLM overrides for task-specific params.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .pattern_suggester import (
    PATTERN_CATALOG,
    VALID_PATTERN_NAMES,
    get_pattern_class,
)


class _DynamicBuildContextRegistry:
    """Lazy registry that introspects pattern build_context() signatures at runtime.

    Replaces the old manually-maintained dict.  Accessed like a dict
    (``registry[name]``, ``registry.get(name)``, ``name in registry``,
    ``registry.items()``) but builds entries on first access from the
    unified pattern registry.
    """

    def __init__(self) -> None:
        self._cache: Dict[str, tuple] | None = None

    def _ensure(self) -> Dict[str, tuple]:
        if self._cache is None:
            from ..skills.pattern_registry import (
                get_pattern_registry,
                get_pattern_build_params,
            )
            registry = get_pattern_registry()
            self._cache = {
                name: get_pattern_build_params(name)
                for name in registry
            }
        return self._cache

    def __getitem__(self, key: str) -> tuple:
        return self._ensure()[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self._ensure().get(key, default)

    def __contains__(self, key: object) -> bool:
        return key in self._ensure()

    def items(self):
        return self._ensure().items()

    def keys(self):
        return self._ensure().keys()

    def values(self):
        return self._ensure().values()

    def __iter__(self):
        return iter(self._ensure())

    def __len__(self):
        return len(self._ensure())


PATTERN_BUILD_CONTEXT_REGISTRY: Any = _DynamicBuildContextRegistry()


@dataclass
class WorkflowChainResult:
    """Result of chain orchestration: chain + chain_params + selection reasoning."""

    chain: List[str]
    chain_params: Dict[str, Dict[str, Any]]
    reasoning: str = ""
    selection_reasoning: Dict[str, str] = field(default_factory=dict)  # pattern_name -> why chosen, how it relates
    question_analysis: Optional[Dict[str, Any]] = None  # facets, key_concerns, decomposition
    template_decomposition: Optional[str] = None  # raw output from question_analyzer template (when used)
    llm_raw: Optional[str] = None

    def to_chain_params_tuple_format(self) -> Dict[str, tuple]:
        """Convert to (primary_key, extra_dict) format for orchestrator loop.
        Returns dict: name -> (primary_input_key, extra_kwargs_for_build_context)
        Always merges registry defaults so required fields (depth, context_section, etc.) are present.
        """
        out = {}
        for name in self.chain:
            params = self.chain_params.get(name, {})
            reg = PATTERN_BUILD_CONTEXT_REGISTRY.get(name, ("input", {}))
            primary, defaults = reg
            # Start with defaults (ensures depth, context, etc. are present)
            extra = dict(defaults)
            # Overlay custom params (excluding primary, which gets prev at runtime)
            for k, v in params.items():
                if k != primary:
                    extra[k] = v
            out[name] = (primary, extra)
        return out


def build_workflow_chain(
    question: str,
    include_enterprise: bool = True,
    max_patterns: Optional[int] = None,
    use_question_analyzer: bool = True,
    provider: str = "openai",
    temperature: float = 0,
    model: Optional[str] = None,
    **llm_kwargs: Any,
) -> WorkflowChainResult:
    """
    Use LLM to select, order, and generate chain_params for a workflow chain.

    When use_question_analyzer=True (default), runs the question_analyzer template first
    to decompose the goal, then uses that output to inform pattern selection.

    Args:
        question: User's question or task description
        include_enterprise: Include enterprise patterns (default True)
        max_patterns: Max patterns in chain (None = no limit)
        use_question_analyzer: Run question_analyzer template first for decomposition (default True)
        provider: LLM provider ("openai", "anthropic", "gemini")
        temperature: LLM temperature (default 0 for determinism)
        model: Override model name
        **llm_kwargs: Extra kwargs passed to provider.generate()

    Returns:
        WorkflowChainResult with chain, chain_params, and reasoning
    """
    from ..core import Context
    from ..foundation import Directive, Guidance

    template_decomposition: Optional[str] = None
    if use_question_analyzer:
        try:
            analyzer = get_pattern_class("question_analyzer")
            if analyzer is not None:
                exec_kw = {"provider": provider, "temperature": temperature, **llm_kwargs}
                if model:
                    exec_kw["model"] = model
                qa_result = analyzer().execute(question=question, **exec_kw)
                template_decomposition = (qa_result.response or "").strip()[:4000]  # bound size
        except Exception:
            pass  # fall back to selection without template output

    # Build catalog for prompt (filter enterprise if needed)
    if include_enterprise:
        catalog = PATTERN_CATALOG
        valid = VALID_PATTERN_NAMES
    else:
        from .pattern_catalog import FULL_PATTERN_CATALOG
        catalog = "\n".join(f"{n}: {d}" for n, c, d in FULL_PATTERN_CATALOG if c == "free")
        valid = {n for n, c, _ in FULL_PATTERN_CATALOG if c == "free"}

    # Schema excerpt for LLM
    schema_example = """
For each pattern, provide optional overrides. Common keys: data, data_description, goal, baseline, problem, situation, input, context, pattern_focus, etc.
Use exact pattern names from the catalog.
"""

    pre_analysis_block = ""
    if template_decomposition:
        pre_analysis_block = f'''## Pre-analysis of the user goal (from question_analyzer template):

{template_decomposition}

**Use this analysis above** to inform your pattern selection. The template has decomposed the question - identify facets, key concerns, and map them to patterns.\n\n'''
    else:
        pre_analysis_block = """**Step 1** - Decompose the question: facets (classification, ambiguity, sarcasm, intent, etc.), key concerns, map to patterns.
**Step 2** - Select patterns for EVERY relevant facet. Do not skip ambiguity_resolver or intent_recognizer when the task involves unclear wording or intent.\n\n"""

    prompt = f"""Task: "{question}"

{pre_analysis_block}Available patterns (use EXACT names):
{catalog}
{schema_example}

Return a JSON object with these keys:
1. "question_analysis": {{"facets": ["list of task facets you identified"], "key_concerns": ["ambiguity?", "sarcasm?", "intent?", etc.], "decomposition": "brief summary of what the task entails"}}
2. "chain": array of pattern names in workflow order. Include patterns for ALL relevant facets (ambiguity, intent, sentiment, synthesis, etc.). No limit.
3. "chain_params": object mapping each pattern name to its build_context params. Primary input key = "<from previous step>", plus task-specific overrides.
4. "selection_reasoning": object mapping each pattern name to a short explanation: WHY you chose it, HOW it relates to the question/facets, WHAT aspect it addresses.

Example for sentiment + ambiguity:
{{
  "question_analysis": {{
    "facets": ["sentiment classification", "ambiguity in wording", "sarcasm/hedging", "intent recognition"],
    "key_concerns": ["mixed signals", "subjective language", "context-dependent meaning", "sarcasm detection"],
    "decomposition": "Classify sentiment while handling ambiguous, sarcastic, or hedged language; infer user intent."
  }},
  "chain": ["question_analyzer", "pattern_recognition_engine", "ambiguity_resolver", "intent_recognizer", "feedback_composer", "synthesis_builder"],
  "chain_params": {{ ... }},
  "selection_reasoning": {{
    "question_analyzer": "Clarifies the task and any ambiguous aspects of the user goal itself.",
    "pattern_recognition_engine": "Identifies sentiment cues and tone patterns in text.",
    "ambiguity_resolver": "Resolves ambiguous wording, sarcasm, hedging - key concern for sentiment.",
    "intent_recognizer": "Infers underlying intent (would_recommend, complain, etc.).",
    "feedback_composer": "Structures constructive sentiment feedback.",
    "synthesis_builder": "Combines all perspectives into coherent output."
  }}
}}

Respond with ONLY valid JSON. No markdown, no explanation outside JSON."""

    try:
        ctx = Context(
            guidance=Guidance(
                role="Workflow chain orchestrator",
                rules=[
                    "First decompose the question: identify ALL facets (ambiguity, sarcasm, intent, sentiment, etc.).",
                    "Then pick patterns that address EVERY facet. Do not skip ambiguity_resolver or intent_recognizer if the task involves unclear wording or intent.",
                    "Pick only from the catalog. Return valid JSON only.",
                    "Order patterns logically: question_analysis first, then analysis → reasoning → specialized (ambiguity, intent) → synthesis.",
                ],
            ),
            directive=Directive(content=prompt),
        )
        exec_kwargs = dict(llm_kwargs)
        exec_kwargs["temperature"] = temperature
        if model:
            exec_kwargs["model"] = model
        result = ctx.execute(provider=provider, **exec_kwargs)
    except Exception as e:
        return WorkflowChainResult(
            chain=[],
            chain_params={},
            reasoning=f"Error: {e}",
            llm_raw=str(e),
        )

    raw = result.response.strip()
    # Strip markdown code blocks if present
    if raw.startswith("```"):
        lines = raw.split("\n")
        raw = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])

    import json
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        return WorkflowChainResult(
            chain=[],
            chain_params={},
            reasoning=f"Invalid JSON: {e}",
            llm_raw=raw[:1000],
        )

    chain = data.get("chain", [])
    chain_params = data.get("chain_params", {})
    selection_reasoning = data.get("selection_reasoning", {})
    question_analysis = data.get("question_analysis")

    # Validate and filter to valid pattern names
    chain = [n for n in chain if n in valid]
    if max_patterns is not None:
        chain = chain[:max_patterns]
    chain_params = {k: v for k, v in chain_params.items() if k in valid}
    selection_reasoning = {k: v for k, v in selection_reasoning.items() if k in valid}

    # Ensure chain_params has entries for all chain patterns; merge with registry
    merged_params = {}
    for name in chain:
        reg = PATTERN_BUILD_CONTEXT_REGISTRY.get(name, ("input", {}))
        primary, defaults = reg
        custom = chain_params.get(name, {})
        merged = dict(defaults)
        for k, v in custom.items():
            if v != "<from previous step>" or k == primary:
                merged[k] = v
        if primary not in merged and name in chain_params:
            merged[primary] = chain_params[name].get(primary, "<from previous step>")
        elif primary not in merged:
            merged[primary] = "<from previous step>"
        merged_params[name] = merged

    reasoning_parts = []
    if question_analysis:
        decomp = question_analysis.get("decomposition", "")
        facets = question_analysis.get("facets", [])
        if decomp:
            reasoning_parts.append(decomp)
        if facets:
            reasoning_parts.append("Facets: " + ", ".join(facets[:6]))
    if selection_reasoning:
        reasoning_parts.append(
            f"Selected {len(chain)} patterns: "
            + " → ".join(chain[:8])
        )
    reasoning_text = ". ".join(reasoning_parts) if reasoning_parts else f"Selected {len(chain)} patterns for this task."

    return WorkflowChainResult(
        chain=chain,
        chain_params=merged_params,
        reasoning=reasoning_text,
        selection_reasoning=selection_reasoning,
        question_analysis=question_analysis,
        template_decomposition=template_decomposition,
        llm_raw=raw[:2000],
    )
