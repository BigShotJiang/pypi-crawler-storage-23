#!/usr/bin/env python
# -*- coding: utf-8 -*-
from argparse import ArgumentParser, BooleanOptionalAction

from ..utils import load_yaml_or_json
from .Spartan import SpartanController


def main() -> None:
    parser = ArgumentParser(description="")
    parser.add_argument("filepath", help="")
    parser.add_argument("--mode", choices=["argparse", "json"])
    parser.add_argument("--n_seeds", type=int)
    parser.add_argument("--max_size", type=int)
    parser.add_argument("--interval", type=int)
    parser.add_argument("--seed_key")
    parser.add_argument("--max_seed", type=int)
    parser.add_argument("--config_filepath")
    parser.add_argument(
        "--display", action=BooleanOptionalAction, default=None
    )

    args = parser.parse_args()
    input_dict = load_yaml_or_json(args.filepath)
    hosts = input_dict.get("hosts", [])
    command = input_dict.get("command", "")
    param_grid = input_dict.get("param_grid", [])

    # Option
    option = input_dict.get("option", {})
    mode = option.get("mode", "argparse")
    n_seeds = option.get("n_seeds", 1)
    maxsize = option.get("max_size", 0)
    interval = option.get("interval", 1.0)
    seed_key = option.get("seed_key", "_seed")
    max_seed = option.get("max_seed", 10000000)
    config_filepath = option.get("config_filepath", "")
    display = option.get("display", True)

    # Overwrite option values only when CLI args are explicitly provided.
    if args.mode is not None:
        mode = args.mode
    if args.n_seeds is not None:
        n_seeds = args.n_seeds
    if args.max_size is not None:
        maxsize = args.max_size
    if args.interval is not None:
        interval = args.interval
    if args.seed_key is not None:
        seed_key = args.seed_key
    if args.max_seed is not None:
        max_seed = args.max_seed
    if args.config_filepath is not None:
        config_filepath = args.config_filepath
    if args.display is not None:
        display = args.display
    sc = SpartanController(hosts, mode=mode)
    sc.exe(
        command,
        param_grid,
        n_seeds=n_seeds,
        maxsize=maxsize,
        interval=interval,
        seed_key=seed_key,
        max_seed=max_seed,
        config_filepath=config_filepath,
        display=display,
    )


if __name__ == "__main__":
    main()
