from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


# ── Request enums ─────────────────────────────────────────────────────


class OsSignal(str, Enum):
    UNDER_13 = "under-13"
    AGE_13_15 = "13-15"
    AGE_16_17 = "16-17"
    AGE_18_PLUS = "18-plus"
    NOT_AVAILABLE = "not-available"


class ParentalConsentStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    REVOKED = "revoked"


class ConsentSource(str, Enum):
    OS_SYSTEM = "os-system"
    THIRD_PARTY_WALLET = "third-party-wallet"
    IN_APP = "in-app"


class FaceEstimationProvider(str, Enum):
    YOTI = "yoti"
    PRIVADO = "privado"
    FACETEC = "facetec"


class IpType(str, Enum):
    RESIDENTIAL = "residential"
    EDUCATION = "education"
    DATACENTER = "datacenter"
    CORPORATE = "corporate"


class ReferrerCategory(str, Enum):
    DIRECT = "direct"
    SOCIAL_MINOR = "social_minor"
    SOCIAL_GENERAL = "social_general"
    PARENTAL_CONTROL = "parental_control"
    SEARCH_ENGINE = "search_engine"
    UNKNOWN = "unknown"


# ── Request models ────────────────────────────────────────────────────


class FaceEstimationResult(BaseModel):
    estimation_provider: FaceEstimationProvider
    estimated_age_lower: int = Field(ge=0, le=150)
    estimated_age_upper: int = Field(ge=0, le=150)
    confidence: float = Field(ge=0, le=1)


class BehavioralMetrics(BaseModel):
    avg_touch_precision: float = Field(ge=0, le=1)
    scroll_velocity: float = Field(ge=0)
    form_completion_time_ms: float = Field(ge=0)
    is_autofill_detected: Optional[bool] = None
    touch_pressure_variance: Optional[float] = Field(default=None, ge=0, le=1)
    multi_touch_frequency: Optional[float] = Field(default=None, ge=0)
    face_estimation_result: Optional[FaceEstimationResult] = None


class DeviceContext(BaseModel):
    os_version: str
    device_model: Optional[str] = None
    is_high_contrast_enabled: bool
    screen_scale_factor: float = Field(ge=0.5, le=5.0)


class ContextualSignals(BaseModel):
    ip_type: Optional[IpType] = None
    timezone_offset_delta_minutes: Optional[float] = None
    referrer_category: Optional[ReferrerCategory] = None


class AccountLongevity(BaseModel):
    account_age_days: int = Field(ge=0)


class InputComplexity(BaseModel):
    keyboard_autocorrect_rate: float = Field(ge=0, le=1)
    average_word_complexity_score: float = Field(ge=0, le=1)


class AssessAgeRequest(BaseModel):
    os_signal: OsSignal
    user_country_code: str
    behavioral_metrics: Optional[BehavioralMetrics] = None
    device_context: Optional[DeviceContext] = None
    contextual_signals: Optional[ContextualSignals] = None
    account_longevity: Optional[AccountLongevity] = None
    input_complexity: Optional[InputComplexity] = None
    parental_consent_status: Optional[ParentalConsentStatus] = None
    consent_source: Optional[ConsentSource] = None


# ── Response enums ────────────────────────────────────────────────────


class Verdict(str, Enum):
    CONSISTENT = "CONSISTENT"
    OVERRIDE = "OVERRIDE"
    REVIEW = "REVIEW"
    PROVISIONAL = "PROVISIONAL"


class AgeBracket(str, Enum):
    UNDER_13 = "under-13"
    AGE_13_15 = "13-15"
    AGE_16_17 = "16-17"
    AGE_18_PLUS = "18-plus"
    UNDETERMINED = "undetermined"


# ── Response model ────────────────────────────────────────────────────


class AssessAgeResponse(BaseModel):
    confidence_score: float
    verdict: Verdict
    os_signal_age_bracket: AgeBracket
    assessed_age_bracket: AgeBracket
    signal_overridden: bool
    internal_evidence_only: bool
    evidence_tags: list[str]
    user_country_code: str
    verification_token: str
    parental_consent_status: Optional[ParentalConsentStatus] = None
    consent_source: Optional[ConsentSource] = None
