"""A3 Age Assurance API — official Python client."""

from ._client import A3Client, AsyncA3Client
from ._errors import (
    A3ApiError,
    A3AuthenticationError,
    A3ConnectionError,
    A3RateLimitError,
    A3ValidationError,
)
from ._types import (
    AccountLongevity,
    AgeBracket,
    AssessAgeRequest,
    AssessAgeResponse,
    BehavioralMetrics,
    ConsentSource,
    ContextualSignals,
    DeviceContext,
    FaceEstimationProvider,
    FaceEstimationResult,
    InputComplexity,
    IpType,
    OsSignal,
    ParentalConsentStatus,
    ReferrerCategory,
    Verdict,
)
from ._version import __version__

__all__ = [
    # Clients
    "A3Client",
    "AsyncA3Client",
    # Errors
    "A3ApiError",
    "A3AuthenticationError",
    "A3ConnectionError",
    "A3RateLimitError",
    "A3ValidationError",
    # Request types
    "AssessAgeRequest",
    "OsSignal",
    "ParentalConsentStatus",
    "ConsentSource",
    "FaceEstimationProvider",
    "IpType",
    "ReferrerCategory",
    "BehavioralMetrics",
    "DeviceContext",
    "ContextualSignals",
    "AccountLongevity",
    "InputComplexity",
    "FaceEstimationResult",
    # Response types
    "AssessAgeResponse",
    "Verdict",
    "AgeBracket",
    # Version
    "__version__",
]
