import pytest
import httpx

from a3api import A3Client, AsyncA3Client

MOCK_RESPONSE_JSON = {
    "confidence_score": 0.92,
    "verdict": "CONSISTENT",
    "os_signal_age_bracket": "18-plus",
    "assessed_age_bracket": "18-plus",
    "signal_overridden": False,
    "internal_evidence_only": True,
    "evidence_tags": ["os_signal_consistent"],
    "user_country_code": "US",
    "verification_token": "eyJ0ZXN0IjoiMSJ9.abc123",
}


@pytest.fixture
def sync_client() -> A3Client:
    return A3Client(
        "sk_test",
        base_url="https://test.a3api.io",
        max_retries=0,
    )


@pytest.fixture
def async_client() -> AsyncA3Client:
    return AsyncA3Client(
        "sk_test",
        base_url="https://test.a3api.io",
        max_retries=0,
    )


@pytest.fixture
def mock_success(httpx_mock) -> None:
    httpx_mock.add_response(
        url="https://test.a3api.io/v1/assurance/assess-age",
        method="POST",
        json=MOCK_RESPONSE_JSON,
    )
