# AREA_VIZ
Tool zur Visualierung der KOCO - Vertriebsgebiete.

# Grunddaten für die Visualsierung
Da die Daten zu groß für ein PyPi-Package sind, können sie im github-Repository im Ordner "large_data" gefunden und nach Installation des PyPi-Packages an die gewünschte Stelle kopiert werden.

Der Ordner für den Zugriff auf die Daten muss über die Umgebungsvariable AV_LARGE_DATA_FOLDER im '''.env'''-File  der finalen Applikation gesetzt sein