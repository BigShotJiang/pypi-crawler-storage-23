# Kipu Quantum Hub API SDK

## Installation

The package is published on PyPI and can be installed via `pip`:

```bash
pip install --upgrade qhub-api
```
