"""Claude Code environment maintenance tool."""

__version__ = "0.1.0"
