# pytrate

[![tests](https://github.com/davipatti/pytrate/actions/workflows/run-tests.yml/badge.svg)](https://github.com/davipatti/pytrate/actions/workflows/run-tests.yml)
[![docs](https://github.com/davipatti/pytrate/actions/workflows/build-deploy-docs.yml/badge.svg)](https://github.com/davipatti/pytrate/actions/workflows/build-deploy-docs.yml)

Inferring effects of amino acid changes on antigenic phenotypes of viruses.

See the [docs](https://davipatti.github.io/pytrate/).

## Install

```
uv pip install git+https://github.com/davipatti/pytrate.git
```

## Main features

- **SeqDf** — aligned amino acid sequence management
- **CrossedSiteAaModel** — Bayesian model with crossed site and amino acid pair effects
- **CombinedSiteAaModel** — Bayesian model with combined site-amino acid effects
- **FoldChangeModel** — decompose titer fold changes from mutant vs root viruses
- **MapCoordModel** — Bayesian antigenic map natural experiments and visualization

## Tests

```
uv run --extra dev pytest
```

Some tests are a bit slow, do `uv run --extra dev pytest -k 'not slow'` to skip them.

## Build & publish

```
uv sync --extra dev
uv run python -m build
uv run python -m twine upload dist/*
```

## Pre-commit hook

To enable the pre-commit hook, symlink it into your local `.git/hooks` directory:

```
ln -s hooks/pre-commit .git/hooks/pre-commit
```