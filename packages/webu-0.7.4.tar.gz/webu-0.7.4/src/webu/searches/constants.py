REQUESTS_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661.62",
}

CHROME_CONFIGS = {
    "uid": "1000",
    "port": 29001,
    "use_vdisp": False,
}

PROXY_CHROME_CONFIGS = {
    "uid": "29002",
    "port": 29002,
    "proxy": "http://127.0.0.1:11111",
    "use_vdisp": False,
}
