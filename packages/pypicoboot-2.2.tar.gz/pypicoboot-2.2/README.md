# pypicoboot
Pico Boot tools for Python

## Introduction

Pico Boot is a tool in Python to communicate with RP2040, RP2350 and RP2354 boards.

## Install

```
pip install pypicoboot
```

## Usage

pypicoboot can be used as a Python module (picoboot.py) or through command line (picotool.py).
