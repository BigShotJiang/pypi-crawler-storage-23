"""muninndb — alias for muninn-python, the Python SDK for MuninnDB."""

__version__ = "0.2.5"
__description__ = "Python SDK for MuninnDB — the cognitive memory database (alias for muninn-python)"
