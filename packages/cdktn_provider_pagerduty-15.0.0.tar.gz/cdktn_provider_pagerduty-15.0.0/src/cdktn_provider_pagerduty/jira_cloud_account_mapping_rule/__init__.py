r'''
# `pagerduty_jira_cloud_account_mapping_rule`

Refer to the Terraform Registry for docs: [`pagerduty_jira_cloud_account_mapping_rule`](https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule).
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import cdktn as _cdktn_78ede62e
import constructs as _constructs_77d1e7e8


class JiraCloudAccountMappingRule(
    _cdktn_78ede62e.TerraformResource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRule",
):
    '''Represents a {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule pagerduty_jira_cloud_account_mapping_rule}.'''

    def __init__(
        self,
        scope: _constructs_77d1e7e8.Construct,
        id: builtins.str,
        *,
        account_mapping: builtins.str,
        name: builtins.str,
        config: typing.Optional[typing.Union["JiraCloudAccountMappingRuleConfigA", typing.Dict[builtins.str, typing.Any]]] = None,
        enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    ) -> None:
        '''Create a new {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule pagerduty_jira_cloud_account_mapping_rule} Resource.

        :param scope: The scope in which to define this construct.
        :param id: The scoped construct ID. Must be unique amongst siblings in the same scope
        :param account_mapping: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#account_mapping JiraCloudAccountMappingRule#account_mapping}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        :param config: config block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#config JiraCloudAccountMappingRule#config}
        :param enabled: Indicates if the rule is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#enabled JiraCloudAccountMappingRule#enabled}
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a159b2e1b43e3eddf3bb521d7d5585a9be4bac45d611803057faf978fe7b419b)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        config_ = JiraCloudAccountMappingRuleConfig(
            account_mapping=account_mapping,
            name=name,
            config=config,
            enabled=enabled,
            connection=connection,
            count=count,
            depends_on=depends_on,
            for_each=for_each,
            lifecycle=lifecycle,
            provider=provider,
            provisioners=provisioners,
        )

        jsii.create(self.__class__, self, [scope, id, config_])

    @jsii.member(jsii_name="generateConfigForImport")
    @builtins.classmethod
    def generate_config_for_import(
        cls,
        scope: _constructs_77d1e7e8.Construct,
        import_to_id: builtins.str,
        import_from_id: builtins.str,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    ) -> _cdktn_78ede62e.ImportableResource:
        '''Generates CDKTN code for importing a JiraCloudAccountMappingRule resource upon running "cdktn plan ".

        :param scope: The scope in which to define this construct.
        :param import_to_id: The construct id used in the generated config for the JiraCloudAccountMappingRule to import.
        :param import_from_id: The id of the existing JiraCloudAccountMappingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#import import section} in the documentation of this resource for the id to use
        :param provider: ? Optional instance of the provider where the JiraCloudAccountMappingRule to import is found.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2da7c53d389b1c589ff34c6bdc61c223627513c3a39fbe0b01f44e5097656172)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument import_to_id", value=import_to_id, expected_type=type_hints["import_to_id"])
            check_type(argname="argument import_from_id", value=import_from_id, expected_type=type_hints["import_from_id"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
        return typing.cast(_cdktn_78ede62e.ImportableResource, jsii.sinvoke(cls, "generateConfigForImport", [scope, import_to_id, import_from_id, provider]))

    @jsii.member(jsii_name="putConfig")
    def put_config(
        self,
        *,
        service: builtins.str,
        jira: typing.Optional[typing.Union["JiraCloudAccountMappingRuleConfigJira", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param service: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#service JiraCloudAccountMappingRule#service}.
        :param jira: jira block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#jira JiraCloudAccountMappingRule#jira}
        '''
        value = JiraCloudAccountMappingRuleConfigA(service=service, jira=jira)

        return typing.cast(None, jsii.invoke(self, "putConfig", [value]))

    @jsii.member(jsii_name="resetConfig")
    def reset_config(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetConfig", []))

    @jsii.member(jsii_name="resetEnabled")
    def reset_enabled(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetEnabled", []))

    @jsii.member(jsii_name="synthesizeAttributes")
    def _synthesize_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeAttributes", []))

    @jsii.member(jsii_name="synthesizeHclAttributes")
    def _synthesize_hcl_attributes(self) -> typing.Mapping[builtins.str, typing.Any]:
        return typing.cast(typing.Mapping[builtins.str, typing.Any], jsii.invoke(self, "synthesizeHclAttributes", []))

    @jsii.python.classproperty
    @jsii.member(jsii_name="tfResourceType")
    def TF_RESOURCE_TYPE(cls) -> builtins.str:
        return typing.cast(builtins.str, jsii.sget(cls, "tfResourceType"))

    @builtins.property
    @jsii.member(jsii_name="autocreateJqlDisabledReason")
    def autocreate_jql_disabled_reason(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "autocreateJqlDisabledReason"))

    @builtins.property
    @jsii.member(jsii_name="autocreateJqlDisabledUntil")
    def autocreate_jql_disabled_until(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "autocreateJqlDisabledUntil"))

    @builtins.property
    @jsii.member(jsii_name="config")
    def config(self) -> "JiraCloudAccountMappingRuleConfigAOutputReference":
        return typing.cast("JiraCloudAccountMappingRuleConfigAOutputReference", jsii.get(self, "config"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @builtins.property
    @jsii.member(jsii_name="accountMappingInput")
    def account_mapping_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "accountMappingInput"))

    @builtins.property
    @jsii.member(jsii_name="configInput")
    def config_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigA"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigA"]], jsii.get(self, "configInput"))

    @builtins.property
    @jsii.member(jsii_name="enabledInput")
    def enabled_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "enabledInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="accountMapping")
    def account_mapping(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "accountMapping"))

    @account_mapping.setter
    def account_mapping(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f06b0750aa086dd3088d4a0d9c86848b8e354e0a53c1aaa332456fd7bb91f7e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "accountMapping", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="enabled")
    def enabled(self) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "enabled"))

    @enabled.setter
    def enabled(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4fbf6d59fe26bd311cbbb3dc079a7e1d07b2a54237acdf7e698647b71744a4da)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "enabled", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d22784634076df8852b133a7cfc51342b9939e5b85af692b4dea44c45b08b324)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfig",
    jsii_struct_bases=[_cdktn_78ede62e.TerraformMetaArguments],
    name_mapping={
        "connection": "connection",
        "count": "count",
        "depends_on": "dependsOn",
        "for_each": "forEach",
        "lifecycle": "lifecycle",
        "provider": "provider",
        "provisioners": "provisioners",
        "account_mapping": "accountMapping",
        "name": "name",
        "config": "config",
        "enabled": "enabled",
    },
)
class JiraCloudAccountMappingRuleConfig(_cdktn_78ede62e.TerraformMetaArguments):
    def __init__(
        self,
        *,
        connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
        count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
        depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
        for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
        lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
        provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
        provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
        account_mapping: builtins.str,
        name: builtins.str,
        config: typing.Optional[typing.Union["JiraCloudAccountMappingRuleConfigA", typing.Dict[builtins.str, typing.Any]]] = None,
        enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    ) -> None:
        '''
        :param connection: 
        :param count: 
        :param depends_on: 
        :param for_each: 
        :param lifecycle: 
        :param provider: 
        :param provisioners: 
        :param account_mapping: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#account_mapping JiraCloudAccountMappingRule#account_mapping}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        :param config: config block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#config JiraCloudAccountMappingRule#config}
        :param enabled: Indicates if the rule is enabled. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#enabled JiraCloudAccountMappingRule#enabled}
        '''
        if isinstance(lifecycle, dict):
            lifecycle = _cdktn_78ede62e.TerraformResourceLifecycle(**lifecycle)
        if isinstance(config, dict):
            config = JiraCloudAccountMappingRuleConfigA(**config)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__af914e6d847853532368b4b983ff2e9f10a25d27846033287bd851b2a1664b78)
            check_type(argname="argument connection", value=connection, expected_type=type_hints["connection"])
            check_type(argname="argument count", value=count, expected_type=type_hints["count"])
            check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
            check_type(argname="argument for_each", value=for_each, expected_type=type_hints["for_each"])
            check_type(argname="argument lifecycle", value=lifecycle, expected_type=type_hints["lifecycle"])
            check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
            check_type(argname="argument provisioners", value=provisioners, expected_type=type_hints["provisioners"])
            check_type(argname="argument account_mapping", value=account_mapping, expected_type=type_hints["account_mapping"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument config", value=config, expected_type=type_hints["config"])
            check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "account_mapping": account_mapping,
            "name": name,
        }
        if connection is not None:
            self._values["connection"] = connection
        if count is not None:
            self._values["count"] = count
        if depends_on is not None:
            self._values["depends_on"] = depends_on
        if for_each is not None:
            self._values["for_each"] = for_each
        if lifecycle is not None:
            self._values["lifecycle"] = lifecycle
        if provider is not None:
            self._values["provider"] = provider
        if provisioners is not None:
            self._values["provisioners"] = provisioners
        if config is not None:
            self._values["config"] = config
        if enabled is not None:
            self._values["enabled"] = enabled

    @builtins.property
    def connection(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("connection")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, _cdktn_78ede62e.WinrmProvisionerConnection]], result)

    @builtins.property
    def count(
        self,
    ) -> typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("count")
        return typing.cast(typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]], result)

    @builtins.property
    def depends_on(
        self,
    ) -> typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("depends_on")
        return typing.cast(typing.Optional[typing.List[_cdktn_78ede62e.ITerraformDependable]], result)

    @builtins.property
    def for_each(self) -> typing.Optional[_cdktn_78ede62e.ITerraformIterator]:
        '''
        :stability: experimental
        '''
        result = self._values.get("for_each")
        return typing.cast(typing.Optional[_cdktn_78ede62e.ITerraformIterator], result)

    @builtins.property
    def lifecycle(self) -> typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle]:
        '''
        :stability: experimental
        '''
        result = self._values.get("lifecycle")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformResourceLifecycle], result)

    @builtins.property
    def provider(self) -> typing.Optional[_cdktn_78ede62e.TerraformProvider]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provider")
        return typing.cast(typing.Optional[_cdktn_78ede62e.TerraformProvider], result)

    @builtins.property
    def provisioners(
        self,
    ) -> typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]]:
        '''
        :stability: experimental
        '''
        result = self._values.get("provisioners")
        return typing.cast(typing.Optional[typing.List[typing.Union[_cdktn_78ede62e.FileProvisioner, _cdktn_78ede62e.LocalExecProvisioner, _cdktn_78ede62e.RemoteExecProvisioner]]], result)

    @builtins.property
    def account_mapping(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#account_mapping JiraCloudAccountMappingRule#account_mapping}.'''
        result = self._values.get("account_mapping")
        assert result is not None, "Required property 'account_mapping' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def config(self) -> typing.Optional["JiraCloudAccountMappingRuleConfigA"]:
        '''config block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#config JiraCloudAccountMappingRule#config}
        '''
        result = self._values.get("config")
        return typing.cast(typing.Optional["JiraCloudAccountMappingRuleConfigA"], result)

    @builtins.property
    def enabled(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Indicates if the rule is enabled.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#enabled JiraCloudAccountMappingRule#enabled}
        '''
        result = self._values.get("enabled")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfig(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigA",
    jsii_struct_bases=[],
    name_mapping={"service": "service", "jira": "jira"},
)
class JiraCloudAccountMappingRuleConfigA:
    def __init__(
        self,
        *,
        service: builtins.str,
        jira: typing.Optional[typing.Union["JiraCloudAccountMappingRuleConfigJira", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param service: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#service JiraCloudAccountMappingRule#service}.
        :param jira: jira block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#jira JiraCloudAccountMappingRule#jira}
        '''
        if isinstance(jira, dict):
            jira = JiraCloudAccountMappingRuleConfigJira(**jira)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4bfd3c2c76f94afb9611ed958d45449542c976f206e825e5e638c71bf7268627)
            check_type(argname="argument service", value=service, expected_type=type_hints["service"])
            check_type(argname="argument jira", value=jira, expected_type=type_hints["jira"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "service": service,
        }
        if jira is not None:
            self._values["jira"] = jira

    @builtins.property
    def service(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#service JiraCloudAccountMappingRule#service}.'''
        result = self._values.get("service")
        assert result is not None, "Required property 'service' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def jira(self) -> typing.Optional["JiraCloudAccountMappingRuleConfigJira"]:
        '''jira block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#jira JiraCloudAccountMappingRule#jira}
        '''
        result = self._values.get("jira")
        return typing.cast(typing.Optional["JiraCloudAccountMappingRuleConfigJira"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfigA(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class JiraCloudAccountMappingRuleConfigAOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigAOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c0e16d86fce29e95b7e973a2f905ffd813a77c336739df82dd6918b38aa335ab)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putJira")
    def put_jira(
        self,
        *,
        issue_type: typing.Union["JiraCloudAccountMappingRuleConfigJiraIssueType", typing.Dict[builtins.str, typing.Any]],
        project: typing.Union["JiraCloudAccountMappingRuleConfigJiraProject", typing.Dict[builtins.str, typing.Any]],
        autocreate_jql: typing.Optional[builtins.str] = None,
        create_issue_on_incident_trigger: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        custom_fields: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["JiraCloudAccountMappingRuleConfigJiraCustomFields", typing.Dict[builtins.str, typing.Any]]]]] = None,
        priorities: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["JiraCloudAccountMappingRuleConfigJiraPriorities", typing.Dict[builtins.str, typing.Any]]]]] = None,
        status_mapping: typing.Optional[typing.Union["JiraCloudAccountMappingRuleConfigJiraStatusMapping", typing.Dict[builtins.str, typing.Any]]] = None,
        sync_notes_user: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param issue_type: issue_type block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#issue_type JiraCloudAccountMappingRule#issue_type}
        :param project: project block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#project JiraCloudAccountMappingRule#project}
        :param autocreate_jql: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#autocreate_jql JiraCloudAccountMappingRule#autocreate_jql}.
        :param create_issue_on_incident_trigger: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#create_issue_on_incident_trigger JiraCloudAccountMappingRule#create_issue_on_incident_trigger}.
        :param custom_fields: custom_fields block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#custom_fields JiraCloudAccountMappingRule#custom_fields}
        :param priorities: priorities block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#priorities JiraCloudAccountMappingRule#priorities}
        :param status_mapping: status_mapping block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#status_mapping JiraCloudAccountMappingRule#status_mapping}
        :param sync_notes_user: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#sync_notes_user JiraCloudAccountMappingRule#sync_notes_user}.
        '''
        value = JiraCloudAccountMappingRuleConfigJira(
            issue_type=issue_type,
            project=project,
            autocreate_jql=autocreate_jql,
            create_issue_on_incident_trigger=create_issue_on_incident_trigger,
            custom_fields=custom_fields,
            priorities=priorities,
            status_mapping=status_mapping,
            sync_notes_user=sync_notes_user,
        )

        return typing.cast(None, jsii.invoke(self, "putJira", [value]))

    @jsii.member(jsii_name="resetJira")
    def reset_jira(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetJira", []))

    @builtins.property
    @jsii.member(jsii_name="jira")
    def jira(self) -> "JiraCloudAccountMappingRuleConfigJiraOutputReference":
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraOutputReference", jsii.get(self, "jira"))

    @builtins.property
    @jsii.member(jsii_name="jiraInput")
    def jira_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigJira"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigJira"]], jsii.get(self, "jiraInput"))

    @builtins.property
    @jsii.member(jsii_name="serviceInput")
    def service_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "serviceInput"))

    @builtins.property
    @jsii.member(jsii_name="service")
    def service(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "service"))

    @service.setter
    def service(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__10f70952c39be5c6fd56ad53caecf9aa7ec9c7f77d7721f65a37fad6efb01021)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "service", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigA]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigA]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigA]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8bd5019a836de5aa29c76f4f5f1ebd4c75b3284149dabd186c45d3c6e76602ae)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJira",
    jsii_struct_bases=[],
    name_mapping={
        "issue_type": "issueType",
        "project": "project",
        "autocreate_jql": "autocreateJql",
        "create_issue_on_incident_trigger": "createIssueOnIncidentTrigger",
        "custom_fields": "customFields",
        "priorities": "priorities",
        "status_mapping": "statusMapping",
        "sync_notes_user": "syncNotesUser",
    },
)
class JiraCloudAccountMappingRuleConfigJira:
    def __init__(
        self,
        *,
        issue_type: typing.Union["JiraCloudAccountMappingRuleConfigJiraIssueType", typing.Dict[builtins.str, typing.Any]],
        project: typing.Union["JiraCloudAccountMappingRuleConfigJiraProject", typing.Dict[builtins.str, typing.Any]],
        autocreate_jql: typing.Optional[builtins.str] = None,
        create_issue_on_incident_trigger: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
        custom_fields: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["JiraCloudAccountMappingRuleConfigJiraCustomFields", typing.Dict[builtins.str, typing.Any]]]]] = None,
        priorities: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["JiraCloudAccountMappingRuleConfigJiraPriorities", typing.Dict[builtins.str, typing.Any]]]]] = None,
        status_mapping: typing.Optional[typing.Union["JiraCloudAccountMappingRuleConfigJiraStatusMapping", typing.Dict[builtins.str, typing.Any]]] = None,
        sync_notes_user: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param issue_type: issue_type block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#issue_type JiraCloudAccountMappingRule#issue_type}
        :param project: project block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#project JiraCloudAccountMappingRule#project}
        :param autocreate_jql: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#autocreate_jql JiraCloudAccountMappingRule#autocreate_jql}.
        :param create_issue_on_incident_trigger: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#create_issue_on_incident_trigger JiraCloudAccountMappingRule#create_issue_on_incident_trigger}.
        :param custom_fields: custom_fields block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#custom_fields JiraCloudAccountMappingRule#custom_fields}
        :param priorities: priorities block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#priorities JiraCloudAccountMappingRule#priorities}
        :param status_mapping: status_mapping block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#status_mapping JiraCloudAccountMappingRule#status_mapping}
        :param sync_notes_user: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#sync_notes_user JiraCloudAccountMappingRule#sync_notes_user}.
        '''
        if isinstance(issue_type, dict):
            issue_type = JiraCloudAccountMappingRuleConfigJiraIssueType(**issue_type)
        if isinstance(project, dict):
            project = JiraCloudAccountMappingRuleConfigJiraProject(**project)
        if isinstance(status_mapping, dict):
            status_mapping = JiraCloudAccountMappingRuleConfigJiraStatusMapping(**status_mapping)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c541a47630133b29284a0702e140b6b78dcf8c2a540d34b8e30ec025238fc5d)
            check_type(argname="argument issue_type", value=issue_type, expected_type=type_hints["issue_type"])
            check_type(argname="argument project", value=project, expected_type=type_hints["project"])
            check_type(argname="argument autocreate_jql", value=autocreate_jql, expected_type=type_hints["autocreate_jql"])
            check_type(argname="argument create_issue_on_incident_trigger", value=create_issue_on_incident_trigger, expected_type=type_hints["create_issue_on_incident_trigger"])
            check_type(argname="argument custom_fields", value=custom_fields, expected_type=type_hints["custom_fields"])
            check_type(argname="argument priorities", value=priorities, expected_type=type_hints["priorities"])
            check_type(argname="argument status_mapping", value=status_mapping, expected_type=type_hints["status_mapping"])
            check_type(argname="argument sync_notes_user", value=sync_notes_user, expected_type=type_hints["sync_notes_user"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "issue_type": issue_type,
            "project": project,
        }
        if autocreate_jql is not None:
            self._values["autocreate_jql"] = autocreate_jql
        if create_issue_on_incident_trigger is not None:
            self._values["create_issue_on_incident_trigger"] = create_issue_on_incident_trigger
        if custom_fields is not None:
            self._values["custom_fields"] = custom_fields
        if priorities is not None:
            self._values["priorities"] = priorities
        if status_mapping is not None:
            self._values["status_mapping"] = status_mapping
        if sync_notes_user is not None:
            self._values["sync_notes_user"] = sync_notes_user

    @builtins.property
    def issue_type(self) -> "JiraCloudAccountMappingRuleConfigJiraIssueType":
        '''issue_type block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#issue_type JiraCloudAccountMappingRule#issue_type}
        '''
        result = self._values.get("issue_type")
        assert result is not None, "Required property 'issue_type' is missing"
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraIssueType", result)

    @builtins.property
    def project(self) -> "JiraCloudAccountMappingRuleConfigJiraProject":
        '''project block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#project JiraCloudAccountMappingRule#project}
        '''
        result = self._values.get("project")
        assert result is not None, "Required property 'project' is missing"
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraProject", result)

    @builtins.property
    def autocreate_jql(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#autocreate_jql JiraCloudAccountMappingRule#autocreate_jql}.'''
        result = self._values.get("autocreate_jql")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def create_issue_on_incident_trigger(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#create_issue_on_incident_trigger JiraCloudAccountMappingRule#create_issue_on_incident_trigger}.'''
        result = self._values.get("create_issue_on_incident_trigger")
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], result)

    @builtins.property
    def custom_fields(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["JiraCloudAccountMappingRuleConfigJiraCustomFields"]]]:
        '''custom_fields block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#custom_fields JiraCloudAccountMappingRule#custom_fields}
        '''
        result = self._values.get("custom_fields")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["JiraCloudAccountMappingRuleConfigJiraCustomFields"]]], result)

    @builtins.property
    def priorities(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["JiraCloudAccountMappingRuleConfigJiraPriorities"]]]:
        '''priorities block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#priorities JiraCloudAccountMappingRule#priorities}
        '''
        result = self._values.get("priorities")
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["JiraCloudAccountMappingRuleConfigJiraPriorities"]]], result)

    @builtins.property
    def status_mapping(
        self,
    ) -> typing.Optional["JiraCloudAccountMappingRuleConfigJiraStatusMapping"]:
        '''status_mapping block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#status_mapping JiraCloudAccountMappingRule#status_mapping}
        '''
        result = self._values.get("status_mapping")
        return typing.cast(typing.Optional["JiraCloudAccountMappingRuleConfigJiraStatusMapping"], result)

    @builtins.property
    def sync_notes_user(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#sync_notes_user JiraCloudAccountMappingRule#sync_notes_user}.'''
        result = self._values.get("sync_notes_user")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfigJira(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraCustomFields",
    jsii_struct_bases=[],
    name_mapping={
        "target_issue_field": "targetIssueField",
        "target_issue_field_name": "targetIssueFieldName",
        "type": "type",
        "source_incident_field": "sourceIncidentField",
        "value": "value",
    },
)
class JiraCloudAccountMappingRuleConfigJiraCustomFields:
    def __init__(
        self,
        *,
        target_issue_field: builtins.str,
        target_issue_field_name: builtins.str,
        type: builtins.str,
        source_incident_field: typing.Optional[builtins.str] = None,
        value: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param target_issue_field: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#target_issue_field JiraCloudAccountMappingRule#target_issue_field}.
        :param target_issue_field_name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#target_issue_field_name JiraCloudAccountMappingRule#target_issue_field_name}.
        :param type: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#type JiraCloudAccountMappingRule#type}.
        :param source_incident_field: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#source_incident_field JiraCloudAccountMappingRule#source_incident_field}.
        :param value: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#value JiraCloudAccountMappingRule#value}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__13dd69c0ec65f62578edec088d8e9b764e6e7cc84e4c1a3178714b1b87a2fa12)
            check_type(argname="argument target_issue_field", value=target_issue_field, expected_type=type_hints["target_issue_field"])
            check_type(argname="argument target_issue_field_name", value=target_issue_field_name, expected_type=type_hints["target_issue_field_name"])
            check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            check_type(argname="argument source_incident_field", value=source_incident_field, expected_type=type_hints["source_incident_field"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "target_issue_field": target_issue_field,
            "target_issue_field_name": target_issue_field_name,
            "type": type,
        }
        if source_incident_field is not None:
            self._values["source_incident_field"] = source_incident_field
        if value is not None:
            self._values["value"] = value

    @builtins.property
    def target_issue_field(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#target_issue_field JiraCloudAccountMappingRule#target_issue_field}.'''
        result = self._values.get("target_issue_field")
        assert result is not None, "Required property 'target_issue_field' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def target_issue_field_name(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#target_issue_field_name JiraCloudAccountMappingRule#target_issue_field_name}.'''
        result = self._values.get("target_issue_field_name")
        assert result is not None, "Required property 'target_issue_field_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def type(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#type JiraCloudAccountMappingRule#type}.'''
        result = self._values.get("type")
        assert result is not None, "Required property 'type' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def source_incident_field(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#source_incident_field JiraCloudAccountMappingRule#source_incident_field}.'''
        result = self._values.get("source_incident_field")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def value(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#value JiraCloudAccountMappingRule#value}.'''
        result = self._values.get("value")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfigJiraCustomFields(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class JiraCloudAccountMappingRuleConfigJiraCustomFieldsList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraCustomFieldsList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__59939727afc67d84af1bd66e890471074fae5ec364271ce21c29cd7d47979b38)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "JiraCloudAccountMappingRuleConfigJiraCustomFieldsOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f35ab790f72c92980c4d43b786d0caee0c91f2706af27876875cd7c20096aa07)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraCustomFieldsOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fe8ed48c9902c170ba65ba242d2ac14d70a4ac2c79c1496d904194ee0d4a8567)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__478e048173484caf7647faef019171407544a55125ec69560e109f6240be8232)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6aee2871bdb2059dd5dd41f629345b80472858e2ecb234a55a81d4901062dd6b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[JiraCloudAccountMappingRuleConfigJiraCustomFields]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[JiraCloudAccountMappingRuleConfigJiraCustomFields]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[JiraCloudAccountMappingRuleConfigJiraCustomFields]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8f6ea6d772612494801c361a4bc916a4cfb826e605282afa2e17fc393a8586c9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class JiraCloudAccountMappingRuleConfigJiraCustomFieldsOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraCustomFieldsOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c0ec3ad650701c89e79c924654ac5a75e62305a163cea19c613610cb44c8e67e)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @jsii.member(jsii_name="resetSourceIncidentField")
    def reset_source_incident_field(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSourceIncidentField", []))

    @jsii.member(jsii_name="resetValue")
    def reset_value(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetValue", []))

    @builtins.property
    @jsii.member(jsii_name="sourceIncidentFieldInput")
    def source_incident_field_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "sourceIncidentFieldInput"))

    @builtins.property
    @jsii.member(jsii_name="targetIssueFieldInput")
    def target_issue_field_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "targetIssueFieldInput"))

    @builtins.property
    @jsii.member(jsii_name="targetIssueFieldNameInput")
    def target_issue_field_name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "targetIssueFieldNameInput"))

    @builtins.property
    @jsii.member(jsii_name="typeInput")
    def type_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "typeInput"))

    @builtins.property
    @jsii.member(jsii_name="valueInput")
    def value_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "valueInput"))

    @builtins.property
    @jsii.member(jsii_name="sourceIncidentField")
    def source_incident_field(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "sourceIncidentField"))

    @source_incident_field.setter
    def source_incident_field(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__efc96e81b939f23789badbc2437c30c43714b2a88c48ebe4b74d7d75f9e596ba)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "sourceIncidentField", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="targetIssueField")
    def target_issue_field(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "targetIssueField"))

    @target_issue_field.setter
    def target_issue_field(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c6f2402839db8507bdecc322af002eb5764c5e28f98ac220ef4ef41250fecf1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "targetIssueField", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="targetIssueFieldName")
    def target_issue_field_name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "targetIssueFieldName"))

    @target_issue_field_name.setter
    def target_issue_field_name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3467ec4c2b4577fbf1ef5edb17a9dae4f323c6d3a55c6e5b93b635b553662341)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "targetIssueFieldName", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="type")
    def type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "type"))

    @type.setter
    def type(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__79514dbe5869141f3d7bcbc67a532cf8bae533655e5fa7893c8c917be8ad57ef)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "type", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="value")
    def value(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "value"))

    @value.setter
    def value(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d043ea6b3df33a47bc5dd2f5a834bc5cd9e937222d31325d82b8cd60848fef89)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "value", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraCustomFields]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraCustomFields]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraCustomFields]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__422568585a292c78516cba3677ccae33a2fe732cd02f7b57ab0c6dde7102ad5a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraIssueType",
    jsii_struct_bases=[],
    name_mapping={"id": "id", "name": "name"},
)
class JiraCloudAccountMappingRuleConfigJiraIssueType:
    def __init__(self, *, id: builtins.str, name: builtins.str) -> None:
        '''
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8a30f0711be2fc37a466be1d0d51a2b6c9ed7b507f834e2094869c35740db1ea)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "id": id,
            "name": name,
        }

    @builtins.property
    def id(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        assert result is not None, "Required property 'id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfigJiraIssueType(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class JiraCloudAccountMappingRuleConfigJiraIssueTypeOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraIssueTypeOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c7887e8db2d98016cccb4eee5ea8c718e243f0525cb71f08954732930973c0a6)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e1859708efcf8fa92d42cb81d996e3d6a3d4b9303e60843ce6a61ab2fd22268d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b345fe111ee36eb0c30ae3ab6cf5a3570a93353461a40a2562cf80249533599)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraIssueType]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraIssueType]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraIssueType]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ef2f05cc7f88541d2efd60af9a1f2f4c17f83d390dcfb45f2f9df1105e46994)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class JiraCloudAccountMappingRuleConfigJiraOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ded0f2948d63d451c63cdf3107a6534251b91aef2549ade83f6111c3714835b6)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putCustomFields")
    def put_custom_fields(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[JiraCloudAccountMappingRuleConfigJiraCustomFields, typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bc57be77b4533f174abd2234b62f2862f4de11d8e767d60005a60e95c845da3)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putCustomFields", [value]))

    @jsii.member(jsii_name="putIssueType")
    def put_issue_type(self, *, id: builtins.str, name: builtins.str) -> None:
        '''
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        '''
        value = JiraCloudAccountMappingRuleConfigJiraIssueType(id=id, name=name)

        return typing.cast(None, jsii.invoke(self, "putIssueType", [value]))

    @jsii.member(jsii_name="putPriorities")
    def put_priorities(
        self,
        value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union["JiraCloudAccountMappingRuleConfigJiraPriorities", typing.Dict[builtins.str, typing.Any]]]],
    ) -> None:
        '''
        :param value: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__23a6cb3420a881127cb7fe81bce27ae316e4ceb7dd5f1e41128c7d9c50d02be9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast(None, jsii.invoke(self, "putPriorities", [value]))

    @jsii.member(jsii_name="putProject")
    def put_project(
        self,
        *,
        id: builtins.str,
        key: builtins.str,
        name: builtins.str,
    ) -> None:
        '''
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param key: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#key JiraCloudAccountMappingRule#key}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        '''
        value = JiraCloudAccountMappingRuleConfigJiraProject(id=id, key=key, name=name)

        return typing.cast(None, jsii.invoke(self, "putProject", [value]))

    @jsii.member(jsii_name="putStatusMapping")
    def put_status_mapping(
        self,
        *,
        triggered: typing.Union["JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered", typing.Dict[builtins.str, typing.Any]],
        acknowledged: typing.Optional[typing.Union["JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged", typing.Dict[builtins.str, typing.Any]]] = None,
        resolved: typing.Optional[typing.Union["JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param triggered: triggered block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#triggered JiraCloudAccountMappingRule#triggered}
        :param acknowledged: acknowledged block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#acknowledged JiraCloudAccountMappingRule#acknowledged}
        :param resolved: resolved block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#resolved JiraCloudAccountMappingRule#resolved}
        '''
        value = JiraCloudAccountMappingRuleConfigJiraStatusMapping(
            triggered=triggered, acknowledged=acknowledged, resolved=resolved
        )

        return typing.cast(None, jsii.invoke(self, "putStatusMapping", [value]))

    @jsii.member(jsii_name="resetAutocreateJql")
    def reset_autocreate_jql(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAutocreateJql", []))

    @jsii.member(jsii_name="resetCreateIssueOnIncidentTrigger")
    def reset_create_issue_on_incident_trigger(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCreateIssueOnIncidentTrigger", []))

    @jsii.member(jsii_name="resetCustomFields")
    def reset_custom_fields(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetCustomFields", []))

    @jsii.member(jsii_name="resetPriorities")
    def reset_priorities(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetPriorities", []))

    @jsii.member(jsii_name="resetStatusMapping")
    def reset_status_mapping(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetStatusMapping", []))

    @jsii.member(jsii_name="resetSyncNotesUser")
    def reset_sync_notes_user(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetSyncNotesUser", []))

    @builtins.property
    @jsii.member(jsii_name="customFields")
    def custom_fields(self) -> JiraCloudAccountMappingRuleConfigJiraCustomFieldsList:
        return typing.cast(JiraCloudAccountMappingRuleConfigJiraCustomFieldsList, jsii.get(self, "customFields"))

    @builtins.property
    @jsii.member(jsii_name="issueType")
    def issue_type(
        self,
    ) -> JiraCloudAccountMappingRuleConfigJiraIssueTypeOutputReference:
        return typing.cast(JiraCloudAccountMappingRuleConfigJiraIssueTypeOutputReference, jsii.get(self, "issueType"))

    @builtins.property
    @jsii.member(jsii_name="priorities")
    def priorities(self) -> "JiraCloudAccountMappingRuleConfigJiraPrioritiesList":
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraPrioritiesList", jsii.get(self, "priorities"))

    @builtins.property
    @jsii.member(jsii_name="project")
    def project(self) -> "JiraCloudAccountMappingRuleConfigJiraProjectOutputReference":
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraProjectOutputReference", jsii.get(self, "project"))

    @builtins.property
    @jsii.member(jsii_name="statusMapping")
    def status_mapping(
        self,
    ) -> "JiraCloudAccountMappingRuleConfigJiraStatusMappingOutputReference":
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraStatusMappingOutputReference", jsii.get(self, "statusMapping"))

    @builtins.property
    @jsii.member(jsii_name="autocreateJqlInput")
    def autocreate_jql_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "autocreateJqlInput"))

    @builtins.property
    @jsii.member(jsii_name="createIssueOnIncidentTriggerInput")
    def create_issue_on_incident_trigger_input(
        self,
    ) -> typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]]:
        return typing.cast(typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]], jsii.get(self, "createIssueOnIncidentTriggerInput"))

    @builtins.property
    @jsii.member(jsii_name="customFieldsInput")
    def custom_fields_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[JiraCloudAccountMappingRuleConfigJiraCustomFields]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[JiraCloudAccountMappingRuleConfigJiraCustomFields]]], jsii.get(self, "customFieldsInput"))

    @builtins.property
    @jsii.member(jsii_name="issueTypeInput")
    def issue_type_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraIssueType]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraIssueType]], jsii.get(self, "issueTypeInput"))

    @builtins.property
    @jsii.member(jsii_name="prioritiesInput")
    def priorities_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["JiraCloudAccountMappingRuleConfigJiraPriorities"]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List["JiraCloudAccountMappingRuleConfigJiraPriorities"]]], jsii.get(self, "prioritiesInput"))

    @builtins.property
    @jsii.member(jsii_name="projectInput")
    def project_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigJiraProject"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigJiraProject"]], jsii.get(self, "projectInput"))

    @builtins.property
    @jsii.member(jsii_name="statusMappingInput")
    def status_mapping_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigJiraStatusMapping"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigJiraStatusMapping"]], jsii.get(self, "statusMappingInput"))

    @builtins.property
    @jsii.member(jsii_name="syncNotesUserInput")
    def sync_notes_user_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "syncNotesUserInput"))

    @builtins.property
    @jsii.member(jsii_name="autocreateJql")
    def autocreate_jql(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "autocreateJql"))

    @autocreate_jql.setter
    def autocreate_jql(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce7d0ab298705c5bec741fcca67138985c19b52a26a2208b007886e6f65853a5)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autocreateJql", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="createIssueOnIncidentTrigger")
    def create_issue_on_incident_trigger(
        self,
    ) -> typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]:
        return typing.cast(typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable], jsii.get(self, "createIssueOnIncidentTrigger"))

    @create_issue_on_incident_trigger.setter
    def create_issue_on_incident_trigger(
        self,
        value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__774c609d3387895cad99b4abee8386d638897a3e37baa5c33a83c87a21371f87)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "createIssueOnIncidentTrigger", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="syncNotesUser")
    def sync_notes_user(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "syncNotesUser"))

    @sync_notes_user.setter
    def sync_notes_user(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a48bafdad78306a11e663a2cb972923d943bc90a509cf3c14efab49c8b08d64e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "syncNotesUser", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJira]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJira]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJira]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__00f44df6617edd541205673447ec8bff828fac77cb1ebf37425db21a89f01e43)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraPriorities",
    jsii_struct_bases=[],
    name_mapping={"jira_id": "jiraId", "pagerduty_id": "pagerdutyId"},
)
class JiraCloudAccountMappingRuleConfigJiraPriorities:
    def __init__(self, *, jira_id: builtins.str, pagerduty_id: builtins.str) -> None:
        '''
        :param jira_id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#jira_id JiraCloudAccountMappingRule#jira_id}.
        :param pagerduty_id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#pagerduty_id JiraCloudAccountMappingRule#pagerduty_id}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a90106c9a59e6bfeff1da0325adcb62773f4a1feae8defaa14ba032a73ec5949)
            check_type(argname="argument jira_id", value=jira_id, expected_type=type_hints["jira_id"])
            check_type(argname="argument pagerduty_id", value=pagerduty_id, expected_type=type_hints["pagerduty_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "jira_id": jira_id,
            "pagerduty_id": pagerduty_id,
        }

    @builtins.property
    def jira_id(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#jira_id JiraCloudAccountMappingRule#jira_id}.'''
        result = self._values.get("jira_id")
        assert result is not None, "Required property 'jira_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def pagerduty_id(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#pagerduty_id JiraCloudAccountMappingRule#pagerduty_id}.'''
        result = self._values.get("pagerduty_id")
        assert result is not None, "Required property 'pagerduty_id' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfigJiraPriorities(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class JiraCloudAccountMappingRuleConfigJiraPrioritiesList(
    _cdktn_78ede62e.ComplexList,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraPrioritiesList",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        wraps_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param wraps_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ef8261eeeb5cdee5da5b09ad7100b00418c1ba125793e58c782dcad7a636421d)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument wraps_set", value=wraps_set, expected_type=type_hints["wraps_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, wraps_set])

    @jsii.member(jsii_name="get")
    def get(
        self,
        index: jsii.Number,
    ) -> "JiraCloudAccountMappingRuleConfigJiraPrioritiesOutputReference":
        '''
        :param index: the index of the item to return.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95892762b46275dfba5fec6d2123fb5bebb42b36fcde9be639426e06d6df1679)
            check_type(argname="argument index", value=index, expected_type=type_hints["index"])
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraPrioritiesOutputReference", jsii.invoke(self, "get", [index]))

    @builtins.property
    @jsii.member(jsii_name="terraformAttribute")
    def _terraform_attribute(self) -> builtins.str:
        '''The attribute on the parent resource this class is referencing.'''
        return typing.cast(builtins.str, jsii.get(self, "terraformAttribute"))

    @_terraform_attribute.setter
    def _terraform_attribute(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd172b3fa75de8f3c76e0bb797fafa7d75dd2c289859d08fbb1f9a9bdd40f022)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformAttribute", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="terraformResource")
    def _terraform_resource(self) -> _cdktn_78ede62e.IInterpolatingParent:
        '''The parent resource.'''
        return typing.cast(_cdktn_78ede62e.IInterpolatingParent, jsii.get(self, "terraformResource"))

    @_terraform_resource.setter
    def _terraform_resource(self, value: _cdktn_78ede62e.IInterpolatingParent) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a41299fb6078dce648e05170efe5d422641797f8c275e84006917ccfe97573be)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "terraformResource", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="wrapsSet")
    def _wraps_set(self) -> builtins.bool:
        '''whether the list is wrapping a set (will add tolist() to be able to access an item via an index).'''
        return typing.cast(builtins.bool, jsii.get(self, "wrapsSet"))

    @_wraps_set.setter
    def _wraps_set(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__46c7787219a333ef2114335078074278e76ec27a026748545ed80b17f52650a4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "wrapsSet", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[JiraCloudAccountMappingRuleConfigJiraPriorities]]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[JiraCloudAccountMappingRuleConfigJiraPriorities]]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[JiraCloudAccountMappingRuleConfigJiraPriorities]]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b7ab89e5a004604987c8698109fc1f0ea7aa5d5a5b9ad6984090ba71f325e1b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class JiraCloudAccountMappingRuleConfigJiraPrioritiesOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraPrioritiesOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
        complex_object_index: jsii.Number,
        complex_object_is_from_set: builtins.bool,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        :param complex_object_index: the index of this item in the list.
        :param complex_object_is_from_set: whether the list is wrapping a set (will add tolist() to be able to access an item via an index).
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__15e58bf02f25afb8dd2f22658f26e71d5e1fbbf18129eace3c8f1c503a626ff8)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
            check_type(argname="argument complex_object_index", value=complex_object_index, expected_type=type_hints["complex_object_index"])
            check_type(argname="argument complex_object_is_from_set", value=complex_object_is_from_set, expected_type=type_hints["complex_object_is_from_set"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute, complex_object_index, complex_object_is_from_set])

    @builtins.property
    @jsii.member(jsii_name="jiraIdInput")
    def jira_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "jiraIdInput"))

    @builtins.property
    @jsii.member(jsii_name="pagerdutyIdInput")
    def pagerduty_id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "pagerdutyIdInput"))

    @builtins.property
    @jsii.member(jsii_name="jiraId")
    def jira_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "jiraId"))

    @jira_id.setter
    def jira_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92959383ec24afa8f7fbaa7e88c339af5c499edf218e1989a4b3b22fa976bf2d)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "jiraId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="pagerdutyId")
    def pagerduty_id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "pagerdutyId"))

    @pagerduty_id.setter
    def pagerduty_id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3839913d8106477d373ed040b12d2ce9bd3d022240ee2266ca7bb66f75f8d511)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "pagerdutyId", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraPriorities]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraPriorities]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraPriorities]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__84fd7cb42a3a7acd209a94abaf07b13f7371088d6560cd48c32049375ccb29a9)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraProject",
    jsii_struct_bases=[],
    name_mapping={"id": "id", "key": "key", "name": "name"},
)
class JiraCloudAccountMappingRuleConfigJiraProject:
    def __init__(
        self,
        *,
        id: builtins.str,
        key: builtins.str,
        name: builtins.str,
    ) -> None:
        '''
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param key: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#key JiraCloudAccountMappingRule#key}.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce4efb6002e7e0a335a9bdd5081216fd62bb57b9377ed61877b95d6cc2f5d04d)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "id": id,
            "key": key,
            "name": name,
        }

    @builtins.property
    def id(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        assert result is not None, "Required property 'id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def key(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#key JiraCloudAccountMappingRule#key}.'''
        result = self._values.get("key")
        assert result is not None, "Required property 'key' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfigJiraProject(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class JiraCloudAccountMappingRuleConfigJiraProjectOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraProjectOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__31779cf1ff44c3f752d39cc729f29dec084f1c53c48c3c2ac8455f83b4f6a393)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="keyInput")
    def key_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "keyInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a28bc8b167f570ca954971d9962e2c9be34fbc758ffe366401402b90dcee3e46)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="key")
    def key(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "key"))

    @key.setter
    def key(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a0013492199ac764ecc772f308b26a8b254e46c9b32dfa6dcf02e24772afaead)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "key", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6663f2d7b9844f1371bc4541ac343665d17fcd6e1e9c50c439eec4e396e1f784)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraProject]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraProject]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraProject]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2c9e2d5b4ca3ad010fa0d94f2469f003d01a613f0fae3c486f67901d29ea1da6)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraStatusMapping",
    jsii_struct_bases=[],
    name_mapping={
        "triggered": "triggered",
        "acknowledged": "acknowledged",
        "resolved": "resolved",
    },
)
class JiraCloudAccountMappingRuleConfigJiraStatusMapping:
    def __init__(
        self,
        *,
        triggered: typing.Union["JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered", typing.Dict[builtins.str, typing.Any]],
        acknowledged: typing.Optional[typing.Union["JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged", typing.Dict[builtins.str, typing.Any]]] = None,
        resolved: typing.Optional[typing.Union["JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''
        :param triggered: triggered block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#triggered JiraCloudAccountMappingRule#triggered}
        :param acknowledged: acknowledged block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#acknowledged JiraCloudAccountMappingRule#acknowledged}
        :param resolved: resolved block. Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#resolved JiraCloudAccountMappingRule#resolved}
        '''
        if isinstance(triggered, dict):
            triggered = JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered(**triggered)
        if isinstance(acknowledged, dict):
            acknowledged = JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged(**acknowledged)
        if isinstance(resolved, dict):
            resolved = JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved(**resolved)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a495ccd53e558a74a917a66203fa01631be7e31e36772bc7bbebc0970d72abb)
            check_type(argname="argument triggered", value=triggered, expected_type=type_hints["triggered"])
            check_type(argname="argument acknowledged", value=acknowledged, expected_type=type_hints["acknowledged"])
            check_type(argname="argument resolved", value=resolved, expected_type=type_hints["resolved"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "triggered": triggered,
        }
        if acknowledged is not None:
            self._values["acknowledged"] = acknowledged
        if resolved is not None:
            self._values["resolved"] = resolved

    @builtins.property
    def triggered(
        self,
    ) -> "JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered":
        '''triggered block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#triggered JiraCloudAccountMappingRule#triggered}
        '''
        result = self._values.get("triggered")
        assert result is not None, "Required property 'triggered' is missing"
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered", result)

    @builtins.property
    def acknowledged(
        self,
    ) -> typing.Optional["JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged"]:
        '''acknowledged block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#acknowledged JiraCloudAccountMappingRule#acknowledged}
        '''
        result = self._values.get("acknowledged")
        return typing.cast(typing.Optional["JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged"], result)

    @builtins.property
    def resolved(
        self,
    ) -> typing.Optional["JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved"]:
        '''resolved block.

        Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#resolved JiraCloudAccountMappingRule#resolved}
        '''
        result = self._values.get("resolved")
        return typing.cast(typing.Optional["JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfigJiraStatusMapping(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged",
    jsii_struct_bases=[],
    name_mapping={"id": "id", "name": "name"},
)
class JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged:
    def __init__(
        self,
        *,
        id: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c78654192f816889a46d98abbe426abd3c54142a0e4a3f7755538eee85db5c8a)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if id is not None:
            self._values["id"] = id
        if name is not None:
            self._values["name"] = name

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledgedOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledgedOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e140ef39f0e708a3e9b581359dd7fb79fe8d75822f46acf21f6d171d0d64bac)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__afec302cfae1ab9e1a930dabaab5f622bfcf929984785e0fcbb8c5892651d99c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37b2666ddbc190c35d0980d140c9b3579a04f6b09307bbe4fbc981deb53bee25)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__832863ebae2beff5baf7e3d45e4fce2be95c8d565ec9a065d535e9a25ad86468)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


class JiraCloudAccountMappingRuleConfigJiraStatusMappingOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraStatusMappingOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d2b8ca28fabbcddb2b256288195c55aa4be78f5a977161f1e15247bb47bf7337)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="putAcknowledged")
    def put_acknowledged(
        self,
        *,
        id: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        '''
        value = JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged(
            id=id, name=name
        )

        return typing.cast(None, jsii.invoke(self, "putAcknowledged", [value]))

    @jsii.member(jsii_name="putResolved")
    def put_resolved(
        self,
        *,
        id: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        '''
        value = JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved(
            id=id, name=name
        )

        return typing.cast(None, jsii.invoke(self, "putResolved", [value]))

    @jsii.member(jsii_name="putTriggered")
    def put_triggered(self, *, id: builtins.str, name: builtins.str) -> None:
        '''
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        '''
        value = JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered(
            id=id, name=name
        )

        return typing.cast(None, jsii.invoke(self, "putTriggered", [value]))

    @jsii.member(jsii_name="resetAcknowledged")
    def reset_acknowledged(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetAcknowledged", []))

    @jsii.member(jsii_name="resetResolved")
    def reset_resolved(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetResolved", []))

    @builtins.property
    @jsii.member(jsii_name="acknowledged")
    def acknowledged(
        self,
    ) -> JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledgedOutputReference:
        return typing.cast(JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledgedOutputReference, jsii.get(self, "acknowledged"))

    @builtins.property
    @jsii.member(jsii_name="resolved")
    def resolved(
        self,
    ) -> "JiraCloudAccountMappingRuleConfigJiraStatusMappingResolvedOutputReference":
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraStatusMappingResolvedOutputReference", jsii.get(self, "resolved"))

    @builtins.property
    @jsii.member(jsii_name="triggered")
    def triggered(
        self,
    ) -> "JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggeredOutputReference":
        return typing.cast("JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggeredOutputReference", jsii.get(self, "triggered"))

    @builtins.property
    @jsii.member(jsii_name="acknowledgedInput")
    def acknowledged_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged]], jsii.get(self, "acknowledgedInput"))

    @builtins.property
    @jsii.member(jsii_name="resolvedInput")
    def resolved_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved"]], jsii.get(self, "resolvedInput"))

    @builtins.property
    @jsii.member(jsii_name="triggeredInput")
    def triggered_input(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered"]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, "JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered"]], jsii.get(self, "triggeredInput"))

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMapping]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMapping]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMapping]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb867f771c661effa20e02b17e733a4340ba3906bdce79c896b2f7e42b30397e)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved",
    jsii_struct_bases=[],
    name_mapping={"id": "id", "name": "name"},
)
class JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved:
    def __init__(
        self,
        *,
        id: typing.Optional[builtins.str] = None,
        name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37be253621b68eb18f98bab9783c9997a1b4f397394a7aa510485c2c42c7940c)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if id is not None:
            self._values["id"] = id
        if name is not None:
            self._values["name"] = name

    @builtins.property
    def id(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.'''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class JiraCloudAccountMappingRuleConfigJiraStatusMappingResolvedOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraStatusMappingResolvedOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a8eafc14f28566926a775fb0af4d16c0a40a2ce1aca399b518852ba7618dc43)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @jsii.member(jsii_name="resetId")
    def reset_id(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetId", []))

    @jsii.member(jsii_name="resetName")
    def reset_name(self) -> None:
        return typing.cast(None, jsii.invoke(self, "resetName", []))

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2649e405bb5b1bc663af8ee2bc064a3dbf680e129c49690de2a35d8496cd0574)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__69da2ce08d288fa2e86239511c60d546020182e4eabb68f95b691f6854107c15)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3825881e5dd0b881497c4c11803d896c1617d55fb4a70abd480ea4daa3fcfa01)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered",
    jsii_struct_bases=[],
    name_mapping={"id": "id", "name": "name"},
)
class JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered:
    def __init__(self, *, id: builtins.str, name: builtins.str) -> None:
        '''
        :param id: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}. Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2. If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        :param name: Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c5c3113a17d352e325c0a497554357cf3c31ad57571f0d1bd44cfdc28aa2c846)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "id": id,
            "name": name,
        }

    @builtins.property
    def id(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#id JiraCloudAccountMappingRule#id}.

        Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        '''
        result = self._values.get("id")
        assert result is not None, "Required property 'id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def name(self) -> builtins.str:
        '''Docs at Terraform Registry: {@link https://registry.terraform.io/providers/pagerduty/pagerduty/3.31.0/docs/resources/jira_cloud_account_mapping_rule#name JiraCloudAccountMappingRule#name}.'''
        result = self._values.get("name")
        assert result is not None, "Required property 'name' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggeredOutputReference(
    _cdktn_78ede62e.ComplexObject,
    metaclass=jsii.JSIIMeta,
    jsii_type="@cdktn/provider-pagerduty.jiraCloudAccountMappingRule.JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggeredOutputReference",
):
    def __init__(
        self,
        terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
        terraform_attribute: builtins.str,
    ) -> None:
        '''
        :param terraform_resource: The parent resource.
        :param terraform_attribute: The attribute on the parent resource this class is referencing.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c51544961b85e7d95cade0195f3c796cc02ae6c9c4a3e5f537d33427b6e1467)
            check_type(argname="argument terraform_resource", value=terraform_resource, expected_type=type_hints["terraform_resource"])
            check_type(argname="argument terraform_attribute", value=terraform_attribute, expected_type=type_hints["terraform_attribute"])
        jsii.create(self.__class__, self, [terraform_resource, terraform_attribute])

    @builtins.property
    @jsii.member(jsii_name="idInput")
    def id_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "idInput"))

    @builtins.property
    @jsii.member(jsii_name="nameInput")
    def name_input(self) -> typing.Optional[builtins.str]:
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "nameInput"))

    @builtins.property
    @jsii.member(jsii_name="id")
    def id(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "id"))

    @id.setter
    def id(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb8d9be99861bc7520ff40a5f1fe55c4a85c7c6edd636d5ac11d6d4e78f48746)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "id", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="name")
    def name(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "name"))

    @name.setter
    def name(self, value: builtins.str) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__51a83e1b70f6454b10df6f36290b07f9d4ef75c3835136dbded3e6e015fbf099)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "name", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="internalValue")
    def internal_value(
        self,
    ) -> typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered]]:
        return typing.cast(typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered]], jsii.get(self, "internalValue"))

    @internal_value.setter
    def internal_value(
        self,
        value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered]],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__72c4f9394e1702029ee46e3125966e25940a9b46ff500f2d20e373888de827e0)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "internalValue", value) # pyright: ignore[reportArgumentType]


__all__ = [
    "JiraCloudAccountMappingRule",
    "JiraCloudAccountMappingRuleConfig",
    "JiraCloudAccountMappingRuleConfigA",
    "JiraCloudAccountMappingRuleConfigAOutputReference",
    "JiraCloudAccountMappingRuleConfigJira",
    "JiraCloudAccountMappingRuleConfigJiraCustomFields",
    "JiraCloudAccountMappingRuleConfigJiraCustomFieldsList",
    "JiraCloudAccountMappingRuleConfigJiraCustomFieldsOutputReference",
    "JiraCloudAccountMappingRuleConfigJiraIssueType",
    "JiraCloudAccountMappingRuleConfigJiraIssueTypeOutputReference",
    "JiraCloudAccountMappingRuleConfigJiraOutputReference",
    "JiraCloudAccountMappingRuleConfigJiraPriorities",
    "JiraCloudAccountMappingRuleConfigJiraPrioritiesList",
    "JiraCloudAccountMappingRuleConfigJiraPrioritiesOutputReference",
    "JiraCloudAccountMappingRuleConfigJiraProject",
    "JiraCloudAccountMappingRuleConfigJiraProjectOutputReference",
    "JiraCloudAccountMappingRuleConfigJiraStatusMapping",
    "JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged",
    "JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledgedOutputReference",
    "JiraCloudAccountMappingRuleConfigJiraStatusMappingOutputReference",
    "JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved",
    "JiraCloudAccountMappingRuleConfigJiraStatusMappingResolvedOutputReference",
    "JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered",
    "JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggeredOutputReference",
]

publication.publish()

def _typecheckingstub__a159b2e1b43e3eddf3bb521d7d5585a9be4bac45d611803057faf978fe7b419b(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    account_mapping: builtins.str,
    name: builtins.str,
    config: typing.Optional[typing.Union[JiraCloudAccountMappingRuleConfigA, typing.Dict[builtins.str, typing.Any]]] = None,
    enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2da7c53d389b1c589ff34c6bdc61c223627513c3a39fbe0b01f44e5097656172(
    scope: _constructs_77d1e7e8.Construct,
    import_to_id: builtins.str,
    import_from_id: builtins.str,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f06b0750aa086dd3088d4a0d9c86848b8e354e0a53c1aaa332456fd7bb91f7e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4fbf6d59fe26bd311cbbb3dc079a7e1d07b2a54237acdf7e698647b71744a4da(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d22784634076df8852b133a7cfc51342b9939e5b85af692b4dea44c45b08b324(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__af914e6d847853532368b4b983ff2e9f10a25d27846033287bd851b2a1664b78(
    *,
    connection: typing.Optional[typing.Union[typing.Union[_cdktn_78ede62e.SSHProvisionerConnection, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.WinrmProvisionerConnection, typing.Dict[builtins.str, typing.Any]]]] = None,
    count: typing.Optional[typing.Union[jsii.Number, _cdktn_78ede62e.TerraformCount]] = None,
    depends_on: typing.Optional[typing.Sequence[_cdktn_78ede62e.ITerraformDependable]] = None,
    for_each: typing.Optional[_cdktn_78ede62e.ITerraformIterator] = None,
    lifecycle: typing.Optional[typing.Union[_cdktn_78ede62e.TerraformResourceLifecycle, typing.Dict[builtins.str, typing.Any]]] = None,
    provider: typing.Optional[_cdktn_78ede62e.TerraformProvider] = None,
    provisioners: typing.Optional[typing.Sequence[typing.Union[typing.Union[_cdktn_78ede62e.FileProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.LocalExecProvisioner, typing.Dict[builtins.str, typing.Any]], typing.Union[_cdktn_78ede62e.RemoteExecProvisioner, typing.Dict[builtins.str, typing.Any]]]]] = None,
    account_mapping: builtins.str,
    name: builtins.str,
    config: typing.Optional[typing.Union[JiraCloudAccountMappingRuleConfigA, typing.Dict[builtins.str, typing.Any]]] = None,
    enabled: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4bfd3c2c76f94afb9611ed958d45449542c976f206e825e5e638c71bf7268627(
    *,
    service: builtins.str,
    jira: typing.Optional[typing.Union[JiraCloudAccountMappingRuleConfigJira, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c0e16d86fce29e95b7e973a2f905ffd813a77c336739df82dd6918b38aa335ab(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__10f70952c39be5c6fd56ad53caecf9aa7ec9c7f77d7721f65a37fad6efb01021(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8bd5019a836de5aa29c76f4f5f1ebd4c75b3284149dabd186c45d3c6e76602ae(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigA]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c541a47630133b29284a0702e140b6b78dcf8c2a540d34b8e30ec025238fc5d(
    *,
    issue_type: typing.Union[JiraCloudAccountMappingRuleConfigJiraIssueType, typing.Dict[builtins.str, typing.Any]],
    project: typing.Union[JiraCloudAccountMappingRuleConfigJiraProject, typing.Dict[builtins.str, typing.Any]],
    autocreate_jql: typing.Optional[builtins.str] = None,
    create_issue_on_incident_trigger: typing.Optional[typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable]] = None,
    custom_fields: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[JiraCloudAccountMappingRuleConfigJiraCustomFields, typing.Dict[builtins.str, typing.Any]]]]] = None,
    priorities: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[JiraCloudAccountMappingRuleConfigJiraPriorities, typing.Dict[builtins.str, typing.Any]]]]] = None,
    status_mapping: typing.Optional[typing.Union[JiraCloudAccountMappingRuleConfigJiraStatusMapping, typing.Dict[builtins.str, typing.Any]]] = None,
    sync_notes_user: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__13dd69c0ec65f62578edec088d8e9b764e6e7cc84e4c1a3178714b1b87a2fa12(
    *,
    target_issue_field: builtins.str,
    target_issue_field_name: builtins.str,
    type: builtins.str,
    source_incident_field: typing.Optional[builtins.str] = None,
    value: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__59939727afc67d84af1bd66e890471074fae5ec364271ce21c29cd7d47979b38(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f35ab790f72c92980c4d43b786d0caee0c91f2706af27876875cd7c20096aa07(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fe8ed48c9902c170ba65ba242d2ac14d70a4ac2c79c1496d904194ee0d4a8567(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__478e048173484caf7647faef019171407544a55125ec69560e109f6240be8232(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6aee2871bdb2059dd5dd41f629345b80472858e2ecb234a55a81d4901062dd6b(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8f6ea6d772612494801c361a4bc916a4cfb826e605282afa2e17fc393a8586c9(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[JiraCloudAccountMappingRuleConfigJiraCustomFields]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c0ec3ad650701c89e79c924654ac5a75e62305a163cea19c613610cb44c8e67e(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__efc96e81b939f23789badbc2437c30c43714b2a88c48ebe4b74d7d75f9e596ba(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c6f2402839db8507bdecc322af002eb5764c5e28f98ac220ef4ef41250fecf1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3467ec4c2b4577fbf1ef5edb17a9dae4f323c6d3a55c6e5b93b635b553662341(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__79514dbe5869141f3d7bcbc67a532cf8bae533655e5fa7893c8c917be8ad57ef(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d043ea6b3df33a47bc5dd2f5a834bc5cd9e937222d31325d82b8cd60848fef89(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__422568585a292c78516cba3677ccae33a2fe732cd02f7b57ab0c6dde7102ad5a(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraCustomFields]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a30f0711be2fc37a466be1d0d51a2b6c9ed7b507f834e2094869c35740db1ea(
    *,
    id: builtins.str,
    name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c7887e8db2d98016cccb4eee5ea8c718e243f0525cb71f08954732930973c0a6(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e1859708efcf8fa92d42cb81d996e3d6a3d4b9303e60843ce6a61ab2fd22268d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b345fe111ee36eb0c30ae3ab6cf5a3570a93353461a40a2562cf80249533599(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ef2f05cc7f88541d2efd60af9a1f2f4c17f83d390dcfb45f2f9df1105e46994(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraIssueType]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ded0f2948d63d451c63cdf3107a6534251b91aef2549ade83f6111c3714835b6(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bc57be77b4533f174abd2234b62f2862f4de11d8e767d60005a60e95c845da3(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[JiraCloudAccountMappingRuleConfigJiraCustomFields, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__23a6cb3420a881127cb7fe81bce27ae316e4ceb7dd5f1e41128c7d9c50d02be9(
    value: typing.Union[_cdktn_78ede62e.IResolvable, typing.Sequence[typing.Union[JiraCloudAccountMappingRuleConfigJiraPriorities, typing.Dict[builtins.str, typing.Any]]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce7d0ab298705c5bec741fcca67138985c19b52a26a2208b007886e6f65853a5(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__774c609d3387895cad99b4abee8386d638897a3e37baa5c33a83c87a21371f87(
    value: typing.Union[builtins.bool, _cdktn_78ede62e.IResolvable],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a48bafdad78306a11e663a2cb972923d943bc90a509cf3c14efab49c8b08d64e(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__00f44df6617edd541205673447ec8bff828fac77cb1ebf37425db21a89f01e43(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJira]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a90106c9a59e6bfeff1da0325adcb62773f4a1feae8defaa14ba032a73ec5949(
    *,
    jira_id: builtins.str,
    pagerduty_id: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ef8261eeeb5cdee5da5b09ad7100b00418c1ba125793e58c782dcad7a636421d(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    wraps_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95892762b46275dfba5fec6d2123fb5bebb42b36fcde9be639426e06d6df1679(
    index: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd172b3fa75de8f3c76e0bb797fafa7d75dd2c289859d08fbb1f9a9bdd40f022(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a41299fb6078dce648e05170efe5d422641797f8c275e84006917ccfe97573be(
    value: _cdktn_78ede62e.IInterpolatingParent,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__46c7787219a333ef2114335078074278e76ec27a026748545ed80b17f52650a4(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b7ab89e5a004604987c8698109fc1f0ea7aa5d5a5b9ad6984090ba71f325e1b(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, typing.List[JiraCloudAccountMappingRuleConfigJiraPriorities]]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__15e58bf02f25afb8dd2f22658f26e71d5e1fbbf18129eace3c8f1c503a626ff8(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
    complex_object_index: jsii.Number,
    complex_object_is_from_set: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92959383ec24afa8f7fbaa7e88c339af5c499edf218e1989a4b3b22fa976bf2d(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3839913d8106477d373ed040b12d2ce9bd3d022240ee2266ca7bb66f75f8d511(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__84fd7cb42a3a7acd209a94abaf07b13f7371088d6560cd48c32049375ccb29a9(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraPriorities]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce4efb6002e7e0a335a9bdd5081216fd62bb57b9377ed61877b95d6cc2f5d04d(
    *,
    id: builtins.str,
    key: builtins.str,
    name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__31779cf1ff44c3f752d39cc729f29dec084f1c53c48c3c2ac8455f83b4f6a393(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a28bc8b167f570ca954971d9962e2c9be34fbc758ffe366401402b90dcee3e46(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a0013492199ac764ecc772f308b26a8b254e46c9b32dfa6dcf02e24772afaead(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6663f2d7b9844f1371bc4541ac343665d17fcd6e1e9c50c439eec4e396e1f784(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2c9e2d5b4ca3ad010fa0d94f2469f003d01a613f0fae3c486f67901d29ea1da6(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraProject]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a495ccd53e558a74a917a66203fa01631be7e31e36772bc7bbebc0970d72abb(
    *,
    triggered: typing.Union[JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered, typing.Dict[builtins.str, typing.Any]],
    acknowledged: typing.Optional[typing.Union[JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged, typing.Dict[builtins.str, typing.Any]]] = None,
    resolved: typing.Optional[typing.Union[JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c78654192f816889a46d98abbe426abd3c54142a0e4a3f7755538eee85db5c8a(
    *,
    id: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e140ef39f0e708a3e9b581359dd7fb79fe8d75822f46acf21f6d171d0d64bac(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__afec302cfae1ab9e1a930dabaab5f622bfcf929984785e0fcbb8c5892651d99c(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37b2666ddbc190c35d0980d140c9b3579a04f6b09307bbe4fbc981deb53bee25(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__832863ebae2beff5baf7e3d45e4fce2be95c8d565ec9a065d535e9a25ad86468(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingAcknowledged]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d2b8ca28fabbcddb2b256288195c55aa4be78f5a977161f1e15247bb47bf7337(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb867f771c661effa20e02b17e733a4340ba3906bdce79c896b2f7e42b30397e(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMapping]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37be253621b68eb18f98bab9783c9997a1b4f397394a7aa510485c2c42c7940c(
    *,
    id: typing.Optional[builtins.str] = None,
    name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a8eafc14f28566926a775fb0af4d16c0a40a2ce1aca399b518852ba7618dc43(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2649e405bb5b1bc663af8ee2bc064a3dbf680e129c49690de2a35d8496cd0574(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__69da2ce08d288fa2e86239511c60d546020182e4eabb68f95b691f6854107c15(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3825881e5dd0b881497c4c11803d896c1617d55fb4a70abd480ea4daa3fcfa01(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingResolved]],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c5c3113a17d352e325c0a497554357cf3c31ad57571f0d1bd44cfdc28aa2c846(
    *,
    id: builtins.str,
    name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c51544961b85e7d95cade0195f3c796cc02ae6c9c4a3e5f537d33427b6e1467(
    terraform_resource: _cdktn_78ede62e.IInterpolatingParent,
    terraform_attribute: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb8d9be99861bc7520ff40a5f1fe55c4a85c7c6edd636d5ac11d6d4e78f48746(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51a83e1b70f6454b10df6f36290b07f9d4ef75c3835136dbded3e6e015fbf099(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72c4f9394e1702029ee46e3125966e25940a9b46ff500f2d20e373888de827e0(
    value: typing.Optional[typing.Union[_cdktn_78ede62e.IResolvable, JiraCloudAccountMappingRuleConfigJiraStatusMappingTriggered]],
) -> None:
    """Type checking stubs"""
    pass
