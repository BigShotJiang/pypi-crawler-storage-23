# PG Airman MCP

**A Postgres MCP server with index tuning, explain plans, health checks, and safe sql execution.**

**[Overview](#overview)** • **[Quick Start](#quick-start)** • **[Configuration Reference](#configuration-reference)** • **[Technical Notes](#technical-notes)** • **[MCP API](#mcp-server-api)** • **[FAQ](#frequently-asked-questions)**

## Overview

**Pg Airman MCP** is an open source Model Context Protocol (MCP) server built to support you and your AI agents throughout the **entire development process**—from initial coding, through testing and deployment, and to production tuning and maintenance.

Pg Airman MCP does much more than wrap a database connection.

Features include:

- **🔍 Database Health** - analyze index health, connection utilization, buffer cache, vacuum health, sequence limits, replication lag, and more.
- **⚡ Index Tuning** - explore thousands of possible indexes to find the best solution for your workload, using industrial-strength algorithms.
- **📈 Query Plans** - validate and optimize performance by reviewing EXPLAIN plans and simulating the impact of hypothetical indexes.
- **🧠 Schema Intelligence** - context-aware SQL generation based on detailed understanding of the database schema.
- **🛡️ Safe SQL Execution** - configurable access control, including support for read-only mode and safe SQL parsing, making it usable for both development and production.
- **🔐 OAuth 2.0 Authentication** - optional token-based authentication using RFC 7662 introspection, protecting all MCP tools with bearer tokens validated against an external authorization server.

Pg Airman MCP supports the following MCP transports for flexibility in different environments:

- [Standard Input/Output (stdio)](https://modelcontextprotocol.io/docs/concepts/transports#standard-input%2Foutput-stdio)
- [Server-Sent Events (SSE)](https://modelcontextprotocol.io/docs/concepts/transports#server-sent-events-sse)
- [Streamable HTTP](https://modelcontextprotocol.io/specification/2025-06-18/basic/transports#streamable-http)

## Quick Start

### Prerequisites

Before getting started, ensure you have:

1. Access credentials for your database.
2. Docker *or* Python 3.12 or higher.

#### Access Credentials

You can confirm your access credentials are valid by using `psql` or a GUI tool such as [pgAdmin](https://www.pgadmin.org/).

#### Docker or Python

The choice to use Docker or Python is yours.
We generally recommend Docker because Python users can encounter more environment-specific issues.
However, it often makes sense to use whichever method you are most familiar with.

### Installation

Choose one of the following methods to install Pg Airman MCP:

#### Option 1: Using Docker

Pull the Pg Airman MCP server Docker image.
This image contains all necessary dependencies, providing a reliable way to run Pg Airman MCP in a variety of environments.

```bash
docker pull enterprisedb/pg-airman-mcp
```

#### Option 2: Using Python

If you have `pipx` installed you can install Pg Airman MCP with:

```bash
pipx install pg-airman-mcp
```

Otherwise, install Pg Airman MCP with `uv`:

```bash
uv pip install pg-airman-mcp
```

If you need to install `uv`, see the [uv installation instructions](https://docs.astral.sh/uv/getting-started/installation/).

> **IMPORTANT:** Pg Airman MCP requires **Python 3.12+** and the [`psycopg`](https://www.psycopg.org/) package for database connectivity.  
> If you install with Docker, all dependencies are included — no extra setup is needed.
>
> If you install with Python (`pipx` or `uv`), you may need:
>
> - A C compiler (e.g., `gcc`, `clang`)
> - PostgreSQL client libraries and headers (e.g., `libpq-dev` on Debian/Ubuntu)
> - Python development headers (e.g., `python3.12-dev` on Debian/Ubuntu)
> - The `pg_config` utility in your system `PATH`
>
> If you see errors about missing `libpq` or `pg_config`, install the relevant packages for your OS.  
> See the [psycopg installation docs](https://www.psycopg.org/psycopg3/docs/basic/install.html#install-pre) for details.

### Configure Your AI Assistant

We provide full instructions for configuring Pg Airman MCP with Claude Desktop.
Many MCP clients have similar configuration files, you can adapt these steps to work with the client of your choice.

#### Claude Desktop Configuration

You will need to edit the Claude Desktop configuration file to add Pg Airman MCP.
The location of this file depends on your operating system:

- MacOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%/Claude/claude_desktop_config.json`

You can also use `Settings` menu item in Claude Desktop to locate the configuration file.

You will now edit the `mcpServers` section of the configuration file.

##### If you are using Docker

```json
{
  "mcpServers": {
    "postgres": {
      "command": "docker",
      "args": [
        "run",
        "-i",
        "--rm",
        "-e",
        "AIRMAN_MCP_DATABASE_URL",
        "enterprisedb/pg-airman-mcp",
        "--access-mode=unrestricted"
      ],
      "env": {
        "AIRMAN_MCP_DATABASE_URL": "postgresql://username:password@localhost:5432/dbname"
      }
    }
  }
}
```

The Pg Airman MCP Docker image will automatically remap the hostname `localhost` to work from inside of the container.

- MacOS/Windows: Uses `host.docker.internal` automatically
- Linux: Uses `172.17.0.1` or the appropriate host address automatically

##### If you are using `pipx`

```json
{
  "mcpServers": {
    "postgres": {
      "command": "pg-airman-mcp",
      "args": [
        "--access-mode=unrestricted"
      ],
      "env": {
        "AIRMAN_MCP_DATABASE_URL": "postgresql://username:password@localhost:5432/dbname"
      }
    }
  }
}
```

##### If you are using `uv`

```json
{
  "mcpServers": {
    "postgres": {
      "command": "uv",
      "args": [
        "run",
        "pg-airman-mcp",
        "--access-mode=unrestricted"
      ],
      "env": {
        "AIRMAN_MCP_DATABASE_URL": "postgresql://username:password@localhost:5432/dbname"
      }
    }
  }
}
```

> **Note:** The examples above show basic configuration without authentication. To enable OAuth 2.0 authentication, see [Authentication](#authentication-optional) for Claude Desktop configuration examples with auth enabled.

##### Connection URI

Replace `postgresql://...` with your [Postgres database connection URI](https://www.postgresql.org/docs/current/libpq-connect.html#LIBPQ-CONNSTRING-URIS).

##### Access Mode

Pg Airman MCP supports multiple *access modes* to give you control over the operations that the AI agent can perform on the database:

- **Unrestricted Mode**: Allows full read/write access to modify data and schema. It is suitable for development environments.
- **Restricted Mode**: Limits operations to read-only transactions and imposes constraints on resource utilization (presently only execution time). It is suitable for production environments.

To use restricted mode, replace `--access-mode=unrestricted` with `--access-mode=restricted` in the configuration examples above.

### Safe Metadata Writes (Allowlist)

In restricted mode the server enforces read-only execution for regular queries via `SafeSqlDriver`. Some lightweight metadata operations can be explicitly allowed through a controlled **safe metadata allowlist**. Currently only `COMMENT ON` statements are supported via the `add_comment_to_object` tool.

The behavior is controlled by the environment variable:

```bash
ALLOW_COMMENT_IN_RESTRICTED=true   # default: true
```

Set this variable to `false` to block comment writes when running with `--access-mode=restricted`.

Rationale:

- Keeps the semantics of restricted mode mostly read-only while permitting non-destructive documentation changes.
- Prevents ad-hoc unwrapping of the safe driver throughout the codebase—metadata writes route through a single helper (`execute_comment_on`).
- Provides a clear extension point for future safe metadata operations if needed.

When a comment is written in restricted mode the server logs:

```text
COMMENT ON <KIND> <qualified_identifier> length=<N> in restricted mode
```

If disabled you will receive an error: `COMMENT ON is not permitted in restricted mode`.

#### Other MCP Clients

Many MCP clients have similar configuration files to Claude Desktop, and you can adapt the examples above to work with the client of your choice.

- If you are using Cursor, you can navigate from the `Command Palette` to `Cursor Settings`, then open the `MCP` tab to access the configuration file.
- If you are using Windsurf, you can navigate from the `Command Palette` to `Open Windsurf Settings Page` to access the configuration file.
- If you are using Goose run `goose configure`, then select `Add Extension`.

## SSE Transport

Pg Airman MCP supports the [SSE transport](https://modelcontextprotocol.io/docs/concepts/transports#server-sent-events-sse), which allows multiple MCP clients to share one server, possibly a remote server.
To use the SSE transport, you need to start the Pg Airman MCP server with the `--transport=sse` option.

For example, with Docker run:

```bash
docker run -p 8000:8000 \
  -e AIRMAN_MCP_DATABASE_URL=postgresql://username:password@localhost:5432/dbname \
  enterprisedb/pg-airman-mcp --access-mode=unrestricted --transport=sse
```

Then update your MCP client configuration to call the Pg Airman MCP server.
For example, in Cursor's `mcp.json` or Cline's `cline_mcp_settings.json` you can put:

```json
{
    "mcpServers": {
        "postgres": {
            "type": "sse",
            "url": "http://localhost:8000/sse"
        }
    }
}
```

For Windsurf, the format in `mcp_config.json` is slightly different:

```json
{
    "mcpServers": {
        "postgres": {
            "type": "sse",
            "serverUrl": "http://localhost:8000/sse"
        }
    }
}
```

## Streamable HTTP Transport

Pg Airman MCP supports the [Streamable HTTP transport](https://modelcontextprotocol.io/specification/2025-06-18/basic/transports#streamable-http), which allows multiple MCP clients to share one server, possibly a remote server.
To use the Streamable HTTP transport, you need to start the server with the `--transport=streamable-http` option.

For example, with Docker run:

```bash
docker run -p 8000:8000 \
  -e AIRMAN_MCP_DATABASE_URL=postgresql://username:password@localhost:5432/dbname \
  enterprisedb/pg-airman-mcp --access-mode=unrestricted --transport=streamable-http
```

Then update your MCP client configuration to call the MCP server.
For example, in Cursor's `mcp.json` you can put:

```json
{
    "mcpServers": {
        "pg-airman": {
            "url": "http://localhost:8000/mcp"
        }
    }
}
```

For Windsurf, the format in `mcp_config.json` is slightly different:

```json
{
    "mcpServers": {
        "postgres": {
            "serverUrl": "http://localhost:8000/mcp"
        }
    }
}
```

## DNS Rebinding Protection

When using SSE or Streamable HTTP transports, the MCP SDK includes [DNS rebinding protection](https://github.com/modelcontextprotocol/python-sdk/issues/1798) that validates incoming `Host` headers against an allowlist.
This can cause **HTTP 421 Misdirected Request** errors when the server runs behind a reverse proxy, load balancer, or Kubernetes service where the `Host` header differs from `localhost`.

By default, DNS rebinding protection is **disabled** to avoid breaking deployments behind proxies or Kubernetes services.
You can enable and configure it explicitly using environment variables or CLI arguments.

### Enabling Protection

To enable protection with the SDK's built-in localhost allowlist:

```bash
AIRMAN_MCP_DNS_REBINDING_PROTECTION=true
```

Or via CLI:

```bash
pg-airman-mcp "postgresql://..." --transport=streamable-http --dns-rebinding-protection
```

### Custom Host Allowlist

To enable protection with a specific allowlist (setting `allowed_hosts` automatically enables protection):

```bash
AIRMAN_MCP_ALLOWED_HOSTS="pg-airman-mcp-service:*,localhost:*"
AIRMAN_MCP_ALLOWED_ORIGINS="http://pg-airman-mcp-service:*,http://localhost:*"
```

Wildcard port patterns (e.g., `myservice:*`) match any port on that host.

## Authentication (Optional)

Pg Airman MCP supports OAuth 2.0 authentication to protect all MCP tools with bearer tokens.
When enabled, every request must include a valid access token, which the MCP server validates by calling an authorization server's [token introspection endpoint (RFC 7662)](https://datatracker.ietf.org/doc/html/rfc7662).

Authentication is disabled by default.
When disabled, the server operates exactly as before with no authentication overhead.

### How It Works

1. An MCP client obtains an access token from the authorization server (e.g., `pg-airman-auth`).
2. The client includes the token in requests to the MCP server via the `Authorization: Bearer {token}` header.
3. The MCP server sends the token to the authorization server's introspection endpoint.
4. If the token is active and valid, the request proceeds; otherwise, a `401 Unauthorized` response is returned.

### Enabling Authentication

Set the following environment variables:

```bash
AIRMAN_MCP_AUTH_ENABLED=true
AIRMAN_MCP_AUTH_SERVER_URL=http://localhost:9000
```

Or use CLI arguments:

```bash
pg-airman-mcp "postgresql://..." --auth-enabled --auth-server-url http://localhost:9000
```

### Claude Desktop Configuration with Authentication

#### Docker with Authentication

```json
{
  "mcpServers": {
    "postgres": {
      "command": "docker",
      "args": [
        "run",
        "-i",
        "--rm",
        "-e",
        "AIRMAN_MCP_DATABASE_URL",
        "-e",
        "AIRMAN_MCP_AUTH_ENABLED",
        "-e",
        "AIRMAN_MCP_AUTH_SERVER_URL",
        "enterprisedb/pg-airman-mcp",
        "--access-mode=unrestricted"
      ],
      "env": {
        "AIRMAN_MCP_DATABASE_URL": "postgresql://username:password@localhost:5432/dbname",
        "AIRMAN_MCP_AUTH_ENABLED": "true",
        "AIRMAN_MCP_AUTH_SERVER_URL": "http://host.docker.internal:9000"
      }
    }
  }
}
```

> **Note:** Use `host.docker.internal` (MacOS/Windows) or `172.17.0.1` (Linux) to reach an authorization server running on the host.

#### If you are using `pipx` or `uv`

When using the `stdio` transport with authentication, you must set `AIRMAN_MCP_SERVER_URL` because the stdio transport does not have a natural HTTP endpoint, but the OAuth flow needs a server URL for resource validation.

```json
{
  "mcpServers": {
    "postgres": {
      "command": "pg-airman-mcp",
      "args": [
        "--access-mode=unrestricted",
        "--auth-enabled",
        "--auth-server-url", "http://localhost:9000"
      ],
      "env": {
        "AIRMAN_MCP_DATABASE_URL": "postgresql://username:password@localhost:5432/dbname",
        "AIRMAN_MCP_SERVER_URL": "http://localhost:8000"
      }
    }
  }
}
```

### Authentication with SSE or Streamable HTTP

When using network transports, enable authentication via environment variables or CLI arguments:

```bash
docker run -p 8000:8000 \
  -e AIRMAN_MCP_DATABASE_URL=postgresql://username:password@localhost:5432/dbname \
  -e AIRMAN_MCP_AUTH_ENABLED=true \
  -e AIRMAN_MCP_AUTH_SERVER_URL=http://auth-server:9000 \
  enterprisedb/pg-airman-mcp --access-mode=unrestricted --transport=sse
```

The server URL is auto-detected from the host and port configuration for SSE and Streamable HTTP transports.

### Authentication Environment Variables

| Variable | Description | Default |
| -------- | ----------- | ------- |
| `AIRMAN_MCP_AUTH_ENABLED` | Enable OAuth authentication | `false` |
| `AIRMAN_MCP_AUTH_SERVER_URL` | Authorization server base URL | `http://localhost:9000` |
| `AIRMAN_MCP_AUTH_INTROSPECTION_ENDPOINT` | Token introspection endpoint URL | `{auth-server-url}/introspect` |
| `AIRMAN_MCP_AUTH_REQUIRED_SCOPES` | Comma-separated required OAuth scopes | `mcp:postgres:access` |
| `AIRMAN_MCP_AUTH_VALIDATE_RESOURCE` | Enable RFC 8707 resource validation | `false` |
| `AIRMAN_MCP_AUTH_INTROSPECTION_CLIENT_ID` | Client ID for introspection endpoint auth | *(none)* |
| `AIRMAN_MCP_AUTH_INTROSPECTION_CLIENT_SECRET` | Client secret for introspection endpoint auth | *(none)* |
| `AIRMAN_MCP_SERVER_URL` | This server's URL (required for stdio with auth) | *(auto-detected for SSE/HTTP)* |

### Security Features

- **SSRF prevention**: The introspection endpoint URL is validated to only allow `https://` URLs or `localhost`.
- **SSL verification**: TLS certificate verification is enforced for all introspection requests.
- **RFC 8707 resource validation**: Optionally validates that the token's resource claim matches the MCP server URL.
- **Scope validation**: Requires tokens to have the configured scopes (default: `mcp:postgres:access`).

## Postgres Extension Installation (Optional)

To enable index tuning and comprehensive performance analysis you need to load the `pg_stat_statements` and `hypopg` extensions on your database.

- The `pg_stat_statements` extension allows Pg Airman MCP to analyze query execution statistics.
For example, this allows it to understand which queries are running slow or consuming significant resources.
- The `hypopg` extension allows Pg Airman MCP to simulate the behavior of the Postgres query planner after adding indexes.

### Installing extensions on AWS RDS, Azure SQL, or Google Cloud SQL

If your Postgres database is running on a cloud provider managed service, the `pg_stat_statements` and `hypopg` extensions should already be available on the system.
In this case, you can just run `CREATE EXTENSION` commands using a role with sufficient privileges:

```sql
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
CREATE EXTENSION IF NOT EXISTS hypopg;
```

### Installing extensions on self-managed Postgres

If you are managing your own Postgres installation, you may need to do additional work.
Before loading the `pg_stat_statements` extension you must ensure that it is listed in the `shared_preload_libraries` in the Postgres configuration file.
The `hypopg` extension may also require additional system-level installation (e.g., via your package manager) because it does not always ship with Postgres.

## Usage Examples

### Get Database Health Overview

Ask:
> Check the health of my database and identify any issues.

### Analyze Slow Queries

Ask:
> What are the slowest queries in my database? And how can I speed them up?

### Get Recommendations On How To Speed Things Up

Ask:
> My app is slow. How can I make it faster?

### Generate Index Recommendations

Ask:
> Analyze my database workload and suggest indexes to improve performance.

### Optimize a Specific Query

Ask:
> Help me optimize this query: SELECT \* FROM orders JOIN customers ON orders.customer_id = customers.id WHERE orders.created_at > '2023-01-01';

## MCP Server API

The [MCP standard](https://modelcontextprotocol.io/) defines various types of endpoints: Tools, Resources, Prompts, and others.

Pg Airman MCP provides functionality via [MCP tools](https://modelcontextprotocol.io/docs/concepts/tools) alone.
We chose this approach because the [MCP client ecosystem](https://modelcontextprotocol.io/clients) has widespread support for MCP tools.
This contrasts with the approach of other Postgres MCP servers, including the [Reference Postgres MCP Server](https://github.com/modelcontextprotocol/servers/tree/main/src/postgres), which use [MCP resources](https://modelcontextprotocol.io/docs/concepts/resources) to expose schema information.

Pg Airman MCP Tools:

| Tool Name | Description |
|-----------|-------------|
| `list_schemas` | Lists all database schemas available in the PostgreSQL instance. |
| `list_objects` | Lists database objects (tables, views, sequences, extensions) within a specified schema. |
| `get_object_details` | Provides information about a specific database object, for example, a table's columns, constraints, and indexes. |
| `execute_sql` | Executes SQL statements on the database, with read-only limitations when connected in restricted mode. |
| `explain_query` | Gets the execution plan for a SQL query describing how PostgreSQL will process it and exposing the query planner's cost model. Can be invoked with hypothetical indexes to simulate the behavior after adding indexes. |
| `get_top_queries` | Reports the slowest SQL queries based on total execution time using `pg_stat_statements` data. |
| `analyze_workload_indexes` | Analyzes the database workload to identify resource-intensive queries, then recommends optimal indexes for them. |
| `analyze_query_indexes` | Analyzes a list of specific SQL queries (up to 10) and recommends optimal indexes for them. |
| `analyze_db_health` | Performs comprehensive health checks including: buffer cache hit rates, connection health, constraint validation, index health (duplicate/unused/invalid), sequence limits, and vacuum health. |
| `add_comment_to_object` | Adds a comment to a table, view, or column (allowed in restricted mode only if `ALLOW_COMMENT_IN_RESTRICTED=true`). |

## Frequently Asked Questions

*How is Pg Airman MCP different from other Postgres MCP servers?*
There are many MCP servers that allow an AI agent to run queries against a Postgres database.
Pg Airman MCP does that too, but also adds tools for understanding and improving the performance of your Postgres database.
For example, it implements a version of the [Anytime Algorithm of Database Tuning Advisor for Microsoft SQL Server](https://www.microsoft.com/en-us/research/wp-content/uploads/2020/06/Anytime-Algorithm-of-Database-Tuning-Advisor-for-Microsoft-SQL-Server.pdf), a modern industrial-strength algorithm for automatic index tuning.

Pg Airman MCP complements generative AI by adding deterministic tools and classical optimization algorithms.
The combination is both reliable and flexible.

*Why are MCP tools needed when the LLM can reason, generate SQL, etc?*
LLMs are invaluable for tasks that involve ambiguity, reasoning, or natural language.
When compared to procedural code, however, they can be slow, expensive, non-deterministic, and sometimes produce unreliable results.
In the case of database tuning, we have well established algorithms, developed over decades, that are proven to work.
Pg Airman MCP lets you combine the best of both worlds by pairing LLMs with classical optimization algorithms and other procedural tools.

*How do you test Pg Airman MCP?*
Testing is critical to ensuring that Pg Airman MCP is reliable and accurate.
We are building out a suite of AI-generated adversarial workloads designed to challenge Pg Airman MCP and ensure it performs under a broad variety of scenarios.

*What Postgres versions are supported?*
Our testing presently focuses on Postgres 15, 16, 17, and 18.
We plan to support Postgres versions 14 through 18.

*Who created this project?*
This project was created by [Crystal DBA](https://www.crystaldba.ai).
We evaluated a number of MCP servers for Postgres and found this project
from Crystal DBA to be excellent. We’ve been using it internally and it’s
been stable and useful. We were sad to see the original team move onto other
pursuits, so we’ve forked the project and will continue to add features.

## Roadmap

*TBD*

You and your needs are a critical driver for what we build.
Tell us what you want to see by opening an [issue](https://github.com/EnterpriseDB/pg-airman-mcp/) or a [pull request](https://github.com/EnterpriseDB/pg-airman-mcp/pulls).

## Configuration Reference

All settings follow a three-tier priority: CLI arguments > environment variables > defaults.
Environment variables use the `AIRMAN_MCP_` prefix.

### Server Settings

| Variable | CLI Argument | Description | Default |
| -------- | ------------ | ----------- | ------- |
| `AIRMAN_MCP_DATABASE_URL` | `database_url` (positional) | PostgreSQL connection URL | *(required)* |
| `AIRMAN_MCP_ACCESS_MODE` | `--access-mode` | SQL access mode: `unrestricted` or `restricted` | `unrestricted` |
| `AIRMAN_MCP_TRANSPORT` | `--transport` | MCP transport: `stdio`, `sse`, or `streamable-http` | `stdio` |
| `AIRMAN_MCP_SSE_HOST` | `--sse-host` | SSE server host | `localhost` |
| `AIRMAN_MCP_SSE_PORT` | `--sse-port` | SSE server port | `8000` |
| `AIRMAN_MCP_STREAMABLE_HTTP_HOST` | `--streamable-http-host` | Streamable HTTP server host | `localhost` |
| `AIRMAN_MCP_STREAMABLE_HTTP_PORT` | `--streamable-http-port` | Streamable HTTP server port | `8001` |
| `AIRMAN_MCP_DNS_REBINDING_PROTECTION` | `--dns-rebinding-protection` | Enable DNS rebinding protection | `false` |
| `AIRMAN_MCP_ALLOWED_HOSTS` | `--allowed-hosts` | Comma-separated allowed Host header values | *(empty)* |
| `AIRMAN_MCP_ALLOWED_ORIGINS` | `--allowed-origins` | Comma-separated allowed Origin header values | *(empty)* |

### Authentication Settings

| Variable | CLI Argument | Description | Default |
| -------- | ------------ | ----------- | ------- |
| `AIRMAN_MCP_AUTH_ENABLED` | `--auth-enabled` | Enable OAuth authentication | `false` |
| `AIRMAN_MCP_AUTH_SERVER_URL` | `--auth-server-url` | Authorization server base URL | `http://localhost:9000` |
| `AIRMAN_MCP_AUTH_INTROSPECTION_ENDPOINT` | `--auth-introspection-endpoint` | Token introspection endpoint URL | `{auth-server-url}/introspect` |
| `AIRMAN_MCP_AUTH_REQUIRED_SCOPES` | `--auth-required-scopes` | Comma-separated required OAuth scopes | `mcp:postgres:access` |
| `AIRMAN_MCP_AUTH_VALIDATE_RESOURCE` | `--auth-validate-resource` | Enable RFC 8707 resource validation | `false` |
| `AIRMAN_MCP_AUTH_INTROSPECTION_CLIENT_ID` | `--auth-introspection-client-id` | Client ID for introspection endpoint auth | *(none)* |
| `AIRMAN_MCP_AUTH_INTROSPECTION_CLIENT_SECRET` | `--auth-introspection-client-secret` | Client secret for introspection endpoint auth | *(none)* |
| `AIRMAN_MCP_SERVER_URL` | *(env only)* | This server's URL (required for stdio with auth) | *(auto-detected for SSE/HTTP)* |

### Other Settings

| Variable | Description | Default |
| -------- | ----------- | ------- |
| `ALLOW_COMMENT_IN_RESTRICTED` | Allow `COMMENT ON` writes in restricted mode | `true` |
| `OPENAI_API_KEY` | OpenAI API key for experimental LLM-based index tuning | *(none)* |

## Technical Notes

This section includes a high-level overview of technical considerations that influenced the design of Pg Airman MCP.

### Index Tuning

Developers know that missing indexes are one of the most common causes of database performance issues.
Indexes provide access methods that allow Postgres to quickly locate data that is required to execute a query.
When tables are small, indexes make little difference, but as the size of the data grows, the difference in algorithmic complexity between a table scan and an index lookup becomes significant (typically *O*(*n*) vs *O*(*log* *n*), potentially more if joins on multiple tables are involved).

Generating suggested indexes in Pg Airman MCP proceeds in several stages:

1. *Identify SQL queries in need of tuning*.
    If you know you are having problems with a specific SQL query you can provide it.
    Pg Airman MCP can also analyze the workload to identify index tuning targets.
    To do this, it relies on the `pg_stat_statements` extension, which records the runtime and resource consumption of each query.

    A query is a candidate for index tuning if it is a top resource consumer, either on a per-execution basis or an aggregate.
    At present, we use execution time as a proxy for cumulative resource consumption, but it may also make sense to look at specific resources, e.g., the number of blocks accessed or the number of blocks read from disk.
    The `analyze_query_workload` tool focuses on slow queries, using the mean time per execution with thresholds for execution count and mean execution time.
    Agents may also call `get_top_queries`, which accepts a parameter for mean vs. total execution time, then passes these queries to `analyze_query_indexes` to get index recommendations.

    Sophisticated index tuning systems use "workload compression" to produce a representative subset of queries that reflects the characteristics of the workload as a whole, reducing the problem for downstream algorithms.
    Pg Airman MCP performs a limited form of workload compression by normalizing queries so that those generated from the same template appear as one.
    It weights each query equally, a simplification that works when the benefits to indexing are large.

2. *Generate candidate indexes*
    Once we have a list of SQL queries that we want to improve through indexing, we generate a list of indexes that we might want to add.
    To do this, we parse the SQL and identify any columns used in filters, joins, grouping, or sorting.

    To generate all possible indexes we need to consider combinations of these columns, because Postgres supports [multicolumn indexes](https://www.postgresql.org/docs/current/indexes-multicolumn.html).
    In the present implementation, we include only one permutation of each possible multicolumn index, which is selected at random.
    We make this simplification to reduce the search space because permutations often have equivalent performance.
    However, we hope to improve in this area.

3. *Search for the optimal index configuration*.
    Our objective is to find the combination of indexes that optimally balances the performance benefits against the costs of storing and maintaining those indexes.
    We estimate the performance improvement by using the "what if?" capabilities provided by the `hypopg` extension.
    This simulates how the Postgres query optimizer will execute a query after the addition of indexes, and reports changes based on the actual Postgres cost model.

    One challenge is that generating query plans generally requires knowledge of the specific parameter values used in the query.
    Query normalization, which is necessary to reduce the queries under consideration, removes parameter constants.
    Parameter values provided via bind variables are similarly not available to us.

    To address this problem, we produce realistic constants that we can provide as parameters by sampling from the table statistics.
    In version 16, Postgres added [generic explain plan functionality](https://www.postgresql.org/docs/current/sql-explain.html), but it has limitations, for example around `LIKE` clauses, which our implementation does not have.

    Search strategy is critical because evaluating all possible index combinations is feasible only in simple situations.
    This is what most sets apart various indexing approaches.
    Adapting the approach of Microsoft's Anytime algorithm, we employ a greedy search strategy, i.e., find the best one-index solution, then find the best index to add to that to produce a two-index solution.
    Our search terminates when the time budget is exhausted or when a round of exploration fails to produce any gains above the minimum improvement threshold of 10%.

4. *Cost-benefit analysis*.
    When posed with two indexing alternatives, one which produces better performance and one which requires more space, how do we decide which to choose?
    Traditionally, index advisors ask for a storage budget and optimize performance with respect to that storage budget.
    We also take a storage budget, but perform a cost-benefit analysis throughout the optimization.

    We frame this as the problem of selecting a point along the [Pareto front](https://en.wikipedia.org/wiki/Pareto_front)—the set of choices for which improving one quality metric necessarily worsens another.
    In an ideal world, we might want to assess the cost of the storage and the benefit of improved performance in monetary terms.
    However, there is a simpler and more practical approach: to look at the changes in relative terms.
    Most people would agree that a 100x performance improvement is worth it, even if the storage cost is 2x.
    In our implementation, we use a configurable parameter to set this threshold.
    By default, we require the change in the log (base 10) of the performance improvement to be 2x the difference in the log of the space cost.
    This works out to allowing a maximum 10x increase in space for a 100x performance improvement.

Our implementation is most closely related to the [Anytime Algorithm](https://www.microsoft.com/en-us/research/wp-content/uploads/2020/06/Anytime-Algorithm-of-Database-Tuning-Advisor-for-Microsoft-SQL-Server.pdf) found in Microsoft SQL Server.
Compared to [Dexter](https://github.com/ankane/dexter/), an automatic indexing tool for Postgres, we search a larger space and use different heuristics.
This allows us to generate better solutions at the cost of longer runtime.

We also show the work done in each round of the search, including a comparison of the query plans before and after the addition of each index.
This gives the LLM additional context that it can use when responding to the indexing recommendations.

### Experimental: Index Tuning by LLM

Pg Airman MCP includes an experimental index tuning feature based on [Optimization by LLM](https://arxiv.org/abs/2309.03409).
Instead of using heuristics to explore possible index configurations, we provide the database schema and query plans to an LLM and ask it to propose index configurations.
We then use `hypopg` to predict performance with the proposed indexes, then feed those results back into the LLM to produce a new set of suggestions.
We repeat this process until multiple rounds of iteration produce no further improvements.

Index optimization by LLM has advantages when the index search space is large, or when indexes with many columns need to be considered.
Like traditional search-based approaches, it relies on the accuracy of the `hypopg` performance predictions.

In order to perform index optimization by LLM, you must provide an OpenAI API key by setting the `OPENAI_API_KEY` environment variable.

### Database Health

Database health checks identify tuning opportunities and maintenance needs before they lead to critical issues.
In the present release, Pg Airman MCP adapts the database health checks directly from [PgHero](https://github.com/ankane/pghero).
We are working to fully validate these checks and may extend them in the future.

- *Index Health*. Looks for unused indexes, duplicate indexes, and indexes that are bloated. Bloated indexes make inefficient use of database pages.
  Postgres autovacuum cleans up index entries pointing to dead tuples, and marks the entries as reusable. However, it does not compact the index pages and, eventually, index pages may contain few live tuple references.
- *Buffer Cache Hit Rate*. Measures the proportion of database reads that are served from the buffer cache instead of disk.
  A low buffer cache hit rate must be investigated as it is often not cost-optimal and leads to degraded application performance.
- *Connection Health*. Checks the number of connections to the database and reports on their utilization.
  The biggest risk is running out of connections, but a high number of idle or blocked connections can also indicate issues.
- *Vacuum Health*. Vacuum is important for many reasons.
  A critical one is preventing transaction id wraparound, which can cause the database to stop accepting writes.
  The Postgres multi-version concurrency control (MVCC) mechanism requires a unique transaction id for each transaction.
  However, because Postgres uses a 32-bit signed integer for transaction ids, it needs to reuse transaction ids after a maximum of 2 billion transactions.
  To do this it "freezes" the transaction ids of historical transactions, setting them all to a special value that indicates distant past.
  When records first go to disk, they are written visibility for a range of transaction ids.
  Before re-using these transaction ids, Postgres must update any on-disk records, "freezing" them to remove the references to the transaction ids to be reused.
  This check looks for tables that require vacuuming to prevent transaction id wraparound.
- *Replication Health*. Checks replication health by monitoring lag between primary and replicas, verifying replication status, and tracking usage of replication slots.
- *Constraint Health*. During normal operation, Postgres rejects any transactions that would cause a constraint violation.
  However, invalid constraints may occur after loading data or in recovery scenarios. This check looks for any invalid constraints.
- *Sequence Health*. Looks for sequences that are at risk of exceeding their maximum value.

### Postgres Client Library

Pg Airman MCP uses [psycopg3](https://www.psycopg.org/) to connect to Postgres using asynchronous I/O.
Under the hood, psycopg3 uses the [libpq](https://www.postgresql.org/docs/current/libpq.html) library to connect to Postgres, providing access to the full Postgres feature set and an underlying implementation fully supported by the Postgres community.

Some other Python-based MCP servers use [asyncpg](https://github.com/MagicStack/asyncpg), which may simplify installation by eliminating the `libpq` dependency.
Asyncpg is also probably [faster](https://fernandoarteaga.dev/blog/psycopg-vs-asyncpg/) than psycopg3, but we have not validated this ourselves.
[Older benchmarks](https://gistpreview.github.io/?0ed296e93523831ea0918d42dd1258c2) report a larger performance gap, suggesting that the newer psycopg3 has closed the gap as it matures.

Balancing these considerations, we selected `psycopg3` over `asyncpg`.
We remain open to revising this decision in the future.

### Connection Configuration

Like the [Reference PostgreSQL MCP Server](https://github.com/modelcontextprotocol/servers/tree/main/src/postgres), Pg Airman MCP takes Postgres connection information at startup.
This is convenient for users who always connect to the same database but can be cumbersome when users switch databases.

An alternative approach, taken by [PG-MCP](https://github.com/stuzero/pg-mcp-server), is to provide connection details via MCP tool calls at the time of use.
This is more convenient for users who switch databases, and allows a single MCP server to simultaneously support multiple end-users.

There must be a better approach than either of these.
Both have security weaknesses—few MCP clients store the MCP server configuration securely (an exception is Goose), and credentials provided via MCP tools are passed through the LLM and stored in the chat history.
Both also have usability issues in some scenarios.

### Schema Information

The purpose of the schema information tool is to provide the calling AI agent with the information it needs to generate correct and performant SQL.
For example, suppose a user asks, "How many flights took off from San Francisco and landed in Paris during the past year?"
The AI agent needs to find the table that stores the flights, the columns that store the origin and destinations, and perhaps a table that maps between airport codes and airport locations.

*Why provide schema information tools when LLMs are generally capable of generating the SQL to retrieve this information from Postgres directly?*

Our experience using Claude indicates that the calling LLM is very good at generating SQL to explore the Postgres schema by querying the [Postgres system catalog](https://www.postgresql.org/docs/current/catalogs.html) and the [information schema](https://www.postgresql.org/docs/current/information-schema.html) (an ANSI-standardized database metadata view).
However, we do not know whether other LLMs do so as reliably and capably.

*Would it be better to provide schema information using [MCP resources](https://modelcontextprotocol.io/docs/concepts/resources) rather than [MCP tools](https://modelcontextprotocol.io/docs/concepts/tools)?*

The [Reference PostgreSQL MCP Server](https://github.com/modelcontextprotocol/servers/tree/main/src/postgres) uses resources to expose schema information rather than tools.
Navigating resources is similar to navigating a file system, so this approach is natural in many ways.
However, resource support is less widespread than tool support in the MCP client ecosystem (see [example clients](https://modelcontextprotocol.io/clients)).
In addition, while the MCP standard says that resources can be accessed by either AI agents or end-user humans, some clients only support human navigation of the resource tree.

### Protected SQL Execution

AI amplifies longstanding challenges of protecting databases from a range of threats, ranging from simple mistakes to sophisticated attacks by malicious actors.
Whether the threat is accidental or malicious, a similar security framework applies, with aims that fall into three categories: confidentiality, integrity, and availability.
The familiar tension between convenience and safety is also evident and pronounced.

Pg Airman MCP's protected SQL execution mode focuses on integrity.
In the context of MCP, we are most concerned with LLM-generated SQL causing damage—for example, unintended data modification or deletion, or other changes that might circumvent an organization's change management process.

The simplest way to provide integrity is to ensure that all SQL executed against the database is read-only.
One way to do this is by creating a database user with read-only access permissions.
While this is a good approach, many find this cumbersome in practice.
Postgres does not provide a way to place a connection or session into read-only mode, so Pg Airman MCP uses a more complex approach to ensure read-only SQL execution on top of a read-write connection.

Pg Airman MCP provides a read-only transaction mode that prevents data and schema modifications.
Like the [Reference PostgreSQL MCP Server](https://github.com/modelcontextprotocol/servers/tree/main/src/postgres), we use read-only transactions to provide protected SQL execution.

To make this mechanism robust, we need to ensure that the SQL does not somehow circumvent the read-only transaction mode, say by issuing a `COMMIT` or `ROLLBACK` statement and then beginning a new transaction.

For example, the LLM can circumvent the read-only transaction mode by issuing a `ROLLBACK` statement and then beginning a new transaction.
For example:

```sql
ROLLBACK; DROP TABLE users;
```

To prevent cases like this, we parse the SQL before execution using the [pglast](https://pglast.readthedocs.io/) library.
We reject any SQL that contains `commit` or `rollback` statements.
Helpfully, the popular Postgres stored procedure languages, including PL/pgSQL and PL/Python, do not allow for `COMMIT` or `ROLLBACK` statements.
If you have unsafe stored procedure languages enabled on your database, then our read-only protections could be circumvented.

At present, Pg Airman MCP provides two levels of protection for the database, one at either extreme of the convenience/safety spectrum.

- "Unrestricted" provides maximum flexibility. It is suitable for development environments where speed and flexibility are paramount, and where there is no need to protect valuable or sensitive data.
- "Restricted" provides a balance between flexibility and safety. It is suitable for production environments where the database is exposed to untrusted users, and where it is important to protect valuable or sensitive data.

Unrestricted mode aligns with the approach of [Cursor's auto-run mode](https://docs.cursor.com/chat/tools#auto-run), where the AI agent operates with limited human oversight or approvals.
We expect auto-run to be deployed in development environments where the consequences of mistakes are low, where databases do not contain valuable or sensitive data, and where they can be recreated or restored from backups when needed.

We designed restricted mode to be conservative, erring on the side of safety even though it may be inconvenient.
Restricted mode is limited to read-only operations, and we limit query execution time to prevent long-running queries from impacting system performance.
We may add measures in the future to make sure that restricted mode is safe to use with production databases.

## Pg Airman MCP Development

The instructions below are for developers who want to work on Pg Airman MCP, or users who prefer to install Pg Airman MCP from source.

### Local Development Setup

1. **Install uv**:

   ```bash
   curl -sSL https://astral.sh/uv/install.sh | sh
   ```

2. **Clone the repository**:

   ```bash
   git clone https://github.com/EnterpriseDB/pg-airman-mcp.git
   cd pg-airman-mcp
   ```

3. **Install dependencies**:

   ```bash
   uv pip install -e .
   uv sync
   ```

4. **Run the server**:

   ```bash
   uv run pg-airman-mcp "postgres://user:password@localhost:5432/dbname"
   ```
