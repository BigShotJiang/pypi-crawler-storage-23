"""Pacote dissmodel - modelagem espacial discreta"""
