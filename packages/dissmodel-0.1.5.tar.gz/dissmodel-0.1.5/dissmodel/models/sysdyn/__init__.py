from .population_growth import PopulationGrowth
from .sir import SIR
from .cofee import Coffee
from .lorenz import Lorenz
from .predatorprey import PredatorPrey