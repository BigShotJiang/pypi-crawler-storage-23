"""ProjectDB: per-project SQLite database for symbols, references, edges, chunks."""

import json
import logging
import os
import sqlite3
from pathlib import Path
from typing import Any

import numpy as np

from ..exceptions import PathTraversalError
from ._utils import normalize_and_validate, sanitize_fts5_query

logger = logging.getLogger(__name__)


class ProjectDB:
    """Manages ~/.tessera/data/{slug}/index.db for symbols, references, and embeddings."""

    # Default base directory for project databases.
    # Override via ProjectDB.base_dir for testing.
    base_dir: str | None = None

    @staticmethod
    def _path_to_slug(project_path: str) -> str:
        """Convert absolute path to a human-readable slug.

        Follows Claude Code convention: /Users/foo/bar → -Users-foo-bar
        """
        return str(project_path).replace(os.sep, "-")

    @classmethod
    def _get_data_dir(cls, project_path: str) -> Path:
        """Get the data directory for a project's index DB."""
        slug = cls._path_to_slug(project_path)
        if cls.base_dir:
            return Path(cls.base_dir) / slug
        return Path.home() / ".tessera" / "data" / slug

    def __init__(self, project_path: str):
        """Initialize project database connection.

        Args:
            project_path: Absolute path to the project root
        """
        project_path = Path(os.path.abspath(project_path))
        tessera_dir = self._get_data_dir(str(project_path))
        tessera_dir.mkdir(parents=True, exist_ok=True)

        self.project_path = project_path
        self.db_path = str(tessera_dir / "index.db")
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row

        # Enable WAL mode for better concurrency
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")

        self._create_schema()
        self._run_migrations()

    CURRENT_SCHEMA_VERSION = 3

    def _run_migrations(self):
        """Run schema migrations if needed."""
        cursor = self.conn.cursor()

        # Ensure _meta table exists
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS _meta (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        self.conn.commit()

        try:
            cursor.execute("SELECT value FROM _meta WHERE key = 'schema_version'")
            row = cursor.fetchone()
            current_version = int(row[0]) if row else 1
        except Exception:
            current_version = 1

        if current_version < 2:
            self._migrate_to_v2()

        if current_version < 3:
            self._migrate_to_v3()

        cursor.execute(
            "INSERT OR REPLACE INTO _meta (key, value) VALUES (?, ?)",
            ('schema_version', str(self.CURRENT_SCHEMA_VERSION))
        )
        self.conn.commit()

    def _migrate_to_v2(self):
        """Migrate from schema v1 to v2: add document columns to chunk_meta."""
        cursor = self.conn.cursor()
        migrations = [
            "ALTER TABLE chunk_meta ADD COLUMN source_type TEXT DEFAULT 'code'",
            "ALTER TABLE chunk_meta ADD COLUMN section_heading TEXT",
            "ALTER TABLE chunk_meta ADD COLUMN key_path TEXT",
            "ALTER TABLE chunk_meta ADD COLUMN page_number INTEGER",
            "ALTER TABLE chunk_meta ADD COLUMN parent_section TEXT",
        ]

        for sql in migrations:
            try:
                cursor.execute(sql)
                logger.info("Schema migration: %s", sql)
            except sqlite3.OperationalError as e:
                if "duplicate column" in str(e).lower() or "already exists" in str(e).lower():
                    logger.debug("Column already exists, skipping: %s", sql)
                else:
                    logger.error("Migration failed: %s", e)
                    raise

        self.conn.commit()

    def _migrate_to_v3(self):
        """Migrate from schema v2 to v3: add end_line to symbols."""
        try:
            self.conn.execute("ALTER TABLE symbols ADD COLUMN end_line INTEGER")
            logger.info("Schema migration: added end_line to symbols")
        except sqlite3.OperationalError as e:
            if "duplicate column" in str(e).lower() or "already exists" in str(e).lower():
                logger.debug("end_line column already exists, skipping")
            else:
                raise
        self.conn.commit()

    def get_meta(self, key: str) -> str | None:
        """Read a value from the _meta key-value store."""
        row = self.conn.execute(
            "SELECT value FROM _meta WHERE key = ?", (key,)
        ).fetchone()
        return row[0] if row else None

    def set_meta(self, key: str, value: str) -> None:
        """Write a value to the _meta key-value store."""
        self.conn.execute(
            "INSERT OR REPLACE INTO _meta (key, value) VALUES (?, ?)",
            (key, value),
        )
        self.conn.commit()

    def _create_schema(self):
        """Create project database schema if it doesn't exist."""
        with self.conn:
            # Files table
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS files (
                    id INTEGER PRIMARY KEY,
                    project_id INTEGER NOT NULL,
                    path TEXT NOT NULL,
                    language TEXT,
                    hash TEXT,
                    index_status TEXT DEFAULT 'pending',
                    indexed_at TIMESTAMP,
                    UNIQUE(project_id, path)
                )
            """)

            # Symbols table
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS symbols (
                    id INTEGER PRIMARY KEY,
                    project_id INTEGER NOT NULL,
                    file_id INTEGER NOT NULL,
                    name TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    line INTEGER,
                    col INTEGER,
                    scope TEXT,
                    signature TEXT,
                    end_line INTEGER,
                    FOREIGN KEY(file_id) REFERENCES files(id)
                )
            """)
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_symbols_project_name "
                "ON symbols(project_id, name)"
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_symbols_file_id ON symbols(file_id)"
            )

            # Refs table
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS refs (
                    id INTEGER PRIMARY KEY,
                    project_id INTEGER NOT NULL,
                    from_symbol_id INTEGER NOT NULL,
                    to_symbol_id INTEGER,
                    to_symbol_name TEXT,
                    kind TEXT NOT NULL,
                    context TEXT,
                    line INTEGER,
                    FOREIGN KEY(from_symbol_id) REFERENCES symbols(id),
                    FOREIGN KEY(to_symbol_id) REFERENCES symbols(id)
                )
            """)
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_refs_from ON refs(from_symbol_id)"
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_refs_to ON refs(to_symbol_id)"
            )

            # Migration: add to_symbol_name if upgrading from older schema
            # Must run before index/trigger creation that references the column
            try:
                self.conn.execute("SELECT to_symbol_name FROM refs LIMIT 0")
            except Exception:
                self.conn.execute("ALTER TABLE refs ADD COLUMN to_symbol_name TEXT")

            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_refs_to_name ON refs(project_id, to_symbol_name)"
            )

            # Edges table
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS edges (
                    id INTEGER PRIMARY KEY,
                    project_id INTEGER NOT NULL,
                    from_id INTEGER NOT NULL,
                    to_id INTEGER NOT NULL,
                    type TEXT NOT NULL,
                    weight REAL DEFAULT 1.0,
                    FOREIGN KEY(from_id) REFERENCES symbols(id),
                    FOREIGN KEY(to_id) REFERENCES symbols(id)
                )
            """)
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_edges_from_to "
                "ON edges(from_id, to_id)"
            )
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_edges_to_from "
                "ON edges(to_id, from_id)"
            )

            # Caller refs: materialized reverse index for "who calls X?"
            # Maintained by triggers on refs table — zero application code.
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS caller_refs (
                    to_symbol_id INTEGER NOT NULL DEFAULT 0,
                    to_symbol_name TEXT,
                    from_symbol_id INTEGER NOT NULL,
                    ref_id INTEGER NOT NULL,
                    kind TEXT NOT NULL,
                    PRIMARY KEY (to_symbol_id, from_symbol_id, ref_id),
                    FOREIGN KEY (from_symbol_id) REFERENCES symbols(id),
                    FOREIGN KEY (ref_id) REFERENCES refs(id)
                )
            """)
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_caller_refs_name "
                "ON caller_refs(to_symbol_name)"
            )

            # Triggers to keep caller_refs in sync with refs
            self.conn.execute("""
                CREATE TRIGGER IF NOT EXISTS trg_caller_refs_insert
                AFTER INSERT ON refs
                WHEN NEW.to_symbol_id IS NOT NULL OR NEW.to_symbol_name IS NOT NULL
                BEGIN
                    INSERT INTO caller_refs
                        (to_symbol_id, to_symbol_name, from_symbol_id, ref_id, kind)
                    VALUES (
                        COALESCE(NEW.to_symbol_id, 0),
                        NEW.to_symbol_name,
                        NEW.from_symbol_id,
                        NEW.id,
                        NEW.kind
                    )
                    ON CONFLICT(to_symbol_id, from_symbol_id, ref_id)
                    DO UPDATE SET kind = excluded.kind, to_symbol_name = excluded.to_symbol_name;
                END
            """)
            self.conn.execute("""
                CREATE TRIGGER IF NOT EXISTS trg_caller_refs_delete
                AFTER DELETE ON refs
                BEGIN
                    DELETE FROM caller_refs WHERE ref_id = OLD.id;
                END
            """)
            self.conn.execute("""
                CREATE TRIGGER IF NOT EXISTS trg_caller_refs_update
                AFTER UPDATE ON refs
                BEGIN
                    DELETE FROM caller_refs WHERE ref_id = OLD.id;
                    INSERT INTO caller_refs
                        (to_symbol_id, to_symbol_name, from_symbol_id, ref_id, kind)
                    VALUES (
                        COALESCE(NEW.to_symbol_id, 0),
                        NEW.to_symbol_name,
                        NEW.from_symbol_id,
                        NEW.id,
                        NEW.kind
                    )
                    ON CONFLICT(to_symbol_id, from_symbol_id, ref_id)
                    DO UPDATE SET kind = excluded.kind, to_symbol_name = excluded.to_symbol_name;
                END
            """)

            # Backfill caller_refs from existing refs (migration path)
            self.conn.execute("""
                INSERT OR IGNORE INTO caller_refs
                    (to_symbol_id, to_symbol_name, from_symbol_id, ref_id, kind)
                SELECT COALESCE(to_symbol_id, 0), to_symbol_name, from_symbol_id, id, kind
                FROM refs
                WHERE to_symbol_id IS NOT NULL OR to_symbol_name IS NOT NULL
            """)

            # Chunk metadata table
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS chunk_meta (
                    id INTEGER PRIMARY KEY,
                    project_id INTEGER NOT NULL,
                    file_id INTEGER NOT NULL,
                    start_line INTEGER NOT NULL,
                    end_line INTEGER NOT NULL,
                    symbol_ids TEXT,
                    ast_type TEXT,
                    chunk_type TEXT,
                    content TEXT NOT NULL,
                    length INTEGER,
                    FOREIGN KEY(file_id) REFERENCES files(id)
                )
            """)
            self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_chunks_file ON chunk_meta(file_id)"
            )

            # FTS5 virtual table for full-text search
            self.conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
                    content,
                    chunk_id UNINDEXED,
                    file_path UNINDEXED
                )
            """)

            # Embeddings table (BLOBs)
            self.conn.execute("""
                CREATE TABLE IF NOT EXISTS chunk_embeddings (
                    chunk_id INTEGER PRIMARY KEY,
                    embedding BLOB NOT NULL,
                    FOREIGN KEY(chunk_id) REFERENCES chunk_meta(id)
                )
            """)

    def validate_path(self, file_path: str) -> str:
        """Validate and normalize a file path within the project.

        Args:
            file_path: File path relative or absolute

        Returns:
            Validated absolute path as string

        Raises:
            PathTraversalError: If path escapes project root
        """
        normalized = normalize_and_validate(self.project_path, file_path)
        return str(normalized)

    # File operations

    def upsert_file(
        self,
        project_id: int,
        path: str,
        language: str,
        file_hash: str
    ) -> int:
        """Upsert a file record (insert or update).

        Args:
            project_id: Project ID
            path: File path
            language: Programming language
            file_hash: Content hash

        Returns:
            File ID
        """
        # Validate path
        self.validate_path(path)

        with self.conn:
            cursor = self.conn.execute(
                """
                INSERT INTO files (project_id, path, language, hash, index_status)
                VALUES (?, ?, ?, ?, 'pending')
                ON CONFLICT(project_id, path) DO UPDATE SET
                    language = excluded.language,
                    hash = excluded.hash,
                    index_status = 'pending'
                RETURNING id
                """,
                (project_id, path, language, file_hash)
            )
            return cursor.fetchone()[0]

    def get_file(
        self,
        file_id: int = None,
        path: str = None
    ) -> dict[str, Any] | None:
        """Retrieve a file record.

        Args:
            file_id: File ID
            path: File path

        Returns:
            File record as dict, or None if not found
        """
        if file_id is not None:
            cursor = self.conn.execute(
                "SELECT * FROM files WHERE id = ?",
                (file_id,)
            )
        elif path is not None:
            cursor = self.conn.execute(
                "SELECT * FROM files WHERE path = ?",
                (path,)
            )
        else:
            raise ValueError("Must provide file_id or path")

        row = cursor.fetchone()
        return dict(row) if row else None

    def update_file_status(self, file_id: int, status: str):
        """Update file indexing status.

        Args:
            file_id: File ID
            status: New status (e.g., 'indexed', 'error')
        """
        with self.conn:
            self.conn.execute(
                """
                UPDATE files
                SET index_status = ?, indexed_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (status, file_id)
            )

    def delete_file_data(self, rel_path: str) -> None:
        """Delete all indexed data for a file by relative path.

        Removes the file record and cascading data (symbols, references, chunks).

        Args:
            rel_path: Relative file path within the project
        """
        cursor = self.conn.execute("SELECT id FROM files WHERE path = ?", (rel_path,))
        row = cursor.fetchone()
        if not row:
            return
        file_id = row["id"]
        self.clear_file_data(file_id)
        with self.conn:
            self.conn.execute("DELETE FROM files WHERE id = ?", (file_id,))

    def get_pending_files(self) -> list[dict[str, Any]]:
        """Get all files with 'pending' index status.

        Returns:
            List of file records
        """
        cursor = self.conn.execute(
            "SELECT * FROM files WHERE index_status = 'pending' ORDER BY path"
        )
        return [dict(row) for row in cursor.fetchall()]

    # Symbol operations

    def insert_symbols(self, symbols: list[dict[str, Any]]) -> list[int]:
        """Batch insert symbols.

        Args:
            symbols: List of symbol records with keys:
                - project_id, file_id, name, kind, line, col, scope, signature

        Returns:
            List of inserted symbol IDs
        """
        ids = []
        with self.conn:
            for sym in symbols:
                cursor = self.conn.execute(
                    """
                    INSERT INTO symbols (
                        project_id, file_id, name, kind, line, col, scope, signature, end_line
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        sym.get("project_id"),
                        sym.get("file_id"),
                        sym.get("name"),
                        sym.get("kind"),
                        sym.get("line"),
                        sym.get("col"),
                        sym.get("scope"),
                        sym.get("signature"),
                        sym.get("end_line"),
                    )
                )
                ids.append(cursor.lastrowid)
        return ids

    def lookup_symbols(
        self,
        query: str = "*",
        kind: str = None,
        language: str = None,
        file_pattern: str = None,
        project_id: int = None
    ) -> list[dict[str, Any]]:
        """Look up symbols with optional filtering.

        Args:
            query: Symbol name pattern (* for wildcard, or exact name)
            kind: Filter by symbol kind (function, class, variable, etc.)
            language: Filter by file language
            file_pattern: Filter by file path pattern
            project_id: Filter by project

        Returns:
            List of matching symbol records
        """
        sql = """
            SELECT s.* FROM symbols s
            JOIN files f ON s.file_id = f.id
            WHERE 1=1
        """
        params = []

        if project_id is not None:
            sql += " AND s.project_id = ?"
            params.append(project_id)

        exact_query = False
        if query != "*":
            if "*" in query:
                pattern = query.replace("*", "%")
                sql += " AND s.name LIKE ?"
                params.append(pattern)
            else:
                sql += " AND s.name = ?"
                params.append(query)
                exact_query = True

        if kind is not None:
            sql += " AND s.kind = ?"
            params.append(kind)

        if language is not None:
            sql += " AND f.language = ?"
            params.append(language)

        if file_pattern is not None:
            pattern = file_pattern.replace("*", "%")
            sql += " AND f.path LIKE ?"
            params.append(pattern)

        sql += " ORDER BY s.name"

        cursor = self.conn.execute(sql, params)
        results = [dict(row) for row in cursor.fetchall()]

        # Exact match returned nothing → retry as substring match
        if not results and exact_query:
            return self.lookup_symbols(
                f"*{query}*", kind=kind, language=language,
                file_pattern=file_pattern, project_id=project_id
            )

        return results

    def get_ancestor_symbols(self, file_id: int, line: int) -> list[dict[str, Any]]:
        """Get all symbols whose range contains the given line, outermost first.

        Args:
            file_id: File ID to search within
            line: Absolute line number to find containing symbols for

        Returns:
            List of symbol dicts ordered outermost first (ascending start, descending end)
        """
        cursor = self.conn.execute(
            "SELECT * FROM symbols "
            "WHERE file_id = ? AND line <= ? AND end_line >= ? "
            "ORDER BY line ASC, end_line DESC",
            (file_id, line, line),
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_symbol(self, symbol_id: int) -> dict[str, Any] | None:
        """Get a symbol by ID.

        Args:
            symbol_id: Symbol ID

        Returns:
            Symbol record as dict, or None if not found
        """
        cursor = self.conn.execute(
            "SELECT * FROM symbols WHERE id = ?",
            (symbol_id,)
        )
        row = cursor.fetchone()
        return dict(row) if row else None

    # Reference operations

    def insert_refs(self, refs: list[dict[str, Any]]) -> list[int]:
        """Batch insert references.

        Args:
            refs: List of reference records with keys:
                - project_id, from_symbol_id, to_symbol_id, kind, context, line

        Returns:
            List of inserted reference IDs
        """
        ids = []
        with self.conn:
            for ref in refs:
                cursor = self.conn.execute(
                    """
                    INSERT INTO refs (
                        project_id, from_symbol_id, to_symbol_id, to_symbol_name, kind, context, line
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        ref.get("project_id"),
                        ref.get("from_symbol_id"),
                        ref.get("to_symbol_id"),
                        ref.get("to_symbol_name"),
                        ref.get("kind"),
                        ref.get("context"),
                        ref.get("line")
                    )
                )
                ids.append(cursor.lastrowid)
        return ids

    def get_refs(
        self,
        symbol_id: int = None,
        symbol_name: str = None,
        kind: str = "all"
    ) -> list[dict[str, Any]]:
        """Get references for a symbol.

        Args:
            symbol_id: Symbol ID (for from_symbol_id)
            symbol_name: Symbol name (looks up by name)
            kind: Reference kind filter ("all" for no filter)

        Returns:
            List of reference records
        """
        sql = "SELECT * FROM refs WHERE 1=1"
        params = []

        if symbol_id is not None:
            sql += " AND from_symbol_id = ?"
            params.append(symbol_id)
        elif symbol_name is not None:
            # Subquery to find symbol by name
            sql += " AND from_symbol_id IN (SELECT id FROM symbols WHERE name = ?)"
            params.append(symbol_name)
        else:
            raise ValueError("Must provide symbol_id or symbol_name")

        if kind != "all":
            sql += " AND kind = ?"
            params.append(kind)

        sql += " ORDER BY line"

        cursor = self.conn.execute(sql, params)
        return [dict(row) for row in cursor.fetchall()]

    def get_callers(
        self,
        symbol_id: int = None,
        symbol_name: str = None,
        kind: str = "all"
    ) -> list[dict[str, Any]]:
        """Get callers of a symbol (reverse reference lookup).

        Uses the materialized caller_refs table for O(1) lookups.
        Resolves both pre-resolved (to_symbol_id) and unresolved
        (to_symbol_name) references.

        Args:
            symbol_id: Target symbol ID
            symbol_name: Target symbol name
            kind: Reference kind filter ("all" for no filter)

        Returns:
            List of caller symbol dicts with full metadata
        """
        conditions = []
        params = []

        if symbol_id is not None:
            # Match by resolved ID OR by name (for cross-file unresolved refs)
            conditions.append(
                "(cr.to_symbol_id = ? OR cr.to_symbol_name IN "
                "(SELECT name FROM symbols WHERE id = ?))"
            )
            params.extend([symbol_id, symbol_id])
        elif symbol_name is not None:
            # Match by resolved ID or unresolved name
            conditions.append(
                "(cr.to_symbol_id IN (SELECT id FROM symbols WHERE name = ?) "
                "OR cr.to_symbol_name = ?)"
            )
            params.extend([symbol_name, symbol_name])
        else:
            raise ValueError("Must provide symbol_id or symbol_name")

        if kind != "all":
            conditions.append("cr.kind = ?")
            params.append(kind)

        where = " AND ".join(conditions)
        cursor = self.conn.execute(
            f"""
            SELECT DISTINCT s.* FROM symbols s
            JOIN caller_refs cr ON cr.from_symbol_id = s.id
            WHERE {where}
            ORDER BY s.name
            """,
            params
        )
        return [dict(row) for row in cursor.fetchall()]

    # Edge operations

    def insert_edges(self, edges: list[dict[str, Any]]) -> list[int]:
        """Batch insert edges in the call graph.

        Args:
            edges: List of edge records with keys:
                - project_id, from_id, to_id, type, weight

        Returns:
            List of inserted edge IDs
        """
        ids = []
        with self.conn:
            for edge in edges:
                cursor = self.conn.execute(
                    """
                    INSERT INTO edges (
                        project_id, from_id, to_id, type, weight
                    )
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (
                        edge.get("project_id"),
                        edge.get("from_id"),
                        edge.get("to_id"),
                        edge.get("type"),
                        edge.get("weight", 1.0)
                    )
                )
                ids.append(cursor.lastrowid)
        return ids

    def get_forward_refs(
        self,
        symbol_id: int,
        depth: int = 1
    ) -> list[dict[str, Any]]:
        """Get forward references (callees) for a symbol up to depth.

        Uses iterative BFS with a visited set for efficient graph traversal.
        Follows pre-resolved refs, unresolved refs (query-time name resolution),
        and containment edges.

        Args:
            symbol_id: Starting symbol ID
            depth: Max traversal depth (number of hops to follow, capped at 10)

        Returns:
            List of reachable symbols (forward graph traversal)
        """
        depth = min(depth, 10)  # Hard cap to prevent runaway recursion

        visited = {symbol_id}
        frontier = {symbol_id}

        for _ in range(depth):
            if not frontier:
                break

            next_frontier = set()
            placeholders = ",".join("?" * len(frontier))
            frontier_list = list(frontier)

            # 1. Pre-resolved refs (to_symbol_id is set)
            rows = self.conn.execute(
                f"SELECT DISTINCT r.to_symbol_id FROM refs r "
                f"WHERE r.from_symbol_id IN ({placeholders}) AND r.to_symbol_id IS NOT NULL",
                frontier_list
            ).fetchall()
            for row in rows:
                sid = row[0]
                if sid not in visited:
                    next_frontier.add(sid)

            # 2. Unresolved refs via query-time name resolution
            rows = self.conn.execute(
                f"SELECT DISTINCT s2.id FROM refs r "
                f"JOIN symbols s2 ON s2.name = r.to_symbol_name AND s2.project_id = r.project_id "
                f"WHERE r.from_symbol_id IN ({placeholders}) "
                f"AND r.to_symbol_id IS NULL AND r.to_symbol_name IS NOT NULL",
                frontier_list
            ).fetchall()
            for row in rows:
                sid = row[0]
                if sid not in visited:
                    next_frontier.add(sid)

            # 3. Containment edges
            rows = self.conn.execute(
                f"SELECT DISTINCT e.to_id FROM edges e "
                f"WHERE e.from_id IN ({placeholders}) AND e.type = 'contains'",
                frontier_list
            ).fetchall()
            for row in rows:
                sid = row[0]
                if sid not in visited:
                    next_frontier.add(sid)

            visited.update(next_frontier)
            frontier = next_frontier

        # Fetch all discovered symbols (excluding the seed)
        result_ids = visited - {symbol_id}
        if not result_ids:
            return []

        placeholders = ",".join("?" * len(result_ids))
        cursor = self.conn.execute(
            f"SELECT * FROM symbols WHERE id IN ({placeholders}) ORDER BY name",
            list(result_ids)
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_backward_refs(self, symbol_id: int) -> list[dict[str, Any]]:
        """Get backward references (callers) for a symbol.

        Args:
            symbol_id: Symbol ID

        Returns:
            List of symbols that reference this one
        """
        cursor = self.conn.execute(
            """
            SELECT s.* FROM symbols s
            JOIN edges e ON e.from_id = s.id
            WHERE e.to_id = ?
            ORDER BY s.name
            """,
            (symbol_id,)
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_impact(
        self,
        symbol_name: str,
        depth: int = 3,
        include_types: bool = True,
    ) -> list[dict[str, Any]]:
        """Find all symbols transitively affected by a change to the named symbol.

        Uses backward BFS through caller_refs (which resolves both
        to_symbol_id and to_symbol_name for cross-file coverage).

        Args:
            symbol_name: Symbol name to analyze impact for
            depth: Max traversal depth (hops), capped at 10
            include_types: Include type_reference edges (default True).
                Set False to limit to runtime dependencies only.

        Returns:
            List of symbols that directly or transitively depend on this symbol
        """
        depth = min(depth, 10)

        # Seed: all symbol IDs matching this name
        seed_ids = set()
        cursor = self.conn.execute(
            "SELECT id FROM symbols WHERE name = ?", (symbol_name,)
        )
        for row in cursor.fetchall():
            seed_ids.add(row[0])

        if not seed_ids:
            return []

        visited_ids = set(seed_ids)
        # Also track visited names to handle cross-file name-only refs
        visited_names = {symbol_name}
        frontier_ids = set(seed_ids)
        frontier_names = {symbol_name}

        for _ in range(depth):
            if not frontier_ids and not frontier_names:
                break

            next_ids = set()
            next_names = set()

            # 1. Find callers via caller_refs by ID (pre-resolved refs)
            if frontier_ids:
                placeholders = ",".join("?" * len(frontier_ids))
                kind_filter = " AND cr.kind != 'type_reference'" if not include_types else ""
                rows = self.conn.execute(
                    f"SELECT DISTINCT cr.from_symbol_id FROM caller_refs cr "
                    f"WHERE cr.to_symbol_id IN ({placeholders}){kind_filter}",
                    list(frontier_ids)
                ).fetchall()
                for row in rows:
                    sid = row[0]
                    if sid not in visited_ids:
                        next_ids.add(sid)

            # 2. Find callers via caller_refs by name (unresolved cross-file refs)
            if frontier_names:
                placeholders = ",".join("?" * len(frontier_names))
                kind_filter = " AND cr.kind != 'type_reference'" if not include_types else ""
                rows = self.conn.execute(
                    f"SELECT DISTINCT cr.from_symbol_id FROM caller_refs cr "
                    f"WHERE cr.to_symbol_name IN ({placeholders}){kind_filter}",
                    list(frontier_names)
                ).fetchall()
                for row in rows:
                    sid = row[0]
                    if sid not in visited_ids:
                        next_ids.add(sid)

            # 3. Containment edges (forward: parent contains children)
            # If outer_func changes, inner_func is also affected
            if frontier_ids:
                placeholders = ",".join("?" * len(frontier_ids))
                rows = self.conn.execute(
                    f"SELECT DISTINCT e.to_id FROM edges e "
                    f"WHERE e.from_id IN ({placeholders}) AND e.type = 'contains'",
                    list(frontier_ids)
                ).fetchall()
                for row in rows:
                    sid = row[0]
                    if sid not in visited_ids:
                        next_ids.add(sid)

            # Resolve new IDs to names for next hop
            if next_ids:
                placeholders = ",".join("?" * len(next_ids))
                rows = self.conn.execute(
                    f"SELECT DISTINCT name FROM symbols WHERE id IN ({placeholders})",
                    list(next_ids)
                ).fetchall()
                for row in rows:
                    name = row[0]
                    if name not in visited_names:
                        next_names.add(name)

            visited_ids.update(next_ids)
            visited_names.update(next_names)
            frontier_ids = next_ids
            frontier_names = next_names

        # Fetch all discovered symbols (excluding seeds)
        result_ids = visited_ids - seed_ids
        if not result_ids:
            return []

        placeholders = ",".join("?" * len(result_ids))
        cursor = self.conn.execute(
            f"SELECT * FROM symbols WHERE id IN ({placeholders}) ORDER BY name",
            list(result_ids)
        )
        return [dict(row) for row in cursor.fetchall()]

    # Chunk operations

    def insert_chunks(self, chunks: list[dict[str, Any]]) -> list[int]:
        """Batch insert chunks with FTS5 and embeddings.

        Args:
            chunks: List of chunk records with keys:
                - project_id, file_id, start_line, end_line, symbol_ids, ast_type,
                  chunk_type, content, length, embedding (optional, np.ndarray)

        Returns:
            List of inserted chunk IDs
        """
        ids = []
        file_path_cache = {}
        with self.conn:
            for chunk in chunks:
                # Insert into chunk_meta
                cursor = self.conn.execute(
                    """
                    INSERT INTO chunk_meta (
                        project_id, file_id, start_line, end_line, symbol_ids,
                        ast_type, chunk_type, content, length,
                        source_type, section_heading, key_path, page_number, parent_section
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        chunk.get("project_id"),
                        chunk.get("file_id"),
                        chunk.get("start_line"),
                        chunk.get("end_line"),
                        json.dumps(chunk.get("symbol_ids", [])),
                        chunk.get("ast_type"),
                        chunk.get("chunk_type"),
                        chunk.get("content"),
                        chunk.get("length"),
                        chunk.get("source_type", "code"),
                        chunk.get("section_heading"),
                        chunk.get("key_path"),
                        chunk.get("page_number"),
                        chunk.get("parent_section"),
                    )
                )
                chunk_id = cursor.lastrowid
                ids.append(chunk_id)

                # Insert into FTS5
                fid = chunk["file_id"]
                if fid not in file_path_cache:
                    file_info = self.get_file(file_id=fid)
                    file_path_cache[fid] = file_info["path"] if file_info else ""
                file_path = file_path_cache[fid]

                self.conn.execute(
                    """
                    INSERT INTO chunks_fts (content, chunk_id, file_path)
                    VALUES (?, ?, ?)
                    """,
                    (chunk.get("content"), chunk_id, file_path)
                )

                # Insert embedding if provided
                if "embedding" in chunk and chunk["embedding"] is not None:
                    embedding = chunk["embedding"]
                    if isinstance(embedding, np.ndarray):
                        embedding_bytes = embedding.astype(np.float32).tobytes()
                    elif isinstance(embedding, (list, tuple)):
                        embedding_bytes = np.array(embedding, dtype=np.float32).tobytes()
                    else:
                        embedding_bytes = embedding

                    self.conn.execute(
                        """
                        INSERT INTO chunk_embeddings (chunk_id, embedding)
                        VALUES (?, ?)
                        """,
                        (chunk_id, embedding_bytes)
                    )

        return ids

    def keyword_search(self, query: str, limit: int = 10,
                       source_type: list[str] | None = None,
                       advanced_fts: bool = False) -> list[dict[str, Any]]:
        """Full-text search on chunks using FTS5 BM25.

        Args:
            query: Search query
            limit: Max results
            source_type: Optional list of source types to filter by (e.g., ['code', 'markdown'])
            advanced_fts: If True, allow FTS5 operators (phrases, NOT, *, NEAR).
                If False (default), escape all operators for safe literal matching.

        Returns:
            List of matching chunks with score
        """
        if not query or not query.strip():
            return []

        query = sanitize_fts5_query(query, allow_advanced=advanced_fts)
        if not query:
            return []

        if source_type:
            placeholders = ','.join('?' for _ in source_type)
            cursor = self.conn.execute(
                f"""
                SELECT cm.*, fts.rank as score
                FROM chunks_fts fts
                JOIN chunk_meta cm ON fts.chunk_id = cm.id
                WHERE chunks_fts MATCH ?
                  AND COALESCE(cm.source_type, 'code') IN ({placeholders})
                ORDER BY fts.rank
                LIMIT ?
                """,
                (query, *source_type, limit)
            )
        else:
            cursor = self.conn.execute(
                """
                SELECT cm.*, fts.rank as score
                FROM chunks_fts fts
                JOIN chunk_meta cm ON fts.chunk_id = cm.id
                WHERE chunks_fts MATCH ?
                ORDER BY fts.rank
                LIMIT ?
                """,
                (query, limit)
            )
        return [dict(row) for row in cursor.fetchall()]

    def get_chunk(self, chunk_id: int) -> dict[str, Any] | None:
        """Get a chunk by ID.

        Args:
            chunk_id: Chunk ID

        Returns:
            Chunk record as dict, or None if not found
        """
        cursor = self.conn.execute(
            "SELECT * FROM chunk_meta WHERE id = ?",
            (chunk_id,)
        )
        row = cursor.fetchone()
        return dict(row) if row else None

    def get_all_embeddings(self) -> tuple[list[int], np.ndarray]:
        """Load all chunk embeddings into a numpy matrix.

        Efficient for <20K chunks. Used for vector search.

        Returns:
            Tuple of (chunk_ids, embeddings_matrix) where embeddings_matrix
            is shape (n_chunks, embedding_dim) float32
        """
        cursor = self.conn.execute(
            """
            SELECT chunk_id, embedding FROM chunk_embeddings
            ORDER BY chunk_id
            """
        )

        rows = cursor.fetchall()
        if not rows:
            return [], np.array([], dtype=np.float32)

        chunk_ids = []
        embeddings = []

        for chunk_id, embedding_bytes in rows:
            chunk_ids.append(chunk_id)
            embedding = np.frombuffer(embedding_bytes, dtype=np.float32)
            embeddings.append(embedding)

        # Stack into matrix
        embeddings_matrix = np.stack(embeddings, axis=0)

        return chunk_ids, embeddings_matrix

    def clear_file_data(self, file_id: int):
        """Clear all data for a file (for re-indexing).

        Deletes symbols, refs, edges, chunks, and embeddings associated with file.

        Args:
            file_id: File ID
        """
        with self.conn:
            # Batch delete chunks: FTS5, embeddings, then metadata
            self.conn.execute(
                "DELETE FROM chunk_embeddings WHERE chunk_id IN (SELECT id FROM chunk_meta WHERE file_id = ?)",
                (file_id,)
            )
            self.conn.execute(
                "DELETE FROM chunks_fts WHERE chunk_id IN (SELECT id FROM chunk_meta WHERE file_id = ?)",
                (file_id,)
            )
            self.conn.execute(
                "DELETE FROM chunk_meta WHERE file_id = ?",
                (file_id,)
            )

            # Batch delete graph data: edges, refs, then symbols
            self.conn.execute(
                "DELETE FROM edges WHERE from_id IN (SELECT id FROM symbols WHERE file_id = ?) "
                "OR to_id IN (SELECT id FROM symbols WHERE file_id = ?)",
                (file_id, file_id)
            )
            self.conn.execute(
                "DELETE FROM refs WHERE from_symbol_id IN (SELECT id FROM symbols WHERE file_id = ?) "
                "OR to_symbol_id IN (SELECT id FROM symbols WHERE file_id = ?)",
                (file_id, file_id)
            )
            self.conn.execute(
                "DELETE FROM symbols WHERE file_id = ?",
                (file_id,)
            )

    def get_all_edges(self, project_id: int) -> list[dict]:
        """Fetch all edges for a project (used by graph loader).

        Args:
            project_id: Project ID

        Returns:
            List of dicts with 'from_id', 'to_id', 'weight' keys
        """
        cursor = self.conn.execute(
            "SELECT from_id, to_id, weight FROM edges WHERE project_id = ? ORDER BY from_id, to_id",
            (project_id,)
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_all_symbols(self, project_id: int) -> list[dict]:
        """Fetch all symbols for a project (used by graph loader).

        Args:
            project_id: Project ID

        Returns:
            List of dicts with 'id', 'name', 'kind' keys (at minimum)
        """
        cursor = self.conn.execute(
            "SELECT id, name, kind, file_id, line, col, scope FROM symbols WHERE project_id = ? ORDER BY id",
            (project_id,)
        )
        return [dict(row) for row in cursor.fetchall()]

    def get_symbol_to_chunks_mapping(self) -> dict[int, list[int]]:
        """Map symbol IDs to chunk IDs they appear in.

        Used by search to convert PPR (symbol-level) to chunk-level results.

        Returns:
            {symbol_id: [chunk_id, ...]}
        """
        cursor = self.conn.execute(
            "SELECT id, symbol_ids FROM chunk_meta WHERE symbol_ids IS NOT NULL"
        )

        symbol_to_chunks: dict[int, list[int]] = {}
        for row in cursor.fetchall():
            chunk_id = row[0]
            symbol_ids_json = row[1]

            try:
                symbol_ids = json.loads(symbol_ids_json) if symbol_ids_json else []
            except json.JSONDecodeError:
                continue

            if symbol_ids is None:
                continue

            for sym_id in symbol_ids:
                if sym_id not in symbol_to_chunks:
                    symbol_to_chunks[sym_id] = []
                symbol_to_chunks[sym_id].append(chunk_id)

        return symbol_to_chunks

    def close(self):
        """Close the project database connection."""
        self.conn.close()



if __name__ == "__main__":
    """Basic verification of database operations."""
    import tempfile

    from ._global import GlobalDB

    # Test GlobalDB
    print("Testing GlobalDB...")
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "global.db")
        gdb = GlobalDB(db_path=db_path)

        # Register a project
        project_id = gdb.register_project(
            path="/path/to/project",
            name="test-project",
            language="python"
        )
        print(f"  Registered project with ID: {project_id}")

        # Retrieve project
        proj = gdb.get_project(project_id=project_id)
        assert proj is not None
        assert proj["name"] == "test-project"
        print(f"  Retrieved project: {proj['name']}")

        # List projects
        projects = gdb.list_projects()
        assert len(projects) == 1
        print(f"  Listed {len(projects)} project(s)")

        gdb.close()

    # Test ProjectDB
    print("\nTesting ProjectDB...")
    with tempfile.TemporaryDirectory() as tmpdir:
        pdb = ProjectDB(tmpdir)

        # Upsert a file
        file_id = pdb.upsert_file(
            project_id=1,
            path="test.py",
            language="python",
            file_hash="abc123"
        )
        print(f"  Upserted file with ID: {file_id}")

        # Get file
        file_rec = pdb.get_file(file_id=file_id)
        assert file_rec is not None
        assert file_rec["path"] == "test.py"
        print(f"  Retrieved file: {file_rec['path']}")

        # Insert symbols
        symbol_ids = pdb.insert_symbols([
            {
                "project_id": 1,
                "file_id": file_id,
                "name": "my_function",
                "kind": "function",
                "line": 10,
                "col": 0,
                "scope": "module",
                "signature": "def my_function(x, y)"
            },
            {
                "project_id": 1,
                "file_id": file_id,
                "name": "MyClass",
                "kind": "class",
                "line": 20,
                "col": 0,
                "scope": "module",
                "signature": "class MyClass"
            }
        ])
        print(f"  Inserted {len(symbol_ids)} symbols")

        # Look up symbol
        syms = pdb.lookup_symbols(query="my_function", kind="function")
        assert len(syms) == 1
        assert syms[0]["name"] == "my_function"
        print(f"  Looked up symbol: {syms[0]['name']}")

        # Insert references
        ref_ids = pdb.insert_refs([
            {
                "project_id": 1,
                "from_symbol_id": symbol_ids[0],
                "to_symbol_id": symbol_ids[1],
                "kind": "calls",
                "context": "instantiation",
                "line": 12
            }
        ])
        print(f"  Inserted {len(ref_ids)} reference(s)")

        # Get references
        refs = pdb.get_refs(symbol_id=symbol_ids[0])
        assert len(refs) == 1
        print(f"  Retrieved {len(refs)} reference(s)")

        # Insert edges
        edge_ids = pdb.insert_edges([
            {
                "project_id": 1,
                "from_id": symbol_ids[0],
                "to_id": symbol_ids[1],
                "type": "calls",
                "weight": 1.0
            }
        ])
        print(f"  Inserted {len(edge_ids)} edge(s)")

        # Get forward refs
        forward = pdb.get_forward_refs(symbol_ids[0], depth=1)
        assert len(forward) == 1
        print(f"  Forward refs: {len(forward)}")

        # Insert chunks with embeddings
        test_embedding = np.array([0.1, 0.2, 0.3, 0.4], dtype=np.float32)
        chunk_ids = pdb.insert_chunks([
            {
                "project_id": 1,
                "file_id": file_id,
                "start_line": 10,
                "end_line": 15,
                "symbol_ids": [symbol_ids[0]],
                "ast_type": "function_definition",
                "chunk_type": "function",
                "content": "def my_function(x, y):\n    return x + y",
                "length": 40,
                "embedding": test_embedding
            }
        ])
        print(f"  Inserted {len(chunk_ids)} chunk(s) with embedding")

        # Get all embeddings
        loaded_ids, embeddings = pdb.get_all_embeddings()
        assert len(loaded_ids) == 1
        assert embeddings.shape == (1, 4)
        print(f"  Loaded embeddings: shape {embeddings.shape}")

        # Keyword search
        results = pdb.keyword_search("function", limit=5)
        print(f"  Keyword search results: {len(results)}")

        # Test path validation
        try:
            validated = pdb.validate_path("subdir/file.py")
            print(f"  Validated path: {validated}")
        except PathTraversalError as e:
            print(f"  Path validation error: {e}")

        # Test path traversal protection
        try:
            pdb.validate_path("../../etc/passwd")
            print("  ERROR: Path traversal not caught!")
        except PathTraversalError:
            print("  Path traversal correctly blocked")

        # Clear file data
        pdb.clear_file_data(file_id)
        syms_after = pdb.lookup_symbols()
        assert len(syms_after) == 0
        print("  Cleared file data successfully")

        pdb.close()

    print("\nAll tests passed!")
