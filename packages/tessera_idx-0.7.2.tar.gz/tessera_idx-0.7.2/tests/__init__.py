"""Test suite for CodeMem."""
