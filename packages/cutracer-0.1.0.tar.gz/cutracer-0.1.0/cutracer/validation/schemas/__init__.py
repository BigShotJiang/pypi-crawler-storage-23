# Copyright (c) Meta Platforms, Inc. and affiliates.

"""
CUTracer JSON Schema files.

This package contains JSON Schema definition files for validating
CUTracer trace records.
"""
