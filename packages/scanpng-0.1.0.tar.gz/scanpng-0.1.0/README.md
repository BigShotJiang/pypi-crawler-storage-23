# scanpng

Analyseur forensic de fichiers PNG :
- chunks
- CRC (recalculé)
- offsets
- données appendées

Usage :
scanpng -path fichier.png

