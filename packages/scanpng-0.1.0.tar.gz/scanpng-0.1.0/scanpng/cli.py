from .parser import run_png_scan

def main():
    run_png_scan()