from .transform import LSFTransformer as Transformer

assert Transformer
