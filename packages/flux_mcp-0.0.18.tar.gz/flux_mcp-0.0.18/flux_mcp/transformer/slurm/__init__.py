from .transform import SlurmTransformer as Transformer

assert Transformer
