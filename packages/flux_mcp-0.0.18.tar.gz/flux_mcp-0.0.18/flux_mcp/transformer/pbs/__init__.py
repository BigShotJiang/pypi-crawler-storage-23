from .transform import PBSTransformer as Transformer

assert Transformer
