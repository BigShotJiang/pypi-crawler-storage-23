from mcp.server.fastmcp import FastMCP

mcp = FastMCP("mcp-tool-web-search", json_response=True)

@mcp.tool()
def search(query: str, max_results: int = 5) -> str:
    """
    在网络上搜索信息。
    
    Args:
        query: 搜索关键词或问题
        max_results: 返回结果的最大数量，默认 5
    """
    return "搜索结果"

def run():
    mcp.run(transport="stdio")  # 默认 stdio，适合 Cursor/Claude Desktop