"""Periodic heartbeat: proactive agent turns in the main session."""

from ductor_bot.heartbeat.observer import HeartbeatObserver as HeartbeatObserver

__all__ = ["HeartbeatObserver"]
