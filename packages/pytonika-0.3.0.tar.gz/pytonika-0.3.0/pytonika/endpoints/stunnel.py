from ._base import Endpoint


class Stunnel(Endpoint):
    pass
