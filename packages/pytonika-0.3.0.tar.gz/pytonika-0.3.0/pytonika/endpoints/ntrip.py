from ._base import Endpoint


class NTRIP(Endpoint):
    pass
