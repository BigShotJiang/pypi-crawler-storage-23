from ._base import Endpoint


class Starlink(Endpoint):
    pass
