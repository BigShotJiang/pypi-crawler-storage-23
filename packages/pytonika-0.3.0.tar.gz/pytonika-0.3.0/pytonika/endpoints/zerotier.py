from ._base import Endpoint


class Zerotier(Endpoint):
    pass
