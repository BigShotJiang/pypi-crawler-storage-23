from ._base import Endpoint


class Docker(Endpoint):
    pass
