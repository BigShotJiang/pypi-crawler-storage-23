from ._base import Endpoint


class IPNeighbors(Endpoint):
    pass
