from ._base import Endpoint


class Netbird(Endpoint):
    pass
