from ._base import Endpoint


class Services(Endpoint):
    pass
