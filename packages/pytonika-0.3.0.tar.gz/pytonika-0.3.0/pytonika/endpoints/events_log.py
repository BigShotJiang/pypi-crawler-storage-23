from ._base import Endpoint


class EventsLog(Endpoint):
    pass
