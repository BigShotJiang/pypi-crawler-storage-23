from ._base import Endpoint


class DLNA(Endpoint):
    pass
