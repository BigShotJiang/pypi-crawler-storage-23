from ._base import Endpoint


class Serial(Endpoint):
    pass
