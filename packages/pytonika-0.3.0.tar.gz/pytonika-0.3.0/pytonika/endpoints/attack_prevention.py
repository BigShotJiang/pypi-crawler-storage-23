from ._base import Endpoint


class AttackPrevention(Endpoint):
    pass
