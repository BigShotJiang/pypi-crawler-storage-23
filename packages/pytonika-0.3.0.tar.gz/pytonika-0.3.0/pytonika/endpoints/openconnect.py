from ._base import Endpoint


class OpenConnect(Endpoint):
    pass
