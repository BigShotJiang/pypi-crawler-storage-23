from ._base import Endpoint


class PortMirroring(Endpoint):
    pass
