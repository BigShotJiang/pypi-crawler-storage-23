from ._base import Endpoint


class OperatorLists(Endpoint):
    pass
