from ._base import Endpoint


class Refresh(Endpoint):
    pass
