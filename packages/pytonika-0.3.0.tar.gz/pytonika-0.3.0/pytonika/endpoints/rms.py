from ._base import Endpoint


class RMS(Endpoint):
    pass
