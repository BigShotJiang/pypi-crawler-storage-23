from ._base import Endpoint


class EIGRP(Endpoint):
    pass
