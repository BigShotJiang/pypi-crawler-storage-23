from ._base import Endpoint


class IPSec(Endpoint):
    pass
