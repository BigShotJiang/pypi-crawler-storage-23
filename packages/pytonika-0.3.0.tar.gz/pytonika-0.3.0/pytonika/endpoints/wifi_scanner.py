from ._base import Endpoint


class WiFiScanner(Endpoint):
    pass
