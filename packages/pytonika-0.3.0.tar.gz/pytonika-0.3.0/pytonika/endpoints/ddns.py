from ._base import Endpoint


class DDNS(Endpoint):
    pass
