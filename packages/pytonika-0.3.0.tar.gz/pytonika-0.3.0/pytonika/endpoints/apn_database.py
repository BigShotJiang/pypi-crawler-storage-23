from ._base import Endpoint


class APNDatabase(Endpoint):
    pass
