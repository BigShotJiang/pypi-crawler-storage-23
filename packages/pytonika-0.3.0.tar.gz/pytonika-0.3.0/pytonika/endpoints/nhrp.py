from ._base import Endpoint


class NHRP(Endpoint):
    pass
