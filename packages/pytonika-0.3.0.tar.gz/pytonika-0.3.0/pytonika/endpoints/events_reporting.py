from ._base import Endpoint


class EventsReporting(Endpoint):
    pass
