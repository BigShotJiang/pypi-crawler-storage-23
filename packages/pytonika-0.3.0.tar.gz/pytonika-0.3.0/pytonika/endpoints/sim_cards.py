from ._base import Endpoint


class SIMCards(Endpoint):
    pass
