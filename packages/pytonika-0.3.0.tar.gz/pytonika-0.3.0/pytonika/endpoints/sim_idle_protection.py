from ._base import Endpoint


class SIMIdleProtection(Endpoint):
    pass
