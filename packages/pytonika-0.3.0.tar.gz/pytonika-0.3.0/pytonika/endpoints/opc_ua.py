from ._base import Endpoint


class OPCUA(Endpoint):
    pass
