from ._base import Endpoint


class CallUtilities(Endpoint):
    pass
