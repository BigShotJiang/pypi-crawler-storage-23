from ._base import Endpoint


class NAT64(Endpoint):
    pass
