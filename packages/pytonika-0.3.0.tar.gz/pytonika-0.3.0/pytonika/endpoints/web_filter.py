from ._base import Endpoint


class WebFilter(Endpoint):
    pass
