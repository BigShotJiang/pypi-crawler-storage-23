from ._base import Endpoint


class Modbus(Endpoint):
    pass
