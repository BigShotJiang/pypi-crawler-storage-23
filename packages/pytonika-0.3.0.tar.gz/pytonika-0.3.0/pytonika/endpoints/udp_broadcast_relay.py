from ._base import Endpoint


class UDPBroadcastRelay(Endpoint):
    pass
