from ._base import Endpoint


class eSIM(Endpoint):
    pass
