from ._base import Endpoint


class DateTime(Endpoint):
    pass
