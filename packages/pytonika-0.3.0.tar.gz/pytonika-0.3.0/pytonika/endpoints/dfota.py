from ._base import Endpoint


class DFOTA(Endpoint):
    pass
