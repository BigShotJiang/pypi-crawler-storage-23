from ._base import Endpoint


class Messages(Endpoint):
    pass
