from ._base import Endpoint


class Modems(Endpoint):
    pass
