from ._base import Endpoint


class Certificates(Endpoint):
    pass
