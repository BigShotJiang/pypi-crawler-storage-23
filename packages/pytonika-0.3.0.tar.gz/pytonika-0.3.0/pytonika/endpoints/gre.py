from ._base import Endpoint


class GRE(Endpoint):
    pass
