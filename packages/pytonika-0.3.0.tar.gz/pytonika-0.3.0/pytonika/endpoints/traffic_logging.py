from ._base import Endpoint


class TrafficLogging(Endpoint):
    pass
