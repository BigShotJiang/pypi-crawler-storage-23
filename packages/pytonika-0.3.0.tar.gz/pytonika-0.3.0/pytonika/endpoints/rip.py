from ._base import Endpoint


class RIP(Endpoint):
    pass
