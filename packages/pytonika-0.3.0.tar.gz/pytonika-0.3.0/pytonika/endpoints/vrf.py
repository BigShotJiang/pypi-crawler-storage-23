from ._base import Endpoint


class VRF(Endpoint):
    pass
