from ._base import Endpoint


class PackageManager(Endpoint):
    pass
