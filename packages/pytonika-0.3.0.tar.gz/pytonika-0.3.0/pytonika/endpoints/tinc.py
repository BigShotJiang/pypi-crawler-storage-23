from ._base import Endpoint


class Tinc(Endpoint):
    pass
