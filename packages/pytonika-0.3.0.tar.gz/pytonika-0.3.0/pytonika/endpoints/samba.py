from ._base import Endpoint


class Samba(Endpoint):
    pass
