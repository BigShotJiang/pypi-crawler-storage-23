from ._base import Endpoint


class MQTT(Endpoint):
    pass
