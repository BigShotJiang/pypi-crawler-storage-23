from ._base import Endpoint


class RoutingTables(Endpoint):
    pass
