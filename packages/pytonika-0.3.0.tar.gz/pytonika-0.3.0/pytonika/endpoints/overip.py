from ._base import Endpoint


class OverIP(Endpoint):
    pass
