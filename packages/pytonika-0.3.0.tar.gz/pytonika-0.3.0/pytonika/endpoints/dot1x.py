from ._base import Endpoint


class Dot1X(Endpoint):
    pass
