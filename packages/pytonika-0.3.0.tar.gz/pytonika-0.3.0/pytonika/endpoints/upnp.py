from ._base import Endpoint


class UPnP(Endpoint):
    pass
