from ._base import Endpoint


class InputOutput(Endpoint):
    pass
