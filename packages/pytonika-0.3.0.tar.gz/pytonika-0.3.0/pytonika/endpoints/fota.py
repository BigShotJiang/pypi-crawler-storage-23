from ._base import Endpoint


class FOTA(Endpoint):
    pass
