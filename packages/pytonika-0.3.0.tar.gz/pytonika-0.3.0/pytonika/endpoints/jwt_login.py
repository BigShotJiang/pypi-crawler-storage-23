from ._base import Endpoint


class JWTLogin(Endpoint):
    pass
