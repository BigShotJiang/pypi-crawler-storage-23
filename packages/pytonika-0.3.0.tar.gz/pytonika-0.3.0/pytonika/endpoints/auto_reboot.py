from ._base import Endpoint


class AutoReboot(Endpoint):
    pass
