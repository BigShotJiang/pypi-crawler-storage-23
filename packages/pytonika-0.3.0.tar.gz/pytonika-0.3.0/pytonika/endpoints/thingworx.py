from ._base import Endpoint


class Thingworx(Endpoint):
    pass
