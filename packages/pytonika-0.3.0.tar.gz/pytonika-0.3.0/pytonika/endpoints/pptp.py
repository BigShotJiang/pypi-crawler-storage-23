from ._base import Endpoint


class PPTP(Endpoint):
    pass
