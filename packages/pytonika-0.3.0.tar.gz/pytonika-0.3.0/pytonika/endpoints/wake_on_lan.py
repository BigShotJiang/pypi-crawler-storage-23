from ._base import Endpoint


class WakeOnLan(Endpoint):
    pass
