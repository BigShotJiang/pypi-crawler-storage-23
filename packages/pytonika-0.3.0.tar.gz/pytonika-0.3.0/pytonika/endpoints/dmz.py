from ._base import Endpoint


class DMZ(Endpoint):
    pass
