from ._base import Endpoint


class OSPF(Endpoint):
    pass
