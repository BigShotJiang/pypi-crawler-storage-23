from ._base import Endpoint


class InternetConnection(Endpoint):
    pass
