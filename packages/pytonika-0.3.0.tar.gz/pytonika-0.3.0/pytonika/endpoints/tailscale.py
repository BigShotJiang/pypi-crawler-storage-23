from ._base import Endpoint


class Tailscale(Endpoint):
    pass
