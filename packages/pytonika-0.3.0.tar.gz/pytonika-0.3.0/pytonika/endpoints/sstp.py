from ._base import Endpoint


class SSTP(Endpoint):
    pass
