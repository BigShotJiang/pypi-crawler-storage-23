from ._base import Endpoint


class ModemControl(Endpoint):
    pass
