from ._base import Endpoint


class Cumulocity(Endpoint):
    pass
