from ._base import Endpoint


class SNMP(Endpoint):
    pass
