from ._base import Endpoint


class OpenVPN(Endpoint):
    pass
