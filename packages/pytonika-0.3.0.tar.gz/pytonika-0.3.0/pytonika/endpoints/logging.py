from ._base import Endpoint


class Logging(Endpoint):
    pass
