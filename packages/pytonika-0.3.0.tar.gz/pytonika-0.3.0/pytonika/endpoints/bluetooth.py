from ._base import Endpoint


class Bluetooth(Endpoint):
    pass
