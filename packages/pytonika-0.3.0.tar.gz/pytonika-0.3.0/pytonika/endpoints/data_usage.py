from ._base import Endpoint


class DataUsage(Endpoint):
    pass
