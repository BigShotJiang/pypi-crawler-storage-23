from ._base import Endpoint


class Network(Endpoint):
    pass
