from ._base import Endpoint


class Console(Endpoint):
    pass
