from ._base import Endpoint


class BGP(Endpoint):
    pass
