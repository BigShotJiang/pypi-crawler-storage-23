from ._base import Endpoint


class CustomScripts(Endpoint):
    pass
