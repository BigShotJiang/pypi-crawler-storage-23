from ._base import Endpoint


class EmailRelay(Endpoint):
    pass
