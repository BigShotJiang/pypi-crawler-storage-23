from ._base import Endpoint


class NetworkUsage(Endpoint):
    pass
