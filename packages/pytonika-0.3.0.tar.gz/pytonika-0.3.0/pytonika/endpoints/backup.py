from ._base import Endpoint


class Backup(Endpoint):
    pass
