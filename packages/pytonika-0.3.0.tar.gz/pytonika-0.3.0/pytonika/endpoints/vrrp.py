from ._base import Endpoint


class VRRP(Endpoint):
    pass
