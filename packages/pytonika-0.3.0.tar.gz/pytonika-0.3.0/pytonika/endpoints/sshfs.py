from ._base import Endpoint


class SSHFS(Endpoint):
    pass
