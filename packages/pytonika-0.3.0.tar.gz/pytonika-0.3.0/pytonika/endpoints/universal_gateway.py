from ._base import Endpoint


class UniversalGateway(Endpoint):
    pass
