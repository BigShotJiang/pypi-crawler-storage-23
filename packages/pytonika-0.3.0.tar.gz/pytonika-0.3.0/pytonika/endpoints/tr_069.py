from ._base import Endpoint


class TR069(Endpoint):
    pass
