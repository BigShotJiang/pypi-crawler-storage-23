from ._base import Endpoint


class QoS(Endpoint):
    pass
