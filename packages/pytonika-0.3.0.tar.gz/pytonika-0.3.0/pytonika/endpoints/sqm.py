from ._base import Endpoint


class SQM(Endpoint):
    pass
