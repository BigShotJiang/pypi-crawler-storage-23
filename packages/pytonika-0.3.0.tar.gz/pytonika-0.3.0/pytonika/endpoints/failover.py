from ._base import Endpoint


class Failover(Endpoint):
    pass
