from ._base import Endpoint


class PortsSettings(Endpoint):
    pass
