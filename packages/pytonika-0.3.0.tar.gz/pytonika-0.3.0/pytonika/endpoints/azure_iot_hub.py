from ._base import Endpoint


class AzureIoTHub(Endpoint):
    pass
