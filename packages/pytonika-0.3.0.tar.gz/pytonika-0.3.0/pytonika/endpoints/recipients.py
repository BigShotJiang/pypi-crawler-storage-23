from ._base import Endpoint


class Recipients(Endpoint):
    pass
