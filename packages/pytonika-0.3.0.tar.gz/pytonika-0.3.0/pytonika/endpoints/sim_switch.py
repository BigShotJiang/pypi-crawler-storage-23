from ._base import Endpoint


class SIMSwitch(Endpoint):
    pass
