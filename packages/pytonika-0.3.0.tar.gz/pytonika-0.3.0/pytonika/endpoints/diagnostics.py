from ._base import Endpoint


class Diagnostics(Endpoint):
    pass
