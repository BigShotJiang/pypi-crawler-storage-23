from ._base import Endpoint


class EventJuggler(Endpoint):
    pass
