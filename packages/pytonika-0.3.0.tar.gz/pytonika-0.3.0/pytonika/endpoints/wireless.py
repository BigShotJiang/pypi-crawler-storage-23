from ._base import Endpoint


class Wireless(Endpoint):
    pass
