from ._base import Endpoint


class DNP3(Endpoint):
    pass
