from ._base import Endpoint


class DataToServer(Endpoint):
    pass
