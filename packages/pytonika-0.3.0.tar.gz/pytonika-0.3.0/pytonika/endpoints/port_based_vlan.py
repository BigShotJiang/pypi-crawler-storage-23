from ._base import Endpoint


class PortBasedVlan(Endpoint):
    pass
