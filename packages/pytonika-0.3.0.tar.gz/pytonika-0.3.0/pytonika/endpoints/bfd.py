from ._base import Endpoint


class BFD(Endpoint):
    pass
