from ._base import Endpoint


class IPRoutes(Endpoint):
    pass
