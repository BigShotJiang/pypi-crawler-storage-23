from ._base import Endpoint


class SMSGateway(Endpoint):
    pass
