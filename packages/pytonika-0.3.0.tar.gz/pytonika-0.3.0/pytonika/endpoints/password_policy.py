from ._base import Endpoint


class PasswordPolicy(Endpoint):
    pass
