from ._base import Endpoint


class Hotspot2(Endpoint):
    pass
