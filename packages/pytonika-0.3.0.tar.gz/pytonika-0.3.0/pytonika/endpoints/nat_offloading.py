from ._base import Endpoint


class NATOffloading(Endpoint):
    pass
