from ._base import Endpoint


class Relayd(Endpoint):
    pass
