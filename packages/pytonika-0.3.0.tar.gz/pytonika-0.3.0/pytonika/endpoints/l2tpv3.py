from ._base import Endpoint


class L2TPv3(Endpoint):
    pass
