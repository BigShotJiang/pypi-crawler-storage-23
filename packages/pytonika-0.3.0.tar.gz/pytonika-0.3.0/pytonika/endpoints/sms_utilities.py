from ._base import Endpoint


class SMSUtilities(Endpoint):
    pass
