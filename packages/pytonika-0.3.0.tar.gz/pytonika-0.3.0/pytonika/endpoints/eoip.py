from ._base import Endpoint


class EoIP(Endpoint):
    pass
