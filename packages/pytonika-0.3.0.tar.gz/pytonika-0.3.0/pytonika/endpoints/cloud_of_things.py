from ._base import Endpoint


class CloudOfThings(Endpoint):
    pass
