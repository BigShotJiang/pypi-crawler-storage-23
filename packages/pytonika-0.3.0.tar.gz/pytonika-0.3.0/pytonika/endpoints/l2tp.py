from ._base import Endpoint


class L2TP(Endpoint):
    pass
