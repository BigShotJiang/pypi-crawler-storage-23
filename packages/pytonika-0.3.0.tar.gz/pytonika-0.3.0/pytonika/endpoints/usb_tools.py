from ._base import Endpoint


class UsbTools(Endpoint):
    pass
