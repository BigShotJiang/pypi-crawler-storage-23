from ._base import Endpoint


class Topology(Endpoint):
    pass
