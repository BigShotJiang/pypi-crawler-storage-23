"""AppKit MCP Charts component."""
