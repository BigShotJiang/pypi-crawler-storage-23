"""Burrow SDK logging configuration."""

import logging

logger = logging.getLogger("burrow")
