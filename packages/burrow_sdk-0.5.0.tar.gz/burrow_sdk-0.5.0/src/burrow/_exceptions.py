"""Burrow exception hierarchy."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from burrow import ScanResult


class BurrowError(Exception):
    """Base exception for all Burrow SDK errors."""


class BurrowBlockedError(BurrowError):
    """Raised when a scan result indicates the content was blocked."""

    def __init__(self, result: ScanResult):
        self.result = result
        super().__init__(f"Burrow blocked: {result.category} ({result.confidence:.0%} confidence)")


class BurrowTimeoutError(BurrowError):
    """Raised when a Burrow API request times out."""
