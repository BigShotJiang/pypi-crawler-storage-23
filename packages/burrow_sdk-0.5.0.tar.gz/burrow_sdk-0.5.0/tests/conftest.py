"""Shared test fixtures for Burrow SDK tests."""

from __future__ import annotations

import httpx
import pytest

from burrow import BurrowGuard, ScanResult


def _make_scan_response(
    action: str = "allow",
    confidence: float = 0.95,
    category: str = "benign",
    request_id: str = "req-test-123",
    latency_ms: float = 12.5,
) -> dict:
    """Create a mock scan API response body."""
    return {
        "action": action,
        "confidence": confidence,
        "category": category,
        "request_id": request_id,
        "latency_ms": latency_ms,
    }


def _make_token_response(
    access_token: str = "test-jwt-token",
    expires_in: int = 3600,
) -> dict:
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "expires_in": expires_in,
    }


def _mock_transport(scan_response: dict | None = None, token_response: dict | None = None):
    """Create an httpx.MockTransport that handles token + scan requests."""
    scan_resp = scan_response or _make_scan_response()
    token_resp = token_response or _make_token_response()

    def handler(request: httpx.Request) -> httpx.Response:
        if "/oauth/token" in str(request.url):
            return httpx.Response(200, json=token_resp)
        if "/v1/scan" in str(request.url):
            return httpx.Response(200, json=scan_resp)
        return httpx.Response(404, text="Not Found")

    return httpx.MockTransport(handler)


@pytest.fixture
def mock_guard() -> BurrowGuard:
    """BurrowGuard with mocked HTTP transport that returns 'allow'."""
    guard = BurrowGuard(
        client_id="test-client",
        client_secret="test-secret",
        api_url="https://api.test.burrow.run",
        auth_url="https://auth.test.burrow.run",
    )
    transport = _mock_transport()
    guard._client = httpx.Client(base_url=guard.api_url, transport=transport)
    # Pre-set token to avoid auth call from scan path
    guard._access_token = "test-jwt-token"
    guard._token_expires_at = 9999999999.0
    return guard


@pytest.fixture
def blocked_guard() -> BurrowGuard:
    """BurrowGuard with mocked HTTP transport that returns 'block'."""
    guard = BurrowGuard(
        client_id="test-client",
        client_secret="test-secret",
        api_url="https://api.test.burrow.run",
        auth_url="https://auth.test.burrow.run",
    )
    transport = _mock_transport(
        scan_response=_make_scan_response(
            action="block", category="injection_detected", confidence=0.98
        )
    )
    guard._client = httpx.Client(base_url=guard.api_url, transport=transport)
    guard._access_token = "test-jwt-token"
    guard._token_expires_at = 9999999999.0
    return guard


@pytest.fixture
def warn_guard() -> BurrowGuard:
    """BurrowGuard with mocked HTTP transport that returns 'warn'."""
    guard = BurrowGuard(
        client_id="test-client",
        client_secret="test-secret",
        api_url="https://api.test.burrow.run",
        auth_url="https://auth.test.burrow.run",
    )
    transport = _mock_transport(
        scan_response=_make_scan_response(
            action="warn", category="suspicious_pattern", confidence=0.72
        )
    )
    guard._client = httpx.Client(base_url=guard.api_url, transport=transport)
    guard._access_token = "test-jwt-token"
    guard._token_expires_at = 9999999999.0
    return guard


@pytest.fixture
def allow_result() -> ScanResult:
    return ScanResult(
        action="allow",
        confidence=0.95,
        category="benign",
        request_id="req-test-123",
        latency_ms=12.5,
    )


@pytest.fixture
def block_result() -> ScanResult:
    return ScanResult(
        action="block",
        confidence=0.98,
        category="injection_detected",
        request_id="req-test-456",
        latency_ms=15.0,
    )


@pytest.fixture
def warn_result() -> ScanResult:
    return ScanResult(
        action="warn",
        confidence=0.72,
        category="suspicious_pattern",
        request_id="req-test-789",
        latency_ms=11.0,
    )
