"""Unit tests for ScanResult and ScanAction."""

from burrow import ScanAction


class TestScanAction:
    def test_enum_values(self):
        assert ScanAction.ALLOW == "allow"
        assert ScanAction.WARN == "warn"
        assert ScanAction.BLOCK == "block"

    def test_string_comparison(self):
        assert ScanAction.ALLOW == "allow"
        assert ScanAction.BLOCK != "allow"


class TestScanResult:
    def test_is_blocked(self, block_result):
        assert block_result.is_blocked is True
        assert block_result.is_allowed is False
        assert block_result.is_warning is False

    def test_is_allowed(self, allow_result):
        assert allow_result.is_allowed is True
        assert allow_result.is_blocked is False
        assert allow_result.is_warning is False

    def test_is_warning(self, warn_result):
        assert warn_result.is_warning is True
        assert warn_result.is_blocked is False
        assert warn_result.is_allowed is False

    def test_fields(self, allow_result):
        assert allow_result.action == "allow"
        assert allow_result.confidence == 0.95
        assert allow_result.category == "benign"
        assert allow_result.request_id == "req-test-123"
        assert allow_result.latency_ms == 12.5
