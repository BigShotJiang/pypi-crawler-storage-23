# Changelog

## [Unreleased]

### Added
- **ADK tool-level hooks**: `create_burrow_tool_callback_v2()` and `create_burrow_after_tool_callback_v2()` for scanning individual tool calls with `tool_name` and `tool_args` (previously only model-level callbacks were available)
- **Strands V1 `block_on_warn`**: `create_burrow_hook_provider()` now accepts `block_on_warn` parameter, matching V2 behavior
- **Unit tests for all adapters**: Added comprehensive test suites for CrewAI, LangChain, OpenAI Agents, ADK, Strands, and Claude SDK integrations (216 new tests)
- **Integration matrix in README**: Per-agent support, scan coverage, and known limitations documented for all adapters

### Changed
- **Claude SDK hooks (BREAKING)**: `create_burrow_hooks()` now returns `{"PreToolUse": [HookMatcher(...)], "PostToolUse": [HookMatcher(...)]}` matching the Claude Agent SDK event-based hook format. Previously returned `{"on_user_message": fn, "on_tool_call": fn, "on_tool_result": fn}`.

### Fixed
- **Strands silent block failure**: When a blocked tool result was not a dict with `toolUseId`, the V1 and V2 `_scan_tool_result` methods now correctly replace `event.result` with the blocked message string instead of passing through the original (potentially malicious) content unchanged
- **OpenAI Agents tool scanning docs**: Added explicit documentation noting the SDK's architectural limitation preventing tool-level scanning, with workaround using `guard.scan()` directly

## 0.5.0 (2026-02-15)

- Initial standalone release (migrated from lattice monorepo)
- Import path: `from burrow import BurrowGuard`
- Integrations: `from burrow.integrations.{framework} import ...`
- Added exception hierarchy (`BurrowError`, `BurrowBlockedError`, `BurrowTimeoutError`)
- Added structured logging via `logging.getLogger("burrow")`
- Added retry transport (`retries=2`) for resilience
- Added `py.typed` PEP 561 marker for type checker support
- Default API URL changed to `https://api.burrow.run`
- Package renamed from `burrow-ai` to `burrow-sdk`
- Build backend migrated from setuptools to hatchling
