from __future__ import annotations

from module_qc_database_tools.db import local, prod

__all__ = ("local", "prod")
