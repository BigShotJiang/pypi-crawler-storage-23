from __future__ import annotations

from module_qc_database_tools.cli.main import app

app()
