# Authors

---

## Maintainers

- Lingxin Meng (@lmeng)
- Giordon Stark (@gstark) [:material-web:](https://giordonstark.com)
  [:material-github:](https://github.com/kratsg)
  [:material-twitter:](https://twitter.com/kratsg)

## Contributors

- Emily Anne Thompson (@emily)
- Jay Chan (@cchan)
- Hideyuki Oide (@hoide)
- Timon Heim (@theim) # codespell:ignore theim
