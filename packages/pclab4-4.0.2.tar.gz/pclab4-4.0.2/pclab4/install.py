from setuptools import setup, find_packages

myinfo={'author': 'S_My',
        'email': 'mingyang3sun@hotmail.com',
        'copyright':'Copyright (c) 2025-2026, S_My Programming Team & '\
                    'KitPy Developers'}

def confirm_info(all_modules):
    '''Confirm name, version of a module.'''
    name = all_modules.__name__
    version = all_modules.__version__
    return name, version
    
def pkg_setup(package, **attrs):
    '''packages' setup. Need version string(__version__).\n
       **attrs: except `name`, `version` and `packages`.'''
    _name, _version= confirm_info(package)
    setup(name=_name, packages=find_packages(), version=_version, **attrs)
    
def my_setup(pkg, **attrs):
    '''S_My setup tools.'''
    pkg_setup(pkg, 
              classifiers = ['Operating System :: Microsoft :: Windows :: Windows 11',
                             'Programming Language :: Python :: 3',
                             'Programming Language :: Python :: 3.9',
                             'License :: OSI Approved :: MIT License',],
              long_description = pkg.__doc__,
              long_description_content_type='text/x-rst',
              license=f"MIT License({myinfo['copyright']})",
              author=myinfo['author'],
              author_email=myinfo['email'],
              **attrs)
