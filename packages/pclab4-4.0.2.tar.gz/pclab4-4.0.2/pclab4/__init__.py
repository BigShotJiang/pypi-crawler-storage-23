'''
pclab4
======

A Python Library of pedal curves.

How to use
----------
We recommend you to import `pclab4`:\n
  >>> import pclab4
  >>> pclab4.deriv(lambda x: x**3, 2)
  12.000099999999847
  
Use the built-in ``help`` function to view a function's docstring:\n
  >>> help(pclab4.deriv)
  ... # doctest: +SKIP
  
Viewing documentation using IPython
-----------------------------------
To see which functions are available in `pclab4`, type ``pclab4.<TAB>`` (where
``<TAB>`` refers to the TAB key), or use ``pclab4.*deriv*?<ENTER>`` (where 
``<ENTER>`` refers to the ENTER key) to narrow down the list.  To view the 
docstring for a function, use ``pclab4.deriv?<ENTER>`` (to view the docstring) 
and ``pclab4.deriv??<ENTER>`` (to view the source code).

We recommend exploring the docstrings using `IPython <https://ipython.org>`_, 
an advanced Python shell with TAB-completion and introspection capabilities. 
See above for further instructions.
  
Click `pclab4 Homepage <https://pypi.org/project/pclab4/>`_ to explore.'''
from .basic import deriv, PC
from .pcplot import plot
from .pcanim import anim
from .install import my_setup, myinfo

__version__ = '4.0.2'