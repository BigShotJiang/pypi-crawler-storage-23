'''This is a module of the library PCPyLib for basic things:\n
   deriv(func), PC(class)'''
   
from numpy import (linspace, sin, cos, tan, sinh, cosh, tanh, arcsin, arccos, 
                   arctan, arcsinh, arccosh, arctanh, degrees, radians, sqrt,
                   log10, round, floor, ceil, sign, exp, log)
from scipy.special import gamma, erf

def deriv(f0, x, h=0.01):
    '''This is the derivative of a function.
    
       Parameters
       ----------
       f0(func), x(num), h(*kwargs)
       
       Returns
       -------
       the derivative of the function'''
    return (f0(x + h) - f0(x - h))/(2*h)
class PC():
    '''
    PC
    ==
    This is a class of the calculation of pedal curves.\n
    Parameters
    ----------
    fx_str1(str), px1, py1(x, y of the point)
    
    Returns
    -------
    a, b: x, y of the function\n
    x, y: x, y of pedal curves'''
    def __init__(self, fx_str1, px1, py1):
        self.a = linspace(-5, 5, 10000)
        def f(x):
            return eval(fx_str1)
        self.b = f(self.a)
        d = deriv(f, self.a)
        self.x = (self.a*d**2 + d*(py1 - self.b) + px1)/(d**2 + 1)
        self.y = (py1*d**2 + self.b + px1 - self.a)/(d**2 + 1)
        return