import pclab4

pclab4.my_setup(pclab4,
      install_requires=["numpy>=1.26.4",
                        "matplotlib>=3.9.2",
                        "scipy>=1.13.1",],
      description='Pedal Curves Lab Version 4',
      python_requires='>=3.9',
      url='https://pypi.org/project/pclab4/'
      )