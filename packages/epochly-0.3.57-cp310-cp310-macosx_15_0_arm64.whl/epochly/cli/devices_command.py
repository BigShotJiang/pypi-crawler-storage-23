"""
CLI commands for multi-device management in Epochly.

Provides subcommands for managing device slots:
  - list:   Show all devices for the current license with seat counts
  - rename: Rename a device slot
  - remove: Remove a device from a slot
  - sync:   Force device sync with the server

Design:
  - API-first: All server communication goes through the public API.
  - Device context: Reads ``~/.epochly/device.json`` for local device state.
  - Cross-platform: Uses ``pathlib.Path.home()`` for home directory resolution
    (works on Windows, Linux, and macOS).
"""

import json
import logging
import os
import re
import sys
from pathlib import Path
from typing import Optional

import requests

from epochly.config.api_endpoints import APIEndpoints

logger = logging.getLogger(__name__)

# Device name validation pattern: lowercase alphanumeric and hyphens,
# 2-64 chars, must start and end with alphanumeric
DEVICE_NAME_PATTERN = re.compile(r'^[a-z0-9][a-z0-9-]{0,62}[a-z0-9]$')

# Timeout for API calls (seconds), overridable via env var
_DEFAULT_TIMEOUT = 10


def _get_api_timeout() -> int:
    """Return API timeout in seconds, respecting EPOCHLY_API_TIMEOUT."""
    try:
        return int(os.environ.get('EPOCHLY_API_TIMEOUT', str(_DEFAULT_TIMEOUT)))
    except ValueError:
        return _DEFAULT_TIMEOUT


def _device_json_path() -> Path:
    """Return the path to ``~/.epochly/device.json``."""
    return Path.home() / '.epochly' / 'device.json'


def _license_key_path() -> Path:
    """Return the path to ``~/.epochly/license.key``."""
    return Path.home() / '.epochly' / 'license.key'


def _read_device_json() -> Optional[dict]:
    """Read and return the device.json data, or None on any error."""
    path = _device_json_path()
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (json.JSONDecodeError, OSError, ValueError):
        return None


def _read_license_key() -> Optional[str]:
    """Read the license key from disk, or None if not present."""
    path = _license_key_path()
    if not path.exists():
        return None
    try:
        return path.read_text(encoding='utf-8').strip()
    except (OSError, ValueError):
        return None


def _validate_device_name(name: str) -> bool:
    """Validate a device name against the naming rules.

    Rules:
      - Lowercase alphanumeric and hyphens only
      - 2-64 characters
      - Must start and end with alphanumeric character

    Args:
        name: The device name to validate.

    Returns:
        True if valid, False otherwise.
    """
    return bool(DEVICE_NAME_PATTERN.match(name))


def list_devices() -> int:
    """List all device slots for the current license.

    Reads ``~/.epochly/device.json`` for the subscription_id, then
    calls GET ``/v1/devices/list`` to get the current device list.

    Returns:
        0 on success, 1 on error.
    """
    device_data = _read_device_json()
    if not device_data:
        print(
            'Error: This device is not registered. '
            'Run "epochly activate <key>" first.',
            file=sys.stderr,
        )
        return 1

    subscription_id = device_data.get('subscription_id', '')
    endpoint = APIEndpoints.get_endpoint('device_list')
    timeout = _get_api_timeout()

    try:
        resp = requests.get(
            endpoint,
            params={'subscription_id': subscription_id},
            headers=APIEndpoints.get_headers(),
            timeout=timeout,
        )
    except requests.exceptions.RequestException as exc:
        logger.debug('Device list API request failed: %s', exc)
        print(
            'Error: Could not reach the Epochly device service. '
            'Please check your internet connection and try again.',
            file=sys.stderr,
        )
        return 1

    if not resp.ok:
        logger.debug('Device list API returned %d: %s', resp.status_code, resp.text[:200])
        print(
            f'Error: Unexpected response from device service '
            f'(HTTP {resp.status_code}). Please try again later.',
            file=sys.stderr,
        )
        return 1

    data = resp.json()

    # Display header
    seats_used = data.get('seats_used', 0)
    seats_total = data.get('seats_total', 0)
    plan_name = data.get('plan_name', 'Unknown Plan')
    sub_status = data.get('subscription_status', 'unknown')

    print(f'Epochly Device Slots ({plan_name})')
    print('=' * 50)
    print(f'  Seats: {seats_used}/{seats_total} active')
    print(f'  Subscription: {sub_status}')
    print()

    devices = data.get('devices', [])
    if not devices:
        print('  No devices registered.')
        return 0

    # Format device list
    print(f'  {"Slot Name":<25} {"Status":<12} {"Last Seen"}')
    print(f'  {"-" * 25} {"-" * 12} {"-" * 20}')

    for device in devices:
        slot = device.get('slot_name', 'N/A')
        status = device.get('status', 'unknown')
        heartbeat = device.get('last_heartbeat', 'never')
        if heartbeat and heartbeat != 'never':
            # Show only date + time portion
            heartbeat = heartbeat[:19].replace('T', ' ')
        print(f'  {slot:<25} {status:<12} {heartbeat}')

    print()
    return 0


def rename_device(old_name: str, new_name: str) -> int:
    """Rename a device slot.

    Validates the new name format, then POSTs to ``/v1/devices/rename``.

    Args:
        old_name: Current device slot name.
        new_name: Desired new device slot name.

    Returns:
        0 on success, 1 on error.
    """
    device_data = _read_device_json()
    if not device_data:
        print(
            'Error: This device is not registered. '
            'Run "epochly activate <key>" first.',
            file=sys.stderr,
        )
        return 1

    # Validate new name format
    if not _validate_device_name(new_name):
        print(
            f'Error: Invalid device name "{new_name}". '
            'Names must be 2-64 characters, lowercase alphanumeric and hyphens, '
            'starting and ending with alphanumeric.',
            file=sys.stderr,
        )
        return 1

    subscription_id = device_data.get('subscription_id', '')
    endpoint = APIEndpoints.get_endpoint('device_rename')
    timeout = _get_api_timeout()

    payload = {
        'subscription_id': subscription_id,
        'old_name': old_name,
        'new_name': new_name,
    }

    try:
        resp = requests.post(
            endpoint,
            json=payload,
            headers=APIEndpoints.get_headers(),
            timeout=timeout,
        )
    except requests.exceptions.RequestException as exc:
        logger.debug('Device rename API request failed: %s', exc)
        print(
            'Error: Could not reach the Epochly device service. '
            'Please check your internet connection and try again.',
            file=sys.stderr,
        )
        return 1

    if resp.status_code == 409:
        print(
            f'Error: Name conflict -- "{new_name}" is already in use.',
            file=sys.stderr,
        )
        return 1

    if not resp.ok:
        logger.debug('Device rename API returned %d: %s', resp.status_code, resp.text[:200])
        print(
            f'Error: Unexpected response from device service '
            f'(HTTP {resp.status_code}). Please try again later.',
            file=sys.stderr,
        )
        return 1

    result = resp.json()
    print(f'Device renamed: "{old_name}" -> "{result.get("new_name", new_name)}"')

    # Update local device.json if the renamed device is this one
    if device_data.get('slot_name') == old_name or device_data.get('device_name') == old_name:
        device_data['slot_name'] = new_name
        device_data['device_name'] = new_name
        _device_json_path().write_text(json.dumps(device_data, indent=2))

    return 0


def remove_device(slot_name: str, force: bool = False) -> int:
    """Remove a device from a slot.

    Asks for confirmation unless ``--force`` is set.

    Args:
        slot_name: The device slot name to remove.
        force: Skip confirmation prompt if True.

    Returns:
        0 on success, 1 on error.
    """
    device_data = _read_device_json()
    if not device_data:
        print(
            'Error: This device is not registered. '
            'Run "epochly activate <key>" first.',
            file=sys.stderr,
        )
        return 1

    # Confirmation prompt unless force
    if not force:
        try:
            answer = input(f'Remove device "{slot_name}"? This frees the seat. [y/N] ')
        except (EOFError, KeyboardInterrupt):
            print('\nCancelled.')
            return 0
        if answer.strip().lower() != 'y':
            print('Cancelled.')
            return 0

    subscription_id = device_data.get('subscription_id', '')
    endpoint = APIEndpoints.get_endpoint('device_remove')
    timeout = _get_api_timeout()

    payload = {
        'subscription_id': subscription_id,
        'slot_name': slot_name,
    }

    try:
        resp = requests.post(
            endpoint,
            json=payload,
            headers=APIEndpoints.get_headers(),
            timeout=timeout,
        )
    except requests.exceptions.RequestException as exc:
        logger.debug('Device remove API request failed: %s', exc)
        print(
            'Error: Could not reach the Epochly device service. '
            'Please check your internet connection and try again.',
            file=sys.stderr,
        )
        return 1

    if not resp.ok:
        logger.debug('Device remove API returned %d: %s', resp.status_code, resp.text[:200])
        print(
            f'Error: Unexpected response from device service '
            f'(HTTP {resp.status_code}). Please try again later.',
            file=sys.stderr,
        )
        return 1

    result = resp.json()
    seats_used = result.get('seats_used', '?')
    seats_total = result.get('seats_total', '?')
    print(f'Device "{slot_name}" removed. Seats: {seats_used}/{seats_total} active.')

    # If removing this device, delete local device.json
    if device_data.get('slot_name') == slot_name or device_data.get('device_name') == slot_name:
        device_json = _device_json_path()
        if device_json.exists():
            device_json.unlink()

    return 0


def sync_device() -> int:
    """Force device sync with the server.

    Reads local device.json and license.key, then POSTs to
    ``/v1/devices/sync`` to verify and update device state.

    Returns:
        0 on success, 1 on error.
    """
    device_data = _read_device_json()
    license_key = _read_license_key()

    if not device_data:
        print(
            'Error: This device is not registered. '
            'Run "epochly activate <key>" first.',
            file=sys.stderr,
        )
        return 1

    if not license_key:
        print(
            'Error: No license key found. '
            'Run "epochly activate <key>" first.',
            file=sys.stderr,
        )
        return 1

    endpoint = APIEndpoints.get_endpoint('device_sync')
    timeout = _get_api_timeout()

    payload = {
        'license_key': license_key,
        'device_name': device_data.get('device_name', ''),
        'subscription_id': device_data.get('subscription_id', ''),
    }

    try:
        resp = requests.post(
            endpoint,
            json=payload,
            headers=APIEndpoints.get_headers(),
            timeout=timeout,
        )
    except requests.exceptions.RequestException as exc:
        logger.debug('Device sync API request failed: %s', exc)
        print(
            'Error: Could not reach the Epochly device service. '
            'Please check your internet connection and try again.',
            file=sys.stderr,
        )
        return 1

    if not resp.ok:
        logger.debug('Device sync API returned %d: %s', resp.status_code, resp.text[:200])
        print(
            f'Error: Unexpected response from device service '
            f'(HTTP {resp.status_code}). Please try again later.',
            file=sys.stderr,
        )
        return 1

    result = resp.json()
    status = result.get('status', 'unknown')
    seats_used = result.get('seats_used', '?')
    seats_total = result.get('seats_total', '?')
    next_sync = result.get('next_sync_seconds', 3600)

    print(f'Device sync: {status}')
    print(f'  Seats: {seats_used}/{seats_total} active')
    print(f'  Next sync in: {next_sync // 60} minutes')

    # Update local device.json with latest seat counts
    if isinstance(seats_used, int) and isinstance(seats_total, int):
        device_data['seats_used'] = seats_used
        device_data['seats_total'] = seats_total
        _device_json_path().write_text(json.dumps(device_data, indent=2))

    return 0
