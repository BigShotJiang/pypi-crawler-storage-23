"""
CLI commands for billing and subscription management in Epochly.

Provides subcommands for managing Epochly Pro subscriptions:
  - portal:  Request a portal link be sent to your email
  - status:  Show current subscription status from local cache
  - cancel:  Display step-by-step cancellation instructions

Design:
  - API-first: All server communication goes through the public API
    (``POST /billing/send-portal-link``). No direct AWS SDK calls.
  - Email discovery: ``--email`` flag > ``~/.epochly/license_cache.json`` > prompt.
  - Cross-platform: Uses ``pathlib.Path.home()`` for home directory resolution
    (works on Windows, Linux, and macOS).
"""

import json
import logging
import os
import sys
from pathlib import Path
from typing import Optional

import requests

from epochly.config.api_endpoints import APIEndpoints

logger = logging.getLogger(__name__)

# Billing portal endpoint path
BILLING_PORTAL_PATH = '/billing/send-portal-link'

# Timeout for API calls (seconds), overridable via env var
_DEFAULT_TIMEOUT = 10


def _get_api_timeout() -> int:
    """Return API timeout in seconds, respecting EPOCHLY_API_TIMEOUT."""
    try:
        return int(os.environ.get('EPOCHLY_API_TIMEOUT', str(_DEFAULT_TIMEOUT)))
    except ValueError:
        return _DEFAULT_TIMEOUT


def _license_cache_path() -> Path:
    """Return the path to ``~/.epochly/license_cache.json``."""
    return Path.home() / '.epochly' / 'license_cache.json'


def _read_license_cache() -> dict:
    """Read and return the license cache JSON, or empty dict on any error."""
    cache_path = _license_cache_path()
    if not cache_path.exists():
        return {}
    try:
        return json.loads(cache_path.read_text(encoding='utf-8'))
    except (json.JSONDecodeError, OSError, ValueError):
        return {}


def _resolve_email(email: Optional[str] = None) -> Optional[str]:
    """Determine the user's email address.

    Priority:
      1. Explicit ``email`` parameter (from ``--email`` flag)
      2. Cached email in ``~/.epochly/license_cache.json``
      3. Interactive prompt

    Returns ``None`` only when the user provides an empty string at the prompt.
    """
    if email:
        return email.strip().lower()

    cached = _read_license_cache()
    cached_email = cached.get('email', '').strip()
    if cached_email:
        return cached_email.lower()

    # Interactive prompt
    try:
        prompted = input('Enter your subscription email address: ')
    except (EOFError, KeyboardInterrupt):
        return None

    return prompted.strip().lower() if prompted.strip() else None


def portal(email: Optional[str] = None) -> int:
    """Send a customer portal link to the user's email.

    Makes a POST request to the billing portal API endpoint.  The server
    sends an email containing customer portal URLs -- they are never
    returned in the API response for security reasons.

    Args:
        email: Email address.  If ``None``, attempts to read from the
               license cache or prompts interactively.

    Returns:
        0 on success, 1 on error.
    """
    resolved_email = _resolve_email(email)
    if not resolved_email or '@' not in resolved_email:
        print('Error: A valid email address is required.', file=sys.stderr)
        return 1

    api_url = f'{APIEndpoints.BASE_URL}{BILLING_PORTAL_PATH}'
    timeout = _get_api_timeout()

    try:
        resp = requests.post(
            api_url,
            json={'email': resolved_email},
            headers={'Content-Type': 'application/json'},
            timeout=timeout,
        )
    except requests.exceptions.RequestException as exc:
        logger.debug('Billing portal API request failed: %s', exc)
        print(
            'Error: Could not reach the Epochly billing service. '
            'Please check your internet connection and try again.',
            file=sys.stderr,
        )
        return 1

    if resp.status_code == 200:
        print(
            'Check your email -- if a subscription exists for that address, '
            "we've sent a portal link."
        )
        return 0

    # Unexpected status code
    logger.debug(
        'Billing portal API returned status %d: %s',
        resp.status_code,
        resp.text[:200],
    )
    print(
        f'Error: Unexpected response from billing service '
        f'(HTTP {resp.status_code}). Please try again later.',
        file=sys.stderr,
    )
    return 1


def status() -> int:
    """Show subscription status from local license cache.

    Reads ``~/.epochly/license_cache.json`` and displays tier, status,
    and email.  Does not make any API calls.

    Returns:
        0 always (informational command).
    """
    cached = _read_license_cache()

    if not cached or not cached.get('email'):
        print('No subscription found in local cache.')
        print(
            'If you have an active subscription, run '
            "'epochly billing portal' to request a portal link."
        )
        return 0

    tier = cached.get('tier', 'unknown').title()
    sub_status = cached.get('status', 'unknown').replace('_', ' ').title()
    email_addr = cached.get('email', 'unknown')

    print('Epochly Subscription Status')
    print('=' * 35)
    print(f'  Email:  {email_addr}')
    print(f'  Tier:   {tier}')
    print(f'  Status: {sub_status}')
    return 0


def cancel() -> int:
    """Display step-by-step cancellation instructions.

    Does not make any API calls or cancel anything automatically.
    Directs the user to the self-service portal.

    Returns:
        0 always (informational command).
    """
    print('How to Cancel Your Epochly Subscription')
    print('=' * 42)
    print()
    print('  1. Request a portal link:')
    print("       epochly billing portal --email you@example.com")
    print()
    print('  2. Check your inbox for an email from hello@epochly.com')
    print()
    print('  3. Click "Manage Subscription" in the email')
    print()
    print('  4. In the portal, click "Cancel Subscription"')
    print()
    print('  Or visit https://epochly.com/billing to request a portal link')
    print('  from the web.')
    return 0
