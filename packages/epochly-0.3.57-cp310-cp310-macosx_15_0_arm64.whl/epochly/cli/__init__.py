"""
Epochly Main CLI Tool

Provides command-line interface for Epochly management and operations.
Integrates with deployment, monitoring, and licensing subsystems.

Author: Epochly Development Team
"""

import argparse
import asyncio
import os
import subprocess
import sys
from typing import Any, Dict, Optional

# Lazy imports: Only import when needed to avoid triggering full Epochly initialization
# for simple commands like 'config get' or 'doctor'
from epochly.utils.logger import setup_logging, get_logger
from epochly.utils.exceptions import EpochlyError

# Re-export from extracted modules for backward compatibility
from epochly.cli.parser import (
    create_parser,
    PositiveIntAction,
    NonNegativeIntAction,
    PercentageAction,
)
from epochly.cli.script_executor import run_script
from epochly.cli.module_executor import run_module
from epochly.cli.command_executor import run_command


class EpochlyCLIError(EpochlyError):
    """CLI-specific error"""
    pass


class EpochlyCLI:
    """Main Epochly CLI controller"""

    def __init__(self):
        self.logger = get_logger(__name__)
        # Lazy-loaded, type: Optional[DeploymentController]
        self.deployment_controller: Optional[Any] = None

    def setup_logging(self, verbose: bool = False) -> None:
        """Setup logging for CLI operations"""
        level = "DEBUG" if verbose else "WARNING"
        setup_logging(level=level)

    async def status(self) -> Dict[str, str]:
        """Get Epochly system status including enhancement level and core metrics"""
        try:
            # Get Epochly core status (includes enhancement level, workers, JIT, etc.)
            import epochly
            core_status = epochly.get_status()

            status = {
                "enabled": "yes" if core_status.get("enabled", False) else "no",
                "enhancement_level": f"{core_status.get('level', 0)} ({core_status.get('enhancement_level', 'UNKNOWN')})",
                "python_version": core_status.get("python_version", "unknown"),
                "platform": core_status.get("platform", "unknown"),
            }

            # Add JIT status from actual core status structure
            jit_system = core_status.get("jit_system", {})
            if isinstance(jit_system, dict) and jit_system.get("enabled", False):
                compiled = jit_system.get("compiled_functions", 0)
                status["jit"] = f"enabled ({compiled} compiled)"
            else:
                status["jit"] = "disabled"

            # Add adaptive orchestrator status
            orchestrator = core_status.get("adaptive_orchestrator", {})
            if isinstance(orchestrator, dict) and orchestrator.get("enabled", False):
                pool = orchestrator.get("current_pool", "unknown")
                status["orchestrator"] = f"active (pool: {pool})"

            # Add GPU status (Level 4)
            gpu_system = core_status.get("level4_gpu_system", {})
            if isinstance(gpu_system, dict) and gpu_system.get("enabled", False):
                gpu_avail = gpu_system.get("gpu_available", False)
                status["gpu"] = "active" if gpu_avail else "enabled (no GPU)"

            # Get deployment status
            try:
                from epochly.deployment.deployment_controller import DeploymentController
                if not self.deployment_controller:
                    self.deployment_controller = DeploymentController()
                deployment_status = self.deployment_controller.get_status()
                status["deployment"] = "active" if deployment_status.get("enabled", False) else "inactive"
                status["mode"] = deployment_status.get("mode", "unknown")
            except Exception:
                status["deployment"] = "unavailable"

            # Check monitoring status
            try:
                from epochly.monitoring.prometheus_exporter import get_prometheus_exporter
                exporter = get_prometheus_exporter()
                status["monitoring"] = "active" if exporter.is_active() else "inactive"
            except Exception:
                status["monitoring"] = "unavailable"

            status["version"] = epochly.__version__

            # Add configuration status (simple loaded/not loaded indicator)
            status["config"] = "loaded"

            return status

        except Exception as e:
            self.logger.error(f"Failed to get status: {e}")
            raise EpochlyCLIError(f"Status check failed: {e}")

    async def start(self, mode: str = "balanced") -> None:
        """Start Epochly system"""
        try:
            # Lazy import to avoid triggering full Epochly init
            from epochly.deployment.deployment_controller import DeploymentController, DeploymentMode

            if not self.deployment_controller:
                self.deployment_controller = DeploymentController()

            # Set deployment mode if specified
            if mode in [m.value for m in DeploymentMode]:
                deployment_mode = DeploymentMode(mode)
                self.deployment_controller.set_mode(deployment_mode)

            self.logger.info(f"Epochly started in {mode} mode")

        except Exception as e:
            self.logger.error(f"Failed to start Epochly: {e}")
            raise EpochlyCLIError(f"Start failed: {e}")

    async def stop(self) -> None:
        """Stop Epochly system"""
        try:
            if self.deployment_controller:
                self.deployment_controller.shutdown()

            # Stop monitoring if active
            try:
                # Lazy import to avoid triggering full Epochly init
                from epochly.monitoring.prometheus_exporter import get_prometheus_exporter
                exporter = get_prometheus_exporter()
                if exporter.is_active():
                    exporter.stop()
            except Exception:
                pass

            self.logger.info("Epochly stopped")

        except Exception as e:
            self.logger.error(f"Failed to stop Epochly: {e}")
            raise EpochlyCLIError(f"Stop failed: {e}")

    async def restart(self, mode: str = "balanced") -> None:
        """Restart Epochly system"""
        try:
            await self.stop()
            await asyncio.sleep(1)  # Brief pause
            await self.start(mode)
            self.logger.info("Epochly restarted")

        except Exception as e:
            self.logger.error(f"Failed to restart Epochly: {e}")
            raise EpochlyCLIError(f"Restart failed: {e}")

    async def health_check(self) -> Dict[str, str]:
        """Perform comprehensive health check"""
        try:
            # Lazy import to avoid triggering full Epochly init
            from epochly.deployment.deployment_controller import DeploymentController

            health = {
                "overall": "healthy",
                "deployment": "unknown",
                "monitoring": "unknown",
                "config": "unknown"
            }

            # Check deployment controller
            try:
                if not self.deployment_controller:
                    self.deployment_controller = DeploymentController()

                status = self.deployment_controller.get_status()
                health["deployment"] = "healthy" if not status.get("emergency_disable", False) else "emergency"
                health["config"] = "healthy"

            except Exception as e:
                health["deployment"] = f"error: {e}"
                health["overall"] = "unhealthy"

            # Check monitoring
            try:
                # Lazy import to avoid triggering full Epochly init
                from epochly.monitoring.prometheus_exporter import get_prometheus_exporter
                exporter = get_prometheus_exporter()
                health["monitoring"] = "healthy" if exporter.is_active() else "inactive"

            except Exception as e:
                health["monitoring"] = f"error: {e}"

            # Determine overall health
            if any("error" in v for v in health.values() if v != health["overall"]):
                health["overall"] = "unhealthy"
            elif health["deployment"] == "emergency":
                health["overall"] = "emergency"

            return health

        except Exception as e:
            self.logger.error(f"Health check failed: {e}")
            raise EpochlyCLIError(f"Health check failed: {e}")



    def metrics_drops(self, reset: bool = False) -> Dict[str, Any]:
        """
        Show metrics drop information (IO-8).

        Args:
            reset: Whether to reset drop counter after showing

        Returns:
            Dictionary containing drop metrics
        """
        try:
            from epochly.monitoring.performance_monitor import get_performance_monitor

            monitor = get_performance_monitor()

            drop_count = monitor.get_drop_count()
            total = monitor.get_total_metrics_attempted()
            drop_rate = monitor.get_drop_rate()

            result = {
                'drops': drop_count,
                'total_attempts': total,
                'drop_rate': drop_rate,
                'drop_rate_pct': drop_rate * 100
            }

            if reset:
                monitor.reset_drop_count()
                result['reset'] = True

            return result

        except Exception as e:
            self.logger.error(f"Failed to get metrics drops: {e}")
            raise EpochlyCLIError(f"Metrics drops failed: {e}")

    def metrics_drops_config(self, alert_interval: Optional[int] = None) -> Dict[str, Any]:
        """
        Configure drop alerting (IO-8).

        Args:
            alert_interval: Alert every N drops (0 to disable, None to show current)

        Returns:
            Dictionary containing configuration
        """
        try:
            from epochly.monitoring.performance_monitor import get_performance_monitor

            monitor = get_performance_monitor()

            if alert_interval is not None:
                monitor.set_drop_alert_interval(alert_interval)
                return {
                    'alert_interval': alert_interval,
                    'configured': True
                }
            else:
                return {
                    'alert_interval': monitor._drop_alert_interval,
                    'configured': False
                }

        except Exception as e:
            self.logger.error(f"Failed to configure metrics: {e}")
            raise EpochlyCLIError(f"Metrics configuration failed: {e}")


async def print_performance_report() -> None:
    """Print performance metrics after script execution.

    NOTE: This function is only useful when running in the same process
    as Epochly. When scripts are run via subprocess (the normal case for CLI),
    the metrics remain in the subprocess and cannot be accessed from the parent.

    This function is kept for potential future use with in-process execution modes.
    """
    try:
        from epochly.api.public_api import get_metrics
        metrics = get_metrics()

        if metrics and 'error' not in metrics:
            print("\n=== Epochly Performance Report ===")
            if 'optimization_count' in metrics:
                print(f"Functions optimized: {metrics['optimization_count']}")
            if 'total_speedup' in metrics:
                print(f"Average speedup: {metrics['total_speedup']:.2f}x")
            if 'time_saved' in metrics:
                print(f"Time saved: {metrics['time_saved']:.3f} seconds")
            print("=" * 35)
    except Exception:
        # Silently ignore if we can't get metrics
        pass


def _levenshtein_distance(s1: str, s2: str) -> int:
    """Compute Levenshtein edit distance between two strings."""
    if len(s1) < len(s2):
        return _levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)
    prev_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        curr_row = [i + 1]
        for j, c2 in enumerate(s2):
            cost = 0 if c1 == c2 else 1
            curr_row.append(min(
                curr_row[j] + 1,       # insert
                prev_row[j + 1] + 1,   # delete
                prev_row[j] + cost,     # substitute
            ))
        prev_row = curr_row
    return prev_row[-1]


def _suggest_command(typo: str, known_commands: set) -> Optional[str]:
    """Find the closest known command to a typo using Levenshtein distance.

    Returns the suggestion if distance <= 2, else None.
    """
    # Only consider actual command names (not flags like --help)
    candidates = [cmd for cmd in known_commands if not cmd.startswith('-')]
    best = None
    best_dist = 3  # threshold: suggest only if distance <= 2
    for cmd in candidates:
        dist = _levenshtein_distance(typo, cmd)
        if dist < best_dist:
            best_dist = dist
            best = cmd
    return best


async def main() -> int:
    """Main CLI entry point"""
    # Define all known top-level commands
    KNOWN_COMMANDS = {
        'status', 'start', 'stop', 'restart', 'health',
        'jupyter', 'sitecustomize', 'shell', 'config', 'doctor',
        'trial', 'verify',  # Trial management commands
        'metrics',  # IO-8: Monitor back-pressure
        'terms',  # Terms acceptance management
        '--help', '-h',
        # Note: --version is handled by argparse before routing
    }

    # Intelligent command vs script detection following best practices:
    # 1. First check if first non-flag argument is a known command -> command mode (highest priority)
    # 2. Then check if first non-flag argument ends with .py -> script mode
    # 3. Otherwise assume script mode for backward compatibility

    is_script_mode = False
    is_command_mode = False
    script_index = -1

    # Check for Python compatibility modes early
    # Look for -m or -c in Epochly's flags (before script args or --)
    is_module_mode = False
    is_c_mode = False
    for arg in sys.argv[1:]:
        if arg == '--':
            # Reached script args separator, stop checking
            break
        if arg == '-m':
            is_module_mode = True
            break
        if arg == '-c':
            is_c_mode = True
            break
        # Stop at first positional arg that looks like a script/command
        if not arg.startswith('-') and (arg.endswith('.py') or '/' in arg or '\\' in arg):
            break

    # Find first non-flag argument to determine mode
    if not is_module_mode and not is_c_mode:
        if len(sys.argv) > 1:
            # Find first non-flag argument (skipping flag values)
            # Flags that take arguments
            FLAGS_WITH_VALUES = {
                '-l', '--level', '--workers', '--mode', '--max-cores',
                '--max-cores-percent', '--reserve-cores', '--pin-pool',
                '--allowed-pools', '-m', '-c'
            }

            first_non_flag = None
            first_non_flag_index = -1
            skip_next = False

            for i, arg in enumerate(sys.argv[1:], 1):
                if skip_next:
                    # This is a value for the previous flag
                    skip_next = False
                    continue

                if arg == '--':
                    # Double dash separator - everything after is script args
                    # The script must be before the --
                    break

                if arg.startswith('-'):
                    # Check if this flag takes a value
                    flag_name = arg.split('=')[0]  # Handle --flag=value format
                    if flag_name in FLAGS_WITH_VALUES and '=' not in arg:
                        # Next arg is the value for this flag
                        skip_next = True
                else:
                    # Found first true positional argument
                    first_non_flag = arg
                    first_non_flag_index = i
                    break

            # Check if it's a known command FIRST
            if first_non_flag and first_non_flag in KNOWN_COMMANDS:
                is_command_mode = True
            elif first_non_flag:
                # Check if it looks like a command typo (no .py, no path seps)
                looks_like_command = (
                    not first_non_flag.endswith('.py')
                    and '/' not in first_non_flag
                    and '\\' not in first_non_flag
                    and '.' not in first_non_flag
                )
                if looks_like_command:
                    suggestion = _suggest_command(first_non_flag, KNOWN_COMMANDS)
                    if suggestion:
                        print(f"Error: Unknown command '{first_non_flag}'. Did you mean: epochly {suggestion}?", file=sys.stderr)
                        print("Run 'epochly --help' for available commands.", file=sys.stderr)
                        return 1

                # Not a known command, treat as script
                is_script_mode = True
                script_index = first_non_flag_index
            else:
                # Only flags provided, show help
                is_command_mode = True
        else:
            # No arguments, show help
            is_command_mode = True

    # Handle script execution mode
    if is_script_mode and script_index > 0:
        # Extract everything before the script as flags
        flags = sys.argv[1:script_index]
        script = sys.argv[script_index]
        script_args = sys.argv[script_index + 1:]

        # Parse just the flags to get options like -l, -v, etc.
        flag_parser = argparse.ArgumentParser(add_help=False)
        flag_parser.add_argument('-v', '--verbose', action='store_true')
        flag_parser.add_argument('-l', '--level', type=int, choices=[0, 1, 2, 3, 4], default=3)
        flag_parser.add_argument('--no-optimize', action='store_true')
        # Add memory pool configuration
        flag_parser.add_argument('--pin-pool', choices=['fast', 'legacy', 'sharded'])
        flag_parser.add_argument('--allowed-pools')
        # Add core usage limits
        flag_parser.add_argument('--max-cores', type=int)
        flag_parser.add_argument('--max-cores-percent', type=int)
        flag_parser.add_argument('--reserve-cores', type=int)
        # Add advanced analysis
        flag_parser.add_argument('--profile', action='store_true')
        flag_parser.add_argument('--benchmark', action='store_true')
        flag_parser.add_argument('--check', action='store_true')
        flag_parser.add_argument('--explain', action='store_true')
        # Add runtime configuration
        flag_parser.add_argument('--workers', type=int)
        flag_parser.add_argument('--mode', choices=['monitor', 'conservative', 'balanced', 'aggressive'])
        flag_parser.add_argument('--debug', action='store_true')

        # Parse known flags, ignore unknown
        flag_args, _ = flag_parser.parse_known_args(flags)

        # Create args object for run_script
        class ScriptArgs:
            def __init__(self):
                self.script = script
                self.script_args = script_args
                self.verbose = flag_args.verbose
                self.level = flag_args.level
                self.no_optimize = flag_args.no_optimize
                # Memory pool configuration
                self.pin_pool = flag_args.pin_pool
                self.allowed_pools = flag_args.allowed_pools
                # Core usage limits
                self.max_cores = flag_args.max_cores
                self.max_cores_percent = flag_args.max_cores_percent
                self.reserve_cores = flag_args.reserve_cores
                # Advanced analysis
                self.profile = flag_args.profile
                self.benchmark = flag_args.benchmark
                self.check = flag_args.check
                self.explain = flag_args.explain
                # Runtime configuration
                self.workers = flag_args.workers
                self.mode = flag_args.mode
                self.debug = flag_args.debug

        return await run_script(ScriptArgs())

    # Handle Python compatibility modes (-m and -c) specially
    if is_module_mode or is_c_mode:
        # Use parse_known_args for -m and -c modes to capture everything after module/command
        parser = create_parser(include_script_args=False, include_subcommands=False)
        args, unknown = parser.parse_known_args()

        if hasattr(args, 'module') and args.module:
            # Module execution mode: epochly -m module [args]
            # Everything after module name should be in unknown
            args.script_args = unknown
            return await run_module(args)

        if hasattr(args, 'command') and args.command:
            # Command execution mode: epochly -c "code" [args]
            # For -c mode, there might be additional args after the command string
            args.script_args = unknown
            return await run_command(args)

    # Create parser based on detected mode
    # In command mode, don't include script args to avoid conflicts
    # In script mode, don't include subcommands to avoid conflicts
    if is_command_mode:
        parser = create_parser(include_script_args=False, include_subcommands=True)
    else:
        parser = create_parser(include_script_args=True, include_subcommands=False)

    # Parse arguments normally for non-Python-compatibility modes
    args = parser.parse_args()

    # Check if we have a command
    if is_command_mode:
        # In command mode, if no command was specified, show help
        if not hasattr(args, 'command') or not args.command:
            parser.print_help()
            return 1
    else:
        # In mixed mode, check for script
        if not args.command and not args.script:
            parser.print_help()
            return 1

        # Handle backward compatibility case where command was captured as script
        if not args.command and args.script and not args.script.endswith('.py'):
            if args.script in KNOWN_COMMANDS:
                args.command = args.script
                args.script = None
            else:
                suggestion = _suggest_command(args.script, KNOWN_COMMANDS)
                if suggestion:
                    print(f"Error: Unknown command '{args.script}'. Did you mean: epochly {suggestion}?", file=sys.stderr)
                else:
                    print(f"Error: '{args.script}' is not a recognized command or Python script.", file=sys.stderr)
                print("Run 'epochly --help' for available commands.", file=sys.stderr)
                return 1

    cli = EpochlyCLI()
    cli.setup_logging(args.verbose if hasattr(args, 'verbose') else False)

    try:
        if args.command == "status":
            status = await cli.status()
            print("Epochly System Status:")
            for key, value in status.items():
                print(f"  {key}: {value}")

        elif args.command == "start":
            await cli.start(args.mode)
            print(f"Epochly started in {args.mode} mode")

        elif args.command == "stop":
            await cli.stop()
            print("Epochly stopped")

        elif args.command == "restart":
            await cli.restart(args.mode)
            print(f"Epochly restarted in {args.mode} mode")

        elif args.command == "health":
            health = await cli.health_check()
            print("Epochly Health Check:")
            for key, value in health.items():
                print(f"  {key}: {value}")

        elif args.command == "jupyter":
            # Handle Jupyter subcommands
            from epochly.cli.jupyter import main as jupyter_main

            # Pass only jupyter subcommands to jupyter CLI
            jupyter_args = sys.argv[2:]  # Skip 'epochly jupyter'
            return jupyter_main(jupyter_args)

        elif args.command == "sitecustomize":
            # Handle sitecustomize subcommands
            from epochly.deployment.sitecustomize_installer import SitecustomizeInstaller

            installer = SitecustomizeInstaller()

            # Check if subcommand was provided
            if not hasattr(args, 'sitecustomize_command') or not args.sitecustomize_command:
                print("Please specify a sitecustomize subcommand: install, uninstall, status, validate, or list-backups", file=sys.stderr)
                return 1

            if args.sitecustomize_command == "install":
                preserve_existing = not args.no_preserve
                success = installer.install(force=args.force, preserve_existing=preserve_existing)
                if success:
                    print("Epochly sitecustomize.py installed successfully")
                    print("Python will now automatically activate Epochly on startup")
                else:
                    print("Failed to install sitecustomize.py", file=sys.stderr)
                    return 1

            elif args.sitecustomize_command == "uninstall":
                restore_backup = not args.no_restore
                success = installer.uninstall(restore_backup=restore_backup)
                if success:
                    print("Epochly sitecustomize.py uninstalled successfully")
                else:
                    print("Failed to uninstall sitecustomize.py", file=sys.stderr)
                    return 1

            elif args.sitecustomize_command == "status":
                status = installer.get_installation_status()
                print("Sitecustomize Installation Status:")
                print(f"  Installed: {status['installed']}")
                print(f"  Epochly Managed: {status['epochly_managed']}")
                print(f"  Valid: {status['valid']}")
                if status['path']:
                    print(f"  Path: {status['path']}")
                print(f"  Backup Directory: {status['backup_directory']}")

            elif args.sitecustomize_command == "validate":
                is_valid = installer.validate_installation()
                if is_valid:
                    print("Sitecustomize.py installation is valid")
                else:
                    print("Sitecustomize.py installation is invalid or not found", file=sys.stderr)
                    return 1

            elif args.sitecustomize_command == "list-backups":
                backups = installer.list_backups()
                if backups:
                    print("Available Sitecustomize Backups:")
                    for backup in backups:
                        from datetime import datetime
                        created = datetime.fromtimestamp(backup['created']).strftime('%Y-%m-%d %H:%M:%S')
                        print(f"  {backup['filename']} - Created: {created}, Size: {backup['size']} bytes")
                else:
                    print("No sitecustomize.py backups found")

            else:
                print(f"Unknown sitecustomize command: {args.sitecustomize_command}", file=sys.stderr)
                return 1

        elif args.command == "shell":
            # Handle shell command - launch Epochly-enabled Python REPL
            env = os.environ.copy()

            # Add src directory to PYTHONPATH
            src_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
            env['PYTHONPATH'] = src_path + os.pathsep + env.get('PYTHONPATH', '')

            # Enable Epochly
            env['EPOCHLY_ENABLED'] = '1'
            env['EPOCHLY_MODE'] = 'balanced'

            # Set up startup script if provided
            if hasattr(args, 'startup') and args.startup:
                script_path = args.startup
                if not os.path.exists(script_path):
                    print(f"Startup script not found: {script_path}", file=sys.stderr)
                    return 1
                env['PYTHONSTARTUP'] = script_path

            # Print banner unless suppressed
            if not hasattr(args, 'no_banner') or not args.no_banner:
                print("=" * 50)
                print("Epochly-Enabled Python REPL")
                print(f"Python {sys.version}")
                import epochly as _epochly_pkg
                print(f"Epochly version: {_epochly_pkg.__version__}")
                print("Type 'help(epochly)' for Epochly documentation")
                print("=" * 50)

            # Launch Python REPL with Epochly
            cmd = [sys.executable, '-i']

            # Add quiet flag if requested
            if hasattr(args, 'quiet') and args.quiet:
                cmd.append('-q')

            try:
                result = subprocess.run(cmd, env=env)
                if result.returncode != 0:
                    print("Failed to start Epochly shell", file=sys.stderr)
                return result.returncode
            except KeyboardInterrupt:
                print("\nShell interrupted by user", file=sys.stderr)
                return 130
            except Exception as e:
                print(f"Failed to start Epochly shell: {e}", file=sys.stderr)
                return 1

        elif args.command == "config":
            # Handle config command
            from epochly.config import ConfigManager, ConfigWizard

            config_manager = ConfigManager()

            # Check if subcommand was provided
            if not hasattr(args, 'config_command') or not args.config_command:
                print("Please specify a config subcommand: show, set, get, reset, wizard, export, or import", file=sys.stderr)
                return 1

            # Determine scope
            scope = 'effective'  # Default
            if hasattr(args, 'global_config') and args.global_config:
                scope = 'global'
            elif hasattr(args, 'local_config') and args.local_config:
                scope = 'local'
            elif hasattr(args, 'system_config') and args.system_config:
                scope = 'system'

            if args.config_command == "show":
                config = config_manager.get_all_config(scope=scope)
                print(f"Epochly Configuration ({scope}):")
                for key, value in config.items():
                    print(f"  {key}: {value}")

            elif args.config_command == "set":
                try:
                    # For set command, default to 'user' scope if not specified
                    set_scope = 'user'  # Default for set command
                    if hasattr(args, 'global_config') and args.global_config:
                        set_scope = 'global'
                    elif hasattr(args, 'local_config') and args.local_config:
                        set_scope = 'local'
                    elif hasattr(args, 'system_config') and args.system_config:
                        set_scope = 'system'

                    # Validate configuration before setting
                    is_valid, error = config_manager.validate_config(args.key, args.value)
                    if not is_valid:
                        print(f"Validation error: {error}", file=sys.stderr)
                        return 1

                    config_manager.set_config(args.key, args.value, scope=set_scope)
                    print(f"Configuration updated: {args.key} = {args.value}")
                except ValueError as e:
                    print(f"Error: Invalid configuration key: {args.key}", file=sys.stderr)
                    return 1

            elif args.config_command == "get":
                value = config_manager.get_config(args.key, scope=scope)
                if value is not None:
                    print(value)
                else:
                    print("(not set)")

            elif args.config_command == "reset":
                if not hasattr(args, 'force') or not args.force:
                    # Check if running in interactive mode (TTY)
                    if sys.stdin.isatty():
                        try:
                            response = input("Are you sure you want to reset configuration to defaults? (y/n): ")
                            if response.lower() != 'y':
                                print("Reset cancelled")
                                return 0
                        except EOFError:
                            # EOF on interactive TTY - treat as cancellation
                            print("Reset cancelled")
                            return 0
                    # else: Non-interactive mode (automated testing, subprocess, etc.)
                    # In non-interactive mode without --force, assume yes for automation compatibility

                config_manager.reset_config()
                print("Configuration reset to defaults")

            elif args.config_command == "wizard":
                wizard = ConfigWizard()
                new_config = wizard.run()
                if new_config:
                    config_manager.apply_config(new_config)
                    print("Configuration wizard completed successfully")
                else:
                    print("Configuration wizard cancelled")

            elif args.config_command == "export":
                export_data = config_manager.export_config(format=args.format)
                print(export_data)

            elif args.config_command == "import":
                if not os.path.exists(args.file):
                    print(f"Configuration file not found: {args.file}", file=sys.stderr)
                    return 1

                with open(args.file, 'r') as f:
                    config_data = f.read()

                success = config_manager.import_config(config_data)
                if success:
                    print(f"Configuration imported from {args.file}")
                else:
                    print(f"Failed to import configuration from {args.file}", file=sys.stderr)
                    return 1

            else:
                print(f"Unknown config command: {args.config_command}", file=sys.stderr)
                return 1

        elif args.command == "doctor":
            # Handle doctor command - diagnose installation
            from epochly.diagnostics import Doctor

            doctor = Doctor()

            # Run diagnostics
            verbose = hasattr(args, 'verbose') and args.verbose
            results = doctor.run_diagnostics(verbose=verbose)

            # Output in JSON if requested
            if hasattr(args, 'json') and args.json:
                import json
                print(json.dumps(results, indent=2))
                return 0 if all(r.get('status') != 'fail' for r in results.values()) else 1

            # Print results
            print("Epochly Doctor - Installation Diagnostics")
            print("=" * 50)

            has_failures = False
            has_warnings = False

            for check_name, result in results.items():
                status = result.get('status', 'unknown')
                message = result.get('message', '')

                if status == 'pass':
                    status_str = "PASS:"
                elif status == 'fail':
                    status_str = "FAIL:"
                    has_failures = True
                elif status == 'warn':
                    status_str = "WARN:"
                    has_warnings = True
                else:
                    status_str = "INFO:"

                print(f"{status_str:6} {check_name:20} - {message}")

                # Print details if verbose
                if verbose and 'details' in result:
                    details = result['details']
                    if isinstance(details, dict):
                        for key, value in details.items():
                            print(f"       {key}: {value}")
                    else:
                        print(f"       {details}")

            print("=" * 50)

            # Attempt fixes if requested
            if hasattr(args, 'fix') and args.fix and has_failures:
                print("\nAttempting to fix issues...")
                fix_results = doctor.fix_issues()

                for issue, fix_result in fix_results.items():
                    if fix_result.get('fixed'):
                        print(f"Fixed: {issue} - {fix_result.get('message', 'Success')}")
                    else:
                        print(f"Could not fix: {issue} - {fix_result.get('message', 'Unknown error')}")

            # Summary
            if has_failures:
                print("\nSome checks failed. Run 'epochly doctor --fix' to attempt automatic fixes.")
                return 1
            elif has_warnings:
                print("\nAll checks passed with warnings.")
                return 0
            else:
                print("\nAll checks passed")
                print("Epochly is ready to use!")
                return 0

        elif args.command == "trial":
            # Handle trial command - use plain function, not Click command
            from epochly.cli.trial_command import _trial_impl
            return _trial_impl(args.email, interactive=True)

        elif args.command == "verify":
            # Handle verify command - use plain function, not Click command
            from epochly.cli.trial_command import _activate_impl
            return _activate_impl(args.token)

        elif args.command == "terms":
            # Handle terms acceptance management
            from epochly.licensing.consent_manager import get_consent_manager
            from epochly.licensing.terms_acceptance import VALID_TERMS_NAMES

            manager = get_consent_manager()

            if not hasattr(args, 'terms_command') or not args.terms_command:
                print("Please specify a terms subcommand: accept, show, or list", file=sys.stderr)
                print("Run 'epochly terms --help' for details", file=sys.stderr)
                return 1

            if args.terms_command == "accept":
                outstanding = manager.check_consent_required()
                if not outstanding:
                    print("All terms are already accepted.")
                    return 0

                print(f"Outstanding terms requiring acceptance: {', '.join(outstanding)}")

                non_interactive = hasattr(args, 'non_interactive') and args.non_interactive
                if not non_interactive and sys.stdin.isatty():
                    print("Review terms at: https://epochly.com/legal")
                    try:
                        response = input("Accept all outstanding terms? (y/n): ")
                        if response.lower() != 'y':
                            print("Terms acceptance cancelled.")
                            return 0
                    except EOFError:
                        print("Terms acceptance cancelled.")
                        return 0

                results = manager.record_consent_for_all(method="cli_prompt")
                errors = [name for name, r in results.items() if r.get("error")]
                if errors:
                    print(f"Failed to record acceptance for: {', '.join(errors)}", file=sys.stderr)
                    return 1

                print("All terms accepted successfully.")
                return 0

            elif args.terms_command == "show":
                summary = manager.get_consent_summary()
                use_json = hasattr(args, 'json_output') and args.json_output

                if use_json:
                    import json
                    print(json.dumps(summary, indent=2, default=str))
                else:
                    print("Terms Acceptance Status:")
                    for name in sorted(VALID_TERMS_NAMES):
                        info = summary.get(name, {})
                        accepted = info.get("accepted", False)
                        status_str = "accepted" if accepted else "NOT accepted"
                        if info.get("needs_reaccept"):
                            status_str = "needs re-acceptance"
                        print(f"  {name}: {status_str}")
                    fully = summary.get("fully_consented", False)
                    print(f"\n  Fully consented: {'yes' if fully else 'no'}")
                    outstanding = summary.get("outstanding", [])
                    if outstanding:
                        print(f"  Outstanding: {', '.join(outstanding)}")
                return 0

            elif args.terms_command == "list":
                print("Available terms documents:")
                for name in sorted(VALID_TERMS_NAMES):
                    print(f"  - {name}")
                print("\nReview at: https://epochly.com/legal")
                return 0

            else:
                print(f"Unknown terms command: {args.terms_command}", file=sys.stderr)
                return 1

        elif args.command == "metrics":
            # IO-8: Metrics monitoring
            if not hasattr(args, 'metrics_command') or args.metrics_command is None:
                print("Error: metrics command requires a subcommand (drops, config)")
                return 1

            if args.metrics_command == "drops":
                result = cli.metrics_drops(reset=args.reset)
                print(f"Metrics Dropped: {result['drops']}")
                print(f"Total Attempts: {result['total_attempts']}")
                print(f"Drop Rate: {result['drop_rate_pct']:.2f}%")
                if result.get('reset'):
                    print("Drop counter reset.")
                return 0

            elif args.metrics_command == "config":
                if args.alert_interval is not None:
                    result = cli.metrics_drops_config(alert_interval=args.alert_interval)
                    print(f"Alert interval set to: {result['alert_interval']}")
                else:
                    result = cli.metrics_drops_config()
                    print(f"Current alert interval: {result['alert_interval']}")
                return 0


        else:
            print(f"Unknown command: {args.command}", file=sys.stderr)
            return 1

        return 0

    except EpochlyCLIError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nOperation cancelled", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        return 1


def cli_main() -> None:
    """Synchronous wrapper for main CLI function"""
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        sys.exit(130)


if __name__ == "__main__":
    cli_main()

# Lazy export: Don't import jupyter at module level
# from .jupyter import main as jupyter_main  # Causes heavy imports

__all__ = [
    'EpochlyCLI',
    'EpochlyCLIError',
    'main',
    'cli_main',
    'run_script',
    'run_module',
    'run_command',
    'create_parser',
    'print_performance_report',
]
