"""
Epochly License Cryptography Module

Provides Ed25519 cryptographic signature generation and validation
for Epochly license keys. Implements offline-first license validation
with tamper-proof cryptographic signatures.

Architecture:
- Ed25519 for compact, secure signatures
- License format: Epochly-TYPE-FEATURES-EXPIRY-MAXCORES-SIGNATURE
- Offline validation (no server required)
- Public key embedded in client, private key server-side only

Author: Epochly Development Team
"""
from __future__ import annotations

import base64
import json
import hashlib
from typing import Dict, Optional, Tuple
from datetime import datetime, timezone
from pathlib import Path

try:
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives import serialization
    HAS_CRYPTOGRAPHY = True
except ImportError:
    HAS_CRYPTOGRAPHY = False


class LicenseCryptoError(Exception):
    """Raised when cryptographic operations fail"""
    pass


class LicenseCrypto:
    """
    Handles cryptographic operations for license validation.

    Uses Ed25519 signatures for compact, secure license validation.
    Supports offline validation without server dependency.
    """

    # Embedded public key for offline license validation
    # Matches the Ed25519 private key stored in AWS Secrets Manager:
    #   epochly/ed25519-private-key (us-west-2)
    # Note: Private key is stored securely server-side and NEVER distributed
    EMBEDDED_PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAzS1nrbdw4bZlFtyZTIvwG/ber4xziPKcc69E2Hgqi8c=
-----END PUBLIC KEY-----
"""

    def __init__(self, public_key_pem: Optional[bytes] = None):
        """
        Initialize license crypto handler.

        Args:
            public_key_pem: Optional PEM-encoded public key (for testing)
        """
        if not HAS_CRYPTOGRAPHY:
            raise LicenseCryptoError(
                "cryptography library not installed. "
                "Install with: pip install cryptography"
            )

        # Use provided key or embedded key
        self.public_key_pem = public_key_pem or self.EMBEDDED_PUBLIC_KEY_PEM
        self._public_key = None

        if self.public_key_pem:
            self._load_public_key()

    def _load_public_key(self):
        """Load and validate the public key"""
        try:
            public_key_obj = serialization.load_pem_public_key(self.public_key_pem)

            # Verify it's an Ed25519 key
            if not isinstance(public_key_obj, ed25519.Ed25519PublicKey):
                raise LicenseCryptoError("Public key must be Ed25519")

            self._public_key = public_key_obj
        except Exception as e:
            raise LicenseCryptoError(f"Failed to load public key: {e}")

    def validate_license_signature(
        self,
        license_data: Dict[str, any],
        signature_b64: str
    ) -> bool:
        """
        Validate a license signature.

        Args:
            license_data: License data dictionary (type, features, expiry, max_cores)
            signature_b64: Base64-encoded signature

        Returns:
            True if signature is valid, False otherwise
        """
        if not self._public_key:
            raise LicenseCryptoError("No public key loaded for validation")

        try:
            # Create canonical JSON representation
            # Use sorted keys for deterministic serialization
            license_json = json.dumps(
                license_data,
                separators=(',', ':'),
                sort_keys=True
            )
            license_bytes = license_json.encode('utf-8')

            # Decode signature (handle URL-safe base64 padding)
            # Ed25519 signatures are 64 bytes = 86 base64 chars (no padding in license key)
            # -len % 4 computes required padding: 0, 1, 2, or 3 '=' characters
            signature = base64.urlsafe_b64decode(
                signature_b64 + '=' * (-len(signature_b64) % 4)
            )

            # Verify signature
            self._public_key.verify(signature, license_bytes)
            return True

        except Exception:
            # Any exception means invalid signature
            return False

    def parse_license_key(self, license_key: str) -> Tuple[Dict[str, any], str]:
        """
        Parse a license key into its components.

        Format: Epochly-TYPE-FEATURES-EXPIRY-MAXCORES-SIGNATURE

        Args:
            license_key: The license key string

        Returns:
            Tuple of (license_data dict, signature string)

        Raises:
            LicenseCryptoError: If license key format is invalid
        """
        # Split by dashes
        parts = license_key.split('-')

        # Minimum: Epochly-TYPE-FEATURES-EXPIRY-MAXCORES-SIGNATURE = 6 parts
        if len(parts) < 6:
            raise LicenseCryptoError(f"Invalid license key format: too few parts ({len(parts)})")

        prefix = parts[0]
        if prefix != 'Epochly':
            raise LicenseCryptoError(f"Invalid license key prefix: {prefix}")

        # Extract components
        lic_type = parts[1]
        features = parts[2].split(',') if parts[2] else []

        try:
            expiry = int(parts[3])  # Unix timestamp
        except ValueError:
            raise LicenseCryptoError(f"Invalid expiry date: {parts[3]}")

        try:
            max_cores = int(parts[4])
        except ValueError:
            raise LicenseCryptoError(f"Invalid max_cores: {parts[4]}")

        # Signature is the last part (may contain dashes)
        signature_b64 = '-'.join(parts[5:])

        # Reconstruct license data in canonical form
        license_data = {
            'epochly': prefix,
            'type': lic_type,
            'features': sorted(features),  # Sort for consistency
            'expiry': expiry,
            'max_cores': max_cores
        }

        return license_data, signature_b64

    def validate_license_key(self, license_key: str) -> Tuple[bool, Optional[Dict]]:
        """
        Validate a complete license key.

        Args:
            license_key: The license key string

        Returns:
            Tuple of (is_valid: bool, license_data: Optional[Dict])
        """
        try:
            # Parse the license key
            license_data, signature_b64 = self.parse_license_key(license_key)

            # Validate signature
            if not self.validate_license_signature(license_data, signature_b64):
                return False, None

            # Check expiry (using timezone-aware datetime for consistency)
            current_timestamp = int(datetime.now(timezone.utc).timestamp())
            if license_data['expiry'] < current_timestamp:
                return False, {'error': 'License expired'}

            return True, license_data

        except LicenseCryptoError as e:
            return False, {'error': str(e)}
        except Exception as e:
            return False, {'error': f'Validation failed: {e}'}


class LicenseKeyGenerator:
    """
    Server-side license key generation (for testing and future server use).

    WARNING: Private key must NEVER be distributed with client.
    This class is for server-side use only.
    """

    def __init__(self, private_key_pem: Optional[bytes] = None):
        """
        Initialize license key generator.

        Args:
            private_key_pem: PEM-encoded private key
        """
        if not HAS_CRYPTOGRAPHY:
            raise LicenseCryptoError(
                "cryptography library not installed. "
                "Install with: pip install cryptography"
            )

        if private_key_pem:
            self._private_key = self._load_private_key(private_key_pem)
        else:
            # Generate new key pair for testing
            self._private_key = ed25519.Ed25519PrivateKey.generate()

    def _load_private_key(self, private_key_pem: bytes) -> ed25519.Ed25519PrivateKey:
        """Load private key from PEM"""
        try:
            private_key = serialization.load_pem_private_key(
                private_key_pem,
                password=None
            )

            if not isinstance(private_key, ed25519.Ed25519PrivateKey):
                raise LicenseCryptoError("Private key must be Ed25519")

            return private_key
        except Exception as e:
            raise LicenseCryptoError(f"Failed to load private key: {e}")

    def get_public_key_pem(self) -> bytes:
        """Get the public key in PEM format"""
        public_key = self._private_key.public_key()
        return public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )

    def generate_license_key(
        self,
        license_type: str,
        features: list,
        expiry_timestamp: int,
        max_cores: int
    ) -> str:
        """
        Generate a signed license key.

        Args:
            license_type: FREE, TRIAL, or PAID
            features: List of enabled features
            expiry_timestamp: Unix timestamp for expiry
            max_cores: Maximum CPU cores allowed

        Returns:
            Signed license key string
        """
        # Create license data
        license_data = {
            'epochly': 'Epochly',
            'type': license_type,
            'features': sorted(features),  # Sort for consistency
            'expiry': expiry_timestamp,
            'max_cores': max_cores
        }

        # Create canonical JSON representation
        license_json = json.dumps(
            license_data,
            separators=(',', ':'),
            sort_keys=True
        )
        license_bytes = license_json.encode('utf-8')

        # Sign the data
        signature = self._private_key.sign(license_bytes)

        # Base64 encode signature (URL-safe, no padding)
        signature_b64 = base64.urlsafe_b64encode(signature).decode('utf-8').rstrip('=')

        # Construct license key
        features_str = ','.join(sorted(features))
        license_key = (
            f"Epochly-{license_type}-{features_str}-"
            f"{expiry_timestamp}-{max_cores}-{signature_b64}"
        )

        return license_key

    @staticmethod
    def generate_key_pair() -> Tuple[bytes, bytes]:
        """
        Generate a new Ed25519 key pair.

        Returns:
            Tuple of (private_key_pem, public_key_pem)
        """
        if not HAS_CRYPTOGRAPHY:
            raise LicenseCryptoError(
                "cryptography library not installed. "
                "Install with: pip install cryptography"
            )

        # Generate private key
        private_key = ed25519.Ed25519PrivateKey.generate()

        # Export private key
        private_key_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )

        # Export public key
        public_key = private_key.public_key()
        public_key_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )

        return private_key_pem, public_key_pem
