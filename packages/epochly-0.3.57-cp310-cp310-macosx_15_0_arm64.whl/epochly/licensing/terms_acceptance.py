"""
Epochly Terms Acceptance Client.

Provides the client-side interface for checking and recording terms acceptance
via the api.epochly.com backend. Supports:
  - Checking acceptance status for tos, privacy_policy, esla
  - Recording new acceptances
  - Withdrawing consent
  - Local caching (in-memory + disk) with configurable TTL
  - Graceful degradation when offline or requests unavailable
  - Machine fingerprint generation for identification

All user-side functionality goes through api.epochly.com - no direct AWS access.
"""

import hashlib
import json
import logging
import os
import platform
import stat
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Lightweight imports only - NO boto3
try:
    import requests

    REQUESTS_AVAILABLE = True
except ImportError:
    requests = None  # type: ignore[assignment]
    REQUESTS_AVAILABLE = False
    logger.warning("requests not available - terms acceptance API disabled")

# Current required versions for each terms document
CURRENT_TERMS_VERSIONS: Dict[str, str] = {
    "tos": "2026.01.30",
    "privacy_policy": "2026.01.30",
    "esla": "2026.01.30",
}

# Valid terms document names
VALID_TERMS_NAMES = frozenset(CURRENT_TERMS_VERSIONS.keys())

# Valid acceptance methods (mirrors Lambda handler)
VALID_ACCEPTANCE_METHODS = frozenset(
    {
        "cli_prompt",
        "cli_flag",
        "env_var",
        "web_form",
        "trial_activation",
        "license_activation",
    }
)

# Default cache TTL: 1 hour
DEFAULT_CACHE_TTL_SECONDS = 3600

# Default request timeout in seconds
DEFAULT_TIMEOUT = 10


class TermsAcceptanceClient:
    """
    Client for the Epochly terms acceptance API.

    Provides methods to check, record, and withdraw terms acceptance,
    with local caching to minimise API calls.
    """

    def __init__(
        self,
        cache_dir: Optional[str] = None,
        api_endpoint: Optional[str] = None,
        timeout: int = DEFAULT_TIMEOUT,
        cache_ttl_seconds: int = DEFAULT_CACHE_TTL_SECONDS,
    ):
        """
        Initialise the terms acceptance client.

        Args:
            cache_dir: Directory for disk cache (created if absent).
            api_endpoint: API base URL (default: EPOCHLY_API_URL env or api.epochly.com).
            timeout: Request timeout in seconds.
            cache_ttl_seconds: How long cached results remain valid.
        """
        self.api_endpoint = (
            api_endpoint
            or os.environ.get("EPOCHLY_API_URL")
            or "https://api.epochly.com"
        )
        self.timeout = timeout
        self.cache_ttl_seconds = cache_ttl_seconds

        # Cache directory
        self._cache_dir = Path(cache_dir or _default_cache_dir())
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._cache_file = self._cache_dir / "terms_status.json"

        # In-memory cache: terms_name -> {"data": dict, "timestamp": float}
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._load_disk_cache()

        # Machine fingerprint (cached after first generation)
        self._cached_fingerprint: Optional[str] = None

    # ------------------------------------------------------------------
    # Machine fingerprint
    # ------------------------------------------------------------------

    def get_machine_fingerprint(self) -> str:
        """
        Generate or return cached machine fingerprint.

        Tries secure_node_auth first, falls back to platform-based hash.
        """
        if self._cached_fingerprint:
            return self._cached_fingerprint

        fingerprint = self._generate_fingerprint()
        self._cached_fingerprint = fingerprint
        return fingerprint

    def _generate_fingerprint(self) -> str:
        """Generate a machine fingerprint using available methods."""
        try:
            from epochly.compatibility.secure_node_auth import MachineFingerprint

            return MachineFingerprint.generate_complete_fingerprint()
        except (ImportError, Exception):
            # Fallback: platform-based fingerprint
            system_info = (
                f"{platform.system()}:{platform.machine()}:"
                f"{platform.processor()}:{platform.node()}"
            )
            return hashlib.sha256(system_info.encode()).hexdigest()

    # ------------------------------------------------------------------
    # Check acceptance status (GET /terms/status)
    # ------------------------------------------------------------------

    def check_status(self, terms_name: str) -> Dict[str, Any]:
        """
        Check acceptance status for a specific terms document.

        Args:
            terms_name: One of 'tos', 'privacy_policy', 'esla'.

        Returns:
            Dict with at least 'accepted' (bool) and other status fields.

        Raises:
            ValueError: If terms_name is not a recognised document name.
        """
        if terms_name not in VALID_TERMS_NAMES:
            raise ValueError(
                f"Invalid terms_name: '{terms_name}'. "
                f"Must be one of: {', '.join(sorted(VALID_TERMS_NAMES))}"
            )

        # Check in-memory cache (TTL-gated)
        cached = self._get_cached(terms_name)
        if cached is not None:
            return cached

        # No requests library available
        if not REQUESTS_AVAILABLE:
            disk = self._get_stale_cached(terms_name)
            if disk is not None:
                return disk
            return {"accepted": False, "error": "requests library not available"}

        # Call API
        try:
            fingerprint = self.get_machine_fingerprint()
            resp = requests.get(
                f"{self.api_endpoint}/terms/status",
                params={
                    "machine_fingerprint": fingerprint,
                    "terms_name": terms_name,
                },
                timeout=self.timeout,
            )
            if resp.ok:
                try:
                    data = resp.json()
                except (ValueError, TypeError):
                    return {"accepted": False, "error": "Invalid JSON in API response"}
                if not isinstance(data, dict) or "accepted" not in data:
                    return {"accepted": False, "error": "Malformed API response"}
                self._set_cached(terms_name, data)
                return data
            return {"accepted": False, "error": f"API returned {resp.status_code}"}
        except Exception as exc:
            logger.debug("Terms status API error for %s: %s", terms_name, exc)
            # Offline fallback: return stale cache if available
            disk = self._get_stale_cached(terms_name)
            if disk is not None:
                return disk
            return {"accepted": False, "error": str(exc)}

    def check_all(self) -> Dict[str, Dict[str, Any]]:
        """
        Check acceptance status for all terms documents.

        Returns:
            Dict mapping terms_name to its status dict.
        """
        results: Dict[str, Dict[str, Any]] = {}
        for name in sorted(VALID_TERMS_NAMES):
            results[name] = self.check_status(name)
        return results

    # ------------------------------------------------------------------
    # Record acceptance (POST /terms/accept)
    # ------------------------------------------------------------------

    def accept(
        self,
        terms_name: str,
        method: str,
        email: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Record acceptance of a terms document.

        Args:
            terms_name: One of 'tos', 'privacy_policy', 'esla'.
            method: Acceptance method (e.g. 'cli_prompt', 'web_form').
            email: Optional user email for dual-key record.

        Returns:
            Dict with acceptance result from the API.

        Raises:
            ValueError: If terms_name or method is invalid.
        """
        if terms_name not in VALID_TERMS_NAMES:
            raise ValueError(
                f"Invalid terms_name: '{terms_name}'. "
                f"Must be one of: {', '.join(sorted(VALID_TERMS_NAMES))}"
            )
        if method not in VALID_ACCEPTANCE_METHODS:
            raise ValueError(
                f"Invalid acceptance_method: '{method}'. "
                f"Must be one of: {', '.join(sorted(VALID_ACCEPTANCE_METHODS))}"
            )

        if not REQUESTS_AVAILABLE:
            return {"error": "requests library not available"}

        body: Dict[str, Any] = {
            "machine_fingerprint": self.get_machine_fingerprint(),
            "terms_name": terms_name,
            "terms_version": CURRENT_TERMS_VERSIONS[terms_name],
            "acceptance_method": method,
            "platform": platform.system(),
            "python_version": platform.python_version(),
        }
        if email:
            body["email"] = email

        try:
            resp = requests.post(
                f"{self.api_endpoint}/terms/accept",
                json=body,
                timeout=self.timeout,
            )
            try:
                data = resp.json()
            except (ValueError, TypeError):
                return {"error": "Invalid JSON in API response"}
            if resp.ok:
                # Invalidate cache so next check_status hits the API
                self._invalidate_cached(terms_name)
            return data
        except Exception as exc:
            logger.debug("Terms accept API error for %s: %s", terms_name, exc)
            return {"error": str(exc)}

    def accept_all(
        self,
        method: str,
        email: Optional[str] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Accept all terms documents.

        Args:
            method: Acceptance method.
            email: Optional user email.

        Returns:
            Dict mapping terms_name to its acceptance result.
        """
        results: Dict[str, Dict[str, Any]] = {}
        for name in sorted(VALID_TERMS_NAMES):
            results[name] = self.accept(name, method=method, email=email)
        return results

    # ------------------------------------------------------------------
    # Withdraw consent (POST /terms/withdraw)
    # ------------------------------------------------------------------

    def withdraw(
        self, terms_name: str, email: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Withdraw consent for a terms document.

        Args:
            terms_name: One of 'tos', 'privacy_policy', 'esla'.
            email: Optional email for EMAIL# record update.

        Returns:
            Dict with withdrawal result from the API.

        Raises:
            ValueError: If terms_name is not recognised.
        """
        if terms_name not in VALID_TERMS_NAMES:
            raise ValueError(
                f"Invalid terms_name: '{terms_name}'. "
                f"Must be one of: {', '.join(sorted(VALID_TERMS_NAMES))}"
            )

        if not REQUESTS_AVAILABLE:
            return {"error": "requests library not available"}

        body: Dict[str, Any] = {
            "machine_fingerprint": self.get_machine_fingerprint(),
            "terms_name": terms_name,
        }
        if email:
            body["email"] = email

        try:
            resp = requests.post(
                f"{self.api_endpoint}/terms/withdraw",
                json=body,
                timeout=self.timeout,
            )
            try:
                data = resp.json()
            except (ValueError, TypeError):
                return {"error": "Invalid JSON in API response"}
            if resp.ok:
                self._invalidate_cached(terms_name)
            return data
        except Exception as exc:
            logger.debug("Terms withdraw API error for %s: %s", terms_name, exc)
            return {"error": str(exc)}

    # ------------------------------------------------------------------
    # Cache management
    # ------------------------------------------------------------------

    def _get_cached(self, terms_name: str) -> Optional[Dict[str, Any]]:
        """Return in-memory cached result if present and TTL has not expired."""
        entry = self._cache.get(terms_name)
        if entry is None:
            return None
        elapsed = time.monotonic() - entry["timestamp"]
        if elapsed <= self.cache_ttl_seconds:
            return entry["data"]
        return None

    def _get_stale_cached(self, terms_name: str) -> Optional[Dict[str, Any]]:
        """Return cached result regardless of TTL (offline fallback)."""
        entry = self._cache.get(terms_name)
        if entry is not None:
            return entry["data"]
        return None

    def _set_cached(self, terms_name: str, data: Dict[str, Any]) -> None:
        """Store result in both in-memory and disk cache."""
        self._cache[terms_name] = {
            "data": data,
            "timestamp": time.monotonic(),
        }
        self._save_disk_cache()

    def _invalidate_cached(self, terms_name: str) -> None:
        """Remove a terms_name from the cache."""
        self._cache.pop(terms_name, None)
        self._save_disk_cache()

    def _load_disk_cache(self) -> None:
        """Load cache from disk file if available."""
        if not self._cache_file.exists():
            return
        try:
            raw = json.loads(self._cache_file.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                return
            now_wall = time.time()
            now_mono = time.monotonic()
            for name, entry in raw.items():
                if isinstance(entry, dict) and "data" in entry:
                    disk_wall = entry.get("wall_time", 0)
                    age = now_wall - disk_wall
                    # Discard entries from the future (clock drift) or
                    # unreasonably old (> 2x TTL), but keep for offline
                    # fallback via _get_stale_cached even if TTL-expired.
                    if age < 0:
                        logger.debug(
                            "Discarding future-dated cache entry for %s", name
                        )
                        continue
                    self._cache[name] = {
                        "data": entry["data"],
                        "timestamp": now_mono - age,
                    }
        except (json.JSONDecodeError, OSError, KeyError):
            logger.debug("Failed to load terms cache from disk")

    def _save_disk_cache(self) -> None:
        """Persist in-memory cache to disk for cross-session re-use.

        Uses atomic write (temp file + rename) and restricts file
        permissions to owner-only (0600) to protect cached data.
        """
        try:
            serialisable: Dict[str, Any] = {}
            now_mono = time.monotonic()
            now_wall = time.time()
            for name, entry in self._cache.items():
                age = now_mono - entry["timestamp"]
                serialisable[name] = {
                    "data": entry["data"],
                    "wall_time": now_wall - age,
                }
            # Atomic write: write to temp file then rename
            temp_file = self._cache_file.with_suffix(".tmp")
            temp_file.write_text(
                json.dumps(serialisable, indent=2),
                encoding="utf-8",
            )
            # Restrict permissions to owner read/write only (0600)
            try:
                temp_file.chmod(stat.S_IRUSR | stat.S_IWUSR)
            except OSError:
                pass  # chmod may fail on some filesystems; proceed anyway
            temp_file.replace(self._cache_file)
        except OSError:
            logger.debug("Failed to save terms cache to disk")


# ============================================================================
# Module-level convenience functions
# ============================================================================

# Singleton client instance (lazy-created by get_terms_client)
_singleton_lock = threading.Lock()
_singleton_client: Optional[TermsAcceptanceClient] = None


def _default_cache_dir() -> str:
    """Return the default cache directory path for terms acceptance data."""
    return str(Path.home() / ".epochly" / "cache" / "terms")


def get_terms_client() -> TermsAcceptanceClient:
    """
    Get or create the singleton TermsAcceptanceClient.

    Thread-safe via double-checked locking.

    Returns:
        TermsAcceptanceClient instance (same object on repeated calls).
    """
    global _singleton_client
    if _singleton_client is None:
        with _singleton_lock:
            if _singleton_client is None:
                _singleton_client = TermsAcceptanceClient(
                    cache_dir=_default_cache_dir(),
                )
    return _singleton_client


def check_all_terms_accepted() -> bool:
    """
    Check whether all terms documents have been accepted.

    Convenience function for quick checks at CLI startup or license gates.
    Creates a fresh client each call so environment changes are respected.

    Returns:
        True if every terms document is accepted with the current version.
    """
    client = TermsAcceptanceClient(cache_dir=_default_cache_dir())
    results = client.check_all()
    return all(
        r.get("accepted") is True and r.get("needs_reaccept") is not True
        for r in results.values()
    )
