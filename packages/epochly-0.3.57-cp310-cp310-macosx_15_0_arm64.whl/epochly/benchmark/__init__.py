"""
Epochly Benchmark Module.

Provides reproducible, self-contained benchmarks that demonstrate Epochly's
performance characteristics across JIT compilation, GPU acceleration, and
parallel CPU workloads.

Usage:
    python -m epochly.benchmark           # Run default benchmark suite
    python -m epochly.benchmark --quick   # Quick validation (3 iterations)
    python -m epochly.benchmark --json    # Machine-readable JSON output
    python -m epochly.benchmark --list    # List available workloads
"""

from epochly.benchmark.workloads import (
    WorkloadSpec,
    get_all_workloads,
    get_workloads_by_category,
)
from epochly.benchmark.runner import (
    BenchmarkResult,
    BenchmarkRunner,
    EpochlyConfig,
    compute_median,
)
from epochly.benchmark.system_info import (
    collect_system_info,
    format_system_line,
)

__all__ = [
    "WorkloadSpec",
    "get_all_workloads",
    "get_workloads_by_category",
    "BenchmarkResult",
    "BenchmarkRunner",
    "EpochlyConfig",
    "compute_median",
    "collect_system_info",
    "format_system_line",
]
