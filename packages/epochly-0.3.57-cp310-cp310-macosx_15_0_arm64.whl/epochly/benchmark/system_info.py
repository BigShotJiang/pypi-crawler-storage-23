"""
Epochly Benchmark System Information.

Collects and formats system information for benchmark reports:
  - CPU model and core count
  - Python version
  - Epochly version
  - GPU availability (via GPUDetector)
  - Platform information
"""

import multiprocessing
import platform
import sys

from epochly.gpu.gpu_detector import GPUDetector


def _get_cpu_model() -> str:
    """Detect the CPU model name."""
    cpu_brand = platform.processor()
    if cpu_brand:
        return cpu_brand

    if sys.platform == "darwin":
        try:
            import subprocess
            result = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            pass

    if sys.platform == "linux":
        try:
            with open("/proc/cpuinfo", "r") as f:
                for line in f:
                    if line.startswith("model name"):
                        return line.split(":", 1)[1].strip()
        except (FileNotFoundError, OSError):
            pass

    return platform.machine() or "Unknown CPU"


def _get_epochly_version() -> str:
    """Get the installed Epochly version string."""
    try:
        from importlib.metadata import version as _get_version
        return _get_version("epochly")
    except Exception:
        try:
            import epochly
            return getattr(epochly, "__version__", "unknown")
        except Exception:
            return "unknown"


def collect_system_info() -> dict:
    """
    Collect comprehensive system information for benchmark reports.

    Returns a dictionary with keys:
      - cpu_model: str - CPU brand string
      - cpu_cores: int - Number of logical CPU cores
      - python_version: str - Python version (major.minor.micro)
      - epochly_version: str - Installed Epochly version
      - gpu_available: bool - Whether GPU is detected
      - platform: str - OS platform string
    """
    gpu_available = False
    try:
        gpu_available = GPUDetector.is_available()
    except Exception:
        gpu_available = False

    return {
        "cpu_model": _get_cpu_model(),
        "cpu_cores": multiprocessing.cpu_count(),
        "python_version": (
            f"{sys.version_info.major}"
            f".{sys.version_info.minor}"
            f".{sys.version_info.micro}"
        ),
        "epochly_version": _get_epochly_version(),
        "gpu_available": gpu_available,
        "platform": platform.platform(),
    }


def format_system_line() -> str:
    """
    Format a one-line system summary for benchmark output headers.

    Example:
      "Python 3.12.1 | Epochly 0.5.0 | 8 cores | Apple M2 Pro | No GPU"
    """
    info = collect_system_info()

    gpu_part = "GPU available" if info["gpu_available"] else "No GPU"

    return (
        f"Python {info['python_version']} | "
        f"Epochly {info['epochly_version']} | "
        f"{info['cpu_cores']} cores | "
        f"{info['cpu_model']} | "
        f"{gpu_part}"
    )
