"""
Epochly Benchmark Workloads.

Self-contained workload definitions for the 7 website-claimed benchmark
categories. Each workload provides:
  - A baseline execution function (pure Python / standard library)
  - Metadata for display, categorization, and expected speedup ranges
  - Size parameters calibrated for meaningful measurement

These workloads ship with pip install epochly and do NOT depend on the
benchmarks/ directory at the project root.
"""

import math
import multiprocessing
import random
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from typing import Callable, Dict, Tuple


@dataclass(frozen=True)
class WorkloadSpec:
    """Specification for a single benchmark workload."""

    name: str
    code_name: str
    category: str  # 'cpu' or 'gpu'
    execute: Callable[[int], float]
    size: int
    expected_speedup_range: Tuple[float, float]


# ---------------------------------------------------------------------------
# CPU workload execute functions
# ---------------------------------------------------------------------------

def _jit_polynomial_execute(size: int) -> float:
    """
    JIT Polynomial Evaluation workload.

    Loop calling a polynomial kernel - optimal pattern for Epochly JIT.
    Computes sum of polynomial evaluations: x^3 + 2x^2 + 3x + 1
    for x in range(size).

    Maps to: benchmarks/unified/workloads.py optimal_pattern
    """
    result = 0.0
    for i in range(size):
        x = float(i)
        result += x * x * x + 2.0 * x * x + 3.0 * x + 1.0
    return result


def _jit_numerical_execute(size: int) -> float:
    """
    JIT Numerical Loop workload.

    Simple inline arithmetic in a tight loop - JIT-friendly pattern.
    Computes sum of i^2 + i + 1.0 for each i.

    Maps to: benchmarks/unified/workloads.py simple_numerical
    """
    result = 0.0
    for i in range(size):
        result += float(i) ** 2 + float(i) + 1.0
    return result


def _parallel_cpu_chunk(args: tuple) -> float:
    """Process a single chunk of CPU-bound work (module-level for pickling)."""
    chunk_id, chunk_size, seed = args
    rng = random.Random(seed)
    total = 0.0
    for _ in range(chunk_size):
        x = rng.random()
        total += math.sqrt(x) * math.log1p(x) + math.sin(x)
    return total


def _parallel_cpu_execute(size: int) -> float:
    """
    Parallel CPU workload.

    Uses ProcessPoolExecutor to distribute work across cores.
    The size parameter determines the number of parallel workers.
    Each worker processes 10,000 iterations of CPU-bound math.

    Maps to: benchmarks/unified/workloads.py batch_data_pipeline
    """
    cpu_cap = multiprocessing.cpu_count() or 8
    num_workers = max(1, min(size, cpu_cap))
    chunk_size = 10_000
    chunks = [(i, chunk_size, i * 42) for i in range(num_workers)]

    total = 0.0
    with ProcessPoolExecutor(max_workers=num_workers) as executor:
        results = list(executor.map(_parallel_cpu_chunk, chunks, timeout=300))

    for r in results:
        total += r
    return total


def _monte_carlo_execute(size: int) -> float:
    """
    Monte Carlo Pi Estimation workload.

    Estimates pi using random point sampling in a unit square.
    Points inside the unit circle (x^2 + y^2 <= 1) approximate pi/4.
    Uses deterministic seed for reproducible results.

    This is a classic embarrassingly parallel workload that benefits
    from both JIT compilation and multi-core parallelization.
    """
    rng = random.Random(42)
    inside = 0
    for _ in range(size):
        x = rng.random()
        y = rng.random()
        if x * x + y * y <= 1.0:
            inside += 1
    return 4.0 * inside / size


# ---------------------------------------------------------------------------
# GPU workload execute functions
# ---------------------------------------------------------------------------

def _gpu_elementwise_execute(size: int) -> float:
    """
    GPU Element-wise Operations workload.

    Performs element-wise mathematical operations on arrays.
    Uses CuPy when GPU is available, falls back to NumPy/pure Python.

    Demonstrates GPU acceleration for embarrassingly parallel element-wise ops.
    """
    try:
        import cupy as cp
        a = cp.arange(size, dtype=cp.float64)
        b = cp.sin(a) + cp.cos(a) * cp.sqrt(a + 1.0)
        result = float(cp.sum(b))
        cp.cuda.Stream.null.synchronize()
        return result
    except Exception:
        pass

    try:
        import numpy as np
        a = np.arange(size, dtype=np.float64)
        b = np.sin(a) + np.cos(a) * np.sqrt(a + 1.0)
        return float(np.sum(b))
    except ImportError:
        total = 0.0
        for i in range(size):
            x = float(i)
            total += math.sin(x) + math.cos(x) * math.sqrt(x + 1.0)
        return total


def _gpu_reduction_execute(size: int) -> float:
    """
    GPU Reduction workload.

    Performs parallel reduction (sum, max, min) across large arrays.
    Uses CuPy when GPU is available, falls back to NumPy/pure Python.

    Demonstrates GPU acceleration for reduction operations that require
    tree-based parallel aggregation.
    """
    try:
        import cupy as cp
        rng = cp.random.default_rng(seed=42)
        data = rng.standard_normal(size, dtype=cp.float64)
        total = float(cp.sum(data))
        maximum = float(cp.max(data))
        minimum = float(cp.min(data))
        cp.cuda.Stream.null.synchronize()
        return total + maximum - minimum
    except Exception:
        pass

    try:
        import numpy as np
        rng = np.random.default_rng(seed=42)
        data = rng.standard_normal(size)
        return float(np.sum(data) + np.max(data) - np.min(data))
    except ImportError:
        rng = random.Random(42)
        data = [rng.gauss(0, 1) for _ in range(size)]
        return sum(data) + max(data) - min(data)


def _gpu_convolution_execute(size: int) -> float:
    """
    GPU 2D Convolution workload.

    Applies a 3x3 convolution kernel to a 2D matrix.
    Uses CuPy when GPU is available, falls back to NumPy/SciPy.

    Demonstrates GPU acceleration for stencil-based operations common
    in image processing and scientific computing.
    """
    side = max(4, int(math.sqrt(size)))

    try:
        import cupy as cp
        from cupyx.scipy.ndimage import convolve as gpu_convolve
        rng = cp.random.default_rng(seed=42)
        matrix = rng.standard_normal((side, side), dtype=cp.float64)
        kernel = cp.array([[1, 2, 1], [2, 4, 2], [1, 2, 1]], dtype=cp.float64) / 16.0
        result = gpu_convolve(matrix, kernel)
        cp.cuda.Stream.null.synchronize()
        return float(cp.sum(result))
    except Exception:
        pass

    try:
        import numpy as np
        from scipy.ndimage import convolve
        rng = np.random.default_rng(seed=42)
        matrix = rng.standard_normal((side, side))
        kernel = np.array([[1, 2, 1], [2, 4, 2], [1, 2, 1]], dtype=np.float64) / 16.0
        result = convolve(matrix, kernel)
        return float(np.sum(result))
    except ImportError:
        total = 0.0
        rng = random.Random(42)
        matrix = [[rng.gauss(0, 1) for _ in range(side)] for _ in range(side)]
        for i in range(1, side - 1):
            for j in range(1, side - 1):
                val = (
                    matrix[i - 1][j - 1] + 2 * matrix[i - 1][j] + matrix[i - 1][j + 1]
                    + 2 * matrix[i][j - 1] + 4 * matrix[i][j] + 2 * matrix[i][j + 1]
                    + matrix[i + 1][j - 1] + 2 * matrix[i + 1][j] + matrix[i + 1][j + 1]
                ) / 16.0
                total += val
        return total


# ---------------------------------------------------------------------------
# Workload registry
# ---------------------------------------------------------------------------

_ALL_WORKLOADS: Dict[str, WorkloadSpec] = {
    'jit_polynomial': WorkloadSpec(
        name='JIT Polynomial Evaluation',
        code_name='jit_polynomial',
        category='cpu',
        execute=_jit_polynomial_execute,
        size=5_000_000,
        expected_speedup_range=(10.0, 250.0),
    ),
    'jit_numerical': WorkloadSpec(
        name='JIT Numerical Loop',
        code_name='jit_numerical',
        category='cpu',
        execute=_jit_numerical_execute,
        size=1_500_000,
        expected_speedup_range=(2.0, 100.0),
    ),
    'gpu_elementwise': WorkloadSpec(
        name='GPU Element-wise Operations',
        code_name='gpu_elementwise',
        category='gpu',
        execute=_gpu_elementwise_execute,
        size=10_000_000,
        expected_speedup_range=(5.0, 100.0),
    ),
    'gpu_reduction': WorkloadSpec(
        name='GPU Parallel Reduction',
        code_name='gpu_reduction',
        category='gpu',
        execute=_gpu_reduction_execute,
        size=50_000_000,
        expected_speedup_range=(3.0, 80.0),
    ),
    'gpu_convolution': WorkloadSpec(
        name='GPU 2D Convolution',
        code_name='gpu_convolution',
        category='gpu',
        execute=_gpu_convolution_execute,
        size=1_000_000,
        expected_speedup_range=(5.0, 50.0),
    ),
    'parallel_cpu': WorkloadSpec(
        name='Parallel CPU Processing',
        code_name='parallel_cpu',
        category='cpu',
        execute=_parallel_cpu_execute,
        size=8,
        expected_speedup_range=(2.0, 16.0),
    ),
    'monte_carlo': WorkloadSpec(
        name='Monte Carlo Pi Estimation',
        code_name='monte_carlo',
        category='cpu',
        execute=_monte_carlo_execute,
        size=1_000_000,
        expected_speedup_range=(2.0, 15.0),
    ),
}


def get_all_workloads() -> Dict[str, WorkloadSpec]:
    """Return all registered benchmark workloads."""
    return dict(_ALL_WORKLOADS)


def get_workloads_by_category(category: str) -> Dict[str, WorkloadSpec]:
    """Return workloads filtered by category ('cpu' or 'gpu')."""
    return {
        name: spec
        for name, spec in _ALL_WORKLOADS.items()
        if spec.category == category
    }
