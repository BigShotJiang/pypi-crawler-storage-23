"""
Shannon Entropy Scorer
======================

Measures the **information density** of each context fragment using
Shannon entropy, TF-IDF cross-fragment redundancy, and a novel
"information surprise" metric.

The core insight (from ICPC, arXiv 2025): not all tokens carry equal
information. Boilerplate code (`import os`, `def __init__`) has near-zero
entropy — it's predictable. But a specific error message or a novel
algorithm implementation has high entropy — it's surprising and informative.

Three scoring dimensions:
  1. **Character-level Shannon entropy**: Raw information density
  2. **Token-level surprisal**: How unexpected each token is given
     the session's token distribution (self-information)
  3. **Cross-fragment redundancy**: TF-IDF-style scoring that
     penalizes fragments containing information already present
     in other fragments

By combining these, we can rank fragments not just by recency or
relevance, but by how much UNIQUE INFORMATION they contribute.

References:
    - Shannon, C. "A Mathematical Theory of Communication" (1948)
    - ICPC: "In-context Prompt Compression" (arXiv 2025)
    - LLMLingua: "Compressing Prompts for Accelerated Inference" (EMNLP 2023)
    - ILRe: "Intermediate Layer Retrieval" (ICLR 2026)
"""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import Dict, List, Optional


# ── Common boilerplate patterns (low information, high predictability) ──
_BOILERPLATE_PATTERNS = [
    r"^\s*import\s+\w+",
    r"^\s*from\s+\w+\s+import",
    r"^\s*def\s+__\w+__\s*\(",  # dunder methods
    r"^\s*class\s+\w+\s*(\(.*\))?\s*:",
    r"^\s*return\s+(None|self|True|False)\s*$",
    r"^\s*pass\s*$",
    r"^\s*\.\.\.\s*$",
    r"^\s*#\s*(TODO|FIXME|HACK|XXX|NOTE)\b",
    r"^\s*(\"\"\"|\'\'\')$",
    r"^\s*\}\s*$",
    r"^\s*\)\s*$",
    r"^\s*\]\s*$",
]
_BOILERPLATE_RE = [re.compile(p) for p in _BOILERPLATE_PATTERNS]


def shannon_entropy(text: str) -> float:
    """
    Compute the character-level Shannon entropy of a text string.

        H(X) = -Σ p(xᵢ) · log₂(p(xᵢ))

    Returns bits per character. English text averages ~4.2 bits/char.
    Code typically ranges from 3.5 (boilerplate) to 5.5 (novel logic).

    A perfectly random string of 256 possible bytes would have H = 8.0.
    A string of all identical characters has H = 0.0.
    """
    if not text:
        return 0.0

    counts = Counter(text)
    length = len(text)
    entropy = 0.0

    for count in counts.values():
        p = count / length
        if p > 0:
            entropy -= p * math.log2(p)

    return entropy


def normalized_entropy(text: str, max_entropy: float = 6.0) -> float:
    """
    Normalize Shannon entropy to [0, 1] range.

    Max entropy for source code is empirically ~6.0 bits/char.
    Values above this are clipped to 1.0.
    """
    if not text:
        return 0.0
    raw = shannon_entropy(text)
    return min(raw / max_entropy, 1.0)


def boilerplate_ratio(text: str) -> float:
    """
    Compute the fraction of lines that match common boilerplate patterns.

    Returns a value in [0, 1]:
      0.0 = no boilerplate (all novel code)
      1.0 = all boilerplate (imports, pass, empty blocks)

    This penalizes fragments full of imports or stub implementations
    that contribute little unique information to the context.
    """
    lines = text.strip().split("\n")
    if not lines:
        return 0.0

    boilerplate_count = 0
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        for pattern in _BOILERPLATE_RE:
            if pattern.match(stripped):
                boilerplate_count += 1
                break

    non_empty = sum(1 for l in lines if l.strip())
    if non_empty == 0:
        return 1.0

    return boilerplate_count / non_empty


def token_surprisal(
    text: str,
    global_token_counts: Dict[str, int],
    total_tokens: int,
) -> float:
    """
    Compute the average self-information (surprisal) of tokens in this
    fragment relative to the global session distribution.

    Surprisal of token t:
        I(t) = -log₂(p(t))
        where p(t) = count(t, global) / total_tokens

    Tokens that are rare in the session (e.g., a specific variable name
    that appears only in this fragment) have HIGH surprisal — they carry
    the most information.

    Tokens that are common (e.g., 'the', 'def', 'return') have LOW
    surprisal — they're predictable and carry little information.

    This is the dual of Shannon entropy: entropy measures the average
    surprise of a SOURCE, while surprisal measures the surprise of
    individual TOKENS relative to a background distribution.

    Reference: Shannon (1948), Information Theory applied to lexical
    diversity measurement.
    """
    if total_tokens == 0 or not text:
        return 0.0

    # Simple whitespace tokenization (fast, no dependencies)
    tokens = text.lower().split()
    if not tokens:
        return 0.0

    total_surprisal = 0.0
    for token in tokens:
        count = global_token_counts.get(token, 0)
        if count == 0:
            # Unseen token → maximum surprisal (capped)
            total_surprisal += 20.0  # ~2^20 = 1M vocabulary
        else:
            p = count / total_tokens
            total_surprisal += -math.log2(p)

    return total_surprisal / len(tokens)


def cross_fragment_redundancy(
    fragment_text: str,
    other_fragments: List[str],
    ngram_size: int = 3,
) -> float:
    """
    Compute how much of this fragment's information is already present
    in other fragments using n-gram overlap (TF-IDF inspired).

    Returns a value in [0, 1]:
      0.0 = completely unique information (no overlap with others)
      1.0 = completely redundant (all n-grams found in other fragments)

    Uses word-level n-grams (trigrams by default) for a balance between
    exact matching (too strict) and unigram matching (too loose).

    This catches cases where the same function definition appears in
    multiple tool results — a common source of context bloat.
    """
    if not fragment_text or not other_fragments:
        return 0.0

    # Extract n-grams from this fragment
    words = fragment_text.lower().split()
    if len(words) < ngram_size:
        return 0.0

    fragment_ngrams = set()
    for i in range(len(words) - ngram_size + 1):
        fragment_ngrams.add(tuple(words[i : i + ngram_size]))

    if not fragment_ngrams:
        return 0.0

    # Build n-gram set from all other fragments
    other_ngrams = set()
    for other in other_fragments:
        other_words = other.lower().split()
        for i in range(len(other_words) - ngram_size + 1):
            other_ngrams.add(tuple(other_words[i : i + ngram_size]))

    # Compute overlap ratio
    overlap = fragment_ngrams & other_ngrams
    return len(overlap) / len(fragment_ngrams)


def compute_information_score(
    text: str,
    global_token_counts: Optional[Dict[str, int]] = None,
    total_tokens: int = 0,
    other_fragments: Optional[List[str]] = None,
) -> float:
    """
    Compute the final information density score for a context fragment.

    Combines three metrics:
      1. Shannon entropy (40% weight) — raw information density
      2. Boilerplate penalty (30% weight) — penalizes predictable code
      3. Cross-fragment redundancy (30% weight) — penalizes duplicated info

    If global token counts are available, token surprisal is blended
    into the Shannon entropy component for a more session-aware score.

    Returns a value in [0, 1] where:
      1.0 = maximally informative, unique, surprising content
      0.0 = empty, boilerplate, or fully redundant content
    """
    if not text.strip():
        return 0.0

    # 1. Shannon entropy (normalized)
    ent = normalized_entropy(text)

    # Blend with token surprisal if available
    if global_token_counts and total_tokens > 0:
        surprisal = token_surprisal(text, global_token_counts, total_tokens)
        # Normalize surprisal (typical range 5-15, cap at 20)
        norm_surprisal = min(surprisal / 20.0, 1.0)
        # 60% entropy, 40% surprisal
        ent = 0.6 * ent + 0.4 * norm_surprisal

    # 2. Boilerplate penalty
    bp = boilerplate_ratio(text)
    boilerplate_score = 1.0 - bp  # Invert: low boilerplate → high score

    # 3. Cross-fragment redundancy
    if other_fragments:
        redundancy = cross_fragment_redundancy(text, other_fragments)
        uniqueness_score = 1.0 - redundancy
    else:
        uniqueness_score = 1.0

    # Weighted combination
    score = (
        0.40 * ent
        + 0.30 * boilerplate_score
        + 0.30 * uniqueness_score
    )

    return round(max(0.0, min(1.0, score)), 4)
