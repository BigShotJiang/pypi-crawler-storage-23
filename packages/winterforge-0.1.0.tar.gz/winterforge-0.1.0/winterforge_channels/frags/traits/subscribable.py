"""Subscribable trait - has subscribers."""

from __future__ import annotations

from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge_channels.primitives.subscription import (
        Subscription,
    )

from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root


@frag_trait()
@root('subscribable')
class SubscribableTrait:
    """Has subscribers."""

    async def get_subscribers(self) -> List:
        """
        Get all subscribers to this channel.

        Returns:
            List of subscriber Frags
        """
        from winterforge_channels.registries import SubscriptionRegistry

        subs_registry = SubscriptionRegistry()
        # Filter by alias directly since loaded Frags might not have
        # Subscription properties
        subscriptions_registry = await subs_registry.filter(
            lambda s: s.aliases.get('channel') == str(self.id)
        )
        subscriptions = await subscriptions_registry.all()

        # Resolve subscriber Frags
        subscribers = []
        for sub in subscriptions:
            subscriber_id = int(sub.aliases.get('subscriber', 0))
            if subscriber_id:
                from winterforge.frags.registries import FragRegistry

                registry = FragRegistry({})
                subscriber = await registry.get(subscriber_id)
                if subscriber:
                    subscribers.append(subscriber)

        return subscribers

    async def subscribe(self, subscriber_id: int) -> 'Subscription':
        """
        Add subscriber to channel.

        Args:
            subscriber_id: Frag ID of subscriber

        Returns:
            Subscription Frag
        """
        from winterforge_channels.primitives import Subscription

        sub = Subscription()
        sub.set_alias('subscriber', str(subscriber_id))
        sub.set_alias('channel', str(self.id))
        await sub.save()

        return sub

    async def unsubscribe(self, subscriber_id: int) -> None:
        """
        Remove subscriber from channel.

        Args:
            subscriber_id: Frag ID to unsubscribe
        """
        from winterforge_channels.registries import SubscriptionRegistry

        subs = SubscriptionRegistry()
        subscriptions_registry = await subs.filter(
            lambda s: (
                s.aliases.get('subscriber') == str(subscriber_id)
                and s.aliases.get('channel') == str(self.id)
            )
        )
        subscriptions = await subscriptions_registry.all()

        for subscription in subscriptions:
            await subscription.delete()
