"""Conversable trait - tracks canonical conversation membership."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root


@frag_trait(requires=['fieldable', 'persistable'])
@root('conversable')
class ConversableTrait:
    """
    Tracks canonical conversation membership.

    Messages belong to a conversation (chat session, thread).
    """

    class Schema(BaseModel):
        """Conversable field schema."""

        conversation_id: int | None = None

    @property
    def conversation_id(self) -> Optional[int]:
        """Return ID of canonical conversation."""
        self._ensure_schema()
        return self._fieldable_data.conversation_id

    def set_conversation_id(
        self,
        conv_id: Optional[int]
    ) -> 'ConversableTrait':
        """
        Set canonical conversation.

        Returns:
            Reference to self for chaining.
        """
        self._ensure_schema()
        self._fieldable_data.conversation_id = conv_id
        return self

    async def get_conversation(self):
        """
        Resolve canonical conversation Frag.

        Returns:
            Conversation Frag or None.
        """
        if not self.conversation_id:
            return None

        from winterforge.frags.registries import FragRegistry

        registry = FragRegistry({})
        return await registry.get(self.conversation_id)
