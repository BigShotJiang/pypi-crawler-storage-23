"""Traits for channels extension."""

from winterforge_channels.frags.traits.messageable import MessageableTrait
from winterforge_channels.frags.traits.conversable import ConversableTrait
from winterforge_channels.frags.traits.transportable import (
    TransportableTrait,
)
from winterforge_channels.frags.traits.subscribable import (
    SubscribableTrait,
)
from winterforge_channels.frags.traits.routable import RoutableTrait

__all__ = [
    'MessageableTrait',
    'ConversableTrait',
    'TransportableTrait',
    'SubscribableTrait',
    'RoutableTrait',
]
