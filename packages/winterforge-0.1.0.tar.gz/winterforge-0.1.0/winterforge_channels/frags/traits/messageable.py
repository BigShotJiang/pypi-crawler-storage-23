"""Messageable trait - provides message content and metadata."""

from __future__ import annotations

from pydantic import BaseModel
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root


@frag_trait(requires=['fieldable', 'persistable'])
@root('messageable')
class MessageableTrait:
    """
    Message content and metadata.

    Provides content, author tracking, and content type.
    """

    class Schema(BaseModel):
        """Messageable field schema."""

        content: str = ''
        author_id: int = 0
        content_type: str = 'text/plain'

    @property
    def content(self) -> str:
        """Return message content."""
        self._ensure_schema()
        return self._fieldable_data.content

    @property
    def author_id(self) -> int:
        """Return author Frag ID."""
        self._ensure_schema()
        return self._fieldable_data.author_id

    @property
    def content_type(self) -> str:
        """Return content MIME type."""
        self._ensure_schema()
        return self._fieldable_data.content_type

    def set_content(self, content: str) -> 'MessageableTrait':
        """
        Set message content.

        Returns:
            Reference to self for chaining.
        """
        self._ensure_schema()
        self._fieldable_data.content = content
        return self

    def set_author_id(self, author_id: int) -> 'MessageableTrait':
        """
        Set author ID.

        Returns:
            Reference to self for chaining.
        """
        self._ensure_schema()
        self._fieldable_data.author_id = author_id
        return self

    def set_content_type(self, content_type: str) -> 'MessageableTrait':
        """
        Set content type.

        Returns:
            Reference to self for chaining.
        """
        self._ensure_schema()
        self._fieldable_data.content_type = content_type
        return self
