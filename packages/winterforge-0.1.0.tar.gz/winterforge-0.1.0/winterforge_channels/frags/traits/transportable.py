"""Transportable trait - enables sending via channels."""

from __future__ import annotations

from winterforge.frags import Manifest
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root


@frag_trait()
@root('transportable')
class TransportableTrait:
    """Can be sent via channels."""

    async def send_to_channels(self, channels: Manifest):
        """
        Send via channels.

        For each channel:
        1. Permission check (can author submit?)
        2. Get egress transport (first-match)
        3. Get subscribers
        4. Send via transport

        Args:
            channels: Manifest of Channel Frags

        Returns:
            List of TransportResult objects
        """
        results = []

        for channel in channels:
            # Permission check
            if not await channel.can_submit(self.author_id):
                continue

            # Get egress transport repository
            egress_repo = channel.get_egress_repository()

            # Resolve first available transport
            transport = egress_repo.resolve()
            if not transport:
                continue

            # Get subscribers
            subscribers = await channel.get_subscribers()

            # Send
            channel_results = await transport.send(
                self,
                channel,
                subscribers,
            )
            results.extend(channel_results)

        return results
