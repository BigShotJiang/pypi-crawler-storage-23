"""Routable trait - routes messages to destinations."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge_channels.primitives.transport_result import (
        TransportResult,
    )

from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root


@frag_trait()
@root('routable')
class RoutableTrait:
    """Routes messages to destinations."""

    async def route_message(self, message) -> 'TransportResult':
        """
        Route message through this channel.

        Orchestrates:
        1. Get egress transport
        2. Get subscribers
        3. Deliver via transport

        Args:
            message: Message Frag to route

        Returns:
            TransportResult

        Raises:
            ValueError: If no egress transport available
        """
        # Get egress repository
        egress_repo = self.get_egress_repository()

        # Resolve first available transport
        transport = egress_repo.resolve()

        if not transport:
            raise ValueError(
                f"No egress transport available for channel {self.id}"
            )

        # Get subscribers
        subscribers = await self.get_subscribers()

        # Send
        return await transport.send(message, self, subscribers)
