"""Channel primitive - permission-controlled routing mechanism."""

from __future__ import annotations

from winterforge.frags import Frag


class Channel(Frag):
    """
    Channel primitive - transport mechanism for routing.

    Permission-controlled, transport-configurable.
    Uses WinterForge authorizable trait for access control.
    """

    def __init__(self, **kwargs):
        """Initialize channel with required composition."""
        # Enforce channel affinity
        affinities = kwargs.get('affinities', [])
        if 'channel' not in affinities:
            affinities.insert(0, 'channel')
        kwargs['affinities'] = affinities

        # Required traits
        traits = kwargs.get('traits', [])
        required_traits = [
            'subscribable',
            'routable',
            'authorizable',
            'persistable',
            'timestamped',
            'titled',
        ]
        for trait in required_traits:
            if trait not in traits:
                traits.append(trait)
        kwargs['traits'] = traits

        super().__init__(**kwargs)

    def get_ingress_repository(self):
        """
        Get ingress transport repository for this channel.

        Returns:
            IngressTransportRepository configured for this channel
        """
        from winterforge_channels.plugins.transports import (
            IngressTransportRepository,
        )

        return IngressTransportRepository(channel=self)

    def get_egress_repository(self):
        """
        Get egress transport repository for this channel.

        Returns:
            EgressTransportRepository configured for this channel
        """
        from winterforge_channels.plugins.transports import (
            EgressTransportRepository,
        )

        return EgressTransportRepository(channel=self)

    async def can_submit(self, user_id: int) -> bool:
        """
        Check if user can submit to channel.

        Uses authorizable trait for permission check.

        Args:
            user_id: User Frag ID

        Returns:
            True if user has channel.submit permission
        """
        try:
            from winterforge.frags.registries import FragRegistry

            # Load user Frag
            users = FragRegistry({'affinities': ['user']})
            user = await users.get(user_id)

            if not user:
                return False

            # Check if user has authorizable trait and permission
            if hasattr(user, 'has_permission'):
                return await user.has_permission('channel.submit')

            # No permission system = deny
            return False

        except Exception:
            # On error, deny access (fail closed)
            return False

    async def can_subscribe(self, user_id: int) -> bool:
        """
        Check if user can subscribe to channel.

        Uses authorizable trait for permission check.

        Args:
            user_id: User Frag ID

        Returns:
            True if user has channel.subscribe permission
        """
        try:
            from winterforge.frags.registries import FragRegistry

            # Load user Frag
            users = FragRegistry({'affinities': ['user']})
            user = await users.get(user_id)

            if not user:
                return False

            # Check if user has authorizable trait and permission
            if hasattr(user, 'has_permission'):
                return await user.has_permission('channel.subscribe')

            # No permission system = deny
            return False

        except Exception:
            # On error, deny access (fail closed)
            return False

    async def can_manage(self, user_id: int) -> bool:
        """
        Check if user can manage channel.

        Uses authorizable trait for permission check.

        Args:
            user_id: User Frag ID

        Returns:
            True if user has channel.manage permission
        """
        try:
            from winterforge.frags.registries import FragRegistry

            # Load user Frag
            users = FragRegistry({'affinities': ['user']})
            user = await users.get(user_id)

            if not user:
                return False

            # Check if user has authorizable trait and permission
            if hasattr(user, 'has_permission'):
                return await user.has_permission('channel.manage')

            # No permission system = deny
            return False

        except Exception:
            # On error, deny access (fail closed)
            return False
