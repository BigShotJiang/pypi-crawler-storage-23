"""Message primitive - transport-agnostic communication unit."""

from __future__ import annotations

from typing import Optional, List, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge_channels.primitives.transport_result import (
        TransportResult,
    )

from winterforge.frags import Frag


class Message(Frag):
    """
    Message primitive - fundamental communication unit.

    Transport-agnostic: doesn't know HOW it's delivered.
    Channels handle routing via pluggable transports.
    """

    def __init__(self, **kwargs):
        """Initialize message with required composition."""
        # Enforce message affinity
        affinities = kwargs.get('affinities', [])
        if 'message' not in affinities:
            affinities.insert(0, 'message')
        kwargs['affinities'] = affinities

        # Required traits
        traits = kwargs.get('traits', [])
        required_traits = [
            'messageable',
            'conversable',
            'transportable',
            'persistable',
            'timestamped',
        ]
        for trait in required_traits:
            if trait not in traits:
                traits.append(trait)
        kwargs['traits'] = traits

        super().__init__(**kwargs)

    # === Thread Management (Dedicated API) ===

    @property
    def reply_to_id(self) -> Optional[int]:
        """Message this replies to (threading)."""
        reply_to = self.aliases.get('reply_to')
        return int(reply_to) if reply_to else None

    def set_reply_to_id(
        self,
        message_id: Optional[int],
    ) -> 'Message':
        """
        Set reply target.

        Returns:
            Reference to self for chaining.
        """
        if message_id is None:
            self.remove_alias('reply_to')
        else:
            self.set_alias('reply_to', str(message_id))
        return self

    async def get_reply_to(self) -> Optional['Message']:
        """
        Resolve replied-to message.

        Returns:
            Message Frag or None
        """
        if not self.reply_to_id:
            return None

        from winterforge_channels.registries import MessageRegistry

        return await MessageRegistry().get(self.reply_to_id)

    # === Reference Management (Semantic Links) ===

    @property
    def reference_ids(self) -> List[int]:
        """IDs of referenced messages."""
        refs = self.aliases.get('references', '')
        if not refs:
            return []
        return [
            int(r.strip())
            for r in refs.split(',')
            if r.strip()
        ]

    def add_reference(self, message_id: int) -> 'Message':
        """
        Add message reference.

        Returns:
            Reference to self for chaining.
        """
        refs = self.reference_ids
        if message_id not in refs:
            refs.append(message_id)
            self.set_alias(
                'references',
                ','.join(str(r) for r in refs),
            )
        return self

    def remove_reference(self, message_id: int) -> 'Message':
        """
        Remove message reference.

        Returns:
            Reference to self for chaining.
        """
        refs = self.reference_ids
        if message_id in refs:
            refs.remove(message_id)
            ref_str = ','.join(str(r) for r in refs) if refs else ''
            self.set_alias('references', ref_str)
        return self

    async def get_references(self) -> List['Message']:
        """
        Resolve all referenced messages.

        Returns:
            List of Message Frags
        """
        from winterforge_channels.registries import MessageRegistry

        registry = MessageRegistry()

        references = []
        for ref_id in self.reference_ids:
            msg = await registry.get(ref_id)
            if msg:
                references.append(msg)

        return references

    # === Transport (via transportable trait) ===

    async def send(self, channels) -> List['TransportResult']:
        """
        Send via channels.

        Delegates to transportable trait's send_to_channels() method.

        Args:
            channels: Manifest of Channel Frags

        Returns:
            List of TransportResult objects
        """
        return await self.send_to_channels(channels)
