"""Subscription primitive - links subscriber to channel."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge_channels.primitives.channel import Channel

from winterforge.frags import Frag


class Subscription(Frag):
    """
    Subscription primitive - links subscriber to channel.

    Subscriber can be ANY Frag (User, Bot, Service, System).
    Simple relationship: subscriber_id + channel_id.
    """

    def __init__(self, **kwargs):
        """Initialize subscription with required composition."""
        # Enforce subscription affinity
        affinities = kwargs.get('affinities', [])
        if 'subscription' not in affinities:
            affinities.insert(0, 'subscription')
        kwargs['affinities'] = affinities

        # Required traits
        traits = kwargs.get('traits', [])
        required_traits = [
            'persistable',
            'timestamped',
        ]
        for trait in required_traits:
            if trait not in traits:
                traits.append(trait)
        kwargs['traits'] = traits

        super().__init__(**kwargs)

    @property
    def subscriber_id(self) -> int:
        """Subscriber Frag ID."""
        return int(self.aliases.get('subscriber'))

    @property
    def channel_id(self) -> int:
        """Channel Frag ID."""
        return int(self.aliases.get('channel'))

    async def get_subscriber(self) -> Frag:
        """
        Resolve subscriber Frag (any type).

        Returns:
            Subscriber Frag
        """
        from winterforge.frags.registries import FragRegistry

        registry = FragRegistry({})
        return await registry.get(self.subscriber_id)

    async def get_channel(self) -> 'Channel':
        """
        Resolve Channel.

        Returns:
            Channel Frag
        """
        from winterforge_channels.registries import ChannelRegistry

        return await ChannelRegistry().get(self.channel_id)
