"""Registry for Channel Frags."""

from __future__ import annotations

from typing import Optional, List

from winterforge.frags.registries import FragRegistry
from winterforge.frags import Frag


class ChannelRegistry(FragRegistry):
    """Registry for Channel Frags."""

    def __init__(self):
        """Initialize with channel composition."""
        super().__init__(composition={'affinities': ['channel']})

    async def all(self) -> List[Frag]:
        """
        Get all Channels.

        Overrides base to return typed Channel instances.

        Returns:
            List of Channel instances
        """
        from winterforge_channels.primitives import Channel

        # Get base Frags from parent
        frags = await super().all()

        # Convert each to typed Channel
        channels = []
        for frag in frags:
            channel = Channel(
                affinities=list(frag.composition.affinities),
                traits=list(frag.composition.traits),
                aliases=frag.aliases,
            )
            channel._set_id(frag.id)
            channel._loaded_from_storage = True

            # Copy fieldable data if present
            if hasattr(frag, '_fieldable_data') and frag._fieldable_data:
                channel._fieldable_data = frag._fieldable_data

            channel._initialize_traits()
            channels.append(channel)

        return channels

    async def _load_and_filter(self, frag_id: int) -> Optional[Frag]:
        """
        Load Channel by ID and return typed Channel instance.

        Overrides base implementation to return Channel primitive
        instead of base Frag.

        Args:
            frag_id: Frag ID to load

        Returns:
            Channel instance if it matches composition, None otherwise
        """
        from winterforge.frags.traits.persistable import (
            get_storage,
        )
        from winterforge_channels.primitives import Channel

        storage = get_storage()
        if not storage:
            return None

        frag = await storage.load(frag_id)
        if frag is None:
            return None

        # Verify frag matches our composition pattern
        if not self._matches_composition(frag):
            return None

        # Convert to typed Channel instance
        channel = Channel(
            affinities=list(frag.composition.affinities),
            traits=list(frag.composition.traits),
            aliases=frag.aliases,
        )
        channel._set_id(frag.id)
        channel._loaded_from_storage = True

        # Copy fieldable data if present
        if hasattr(frag, '_fieldable_data') and frag._fieldable_data:
            channel._fieldable_data = frag._fieldable_data

        # Re-initialize traits with loaded data
        channel._initialize_traits()

        return channel
