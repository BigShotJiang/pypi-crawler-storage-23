"""Registry for Message Frags."""

from __future__ import annotations

from typing import List, Optional

from winterforge.frags.registries import FragRegistry
from winterforge.frags import Manifest, Frag


class MessageRegistry(FragRegistry):
    """Registry for Message Frags."""

    def __init__(self):
        """Initialize with message composition."""
        super().__init__(composition={'affinities': ['message']})

    async def all(self) -> List[Frag]:
        """
        Get all Messages.

        Overrides base to return typed Message instances.

        Returns:
            List of Message instances
        """
        from winterforge_channels.primitives import Message

        # Get base Frags from parent
        frags = await super().all()

        # Convert each to typed Message
        messages = []
        for frag in frags:
            message = Message(
                affinities=list(frag.composition.affinities),
                traits=list(frag.composition.traits),
                aliases=frag.aliases,
            )
            message._set_id(frag.id)
            message._loaded_from_storage = True

            # Copy fieldable data if present
            if hasattr(frag, '_fieldable_data') and frag._fieldable_data:
                message._fieldable_data = frag._fieldable_data

            message._initialize_traits()
            messages.append(message)

        return messages

    async def _load_and_filter(self, frag_id: int) -> Optional[Frag]:
        """
        Load Message by ID and return typed Message instance.

        Overrides base implementation to return Message primitive
        instead of base Frag.

        Args:
            frag_id: Frag ID to load

        Returns:
            Message instance if it matches composition, None otherwise
        """
        from winterforge.frags.traits.persistable import get_storage
        from winterforge_channels.primitives import Message

        storage = get_storage()
        if not storage:
            return None

        frag = await storage.load(frag_id)
        if frag is None:
            return None

        # Verify frag matches our composition pattern
        if not self._matches_composition(frag):
            return None

        # Convert to typed Message instance
        message = Message(
            affinities=list(frag.composition.affinities),
            traits=list(frag.composition.traits),
            aliases=frag.aliases,
        )
        message._set_id(frag.id)
        message._loaded_from_storage = True

        # Copy fieldable data if present
        if hasattr(frag, '_fieldable_data') and frag._fieldable_data:
            message._fieldable_data = frag._fieldable_data

        # Re-initialize traits with loaded data
        message._initialize_traits()

        return message

    async def get_thread(self, message_id: int) -> Manifest:
        """
        Get complete thread for message.

        Follows reply_to chain backward to root.

        Args:
            message_id: Message ID to get thread for

        Returns:
            Manifest of messages in thread (root first)
        """
        thread = []
        current = await self.get(message_id)

        while current:
            thread.insert(0, current)
            if current.reply_to_id:
                current = await self.get(current.reply_to_id)
            else:
                current = None

        return Manifest(thread)

    async def get_for_conversation(
        self,
        conversation_id: int,
    ) -> List:
        """
        Get all messages for conversation.

        Args:
            conversation_id: Conversation ID

        Returns:
            List of Message Frags
        """
        filtered_registry = await self.filter(
            lambda m: m.conversation_id == conversation_id
        )
        return await filtered_registry.all()
