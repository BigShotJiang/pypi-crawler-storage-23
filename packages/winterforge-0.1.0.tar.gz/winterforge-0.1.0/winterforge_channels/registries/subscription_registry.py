"""Registry for Subscription Frags."""

from __future__ import annotations

from typing import Optional, List

from winterforge.frags.registries import FragRegistry
from winterforge.frags import Frag


class SubscriptionRegistry(FragRegistry):
    """Registry for Subscription Frags."""

    def __init__(self):
        """Initialize with subscription composition."""
        super().__init__(composition={'affinities': ['subscription']})

    async def all(self) -> List[Frag]:
        """
        Get all Subscriptions.

        Overrides base to return typed Subscription instances.

        Returns:
            List of Subscription instances
        """
        from winterforge_channels.primitives import Subscription

        # Get base Frags from parent
        frags = await super().all()

        # Convert each to typed Subscription
        subscriptions = []
        for frag in frags:
            subscription = Subscription(
                affinities=list(frag.composition.affinities),
                traits=list(frag.composition.traits),
                aliases=frag.aliases,
            )
            subscription._set_id(frag.id)
            subscription._loaded_from_storage = True

            # Copy fieldable data if present
            if (
                hasattr(frag, '_fieldable_data')
                and frag._fieldable_data
            ):
                subscription._fieldable_data = frag._fieldable_data

            subscription._initialize_traits()
            subscriptions.append(subscription)

        return subscriptions

    async def _load_and_filter(
        self,
        frag_id: int,
    ) -> Optional[Frag]:
        """
        Load Subscription by ID and return typed Subscription instance.

        Overrides base implementation to return Subscription primitive
        instead of base Frag.

        Args:
            frag_id: Frag ID to load

        Returns:
            Subscription instance if it matches composition, None otherwise
        """
        from winterforge.frags.traits.persistable import (
            get_storage,
        )
        from winterforge_channels.primitives import Subscription

        storage = get_storage()
        if not storage:
            return None

        frag = await storage.load(frag_id)
        if frag is None:
            return None

        # Verify frag matches our composition pattern
        if not self._matches_composition(frag):
            return None

        # Convert to typed Subscription instance
        subscription = Subscription(
            affinities=list(frag.composition.affinities),
            traits=list(frag.composition.traits),
            aliases=frag.aliases,
        )
        subscription._set_id(frag.id)
        subscription._loaded_from_storage = True

        # Copy fieldable data if present
        if hasattr(frag, '_fieldable_data') and frag._fieldable_data:
            subscription._fieldable_data = frag._fieldable_data

        # Re-initialize traits with loaded data
        subscription._initialize_traits()

        return subscription
