"""CLI commands for channel management."""

from __future__ import annotations

from winterforge.plugins.decorators import root, cli_command


@root('channel')
class ChannelCommands:
    """Channel management commands."""

    @cli_command()
    async def create_channel(
        self,
        title: str,
        transport: str = 'http',
    ):
        """
        Create a new channel.

        Args:
            title: Channel title
            transport: Transport type (http or websocket)

        Returns:
            Created Channel Frag
        """
        from winterforge_channels.primitives import Channel

        # Create channel
        channel = Channel()
        channel.set_title(title)

        # Set transport preference
        channel.set_alias('egress_transport', transport)

        # Save
        await channel.save()

        return channel

    @cli_command()
    async def list_channels(self):
        """
        List all channels.

        Returns:
            List of Channel Frags
        """
        from winterforge_channels.registries import ChannelRegistry

        registry = ChannelRegistry()
        return await registry.all()

    @cli_command()
    async def send_message(
        self,
        channel_id: int,
        content: str,
        author_id: int = 0,
    ):
        """
        Send message to channel.

        Args:
            channel_id: Channel ID to send to
            content: Message content
            author_id: Author Frag ID (optional)

        Returns:
            Created Message Frag
        """
        from winterforge_channels.primitives import Message
        from winterforge_channels.registries import ChannelRegistry
        from winterforge.frags import Manifest

        # Get channel
        registry = ChannelRegistry()
        channel = await registry.get(channel_id)
        if not channel:
            raise ValueError(f'Channel {channel_id} not found')

        # Create message
        message = Message()
        message.set_content(content)
        message.set_author_id(author_id)
        await message.save()

        # Send to channel
        await message.send(Manifest([channel]))

        return message

    @cli_command()
    async def subscribe_to_channel(
        self,
        channel_id: int,
        subscriber_id: int,
    ):
        """
        Subscribe to channel.

        Args:
            channel_id: Channel ID to subscribe to
            subscriber_id: Subscriber Frag ID

        Returns:
            Created Subscription Frag
        """
        from winterforge_channels.registries import ChannelRegistry

        # Get channel
        registry = ChannelRegistry()
        channel = await registry.get(channel_id)
        if not channel:
            raise ValueError(f'Channel {channel_id} not found')

        # Subscribe
        subscription = await channel.subscribe(subscriber_id)

        return subscription

    @cli_command()
    async def unsubscribe_from_channel(
        self,
        channel_id: int,
        subscriber_id: int,
    ):
        """
        Unsubscribe from channel.

        Args:
            channel_id: Channel ID to unsubscribe from
            subscriber_id: Subscriber Frag ID

        Returns:
            True if successful
        """
        from winterforge_channels.registries import ChannelRegistry

        # Get channel
        registry = ChannelRegistry()
        channel = await registry.get(channel_id)
        if not channel:
            raise ValueError(f'Channel {channel_id} not found')

        # Unsubscribe
        await channel.unsubscribe(subscriber_id)

        return True

    @cli_command()
    async def list_subscribers(self, channel_id: int):
        """
        List channel subscribers.

        Args:
            channel_id: Channel ID

        Returns:
            List of subscriber Frags
        """
        from winterforge_channels.registries import ChannelRegistry

        # Get channel
        registry = ChannelRegistry()
        channel = await registry.get(channel_id)
        if not channel:
            raise ValueError(f'Channel {channel_id} not found')

        # Get subscribers
        return await channel.get_subscribers()


__all__ = ['ChannelCommands']
