"""
WinterForge Channels - Communication primitives and transport abstraction.

Provides transport-agnostic message routing with permission-controlled
channels and pluggable delivery mechanisms.
"""

from winterforge_channels.primitives.message import Message
from winterforge_channels.primitives.channel import Channel
from winterforge_channels.primitives.subscription import Subscription

__all__ = [
    'Message',
    'Channel',
    'Subscription',
]

__version__ = '1.0.0'
