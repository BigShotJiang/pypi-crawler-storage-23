"""WebSocket egress transport - sends messages via WebSocket."""

from __future__ import annotations

from typing import List, Dict, Any
from winterforge.plugins import plugin


@plugin('winterforge.channels.egress_transports', 'websocket')
class WebSocketEgressTransport:
    """
    WebSocket egress transport.

    Sends messages to subscribers via WebSocket connections.
    Subscribers must have a 'websocket_id' alias for connection tracking.

    Note: This is a simplified implementation. Production use would
    require a connection manager to track active WebSocket connections.
    """

    def __init__(self):
        """Initialize transport with connection tracking."""
        # In production, this would be replaced with Redis/shared storage
        self._connections: Dict[str, Any] = {}

    def transport_id(self) -> str:
        """Return transport identifier."""
        return 'websocket'

    async def send(
        self,
        message,
        channel,
        subscribers: List,
    ) -> List:
        """
        Send message to subscribers via WebSocket.

        Args:
            message: Message Frag to send
            channel: Channel Frag routing the message
            subscribers: List of subscriber Frags

        Returns:
            List of TransportResult objects
        """
        from winterforge_channels.plugins.transports.protocols import (
            TransportResult,
        )

        results = []

        for subscriber in subscribers:
            # Check if subscriber can receive via WebSocket
            if not await self.can_deliver_to(subscriber):
                results.append(
                    TransportResult(
                        success=False,
                        transport_id=self.transport_id(),
                        channel_id=channel.id,
                        subscriber_id=subscriber.id,
                        error='Subscriber has no websocket_id alias',
                    )
                )
                continue

            websocket_id = subscriber.aliases.get('websocket_id')

            try:
                # Build payload
                payload = self._build_payload(message, channel)

                # Get connection (in production, from connection manager)
                connection = self._connections.get(websocket_id)

                if connection is None:
                    results.append(
                        TransportResult(
                            success=False,
                            transport_id=self.transport_id(),
                            channel_id=channel.id,
                            subscriber_id=subscriber.id,
                            error='No active WebSocket connection',
                            metadata={'websocket_id': websocket_id},
                        )
                    )
                    continue

                # Send message
                await connection.send_json(payload)

                results.append(
                    TransportResult(
                        success=True,
                        transport_id=self.transport_id(),
                        channel_id=channel.id,
                        subscriber_id=subscriber.id,
                        metadata={'websocket_id': websocket_id},
                    )
                )

            except Exception as e:
                results.append(
                    TransportResult(
                        success=False,
                        transport_id=self.transport_id(),
                        channel_id=channel.id,
                        subscriber_id=subscriber.id,
                        error=str(e),
                        metadata={'websocket_id': websocket_id},
                    )
                )

        return results

    async def can_deliver_to(self, subscriber) -> bool:
        """
        Check if subscriber has WebSocket connection ID.

        Args:
            subscriber: Subscriber Frag to check

        Returns:
            True if subscriber has 'websocket_id' alias
        """
        return 'websocket_id' in subscriber.aliases

    def _build_payload(
        self,
        message,
        channel,
    ) -> Dict[str, Any]:
        """
        Build WebSocket message payload.

        Args:
            message: Message Frag
            channel: Channel Frag

        Returns:
            Dict payload for JSON serialization
        """
        payload = {
            'type': 'message',
            'message_id': message.id,
            'channel_id': channel.id,
            'channel_title': (
                channel.title if hasattr(channel, 'title') else None
            ),
            'content': (
                message.content if hasattr(message, 'content') else ''
            ),
            'author_id': (
                message.author_id
                if hasattr(message, 'author_id')
                else None
            ),
            'content_type': (
                message.content_type
                if hasattr(message, 'content_type')
                else 'text/plain'
            ),
        }

        # Add conversation info if available
        if (
            hasattr(message, 'conversation_id')
            and message.conversation_id
        ):
            payload['conversation_id'] = message.conversation_id

        # Add reply info if available
        if hasattr(message, 'reply_to_id') and message.reply_to_id:
            payload['reply_to_id'] = message.reply_to_id

        return payload

    def register_connection(
        self,
        websocket_id: str,
        connection: Any,
    ) -> None:
        """
        Register active WebSocket connection.

        Args:
            websocket_id: Unique connection identifier
            connection: WebSocket connection object
        """
        self._connections[websocket_id] = connection

    def unregister_connection(self, websocket_id: str) -> None:
        """
        Unregister WebSocket connection.

        Args:
            websocket_id: Connection identifier to remove
        """
        self._connections.pop(websocket_id, None)


__all__ = ['WebSocketEgressTransport']
