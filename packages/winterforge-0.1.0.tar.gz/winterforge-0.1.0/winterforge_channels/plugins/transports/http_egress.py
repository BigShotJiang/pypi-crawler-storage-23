"""HTTP egress transport - sends messages via HTTP POST."""

from __future__ import annotations

from typing import List, Any, Dict
from winterforge.plugins import plugin


@plugin('winterforge.channels.egress_transports', 'http')
class HttpEgressTransport:
    """
    HTTP egress transport.

    Sends messages to subscribers via HTTP POST requests.
    Subscribers must have an 'endpoint' alias with their HTTP URL.
    """

    def transport_id(self) -> str:
        """Return transport identifier."""
        return 'http'

    async def send(
        self,
        message,
        channel,
        subscribers: List,
    ) -> List:
        """
        Send message to subscribers via HTTP POST.

        Args:
            message: Message Frag to send
            channel: Channel Frag routing the message
            subscribers: List of subscriber Frags

        Returns:
            List of TransportResult objects
        """
        from winterforge_channels.plugins.transports.protocols import (
            TransportResult,
        )
        import httpx

        results = []

        for subscriber in subscribers:
            # Check if subscriber can receive via HTTP
            if not await self.can_deliver_to(subscriber):
                results.append(
                    TransportResult(
                        success=False,
                        transport_id=self.transport_id(),
                        channel_id=channel.id,
                        subscriber_id=subscriber.id,
                        error='Subscriber has no endpoint alias',
                    )
                )
                continue

            endpoint = subscriber.aliases.get('endpoint')

            try:
                # Build payload
                payload = self._build_payload(message, channel)

                # Send POST request
                async with httpx.AsyncClient(timeout=10.0) as client:
                    response = await client.post(
                        endpoint,
                        json=payload,
                    )
                    response.raise_for_status()

                results.append(
                    TransportResult(
                        success=True,
                        transport_id=self.transport_id(),
                        channel_id=channel.id,
                        subscriber_id=subscriber.id,
                        metadata={
                            'status_code': response.status_code,
                            'endpoint': endpoint,
                        },
                    )
                )

            except Exception as e:
                results.append(
                    TransportResult(
                        success=False,
                        transport_id=self.transport_id(),
                        channel_id=channel.id,
                        subscriber_id=subscriber.id,
                        error=str(e),
                        metadata={'endpoint': endpoint},
                    )
                )

        return results

    async def can_deliver_to(self, subscriber) -> bool:
        """
        Check if subscriber has HTTP endpoint.

        Args:
            subscriber: Subscriber Frag to check

        Returns:
            True if subscriber has 'endpoint' alias
        """
        return 'endpoint' in subscriber.aliases

    def _build_payload(
        self,
        message,
        channel,
    ) -> Dict[str, Any]:
        """
        Build HTTP request payload.

        Args:
            message: Message Frag
            channel: Channel Frag

        Returns:
            Dict payload for JSON serialization
        """
        channel_title = (
            channel.title if hasattr(channel, 'title') else None
        )
        content = (
            message.content if hasattr(message, 'content') else ''
        )
        author_id = (
            message.author_id if hasattr(message, 'author_id') else None
        )
        content_type = (
            message.content_type
            if hasattr(message, 'content_type')
            else 'text/plain'
        )

        payload = {
            'message_id': message.id,
            'channel_id': channel.id,
            'channel_title': channel_title,
            'content': content,
            'author_id': author_id,
            'content_type': content_type,
        }

        # Add conversation info if available
        if hasattr(message, 'conversation_id') and message.conversation_id:
            payload['conversation_id'] = message.conversation_id

        # Add reply info if available
        if hasattr(message, 'reply_to_id') and message.reply_to_id:
            payload['reply_to_id'] = message.reply_to_id

        return payload


__all__ = ['HttpEgressTransport']
