"""Transport protocols for winterforge-channels."""

from __future__ import annotations

from typing import Protocol, Any, List
from dataclasses import dataclass


@dataclass
class TransportResult:
    """Result from transport send operation."""

    success: bool
    transport_id: str
    channel_id: int
    subscriber_id: int
    error: str | None = None
    metadata: dict[str, Any] | None = None


class IngressTransport(Protocol):
    """
    Protocol for ingress transports.

    Ingress transports receive messages FROM external sources
    and convert them into Message Frags.
    """

    def transport_id(self) -> str:
        """
        Unique identifier for this transport.

        Returns:
            Transport ID string (e.g., 'http', 'websocket')
        """
        ...

    async def receive(
        self,
        channel,
        payload: dict[str, Any],
    ) -> 'Message':
        """
        Receive message from external source.

        Args:
            channel: Channel Frag receiving the message
            payload: Raw payload from external source

        Returns:
            Message Frag created from payload
        """
        ...

    async def validate_payload(
        self,
        payload: dict[str, Any],
    ) -> bool:
        """
        Validate incoming payload structure.

        Args:
            payload: Raw payload to validate

        Returns:
            True if payload is valid for this transport
        """
        ...


class EgressTransport(Protocol):
    """
    Protocol for egress transports.

    Egress transports send messages TO external destinations
    (subscribers).
    """

    def transport_id(self) -> str:
        """
        Unique identifier for this transport.

        Returns:
            Transport ID string (e.g., 'http', 'websocket')
        """
        ...

    async def send(
        self,
        message,
        channel,
        subscribers: List,
    ) -> List[TransportResult]:
        """
        Send message to subscribers.

        Args:
            message: Message Frag to send
            channel: Channel Frag routing the message
            subscribers: List of subscriber Frags

        Returns:
            List of TransportResult objects (one per subscriber)
        """
        ...

    async def can_deliver_to(
        self,
        subscriber,
    ) -> bool:
        """
        Check if this transport can deliver to subscriber.

        Args:
            subscriber: Subscriber Frag to check

        Returns:
            True if transport can deliver to this subscriber
        """
        ...


__all__ = [
    'TransportResult',
    'IngressTransport',
    'EgressTransport',
]
