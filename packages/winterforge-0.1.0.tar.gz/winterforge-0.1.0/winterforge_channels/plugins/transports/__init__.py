"""Transport plugins."""

from winterforge_channels.plugins.transports.managers import (
    IngressTransportManager,
    EgressTransportManager,
    IngressTransportRepository,
    EgressTransportRepository,
)
from winterforge_channels.plugins.transports.protocols import (
    TransportResult,
    IngressTransport,
    EgressTransport,
)

# Import transports to trigger registration
from winterforge_channels.plugins.transports.http_egress import (
    HttpEgressTransport,
)
from winterforge_channels.plugins.transports.http_ingress import (
    HttpIngressTransport,
)
from winterforge_channels.plugins.transports.websocket_egress import (
    WebSocketEgressTransport,
)


__all__ = [
    'IngressTransportManager',
    'EgressTransportManager',
    'IngressTransportRepository',
    'EgressTransportRepository',
    'TransportResult',
    'IngressTransport',
    'EgressTransport',
    'HttpEgressTransport',
    'HttpIngressTransport',
    'WebSocketEgressTransport',
]
