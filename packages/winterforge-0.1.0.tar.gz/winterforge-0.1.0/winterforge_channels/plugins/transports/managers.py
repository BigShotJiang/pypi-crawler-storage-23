"""Transport plugin managers."""

from __future__ import annotations

from typing import Optional
from winterforge.plugins import PluginManagerBase
from winterforge.plugins.repository import PluginRepository


class IngressTransportManager(PluginManagerBase):
    """
    Manager for ingress transport plugins.

    Ingress transports receive messages FROM external sources.
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return manager identifier."""
        return 'winterforge.channels.ingress_transports'


class EgressTransportManager(PluginManagerBase):
    """
    Manager for egress transport plugins.

    Egress transports send messages TO external destinations.
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return manager identifier."""
        return 'winterforge.channels.egress_transports'


class IngressTransportRepository:
    """
    Repository for channel-specific ingress transport resolution.

    Provides first-match resolution strategy:
    1. Channel-preferred transport (via alias)
    2. First available transport
    """

    def __init__(self, channel=None):
        """
        Initialize repository.

        Args:
            channel: Optional Channel Frag for preference resolution
        """
        self.channel = channel

    def resolve(self):
        """
        Resolve best ingress transport for channel.

        Resolution strategy:
        1. If channel has 'ingress_transport' alias, use that
        2. Otherwise, return first available transport
        3. If no transports available, return None

        Returns:
            Transport instance or None
        """
        manager = IngressTransportManager
        available = manager.repository()

        # No transports available
        if not available:
            return None

        # Channel preference
        if self.channel:
            preferred = self.channel.aliases.get('ingress_transport')
            if preferred and available.has(preferred):
                transport_class = available.get(preferred)
                return transport_class()

        # First available
        all_transports = available.all()
        if all_transports:
            return all_transports[0]()

        return None


class EgressTransportRepository:
    """
    Repository for channel-specific egress transport resolution.

    Provides first-match resolution strategy:
    1. Channel-preferred transport (via alias)
    2. First available transport
    """

    def __init__(self, channel=None):
        """
        Initialize repository.

        Args:
            channel: Optional Channel Frag for preference resolution
        """
        self.channel = channel

    def resolve(self):
        """
        Resolve best egress transport for channel.

        Resolution strategy:
        1. If channel has 'egress_transport' alias, use that
        2. Otherwise, return first available transport
        3. If no transports available, return None

        Returns:
            Transport instance or None
        """
        manager = EgressTransportManager
        available = manager.repository()

        # No transports available
        if not available:
            return None

        # Channel preference
        if self.channel:
            preferred = self.channel.aliases.get('egress_transport')
            if preferred and available.has(preferred):
                transport_class = available.get(preferred)
                return transport_class()

        # First available
        all_transports = available.all()
        if all_transports:
            return all_transports[0]()

        return None


__all__ = [
    'IngressTransportManager',
    'EgressTransportManager',
    'IngressTransportRepository',
    'EgressTransportRepository',
]
