"""HTTP ingress transport - receives messages via HTTP POST."""

from __future__ import annotations

from typing import Dict, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge_channels.primitives.message import Message

from winterforge.plugins import plugin


@plugin('winterforge.channels.ingress_transports', 'http')
class HttpIngressTransport:
    """
    HTTP ingress transport.

    Receives messages FROM external sources via HTTP POST.
    Converts HTTP payloads into Message Frags.
    """

    def transport_id(self) -> str:
        """Return transport identifier."""
        return 'http'

    async def receive(
        self,
        channel,
        payload: Dict[str, Any],
    ) -> 'Message':
        """
        Receive message from HTTP POST.

        Args:
            channel: Channel Frag receiving the message
            payload: HTTP request payload

        Returns:
            Message Frag created from payload
        """
        from winterforge_channels.primitives import Message

        # Validate payload
        if not await self.validate_payload(payload):
            raise ValueError('Invalid payload structure')

        # Create message from payload
        message = Message()

        # Set content
        if 'content' in payload:
            message.set_content(payload['content'])

        # Set author
        if 'author_id' in payload:
            message.set_author_id(payload['author_id'])

        # Set content type
        if 'content_type' in payload:
            message.set_content_type(payload['content_type'])

        # Set conversation
        if 'conversation_id' in payload:
            message.set_conversation_id(payload['conversation_id'])

        # Set reply_to
        if 'reply_to_id' in payload:
            message.set_reply_to_id(payload['reply_to_id'])

        # Add references
        if 'reference_ids' in payload and isinstance(
            payload['reference_ids'],
            list,
        ):
            for ref_id in payload['reference_ids']:
                message.add_reference(int(ref_id))

        # Save message
        await message.save()

        return message

    async def validate_payload(
        self,
        payload: Dict[str, Any],
    ) -> bool:
        """
        Validate incoming HTTP payload.

        Args:
            payload: HTTP request payload to validate

        Returns:
            True if payload is valid
        """
        # Require at least content or author_id
        if 'content' not in payload and 'author_id' not in payload:
            return False

        # Validate types if present
        if 'content' in payload and not isinstance(
            payload['content'],
            str,
        ):
            return False

        if 'author_id' in payload and not isinstance(
            payload['author_id'],
            (int, str),
        ):
            return False

        if 'content_type' in payload and not isinstance(
            payload['content_type'],
            str,
        ):
            return False

        return True


__all__ = ['HttpIngressTransport']
