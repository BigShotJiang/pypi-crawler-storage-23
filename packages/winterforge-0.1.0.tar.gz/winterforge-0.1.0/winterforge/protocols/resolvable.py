"""Protocol for resolvable items in chain-of-responsibility pattern."""

from typing import Protocol, Any, runtime_checkable


@runtime_checkable
class Resolvable(Protocol):
    """
    Protocol for items that can be resolved via chain-of-responsibility.

    Items implementing this protocol can be used with Repository/Manifest
    resolve() and resolve_all() methods for execution-based resolution.

    The canonical Winterforge resolution pattern:
    1. Check if item matches context: is_match(context)
    2. Execute if matched: execute(context, source)
    3. Track success/failure for collection-level results

    Example:
        class OutputFormatter:
            def is_match(self, context: dict) -> bool:
                return context.get('format') == self.format_type

            def execute(self, context: dict, source=None) -> bool:
                try:
                    self.format(context.get('data'), source)
                    return True  # Success
                except Exception:
                    return False  # Failure

        # Usage:
        result = frag.output_formats.resolve_all(context)
        if result == True:  # All succeeded (empty failures)
            print("All formatters succeeded")
    """

    def is_match(self, context: Any) -> bool:
        """
        Check if this item matches the given context.

        Args:
            context: Context to match against (dict, Frag, or any object)

        Returns:
            True if this item can handle the context, False otherwise

        Example:
            def is_match(self, context):
                return context.get('type') == 'json'
        """
        ...

    def execute(self, context: Any, source: Any = None) -> bool:
        """
        Execute this item's action with the given context.

        Args:
            context: Context for execution
            source: Optional source Frag (with source trait)

        Returns:
            True if execution succeeded, False if failed

        Example:
            def execute(self, context, source=None):
                try:
                    result = self.process(context, source)
                    return result is not None
                except Exception:
                    return False
        """
        ...
