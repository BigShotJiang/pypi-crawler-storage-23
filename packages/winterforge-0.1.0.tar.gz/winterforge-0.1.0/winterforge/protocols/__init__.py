"""
Framework protocol definitions for WinterForge core abstractions.

These protocols define contracts for core framework components,
not plugin extension points. For plugin protocols, see
winterforge.plugins._protocols.

Available Framework Protocols:
    - Collections: Shared interface for Manifest and PluginRepository
    - Resolvable: Chain-of-responsibility execution protocol

Example Usage:
    from winterforge.protocols import Collections

    def process_items(items: Collections) -> None:
        first = items.resolve(lambda x: x.active)
        # Works with both Manifest and PluginRepository
"""

from winterforge.protocols.collections import Collections
from winterforge.protocols.resolvable import Resolvable

__all__ = [
    'Collections',
    'Resolvable',
]
