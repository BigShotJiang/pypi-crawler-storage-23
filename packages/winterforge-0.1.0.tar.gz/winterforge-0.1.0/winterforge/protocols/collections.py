"""Collections protocol — shared interface for Manifests and Repositories."""

from __future__ import annotations

from typing import Any, Callable, Iterator, Protocol, runtime_checkable


@runtime_checkable
class Collections(Protocol):
    """
    Structural protocol shared by Manifest and PluginRepository.

    Both collections are iterable, sized, boolean, and support
    first-match resolution. This protocol enables ``compile()``,
    ``render()``, and other pipeline methods to accept either type
    without coupling to a concrete class.

    Manifest  — ordered collection of Frags.
    PluginRepository — ordered collection of plugin instances.

    Example::

        def process(items: Collections) -> None:
            envoy = items.resolve(lambda p: hasattr(p, 'query'))
    """

    def __len__(self) -> int:
        """Number of items in this collection."""
        ...

    def __bool__(self) -> bool:
        """True when the collection contains at least one item."""
        ...

    def __iter__(self) -> Iterator:
        """Iterate over items in order."""
        ...

    def resolve(
        self,
        predicate: Callable[[Any], bool],
    ) -> Any | None:
        """
        Return the first item for which *predicate* returns True,
        or None if no item matches.
        """
        ...

    def all(self) -> list:
        """Return all items as an ordered list."""
        ...
