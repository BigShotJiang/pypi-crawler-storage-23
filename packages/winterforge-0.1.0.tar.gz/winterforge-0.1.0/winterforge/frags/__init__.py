"""Frag system - composable data primitives."""

from winterforge.frags.base import Frag
from winterforge.frags.manifest import Manifest
from winterforge.frags.composition import Composition
from winterforge.frags.scope import Scope
from winterforge.frags.registries.frag_registry import FragRegistry, Identity
from winterforge.frags.registries.affinity_registry import AffinityRegistry
from winterforge.frags.registries.trait_registry import TraitRegistry
from winterforge.frags.primitives import Affinity, Trait
from winterforge.frags.materialization import (
    materialize_traits,
    materialize_affinities,
    materialize_primitives,
)

# Import for Manifest usage
from winterforge.frags.traits.persistable import get_storage

__all__ = [
    'Frag',
    'Manifest',
    'Composition',
    'Scope',
    'FragRegistry',
    'Identity',
    'AffinityRegistry',
    'TraitRegistry',
    'Affinity',
    'Trait',
    'materialize_traits',
    'materialize_affinities',
    'materialize_primitives',
    'get_storage',
]
