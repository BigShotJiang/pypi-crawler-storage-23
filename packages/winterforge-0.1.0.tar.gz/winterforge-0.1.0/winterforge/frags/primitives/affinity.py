"""Affinity primitive - represents an affinity type in the system."""

from __future__ import annotations

from winterforge.frags.primitives._base import PrimitiveFrag


class Affinity(PrimitiveFrag):
    """
    Affinity primitive - represents an affinity type.

    Affinities themselves are Frags, making them queryable and allowing
    metadata storage (descriptions, usage notes, etc.).

    The affinity name is stored in the 'title' field.
    The primitive_id field ('affinity') enables pre-bootstrap identification.

    Example:
        # Create affinity Frag
        user_affinity = Affinity()
        user_affinity.set_title('user')
        await user_affinity.save()

        # Query affinities
        registry = AffinityRegistry()
        all_affinities = await registry.all()

        # Query by primitive_id (indexed field)
        from winterforge.frags import FragRegistry
        registry = FragRegistry({'affinities': [], 'traits': []})
        primitives = await registry.query()
            .condition('primitive_id', 'affinity')
            .execute()

        # Check if primitive
        print(user_affinity.is_primitive())  # True
        print(user_affinity.primitive_id)    # 'affinity'
    """

    def __init__(
        self,
        name: str | None = None,
        affinities: list[str] | None = None,
        traits: list[str] | None = None,
        aliases: dict[str, int] | None = None,
    ):
        """
        Initialize Affinity Frag.

        Args:
            name: Affinity name (e.g., 'user', 'config', 'post')
            affinities: Additional affinities (default: ['affinity'])
            traits: Additional traits (default: ['persistable', 'titled'])
            aliases: Alias relationships

        Example:
            user_affinity = Affinity(name='user')
            config_affinity = Affinity(name='config')
        """
        # Merge with defaults
        default_affinities = ['affinity']
        default_traits = ['persistable', 'titled']

        merged_affinities = (
            list(set(default_affinities + affinities))
            if affinities
            else default_affinities
        )
        merged_traits = (
            list(set(default_traits + traits))
            if traits
            else default_traits
        )

        super().__init__(
            primitive_id=name,
            affinities=merged_affinities,
            traits=merged_traits,
            aliases=aliases or {},
        )


# Auto-register Affinity primitive type
from winterforge.frags.primitives.manager import PrimitiveTypeManager


def _get_affinity_names():
    """Source function for affinity materialization."""
    from winterforge.frags.registries import FragRegistry

    # Scan all Frags and collect unique affinities
    registry = FragRegistry({'affinities': [], 'traits': []})

    async def _collect_affinities():
        frags = await registry.all()
        return sorted({aff for frag in frags for aff in frag.affinities})

    # Return async callable
    return _collect_affinities


PrimitiveTypeManager.register(
    'affinity',
    Affinity,
    source=_get_affinity_names
)

__all__ = ['Affinity']
