"""Base class for system primitives with primitive_id field."""

from __future__ import annotations

from winterforge.frags.base import Frag


class PrimitiveFrag(Frag):
    """
    Base class for system primitives (Affinity, Trait, etc.).

    Provides a `primitive_id` field for identification before full
    trait/affinity bootstrap. This solves the circular dependency
    where primitives need traits but traits are themselves primitives.

    The primitive_id is a real field (not a class variable), making it:
    - Indexable (can create database indexes)
    - Queryable (can filter by primitive_id)
    - Storable (persisted like any other field)

    Subclasses should call super().__init__ with their primitive_id:

    Example:
        class Affinity(PrimitiveFrag):
            def __init__(self, **kwargs):
                super().__init__(
                    primitive_id='affinity',
                    affinities=['affinity'],
                    traits=['persistable', 'titled'],
                    **kwargs
                )
    """

    def __init__(
        self,
        primitive_id: str | None = None,
        affinities: list[str] | None = None,
        traits: list[str] | None = None,
        aliases: dict[str, int] | None = None,
    ):
        """
        Initialize PrimitiveFrag with primitive_id field.

        Args:
            primitive_id: Specific identifier (e.g., 'user', 'persistable')
            affinities: Affinity list
            traits: Trait list
            aliases: Alias dict
        """
        super().__init__(
            affinities=affinities,
            traits=traits,
            aliases=aliases or {},
        )

        # Store primitive_id as an alias (storage-friendly)
        if primitive_id:
            self.set_alias('primitive_id', primitive_id)

    @property
    def primitive_id(self) -> str:
        """
        Get the primitive identifier.

        Stored as an alias for storage compatibility.

        Returns:
            Primitive identifier string (e.g., 'user', 'persistable')

        Example:
            user_affinity = Affinity()
            user_affinity.set_name('user')
            print(user_affinity.primitive_id)  # 'user'
        """
        return self.get_alias('primitive_id') or ''

    def set_primitive_id(self, primitive_id: str) -> 'PrimitiveFrag':
        """
        Set the primitive identifier.

        Stored as an alias for storage compatibility.

        Args:
            primitive_id: Primitive identifier (e.g., 'user', 'persistable')

        Returns:
            Self for method chaining

        Example:
            affinity = Affinity()
            affinity.set_primitive_id('user')
        """
        self.set_alias('primitive_id', primitive_id)
        return self

    @property
    def name(self) -> str:
        """
        Get primitive name (alias for primitive_id).

        Returns:
            Primitive identifier

        Example:
            affinity = Affinity()
            affinity.set_name('user')
            print(affinity.name)  # 'user'
        """
        return self.primitive_id

    def set_name(self, name: str) -> 'PrimitiveFrag':
        """
        Set primitive name (sets primitive_id).

        Args:
            name: Primitive name

        Returns:
            Self for method chaining

        Example:
            affinity = Affinity()
            affinity.set_name('user')
        """
        self.set_primitive_id(name)
        return self

    def is_primitive(self) -> bool:
        """
        Check if this is a system primitive.

        Returns:
            Always True for PrimitiveFrag instances

        Example:
            affinity = Affinity()
            affinity.is_primitive()  # True
        """
        return True

    def __str__(self) -> str:
        """
        Cast primitive to string (returns primitive_id).

        Enables easy inline string conversion for queries.

        Returns:
            Primitive identifier string

        Example:
            user_affinity = Affinity(name='user')
            query.affinity(user_affinity)  # Automatically uses 'user'
            query.affinity(str(user_affinity))  # Explicit: 'user'
        """
        return self.primitive_id


__all__ = ['PrimitiveFrag']
