"""Frag primitives - first-class Frag types in Winterforge core."""

from __future__ import annotations

from winterforge.frags.primitives._base import PrimitiveFrag
from winterforge.frags.primitives.manager import PrimitiveTypeManager
from winterforge.frags.primitives.affinity import Affinity
from winterforge.frags.primitives.trait import Trait

__all__ = ['PrimitiveFrag', 'PrimitiveTypeManager', 'Affinity', 'Trait']
