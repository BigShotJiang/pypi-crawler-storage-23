"""Trait primitive - represents a trait type in the system."""

from __future__ import annotations

from winterforge.frags.primitives._base import PrimitiveFrag


class Trait(PrimitiveFrag):
    """
    Trait primitive - represents a trait type.

    Traits themselves are Frags, making them queryable and allowing
    metadata storage (descriptions, capabilities, usage notes, etc.).

    The trait name is stored in the 'title' field.
    The primitive_id field ('trait') enables pre-bootstrap identification.

    Example:
        # Create trait Frag
        persistable_trait = Trait()
        persistable_trait.set_title('persistable')
        await persistable_trait.save()

        # Query traits
        registry = TraitRegistry()
        all_traits = await registry.all()

        # Query by primitive_id (indexed field)
        from winterforge.frags import FragRegistry
        registry = FragRegistry({'affinities': [], 'traits': []})
        primitives = await registry.query()
            .condition('primitive_id', 'trait')
            .execute()

        # Check if primitive
        print(persistable_trait.is_primitive())  # True
        print(persistable_trait.primitive_id)    # 'trait'
    """

    def __init__(
        self,
        name: str | None = None,
        affinities: list[str] | None = None,
        traits: list[str] | None = None,
        aliases: dict[str, int] | None = None,
    ):
        """
        Initialize Trait Frag.

        Args:
            name: Trait name (e.g., 'persistable', 'titled', 'sluggable')
            affinities: Additional affinities (default: ['trait'])
            traits: Additional traits (default: ['persistable', 'titled'])
            aliases: Alias relationships

        Example:
            persistable = Trait(name='persistable')
            titled = Trait(name='titled')
        """
        # Merge with defaults
        default_affinities = ['trait']
        default_traits = ['persistable', 'titled']

        merged_affinities = (
            list(set(default_affinities + affinities))
            if affinities
            else default_affinities
        )
        merged_traits = (
            list(set(default_traits + traits))
            if traits
            else default_traits
        )

        super().__init__(
            primitive_id=name,
            affinities=merged_affinities,
            traits=merged_traits,
            aliases=aliases or {},
        )


# Auto-register Trait primitive type
from winterforge.frags.primitives.manager import PrimitiveTypeManager


def _get_trait_names():
    """Source function for trait materialization."""
    from winterforge.frags.traits._manager import FragTraitManager

    return FragTraitManager.get_all_trait_ids()


PrimitiveTypeManager.register('trait', Trait, source=_get_trait_names)

__all__ = ['Trait']
