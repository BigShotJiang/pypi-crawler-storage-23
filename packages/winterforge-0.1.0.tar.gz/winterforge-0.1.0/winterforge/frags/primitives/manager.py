"""Manager for primitive Frag types."""

from __future__ import annotations

from typing import Type, Dict, Callable, Optional
from winterforge.frags.primitives._base import PrimitiveFrag


class PrimitiveTypeManager:
    """
    Manager for registering and discovering primitive Frag types.

    Primitive types (Affinity, Trait, etc.) register themselves
    with this manager, enabling dynamic materialization.

    Example:
        # Register primitive type
        PrimitiveTypeManager.register(
            'trait',
            Trait,
            source=lambda: FragTraitManager.get_all_trait_ids()
        )

        # Get all primitive types
        types = PrimitiveTypeManager.all_types()
    """

    _types: Dict[str, Type[PrimitiveFrag]] = {}
    _sources: Dict[str, Callable] = {}

    @classmethod
    def register(
        cls,
        type_id: str,
        primitive_class: Type[PrimitiveFrag],
        source: Callable
    ) -> None:
        """
        Register a primitive type.

        Args:
            type_id: Primitive type identifier (e.g., 'trait', 'affinity')
            primitive_class: PrimitiveFrag subclass
            source: Callable that returns list of primitive names to
                materialize

        Example:
            PrimitiveTypeManager.register(
                'trait',
                Trait,
                source=lambda: FragTraitManager.get_all_trait_ids()
            )
        """
        cls._types[type_id] = primitive_class
        cls._sources[type_id] = source

    @classmethod
    def get_type(cls, type_id: str) -> Optional[Type[PrimitiveFrag]]:
        """Get primitive class by type ID."""
        return cls._types.get(type_id)

    @classmethod
    def get_source(cls, type_id: str) -> Optional[Callable]:
        """Get source callable for primitive type."""
        return cls._sources.get(type_id)

    @classmethod
    def all_types(cls) -> Dict[str, Type[PrimitiveFrag]]:
        """
        Get all registered primitive types.

        Returns:
            Dict mapping type IDs to primitive classes
        """
        return dict(cls._types)

    @classmethod
    def all_sources(cls) -> Dict[str, Callable]:
        """
        Get all registered source callables.

        Returns:
            Dict mapping type IDs to source callables
        """
        return dict(cls._sources)


__all__ = ['PrimitiveTypeManager']
