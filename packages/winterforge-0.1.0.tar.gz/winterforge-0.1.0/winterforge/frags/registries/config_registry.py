"""ConfigRegistry - specialized registry for configuration Frags.

Provides convenient access to configuration values stored as Frags.
Configs are identified by slug (e.g., 'database-host', 'jwt-secret').
"""

from typing import Optional, List, Dict, Any

from winterforge.frags.registries.frag_registry import FragRegistry
from winterforge.frags import Frag
from winterforge.plugins.decorators import cli_command, root


@root('config')
class ConfigRegistry(FragRegistry):
    """
    Registry for configuration Frags.

    Configs are Frags with affinity=['config'] and
    traits=['fieldable', 'sluggable', 'persistable'].

    Each config references a standard "value" Field Frag to define
    its schema - no special traits needed. This demonstrates the
    universal Field Frag reference pattern.

    Example:
        config = ConfigRegistry()

        # Set config (creates Frag with field reference)
        await config.set_value('database-host', 'localhost')

        # Get config Frag
        frag = await config.get('database-host')
        if frag:
            value = frag.value('value')  # Access via field system

        # Or use convenience method
        value = await config.get_value('database-host')

        # List all config Frags
        all_configs = await config.all()
    """

    def __init__(self):
        """Initialize ConfigRegistry for config affinity."""
        super().__init__(
            composition={
                'affinities': ['config'],
                'traits': ['fieldable', 'sluggable', 'persistable']
            }
        )
        self._value_field = None  # Cache for value Field Frag

    async def _ensure_value_field(self) -> Frag:
        """
        Ensure the standard 'value' Field Frag exists.

        Creates it if needed, caches for reuse. All configs reference
        this Field Frag to define their 'value' field.

        Returns:
            Value Field Frag
        """
        if self._value_field:
            return self._value_field

        # Try to load existing value field
        from winterforge.frags import Frag
        from winterforge.frags.traits.persistable import get_storage

        storage = get_storage()
        if not storage:
            raise RuntimeError("No storage backend configured")

        # Query for field with slug='value'
        try:
            existing = await storage.query()\
                .affinity('field')\
                .trait('fieldable')\
                .trait('typed')\
                .trait('sluggable')\
                .trait('persistable')\
                .condition('slug', 'value')\
                .execute()
        except Exception:
            # Schema might not exist yet, filter in memory
            all_fields = await storage.query()\
                .affinity('field')\
                .trait('fieldable')\
                .trait('typed')\
                .trait('sluggable')\
                .trait('persistable')\
                .execute()
            existing = [f for f in all_fields if hasattr(f, 'slug') and f.slug == 'value']

        if existing:
            self._value_field = existing[0]
            return self._value_field

        # Create value field
        value_field = Frag(
            affinities=['field'],
            traits=['fieldable', 'typed', 'sluggable', 'persistable']
        )
        value_field.set_slug('value')
        value_field.set_type(str)  # Pass type class, not string
        value_field.set_default('')
        value_field.set_required(False)
        await value_field.save()

        self._value_field = value_field
        return value_field

    @cli_command(required=['key'])
    async def get_value(self, key: str) -> Optional[str]:
        """
        Get configuration value by key (slug).

        Returns None if key not found. Primitives over policies -
        the caller decides if a missing key is an error.

        Args:
            key: Config key (slug), e.g., 'database-host'

        Returns:
            Config value (from 'value' field) or None if not found

        Example:
            config = ConfigRegistry()
            db_host = await config.get_value('database-host')
            if db_host is None:
                # Caller handles missing config
                db_host = 'localhost'
        """
        config_frag = await self.get(key)
        if config_frag:
            return config_frag.value('value')
        return None

    @cli_command(required=['key', 'value'])
    async def set_value(self, key: str, value: str) -> Frag:
        """
        Set configuration value by key.

        Creates new config if it doesn't exist, updates if it does.
        Uses Field Frag reference to define the 'value' field.

        Args:
            key: Config key (slug), e.g., 'database-host'
            value: Config value (stored in 'value' field)

        Returns:
            Config Frag (saved)

        Example:
            config = ConfigRegistry()
            frag = await config.set_value('database-host', 'localhost')
            # Can access: frag.slug, frag.value('value')
        """
        # Ensure value field exists
        value_field = await self._ensure_value_field()

        # Check if config already exists
        existing = await self.get(key)

        if existing:
            # Update existing config
            existing.set_value('value', value)
            await existing.save()
            return existing
        else:
            # Create new config with field reference
            config_frag = Frag(
                affinities=['config'],
                traits=['fieldable', 'sluggable', 'persistable']
            )
            config_frag.set_slug(key)
            # Add field reference (builds 'value' into schema)
            config_frag.add_field_reference(value_field)
            # Now can set the value
            config_frag.set_value('value', value)
            await config_frag.save()
            return config_frag

    @cli_command()
    async def list_all(self) -> List[Dict[str, str]]:
        """
        List all configuration key-value pairs.

        Convenience method for simple config display.
        For full Frag access, use all() instead.

        Returns:
            List of dicts with 'key' and 'value' fields, sorted by key

        Example:
            config = ConfigRegistry()
            configs = await config.list_all()
            # Returns: [
            #     {'key': 'database-host', 'value': 'localhost'},
            #     {'key': 'database-port', 'value': '5432'},
            # ]
        """
        all_configs = await self.all()
        result = []

        for config_frag in all_configs:
            if hasattr(config_frag, 'slug'):
                result.append({
                    'key': config_frag.slug,
                    'value': config_frag.value('value')
                })

        # Sort by key
        result.sort(key=lambda x: x['key'])
        return result

    @cli_command(required=['key'])
    async def delete_config(self, key: str) -> bool:
        """
        Delete configuration by key.

        Args:
            key: Config key (slug) to delete

        Returns:
            True if deleted, False if not found

        Example:
            config = ConfigRegistry()
            deleted = await config.delete_config('old-setting')
        """
        return await self.delete(key)

    async def has_config(self, key: str) -> bool:
        """
        Check if configuration key exists.

        Args:
            key: Config key (slug) to check

        Returns:
            True if config exists, False otherwise

        Example:
            config = ConfigRegistry()
            if await config.has_config('jwt-secret'):
                print("JWT is configured")
        """
        config_frag = await self.get(key)
        return config_frag is not None

    async def get_by_pattern(self, pattern: str) -> List[Dict[str, str]]:
        r"""
        Get all configs matching a regex pattern.

        Uses Python's re module for pattern matching against config keys.
        Much more flexible than prefix matching.

        Args:
            pattern: Regex pattern to match against keys

        Returns:
            List of dicts with 'key' and 'value' fields

        Example:
            import re
            config = ConfigRegistry()

            # Match all database configs
            db_configs = await config.get_by_pattern(r'^database-')

            # Match specific database configs
            db_configs = await config.get_by_pattern(r'database-(host|port|name)')

            # Match all configs ending with '-secret'
            secrets = await config.get_by_pattern(r'-secret$')

            # Match configs with numbers
            numbered = await config.get_by_pattern(r'\d+')
        """
        import re

        compiled = re.compile(pattern)
        all_configs = await self.list_all()
        return [
            cfg for cfg in all_configs
            if compiled.search(cfg['key'])
        ]

    async def set_values(self, configs: Dict[str, str]) -> List[Frag]:
        """
        Set multiple configuration values at once.

        Creates new configs or updates existing ones. Consistent with
        set_value() for single values.

        Args:
            configs: Dict mapping keys to values

        Returns:
            List of saved config Frags

        Example:
            config = ConfigRegistry()
            await config.set_values({
                'smtp-host': 'smtp.gmail.com',
                'smtp-port': '587',
                'smtp-username': 'user@gmail.com',
            })
        """
        saved_frags = []
        for key, value in configs.items():
            frag = await self.set_value(key, value)
            saved_frags.append(frag)
        return saved_frags
