"""ProfileRegistry - registry for install profile Frags."""

from typing import Optional, List
from winterforge.frags.registries.frag_registry import FragRegistry
from winterforge.frags import Frag
from winterforge.frags.traits.persistable import get_storage
from winterforge.plugins.decorators import cli_command, root


@root('profile')
class ProfileRegistry(FragRegistry):
    """
    Registry for install profile Frags.

    Profiles are Frags with affinity=['install-profile'] that define
    installation workflows. They compose field definitions and execute
    installation steps.

    Example:
        profiles = ProfileRegistry()

        # List available profiles
        all_profiles = await profiles.all()

        # Get specific profile
        quick = await profiles.get_by_slug('quick-install')

        # Execute profile
        values = await quick.execute(interactive=True)
    """

    def __init__(self):
        """Initialize ProfileRegistry for install-profile affinity."""
        super().__init__(
            composition={
                'affinities': ['install-profile'],
                'traits': ['profileable', 'composable', 'fieldable', 'titled', 'sluggable', 'persistable']
            }
        )

    async def get_by_slug(self, slug: str) -> Optional[Frag]:
        """
        Get profile by slug.

        Args:
            slug: Profile slug (e.g., 'quick-install')

        Returns:
            Profile Frag or None

        Example:
            profile = await profiles.get_by_slug('quick-install')
        """
        storage = get_storage()
        if not storage:
            return None

        try:
            results = await storage.query()\
                .affinity('install-profile')\
                .condition('slug', slug)\
                .execute()
            return results[0] if results else None
        except Exception:
            # Schema might not exist yet, filter in memory
            all_profiles = await storage.query().affinity('install-profile').execute()
            for profile in all_profiles:
                if hasattr(profile, 'slug') and profile.slug == slug:
                    return profile
            return None

    async def list_profiles(self) -> List[dict]:
        """
        List all profiles with metadata.

        Returns:
            List of profile info dicts with:
            - title: Profile title
            - slug: Profile slug
            - description: Profile description
            - field_count: Number of fields

        Example:
            profiles = await registry.list_profiles()
            for profile in profiles:
                print(f"{profile['title']}: {profile['description']}")
        """
        all_profiles = await self.all()
        profile_list = []

        for profile in all_profiles:
            info = {
                'title': profile.title if hasattr(profile, 'title') else 'Untitled',
                'slug': profile.slug if hasattr(profile, 'slug') else None,
                'description': profile.get_description() if hasattr(profile, 'get_description') else None,
                'field_count': profile.get_field_count() if hasattr(profile, 'get_field_count') else 0,
            }
            profile_list.append(info)

        return profile_list

    async def create_profile(
        self,
        slug: str,
        title: str,
        description: str,
        field_refs: List[Frag],
        steps: List[str] = None
    ) -> Frag:
        """
        Create a new install profile.

        Args:
            slug: Unique profile identifier
            title: Profile title
            description: Profile description
            field_refs: List of Field Frags to include
            steps: Installation step IDs

        Returns:
            Created profile Frag

        Example:
            profile = await profiles.create_profile(
                slug='custom-install',
                title='Custom Install',
                description='My custom installation',
                field_refs=[username_field, email_field],
                steps=['database', 'admin']
            )
        """
        # Create profile Frag
        profile = Frag(
            affinities=['install-profile'],
            traits=['profileable', 'composable', 'fieldable', 'titled', 'sluggable', 'persistable']
        )

        # Set metadata
        profile.set_slug(slug)
        profile.set_title(title)
        profile.set_description(description)

        if steps:
            profile.set_steps(','.join(steps))

        # Add field references
        for field_ref in field_refs:
            profile.add_field_reference(field_ref)

        # Save
        await profile.save()

        return profile
