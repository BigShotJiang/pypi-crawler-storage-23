"""FragRegistry - collection operations for Frags matching a composition pattern."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, List, Optional, Union, Callable

if TYPE_CHECKING:
    from winterforge.plugins.repository import PluginRepository
    from winterforge.frags.base import Frag
    from winterforge.plugins._protocols.storage import StorageBackend

# Identity type - accepts int IDs, str identifiers, or Frag objects
Identity = Union[int, str, 'Frag']


class RegistryBase(ABC):
    """
    Abstract base class for Frag registries.

    Registries provide query and access operations for Frags with identity resolution.
    All registries are Frag-specific and support identity resolution through the
    IdentityResolverManager.

    Must be extended for concrete usage (base classes never instantiated directly).
    """

    def __init__(self, resolver_repo: Optional['PluginRepository'] = None):
        """
        Initialize registry with optional custom resolver repository.

        Args:
            resolver_repo: Custom resolver repository for identity resolution
                          (defaults to IdentityResolverManager.repository())
        """
        self._resolver_repo = resolver_repo

    @property
    def resolvers(self) -> 'PluginRepository':
        """
        Get current identity resolver repository.

        Returns:
            PluginRepository of identity resolvers in current order
        """
        if self._resolver_repo is None:
            from winterforge.plugins.identity.manager import IdentityResolverManager
            self._resolver_repo = IdentityResolverManager.repository()
        return self._resolver_repo

    @abstractmethod
    def with_resolvers(self, resolver_repo: 'PluginRepository') -> 'RegistryBase':
        """
        Return new registry with custom resolver ordering.

        Args:
            resolver_repo: PluginRepository with custom resolver order

        Returns:
            New registry instance with specified resolvers
        """
        ...

    async def get(self, identity: Identity) -> Optional['Frag']:
        """
        Resolve identity to Frag using identity resolver chain.

        Delegates to IdentityResolverManager for resolution using this
        registry's resolver repository, then filters result through
        registry-specific composition matching.

        Args:
            identity: Identity to resolve (int ID, str identifier, or Frag)

        Returns:
            First matching Frag or None if not found

        Example:
            config = FragRegistry({'affinities': ['config']})
            db_host = await config.get('database.host')  # Resolves by slug
            db_host = await config.get(123)  # Resolves by ID
            db_host = await config.get(existing_frag)  # Accepts Frag directly
        """
        from winterforge.frags.base import Frag
        from winterforge.plugins.identity.manager import IdentityResolverManager
        from winterforge.frags.traits.persistable import get_storage

        storage = get_storage()
        if not storage:
            return None

        # For Frag objects, return directly if they match composition
        if isinstance(identity, Frag):
            if self._matches_composition(identity):
                return identity
            return None

        # For integer IDs, load and filter by composition
        if isinstance(identity, int):
            return await self._load_and_filter(identity)

        # For all other identity types (str, UUID, etc.), delegate to
        # identity resolver chain, then filter by composition
        frag_id = await IdentityResolverManager.resolve_with_repo(
            identity, storage, self.resolvers
        )

        if frag_id is None:
            return None

        return await self._load_and_filter(frag_id)

    @abstractmethod
    async def _load_and_filter(self, frag_id: int) -> Optional['Frag']:
        """
        Load Frag by ID and apply registry-specific filtering.

        Subclasses implement composition/query filtering logic.

        Args:
            frag_id: Frag ID to load

        Returns:
            Frag if it matches registry criteria, None otherwise
        """
        ...

    @abstractmethod
    async def all(self) -> List['Frag']:
        """
        Get all Frags matching this registry's criteria.

        Returns:
            List of matching Frags
        """
        ...

    async def create(self, **fields) -> 'Frag':
        """
        Create a new Frag with this registry's composition.

        Base implementation creates a Frag with the registry's affinities and traits,
        then sets any provided fields. Specialized registries should override this
        to provide type-specific parameters and validation.

        Args:
            **fields: Field values to set on the Frag

        Returns:
            Created Frag (unsaved - caller must save())

        Example:
            # Base usage
            registry = FragRegistry({'affinities': ['note'], 'traits': ['titled']})
            note = await registry.create(title='My Note')
            await note.save()

            # Specialized registries override with specific params
            users = UserRegistry()
            user = await users.create(username='john', email='john@example.com')
        """
        from winterforge.frags.base import Frag

        # Get composition from registry
        composition = getattr(self, '_composition', {'affinities': [], 'traits': []})

        # Create Frag with registry's composition
        frag = Frag(
            affinities=composition.get('affinities', []),
            traits=composition.get('traits', [])
        )

        # Set any provided fields
        for field_name, value in fields.items():
            setter_name = f'set_{field_name}'
            if hasattr(frag, setter_name):
                getattr(frag, setter_name)(value)
            else:
                setattr(frag, f'_{field_name}', value)

        return frag

    def query(self) -> 'QueryRepository':
        """
        Return QueryRepository pre-configured for this registry.

        The returned QueryRepository has:
        - Storage backend configured
        - Composition filters pre-applied (affinities, traits)

        Returns:
            QueryRepository ready for additional conditions

        Examples:
            # Simple query
            users = UserRegistry()
            admins = await users.query().condition(
                'affinities',
                'admin',
                QueryOperator.CONTAINS
            ).execute()
            # Returns Manifest

            # Complex query
            active_admins = await users.query()\\
                .condition('affinities', 'admin', QueryOperator.CONTAINS)\\
                .condition('active', True, QueryOperator.EQUALS)\\
                .sort('created_at', 'DESC')\\
                .limit(10)\\
                .execute()
        """
        from winterforge.plugins.query._repository import QueryRepository
        from winterforge.plugins.query._operators import QueryOperator
        from winterforge.frags.traits.persistable import get_storage

        # Get storage
        storage = get_storage()

        # Create QueryRepository with storage
        qb = QueryRepository(storage=storage)

        # Pre-configure with registry composition
        composition = getattr(self, '_composition', {})
        for affinity in composition.get('affinities', []):
            qb = qb.condition(
                'affinities',
                affinity,
                QueryOperator.CONTAINS
            )
        for trait in composition.get('traits', []):
            qb = qb.condition(
                'traits',
                trait,
                QueryOperator.CONTAINS
            )

        return qb


class FragRegistry(RegistryBase):
    """
    Registry for Frags matching a composition pattern, including unfiltered.

    Provides collection operations filtered by affinities and traits.
    No generic type parameter - Frags are dynamically composed.

    Two Usage Patterns:
    1. **Ad Hoc Registry**: Created on-the-fly with custom composition
    2. **Named Registry**: Concrete subclass with defined composition (see examples below)

    Ad Hoc Registry Examples:
        # By composition dict
        comments = FragRegistry({
            'affinities': ['comment'],
            'traits': ['timestamped', 'persistable']
        })

        # From existing Frag
        registry = frag.get_registry()

    Named Registry Example:
        # Concrete subclass with specialized methods
        class UserRegistry(FragRegistry):
            def __init__(self):
                super().__init__(composition={'affinities': ['user']})

            def with_role(self, role: str):
                return self.filter(lambda u: u.has_role(role))
    """

    def __init__(
        self,
        composition: Union[dict, 'Frag'],
        resolver_repo: Optional['PluginRepository'] = None
    ):
        """
        Initialize FragRegistry with a composition pattern.

        Args:
            composition: Composition dict or Frag instance
            resolver_repo: Optional custom resolver repository for identity resolution
        """
        # Initialize base with resolver repository
        super().__init__(resolver_repo)

        from winterforge.frags.base import Frag

        # Guard clause - validate composition type
        if not isinstance(composition, (Frag, dict)):
            raise ValueError(
                f"Composition must be dict or Frag, got {type(composition)}"
            )

        # Extract composition (from Frag or use dict directly)
        self._composition = (
            composition.composition if isinstance(composition, Frag)
            else composition
        )

        # Cache for compositions discovery
        self._cached_compositions: Optional['FragRegistry'] = None
        self._cached_frags: Optional[List['Frag']] = None

    async def all(self) -> List['Frag']:
        """
        Get all Frags matching this composition.

        Returns:
            List of Frags matching the composition pattern
        """
        # If we have cached frags, return them
        if self._cached_frags is not None:
            return self._cached_frags

        from winterforge.frags.base import Frag
        from winterforge.frags.traits.persistable import get_storage

        storage = get_storage()
        if not storage:
            return []

        # Get affinities and traits from composition
        affinities = self._composition.get('affinities', [])
        traits = self._composition.get('traits', [])

        # Query storage for matching Frags
        query = storage.query()
        for aff in affinities:
            query = query.affinity(aff)
        for trait in traits:
            query = query.trait(trait)
        frags = await query.execute()

        return frags

    async def filter(self, predicate: Callable[['Frag'], bool]) -> 'FragRegistry':
        """
        Filter Frags by custom predicate.

        Supports both sync and async predicates.

        Args:
            predicate: Function that takes a Frag and returns bool (can be async)

        Returns:
            New FragRegistry with filtered Frags

        Example:
            # Sync predicate
            verified = await registry.filter(lambda u: u.is_email_verified())

            # Async predicate
            async def has_admin(u):
                return await u.has_role('admin')
            admins = await registry.filter(has_admin)
        """
        import asyncio
        import inspect

        all_frags = await self.all()
        filtered_frags = []

        for f in all_frags:
            result = predicate(f)
            # Check if result is a coroutine (async predicate)
            if inspect.iscoroutine(result):
                result = await result
            if result:
                filtered_frags.append(f)

        return self._with_frags(filtered_frags)

    async def first(self) -> Optional['Frag']:
        """
        Get first Frag matching this composition.

        Returns:
            First matching Frag or None
        """
        frags = await self.all()
        return frags[0] if frags else None

    async def count(self) -> int:
        """
        Count Frags matching this composition.

        Returns:
            Number of matching Frags
        """
        all_frags = await self.all()
        return len(all_frags)

    async def get_compositions(self, refresh: bool = False) -> 'FragRegistry':
        """
        Get registry of unique compositions found in this registry.

        Analyzes all Frags in this registry, identifies unique combinations
        of affinities + traits (NOT aliases), and returns a registry of
        Frags where each represents one unique composition pattern.

        Aliases are NOT part of composition (they're identifiers, not schema).
        Only affinities + traits define composition.

        Results are cached. Set refresh=True to recompute.

        Args:
            refresh: If True, recompute instead of using cache (default: False)

        Returns:
            FragRegistry containing Frags representing each unique composition

        Example:
            posts = FragRegistry({'affinities': ['post'], 'traits': ['titled']})

            # First call computes and caches
            compositions = await posts.get_compositions()

            # Subsequent calls use cache
            compositions = await posts.get_compositions()  # Fast!

            # Force refresh
            compositions = await posts.get_compositions(refresh=True)
        """
        from winterforge.frags.base import Frag

        # Check cache
        if not refresh and self._cached_compositions is not None:
            return self._cached_compositions

        from winterforge.frags.traits.persistable import get_storage

        storage = get_storage()
        if not storage:
            empty_registry = FragRegistry({'affinities': [], 'traits': []})
            self._cached_compositions = empty_registry
            return empty_registry

        # Get all Frags in this registry
        frags = await self.all()

        # Track unique compositions as tuples for hashability
        # NOTE: Aliases are NOT part of composition (they're identifiers, not schema)
        seen_compositions = set()
        unique_frags = []

        for frag in frags:
            # Create hashable composition signature (affinities + traits only)
            comp_sig = (
                tuple(sorted(frag.affinities)),
                tuple(sorted(frag.traits))
            )

            if comp_sig not in seen_compositions:
                seen_compositions.add(comp_sig)
                unique_frags.append(frag)

        # Create new registry with unique composition Frags
        result = FragRegistry({
            'affinities': [],  # No filter - include all
            'traits': []
        })._with_frags(unique_frags)

        # Cache result
        self._cached_compositions = result
        return result

    def with_resolvers(self, resolver_repo: 'PluginRepository') -> 'FragRegistry':
        """
        Return new FragRegistry with custom resolver ordering.

        Args:
            resolver_repo: PluginRepository with custom resolver order

        Returns:
            New FragRegistry with same composition but different resolvers

        Example:
            registry = FragRegistry({'affinities': ['config']})
            # Prefer slug resolution first
            registry = registry.with_resolvers(
                IdentityResolverManager.repository().with_front('slug')
            )
        """
        return FragRegistry(self._composition, resolver_repo)

    async def _load_and_filter(self, frag_id: int) -> Optional['Frag']:
        """
        Load Frag by ID and verify it matches this registry's composition.

        Args:
            frag_id: Frag ID to load

        Returns:
            Frag if it matches composition, None otherwise
        """
        from winterforge.frags.base import Frag
        from winterforge.frags.traits.persistable import get_storage

        storage = get_storage()
        if not storage:
            return None

        frag = await storage.load(frag_id)
        if frag is None:
            return None

        # Verify frag matches our composition pattern
        if self._matches_composition(frag):
            return frag

        return None

    def _matches_composition(self, frag: 'Frag') -> bool:
        """
        Check if a Frag matches this registry's composition pattern.

        Composition matching checks:
        - Affinities: Frag must have all required affinities
        - Traits: Frag must have all required traits
        - Aliases: Frag must have all required relations (keys), values don't matter

        Args:
            frag: Frag to check

        Returns:
            True if frag matches the composition
        """
        # Get required affinities, traits, and aliases from our composition
        required_affinities = set(self._composition.get('affinities', []))
        required_traits = set(self._composition.get('traits', []))
        required_aliases = self._composition.get('aliases', {})

        # Frag must have all required affinities and traits
        frag_affinities = set(frag.affinities)
        frag_traits = set(frag.traits)

        # Frag must have all required alias relations (keys only, not values)
        required_relations = set(required_aliases.keys())
        frag_relations = set(frag.aliases.keys())

        return (
            required_affinities.issubset(frag_affinities) and
            required_traits.issubset(frag_traits) and
            required_relations.issubset(frag_relations)
        )

    async def delete(self, identity: Identity) -> bool:
        """
        Delete a Frag by identity.

        Uses identity resolution to find the Frag, then deletes it from storage.

        Args:
            identity: Identity to resolve (int ID, str identifier, or Frag)

        Returns:
            True if deleted, False if not found

        Example:
            users = UserRegistry()
            await users.delete('john_doe')  # By username
            await users.delete(123)  # By ID
            await users.delete(user_frag)  # By Frag object
        """
        from winterforge.frags.base import Frag
        from winterforge.frags.traits.persistable import get_storage

        storage = get_storage()
        if not storage:
            return False

        # Resolve identity to Frag
        frag = await self.get(identity)
        if frag is None:
            return False

        # Delete from storage
        return await storage.delete(frag.id)


    def _with_frags(self, frags: List['Frag']) -> 'FragRegistry':
        """
        Internal: Override all() to return specific Frag list.

        Args:
            frags: List of Frags to cache

        Returns:
            Self for method chaining
        """
        self._cached_frags = frags
        return self
