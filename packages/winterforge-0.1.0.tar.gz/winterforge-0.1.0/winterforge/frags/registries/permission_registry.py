"""PermissionRegistry - specialized registry for Permission Frags."""

from __future__ import annotations

from typing import Optional

from winterforge.frags.registries.frag_registry import FragRegistry
from winterforge.plugins.decorators import (
    decorator_provider,
    CLICommandConfig,
    root,
)


@root('permission')
class PermissionRegistry(FragRegistry):
    """
    Registry for Permission Frags.

    Provides query methods for permissions.

    Example:
        permissions = PermissionRegistry()

        # Get permission by title or ID
        perm = await permissions.get('user.delete')
        perm = await permissions.get(123)

        # Get all permissions
        all_perms = await permissions.all()
    """

    def __init__(self, resolver_repo: Optional['PluginRepository'] = None):
        """
        Initialize PermissionRegistry with permission composition.

        Args:
            resolver_repo: Optional custom resolver repository
        """
        super().__init__(
            composition={'affinities': ['permission']},
            resolver_repo=resolver_repo
        )

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ Permission created: {title} (ID: {id})"
        )
    )
    async def create(self, title: str) -> 'Frag':
        """
        Create a new permission.

        Args:
            title: Permission title (e.g., 'user.delete', 'post.create')

        Returns:
            Permission Frag

        Example:
            # Programmatic
            permissions = PermissionRegistry()
            perm = await permissions.create('user.delete')

            # CLI
            winterforge permission create user.delete
        """
        from winterforge.frags.base import Frag

        # Create permission Frag
        perm = Frag(
            affinities=['permission'],
            traits=['fieldable', 'titled', 'timestamped', 'persistable']
        )

        perm.set_title(title)
        await perm.save()

        return perm

    async def ensure_permission(
        self,
        slug: str,
        title: str,
        description: str = None
    ) -> 'Frag':
        """
        Ensure a permission exists, creating it if necessary.

        Args:
            slug: Permission slug/identifier
            title: Permission title
            description: Optional description

        Returns:
            Permission Frag

        Example:
            perm = await permissions.ensure_permission(
                'content.create',
                'Create content',
                'Permission to create new content'
            )
        """
        # Try to get existing permission
        perm = await self.get(slug)
        if perm:
            return perm

        # Create new permission
        from winterforge.frags.base import Frag

        perm = Frag(
            affinities=['permission'],
            traits=['fieldable', 'titled', 'sluggable', 'timestamped', 'persistable']
        )

        perm.set_slug(slug)
        perm.set_title(title)

        if description:
            perm.set_alias('description', description)

        await perm.save()
        return perm

    @decorator_provider(
        cli_command=CLICommandConfig()
    )
    async def list_permissions(self):
        """
        List all permissions.

        Returns:
            List of Permission Frags

        Example:
            # Programmatic
            permissions = PermissionRegistry()
            all_perms = await permissions.list_permissions()

            # CLI
            winterforge permission list
        """
        return await self.all()

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ Permission deleted: {title}",
            error="Permission not found: {title}"
        )
    )
    async def delete_permission(self, title: str) -> bool:
        """
        Delete a permission.

        Args:
            title: Permission title

        Returns:
            True if deleted, False if not found

        Example:
            # Programmatic
            deleted = await permissions.delete_permission('user.delete')

            # CLI
            winterforge permission delete user.delete
        """
        return await self.delete(title)
