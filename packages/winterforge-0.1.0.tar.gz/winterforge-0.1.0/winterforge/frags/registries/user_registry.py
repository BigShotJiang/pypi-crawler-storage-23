"""UserRegistry - specialized registry for User Frags."""

from __future__ import annotations

from typing import Optional

from winterforge.frags.registries.frag_registry import FragRegistry, Identity
from winterforge.plugins.decorators import (
    decorator_provider,
    root,
)

# NOTE: Do NOT import CLICommandConfig here - it causes circular import!
# CLICommandConfig import triggers cli package load which imports main.py
# which imports this module. Use dicts for cli_command config instead.


@root('user')
class UserRegistry(FragRegistry):
    """
    Registry for User Frags with role filtering.

    Provides specialized query methods for users with roles and permissions.

    Example:
        users = UserRegistry()

        # Get user by username, email, or ID
        user = await users.get('beau')
        user = await users.get('beau@example.com')
        user = await users.get(123)

        # Filter users
        admins = users.with_role('admin')
        editors = users.with_permission('post.edit')
        verified = users.verified_only()
        locked = users.locked_only()
    """

    def __init__(self, resolver_repo: Optional['PluginRepository'] = None):
        """
        Initialize UserRegistry with user composition.

        Args:
            resolver_repo: Optional custom resolver repository
        """
        super().__init__(
            composition={'affinities': ['user']},
            resolver_repo=resolver_repo
        )

    async def with_role(self, role_title: str) -> 'UserRegistry':
        """
        Filter users by role title.

        Args:
            role_title: Role title (e.g., 'admin', 'editor')

        Returns:
            Filtered registry
        """
        import asyncio

        async def has_role_filter(u):
            return await u.has_role(role_title)

        return await self.filter(has_role_filter)

    async def with_permission(self, perm_title: str) -> 'UserRegistry':
        """
        Filter users by permission.

        Args:
            perm_title: Permission title (e.g., 'user.delete')

        Returns:
            Filtered registry
        """
        async def has_permission_filter(u):
            return await u.has_permission(perm_title)

        return await self.filter(has_permission_filter)

    async def verified_only(self) -> 'UserRegistry':
        """
        Filter to verified email users.

        Returns:
            Filtered registry
        """
        return await self.filter(lambda u: u.is_email_verified())

    @decorator_provider(
        cli_command={
            'message_success': "✓ {entity} created: {display_name} (ID: {id}){role_info}",
            'options': {
                'password': {'prompt': True, 'hide_input': True, 'confirmation_prompt': True, 'help': 'User password'},
                'role': {'help': 'Role to assign (can specify multiple)', 'multiple': True},
                'verified': {'is_flag': True, 'help': 'Mark email as verified'}
            }
        }
    )
    async def create(
        self,
        username: str,
        email: str,
        password: str = None,
        role: tuple = None,
        verified: bool = False
    ) -> 'Frag':
        """
        Create a new user.

        Decorator auto-wraps return in CLIResult when called from CLI.

        Args:
            username: Username (3-30 chars, alphanumeric + underscore/dash)
            email: Email address
            password: Password (optional)
            role: Tuple of role titles (CLI) or list (programmatic)
            verified: Mark email as verified (default: False)

        Returns:
            User Frag (auto-wrapped in CLIResult if called from CLI)

        Example:
            # Programmatic usage
            users = UserRegistry()
            user = await users.create('john_doe', 'john@example.com', 'pass123', ['editor'])

            # CLI usage
            winterforge user create john_doe john@example.com --role editor
        """
        from winterforge.frags.base import Frag
        from winterforge.frags.registries.role_registry import RoleRegistry

        # Normalize roles (CLI passes tuple, programmatic passes list)
        roles_list = list(role) if role else None

        # Create user Frag
        user = Frag(
            affinities=['user'],
            traits=['userable', 'authenticatable', 'authorizable', 'sessionable', 'timestamped', 'persistable']
        )

        user.set_username(username)
        user.set_email(email)

        if password:
            user.set_password(password)

        if verified:
            user.mark_email_verified()

        # Assign roles if provided
        if roles_list:
            role_registry = RoleRegistry()
            for role_title in roles_list:
                role_frag = await role_registry.get(role_title)
                if role_frag:
                    user.add_role(role_frag.id)

        await user.save()

        # Decorator handles CLI wrapping automatically
        return user

    @decorator_provider(
        cli_command={
            
            'options':{
                'role': {'help': 'Filter by role'},
                'verified': {'is_flag': True, 'help': 'Show only verified users'},
                'locked': {'is_flag': True, 'help': 'Show only locked users'}
            }
        }
    )
    async def list_users(
        self,
        role: str = None,
        verified: bool = False,
        locked: bool = False
    ) -> 'Frag':
        """
        List all users with optional filters.

        Returns:
            List of User Frags (programmatic) or CLIResult Frag (CLI)

        Example:
            # Programmatic
            users = UserRegistry()
            all_users = await users.list_users()

            # CLI
            winterforge user list --role admin --verified
        """
        from winterforge.plugins.cli._context import in_cli_context, cli_result

        # Apply filters
        registry = self
        if role:
            registry = await registry.with_role(role)
        if verified:
            registry = await registry.verified_only()
        if locked:
            registry = await registry.locked_only()

        # Get all matching users
        users = await registry.all()

        # Return appropriate Frag based on context
        if in_cli_context():
            if not users:
                return cli_result(success=True, message="No users found.")

            # Format user list
            lines = [f"\nFound {len(users)} user(s):\n"]
            for u in users:
                status = []
                if u.is_email_verified():
                    status.append("verified")
                if u.is_locked():
                    status.append(f"locked until {u.locked_until.strftime('%Y-%m-%d %H:%M')}")

                status_str = f" ({', '.join(status)})" if status else ""
                lines.append(f"  {u.id:4d}  {u.username:20s}  {u.email:30s}{status_str}")

            return cli_result(
                success=True,
                message="\n".join(lines),
                data={'count': len(users)}
            )
        else:
            return users

    @decorator_provider('cli_command')
    async def show(self, identity: Identity) -> 'Frag':
        """
        Show detailed user information.

        Decorator auto-wraps return in CLIResult when called from CLI.

        Args:
            identity: Username, email, or ID

        Returns:
            User Frag (auto-wrapped in CLIResult if called from CLI)

        Example:
            # Programmatic
            user = await users.show('john_doe')

            # CLI
            winterforge user show john_doe
        """
        user = await self.get(identity)

        if not user:
            return None

        # Decorator handles CLI wrapping automatically
        return user

    @decorator_provider(
        cli_command={
            
            'message_success':"✓ User deleted: {identity}",
            'message_failure':"User not found: {identity}"
        }
    )
    async def delete_user(self, identity: Identity) -> bool:
        """
        Delete a user.

        Args:
            identity: Username, email, or ID

        Returns:
            True if deleted, False if not found

        Example:
            # Programmatic
            deleted = await users.delete_user('john_doe')

            # CLI
            winterforge user delete john_doe
        """
        return await self.delete(identity)

    async def locked_only(self) -> 'UserRegistry':
        """
        Filter to locked accounts.

        Returns:
            Filtered registry
        """
        return await self.filter(lambda u: u.is_locked())

    @decorator_provider(
        cli_command={
            'message_success':"✓ Password updated for user: {identity}",
            'options':{
                'password': {'prompt': True, 'hide_input': True, 'confirmation_prompt': True, 'help': 'New password'}
            }
        }
    )
    async def set_password(self, identity: Identity, password: str) -> Optional['Frag']:
        """
        Update user password.

        Args:
            identity: Username, email, or ID
            password: New password

        Returns:
            User Frag if found, None if not found

        Example:
            # Programmatic
            user = await users.set_password('john_doe', 'newpass123')

            # CLI
            winterforge user set-password john_doe
        """
        user = await self.get(identity)
        if not user:
            return None

        user.set_password(password)
        await user.save()
        return user

    @decorator_provider(
        cli_command={
            'message_success':"✓ Email updated for user: {identity} → {email} (verification reset)"
        }
    )
    async def set_email(self, identity: Identity, email: str) -> Optional['Frag']:
        """
        Update user email address.

        Args:
            identity: Username, email, or ID
            email: New email address

        Returns:
            User Frag if found, None if not found

        Example:
            # Programmatic
            user = await users.set_email('john_doe', 'new@example.com')

            # CLI
            winterforge user set-email john_doe new@example.com
        """
        user = await self.get(identity)
        if not user:
            return None

        user.set_email(email)
        # Email verification resets when email changes
        user._email_verified = False
        await user.save()
        return user

    @decorator_provider(
        cli_command={
            'message_success':"✓ Email verified for user: {identity}"
        }
    )
    async def verify_email(self, identity: Identity) -> Optional['Frag']:
        """
        Mark user email as verified.

        Args:
            identity: Username, email, or ID

        Returns:
            User Frag if found, None if not found

        Example:
            # Programmatic
            user = await users.verify_email('john_doe')

            # CLI
            winterforge user verify-email john_doe
        """
        user = await self.get(identity)
        if not user:
            return None

        user.mark_email_verified()
        await user.save()
        return user

    @decorator_provider(
        cli_command={
            'message_success':"✓ User locked: {identity} (duration: {duration}s)",
            'options':{
                'duration': {'type': int, 'help': 'Lock duration in seconds (default: 900 = 15 minutes)'}
            }
        }
    )
    async def lock(self, identity: Identity, duration: int = 900) -> Optional['Frag']:
        """
        Lock user account.

        Args:
            identity: Username, email, or ID
            duration: Lock duration in seconds (default: 900 = 15 minutes)

        Returns:
            User Frag if found, None if not found

        Example:
            # Programmatic
            user = await users.lock('john_doe', duration=3600)

            # CLI
            winterforge user lock john_doe --duration 3600
        """
        from datetime import datetime, timedelta

        user = await self.get(identity)
        if not user:
            return None

        # Set lockout
        user._locked_until = datetime.now() + timedelta(seconds=duration)
        await user.save()
        return user

    @decorator_provider(
        cli_command={
            'message_success':"✓ User unlocked: {identity}"
        }
    )
    async def unlock(self, identity: Identity) -> Optional['Frag']:
        """
        Unlock user account.

        Args:
            identity: Username, email, or ID

        Returns:
            User Frag if found, None if not found

        Example:
            # Programmatic
            user = await users.unlock('john_doe')

            # CLI
            winterforge user unlock john_doe
        """
        user = await self.get(identity)
        if not user:
            return None

        user.unlock()
        await user.save()
        return user

    @decorator_provider(
        cli_command={
            'message_success':"✓ Role assigned: {identity} → {role_title}"
        }
    )
    async def add_role(self, identity: Identity, role_title: str) -> Optional['Frag']:
        """
        Assign role to user.

        Args:
            identity: Username, email, or ID
            role_title: Role title to assign

        Returns:
            User Frag if successful, None if user or role not found

        Example:
            # Programmatic
            user = await users.add_role('john_doe', 'admin')

            # CLI
            winterforge user add-role john_doe admin
        """
        from winterforge.frags.registries.role_registry import RoleRegistry

        user = await self.get(identity)
        if not user:
            return None

        # Get role
        role_registry = RoleRegistry()
        role = await role_registry.get(role_title)
        if not role:
            return None

        # Add role
        user.add_role(role.id)
        await user.save()
        return user

    @decorator_provider(
        cli_command={
            'message_success':"✓ Role revoked: {identity} ✗ {role_title}"
        }
    )
    async def remove_role(self, identity: Identity, role_title: str) -> Optional['Frag']:
        """
        Revoke role from user.

        Args:
            identity: Username, email, or ID
            role_title: Role title to revoke

        Returns:
            User Frag if successful, None if user or role not found

        Example:
            # Programmatic
            user = await users.remove_role('john_doe', 'admin')

            # CLI
            winterforge user remove-role john_doe admin
        """
        from winterforge.frags.registries.role_registry import RoleRegistry

        user = await self.get(identity)
        if not user:
            return None

        # Get role
        role_registry = RoleRegistry()
        role = await role_registry.get(role_title)
        if not role:
            return None

        # Remove role
        user.remove_role(role.id)
        await user.save()
        return user
