"""Registry for Trait Frags."""

from __future__ import annotations

from typing import List, Optional

from winterforge.frags.registries import FragRegistry
from winterforge.frags import Frag


class TraitRegistry(FragRegistry):
    """Registry for Trait Frags."""

    def __init__(self):
        """Initialize with trait composition."""
        super().__init__(composition={'affinities': ['trait']})

    async def all(self) -> List[Frag]:
        """
        Get all Traits.

        Overrides base to return typed Trait instances.

        Returns:
            List of Trait instances
        """
        from winterforge.frags.primitives import Trait

        # Get base Frags from parent
        frags = await super().all()

        # Convert each to typed Trait
        traits = []
        for frag in frags:
            trait = Trait(
                affinities=frag.affinities,
                traits=frag.traits,
                aliases=frag.aliases,
            )
            trait._set_id(frag.id)
            trait._loaded_from_storage = True

            # Copy fieldable data if present
            if hasattr(frag, '_fieldable_data') and frag._fieldable_data:
                trait._fieldable_data = frag._fieldable_data

            trait._initialize_traits()
            traits.append(trait)

        return traits

    async def _load_and_filter(self, frag_id: int) -> Optional[Frag]:
        """
        Load Trait by ID and return typed Trait instance.

        Args:
            frag_id: Frag ID to load

        Returns:
            Trait instance if it matches composition, None otherwise
        """
        from winterforge.frags.traits.persistable import get_storage
        from winterforge.frags.primitives import Trait

        storage = get_storage()
        if not storage:
            return None

        frag = await storage.load(frag_id)
        if frag is None:
            return None

        # Verify frag matches our composition pattern
        if not self._matches_composition(frag):
            return None

        # Convert to typed Trait instance
        trait = Trait(
            affinities=frag.affinities,
            traits=frag.traits,
            aliases=frag.aliases,
        )
        trait._set_id(frag.id)
        trait._loaded_from_storage = True

        # Copy fieldable data if present
        if hasattr(frag, '_fieldable_data') and frag._fieldable_data:
            trait._fieldable_data = frag._fieldable_data

        # Re-initialize traits with loaded data
        trait._initialize_traits()

        return trait


__all__ = ['TraitRegistry']
