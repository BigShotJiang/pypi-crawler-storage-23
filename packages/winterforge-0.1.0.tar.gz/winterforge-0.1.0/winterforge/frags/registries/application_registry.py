"""Application identity registry."""

from winterforge.frags.registries.frag_registry import FragRegistry


class ApplicationRegistry(FragRegistry):
    """
    Registry for application identity Frags.

    Typically contains one Frag representing the current application,
    but supports multiple through stack resolution for:
    - Context switching
    - Multi-tenant scenarios
    - Development/staging/production environments
    - Plugin-injected application contexts

    Application Frags serve as signals in import/export:
    - Export includes application Frags → non-portable
    - Export omits application Frags → portable

    Example:
        # Get all application Frags
        registry = ApplicationRegistry()
        apps = await registry.all()

        # Get first (primary) application
        current = apps.resolve(lambda f: True)
        print(f"Application: {current.name}")
        print(f"UUID: {current.uuid}")

        # Create new application
        app = await registry.create(
            name='Production Blog',
            description='Main production instance'
        )
        await app.save()

        # Check in export
        export_apps = [
            row for row in export_data['frags'].values()
            if 'application' in row.get('affinities', [])
        ]
        if export_apps:
            # Non-portable export
            app_uuids = [app['uuid'] for app in export_apps]
    """

    _affinity = 'application'
    _traits = ['is_application']

    def __init__(self):
        """Initialize ApplicationRegistry with proper composition."""
        super().__init__(composition={
            'affinities': ['application'],
            'traits': ['is_application', 'persistable']
        })
