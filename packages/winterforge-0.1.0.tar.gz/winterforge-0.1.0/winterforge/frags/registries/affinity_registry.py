"""Registry for Affinity Frags."""

from __future__ import annotations

from typing import List, Optional

from winterforge.frags.registries import FragRegistry
from winterforge.frags import Frag


class AffinityRegistry(FragRegistry):
    """Registry for Affinity Frags."""

    def __init__(self):
        """Initialize with affinity composition."""
        super().__init__(composition={'affinities': ['affinity']})

    async def all(self) -> List[Frag]:
        """
        Get all Affinities.

        Overrides base to return typed Affinity instances.

        Returns:
            List of Affinity instances
        """
        from winterforge.frags.primitives import Affinity

        # Get base Frags from parent
        frags = await super().all()

        # Convert each to typed Affinity
        affinities = []
        for frag in frags:
            affinity = Affinity(
                affinities=frag.affinities,
                traits=frag.traits,
                aliases=frag.aliases,
            )
            affinity._set_id(frag.id)
            affinity._loaded_from_storage = True

            # Copy fieldable data if present
            if hasattr(frag, '_fieldable_data') and frag._fieldable_data:
                affinity._fieldable_data = frag._fieldable_data

            affinity._initialize_traits()
            affinities.append(affinity)

        return affinities

    async def _load_and_filter(self, frag_id: int) -> Optional[Frag]:
        """
        Load Affinity by ID and return typed Affinity instance.

        Args:
            frag_id: Frag ID to load

        Returns:
            Affinity instance if it matches composition, None otherwise
        """
        from winterforge.frags.traits.persistable import get_storage
        from winterforge.frags.primitives import Affinity

        storage = get_storage()
        if not storage:
            return None

        frag = await storage.load(frag_id)
        if frag is None:
            return None

        # Verify frag matches our composition pattern
        if not self._matches_composition(frag):
            return None

        # Convert to typed Affinity instance
        affinity = Affinity(
            affinities=frag.affinities,
            traits=frag.traits,
            aliases=frag.aliases,
        )
        affinity._set_id(frag.id)
        affinity._loaded_from_storage = True

        # Copy fieldable data if present
        if hasattr(frag, '_fieldable_data') and frag._fieldable_data:
            affinity._fieldable_data = frag._fieldable_data

        # Re-initialize traits with loaded data
        affinity._initialize_traits()

        return affinity


__all__ = ['AffinityRegistry']
