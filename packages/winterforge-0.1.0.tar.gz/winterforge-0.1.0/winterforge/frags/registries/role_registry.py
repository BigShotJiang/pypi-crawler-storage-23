"""RoleRegistry - specialized registry for Role Frags."""

from __future__ import annotations

from typing import Optional

from winterforge.frags.registries.frag_registry import FragRegistry
from winterforge.plugins.decorators import (
    decorator_provider,
    CLICommandConfig,
    root,
)


@root('role')
class RoleRegistry(FragRegistry):
    """
    Registry for Role Frags.

    Provides specialized query methods for roles with permissions.

    Example:
        roles = RoleRegistry()

        # Get role by title or ID
        admin = await roles.get('admin')
        role = await roles.get(123)

        # Filter roles
        delete_roles = roles.with_permission('user.delete')
    """

    def __init__(self, resolver_repo: Optional['PluginRepository'] = None):
        """
        Initialize RoleRegistry with role composition.

        Args:
            resolver_repo: Optional custom resolver repository
        """
        super().__init__(
            composition={'affinities': ['role']},
            resolver_repo=resolver_repo
        )

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ {entity} created: {display_name} (ID: {id}){permission_info}",
            options={
                'permission': {'help': 'Permission to assign (can specify multiple)', 'multiple': True}
            }
        )
    )
    async def create(
        self,
        title: str,
        permission: tuple = None
    ) -> 'Frag':
        """
        Create a new role.

        Decorator auto-wraps return in CLIResult when called from CLI.

        Args:
            title: Role title (e.g., 'admin', 'editor')
            permission: Tuple of permission titles (CLI) or list (programmatic)

        Returns:
            Role Frag (auto-wrapped in CLIResult if called from CLI)

        Example:
            # Programmatic
            roles = RoleRegistry()
            admin = await roles.create('admin', ['user.delete', 'post.create'])

            # CLI
            winterforge role create admin --permission user.delete --permission post.create
        """
        from winterforge.frags.base import Frag
        from winterforge.frags.registries.permission_registry import PermissionRegistry

        # Normalize permissions (CLI passes tuple, programmatic passes list)
        perms_list = list(permission) if permission else None

        # Create role Frag
        role = Frag(
            affinities=['role'],
            traits=['fieldable', 'titled', 'permissioned', 'timestamped', 'persistable']
        )

        role.set_title(title)

        # Assign permissions if provided
        if perms_list:
            perm_registry = PermissionRegistry()
            for perm_title in perms_list:
                perm_frag = await perm_registry.get(perm_title)
                if perm_frag:
                    role.add_permission(perm_frag.id)

        await role.save()

        # Decorator handles CLI wrapping automatically
        return role

    async def ensure_role(
        self,
        slug: str,
        title: str,
        description: str = None
    ) -> 'Frag':
        """
        Ensure a role exists, creating it if necessary.

        Args:
            slug: Role slug/identifier
            title: Role title
            description: Optional description

        Returns:
            Role Frag

        Example:
            role = await roles.ensure_role('admin', 'Administrator', 'Full access')
        """
        # Try to get existing role
        role = await self.get(slug)
        if role:
            return role

        # Create new role
        from winterforge.frags.base import Frag

        role = Frag(
            affinities=['role'],
            traits=['fieldable', 'titled', 'sluggable', 'timestamped', 'persistable']
        )

        role.set_slug(slug)
        role.set_title(title)

        if description:
            role.set_alias('description', description)

        await role.save()
        return role

    async def with_permission(self, perm_title: str) -> 'RoleRegistry':
        """
        Filter roles by permission.

        Args:
            perm_title: Permission title (e.g., 'user.delete')

        Returns:
            Filtered registry
        """
        async def has_permission_filter(r):
            perms = await r.get_permissions()
            return any(p.title == perm_title for p in perms)

        return await self.filter(has_permission_filter)

    @decorator_provider(
        cli_command=CLICommandConfig(
            
            options={
                'permission': {'help': 'Filter by permission'}
            }
        )
    )
    async def list_roles(
        self,
        permission: str = None
    ) -> list['Frag']:
        """
        List all roles with optional filters.

        Args:
            permission: Filter by permission title

        Returns:
            List of Role Frags

        Example:
            # Programmatic
            roles = RoleRegistry()
            all_roles = await roles.list_roles()

            # CLI
            winterforge role list --permission user.delete
        """
        # Apply filters
        registry = self
        if permission:
            registry = registry.with_permission(permission)

        # Get all matching roles
        roles = await registry.all()

        return roles

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ Permission added: {role_title} ← {permission_title}",
            error="Role or permission not found"
        )
    )
    async def add_permission(
        self,
        role_title: str,
        permission_title: str
    ) -> Optional['Frag']:
        """
        Add permission to role.

        Args:
            role_title: Role title
            permission_title: Permission title to add

        Returns:
            Role Frag or None if role/permission not found

        Example:
            # Programmatic
            role = await roles.add_permission('admin', 'user.delete')

            # CLI
            winterforge role add-permission admin user.delete
        """
        from winterforge.frags.registries.permission_registry import (
            PermissionRegistry
        )

        role = await self.get(role_title)
        if not role:
            return None

        # Get permission
        perm_registry = PermissionRegistry()
        perm = await perm_registry.get(permission_title)
        if not perm:
            return None

        # Add permission
        role.add_permission(perm.id)
        await role.save()

        return role

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ Permission removed: {role_title} ✗ {permission_title}",
            error="Role or permission not found"
        )
    )
    async def remove_permission(
        self,
        role_title: str,
        permission_title: str
    ) -> Optional['Frag']:
        """
        Remove permission from role.

        Args:
            role_title: Role title
            permission_title: Permission title to remove

        Returns:
            Role Frag or None if role/permission not found

        Example:
            # Programmatic
            role = await roles.remove_permission('admin', 'user.delete')

            # CLI
            winterforge role remove-permission admin user.delete
        """
        from winterforge.frags.registries.permission_registry import (
            PermissionRegistry
        )

        role = await self.get(role_title)
        if not role:
            return None

        # Get permission
        perm_registry = PermissionRegistry()
        perm = await perm_registry.get(permission_title)
        if not perm:
            return None

        # Remove permission
        role.remove_permission(perm.id)
        await role.save()

        return role

    @decorator_provider(
        cli_command=CLICommandConfig(
            
            success="✓ Role deleted: {title}",
            error="Role not found: {title}"
        )
    )
    async def delete_role(self, title: str) -> bool:
        """
        Delete a role.

        Args:
            title: Role title

        Returns:
            True if deleted, False if not found

        Example:
            # Programmatic
            deleted = await roles.delete_role('editor')

            # CLI
            winterforge role delete editor
        """
        # Use base registry delete method
        success = await self.delete(title)
        return success
