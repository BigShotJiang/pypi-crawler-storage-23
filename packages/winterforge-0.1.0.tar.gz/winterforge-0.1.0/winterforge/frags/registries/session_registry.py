"""SessionRegistry - specialized registry for Session Frags."""

from __future__ import annotations

from typing import Optional
from datetime import datetime

from winterforge.frags.registries.frag_registry import FragRegistry, Identity
from winterforge.plugins.decorators import (
    decorator_provider,
    CLICommandConfig,
    root,
)


@root('session')
class SessionRegistry(FragRegistry):
    """
    Registry for Session Frags.

    Provides specialized query methods for sessions.

    Example:
        sessions = SessionRegistry()

        # Get session by token or ID
        session = await sessions.get('abc123def456')
        session = await sessions.get(123)

        # Filter sessions
        user_sessions = await sessions.for_user(user_id=123)
        active = await sessions.active_only()
    """

    def __init__(self, resolver_repo: Optional['PluginRepository'] = None):
        """
        Initialize SessionRegistry with session composition.

        Args:
            resolver_repo: Optional custom resolver repository
        """
        super().__init__(
            composition={'affinities': ['session']},
            resolver_repo=resolver_repo
        )

    async def for_user(self, user_identity: Identity) -> 'SessionRegistry':
        """
        Filter sessions by user identity.

        Args:
            user_identity: User identity (username, email, or ID)

        Returns:
            Filtered registry

        Example:
            sessions = SessionRegistry()

            # By username
            user_sessions = await sessions.for_user('john_doe')

            # By email
            user_sessions = await sessions.for_user('john@example.com')

            # By ID
            user_sessions = await sessions.for_user(123)
        """
        from winterforge.frags.registries.user_registry import UserRegistry

        # Resolve user identity to Frag
        users = UserRegistry()
        user_frag = await users.get(user_identity)

        if not user_frag:
            # Return empty registry if user not found
            return await self.filter(lambda s: False)

        return await self.filter(lambda s: s.owner_id == user_frag.id)

    async def active_only(self) -> 'SessionRegistry':
        """
        Filter to non-expired sessions.

        Returns:
            Filtered registry
        """
        return await self.filter(lambda s: s.expires_at > datetime.now())

    @decorator_provider(
        cli_command=CLICommandConfig(
            success=(
                "✓ Session created for user: {user_identity}\n"
                "  Provider: {provider}\n"
                "  TTL: {ttl} seconds\n"
                "  Token: {result}"
            ),
            error="✗ User not found: {user_identity}",
            options={
                'provider': {
                    'default': 'frag',
                    'help': 'Session provider (frag or jwt)'
                },
                'ttl': {
                    'type': int,
                    'default': 86400,
                    'help': 'Session TTL in seconds (default: 86400 = 24 hours)'
                }
            }
        )
    )
    async def create(
        self,
        user_identity: Identity,
        provider: str = 'frag',
        ttl: int = 86400
    ) -> Optional[str]:
        """Create a new session for user (testing/development)."""
        from winterforge.frags.registries.user_registry import UserRegistry
        from winterforge.plugins import SessionProviderManager

        # Load user
        users = UserRegistry()
        user_frag = await users.get(user_identity)

        if not user_frag:
            return None

        # Create session
        token = await SessionProviderManager.create_session(
            user_id=user_frag.id,
            ttl=ttl,
            provider_id=provider
        )

        return token

    @decorator_provider(
        cli_command=CLICommandConfig(
            success=(
                "✓ Valid session\n"
                "  User ID: {result[user_id]}\n"
                "  Expires: {result[expires_at]}"
            ),
            error="✗ Invalid or expired session token"
        )
    )
    async def verify(self, token: str) -> Optional[dict]:
        """Verify a session token."""
        from winterforge.plugins import SessionProviderManager

        session_data = await SessionProviderManager.verify_session(token)

        if not session_data:
            return None

        return session_data

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ Session invalidated",
            error="✗ Session not found or already invalidated"
        )
    )
    async def invalidate(self, token: str) -> bool:
        """Invalidate a session token."""
        from winterforge.plugins import SessionProviderManager

        success = await SessionProviderManager.invalidate_session(token)
        return success

    @decorator_provider(
        cli_command=CLICommandConfig(
            
            success=(
                "\nActive sessions for {user_identity}:\n"
                "{result}"
            ),
            error="✗ User not found: {user_identity}"
        )
    )
    async def list_sessions(self, user_identity: Identity) -> Optional[list]:
        """List all active sessions for a user."""
        from winterforge.frags.registries.user_registry import UserRegistry

        # Load user
        users = UserRegistry()
        user_frag = await users.get(user_identity)

        if not user_frag:
            return None

        # Get active sessions
        user_registry = await self.for_user(user_frag.id)
        active_registry = await user_registry.active_only()
        user_sessions = await active_registry.all()

        return user_sessions
