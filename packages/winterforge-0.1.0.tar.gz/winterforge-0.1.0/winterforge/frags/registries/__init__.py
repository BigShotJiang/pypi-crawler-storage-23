"""Base registry and specialized registries."""

from winterforge.frags.registries.frag_registry import FragRegistry, Identity

__all__ = ['FragRegistry', 'Identity']
