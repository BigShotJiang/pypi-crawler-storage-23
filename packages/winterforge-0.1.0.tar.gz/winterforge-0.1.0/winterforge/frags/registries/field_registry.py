"""FieldRegistry - specialized registry for field definition Frags.

Provides access to field definitions stored as Frags. Fields define
schema for other Frags (name, type, validation, defaults).
"""

from typing import Optional, List, Type, Any

from winterforge.frags.registries.frag_registry import FragRegistry
from winterforge.frags import Frag
from winterforge.frags.traits.persistable import get_storage
from winterforge.plugins.decorators import cli_command, root


@root('field')
class FieldRegistry(FragRegistry):
    """
    Registry for field definition Frags.

    Field definitions are Frags with affinity=['field'] that define
    schema for other Frags. Each field specifies name, type, validation,
    and defaults.

    Example:
        fields = FieldRegistry()

        # Get field by name
        host_field = await fields.get_by_name('database_host')

        # Create new field
        field = Frag(
            affinities=['field'],
            traits=['fieldable', 'titled', 'typed', 'persistable']
        )
        field.set_title('port').set_type(int).set_default(5432)
        await field.save()

        # Query fields by type
        string_fields = await fields.filter_by_type(str)
    """

    def __init__(self):
        """Initialize FieldRegistry for field affinity."""
        super().__init__(
            composition={
                'affinities': ['field'],
                'traits': ['fieldable', 'titled', 'typed', 'persistable']
            }
        )

    async def get_by_name(self, name: str) -> Optional[Frag]:
        """
        Get field definition by name (title).

        Args:
            name: Field name

        Returns:
            Field Frag or None if not found

        Example:
            fields = FieldRegistry()
            host = await fields.get_by_name('database_host')
        """
        # Query by title (field name is stored in title)
        storage = get_storage()
        if not storage:
            return None

        try:
            results = await storage.query()\
                .affinity('field')\
                .condition('title', name)\
                .execute()
            return results[0] if results else None
        except Exception:
            # Schema might not exist yet, fall back to memory filter
            all_fields = await storage.query().affinity('field').execute()
            for field in all_fields:
                if hasattr(field, 'title') and field.title == name:
                    return field
            return None

    async def filter_by_type(self, field_type: Type) -> List[Frag]:
        """
        Get all fields of a specific type.

        Args:
            field_type: Python type (str, int, bool, etc.)

        Returns:
            List of field Frags with matching type

        Example:
            fields = FieldRegistry()
            string_fields = await fields.filter_by_type(str)
        """
        all_fields = await self.all()
        type_name = field_type.__name__

        return [
            field for field in all_fields
            if hasattr(field, 'get_type') and field.get_type().__name__ == type_name
        ]

    async def load_many(self, ids: List[int]) -> List[Frag]:
        """
        Batch load field definitions by ID.

        Args:
            ids: List of field Frag IDs

        Returns:
            List of field Frags

        Example:
            fields = FieldRegistry()
            field_list = await fields.load_many([1, 2, 3])
        """
        storage = get_storage()
        if not storage:
            return []

        # Query for all IDs
        all_fields = []
        for frag_id in ids:
            field = await storage.get(frag_id)
            if field:
                all_fields.append(field)

        return all_fields

    async def ensure_field(
        self,
        slug: str,
        field_type: Type,
        default: Any = None,
        required: bool = False,
        prompt: str = None,
        validators: list = None,
        help_text: str = None
    ) -> Frag:
        """
        Ensure a field definition exists, creating it if necessary.

        If a field with the given slug exists, returns it.
        Otherwise creates a new field definition with the specified parameters.

        Args:
            slug: Unique field identifier
            field_type: Python type (str, int, bool, etc.)
            default: Default value for the field
            required: Whether the field is required
            prompt: Prompt text for interactive input
            validators: List of validator IDs to apply
            help_text: Help text describing the field

        Returns:
            Field definition Frag

        Example:
            fields = FieldRegistry()
            email_field = await fields.ensure_field(
                slug='email',
                field_type=str,
                required=True,
                prompt='Email address',
                validators=['required', 'email'],
                help_text='Valid email for account'
            )
        """
        # Try to get existing field by slug
        storage = get_storage()
        if storage:
            try:
                results = await storage.query()\
                    .affinity('field')\
                    .condition('slug', slug)\
                    .execute()
                if results:
                    return results[0]
            except Exception:
                # Schema might not exist yet, fall back to memory filter
                all_fields = await storage.query().affinity('field').execute()
                for field in all_fields:
                    if hasattr(field, 'slug') and field.slug == slug:
                        return field

        # Field doesn't exist, create it
        field = Frag(
            affinities=['field'],
            traits=['fieldable', 'titled', 'typed', 'sluggable', 'persistable']
        )

        field.set_slug(slug)
        field.set_title(slug)
        field.set_type(field_type)

        if default is not None:
            field.set_default(default)

        # Store metadata as aliases (flexible key-value storage)
        if prompt:
            field.set_alias('prompt', prompt)
        if validators:
            # Store as comma-separated string
            field.set_alias('validators', ','.join(validators))
        if help_text:
            field.set_alias('help-text', help_text)
        if required:
            field.set_alias('required', 'true')

        # Save to storage if available
        storage = get_storage()
        if storage:
            await field.save()

        return field
