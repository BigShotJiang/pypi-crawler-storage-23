"""Core Frag class - composable data primitive."""

from __future__ import annotations

from typing import List, Dict, Any, Optional, TYPE_CHECKING
import itertools
import uuid as uuid_lib

if TYPE_CHECKING:
    from winterforge.plugins._protocols.storage import StorageBackend


class Frag:
    """
    Core Frag class with composition-based identity.

    Frags are composable data primitives - canvases for composition and data.
    They use composition instead of rigid types:
    - Global sequential IDs (no type prefixing)
    - Affinities: Categorical tags (what it IS)
    - Traits: Schema components mixed in dynamically (what it CAN DO)
    - Aliases: Flexible metadata storage (relation/reference string pairs)

    Properties provide read access, setters enable fluent interface for writes.

    Primitives (system-critical Frags like Affinity, Trait) extend
    PrimitiveFrag which provides a primitive_id field.

    Examples:
        # Basic Frag (empty canvas)
        frag = Frag()

        # Frag with composition
        frag = Frag(
            affinities=['article', 'published'],
            traits=['titled', 'timestamped'],
            aliases={'publication_id': '345', 'category': 'science'}
        )

        # Fluent interface for composition
        frag = Frag()
        frag.set_affinities(['article']).add_affinity('featured')
        frag.set_alias('external_id', 'ext-12345')

        # Read via properties
        frag_id = frag.id
        categories = frag.affinities
        external_id = frag.get_alias('external_id')
        if frag.has_affinity('published'):
            print("Published!")

        # System primitives extend PrimitiveFrag
        from winterforge.frags.primitives import PrimitiveFrag
        class Affinity(PrimitiveFrag):
            def __init__(self):
                super().__init__(primitive_id='affinity', ...)
    """

    # Global ID counter (simple sequential IDs)
    _id_counter = itertools.count(1)

    def __init__(
        self,
        affinities: Optional[List[str]] = None,
        traits: Optional[List[str]] = None,
        aliases: Optional[Dict[str, str]] = None
    ) -> None:
        """
        Initializes a new Frag.

        Args:
            affinities: Categories/types (e.g., ['user', 'content'])
            traits: Schema/capabilities (e.g., ['titled', 'persistable'])
            aliases: Relation/reference pairs (e.g., {'publication_id': '345'})
        """
        # Private attributes for encapsulation
        self._id: int = next(Frag._id_counter)
        self._uuid: str = str(uuid_lib.uuid4())  # Always generated
        self._affinities: List[str] = []
        self._traits: List[str] = []
        self._aliases: Dict[str, str] = {}
        self._composed_traits: set = set()  # Track applied traits

        # Validate traits
        if traits is not None:
            if not isinstance(traits, list):
                raise ValueError("Traits must be a list")
            if not all(isinstance(t, str) for t in traits):
                raise ValueError("All traits must be strings")
            self._traits = traits.copy()

        # Initialize affinities and aliases via setter methods
        if affinities:
            self.set_affinities(affinities)
        if aliases:
            self.set_aliases(aliases)

        # Apply traits with recursive dependency resolution
        self._apply_traits()

        # Initialize traits (if they have _initialize method)
        self._initialize_traits()

    # -------------------------------------------------------------------------
    # ID property (read-only after creation)
    # -------------------------------------------------------------------------

    @property
    def id(self) -> int:
        """
        Gets the Frag ID (property accessor).

        Returns:
            int: The global Frag ID.
        """
        return self._id

    # Internal method for storage backends to override ID on load
    def _set_id(self, frag_id: int) -> Frag:
        """
        Sets the Frag ID (internal use only).

        This is used by storage backends when loading existing Frags.
        Should not be called by application code.

        Args:
            frag_id: The Frag ID from storage.

        Returns:
            self: Returns the Frag for method chaining.
        """
        self._id = frag_id
        return self

    # -------------------------------------------------------------------------
    # UUID property (read-only, immutable)
    # -------------------------------------------------------------------------

    @property
    def uuid(self) -> str:
        """
        Gets the Frag UUID (property accessor).

        UUID is auto-generated on instantiation using uuid4().
        Immutable once set - cannot be changed.

        UUIDs enable:
        - Cross-system Frag references (portable identity)
        - Export/import with preserved identity
        - Globally unique identity (beyond database scope)

        Returns:
            str: The UUID string (e.g., '123e4567-e89b-12d3-a456-426614174000')

        Example:
            frag = Frag(traits=['titled'])
            print(frag.uuid)
            # '123e4567-e89b-12d3-a456-426614174000'
        """
        return self._uuid

    @uuid.setter
    def uuid(self, value):
        """
        Prevent UUID mutation.

        UUIDs are immutable like Frag IDs. Once set during
        instantiation, they cannot be changed.

        Raises:
            AttributeError: Always (UUID is immutable)

        Example:
            frag.uuid = 'new-uuid'
            # AttributeError: UUID is immutable...
        """
        raise AttributeError(
            "UUID is immutable. "
            "UUIDs are auto-generated on instantiation and cannot be changed."
        )

    # Internal method for storage backends to restore UUID on load
    def _set_uuid(self, uuid: str) -> Frag:
        """
        Sets the Frag UUID (internal use only).

        This is used by storage backends when loading existing Frags
        to restore the original UUID. Should not be called by application code.

        Args:
            uuid: The UUID from storage.

        Returns:
            self: Returns the Frag for method chaining.
        """
        self._uuid = uuid
        return self

    # -------------------------------------------------------------------------
    # Affinity methods and properties
    # -------------------------------------------------------------------------

    @property
    def affinities(self) -> List[str]:
        """
        Gets the affinities (readonly property).

        Returns:
            List[str]: Categorical tags (copy of internal list).
        """
        return self._affinities.copy()

    def set_affinities(self, affinities: List[str]) -> Frag:
        """
        Sets the affinities (fluent setter).

        Args:
            affinities: Categorical tags.

        Returns:
            self: Returns the Frag for method chaining.

        Raises:
            ValueError: If affinities is not a list or contains non-strings.
        """
        if not isinstance(affinities, list):
            raise ValueError("Affinities must be a list")
        if not all(isinstance(a, str) for a in affinities):
            raise ValueError("All affinities must be strings")

        self._affinities = affinities.copy()
        return self

    def add_affinity(self, affinity: str) -> Frag:
        """
        Adds an affinity tag.

        Args:
            affinity: Categorical tag to add.

        Returns:
            self: Returns the Frag for method chaining.

        Raises:
            ValueError: If affinity is not a string.
        """
        if not isinstance(affinity, str):
            raise ValueError("Affinity must be a string")

        if not self.has_affinity(affinity):
            self._affinities.append(affinity)
        return self

    def remove_affinity(self, affinity: str) -> Frag:
        """
        Removes an affinity tag.

        Args:
            affinity: Categorical tag to remove.

        Returns:
            self: Returns the Frag for method chaining.
        """
        if self.has_affinity(affinity):
            self._affinities.remove(affinity)
        return self

    def has_affinity(self, affinity: str) -> bool:
        """
        Checks whether the Frag has the given affinity.

        Args:
            affinity: Categorical tag to check.

        Returns:
            bool: True if affinity exists, False otherwise.
        """
        return affinity in self._affinities

    # -------------------------------------------------------------------------
    # Trait methods and properties
    # -------------------------------------------------------------------------

    @property
    def traits(self) -> List[str]:
        """
        Gets the traits (readonly property).

        Traits are immutable after initialization - they can only be declared
        during Frag creation. To change a Frag's capabilities, create a new
        Frag with different traits.

        Rationale: Traits define schema (fields/methods). Runtime changes
        would leave orphaned fields, pollute the class namespace, and break
        type safety guarantees.

        Returns:
            List[str]: Schema components (copy of internal list).
        """
        return self._traits.copy()

    def has_trait(self, trait: str) -> bool:
        """
        Checks whether the Frag has the given trait.

        Args:
            trait: Trait ID to check.

        Returns:
            bool: True if trait exists, False otherwise.
        """
        return trait in self._traits

    @property
    def is_orphaned(self) -> bool:
        """
        Check if Frag has missing traits.

        A Frag is "orphaned" when it declares traits that no longer exist
        in the system (e.g., extension uninstalled). Orphaned Frags:
        - Cannot load trait fields/methods (trait code missing)
        - Still exist in storage (data preserved)
        - Can be exported for recovery

        Returns:
            bool: True if any declared traits don't exist

        Example:
            # Extension uninstalled, trait code gone
            frag = Frag(affinities=['post'], traits=['blog_post'])
            if frag.is_orphaned:
                print("Frag has missing traits!")
                # Export for recovery
                data = frag.to_dict()
        """
        from winterforge.plugins import FragTraitManager

        for trait_id in self._traits:
            if not FragTraitManager.has(trait_id):
                return True

        return False

    # -------------------------------------------------------------------------
    # Alias methods and properties
    # -------------------------------------------------------------------------

    @property
    def aliases(self) -> Dict[str, str]:
        """
        Gets the aliases (readonly property).

        Aliases are flexible metadata storage - relation/reference string pairs
        for external identifiers, categorical data, and arbitrary metadata.

        Returns:
            Dict[str, str]: Relation/reference pairs (copy of internal dict).
        """
        return self._aliases.copy()

    def set_aliases(self, aliases: Dict[str, str]) -> Frag:
        """
        Sets the aliases (fluent setter).

        Args:
            aliases: Relation/reference pairs.

        Returns:
            self: Returns the Frag for method chaining.

        Raises:
            ValueError: If aliases is not a dictionary.
        """
        if not isinstance(aliases, dict):
            raise ValueError("Aliases must be a dictionary")

        self._aliases = aliases.copy()
        return self

    def get_alias(self, relation: str) -> Optional[str]:
        """
        Gets the alias reference value for a relation.

        Args:
            relation: Relation name.

        Returns:
            Optional[str]: Reference value or None if not found.
        """
        return self._aliases.get(relation)

    def set_alias(self, relation: str, reference: str) -> Frag:
        """
        Sets an alias (relation/reference pair).

        Args:
            relation: Relation name.
            reference: Reference value (arbitrary identifier).

        Returns:
            self: Returns the Frag for method chaining.
        """
        self._aliases[relation] = reference
        return self

    def remove_alias(self, relation: str) -> Frag:
        """
        Removes an alias by relation name.

        Args:
            relation: Relation name to remove.

        Returns:
            self: Returns the Frag for method chaining.
        """
        if self.has_relation(relation):
            del self._aliases[relation]
        return self

    def has_relation(self, relation: str) -> bool:
        """
        Checks whether the Frag has the given relation.

        Args:
            relation: Relation name to check.

        Returns:
            bool: True if relation exists, False otherwise.
        """
        return relation in self._aliases

    # -------------------------------------------------------------------------
    # Composition property
    # -------------------------------------------------------------------------

    @property
    def composition(self) -> dict:
        """
        Get Frag composition as dictionary.

        Returns composition dict suitable for Frag(**composition) or FragRegistry(composition).
        Always includes affinities, traits, and aliases (even if empty).

        Returns:
            dict: Composition dictionary with affinities, traits, and aliases

        Example:
            frag = Frag(affinities=['post'], traits=['titled'])
            comp = frag.composition
            # {'affinities': ['post'], 'traits': ['titled'], 'aliases': {}}

            # Create identical Frag from composition
            frag2 = Frag(**comp)
        """
        return {
            'affinities': list(self.affinities),
            'traits': list(self.traits),
            'aliases': dict(self.aliases)
        }

    def get_registry(self) -> 'FragRegistry':
        """
        Get FragRegistry for this Frag's composition.

        Returns registry matching this Frag's affinities and traits.
        Works for all Frags regardless of how they were created.

        Returns:
            FragRegistry: Registry for this composition pattern

        Example:
            frag = Frag(affinities=['post'], traits=['titled'])
            registry = frag.get_registry()
            similar_frags = await registry.all()
        """
        from winterforge.frags.registries.frag_registry import FragRegistry
        return FragRegistry(self.composition)

    def clone(self) -> 'Frag':
        """
        Create complete clone of this Frag with new ID.

        Clones all composition (affinities, traits, aliases) and field values.
        The only difference is the ID (new sequential ID assigned).

        Returns:
            Frag: New Frag with identical composition and fields

        Example:
            original = Frag(affinities=['post'], traits=['titled', 'persistable'])
            original.set_title("Original Post")
            await original.save()

            copy = original.clone()
            # copy has different ID but identical everything else
            await copy.save()  # Saves as new Frag
        """
        # Create new Frag with same composition
        cloned = Frag(
            affinities=list(self.affinities),
            traits=list(self.traits),
            aliases=dict(self.aliases) if self.aliases else None
        )

        # Copy all field values from traits
        from winterforge.plugins import FragTraitManager

        for trait_id in self.traits:
            if not FragTraitManager.has(trait_id):
                continue

            trait_fields = FragTraitManager.get_trait_fields(trait_id)
            for field_name, field_info in trait_fields.items():
                if hasattr(self, field_name):
                    value = field_info.get(self)

                    # Deep copy mutable values
                    if isinstance(value, list):
                        value_copy = value.copy()
                    elif isinstance(value, dict):
                        value_copy = value.copy()
                    else:
                        value_copy = value

                    # Set value using field_info if writable
                    if field_info.writable:
                        field_info.set(cloned, value_copy)

        return cloned

    # -------------------------------------------------------------------------
    # Serialization
    # -------------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
        Serialize Frag to dictionary (includes UUID).

        Includes all composition (affinities, traits, aliases) and
        field values from traits. Used for export, archiving, and
        data transport.

        Returns:
            dict: Complete Frag data including UUID

        Example:
            frag = Frag(affinities=['post'], traits=['titled'])
            frag.set_title('Hello World')

            data = frag.to_dict()
            # {
            #     'id': 42,
            #     'uuid': '123e4567-...',
            #     'affinities': ['post'],
            #     'traits': ['titled'],
            #     'aliases': {},
            #     'title': 'Hello World'
            # }

            # Archive to file
            with open('frag_backup.json', 'w') as f:
                json.dump(data, f)
        """
        data = {
            'id': self.id,
            'uuid': self._uuid,
            'affinities': list(self.affinities),
            'traits': list(self.traits),
            'aliases': dict(self.aliases)
        }

        # Include trait fields
        from winterforge.plugins import FragTraitManager

        for trait_id in self.traits:
            if not FragTraitManager.has(trait_id):
                continue

            trait_fields = FragTraitManager.get_trait_fields(trait_id)
            for field_name, field_info in trait_fields.items():
                if hasattr(self, field_name):
                    data[field_name] = field_info.get(self)

        return data

    @classmethod
    def from_dict(cls, data: dict) -> 'Frag':
        """
        Deserialize Frag from dictionary (restores UUID).

        Creates Frag from serialized data, restoring original UUID
        (doesn't generate new one). Used for import, archiving, and
        data transport.

        Args:
            data: Serialized Frag data (from to_dict())

        Returns:
            Frag: Frag instance with restored UUID and fields

        Example:
            # Load from archive
            with open('frag_backup.json') as f:
                data = json.load(f)

            restored = Frag.from_dict(data)
            # UUID preserved from archive
            print(restored.uuid)
            # '123e4567-...' (same as original)

            print(restored.title)
            # 'Hello World' (fields restored)
        """
        # Create Frag with composition
        frag = cls(
            affinities=data.get('affinities', []),
            traits=data.get('traits', []),
            aliases=data.get('aliases', {})
        )

        # Restore UUID (bypass setter by setting private attribute)
        if 'uuid' in data:
            frag._uuid = data['uuid']

        # Restore ID if present (bypass setter)
        if 'id' in data:
            frag._id = data['id']

        # Restore trait fields
        from winterforge.plugins import FragTraitManager

        for trait_id in frag.traits:
            if not FragTraitManager.has(trait_id):
                continue

            trait_fields = FragTraitManager.get_trait_fields(trait_id)
            for field_name, field_info in trait_fields.items():
                if field_name in data:
                    if field_info.writable:
                        # Writable direct attributes
                        field_info.set(frag, data[field_name])
                    else:
                        # Read-only Schema properties - use setter method
                        setter_name = f'set_{field_name}'
                        if hasattr(frag, setter_name):
                            setter = getattr(frag, setter_name)
                            setter(data[field_name])

        return frag

    # -------------------------------------------------------------------------
    # Trait field initialization
    # -------------------------------------------------------------------------

    def _apply_traits(self) -> None:
        """
        Apply requested traits with recursive dependency resolution.

        Each trait ensures its dependencies are applied first.
        Already-applied traits are skipped (idempotent).
        Order and duplicates don't matter.
        """
        if not self._traits:
            return

        for trait_id in self._traits:
            self._apply_trait(trait_id)

    def _apply_trait(
        self,
        trait_id: str,
        _dependency_stack: Optional[set] = None
    ) -> None:
        """
        Apply a single trait with recursive dependency resolution.

        Depth-first traversal with cycle detection:
        1. Check if already applied (skip if yes)
        2. Detect circular dependencies
        3. Recursively apply dependencies first
        4. Apply this trait
        5. Mark as applied

        Args:
            trait_id: Trait identifier to apply
            _dependency_stack: Internal stack for cycle detection

        Raises:
            ValueError: If circular dependency detected
            KeyError: If trait not found
        """
        # Initialize dependency stack for root call
        if _dependency_stack is None:
            _dependency_stack = set()

        # Idempotent: skip if already applied
        if trait_id in self._composed_traits:
            return

        # Detect circular dependencies
        if trait_id in _dependency_stack:
            chain = ' -> '.join(_dependency_stack) + f' -> {trait_id}'
            raise ValueError(
                f"Circular trait dependency detected: {chain}"
            )

        from winterforge.plugins import FragTraitManager
        import types

        # Add to dependency stack for cycle detection
        _dependency_stack.add(trait_id)

        try:
            # Get trait metadata and dependencies
            metadata = FragTraitManager.get_metadata(trait_id)
            requires = metadata.get('requires', [])

            # Recursively apply dependencies first (depth-first)
            for dep_trait_id in requires:
                self._apply_trait(dep_trait_id, _dependency_stack)

            # Now apply this trait (dependencies guaranteed applied)
            # Get fields defined by this trait
            trait_fields = FragTraitManager.get_trait_fields(trait_id)

            # Add each field to this Frag instance
            for field_name, field_info in trait_fields.items():
                # Skip read-only fields (Schema properties)
                if not field_info.writable:
                    continue

                # Copy the value so each Frag instance is independent
                field_value = field_info.default_value
                if isinstance(field_value, (list, dict)):
                    field_value = field_value.copy()
                field_info.set(self, field_value)

            # Get properties from the trait
            trait_properties = FragTraitManager.get_trait_properties(
                trait_id
            )

            # Add properties to Frag class (shared across instances)
            for property_name, property_obj in trait_properties.items():
                if not hasattr(Frag, property_name):
                    setattr(Frag, property_name, property_obj)

            # Get methods from the trait
            trait_methods = FragTraitManager.get_trait_methods(trait_id)

            # Bind methods to this instance or class
            for method_name, method in trait_methods.items():
                # Special methods (__str__, __repr__, etc.) must be on class
                if method_name.startswith('__') and method_name.endswith('__'):
                    # Set on class if not already defined
                    if not hasattr(Frag, method_name) or method_name in ('__str__', '__repr__'):
                        setattr(Frag, method_name, method)
                else:
                    # Regular methods: bind to instance
                    bound_method = types.MethodType(method, self)
                    setattr(self, method_name, bound_method)

            # Mark trait as applied
            self._composed_traits.add(trait_id)

        finally:
            # Remove from dependency stack after processing
            _dependency_stack.discard(trait_id)

    def _initialize_traits(self) -> None:
        """
        Initialize traits after fields and methods are applied.

        Calls _initialize() on each trait that implements it.
        Enables traits to perform setup logic that requires all traits to be mixed in.
        """
        if not self._traits:
            return

        for trait_id in self._traits:
            # Check if trait has _initialize method
            if hasattr(self, '_initialize'):
                # Call it (it's already bound to this instance)
                self._initialize()  # type: ignore
                break  # Only call once (all traits share the method)

    # -------------------------------------------------------------------------
    # Representation
    # -------------------------------------------------------------------------

    def __repr__(self) -> str:
        """
        Returns string representation of Frag.

        Returns:
            str: Human-readable representation.
        """
        parts = [f"id={self._id}", f"uuid={self._uuid[:8]}..."]

        if self._affinities:
            parts.append(f"affinities={self._affinities}")

        if self._traits:
            parts.append(f"traits={self._traits}")

        if self._aliases:
            alias_str = ", ".join(f"{k}={v}" for k, v in self._aliases.items())
            parts.append(f"aliases={{{alias_str}}}")

        return f"Frag({', '.join(parts)})"
