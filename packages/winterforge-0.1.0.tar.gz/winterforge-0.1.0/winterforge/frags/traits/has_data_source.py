"""has_data_source trait - Data import source configuration."""

from typing import TYPE_CHECKING, List, Any

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.plugins.repository import PluginRepository


class HasDataSourceTrait:
    """
    Data import source trait.

    Provides API for holding pre-configured import plugin instances
    and accessing them as ordered Repository for execution.

    Frags with this trait serve as blackbox vessels containing:
    - Import plugin instances (already configured)
    - Any additional import-specific configuration

    Fields:
        importers: List of pre-configured import plugin instances

    Methods:
        get_importers() - Returns Repository of configured importers

    Example:
        # Compose input Frag with pre-configured importers
        input = Frag(affinities=['data_source'], traits=['has_data_source'])
        input.importers = [
            YamlFileImporter(path='/backup/export.yaml'),
            S3Importer(bucket='backups', key='export.yaml')  # Fallback
        ]

        # Import from first available source
        await transport.load_raw(input=input)
    """

    @property
    def importers(self) -> List[Any]:
        """Get list of configured import plugin instances."""
        return getattr(self, '_importers', [])

    def set_importers(self, importers: List[Any]) -> 'Frag':
        """
        Set import plugin instances.

        Args:
            importers: List of pre-configured importer instances

        Returns:
            Self for chaining
        """
        self._importers = importers
        return self

    def add_importer(self, importer: Any) -> 'Frag':
        """
        Add import plugin instance to stack.

        Args:
            importer: Pre-configured importer instance

        Returns:
            Self for chaining
        """
        if not hasattr(self, '_importers'):
            self._importers = []
        self._importers.append(importer)
        return self

    def get_importers(self) -> 'PluginRepository':
        """
        Get importers as ordered Repository.

        Returns Repository of pre-configured import plugin instances
        ready for execution via resolve/resolve_all.

        Returns:
            PluginRepository containing configured importers
        """
        from winterforge.plugins.repository import PluginRepository

        # Build repository from configured importers
        plugins = {}
        order = []

        for idx, importer in enumerate(self.importers):
            plugin_id = f"importer_{idx}"
            plugins[plugin_id] = importer
            order.append(plugin_id)

        return PluginRepository(plugins, order)


# Register trait
from winterforge.plugins import FragTraitManager

FragTraitManager.register(
    'has_data_source',
    HasDataSourceTrait,
    {
        'fields': {
            'importers': {
                'type': 'JSONB',
                'default': [],
                'description': 'List of pre-configured importer instances'
            }
        }
    }
)
