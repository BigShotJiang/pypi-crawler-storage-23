"""HasRoles trait - Trait-based access control (TBAC)."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.frags.registries.frag_registry import Identity


@frag_trait(requires=['persistable'])
@root('has-roles')
class HasRolesTrait:
    """
    Trait-based access control (TBAC).

    ANY Frag can have roles - not just users. Enables Linux-style
    permissions where groups, channels, resources can all have roles.

    Fields:
        role_ids: List[int] - References to Role Frags

    Example:
        # User with roles
        user = Frag(affinities=['user'], traits=['has_roles'])
        user.add(admin_role)
        user.add(editor_role)

        if await user.has_role('admin'):
            print("Has admin role!")

        if await user.has_permission('user.delete'):
            print("Can delete users!")

        # Channel with roles (enables group-based permissions)
        channel = Frag(affinities=['channel'], traits=['has_roles'])
        channel.add(moderators_role)

        # Any Frag can have roles
        resource = Frag(affinities=['resource'], traits=['has_roles'])
        resource.add(owners_role)
    """

    # Private attributes
    _role_ids: List[int] = []

    # Role IDs (stored as list)
    @property
    def role_ids(self) -> List[int]:
        """Get list of assigned role IDs."""
        return self._role_ids

    def set_roles(self, role_ids: List[int]) -> Frag:
        """
        Replace all roles.

        Args:
            role_ids: List of Role Frag IDs

        Returns:
            Self for fluent chaining
        """
        self._role_ids = list(role_ids)  # type: ignore
        return self  # type: ignore

    def add_role(self, role: Identity | int) -> Frag:
        """
        Add role (idempotent).

        Args:
            role: Role Frag or Role ID

        Returns:
            Self for fluent chaining

        Example:
            user.add_role(admin_role)
            user.add_role(123)  # By ID
        """
        role_id = role if isinstance(role, int) else role.id
        role_ids = list(self._role_ids)
        if role_id not in role_ids:
            role_ids.append(role_id)
            self._role_ids = role_ids  # type: ignore
        return self  # type: ignore

    def remove_role(self, role: Identity | int) -> Frag:
        """
        Remove role (idempotent).

        Args:
            role: Role Frag or Role ID

        Returns:
            Self for fluent chaining

        Example:
            user.remove_role(admin_role)
            user.remove_role(123)  # By ID
        """
        role_id = role if isinstance(role, int) else role.id
        role_ids = list(self._role_ids)
        if role_id in role_ids:
            role_ids.remove(role_id)
            self._role_ids = role_ids  # type: ignore
        return self  # type: ignore

    # Async property pattern (Python supports this)
    @property
    async def roles(self) -> List[Identity]:
        """
        Get actual Role Frags (async property).

        Usage:
            roles = await user.roles

        Returns:
            List of Role Frags
        """
        if not self._role_ids:
            return []

        # Load Role Frags by IDs
        try:
            from winterforge.frags.registries.role_registry import (
                RoleRegistry
            )
            from winterforge.frags.manifest import Manifest

            registry = RoleRegistry()

            # Use reducer to collect roles
            async def load_role(acc: List[Identity], role_id: int):
                role = await registry.get(role_id)
                if role:
                    acc.append(role)
                return acc

            # Load all roles using reducer pattern
            roles = []
            for role_id in self._role_ids:
                roles = await load_role(roles, role_id)

            return roles
        except ImportError:
            # RoleRegistry not yet implemented
            return []

    @property
    async def permissions(self) -> List[Identity]:
        """
        Get all unique Permission Frags from all roles (async property).

        Usage:
            perms = await user.permissions

        Returns:
            List of Permission Frags (deduplicated)
        """
        from winterforge.frags.manifest import Manifest

        roles = await self.roles

        # Use reducer to merge permissions from all roles
        async def merge_permissions(
            acc: dict,
            role: Identity
        ) -> dict:
            # Check if role has permissions method by checking trait
            if role.has_trait('permissioned'):
                perms = await role.permissions
                for perm in perms:
                    acc[perm.id] = perm  # Deduplicate by ID
            return acc

        all_perms = {}
        for role in roles:
            all_perms = await merge_permissions(all_perms, role)

        return list(all_perms.values())

    # Role checking
    async def has_role(self, role_title: str) -> bool:
        """
        Check if Frag has role by title.

        Requires roles to have 'titled' trait.

        Args:
            role_title: Role title (e.g., 'admin')

        Returns:
            True if has role, False otherwise

        Example:
            if await user.has_role('admin'):
                print("User is admin")
        """
        roles = await self.roles
        return any(
            hasattr(role, 'title') and role.title == role_title
            for role in roles
        )

    # Permission checking (merges all permissions from all roles)
    async def has_permission(self, perm_title: str) -> bool:
        """
        Check if Frag has permission.

        Strategy: Merge all permissions from all roles, then check.

        Requires roles with 'permissioned' trait and permissions
        with 'titled'.

        Args:
            perm_title: Permission title (e.g., 'user.delete')

        Returns:
            True if has permission, False otherwise

        Example:
            if await user.has_permission('user.delete'):
                print("User can delete users")

            if await channel.has_permission('channel.moderate'):
                print("Channel can be moderated")
        """
        # Get all permissions using the property
        all_permissions = await self.permissions

        # Check if requested permission is in merged set
        return any(
            hasattr(perm, 'title') and perm.title == perm_title
            for perm in all_permissions
        )
