"""has_result trait - Standardized operation result."""

from typing import TYPE_CHECKING, Optional, Any

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class HasResultTrait:
    """
    Operation result trait.

    Provides standardized result structure for any operation
    (CLI, import/export, API calls, async tasks, etc.).

    Pattern: success flag, human-readable message, structured data.

    Fields:
        success: bool - Whether operation succeeded
        message: str - Human-readable result message
        data: Optional[dict] - Additional structured result data

    Example:
        # Export operation result
        result = Frag(traits=['has_result'])
        result.set_success(True)
        result.set_message("✓ Exported 247 Frags to 2 targets")
        result.set_data({
            'exported': 247,
            'targets': 2,
            'files': ['/backup.yaml', 's3://bucket/backup.yaml']
        })

        # Import operation result
        result = Frag(traits=['has_result'])
        result.set_success(False)
        result.set_message("No matching application")
        result.set_data({
            'imported': 0,
            'error': 'application_mismatch'
        })
    """

    @property
    def success(self) -> bool:
        """Get success status."""
        return getattr(self, '_success', False)

    def set_success(self, success: bool) -> 'Frag':
        """Set success status."""
        self._success = success
        return self

    @property
    def message(self) -> str:
        """Get result message."""
        return getattr(self, '_message', '')

    def set_message(self, message: str) -> 'Frag':
        """Set result message."""
        self._message = message
        return self

    @property
    def data(self) -> Optional[dict]:
        """Get additional structured data."""
        return getattr(self, '_data', None)

    def set_data(self, data: dict) -> 'Frag':
        """Set additional structured data."""
        self._data = data
        return self

    def __str__(self) -> str:
        """Format for output."""
        return self.message


# Register trait
from winterforge.plugins import FragTraitManager

FragTraitManager.register(
    'has_result',
    HasResultTrait,
    {
        'fields': {
            'success': {
                'type': 'BOOLEAN',
                'default': False,
                'description': 'Whether operation succeeded'
            },
            'message': {
                'type': 'TEXT',
                'default': '',
                'description': 'Human-readable result message'
            },
            'data': {
                'type': 'JSONB',
                'description': 'Additional structured result data'
            }
        }
    }
)
