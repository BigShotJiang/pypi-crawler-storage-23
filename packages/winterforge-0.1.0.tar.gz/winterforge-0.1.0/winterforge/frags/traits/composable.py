"""Composable trait - enables Frags to compose with other Frags.

Provides composition over inheritance by allowing Frags to merge field
definitions, affinities, and traits from other Frags.

Example:
    # Profile Frag defines fields
    profile = Frag(
        affinities=['install-profile'],
        traits=['composable', 'fieldable']
    )
    profile.add_field_reference('username', required=True)
    profile.add_field_reference('email', required=True)

    # User Frag composes from profile
    user = Frag(
        affinities=['user'],
        traits=['composable', 'fieldable']
    )
    user.compose(profile)
    # User now has username and email field references
"""

from typing import Union, List
from winterforge.plugins.decorators import frag_trait, root


@frag_trait(requires=['fieldable'])
@root('composable')
class ComposableTrait:
    """
    Trait enabling Frag composition.

    Allows a Frag to compose (merge) properties from other Frags:
    - Field references (via fieldable trait)
    - Affinities
    - Traits
    - Field values

    Composition is additive and non-destructive. The composing Frag
    retains its own identity while incorporating properties from
    composed Frags.
    """

    def compose(
        self,
        *frags: Union['Frag', List['Frag']],
        include_affinities: bool = False,
        include_traits: bool = False,
        include_field_refs: bool = True,
        include_field_values: bool = False
    ) -> 'Frag':
        """
        Compose this Frag with other Frag(s).

        Merges properties from provided Frags into this Frag.
        By default, only field references are composed. Use flags
        to include other properties.

        Args:
            *frags: One or more Frags to compose from
            include_affinities: Merge affinities from composed Frags
            include_traits: Merge traits from composed Frags
            include_field_refs: Merge field references (default: True)
            include_field_values: Merge field values from composed Frags

        Returns:
            Self for method chaining

        Example:
            # Compose from single Frag
            user.compose(profile)

            # Compose from multiple Frags
            user.compose(profile, permissions, timestamps)

            # Compose with affinities and traits
            user.compose(
                profile,
                include_affinities=True,
                include_traits=True
            )

        Note:
            Composition is shallow - it copies references, not deep
            copies of Frag objects. Field references point to the
            same field definition Frags.
        """
        # Flatten frag arguments (handle both *frags and lists)
        all_frags = []
        for item in frags:
            if isinstance(item, list):
                all_frags.extend(item)
            else:
                all_frags.append(item)

        # Compose from each Frag
        for frag in all_frags:
            # Compose field references (copy IDs)
            if include_field_refs and hasattr(
                frag,
                'get_field_references'
            ):
                field_ref_ids = frag.get_field_references()
                if field_ref_ids and hasattr(self, '_field_refs'):
                    # Copy field reference IDs directly
                    for field_id in field_ref_ids:
                        if field_id not in self._field_refs:
                            self._field_refs.append(field_id)

                    # Also copy field definitions cache
                    if (
                        hasattr(frag, '_field_definitions')
                        and hasattr(self, '_field_definitions')
                    ):
                        for field_name, definition in frag._field_definitions.items():
                            if field_name not in self._field_definitions:
                                self._field_definitions[field_name] = definition

                    # Rebuild schema to include new fields
                    if hasattr(self, '_rebuild_schema_with_field_refs'):
                        self._rebuild_schema_with_field_refs()

            # Compose field values
            if include_field_values and hasattr(frag, 'values'):
                field_values = frag.values()
                for field_name, value in field_values.items():
                    # Set field value if not already set to non-default
                    if hasattr(self, 'set_value'):
                        # Don't overwrite existing non-empty values
                        try:
                            existing = self.value(field_name)
                        except AttributeError:
                            existing = None

                        # Only copy if target field is empty/default
                        # Empty means: None, empty string, empty list, etc.
                        is_empty = (
                            existing is None
                            or existing == ''
                            or existing == []
                            or existing == {}
                        )
                        if is_empty:
                            self.set_value(field_name, value)

            # Compose affinities
            if include_affinities and hasattr(frag, 'affinities'):
                # Add affinities that aren't already present
                if hasattr(self, 'add_affinity'):
                    for affinity in frag.affinities:
                        self.add_affinity(affinity)

            # Compose traits
            if include_traits and hasattr(frag, 'traits'):
                # Note: Traits are immutable after initialization,
                # so we can only check for conflicts, not add new traits
                # dynamically. This flag is mainly for documentation/
                # validation purposes.
                if hasattr(self, 'traits'):
                    # We can't actually add traits dynamically since they're
                    # mixed in at initialization. This is a no-op but kept
                    # for API consistency.
                    pass

        # Mark as changed if persistable
        if hasattr(self, '_changed'):
            self._changed = True

        return self

    def get_composed_fields(self) -> dict:
        """
        Get all field references with metadata.

        Returns dictionary mapping field slugs to their metadata from
        cached _field_definitions. For full metadata including prompts
        and validators, load the Field Frags from storage.

        Returns:
            Dict of {field_slug: field_metadata}

        Example:
            user.compose(profile)
            fields = user.get_composed_fields()
            # {'username': {'type': 'str', 'default': None, ...}}
        """
        if not hasattr(self, '_field_definitions'):
            return {}

        composed_fields = {}

        # Return cached field definitions
        for field_name, definition in self._field_definitions.items():
            composed_fields[field_name] = {
                'type': definition.get('type_name'),
                'default': definition.get('default'),
                # Note: prompt, validators, help_text require loading
                # the actual Field Frag from storage
            }

        return composed_fields

    async def prompt_composed_fields(
        self,
        field_names: list = None,
        interactive: bool = True
    ) -> dict:
        """
        Prompt for all composed field values.

        Convenience method that combines composition with prompting.
        Uses field metadata to generate prompts and validate input.

        Args:
            field_names: Specific fields to prompt for (None = all)
            interactive: Whether to prompt interactively

        Returns:
            Dict of {field_name: value}

        Example:
            user.compose(profile)
            values = await user.prompt_composed_fields()
            # Prompts for username, email based on profile fields

            # Set values on Frag
            for field_name, value in values.items():
                user.set_field_value(field_name, value)
        """
        from winterforge.frags.field_helpers import prompt_for_fields

        return await prompt_for_fields(
            self,
            field_names=field_names,
            interactive=interactive
        )
