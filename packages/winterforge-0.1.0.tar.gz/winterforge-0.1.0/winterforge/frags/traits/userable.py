"""Userable trait - Core user identity fields."""

from __future__ import annotations

from typing import TYPE_CHECKING
import re
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


# Validation patterns (module-level so they're accessible from bound methods)
_USERNAME_PATTERN = re.compile(r'^[a-zA-Z][a-zA-Z0-9_-]{2,29}$')
_EMAIL_PATTERN = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')


@frag_trait(requires=['persistable'])
@root('userable')
class UserableTrait:
    """
    Core user identity trait.

    Provides username and email management with validation and uniqueness checks.

    Fields:
        username: str - Unique username (3-30 chars, alphanumeric + _/-)
        email: str - Unique email address
        email_verified: bool - Email verification status

    Example:
        user = Frag(affinities=['user'], traits=['userable'])
        user.set_username('beau').set_email('beau@example.com')
        user.mark_email_verified()

        if user.has_username() and user.is_email_verified():
            print(f"{user.username} <{user.email}>")
    """

    # Private attributes
    _username: str = ""
    _email: str = ""
    _email_verified: bool = False

    # Username
    @property
    def username(self) -> str:
        """Get username."""
        return self._username

    def set_username(self, username: str) -> Frag:
        """
        Set username.

        Validates format (3-30 chars, alphanumeric + underscore/dash, starts with letter).
        Does NOT check uniqueness - that's enforced by PostgreSQL unique constraint.

        Args:
            username: Username string

        Returns:
            Self for fluent chaining

        Raises:
            ValueError: If username format is invalid
        """
        if not _USERNAME_PATTERN.match(username):
            raise ValueError(
                "Username must be 3-30 characters, start with a letter, "
                "and contain only letters, numbers, underscores, or dashes"
            )

        self._username = username  # type: ignore
        return self  # type: ignore

    def has_username(self) -> bool:
        """Check if username is set."""
        return bool(self._username)

    # Email
    @property
    def email(self) -> str:
        """Get email."""
        return self._email

    def set_email(self, email: str) -> Frag:
        """
        Set email.

        Validates format (basic RFC 5322 compliance).
        Does NOT check uniqueness - that's enforced by PostgreSQL unique constraint.

        Args:
            email: Email address

        Returns:
            Self for fluent chaining

        Raises:
            ValueError: If email format is invalid
        """
        if not _EMAIL_PATTERN.match(email):
            raise ValueError("Invalid email format")

        self._email = email  # type: ignore
        return self  # type: ignore

    def has_email(self) -> bool:
        """Check if email is set."""
        return bool(self._email)

    # Email verification
    @property
    def email_verified(self) -> bool:
        """Get email verification status."""
        return self._email_verified

    def mark_email_verified(self) -> Frag:
        """Mark email as verified."""
        self._email_verified = True  # type: ignore
        return self  # type: ignore

    def is_email_verified(self) -> bool:
        """Check if email is verified."""
        return self.email_verified
