"""Manifest trait - marker for Manifest Frags."""

from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root


@frag_trait()
@root('manifest')
class ManifestTrait:
    """
    Marker trait for Manifest Frags.

    Manifests are Frags that contain other Frags. They're ephemeral
    snapshots used for functional operations (map, walk, reduce, resolve).

    Manifests store their own composition (affinities/traits) but NOT
    subordinate Frag IDs. Saving a Manifest captures composition for
    reuse, not the snapshot itself.

    This trait is automatically added to all Manifest instances.
    """
    pass
