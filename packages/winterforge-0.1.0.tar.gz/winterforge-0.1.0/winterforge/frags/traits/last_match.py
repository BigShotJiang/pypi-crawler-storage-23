"""Last match tracking for collections."""

from typing import Any, Optional


class LastMatchTrait:
    """
    Track successful matches from resolve/resolve_all operations.

    Collections with this trait store the items that successfully
    matched and executed in the most recent resolution operation.

    Examples:
        # Single match (resolve)
        result = handlers.resolve(context)
        if handlers.last_match:
            print(f"Handled by: {handlers.last_match}")

        # Multiple matches (resolve_all)
        result = validators.resolve_all(context)
        succeeded = validators.last_match  # All that succeeded
        if succeeded:
            print(f"{len(succeeded)} validators passed")
    """

    def __init__(self, *args, **kwargs):
        """Initialize last match tracking."""
        super().__init__(*args, **kwargs)
        self._last_match: Optional[Any] = None

    @property
    def last_match(self) -> Optional[Any]:
        """
        Get items that matched/executed in last operation.

        Returns appropriate collection type:
        - resolve(): Collection with single matched item
        - resolve_all(): Collection with all succeeded items
        - None if no operation performed yet

        Returns:
            Collection of matched items or None
        """
        return self._last_match

    def _set_last_match(self, matched: Any) -> None:
        """
        Set last match result (internal).

        Args:
            matched: Collection of matched items
        """
        self._last_match = matched

    def _clear_last_match(self) -> None:
        """Clear last match tracking (internal)."""
        self._last_match = None
