"""Tokenable trait - Token storage for sessions and one-time operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional
from datetime import datetime
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['persistable', 'ownable'])
@root('tokenable')
class TokenableTrait:
    """
    Token storage trait.

    Provides token field and expiry management.

    Fields:
        token: str - Random token or JWT
        token_type: str - Token type ('session', 'password_reset', 'email_verify', etc.)
        expires_at: datetime - Token expiry timestamp

    Example:
        session = Frag(affinities=['session'], traits=['tokenable', 'timestamped'])
        session.set_token("abc123def456")
        session.set_token_type('session')
        session.set_expires_at(datetime.now() + timedelta(hours=24))

        if not session.is_expired():
            print(f"Token valid: {session.token}")
    """

    # Private attributes
    _token: str = ""
    _token_type: str = ""
    _expires_at: Optional[datetime] = None

    # Token
    @property
    def token(self) -> str:
        """Get token."""
        return self._token

    def set_token(self, token: str) -> Frag:
        """Set token."""
        self._token = token  # type: ignore
        return self  # type: ignore

    def has_token(self) -> bool:
        """Check if token is set."""
        return bool(self._token)

    # Token type
    @property
    def token_type(self) -> str:
        """Get token type."""
        return self._token_type

    def set_token_type(self, token_type: str) -> Frag:
        """Set token type."""
        self._token_type = token_type  # type: ignore
        return self  # type: ignore

    # Expiry
    @property
    def expires_at(self) -> Optional[datetime]:
        """Get expiry timestamp."""
        return self._expires_at

    def set_expires_at(self, expires_at: datetime) -> Frag:
        """Set expiry timestamp."""
        self._expires_at = expires_at  # type: ignore
        return self  # type: ignore

    def is_expired(self) -> bool:
        """
        Check if token has expired.

        Returns:
            True if expired, False otherwise
        """
        if self._expires_at is None:
            return False
        return datetime.now() >= self._expires_at
