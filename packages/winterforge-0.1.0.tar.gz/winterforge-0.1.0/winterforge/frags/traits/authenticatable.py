"""Authenticatable trait - Password management and account security."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional
from datetime import datetime, timedelta
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


# Lockout configuration (module-level so accessible from bound methods)
_MAX_FAILED_LOGINS = 5
_LOCKOUT_DURATION = 900  # 15 minutes in seconds


@frag_trait(requires=['persistable', 'userable'])
@root('authenticatable')
class AuthenticatableTrait:
    """
    Password authentication and security trait.

    Provides password hashing, verification, and account lockout functionality.

    Fields:
        password_hash: str - Hashed password (never plain text)
        failed_logins: int - Failed login counter
        locked_until: datetime - Account lockout expiry

    Example:
        user = Frag(affinities=['user'], traits=['authenticatable'])
        user.set_password('secure_password')

        if user.verify_password('secure_password'):
            print("Password correct!")
        else:
            user.record_failed_login()

        if user.is_locked():
            print(f"Account locked until {user.locked_until}")
    """

    # Private attributes
    _password_hash: str = ""
    _failed_logins: int = 0
    _locked_until: Optional[datetime] = None

    # Password hash
    @property
    def password_hash(self) -> str:
        """Get password hash (read-only)."""
        return self._password_hash

    def set_password(self, plain: str) -> Frag:
        """
        Hash and set password.

        Uses configured HashingProvider (default: Argon2).

        Args:
            plain: Plain text password

        Returns:
            Self for fluent chaining
        """
        from winterforge.plugins import HashingProviderManager
        hashed = HashingProviderManager.hash_password(plain)

        self._password_hash = hashed  # type: ignore
        return self  # type: ignore

    def verify_password(self, plain: str) -> bool:
        """
        Verify plain password against stored hash.

        Args:
            plain: Plain text password to verify

        Returns:
            True if password matches, False otherwise
        """
        if not self.has_password():
            return False

        from winterforge.plugins import HashingProviderManager
        return HashingProviderManager.verify_password(plain, self.password_hash)

    def has_password(self) -> bool:
        """Check if password is set."""
        return bool(self._password_hash)

    # Failed login tracking
    @property
    def failed_logins(self) -> int:
        """Get failed login counter."""
        return self._failed_logins

    @property
    def locked_until(self) -> Optional[datetime]:
        """Get lockout expiry timestamp."""
        return self._locked_until

    def record_failed_login(self) -> Frag:
        """
        Record failed login attempt.

        Increments counter and locks account if threshold reached.

        Returns:
            Self for fluent chaining
        """
        self._failed_logins += 1  # type: ignore

        if self._failed_logins >= _MAX_FAILED_LOGINS:  # type: ignore
            self._locked_until = datetime.now() + timedelta(seconds=_LOCKOUT_DURATION)  # type: ignore

        return self  # type: ignore

    def clear_failed_logins(self) -> Frag:
        """
        Clear failed login counter.

        Called on successful login.

        Returns:
            Self for fluent chaining
        """
        self._failed_logins = 0  # type: ignore
        self._locked_until = None  # type: ignore
        return self  # type: ignore

    def is_locked(self) -> bool:
        """
        Check if account is currently locked.

        Returns:
            True if locked and lockout has not expired, False otherwise
        """
        if self._locked_until is None:
            return False
        return datetime.now() < self._locked_until

    def unlock(self) -> Frag:
        """
        Manually unlock account.

        Admin action - clears lockout and failed login counter.

        Returns:
            Self for fluent chaining
        """
        self._failed_logins = 0  # type: ignore
        self._locked_until = None  # type: ignore
        return self  # type: ignore
