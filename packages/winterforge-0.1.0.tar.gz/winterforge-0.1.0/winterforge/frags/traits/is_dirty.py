"""IsDirtyTrait - tracks uncommitted field changes."""

from __future__ import annotations
from typing import Any, TYPE_CHECKING
from winterforge.plugins.decorators import frag_trait, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['persistable'])
@root('is-dirty')
class IsDirtyTrait:
    """
    Tracks uncommitted changes via internal state management.

    Extends persistable to track dirty state across persistence lifecycle.

    Dirty state managed internally via:
    - set() → _dirty = True (field writes mark dirty)
    - set_alias() → NO change (aliases are state, not data)
    - save() → _dirty = False (only after successful save)
    - clear() → _dirty = False (when discarding changes)

    Public API:
    - is_dirty() → bool (read-only)

    Requires: persistable trait (for save/clear/delete lifecycle)

    Examples:
        # Create StatFrag with dirty tracking
        stat = Frag(affinities=['stat'], traits=['is_dirty'])

        # Aliases don't mark dirty (they're state)
        stat.set_alias('source_frag', '123')
        assert stat.is_dirty() == False

        # Fields mark dirty (they're data)
        stat.set('duration', 0.5)
        stat.set('cpu_percent', 45.2)
        assert stat.is_dirty() == True

        # Save resets dirty (after success)
        await stat.save()
        assert stat.is_dirty() == False

        # Clear resets dirty (after discard)
        stat.set('duration', 0.7)
        assert stat.is_dirty() == True
        stat.clear()
        assert stat.is_dirty() == False
    """

    # Initialize dirty flag
    _dirty = False

    def is_dirty(self) -> bool:
        """
        Check if Frag has uncommitted field changes.

        Returns:
            True if data modified but not persisted or cleared.
        """
        return self._dirty

    def set(self, key: str, value: Any) -> 'Frag':
        """
        Override to mark dirty on field write.

        Args:
            key: Field name
            value: Field value

        Returns:
            Self for method chaining
        """
        # Store field value (persistable logic)
        if not hasattr(self, '_fields'):
            self._fields = {}  # type: ignore
        self._fields[key] = value  # type: ignore

        # Mark dirty after field write
        self._dirty = True
        return self  # type: ignore

    async def save(self):
        """
        Override to reset dirty only after successful save.

        If save fails (raises exception), dirty flag preserved.

        Returns:
            Self for method chaining

        Raises:
            ValueError: If no storage configured
        """
        # Get storage (persistable logic)
        storage = self.get_storage()  # type: ignore
        if storage is None:
            raise ValueError(
                "Cannot save Frag: no storage configured. "
                "Use attach_storage() or set_storage()"
            )

        # Save to storage (may raise exception)
        await storage.save(self)

        # Only reached if save succeeded
        self._dirty = False
        return self

    def clear(self) -> 'Frag':
        """
        Override to reset dirty when discarding uncommitted data.

        Returns:
            Self for method chaining
        """
        # Clear field data (persistable logic)
        if hasattr(self, '_fields'):
            self._fields = {}  # type: ignore

        # Reset dirty state
        self._dirty = False
        return self  # type: ignore
