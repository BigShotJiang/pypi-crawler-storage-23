"""Timestamped trait for Frags with created and updated timestamps."""

from __future__ import annotations

from typing import Optional, TYPE_CHECKING
from datetime import datetime, UTC, timedelta
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['persistable'])
@root('timestamped')
class TimestampedTrait:
    """
    Provides created_at and updated_at timestamp fields.

    Timestamps are stored as ISO 8601 strings for simplicity
    and database compatibility.

    Common use cases:
    - Audit trails
    - Sorting by creation/modification time
    - Temporal queries

    This trait adds:
    - Readonly properties: created_on, updated_on
    - Fluent setters: set_created_time(), set_updated_time(), touch()
    - Helpers: get_age()
    - Checks: is_created(), is_updated()

    Example:
        from datetime import datetime, UTC

        frag = Frag(
            affinities=['content'],
            traits=['timestamped']
        )
        frag.set_created_time(datetime.now(UTC).isoformat()).touch()  # Chain setters

        if frag.is_created():
            print(f"Age: {frag.get_age()}")

    Note:
        Timestamps are not automatically managed by the trait.
        Application code or storage backend hooks should handle
        timestamp updates.
    """

    # Private attributes (will be copied to Frag instances)
    _created_at: Optional[str] = None
    _updated_at: Optional[str] = None

    @property
    def created_on(self) -> Optional[str]:
        """
        Gets the creation timestamp (readonly property).

        Returns:
            Optional[str]: ISO 8601 timestamp or None.
        """
        return self._created_at

    def set_created_time(self, timestamp: str) -> Frag:
        """
        Sets the creation timestamp (fluent setter).

        Args:
            timestamp: ISO 8601 timestamp.

        Returns:
            self: Returns the Frag for method chaining.

        Raises:
            ValueError: If timestamp is invalid ISO 8601 format.
        """
        # Validate ISO 8601
        try:
            datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        except (ValueError, TypeError, AttributeError) as e:
            raise ValueError(f"Invalid ISO 8601 timestamp: {timestamp}") from e

        self._created_at = timestamp  # type: ignore
        return self  # type: ignore

    @property
    def updated_on(self) -> Optional[str]:
        """
        Gets the last update timestamp (readonly property).

        Returns:
            Optional[str]: ISO 8601 timestamp or None.
        """
        return self._updated_at

    def set_updated_time(self, timestamp: str) -> Frag:
        """
        Sets the last update timestamp (fluent setter).

        Args:
            timestamp: ISO 8601 timestamp.

        Returns:
            self: Returns the Frag for method chaining.

        Raises:
            ValueError: If timestamp is invalid ISO 8601 format.
        """
        # Validate ISO 8601
        try:
            datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
        except (ValueError, TypeError, AttributeError) as e:
            raise ValueError(f"Invalid ISO 8601 timestamp: {timestamp}") from e

        self._updated_at = timestamp  # type: ignore
        return self  # type: ignore

    def touch(self) -> Frag:
        """
        Updates the updated_at timestamp to now.

        Convenience method for marking as modified.

        Returns:
            self: Returns the Frag for method chaining.
        """
        self.set_updated_time(datetime.now(UTC).isoformat())
        return self  # type: ignore

    def is_created(self) -> bool:
        """
        Checks whether the creation timestamp is set.

        Returns:
            bool: True if created_at is set, False otherwise.
        """
        return self._created_at is not None

    def is_updated(self) -> bool:
        """
        Checks whether the update timestamp is set.

        Returns:
            bool: True if updated_at is set, False otherwise.
        """
        return self._updated_at is not None

    def get_age(self) -> Optional[timedelta]:
        """
        Gets the age since creation.

        Returns:
            Optional[timedelta]: Time elapsed since creation, or None if not created.
        """
        created_at = self._created_at
        if not created_at:
            return None

        created = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
        return datetime.now(UTC) - created
