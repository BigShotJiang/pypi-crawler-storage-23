"""Registry trait - marker for Registry Frags."""

from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root


@frag_trait(is_system=True)
@root('registry')
class RegistryTrait:
    """
    Marker trait for Registry Frags.

    Registries are Frags that manage other Frags. They provide query
    and access operations with identity resolution. Registries store
    their own composition (affinities/traits) but NOT current Frag lists.

    Registries are ephemeral snapshots - saving a Registry captures
    composition for reuse, not the snapshot itself.

    This trait is automatically added to all Registry instances.

    **System Trait:**
    This is a system trait (metadata about the Frag) rather than a
    structural trait (defining schema/fields). System traits are excluded
    from composition filtering to avoid false matches.
    """
    pass
