"""has_data_target trait - Data export target configuration."""

from typing import TYPE_CHECKING, List, Any

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.plugins.repository import PluginRepository


class HasDataTargetTrait:
    """
    Data export target trait.

    Provides API for holding pre-configured export plugin instances
    and accessing them as ordered Repository for execution.

    Frags with this trait serve as blackbox vessels containing:
    - Export plugin instances (already configured)
    - Portability settings
    - Any additional export-specific configuration

    Fields:
        exporters: List of pre-configured export plugin instances
        portable: Whether to omit application Frags from export

    Methods:
        get_exporters() - Returns Repository of configured exporters

    Example:
        # Compose output Frag with pre-configured exporters
        output = Frag(affinities=['data_target'], traits=['has_data_target'])
        output.exporters = [
            YamlFileExporter(path='/backup/export.yaml'),
            S3Exporter(bucket='backups', key='export.yaml')
        ]
        output.portable = True

        # Export to all targets
        await transport.dump_raw(output=output)
    """

    @property
    def exporters(self) -> List[Any]:
        """Get list of configured export plugin instances."""
        return getattr(self, '_exporters', [])

    def set_exporters(self, exporters: List[Any]) -> 'Frag':
        """
        Set export plugin instances.

        Args:
            exporters: List of pre-configured exporter instances

        Returns:
            Self for chaining
        """
        self._exporters = exporters
        return self

    def add_exporter(self, exporter: Any) -> 'Frag':
        """
        Add export plugin instance to stack.

        Args:
            exporter: Pre-configured exporter instance

        Returns:
            Self for chaining
        """
        if not hasattr(self, '_exporters'):
            self._exporters = []
        self._exporters.append(exporter)
        return self

    @property
    def portable(self) -> bool:
        """Get portability flag."""
        return getattr(self, '_portable', False)

    def set_portable(self, portable: bool) -> 'Frag':
        """
        Set portability flag.

        Portable exports omit application Frags, making them
        suitable for cross-system sharing.

        Args:
            portable: True to omit application Frags

        Returns:
            Self for chaining
        """
        self._portable = portable
        return self

    def get_exporters(self) -> 'PluginRepository':
        """
        Get exporters as ordered Repository.

        Returns Repository of pre-configured export plugin instances
        ready for execution via resolve/resolve_all.

        Returns:
            PluginRepository containing configured exporters
        """
        from winterforge.plugins.repository import PluginRepository

        # Build repository from configured exporters
        plugins = {}
        order = []

        for idx, exporter in enumerate(self.exporters):
            plugin_id = f"exporter_{idx}"
            plugins[plugin_id] = exporter
            order.append(plugin_id)

        return PluginRepository(plugins, order)


# Register trait
from winterforge.plugins import FragTraitManager

FragTraitManager.register(
    'has_data_target',
    HasDataTargetTrait,
    {
        'fields': {
            'exporters': {
                'type': 'JSONB',
                'default': [],
                'description': 'List of pre-configured exporter instances'
            },
            'portable': {
                'type': 'BOOLEAN',
                'default': False,
                'description': 'Omit application Frags for cross-system sharing'
            }
        }
    }
)
