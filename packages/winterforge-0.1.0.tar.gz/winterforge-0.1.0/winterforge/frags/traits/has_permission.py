"""
Permission checking trait.

Enables Frags (typically Users) to check and manage permissions.
Permissions stored as aliases with prefix 'permission:'.
"""

from __future__ import annotations

from typing import List, TYPE_CHECKING

from winterforge.plugins.decorators import frag_trait, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['persistable'])
@root('has-permission')
class HasPermissionTrait:
    """
    Enable permission checking for Frag (typically User).

    Permissions stored as aliases with format: permission:{path}
    Value is typically 'granted' but can be any string.

    Validates permissions against PermissionProviderManager to
    ensure only defined permissions can be granted.

    Example:
        user = Frag(traits=['has_permission', 'titled'])
        user.set_title('Alice')
        await user.save()

        # Grant permission
        await user.grant_permission('content.create')
        await user.grant_permission('content.edit')

        # Check permission
        if await user.has_permission('content.create'):
            content = Frag(traits=['titled'])
            content.set_title('My Article')
            await content.save()

        # List permissions
        perms = await user.get_permissions()
        # ['content.create', 'content.edit']

        # Revoke permission
        await user.revoke_permission('content.edit')
    """

    async def has_permission(
        self,
        permission_path: str,
        **kwargs
    ) -> bool:
        """
        Check if Frag has permission.

        Validates permission against PermissionProviderManager,
        then checks if alias exists: permission:{path}

        Args:
            permission_path: Permission path (e.g., 'content.create')
            **kwargs: Context for permission check (not currently used,
                     reserved for future permission context validation)

        Returns:
            True if has permission

        Raises:
            ValueError: If permission not defined by any provider

        Example:
            if await user.has_permission('content.create'):
                await content.save()
            else:
                raise PermissionError("Cannot create content")
        """
        from winterforge.plugins.permissions.provider_manager import (
            PermissionProviderManager,
        )

        # Validate permission exists
        if not PermissionProviderManager.validate(permission_path):
            raise ValueError(
                f"Permission '{permission_path}' not defined. "
                f"Define with @permission_provider first."
            )

        # Check permission via alias
        return self.has_alias(f'permission:{permission_path}')

    async def grant_permission(self, permission_path: str) -> 'Frag':
        """
        Grant permission to Frag.

        Stores permission as alias: permission:{path} = 'granted'

        Args:
            permission_path: Permission path

        Returns:
            Self (fluent interface)

        Raises:
            ValueError: If permission not defined

        Example:
            await user.grant_permission('content.create')
            await user.grant_permission('content.edit')
        """
        from winterforge.plugins.permissions.provider_manager import (
            PermissionProviderManager,
        )

        if not PermissionProviderManager.validate(permission_path):
            raise ValueError(
                f"Permission '{permission_path}' not defined"
            )

        self.set_alias(f'permission:{permission_path}', 'granted')
        await self.save()
        return self

    async def revoke_permission(self, permission_path: str) -> 'Frag':
        """
        Revoke permission from Frag.

        Removes alias: permission:{path}

        Args:
            permission_path: Permission path

        Returns:
            Self (fluent interface)

        Example:
            await user.revoke_permission('content.create')
        """
        self.clear_alias(f'permission:{permission_path}')
        await self.save()
        return self

    async def get_permissions(self) -> List[str]:
        """
        Get all permissions granted to Frag.

        Extracts permission paths from aliases starting with
        'permission:' prefix.

        Returns:
            List of permission paths

        Example:
            perms = await user.get_permissions()
            # ['content.create', 'content.edit', 'content.delete']

            # Check if user has any content permissions
            has_content_perms = any(
                p.startswith('content.')
                for p in await user.get_permissions()
            )
        """
        aliases = self.get_aliases()
        perms: List[str] = []

        for key in aliases.keys():
            if key.startswith('permission:'):
                perm_path = key.replace('permission:', '')
                perms.append(perm_path)

        return sorted(perms)  # Return sorted for consistency
