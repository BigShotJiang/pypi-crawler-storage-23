"""Clearable trait - discard uncommitted field data."""

from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


def clear(self: 'Frag') -> 'Frag':
    """
    Discard all uncommitted field data.

    Clears fields (instance data) but preserves aliases (state).
    Part of persistence lifecycle: save/clear/delete.

    Returns:
        Reference to self for chaining.
    """
    if hasattr(self, '_fields'):
        self._fields = {}
    return self
