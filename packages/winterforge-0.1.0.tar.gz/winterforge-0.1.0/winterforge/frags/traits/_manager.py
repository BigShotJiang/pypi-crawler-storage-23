"""Frag trait plugin manager."""

from __future__ import annotations

from typing import Dict, Type, Any, Callable, Optional
from winterforge.plugins._base import ReorderablePluginManagerBase
from winterforge.frags.traits._field_info import (
    TraitFieldInfo,
    FieldType
)
import types


class FragTraitManager(ReorderablePluginManagerBase):
    """Manages frag trait plugins."""

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier for frag traits."""
        return 'winterforge.frag_traits'

    @classmethod
    def get_all_trait_ids(cls) -> list[str]:
        """
        Get all registered trait IDs.

        Returns list of all trait plugin identifiers registered in the system.
        Used for materialization - creating Trait Frags from execution scope.

        Returns:
            Sorted list of trait IDs

        Example:
            from winterforge.plugins import discover_plugins
            discover_plugins()

            trait_ids = FragTraitManager.get_all_trait_ids()
            # ['persistable', 'sluggable', 'timestamped', 'titled', ...]
        """
        return sorted(cls._plugins.keys())

    @classmethod
    def _get_trait_class(cls, trait_id: str) -> Type:
        """
        Get the trait class for a given trait ID (internal helper).

        Args:
            trait_id: Trait plugin identifier

        Returns:
            The trait class

        Raises:
            KeyError: If trait not found
        """
        trait_class = cls._plugins.get(trait_id)
        if not trait_class:
            raise KeyError(f"Trait '{trait_id}' not found")
        return trait_class

    @classmethod
    def get_trait_fields(
        cls,
        trait_id: str
    ) -> Dict[str, TraitFieldInfo]:
        """
        Get field definitions from a trait.

        Args:
            trait_id: Trait plugin identifier

        Returns:
            Dict mapping field names to TraitFieldInfo objects

        Raises:
            KeyError: If trait not found
        """
        trait_class = cls._get_trait_class(trait_id)

        # Collect fields from trait class
        fields = {}

        # Check for Pydantic Schema (new fieldable pattern)
        if hasattr(trait_class, 'Schema'):
            schema_class = getattr(trait_class, 'Schema')
            if hasattr(schema_class, 'model_fields'):
                # Pydantic v2
                for field_name, field_info in schema_class.model_fields.items():
                    fields[field_name] = TraitFieldInfo(
                        name=field_name,
                        field_type=FieldType.SCHEMA_PROPERTY,
                        default_value=field_info.default
                    )
            elif hasattr(schema_class, '__fields__'):
                # Pydantic v1
                for field_name, field_info in schema_class.__fields__.items():
                    fields[field_name] = TraitFieldInfo(
                        name=field_name,
                        field_type=FieldType.SCHEMA_PROPERTY,
                        default_value=field_info.default
                    )

        # Also collect old-style _field attributes
        for attr_name in dir(trait_class):
            # Include single-underscore private attributes
            # Exclude double-underscore (dunder) attributes
            # Also exclude name-mangled attributes
            if attr_name.startswith('_') and not attr_name.startswith('__'):
                # Exclude name-mangled attributes (contains __ after _)
                if '__' in attr_name[1:]:
                    continue

                attr = getattr(trait_class, attr_name)
                # Only include private data attributes
                if not callable(attr) and not isinstance(
                    attr,
                    (classmethod, staticmethod, types.MethodType, type)
                ):
                    fields[attr_name] = TraitFieldInfo(
                        name=attr_name,
                        field_type=FieldType.DIRECT_ATTRIBUTE,
                        default_value=attr
                    )

        return fields

    @classmethod
    def get_trait_methods(cls, trait_id: str) -> Dict[str, Callable[..., Any]]:
        """
        Get method definitions from a trait.

        Args:
            trait_id: Trait plugin identifier

        Returns:
            Dict mapping method names to callable methods

        Raises:
            KeyError: If trait not found
        """
        trait_class = cls._get_trait_class(trait_id)

        # Collect methods from trait class
        methods = {}
        # Allow certain special methods (__str__, __repr__, __eq__, etc.)
        allowed_special_methods = {'__str__', '__repr__', '__eq__', '__hash__'}

        for attr_name in dir(trait_class):
            # Skip most dunder methods but allow specific ones for display/comparison
            if attr_name.startswith('__') and attr_name not in allowed_special_methods:
                continue
            attr = getattr(trait_class, attr_name)
            # Include callable attributes (methods, not data)
            if callable(attr) and not isinstance(attr, (classmethod, staticmethod, type)):
                methods[attr_name] = attr

        return methods

    @classmethod
    def get_trait_properties(cls, trait_id: str) -> Dict[str, property]:
        """
        Get property definitions from a trait.

        Args:
            trait_id: Trait plugin identifier

        Returns:
            Dict mapping property names to property objects

        Raises:
            KeyError: If trait not found
        """
        trait_class = cls._get_trait_class(trait_id)

        # Collect properties from trait class
        properties = {}
        for attr_name in dir(trait_class):
            if attr_name.startswith('_'):
                continue
            attr = getattr(trait_class, attr_name)
            if isinstance(attr, property):
                properties[attr_name] = attr

        return properties

    @classmethod
    def get_metadata(cls, trait_id: str) -> Dict[str, Any]:
        """
        Get trait metadata including dependencies.

        Args:
            trait_id: Trait plugin identifier

        Returns:
            Metadata dict with 'requires' and other fields

        Raises:
            KeyError: If trait not found
        """
        # Ensure trait exists
        if trait_id not in cls._plugins:
            raise KeyError(f"Trait '{trait_id}' not found")

        # Return metadata (empty dict if not set)
        return cls._metadata.get(trait_id, {})

    @classmethod
    def get_ordered_traits(cls, trait_ids: list[str]) -> list[str]:
        """
        Get traits in dependency order (dependencies first).

        Uses DependencyResolver to topologically sort traits based on
        their 'requires' metadata. Returns ordered list suitable for
        sequential application to Frag instances.

        Args:
            trait_ids: List of trait identifiers to order

        Returns:
            Ordered list of trait IDs (dependencies before dependents)

        Raises:
            ValueError: If circular dependency detected
            KeyError: If any trait_id not found

        Example:
            >>> traits = ['is_dirty', 'persistable', 'timestamped']
            >>> ordered = get_ordered_traits(traits)
            ['persistable', 'timestamped', 'is_dirty']
            # persistable has no deps, timestamped requires persistable,
            # is_dirty requires persistable
        """
        from winterforge.utils.dependency_resolver import (
            DependencyResolver
        )

        # Build dependency map for requested traits
        dependencies = {}
        for trait_id in trait_ids:
            metadata = cls.get_metadata(trait_id)
            requires = metadata.get('requires', [])
            # Only include dependencies that are in our trait list
            dependencies[trait_id] = [
                dep for dep in requires if dep in trait_ids
            ]

        # Use DependencyResolver for topological sort
        return DependencyResolver.resolve_order(dependencies)

    @classmethod
    def dependency_tree(
        cls,
        machine_name: Optional[str] = None,
        depth: Optional[int] = None,
        parent_return_depth: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Get complete dependency tree for trait(s).

        Args:
            machine_name: Trait ID to get tree for. If None, returns trees
                for all root traits (traits with no dependents)
            depth: Tree depth control:
                - None: Unlimited depth (full tree)
                - 0: Just the trait itself (no dependencies)
                - Positive N: Traverse down N levels (dependencies)
                - Negative -N: Traverse up N levels (reverse deps),
                  then down |depth| or parent_return_depth levels
            parent_return_depth: For negative depth only. Overrides depth
                for the downward traversal from the parent. If None,
                uses |depth|.

        Returns:
            Dict representing dependency tree:
            {
                'trait': 'trait_id',
                'requires': [
                    {'trait': 'dep1', 'requires': [...]},
                    {'trait': 'dep2', 'requires': [...]}
                ]
            }

        Raises:
            KeyError: If machine_name not found

        Examples:
            # Full tree for 'is_dirty'
            >>> dependency_tree('is_dirty')
            {'trait': 'is_dirty', 'requires': [
                {'trait': 'persistable', 'requires': []}
            ]}

            # Just the trait (depth=0)
            >>> dependency_tree('is_dirty', depth=0)
            {'trait': 'is_dirty', 'requires': []}

            # One level down
            >>> dependency_tree('is_dirty', depth=1)
            {'trait': 'is_dirty', 'requires': [
                {'trait': 'persistable', 'requires': []}
            ]}

            # Reverse dependencies (negative depth)
            >>> dependency_tree('persistable', depth=-1)
            # Returns tree for 'is_dirty' (depends on persistable)
            # going 1 level deep
        """
        # Build reverse dependency map (trait -> list of traits that require it)
        reverse_deps: Dict[str, list] = {}
        for trait_id in cls._plugins.keys():
            metadata = cls.get_metadata(trait_id)
            requires = metadata.get('requires', [])
            for dep in requires:
                if dep not in reverse_deps:
                    reverse_deps[dep] = []
                reverse_deps[dep].append(trait_id)

        def build_tree_down(trait_id: str, current_depth: int, max_depth: Optional[int]) -> Dict[str, Any]:
            """Build tree going down (dependencies)."""
            # Check depth limit
            if max_depth is not None and current_depth >= max_depth:
                return {'trait': trait_id, 'requires': []}

            # Get dependencies
            metadata = cls.get_metadata(trait_id)
            requires = metadata.get('requires', [])

            # Build subtrees
            subtrees = []
            for dep in requires:
                subtree = build_tree_down(dep, current_depth + 1, max_depth)
                subtrees.append(subtree)

            return {
                'trait': trait_id,
                'requires': subtrees
            }

        def find_parents(trait_id: str, levels: int) -> list:
            """Find traits that depend on this one, N levels up."""
            if levels == 0:
                return [trait_id]

            parents = reverse_deps.get(trait_id, [])
            if not parents or levels == 1:
                return parents

            # Recursively go up
            all_ancestors = []
            for parent in parents:
                ancestors = find_parents(parent, levels - 1)
                all_ancestors.extend(ancestors)

            return all_ancestors

        # Handle negative depth (traverse up, then down)
        if depth is not None and depth < 0:
            if machine_name is None:
                raise ValueError(
                    "machine_name required for negative depth"
                )

            # Traverse up |depth| levels
            ancestors = find_parents(machine_name, abs(depth))

            if not ancestors:
                # No ancestors at that level, return original trait
                downward_depth = (
                    parent_return_depth if parent_return_depth is not None
                    else abs(depth)
                )
                return build_tree_down(machine_name, 0, downward_depth)

            # Build trees for all ancestors
            downward_depth = (
                parent_return_depth if parent_return_depth is not None
                else abs(depth)
            )

            if len(ancestors) == 1:
                return build_tree_down(ancestors[0], 0, downward_depth)
            else:
                # Multiple ancestors - return all
                return {
                    'ancestors': [
                        build_tree_down(anc, 0, downward_depth)
                        for anc in ancestors
                    ]
                }

        # Handle positive depth or None (normal downward tree)
        if machine_name is not None:
            # Single trait tree
            max_depth = None if depth is None else (depth + 1 if depth > 0 else 1)
            return build_tree_down(machine_name, 0, max_depth)

        # No machine_name - return all root traits
        # (traits that nothing depends on)
        all_traits = set(cls._plugins.keys())
        has_dependents = set(reverse_deps.keys())
        roots = all_traits - has_dependents

        if not roots:
            # No pure roots, return all traits
            roots = all_traits

        max_depth = None if depth is None else (depth + 1 if depth > 0 else 1)
        return {
            'roots': [
                build_tree_down(root, 0, max_depth)
                for root in sorted(roots)
            ]
        }
