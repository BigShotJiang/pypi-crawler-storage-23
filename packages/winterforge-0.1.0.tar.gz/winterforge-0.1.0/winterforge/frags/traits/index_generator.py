"""
Database index generator based on trait inheritance.

Analyzes trait hierarchy and suggests optimal database indexes
for common query patterns.
"""

from typing import Dict, List, Set, Tuple, Type
import inspect


class TraitIndexGenerator:
    """
    Generate database indexes from trait inheritance patterns.

    Uses Python's introspection to analyze trait relationships
    and suggest indexes that align with actual usage patterns.
    """

    @classmethod
    def analyze_trait_hierarchy(
        cls, trait_registry: Dict[str, Type]
    ) -> Dict[str, List[str]]:
        """
        Analyze trait inheritance to build dependency map.

        Args:
            trait_registry: Dict mapping trait IDs to trait classes

        Returns:
            Dict mapping each trait to its base traits

        Example:
            {
                'promptable': ['fieldable'],
                'textual': ['fieldable'],
                'profileable': ['fieldable', 'composable']
            }
        """
        hierarchy = {}

        for trait_id, trait_class in trait_registry.items():
            bases = []

            # Get all base classes (excluding object)
            for base in trait_class.__bases__:
                if base == object:
                    continue

                # Find trait ID for this base class
                base_trait_id = cls._find_trait_id(
                    base, trait_registry
                )
                if base_trait_id:
                    bases.append(base_trait_id)

            if bases:
                hierarchy[trait_id] = bases

        return hierarchy

    @classmethod
    def _find_trait_id(
        cls, trait_class: Type, trait_registry: Dict[str, Type]
    ) -> str:
        """Find trait ID for a given trait class."""
        for trait_id, registered_class in trait_registry.items():
            if registered_class is trait_class:
                return trait_id
        return None

    @classmethod
    def generate_inheritance_indexes(
        cls, hierarchy: Dict[str, List[str]]
    ) -> List[str]:
        """
        Generate index DDL statements based on trait hierarchy.

        Args:
            hierarchy: Trait dependency map from analyze_trait_hierarchy()

        Returns:
            List of SQL CREATE INDEX statements

        Pattern 1: Single Base Trait
            If PromptableTrait extends FieldableTrait,
            prompts are always queried with field operations.
            → Create index on traits array containing both.

        Pattern 2: Multiple Base Traits
            If ProfileableTrait extends FieldableTrait AND ComposableTrait,
            profiles need both sets of operations.
            → Create composite index for all three.

        Pattern 3: Shared Base
            If multiple traits extend the same base (textual, promptable,
            generated all extend fieldable), they share common query patterns.
            → Create indexes for each combination.
        """
        indexes = []

        # Pattern 1 & 2: Trait + its bases
        for trait_id, bases in hierarchy.items():
            # Include the trait itself plus all bases
            trait_array = [trait_id] + bases

            # Create PostgreSQL array literal
            pg_array = f"ARRAY[{', '.join(f\"'{t}'\" for t in trait_array)}]"

            index_name = f"idx_{trait_id}_with_bases"

            ddl = f"""-- Index for {trait_id} (extends {', '.join(bases)})
-- Optimizes queries where {trait_id} traits use inherited methods
CREATE INDEX IF NOT EXISTS {index_name}
ON frags ((traits @> {pg_array}))
WHERE traits @> ARRAY['{trait_id}'];"""

            indexes.append(ddl)

        # Pattern 3: Shared base patterns
        shared_base_indexes = cls._generate_shared_base_indexes(
            hierarchy
        )
        indexes.extend(shared_base_indexes)

        return indexes

    @classmethod
    def _generate_shared_base_indexes(
        cls, hierarchy: Dict[str, List[str]]
    ) -> List[str]:
        """
        Generate indexes for traits sharing the same base.

        If multiple traits extend fieldable (promptable, textual, generated),
        they're often queried together in workflows:
        - Prompt (promptable) → Response (textual + generated)
        - Config (fieldable) lookups
        """
        indexes = []

        # Find traits that share bases
        base_to_traits: Dict[str, List[str]] = {}

        for trait_id, bases in hierarchy.items():
            for base in bases:
                if base not in base_to_traits:
                    base_to_traits[base] = []
                base_to_traits[base].append(trait_id)

        # For each shared base with multiple children
        for base, children in base_to_traits.items():
            if len(children) <= 1:
                continue  # Not shared

            # Common pattern: base + any children
            index_name = f"idx_{base}_family"
            child_array = ", ".join(f"'{c}'" for c in children)

            ddl = f"""-- Index for {base} family ({', '.join(children)})
-- Optimizes queries across traits extending {base}
CREATE INDEX IF NOT EXISTS {index_name}
ON frags ((traits @> ARRAY['{base}']))
WHERE traits && ARRAY[{child_array}];"""

            indexes.append(ddl)

        return indexes

    @classmethod
    def generate_common_pattern_indexes(cls) -> List[str]:
        """
        Generate indexes for empirically observed common patterns.

        These are based on actual usage patterns in applications:
        - Config Frags (fieldable + sluggable + titled)
        - Prompts (promptable + timestamped)
        - Responses (textual + generated + timestamped)
        - Conversations (relatable + timestamped)
        """
        indexes = []

        patterns = [
            (
                "config_pattern",
                "Configuration Frags",
                ["fieldable", "sluggable", "titled", "persistable"],
                "WHERE affinities @> ARRAY['config']"
            ),
            (
                "prompt_pattern",
                "AI prompt Frags",
                ["promptable", "timestamped", "persistable"],
                "WHERE affinities @> ARRAY['prompt']"
            ),
            (
                "response_pattern",
                "AI response Frags",
                ["textual", "generated", "timestamped"],
                "WHERE affinities @> ARRAY['response']"
            ),
            (
                "conversation_pattern",
                "Conversation Frags",
                ["relatable", "timestamped"],
                "WHERE affinities @> ARRAY['conversation']"
            ),
            (
                "profile_pattern",
                "Install profile Frags",
                ["profileable", "titled"],
                "WHERE affinities @> ARRAY['install-profile']"
            ),
        ]

        for name, description, traits, where_clause in patterns:
            trait_array = f"ARRAY[{', '.join(f\"'{t}'\" for t in traits)}]"

            ddl = f"""-- {description}
-- Common pattern: {', '.join(traits)}
CREATE INDEX IF NOT EXISTS idx_{name}
ON frags ((traits @> {trait_array}))
{where_clause};"""

            indexes.append(ddl)

        return indexes

    @classmethod
    def generate_affinity_trait_indexes(cls) -> List[str]:
        """
        Generate indexes combining affinities and traits.

        Since queries often filter by both affinity AND trait,
        composite indexes improve performance significantly.
        """
        indexes = []

        # Common affinity + trait combinations
        combos = [
            ("config", "fieldable"),
            ("prompt", "promptable"),
            ("response", "textual"),
            ("response", "generated"),
            ("conversation", "relatable"),
            ("user", "userable"),
            ("role", "titled"),
        ]

        for affinity, trait in combos:
            index_name = f"idx_{affinity}_{trait}"

            ddl = f"""-- Composite index: {affinity} affinity + {trait} trait
CREATE INDEX IF NOT EXISTS {index_name}
ON frags (affinities, traits)
WHERE affinities @> ARRAY['{affinity}']
  AND traits @> ARRAY['{trait}'];"""

            indexes.append(ddl)

        return indexes

    @classmethod
    def generate_all_indexes(
        cls, trait_registry: Dict[str, Type]
    ) -> str:
        """
        Generate complete index migration SQL.

        Args:
            trait_registry: Dict mapping trait IDs to trait classes

        Returns:
            Complete SQL migration with all suggested indexes

        Usage:
            from winterforge.frags.traits._manager import FragTraitManager
            sql = TraitIndexGenerator.generate_all_indexes(
                FragTraitManager._traits
            )
            print(sql)
        """
        lines = [
            "-- Generated Database Indexes for WinterForge Frags",
            "-- Based on trait inheritance analysis",
            f"-- Generated: {cls._get_timestamp()}",
            "",
            "-- Overview:",
            "-- 1. Inheritance-based indexes (traits + bases)",
            "-- 2. Shared base family indexes",
            "-- 3. Common usage pattern indexes",
            "-- 4. Affinity + trait composite indexes",
            "",
            "BEGIN;",
            "",
        ]

        # 1. Inheritance-based indexes
        hierarchy = cls.analyze_trait_hierarchy(trait_registry)

        lines.append("-- 1. INHERITANCE-BASED INDEXES")
        lines.append("-" * 70)
        lines.append("")

        inheritance_indexes = cls.generate_inheritance_indexes(
            hierarchy
        )
        lines.extend(inheritance_indexes)
        lines.append("")

        # 2. Common pattern indexes
        lines.append("-- 2. COMMON USAGE PATTERN INDEXES")
        lines.append("-" * 70)
        lines.append("")

        pattern_indexes = cls.generate_common_pattern_indexes()
        lines.extend(pattern_indexes)
        lines.append("")

        # 3. Affinity + trait composite indexes
        lines.append("-- 3. AFFINITY + TRAIT COMPOSITE INDEXES")
        lines.append("-" * 70)
        lines.append("")

        composite_indexes = cls.generate_affinity_trait_indexes()
        lines.extend(composite_indexes)
        lines.append("")

        # Footer
        lines.extend([
            "COMMIT;",
            "",
            "-- Index creation complete!",
            f"-- Total indexes: {len(inheritance_indexes) + len(pattern_indexes) + len(composite_indexes)}",
            "",
            "-- To analyze index usage:",
            "-- SELECT schemaname, tablename, indexname, idx_scan",
            "-- FROM pg_stat_user_indexes",
            "-- WHERE tablename = 'frags'",
            "-- ORDER BY idx_scan DESC;",
        ])

        return "\n".join(lines)

    @classmethod
    def _get_timestamp(cls) -> str:
        """Get current timestamp for migration header."""
        from datetime import datetime
        return datetime.now().isoformat()

    @classmethod
    def print_hierarchy_analysis(
        cls, trait_registry: Dict[str, Type]
    ) -> None:
        """
        Print human-readable trait hierarchy analysis.

        Useful for understanding trait relationships and
        validating index generation logic.
        """
        hierarchy = cls.analyze_trait_hierarchy(trait_registry)

        print("=" * 70)
        print("TRAIT INHERITANCE HIERARCHY")
        print("=" * 70)
        print()

        if not hierarchy:
            print("No trait inheritance found.")
            print("(All traits are independent)")
            return

        # Group by base trait
        base_to_children: Dict[str, List[str]] = {}

        for trait_id, bases in hierarchy.items():
            for base in bases:
                if base not in base_to_children:
                    base_to_children[base] = []
                base_to_children[base].append(trait_id)

        # Print families
        for base, children in sorted(base_to_children.items()):
            print(f"{base}:")
            for child in sorted(children):
                all_bases = hierarchy.get(child, [])
                if len(all_bases) > 1:
                    other_bases = [b for b in all_bases if b != base]
                    print(
                        f"  └─ {child} (also extends: "
                        f"{', '.join(other_bases)})"
                    )
                else:
                    print(f"  └─ {child}")
            print()

        # Print summary
        total_with_bases = len(hierarchy)
        total_traits = len(trait_registry)
        print(f"Summary:")
        print(f"  Total traits: {total_traits}")
        print(f"  Traits with inheritance: {total_with_bases}")
        print(
            f"  Independent traits: "
            f"{total_traits - total_with_bases}"
        )
        print()
