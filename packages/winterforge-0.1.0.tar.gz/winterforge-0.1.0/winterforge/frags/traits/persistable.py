"""Persistable trait - provides self-save capability to Frags."""

from __future__ import annotations

from contextvars import ContextVar
from typing import Any, Dict, List, Optional, TYPE_CHECKING
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import emits, emits_both, root

if TYPE_CHECKING:
    from winterforge.plugins._protocols.storage import StorageBackend


# Context-local storage backend (isolated per async task/thread)
# This enables multi-tenancy and safer testing
_storage_context: ContextVar[Optional['StorageBackend']] = ContextVar(
    'storage_backend',
    default=None
)


def set_storage(storage: Optional['StorageBackend']) -> None:
    """
    Set the storage backend for current context.

    Context-isolated: Each async task, thread, or request gets its own
    storage backend. This enables multi-tenant applications where different
    requests use different storage backends concurrently.

    Args:
        storage: Storage backend instance (or None to clear)

    Example:
        # Single-tenant usage (unchanged)
        set_storage(StorageManager.get('sqlite'))
        user = Frag(traits=['persistable'])
        await user.save()  # Uses sqlite

        # Multi-tenant usage (new capability)
        async def handle_tenant_a():
            set_storage(postgres_storage)
            await frag.save()  # Uses PostgreSQL

        async def handle_tenant_b():
            set_storage(sqlite_storage)
            await frag.save()  # Uses SQLite (no conflict!)

        # Both run concurrently without interference
        await asyncio.gather(handle_tenant_a(), handle_tenant_b())
    """
    _storage_context.set(storage)


def get_storage() -> Optional['StorageBackend']:
    """
    Get the storage backend for current context.

    Returns the storage backend set for the current async task, thread,
    or request context. Each context maintains its own storage backend.

    Returns:
        Storage backend instance or None if not configured for this context
    """
    return _storage_context.get()


def has_storage() -> bool:
    """
    Check if storage backend is configured for current context.

    Returns:
        True if storage is configured in this context, False otherwise
    """
    return _storage_context.get() is not None


@frag_trait()
@root('persistable')
class PersistableTrait:
    """
    Provides persistence capability to Frags.

    Frags with this trait can save/delete themselves using either:
    - An attached storage backend (via attach_storage)
    - The default storage backend (via set_storage module function)

    This trait also provides:
    - is_new() - True until first successful save
    - Field storage via get()/set() methods

    This trait enables object-oriented persistence while maintaining
    storage decoupling through composition.

    Examples:
        # Using default storage
        from winterforge.frags.traits.persistable import set_storage
        set_storage(StorageManager.get('sqlite'))

        frag = Frag(traits=['titled', 'persistable'])
        frag.set_title("My Post")
        await frag.save()  # Uses default storage

        # Using attached storage
        frag = Frag(traits=['persistable'])
        frag.attach_storage(custom_storage)
        await frag.save()  # Uses attached storage

        # is_new tracking
        frag = Frag(traits=['persistable'])
        assert await frag.is_new()  # True - not saved yet
        await frag.save()
        assert not await frag.is_new()  # False - has been saved

        # Field storage
        frag.set('duration', 0.5)
        frag.set('cpu_percent', 42.3)
        value = frag.get('duration')  # Returns 0.5

        # Method chaining
        frag = Frag(traits=['persistable']) \\
            .attach_storage(storage)
        await frag.save()
    """

    # Initialize field storage
    _fields: Dict[str, Any] = {}

    def attach_storage(self, storage: StorageBackend):
        """
        Attach a storage backend to this Frag.

        Args:
            storage: Storage backend instance

        Returns:
            Self for method chaining
        """
        # Store as instance attribute (not in _fields to avoid persistence)
        object.__setattr__(self, '_storage_backend', storage)
        return self

    def detach_storage(self):
        """
        Remove attached storage backend.

        After detaching, the Frag will use class-level storage
        for persistence operations.

        Returns:
            Self for method chaining
        """
        # Remove instance attribute if it exists
        if hasattr(self, '_storage_backend'):
            object.__delattr__(self, '_storage_backend')
        return self

    def get_storage(self) -> Optional[StorageBackend]:
        """
        Get the storage backend for this Frag.

        Returns attached storage if present, otherwise module-level storage.

        Returns:
            Storage backend or None if no storage configured
        """
        # Check for instance attribute (attached storage)
        if hasattr(self, '_storage_backend'):
            return object.__getattribute__(self, '_storage_backend')

        # Fall back to module-level storage
        return get_storage()

    def has_storage(self) -> bool:
        """
        Check if storage is available (attached or default).

        Returns:
            True if storage is configured
        """
        return self.get_storage() is not None

    @property
    def storage_backend(self) -> Optional['StorageBackend']:
        """
        Get the current storage backend for this Frag.

        Returns attached storage if present, otherwise default storage.

        Returns:
            Optional[StorageBackend]: Storage backend or None

        Example:
            backend = frag.storage_backend
            if backend:
                print(f"Using: {type(backend).__name__}")
        """
        return self.get_storage()

    async def is_new(self) -> bool:
        """
        Check if this Frag has been saved yet.

        Determined by checking if a record exists in storage for this Frag ID.

        Returns:
            True if Frag has never been saved, False otherwise
        """
        storage = self.get_storage()
        if storage is None:
            return True  # No storage configured - consider it new

        # Check if Frag exists in storage
        existing = await storage.load(self.id)
        return existing is None

    def get(self, key: str):
        """
        Get a field value by key.

        Args:
            key: Field name

        Returns:
            Field value or None if not found
        """
        if not hasattr(self, '_fields'):
            return None
        return self._fields.get(key)

    def set(self, key: str, value):
        """
        Set a field value.

        Args:
            key: Field name
            value: Field value

        Returns:
            Self for method chaining
        """
        if not hasattr(self, '_fields'):
            self._fields = {}
        self._fields[key] = value
        return self

    def clear(self):
        """
        Discard all uncommitted field data.

        Clears fields (instance data) but preserves aliases (state).
        Part of persistence lifecycle: save/clear/delete.

        Returns:
            Self for method chaining.
        """
        if hasattr(self, '_fields'):
            self._fields = {}
        return self

    @emits('post_save')
    async def save(self):
        """
        Save this Frag to storage.

        Uses attached storage if present, otherwise class-level storage.

        Emits 'frag.post_save' event after successful save (via @root).

        Returns:
            Self for method chaining

        Raises:
            ValueError: If no storage is configured
        """
        storage = self.get_storage()
        if storage is None:
            raise ValueError(
                "Cannot save Frag: no storage configured. "
                "Use attach_storage() or set_storage()"
            )

        await storage.save(self)

        return self

    @emits('post_delete')
    async def delete(self, cascade: str = 'NULLIFY') -> 'FragRegistry':
        """
        Delete this Frag from storage and return its registry.

        Handles referential integrity by finding all Frags that reference
        this one in their aliases and applying the cascade policy.

        Emits 'frag.post_delete' event after successful deletion (via @root).

        Args:
            cascade: Referential integrity policy
                - 'NULLIFY': Remove references (default, safest)
                - 'CASCADE': Delete referencing Frags
                - 'RESTRICT': Prevent deletion if references exist
                - 'IGNORE': Delete anyway, leave orphaned references

        Returns:
            FragRegistry: Registry for this Frag's composition

        Raises:
            ValueError: If no storage configured or cascade=RESTRICT and refs exist

        Example:
            # Safe deletion (default)
            user = await users.get('john_doe')
            await user.delete()  # Nullifies all references to this user

            # Cascade deletion
            category = await categories.get('temp')
            await category.delete(cascade='CASCADE')  # Deletes all posts in category

            # Restricted deletion
            product = await products.get('active')
            await product.delete(cascade='RESTRICT')  # Raises error if orders exist
        """
        storage = self.get_storage()
        if storage is None:
            raise ValueError(
                "Cannot delete Frag: no storage configured. "
                "Use set_storage() to configure storage"
            )

        # Handle cascading based on policy
        if cascade not in ('NULLIFY', 'CASCADE', 'RESTRICT', 'IGNORE'):
            raise ValueError(
                f"Invalid cascade policy '{cascade}'. "
                f"Must be NULLIFY, CASCADE, RESTRICT, or IGNORE"
            )

        # Find all Frags that reference this one in aliases
        if cascade != 'IGNORE':
            referencing = await self._find_referencing_frags(storage)

            if cascade == 'RESTRICT' and referencing:
                ref_ids = [f.id for f in referencing]
                raise ValueError(
                    f"Cannot delete Frag {self.id}: {len(referencing)} Frags "
                    f"reference it (IDs: {ref_ids[:5]}{'...' if len(ref_ids) > 5 else ''}). "
                    f"Use cascade='CASCADE' or 'NULLIFY' to handle references."
                )

            elif cascade == 'CASCADE':
                # Delete all referencing Frags (recursive)
                for ref_frag in referencing:
                    await ref_frag.delete(cascade='CASCADE')

            elif cascade == 'NULLIFY':
                # Remove references to this Frag
                for ref_frag in referencing:
                    # Find and remove aliases pointing to this Frag
                    aliases_to_remove = [
                        key for key, value in ref_frag.aliases.items()
                        if value == self.id
                    ]
                    for key in aliases_to_remove:
                        ref_frag.remove_alias(key)
                    if aliases_to_remove:
                        await ref_frag.save()

        # Delete this Frag
        await storage.delete(self.id)

        # Return registry for this composition
        return self.get_registry()

    async def _find_referencing_frags(self, storage) -> List[Any]:
        """
        Find all Frags that reference this Frag in their aliases.

        Args:
            storage: Storage backend

        Returns:
            List of Frags that have aliases pointing to this Frag's ID
        """
        # Query storage for Frags with aliases containing this ID
        # Unconditional query returns ALL Frags from storage
        all_frags = await storage.query().execute()

        referencing = []
        for frag in all_frags:
            if frag.id == self.id:
                continue  # Skip self
            # Check if any alias value references this Frag
            for value in frag.aliases.values():
                if value == self.id:
                    referencing.append(frag)
                    break

        return referencing

    async def reload(self):
        """
        Reload this Frag from storage.

        Replaces the current Frag's data with fresh data from storage.

        Returns:
            Self for method chaining

        Raises:
            ValueError: If no storage is configured
            KeyError: If Frag not found in storage
        """
        storage = self.get_storage()
        if storage is None:
            raise ValueError(
                "Cannot reload Frag: no storage configured. "
                "Use attach_storage() or set_storage()"
            )

        fresh = await storage.load(self.id)
        if fresh is None:
            raise KeyError(f"Frag with id={self.id} not found in storage")

        # Verify trait immutability - traits cannot change after initialization
        if sorted(self.traits) != sorted(fresh.traits):
            raise ValueError(
                f"Cannot reload Frag: traits have changed in storage. "
                f"Traits are immutable after initialization. "
                f"Current: {sorted(self.traits)}, Storage: {sorted(fresh.traits)}"
            )

        # Update mutable state via proper setters
        self.set_affinities(fresh.affinities)
        self.set_aliases(fresh.aliases)

        # Update internal fields directly (persistable trait)
        if hasattr(fresh, '_fields'):
            self._fields = fresh._fields.copy()

        # Update fieldable data if present (fieldable trait)
        if hasattr(fresh, '_fieldable_data') and fresh._fieldable_data is not None:
            self._fieldable_data = fresh._fieldable_data  # type: ignore

        return self
