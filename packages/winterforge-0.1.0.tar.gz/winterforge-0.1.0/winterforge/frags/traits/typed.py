"""Typed trait - stores type information for field definitions."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional, Type, Any
from pydantic import BaseModel
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


# Common type mappings
TYPE_REGISTRY = {
    'str': str,
    'int': int,
    'float': float,
    'bool': bool,
    'list': list,
    'dict': dict,
}


@frag_trait(requires=['fieldable', 'persistable'])
@root('typed')
class TypedTrait:
    """
    Provides type storage for field definitions.

    Stores Python type information (str, int, bool, etc.) and optional
    default values. Used by field definition Frags to specify schema.

    This trait adds:
    - Readonly properties: field_type_name, default_value, required
    - Fluent setters: set_type(), set_default(), set_required()
    - Type access: get_type()

    Example:
        # Create field definition
        field = Frag(
            affinities=['field'],
            traits=['titled', 'typed', 'persistable']
        )
        field.set_title('port')
        field.set_type(int)
        field.set_default(5432)
        field.set_required(False)

        # Access type
        field.get_type()  # Returns <class 'int'>
        field.field_type_name  # 'int'
        field.default_value  # 5432
    """

    class Schema(BaseModel):
        """Pydantic schema for typed trait fields."""
        field_type_name: Optional[str] = None
        default_value: Optional[str] = None  # Stored as JSON string
        required: bool = False

    @property
    def field_type_name(self) -> Optional[str]:
        """Get the type name (readonly property)."""
        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        return self._fieldable_data.field_type_name  # type: ignore

    @property
    def default_value(self) -> Optional[Any]:
        """Get the default value (readonly property)."""
        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        if self._fieldable_data.default_value is None:  # type: ignore
            return None
        if self._fieldable_data.default_value == "":  # type: ignore
            return None

        # Deserialize from JSON
        import json
        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        try:
            return json.loads(self._fieldable_data.default_value)  # type: ignore
        except (json.JSONDecodeError, ValueError):
            # Value is not JSON-encoded, return as-is
            # This handles legacy data or direct attribute assignment
            return self._fieldable_data.default_value  # type: ignore

    @property
    def required(self) -> bool:
        """Check if field is required (readonly property)."""
        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        return self._fieldable_data.required  # type: ignore

    def set_type(self, field_type: Type) -> Frag:
        """
        Set the field type.

        Args:
            field_type: Python type (str, int, bool, float, etc.)

        Returns:
            Self for method chaining

        Example:
            field.set_type(str)
            field.set_type(int)
        """
        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        self._fieldable_data.field_type_name = field_type.__name__  # type: ignore
        self._changed = True  # type: ignore
        return self  # type: ignore

    def set_default(self, value: Any) -> Frag:
        """
        Set the default value.

        Args:
            value: Default value (will be JSON serialized)

        Returns:
            Self for method chaining

        Example:
            field.set_default('localhost')
            field.set_default(5432)
            field.set_default(False)
        """
        import json
        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        self._fieldable_data.default_value = json.dumps(value)  # type: ignore
        self._changed = True  # type: ignore
        return self  # type: ignore

    def set_required(self, required: bool) -> Frag:
        """
        Set whether field is required.

        Args:
            required: True if field is required

        Returns:
            Self for method chaining

        Example:
            field.set_required(True)
            field.set_required(False)
        """
        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        self._fieldable_data.required = required  # type: ignore
        self._changed = True  # type: ignore
        return self  # type: ignore

    def get_type(self) -> Type:
        """
        Get the Python type class.

        Returns:
            Python type (str, int, bool, etc.)

        Example:
            field.set_type(int)
            field.get_type()  # Returns <class 'int'>
        """
        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        type_name = self._fieldable_data.field_type_name  # type: ignore

        if not type_name:
            return str  # Default to string

        # Look up in type registry
        if type_name in TYPE_REGISTRY:
            return TYPE_REGISTRY[type_name]

        # Fallback to string
        return str

    def get_default(self) -> Any:
        """
        Get the default value with proper type.

        Returns:
            Default value or None

        Example:
            field.set_default(5432)
            field.get_default()  # Returns int(5432)
        """
        return self.default_value
