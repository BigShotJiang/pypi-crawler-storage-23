"""Trait field metadata and access patterns."""

from enum import Enum
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class FieldType(Enum):
    """Field storage and access pattern type."""

    SCHEMA_PROPERTY = "schema_property"
    """Pydantic Schema field exposed as property (read-only)"""

    DIRECT_ATTRIBUTE = "direct_attribute"
    """Direct instance attribute (read-write via setattr)"""


class TraitFieldInfo:
    """
    Value object encapsulating trait field metadata and access patterns.

    Abstracts away the difference between:
    - Pydantic Schema fields (properties stored in _fieldable_data)
    - Direct _field attributes (instance variables)

    Eliminates scattered property checks and provides unified interface
    for field access across Frag initialization, storage, and serialization.

    Examples:
        # Schema property (from Pydantic model)
        title_field = TraitFieldInfo(
            name='title',
            field_type=FieldType.SCHEMA_PROPERTY,
            default_value=''
        )

        # Direct attribute (old-style trait field)
        refs_field = TraitFieldInfo(
            name='_field_refs',
            field_type=FieldType.DIRECT_ATTRIBUTE,
            default_value=[]
        )

        # Unified access
        value = title_field.get(frag)
        refs_field.set(frag, [123, 456])
    """

    def __init__(
        self,
        name: str,
        field_type: FieldType,
        default_value: Any = None
    ):
        """
        Initialize field info.

        Args:
            name: Field name (property name or attribute name)
            field_type: How field is stored and accessed
            default_value: Default value for initialization
        """
        self.name = name
        self.field_type = field_type
        self.default_value = default_value

    @property
    def readable(self) -> bool:
        """Check if field can be read."""
        return True  # All fields are readable

    @property
    def writable(self) -> bool:
        """Check if field can be written."""
        # Schema properties are read-only (no setter)
        return self.field_type == FieldType.DIRECT_ATTRIBUTE

    def get(self, frag: 'Frag') -> Any:
        """
        Get field value from Frag.

        Works for both property-based and attribute-based fields.

        Args:
            frag: Frag instance to read from

        Returns:
            Field value

        Raises:
            AttributeError: If field doesn't exist on Frag
        """
        # Both types can be accessed via getattr
        # Properties: getattr calls the getter
        # Attributes: getattr returns the value directly
        return getattr(frag, self.name)

    def set(self, frag: 'Frag', value: Any) -> None:
        """
        Set field value on Frag.

        Only works for writable fields (DIRECT_ATTRIBUTE).
        Schema properties cannot be set directly (use trait setters).

        Args:
            frag: Frag instance to write to
            value: Value to set

        Raises:
            AttributeError: If field is read-only (property without setter)
            AttributeError: If field doesn't exist on Frag
        """
        if not self.writable:
            raise AttributeError(
                f"Field '{self.name}' is read-only (SCHEMA_PROPERTY). "
                f"Use trait setter method instead (e.g., set_{self.name}())."
            )

        # Direct attribute can be set via setattr
        setattr(frag, self.name, value)

    def __repr__(self) -> str:
        """String representation for debugging."""
        return (
            f"TraitFieldInfo(name={self.name!r}, "
            f"type={self.field_type.value}, "
            f"writable={self.writable})"
        )
