"""Authorizable trait - Role-based authorization."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['persistable', 'userable'])
@root('authorizable')
class AuthorizableTrait:
    """
    Role-based authorization trait.

    Provides role assignment and permission checking via role composition.

    Fields:
        role_ids: List[int] - References to Role Frags

    Example:
        user = Frag(affinities=['user'], traits=['authorizable'])
        user.add_role(admin_role.id)
        user.add_role(editor_role.id)

        if await user.has_role('admin'):
            print("User is admin!")

        if await user.has_permission('user.delete'):
            print("User can delete users!")

        # Fluent navigation (requires roles to have 'titled' and 'permissioned' traits)
        for role in await user.get_roles():
            for perm in await role.get_permissions():
                print(f"Permission: {perm.title}")
    """

    # Private attributes
    _role_ids: List[int] = []

    # Role IDs (stored as list)
    @property
    def role_ids(self) -> List[int]:
        """Get list of assigned role IDs."""
        return self._role_ids

    def set_roles(self, role_ids: List[int]) -> Frag:
        """
        Replace all roles.

        Args:
            role_ids: List of Role Frag IDs

        Returns:
            Self for fluent chaining
        """
        self._role_ids = list(role_ids)  # type: ignore
        return self  # type: ignore

    def add_role(self, role_id: int) -> Frag:
        """
        Add single role.

        Args:
            role_id: Role Frag ID

        Returns:
            Self for fluent chaining
        """
        role_ids = list(self._role_ids)
        if role_id not in role_ids:
            role_ids.append(role_id)
            self._role_ids = role_ids  # type: ignore
        return self  # type: ignore

    def remove_role(self, role_id: int) -> Frag:
        """
        Remove single role.

        Args:
            role_id: Role Frag ID

        Returns:
            Self for fluent chaining
        """
        role_ids = list(self._role_ids)
        if role_id in role_ids:
            role_ids.remove(role_id)
            self._role_ids = role_ids  # type: ignore
        return self  # type: ignore

    # Role access (loaded Frags) - Fluent Navigation
    async def get_roles(self) -> List[Frag]:
        """
        Get actual Role Frags (not just IDs).

        Note: This is an async method, not a property, because it requires
        loading from storage.

        Returns:
            List of Role Frags

        Example:
            roles = await user.get_roles()
            for role in roles:
                print(role.title)
        """
        if not self._role_ids:
            return []

        # Load Role Frags by IDs
        try:
            from winterforge.frags.registries.role_registry import RoleRegistry
            registry = RoleRegistry()

            roles = []
            for role_id in self._role_ids:
                role = await registry.get(role_id)
                if role:
                    roles.append(role)

            return roles
        except ImportError:
            # RoleRegistry not yet implemented
            return []

    @property
    def roles(self) -> List[Frag]:
        """
        DEPRECATED: Use get_roles() instead.

        This property returns an empty list. The fluent navigation pattern
        (user.roles) cannot work with async storage. Use await user.get_roles() instead.

        Returns:
            Empty list (use get_roles() instead)
        """
        import warnings
        warnings.warn(
            "user.roles property is deprecated. Use 'await user.get_roles()' instead.",
            DeprecationWarning,
            stacklevel=2
        )
        return []

    # Role checking
    async def has_role(self, role_title: str) -> bool:
        """
        Check if user has role by title.

        Requires roles to have 'titled' trait.

        Args:
            role_title: Role title (e.g., 'admin')

        Returns:
            True if user has role, False otherwise

        Example:
            if await user.has_role('admin'):
                print("User is admin")
        """
        roles = await self.get_roles()
        return any(
            hasattr(role, 'title') and role.title == role_title  # type: ignore
            for role in roles
        )

    # Permission checking (merges all permissions from all roles)
    async def has_permission(self, perm_title: str) -> bool:
        """
        Check if user has permission.

        Strategy: Merge all permissions from all roles, then check.

        Requires roles to have 'permissioned' trait and permissions to have 'titled' trait.

        Args:
            perm_title: Permission title (e.g., 'user.delete')

        Returns:
            True if user has permission, False otherwise

        Example:
            if await user.has_permission('user.delete'):
                print("User can delete users")
        """
        # Collect all permissions from all roles
        all_permissions = set()
        roles = await self.get_roles()

        for role in roles:
            # Check if role has permissioned trait by checking for get_permissions method
            if hasattr(role, 'get_permissions') and callable(getattr(role, 'get_permissions')):
                perms = await role.get_permissions()  # type: ignore
                for perm in perms:
                    if hasattr(perm, 'title'):
                        all_permissions.add(perm.title)  # type: ignore

        # Check if requested permission is in merged set
        return perm_title in all_permissions

    async def get_permissions(self) -> List[Frag]:
        """
        Get all unique Permission Frags from all roles.

        Requires roles to have 'permissioned' trait.

        Returns:
            List of Permission Frags (deduplicated)

        Example:
            perms = await user.get_permissions()
            for perm in perms:
                print(perm.title)
        """
        all_perms = {}
        roles = await self.get_roles()

        for role in roles:
            if hasattr(role, 'permissions'):
                perms = await role.get_permissions()  # type: ignore
                for perm in perms:
                    all_perms[perm.id] = perm  # Deduplicate by ID

        return list(all_perms.values())
