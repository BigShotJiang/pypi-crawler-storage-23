"""BudgetAware trait — generic budget/quota tracking via aliases."""

from __future__ import annotations

from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root


@frag_trait(requires=[])
@root('budget-aware')
class BudgetAware:
    """
    Generic budget tracking for any Frag-based resource.

    Budget data lives in ``_aliases`` so it is lightweight and
    copyable without mutation.  Two keys are used:

    * ``allotment`` — the total allocation (int as string).
      ``0`` means *not allotted* (unknown / unlimited).
    * ``used``      — units consumed so far (int as string).
      Updated externally (e.g. by an envoy after counting tokens).

    This trait is intentionally domain-agnostic: it works equally
    well for context-window token budgets, API quota tracking, or
    any other finite resource.

    **Non-allotted behaviour**
    When ``allotment == 0`` (unknown / unlimited), percentage
    queries return ``0.0`` — not 100 % — to signal "untracked"
    rather than implying the resource is full or empty.

    Example::

        window = ContextWindow(
            traits=['budget-aware'],
            aliases={'allotment': '200000', 'used': '0'},
        )
        window.remaining()               # 200000
        window.remaining(as_percentage=True)  # 100.0
        window.exhausted                 # False

        # After envoy counts tokens:
        window = window.with_aliases({'used': '198000'})
        window.remaining()               # 2000
        window.remaining(as_percentage=True)  # ~1.0
        window.exhausted                 # False
    """

    @property
    def allotment(self) -> int:
        """Total units allocated; 0 = not allotted / unknown."""
        return int(self._aliases.get('allotment', 0))

    @property
    def used(self) -> int:
        """Units consumed so far."""
        return int(self._aliases.get('used', 0))

    def remaining(self, as_percentage: bool = False) -> int | float:
        """
        Units not yet consumed.

        Args:
            as_percentage: When True, returns a float percentage
                of *allotment*.  Non-allotted collections return
                ``0.0``.

        Returns:
            Remaining units, or percentage of allotment remaining.
        """
        allotment = self.allotment
        if as_percentage:
            if allotment == 0:
                return 0.0
            return max(
                0.0,
                (allotment - self.used) / allotment * 100,
            )
        return max(0, allotment - self.used)

    def available(self, as_percentage: bool = False) -> int | float:
        """
        Units available for new content.

        Equivalent to ``remaining`` until reservation tracking is
        introduced.

        Args:
            as_percentage: When True, returns a float percentage
                of *allotment*.  Non-allotted collections return
                ``0.0``.

        Returns:
            Available units, or percentage of allotment available.
        """
        return self.remaining(as_percentage)

    @property
    def exhausted(self) -> bool:
        """
        True when the allotment is fully consumed.

        Non-allotted collections (``allotment == 0``) are never
        considered exhausted.
        """
        allotment = self.allotment
        return allotment > 0 and self.used >= allotment
