"""With history trait - enables history tracking via cloning.

Automatically tracks history when cloning Frags, creating bidirectional
lineage links for forward/backward navigation and provenance analysis.

Example:
    from winterforge.frags.traits.persistable import set_storage
    from winterforge.plugins.storage.manager import StorageManager

    # Configure storage once
    set_storage(StorageManager.get('sqlite'))

    # Create original
    doc = Frag(
        affinities=['document'],
        traits=['titled', 'with_history']
    )
    doc.set_title('Version 1')
    await doc.save()

    # Clone automatically creates history links
    v2 = doc.clone()
    v2.set_title('Version 2')
    await v2.save()

    # Navigate history
    parent = await v2.prev()  # Returns doc
    child = await doc.next()  # Returns v2

    # Get full lineage
    history = await doc.provenance()
    # {1: Frag(id=1), 2: Frag(id=2)}
"""

from typing import Optional, Dict
from winterforge.plugins.decorators import frag_trait, root


@frag_trait(requires=['persistable'])
@root('with-history')
class WithHistoryTrait:
    """
    Trait for automatic history tracking via cloning.

    Overrides the clone() method to automatically establish bidirectional
    history links. Each clone maintains links to its predecessor
    (history_prev) and successor (history_next), forming a
    doubly-linked history chain.

    Methods:
        clone(): Create clone with automatic history links
        prev(offset): Navigate backward in history chain
        next(offset): Navigate forward in history chain
        provenance(): Get complete history
    """

    def clone(self) -> 'Frag':
        """
        Clone this Frag with automatic history tracking.

        Creates a new Frag with identical composition and field values,
        then automatically establishes bidirectional history links:
        - Original receives `history_next` pointing to clone
        - Clone receives `history_prev` pointing to original

        Returns:
            New Frag instance with history links

        Example:
            original = Frag(traits=['titled', 'with_history'])
            original.set_title('Draft')
            await original.save()

            # clone() automatically adds history
            revised = original.clone()
            revised.set_title('Published')
            await revised.save()

            # Navigate
            assert await revised.prev() == original
            assert await original.next() == revised
        """
        # Import here to avoid circular dependency
        from winterforge.frags.base import Frag

        # Call base Frag.clone() to get standard clone
        cloned = Frag.clone(self)

        # Establish bidirectional history links
        self.set_alias('history_next', str(cloned.id))
        cloned.set_alias('history_prev', str(self.id))

        return cloned

    async def prev(self, offset: int = 0) -> Optional['Frag']:
        """
        Get previous Frag in history chain.

        Navigates backward in the history by following `history_prev`
        links. Supports negative offsets to navigate forward instead.

        Args:
            offset: Steps to traverse (0=immediate previous)
                - Positive: Walk backward (older versions)
                - Negative: Walk forward (newer versions)
                - 0: Immediate previous

        Returns:
            Previous Frag or None if chain ends

        Example:
            # Walk backward in history chain
            parent = await frag.prev()  # Immediate previous
            grandparent = await frag.prev(1)  # Skip 1 level
            newer = await frag.prev(-1)  # Walk forward 1 level

            # Negative offset delegates to next()
            child = await frag.prev(-1)
            # Equivalent to: await frag.next(0)
        """
        # Negative offset means walk forward instead
        if offset < 0:
            return await self.next(abs(offset) - 1)

        # Start with immediate previous
        prev_id = self.get_alias('history_prev')
        if not prev_id:
            return None

        # Load previous
        storage = self.get_storage()
        if not storage:
            return None

        current = await storage.load(int(prev_id))
        if not current:
            return None

        # offset=0 returns immediate previous (already loaded)
        # offset>0 walks further backward
        for _ in range(offset):
            prev_id = current.get_alias('history_prev')
            if not prev_id:
                return None
            current = await storage.load(int(prev_id))
            if not current:
                return None

        return current

    async def next(self, offset: int = 0) -> Optional['Frag']:
        """
        Get next Frag in history chain.

        Navigates forward in the history by following `history_next`
        links. Supports negative offsets to navigate backward instead.

        Args:
            offset: Steps to traverse (0=immediate next)
                - Positive: Walk forward (newer versions)
                - Negative: Walk backward (older versions)
                - 0: Immediate next

        Returns:
            Next Frag or None if chain ends

        Example:
            # Walk forward in history chain
            child = await frag.next()  # Immediate next
            grandchild = await frag.next(1)  # Skip 1 level

            # Negative offset delegates to prev()
            parent = await frag.next(-1)
            # Equivalent to: await frag.prev(0)
        """
        # Negative offset means walk backward instead
        if offset < 0:
            return await self.prev(abs(offset) - 1)

        # Start with immediate next
        next_id = self.get_alias('history_next')
        if not next_id:
            return None

        # Load next
        storage = self.get_storage()
        if not storage:
            return None

        current = await storage.load(int(next_id))
        if not current:
            return None

        # offset=0 returns immediate next (already loaded)
        # offset>0 walks further forward
        for _ in range(offset):
            next_id = current.get_alias('history_next')
            if not next_id:
                return None
            current = await storage.load(int(next_id))
            if not current:
                return None

        return current

    async def provenance(self) -> Dict[int, 'Frag']:
        """
        Get complete history.

        Walks the entire history chain in both directions from this
        Frag, collecting all previous and next versions. Returns a
        dictionary keyed by Frag ID, ordered by ascendancy (oldest
        to newest).

        The returned dict has the standard dict API for filtering,
        iteration, and manipulation.

        Returns:
            Dict mapping Frag ID → Frag, oldest to newest

        Example:
            history = await frag.provenance()
            # {1: Frag(id=1), 2: Frag(id=2), 3: Frag(id=3)}

            # Get root (oldest)
            root_id = min(history.keys())
            root = history[root_id]

            # Get tip (newest)
            tip_id = max(history.keys())
            tip = history[tip_id]

            # Iterate chronologically
            for fid, frag in history.items():
                print(f"Version {fid}: {frag.title}")
        """
        storage = self.get_storage()
        if not storage:
            return {self.id: self}

        lineage: Dict[int, 'Frag'] = {self.id: self}

        # Walk backward to root (oldest)
        current = self
        while True:
            prev_id = current.get_alias('history_prev')
            if not prev_id:
                break

            # Prevent infinite loops from circular references
            prev_id_int = int(prev_id)
            if prev_id_int in lineage:
                break

            ancestor = await storage.load(prev_id_int)
            if not ancestor:
                break

            lineage[ancestor.id] = ancestor
            current = ancestor

        # Walk forward to tip (newest)
        current = self
        while True:
            next_id = current.get_alias('history_next')
            if not next_id:
                break

            # Prevent infinite loops from circular references
            next_id_int = int(next_id)
            if next_id_int in lineage:
                break

            descendant = await storage.load(next_id_int)
            if not descendant:
                break

            lineage[descendant.id] = descendant
            current = descendant

        # Return sorted by ID (chronological order)
        return dict(sorted(lineage.items()))
