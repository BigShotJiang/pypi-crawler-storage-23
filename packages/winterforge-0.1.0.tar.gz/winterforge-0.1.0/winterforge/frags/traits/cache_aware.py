"""
Cache awareness trait.

Provides cache control methods on Frags. All Frags are cached
automatically - this trait adds convenience methods for cache
operations.
"""

from __future__ import annotations

from winterforge.plugins.decorators import frag_trait, root
from winterforge.plugins.cache._manager import CacheBackendManager


@frag_trait(requires=['persistable'])
@root('cache-aware')
class CacheAwareTrait:
    """
    Provides cache control methods on Frag.

    All Frags are cached automatically regardless of this trait.
    This trait just adds convenience methods for manual cache
    operations (rarely needed).

    Example:
        user = Frag(traits=['cache_aware', 'titled'])
        user.set_title('Alice')
        await user.save()

        # Check if cached
        if user.is_cached():
            print("User is in cache")

        # Manually invalidate (rare - events do this automatically)
        await user.invalidate_cache()

        # Get global cache stats
        stats = Frag.get_cache_stats()
        # {'lru': {'hits': 1523, 'size': 987, 'hit_rate': 86.7}}
    """

    async def invalidate_cache(self) -> None:
        """
        Invalidate this Frag in all caches.

        Rarely needed - events handle this automatically via
        invalidate_cache_on_change listener.

        Use cases:
        - Manual cache control during testing
        - Explicit cache flush for specific Frag
        - Cache debugging

        Example:
            await user.invalidate_cache()
            # User no longer in any cache
        """
        CacheBackendManager.invalidate(self.id)

    def is_cached(self) -> bool:
        """
        Check if this Frag is in cache.

        Returns:
            True if cached in at least one backend

        Example:
            if user.is_cached():
                print("Cache hit expected on next access")
            else:
                print("Will load from storage on next access")
        """
        return CacheBackendManager.get(self.id) is not None

    @staticmethod
    def get_cache_stats() -> dict:
        """
        Get cache statistics across all backends.

        Returns:
            Dict of backend_id → stats

        Example:
            stats = Frag.get_cache_stats()
            # {
            #     'lru': {
            #         'hits': 1523,
            #         'misses': 234,
            #         'size': 987,
            #         'max_size': 10000,
            #         'hit_rate': 86.7
            #     }
            # }

            # Print hit rate
            lru_stats = stats.get('lru', {})
            hit_rate = lru_stats.get('hit_rate', 0)
            print(f"Cache hit rate: {hit_rate}%")
        """
        return CacheBackendManager.get_stats()

    @staticmethod
    def clear_all_caches() -> None:
        """
        Clear all caches.

        Use cases:
        - Testing (reset cache between tests)
        - Explicit cache flush during development
        - Memory management (emergency cache clear)

        Example:
            Frag.clear_all_caches()
            # All caches now empty
        """
        CacheBackendManager.clear()
