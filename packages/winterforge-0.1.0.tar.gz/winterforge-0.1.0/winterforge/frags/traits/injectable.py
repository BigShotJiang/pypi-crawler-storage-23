"""Injectable trait - universal dependency injection."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['persistable'])
@root('injectable')
class InjectableTrait:
    """
    Universal dependency injection via composition matching.

    Frags signal injectability by composing the injectable trait.
    Consumers query for Frags with target composition.

    No special handling - just normal Winterforge queries!

    Example:
        # Injectable config (compose traits for fields)
        config = Frag(traits=['injectable', 'has_api_key', 'has_model'])
        config.api_key = 'sk-...'      # From has_api_key trait
        config.model = 'claude-sonnet'  # From has_model trait

        # Consumer queries by composition (normal query)
        configs = await FragRegistry(
            traits=['injectable', 'has_api_key', 'has_model']
        ).query().execute()

        # Returns Manifest - consumer decides
        primary = configs.resolve(lambda c: c.has_affinity('primary'))
        self.api_key = primary.api_key

    Composition IS applicability:
        - No special injection_aliases field
        - No special targeting API
        - Query by trait composition
        - Use existing patterns
    """

    # Injectable is just a marker trait
    # Composition determines applicability
    # No special fields or methods needed!
