"""Profileable trait - makes Frags executable as install profiles.

Install profiles are Frags that define installation workflows.
They compose field definitions and execute installation steps.

Example:
    # Create profile
    profile = Frag(
        affinities=['install-profile'],
        traits=['profileable', 'composable', 'fieldable', 'titled']
    )
    profile.set_title('Quick Install')
    profile.set_description('Fast setup with minimal prompts')

    # Add fields
    profile.add_field_reference(username_field)
    profile.add_field_reference(email_field)

    # Execute profile
    values = await profile.execute(interactive=True)
"""

from typing import Dict, Any, Optional
from winterforge.plugins.decorators import frag_trait, root
from winterforge.frags.traits.fieldable import FieldableTrait
from winterforge.frags.traits.composable import ComposableTrait


@frag_trait(requires=['fieldable', 'composable', 'titled', 'persistable'])
@root('profileable')
class ProfileableTrait(FieldableTrait, ComposableTrait):
    """
    Trait for executable install profiles.

    Enables Frags to act as installation profiles that:
    - Define required fields via composition
    - Prompt for field values interactively
    - Execute installation steps
    - Store profile metadata (description, steps)

    Extends: fieldable (for field storage) and composable (for composition).

    Example:
        profile = Frag(
            affinities=['install-profile'],
            traits=['profileable', 'composable', 'fieldable', 'titled']
        )
        profile.set_title('Full Install')
        profile.set_description('Complete setup with all options')

        # Add field references
        profile.add_field_reference(username_field)
        profile.add_field_reference(password_field)

        # Execute
        values = await profile.execute()
    """

    def set_description(self, description: str) -> 'Frag':
        """
        Set profile description.

        Args:
            description: Human-readable description of profile

        Returns:
            Self for method chaining

        Example:
            profile.set_description('Quick setup for development')
        """
        if hasattr(self, 'set_alias'):
            self.set_alias('description', description)
        return self  # type: ignore

    def get_description(self) -> Optional[str]:
        """
        Get profile description.

        Returns:
            Description string or None

        Example:
            desc = profile.get_description()
        """
        if hasattr(self, 'get_alias'):
            return self.get_alias('description')
        return None

    def set_steps(self, steps: str) -> 'Frag':
        """
        Set installation steps (comma-separated).

        Steps are identifiers for installation tasks:
        - database: Set up database
        - admin: Create admin user
        - config: Write configuration
        - plugins: Install default plugins

        Args:
            steps: Comma-separated step IDs

        Returns:
            Self for method chaining

        Example:
            profile.set_steps('database,admin,config')
        """
        if hasattr(self, 'set_alias'):
            self.set_alias('steps', steps)
        return self  # type: ignore

    def get_steps(self) -> list:
        """
        Get installation steps as list.

        Returns:
            List of step IDs

        Example:
            steps = profile.get_steps()  # ['database', 'admin', 'config']
        """
        if hasattr(self, 'get_alias'):
            steps_str = self.get_alias('steps') or ''
            return [s.strip() for s in steps_str.split(',') if s.strip()]
        return []

    async def execute(
        self,
        interactive: bool = True,
        defaults: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Execute install profile.

        Prompts for field values and returns collected data.
        Does not perform installation - that's handled by installer
        using the returned values.

        Args:
            interactive: Whether to prompt user interactively
            defaults: Default values for fields

        Returns:
            Dict of {field_name: value}

        Example:
            values = await profile.execute(interactive=True)
            # {'username': 'admin', 'email': 'admin@example.com'}
        """
        defaults = defaults or {}

        # Check if we have prompt_composed_fields from composable trait
        if hasattr(self, 'prompt_composed_fields'):
            # Use composable trait's prompting
            return await self.prompt_composed_fields(
                interactive=interactive
            )

        # Fallback: collect values from field definitions
        if hasattr(self, 'get_composed_fields'):
            composed_fields = self.get_composed_fields()
            values = {}

            for field_name in composed_fields.keys():
                # Use default if provided
                if field_name in defaults:
                    values[field_name] = defaults[field_name]
                    continue

                # Non-interactive mode: use None
                if not interactive:
                    values[field_name] = None
                    continue

                # Interactive: prompt
                value = input(f"{field_name}: ").strip()
                values[field_name] = value

            return values

        return {}

    def get_field_count(self) -> int:
        """
        Get number of fields in profile.

        Returns:
            Field count

        Example:
            count = profile.get_field_count()  # 5
        """
        if hasattr(self, 'get_field_references'):
            return len(self.get_field_references())
        return 0

    def is_minimal(self) -> bool:
        """
        Check if this is a minimal profile.

        Minimal profiles have 3 or fewer fields.

        Returns:
            True if minimal profile

        Example:
            if profile.is_minimal():
                print("Quick install!")
        """
        return self.get_field_count() <= 3
