"""Real-world trait implementations for Frags.

Trait implementations are registered via decorators and discovered during
initialization. Import specific traits directly when needed:

    from winterforge.frags.traits.titled import TitledTrait
    from winterforge.frags.traits.timestamped import TimestampedTrait

Or access via manager after initialization:

    from winterforge.frags.traits._manager import FragTraitManager
    trait = FragTraitManager.get('titled')
"""

from winterforge.frags.traits._manager import FragTraitManager

# Import HTTP traits to trigger registration
from winterforge.frags.traits import http_request  # noqa: F401
from winterforge.frags.traits import http_response  # noqa: F401

__all__ = ['FragTraitManager', 'http_request', 'http_response']
