"""is_application trait - Application identity."""

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class IsApplicationTrait:
    """
    Application identity trait.

    Marks a Frag as representing a Winterforge application instance.
    Used for export/import detection and application metadata.

    Each Winterforge instance has one or more application Frags that
    identify it. These serve as signals in exports:
    - Present in export: Non-portable (same-application export)
    - Absent from export: Portable (cross-system sharing)

    Application Frags leverage natural Frag UUID for identity,
    avoiding separate "system UUID" configuration.

    Fields:
        name: Human-readable application name
        description: Optional description of this instance

    Example:
        # Created during winterforge init
        app = Frag(
            affinities=['application'],
            traits=['is_application'],
            name='Production Blog',
            description='Main production instance'
        )
        await app.save()

        # Querying applications
        from winterforge.frags.registries.application_registry import (
            ApplicationRegistry
        )
        apps = await ApplicationRegistry.all()
        current = apps.resolve(lambda f: True)  # First match
        print(f"Application: {current.name} ({current.uuid})")
    """

    @property
    def name(self) -> str:
        """Get application name."""
        return getattr(self, '_name', '')

    def set_name(self, name: str) -> 'Frag':
        """
        Set application name.

        Args:
            name: Human-readable application name

        Returns:
            Self for chaining
        """
        self._name = name
        return self

    @property
    def description(self) -> Optional[str]:
        """Get application description."""
        return getattr(self, '_description', None)

    def set_description(self, description: str) -> 'Frag':
        """
        Set application description.

        Args:
            description: Application description/purpose

        Returns:
            Self for chaining
        """
        self._description = description
        return self

    def __str__(self) -> str:
        """String representation."""
        desc = f" - {self.description}" if self.description else ""
        return f"{self.name}{desc}"


# Register trait
from winterforge.plugins import FragTraitManager

FragTraitManager.register(
    'is_application',
    IsApplicationTrait,
    {
        'fields': {
            'name': {
                'type': 'TEXT',
                'required': True,
                'description': 'Application name'
            },
            'description': {
                'type': 'TEXT',
                'required': False,
                'description': 'Application description/purpose'
            }
        }
    }
)
