"""HTTPRequest trait - Standardized HTTP request data."""

from typing import TYPE_CHECKING, Optional, Any, Dict
from winterforge.plugins.decorators import frag_trait, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait()
@root('http-request')
class HTTPRequestTrait:
    """
    HTTP request data trait.

    Provides standardized structure for HTTP request data.
    Used by HTTPRequestHandler plugins to extract and normalize
    incoming HTTP requests into Frags.

    Fields:
        method: str - HTTP method (GET, POST, PUT, DELETE, etc)
        path: str - Request path (/api/users/123)
        headers: dict - HTTP headers
        query_params: dict - URL query parameters (?key=value)
        path_params: dict - URL path parameters ({id} in route)
        body: Any - Request body (dict, str, bytes, etc)
        content_type: str - Content-Type header value

    Example:
        request_frag = Frag(
            affinities=['http_request'],
            traits=['http_request']
        )
        request_frag.set_method('POST')
        request_frag.set_path('/api/users')
        request_frag.set_body({'username': 'alice', 'email': 'alice@example.com'})
        request_frag.set_content_type('application/json')
    """

    @property
    def method(self) -> str:
        """Get HTTP method."""
        return getattr(self, '_method', 'GET')

    def set_method(self, method: str) -> 'Frag':
        """Set HTTP method."""
        self._method = method.upper()
        return self

    @property
    def path(self) -> str:
        """Get request path."""
        return getattr(self, '_path', '')

    def set_path(self, path: str) -> 'Frag':
        """Set request path."""
        self._path = path
        return self

    @property
    def headers(self) -> Dict[str, str]:
        """Get HTTP headers."""
        return getattr(self, '_headers', {})

    def set_headers(self, headers: Dict[str, str]) -> 'Frag':
        """Set HTTP headers."""
        self._headers = headers
        return self

    @property
    def query_params(self) -> Dict[str, Any]:
        """Get URL query parameters."""
        return getattr(self, '_query_params', {})

    def set_query_params(self, params: Dict[str, Any]) -> 'Frag':
        """Set URL query parameters."""
        self._query_params = params
        return self

    @property
    def path_params(self) -> Dict[str, str]:
        """Get URL path parameters."""
        return getattr(self, '_path_params', {})

    def set_path_params(self, params: Dict[str, str]) -> 'Frag':
        """Set URL path parameters."""
        self._path_params = params
        return self

    @property
    def body(self) -> Any:
        """Get request body."""
        return getattr(self, '_body', None)

    def set_body(self, body: Any) -> 'Frag':
        """Set request body."""
        self._body = body
        return self

    @property
    def content_type(self) -> str:
        """Get Content-Type header."""
        return getattr(self, '_content_type', '')

    def set_content_type(self, content_type: str) -> 'Frag':
        """Set Content-Type header."""
        self._content_type = content_type
        return self

    def __str__(self) -> str:
        """Format for display."""
        return f"{self.method} {self.path}"
