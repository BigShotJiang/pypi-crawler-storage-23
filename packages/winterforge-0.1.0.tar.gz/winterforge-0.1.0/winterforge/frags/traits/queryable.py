"""
Queryable trait - Provides standardized query() method.

Any collection (Registry, Manifest, etc.) can be queryable by having
this trait and implementing _create_query_builder().
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from winterforge.plugins.decorators import frag_trait, root

if TYPE_CHECKING:
    from winterforge.plugins.query._repository import QueryRepository


@root('queryable')
@frag_trait()
class QueryableTrait:
    """
    Provides standardized query() method via delegation.

    Classes with this trait can be queried using the QueryBuilder API.
    All queryable collections provide consistent .query() interface.

    Examples:
        # Registry (queryable)
        users = UserRegistry()
        active = await users.query().condition('active', True).execute()

        # Manifest (queryable)
        items = Manifest([...])
        filtered = await items.query().condition(...).execute()

        # Any custom queryable collection
        collection = MyQueryableCollection()
        results = await collection.query().sort('title').execute()
    """

    def query(self) -> 'QueryRepository':
        """
        Return QueryRepository for querying this collection.

        Delegates to _create_query_builder() which subclasses must
        implement to configure the query builder appropriately.

        Returns:
            QueryRepository configured for this collection

        Examples:
            # Basic query
            results = await obj.query().condition('status', 'active').execute()

            # Complex query
            results = await obj.query()
                .condition('created_on', start_date, QueryOperator.GTE)
                .condition('affinities', 'admin', QueryOperator.CONTAINS)
                .sort('title')
                .limit(10)
                .execute()
        """
        return self._create_query_builder()

    def _create_query_builder(self) -> 'QueryRepository':
        """
        Create and configure QueryRepository for this collection.

        Subclasses must implement this to provide:
        - Storage backend
        - Composition filters (if applicable)
        - Data source (if pre-filtered)

        Returns:
            Configured QueryRepository

        Raises:
            NotImplementedError: If subclass doesn't implement

        Examples:
            # Registry implementation
            def _create_query_builder(self) -> 'QueryRepository':
                return QueryRepository(
                    storage=self.storage,
                    composition={
                        'affinities': ['user'],
                        'traits': ['userable']
                    }
                )

            # Manifest implementation
            def _create_query_builder(self) -> 'QueryRepository':
                return QueryRepository(
                    storage=self._storage,
                    data_source=self  # Pre-filtered data
                )
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement "
            "_create_query_builder() to be queryable"
        )
