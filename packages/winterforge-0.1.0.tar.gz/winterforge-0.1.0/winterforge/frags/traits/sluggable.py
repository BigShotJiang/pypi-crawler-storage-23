"""Sluggable trait for Frags with URL-friendly identifiers."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING
from pydantic import BaseModel
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['fieldable', 'persistable'])
@root('sluggable')
class SluggableTrait:
    """
    Provides a slug field for URL-friendly identifiers.

    Slugs are human-readable, URL-safe strings used for:
    - Pretty URLs (/blog/my-post-title instead of /blog/123)
    - SEO-friendly identifiers
    - Identity resolution via SlugIdentityResolver

    This trait adds:
    - Readonly property: slug
    - Fluent setters: set_slug(), generate_slug()
    - Check: has_slug()

    Example:
        frag = Frag(
            affinities=['content', 'published'],
            traits=['titled', 'sluggable']
        )
        frag.set_title("My Blog Post").generate_slug(frag.title)  # Sets slug to "my-blog-post"

        # Or manual slug
        frag.set_slug("custom-slug")

        # Later, resolve by slug
        from winterforge.plugins.identity import SlugResolver
        resolver = SlugResolver()
        frag_id = resolver.resolve("my-blog-post", storage)

    Note:
        Slug generation is not automatic. Application code should:
        1. Generate slugs from titles (using generate_slug())
        2. Ensure slug uniqueness
        3. Handle slug conflicts (append numbers, timestamps, etc.)
    """

    class Schema(BaseModel):
        """Pydantic schema for sluggable trait fields."""
        slug: str = ""

    @property
    def slug(self) -> str:
        """
        Gets the slug (readonly property).

        Returns:
            str: URL-friendly identifier.
        """
        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        return self._fieldable_data.slug  # type: ignore

    def set_slug(self, slug: str) -> Frag:
        """
        Sets the slug (fluent setter).

        Args:
            slug: URL-friendly identifier.

        Returns:
            self: Returns the Frag for method chaining.

        Raises:
            ValueError: If slug contains invalid characters or is not a string.
        """
        if not isinstance(slug, str):
            raise ValueError("Slug must be a string")

        # Validate slug format (lowercase, alphanumeric, hyphens)
        if slug and not re.match(r'^[a-z0-9-]+$', slug):
            raise ValueError(
                f"Invalid slug format: '{slug}'. "
                "Must contain only lowercase letters, numbers, and hyphens."
            )

        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        self._fieldable_data.slug = slug  # type: ignore
        self._changed = True  # type: ignore
        return self  # type: ignore

    def has_slug(self) -> bool:
        """
        Checks whether the slug is set.

        Returns:
            bool: True if slug is non-empty, False otherwise.
        """
        if hasattr(self, "_ensure_schema"):  # type: ignore
            self._ensure_schema()  # type: ignore
        return bool(self._fieldable_data.slug)  # type: ignore

    def generate_slug(self, source: str, max_length: int = 100) -> Frag:
        """
        Generates a slug from source text.

        Converts text to lowercase, replaces spaces with hyphens,
        removes special characters.

        Args:
            source: Source text to slugify.
            max_length: Maximum slug length (default: 100).

        Returns:
            self: Returns the Frag for method chaining.

        Raises:
            ValueError: If source is not a string.

        Example:
            >>> frag.generate_slug("My Blog Post!")
            >>> frag.slug
            'my-blog-post'

            >>> frag.generate_slug("Hello   World! 123")
            >>> frag.slug
            'hello-world-123'
        """
        if not isinstance(source, str):
            raise ValueError("Source must be a string")

        if not source:
            self.set_slug("")
            return self  # type: ignore

        # Convert to lowercase
        slug = source.lower()

        # Replace spaces and underscores with hyphens
        slug = re.sub(r'[\s_]+', '-', slug)

        # Remove special characters (keep alphanumeric and hyphens)
        slug = re.sub(r'[^a-z0-9-]', '', slug)

        # Remove leading/trailing hyphens
        slug = slug.strip('-')

        # Collapse multiple hyphens
        slug = re.sub(r'-+', '-', slug)

        # Enforce max length
        if len(slug) > max_length:
            slug = slug[:max_length].rstrip('-')

        self.set_slug(slug)
        return self  # type: ignore
