"""Permissioned trait - Permission management for roles.

Manages permission references within Role Frags.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['persistable'])
@root('permissioned')
class PermissionedTrait:
    """
    Permission management trait (for Role Frags).

    Fields:
        permission_ids: List[int] - References to Permission Frags

    Example:
        role = Frag(affinities=['role'], traits=['titled', 'permissioned'])
        role.set_title('admin')
        role.add_permission(delete_perm.id)
        role.add_permission(edit_perm.id)

        # Fluent navigation (requires permissions to have 'titled' trait)
        for perm in await role.get_permissions():
            print(f"Permission: {perm.title}")
    """

    # Private attributes
    _permission_ids: List[int] = []

    # Permission IDs
    @property
    def permission_ids(self) -> List[int]:
        """Get list of assigned permission IDs."""
        return self._permission_ids

    def set_permissions(self, perm_ids: List[int]) -> Frag:
        """
        Replace all permissions.

        Args:
            perm_ids: List of Permission Frag IDs

        Returns:
            Self for fluent chaining
        """
        self._permission_ids = list(perm_ids)  # type: ignore
        return self  # type: ignore

    def add_permission(self, perm_id: int) -> Frag:
        """
        Add single permission.

        Args:
            perm_id: Permission Frag ID

        Returns:
            Self for fluent chaining
        """
        perm_ids = list(self._permission_ids)
        if perm_id not in perm_ids:
            perm_ids.append(perm_id)
            self._permission_ids = perm_ids  # type: ignore
        return self  # type: ignore

    def remove_permission(self, perm_id: int) -> Frag:
        """
        Remove single permission.

        Args:
            perm_id: Permission Frag ID

        Returns:
            Self for fluent chaining
        """
        perm_ids = list(self._permission_ids)
        if perm_id in perm_ids:
            perm_ids.remove(perm_id)
            self._permission_ids = perm_ids  # type: ignore
        return self  # type: ignore

    # Permission access (loaded Frags) - Fluent Navigation
    async def get_permissions(self) -> List[Frag]:
        """
        Get actual Permission Frags (not just IDs).

        Note: This is an async method, not a property, because it requires
        loading from storage.

        Returns:
            List of Permission Frags

        Example:
            perms = await role.get_permissions()
            for perm in perms:
                print(perm.title)
        """
        if not self._permission_ids:
            return []

        # Load Permission Frags by IDs
        try:
            from winterforge.frags.registries.permission_registry import PermissionRegistry
            registry = PermissionRegistry()

            perms = []
            for perm_id in self._permission_ids:
                perm = await registry.get(perm_id)
                if perm:
                    perms.append(perm)

            return perms
        except ImportError:
            # PermissionRegistry not yet available
            return []

    @property
    def permissions(self) -> List[Frag]:
        """
        DEPRECATED: Use get_permissions() instead.

        This property returns an empty list. The fluent navigation pattern
        (role.permissions) cannot work with async storage. Use await role.get_permissions() instead.

        Returns:
            Empty list (use get_permissions() instead)
        """
        import warnings
        warnings.warn(
            "role.permissions property is deprecated. Use 'await role.get_permissions()' instead.",
            DeprecationWarning,
            stacklevel=2
        )
        return []

    def has_permission(self, perm_id: int) -> bool:
        """
        Check if role includes permission ID.

        Args:
            perm_id: Permission Frag ID

        Returns:
            True if role has permission, False otherwise
        """
        return perm_id in self._permission_ids
