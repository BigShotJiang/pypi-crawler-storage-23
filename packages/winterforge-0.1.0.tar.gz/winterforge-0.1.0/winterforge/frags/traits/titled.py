"""Titled trait for Frags with title and subtitle fields."""

from __future__ import annotations

from typing import TYPE_CHECKING
from pydantic import BaseModel
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['fieldable', 'persistable'])
@root('titled')
class TitledTrait:
    """
    Provides title and subtitle fields for content Frags.

    Common use cases:
    - Blog posts, articles, pages
    - Products, categories
    - Documents, files

    This trait adds:
    - Readonly properties: title, subtitle
    - Fluent setters: set_title(), set_subtitle()
    - Checks: has_title(), has_subtitle()

    Requires fieldable trait to be included.

    Example:
        frag = Frag(
            affinities=['content', 'published'],
            traits=['fieldable', 'titled']
        )
        frag.set_title("Introduction to Winterforge").set_subtitle("A composable AI-native framework")

        if frag.has_title():
            print(frag.title)
    """

    class Schema(BaseModel):
        """Pydantic schema for titled trait fields."""
        title: str = ""
        subtitle: str = ""

    @property
    def title(self) -> str:
        """
        Gets the title (readonly property).

        Returns:
            str: The title.
        """
        if hasattr(self, "_ensure_schema"):  # type: ignore

            if hasattr(self, "_ensure_schema"):  # type: ignore
                self._ensure_schema()  # type: ignore
        return self._fieldable_data.title  # type: ignore

    def set_title(self, title: str) -> Frag:
        """
        Sets the title (fluent setter).

        Args:
            title: The title.

        Returns:
            self: Returns the Frag for method chaining.

        Raises:
            ValueError: If title is not a string.
        """
        if not isinstance(title, str):
            raise ValueError("Title must be a string")

        if hasattr(self, "_ensure_schema"):  # type: ignore


            if hasattr(self, "_ensure_schema"):  # type: ignore
                self._ensure_schema()  # type: ignore
        self._fieldable_data.title = title  # type: ignore
        self._changed = True  # type: ignore
        return self  # type: ignore

    @property
    def subtitle(self) -> str:
        """
        Gets the subtitle (readonly property).

        Returns:
            str: The subtitle.
        """
        if hasattr(self, "_ensure_schema"):  # type: ignore

            if hasattr(self, "_ensure_schema"):  # type: ignore
                self._ensure_schema()  # type: ignore
        return self._fieldable_data.subtitle  # type: ignore

    def set_subtitle(self, subtitle: str) -> Frag:
        """
        Sets the subtitle (fluent setter).

        Args:
            subtitle: The subtitle.

        Returns:
            self: Returns the Frag for method chaining.

        Raises:
            ValueError: If subtitle is not a string.
        """
        if not isinstance(subtitle, str):
            raise ValueError("Subtitle must be a string")

        if hasattr(self, "_ensure_schema"):  # type: ignore


            if hasattr(self, "_ensure_schema"):  # type: ignore
                self._ensure_schema()  # type: ignore
        self._fieldable_data.subtitle = subtitle  # type: ignore
        self._changed = True  # type: ignore
        return self  # type: ignore

    def has_title(self) -> bool:
        """
        Checks whether the title is set.

        Returns:
            bool: True if title is non-empty, False otherwise.
        """
        if hasattr(self, "_ensure_schema"):  # type: ignore

            if hasattr(self, "_ensure_schema"):  # type: ignore
                self._ensure_schema()  # type: ignore
        return bool(self._fieldable_data.title)  # type: ignore

    def has_subtitle(self) -> bool:
        """
        Checks whether the subtitle is set.

        Returns:
            bool: True if subtitle is non-empty, False otherwise.
        """
        if hasattr(self, "_ensure_schema"):  # type: ignore

            if hasattr(self, "_ensure_schema"):  # type: ignore
                self._ensure_schema()  # type: ignore
        return bool(self._fieldable_data.subtitle)  # type: ignore
