"""HTTPResponse trait - Standardized HTTP response data."""

from typing import TYPE_CHECKING, Optional, Any, Dict
from winterforge.plugins.decorators import frag_trait, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait()
@root('http-response')
class HTTPResponseTrait:
    """
    HTTP response data trait.

    Provides standardized structure for HTTP response data.
    Used by HTTPResponseHandler plugins to format Frags into
    HTTP responses.

    Fields:
        status_code: int - HTTP status code (200, 404, 500, etc)
        headers: dict - HTTP response headers
        body: Any - Response body (dict, str, bytes, etc)
        content_type: str - Content-Type header value

    Example:
        response_frag = Frag(
            affinities=['http_response'],
            traits=['http_response']
        )
        response_frag.set_status_code(200)
        response_frag.set_body({'id': 123, 'username': 'alice'})
        response_frag.set_content_type('application/json')
        response_frag.set_headers({'X-Request-ID': 'abc-123'})
    """

    @property
    def status_code(self) -> int:
        """Get HTTP status code."""
        return getattr(self, '_status_code', 200)

    def set_status_code(self, status_code: int) -> 'Frag':
        """Set HTTP status code."""
        self._status_code = status_code
        return self

    @property
    def headers(self) -> Dict[str, str]:
        """Get HTTP response headers."""
        return getattr(self, '_headers', {})

    def set_headers(self, headers: Dict[str, str]) -> 'Frag':
        """Set HTTP response headers."""
        self._headers = headers
        return self

    def add_header(self, key: str, value: str) -> 'Frag':
        """Add a single header."""
        if not hasattr(self, '_headers'):
            self._headers = {}
        self._headers[key] = value
        return self

    @property
    def body(self) -> Any:
        """Get response body."""
        return getattr(self, '_body', None)

    def set_body(self, body: Any) -> 'Frag':
        """Set response body."""
        self._body = body
        return self

    @property
    def content_type(self) -> str:
        """Get Content-Type header."""
        return getattr(self, '_content_type', 'application/json')

    def set_content_type(self, content_type: str) -> 'Frag':
        """Set Content-Type header."""
        self._content_type = content_type
        return self

    def __str__(self) -> str:
        """Format for display."""
        return f"HTTP {self.status_code}"
