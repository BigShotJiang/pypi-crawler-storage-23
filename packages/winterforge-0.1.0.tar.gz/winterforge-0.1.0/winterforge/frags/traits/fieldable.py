"""Fieldable trait - Pydantic-based field storage for Frags."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional, Dict, Any, Type, List
from pydantic import BaseModel, create_model
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait()
@root('fieldable')
class FieldableTrait:
    """
    Provides Pydantic-based field storage for Frags.

    Merges field schemas from all traits on the Frag and creates a single
    Pydantic model for validated field storage. Enables type-safe field
    access and dynamic field definition.

    This trait must be explicitly included for Frags that have field-bearing
    traits (titled, timestamped, etc.).

    This trait adds:
    - _fieldable_schema: Merged Pydantic model class
    - _fieldable_data: Pydantic model instance (validated field values)
    - _field_refs: References to field definition Frags (for schema-based Frags)
    - Methods: value(), values(), field(), fields(), define_field()

    Example:
        # Create Frag with fieldable
        frag = Frag(
            affinities=['post'],
            traits=['fieldable', 'titled', 'sluggable', 'persistable']
        )

        # Field access
        frag.title  # Via attribute
        frag.value('title')  # Via method
        frag.values()  # All values

        # Field definitions (for schema-based Frags)
        host_field = frag.field('host')  # Returns Field Frag
        all_fields = frag.fields()  # Returns Dict[str, Frag]
    """

    # Class attributes (will be copied to Frag instances)
    _fieldable_schema: Optional[Type[BaseModel]] = None
    _fieldable_data: Optional[BaseModel] = None
    _field_refs: List[int] = []  # Field Frag IDs (for tracking)
    _field_definitions: Dict[str, Dict[str, Any]] = {}  # Cached field definitions
    _field_origins: Dict[str, str] = {}  # Maps field_name → trait_id for column naming

    def _initialize(self) -> None:
        """
        Initialize Pydantic schema and data model.

        Called by Frag after all traits are mixed in.
        Schema building is deferred until first access to handle
        field definitions loaded from storage.
        """
        # Mark schema as not yet built
        self._schema_built = False  # type: ignore

    def _ensure_schema(self) -> None:
        """
        Ensure Pydantic schema is built.

        Builds schema on first access. This allows field definitions
        to be restored from storage before schema is built.
        Preserves any existing field values (from storage).
        """
        if getattr(self, '_schema_built', False):  # type: ignore
            return

        # Check if we already have data loaded from storage
        existing_data = None
        if hasattr(self, '_fieldable_data') and self._fieldable_data is not None:  # type: ignore
            # Pydantic model already exists (loaded from storage as dict)
            # Extract the data if it's a dict or Pydantic model
            if isinstance(self._fieldable_data, dict):  # type: ignore
                existing_data = self._fieldable_data  # type: ignore
            elif hasattr(self._fieldable_data, 'model_dump'):  # type: ignore
                existing_data = self._fieldable_data.model_dump()  # type: ignore
            elif hasattr(self._fieldable_data, 'dict'):  # type: ignore
                existing_data = self._fieldable_data.dict()  # type: ignore

        # Build merged schema from all traits
        self._fieldable_schema = self._build_merged_schema()  # type: ignore

        # Initialize data model with existing values if available
        if existing_data:
            self._fieldable_data = self._fieldable_schema(**existing_data)  # type: ignore
        else:
            self._fieldable_data = self._fieldable_schema()  # type: ignore

        # Mark as built
        self._schema_built = True  # type: ignore

    def _build_merged_schema(self) -> Type[BaseModel]:
        """
        Build single Pydantic model from all trait schemas AND Field Frags.

        Collects Schema inner classes from all traits and field definitions
        from referenced Field Frags, then merges them into a single
        Pydantic model.

        Also builds _field_origins mapping for normalized column storage.

        Returns:
            Merged Pydantic model class
        """
        from winterforge.frags.traits._manager import FragTraitManager

        schemas = []
        # Only reset _field_origins if not already populated (from storage)
        if not hasattr(self, '_field_origins') or not self._field_origins:  # type: ignore
            self._field_origins = {}  # type: ignore

        # Collect schemas from all traits and track field origins
        for trait_id in self._traits:  # type: ignore
            if not FragTraitManager.has(trait_id):
                continue

            trait_class = FragTraitManager._get_trait_class(trait_id)
            if hasattr(trait_class, 'Schema'):
                schemas.append(trait_class.Schema)

                # Track which trait contributes which fields
                # (only if not already set from storage)
                schema_class = trait_class.Schema
                if hasattr(schema_class, '__annotations__'):
                    for field_name in schema_class.__annotations__.keys():
                        if field_name not in self._field_origins:  # type: ignore
                            self._field_origins[field_name] = trait_id  # type: ignore

        # Load field definitions from Field Frag references
        field_frag_fields = self._load_field_frag_definitions()

        # Track Field Frag fields as belonging to 'fieldable' trait
        # (only if not already set from storage)
        for field_name in field_frag_fields.keys():
            if field_name not in self._field_origins:  # type: ignore
                self._field_origins[field_name] = 'fieldable'  # type: ignore

        # If we have no trait schemas and no field frags, create empty schema
        if not schemas and not field_frag_fields:
            return create_model('EmptySchema')

        # If we only have trait schemas (no field frags)
        if not field_frag_fields:
            if len(schemas) == 1:
                return schemas[0]
            return FieldableTrait._merge_schemas(schemas)

        # If we only have field frags (no trait schemas)
        if not schemas:
            return create_model('FieldFragSchema', **field_frag_fields)

        # We have both - merge trait schemas, then add field frag fields
        if len(schemas) == 1:
            base_schema = schemas[0]
        else:
            base_schema = FieldableTrait._merge_schemas(schemas)

        # Merge base schema with field frag fields
        return FieldableTrait._merge_schema_with_fields(
            base_schema,
            field_frag_fields
        )

    @staticmethod
    def _merge_schemas(schemas: List[Type[BaseModel]]) -> Type[BaseModel]:
        """
        Merge multiple Pydantic schemas into one.

        Args:
            schemas: List of Pydantic BaseModel classes

        Returns:
            Single merged Pydantic model

        Raises:
            ValueError: If field name conflict detected
        """
        merged_fields = {}

        for schema in schemas:
            # Handle Pydantic v1 vs v2
            fields_dict = schema.model_fields if hasattr(schema, 'model_fields') else schema.__fields__

            for field_name, field_info in fields_dict.items():
                if field_name in merged_fields:
                    # Field conflict - same name in multiple traits
                    raise ValueError(
                        f"Field name conflict: '{field_name}' defined in "
                        f"multiple traits. Use aliases to resolve."
                    )

                # Add field to merged schema
                merged_fields[field_name] = (
                    field_info.annotation,
                    field_info.default
                )

        return create_model('MergedSchema', **merged_fields)

    def _load_field_frag_definitions(self) -> Dict[str, tuple]:
        """
        Load field definitions from cached definitions.

        Uses _field_definitions dict which is populated when field references
        are added. This avoids async calls during __init__.

        Returns:
            Dict of field_name → (type, default) for Pydantic create_model
        """
        if not self._field_definitions:  # type: ignore
            return {}

        field_definitions = {}

        # Type name to type mapping
        type_map = {
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
            'list': list,
            'dict': dict
        }

        for field_name, field_def in self._field_definitions.items():  # type: ignore
            type_name = field_def.get('type_name', 'str')
            field_type = type_map.get(type_name, str)
            default_value = field_def.get('default', "")
            field_definitions[field_name] = (field_type, default_value)

        return field_definitions

    def _resolve_field_type(self, field_frag: Frag) -> Type:
        """
        Resolve Python type from Field Frag's type name.

        Args:
            field_frag: Field definition Frag

        Returns:
            Python type class
        """
        if not hasattr(field_frag, 'field_type_name'):
            return str  # Default to string

        type_name = field_frag.field_type_name

        # Map type names to Python types
        type_map = {
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
            'list': list,
            'dict': dict
        }

        return type_map.get(type_name, str)

    def _resolve_default_value(self, field_frag: Frag) -> Any:
        """
        Resolve default value from Field Frag.

        Args:
            field_frag: Field definition Frag

        Returns:
            Default value (properly typed)
        """
        if not hasattr(field_frag, 'get_default'):
            # Check if required field
            if hasattr(field_frag, 'required') and field_frag.required:
                from pydantic import Field
                return Field(...)  # Required field
            return ""  # Default to empty string

        default = field_frag.get_default()

        # If required and no default, mark as required
        if hasattr(field_frag, 'required') and field_frag.required and default is None:
            from pydantic import Field
            return Field(...)

        return default if default is not None else ""

    @staticmethod
    def _merge_schema_with_fields(
        base_schema: Type[BaseModel],
        field_definitions: Dict[str, tuple]
    ) -> Type[BaseModel]:
        """
        Merge a base Pydantic schema with field definitions from Field Frags.

        Args:
            base_schema: Existing Pydantic model
            field_definitions: Dict of field_name → (type, default)

        Returns:
            Merged Pydantic model

        Raises:
            ValueError: If field name conflict detected
        """
        # Get existing fields from base schema
        if hasattr(base_schema, 'model_fields'):
            existing_fields = base_schema.model_fields
        else:
            existing_fields = base_schema.__fields__

        # Check for conflicts
        for field_name in field_definitions:
            if field_name in existing_fields:
                raise ValueError(
                    f"Field name conflict: '{field_name}' defined in both "
                    f"trait schema and Field Frag. Use different field names."
                )

        # Build merged fields dict for create_model
        merged_fields = {}

        # Add base schema fields
        for field_name, field_info in existing_fields.items():
            merged_fields[field_name] = (
                field_info.annotation,
                field_info.default
            )

        # Add Field Frag fields
        merged_fields.update(field_definitions)

        return create_model('MergedSchemaWithFields', **merged_fields)

    def value(self, name: str) -> Any:
        """
        Get field value by name.

        Args:
            name: Field name

        Returns:
            Field value

        Raises:
            AttributeError: If field doesn't exist

        Example:
            frag.value('title')  # Returns 'My Title'
        """
        self._ensure_schema()  # type: ignore
        if not hasattr(self._fieldable_data, name):  # type: ignore
            raise AttributeError(f"Field '{name}' not defined")
        return getattr(self._fieldable_data, name)  # type: ignore

    def values(self) -> Dict[str, Any]:
        """
        Get all field values as dictionary.

        Returns:
            Dict of field name → value

        Example:
            frag.values()
            # {'title': 'My Title', 'slug': 'my-title', ...}
        """
        self._ensure_schema()  # type: ignore
        # Handle Pydantic v1 vs v2
        if hasattr(self._fieldable_data, 'model_dump'):  # type: ignore
            return self._fieldable_data.model_dump()  # type: ignore
        else:
            return self._fieldable_data.dict()  # type: ignore

    def set_value(self, name: str, value: Any) -> Frag:
        """
        Set field value by name.

        Args:
            name: Field name
            value: Field value (validated by Pydantic)

        Returns:
            Self for method chaining

        Raises:
            AttributeError: If field doesn't exist
            ValueError: If value fails validation

        Example:
            frag.set_value('title', 'New Title')
        """
        self._ensure_schema()  # type: ignore
        if not hasattr(self._fieldable_data, name):  # type: ignore
            raise AttributeError(f"Field '{name}' not defined")

        setattr(self._fieldable_data, name, value)  # type: ignore
        self._changed = True  # type: ignore
        return self  # type: ignore

    def field(self, name: str) -> Optional[Frag]:
        """
        Get field definition Frag by name.

        For schema-based Frags, returns the Field Frag that defines
        this field's schema.

        Args:
            name: Field name (slug of the Field Frag)

        Returns:
            Field definition Frag or None if not found

        Example:
            host_field = config.field('host')
            if host_field:
                print(host_field.get_type())  # <class 'str'>
        """
        all_fields = self.fields()
        return all_fields.get(name)

    def get_field_definition(self, name: str) -> Optional[Dict[str, Any]]:
        """
        Get cached field definition by name.

        Returns the field definition dict with 'type' and 'default' keys.

        Args:
            name: Field name

        Returns:
            Field definition dict or None if not found

        Example:
            field_def = frag.get_field_definition('value')
            if field_def:
                print(f"Type: {field_def['type']}")
                print(f"Default: {field_def['default']}")
        """
        return self._field_definitions.get(name)  # type: ignore

    def fields(self) -> Dict[str, Frag]:
        """
        Get all field definition Frags.

        Note: This requires async loading and is not currently implemented.
        Use get_field_definition() to access cached definitions instead.

        Returns:
            Empty dict (placeholder for future async implementation)
        """
        # TODO: Implement async loading of Field Frags
        # For now, use get_field_definition() to access cached definitions
        return {}

    def define_field(
        self,
        name: str,
        field_type: Type,
        default: Any = None,
        **field_kwargs
    ) -> Frag:
        """
        Define a new field dynamically.

        Rebuilds the Pydantic schema with the new field. Enables
        runtime schema extension for CMS use cases.

        Args:
            name: Field name
            field_type: Python type (str, int, bool, etc.)
            default: Default value
            **field_kwargs: Additional Pydantic field kwargs

        Returns:
            Self for method chaining

        Example:
            frag.define_field('host', str, default='localhost')
            frag.define_field('port', int, default=5432, ge=1, le=65535)
            frag.host = 'prod.example.com'
        """
        from pydantic import Field

        # Ensure schema is built first
        self._ensure_schema()  # type: ignore

        # Get current schema fields (handle Pydantic v1 vs v2)
        if hasattr(self._fieldable_schema, 'model_fields'):  # type: ignore
            # Pydantic v2
            current_fields = {
                fname: (finfo.annotation, finfo.default)
                for fname, finfo in self._fieldable_schema.model_fields.items()  # type: ignore
            }
        elif hasattr(self._fieldable_schema, '__fields__'):  # type: ignore
            # Pydantic v1
            current_fields = {
                fname: (finfo.annotation, finfo.default)
                for fname, finfo in self._fieldable_schema.__fields__.items()  # type: ignore
            }
        else:
            # Empty schema or no fields
            current_fields = {}

        # Add new field
        if field_kwargs:
            current_fields[name] = (field_type, Field(default=default, **field_kwargs))
        else:
            current_fields[name] = (field_type, default)

        # Rebuild schema
        new_schema = create_model('ExtendedSchema', **current_fields)

        # Preserve existing data (handle Pydantic v1 vs v2)
        if hasattr(self._fieldable_data, 'model_dump'):  # type: ignore
            # Pydantic v2
            current_data = self._fieldable_data.model_dump()  # type: ignore
        elif hasattr(self._fieldable_data, 'dict'):  # type: ignore
            # Pydantic v1
            current_data = self._fieldable_data.dict()  # type: ignore
        else:
            current_data = {}

        # Create new data instance with extended schema
        self._fieldable_schema = new_schema  # type: ignore
        self._fieldable_data = new_schema(**current_data)  # type: ignore
        self._changed = True  # type: ignore

        return self  # type: ignore

    def add_field_reference(self, field: Frag) -> Frag:
        """
        Add field definition reference to schema.

        For schema-based Frags, tracks which Field Frags define this
        Frag's schema. Extracts and caches the field definition, then
        rebuilds the Pydantic schema to include the new field.

        Args:
            field: Field definition Frag (must have affinity=['field'])

        Returns:
            Self for method chaining

        Raises:
            ValueError: If not a field Frag or missing required attributes

        Example:
            config.add_field_reference(value_field)
            config.set_value('value', 'localhost')  # Now works!
        """
        if 'field' not in field.affinities:  # type: ignore
            raise ValueError("Must pass a Frag with affinity=['field']")

        if not hasattr(field, 'slug'):
            raise ValueError("Field Frag must have a slug (field name)")

        # Extract field definition from Field Frag
        field_name = field.slug
        field_type = self._resolve_field_type(field)
        default_value = self._resolve_default_value(field)

        # Cache the field definition (store type name, not type object)
        self._field_definitions[field_name] = {  # type: ignore
            'type_name': field_type.__name__,
            'default': default_value
        }

        # Add to references (for tracking)
        self._field_refs.append(field.id)  # type: ignore

        # Rebuild schema to include new field
        self._rebuild_schema_with_field_refs()

        self._changed = True  # type: ignore
        return self  # type: ignore

    def _rebuild_schema_with_field_refs(self) -> None:
        """
        Rebuild Pydantic schema to include field references.

        Preserves existing field values while extending the schema.
        """
        # Ensure schema exists first
        self._ensure_schema()  # type: ignore

        # Save current field values
        if hasattr(self._fieldable_data, 'model_dump'):  # type: ignore
            current_data = self._fieldable_data.model_dump()  # type: ignore
        elif hasattr(self._fieldable_data, 'dict'):  # type: ignore
            current_data = self._fieldable_data.dict()  # type: ignore
        else:
            current_data = {}

        # Rebuild schema
        self._fieldable_schema = self._build_merged_schema()  # type: ignore

        # Create new data instance with extended schema
        self._fieldable_data = self._fieldable_schema(**current_data)  # type: ignore

        # Mark as built
        self._schema_built = True  # type: ignore

    def get_field_references(self) -> List[int]:
        """
        Get field definition IDs for schema.

        Returns:
            List of Field Frag IDs

        Example:
            field_ids = schema.get_field_references()
            fields = await FieldRegistry().load_many(field_ids)
        """
        return self._field_refs.copy()
