"""Sessionable trait - Session management."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional, List, Dict, Any

from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['userable', 'persistable'])
@root('sessionable')
class SessionableTrait:
    """
    Session management trait.

    Provides methods for creating, verifying, and invalidating sessions.
    Delegates to SessionProvider plugins for implementation.

    Example:
        user = Frag(affinities=['user'], traits=['sessionable'])

        # Create session (default provider)
        token = await user.create_session(ttl=86400)

        # Create specific session type
        jwt_token = await user.create_jwt_session(ttl=3600)
        frag_token = await user.create_frag_session(ttl=86400)

        # Verify session
        session_data = await user.verify_session(token)
        print(f"User ID: {session_data['user_id']}")

        # Invalidate session
        await user.invalidate_session(token)

        # List active sessions
        sessions = await user.get_active_sessions()
    """

    async def create_session(self, ttl: int = 86400, **claims) -> str:
        """
        Create session using default SessionProvider.

        Args:
            ttl: Time-to-live in seconds (default: 24 hours)
            **claims: Additional claims to include in session

        Returns:
            Session token string
        """
        # Forward reference to Sprint 4.2
        try:
            from winterforge.plugins.session.manager import SessionProviderManager
            provider_id = SessionProviderManager.repository().order()[0]
            provider = SessionProviderManager.get(provider_id)
            return await provider.create(self.id, ttl, **claims)  # type: ignore
        except ImportError:
            raise NotImplementedError("SessionProviderManager not yet implemented (Sprint 4.2)")

    async def create_jwt_session(self, ttl: int = 3600, **claims) -> str:
        """
        Create JWT session (stateless).

        Args:
            ttl: Time-to-live in seconds (default: 1 hour)
            **claims: Additional claims to include in JWT

        Returns:
            JWT token string
        """
        # Forward reference to Sprint 4.2
        try:
            from winterforge.plugins.session.manager import SessionProviderManager
            provider = SessionProviderManager.get('jwt')
            return await provider.create(self.id, ttl, **claims)  # type: ignore
        except ImportError:
            raise NotImplementedError("SessionProviderManager not yet implemented (Sprint 4.2)")

    async def create_frag_session(self, ttl: int = 86400, **claims) -> str:
        """
        Create Frag session (stateful, revocable).

        Args:
            ttl: Time-to-live in seconds (default: 24 hours)
            **claims: Additional metadata to store

        Returns:
            Random token string
        """
        # Forward reference to Sprint 4.2
        try:
            from winterforge.plugins.session.manager import SessionProviderManager
            provider = SessionProviderManager.get('frag')
            return await provider.create(self.id, ttl, **claims)  # type: ignore
        except ImportError:
            raise NotImplementedError("SessionProviderManager not yet implemented (Sprint 4.2)")

    @staticmethod
    async def verify_session(token: str) -> Optional[Dict[str, Any]]:
        """
        Verify session token.

        Tries all SessionProviders in order until one succeeds.

        Args:
            token: Session token string

        Returns:
            Session data dict if valid, None otherwise
        """
        # Forward reference to Sprint 4.2
        try:
            from winterforge.plugins.session.manager import SessionProviderManager

            for provider in SessionProviderManager.repository().values():
                session_data = await provider.verify(token)
                if session_data:
                    return session_data

            return None
        except ImportError:
            raise NotImplementedError("SessionProviderManager not yet implemented (Sprint 4.2)")

    async def invalidate_session(self, token: str) -> bool:
        """
        Invalidate specific session.

        Args:
            token: Session token string

        Returns:
            True if invalidated, False otherwise
        """
        # Forward reference to Sprint 4.2
        try:
            from winterforge.plugins.session.manager import SessionProviderManager

            for provider in SessionProviderManager.repository().values():
                if await provider.invalidate(token):
                    return True

            return False
        except ImportError:
            raise NotImplementedError("SessionProviderManager not yet implemented (Sprint 4.2)")

    async def invalidate_all_sessions(self) -> int:
        """
        Invalidate all sessions for this user (logout everywhere).

        Returns:
            Number of sessions invalidated
        """
        # Forward reference to Sprint 4.3
        try:
            from winterforge.frags.registries.session_registry import SessionRegistry

            registry = SessionRegistry().for_user(self.id)  # type: ignore
            sessions = await registry.all()

            count = 0
            for session in sessions:
                if await self.invalidate_session(session.token):
                    count += 1

            return count
        except ImportError:
            raise NotImplementedError("SessionRegistry not yet implemented (Sprint 4.3)")

    async def get_active_sessions(self) -> List[Dict[str, Any]]:
        """
        Get all active sessions for this user.

        Returns:
            List of session data dicts
        """
        # Forward reference to Sprint 4.2
        try:
            from winterforge.plugins.session.manager import SessionProviderManager

            provider_id = SessionProviderManager.repository().order()[0]
            provider = SessionProviderManager.get(provider_id)
            return await provider.get_user_sessions(self.id)  # type: ignore
        except ImportError:
            raise NotImplementedError("SessionProviderManager not yet implemented (Sprint 4.2)")
