"""CLIResult trait - Standardized CLI command output."""

from typing import TYPE_CHECKING, Optional, Any

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class CLIResultTrait:
    """
    CLI result output trait.

    Provides standardized output formatting for CLI commands.
    CLI-facing methods return CLIResult Frags instead of strings.

    Fields:
        success: bool - Whether operation succeeded
        message: str - Human-readable output message
        result_frag_id: Optional[int] - Reference to created/modified Frag
        data: Optional[dict] - Additional structured data
    """

    @property
    def success(self) -> bool:
        """Get success status."""
        return self._success

    def set_success(self, success: bool) -> 'Frag':
        """Set success status."""
        self._success = success
        return self

    @property
    def message(self) -> str:
        """Get output message."""
        return self._message

    def set_message(self, message: str) -> 'Frag':
        """Set output message."""
        self._message = message
        return self

    @property
    def result_frag_id(self) -> Optional[int]:
        """Get reference to result Frag."""
        return self._result_frag_id

    def set_result_frag_id(self, frag_id: int) -> 'Frag':
        """Set reference to result Frag."""
        self._result_frag_id = frag_id
        return self

    @property
    def data(self) -> Optional[dict]:
        """Get additional structured data."""
        return self._data

    def set_data(self, data: dict) -> 'Frag':
        """Set additional structured data."""
        self._data = data
        return self

    def __str__(self) -> str:
        """Format for CLI output."""
        return self.message


# Register trait
from winterforge.plugins import FragTraitManager

FragTraitManager.register(
    'cli_result',
    CLIResultTrait,
    {
        'fields': {
            'success': {'type': 'BOOLEAN', 'default': False},
            'message': {'type': 'TEXT', 'default': ''},
            'result_frag_id': {'type': 'INTEGER'},
            'data': {'type': 'JSONB'}
        }
    }
)
