"""Ownable trait - Owner/creator association."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional
from winterforge.plugins import frag_trait
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['persistable'])
@root('ownable')
class OwnableTrait:
    """
    Owner/creator association trait.

    Provides owner_id field to associate a Frag with its owner/creator.
    Commonly used with Sessions and Tokens to track which user they belong to.

    Fields:
        owner_id: int - ID of owner Frag (typically a User)

    Example:
        session = Frag(affinities=['session'], traits=['tokenable', 'ownable'])
        session.set_token("abc123")
        session.set_owner(user_id=123)

        # Later, find sessions for a user
        if session.owner_id == user_id:
            print(f"Session belongs to user {user_id}")
    """

    # Private attributes
    _owner_id: Optional[int] = None

    @property
    def owner_id(self) -> Optional[int]:
        """Get owner ID."""
        return self._owner_id

    def set_owner(self, owner_id: int) -> Frag:
        """
        Set owner ID.

        Args:
            owner_id: Owner Frag ID (typically a User)

        Returns:
            Self for fluent chaining
        """
        self._owner_id = owner_id  # type: ignore
        return self  # type: ignore

    def has_owner(self) -> bool:
        """Check if owner is set."""
        return self._owner_id is not None

    async def get_owner(self) -> Optional[Frag]:
        """
        Load and return owner Frag.

        Uses identity resolution to load the owner Frag by ID.
        Typically returns a User Frag, but can be any Frag type.

        Returns:
            Owner Frag or None if not set

        Example:
            session = Frag(affinities=['session'], traits=['ownable'])
            session.set_owner(123)
            await session.save()

            # Later, load the owner
            user = await session.get_owner()
            if user:
                print(f"Session belongs to {user.username}")
        """
        if not self.has_owner():
            return None

        # Import here to avoid circular import
        from winterforge.frags.registries.frag_registry import FragRegistry

        # Try User registry first (most common case)
        from winterforge.frags.registries.user_registry import UserRegistry
        users = UserRegistry()
        user = await users.get(self.owner_id)
        if user:
            return user

        # Fallback to generic registry
        registry = FragRegistry({'affinities': [], 'traits': []})
        return await registry.get(self.owner_id)

    @property
    def owner(self) -> Optional[Frag]:
        """
        Deprecated: Use 'await get_owner()' instead.

        This property cannot call async methods and will always return None.
        """
        import warnings
        warnings.warn(
            "owner property is deprecated. Use 'await get_owner()' instead.",
            DeprecationWarning,
            stacklevel=2
        )
        return None
