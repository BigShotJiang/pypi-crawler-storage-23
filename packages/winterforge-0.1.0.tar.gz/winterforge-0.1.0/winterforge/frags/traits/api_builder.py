"""
ApiBuilder trait - auto-generates fluent API methods from scoped plugins.

Implements the Builder pattern for composite plugin systems by discovering
scoped subsidiary plugins and dynamically generating builder methods.

This trait replaces hardcoded builder methods with plugin-driven discovery,
following the principle: "Everything is discovered, nothing is hardcoded."

Architecture:
    - Uses __init_subclass__ to discover plugins at class definition time
    - Generates fluent methods from plugin signatures using extract_signature()
    - Method names derived from plugin IDs using derive_key_from_name()
    - Each method instantiates plugin, appends to collection, returns new instance

Example:
    class QueryRepository(ApiBuilderMixin):
        _api_builder_manager = 'winterforge.query_builders'
        _api_builder_collection = '_plugins'

        def __init__(self, plugins=None):
            self._plugins = plugins or []

    # Auto-generated methods from @query_builder() plugins:
    # - condition(field, value, operator)
    # - affinity(name)
    # - trait(name)
    # - join(left_field, right_field, alias, type)
    # - sort(field, direction)
    # - limit(limit)
    # - offset(offset)

Usage:
    query = QueryRepository()
    results = await (query
        .condition('status', 'published')
        .affinity('blog-post')
        .sort('created_at', 'DESC')
        .limit(10)
        .execute()
    )

Key Principles:
    - Data as configuration (plugins define behavior, not code)
    - Organic discovery (plugins discovered via manager)
    - Fluent interfaces (immutability via new instance returns)
    - Plugin-first architecture (everything discovered)
"""

from typing import Any, Callable, Dict, Optional, Type
from winterforge.utils.naming import derive_key_from_name
from winterforge.utils.signature import extract_signature


class ApiBuilderMixin:
    """
    Mixin that auto-generates fluent API methods from scoped plugins.

    Discovers scoped subsidiary plugins and creates builder methods
    dynamically based on plugin signatures using __init_subclass__.

    Configuration (set as class attributes):
        _api_builder_manager: Plugin manager ID to discover from
        _api_builder_collection: Attribute name holding plugin collection
        _api_builder_scope: Optional scope filter (default: None = all)

    Example:
        class QueryRepository(ApiBuilderMixin):
            _api_builder_manager = 'winterforge.query_builders'
            _api_builder_collection = '_plugins'

            def __init__(self, plugins=None):
                self._plugins = plugins or []
    """

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """
        Auto-generate builder methods when subclass is defined.

        This hook is called when a subclass of ApiBuilderMixin is created.
        It discovers plugins from the configured manager and generates
        fluent builder methods for each one.

        Args:
            **kwargs: Additional keyword arguments from class definition
        """
        super().__init_subclass__(**kwargs)

        # Get configuration from class attributes
        manager_id = getattr(cls, '_api_builder_manager', None)
        collection_attr = getattr(cls, '_api_builder_collection', None)
        scope_filter = getattr(cls, '_api_builder_scope', None)

        # Skip if not configured (base class or incomplete config)
        if not manager_id or not collection_attr:
            return

        # Discover plugins from manager
        from winterforge.plugins._discovery import PluginDiscoverer

        if not PluginDiscoverer.has_manager(manager_id):
            # Manager not yet registered - skip for now
            # Builder methods will be empty until manager exists
            return

        manager = PluginDiscoverer.get_manager(manager_id)

        # Get all plugins via repository (class-level access)
        repo = manager.repository()

        # Filter by scope if needed
        if scope_filter:
            # Get plugins that match the scope
            scope_map = getattr(manager, '_scope_map', {})
            scoped_ids = scope_map.get(scope_filter, set())
            plugins = {
                pid: plugin
                for pid, plugin in repo.items()
                if pid in scoped_ids
            }
        else:
            plugins = dict(repo.items())

        # Generate builder methods for each plugin
        for plugin_id, plugin_class in plugins.items():
            _generate_builder_method(
                cls,
                plugin_id,
                plugin_class,
                collection_attr
            )



def _generate_builder_method(
    target_class: type,
    plugin_id: str,
    plugin_class: type,
    collection_attr: str
) -> None:
    """
    Generate a single fluent builder method.

    Creates a method that:
    1. Accepts plugin's __init__ parameters
    2. Instantiates the plugin
    3. Appends to collection attribute
    4. Returns new instance of target_class

    Args:
        target_class: Class to add method to
        plugin_id: Plugin identifier
        plugin_class: Plugin class to instantiate
        collection_attr: Attribute name for plugin collection

    Example:
        # For ConditionPlugin(field, value, operator)
        # Generates:
        def condition(self, field, value, operator):
            plugin = ConditionPlugin(field, value, operator)
            new_plugins = self._plugins + [plugin]
            return type(self)(new_plugins, ...)
    """
    # Derive method name from plugin ID using naming utility
    method_name = derive_key_from_name(
        plugin_id,
        strip_suffixes=True,
        to_kebab_case=False
    ).replace('-', '_')

    # Check if method already exists (skip if hardcoded)
    if hasattr(target_class, method_name):
        return

    # Extract plugin signature for type annotations
    signature_metadata = extract_signature(plugin_class.__init__)

    # Remove 'self' from parameters
    params = {
        k: v for k, v in signature_metadata.items()
        if k != 'self'
    }

    # Create wrapper method with proper metadata
    builder_method = _create_wrapper_method(
        plugin_class,
        collection_attr,
        method_name
    )

    # Set qualname for proper introspection
    builder_method.__qualname__ = (
        f"{target_class.__qualname__}.{method_name}"
    )

    # Add type annotations from plugin signature
    builder_method.__annotations__ = {}
    for param_name, param_meta in params.items():
        if param_meta.type_hint:
            builder_method.__annotations__[param_name] = (
                param_meta.type_hint
            )

    builder_method.__annotations__['return'] = target_class

    # Attach method to class
    setattr(target_class, method_name, builder_method)


def _create_wrapper_method(
    plugin_class: type,
    collection_attr: str,
    method_name: str
) -> Callable:
    """
    Create a proper wrapper method with full metadata.

    This creates a function that has proper __name__, __doc__,
    __annotations__, and __qualname__ set correctly.

    Args:
        plugin_class: Plugin class to instantiate
        collection_attr: Attribute name for plugin collection
        method_name: Name for the generated method

    Returns:
        Wrapper function with proper metadata
    """
    def wrapper(self, *args, **kwargs) -> Any:
        """Auto-generated builder method."""
        # Instantiate plugin
        plugin = plugin_class(*args, **kwargs)

        # Get current collection
        current_collection = getattr(self, collection_attr, [])

        # Create new collection with plugin appended
        new_collection = current_collection + [plugin]

        # Get constructor signature to preserve other attributes
        constructor_params = extract_signature(self.__init__)

        # Build new instance kwargs
        new_kwargs = {}

        # Try to preserve common attributes
        for param_name in constructor_params:
            if param_name == 'self':
                continue

            # Map collection attr to new collection
            if param_name == collection_attr.lstrip('_'):
                new_kwargs[param_name] = new_collection
            else:
                # Preserve existing attributes
                attr_name = (
                    f"_{param_name}" if not param_name.startswith('_')
                    else param_name
                )
                if hasattr(self, attr_name):
                    new_kwargs[param_name] = getattr(self, attr_name)

        # Create and return new instance
        return type(self)(**new_kwargs)

    # Set proper metadata
    wrapper.__name__ = method_name

    # Build docstring from plugin
    plugin_doc = getattr(plugin_class, '__doc__', '').strip()
    first_line = (
        plugin_doc.split('\n')[0] if plugin_doc
        else f"Add {plugin_class.__name__}"
    )

    wrapper.__doc__ = f"""
        {first_line}

        Returns:
            New instance with {plugin_class.__name__} appended

        Auto-generated from {plugin_class.__name__}.
        """

    return wrapper


__all__ = ['ApiBuilderMixin']
