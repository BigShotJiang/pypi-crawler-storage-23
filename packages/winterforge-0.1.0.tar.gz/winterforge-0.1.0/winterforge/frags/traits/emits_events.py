"""
Event emission trait.

Enables Frags to emit events with automatic ID extraction,
Frag loading, and dispatch to listeners.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional, Dict, Any

from winterforge.plugins.decorators import frag_trait, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@frag_trait(requires=['persistable'])
@root('emits-events')
class EmitsEventsTrait:
    """
    Enable event emission for Frag.

    Provides emit() method that:
    - Validates event type exists (via EventProviderManager)
    - Creates Event Frag with typed context
    - Extracts IDs from Frag references automatically
    - Dispatches to listeners with loaded Frags
    - Returns Event Frag for inspection

    Event context can contain Frags - IDs are extracted and stored,
    then Frags are reloaded during dispatch so listeners receive
    loaded instances.

    Example:
        user = Frag(traits=['emits_events', 'titled'])
        admin = await FragRegistry.get(456)

        event = await user.emit(
            'user.save',
            user=user,           # Frag stored as ID, reloaded for dispatch
            modified_by=admin,   # Frag stored as ID, reloaded for dispatch
            email='user@example.com'  # Non-Frag stored directly
        )

        # Listeners receive loaded Frags:
        @event_listener(events=['user.save'])
        async def audit(event: Frag, source: Frag):
            context = event.get_loaded_context()
            user = context['user']  # Loaded Frag, not ID
            admin = context['modified_by']  # Loaded Frag, not ID
    """

    async def emit(self, event_type: str, **kwargs: Any) -> 'Frag':
        """
        Emit event with automatic Frag handling.

        Context can contain Frags - IDs extracted automatically.
        Listeners receive loaded Frags in context.

        Args:
            event_type: Event path (e.g., 'user.save')
            **kwargs: Event context (can include Frags)

        Returns:
            Event Frag (saved to storage)

        Raises:
            ValueError: If event_type not defined by any provider

        Example:
            user = Frag(traits=['emits_events'])
            await user.emit('user.save',
                user=user,
                email='user@example.com',
                created_at=datetime.now()
            )
        """
        from winterforge.plugins.events.provider_manager import (
            EventProviderManager,
        )
        from winterforge.plugins.events.dispatcher_manager import (
            EventDispatcherManager,
        )
        from winterforge.frags.base import Frag

        # Validate event exists
        if not EventProviderManager.validate(event_type):
            raise ValueError(
                f"Event '{event_type}' not defined by any provider. "
                f"Define with @event_provider decorator first."
            )

        # Process context: extract IDs from Frags
        stored_context: Dict[str, Any] = {}
        frag_refs: Dict[str, bool] = {}  # Track which keys were Frags

        for key, value in kwargs.items():
            if isinstance(value, Frag):
                # Store ID, remember this was a Frag
                stored_context[key] = value.id
                frag_refs[key] = True
            else:
                stored_context[key] = value

        # Create Event Frag
        event = Frag(affinities=['event'], traits=['timestamped'])
        event.set('type', event_type)
        event.set('fid', self.id)  # Store source ID
        event.set('context', stored_context)  # Store IDs
        event.set('_frag_refs', frag_refs)  # Remember which were Frags

        # Save event
        await event.save()

        # Load Frags for dispatch
        loaded_context = await self._load_context_frags(event)
        event._loaded_context = loaded_context  # Attach loaded context

        # Dispatch with loaded Frags
        await EventDispatcherManager.dispatch(event, self)

        return event

    async def _load_context_frags(self, event: 'Frag') -> Dict[str, Any]:
        """
        Load Frag references from context.

        Reloads Frags that were stored as IDs so listeners receive
        loaded instances instead of IDs.

        Args:
            event: Event Frag

        Returns:
            Context dict with loaded Frags (not IDs)
        """
        from winterforge.frags.registries.frag_registry import FragRegistry

        context = event.get('context', {})
        frag_refs = event.get('_frag_refs', {})

        loaded: Dict[str, Any] = {}

        for key, value in context.items():
            if frag_refs.get(key):
                # This was a Frag - reload it
                loaded[key] = await FragRegistry.get(value)
            else:
                loaded[key] = value

        return loaded

    async def get_source(self) -> 'Frag':
        """
        Get source Frag (loaded).

        Only works on Event Frags (Frags with 'event' affinity).

        Returns:
            Source Frag that emitted this event

        Raises:
            ValueError: If not an Event Frag (no fid field)

        Example:
            # Inside event listener
            async def my_listener(event: Frag, source: Frag):
                # source is passed directly, but can also get via:
                source = await event.get_source()
        """
        from winterforge.frags.registries.frag_registry import FragRegistry

        fid = self.get('fid')
        if not fid:
            raise ValueError(
                "Not an Event Frag (no fid). "
                "Only Event Frags can call get_source()."
            )

        return await FragRegistry.get(fid)

    def get_loaded_context(self) -> Dict[str, Any]:
        """
        Get context with loaded Frags.

        During dispatch, Frag IDs are loaded and attached as
        _loaded_context. This returns the loaded version.

        If called before dispatch or outside event flow, returns
        stored context (with IDs, not loaded Frags).

        Returns:
            Context dict with loaded Frags (not IDs)

        Example:
            @event_listener(events=['user.save'])
            async def audit(event: Frag, source: Frag):
                context = event.get_loaded_context()
                user = context['user']  # Loaded Frag
                email = context['email']  # Regular value
                print(f"User {user.id}: {email}")
        """
        # If dispatch loaded context, return it
        if hasattr(self, '_loaded_context'):
            return self._loaded_context

        # Otherwise return stored context (IDs)
        return self.get('context', {})
