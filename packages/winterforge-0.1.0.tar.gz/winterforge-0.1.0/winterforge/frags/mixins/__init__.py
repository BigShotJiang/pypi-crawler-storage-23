"""Mixins for Frag-like objects."""

from winterforge.frags.mixins.trait_mixin import TraitMixin

__all__ = ['TraitMixin']
