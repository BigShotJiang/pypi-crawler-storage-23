"""Universal trait application mixin.

Makes any class trait-capable. Traits apply themselves given the target
object and full trait context (including modifier traits).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import List


class TraitMixin:
    """
    Universal trait application mixin.

    Classes that extend TraitMixin can use the trait system by:
    1. Storing traits in self._traits
    2. Calling self._apply_traits() after initialization

    Traits apply themselves via their apply(obj, all_traits) method.
    Modifier traits (for_collections, for_async, etc.) provide context
    hints that other traits can detect and adapt to.

    Example:
        class MyClass(TraitMixin):
            def __init__(self, traits=None):
                self._traits = traits or []
                self._apply_traits()

        # Use with modifiers
        obj = MyClass(traits=['for_collections', 'compilable'])
        # compilable trait sees for_collections and adapts
    """

    def _apply_traits(self) -> None:
        """
        Apply all traits to self.

        Each trait applies itself via its apply() classmethod, receiving
        both the target object and the full list of traits (for context).

        Modifier traits (starting with 'for_') are processed like any other
        trait - they're just regular traits that typically provide signals
        to other traits rather than direct functionality.
        """
        from winterforge.frags.traits._manager import FragTraitManager
        import warnings

        traits = getattr(self, '_traits', [])

        for trait_id in traits:
            try:
                trait_class = FragTraitManager.get(trait_id)

                # Trait applies itself, given full context
                if hasattr(trait_class, 'apply'):
                    try:
                        trait_class.apply(self, all_traits=traits)
                    except Exception as e:
                        # Trait application failed - warn but continue
                        warnings.warn(
                            f"Failed to apply trait '{trait_id}': {e}",
                            RuntimeWarning,
                            stacklevel=2
                        )
                else:
                    # Fallback: Old-style trait without self-application
                    # (for backward compatibility during transition)
                    self._apply_trait_legacy(trait_id)

            except KeyError:
                # Trait not registered - might be a forward declaration
                # or a modifier trait that doesn't have implementation yet
                # Only warn if it doesn't look like a modifier
                if not trait_id.startswith('for_'):
                    warnings.warn(
                        f"Trait '{trait_id}' not registered in FragTraitManager",
                        RuntimeWarning,
                        stacklevel=2
                    )

    def _apply_trait_legacy(self, trait_id: str) -> None:
        """
        Legacy trait application for backward compatibility.

        This supports traits that haven't been updated to the new
        self-application pattern yet. Will be removed once all traits
        are migrated.
        """
        from winterforge.frags.traits._manager import FragTraitManager

        trait_or_instance = FragTraitManager.get(trait_id)

        # Handle both classes and instances
        if isinstance(trait_or_instance, type):
            # It's a class - instantiate it
            instance = trait_or_instance()
        else:
            # It's already an instance
            instance = trait_or_instance

        # Old pattern: Copy attributes from instance
        for method_name in dir(instance):
            if method_name.startswith('_'):
                continue

            attr = getattr(instance, method_name)
            if callable(attr):
                setattr(self, method_name, attr)
