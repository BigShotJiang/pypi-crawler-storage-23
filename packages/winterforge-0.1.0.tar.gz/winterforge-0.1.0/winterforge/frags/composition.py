"""Composition value object - immutable composition descriptor."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Union, TYPE_CHECKING, List

if TYPE_CHECKING:
    from typing import Iterable


@dataclass(frozen=True)
class Composition:
    """
    Immutable composition value object.

    Composition describes the identity and capabilities of a Frag:
    - Affinities: Polymorphic identity (replaces rigid type hierarchies)
    - Traits: Schema/API components (what it CAN DO)

    NOTE: Aliases are NOT part of composition. They are categorical
    identifiers (like external IDs) and are treated separately, similar
    to Frag.id and Frag.uuid.

    Frozen dataclass ensures immutability. All operations return new
    instances.

    Used as inverted factory for creating compositionally consistent
    primitives (Frags, Registries, Manifests).

    **API Convention**: Pass lists, stored as tuples internally for immutability.

    Examples:
        # Empty composition
        comp = Composition()

        # With values (lists are auto-converted to tuples)
        comp = Composition(
            affinities=['admin', 'user'],
            traits=['persistable', 'titled']
        )

        # Inverted factory pattern
        template = Composition(affinities=['article'], traits=['titled'])
        frag1 = Frag(template, title='First Post')
        frag2 = Frag(template, title='Second Post')
        registry = Registry(template)

        # Set operations
        common = Composition.intersection([comp1, comp2, comp3])
        combined = Composition.union([comp1, comp2])
        diff = comp1.diff(comp2)

        # Fluent operations
        comp = Composition().with_affinity('admin').with_trait('persistable')

        # Comparison
        if comp1 == comp2:
            print("Same composition!")
    """

    affinities: Union[tuple[str, ...], list[str]] = field(default_factory=list)
    traits: Union[tuple[str, ...], list[str]] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Normalize inputs to immutable tuples (implementation detail)."""
        # Always convert to tuples for internal immutability
        if not isinstance(self.affinities, tuple):
            object.__setattr__(self, 'affinities', tuple(self.affinities))
        if not isinstance(self.traits, tuple):
            object.__setattr__(self, 'traits', tuple(self.traits))

    # ========== Checks ==========

    def has_affinity(self, affinity: str) -> bool:
        """
        Check if affinity exists.

        Args:
            affinity: Affinity to check

        Returns:
            True if affinity exists
        """
        return affinity in self.affinities

    def has_trait(self, trait: str) -> bool:
        """
        Check if trait exists.

        Args:
            trait: Trait to check

        Returns:
            True if trait exists
        """
        return trait in self.traits


    # ========== Immutable Operations ==========

    def with_affinity(self, affinity: str) -> 'Composition':
        """
        Add affinity (returns new instance).

        Args:
            affinity: Affinity to add

        Returns:
            New Composition with affinity added
        """
        if affinity in self.affinities:
            return self
        return Composition(
            affinities=tuple(sorted(set(self.affinities) | {affinity})),
            traits=self.traits
        )

    def without_affinity(self, affinity: str) -> 'Composition':
        """
        Remove affinity (returns new instance).

        Args:
            affinity: Affinity to remove

        Returns:
            New Composition with affinity removed
        """
        if affinity not in self.affinities:
            return self
        return Composition(
            affinities=tuple(a for a in self.affinities if a != affinity),
            traits=self.traits
        )

    def with_trait(self, trait: str) -> 'Composition':
        """
        Add trait (returns new instance).

        Args:
            trait: Trait to add

        Returns:
            New Composition with trait added
        """
        if trait in self.traits:
            return self
        return Composition(
            affinities=self.affinities,
            traits=tuple(sorted(set(self.traits) | {trait}))
        )

    def without_trait(self, trait: str) -> 'Composition':
        """
        Remove trait (returns new instance).

        Args:
            trait: Trait to remove

        Returns:
            New Composition with trait removed
        """
        if trait not in self.traits:
            return self
        return Composition(
            affinities=self.affinities,
            traits=tuple(t for t in self.traits if t != trait)
        )


    # ========== Set Operations ==========

    @classmethod
    def intersection(cls, compositions: 'Iterable[Composition]') -> 'Composition':
        """
        Calculate common composition (intersection).

        Args:
            compositions: Iterable of Compositions

        Returns:
            New Composition with only common elements

        Example:
            common = Composition.intersection([comp1, comp2, comp3])
        """
        compositions_list = list(compositions)
        if not compositions_list:
            return cls()

        # Start with first composition
        common_affinities = set(compositions_list[0].affinities)
        common_traits = set(compositions_list[0].traits)

        # Intersect with remaining compositions
        for comp in compositions_list[1:]:
            common_affinities &= set(comp.affinities)
            common_traits &= set(comp.traits)

        return cls(
            affinities=tuple(sorted(common_affinities)),
            traits=tuple(sorted(common_traits))
            # Note: Aliases not included in intersection (no clear semantics)
        )

    @classmethod
    def union(cls, compositions: 'Iterable[Composition]') -> 'Composition':
        """
        Calculate combined composition (union).

        Args:
            compositions: Iterable of Compositions

        Returns:
            New Composition with all elements

        Example:
            combined = Composition.union([comp1, comp2, comp3])
        """
        all_affinities: set[str] = set()
        all_traits: set[str] = set()

        for comp in compositions:
            all_affinities.update(comp.affinities)
            all_traits.update(comp.traits)

        return cls(
            affinities=tuple(sorted(all_affinities)),
            traits=tuple(sorted(all_traits))
        )

    def diff(self, other: 'Composition') -> 'Composition':
        """
        Calculate difference (elements in self but not other).

        Args:
            other: Composition to compare against

        Returns:
            New Composition with differences

        Example:
            unique = comp1.diff(comp2)
        """
        diff_affinities = set(self.affinities) - set(other.affinities)
        diff_traits = set(self.traits) - set(other.traits)

        return Composition(
            affinities=tuple(sorted(diff_affinities)),
            traits=tuple(sorted(diff_traits))
        )

    # ========== Serialization ==========

    def to_dict(self) -> dict[str, list[str]]:
        """
        Convert to dict (for serialization/storage).

        Returns:
            Dict with affinities and traits as mutable lists

        Example:
            data = comp.to_dict()
            # {'affinities': [...], 'traits': [...]}
        """
        return {
            'affinities': list(self.affinities),
            'traits': list(self.traits)
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'Composition':
        """
        Create from dict (for deserialization).

        Args:
            data: Dict with affinities and traits keys

        Returns:
            New Composition

        Example:
            comp = Composition.from_dict({
                'affinities': ['admin'],
                'traits': ['persistable']
            })
        """
        return cls(
            affinities=data.get('affinities', []),
            traits=data.get('traits', [])
        )

    # ========== Introspection ==========

    def is_empty(self) -> bool:
        """
        Check if composition is empty.

        Returns:
            True if no affinities or traits
        """
        return (
            len(self.affinities) == 0 and
            len(self.traits) == 0
        )

    def __repr__(self) -> str:
        """String representation."""
        parts = []
        if self.affinities:
            parts.append(f"affinities={list(self.affinities)}")
        if self.traits:
            parts.append(f"traits={list(self.traits)}")

        if not parts:
            return "Composition()"

        return f"Composition({', '.join(parts)})"

    # ========== Equality (auto-generated by @dataclass) ==========
    # __eq__ is automatically implemented by frozen dataclass
    # __hash__ is automatically implemented by frozen dataclass
