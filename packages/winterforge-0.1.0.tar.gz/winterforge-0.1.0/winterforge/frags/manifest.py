"""
Manifest - Immutable collection for functional operations on Frags.

Manifests are "shipping manifests" - snapshots of Frag collections with
functional transformation capabilities. Used for query results, form data,
batch validation, and transient working sets.

All operations return new instances (immutable pattern).
"""

from __future__ import annotations

from typing import (
    Iterator,
    Callable,
    Any,
    Optional,
    TYPE_CHECKING,
    Union,
    List
)

from winterforge.frags.mixins import TraitMixin

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.plugins._protocols.storage import StorageBackend
    from winterforge.plugins.query._repository import QueryRepository


class Manifest(TraitMixin):
    """
    Immutable collection for functional operations on Frags.

    Manifests are "shipping manifests" - snapshots listing Frag contents
    with functional transformation capabilities.

    Used for:
    - Query results
    - Form data processing
    - Batch validation
    - Transient working sets

    All operations return new instances (immutable).

    Examples:
        # From query
        users = await UserRegistry().query().execute()
        # users is Manifest

        # Functional operations
        admins = users.resolve(lambda f: 'admin' in f.affinities)
        active_count = users.resolve_all(
            lambda acc, f: acc + 1 if f.active else acc,
            initial=0
        )

        # Slicing (returns new Manifest)
        first_ten = users[:10]

        # Converting
        user_dict = users.toDict('username')
        user_list = list(users)

        # Further querying
        active_users = await users.query().condition(
            'active',
            True
        ).execute()
    """

    def __init__(
        self,
        frags: Union[list['Frag'], dict[Any, 'Frag']],
        storage: Optional['StorageBackend'] = None,
        traits: Optional[List[str]] = None
    ):
        """
        Initialize manifest.

        Args:
            frags: List or dict of Frags
            storage: Storage backend (for query() method)
            traits: Optional traits to apply (e.g., compilable, renderable)
        """
        if isinstance(frags, dict):
            frags = list(frags.values())

        self._frags = tuple(frags)  # Immutable
        self._storage = storage or self._get_storage()
        self._composition = self._calculate_common_composition()
        self._traits = traits or []

        # Apply traits after initialization (from TraitMixin)
        self._apply_traits()

    # ========== Python Protocols ==========

    def __iter__(self) -> Iterator['Frag']:
        """
        Iterate over frags.

        Enables:
            for frag in manifest:
                ...
        """
        return iter(self._frags)

    def __len__(self) -> int:
        """
        Number of frags.

        Enables:
            len(manifest)
        """
        return len(self._frags)

    def __getitem__(
        self,
        index: Union[int, slice]
    ) -> Union['Frag', 'Manifest']:
        """
        Get frag by index or slice.

        Enables:
            manifest[0]      # First frag
            manifest[-1]     # Last frag
            manifest[1:5]    # Slice (returns new Manifest)

        Args:
            index: Integer index or slice

        Returns:
            Frag for integer index, Manifest for slice
        """
        if isinstance(index, slice):
            # Preserve traits when slicing
            return Manifest(
                self._frags[index],
                storage=self._storage,
                traits=self._traits
            )
        return self._frags[index]

    def __bool__(self) -> bool:
        """
        Truth value - False if empty, True otherwise.

        Enables:
            if manifest:
                ...
        """
        return len(self._frags) > 0

    # ========== Functional Operations ==========

    def map(
        self,
        key: Union[str, list[str], Callable[['Frag'], Any]] = 'id',
        value: Optional[Callable[['Frag'], Any]] = None
    ) -> dict[Any, Any]:
        """
        Transform frags to dict with custom keys/values.

        Args:
            key: Field name, list of keys, or callable for keys
            value: Callable to transform each frag to value

        Returns:
            Dict with transformed keys and values

        Examples:
            # Map by field name (default: 'id')
            by_id = manifest.map()  # {1: frag1, 2: frag2, ...}
            by_username = manifest.map('username')

            # Map with custom key callable
            by_title = manifest.map(lambda f: f.title.lower())

            # Map with value transformation
            titles = manifest.map('id', lambda f: f.title)
            # {1: "Post 1", 2: "Post 2", ...}

            # Map with list of keys
            result = manifest.map(['a', 'b', 'c'])
            # {'a': frag1, 'b': frag2, 'c': frag3}
        """
        result = {}

        # Handle list of keys
        if isinstance(key, list):
            if len(key) != len(self._frags):
                raise ValueError(
                    f"Key list length ({len(key)}) must match "
                    f"manifest length ({len(self._frags)})"
                )
            for k, frag in zip(key, self._frags):
                if value is None:
                    result[k] = frag
                else:
                    result[k] = value(frag)
            return result

        # Handle callable or string key
        for frag in self._frags:
            # Generate key
            if callable(key):
                k = key(frag)
            else:
                k = getattr(frag, key)

            # Generate value
            if value is None:
                result[k] = frag
            else:
                result[k] = value(frag)

        return result

    def walk(self, func: Callable[['Frag'], None]) -> 'Manifest':
        """
        Execute callable on each frag (side effects).

        Returns self for chaining (manifest is immutable so no
        modification occurs, but allows fluent interface).

        Args:
            func: Callable receiving each frag

        Returns:
            Self for chaining

        Example:
            manifest.walk(lambda f: print(f.title))
        """
        for frag in self._frags:
            func(frag)
        return self

    def reduce(
        self,
        func: Callable[[Any, 'Frag'], Any],
        initial: Any = None
    ) -> Any:
        """
        Reduce manifest to single value.

        Args:
            func: Reducer function(accumulated_value, frag) -> new_value
            initial: Starting value for accumulation

        Returns:
            Final accumulated value

        Examples:
            # Sum IDs
            total = manifest.reduce(lambda acc, f: acc + f.id, initial=0)

            # Collect titles
            titles = manifest.reduce(
                lambda acc, f: acc + [f.title],
                initial=[]
            )

            # Find max created_at
            latest = manifest.reduce(
                lambda acc, f: max(acc, f.created_at),
                initial=None
            )
        """
        from functools import reduce as functools_reduce

        if initial is not None:
            return functools_reduce(func, self._frags, initial)
        return functools_reduce(func, self._frags)

    # ========== Resolution Operations ==========
    # (Matches plugin Repository API)

    def resolve(self, predicate: Callable[['Frag'], bool]) -> Optional['Frag']:
        """
        First-match resolution using predicate.

        Tries each frag in order until predicate returns True.

        Args:
            predicate: Function that returns True if frag matches

        Returns:
            First matching frag, or None if no match

        Examples:
            # Find first admin
            admin = manifest.resolve(lambda f: 'admin' in f.affinities)

            # Find first active user
            active = manifest.resolve(lambda f: f.active)

            # Find by username
            alice = manifest.resolve(lambda f: f.username == 'alice')
        """
        for frag in self._frags:
            if predicate(frag):
                return frag
        return None

    def resolve_all(
        self,
        reducer: Callable[[Any, 'Frag'], Any],
        initial: Any = None
    ) -> Any:
        """
        Chain of responsibility - accumulate through all frags in order.

        Passes each frag through the reducer function, allowing each to
        transform/override/merge the accumulated value.

        Args:
            reducer: Function(accumulated_value, frag) -> new_value
            initial: Starting value for accumulation

        Returns:
            Final accumulated value after passing through all frags

        Examples:
            # Count matching frags
            admin_count = manifest.resolve_all(
                lambda acc, f: acc + 1 if 'admin' in f.affinities else acc,
                initial=0
            )

            # Collect IDs
            ids = manifest.resolve_all(
                lambda acc, f: acc + [f.id],
                initial=[]
            )

            # Last-wins config override
            value = manifest.resolve_all(
                lambda val, f: f.get_config('key', val) if hasattr(f, 'get_config') else val,
                initial=None
            )

            # Build dict
            by_username = manifest.resolve_all(
                lambda acc, f: {**acc, f.username: f},
                initial={}
            )
        """
        result = initial
        for frag in self._frags:
            result = reducer(result, frag)
        return result

    # ========== Immutable Operations ==========

    def with_before(
        self,
        items: Union['Frag', 'Manifest']
    ) -> 'Manifest':
        """
        Prepend frag(s) to manifest.

        Args:
            items: Frag or Manifest to prepend

        Returns:
            New Manifest with items prepended

        Example:
            new_manifest = manifest.with_before(admin_frag)
        """
        if isinstance(items, Manifest):
            items = list(items)
        elif not isinstance(items, (list, tuple)):
            items = [items]

        new_frags = list(items) + list(self._frags)
        return Manifest(new_frags, storage=self._storage, traits=self._traits)

    def with_after(
        self,
        items: Union['Frag', 'Manifest']
    ) -> 'Manifest':
        """
        Append frag(s) to manifest.

        Args:
            items: Frag or Manifest to append

        Returns:
            New Manifest with items appended

        Example:
            new_manifest = manifest.with_after(guest_frag)
        """
        if isinstance(items, Manifest):
            items = list(items)
        elif not isinstance(items, (list, tuple)):
            items = [items]

        new_frags = list(self._frags) + list(items)
        return Manifest(new_frags, storage=self._storage, traits=self._traits)

    def diff(self, other: 'Manifest') -> 'Manifest':
        """
        Return frags in self but not in other.

        Args:
            other: Manifest to compare against

        Returns:
            New Manifest containing difference

        Example:
            original = Manifest([frag1, frag2, frag3, frag4])
            filtered = original[:2]  # [frag1, frag2]
            removed = original.diff(filtered)  # [frag3, frag4]
        """
        other_ids = {f.id for f in other}
        diff_frags = [f for f in self._frags if f.id not in other_ids]
        return Manifest(diff_frags, storage=self._storage, traits=self._traits)

    def sorted(
        self,
        key: Optional[Callable[['Frag'], Any]] = None,
        reverse: bool = False
    ) -> 'Manifest':
        """
        Return sorted Manifest.

        Args:
            key: Optional callable for sort key
            reverse: Sort in descending order if True

        Returns:
            New sorted Manifest

        Examples:
            # Sort by ID (default)
            ordered = manifest.sorted()

            # Sort by title
            by_title = manifest.sorted(key=lambda f: f.title)

            # Sort by created time (newest first)
            recent = manifest.sorted(
                key=lambda f: f.created_on or '',
                reverse=True
            )

            # Sort by multiple keys
            multi_sort = manifest.sorted(
                key=lambda f: (f.affinity, f.title)
            )
        """
        sorted_frags = sorted(self._frags, key=key, reverse=reverse)
        return Manifest(sorted_frags, storage=self._storage, traits=self._traits)

    # ========== Conversion ==========

    def toDict(
        self,
        key: Union[str, Callable[['Frag'], Any]] = 'id'
    ) -> dict[Any, 'Frag']:
        """
        Convert to dict keyed by field or callable.

        Args:
            key: Field name or callable for generating keys

        Returns:
            Dict mapping keys to Frags

        Examples:
            # By ID (default)
            by_id = manifest.toDict()
            # {1: frag1, 2: frag2, ...}

            # By username
            by_username = manifest.toDict('username')
            # {'alice': frag1, 'bob': frag2, ...}

            # By custom callable
            by_title = manifest.toDict(lambda f: f.title.lower())
            # {'post 1': frag1, 'post 2': frag2, ...}
        """
        if callable(key):
            return {key(f): f for f in self._frags}
        return {getattr(f, key): f for f in self._frags}

    # ========== Utils ==========

    def first(self) -> Optional['Frag']:
        """
        Get first Frag or None if empty.

        Returns:
            First Frag or None

        Example:
            # Instead of: frags[0] if frags else None
            user = await storage.query().condition('username', 'alice').first()

            # Chaining
            if user := results.first():
                print(f"Found: {user.title}")
        """
        return self._frags[0] if self._frags else None

    def is_empty(self) -> bool:
        """
        Check if manifest is empty.

        Returns:
            True if no frags, False otherwise

        Example:
            if manifest.is_empty():
                print("No results")
        """
        return len(self._frags) == 0

    # ========== QueryBuilder Integration ==========

    def query(self) -> 'QueryRepository':
        """
        Return QueryRepository for further querying.

        System intelligently decides execution strategy:
        - In-memory filtering if conditions simple
        - Back to database for complex queries
        - Index optimization when available

        Returns:
            QueryRepository configured for this manifest

        Examples:
            # Query from registry
            users = UserRegistry()
            admins = await users.query().condition(
                'affinities',
                'admin',
                QueryOperator.CONTAINS
            ).execute()
            # admins is Manifest

            # Further querying (system decides: memory or DB)
            active_admins = await admins.query().condition(
                'active',
                True
            ).execute()
            # Returns new Manifest
        """
        from winterforge.plugins.query._repository import QueryRepository
        from winterforge.plugins.query._operators import QueryOperator

        qb = QueryRepository(storage=self._storage)

        # Pass manifest as data source for intelligent execution
        qb._data_source = self

        # Pre-configure with composition filters
        for affinity in self._composition.get('affinities', []):
            qb = qb.condition(
                'affinities',
                affinity,
                QueryOperator.CONTAINS
            )
        for trait in self._composition.get('traits', []):
            qb = qb.condition(
                'traits',
                trait,
                QueryOperator.CONTAINS
            )

        # Limit to manifest IDs if not empty
        if self._frags:
            frag_ids = [f.id for f in self._frags]
            # TODO: Need QueryOperator.IN for ID filtering
            # qb = qb.condition('id', frag_ids, QueryOperator.IN)

        return qb

    # ========== Composition Analysis ==========

    def _calculate_common_composition(self) -> dict[str, list[str]]:
        """
        Calculate composition shared by ALL frags (intersection).

        Returns:
            Dict with 'affinities' and 'traits' keys containing
            lists of common values

        Examples:
            # All frags have ['user', 'admin']
            # composition = {'affinities': ['admin', 'user'], 'traits': [...]}

            # Mixed frags with no common affinities
            # composition = {'affinities': [], 'traits': [...]}
        """
        if not self._frags:
            return {'affinities': [], 'traits': []}

        # Start with first frag's composition
        common_affinities = set(self._frags[0].affinities)
        common_traits = set(self._frags[0].traits)

        # Intersect with remaining frags
        for frag in self._frags[1:]:
            common_affinities &= set(frag.affinities)
            common_traits &= set(frag.traits)

        return {
            'affinities': sorted(list(common_affinities)),
            'traits': sorted(list(common_traits))
        }

    def _get_storage(self) -> Optional['StorageBackend']:
        """
        Get default storage backend.

        Returns:
            Default storage or None
        """
        try:
            from winterforge.frags import get_storage
            return get_storage()
        except ImportError:
            return None

    # ========== Repr ==========

    def __repr__(self) -> str:
        """String representation."""
        return f"Manifest({len(self._frags)} frags)"
