"""Helper functions for field prompting and interaction.

Enables fields to prompt for their own values based on metadata.
"""

import getpass
from typing import Tuple, Any
from winterforge.frags import Frag
from winterforge.plugins.validators import validate_input


async def prompt_for_field(
    field: Frag,
    interactive: bool = True,
    default_value: Any = None
) -> Any:
    """
    Prompt user for field value using field's metadata.

    Reads metadata from field Frag:
    - prompt: Prompt text to display
    - validators: Comma-separated validator IDs
    - help-text: Help text
    - required: Whether field is required

    Args:
        field: Field definition Frag with metadata
        interactive: Whether to prompt interactively
        default_value: Default value if not interactive

    Returns:
        User input value (validated)

    Example:
        email_field = await fields.ensure_field(
            'email',
            str,
            prompt='Email',
            validators=['required', 'email']
        )
        email = await prompt_for_field(email_field)
    """
    # Extract metadata from aliases
    prompt_text = field.get_alias('prompt') or field.slug
    help_text = field.get_alias('help-text')
    validators_str = field.get_alias('validators') or ''
    validators = [v.strip() for v in validators_str.split(',') if v.strip()]
    is_required = field.get_alias('required') == 'true'

    # Check for password field
    is_password = 'password' in field.slug.lower()

    # Non-interactive mode
    if not interactive:
        if default_value is not None:
            return default_value
        if hasattr(field, 'get_default'):
            return field.get_default()
        return None

    # Interactive prompting
    if help_text:
        print(f"  ({help_text})")

    # Get default value
    default = None
    if hasattr(field, 'get_default'):
        default = field.get_default()

    # Prompt text with default
    if default is not None:
        prompt_display = f"{prompt_text} [{default}]"
    else:
        prompt_display = f"{prompt_text}"

    # Validation loop
    while True:
        # Get input
        if is_password:
            value = getpass.getpass(f"{prompt_display}: ")
        else:
            value = input(f"{prompt_display}: ").strip()

        # Use default if empty
        if not value and default is not None:
            value = str(default)

        # Validate
        if validators:
            is_valid, error = validate_input(
                value,
                validators,
                prompt_text
            )
            if not is_valid:
                print(f"✗ {error}")
                continue

        # Check required
        if is_required and not value:
            print(f"✗ {prompt_text} is required")
            continue

        break

    return value


async def prompt_for_fields(
    frag: Frag,
    field_names: list = None,
    interactive: bool = True
) -> dict:
    """
    Prompt for multiple field values.

    Args:
        frag: Frag containing field references
        field_names: List of field names to prompt for (None = all)
        interactive: Whether to prompt interactively

    Returns:
        Dict of {field_name: value}

    Example:
        user = Frag(affinities=['user'], traits=['userable'])
        values = await prompt_for_fields(user, ['username', 'email'])
    """
    from winterforge.frags.registries.field_registry import FieldRegistry
    from winterforge.frags.traits.persistable import get_storage

    fields_registry = FieldRegistry()
    values = {}

    # Get field references from Frag
    if hasattr(frag, 'get_field_references'):
        field_ref_ids = frag.get_field_references()

        # Load Field Frags from storage
        storage = get_storage()
        if not storage:
            return values

        for field_id in field_ref_ids:
            # Load field Frag from storage
            field_frag = await storage.load(field_id)
            if not field_frag:
                continue

            field_slug = field_frag.slug

            # Skip if not in requested field_names
            if field_names and field_slug not in field_names:
                continue

            # Prompt for value
            value = await prompt_for_field(
                field_frag,
                interactive=interactive
            )
            values[field_slug] = value

    return values


def get_field_metadata(field: Frag) -> dict:
    """
    Extract metadata from field Frag.

    Args:
        field: Field definition Frag

    Returns:
        Dict with metadata keys:
        - prompt: Prompt text
        - validators: List of validator IDs
        - help_text: Help text
        - required: Boolean
        - default: Default value

    Example:
        metadata = get_field_metadata(email_field)
        print(metadata['prompt'])  # "Email address"
    """
    validators_str = field.get_alias('validators') or ''
    validators = [v.strip() for v in validators_str.split(',') if v.strip()]

    return {
        'prompt': field.get_alias('prompt') or field.slug,
        'validators': validators,
        'help_text': field.get_alias('help-text'),
        'required': field.get_alias('required') == 'true',
        'default': field.get_default() if hasattr(field, 'get_default') else None,
    }
