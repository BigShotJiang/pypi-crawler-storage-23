"""
Materialization - create primitive Frags from execution scope.

Dynamic materialization that discovers all registered primitive types
and materializes them automatically.
"""

from __future__ import annotations

from typing import TYPE_CHECKING
import inspect

if TYPE_CHECKING:
    from winterforge.frags import Manifest


async def materialize_primitives() -> dict[str, 'Manifest']:
    """
    Materialize all registered primitive types as Frags.

    Dynamically discovers all primitive types registered with
    PrimitiveTypeManager and materializes each one. This makes
    primitives (traits, affinities, etc.) queryable as first-class
    Frags instead of just strings.

    Returns:
        Dict mapping type IDs to Manifests of created Frags

    Example:
        # After plugin discovery (primitives auto-register)
        from winterforge.plugins import discover_plugins
        discover_plugins()

        # Materialize all primitives
        primitives = await materialize_primitives()

        # Results keyed by primitive type
        print(f"Created {len(primitives['trait'])} trait Frags")
        print(f"Created {len(primitives['affinity'])} affinity Frags")

        # Now queryable
        from winterforge.frags import TraitRegistry
        registry = TraitRegistry()
        all_traits = await registry.all()
    """
    from winterforge.frags.primitives.manager import PrimitiveTypeManager
    from winterforge.frags import Manifest

    results = {}

    # Get all registered primitive types
    types = PrimitiveTypeManager.all_types()
    sources = PrimitiveTypeManager.all_sources()

    # Materialize each primitive type
    for type_id, primitive_class in types.items():
        source_callable = sources.get(type_id)
        if not source_callable:
            continue

        # Get names from source (handle both sync and async)
        names_or_coro = source_callable()

        # Handle case where source returns another callable
        if callable(names_or_coro):
            names_or_coro = names_or_coro()

        if inspect.iscoroutine(names_or_coro):
            names = await names_or_coro
        else:
            names = names_or_coro

        # Create Frag for each name
        frags = []

        # Skip if no storage (can't save)
        from winterforge.frags.traits.persistable import get_storage
        if not get_storage():
            results[type_id] = Manifest(frags)
            continue

        for name in names:
            # Instantiate primitive with name
            primitive = primitive_class(name=name)
            await primitive.save()
            frags.append(primitive)

        results[type_id] = Manifest(frags)

    return results


# Backward compatibility helpers
async def materialize_traits() -> 'Manifest':
    """
    Materialize all registered traits as Trait Frags.

    Backward compatibility wrapper around materialize_primitives().

    Returns:
        Manifest of created Trait Frags
    """
    primitives = await materialize_primitives()
    return primitives.get('trait', [])


async def materialize_affinities() -> 'Manifest':
    """
    Materialize all affinities from Frags in storage as Affinity Frags.

    Backward compatibility wrapper around materialize_primitives().

    Returns:
        Manifest of created Affinity Frags
    """
    primitives = await materialize_primitives()
    return primitives.get('affinity', [])


__all__ = [
    'materialize_primitives',
    'materialize_traits',
    'materialize_affinities',
]
