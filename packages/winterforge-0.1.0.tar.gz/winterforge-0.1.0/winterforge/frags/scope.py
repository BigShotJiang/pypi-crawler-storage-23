"""Scope value object - composition + categorical membership.

Scope represents the complete matching pattern for Frag selection:
- Composition: What a Frag IS (identity + capability)
- Aliases: What it BELONGS TO (categorical membership)

Scope is used for:
- Injectable scope matching (InjectableMixin)
- Storage queries (scope-based filtering)
- Collection filtering (in-memory matching)

Examples:
    # Basic scope (composition only)
    scope = Scope(
        composition=Composition(affinities=('config',), traits=('injectable',))
    )

    # Scope with exact alias values
    scope = Scope(
        composition=Composition(affinities=('config',)),
        aliases={'environment': 'production', 'service': 'database'}
    )

    # Scope with alias key matching (any value)
    scope = Scope(
        composition=Composition(affinities=('post',)),
        aliases={'publication_id': ...}  # Has publication_id, any value
    )

    # Scope with alias value sets
    scope = Scope(
        composition=Composition(affinities=('user',)),
        aliases={'role': ['admin', 'moderator']}  # role in set
    )

    # Scope with predicate functions
    scope = Scope(
        composition=Composition(affinities=('article',)),
        aliases={'publication_id': lambda v: 92 <= int(v) <= 204}  # Range
    )

    # Matching
    if scope.matches(frag):
        print("Frag is in scope!")
"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Callable, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.frags.composition import Composition
    from typing import Mapping


# Type alias for alias constraints
AliasConstraint = Union[
    str,  # Exact value match
    type(...),  # Ellipsis = key must exist (any value)
    list,  # Value in set
    tuple,  # Value in set
    set,  # Value in set
    Callable[[Any], bool]  # Predicate function
]


@dataclass(frozen=True)
class Scope:
    """
    Scope = Composition + Categorical Membership.

    Represents the complete matching pattern for Frag selection.
    Composition defines WHAT a Frag is (identity + capability).
    Aliases define WHERE it belongs (categorical membership).

    Scope matching supports:
    - Exact alias values: {'environment': 'production'}
    - Alias key existence: {'publication_id': ...}
    - Value sets: {'role': ['admin', 'moderator']}
    - Predicate functions: {'id': lambda v: int(v) > 100}

    Attributes:
        composition: Composition defining shape (affinities + traits)
        aliases: Alias constraints for categorical matching

    Examples:
        # Production database configs
        scope = Scope(
            composition=Composition(
                affinities=('config',),
                traits=('injectable',)
            ),
            aliases={'environment': 'production', 'service': 'database'}
        )

        # Articles in publication range
        scope = Scope(
            composition=Composition(affinities=('article',)),
            aliases={'publication_id': lambda v: 92 <= int(v) <= 204}
        )

        # Any Frag with external_id
        scope = Scope(
            composition=Composition(affinities=('post',)),
            aliases={'external_id': ...}
        )
    """

    composition: 'Composition'
    aliases: Mapping[str, AliasConstraint] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Ensure immutability of aliases."""
        if isinstance(self.aliases, dict):
            object.__setattr__(
                self,
                'aliases',
                MappingProxyType(self.aliases)
            )

    # ========== Matching ==========

    def matches(self, frag: 'Frag') -> bool:
        """
        Check if Frag matches this scope.

        A Frag matches if:
        1. Its composition matches (affinities + traits)
        2. Its aliases satisfy all constraints

        Args:
            frag: Frag to check

        Returns:
            True if Frag is in scope

        Example:
            scope = Scope(
                composition=Composition(affinities=('config',)),
                aliases={'environment': 'production'}
            )

            if scope.matches(frag):
                print("Config is in production scope!")
        """
        # Composition matching
        if not self._matches_composition(frag):
            return False

        # Alias matching
        if not self._matches_aliases(frag):
            return False

        return True

    def _matches_composition(self, frag: 'Frag') -> bool:
        """
        Check if Frag's composition matches.

        Uses subset matching:
        - Frag must have ALL required affinities
        - Frag must have ALL required traits
        - Frag can have additional affinities/traits

        Args:
            frag: Frag to check

        Returns:
            True if composition matches
        """
        required_affinities = set(self.composition.affinities)
        required_traits = set(self.composition.traits)

        frag_affinities = set(frag.affinities)
        frag_traits = set(frag.traits)

        return (
            required_affinities.issubset(frag_affinities) and
            required_traits.issubset(frag_traits)
        )

    def _matches_aliases(self, frag: 'Frag') -> bool:
        """
        Check if Frag's aliases satisfy constraints.

        Supports multiple constraint types:
        - str/int/etc: Exact value match
        - Ellipsis (...): Key must exist (any value)
        - list/tuple/set: Value must be in set
        - Callable: Predicate function must return True

        Args:
            frag: Frag to check

        Returns:
            True if all alias constraints satisfied
        """
        for key, constraint in self.aliases.items():
            frag_value = frag.get_alias(key)

            # Key-only matching (alias must exist)
            if constraint is ...:
                if frag_value is None:
                    return False
                continue

            # If frag doesn't have the key and we need a value, fail
            if frag_value is None:
                return False

            # Value matching based on constraint type
            if callable(constraint):
                # Predicate function
                try:
                    if not constraint(frag_value):
                        return False
                except Exception:
                    # Predicate raised exception (e.g., type conversion)
                    return False

            elif isinstance(constraint, (list, tuple, set)):
                # Value in set
                if frag_value not in constraint:
                    return False

            else:
                # Exact match
                if frag_value != constraint:
                    return False

        return True

    # ========== Set Operations ==========

    @classmethod
    def intersection(cls, scopes: 'list[Scope]') -> 'Scope':
        """
        Calculate common scope (intersection).

        Returns scope that matches ALL input scopes.
        - Composition: intersection of all compositions
        - Aliases: union of all alias constraints (must satisfy ALL)

        Args:
            scopes: List of Scopes to intersect

        Returns:
            New Scope representing intersection

        Example:
            scope1 = Scope(
                Composition(affinities=('config', 'prod')),
                aliases={'service': 'db'}
            )
            scope2 = Scope(
                Composition(affinities=('config',)),
                aliases={'region': 'us-east'}
            )
            common = Scope.intersection([scope1, scope2])
            # Composition(affinities=('config',))
            # aliases={'service': 'db', 'region': 'us-east'}
        """
        from winterforge.frags.composition import Composition

        if not scopes:
            return cls(composition=Composition())

        # Intersect compositions
        compositions = [s.composition for s in scopes]
        common_comp = Composition.intersection(compositions)

        # Union alias constraints (must satisfy ALL)
        all_aliases = {}
        for scope in scopes:
            all_aliases.update(scope.aliases)

        return cls(
            composition=common_comp,
            aliases=all_aliases
        )

    # ========== Serialization ==========

    def to_dict(self) -> dict:
        """
        Convert to dict (for serialization).

        Note: Only simple alias constraints can be serialized.
        Callable predicates will be omitted.

        Returns:
            Dict representation
        """
        data = {
            'composition': self.composition.to_dict()
        }

        # Only serialize simple alias constraints
        simple_aliases = {}
        for key, constraint in self.aliases.items():
            if constraint is ...:
                simple_aliases[key] = None  # Ellipsis as None
            elif isinstance(constraint, (str, int, float, bool)):
                simple_aliases[key] = constraint
            elif isinstance(constraint, (list, tuple, set)):
                simple_aliases[key] = list(constraint)
            # Skip callables (can't serialize)

        if simple_aliases:
            data['aliases'] = simple_aliases

        return data

    @classmethod
    def from_dict(cls, data: dict) -> 'Scope':
        """
        Create from dict (for deserialization).

        Args:
            data: Serialized scope data

        Returns:
            New Scope instance
        """
        from winterforge.frags.composition import Composition

        composition = Composition.from_dict(data.get('composition', {}))

        # Restore aliases (None -> Ellipsis)
        aliases = {}
        for key, value in data.get('aliases', {}).items():
            if value is None:
                aliases[key] = ...
            else:
                aliases[key] = value

        return cls(composition=composition, aliases=aliases)

    # ========== Introspection ==========

    def is_empty(self) -> bool:
        """
        Check if scope is empty (matches everything).

        Returns:
            True if no constraints
        """
        return (
            self.composition.is_empty() and
            len(self.aliases) == 0
        )

    def __repr__(self) -> str:
        """String representation."""
        parts = []

        if not self.composition.is_empty():
            parts.append(f"composition={self.composition}")

        if self.aliases:
            # Format aliases nicely
            alias_parts = []
            for key, constraint in self.aliases.items():
                if constraint is ...:
                    alias_parts.append(f"{key}=...")
                elif callable(constraint):
                    alias_parts.append(f"{key}=<predicate>")
                else:
                    alias_parts.append(f"{key}={constraint!r}")

            parts.append(f"aliases={{{', '.join(alias_parts)}}}")

        if not parts:
            return "Scope()"

        return f"Scope({', '.join(parts)})"
