"""Injectable mixin - automatic injection via composition matching."""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Union

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.frags.manifest import Manifest


class InjectableMixin:
    """
    Mixin for automatic injectable scope retrieval.

    Compose this mixin to automatically query for Frags
    with matching composition on initialization.

    Usage:
        class Claude(InjectableMixin):
            # Specify composition to inject
            injectable_composition = ['has_api_key', 'has_model']

            def __init__(self):
                super().__init__()
                # self.injectable_scope is now Manifest

                # Consumer decides what to do
                config = self.injectable_scope.resolve(lambda c: True)
                self.api_key = config.api_key
                self.model = config.model

        # Or pass Frag as template
        class LocalOllama(InjectableMixin):
            def __init__(self, template: 'Frag'):
                super().__init__(injectable_composition=template)
                # Queries for Frags with same composition as template

    Attributes:
        injectable_scope: Manifest of matching Frags
        injectable_composition: Trait list or Frag template
    """

    injectable_composition: Union[List[str], 'Frag', None] = None
    injectable_scope: 'Manifest'

    def __init__(
        self,
        injectable_composition: Union[List[str], 'Frag', None] = None,
        **kwargs
    ):
        """
        Initialize mixin and query for injectable scope.

        Args:
            injectable_composition: Trait list or Frag template
            **kwargs: Passed to super().__init__()
        """
        super().__init__(**kwargs)

        from winterforge.frags.manifest import Manifest

        # Store composition for refresh
        if injectable_composition is not None:
            self.injectable_composition = injectable_composition

        # Query for matching Frags if composition provided
        self.injectable_scope = (
            self._query_injectable(self.injectable_composition)
            if self.injectable_composition is not None else Manifest([])
        )

    async def refresh_injectable_scope(self) -> InjectableMixin:
        """
        Refresh injectable scope (async).

        Re-queries for matching Frags. Useful if Frags
        were added/modified after initialization.

        Example:
            await claude.refresh_injectable_scope()
            config = claude.injectable_scope.resolve(lambda c: True)
        """
        if self.injectable_composition is None:
            return self

        from winterforge.frags.registries.frag_registry import (
            FragRegistry
        )

        composition = self._build_composition(
            self.injectable_composition
        )
        registry = FragRegistry(composition)
        self.injectable_scope = await registry.query().execute()
        return self

    @staticmethod
    def _query_injectable(
        composition: Union[List[str], 'Frag']
    ) -> 'Manifest':
        """
        Query for Frags with matching composition.

        Args:
            composition: Trait list or Frag template

        Returns:
            Manifest of matching Frags
        """
        from winterforge.frags.registries.frag_registry import FragRegistry
        from winterforge.frags.manifest import Manifest
        from winterforge.frags.traits.persistable import get_storage
        from winterforge.utils.sync import is_async
        import asyncio

        if not get_storage():
            return Manifest([])

        composition_obj = InjectableMixin._build_composition(composition)

        # Lenient pattern - return empty if in async context
        if is_async():
            # Can't run synchronously from async context
            # Caller should use refresh_injectable_scope() instead
            return Manifest([])

        # Sync context - safe to run query
        registry = FragRegistry(composition_obj)
        return asyncio.run(registry.query().execute())

    @staticmethod
    def _build_composition(
        composition: Union[List[str], 'Frag']
    ) -> 'Composition':
        """
        Build Composition for injectable scope matching.

        Args:
            composition: Frag template or trait list

        Returns:
            Composition with normalized traits including 'injectable'
        """
        from winterforge.frags.composition import Composition

        return Composition(
            affinities=[],
            traits=InjectableMixin._normalize_traits(composition)
        )

    @staticmethod
    def _normalize_traits(
        composition: Union[List[str], 'Frag']
    ) -> list[str]:
        """
        Normalize composition to trait list with 'injectable'.

        Uses duck typing (EAFP) instead of isinstance checks.
        Strategy: Try Frag interface first, fall back to list.

        Args:
            composition: Frag template or trait list

        Returns:
            Normalized trait list with 'injectable' included
        """
        # Strategy pattern via duck typing (EAFP: Easier to Ask Forgiveness than Permission)
        try:
            # Try Frag interface: extract traits from composition
            traits = list(composition.composition.traits)
        except AttributeError:
            # Fall back to list interface: use directly
            traits = list(composition) if composition else []

        # Ensure 'injectable' is included (idempotent)
        if 'injectable' not in traits:
            traits.insert(0, 'injectable')

        return traits
