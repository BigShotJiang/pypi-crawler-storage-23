"""
Winterforge - AI-native framework with composable primitives.

Author: Beau Simensen
License: TBD
Version: 0.1.0
"""

__version__ = "0.1.0"

import asyncio
from winterforge.plugins._discovery import discover_plugins


async def async_initialize() -> None:
    """
    Initialize Winterforge plugin system with lifecycle support.

    Discovers plugins (including derivative generation) and calls
    startup() on all LifecycleAware plugins. Use in async contexts.
    """
    # Discover plugins from entry points (includes derivative generation)
    discover_plugins()

    # Import built-in plugin managers first (so decorators can register)
    from winterforge.plugins.storage.manager import StorageManager
    from winterforge.frags.traits._manager import FragTraitManager
    from winterforge.plugins.identity.manager import IdentityResolverManager
    from winterforge.plugins import (
        HashingProviderManager,
        SessionProviderManager,
        AuthenticationProviderManager,
        TokenProviderManager,
        EmailProviderManager,
    )

    # Import built-in plugin implementations to trigger decorator-based registration
    import winterforge.frags.traits.fieldable  # noqa: F401
    import winterforge.frags.traits.titled  # noqa: F401
    import winterforge.frags.traits.timestamped  # noqa: F401
    import winterforge.frags.traits.sluggable  # noqa: F401
    import winterforge.frags.traits.persistable  # noqa: F401
    import winterforge.frags.traits.typed  # noqa: F401
    import winterforge.frags.traits.composable  # noqa: F401
    import winterforge.frags.traits.profileable  # noqa: F401
    import winterforge.frags.traits.userable  # noqa: F401
    import winterforge.frags.traits.authenticatable  # noqa: F401
    import winterforge.frags.traits.authorizable  # noqa: F401
    import winterforge.frags.traits.sessionable  # noqa: F401
    import winterforge.frags.traits.tokenable  # noqa: F401
    import winterforge.frags.traits.permissioned  # noqa: F401
    import winterforge.frags.traits.ownable  # noqa: F401
    import winterforge.plugins.identity.frag_id_resolver  # noqa: F401
    import winterforge.plugins.identity.slug_resolver  # noqa: F401
    import winterforge.plugins.identity.uuid_resolver  # noqa: F401
    import winterforge.plugins.identity.username_resolver  # noqa: F401
    import winterforge.plugins.identity.email_resolver  # noqa: F401
    import winterforge.plugins.identity.title_resolver  # noqa: F401
    import winterforge.plugins.storage.sqlite  # noqa: F401
    import winterforge.plugins.storage.postgresql  # noqa: F401
    import winterforge.plugins.storage.yaml  # noqa: F401
    import winterforge.plugins.storage.env  # noqa: F401
    import winterforge.plugins.hashing  # noqa: F401
    import winterforge.plugins.session  # noqa: F401
    import winterforge.plugins.authentication  # noqa: F401
    import winterforge.plugins.token  # noqa: F401
    import winterforge.plugins.email  # noqa: F401

    # Call startup on all LifecycleAware plugins
    all_managers = [
        StorageManager,
        FragTraitManager,
        IdentityResolverManager,
        HashingProviderManager,
        SessionProviderManager,
        AuthenticationProviderManager,
        TokenProviderManager,
        EmailProviderManager,
    ]

    for manager in all_managers:
        await manager.startup_all()


async def async_shutdown() -> None:
    """
    Shutdown Winterforge plugin system.

    Calls shutdown() on all LifecycleAware plugin instances.
    Use during application termination in async contexts.
    """
    from winterforge.plugins.storage.manager import StorageManager
    from winterforge.frags.traits._manager import FragTraitManager
    from winterforge.plugins.identity.manager import IdentityResolverManager
    from winterforge.plugins import (
        HashingProviderManager,
        SessionProviderManager,
        AuthenticationProviderManager,
        TokenProviderManager,
        EmailProviderManager,
    )

    all_managers = [
        StorageManager,
        FragTraitManager,
        IdentityResolverManager,
        HashingProviderManager,
        SessionProviderManager,
        AuthenticationProviderManager,
        TokenProviderManager,
        EmailProviderManager,
    ]

    for manager in all_managers:
        await manager.shutdown_all()


def initialize() -> None:
    """
    Initialize Winterforge plugin system (synchronous wrapper).

    Calls async_initialize() in a new event loop. For async applications,
    use async_initialize() directly.
    """
    asyncio.run(async_initialize())


def shutdown() -> None:
    """
    Shutdown Winterforge plugin system (synchronous wrapper).

    Calls async_shutdown() in a new event loop. For async applications,
    use async_shutdown() directly.
    """
    asyncio.run(async_shutdown())


__all__ = [
    '__version__',
    'initialize',
    'shutdown',
    'async_initialize',
    'async_shutdown',
]
