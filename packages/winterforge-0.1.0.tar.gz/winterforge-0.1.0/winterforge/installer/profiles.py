"""Built-in install profiles.

Defines standard installation profiles as Frags:
- quick: Minimal setup (username, password, email)
- full: Complete setup with all options
- docker: Container-optimized setup
- development: Developer-friendly defaults
"""

from winterforge.frags import Frag
from winterforge.frags.registries.field_registry import FieldRegistry
from winterforge.frags.registries.profile_registry import ProfileRegistry

# Import traits to ensure they're registered
import winterforge.frags.traits.profileable  # noqa: F401
import winterforge.frags.traits.composable  # noqa: F401
import winterforge.frags.traits.fieldable  # noqa: F401
import winterforge.frags.traits.titled  # noqa: F401
import winterforge.frags.traits.sluggable  # noqa: F401
import winterforge.frags.traits.persistable  # noqa: F401


async def ensure_builtin_profiles() -> None:
    """
    Ensure built-in install profiles exist.

    Creates standard profiles if they don't already exist.
    Idempotent - safe to call multiple times.

    Profiles created:
    - quick-install: Minimal setup
    - full-install: Complete setup
    - docker-install: Container setup
    - development-install: Developer setup
    """
    fields = FieldRegistry()
    profiles = ProfileRegistry()

    # Define common fields
    username_field = await fields.ensure_field(
        slug='username',
        field_type=str,
        required=True,
        prompt='Admin username',
        validators=['required', 'username'],
        help_text='Administrator account username (3-30 characters)'
    )

    password_field = await fields.ensure_field(
        slug='password',
        field_type=str,
        required=True,
        prompt='Admin password',
        validators=['required', 'password_validators.strong'],
        help_text='Strong password (8+ chars, mixed case, numbers)'
    )

    email_field = await fields.ensure_field(
        slug='email',
        field_type=str,
        required=True,
        prompt='Admin email',
        validators=['required', 'email'],
        help_text='Valid email address for admin account'
    )

    site_name_field = await fields.ensure_field(
        slug='site-name',
        field_type=str,
        default='WinterForge Site',
        prompt='Site name',
        help_text='Display name for your site'
    )

    db_host_field = await fields.ensure_field(
        slug='database-host',
        field_type=str,
        default='localhost',
        prompt='Database host',
        help_text='Database server hostname or IP'
    )

    db_port_field = await fields.ensure_field(
        slug='database-port',
        field_type=int,
        default=5432,
        prompt='Database port',
        help_text='Database server port'
    )

    db_name_field = await fields.ensure_field(
        slug='database-name',
        field_type=str,
        default='winterforge',
        prompt='Database name',
        help_text='Name of database to use'
    )

    db_user_field = await fields.ensure_field(
        slug='database-user',
        field_type=str,
        prompt='Database username',
        help_text='Database authentication username'
    )

    db_pass_field = await fields.ensure_field(
        slug='database-password',
        field_type=str,
        prompt='Database password',
        help_text='Database authentication password'
    )

    # Quick Install Profile
    quick_profile = await profiles.get_by_slug('quick-install')
    if not quick_profile:
        quick_profile = Frag(
            affinities=['install-profile'],
            traits=['profileable', 'composable', 'fieldable', 'titled', 'sluggable', 'persistable']
        )
        quick_profile.set_slug('quick-install')
        quick_profile.set_title('Quick Install')
        quick_profile.set_description(
            'Fast setup with minimal prompts. Uses SQLite and sensible defaults.'
        )
        quick_profile.set_steps('database,admin,config')

        # Only essential fields
        quick_profile.add_field_reference(username_field)
        quick_profile.add_field_reference(password_field)
        quick_profile.add_field_reference(email_field)

        await quick_profile.save()

    # Full Install Profile
    full_profile = await profiles.get_by_slug('full-install')
    if not full_profile:
        full_profile = Frag(
            affinities=['install-profile'],
            traits=['profileable', 'composable', 'fieldable', 'titled', 'sluggable', 'persistable']
        )
        full_profile.set_slug('full-install')
        full_profile.set_title('Full Install')
        full_profile.set_description(
            'Complete setup with all configuration options. Recommended for production.'
        )
        full_profile.set_steps('database,admin,config,plugins,permissions')

        # All configuration fields
        full_profile.add_field_reference(username_field)
        full_profile.add_field_reference(password_field)
        full_profile.add_field_reference(email_field)
        full_profile.add_field_reference(site_name_field)
        full_profile.add_field_reference(db_host_field)
        full_profile.add_field_reference(db_port_field)
        full_profile.add_field_reference(db_name_field)
        full_profile.add_field_reference(db_user_field)
        full_profile.add_field_reference(db_pass_field)

        await full_profile.save()

    # Docker Install Profile
    docker_profile = await profiles.get_by_slug('docker-install')
    if not docker_profile:
        docker_profile = Frag(
            affinities=['install-profile'],
            traits=['profileable', 'composable', 'fieldable', 'titled', 'sluggable', 'persistable']
        )
        docker_profile.set_slug('docker-install')
        docker_profile.set_title('Docker Install')
        docker_profile.set_description(
            'Container-optimized setup. Uses environment variables and PostgreSQL.'
        )
        docker_profile.set_steps('database,admin,config')

        # Container-relevant fields
        docker_profile.add_field_reference(username_field)
        docker_profile.add_field_reference(password_field)
        docker_profile.add_field_reference(email_field)
        docker_profile.add_field_reference(db_host_field)
        docker_profile.add_field_reference(db_name_field)

        await docker_profile.save()

    # Development Install Profile
    dev_profile = await profiles.get_by_slug('development-install')
    if not dev_profile:
        dev_profile = Frag(
            affinities=['install-profile'],
            traits=['profileable', 'composable', 'fieldable', 'titled', 'sluggable', 'persistable']
        )
        dev_profile.set_slug('development-install')
        dev_profile.set_title('Development Install')
        dev_profile.set_description(
            'Developer-friendly setup with debug tools and relaxed security.'
        )
        dev_profile.set_steps('database,admin,config,dev-tools')

        # Dev-focused fields
        dev_profile.add_field_reference(username_field)
        dev_profile.add_field_reference(password_field)
        dev_profile.add_field_reference(email_field)

        await dev_profile.save()


async def get_profile_by_name(profile_name: str) -> Frag:
    """
    Get install profile by name.

    Args:
        profile_name: Profile name (quick, full, docker, development)

    Returns:
        Profile Frag

    Raises:
        ValueError: If profile not found

    Example:
        profile = await get_profile_by_name('quick')
        values = await profile.execute()
    """
    # Map friendly names to slugs
    slug_map = {
        'quick': 'quick-install',
        'full': 'full-install',
        'docker': 'docker-install',
        'development': 'development-install',
        'dev': 'development-install',
    }

    slug = slug_map.get(profile_name, profile_name)

    profiles = ProfileRegistry()
    profile = await profiles.get_by_slug(slug)

    if not profile:
        raise ValueError(
            f"Profile '{profile_name}' not found. "
            f"Available: {', '.join(slug_map.keys())}"
        )

    return profile
