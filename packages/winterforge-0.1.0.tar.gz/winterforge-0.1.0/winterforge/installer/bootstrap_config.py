"""Bootstrap configuration Frag creation."""

from typing import Any, Dict, Optional
from winterforge.frags import Frag
from winterforge.plugins.slug_convertors import SlugConvertorManager


async def create_bootstrap_config(
    backend: str, **config: Any
) -> Frag:
    """
    Create bootstrap configuration Frag.

    Single Frag with multiple fields storing storage configuration.

    Args:
        backend: Storage backend type ('sqlite', 'postgresql', 'yaml')
        **config: Storage-specific configuration fields
            For SQLite: db_path
            For PostgreSQL: host, port, database, username, password

    Returns:
        Bootstrap config Frag

    Example:
        # SQLite
        bootstrap = await create_bootstrap_config(
            'sqlite',
            db_path='./winterforge.db'
        )

        # PostgreSQL
        bootstrap = await create_bootstrap_config(
            'postgresql',
            host='localhost',
            port=5432,
            database='winterforge',
            username='winterforge',
            password='secret'
        )
    """
    # Create field definitions for each config key
    from winterforge.frags.registries.field_registry import FieldRegistry

    fields = FieldRegistry()

    # Create bootstrap Frag
    bootstrap = Frag(
        affinities=['bootstrap', 'config'],
        traits=['fieldable', 'sluggable', 'persistable'],
    )

    bootstrap.set_slug('bootstrap')

    # Add field definition and value for each config key
    for key, value in {'backend': backend, **config}.items():
        # Determine field type
        if isinstance(value, str):
            field_type = str
            default = ''
        elif isinstance(value, int):
            field_type = int
            default = 0
        else:
            # Default to string for other types
            field_type = str
            default = ''

        # Convert Python naming to slug format (db_path → db-path)
        slug = SlugConvertorManager.convert(key, 'python', 'slug') or key

        # Ensure field definition exists for this key
        field = await fields.ensure_field(
            slug=slug, field_type=field_type, default=default, required=False
        )

        # Add field reference (uses field's slug as field name)
        bootstrap.add_field_reference(field)

        # Set the value using the original key (may have underscores)
        bootstrap.set_value(slug, value)

    # Save to storage
    await bootstrap.save()

    return bootstrap
