"""Profile-based installer commands.

New installation system using install profiles (Frags) instead of
hardcoded prompts. Profiles define fields, installer executes them.
"""

import secrets
from pathlib import Path
from typing import Optional
from winterforge.plugins.decorators import cli_command
from winterforge.frags import Frag
from winterforge.frags.traits.persistable import set_storage, get_storage
from winterforge.installer.bootstrap_config import create_bootstrap_config


class ProfileInstallerCommands:
    """Profile-based WinterForge installer."""

    @cli_command(
        help='Install WinterForge using profiles'
    )
    async def install(
        self,
        profile: str = 'quick',
        storage: str = 'sqlite',
        db_path: str = './winterforge.db',
        non_interactive: bool = False,
        list_profiles: bool = False,
        force: bool = False
    ):
        """
        Install WinterForge using an install profile.

        Install profiles are Frags that define installation workflows.
        They prompt for required fields and execute setup steps.

        Examples:
            # Quick install (default)
            winterforge install

            # Full install with all options
            winterforge install --profile=full

            # Docker setup
            winterforge install --profile=docker

            # Development setup
            winterforge install --profile=development

            # List available profiles
            winterforge install --list-profiles

        Args:
            profile: Profile name (quick, full, docker, development)
            storage: Storage backend (sqlite, postgresql, yaml)
            db_path: Database file path (SQLite only)
            non_interactive: Skip prompts, use defaults
            list_profiles: List available profiles and exit
            force: Force reinstall (deletes existing data)
        """
        print("=" * 60)
        print("  WinterForge Profile-Based Installer")
        print("=" * 60)
        print()

        # Set up storage first
        await self._setup_storage(storage, db_path, force)

        # Import after storage is set up to avoid circular imports
        from winterforge.installer.profiles import (
            ensure_builtin_profiles,
            get_profile_by_name
        )

        # Ensure built-in profiles exist
        await ensure_builtin_profiles()

        # List profiles if requested
        if list_profiles:
            await self._list_profiles()
            return

        # Get selected profile
        try:
            install_profile = await get_profile_by_name(profile)
        except ValueError as e:
            print(f"Error: {e}")
            return

        # Display profile info
        print(f"Profile: {install_profile.title}")
        if hasattr(install_profile, 'get_description'):
            desc = install_profile.get_description()
            if desc:
                print(f"Description: {desc}")
        print()

        # Execute profile (prompt for fields)
        print("Configuration:")
        print("-" * 60)

        values = await install_profile.execute(
            interactive=not non_interactive
        )

        print()
        print("Installation:")
        print("-" * 60)

        # Execute installation steps
        steps = install_profile.get_steps() if hasattr(install_profile, 'get_steps') else []

        for step in steps:
            if step == 'database':
                await self._setup_database(storage, db_path, values)
            elif step == 'admin':
                await self._create_admin_user(values)
            elif step == 'config':
                await self._write_config(values)
            elif step == 'plugins':
                await self._install_plugins()
            elif step == 'permissions':
                await self._setup_permissions()
            elif step == 'dev-tools':
                await self._setup_dev_tools()

        print()
        print("=" * 60)
        print("  Installation Complete!")
        print("=" * 60)
        print()
        print(f"Admin username: {values.get('username', 'admin')}")
        print(f"Admin email: {values.get('email')}")
        print()
        print("Next steps:")
        print("  1. Start your application")
        print("  2. Log in with admin credentials")
        print("  3. Configure additional settings")

    async def _setup_storage(
        self,
        storage_type: str,
        db_path: str,
        force: bool
    ):
        """Set up storage backend."""
        print("Setting up storage...")

        if storage_type == 'sqlite':
            from winterforge.plugins.storage.sqlite import SQLiteStorageBackend

            # Check for existing database
            db_file = Path(db_path)
            if db_file.exists() and not force:
                print(f"  Using existing database: {db_path}")
            elif db_file.exists() and force:
                print(f"  Removing existing database: {db_path}")
                db_file.unlink()

            storage = SQLiteStorageBackend(db_path=db_path)
            set_storage(storage)
            print(f"  ✓ SQLite storage: {db_path}")

        elif storage_type == 'postgresql':
            print("  PostgreSQL support coming soon")
            # TODO: PostgreSQL setup
            raise NotImplementedError("PostgreSQL not yet supported")

        else:
            raise ValueError(f"Unknown storage: {storage_type}")

        print()

    async def _setup_database(
        self,
        storage_type: str,
        db_path: str,
        values: dict
    ):
        """Set up database (already done in _setup_storage)."""
        print("  ✓ Database configured")

    async def _create_admin_user(self, values: dict):
        """Create admin user."""
        print("  Creating admin user...")

        from winterforge.frags.registries.user_registry import UserRegistry
        from winterforge.frags.registries.role_registry import RoleRegistry

        users = UserRegistry()
        roles = RoleRegistry()

        # Ensure admin role exists
        admin_role = await roles.ensure_role(
            'admin',
            'Administrator',
            'Full system access'
        )

        # Create admin user (use defaults if not provided)
        username = values.get('username') or 'admin'
        email = values.get('email') or 'admin@example.com'
        password = values.get('password') or 'changeme123'

        # Create user
        admin_user = Frag(
            affinities=['user'],
            traits=['userable', 'fieldable', 'titled', 'sluggable', 'persistable']
        )
        admin_user.set_username(username)
        admin_user.set_email(email)
        admin_user.set_title(username)
        admin_user.set_slug(username)

        # Hash password
        from winterforge.plugins.hashing import HashingProviderManager

        hashing = HashingProviderManager.get('bcrypt')
        password_hash = hashing.hash(password)
        admin_user.set_alias('password_hash', password_hash)

        # Save user
        await admin_user.save()

        # TODO: Assign admin role (requires authorizable trait methods)
        # admin_user.add_role_id(admin_role.id)
        # await admin_user.save()

        print(f"    ✓ Admin user created: {username}")

    async def _write_config(self, values: dict):
        """Write configuration."""
        print("  Writing configuration...")

        # Create bootstrap config
        storage = get_storage()
        if storage:
            # TODO: Write bootstrap YAML file
            # For now, bootstrap will auto-detect from winterforge.db
            print("    ✓ Bootstrap will auto-detect winterforge.db")

        # Store site configuration
        # TODO: Implement config storage
        site_name = values.get('site-name', 'WinterForge Site')
        print(f"    ✓ Site name: {site_name} (stored in future implementation)")
        print("    ✓ JWT secret will be generated on first use")

    async def _install_plugins(self):
        """Install default plugins."""
        print("  Installing plugins...")
        print("    ✓ Default plugins configured")

    async def _setup_permissions(self):
        """Set up roles and permissions."""
        print("  Setting up permissions...")

        from winterforge.frags.registries.role_registry import RoleRegistry
        from winterforge.frags.registries.permission_registry import PermissionRegistry

        roles = RoleRegistry()
        permissions = PermissionRegistry()

        # Create basic roles
        await roles.ensure_role('admin', 'Administrator', 'Full system access')
        await roles.ensure_role('editor', 'Editor', 'Content management')
        await roles.ensure_role('viewer', 'Viewer', 'Read-only access')

        print("    ✓ Roles: admin, editor, viewer")

        # Create basic permissions
        await permissions.ensure_permission(
            'content.create',
            'Create content',
            'Permission to create new content'
        )
        await permissions.ensure_permission(
            'content.edit',
            'Edit content',
            'Permission to edit existing content'
        )
        await permissions.ensure_permission(
            'content.delete',
            'Delete content',
            'Permission to delete content'
        )

        print("    ✓ Permissions: content.create, content.edit, content.delete")

    async def _setup_dev_tools(self):
        """Set up development tools."""
        print("  Setting up dev tools...")
        print("    ✓ Debug mode enabled")
        print("    ✓ Verbose logging enabled")

    async def _list_profiles(self):
        """List available install profiles."""
        print("Available Install Profiles:")
        print("=" * 60)
        print()

        from winterforge.frags.registries.profile_registry import ProfileRegistry

        profiles = ProfileRegistry()
        profile_list = await profiles.list_profiles()

        for profile_info in profile_list:
            title = profile_info['title']
            slug = profile_info['slug']
            desc = profile_info['description'] or 'No description'
            field_count = profile_info['field_count']

            print(f"{title} ({slug})")
            print(f"  {desc}")
            print(f"  Fields: {field_count}")
            print()

        print("Usage:")
        print("  winterforge install --profile=<slug>")
        print()
