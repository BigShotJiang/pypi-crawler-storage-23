"""Winterforge init command."""

import asyncio
from winterforge.plugins.decorators import decorator_provider, CLICommandConfig


@decorator_provider(
    cli_command=CLICommandConfig(
        name='init',
        success="✓ {message}",
        error="Initialization failed: {error}"
    )
)
async def init(name: str, description: str = None) -> 'Frag':
    """
    Initialize Winterforge application via initializer stack.

    Executes all registered initializers in dependency order.
    Each initializer is idempotent - safe to run multiple times.

    Args:
        name: Application name (required)
        description: Application description (optional)

    Returns:
        Result Frag with initialization status

    Example:
        # Via CLI
        winterforge init "Production Blog" --description "Main instance"

        # Via code
        from winterforge.installer.init_command import init
        result = await init(
            name='Production Blog',
            description='Main production instance'
        )
        print(result.message)
        # ✓ Application 'Production Blog' initialized
    """
    from winterforge.plugins.initializers.manager import InitializerManager
    from winterforge.frags.base import Frag

    context = {
        'name': name,
        'description': description or f'Winterforge application: {name}'
    }

    # Get ordered initializer stack
    initializers = InitializerManager.repository()

    # Accumulate async tasks via resolve_all
    tasks = initializers.resolve_all(
        lambda acc, init: acc + [init.execute(context)],
        initial=[]
    )

    # Execute all initializers (ordered by dependencies)
    await asyncio.gather(*tasks)

    # Return operation result
    result = Frag(traits=['has_result'])
    result.set_success(True)
    result.set_message(f"✓ Application '{name}' initialized")
    result.set_data({
        'name': name,
        'description': context['description'],
        'initializers_run': len(tasks)
    })

    return result
