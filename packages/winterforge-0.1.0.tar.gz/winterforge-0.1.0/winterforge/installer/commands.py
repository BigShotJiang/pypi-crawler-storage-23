"""
Installer commands for WinterForge project initialization.

Provides `winterforge init` command with interactive and automated modes.
"""

import secrets
from pathlib import Path
from typing import Optional, Dict, Any, Tuple
import yaml
from winterforge.plugins.decorators import cli_command
from winterforge.frags import Frag
from winterforge.frags.traits.persistable import set_storage
from winterforge.installer.bootstrap_config import create_bootstrap_config
from winterforge.plugins.validators import validate_input


class InstallerCommands:
    """WinterForge project installer commands."""

    @cli_command(
        help='Initialize a new WinterForge project'
    )
    async def init(
        self,
        storage: str = None,
        db_path: str = './winterforge.db',
        pg_host: str = 'localhost',
        pg_port: int = 5432,
        pg_database: str = 'winterforge',
        pg_username: str = 'winterforge',
        pg_password: str = None,
        skip_plugins: bool = False,
        skip_config: bool = False,
        skip_roles: bool = False,
        skip_admin: bool = False,
        admin_username: str = 'admin',
        admin_email: str = None,
        admin_password: str = None,
        non_interactive: bool = False,
        force: bool = False
    ):
        """
        Initialize a new WinterForge project.

        Interactive by default, or use flags for automation.

        Examples:
            # Interactive installation
            winterforge init

            # Automated SQLite setup
            winterforge init --storage=sqlite --db-path=./myapp.db --non-interactive

            # Automated PostgreSQL setup
            winterforge init --storage=postgresql --non-interactive

            # Force reinstall
            winterforge init --force

        Args:
            storage: Storage backend ('sqlite', 'postgresql', 'yaml')
            db_path: SQLite database file path
            pg_host: PostgreSQL host
            pg_port: PostgreSQL port
            pg_database: PostgreSQL database name
            pg_username: PostgreSQL username
            pg_password: PostgreSQL password
            skip_plugins: Skip plugin configuration
            skip_config: Skip framework configuration
            skip_roles: Skip roles and permissions
            skip_admin: Skip admin user creation
            admin_username: Admin username
            admin_email: Admin email
            admin_password: Admin password (prompted if not provided)
            non_interactive: Run without prompts (use defaults/flags)
            force: Force reinstall (deletes existing data)
        """
        self.interactive = not non_interactive

        # Discover plugins (needed for identity resolution)
        from winterforge.plugins import discover_plugins
        discover_plugins()

        # Print banner
        self._print_banner()

        # Check for existing installation
        existing = await self._check_existing_installation(storage, db_path)

        if existing and not force:
            # Idempotent mode - skip completed steps
            return await self._idempotent_install(
                existing, storage, db_path, pg_host, pg_port, pg_database,
                pg_username, pg_password, skip_plugins, skip_config,
                skip_roles, skip_admin, admin_username, admin_email,
                admin_password
            )

        if existing and force:
            # Force reinstall - confirm and delete
            if not await self._confirm_force_reinstall():
                print("Installation cancelled.")
                return
            await self._delete_existing(storage, db_path)

        # Step 1: Storage Backend
        storage_backend = await self._setup_storage(
            storage, db_path, pg_host, pg_port, pg_database,
            pg_username, pg_password
        )

        # Step 2: Plugin Configuration
        if not skip_plugins:
            await self._import_plugin_config()

        # Step 3: Framework Configuration
        if not skip_config:
            await self._import_framework_config()

        # Step 4: Roles & Permissions
        if not skip_roles:
            roles, permissions = await self._import_roles_and_permissions()

        # Step 5: Admin User
        if not skip_admin:
            await self._create_admin_user(
                admin_username, admin_email, admin_password
            )

        # Print completion summary
        self._print_completion_summary()

    def _print_banner(self):
        """Print installer banner."""
        print(f"\n╔{'═' * 63}╗")
        print(f"║{' ' * 15}WinterForge Project Installer v1.0.0{' ' * 12}║")
        print(f"║{' ' * 7}Initialize database, roles, permissions, and admin user{' ' * 1}║")
        print(f"╚{'═' * 63}╝")

    async def _check_existing_installation(
        self, storage: str, db_path: str
    ) -> Dict[str, bool]:
        """
        Check for existing installation.

        Returns dict with status of each component:
        - database: Database exists
        - schema: Schema initialized
        - config: Config Frags present
        - roles: Roles present
        - permissions: Permissions present
        - admin: Admin user present
        """
        print("\nChecking for existing installation...")

        existing = {
            'database': False,
            'schema': False,
            'config': False,
            'roles': False,
            'permissions': False,
            'admin': False
        }

        # Check database file (SQLite)
        if storage == 'sqlite' or not storage:
            db_file = Path(db_path)
            if db_file.exists():
                existing['database'] = True

                # Try to load storage and check schema
                try:
                    from winterforge.plugins.storage.sqlite import SQLiteStorageBackend
                    storage_backend = SQLiteStorageBackend(db_path=db_path)
                    set_storage(storage_backend)

                    # Check for Frags - verify schema is actually initialized
                    from winterforge.frags.registries.user_registry import UserRegistry
                    from winterforge.frags.registries.role_registry import RoleRegistry
                    from winterforge.frags.registries.permission_registry import PermissionRegistry

                    # Try to query - if schema isn't initialized, this will fail
                    try:
                        await storage_backend.query().execute()
                        existing['schema'] = True
                    except Exception:
                        # Schema not properly initialized
                        pass

                    # Check roles
                    roles = RoleRegistry()
                    role_list = await roles.all()
                    if role_list:
                        existing['roles'] = True

                    # Check permissions
                    perms = PermissionRegistry()
                    perm_list = await perms.all()
                    if perm_list:
                        existing['permissions'] = True

                    # Check admin user
                    users = UserRegistry()
                    admin = await users.get('admin')
                    if admin:
                        existing['admin'] = True

                    # Check bootstrap config
                    from winterforge.plugins.bootstrap import (
                        BootstrapSourceManager
                    )
                    bootstrap = await BootstrapSourceManager.discover()
                    if bootstrap:
                        existing['config'] = True

                except Exception:
                    # Database exists but schema not initialized
                    pass

        # Print status
        for component, status in existing.items():
            symbol = "✓" if status else "✗"
            component_name = component.replace('_', ' ').title()
            print(f"{symbol} {component_name}: {'found' if status else 'not found'}")

        return existing

    async def _idempotent_install(
        self, existing, storage, db_path, pg_host, pg_port, pg_database,
        pg_username, pg_password, skip_plugins, skip_config, skip_roles,
        skip_admin, admin_username, admin_email, admin_password
    ):
        """
        Idempotent installation - skip completed steps.

        Only runs steps for missing components.
        """
        steps_completed = 0
        steps_skipped = 0

        # Step 1: Storage Backend
        print("\n[1/5] Storage Backend")
        print("═" * 65)
        if existing['database'] and existing['schema']:
            print("✓ Skipped (already configured)")
            # But ensure bootstrap config exists
            if not existing['config']:
                print("  → Creating bootstrap config...")
                await create_bootstrap_config(
                    storage or 'sqlite',
                    db_path=db_path
                )
                print("  ✓ Bootstrap config created")
            steps_skipped += 1
        else:
            await self._setup_storage(
                storage, db_path, pg_host, pg_port, pg_database,
                pg_username, pg_password
            )
            steps_completed += 1

        # Step 2: Plugin Configuration
        print("\n[2/5] Plugin Configuration")
        print("═" * 65)
        if skip_plugins:
            print("✓ Skipped")
            steps_skipped += 1
        else:
            await self._import_plugin_config()
            steps_completed += 1

        # Step 3: Framework Configuration
        print("\n[3/5] Framework Configuration")
        print("═" * 65)
        if skip_config:
            print("✓ Skipped")
            steps_skipped += 1
        else:
            await self._import_framework_config()
            steps_completed += 1

        # Step 4: Roles & Permissions
        print("\n[4/5] Roles & Permissions")
        print("═" * 65)
        if skip_roles or (existing['roles'] and existing['permissions']):
            print("✓ Skipped (already installed)")
            steps_skipped += 1
        else:
            await self._import_roles_and_permissions()
            steps_completed += 1

        # Step 5: Admin User
        print("\n[5/5] Admin User")
        print("═" * 65)
        if skip_admin:
            print("✓ Skipped")
            steps_skipped += 1
        elif existing['admin']:
            print("✓ Skipped (admin user already exists)")
            steps_skipped += 1
        else:
            # Admin missing - create
            await self._create_admin_user(
                admin_username, admin_email, admin_password
            )
            steps_completed += 1

        # Print summary
        print(f"\n{'═' * 65}")
        print("Installation Updated!")
        print(f"{'═' * 65}")
        print(f"\nSummary:")
        print(f"  - {steps_skipped} steps skipped (already configured)")
        print(f"  - {steps_completed} steps completed")
        if steps_skipped > 0:
            print("\nRun 'winterforge init --force' to reinstall from scratch.")

    async def _confirm_force_reinstall(self) -> bool:
        """Confirm force reinstall with user."""
        if not self.interactive:
            # Non-interactive mode - assume confirmed
            return True

        print("\n⚠ WARNING: Force reinstall will DELETE all existing data!")
        print("⚠ This includes:")
        print("  - All Frags (users, roles, permissions, config)")
        print("  - All sessions and tokens")
        print("  - ALL application data")
        print()

        confirm = input("Continue? [y/N]: ").strip().lower()
        return confirm == 'y'

    async def _delete_existing(self, storage: str, db_path: str):
        """Delete existing installation."""
        # Delete SQLite database file
        if storage == 'sqlite' or not storage:
            db_file = Path(db_path)
            if db_file.exists():
                db_file.unlink()
                print(f"✓ Deleted {db_path}")

        print("✓ Starting fresh installation...")

    async def _setup_storage(
        self,
        storage: str,
        db_path: str,
        pg_host: str,
        pg_port: int,
        pg_database: str,
        pg_username: str,
        pg_password: str
    ):
        """Set up storage backend (interactive or automated)."""
        print("\n[1/5] Storage Backend")
        print("═" * 65)

        # Interactive selection if not specified
        if not storage and self.interactive:
            print("Choose storage backend:")
            print("  1. SQLite (recommended for development)")
            print("  2. PostgreSQL (recommended for production)")
            print("  3. YAML (file-based, read-only)")
            print()

            choice = input("Selection [1]: ").strip() or "1"
            storage = {
                "1": "sqlite",
                "2": "postgresql",
                "3": "yaml"
            }.get(choice, "sqlite")

        # Default to SQLite if still not specified
        if not storage:
            storage = "sqlite"

        # Set up chosen backend
        if storage == "sqlite":
            backend = await self._setup_sqlite(db_path)

            # Create bootstrap config Frag (single Frag with multiple fields)
            await create_bootstrap_config('sqlite', db_path=db_path)

            return backend
        elif storage == "postgresql":
            backend = await self._setup_postgresql(
                pg_host, pg_port, pg_database, pg_username, pg_password
            )

            # Create bootstrap config Frag (single Frag with multiple fields)
            await create_bootstrap_config(
                'postgresql',
                host=pg_host,
                port=pg_port,
                database=pg_database,
                username=pg_username,
            )

            return backend
        elif storage == "yaml":
            return await self._setup_yaml()
        else:
            raise ValueError(f"Unknown storage backend: {storage}")

    async def _setup_sqlite(self, db_path: str):
        """Set up SQLite storage backend."""
        # Interactive path prompt
        if self.interactive:
            prompted_path = input(f"\nDatabase file path [{db_path}]: ").strip()
            if prompted_path:
                db_path = prompted_path

        # Create storage backend
        from winterforge.plugins.storage.sqlite import SQLiteStorageBackend
        storage = SQLiteStorageBackend(db_path=db_path)

        # Set as default storage
        set_storage(storage)

        # Actually create the database file and initialize schema
        await storage._ensure_connection()

        print(f"\n✓ SQLite database created: {db_path}")
        print("✓ Schema initialized (frags table, indexes)")

        # Run bootstrappers
        await self._run_bootstrappers()

        return storage

    async def _setup_postgresql(
        self,
        host: str,
        port: int,
        database: str,
        username: str,
        password: str
    ):
        """Set up PostgreSQL storage backend."""
        print("\nPostgreSQL Configuration")
        print("─" * 65)

        # Interactive prompts
        if self.interactive:
            host = input(f"Host [{host}]: ").strip() or host
            port_input = input(f"Port [{port}]: ").strip()
            port = int(port_input) if port_input else port
            database = input(f"Database name [{database}]: ").strip() or database
            username = input(f"Username [{username}]: ").strip() or username

            if not password:
                import getpass
                password = getpass.getpass("Password: ")

        # Check for environment variables if not provided
        if not password:
            import os
            password = os.getenv('WINTERFORGE_POSTGRESQL_PASSWORD')
            if not password:
                raise ValueError(
                    "PostgreSQL password required "
                    "(set via --pg-password or WINTERFORGE_POSTGRESQL_PASSWORD)"
                )

        # Test connection
        print("\nTesting connection...")
        from winterforge.plugins.storage.postgresql import PostgreSQLStorageBackend

        try:
            storage = PostgreSQLStorageBackend(
                host=host,
                port=port,
                database=database,
                user=username,
                password=password
            )

            # Set as default storage
            set_storage(storage)

            print("✓ PostgreSQL connection successful")
            print("✓ Schema initialized (frags table, GIN indexes)")

        except Exception as e:
            print(f"✗ Connection failed: {e}")
            raise

        # Store credentials as config Frags
        await self._store_postgresql_config(
            host, port, database, username, password
        )

        # Print environment variable instructions
        self._print_postgresql_env_vars(
            host, port, database, username, password
        )

        # Run bootstrappers
        await self._run_bootstrappers()

        return storage

    async def _setup_yaml(self):
        """Set up YAML storage backend."""
        print("\nYAML storage not yet implemented.")
        print("Please choose SQLite or PostgreSQL.")
        raise NotImplementedError("YAML storage backend")

    async def _run_bootstrappers(self):
        """Run all bootstrap plugins using repository pattern."""
        print("\n⏳ Running bootstrap plugins...")

        from winterforge.plugins.bootstrap import BootstrapperManager

        # Get repository and execute in order
        repo = BootstrapperManager.repository()
        results = {}

        for bs_id in repo.order():
            bootstrapper = BootstrapperManager.get(bs_id)
            result = await bootstrapper.bootstrap()
            results[bs_id] = result

        # Print results
        for bs_id, result in results.items():
            status = result.get('status', 'unknown')

            # Format output based on bootstrapper
            if bs_id == 'materialization':
                if status == 'created':
                    # Build message from all primitive types
                    counts = [
                        f"{count} {type_id}{'s' if count != 1 else ''}"
                        for type_id, count in result.items()
                        if type_id != 'status' and isinstance(count, int)
                    ]
                    print(f"  ✓ Materialized {', '.join(counts)}")
                elif status == 'skipped':
                    traits = result.get('traits', 0)
                    print(
                        f"  ⏭ Primitives already exist ({traits} traits)"
                    )
            else:
                # Generic output for other bootstrappers
                print(f"  ✓ {bs_id}: {status}")

    async def _store_postgresql_config(
        self, host: str, port: int, database: str, username: str, password: str
    ):
        """Store PostgreSQL credentials as config Frags."""
        # Note: Using hyphens in slugs (sluggable trait doesn't allow dots)
        # but dots in title for semantic grouping
        configs = {
            'database-host': ('database.host', host),
            'database-port': ('database.port', str(port)),
            'database-name': ('database.name', database),
            'database-username': ('database.username', username),
            'database-password': ('database.password', password)
        }

        # Use ConfigRegistry to create configs (handles field references)
        from winterforge.frags.registries.config_registry import ConfigRegistry
        config_registry = ConfigRegistry()

        for slug, (semantic_key, value) in configs.items():
            await config_registry.set_value(slug, value)

    def _print_postgresql_env_vars(
        self, host: str, port: int, database: str, username: str, password: str
    ):
        """Print environment variable export commands."""
        print("\nImportant: Store credentials securely")
        print("─" * 65)
        print("Add these to your environment for production use:\n")
        print(f"  export WINTERFORGE_POSTGRESQL_HOST={host}")
        print(f"  export WINTERFORGE_POSTGRESQL_PORT={port}")
        print(f"  export WINTERFORGE_POSTGRESQL_NAME={database}")
        print(f"  export WINTERFORGE_POSTGRESQL_USER={username}")
        print(f"  export WINTERFORGE_POSTGRESQL_PASSWORD={'•' * len(password)}\n")
        print("Or create a .env file:\n")
        print(f"  WINTERFORGE_POSTGRESQL_HOST={host}")
        print(f"  WINTERFORGE_POSTGRESQL_PORT={port}")
        print(f"  WINTERFORGE_POSTGRESQL_NAME={database}")
        print(f"  WINTERFORGE_POSTGRESQL_USER={username}")
        print(f"  WINTERFORGE_POSTGRESQL_PASSWORD={'•' * len(password)}\n")
        print("✓ Credentials also stored as config Frags (slug: database.*)")

    async def _import_plugin_config(self):
        """Import default plugin orderings as config Frags."""
        print("\n[2/5] Plugin Configuration")
        print("═" * 65)

        # Load YAML
        defaults_dir = Path(__file__).parent / 'defaults'
        plugins_yaml = defaults_dir / 'plugins.yaml'

        with open(plugins_yaml) as f:
            plugin_config = yaml.safe_load(f)

        # Create config Frags for each manager's ordering
        count = 0
        for manager_type, settings in plugin_config.items():
            if 'order' in settings:
                # Store as comma-separated string
                # Use hyphens in slug (sluggable trait requirement)
                slug = f'{manager_type.replace("_", "-")}-order'
                value = ','.join(settings['order'])

                # Use ConfigRegistry for consistent field handling
                from winterforge.frags.registries.config_registry import ConfigRegistry
                config_registry = ConfigRegistry()
                await config_registry.set_value(slug, value)
                count += 1

        print(f"\n✓ Imported {count} plugin orderings from defaults/plugins.yaml")
        print("  - Identity Resolvers: int, uuid, username, email, slug, title")
        print("  - Storage: sqlite, postgresql, yaml")
        print("  - Hashing: argon2, bcrypt")
        print("  - Session: frag, jwt")
        print("  - Token: jwt, frag")
        print("  - Email: smtp, console")
        print("  - Authentication: password")

    async def _import_framework_config(self):
        """Import framework configuration from defaults/config.yaml."""
        print("\n[3/5] Framework Configuration")
        print("═" * 65)

        # Load YAML
        defaults_dir = Path(__file__).parent / 'defaults'
        config_yaml = defaults_dir / 'config.yaml'

        with open(config_yaml) as f:
            config_data = yaml.safe_load(f)

        # Generate JWT secret
        print("\nGenerating JWT secret...")
        jwt_secret = secrets.token_hex(32)  # 64-character hex string
        print("✓ Generated random 64-character secret")

        # Flatten nested config and create Frags
        count = 0
        for section, settings in config_data.items():
            for key, value in settings.items():
                # Use hyphens in slug (sluggable trait requirement)
                slug = f"{section}-{key}".replace("_", "-")

                # Handle special values
                if value == '__GENERATED__':
                    if section == 'jwt' and key == 'secret':
                        value = jwt_secret
                    else:
                        value = secrets.token_hex(16)
                elif value == '__PROMPTED__':
                    # Already handled (e.g., database.password)
                    continue

                # Use ConfigRegistry for consistent field handling
                from winterforge.frags.registries.config_registry import ConfigRegistry
                config_registry = ConfigRegistry()
                await config_registry.set_value(slug, str(value))
                count += 1

        print(f"\n✓ Imported {count} configuration values from defaults/config.yaml")
        print("  - JWT: 4 values (secret, algorithm, token TTLs)")
        print("  - SMTP: 6 values (host, port, credentials, TLS)")
        print("  - Session: 3 values (TTL, max sessions, cleanup)")
        print("  - Auth: 7 values (lockout, password requirements)")
        print("  - Email Verification: 2 values")
        print("  - Password Reset: 2 values")

    async def _import_roles_and_permissions(self) -> Tuple[Dict, Dict]:
        """Import default roles and permissions from YAML."""
        print("\n[4/5] Roles & Permissions")
        print("═" * 65)

        defaults_dir = Path(__file__).parent / 'defaults'

        # Import permissions first
        with open(defaults_dir / 'permissions.yaml') as f:
            perms_config = yaml.safe_load(f)

        permissions = {}
        perm_titles = []

        for perm_data in perms_config['permissions']:
            perm = Frag(
                affinities=['permission'],
                traits=['fieldable', 'titled', 'persistable']
            )
            perm.set_title(perm_data['title'])
            await perm.save()
            permissions[perm.title] = perm
            perm_titles.append(perm.title)

        print(f"✓ Created {len(permissions)} permissions:")
        for title in perm_titles:
            print(f"  - {title}")

        # Import roles
        with open(defaults_dir / 'roles.yaml') as f:
            roles_config = yaml.safe_load(f)

        roles = {}

        for role_data in roles_config['roles']:
            role = Frag(
                affinities=['role'],
                traits=['fieldable', 'titled', 'permissioned', 'persistable']
            )
            role.set_title(role_data['title'])

            # Assign permissions
            perm_count = 0
            for perm_title in role_data.get('permissions', []):
                if perm_title in permissions:
                    role.add_permission(permissions[perm_title].id)
                    perm_count += 1

            await role.save()
            roles[role.title] = role

            print(f"\n✓ Created 1 role: {role.title}")
            print(f"✓ Assigned {perm_count} permissions to {role.title} role")

        return roles, permissions

    async def _create_admin_user(
        self, username: str, email: str, password: str
    ):
        """Create initial admin user with admin role."""
        print("\n[5/5] Admin User")
        print("═" * 65)

        # Interactive prompts
        if self.interactive:
            username = input(f"Admin username [{username}]: ").strip() or username

            # Prompt for email with validation
            if not email:
                while True:
                    email = input("Admin email: ").strip()
                    is_valid, error = validate_input(
                        email,
                        ['required', 'email'],
                        'Admin email'
                    )
                    if is_valid:
                        break
                    print(f"✗ {error}")

            # Prompt for password with validation
            if not password:
                import getpass
                while True:
                    password = getpass.getpass("Admin password: ")

                    # Validate password strength
                    is_valid, error = validate_input(
                        password,
                        ['required', 'password_validators.simple'],
                        'Password'
                    )
                    if not is_valid:
                        print(f"✗ {error}")
                        continue

                    # Confirm password
                    password_confirm = getpass.getpass(
                        "Repeat for confirmation: "
                    )
                    if password == password_confirm:
                        break
                    print("✗ Passwords don't match. Try again.")

        # Validate inputs
        if not email:
            raise ValueError("Admin email required")
        if not password:
            raise ValueError("Admin password required")

        # Create user Frag
        from winterforge.frags.registries.role_registry import RoleRegistry

        user = Frag(
            affinities=['user'],
            traits=[
                'userable',
                'authenticatable',
                'authorizable',
                'sessionable',
                'timestamped',
                'persistable'
            ]
        )
        user.set_username(username)
        user.set_email(email)
        user.set_password(password)
        user.mark_email_verified()  # Admin pre-verified
        await user.save()

        # Assign admin role
        roles = RoleRegistry()
        admin_role = await roles.get('admin')

        if admin_role:
            user.add_role(admin_role.id)
            await user.save()

            # Get permission count
            perms = await admin_role.get_permissions()
            perm_count = len(perms)

            print(f"✓ Created admin user (ID: {user.id})")
            print(f"✓ Assigned 'admin' role ({perm_count} permissions)")
            print("✓ Email marked as verified (admin pre-verified)")
        else:
            print(f"✓ Created admin user (ID: {user.id})")
            print("✗ Warning: Admin role not found (was it skipped?)")

        return user

    def _print_completion_summary(self):
        """Print installation completion summary."""
        print(f"\n{'═' * 65}")
        print("Installation Complete!")
        print(f"{'═' * 65}")

        print("\nProject Configuration:")
        print("  Database:    ./winterforge.db (SQLite)")
        print("  Admin User:  admin (admin@example.com)")
        print("  Roles:       1 (admin)")
        print("  Permissions: 7")
        print("  Config:      32 framework settings (including plugin orderings)")

        print("\nNext Steps:")
        print("  1. Configure storage in your application:")
        print("     ")
        print("     from winterforge.plugins import StorageManager, discover_plugins")
        print("     from winterforge.frags.traits.persistable import set_storage")
        print("     ")
        print("     discover_plugins()")
        print("     storage = StorageManager.get('sqlite', db_path='./winterforge.db')")
        print("     set_storage(storage)")
        print("  ")
        print("  2. Apply plugin orderings (optional):")
        print("     # See Phase 5 documentation")
        print("  ")
        print("  3. Manage users:")
        print("     ")
        print("     winterforge user --help")
        print("     winterforge role --help")
        print("     winterforge permission --help")

        print("\nDocumentation: See QUICKSTART.md for examples")
        print("\nHappy building! 🎉")
