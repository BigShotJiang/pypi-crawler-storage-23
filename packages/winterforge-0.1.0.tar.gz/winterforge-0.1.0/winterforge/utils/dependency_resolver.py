"""
Reusable dependency resolution for plugins and traits.

Universal dependency resolution algorithm used across the framework
for ordering items based on their dependencies.
"""

from __future__ import annotations

from typing import Any


class DependencyResolver:
    """
    Universal dependency resolution with cycle detection.

    Handles topological sorting for any dependency graph.
    Used by both trait system and plugin scoping.
    """

    @staticmethod
    def resolve_order(items: dict[str, list[str]]) -> list[str]:
        """
        Resolve dependency order (dependencies first).

        Uses Kahn's algorithm for topological sorting.
        Items with no dependencies come first (roots),
        then items that depend on them (leaves).

        Args:
            items: Dict mapping item_id to list of dependency_ids
                (things this item depends on)

        Returns:
            List of item_ids in dependency order (dependencies first)

        Raises:
            ValueError: If circular dependency detected

        Example:
            items = {
                'a': [],      # No dependencies
                'b': ['a'],   # Depends on 'a'
                'c': ['b']    # Depends on 'b'
            }
            order = DependencyResolver.resolve_order(items)
            # Returns: ['a', 'b', 'c']
        """
        # Build in-degree map (how many things I depend on)
        in_degree = {item_id: len(deps) for item_id, deps in items.items()}

        # Start with items that have no dependencies (roots)
        queue = [iid for iid, deg in in_degree.items() if deg == 0]
        result = []

        # Build reverse map (what depends on me)
        dependents = {item_id: [] for item_id in items}
        for item_id, deps in items.items():
            for dep in deps:
                if dep in dependents:
                    dependents[dep].append(item_id)

        while queue:
            item_id = queue.pop(0)
            result.append(item_id)

            # Decrease in-degree for items that depend on this one
            for dependent in dependents.get(item_id, []):
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)

        # Check for cycles
        if len(result) != len(items):
            raise ValueError("Circular dependency detected")

        return result

    @staticmethod
    def build_tree(
        item_id: str,
        reverse_map: dict[str, list[str]]
    ) -> dict[str, Any]:
        """
        Build dependency tree (recursive).

        Creates a tree structure showing an item and all items
        that depend on it (children).

        Args:
            item_id: Root item identifier
            reverse_map: Dict mapping parent_id to list of child_ids
                (items that depend on parent)

        Returns:
            Tree structure: {'id': str, 'children': [tree, ...]}

        Example:
            reverse_map = {
                'prettier': ['panel', 'table']  # panel/table scope to prettier
            }
            tree = DependencyResolver.build_tree('prettier', reverse_map)
            # {
            #   'id': 'prettier',
            #   'children': [
            #     {'id': 'panel', 'children': []},
            #     {'id': 'table', 'children': []}
            #   ]
            # }
        """
        children = reverse_map.get(item_id, [])

        return {
            'id': item_id,
            'children': [
                DependencyResolver.build_tree(child, reverse_map)
                for child in children
            ]
        }

    @staticmethod
    def traverse_to_list(
        tree: dict[str, Any],
        all_items: dict[str, Any]
    ) -> list[tuple[str, Any]]:
        """
        Traverse tree to flat list (child→sibling→parent).

        Performs depth-first traversal, processing children before parent.
        Returns ordered list suitable for Repository construction.

        Args:
            tree: Tree structure from build_tree()
            all_items: Dict mapping item_id to item object

        Returns:
            List of (id, item) tuples in processing order

        Example:
            tree = {
                'id': 'prettier',
                'children': [
                    {'id': 'panel', 'children': []},
                    {'id': 'table', 'children': []}
                ]
            }
            items = {'prettier': A, 'panel': B, 'table': C}
            result = DependencyResolver.traverse_to_list(tree, items)
            # [('panel', B), ('table', C), ('prettier', A)]
        """
        result = []

        # Depth-first: children first
        for child_tree in tree.get('children', []):
            result.extend(
                DependencyResolver.traverse_to_list(child_tree, all_items)
            )

        # Then this node
        item_id = tree['id']
        if item_id in all_items:
            result.append((item_id, all_items[item_id]))

        return result
