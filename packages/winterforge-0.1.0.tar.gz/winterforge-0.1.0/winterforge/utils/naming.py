"""Naming convention utilities for decorator key derivation."""

import re
from typing import Optional

# Common suffixes to strip during derivation
COMMON_SUFFIXES = [
    'Trait',
    'Provider',
    'Backend',
    'Manager',
    'Registry',
    'Plugin',
    'Resolver',
    'Formatter',
    'Convertor',
    'Printer',
    'Redirect',
    'Executor',
    'Strategy',
    'Dispatcher',
    'Listener',
]


def derive_key_from_name(
    name: str,
    *,
    strip_suffixes: bool = True,
    to_kebab_case: bool = True
) -> str:
    """
    Derive decorator key from Python identifier.

    Applies universal naming conventions:
    1. Strip common suffixes (Trait, Provider, etc.)
    2. Convert CamelCase to snake_case
    3. Convert snake_case to kebab-case

    Args:
        name: Python class, method, or function name
        strip_suffixes: Remove common suffixes
        to_kebab_case: Convert to kebab-case

    Returns:
        Decorator registration key

    Examples:
        >>> derive_key_from_name('UserableTrait')
        'userable'
        >>> derive_key_from_name('set_password')
        'set-password'
        >>> derive_key_from_name('SQLiteStorageBackend')
        'sqlite-storage'
        >>> derive_key_from_name('JWTSessionProvider')
        'jwt-session'
        >>> derive_key_from_name('HasPermissionTrait')
        'has-permission'
    """
    result = name

    # Step 1: Strip common suffixes
    if strip_suffixes:
        for suffix in COMMON_SUFFIXES:
            if result.endswith(suffix) and len(result) > len(suffix):
                result = result[:-len(suffix)]
                break

    # Step 2: Convert CamelCase to snake_case
    # Handle acronyms: SQLite → sqlite, JWT → jwt
    result = re.sub('([A-Z]+)([A-Z][a-z])', r'\1_\2', result)
    result = re.sub('([a-z\d])([A-Z])', r'\1_\2', result)
    result = result.lower()

    # Step 3: Convert snake_case to kebab-case
    if to_kebab_case:
        result = result.replace('_', '-')

    return result


def validate_key(key: str) -> None:
    """
    Validate decorator key format.

    Rules:
    - Lowercase alphanumeric with hyphens
    - Must start and end with alphanumeric
    - No consecutive hyphens

    Args:
        key: Decorator key to validate

    Raises:
        ValueError: If key format is invalid

    Examples:
        >>> validate_key('userable')  # OK
        >>> validate_key('set-password')  # OK
        >>> validate_key('sqlite-storage')  # OK
        >>> validate_key('SetPassword')  # ValueError
        >>> validate_key('set_password')  # ValueError
        >>> validate_key('-userable')  # ValueError
    """
    pattern = r'^[a-z0-9]+(-[a-z0-9]+)*$'
    if not re.match(pattern, key):
        raise ValueError(
            f"Invalid decorator key '{key}'. "
            f"Must match pattern: {pattern} "
            f"(lowercase alphanumeric with hyphens, no leading/trailing hyphens)"
        )


def get_root_key(cls: type) -> Optional[str]:
    """
    Get canonical key from @root decorator if present.

    Args:
        cls: Class to inspect

    Returns:
        Root key if @root decorator present, None otherwise

    Examples:
        >>> @root('sqlite')
        >>> class SQLiteStorageBackend:
        ...     pass
        >>> get_root_key(SQLiteStorageBackend)
        'sqlite'
        >>>
        >>> class NoRootClass:
        ...     pass
        >>> get_root_key(NoRootClass)
        None
    """
    # Check for _root_key attribute set by @root decorator
    return getattr(cls, '_root_key', None)
