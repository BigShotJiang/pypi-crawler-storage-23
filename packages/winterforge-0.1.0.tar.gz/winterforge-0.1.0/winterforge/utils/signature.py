"""Function signature inspection utilities."""

import inspect
from typing import Dict, Any, Callable
from dataclasses import dataclass


@dataclass
class ArgumentMetadata:
    """
    Metadata extracted from function parameter.

    Attributes:
        name: Parameter name
        type_hint: Type annotation (defaults to str if not annotated)
        required: True if no default value provided
        default: Default value (None if required)
        kind: Parameter kind (POSITIONAL_OR_KEYWORD, KEYWORD_ONLY, etc.)
    """

    name: str
    type_hint: type
    required: bool
    default: Any
    kind: str

    def __repr__(self) -> str:
        """String representation for debugging."""
        req_str = "required" if self.required else f"default={self.default!r}"
        return (
            f"ArgumentMetadata("
            f"name={self.name!r}, "
            f"type={self.type_hint.__name__}, "
            f"{req_str})"
        )


def extract_signature(func: Callable) -> Dict[str, ArgumentMetadata]:
    """
    Extract argument metadata from function signature.

    Inspects function signature and type hints to build metadata
    for each parameter. Skips 'self' and 'cls' parameters.

    Args:
        func: Function to inspect

    Returns:
        Dict mapping parameter names to ArgumentMetadata

    Examples:
        >>> def create(self, username: str, email: str, *, admin: bool = False):
        ...     pass
        >>> args = extract_signature(create)
        >>> args['username'].required
        True
        >>> args['username'].type_hint
        <class 'str'>
        >>> args['admin'].default
        False
        >>> args['admin'].kind
        'KEYWORD_ONLY'
    """
    sig = inspect.signature(func)

    # Get type hints (handle functions without annotations)
    try:
        from typing import get_type_hints
        type_hints = get_type_hints(func)
    except (AttributeError, NameError):
        # get_type_hints can fail on some edge cases
        type_hints = {}

    arguments = {}
    for param_name, param in sig.parameters.items():
        # Skip 'self' and 'cls'
        if param_name in ('self', 'cls'):
            continue

        arguments[param_name] = ArgumentMetadata(
            name=param_name,
            type_hint=type_hints.get(param_name, str),
            required=param.default == inspect.Parameter.empty,
            default=(
                None
                if param.default == inspect.Parameter.empty
                else param.default
            ),
            kind=param.kind.name,
        )

    return arguments


def extract_docstring_help(func: Callable) -> Dict[str, str]:
    """
    Extract help text from function docstring.

    Parses docstrings to extract parameter descriptions.
    Currently returns empty dict - full implementation TBD.

    Args:
        func: Function to inspect

    Returns:
        Dict mapping parameter names to help text

    Examples:
        >>> def create(username: str):
        ...     '''Create user.
        ...
        ...     Args:
        ...         username: The username to create
        ...     '''
        ...     pass
        >>> help_text = extract_docstring_help(create)
        >>> # help_text['username'] == 'The username to create'
    """
    # TODO: Implement docstring parsing
    # Could use libraries like docstring_parser or parse manually
    # For now, return empty dict
    return {}
