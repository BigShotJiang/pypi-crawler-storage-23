"""Utilities for running async code from synchronous contexts."""

import asyncio
import functools
from typing import Callable, Any


def to_sync(async_func: Callable) -> Callable:
    """
    Decorator to convert an async function to a synchronous one.

    This allows async functions to be called from synchronous contexts
    by automatically running them in an event loop. Similar to Django's
    async_to_sync decorator.

    Usage:
        @to_sync
        async def my_async_function(arg):
            await some_async_operation()
            return result

        # Can now call synchronously
        result = my_async_function(arg)

    Note:
        - Creates a new event loop if none exists
        - Raises error if called from within an existing running loop
        - For best performance, use async functions natively when possible

    Args:
        async_func: The async function to wrap

    Returns:
        A synchronous function that runs the async function

    Raises:
        RuntimeError: If called from within a running event loop
    """
    @functools.wraps(async_func)
    def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
        # Check if we're already in an async context
        try:
            loop = asyncio.get_running_loop()
            # If we get here, we're in a running loop - can't use asyncio.run()
            raise RuntimeError(
                f"Cannot call {async_func.__name__} from an async context. "
                f"Use 'await {async_func.__name__}(...)' instead of calling it synchronously."
            )
        except RuntimeError:
            # No running loop - safe to create one
            pass

        # Run the async function in a new event loop
        return asyncio.run(async_func(*args, **kwargs))

    return sync_wrapper


def run_sync(coro: Any) -> Any:
    """
    Run a coroutine synchronously.

    Helper function for one-off async operations in sync contexts.

    Usage:
        result = run_sync(some_async_function(arg))

    Args:
        coro: A coroutine object (result of calling an async function)

    Returns:
        The result of the coroutine

    Raises:
        RuntimeError: If called from within a running event loop
    """
    try:
        loop = asyncio.get_running_loop()
        raise RuntimeError(
            "Cannot use run_sync() from an async context. "
            "Use 'await' instead."
        )
    except RuntimeError:
        pass

    return asyncio.run(coro)
