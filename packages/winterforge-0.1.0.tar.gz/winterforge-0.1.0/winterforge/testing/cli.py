"""CLI testing utilities.

Provides validation helpers for ensuring CLI command quality,
consistency, and adherence to architectural patterns.
"""

from typing import Dict, List, Set, Tuple, Optional
from dataclasses import dataclass


@dataclass
class ValidationIssue:
    """Represents a validation issue found during testing."""

    severity: str  # 'error', 'warning', 'info'
    category: str  # 'collision', 'redundancy', 'naming', etc.
    message: str
    location: str  # Class/method location
    suggestion: Optional[str] = None


class CLITestHelper:
    """
    Helper for testing CLI command patterns and validation.

    Provides utilities to:
    - Validate all @root usage across codebase
    - Detect command name collisions
    - Check for redundant identifiers (user.delete-user)
    - Validate naming conventions
    - Generate test reports

    Example:
        # In test suite
        def test_cli_commands_valid():
            issues = CLITestHelper.validate_all_roots()
            assert len(issues) == 0, f"CLI validation failed:\\n{issues}"

        # Check specific root namespace
        issues = CLITestHelper.validate_root('user')
        for issue in issues:
            if issue.severity == 'error':
                pytest.fail(issue.message)
    """

    @classmethod
    def validate_all_roots(cls) -> List[ValidationIssue]:
        """
        Validate all @root namespaces and their commands.

        Checks:
        - Command name collisions within namespace
        - Redundant identifiers (root name in command name)
        - Invalid command names (dunder, private methods)
        - Duplicate aliases
        - Missing commands in namespace

        Returns:
            List of validation issues (errors, warnings, info)

        Example:
            issues = CLITestHelper.validate_all_roots()
            errors = [i for i in issues if i.severity == 'error']
            if errors:
                print("Found errors:")
                for err in errors:
                    print(f"  - {err.message}")
        """
        from winterforge.plugins.cli._manager import CLICommandManager

        issues: List[ValidationIssue] = []

        # Ensure parent commands are resolved
        CLICommandManager.resolve_parent_commands()

        # Get all groups
        groups = CLICommandManager.get_all_groups()

        for group_name, group_meta in groups.items():
            # Validate this root namespace
            group_issues = cls.validate_root(group_name)
            issues.extend(group_issues)

        return issues

    @classmethod
    def validate_root(cls, root_name: str) -> List[ValidationIssue]:
        """
        Validate a specific @root namespace.

        Args:
            root_name: Root namespace to validate (e.g., 'user', 'admin')

        Returns:
            List of validation issues for this namespace

        Example:
            issues = CLITestHelper.validate_root('user')
            for issue in issues:
                print(f"{issue.severity}: {issue.message}")
        """
        from winterforge.plugins.cli._manager import CLICommandManager

        issues: List[ValidationIssue] = []

        # Ensure parent commands are resolved
        CLICommandManager.resolve_parent_commands()

        # Get commands for this root
        commands = CLICommandManager.get_commands_for_group(root_name)

        if not commands:
            issues.append(
                ValidationIssue(
                    severity='warning',
                    category='empty_namespace',
                    message=f"Root namespace '{root_name}' has no commands",
                    location=f"@root('{root_name}')",
                    suggestion="Add @cli_command methods or remove unused @root"
                )
            )
            return issues

        # Check for command name collisions
        command_names: Dict[str, List[str]] = {}
        for cmd in commands:
            name = cmd['name']
            location = f"{cmd.get('parent_class', 'unknown').__name__}.{cmd['callable'].__name__}"
            command_names.setdefault(name, []).append(location)

        for name, locations in command_names.items():
            if len(locations) > 1:
                issues.append(
                    ValidationIssue(
                        severity='error',
                        category='collision',
                        message=f"Command name '{name}' appears {len(locations)} times in '{root_name}'",
                        location=', '.join(locations),
                        suggestion=f"Rename commands to be unique within '{root_name}' namespace"
                    )
                )

        # Check for redundant identifiers
        for cmd in commands:
            name = cmd['name']
            location = f"{cmd.get('parent_class', 'unknown').__name__}.{cmd['callable'].__name__}"

            # Check if command name contains root name
            if root_name in name and name != root_name:
                issues.append(
                    ValidationIssue(
                        severity='warning',
                        category='redundancy',
                        message=f"Command '{name}' contains root name '{root_name}' (redundant)",
                        location=location,
                        suggestion=f"Rename method to remove '{root_name}' prefix/suffix"
                    )
                )

        # Check for alias collisions and duplicates
        all_aliases: Dict[str, List[str]] = {}
        for cmd in commands:
            aliases = cmd.get('aliases', [])
            location = f"{cmd.get('parent_class', 'unknown').__name__}.{cmd['callable'].__name__}"
            for alias in aliases:
                all_aliases.setdefault(alias, []).append(location)

        for alias, locations in all_aliases.items():
            if len(locations) > 1:
                issues.append(
                    ValidationIssue(
                        severity='error',
                        category='alias_collision',
                        message=f"Alias '{alias}' used by {len(locations)} commands in '{root_name}'",
                        location=', '.join(locations),
                        suggestion=f"Ensure aliases are unique within '{root_name}' namespace"
                    )
                )

        # Check for alias/command name conflicts
        command_name_set = set(cmd['name'] for cmd in commands)
        for alias, locations in all_aliases.items():
            if alias in command_name_set:
                issues.append(
                    ValidationIssue(
                        severity='error',
                        category='alias_conflict',
                        message=f"Alias '{alias}' conflicts with command name in '{root_name}'",
                        location=locations[0],
                        suggestion=f"Choose alias that doesn't match existing command name"
                    )
                )

        return issues

    @classmethod
    def get_command_report(cls, root_name: str) -> str:
        """
        Generate a formatted report of all commands in a root namespace.

        Args:
            root_name: Root namespace to report on

        Returns:
            Formatted string report

        Example:
            report = CLITestHelper.get_command_report('user')
            print(report)

            # Output:
            # Root: user
            # Commands: 8
            #   - create-user (UserRegistry.create)
            #   - delete-user (UserRegistry.delete_user)
            #   ...
        """
        from winterforge.plugins.cli._manager import CLICommandManager

        # Ensure parent commands are resolved
        CLICommandManager.resolve_parent_commands()

        commands = CLICommandManager.get_commands_for_group(root_name)

        lines = [
            f"Root: {root_name}",
            f"Commands: {len(commands)}",
        ]

        for cmd in sorted(commands, key=lambda c: c['name']):
            parent = cmd.get('parent_class')
            parent_name = parent.__name__ if parent else 'unknown'
            func_name = cmd['callable'].__name__

            aliases = cmd.get('aliases', [])
            alias_str = f" (aliases: {', '.join(aliases)})" if aliases else ""

            lines.append(f"  - {cmd['name']} ({parent_name}.{func_name}){alias_str}")

        return '\n'.join(lines)

    @classmethod
    def assert_no_collisions(cls, root_name: str) -> None:
        """
        Assert that a root namespace has no command name collisions.

        Raises AssertionError if collisions found.

        Args:
            root_name: Root namespace to check

        Example:
            def test_user_commands_no_collisions():
                CLITestHelper.assert_no_collisions('user')
        """
        issues = cls.validate_root(root_name)
        collisions = [i for i in issues if i.category in ('collision', 'alias_collision', 'alias_conflict')]

        if collisions:
            messages = [f"  - {issue.message}" for issue in collisions]
            raise AssertionError(
                f"Command collisions in '{root_name}' namespace:\n{'\n'.join(messages)}"
            )

    @classmethod
    def assert_no_redundancy(cls, root_name: str) -> None:
        """
        Assert that command names don't redundantly include root name.

        Raises AssertionError if redundant names found.

        Args:
            root_name: Root namespace to check

        Example:
            def test_user_commands_no_redundancy():
                CLITestHelper.assert_no_redundancy('user')
        """
        issues = cls.validate_root(root_name)
        redundancy = [i for i in issues if i.category == 'redundancy']

        if redundancy:
            messages = [f"  - {issue.message}" for issue in redundancy]
            raise AssertionError(
                f"Redundant identifiers in '{root_name}' namespace:\n{'\n'.join(messages)}"
            )

    @classmethod
    def get_all_roots(cls) -> List[str]:
        """
        Get all registered root namespaces.

        Returns:
            List of root namespace names

        Example:
            roots = CLITestHelper.get_all_roots()
            print(f"Registered roots: {', '.join(roots)}")
        """
        from winterforge.plugins.cli._manager import CLICommandManager

        CLICommandManager.resolve_parent_commands()
        groups = CLICommandManager.get_all_groups()
        return sorted(groups.keys())

    @classmethod
    def print_all_commands(cls) -> None:
        """
        Print a report of all registered CLI commands.

        Useful for debugging and documentation.

        Example:
            # Print all commands
            CLITestHelper.print_all_commands()
        """
        roots = cls.get_all_roots()

        print(f"\n{'=' * 60}")
        print("WinterForge CLI Commands")
        print(f"{'=' * 60}")

        for root in roots:
            print(f"\n{cls.get_command_report(root)}")
            print(f"{'-' * 60}")
