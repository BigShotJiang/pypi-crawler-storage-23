"""Matchable plugin mixin - provides is_match() protocol."""

from __future__ import annotations

from typing import Any


class MatchablePlugin:
    """
    Mixin for plugins that support matching/filtering.

    Provides default is_match() that returns True.
    Plugins override for custom logic.

    Used by resolution chains:
    - Identity resolvers (can this resolve X?)
    - Query strategies (can this optimize X?)
    - Cache backends (can this handle X?)
    - Event handlers (does this match X?)
    - Index backends (can this optimize X?)

    Example:
        class MyResolver(MatchablePlugin):
            def is_match(self, identity: Any) -> bool:
                return isinstance(identity, str) and '@' in identity

        # Repository filtering
        repo.filter(lambda p: p.is_match(identity))
    """

    def is_match(self, *args: Any, **kwargs: Any) -> bool:
        """
        Check if this plugin matches the given criteria.

        Default: Returns True (always matches).
        Override in subclasses for custom matching logic.

        Args:
            *args: Positional match criteria
            **kwargs: Named match criteria

        Returns:
            True if plugin matches criteria, False otherwise

        Example:
            # Identity resolver
            def is_match(self, identity: Any) -> bool:
                return isinstance(identity, int)

            # Query strategy
            def is_match(self, query_params: dict) -> bool:
                return 'indexed_field' in query_params

            # Event handler
            def is_match(self, event_path: str) -> bool:
                return event_path.startswith('user.')
        """
        return True


__all__ = ['MatchablePlugin']
