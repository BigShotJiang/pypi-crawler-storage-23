"""HTTP request handler plugins."""

from winterforge.plugins.http_request.manager import (
    HTTPRequestHandlerManager
)

# Import plugins to trigger decorator registration
from winterforge.plugins.http_request import (  # noqa: F401
    json_handler,
    form_handler,
)

__all__ = [
    'HTTPRequestHandlerManager',
    'json_handler',
    'form_handler',
]
