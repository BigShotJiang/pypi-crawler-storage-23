"""Form data HTTP request handler."""

from typing import Any, Dict, TYPE_CHECKING
from winterforge.plugins.decorators import http_request_handler, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@http_request_handler()
@root('form')
class FormRequestHandler:
    """
    Form data HTTP request handler.

    Extracts form-encoded request bodies into HTTPRequest Frags.
    Applies when Content-Type is application/x-www-form-urlencoded.
    """

    def applies_to(self, request: Any, config: Dict[str, Any]) -> bool:
        """
        Apply when Content-Type is application/x-www-form-urlencoded.

        Args:
            request: HTTP request object
            config: Handler configuration

        Returns:
            True if Content-Type is form-urlencoded
        """
        content_type = ''
        if hasattr(request, 'headers'):
            content_type = request.headers.get('content-type', '')
        elif hasattr(request, 'content_type'):
            content_type = request.content_type or ''

        return 'application/x-www-form-urlencoded' in content_type.lower()

    async def extract(
        self,
        request: Any,
        config: Dict[str, Any]
    ) -> 'Frag':
        """
        Extract form data into HTTPRequest Frag.

        Args:
            request: HTTP request object
            config: Handler configuration

        Returns:
            Frag with http_request trait
        """
        from winterforge.frags.base import Frag

        # Create HTTPRequest Frag
        request_frag = Frag(
            affinities=['http_request', 'form'],
            traits=['http-request']
        )

        # Set method and path
        request_frag.set_method(request.method)
        if hasattr(request, 'url'):
            request_frag.set_path(str(request.url.path))
            if request.url.query:
                query_params = dict(request.query_params)
                request_frag.set_query_params(query_params)
        else:
            request_frag.set_path(getattr(request, 'path', ''))

        # Set headers
        if hasattr(request, 'headers'):
            headers = dict(request.headers)
            request_frag.set_headers(headers)

        # Extract path params if available
        if hasattr(request, 'path_params'):
            request_frag.set_path_params(dict(request.path_params))

        # Parse form data
        try:
            if hasattr(request, 'form'):
                form_data = await request.form()
                # Convert to dict
                body = {key: form_data[key] for key in form_data.keys()}
            else:
                body = {}
            request_frag.set_body(body)
        except Exception:
            request_frag.set_body({})

        request_frag.set_content_type('application/x-www-form-urlencoded')

        return request_frag
