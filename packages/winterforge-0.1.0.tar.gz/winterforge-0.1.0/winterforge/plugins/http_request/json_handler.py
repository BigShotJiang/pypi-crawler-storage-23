"""JSON HTTP request handler."""

from typing import Any, Dict, TYPE_CHECKING
from winterforge.plugins.decorators import http_request_handler, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@http_request_handler()
@root('json')
class JSONRequestHandler:
    """
    JSON HTTP request handler.

    Extracts JSON request bodies into HTTPRequest Frags.
    Applies when Content-Type is application/json.
    """

    def applies_to(self, request: Any, config: Dict[str, Any]) -> bool:
        """
        Apply when Content-Type is application/json or GET/DELETE.

        Args:
            request: HTTP request object
            config: Handler configuration

        Returns:
            True if Content-Type is application/json or GET/DELETE request
        """
        # GET and DELETE requests typically don't have bodies
        # Handle them with JSON handler by default
        method = getattr(request, 'method', 'GET').upper()
        if method in ('GET', 'DELETE', 'HEAD', 'OPTIONS'):
            return True

        content_type = ''
        if hasattr(request, 'headers'):
            content_type = request.headers.get('content-type', '')
        elif hasattr(request, 'content_type'):
            content_type = request.content_type or ''

        return 'application/json' in content_type.lower()

    async def extract(
        self,
        request: Any,
        config: Dict[str, Any]
    ) -> 'Frag':
        """
        Extract JSON request into HTTPRequest Frag.

        Args:
            request: HTTP request object
            config: Handler configuration

        Returns:
            Frag with http_request trait
        """
        from winterforge.frags.base import Frag

        # Create HTTPRequest Frag
        request_frag = Frag(
            affinities=['http-request', 'json'],
            traits=['http-request']
        )

        # Set method and path
        request_frag.set_method(request.method)
        if hasattr(request, 'url'):
            # FastAPI Request object
            request_frag.set_path(str(request.url.path))
            # Extract query params
            if request.url.query:
                query_params = dict(request.query_params)
                request_frag.set_query_params(query_params)
        else:
            request_frag.set_path(getattr(request, 'path', ''))

        # Set headers
        if hasattr(request, 'headers'):
            headers = dict(request.headers)
            request_frag.set_headers(headers)

        # Extract path params if available
        if hasattr(request, 'path_params'):
            request_frag.set_path_params(dict(request.path_params))

        # Parse JSON body
        try:
            if hasattr(request, 'json'):
                body = await request.json()
            else:
                # Fallback for custom request objects
                import json
                body_bytes = await request.body()
                body = json.loads(body_bytes) if body_bytes else {}
            request_frag.set_body(body)
        except Exception:
            # Empty or invalid JSON - set empty body
            request_frag.set_body({})

        request_frag.set_content_type('application/json')

        return request_frag
