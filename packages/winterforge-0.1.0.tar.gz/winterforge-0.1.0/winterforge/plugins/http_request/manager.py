"""HTTP request handler manager.

Manages registration and resolution of HTTP request handler plugins.
Uses standard "first match wins" pattern based on applicability.
"""

from typing import Any, Dict, TYPE_CHECKING
from winterforge.plugins._base import ReorderablePluginManagerBase

if TYPE_CHECKING:
    from winterforge.plugins._protocols.http import HTTPRequestHandler
    from winterforge.frags.base import Frag


class HTTPRequestHandlerManager(ReorderablePluginManagerBase):
    """
    Manager for HTTP request handler plugins.

    Uses standard reconciliation pattern: query all handlers,
    first one that applies_to() wins.

    Example:
        # Extract request using first applicable handler
        request_frag = await HTTPRequestHandlerManager.extract(
            request,
            config={'content_type': 'application/json'}
        )
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.http_request_handlers'

    @classmethod
    async def extract(
        cls,
        request: Any,
        config: Dict[str, Any] = None
    ) -> 'Frag':
        """
        Extract HTTP request into Frag using first applicable handler.

        Queries all handlers in order, uses first match.

        Args:
            request: HTTP request object (FastAPI Request, etc)
            config: Handler configuration dict

        Returns:
            Frag with http_request trait

        Raises:
            RuntimeError: If no handler applies
        """
        config = config or {}

        # Query handlers in order
        for handler_id in cls.repository().order():
            handler = cls.get(handler_id)
            if handler and handler.applies_to(request, config):
                return await handler.extract(request, config)

        # Fallback: no handler applied
        raise RuntimeError(
            f"No HTTP request handler applies to request: "
            f"{request.method} {request.url}"
        )
