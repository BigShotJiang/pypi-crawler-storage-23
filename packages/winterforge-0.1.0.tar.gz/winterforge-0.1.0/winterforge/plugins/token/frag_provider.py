"""Frag token provider.

Stateful token storage using Frags (revocable, trackable).
"""

from __future__ import annotations

from typing import Optional
from datetime import datetime, timedelta
import secrets

from winterforge.plugins.decorators import token_provider, root


@token_provider()
@root('frag')
class FragTokenProvider:
    """
    Stateful token storage using Frags (revocable, trackable).

    Tokens are stored as Frags with affinity=['token'], allowing them
    to be revoked and tracked. Useful when token revocation is required.

    Example:
        provider = await TokenProviderManager.get('frag')
        token = await provider.generate(
            user_id=123,
            token_type='password_reset',
            ttl=3600
        )
        user_id = await provider.verify(token, 'password_reset')
        await provider.invalidate(token)
    """

    async def generate(self, user_id: int, token_type: str, ttl: int, **metadata) -> str:
        """
        Generate random token and store as Frag.

        Args:
            user_id: User Frag ID
            token_type: Token type ('password_reset', 'email_verify', etc.)
            ttl: Time-to-live in seconds
            **metadata: Additional metadata to store

        Returns:
            Random token string
        """
        from winterforge.frags.base import Frag

        token_str = secrets.token_urlsafe(32)
        expires_at = datetime.now() + timedelta(seconds=ttl)

        token = Frag(
            affinities=['token'],
            traits=['tokenable', 'timestamped', 'ownable', 'persistable']
        )
        token.set_token(token_str)
        token.set_token_type(token_type)
        token.set_owner(user_id)
        token.set_expires_at(expires_at)

        if metadata:
            for key, value in metadata.items():
                token.set_metadata(key, value)

        await token.save()
        return token_str

    async def verify(self, token: str, token_type: str) -> Optional[int]:
        """
        Look up token Frag and verify.

        Args:
            token: Token string
            token_type: Expected token type

        Returns:
            User ID if valid, None otherwise
        """
        from winterforge.frags.registries.frag_registry import FragRegistry

        registry = FragRegistry({'affinities': ['token'], 'traits': ['tokenable']})
        filtered_registry = await registry.filter(
            lambda t: (
                t.token == token and
                t.token_type == token_type and
                t.expires_at > datetime.now()
            )
        )
        tokens = await filtered_registry.all()

        return tokens[0].owner_id if tokens else None

    async def invalidate(self, token: str) -> bool:
        """
        Delete token Frag.

        Args:
            token: Token string

        Returns:
            True if invalidated, False if not found
        """
        from winterforge.frags.registries.frag_registry import FragRegistry

        registry = FragRegistry({'affinities': ['token'], 'traits': ['tokenable']})
        filtered_registry = await registry.filter(lambda t: t.token == token)
        tokens = await filtered_registry.all()

        if tokens:
            await tokens[0].delete()
            return True
        return False
