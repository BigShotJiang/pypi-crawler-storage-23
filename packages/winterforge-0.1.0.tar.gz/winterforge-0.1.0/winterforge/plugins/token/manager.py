"""Token provider manager.

Manages one-time token implementations (password reset, email verification, etc.).
"""

from __future__ import annotations

from typing import Optional

from winterforge.plugins._base import ReorderablePluginManagerBase


class TokenProviderManager(ReorderablePluginManagerBase):
    """
    Manages one-time token provider implementations.

    Provides centralized access to token providers for one-time operations
    like password reset and email verification.

    Example:
        # Generate reset token
        token = await TokenProviderManager.generate_token(
            user_id=123,
            token_type='password_reset',
            ttl=3600
        )

        # Verify token
        user_id = await TokenProviderManager.verify_token(token, 'password_reset')

        # Invalidate token
        await TokenProviderManager.invalidate_token(token)
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.token_providers'

    @classmethod
    async def generate_token(
        cls,
        user_id: int,
        token_type: str,
        ttl: int,
        provider_id: str = None,
        **metadata
    ) -> str:
        """
        Generate one-time token using specified or default provider.

        Args:
            user_id: User Frag ID
            token_type: Token type ('password_reset', 'email_verify', etc.)
            ttl: Time-to-live in seconds
            provider_id: Optional specific provider to use
            **metadata: Additional metadata to store

        Returns:
            Token string
        """
        if not provider_id:
            provider_id = cls.repository().order()[0]
        provider = cls.get(provider_id)
        return await provider.generate(user_id, token_type, ttl, **metadata)

    @classmethod
    async def verify_token(cls, token: str, token_type: str, provider_id: str = None) -> Optional[int]:
        """
        Verify token and return user_id if valid.

        Args:
            token: Token string
            token_type: Expected token type
            provider_id: Optional specific provider to use

        Returns:
            User ID if valid, None otherwise
        """
        if provider_id:
            provider = cls.get(provider_id)
            return await provider.verify(token, token_type)

        # Try all providers
        for provider in cls.repository().values():
            user_id = await provider.verify(token, token_type)
            if user_id:
                return user_id

        return None

    @classmethod
    async def invalidate_token(cls, token: str, provider_id: str = None) -> bool:
        """
        Invalidate token using specified or all providers.

        Args:
            token: Token string
            provider_id: Optional specific provider to use

        Returns:
            True if invalidated, False otherwise
        """
        if provider_id:
            provider = cls.get(provider_id)
            return await provider.invalidate(token)

        # Try all providers
        for provider in cls.repository().values():
            if await provider.invalidate(token):
                return True

        return False
