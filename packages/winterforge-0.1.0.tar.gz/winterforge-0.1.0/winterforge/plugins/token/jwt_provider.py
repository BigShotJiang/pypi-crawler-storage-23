"""JWT token provider.

Stateless JWT tokens for one-time operations (password reset, email verify).
"""

from __future__ import annotations

from typing import Optional
from datetime import datetime, timedelta, timezone

from winterforge.plugins.decorators import token_provider, root


@token_provider()
@root('jwt')
class JWTTokenProvider:
    """
    Stateless JWT tokens for one-time operations.

    Ideal for password reset and email verification tokens where
    short TTL and stateless validation are desired.

    Example:
        provider = TokenProviderManager.get('jwt')
        token = await provider.generate(
            user_id=123,
            token_type='password_reset',
            ttl=3600
        )
        user_id = await provider.verify(token, 'password_reset')
    """

    def __init__(self, secret_key: str = None):
        """
        Initialize with JWT secret from config.

        Args:
            secret_key: Optional JWT secret (loads from config if not provided)
        """
        if not secret_key:
            import os
            secret_key = os.environ.get('WINTERFORGE_JWT_SECRET')

            if not secret_key:
                try:
                    from winterforge.frags.registries.frag_registry import FragRegistry
                    config = FragRegistry({'affinities': ['config']})
                    secret_frag = config.get('jwt.secret')
                    if secret_frag:
                        secret_key = secret_frag.title
                except Exception:
                    pass

            if not secret_key:
                # Use default secret for development (warn in production)
                import secrets
                secret_key = secrets.token_urlsafe(32)
                import warnings
                warnings.warn(
                    "Using auto-generated JWT secret. Set WINTERFORGE_JWT_SECRET environment "
                    "variable or create config Frag for production use.",
                    UserWarning
                )

        self.secret_key = secret_key

    async def generate(self, user_id: int, token_type: str, ttl: int, **metadata) -> str:
        """
        Generate JWT token with user_id and token_type.

        Args:
            user_id: User Frag ID
            token_type: Token type ('password_reset', 'email_verify', etc.)
            ttl: Time-to-live in seconds
            **metadata: Additional metadata to include

        Returns:
            JWT token string
        """
        import jwt

        payload = {
            'user_id': user_id,
            'token_type': token_type,
            'exp': datetime.now(timezone.utc) + timedelta(seconds=ttl),
            'iat': datetime.now(timezone.utc),
            **metadata
        }

        return jwt.encode(payload, self.secret_key, algorithm='HS256')

    async def verify(self, token: str, token_type: str) -> Optional[int]:
        """
        Verify JWT and return user_id if token_type matches.

        Args:
            token: JWT token string
            token_type: Expected token type

        Returns:
            User ID if valid, None otherwise
        """
        import jwt

        try:
            payload = jwt.decode(token, self.secret_key, algorithms=['HS256'])
            if payload.get('token_type') != token_type:
                return None
            return payload.get('user_id')
        except (jwt.ExpiredSignatureError, jwt.InvalidTokenError):
            return None

    async def invalidate(self, token: str) -> bool:
        """
        Cannot invalidate JWT tokens (stateless).

        Args:
            token: JWT token string

        Returns:
            False (one-time use enforced by application logic)
        """
        return False  # One-time use enforced by application logic
