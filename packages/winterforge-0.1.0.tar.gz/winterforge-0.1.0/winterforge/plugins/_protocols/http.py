"""Protocols for HTTP system plugins."""

from __future__ import annotations

from typing import Protocol, Any, Dict, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class HTTPRequestHandler(Protocol):
    """
    Protocol for HTTP request handler plugins.

    Request handlers extract incoming HTTP requests into Frags.
    Handlers signal applicability based on Content-Type header.

    Example:
        @root('json')
        @http_request_handler()
        class JSONRequestHandler:
            def applies_to(self, request, config) -> bool:
                return 'application/json' in request.headers.get(
                    'content-type', ''
                )

            async def extract(self, request, config) -> Frag:
                # Parse JSON body into HTTPRequest Frag
                request_frag = Frag(
                    affinities=['http_request'],
                    traits=['http_request']
                )
                request_frag.set_body(await request.json())
                return request_frag
    """

    def applies_to(self, request: Any, config: Dict[str, Any]) -> bool:
        """
        Check if this handler applies to the request.

        Args:
            request: HTTP request object (FastAPI Request, etc)
            config: Handler configuration dict

        Returns:
            True if this handler should process the request
        """
        ...

    async def extract(
        self,
        request: Any,
        config: Dict[str, Any]
    ) -> 'Frag':
        """
        Extract request data into HTTPRequest Frag.

        Args:
            request: HTTP request object
            config: Handler configuration dict

        Returns:
            Frag with http_request trait containing parsed data
        """
        ...


class HTTPResponseHandler(Protocol):
    """
    Protocol for HTTP response handler plugins.

    Response handlers format Frags into HTTP responses.
    Handlers signal applicability based on Accept header.

    Example:
        @root('json')
        @http_response_handler()
        class JSONResponseHandler:
            def applies_to(self, frag, config) -> bool:
                accept = config.get('accept', 'application/json')
                return 'application/json' in accept

            async def format(self, frag, config) -> Dict[str, Any]:
                # Format Frag as JSON response
                return {
                    'status_code': 200,
                    'body': frag.to_dict(),
                    'headers': {'Content-Type': 'application/json'}
                }
    """

    def applies_to(self, frag: 'Frag', config: Dict[str, Any]) -> bool:
        """
        Check if this handler applies to the response.

        Args:
            frag: Frag to format as response
            config: Handler configuration (includes Accept header)

        Returns:
            True if this handler should format the response
        """
        ...

    async def format(
        self,
        frag: 'Frag',
        config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Format Frag into HTTP response data.

        Args:
            frag: Frag to format
            config: Handler configuration

        Returns:
            Dict with status_code, body, headers
        """
        ...


class HTTPAuthenticator(Protocol):
    """
    Protocol for HTTP authenticator plugins.

    Authenticators extract credentials from HTTP requests and
    authenticate users using AuthenticationProviderManager.

    Example:
        @root('bearer')
        @http_authenticator()
        class BearerAuthenticator:
            def applies_to(self, request, config) -> bool:
                auth = request.headers.get('authorization', '')
                return auth.startswith('Bearer ')

            async def authenticate(self, request, config) -> Frag:
                # Extract bearer token and verify
                token = request.headers['authorization'][7:]
                user_id = await SessionProviderManager.verify_session(token)
                if user_id:
                    return await UserRegistry().get(user_id)
                return None
    """

    def applies_to(self, request: Any, config: Dict[str, Any]) -> bool:
        """
        Check if this authenticator applies to the request.

        Args:
            request: HTTP request object
            config: Authenticator configuration

        Returns:
            True if this authenticator should handle the request
        """
        ...

    async def authenticate(
        self,
        request: Any,
        config: Dict[str, Any]
    ) -> 'Frag | None':
        """
        Authenticate user from HTTP request.

        Args:
            request: HTTP request object
            config: Authenticator configuration

        Returns:
            User Frag on success, None on failure
        """
        ...


class HTTPAppProvider(Protocol):
    """
    Protocol for HTTP application provider plugins.

    App providers create and configure HTTP applications
    (FastAPI, Flask, Starlette, etc).

    Providers own the full app lifecycle:
    - Creating the app
    - Registering endpoints from registry classes
    - Generating and serving OpenAPI documentation
    - Startup/shutdown hooks

    Example:
        @root('fastapi')
        @http_app_provider()
        class FastAPIProvider:
            def create_app(self, **config):
                from fastapi import FastAPI
                return FastAPI(**config)

            def register_endpoints(self, registry_classes, **options):
                # Scan registry classes for @http_endpoint methods
                pass

            def generate_openapi_spec(self, registry_classes, title, version):
                # Generate OpenAPI 3.0 spec
                pass

            def add_openapi_routes(self, spec):
                # Add /openapi.json and /docs
                pass
    """

    def create_app(self, **config: Any) -> Any:
        """
        Create HTTP application instance.

        Args:
            **config: Application-specific configuration

        Returns:
            Application instance (FastAPI app, Flask app, etc)
        """
        ...

    def add_route(
        self,
        method: str,
        path: str,
        handler: Any,
        **options: Any
    ) -> None:
        """
        Register route with HTTP application.

        Args:
            method: HTTP method (GET, POST, etc)
            path: URL path (/api/users/{id})
            handler: Async handler function
            **options: Framework-specific route options
        """
        ...

    def register_endpoints(
        self,
        registry_classes: list,
        **options: Any
    ) -> None:
        """
        Register HTTP endpoints from registry classes.

        Scans registry classes for @http_endpoint decorated methods
        and registers them with the HTTP application.

        Args:
            registry_classes: List of registry classes to scan
            **options: Provider-specific registration options
        """
        ...

    def generate_openapi_spec(
        self,
        registry_classes: list,
        title: str = "API",
        version: str = "1.0.0",
        description: str = ""
    ) -> Dict[str, Any]:
        """
        Generate OpenAPI 3.0 specification.

        Args:
            registry_classes: List of registry classes to document
            title: API title
            version: API version
            description: API description

        Returns:
            OpenAPI 3.0 spec dict
        """
        ...

    def add_openapi_routes(self, spec: Dict[str, Any]) -> None:
        """
        Add OpenAPI spec and documentation routes.

        Adds /openapi.json endpoint and framework-specific
        documentation UI (e.g., /docs for FastAPI).

        Args:
            spec: OpenAPI 3.0 spec dict
        """
        ...

    async def startup(self) -> None:
        """Application startup lifecycle hook."""
        ...

    async def shutdown(self) -> None:
        """Application shutdown lifecycle hook."""
        ...
