"""Validator protocol for input validation."""

from typing import Protocol, Tuple


class Validator(Protocol):
    """
    Protocol for input validators.

    Validators check input values and return validation results.
    Used by CLI commands, forms, and other input systems.
    """

    def validate(self, value: str, field_name: str = None) -> Tuple[bool, str]:
        """
        Validate input value.

        Args:
            value: Input value to validate
            field_name: Optional field name for error messages

        Returns:
            Tuple of (is_valid, error_message)
            - is_valid: True if valid, False otherwise
            - error_message: Empty string if valid, error description if invalid

        Example:
            is_valid, error = validator.validate('user@example.com', 'email')
            if not is_valid:
                print(f"Validation error: {error}")
        """
        ...
