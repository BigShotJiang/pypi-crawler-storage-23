"""Bootstrap protocol for initialization plugins."""

from __future__ import annotations

from typing import Protocol, Any


class Bootstrapper(Protocol):
    """
    Protocol for bootstrap plugins.

    Bootstrappers run once during initialization to set up
    system primitives, defaults, and schema.

    Bootstrap plugins execute in repository order (registration
    order by default). Use repository().reorder() to control
    execution sequence.

    Example:
        @bootstrapper
        class MaterializationBootstrapper:
            async def bootstrap(self):
                return await materialize_primitives()

        # Control order if needed
        repo = BootstrapperManager.repository()
        reordered = repo.reorder(['materialization', 'config'])
        BootstrapperManager.reorder(reordered)
    """

    async def bootstrap(self) -> dict[str, Any]:
        """
        Execute bootstrap logic and return results.

        Returns:
            Dict with bootstrap results (status, counts, etc.)
        """
        ...


__all__ = ['Bootstrapper']
