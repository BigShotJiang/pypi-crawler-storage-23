"""Protocol for identity resolver plugins."""

from __future__ import annotations

from typing import Any, Optional, Protocol, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.plugins._protocols.storage import StorageBackend


class IdentityResolver(Protocol):
    """
    Protocol for identity resolver plugins.

    Identity resolvers convert identities (any type) into Frag IDs.
    Multiple resolvers can be chained, tried in order until one succeeds.

    Identities can be:
    - Integers (direct Frag IDs)
    - Strings (usernames, emails, slugs, etc.)
    - UUIDs (for external system integration)
    - Any other type a custom resolver might handle

    Each resolver uses is_match() to check if it can handle the identity type.

    Example Implementation:
        @identity_resolver('email')
        class EmailIdentityResolver(MatchablePlugin):
            def is_match(self, identity: Any) -> bool:
                # Check if identity is an email
                return isinstance(identity, str) and '@' in identity

            async def resolve(
                self,
                identity: Any,
                storage: StorageBackend,
                **kwargs
            ) -> Optional[int]:
                # Query storage for user with this email
                results = await storage.query()\
                    .affinity('user')\
                    .trait('userable')\
                    .condition('email', identity)\
                    .execute()
                return results[0].id if results else None
    """

    def is_match(self, identity: Any) -> bool:
        """
        Check if this resolver can handle the given identity.

        Args:
            identity: The identity to check (can be any type)

        Returns:
            True if this resolver can attempt resolution
        """
        ...

    def resolve(self, identity: Any, storage: StorageBackend, **kwargs) -> Optional[int]:
        """
        Resolve an identity to a Frag ID.

        Args:
            identity: The identity to resolve (can be any type)
            storage: Storage backend to query
            **kwargs: Optional resolver-specific parameters

        Returns:
            Frag ID if resolved, None otherwise
        """
        ...
