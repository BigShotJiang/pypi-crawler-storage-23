"""OutputRedirect protocol for CLI output destinations."""

from typing import Protocol


class OutputRedirect(Protocol):
    """
    Protocol for CLI output redirection plugins.

    OutputRedirects determine where CLI command output is sent.
    Built-in redirects:
    - CliOutputRedirect: Standard CLI output via click.echo()
    - NullOutputRedirect: Silent output (for testing)
    - FileOutputRedirect: Output to file (future)
    """

    def write(self, message: str) -> None:
        """
        Write a message to the output destination.

        Args:
            message: The formatted message string to output

        Example:
            def write(self, message):
                with open('/tmp/cli.log', 'a') as f:
                    f.write(message + '\\n')
        """
        ...
