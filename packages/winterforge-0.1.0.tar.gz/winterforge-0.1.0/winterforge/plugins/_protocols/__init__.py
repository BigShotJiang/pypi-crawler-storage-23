"""
Plugin protocol definitions for WinterForge plugin extension points.

All plugin types managed by PluginManagerBase have Protocol definitions
here. These provide static type checking for plugin developers and
document the contract each plugin type must fulfill.

Available Plugin Protocols:
    - StorageBackend: Storage backend plugins
    - IdentityResolver: Identity resolver plugins
    - HashingProvider: Hashing provider plugins
    - SessionProvider: Session provider plugins
    - AuthenticationProvider: Authentication provider plugins
    - TokenProvider: Token provider plugins
    - EmailProvider: Email provider plugins
    - Validator: Validator plugins
    - CounterProvider: Counter provider plugins
    - HTTPRequestHandler: HTTP request handler plugins
    - HTTPResponseHandler: HTTP response handler plugins
    - HTTPAuthenticator: HTTP authenticator plugins
    - Bootstrapper: Bootstrap initialization plugins
    - StatusPrinter: Status printer plugins
    - OutputRedirect: Output redirect plugins
    - QueryExecutor: Query executor plugins
    - ResolverProtocol: Resolver plugins

Example Usage:
    from winterforge.plugins._protocols import StorageBackend

    @storage_backend('custom')
    class CustomStorageBackend:
        def save(self, frag: Frag) -> None:
            ...

        def load(self, frag_id: int) -> Optional[Frag]:
            ...

        # Type checker validates all required methods are present
"""

from typing import Protocol, Optional, List, Any, Dict, runtime_checkable

# ============================================================================
# Core Plugin Protocols (defined inline)
# ============================================================================

@runtime_checkable
class LifecycleAware(Protocol):
    """
    Optional protocol for plugins requiring lifecycle management.

    Plugins implementing this protocol receive startup() and shutdown()
    calls during application initialization and termination.
    """
    async def startup(self) -> None: ...
    async def shutdown(self) -> None: ...


@runtime_checkable
class ReadOnlyStorage(Protocol):
    """Protocol for read-only storage backends."""
    def load(self, frag_id: int) -> Optional[Any]: ...
    def query(
        self,
        affinities: Optional[List[str]] = None,
        traits: Optional[List[str]] = None,
        aliases: Optional[Dict[str, Any]] = None,
        **filters: Any
    ) -> List[Any]: ...


class FragTrait(Protocol):
    """Interface for frag trait plugins."""
    pass  # Traits define their own fields and methods


class IdentityResolverProvider(Protocol):
    """Interface for identity resolver provider plugins."""
    def is_match(self, identifier: Any) -> bool: ...
    def resolve(
        self,
        identifier: Any,
        storage_backend: Any
    ) -> Optional[int]: ...


# ============================================================================
# Managed Plugin Protocols (from dedicated files)
# ============================================================================

from winterforge.plugins._protocols.storage import StorageBackend
from winterforge.plugins._protocols.identity import IdentityResolver
from winterforge.plugins._protocols.hashing import HashingProvider
from winterforge.plugins._protocols.session import SessionProvider
from winterforge.plugins._protocols.authentication import (
    AuthenticationProvider,
)
from winterforge.plugins._protocols.token_provider import TokenProvider
from winterforge.plugins._protocols.email_provider import EmailProvider
from winterforge.plugins._protocols.validator import Validator
from winterforge.plugins._protocols.counter import CounterProvider
from winterforge.plugins._protocols.http import (
    HTTPRequestHandler,
    HTTPResponseHandler,
    HTTPAuthenticator,
    HTTPAppProvider,
)
from winterforge.plugins._protocols.bootstrapper import Bootstrapper
from winterforge.plugins._protocols.status_printer import StatusPrinter
from winterforge.plugins._protocols.output_redirect import OutputRedirect
from winterforge.plugins._protocols.query_execution import (
    QueryExecutionStrategy,
    QueryContext,
)
from winterforge.plugins._protocols.resolver import ResolverProtocol

__all__ = [
    # Core protocols
    'LifecycleAware',
    'ReadOnlyStorage',
    'FragTrait',
    'IdentityResolverProvider',
    # Managed protocols
    'StorageBackend',
    'IdentityResolver',
    'HashingProvider',
    'SessionProvider',
    'AuthenticationProvider',
    'TokenProvider',
    'EmailProvider',
    'Validator',
    'CounterProvider',
    'HTTPRequestHandler',
    'HTTPResponseHandler',
    'HTTPAuthenticator',
    'HTTPAppProvider',
    'Bootstrapper',
    'StatusPrinter',
    'OutputRedirect',
    'QueryExecutionStrategy',
    'QueryContext',
    'ResolverProtocol',
]
