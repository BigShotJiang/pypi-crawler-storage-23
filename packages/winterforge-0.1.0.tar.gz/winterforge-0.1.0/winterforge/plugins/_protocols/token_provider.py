"""Protocol for token provider plugins."""

from __future__ import annotations

from typing import Protocol, Optional, Dict, Any


class TokenProvider(Protocol):
    """
    Protocol for token provider plugins.

    Token providers generate and verify tokens (API keys, reset tokens, etc.).

    Example Implementation:
        @token_provider('jwt')
        class JWTTokenProvider:
            async def generate(
                self,
                token_type: str,
                user_id: int,
                metadata: Optional[Dict[str, Any]] = None
            ) -> str:
                # Generate JWT token
                payload = {
                    'type': token_type,
                    'user_id': user_id,
                    'metadata': metadata
                }
                return jwt.encode(payload, secret_key)

            async def verify(
                self,
                token: str,
                token_type: str
            ) -> Optional[int]:
                # Verify JWT and return user_id
                try:
                    payload = jwt.decode(token, secret_key)
                    if payload['type'] == token_type:
                        return payload['user_id']
                except jwt.InvalidTokenError:
                    pass
                return None
    """

    async def generate(
        self,
        token_type: str,
        user_id: int,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Generate a token.

        Args:
            token_type: Type of token (e.g., 'reset', 'api_key')
            user_id: The user ID for this token
            metadata: Optional metadata to embed in token

        Returns:
            Generated token string
        """
        ...

    async def verify(
        self,
        token: str,
        token_type: str
    ) -> Optional[int]:
        """
        Verify a token and return the user ID.

        Args:
            token: The token to verify
            token_type: Expected token type

        Returns:
            User ID if valid, None otherwise
        """
        ...
