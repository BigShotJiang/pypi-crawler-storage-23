"""Protocol for storage backend plugins."""

from __future__ import annotations

from typing import Protocol, Optional, List, Dict, Any


class StorageBackend(Protocol):
    """
    Protocol for storage backend plugins.

    All storage backend implementations must provide async methods.
    Storage backends are responsible for persisting and retrieving Frags.

    WinterForge is async-first. All storage operations are asynchronous
    for consistency and to support modern async frameworks (FastAPI,
    async Django, etc.).

    Example Implementation:
        @storage_backend('sqlite')
        class SQLiteStorageBackend:
            async def save(self, frag: 'Frag') -> None:
                # Implementation here
                ...

            async def load(self, frag_id: int) -> Optional['Frag']:
                # Implementation here
                ...

            async def delete(self, frag_id: int) -> bool:
                # Implementation here
                ...

            async def query(
                self,
                affinities: Optional[List[str]] = None,
                traits: Optional[List[str]] = None,
                **field_filters: Any
            ) -> 'Manifest':
                # Implementation here
                ...

    For synchronous contexts, use the @to_sync decorator:
        from winterforge.utils import to_sync

        @to_sync
        async def my_script():
            frag = Frag(traits=['persistable'])
            await frag.save()

        my_script()  # Runs async code synchronously
    """

    async def save(self, frag: 'Frag') -> None:
        """
        Save a Frag to storage.

        Args:
            frag: The Frag instance to save
        """
        ...

    async def load(self, frag_id: int) -> Optional['Frag']:
        """
        Load a Frag by ID from storage.

        Args:
            frag_id: The Frag ID to load

        Returns:
            The loaded Frag instance or None if not found
        """
        ...

    async def delete(self, frag_id: int) -> bool:
        """
        Delete a Frag from storage.

        Args:
            frag_id: The Frag ID to delete

        Returns:
            True if deleted successfully, False otherwise
        """
        ...

    def query(self) -> 'QueryRepository':
        """
        Return query builder for this storage backend.

        Returns:
            QueryRepository configured with this storage

        Example:
            results = await storage.query().affinity('user').trait('titled').execute()
        """
        ...

    async def execute(self, query_dict: dict) -> List[dict]:
        """
        Execute query and return raw rows.

        Used internally by QueryRepository execution strategies.
        Storage backends translate query_dict to their native format.

        Args:
            query_dict: Query specification with:
                - affinities: List[str] - Affinity tags (AND logic)
                - traits: List[str] - Trait IDs (AND logic)
                - conditions: List[dict] - Field conditions
                - condition_groups: List[dict] - Grouped conditions
                - joins: List[dict] - Join specifications
                - sort: List[dict] - Sort specifications
                - limit: Optional[int] - Result limit
                - offset: Optional[int] - Result offset

        Returns:
            List of row dicts with column names as keys

        Example:
            query_dict = {
                'affinities': ['user'],
                'traits': ['titled'],
                'conditions': [{'field': 'active', 'value': True, 'operator': '='}],
                'sort': [{'field': 'created_at', 'direction': 'DESC'}],
                'limit': 10
            }
            rows = await storage.execute(query_dict)
        """
        ...

    async def get_distinct_affinities(self) -> List[str]:
        """
        Get all unique affinities across all Frags.

        Optimized method that retrieves distinct affinities without
        loading full Frag objects into memory. For SQL backends,
        this should use database aggregation.

        Returns:
            Sorted list of unique affinity strings

        Example:
            affinities = await storage.get_distinct_affinities()
            # Returns: ['comment', 'permission', 'post', 'role', 'user']
        """
        ...

    async def get_distinct_traits(self) -> List[str]:
        """
        Get all unique traits across all Frags.

        Optimized method that retrieves distinct traits without
        loading full Frag objects into memory. For SQL backends,
        this should use database aggregation.

        Returns:
            Sorted list of unique trait strings

        Example:
            traits = await storage.get_distinct_traits()
            # Returns: ['persistable', 'sluggable', 'titled']
        """
        ...

    async def get_affinity_counts(self) -> Dict[str, int]:
        """
        Get usage counts for each affinity across all Frags.

        Optimized method that counts affinity usage without
        loading full Frag objects into memory. For SQL backends,
        this should use database aggregation.

        Returns:
            Dict mapping affinity name to count, sorted by affinity

        Example:
            counts = await storage.get_affinity_counts()
            # Returns: {'permission': 8, 'post': 45, 'user': 10}
        """
        ...

    async def get_trait_counts(self) -> Dict[str, int]:
        """
        Get usage counts for each trait across all Frags.

        Optimized method that counts trait usage without
        loading full Frag objects into memory. For SQL backends,
        this should use database aggregation.

        Returns:
            Dict mapping trait name to count, sorted by trait

        Example:
            counts = await storage.get_trait_counts()
            # Returns: {'persistable': 100, 'titled': 95}
        """
        ...
