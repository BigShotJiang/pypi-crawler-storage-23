"""Protocol for email provider plugins."""

from __future__ import annotations

from typing import Protocol, Optional, List, Dict, Any


class EmailProvider(Protocol):
    """
    Protocol for email provider plugins.

    Email providers handle sending emails.

    Example Implementation:
        @email_provider('smtp')
        class SMTPEmailProvider:
            async def send(
                self,
                to: List[str],
                subject: str,
                body: str,
                from_addr: Optional[str] = None,
                html: Optional[str] = None,
                attachments: Optional[List[Dict[str, Any]]] = None
            ) -> bool:
                # Send email via SMTP
                msg = MIMEMultipart()
                msg['From'] = from_addr or default_from
                msg['To'] = ', '.join(to)
                msg['Subject'] = subject

                msg.attach(MIMEText(body, 'plain'))
                if html:
                    msg.attach(MIMEText(html, 'html'))

                smtp.sendmail(msg['From'], to, msg.as_string())
                return True
    """

    async def send(
        self,
        to: List[str],
        subject: str,
        body: str,
        from_addr: Optional[str] = None,
        html: Optional[str] = None,
        attachments: Optional[List[Dict[str, Any]]] = None
    ) -> bool:
        """
        Send an email.

        Args:
            to: List of recipient email addresses
            subject: Email subject
            body: Email body (plain text)
            from_addr: Sender email address (optional)
            html: HTML version of body (optional)
            attachments: List of attachment dicts (optional)

        Returns:
            True if sent successfully, False otherwise
        """
        ...
