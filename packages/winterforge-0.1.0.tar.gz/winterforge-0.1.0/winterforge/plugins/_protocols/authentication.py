"""Protocol for authentication provider plugins."""

from __future__ import annotations

from typing import Protocol, Optional, Any, Dict


class AuthenticationProvider(Protocol):
    """
    Protocol for authentication provider plugins.

    Authentication providers validate credentials and return user IDs.

    Example Implementation:
        @authentication_provider('password')
        class PasswordAuthenticationProvider:
            async def authenticate(
                self,
                identifier: Any,
                credentials: Dict[str, Any]
            ) -> Optional[int]:
                # Resolve identifier to user_id
                user_id = await resolve_identity(identifier)
                if not user_id:
                    return None

                # Load user and verify password
                user = await storage.load(user_id)
                password = credentials.get('password')

                if hashing_provider.verify(password, user.password_hash):
                    return user_id

                return None
    """

    async def authenticate(
        self,
        identifier: Any,
        credentials: Dict[str, Any]
    ) -> Optional[int]:
        """
        Authenticate a user with credentials.

        Args:
            identifier: User identifier (email, username, etc.)
            credentials: Authentication credentials (password, token, etc.)

        Returns:
            User ID if authenticated successfully, None otherwise
        """
        ...
