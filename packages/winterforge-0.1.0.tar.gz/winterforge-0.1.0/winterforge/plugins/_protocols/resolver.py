"""Resolver protocol - universal ordering agents."""

from typing import Protocol, List, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.frags.manifest import Manifest
    from winterforge.plugins.repository import Repository


class ResolverProtocol(Protocol):
    """
    Resolver - universal ordering agent.

    Resolvers modify collection stacks dynamically:
    - Reorder items based on logic
    - Inject items (fallbacks, defaults)
    - Remove items (duplicates, completed operations)

    Work on both Manifests and Repositories.
    Access collection context via public API.

    Usage:
        # Get resolver
        resolver = ResolverManager.get('injectable_scope')

        # Apply to Manifest
        configs = Manifest(config_list, resolver=resolver)

        # Apply to Repository (future)
        items = Repository(item_list, resolver=resolver)

        # Continuous re-evaluation
        updated = manifest.with_before(new_item)
        # ↑ Resolver runs again on new stack

    Use Cases:
        - Self-healing (re-add failed operations)
        - Idempotency (remove completed operations)
        - Context matching (filter to applicable items)
        - Dynamic injection (add fallbacks)
    """

    def resolve(
        self,
        items: List['Frag'],
        collection: Union['Manifest', 'Repository']
    ) -> List['Frag']:
        """
        Resolve ordering and stack modifications.

        Args:
            items: Current items in collection
            collection: Owner (Manifest or Repository) for context access

        Returns:
            Reordered/modified item list

        Example:
            def resolve(self, items, collection):
                # Access context
                context = collection.to_dict()
                target = context.get('target')

                # Filter to matching
                matching = [i for i in items if i.matches(target)]

                # Inject fallback if needed
                if not matching:
                    matching = [self._create_default(target)]

                return matching
        """
        ...
