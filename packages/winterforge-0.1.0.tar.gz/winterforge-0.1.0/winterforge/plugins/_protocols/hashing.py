"""Protocol for hashing provider plugins."""

from __future__ import annotations

from typing import Protocol


class HashingProvider(Protocol):
    """
    Protocol for hashing provider plugins.

    Hashing providers handle password/secret hashing and verification.

    Example Implementation:
        @hashing_provider('bcrypt')
        class BcryptHashingProvider:
            def hash(self, plaintext: str) -> str:
                # Hash the plaintext
                return bcrypt.hashpw(
                    plaintext.encode('utf-8'),
                    bcrypt.gensalt()
                ).decode('utf-8')

            def verify(self, plaintext: str, hashed: str) -> bool:
                # Verify plaintext against hash
                return bcrypt.checkpw(
                    plaintext.encode('utf-8'),
                    hashed.encode('utf-8')
                )
    """

    def hash(self, plaintext: str) -> str:
        """
        Hash a plaintext string.

        Args:
            plaintext: The plaintext to hash

        Returns:
            The hashed string
        """
        ...

    def verify(self, plaintext: str, hashed: str) -> bool:
        """
        Verify a plaintext string against a hash.

        Args:
            plaintext: The plaintext to verify
            hashed: The hash to verify against

        Returns:
            True if plaintext matches hash, False otherwise
        """
        ...
