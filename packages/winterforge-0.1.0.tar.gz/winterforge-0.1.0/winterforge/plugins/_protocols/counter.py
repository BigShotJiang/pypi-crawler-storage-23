"""Counter provider protocol for ID counter management."""

from typing import Protocol, Any
import itertools


class CounterProvider(Protocol):
    """
    Protocol for ID counter providers.

    Counter providers manage Frag ID generation strategies.
    Different providers can sync with databases, use sequences,
    or implement custom ID generation logic.

    The storage backend uses CounterProviderManager.resolve() to
    find the appropriate counter provider based on storage state.

    Example:
        # In storage backend initialization:
        provider = CounterProviderManager.resolve({'storage': self})
        if provider:
            Frag._id_counter = await provider.get(self)
        else:
            logger.warning("No counter provider matched")
    """

    def is_match(self, context: dict[str, Any]) -> bool:
        """
        Check if this counter provider matches the context.

        Args:
            context: Context dict with keys:
                - storage: Storage backend instance
                - initialized: Whether storage is initialized
                - has_data: Whether storage contains existing data

        Returns:
            True if this provider should handle counter management
        """
        ...

    async def get(self, storage: Any) -> itertools.count:
        """
        Get an ID counter for the given storage backend.

        Args:
            storage: Storage backend instance

        Returns:
            itertools.count object starting at appropriate value

        Example:
            # Database-synced counter
            max_id = await storage.get_max_id()
            return itertools.count(max_id + 1)

            # Fresh counter
            return itertools.count(1)
        """
        ...
