"""Protocol for query execution strategies."""

from __future__ import annotations

from typing import Protocol, TYPE_CHECKING, List, Any

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class QueryExecutionStrategy(Protocol):
    """
    Protocol for query execution strategies.

    Execution strategies determine HOW to execute a query:
    - Index optimization (fast lookups)
    - In-memory filtering (when data already loaded)
    - Database queries (fallback)

    Strategies are tried in Repository order via resolve() until
    one indicates it can handle the query.

    Example:
        @query_execution_strategy('index')
        class IndexExecutionStrategy:
            def can_execute(self, context: QueryContext) -> bool:
                # Check if suitable index exists
                return IndexManager.has_index_for(context.params)

            async def execute(self, context: QueryContext) -> List[Frag]:
                # Execute using index
                return await IndexManager.query(context.params)
    """

    def can_execute(self, context: 'QueryContext') -> bool:
        """
        Check if this strategy can execute the query.

        Args:
            context: Query context with plugins, data source, storage

        Returns:
            True if strategy can handle this query, False otherwise

        Example:
            # Index strategy
            def can_execute(self, context):
                return IndexManager.has_index(context.params)

            # Memory strategy
            def can_execute(self, context):
                return isinstance(context.data_source, Manifest)

            # Storage strategy (fallback)
            def can_execute(self, context):
                return True  # Always can execute
        """
        ...

    async def execute(self, context: 'QueryContext') -> List['Frag']:
        """
        Execute query using this strategy.

        Args:
            context: Query context with plugins, data source, storage

        Returns:
            List of Frags matching query

        Example:
            async def execute(self, context):
                # Use index
                frag_ids = await IndexManager.query(context.params)
                return await self._load_frags(frag_ids, context.storage)
        """
        ...


class QueryContext:
    """
    Context for query execution.

    Contains all information needed for execution strategies
    to determine if they can handle a query and how to execute it.

    Attributes:
        plugins: List of query plugins (conditions, sorts, etc.)
        data_source: Data source (Manifest if querying loaded data, None for DB)
        storage: Storage backend
        params: Query parameters (extracted from plugins)
    """

    def __init__(
        self,
        plugins: List[Any],
        data_source: Any = None,
        storage: Any = None
    ):
        """
        Initialize query context.

        Args:
            plugins: List of query plugins
            data_source: Optional Manifest or other data source
            storage: Storage backend
        """
        self.plugins = plugins
        self.data_source = data_source
        self.storage = storage
        self.params = self._extract_params()

    def _extract_params(self) -> dict:
        """
        Extract query parameters from plugins.

        Returns:
            Dict of query parameters for strategy evaluation
        """
        params = {
            'conditions': [],
            'joins': [],
            'sort': [],
            'limit': None,
            'offset': None
        }

        for plugin in self.plugins:
            plugin_dict = plugin.to_dict()
            ptype = plugin_dict['type']

            if ptype == 'condition':
                params['conditions'].append(plugin_dict)
            elif ptype == 'join':
                params['joins'].append(plugin_dict)
            elif ptype == 'sort':
                params['sort'].append(plugin_dict)
            elif ptype == 'limit':
                params['limit'] = plugin_dict['limit']
            elif ptype == 'offset':
                params['offset'] = plugin_dict['offset']

        return params
