"""StatusPrinter protocol for CLI output formatting.

StatusPrinters use the strategy pattern to format CLI command results.
"""

from typing import Protocol, Any, Dict, Optional


class StatusPrinter(Protocol):
    """
    Protocol for CLI output formatting plugins.

    StatusPrinters determine how command results are formatted for CLI output.
    Uses first-match ordering - the first printer whose is_applicable() returns
    True will be used to format the output.

    Built-in printers:
    - SingleFragPrinter: Single Frag returns (uses token templates)
    - ListFragPrinter: List/collection returns
    - NoneResultPrinter: None returns (not found errors)
    """

    def is_applicable(self, result: Any, metadata: Dict[str, Any]) -> bool:
        """
        Determine if this printer can handle the result.

        Args:
            result: The command return value
            metadata: Command metadata (name, group, options, etc.)

        Returns:
            True if this printer should format the result

        Example:
            def is_applicable(self, result, metadata):
                # Handle single Frags
                return hasattr(result, 'affinities')
        """
        ...

    def format(self, result: Any, metadata: Dict[str, Any], kwargs: Dict[str, Any]) -> str:
        """
        Format the result as a CLI message string.

        Args:
            result: The command return value
            metadata: Command metadata (for context)
            kwargs: Command arguments (for token replacement)

        Returns:
            Formatted message string

        Example:
            def format(self, result, metadata, kwargs):
                return f"✓ User created: {result.username}"
        """
        ...
