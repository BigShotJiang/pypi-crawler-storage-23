"""Protocol for session provider plugins."""

from __future__ import annotations

from typing import Protocol, Optional, Any, Dict


class SessionProvider(Protocol):
    """
    Protocol for session provider plugins.

    Session providers handle session creation, validation, and revocation.

    Example Implementation:
        @session_provider('jwt')
        class JWTSessionProvider:
            async def create(
                self,
                user_id: int,
                metadata: Optional[Dict[str, Any]] = None
            ) -> str:
                # Create JWT session token
                payload = {'user_id': user_id, 'metadata': metadata}
                return jwt.encode(payload, secret_key, algorithm='HS256')

            async def validate(self, session_token: str) -> Optional[int]:
                # Validate JWT and return user_id
                try:
                    payload = jwt.decode(session_token, secret_key)
                    return payload['user_id']
                except jwt.InvalidTokenError:
                    return None

            async def revoke(self, session_token: str) -> bool:
                # Add to revocation list
                return True
    """

    async def create(
        self,
        user_id: int,
        metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Create a new session.

        Args:
            user_id: The user ID for this session
            metadata: Optional metadata to store with session

        Returns:
            Session token
        """
        ...

    async def validate(self, session_token: str) -> Optional[int]:
        """
        Validate a session token and return the user ID.

        Args:
            session_token: The session token to validate

        Returns:
            User ID if valid, None otherwise
        """
        ...

    async def revoke(self, session_token: str) -> bool:
        """
        Revoke a session token.

        Args:
            session_token: The session token to revoke

        Returns:
            True if revoked successfully, False otherwise
        """
        ...
