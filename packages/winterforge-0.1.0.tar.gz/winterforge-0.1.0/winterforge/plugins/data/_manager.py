"""Data transport plugin manager."""

from __future__ import annotations

from winterforge.plugins._base import ReorderablePluginManagerBase


class DataTransportManager(ReorderablePluginManagerBase):
    """
    Manages data transport plugins.

    Data transports handle import/export of Frags in various formats
    (YAML, JSON, XML, etc.) with dependency resolution and validation.

    Example:
        from winterforge.data.manager import DataTransportManager
        yaml_transport = DataTransportManager.get('yaml')
        await yaml_transport.dump('backup.yaml')
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return plugin manager identifier for data transports."""
        return 'winterforge.data_transports'
