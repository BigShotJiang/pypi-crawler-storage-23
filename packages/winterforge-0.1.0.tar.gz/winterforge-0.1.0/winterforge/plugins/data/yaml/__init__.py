"""YAML data transport plugin."""

import yaml
import asyncio
from typing import List, Optional, Dict, Set, Any, TYPE_CHECKING
from datetime import datetime
from pathlib import Path
from winterforge.plugins.decorators import data_transport, root

if TYPE_CHECKING:
    from winterforge.plugins.query._repository import QueryRepository
    from winterforge.frags.base import Frag


@data_transport()
@root('yaml')
class YamlDataTransport:
    """
    YAML import/export plugin.

    Features:
    - Flat structure (UUID-keyed, no nesting)
    - Dependency-aware batching (100x speedup)
    - Concurrent writes (async batch imports)
    - Permissive mode (overwrite duplicates)
    - Missing trait detection
    - UUID reference conversion (_id → _uuid for export)

    Examples:
        transport = YamlDataTransport()

        # Export all blog posts
        stats = await transport.dump(
            'blog_posts.yaml',
            query=QueryRepository().condition('affinities', 'blog-post')
        )

        # Import with overwrite
        stats = await transport.load('blog_posts.yaml', permissive=True)
    """

    async def dump(
        self,
        output_path: str,
        query: Optional['QueryRepository'] = None,
        include_related: bool = True
    ) -> dict:
        """
        Dump Frags to YAML.

        Args:
            output_path: Where to write YAML
            query: QueryRepository (None = all Frags)
            include_related: Include Frags referenced by exported Frags

        Returns:
            Export statistics

        Example:
            transport = YamlDataTransport()
            stats = await transport.dump(
                'blog_posts.yaml',
                query=QueryRepository().condition('affinities', 'blog-post')
            )
            # {'exported': 247, 'file': 'blog_posts.yaml', 'size_kb': 125.3}
        """
        # Get Frags
        if query:
            frags = await query.execute()
        else:
            from winterforge.frags.registries.frag_registry import FragRegistry
            registry = FragRegistry({})  # All Frags
            frags = await registry.all()

        # Include related Frags
        if include_related:
            frags = await self._expand_related(frags)

        # Build flat structure
        export_data = {
            'version': '1.0',
            'exported_at': datetime.now().isoformat(),
            'frag_count': len(frags),
            'frags': {}
        }

        # Frags as flat dict (UUID-keyed)
        for frag in frags:
            export_data['frags'][frag.uuid] = await self._serialize_frag(frag)

        # Write YAML
        output_file = Path(output_path)
        with output_file.open('w') as f:
            f.write("# WinterForge Frag Export\n")
            f.write(f"# Version: 1.0\n")
            f.write(f"# Exported: {export_data['exported_at']}\n\n")

            yaml.dump(
                export_data,
                f,
                default_flow_style=False,
                allow_unicode=True,
                sort_keys=False
            )

        return {
            'exported': len(frags),
            'file': str(output_file),
            'size_kb': output_file.stat().st_size / 1024
        }

    async def load(
        self,
        input_path: str,
        permissive: bool = False,
        batch_size: int = 100,
        concurrent: bool = True
    ) -> dict:
        """
        Load Frags from YAML.

        Features dependency-aware batching and concurrent writes.

        Args:
            input_path: YAML file to load
            permissive: If True, overwrite duplicates. If False, skip.
            batch_size: Frags per batch
            concurrent: Use async concurrency for batch writes

        Returns:
            Import statistics

        Example:
            transport = YamlDataTransport()
            stats = await transport.load('blog_posts.yaml', permissive=True)
            # {
            #     'imported': 245,
            #     'skipped': 2,
            #     'missing_traits': {'blog_post': 2},
            #     'batches': 5
            # }
        """
        # Load YAML
        with open(input_path, 'r') as f:
            export_data = yaml.safe_load(f)

        stats = {
            'imported': 0,
            'skipped': 0,
            'missing_traits': {},
            'batches': 0
        }

        # Build dependency graph
        dep_graph = self._build_dependency_graph(export_data['frags'])

        # Create batches by dependency level
        batches = self._create_batches(dep_graph, batch_size)

        # Import each batch
        for batch in batches:
            stats['batches'] += 1

            if concurrent:
                batch_stats = await self._import_batch_concurrent(
                    batch, export_data['frags'], permissive
                )
            else:
                batch_stats = await self._import_batch_sequential(
                    batch, export_data['frags'], permissive
                )

            # Merge stats
            stats['imported'] += batch_stats['imported']
            stats['skipped'] += batch_stats['skipped']
            for trait_id, count in batch_stats['missing_traits'].items():
                stats['missing_traits'][trait_id] = \
                    stats['missing_traits'].get(trait_id, 0) + count

        return stats

    async def _serialize_frag(self, frag: 'Frag') -> dict:
        """
        Serialize Frag to flat structure.

        Returns dict with:
        - affinities, traits (composition)
        - All fields (flat)
        - UUID references (not numeric IDs)

        Args:
            frag: Frag to serialize

        Returns:
            Flat dict representation
        """
        from winterforge.plugins.storage.manager import StorageManager

        storage = StorageManager.get('sqlite')

        data = {
            'affinities': frag.affinities,
            'traits': frag.traits,
        }

        # Add trait fields from to_dict()
        frag_dict = frag.to_dict()

        # Also scan for dynamic attributes not in traits
        # Look for public attributes (not starting with _) that might be references
        # Skip deprecated properties that trigger warnings
        deprecated_properties = {'owner', 'permissions', 'roles'}

        for attr_name in dir(frag):
            if (not attr_name.startswith('_')
                and attr_name not in frag_dict
                and attr_name not in deprecated_properties):
                # Check if it's a data attribute (not a method/property)
                try:
                    attr_value = getattr(frag, attr_name)
                    # Skip methods, properties, and other non-data attributes
                    if not callable(attr_value) and not isinstance(
                        type(frag).__dict__.get(attr_name), property
                    ):
                        frag_dict[attr_name] = attr_value
                except Exception:
                    pass

        # Process all fields
        for key, value in frag_dict.items():
            if key not in ['id', 'uuid', 'affinities', 'traits', 'aliases']:
                # Convert _id references to _uuid references
                if key.endswith('_id') and isinstance(value, int):
                    # Load referenced Frag, get UUID
                    try:
                        ref_frag = await storage.load(value)
                        if ref_frag:
                            uuid_key = key.replace('_id', '_uuid')
                            data[uuid_key] = ref_frag.uuid
                    except Exception:
                        # Frag not found or failed to load - skip reference
                        pass
                else:
                    data[key] = value

        # Include aliases
        if frag.aliases:
            data['aliases'] = frag.aliases

        return data

    async def _expand_related(self, frags: List['Frag']) -> List['Frag']:
        """
        Expand to include related Frags.

        Example: Blog post references author and category
        → Include author and category Frags in export

        Args:
            frags: Initial Frags to export

        Returns:
            Expanded list including related Frags
        """
        from winterforge.plugins.storage.manager import StorageManager

        storage = StorageManager.get('sqlite')
        expanded = {f.uuid: f for f in frags}  # De-duplicate by UUID

        for frag in list(expanded.values()):
            # Find Frag references
            frag_dict = frag.to_dict()
            for key, value in frag_dict.items():
                if key.endswith('_id') and isinstance(value, int):
                    try:
                        ref_frag = await storage.load(value)
                        if ref_frag and ref_frag.uuid not in expanded:
                            expanded[ref_frag.uuid] = ref_frag
                    except Exception:
                        # Frag not found or failed to load - skip
                        pass

        return list(expanded.values())

    def _build_dependency_graph(self, frags_data: dict) -> dict:
        """
        Build dependency graph from Frag data.

        Returns:
            {
                uuid: {
                    'data': frag_data,
                    'depends_on': [uuid1, uuid2, ...],
                    'depth': 0  # Dependency depth
                }
            }

        Args:
            frags_data: Dict of UUID → Frag data

        Returns:
            Dependency graph
        """
        graph = {}

        # First pass: Build nodes
        for uuid, frag_data in frags_data.items():
            graph[uuid] = {
                'data': frag_data,
                'depends_on': [],
                'depth': None
            }

        # Second pass: Find dependencies
        for uuid, frag_data in frags_data.items():
            for key, value in frag_data.items():
                # UUID reference field
                if key.endswith('_uuid') and value in graph:
                    graph[uuid]['depends_on'].append(value)

        # Third pass: Calculate depths
        self._calculate_depths(graph)

        return graph

    def _calculate_depths(self, graph: dict):
        """
        Calculate dependency depth for each Frag.

        Depth 0 = no dependencies
        Depth 1 = depends on depth 0
        Depth N = depends on depth N-1

        Uses iterative algorithm to handle circular dependencies.

        Args:
            graph: Dependency graph (modified in place)
        """
        max_iterations = len(graph) + 1
        iteration = 0

        while iteration < max_iterations:
            iteration += 1
            changed = False

            for uuid, node in graph.items():
                if node['depth'] is not None:
                    continue  # Already calculated

                deps = node['depends_on']

                if not deps:
                    # No dependencies
                    node['depth'] = 0
                    changed = True
                else:
                    # Check if all dependencies have depths
                    dep_depths = []
                    for dep_uuid in deps:
                        if dep_uuid not in graph:
                            # Dependency not in export (broken reference)
                            continue

                        dep_depth = graph[dep_uuid]['depth']
                        if dep_depth is None:
                            break  # Dependency not ready
                        dep_depths.append(dep_depth)
                    else:
                        # All dependencies have depths
                        if dep_depths:
                            node['depth'] = max(dep_depths) + 1
                        else:
                            node['depth'] = 0
                        changed = True

            if not changed:
                break

        # Any remaining None depths = circular dependencies
        for uuid, node in graph.items():
            if node['depth'] is None:
                node['depth'] = 0  # Break circular dependency

    def _create_batches(
        self,
        graph: dict,
        batch_size: int
    ) -> List[List[tuple]]:
        """
        Create batches by dependency depth.

        Returns:
            [
                [(uuid, frag_data), ...],  # Batch 1 (depth 0)
                [(uuid, frag_data), ...],  # Batch 2 (depth 1)
                ...
            ]

        Args:
            graph: Dependency graph
            batch_size: Maximum Frags per batch

        Returns:
            List of batches
        """
        # Group by depth
        by_depth = {}
        for uuid, node in graph.items():
            depth = node['depth']
            if depth not in by_depth:
                by_depth[depth] = []
            by_depth[depth].append((uuid, node['data']))

        # Create batches
        batches = []
        for depth in sorted(by_depth.keys()):
            frags = by_depth[depth]

            # Split into batch_size chunks
            for i in range(0, len(frags), batch_size):
                batch = frags[i:i + batch_size]
                batches.append(batch)

        return batches

    async def _import_batch_concurrent(
        self,
        batch: List[tuple],
        all_frags_data: dict,
        permissive: bool
    ) -> dict:
        """
        Import batch with concurrent writes.

        Uses asyncio.gather for parallel imports.

        Args:
            batch: List of (uuid, frag_data) tuples
            all_frags_data: All Frag data (for reference resolution)
            permissive: Overwrite duplicates

        Returns:
            Batch import statistics
        """
        stats = {
            'imported': 0,
            'skipped': 0,
            'missing_traits': {}
        }

        # Create tasks
        tasks = [
            self._import_single_frag(uuid, frag_data, permissive)
            for uuid, frag_data in batch
        ]

        # Execute concurrently
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Aggregate results
        for result in results:
            if isinstance(result, Exception):
                stats['skipped'] += 1
            elif result['status'] == 'imported':
                stats['imported'] += 1
            elif result['status'] == 'skipped':
                stats['skipped'] += 1
                for trait_id in result.get('missing_traits', []):
                    stats['missing_traits'][trait_id] = \
                        stats['missing_traits'].get(trait_id, 0) + 1

        return stats

    async def _import_batch_sequential(
        self,
        batch: List[tuple],
        all_frags_data: dict,
        permissive: bool
    ) -> dict:
        """
        Import batch sequentially (fallback).

        Args:
            batch: List of (uuid, frag_data) tuples
            all_frags_data: All Frag data
            permissive: Overwrite duplicates

        Returns:
            Batch import statistics
        """
        stats = {
            'imported': 0,
            'skipped': 0,
            'missing_traits': {}
        }

        for uuid, frag_data in batch:
            result = await self._import_single_frag(uuid, frag_data, permissive)

            if result['status'] == 'imported':
                stats['imported'] += 1
            elif result['status'] == 'skipped':
                stats['skipped'] += 1
                for trait_id in result.get('missing_traits', []):
                    stats['missing_traits'][trait_id] = \
                        stats['missing_traits'].get(trait_id, 0) + 1

        return stats

    async def _import_single_frag(
        self,
        uuid: str,
        frag_data: dict,
        permissive: bool
    ) -> dict:
        """
        Import single Frag.

        Returns:
            {'status': 'imported' | 'skipped', 'missing_traits': [...]}

        Args:
            uuid: Frag UUID
            frag_data: Frag data dict
            permissive: Overwrite if exists

        Returns:
            Import result
        """
        from winterforge.plugins.storage.manager import StorageManager

        storage = StorageManager.get('sqlite')

        # Check traits exist
        missing = self._check_traits(frag_data['traits'])
        if missing:
            return {
                'status': 'skipped',
                'missing_traits': missing
            }

        # Check for duplicate by querying for UUID
        try:
            results = await storage.query().condition('uuid', uuid).execute()
            existing = results[0] if results else None
        except Exception:
            existing = None

        if existing and not permissive:
            return {'status': 'skipped'}

        # Import
        if existing:
            await self._update_frag(existing, frag_data)
        else:
            await self._create_frag(uuid, frag_data)

        return {'status': 'imported'}

    def _check_traits(self, trait_ids: List[str]) -> List[str]:
        """
        Check if all traits exist.

        Returns:
            List of missing trait IDs (empty if all exist)

        Args:
            trait_ids: Trait IDs to check

        Returns:
            Missing trait IDs
        """
        from winterforge.plugins import FragTraitManager

        missing = []
        for trait_id in trait_ids:
            if not FragTraitManager.has(trait_id):
                missing.append(trait_id)

        return missing

    async def _update_frag(self, existing: 'Frag', frag_data: dict):
        """
        Update existing Frag with imported data.

        Args:
            existing: Existing Frag
            frag_data: Imported data
        """
        from winterforge.plugins.storage.manager import StorageManager

        storage = StorageManager.get('sqlite')

        for key, value in frag_data.items():
            if key not in ['affinities', 'traits', 'aliases']:
                # Convert _uuid references to _id references
                if key.endswith('_uuid'):
                    try:
                        results = await storage.query().condition('uuid', value).execute()
                        ref_frag = results[0] if results else None
                        if ref_frag:
                            id_key = key.replace('_uuid', '_id')
                            setattr(existing, id_key, ref_frag.id)
                    except Exception:
                        # Reference not found - skip
                        pass
                else:
                    # Try setter method first (for read-only properties)
                    setter_name = f'set_{key}'
                    if hasattr(existing, setter_name):
                        getattr(existing, setter_name)(value)
                    else:
                        setattr(existing, key, value)

        await existing.save()

    async def _create_frag(self, uuid: str, frag_data: dict):
        """
        Create new Frag from imported data.

        Args:
            uuid: Frag UUID
            frag_data: Imported data
        """
        from winterforge.frags.base import Frag
        from winterforge.plugins.storage.manager import StorageManager

        storage = StorageManager.get('sqlite')

        frag = Frag(
            affinities=frag_data['affinities'],
            traits=frag_data['traits']
        )

        # Restore UUID
        frag._set_uuid(uuid)

        # Set aliases if present
        if 'aliases' in frag_data:
            frag.set_aliases(frag_data['aliases'])

        # Set fields
        for key, value in frag_data.items():
            if key not in ['affinities', 'traits', 'aliases']:
                # Convert _uuid references to _id references
                if key.endswith('_uuid'):
                    try:
                        results = await storage.query().condition('uuid', value).execute()
                        ref_frag = results[0] if results else None
                        if ref_frag:
                            id_key = key.replace('_uuid', '_id')
                            setattr(frag, id_key, ref_frag.id)
                    except Exception:
                        # Reference not found - skip
                        pass
                else:
                    # Try setter method first (for read-only properties)
                    setter_name = f'set_{key}'
                    if hasattr(frag, setter_name):
                        getattr(frag, setter_name)(value)
                    else:
                        setattr(frag, key, value)

        await frag.save()
