"""Envoy protocol - interface for AI endpoint wrappers."""

from typing import Protocol, Dict, Any, List, AsyncIterator, AsyncContextManager, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class EnvoyResponse:
    """
    Response from envoy.

    Can be used as async iterator for streaming or accessed directly
    for completion.
    """

    def __init__(
        self,
        content: str = '',
        metadata: Dict[str, Any] | None = None,
        usage: Dict[str, int] | None = None,
        model: str = '',
        finish_reason: str = 'complete',
        stream: AsyncIterator[str] | None = None
    ):
        """Initialize response."""
        self.content = content
        self.metadata = metadata or {}
        self.usage = usage or {}
        self.model = model
        self.finish_reason = finish_reason
        self._stream = stream

    def __aiter__(self):
        """Enable async iteration for streaming."""
        if self._stream is None:
            raise ValueError("Response is not streaming")
        return self._stream

    async def __anext__(self):
        """Get next chunk from stream."""
        if self._stream is None:
            raise ValueError("Response is not streaming")
        return await self._stream.__anext__()


class EnvoyProtocol(Protocol):
    """
    Protocol for AI endpoint wrappers.

    Envoys wrap AI endpoints (Claude API, Ollama, etc.) with
    consistent interface for Redkeep Emissaries.

    Key Design:
    - Role-agnostic (no 'claude' vs 'local' roles)
    - Pluggable (standard plugin pattern)
    - Transport-agnostic (HTTP, WebSocket, etc.)
    - Streaming via async context manager

    Usage:
        # Direct instantiation
        claude = Claude()

        # Create message Frag
        message = Frag(affinities=['message'], traits=['messageable'])
        message.set_content('Hello!')
        message.set_role('user')

        # Query (simple completion)
        resp = await claude.query(message)
        print(resp.content)

        # Response (async context manager for streaming)
        async with claude.response(message) as resp:
            async for chunk in resp:
                print(chunk, end='', flush=True)
    """

    def envoy_id(self) -> str:
        """
        Return envoy identifier.

        Returns:
            Envoy ID (e.g., 'claude', 'local_ollama')
        """
        ...

    async def query(
        self,
        messages: 'Frag | List[Frag]',
        **options: Any
    ) -> EnvoyResponse:
        """
        Send query to AI endpoint (completion).

        Args:
            messages: Message Frag(s) with 'messageable' trait
            **options: Envoy-specific options (model, temperature, etc.)

        Returns:
            Response from AI endpoint

        Example:
            claude = Claude()
            msg = Frag(affinities=['message'], traits=['messageable'])
            msg.set_content('Hello!')
            msg.set_role('user')

            response = await claude.query(msg, temperature=0.7)
            print(response.content)
        """
        ...

    def response(
        self,
        messages: 'Frag | List[Frag]',
        **options: Any
    ) -> AsyncContextManager[EnvoyResponse]:
        """
        Get response from AI endpoint (async context manager).

        Use for streaming responses with async context manager pattern.

        Args:
            messages: Message Frag(s) with 'messageable' trait
            **options: Envoy-specific options

        Returns:
            Async context manager yielding EnvoyResponse

        Example:
            claude = Claude()
            msg = Frag(affinities=['message'], traits=['messageable'])
            msg.set_content('Explain async/await')

            async with claude.response(msg) as resp:
                async for chunk in resp:
                    print(chunk, end='', flush=True)
        """
        ...

    async def health_check(self) -> bool:
        """
        Check if endpoint is available.

        Returns:
            True if endpoint is healthy, False otherwise

        Example:
            claude = Claude()
            if await claude.health_check():
                resp = await claude.query(messages)
        """
        ...

    def supports_streaming(self) -> bool:
        """
        Check if envoy supports streaming.

        Returns:
            True if streaming is supported
        """
        ...

    def get_capabilities(self) -> Dict[str, Any]:
        """
        Get envoy capabilities.

        Returns:
            Capabilities dict (models, max_tokens, features, etc.)

        Example:
            claude = Claude()
            caps = claude.get_capabilities()
            print(f"Models: {caps['models']}")
            print(f"Max tokens: {caps['max_tokens']}")
        """
        ...
