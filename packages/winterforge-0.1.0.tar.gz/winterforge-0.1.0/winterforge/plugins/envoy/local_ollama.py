"""LocalOllama - local model wrapper."""

from typing import List, Dict, Any, TYPE_CHECKING
from contextlib import asynccontextmanager
from winterforge.plugins import plugin
from winterforge.plugins.envoy._protocol import EnvoyResponse

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@plugin('winterforge.envoys', 'local_ollama')
class LocalOllama:
    """
    Ollama local model envoy.

    Wraps Ollama API for local model inference.
    Supports models like Llama, Mistral, etc.

    Configuration:
    - OLLAMA_HOST: Ollama server URL (default: http://localhost:11434)
    - OLLAMA_MODEL: Default model (default: llama3.2)

    Example:
        ollama = LocalOllama()

        # Create message Frag
        msg = Frag(affinities=['message'], traits=['messageable'])
        msg.set_content('Hello!')
        msg.set_role('user')

        # Query (completion)
        response = await ollama.query(msg)

        # Response (streaming)
        async with ollama.response(msg) as resp:
            async for chunk in resp:
                print(chunk, end='', flush=True)
    """

    def __init__(
        self,
        host: str | None = None,
        default_model: str | None = None
    ):
        """
        Initialize LocalOllama.

        Args:
            host: Ollama server URL (or from env)
            default_model: Default model name
        """
        self._host = host or 'http://localhost:11434'
        self._default_model = default_model or 'llama3.2'
        self._client = None

    def envoy_id(self) -> str:
        """Return envoy identifier."""
        return 'local_ollama'

    async def query(
        self,
        messages: 'Frag | List[Frag]',
        **options: Any
    ) -> EnvoyResponse:
        """
        Send query to Ollama (completion).

        Args:
            messages: Message Frag(s) with 'messageable' trait
            **options: Ollama-specific options
                - model: Model to use
                - temperature: Sampling temperature
                - num_predict: Max tokens to generate

        Returns:
            Response from Ollama
        """
        import httpx

        # Extract options
        model = options.get('model', self._default_model)
        temperature = options.get('temperature', 0.8)
        num_predict = options.get('num_predict', 2048)

        # Convert messages to Ollama format
        ollama_messages = self._convert_messages(messages)

        # Build request
        request = {
            'model': model,
            'messages': ollama_messages,
            'stream': False,
            'options': {
                'temperature': temperature,
                'num_predict': num_predict,
            }
        }

        # Call API
        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                f'{self._host}/api/chat',
                json=request
            )
            response.raise_for_status()
            data = response.json()

        # Convert to standard format
        return EnvoyResponse(
            content=data['message']['content'],
            metadata={},
            usage={
                'input_tokens': data.get('prompt_eval_count', 0),
                'output_tokens': data.get('eval_count', 0),
            },
            model=model,
            finish_reason='complete',
        )

    @asynccontextmanager
    async def response(
        self,
        messages: 'Frag | List[Frag]',
        **options: Any
    ):
        """
        Get response from Ollama (async context manager).

        Args:
            messages: Message Frag(s) with 'messageable' trait
            **options: Ollama-specific options

        Yields:
            EnvoyResponse with streaming support
        """
        import httpx
        import json

        # Extract options
        model = options.get('model', self._default_model)
        temperature = options.get('temperature', 0.8)
        num_predict = options.get('num_predict', 2048)

        # Convert messages
        ollama_messages = self._convert_messages(messages)

        # Build request
        request = {
            'model': model,
            'messages': ollama_messages,
            'stream': True,
            'options': {
                'temperature': temperature,
                'num_predict': num_predict,
            }
        }

        # Create async generator for streaming
        async def stream_generator():
            async with httpx.AsyncClient(timeout=120.0) as client:
                async with client.stream(
                    'POST',
                    f'{self._host}/api/chat',
                    json=request
                ) as http_response:
                    http_response.raise_for_status()
                    async for line in http_response.aiter_lines():
                        if line:
                            chunk = json.loads(line)
                            if 'message' in chunk:
                                content = chunk['message'].get('content', '')
                                if content:
                                    yield content

        # Yield response with stream
        response = EnvoyResponse(
            model=model,
            stream=stream_generator()
        )
        yield response

    async def health_check(self) -> bool:
        """
        Check if Ollama is available.

        Returns:
            True if Ollama is running
        """
        try:
            import httpx

            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(f'{self._host}/api/tags')
                return response.status_code == 200
        except Exception:
            return False

    def supports_streaming(self) -> bool:
        """Check if envoy supports streaming."""
        return True

    def get_capabilities(self) -> Dict[str, Any]:
        """
        Get Ollama capabilities.

        Returns:
            Capabilities dictionary
        """
        return {
            'models': [
                'llama3.2',
                'llama3.1',
                'mistral',
                'mixtral',
                'phi',
                'qwen',
            ],
            'max_tokens': 4096,  # Varies by model
            'streaming': True,
            'vision': False,  # Model-dependent
            'tools': False,   # Model-dependent
            'features': [
                'local_inference',
                'offline_capable',
                'custom_models',
                'temperature_control',
            ],
        }

    def _convert_messages(
        self,
        messages: 'Frag | List[Frag]'
    ) -> List[Dict[str, str]]:
        """
        Convert Frag messages to Ollama format.

        Args:
            messages: Message Frag(s)

        Returns:
            Ollama API message format
        """
        # Normalize to list
        if not isinstance(messages, list):
            messages = [messages]

        ollama_messages = []
        for msg in messages:
            # Get role and content from messageable trait
            role = getattr(msg, 'role', 'user')
            content = getattr(msg, 'content', '')

            ollama_messages.append({
                'role': role,
                'content': content,
            })

        return ollama_messages
