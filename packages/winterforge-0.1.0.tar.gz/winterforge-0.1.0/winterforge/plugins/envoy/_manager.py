"""Envoy plugin manager."""

from winterforge.plugins._base import PluginManagerBase


class EnvoyManager(PluginManagerBase):
    """
    Manages AI endpoint wrapper plugins.

    Envoys provide consistent interface for different AI endpoints:
    - Claude API (Anthropic)
    - Ollama (local models)
    - OpenAI API
    - Custom endpoints

    Usage:
        # Get specific envoy
        claude = EnvoyManager.get('claude')
        response = await claude.send(messages)

        # List available envoys
        envoys = EnvoyManager.all()

        # Check availability
        if EnvoyManager.has('local_ollama'):
            local = EnvoyManager.get('local_ollama')
    """

    # Plugin namespace for entry points
    _namespace = 'winterforge.envoys'
