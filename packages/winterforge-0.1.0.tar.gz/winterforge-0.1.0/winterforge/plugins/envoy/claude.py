"""Claude - Anthropic API wrapper."""

from typing import List, Dict, Any, TYPE_CHECKING
from contextlib import asynccontextmanager
from winterforge.plugins import plugin
from winterforge.plugins.envoy._protocol import EnvoyResponse

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@plugin('winterforge.envoys', 'claude')
class Claude:
    """
    Claude API envoy.

    Wraps Anthropic's Claude API with standard envoy interface.

    Configuration (via environment or settings):
    - ANTHROPIC_API_KEY: API key
    - CLAUDE_MODEL: Default model (default: claude-sonnet-4-5)
    - CLAUDE_MAX_TOKENS: Max response tokens (default: 4096)

    Example:
        claude = Claude()

        # Create message Frag
        msg = Frag(affinities=['message'], traits=['messageable'])
        msg.set_content('Hello!')
        msg.set_role('user')

        # Query (completion)
        response = await claude.query(msg)
        print(response.content)

        # Response (streaming with context manager)
        async with claude.response(msg) as resp:
            async for chunk in resp:
                print(chunk, end='', flush=True)
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None
    ):
        """
        Initialize Claude.

        Args:
            api_key: Anthropic API key (or from env)
            base_url: API base URL (optional)
        """
        self._api_key = api_key
        self._base_url = base_url or 'https://api.anthropic.com'
        self._client = None

    def envoy_id(self) -> str:
        """Return envoy identifier."""
        return 'claude'

    async def query(
        self,
        messages: 'Frag | List[Frag]',
        **options: Any
    ) -> EnvoyResponse:
        """
        Send query to Claude API (completion).

        Args:
            messages: Message Frag(s) with 'messageable' trait
            **options: Claude-specific options
                - model: Model to use (default: claude-sonnet-4-5)
                - temperature: Sampling temperature (0-1)
                - max_tokens: Max response tokens
                - system: System prompt

        Returns:
            Response from Claude API

        Example:
            claude = Claude()
            msg = Frag(affinities=['message'], traits=['messageable'])
            msg.set_content('Explain Python')
            msg.set_role('user')

            response = await claude.query(msg, model='claude-opus-4-6')
            print(response.content)
        """
        client = await self._get_client()

        # Extract options
        model = options.get('model', 'claude-sonnet-4-5')
        temperature = options.get('temperature', 1.0)
        max_tokens = options.get('max_tokens', 4096)
        system = options.get('system')

        # Convert messages to Claude format
        claude_messages = self._convert_messages(messages)

        # Build request
        request_params = {
            'model': model,
            'messages': claude_messages,
            'max_tokens': max_tokens,
            'temperature': temperature,
        }

        if system:
            request_params['system'] = system

        # Call API
        api_response = await client.messages.create(**request_params)

        # Convert to standard format
        return EnvoyResponse(
            content=api_response.content[0].text,
            metadata={},
            usage={
                'input_tokens': api_response.usage.input_tokens,
                'output_tokens': api_response.usage.output_tokens,
            },
            model=api_response.model,
            finish_reason=api_response.stop_reason or 'complete',
        )

    @asynccontextmanager
    async def response(
        self,
        messages: 'Frag | List[Frag]',
        **options: Any
    ):
        """
        Get response from Claude API (async context manager).

        Use for streaming responses.

        Args:
            messages: Message Frag(s) with 'messageable' trait
            **options: Claude-specific options

        Yields:
            EnvoyResponse with streaming support

        Example:
            claude = Claude()
            msg = Frag(affinities=['message'], traits=['messageable'])
            msg.set_content('Explain async/await')

            async with claude.response(msg) as resp:
                async for chunk in resp:
                    print(chunk, end='', flush=True)
        """
        client = await self._get_client()

        # Extract options
        model = options.get('model', 'claude-sonnet-4-5')
        temperature = options.get('temperature', 1.0)
        max_tokens = options.get('max_tokens', 4096)
        system = options.get('system')

        # Convert messages
        claude_messages = self._convert_messages(messages)

        # Build request
        request_params = {
            'model': model,
            'messages': claude_messages,
            'max_tokens': max_tokens,
            'temperature': temperature,
            'stream': True,
        }

        if system:
            request_params['system'] = system

        # Stream response
        async with client.messages.stream(**request_params) as stream:
            # Create response with stream
            response = EnvoyResponse(
                model=model,
                stream=stream.text_stream
            )
            yield response

    async def health_check(self) -> bool:
        """
        Check if Claude API is available.

        Returns:
            True if API is healthy

        Example:
            claude = Claude()
            if await claude.health_check():
                response = await claude.query(messages)
        """
        try:
            client = await self._get_client()
            # Simple test request
            await client.messages.create(
                model='claude-haiku-4-5',
                max_tokens=10,
                messages=[{'role': 'user', 'content': 'test'}]
            )
            return True
        except Exception:
            return False

    def supports_streaming(self) -> bool:
        """Check if envoy supports streaming."""
        return True

    def get_capabilities(self) -> Dict[str, Any]:
        """
        Get Claude capabilities.

        Returns:
            Capabilities dictionary

        Example:
            claude = Claude()
            caps = claude.get_capabilities()
            print(f"Max tokens: {caps['max_tokens']}")
        """
        return {
            'models': [
                'claude-opus-4-6',
                'claude-sonnet-4-5',
                'claude-haiku-4-5',
            ],
            'max_tokens': 200000,  # Claude 4+ context window
            'streaming': True,
            'vision': True,
            'tools': True,
            'features': [
                'extended_thinking',
                'system_prompts',
                'temperature_control',
            ],
        }

    async def _get_client(self):
        """Get or create Anthropic client."""
        if self._client is None:
            import anthropic
            import os

            api_key = self._api_key or os.getenv('ANTHROPIC_API_KEY')
            if not api_key:
                raise ValueError(
                    "ANTHROPIC_API_KEY not set. "
                    "Set environment variable or pass to constructor."
                )

            self._client = anthropic.AsyncAnthropic(
                api_key=api_key,
                base_url=self._base_url,
            )

        return self._client

    def _convert_messages(
        self,
        messages: 'Frag | List[Frag]'
    ) -> List[Dict[str, str]]:
        """
        Convert Frag messages to Claude format.

        Args:
            messages: Message Frag(s)

        Returns:
            Claude API message format
        """
        # Normalize to list
        if not isinstance(messages, list):
            messages = [messages]

        claude_messages = []
        for msg in messages:
            # Get role and content from messageable trait
            role = getattr(msg, 'role', 'user')
            content = getattr(msg, 'content', '')

            # Skip system messages (handled separately via options)
            if role == 'system':
                continue

            claude_messages.append({
                'role': role,
                'content': content,
            })

        return claude_messages
