"""
Plugin discovery and derivative generation.

Discovers plugins from both internal and external sources:
- Loads plugins via entry points (external packages)
- Generates derivative plugins (dynamic)
- Coordinates discovery across all plugin types

Plugin manager IDs (e.g., 'winterforge.storage_backends') serve double duty:
they identify managers internally AND define entry point groups in setuptools.

External packages declare plugins in pyproject.toml:
    [project.entry-points."winterforge.storage_backends"]
    redis = "mypkg.redis:RedisBackend"

The discovery system matches entry point groups to manager IDs and automatically
registers discovered plugins with the appropriate manager.
"""

from __future__ import annotations
from typing import Dict, Type, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.plugins._base import PluginManagerBase


class PluginDiscoverer:
    """
    Mixin for coordinating plugin discovery across all plugin types.

    Maintains a registry of all plugin managers and provides discovery
    coordination. Used by PluginManagerManager to discover plugins for
    all registered plugin types.
    """

    # Registry of all plugin managers (class-level, shared)
    _PLUGIN_MANAGERS: Dict[str, Type['PluginManagerBase']] = {}

    @classmethod
    def register_manager(cls, manager_id: str, manager_class: Type['PluginManagerBase']) -> None:
        """
        Register a plugin manager.

        Called automatically by PluginManagerBase.__init_subclass__
        when concrete manager classes are defined.

        Args:
            manager_id: Unique plugin manager identifier
            manager_class: Plugin manager class
        """
        cls._PLUGIN_MANAGERS[manager_id] = manager_class

    @classmethod
    def get_manager(cls, manager_id: str) -> Type['PluginManagerBase']:
        """
        Get a registered plugin manager by ID.

        Args:
            manager_id: Plugin manager identifier

        Returns:
            Plugin manager class

        Raises:
            KeyError: If manager_id not found
        """
        return cls._PLUGIN_MANAGERS[manager_id]

    @classmethod
    def has_manager(cls, manager_id: str) -> bool:
        """
        Check if a plugin manager is registered.

        Args:
            manager_id: Plugin manager identifier

        Returns:
            True if manager is registered
        """
        return manager_id in cls._PLUGIN_MANAGERS

    @classmethod
    def all_managers(cls) -> Dict[str, Type['PluginManagerBase']]:
        """
        Get all registered plugin managers.

        Returns:
            Dictionary of manager_id -> manager_class
        """
        return cls._PLUGIN_MANAGERS.copy()

    @classmethod
    def _find_plugin_manager(
        cls,
        plugin_id: str
    ) -> str | None:
        """
        Find which manager owns a plugin by ID.

        Searches all registered managers to find which one contains
        the specified plugin.

        Args:
            plugin_id: Plugin identifier to search for

        Returns:
            Manager ID that owns the plugin, or None if not found
        """
        for manager_id, manager_class in cls._PLUGIN_MANAGERS.items():
            if manager_class.has(plugin_id):
                return manager_id
        return None

    @classmethod
    def _build_manager_dependencies(cls) -> dict[str, list[str]]:
        """
        Build manager dependency map from plugin scope relationships.

        Examines all plugins across all managers to identify scope
        relationships. If a plugin in ManagerA is scoped to a parent
        in ManagerB, then ManagerA depends on ManagerB (ManagerA's
        plugins must be processed after ManagerB's).

        Returns:
            Dict mapping manager_id to list of manager_ids it depends on

        Example:
            {
                'winterforge.cli_formatters.elements': [
                    'winterforge.cli_formatters'
                ],
                'winterforge.cli_formatters': []
            }
        """
        dependencies = {}

        # Initialize empty dependency lists for all managers
        for manager_id in cls._PLUGIN_MANAGERS:
            dependencies[manager_id] = []

        # Examine all plugins across all managers
        for manager_id, manager_class in cls._PLUGIN_MANAGERS.items():
            for plugin_id, plugin_class in (
                manager_class.get_definitions().items()
            ):
                # Check if this plugin has a scope
                if hasattr(plugin_class, '__scope__'):
                    parent_id = plugin_class.__scope__

                    # Find which manager owns the parent plugin
                    parent_manager_id = cls._find_plugin_manager(
                        parent_id
                    )

                    if (
                        parent_manager_id
                        and parent_manager_id != manager_id
                    ):
                        # This manager depends on parent's manager
                        if (
                            parent_manager_id
                            not in dependencies[manager_id]
                        ):
                            dependencies[manager_id].append(
                                parent_manager_id
                            )

        return dependencies

    @classmethod
    def get_ordered_managers(cls) -> list[Type['PluginManagerBase']]:
        """
        Get managers in dependency order (child→sibling→parent).

        Analyzes scope relationships between plugins to determine
        manager dependencies. Returns managers in processing order:
        subsidiary managers before their parent managers.

        This order is critical for derivative generation - scoped
        plugins must be derived before their parents to maintain
        referential integrity.

        Returns:
            List of manager classes in dependency order

        Example:
            [ElementManager, FormatterManager]
            # Elements (children) before Formatters (parents)
        """
        from winterforge.utils.dependency_resolver import (
            DependencyResolver
        )

        # Build manager dependency map from plugin scope relationships
        dependencies = cls._build_manager_dependencies()

        # Resolve discovery order (children first)
        try:
            ordered_ids = DependencyResolver.resolve_order(dependencies)
        except ValueError as e:
            import warnings
            warnings.warn(
                f"Circular dependency in plugin managers: {e}",
                RuntimeWarning
            )
            # Fall back to arbitrary order
            ordered_ids = list(cls._PLUGIN_MANAGERS.keys())

        # Return manager classes in order
        return [cls._PLUGIN_MANAGERS[mid] for mid in ordered_ids]

    @classmethod
    def discover_all_plugins(cls) -> None:
        """
        Discover plugins from entry points for all registered managers.

        Iterates through all registered plugin managers and loads their
        plugins from setuptools entry points. Each manager's entry point
        group is determined by its plugin_id.

        Example entry point group: 'winterforge.storage_backends'
        """
        try:
            from importlib.metadata import entry_points
        except ImportError:
            # Python < 3.10
            from importlib_metadata import entry_points

        # Discover plugins for each registered manager
        # Use list() to create a snapshot to avoid "dictionary changed size
        # during iteration" errors when decorators register new managers
        for manager_id, manager_class in list(cls._PLUGIN_MANAGERS.items()):
            # Get entry points for this plugin type
            eps = entry_points()

            # Handle both old and new entry_points API
            if hasattr(eps, 'select'):
                # Python 3.10+ API
                group_eps = eps.select(group=manager_id)
            else:
                # Python 3.9 API
                group_eps = eps.get(manager_id, [])

            # Load each plugin from entry points
            for ep in group_eps:
                try:
                    plugin_class = ep.load()
                    manager_class.register(ep.name, plugin_class)
                except Exception as e:
                    import warnings
                    warnings.warn(
                        f"Failed to load plugin '{ep.name}' for {manager_id}: {e}",
                        RuntimeWarning
                    )


def discover_plugins() -> None:
    """
    Discover plugins from installed packages via entry points.

    Automatically discovers all registered plugin managers and loads
    their entry points. Called during Winterforge initialization.

    Plugin managers auto-register via PluginManagerBase inheritance,
    so no manual configuration is required to add new plugin types.

    Derivative generation occurs in dependency order (child→parent)
    to ensure scoped plugins are derived before their parents.
    """
    from winterforge.plugins._manager_manager import PluginManagerManager

    # Delegate to PluginManagerManager for entry point discovery
    PluginManagerManager.discover_all_plugins()

    # Derive dynamic plugins in dependency order
    # Scoped plugins (children) are derived before parents
    for manager_class in PluginManagerManager.get_ordered_managers():
        manager_class.derive_plugins()
