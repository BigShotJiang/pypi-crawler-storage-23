"""
Bootstrapper decorator for declaring bootstrap plugins.

Enables ordered initialization of system primitives and defaults.
"""

from __future__ import annotations

from typing import Type


def bootstrapper(cls: Type) -> Type:
    """
    Decorator for bootstrap plugins.

    Auto-registers class with BootstrapperManager. Execution order
    follows repository order (registration order by default).

    Use BootstrapperManager.repository().reorder() to control
    execution sequence.

    Args:
        cls: Bootstrapper class to register

    Returns:
        Registered class

    Example:
        @bootstrapper
        class MaterializationBootstrapper:
            async def bootstrap(self):
                return await materialize_primitives()

        # Auto-registered with BootstrapperManager
        # Runs in registration order

        # Control order if needed
        repo = BootstrapperManager.repository()
        reordered = repo.reorder(['materialization', 'config'])
        BootstrapperManager.reorder(reordered)
    """
    # Auto-register with BootstrapperManager
    from winterforge.plugins.bootstrap.bootstrapper_manager import (
        BootstrapperManager
    )

    # Use class name as plugin ID (lowercase)
    plugin_id = cls.__name__.lower()
    BootstrapperManager.register(plugin_id, cls)

    return cls


__all__ = ['bootstrapper']
