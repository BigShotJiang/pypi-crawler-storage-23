"""
Version root decorator for API versioning.

Works with @root to create versioned API endpoints:
@root('users') + @version_root('v2') = /users/v2/...
"""

from typing import Any, Callable, Optional


# Storage for version_root metadata
_VERSION_ROOT_METADATA = {}


def version_root(version: str) -> Callable:
    """
    Decorator to mark API version for HTTP endpoints.

    Works in conjunction with @root to form endpoint paths:
    /{root}/{version}/{method_name}/{args}

    Args:
        version: Version identifier (e.g., 'v1', 'v2', 'beta')

    Returns:
        Decorator function

    Example:
        @root('users')
        @version_root('v2')
        @decorator_provider('http_endpoint')
        async def show(self, identity: str):
            '''Get user.'''
            pass
        # Generates: GET /users/v2/show/{identity}

        @root('products')
        @version_root('beta')
        @decorator_provider('http_endpoint')
        async def list_products(self, category: str = None):
            '''List products.'''
            pass
        # Generates: GET /products/beta/list-products?category=...
    """
    def decorator(target: Any) -> Any:
        """Apply version_root to target."""
        # Store version in metadata
        target.__version_root__ = version

        # If it's a class, also store in global registry
        if isinstance(target, type):
            _VERSION_ROOT_METADATA[id(target)] = version

        return target

    return decorator


def get_version_root(target: Any) -> Optional[str]:
    """
    Get version_root value from decorated target.

    Args:
        target: Decorated function, method, or class

    Returns:
        Version string or None if not decorated
    """
    # Check direct attribute
    if hasattr(target, '__version_root__'):
        return target.__version_root__

    # Check if it's a method - get from class
    if hasattr(target, '__self__'):
        return get_version_root(target.__self__.__class__)

    # Check if it's a bound method's function
    if hasattr(target, '__func__'):
        return get_version_root(target.__func__)

    return None


def has_version_root(target: Any) -> bool:
    """
    Check if target has @version_root decorator.

    Args:
        target: Function, method, or class

    Returns:
        True if decorated with @version_root
    """
    return get_version_root(target) is not None
