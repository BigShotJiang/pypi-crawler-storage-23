"""Counter provider decorator for ID counter management plugins."""

from typing import Callable, Type, TypeVar

T = TypeVar('T')


def counter_provider() -> Callable[[Type[T]], Type[T]]:
    """
    Decorator to register counter provider plugins.

    Counter providers implement ID generation strategies for Frags.
    They must implement the CounterProvider protocol:
    - is_match(context: dict) -> bool
    - async get_counter(storage) -> itertools.count

    The manager uses Repository.resolve() to find the appropriate
    provider based on storage state.

    Returns:
        Decorated class registered with CounterProviderManager

    Example:
        @counter_provider()
        @root('database-synced')
        class DatabaseSyncedCounter:
            '''Syncs counter with existing database data.'''

            def is_match(self, context: dict) -> bool:
                storage = context.get('storage')
                if not storage:
                    return False
                # Only match if database has existing data
                return storage.has_data()

            async def get_counter(self, storage):
                max_id = await storage.get_max_id()
                return itertools.count(max_id + 1)

        @counter_provider()
        @root('fresh')
        class FreshCounter:
            '''Counter for new/empty databases.'''

            def is_match(self, context: dict) -> bool:
                return True  # Always matches (fallback)

            async def get_counter(self, storage):
                return itertools.count(1)
    """
    def decorator(cls: Type[T]) -> Type[T]:
        # Register with CounterProviderManager
        from winterforge.plugins.counter import CounterProviderManager
        from winterforge.plugins.decorators.root import get_root_namespace

        # Get plugin ID from @root decorator
        plugin_id = get_root_namespace(cls)
        if not plugin_id:
            raise ValueError(
                f"@counter_provider requires @root decorator on {cls.__name__}. "
                f"Add @root('plugin-id') above @counter_provider."
            )

        # Register plugin
        CounterProviderManager.register(plugin_id, cls)

        return cls

    return decorator
