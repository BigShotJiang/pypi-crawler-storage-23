"""HTTP endpoint configuration for @decorator_provider."""

from typing import Optional, Dict, Any
from dataclasses import dataclass, field


@dataclass
class HTTPEndpointConfig:
    """
    Configuration for @decorator_provider('http_endpoint').

    Supports auto-detection of paths, parameters, and methods from:
    - @root decorator
    - @version_root decorator
    - Function signature
    - Type hints

    Example:
        # Minimal - auto-detect everything
        @root('users')
        @decorator_provider('http_endpoint')
        async def show(self, identity: str):
            pass
        # Generates: GET /users/v1/show/{identity}

        # With version
        @root('products')
        @version_root('v2')
        @decorator_provider('http_endpoint')
        async def list_products(self, category: str = None):
            pass
        # Generates: GET /products/v2/list-products?category=...

        # With custom method
        @root('users')
        @decorator_provider(
            http_endpoint=HTTPEndpointConfig(method='POST')
        )
        async def create(self, username: str, email: str):
            pass
        # Generates: POST /users/v1/create

        # Override path
        @root('users')
        @decorator_provider(
            http_endpoint=HTTPEndpointConfig(
                method='DELETE',
                path='/users/v1/{identity}/archive'
            )
        )
        async def archive_user(self, identity: str):
            pass

        # With auth
        @root('admin')
        @decorator_provider(
            http_endpoint=HTTPEndpointConfig(
                method='POST',
                auth_required=True
            )
        )
        async def delete_all(self):
            pass
    """

    method: Optional[str] = None
    """HTTP method (GET, POST, etc). Auto-detected from function name if None."""

    path: Optional[str] = None
    """
    Full URL path. Auto-generated from @root + @version_root + method name if None.
    Format: /{root}/{version}/{method-name}/{arg1}/{arg2}?kwarg1=&kwarg2=
    """

    auth_required: bool = False
    """Whether authentication is required for this endpoint."""

    options: Dict[str, Any] = field(default_factory=dict)
    """Additional FastAPI route options."""

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dict for decorator application.

        Returns:
            Dict with non-None values
        """
        result = {}
        if self.method is not None:
            result['method'] = self.method
        if self.path is not None:
            result['path'] = self.path
        result['auth_required'] = self.auth_required
        if self.options:
            result['options'] = self.options
        return result
