"""OpenAPI specification generator for HTTP endpoints."""

import inspect
from typing import Any, Dict, List, Type, get_type_hints


def generate_openapi_spec(
    registry_classes: List[Type],
    title: str = "WinterForge API",
    version: str = "1.0.0",
    description: str = ""
) -> Dict[str, Any]:
    """
    Generate OpenAPI 3.0 specification from registry classes.

    Scans registry classes for @http_endpoint decorated methods
    and generates a complete OpenAPI spec.

    Args:
        registry_classes: List of registry classes to scan
        title: API title
        version: API version
        description: API description

    Returns:
        OpenAPI 3.0 spec as dict

    Example:
        from winterforge.frags.registries.user_registry import UserRegistry

        spec = generate_openapi_spec(
            registry_classes=[UserRegistry],
            title="User API",
            version="1.0.0"
        )

        # Serve spec at /openapi.json
        @app.get("/openapi.json")
        def openapi():
            return spec
    """
    spec = {
        'openapi': '3.0.0',
        'info': {
            'title': title,
            'version': version,
            'description': description
        },
        'paths': {},
        'components': {
            'schemas': {},
            'securitySchemes': {
                'bearerAuth': {
                    'type': 'http',
                    'scheme': 'bearer'
                },
                'basicAuth': {
                    'type': 'http',
                    'scheme': 'basic'
                }
            }
        }
    }

    # Scan each registry class
    for registry_class in registry_classes:
        _scan_registry(registry_class, spec)

    return spec


def _scan_registry(registry_class: Type, spec: Dict[str, Any]) -> None:
    """
    Scan registry class for HTTP endpoints.

    Args:
        registry_class: Registry class to scan
        spec: OpenAPI spec dict to update
    """
    # Get registry name for tags
    registry_name = registry_class.__name__.replace('Registry', '')

    # Scan for @http_endpoint methods
    for attr_name in dir(registry_class):
        attr = getattr(registry_class, attr_name)
        if not callable(attr):
            continue

        # Check for @http_endpoint
        if not hasattr(attr, '__http_endpoint__'):
            continue

        metadata = attr.__http_endpoint__
        http_method = metadata['method'].lower()
        http_path = metadata['path']
        auth_required = metadata['auth_required']
        original_func = metadata['original_func']

        # Create path entry if not exists
        if http_path not in spec['paths']:
            spec['paths'][http_path] = {}

        # Generate operation
        operation = _generate_operation(
            original_func,
            registry_name,
            auth_required
        )

        spec['paths'][http_path][http_method] = operation


def _generate_operation(
    func: Any,
    tag: str,
    auth_required: bool
) -> Dict[str, Any]:
    """
    Generate OpenAPI operation from function.

    Args:
        func: Function to document
        tag: OpenAPI tag (registry name)
        auth_required: Whether auth is required

    Returns:
        OpenAPI operation dict
    """
    # Extract docstring
    docstring = inspect.getdoc(func) or func.__name__

    # Parse docstring for summary/description
    lines = docstring.split('\n')
    summary = lines[0]
    description = '\n'.join(lines[1:]).strip() if len(lines) > 1 else summary

    operation = {
        'summary': summary,
        'description': description,
        'tags': [tag],
        'parameters': [],
        'responses': {
            '200': {
                'description': 'Successful response',
                'content': {
                    'application/json': {
                        'schema': {'type': 'object'}
                    }
                }
            }
        }
    }

    # Add security if required
    if auth_required:
        operation['security'] = [{'bearerAuth': []}, {'basicAuth': []}]

    # Extract parameters from signature
    sig = inspect.signature(func)
    try:
        type_hints = get_type_hints(func)
    except Exception:
        type_hints = {}

    for param_name, param in sig.parameters.items():
        if param_name == 'self':
            continue

        # Determine parameter type
        param_type = type_hints.get(param_name, str)
        schema_type = _python_type_to_json_schema(param_type)

        # Check if path parameter
        is_path_param = False  # Simplified - would check actual path
        required = param.default == inspect.Parameter.empty

        if is_path_param:
            # Path parameter
            operation['parameters'].append({
                'name': param_name,
                'in': 'path',
                'required': True,
                'schema': schema_type
            })
        elif required:
            # Required body parameter (for POST/PUT/PATCH)
            if 'requestBody' not in operation:
                operation['requestBody'] = {
                    'required': True,
                    'content': {
                        'application/json': {
                            'schema': {
                                'type': 'object',
                                'properties': {},
                                'required': []
                            }
                        }
                    }
                }

            schema = operation['requestBody']['content']['application/json']['schema']
            schema['properties'][param_name] = schema_type
            schema['required'].append(param_name)
        else:
            # Optional query parameter
            operation['parameters'].append({
                'name': param_name,
                'in': 'query',
                'required': False,
                'schema': schema_type
            })

    return operation


def _python_type_to_json_schema(py_type: Any) -> Dict[str, str]:
    """
    Convert Python type to JSON Schema type.

    Args:
        py_type: Python type annotation

    Returns:
        JSON Schema type dict
    """
    type_map = {
        str: {'type': 'string'},
        int: {'type': 'integer'},
        float: {'type': 'number'},
        bool: {'type': 'boolean'},
        list: {'type': 'array'},
        dict: {'type': 'object'},
    }

    # Handle type strings
    if isinstance(py_type, str):
        py_type = {'str': str, 'int': int, 'float': float, 'bool': bool}.get(
            py_type,
            str
        )

    return type_map.get(py_type, {'type': 'string'})


def add_openapi_routes(app: Any, spec: Dict[str, Any]) -> None:
    """
    Add OpenAPI spec and Swagger UI routes to FastAPI app.

    Args:
        app: FastAPI application
        spec: OpenAPI specification dict

    Example:
        app = FastAPI()
        spec = generate_openapi_spec([UserRegistry])
        add_openapi_routes(app, spec)

        # Now /openapi.json and /docs work
    """
    @app.get("/openapi.json", include_in_schema=False)
    def get_openapi():
        """Serve OpenAPI specification."""
        return spec

    # FastAPI will automatically use /openapi.json for /docs
