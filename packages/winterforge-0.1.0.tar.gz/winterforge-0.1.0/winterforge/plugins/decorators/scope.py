"""
Scope decorator for declaring plugin parent relationships.

Enables subsidiary plugin pattern where plugins operate within
the scope of a parent plugin.
"""

from __future__ import annotations

from typing import Type


def scope(parent_plugin_id: str):
    """
    Declare plugin operates within parent scope.

    Automatically registers dependency relationship via metadata.
    Discovery system uses this for ordering (children before parents).

    Args:
        parent_plugin_id: Parent plugin identifier

    Returns:
        Decorator function

    Example:
        @scope('prettier')
        @element('panel')
        class PanelElement:
            '''Renders panels using Rich library.'''
            pass

        # PanelElement now has __scope__ = 'prettier'
        # Discovery ensures prettier is processed after panel
    """
    def decorator(plugin_class: Type) -> Type:
        # Store scope metadata on class
        plugin_class.__scope__ = parent_plugin_id
        return plugin_class

    return decorator
