"""
Root namespace decorator.

Provides a common namespace/domain for subordinate decorators.
Acts as the single source of truth for CLI groups, event namespaces,
cache keys, permission scopes, etc.
"""

from typing import Callable, Type, TypeVar, Optional

T = TypeVar('T')


def root(key: str, **metadata) -> Callable[[Type[T]], Type[T]]:
    """
    Define canonical key/namespace for a class.

    @root is the ONLY decorator that accepts a key parameter.
    It defines the canonical key for a class and creates CLI namespace
    for registry classes.

    For registry classes: Creates CLI namespace (e.g., 'user' → 'wf user ...')
    For plugin classes: Provides canonical key for all decorators

    Args:
        key: Canonical key/namespace (REQUIRED)
        **metadata: Additional metadata for subordinate decorators

    Returns:
        Decorated class with root key

    Examples:
        # Registry: CLI namespace
        @root('user')
        class UserRegistry(FragRegistry):
            @cli_command()  # Auto-derives: 'create'
            def create(self, username: str):
                pass  # CLI: wf user create

        # Plugin: Canonical key for all decorators
        @root('sqlite')
        @storage_backend()  # Uses 'sqlite' from @root
        @cache_backend()    # Also uses 'sqlite'
        class SQLiteStorageBackend:
            pass

        # Events use namespace prefix
        @root('user')
        class UserRegistry:
            @emits('post_save')  # → emits 'user.post_save'
            async def save(self):
                pass

    Pattern:
        - Root stores: cls._root_key = key
        - Subordinates read: getattr(cls, '_root_key', None)
        - Also stores: cls._root_namespace for backward compatibility
        - Metadata: cls._root_metadata for subordinate decorators
    """
    from winterforge.utils.naming import validate_key

    # Validate key format
    validate_key(key)

    def decorator(cls: Type[T]) -> Type[T]:
        # Prevent @root stacking - only one @root per class (direct application)
        # Check if _root_key is defined directly on this class (not inherited)
        if '_root_key' in cls.__dict__:
            existing_key = cls.__dict__['_root_key']
            raise ValueError(
                f"Cannot apply @root('{key}') to {cls.__name__}: "
                f"class already has @root('{existing_key}'). "
                f"Each class can only have one @root namespace."
            )

        # Store root key (primary attribute)
        cls._root_key = key  # type: ignore

        # Store as namespace for backward compatibility
        cls._root_namespace = key  # type: ignore

        # Store additional metadata
        if metadata:
            cls._root_metadata = metadata  # type: ignore

        return cls

    return decorator


def get_root_namespace(obj, default: Optional[str] = None) -> Optional[str]:
    """
    Get root namespace from object or its class.

    Helper for subordinate decorators to read namespace context.

    Args:
        obj: Instance or class to check
        default: Fallback if no root namespace found

    Returns:
        Root namespace or default

    Example:
        # In subordinate decorator:
        def emits(event_type: str):
            def decorator(func):
                def wrapper(self, *args, **kwargs):
                    # Get namespace from class
                    ns = get_root_namespace(self.__class__)
                    full_event = f"{ns}.{event_type}" if ns else event_type
                    await self.emit(full_event, ...)
                return wrapper
            return decorator
    """
    # Check instance class first, then object itself
    for target in [getattr(obj, '__class__', None), obj]:
        if target is not None:
            namespace = getattr(target, '_root_namespace', None)
            if namespace is not None:
                return namespace

    return default


def get_root_metadata(obj, key: str, default=None):
    """
    Get specific metadata value from root decorator.

    Args:
        obj: Instance or class to check
        key: Metadata key
        default: Fallback value

    Returns:
        Metadata value or default

    Example:
        @root('user', cache_ttl=300, audit=True)
        class UserRegistry:
            pass

        # In subordinate decorator:
        ttl = get_root_metadata(cls, 'cache_ttl', 60)  # → 300
        audit = get_root_metadata(cls, 'audit', False)  # → True
    """
    for target in [getattr(obj, '__class__', None), obj]:
        if target is not None:
            metadata = getattr(target, '_root_metadata', {})
            if key in metadata:
                return metadata[key]

    return default


def has_root(obj) -> bool:
    """
    Check if object has a root namespace defined.

    Args:
        obj: Instance or class to check

    Returns:
        True if root namespace exists

    Example:
        if has_root(user_registry):
            # Use namespaced behavior
        else:
            # Use default behavior
    """
    return get_root_namespace(obj) is not None
