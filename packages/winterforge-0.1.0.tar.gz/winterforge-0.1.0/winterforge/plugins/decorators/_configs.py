"""Protocol definitions for decorator configurations.

Provides type-safe configuration classes for injectable decorators.
"""

from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field


@dataclass
class CLICommandConfig:
    """
    Configuration for @cli_command decorator.

    Attributes:
        aliases: Alternative command names (case-insensitive, validated)
        success: Success message template (supports {token} replacement)
        error: Error/failure message template
        options: Click options for command parameters
        printer: Custom StatusPrinter ID to use
        help: Help text for the command

    Note: Command name is ALWAYS auto-detected from method name.
          No manual name override - method name IS the command name.

    Example:
        @decorator_provider(
            cli_command=CLICommandConfig(
                success='✓ User deleted: {identity}',
                error='User not found: {identity}',
                aliases=['remove', 'rm']
            )
        )
        async def delete(self, identity: str) -> bool:
            return await self.delete(identity)
    """

    aliases: Optional[List[str]] = None
    success: Optional[str] = None
    error: Optional[str] = None
    options: Optional[Dict[str, Any]] = None
    printer: Optional[str] = None
    help: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to decorator kwargs dict."""
        result = {}
        if self.aliases is not None:
            result['aliases'] = self.aliases
        if self.success is not None:
            result['message_success'] = self.success
        if self.error is not None:
            result['message_failure'] = self.error
        if self.options is not None:
            result['options'] = self.options
        if self.printer is not None:
            result['printer'] = self.printer
        if self.help is not None:
            result['help'] = self.help
        return result


@dataclass
class RootConfig:
    """
    Configuration for @root decorator.

    Attributes:
        namespace: Root command namespace (e.g., 'user', 'role')
        inject: Injection configuration for command group
        help: Help text for command group
        hidden: Whether to hide command group from help
        epilog: Text to display after help

    Example:
        @decorator_provider(
            root=RootConfig(
                namespace='user',
                inject={'admin': 'admin@system.com'}
            )
        )
        class UserRegistry(FragRegistry):
            pass
    """

    namespace: str
    inject: Optional[Dict[str, str]] = None
    help: Optional[str] = None
    hidden: bool = False
    epilog: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to decorator kwargs dict."""
        result = {}
        if self.inject is not None:
            result['inject'] = self.inject
        if self.help is not None:
            result['help'] = self.help
        if self.hidden:
            result['hidden'] = self.hidden
        if self.epilog is not None:
            result['epilog'] = self.epilog
        return result


@dataclass
class StatusPrinterConfig:
    """
    Configuration for @status_printer decorator.

    Attributes:
        priority: Printer priority (lower = checked first)
        help: Help text for the printer

    Example:
        @decorator_provider(
            status_printer=StatusPrinterConfig(priority=1)
        )
        class MyPrinter:
            pass
    """

    priority: Optional[int] = None
    help: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to decorator kwargs dict."""
        result = {}
        if self.priority is not None:
            result['priority'] = self.priority
        if self.help is not None:
            result['help'] = self.help
        return result


@dataclass
class OutputRedirectConfig:
    """
    Configuration for @output_redirect decorator.

    Attributes:
        priority: Redirect priority (lower = checked first)
        help: Help text for the redirect

    Example:
        @decorator_provider(
            output_redirect=OutputRedirectConfig(priority=1)
        )
        class MyRedirect:
            pass
    """

    priority: Optional[int] = None
    help: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to decorator kwargs dict."""
        result = {}
        if self.priority is not None:
            result['priority'] = self.priority
        if self.help is not None:
            result['help'] = self.help
        return result
