"""
Base decorator factories with common functionality.

Provides factory functions for creating class and method decorators
with automatic key derivation, signature inspection, and @root inheritance.
"""

from typing import Callable, Any, TypeVar, Type

from winterforge.utils.naming import (
    derive_key_from_name,
    validate_key,
    get_root_key,
)
from winterforge.utils.signature import extract_signature

T = TypeVar('T')


def class_decorator(manager_id: str) -> Callable:
    """
    Factory for class-level decorators.

    Class decorators REQUIRE @root to be present on the class.
    Without @root, the decorator is a no-op (does nothing).
    No key= parameter - @root provides the canonical key.

    Args:
        manager_id: Plugin manager identifier

    Returns:
        Decorator function that accepts only metadata

    Example:
        >>> # Define decorator
        >>> storage_backend = class_decorator('winterforge.storage_backends')
        >>>
        >>> # Use decorator (requires @root)
        >>> @root('sqlite')
        >>> @storage_backend()
        >>> class SQLiteStorageBackend:
        ...     pass  # Registers as 'sqlite' from @root
        >>>
        >>> # Without @root - no-op
        >>> @storage_backend()
        >>> class UnregisteredBackend:
        ...     pass  # NOT registered - missing @root
    """

    def decorator(**metadata: Any):
        """
        Actual decorator that accepts only metadata (no key parameter).

        Args:
            **metadata: Additional metadata for registration

        Returns:
            Decorated class
        """

        def wrapper(cls: Type[T]) -> Type[T]:
            # Get key from @root - REQUIRED for class decorators
            root_key = get_root_key(cls)

            if root_key is None:
                # No @root present - decorator is a no-op
                # Silently skip to allow stacking decorators
                return cls

            # Validate key format
            validate_key(root_key)

            # Register with plugin manager
            from winterforge.plugins._discovery import PluginDiscoverer

            if not PluginDiscoverer.has_manager(manager_id):
                raise KeyError(
                    f"No plugin manager registered for '{manager_id}'. "
                    f"Class '{cls.__name__}' has @root('{root_key}') but "
                    f"decorator requires plugin manager."
                )

            manager = PluginDiscoverer.get_manager(manager_id)

            # Add SQL-safe identifier to metadata (soft canonical form)
            # Converts kebab-case trait keys to snake_case for SQL column names
            enriched_metadata = dict(metadata) if metadata else {}
            enriched_metadata['sql_identifier'] = root_key.replace('-', '_')

            manager.register(root_key, cls, enriched_metadata)

            return cls

        return wrapper

    return decorator


def method_decorator(
    manager_id: str, *, inspect_signature: bool = True
) -> Callable:
    """
    Factory for method-level decorators with signature inspection.

    Method decorators auto-derive keys from method names.
    No key= parameter - auto-derivation only.

    Args:
        manager_id: Plugin manager identifier
        inspect_signature: Extract argument metadata from signature

    Returns:
        Decorator function that accepts only metadata

    Example:
        >>> # Define decorator
        >>> cli_command = method_decorator('winterforge.cli_commands')
        >>>
        >>> # Use decorator
        >>> class UserRegistry:
        ...     @cli_command()
        ...     def set_password(self, username: str, password: str):
        ...         '''Set user password.'''
        ...         pass  # Auto-derives key: 'set-password'
    """

    def decorator(**options: Any):
        """
        Actual decorator that accepts only metadata (no key parameter).

        Args:
            **options: Additional options for registration

        Returns:
            Decorated method
        """

        def wrapper(func: Callable) -> Callable:
            # Auto-derive key from method name
            final_key = derive_key_from_name(
                func.__name__,
                strip_suffixes=False,  # Methods don't have suffixes
                to_kebab_case=True,
            )

            # Validate key format
            validate_key(final_key)

            # Extract signature if requested
            arguments = {}
            if inspect_signature:
                arguments = extract_signature(func)

            # Store metadata on function for later discovery
            # (Actual registration happens when class is scanned)
            func._plugin_key = final_key
            func._plugin_arguments = arguments
            func._plugin_options = options
            func._plugin_manager_id = manager_id

            return func

        return wrapper

    return decorator


def root_decorator() -> Callable:
    """
    Create the @root decorator.

    @root is special - it's the ONLY decorator that accepts a key parameter.
    It defines the canonical key for a class.

    For registry classes: Creates CLI namespace
    For plugin classes: Provides canonical key for all decorators

    Returns:
        @root decorator function

    Example:
        >>> root = root_decorator()
        >>>
        >>> # CLI namespace
        >>> @root('user')
        >>> class UserRegistry(FragRegistry):
        ...     pass
        >>>
        >>> # Plugin canonical key
        >>> @root('sqlite')
        >>> @storage_backend()
        >>> class SQLiteStorageBackend:
        ...     pass
    """

    def decorator(key: str):
        """
        Define canonical key/namespace for a class.

        Args:
            key: Canonical key (REQUIRED)

        Returns:
            Decorated class

        Raises:
            ValueError: If key format is invalid
        """
        # Validate key format
        validate_key(key)

        def wrapper(cls: Type[T]) -> Type[T]:
            # Store root key as class attribute
            cls._root_key = key

            # If it's a registry class with CLI commands,
            # the CLI manager will discover and register the namespace
            # (handled separately by CLI manager)

            return cls

        return wrapper

    return decorator
