"""Status printer decorator for registering CLI output formatters."""

from typing import Callable


def status_printer() -> Callable:
    """
    Decorator to register a StatusPrinter plugin.

    Requires @root to define the canonical printer key.
    No key= parameter - @root provides the canonical key.

    Example:
        @root('detailed-user')
        @status_printer()
        class DetailedUserPrinter:
            def is_applicable(self, result, metadata):
                return (hasattr(result, 'affinities') and
                        'user' in result.affinities)

            def format(self, result, metadata, kwargs):
                lines = [
                    f"User: {result.username}",
                    f"  Email: {result.email}",
                    f"  ID: {result.id}"
                ]
                return "\\n".join(lines)
    """
    def decorator(cls):
        # Get key from @root - REQUIRED
        from winterforge.plugins.decorators.root import get_root_namespace

        printer_id = get_root_namespace(cls)
        if printer_id is None:
            # No @root present - decorator is a no-op
            return cls

        # Import here to avoid circular imports
        from winterforge.plugins.status_printers.manager import StatusPrinterManager

        # Register the class (not instance)
        StatusPrinterManager.register(printer_id, cls)

        return cls

    return decorator
