"""Decorator provider meta-decorator.

Provides @decorator_provider for injecting multiple decorators with configuration.
"""

from typing import Any, Callable, Dict, Union
from winterforge.plugins.decorators._manager import DecoratorManager
from winterforge.plugins.decorators._configs import (
    CLICommandConfig,
    RootConfig,
    StatusPrinterConfig,
    OutputRedirectConfig,
)


def decorator_provider(*decorator_specs, **decorator_configs):
    """
    Meta-decorator that injects multiple decorators with configuration.

    Decorators are applied in the order specified. Each decorator can be:
    - A string name (uses default config)
    - A kwarg with config dict or config object

    Args:
        *decorator_specs: Decorator names to apply with defaults (strings)
        **decorator_configs: Decorator names mapped to config dicts or config objects

    Returns:
        Decorated function/class

    Example:
        # Minimal - apply with defaults
        @decorator_provider('cli_command')
        async def show(self, identity: str) -> 'Frag':
            return await self.get(identity)

        # With configuration dict
        @decorator_provider(
            cli_command={
                'success': '✓ User deleted: {identity}',
                'error': 'User not found: {identity}'
            }
        )
        async def delete_user(self, identity: str) -> bool:
            return await self.delete(identity)

        # With configuration object
        @decorator_provider(
            cli_command=CLICommandConfig(
                success='✓ User deleted: {identity}',
                error='User not found: {identity}'
            )
        )
        async def delete_user(self, identity: str) -> bool:
            return await self.delete(identity)

        # Multiple decorators
        @decorator_provider(
            'cache_backend',
            'permission',
            cli_command={'success': '✓ Done'}
        )
        async def complex_operation(self):
            pass
    """

    def wrapper(target):
        # Combine specs and configs in order
        # Order matters - decorators are applied in the order specified
        decorator_order = []

        # Add string specs first (in order)
        for spec in decorator_specs:
            if isinstance(spec, str):
                decorator_order.append((spec, {}))

        # Add keyword configs (maintain order via dict - Python 3.7+)
        for name, config in decorator_configs.items():
            # Convert config objects to dicts
            if hasattr(config, 'to_dict'):
                config_dict = config.to_dict()
            elif isinstance(config, dict):
                config_dict = config
            else:
                # Assume it's a config object, try to convert
                config_dict = config

            decorator_order.append((name, config_dict))

        # Apply decorators in order
        decorated = target
        for decorator_name, config in decorator_order:
            decorator_func = DecoratorManager.get(decorator_name)
            if not decorator_func:
                raise ValueError(
                    f"Unknown decorator: '{decorator_name}'. "
                    f"Available decorators: {DecoratorManager.list_all()}"
                )

            # Apply decorator with config
            if config:
                decorated = decorator_func(**config)(decorated)
            else:
                decorated = decorator_func()(decorated)

        # Track what decorators were applied (useful for debugging)
        if not hasattr(decorated, '__decorator_provider_applied__'):
            decorated.__decorator_provider_applied__ = []
        decorated.__decorator_provider_applied__.extend(
            [name for name, _ in decorator_order]
        )

        return decorated

    return wrapper
