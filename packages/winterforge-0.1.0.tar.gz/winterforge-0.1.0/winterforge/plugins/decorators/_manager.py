"""Decorator manager for injectable decorators.

Manages decorator functions for @decorator_provider meta-decoration.
Follows plugin manager pattern (not registry - managers manage plugins, registries manage Frags).
"""

from typing import Callable, Dict, Optional


class DecoratorManager:
    """
    Manager for decorator functions.

    Stores decorator functions for injection via @decorator_provider.
    Separation: This manages decorator FUNCTIONS, not command METADATA.
    CLI command metadata is managed by CLICommandManager.

    Example:
        # Register a decorator
        DecoratorManager.register('cli_command', cli_command)

        # Use in decorator provider
        @decorator_provider('cli_command')
        async def my_method(self):
            pass
    """

    _decorators: Dict[str, Callable] = {}

    @classmethod
    def register(cls, name: str, decorator_func: Callable) -> None:
        """
        Register a decorator for injection.

        Args:
            name: Decorator identifier (e.g., 'cli_command')
            decorator_func: The actual decorator function

        Example:
            DecoratorManager.register('cli_command', cli_command)
        """
        cls._decorators[name] = decorator_func

    @classmethod
    def get(cls, name: str) -> Optional[Callable]:
        """
        Retrieve a registered decorator.

        Args:
            name: Decorator identifier

        Returns:
            Decorator function or None if not found
        """
        return cls._decorators.get(name)

    @classmethod
    def list_all(cls) -> list[str]:
        """
        List all registered decorator names.

        Returns:
            List of decorator identifiers
        """
        return list(cls._decorators.keys())

    @classmethod
    def is_registered(cls, name: str) -> bool:
        """
        Check if a decorator is registered.

        Args:
            name: Decorator identifier

        Returns:
            True if registered, False otherwise
        """
        return name in cls._decorators

    @classmethod
    def reset(cls) -> None:
        """Reset registry (for testing)."""
        cls._decorators = {}
