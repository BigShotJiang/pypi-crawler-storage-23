"""
Event emission decorator.

Automatically emits events after method execution,
mirroring the @cli_command pattern.
"""

from typing import Callable, Any, Optional, Dict
import functools
from winterforge.plugins.decorators.root import get_root_namespace


def emits(
    event_type: str,
    *,
    context: Optional[Dict[str, Any]] = None,
    on_success: bool = True,
    on_failure: bool = False
) -> Callable:
    """
    Decorator to automatically emit events after method execution.

    Mirrors @cli_command pattern - decorates methods to emit events
    with automatic context extraction.

    Args:
        event_type: Event path (e.g., 'user.save', 'frag.post_save')
        context: Static context to include (optional)
        on_success: Emit on successful completion (default True)
        on_failure: Emit on exception (default False)

    Returns:
        Decorated method

    Example:
        @emits('user.save')
        async def save(self):
            await storage.save(self)
            return self

        @emits('user.delete', on_failure=True)
        async def delete(self):
            await storage.delete(self.id)
            return self

        # With static context
        @emits('user.promote', context={'action': 'role_change'})
        async def add_role(self, role):
            self.roles.append(role)
            return self

    Pattern:
        - Executes method first
        - If successful and on_success=True: emit event
        - If exception and on_failure=True: emit event with error
        - Requires Frag to have 'emits_events' trait
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(self, *args, **kwargs) -> Any:
            error = None
            result = None

            try:
                result = await func(self, *args, **kwargs)
                success = True
            except Exception as e:
                error = e
                success = False

            # Build full event type with root namespace
            full_event_type = event_type

            # If event_type doesn't contain '.', try to get root namespace
            if '.' not in event_type:
                root_ns = get_root_namespace(self)
                if root_ns:
                    full_event_type = f"{root_ns}.{event_type}"

            # Build event context
            event_context = context.copy() if context else {}
            event_context['source'] = self

            if success:
                event_context['result'] = result
            else:
                event_context['error'] = str(error)
                event_context['error_type'] = type(error).__name__

            # Emit if conditions met
            should_emit = (success and on_success) or (not success and on_failure)

            if should_emit:
                # Check if Frag has emit capability
                if hasattr(self, 'emit'):
                    try:
                        await self.emit(full_event_type, **event_context)
                    except Exception as emit_error:
                        # Don't let event emission failures break the method
                        # Log in production - for now, silently continue
                        pass

            # Re-raise if there was an error
            if error:
                raise error

            return result

        # Mark as event emitter for introspection
        wrapper._emits_event = event_type
        wrapper._emits_on_success = on_success
        wrapper._emits_on_failure = on_failure

        return wrapper

    return decorator


def emits_before(event_type: str, **context: Any) -> Callable:
    """
    Decorator to emit events BEFORE method execution.

    Args:
        event_type: Event path
        **context: Static context to include

    Example:
        @emits_before('user.pre_save')
        async def save(self):
            await storage.save(self)
            return self
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(self, *args, **kwargs) -> Any:
            # Build full event type with root namespace
            full_event_type = event_type
            if '.' not in event_type:
                root_ns = get_root_namespace(self)
                if root_ns:
                    full_event_type = f"{root_ns}.{event_type}"

            # Emit before execution
            if hasattr(self, 'emit'):
                event_context = {'source': self, **context}
                try:
                    await self.emit(full_event_type, **event_context)
                except Exception:
                    # Silently continue
                    pass

            # Execute method
            return await func(self, *args, **kwargs)

        wrapper._emits_event = event_type
        wrapper._emits_timing = 'before'

        return wrapper

    return decorator


def emits_both(
    before: str,
    after: str,
    **context: Any
) -> Callable:
    """
    Decorator to emit events both before and after method execution.

    Args:
        before: Event path for pre-execution
        after: Event path for post-execution
        **context: Static context to include

    Example:
        @emits_both('user.pre_save', 'user.post_save')
        async def save(self):
            await storage.save(self)
            return self
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(self, *args, **kwargs) -> Any:
            # Build full event types with root namespace
            root_ns = get_root_namespace(self)

            before_event = before
            if '.' not in before and root_ns:
                before_event = f"{root_ns}.{before}"

            after_event = after
            if '.' not in after and root_ns:
                after_event = f"{root_ns}.{after}"

            # Before event
            if hasattr(self, 'emit'):
                try:
                    await self.emit(before_event, source=self, **context)
                except Exception:
                    pass

            # Execute
            result = await func(self, *args, **kwargs)

            # After event
            if hasattr(self, 'emit'):
                try:
                    await self.emit(
                        after_event,
                        source=self,
                        result=result,
                        **context
                    )
                except Exception:
                    pass

            return result

        wrapper._emits_events = (before, after)
        wrapper._emits_timing = 'both'

        return wrapper

    return decorator
