"""Plugin decorators for registration and derivation."""

from __future__ import annotations

from typing import Type, TypeVar, Callable, Any, Optional
from winterforge.plugins._discovery import PluginDiscoverer
from winterforge.plugins.decorators.cli_command import cli_command
from winterforge.plugins.decorators.status_printer import status_printer
from winterforge.plugins.decorators.output_redirect import output_redirect
from winterforge.plugins.decorators.http_endpoint import http_endpoint
from winterforge.plugins.decorators.version_root import (
    version_root,
    get_version_root,
    has_version_root
)
from winterforge.plugins.decorators._http_endpoint_config import (
    HTTPEndpointConfig
)
from winterforge.plugins.decorators.emits import (
    emits,
    emits_before,
    emits_both
)
from winterforge.plugins.decorators.root import (
    root,
    get_root_namespace,
    get_root_metadata,
    has_root
)
from winterforge.plugins.decorators.scope import scope
from winterforge.plugins.decorators.bootstrapper import bootstrapper
from winterforge.plugins.decorators._manager import DecoratorManager
from winterforge.plugins.decorators._provider import decorator_provider
from winterforge.plugins.decorators._configs import (
    CLICommandConfig,
    RootConfig,
    StatusPrinterConfig,
    OutputRedirectConfig,
)
from winterforge.plugins.decorators._http_endpoint_config import (
    HTTPEndpointConfig
)
from winterforge.plugins.decorators.counter_provider import counter_provider

T = TypeVar('T')

# Register decorators for @decorator_provider injection
DecoratorManager.register('cli_command', cli_command)
DecoratorManager.register('status_printer', status_printer)
DecoratorManager.register('output_redirect', output_redirect)
DecoratorManager.register('root', root)
DecoratorManager.register('http_endpoint', http_endpoint)


def plugin(manager_id: str, id: str, **metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator to register a plugin.

    Args:
        manager_id: Plugin manager identifier (e.g., 'winterforge.storage_backends')
        id: Unique identifier for this plugin
        **metadata: Additional metadata

    Returns:
        Decorator function

    Raises:
        KeyError: If manager_id is not registered

    Example:
        @plugin('winterforge.storage_backends', id='sqlite')
        class SQLiteBackend:
            pass
    """
    def decorator(cls: Type[T]) -> Type[T]:
        # Look up manager from discoverer
        if not PluginDiscoverer.has_manager(manager_id):
            raise KeyError(
                f"No plugin manager registered for '{manager_id}'. "
                f"Available managers: {list(PluginDiscoverer.all_managers().keys())}"
            )

        manager = PluginDiscoverer.get_manager(manager_id)

        # Register the plugin
        manager.register(id, cls, metadata)

        return cls

    return decorator


def storage_backend(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for storage backend plugins.

    Requires @root to define the canonical backend key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('sqlite')
        @storage_backend()
        class SQLiteBackend:
            pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.storage_backends')
    return decorator_func(**metadata)


def frag_trait(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for frag trait plugins.

    Requires @root to define the canonical trait key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata (requires, etc.)

    Returns:
        Decorator function

    Example:
        @root('userable')
        @frag_trait(requires=['persistable'])
        class UserableTrait:
            username = StringField(max_length=255)
            email = EmailField()
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator

    # Use factory to create decorator with @root inheritance
    decorator_func = class_decorator('winterforge.frag_traits')
    return decorator_func(**metadata)


def identity_resolver(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for identity resolver provider plugins.

    Requires @root to define the canonical resolver key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('uuid')
        @identity_resolver()
        class UUIDResolverProvider:
            pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.identity_resolvers')
    return decorator_func(**metadata)


def hashing_provider(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for password hashing provider plugins.

    Requires @root to define the canonical provider key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('argon2')
        @hashing_provider()
        class Argon2HashingProvider:
            pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.hashing_providers')
    return decorator_func(**metadata)


def session_provider(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for session provider plugins.

    Requires @root to define the canonical provider key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('frag')
        @session_provider()
        class FragSessionProvider:
            pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.session_providers')
    return decorator_func(**metadata)


def authentication_provider(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for authentication provider plugins.

    Requires @root to define the canonical provider key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('password')
        @authentication_provider()
        class PasswordAuthProvider:
            pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.authentication_providers')
    return decorator_func(**metadata)


def token_provider(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for token provider plugins.

    Requires @root to define the canonical provider key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('jwt')
        @token_provider()
        class JWTTokenProvider:
            pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.token_providers')
    return decorator_func(**metadata)


def email_provider(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for email provider plugins.

    Requires @root to define the canonical provider key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('smtp')
        @email_provider()
        class SMTPEmailProvider:
            pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.email_providers')
    return decorator_func(**metadata)


def http_request_handler(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for HTTP request handler plugins.

    Requires @root to define the canonical handler key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('json')
        @http_request_handler()
        class JSONRequestHandler:
            def applies_to(self, request, config) -> bool:
                return 'application/json' in request.headers.get(
                    'content-type', ''
                )

            async def extract(self, request, config) -> Frag:
                # Parse JSON body
                pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.http_request_handlers')
    return decorator_func(**metadata)


def http_response_handler(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for HTTP response handler plugins.

    Requires @root to define the canonical handler key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('json')
        @http_response_handler()
        class JSONResponseHandler:
            def applies_to(self, frag, config) -> bool:
                return 'application/json' in config.get('accept', '')

            async def format(self, frag, config) -> Dict[str, Any]:
                # Format as JSON
                pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.http_response_handlers')
    return decorator_func(**metadata)


def http_authenticator(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for HTTP authenticator plugins.

    Requires @root to define the canonical authenticator key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('bearer')
        @http_authenticator()
        class BearerAuthenticator:
            def applies_to(self, request, config) -> bool:
                auth = request.headers.get('authorization', '')
                return auth.startswith('Bearer ')

            async def authenticate(self, request, config) -> Frag:
                # Verify bearer token
                pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.http_authenticators')
    return decorator_func(**metadata)


def http_app_provider(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for HTTP application provider plugins.

    Requires @root to define the canonical provider key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('fastapi')
        @http_app_provider()
        class FastAPIProvider:
            def create_app(self, **config):
                from fastapi import FastAPI
                return FastAPI(**config)

            def add_route(self, method, path, handler):
                # Add route to app
                pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.http_app_providers')
    return decorator_func(**metadata)


def deriver(manager_id: str, id: Optional[str] = None) -> Callable[[Callable], Callable]:
    """
    Decorator to register a plugin deriver.

    Args:
        manager_id: Plugin manager identifier (e.g., 'winterforge.storage_backends')
        id: Optional deriver identifier (defaults to function name)

    Returns:
        Decorator function

    Raises:
        KeyError: If manager_id is not registered

    Example:
        @deriver('winterforge.storage_backends')
        def database_deriver():
            # Query for database config Frags
            config = FragRegistry({'affinities': ['config', 'database']})
            for db_config in config.all():
                yield {
                    'id': f'database_{db_config.slug}',
                    'class': PostgreSQLBackend,
                    'metadata': {'config': db_config}
                }
    """
    def decorator(func: Callable) -> Callable:
        # Look up manager from discoverer
        if not PluginDiscoverer.has_manager(manager_id):
            raise KeyError(
                f"No plugin manager registered for '{manager_id}'. "
                f"Available managers: {list(PluginDiscoverer.all_managers().keys())}"
            )

        manager = PluginDiscoverer.get_manager(manager_id)
        deriver_id = id or func.__name__
        manager.register_deriver(deriver_id, func)
        return func

    return decorator


def event_provider(id: str, **metadata: Any) -> Callable:
    """
    Decorator for event provider plugins.

    Supports namespacing via nested decorators on both classes
    and methods. Method signature defines event schema.

    When applied to a CLASS: Registers with EventProviderManager
    When applied to a METHOD: Marks method with _plugin_id

    Args:
        id: Event identifier or namespace
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @event_provider('user')
        class UserEvents:
            @event_provider('save')
            async def on_save(self, user: Frag, email: str):
                '''Emitted when user saved.'''
                pass

        # Defines: user.save (namespace.event)
    """
    def _decorator(target: Any) -> Any:
        """Apply decorator to class or method."""
        # If it's a class, register with manager
        if isinstance(target, type):
            from winterforge.plugins._discovery import PluginDiscoverer

            if PluginDiscoverer.has_manager('winterforge.event_providers'):
                manager = PluginDiscoverer.get_manager(
                    'winterforge.event_providers'
                )
                manager.register(id, target, metadata)

            # Mark class with plugin_id
            target._plugin_id = id
            return target

        # If it's a method, just mark it
        target._plugin_id = id
        return target

    return _decorator


def permission_provider(id: str, **metadata: Any) -> Callable:
    """
    Decorator for permission provider plugins.

    Supports namespacing via nested decorators on both classes
    and methods. Method signature defines permission check parameters.

    When applied to a CLASS: Registers with PermissionProviderManager
    When applied to a METHOD: Marks method with _plugin_id

    Args:
        id: Permission identifier or namespace
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @permission_provider('content')
        class ContentPermissions:
            @permission_provider('create')
            def can_create(self, user_id: int):
                '''Permission to create content.'''
                pass

        # Defines: content.create (namespace.permission)
    """
    def _decorator(target: Any) -> Any:
        """Apply decorator to class or method."""
        # If it's a class, register with manager
        if isinstance(target, type):
            from winterforge.plugins._discovery import PluginDiscoverer

            if PluginDiscoverer.has_manager(
                'winterforge.permission_providers'
            ):
                manager = PluginDiscoverer.get_manager(
                    'winterforge.permission_providers'
                )
                manager.register(id, target, metadata)

            # Mark class with plugin_id
            target._plugin_id = id
            return target

        # If it's a method, just mark it
        target._plugin_id = id
        return target

    return _decorator


def event_dispatcher(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for event dispatcher plugins.

    Requires @root to define the canonical dispatcher key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('event')
        @event_dispatcher()
        class Event:
            async def dispatch(self, event: Frag, source: Frag):
                pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.event_dispatchers')
    return decorator_func(**metadata)


def event_listener(events: List[str]) -> Callable:
    """
    Register callable as event listener.

    Can be applied to any async callable. Registration happens at
    import time (not via plugin system).

    Args:
        events: Event paths to listen for (e.g., ['user.save'])

    Returns:
        Decorator function

    Example:
        @event_listener(events=['user.save', 'user.delete'])
        async def audit_user(event: Frag, source: Frag):
            context = event.get_loaded_context()
            user = context['user']
            await log(f"User {user.id} changed")

        @event_listener(events=['user.save'])
        async def send_welcome_email(event: Frag, source: Frag):
            context = event.get_loaded_context()
            email = context['email']
            await email_service.send(email, 'Welcome!')
    """
    def _decorator(func: Callable) -> Callable:
        """Register function as listener for specified events."""
        from winterforge.plugins.events.listener_manager import (
            EventListenerManager,
        )

        for event_path in events:
            EventListenerManager.register(event_path, func)

        return func

    return _decorator


def index_backend(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for index backend plugins.

    Requires @root to define the canonical backend key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('hash')
        @index_backend()
        class HashIndex:
            def __init__(self, field: str):
                self._field = field
                self._index = {}

            async def warm(self):
                # Build index from storage
                pass

            def can_optimize(self, query_params: dict) -> bool:
                return self._field in query_params

            async def query(self, **criteria) -> List[int]:
                # Return matching IDs
                pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.index_backends')
    return decorator_func(**metadata)


def cache_backend(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for cache backend plugins.

    Requires @root to define the canonical backend key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('lru')
        @cache_backend()
        class LRUCache:
            def __init__(self, max_size: int = 10000):
                self.max_size = max_size
                self._cache = OrderedDict()

            def get(self, frag_id: int):
                # Return cached Frag or None
                pass

            def set(self, frag_id: int, frag: Frag):
                # Cache Frag
                pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.cache_backends')
    return decorator_func(**metadata)


def query_builder(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for query builder plugins.

    Query builder plugins are components of the query system:
    - Condition plugins (field comparisons)
    - Sort plugins (ordering)
    - Limit/Offset plugins (pagination)
    - Join plugins (relationships)
    - Executor plugins (query execution)

    Requires @root to define the canonical plugin key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('condition')
        @query_builder()
        class ConditionPlugin:
            def __init__(self, field: str, value, operator: QueryOperator):
                self.field = field
                self.value = value
                self.operator = operator

            def to_dict(self) -> dict:
                return {
                    'type': 'condition',
                    'field': self.field,
                    'value': self.value,
                    'operator': self.operator.value
                }
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.query_builders')
    return decorator_func(**metadata)


def data_transport(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for data transport plugins.

    Data transport plugins handle import/export of Frags in various formats:
    - YAML (human-readable, version-controlled)
    - JSON (API integration)
    - CSV (spreadsheet compatibility)
    - Custom formats (specialized use cases)

    Requires @root to define the canonical transport key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('yaml')
        @data_transport()
        class YamlDataTransport:
            async def dump(self, output_path: str, query=None):
                # Export Frags to YAML
                pass

            async def load(self, input_path: str, permissive=False):
                # Import Frags from YAML
                pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.data_transports')
    return decorator_func(**metadata)


def extension_installer(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for extension installer plugins.

    Extension installers manage the lifecycle of WinterForge extensions:
    - install_data() - Create default Frags, configurations
    - uninstall_check() - Analyze impact of uninstalling
    - uninstall_data() - Optional custom cleanup

    Requires @root to define the canonical extension key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('blog')
        @extension_installer()
        class BlogExtension(ExtensionInstaller):
            extension_id = 'blog'
            version = '1.0.0'

            async def install_data(self):
                # Create default categories
                pass

            async def uninstall_check(self) -> dict:
                # Analyze impact
                return super().uninstall_check()
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.extension_installers')
    return decorator_func(**metadata)


def field_auditor(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for field auditor plugins.

    Field auditors analyze database fields to find:
    - Orphaned fields (trait code missing)
    - Unused fields (no data)
    - Field provenance (which extension owns which fields)

    Requires @root to define the canonical auditor key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('orphaned-fields')
        @field_auditor()
        class OrphanedFieldAuditor:
            async def audit(self) -> Dict[str, List[dict]]:
                # Find orphaned fields
                pass

            async def cleanup_fields(self, package=None, safe_mode=True):
                # Drop orphaned fields
                pass
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.field_auditors')
    return decorator_func(**metadata)


def query_execution_strategy(**metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for query execution strategy plugins.

    Execution strategies determine HOW to execute queries:
    - Index optimization (fast lookups via IndexManager)
    - In-memory filtering (when data already loaded in Manifest)
    - Database queries (fallback to storage backend)

    Strategies are tried in Repository order via resolve() until
    one indicates it can handle the query.

    Requires @root to define the canonical strategy key.
    No key= parameter - @root provides the canonical key.

    Args:
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @root('index')
        @query_execution_strategy()
        class IndexExecutionStrategy:
            def can_execute(self, context: QueryContext) -> bool:
                # Check if suitable index exists
                return IndexManager.has_index_for(context.params)

            async def execute(self, context: QueryContext) -> List[Frag]:
                # Execute using index
                return await IndexManager.query(context.params)
    """
    from winterforge.plugins.decorators._decorator_base import class_decorator
    decorator_func = class_decorator('winterforge.query_execution_strategies')
    return decorator_func(**metadata)


def slug_convertor(id: str, **metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for slug convertor plugins.

    Slug convertors transform slugs between different formats:
    - python_slug: Converts slugs to Python-safe identifiers
    - sql_slug: Converts slugs to SQL-safe identifiers
    - Custom convertors for specialized naming conventions

    Args:
        id: Convertor identifier (e.g., 'python_slug', 'sql_slug')
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @slug_convertor('python_slug')
        class PythonSlugConvertor:
            @staticmethod
            def convert(slug: str) -> str:
                # Convert kebab-case to snake_case
                return slug.replace('-', '_')
    """
    return plugin('winterforge.slug_convertors', id=id, **metadata)


def output_formatter(id: str, **metadata: Any) -> Callable[[Type[T]], Type[T]]:
    """
    Decorator for output formatter plugins.

    Output formatters control CLI output presentation:
    - default: Standard formatted output
    - json: Machine-readable JSON
    - quiet: Minimal output
    - debug: Verbose debug information

    Args:
        id: Formatter identifier (e.g., 'json', 'debug', 'quiet')
        **metadata: Additional metadata

    Returns:
        Decorator function

    Example:
        @output_formatter('json')
        class JsonFormatter:
            def format(self, data):
                # Format data as JSON
                return json.dumps(data, indent=2)
    """
    return plugin('winterforge.output_formatters', id=id, **metadata)
