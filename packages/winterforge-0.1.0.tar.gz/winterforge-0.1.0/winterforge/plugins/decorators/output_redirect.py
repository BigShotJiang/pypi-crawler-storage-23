"""Output redirect decorator for registering CLI output destinations."""

from typing import Callable


def output_redirect() -> Callable:
    """
    Decorator to register an OutputRedirect plugin.

    Requires @root to define the canonical redirect key.
    No key= parameter - @root provides the canonical key.

    Example:
        @root('file')
        @output_redirect()
        class FileOutputRedirect:
            def write(self, message):
                with open('/tmp/cli.log', 'a') as f:
                    f.write(message + '\\n')
    """
    def decorator(cls):
        # Get key from @root - REQUIRED
        from winterforge.plugins.decorators.root import get_root_namespace

        redirect_id = get_root_namespace(cls)
        if redirect_id is None:
            # No @root present - decorator is a no-op
            return cls

        # Import here to avoid circular imports
        from winterforge.plugins.output_redirects.manager import OutputRedirectManager

        # Register the class (not instance)
        OutputRedirectManager.register(redirect_id, cls)

        return cls

    return decorator
