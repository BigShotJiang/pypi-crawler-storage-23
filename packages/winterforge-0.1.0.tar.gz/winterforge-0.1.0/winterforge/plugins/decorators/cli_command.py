"""CLI command decorator for extensible command registration.

Enables plugins, managers, and registries to expose CLI commands.
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional, Callable, Union
import inspect
from winterforge.plugins.decorators.root import get_root_namespace


def cli_command(
    *,
    aliases: Optional[List[str]] = None,
    help: Optional[str] = None,
    required: Optional[List[str]] = None,
    options: Optional[Dict[str, Any]] = None,
    inject: Optional[Dict[str, str]] = None,
    hidden: bool = False,
    epilog: Optional[str] = None,
    message_success: Optional[str] = None,
    message_failure: Optional[str] = None,
    printer: Optional[str] = None,
    output: Optional[str] = None,
) -> Callable:
    """
    Decorator to register CLI commands.

    IMPORTANT: Use @root decorator on classes, not @cli_command.

    Can decorate:
    1. Methods on @root classes - Creates subcommand (e.g., 'user create')
    2. Methods on non-@root classes - Creates standalone command (e.g., 'migrate')
    3. Standalone functions - Creates standalone command

    Pattern with @root:
    - Classes use @root('namespace') to establish command group
    - Methods on @root classes use @cli_command() for subcommands (auto-detects name)
    - Commands automatically join their class's root namespace

    Auto-Detection:
    - Command name ALWAYS auto-detected from method/function name (snake_case → kebab-case)
    - delete_user → delete-user
    - set_password → set-password
    - show → show
    - export_PDF → export-pdf
    - NO manual name override - method name IS the command name

    Args:
        aliases: Alternative command names (case-insensitive, validated)
        help: Help text (optional, defaults to docstring)
        required: List of required argument names (overrides signature inspection)
        options: Dict of Click option configurations
        inject: Dict of injection params {arg_name: identity} for class instantiation
        hidden: Hide command from help output
        epilog: Additional help text shown after main help
        message_success: Custom success message template with token replacement
        message_failure: Custom failure message template with token replacement
        printer: Custom StatusPrinter plugin ID for formatting output
        output: Custom OutputRedirect plugin ID for output destination

    Token Replacement:
        Available tokens in message templates:
        - {action}: Command name (create, update, delete, etc.)
        - {entity}: Entity type (from group or affinities)
        - {display_name}: Extracted from frag (title, username, email)
        - {id}: Frag ID
        - Any command argument (e.g., {username}, {email})
        - For list arguments: {argname} and {argname_count}

    Examples:
        # Subcommands on @root class (name auto-detected)
        @root('user')
        class UserRegistry:
            @cli_command(required=['username', 'email'])
            async def create(self, username: str, email: str):
                '''Creates 'user create' command (name from method)'''
                pass
            # Output: "✓ User created: john_doe (ID: 123)"

            @cli_command(aliases=['remove', 'rm'])
            async def delete(self, identity: str):
                '''Creates 'user delete' command with aliases'''
                pass
            # Can call: winterforge user delete alice
            #       or: winterforge user remove alice
            #       or: winterforge user rm alice

        # Custom success message with tokens
        @root('role')
        class RoleRegistry:
            @cli_command(
                required=['title'],
                message_success="✓ Role '{display_name}' created")
            async def create(self, title: str, permission: tuple = None):
                pass
            # Output: "✓ Role 'admin' created"

        # Standalone command (no @root on class)
        class DatabaseMaintenance:
            @cli_command(
                message_success="✓ Database migrated",
                message_failure="✗ Migration failed: {error}")
            async def migrate(self):
                '''Creates standalone 'migrate' command'''
                pass

        # Standalone function
        @cli_command('version')
        def show_version():
            '''Creates standalone 'version' command'''
            return "1.0.0"
    """
    def decorator(target: Union[type, Callable]) -> Union[type, Callable]:
        # Import here to avoid circular imports
        from winterforge.plugins.cli._manager import CLICommandManager
        from winterforge.plugins.cli._validation import CommandNameValidator

        # Determine if decorating a class or method/function
        is_class = inspect.isclass(target)

        if is_class:
            # Class decoration is a misuse - just return class unchanged
            # Use @root decorator for classes instead
            return target

        # Decorating a method/function
        method_name = target.__name__

        # Block dunder methods
        if method_name.startswith('__') and method_name.endswith('__'):
            raise ValueError(
                f"Cannot decorate dunder method '{method_name}'.\n"
                f"Dunder methods are not suitable for CLI commands."
            )

        # Block private methods
        if method_name.startswith('_'):
            raise ValueError(
                f"Cannot decorate private method '{method_name}'.\n"
                f"Only public methods can be CLI commands.\n"
                f"Remove the decorator or make the method public."
            )

        # Check for parent class and root namespace
        parent_group = None

        # Try to get parent class from qualname (e.g., 'UserCommands.create_user')
        if hasattr(target, '__qualname__') and '.' in target.__qualname__:
            # This is a method - mark for parent resolution
            # Note: Can't detect @root here because decorators run bottom-up
            # (@root runs AFTER @cli_command on methods)
            parent_group = '__PARENT__'

        # Auto-detect command name from function/method name
        # Uses CommandNameValidator for consistent normalization
        cmd_name = CommandNameValidator.normalize(method_name)

        # Validate and normalize aliases (case-insensitive)
        validated_aliases = []
        if aliases:
            for alias in aliases:
                # Normalize to lowercase
                normalized_alias = alias.lower()

                # Validate
                CommandNameValidator.validate(normalized_alias, context='alias')

                validated_aliases.append(normalized_alias)

        # Determine group
        resolved_group = cmd_name if parent_group != '__PARENT__' else parent_group

        # Inspect signature for argument detection
        sig = inspect.signature(target)
        params = list(sig.parameters.values())

        # Remove 'self' or 'cls' if present
        if params and params[0].name in ('self', 'cls'):
            params = params[1:]

        # Build argument list (required positional args)
        detected_args = []
        detected_options = {}

        for param in params:
            has_default = param.default != inspect.Parameter.empty

            if not has_default and param.kind == inspect.Parameter.POSITIONAL_OR_KEYWORD:
                # Required positional argument
                detected_args.append(param.name)
            else:
                # Optional argument becomes an option
                option_config = {
                    'default': param.default if has_default else None,
                    'help': f'{param.name} parameter',
                }

                # Detect boolean flags
                if param.annotation == bool or (has_default and isinstance(param.default, bool)):
                    option_config['is_flag'] = True
                    if has_default:
                        option_config['default'] = param.default

                detected_options[param.name] = option_config

        # Override with explicit required list if provided
        if required is not None:
            # When explicit required list provided, ALL params not in required become options
            for param in params:
                if param.name not in required and param.name not in detected_options:
                    # This was an argument but not in required - move to options
                    option_config = {
                        'default': None,
                        'help': f'{param.name} parameter',
                    }
                    detected_options[param.name] = option_config

            detected_args = required

        # Merge detected options with explicit options
        if options:
            detected_options.update(options)

        metadata = {
            'type': 'command',
            'name': cmd_name,
            'aliases': validated_aliases,
            'group': parent_group or resolved_group,  # Use parent group if method, else standalone
            'help': help or inspect.getdoc(target),
            'callable': target,
            'arguments': detected_args,
            'options': detected_options,
            'hidden': hidden,
            'epilog': epilog,
            'is_async': inspect.iscoroutinefunction(target),
            'message_success': message_success,
            'message_failure': message_failure,
            'printer': printer,
            'output': output,
        }

        # Store metadata on function for later resolution
        target._cli_command_metadata = metadata

        # Register with CLI manager
        CLICommandManager.register_command(metadata)

        return target

    return decorator
