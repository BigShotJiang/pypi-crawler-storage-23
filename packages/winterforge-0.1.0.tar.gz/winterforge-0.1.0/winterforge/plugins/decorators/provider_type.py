"""
Meta-decorator for creating provider types.

Augments manager classes with provider-specific validation and
introspection methods. Enables method signatures as API contracts.
"""

from __future__ import annotations

from typing import Type, Optional, Dict, Any, TYPE_CHECKING
import inspect

if TYPE_CHECKING:
    from winterforge.plugins._base import PluginManagerBase


def provider_type(manager_id: str):
    """
    Meta-decorator to augment provider managers with validation methods.

    Adds standard methods to manager classes for provider validation
    and introspection:
    - validate(path) - Check if provider defines path
    - get_schema(path) - Extract method signature as dict
    - get_description(path) - Get method docstring

    The manager must extend PluginManagerBase and implement plugin_id()
    which should return f'winterforge.{manager_id}'.

    Args:
        manager_id: Manager identifier (e.g., 'event_providers')

    Returns:
        Class decorator that augments the manager

    Example:
        @provider_type('event_providers')
        class EventProviderManager(ReorderablePluginManagerBase):
            @classmethod
            def plugin_id(cls) -> str:
                return 'winterforge.event_providers'

        # Manager now has:
        # - EventProviderManager.validate('user.save')
        # - EventProviderManager.get_schema('user.save')
        # - EventProviderManager.get_description('user.save')
    """
    def _decorator(
        cls: Type['PluginManagerBase']
    ) -> Type['PluginManagerBase']:
        """Augment manager class with provider validation methods."""

        @classmethod
        def _validate(manager_cls: Type['PluginManagerBase'], path: str) -> bool:
            """
            Check if any provider defines this path.

            Args:
                path: Provider path (e.g., 'user.save' or 'save')

            Returns:
                True if path is defined by any provider

            Example:
                if EventProviderManager.validate('user.save'):
                    await frag.emit('user.save', user=user)
            """
            # Get all registered plugin classes
            plugin_classes = manager_cls._plugins

            # Check each provider
            for plugin_id, plugin_class in plugin_classes.items():
                # Instantiate to check attributes
                provider = (
                    plugin_class()
                    if isinstance(plugin_class, type)
                    else plugin_class
                )

                if manager_cls._provider_defines(provider, path):
                    return True

            return False

        @classmethod
        def _get_schema(
            manager_cls: Type['PluginManagerBase'],
            path: str
        ) -> Optional[Dict[str, str]]:
            """
            Get method signature as schema dict.

            Extracts parameter names and type hints from provider method.

            Args:
                path: Provider path

            Returns:
                Dict mapping parameter names to type strings, or None

            Example:
                schema = EventProviderManager.get_schema('user.save')
                # {'user': 'Frag', 'email': 'str', 'created_at': 'datetime'}
            """
            plugin_classes = manager_cls._plugins

            for plugin_id, plugin_class in plugin_classes.items():
                provider = (
                    plugin_class()
                    if isinstance(plugin_class, type)
                    else plugin_class
                )

                method = manager_cls._get_provider_method(provider, path)
                if method:
                    # Extract signature
                    sig = inspect.signature(method)
                    schema: Dict[str, str] = {}

                    for name, param in sig.parameters.items():
                        if name == 'self':
                            continue

                        # Get type annotation
                        if param.annotation != inspect.Parameter.empty:
                            anno = param.annotation
                            # Convert annotation to string
                            if hasattr(anno, '__name__'):
                                schema[name] = anno.__name__
                            else:
                                schema[name] = str(anno)
                        else:
                            schema[name] = 'Any'

                    return schema

            return None

        @classmethod
        def _get_description(
            manager_cls: Type['PluginManagerBase'],
            path: str
        ) -> Optional[str]:
            """
            Get provider method docstring.

            Args:
                path: Provider path

            Returns:
                Method docstring or None

            Example:
                desc = EventProviderManager.get_description('user.save')
                # "Emitted when user saved."
            """
            plugin_classes = manager_cls._plugins

            for plugin_id, plugin_class in plugin_classes.items():
                provider = (
                    plugin_class()
                    if isinstance(plugin_class, type)
                    else plugin_class
                )

                method = manager_cls._get_provider_method(provider, path)
                if method:
                    return inspect.getdoc(method)

            return None

        @classmethod
        def _provider_defines(
            manager_cls: Type['PluginManagerBase'],
            provider: Any,
            path: str
        ) -> bool:
            """
            Check if provider defines path.

            Supports nested paths (e.g., 'user.save').

            Args:
                provider: Provider instance
                path: Provider path

            Returns:
                True if provider defines this path
            """
            parts = path.split('.')

            # Get provider's plugin_id from its class
            provider_id = getattr(
                provider.__class__,
                '_plugin_id',
                None
            )

            # For nested paths (e.g., 'user.save')
            if len(parts) > 1:
                # Check if provider matches first part of path
                if provider_id == parts[0]:
                    # Check if method exists
                    return (
                        manager_cls._get_provider_method(provider, path)
                        is not None
                    )

            # Single-level path (e.g., 'save')
            return provider_id == path

        @classmethod
        def _get_provider_method(
            manager_cls: Type['PluginManagerBase'],
            provider: Any,
            path: str
        ) -> Optional[Any]:
            """
            Get provider method for path.

            Handles nested paths (e.g., 'user.save' → UserEvents.on_save).

            Args:
                provider: Provider instance
                path: Provider path

            Returns:
                Method object or None
            """
            parts = path.split('.')

            provider_id = getattr(
                provider.__class__,
                '_plugin_id',
                None
            )

            # Nested path (e.g., 'user.save')
            if len(parts) > 1:
                if provider_id == parts[0]:
                    # Look for method matching remaining parts
                    method_id = '.'.join(parts[1:])

                    # Check all attributes
                    for attr_name in dir(provider):
                        if attr_name.startswith('_'):
                            continue

                        attr = getattr(provider, attr_name)
                        if callable(attr):
                            # Check if method has _plugin_id
                            attr_plugin_id = getattr(
                                attr,
                                '_plugin_id',
                                None
                            )
                            if attr_plugin_id == parts[1]:
                                return attr
            else:
                # Single-level path - provider itself is callable
                if provider_id == path and callable(provider):
                    return provider

            return None

        # Attach methods to manager class
        cls.validate = _validate
        cls.get_schema = _get_schema
        cls.get_description = _get_description
        cls._provider_defines = _provider_defines
        cls._get_provider_method = _get_provider_method

        return cls

    return _decorator
