"""HTTP endpoint decorator - connects WinterForge methods to HTTP APIs."""

from typing import Callable, Any, Dict, Optional
import inspect
import re
from functools import wraps


def http_endpoint(
    method: str = None,
    path: str = None,
    auth_required: bool = False,
    **options: Any
) -> Callable:
    """
    Decorator to expose WinterForge method as HTTP endpoint.

    Connects WinterForge registry methods to HTTP APIs via FastAPI.
    Uses HTTPRequestHandlerManager to extract requests and
    HTTPResponseHandlerManager to format responses.

    This enables the "Universal Methods" pattern where one method
    serves CLI, HTTP API, and Python interfaces.

    Args:
        method: HTTP method (GET, POST, PUT, DELETE, etc)
        path: URL path (/api/users/{identity})
        auth_required: Whether authentication is required
        **options: Additional FastAPI route options

    Returns:
        Decorator function

    Example:
        @http_endpoint(method='GET', path='/api/users/{identity}')
        async def show(self, identity: str) -> Frag:
            '''Get user by identity.'''
            return await self.get(identity)

        @http_endpoint(
            method='POST',
            path='/api/users',
            auth_required=True
        )
        async def create(self, username: str, email: str) -> Frag:
            '''Create new user.'''
            user = Frag(
                affinities=['user'],
                traits=['userable', 'persistable']
            )
            user.set_username(username)
            user.set_email(email)
            await user.save()
            return user
    """
    def decorator(func: Callable) -> Callable:
        # Import here to avoid circular dependency
        from winterforge.plugins.decorators.root import (
            get_root_namespace,
        )
        from winterforge.plugins.decorators.version_root import (
            get_version_root
        )

        # NOTE: We can't check for @root here because during class definition,
        # the method doesn't know about its class yet. The check is deferred to
        # registration time in the HTTPAppProvider.

        # Store metadata for lazy evaluation during registration
        # Auto-detect HTTP method from function name if not provided
        http_method = method
        if not http_method:
            func_name = func.__name__
            # create_* -> POST, update_* -> PUT, delete_* -> DELETE, else GET
            if func_name.startswith('create'):
                http_method = 'POST'
            elif func_name.startswith('update'):
                http_method = 'PUT'
            elif func_name.startswith('delete'):
                http_method = 'DELETE'
            else:
                http_method = 'GET'

        # Store original path (may be None for auto-generation)
        http_path = path

        # Create async wrapper that handles HTTP
        @wraps(func)
        async def http_wrapper(*args, **kwargs):
            """HTTP wrapper for WinterForge method."""
            # This will be called by FastAPI with request object
            # For now, just call the original function
            # Full integration will be completed in app registration
            return await func(*args, **kwargs)

        # Store metadata for app registration
        # Path may be None - will be auto-generated during registration
        http_wrapper.__http_endpoint__ = {
            'method': http_method.upper(),
            'path': http_path,  # May be None for auto-generation
            'auth_required': auth_required,
            'options': options,
            'original_func': func,
            # Store func for later path generation
            'func_for_path_gen': func,
        }

        return http_wrapper

    return decorator


def register_http_endpoints(app: Any, registry_class: type) -> None:
    """
    Register all HTTP endpoints from a registry class.

    Scans registry class for methods decorated with @http_endpoint
    and registers them with the FastAPI app.

    Args:
        app: FastAPI application instance
        registry_class: Registry class with @http_endpoint methods

    Example:
        from fastapi import FastAPI
        from winterforge.frags.registries.user_registry import UserRegistry

        app = FastAPI()
        register_http_endpoints(app, UserRegistry)
    """
    from winterforge.plugins.http_request import HTTPRequestHandlerManager
    from winterforge.plugins.http_response import HTTPResponseHandlerManager
    from winterforge.plugins.http_authenticator import HTTPAuthenticatorManager

    # Scan class for HTTP endpoint methods
    for attr_name in dir(registry_class):
        attr = getattr(registry_class, attr_name)
        if not callable(attr):
            continue

        # Check if decorated with @http_endpoint
        if not hasattr(attr, '__http_endpoint__'):
            continue

        metadata = attr.__http_endpoint__
        http_method = metadata['method']
        http_path = metadata['path']
        auth_required = metadata['auth_required']
        options = metadata['options']
        original_func = metadata['original_func']

        # Create route handler with proper closure
        def make_handler(func, requires_auth, reg_class):
            """Create FastAPI route handler."""
            async def handler(request, **path_params):
                """FastAPI route handler."""
                # Authenticate if required
                user = None
                if requires_auth:
                    user = await HTTPAuthenticatorManager.authenticate(
                        request,
                        {'required': True}
                    )

                # Extract request data
                request_frag = await HTTPRequestHandlerManager.extract(
                    request,
                    {}
                )

                # Merge path params with request body
                call_kwargs = {**path_params}
                if request_frag.body and isinstance(request_frag.body, dict):
                    call_kwargs.update(request_frag.body)

                # Call original method
                # Create registry instance
                registry = reg_class()
                result = await func(registry, **call_kwargs)

                # Format response
                response_data = await HTTPResponseHandlerManager.format(
                    result,
                    {'accept': request.headers.get('accept', 'application/json')}
                )

                # Return FastAPI response
                from fastapi import Response
                return Response(
                    content=response_data['body'],
                    status_code=response_data['status_code'],
                    headers=response_data['headers']
                )

            return handler

        # Register with FastAPI
        route_handler = make_handler(original_func, auth_required, registry_class)
        route_method = getattr(app, http_method.lower())
        route_method(http_path, **options)(route_handler)
