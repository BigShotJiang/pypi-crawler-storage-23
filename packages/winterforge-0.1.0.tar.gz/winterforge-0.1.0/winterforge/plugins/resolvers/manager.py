"""Resolver manager - universal ordering agents."""

from __future__ import annotations

from winterforge.plugins import PluginManagerBase
from winterforge.plugins._protocols.resolver import ResolverProtocol


class ResolverManager(PluginManagerBase):
    """
    Resolver manager - universal ordering agents.

    Resolvers modify collection stacks dynamically:
    - Reorder items based on logic
    - Inject items (fallbacks, defaults)
    - Remove items (duplicates, completed operations)

    Work on both Manifests and Repositories.

    Usage:
        # Get resolver
        resolver = ResolverManager.get('injectable_scope')

        # Apply to collection
        configs = Manifest(config_list, resolver=resolver)

        # Continuous re-evaluation on mutations
        updated = configs.with_before(new_config)
        # ↑ Automatically re-resolved!

    Domain-Specific Use:
        Collections can provide resolver properties:
        - InjectableManager.resolvers (config ordering)
        - SearchManager.resolvers (result ranking)
        - RouteManager.resolvers (route matching)
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return plugin manager identifier."""
        return 'winterforge.resolvers'
