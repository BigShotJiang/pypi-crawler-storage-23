"""Resolver plugins - universal ordering agents."""

from winterforge.plugins.resolvers.manager import ResolverManager

__all__ = ['ResolverManager']
