"""
Index management.

Manages index backends that provide fast Frag lookups without
loading full data. Coordinates database indexes (Tier 1) and
in-memory indexes (Tier 2).
"""

from __future__ import annotations

from typing import Optional, TYPE_CHECKING

from winterforge.plugins._base import ReorderablePluginManagerBase

if TYPE_CHECKING:
    from winterforge.indexes.backend import IndexBackend


class IndexManager(ReorderablePluginManagerBase):
    """
    Manage index backends.

    Coordinates database indexes (Tier 1) and in-memory indexes
    (Tier 2) for optimal query performance. Completely transparent -
    indexes auto-created based on trait composition.

    Database indexes (Tier 1):
    - Created by storage backends (SQLite, PostgreSQL)
    - Persistent across restarts
    - Handle complex SQL queries
    - Based on trait-normalized fields

    In-memory indexes (Tier 2):
    - Managed by IndexBackend plugins
    - Cache Frag instances for O(1) lookups
    - Support patterns DB indexes can't handle
    - Auto-maintained via events

    Example:
        # Warm indexes on startup (optional)
        await IndexManager.warm_indexes()

        # Query optimization (automatic in registries)
        backend = IndexManager.query_optimization({'slug': 'my-post'})
        if backend:
            ids = await backend.query(slug='my-post')
            # O(1) lookup instead of DB scan

        # Register custom index
        @index_backend('custom')
        class CustomIndex:
            async def warm(self):
                pass
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.index_backends'

    @classmethod
    async def warm_indexes(cls) -> None:
        """
        Build in-memory indexes on startup.

        Auto-detects commonly queried fields from traits and
        populates indexes. Optional - system works without warming.

        Called during application startup after plugin registration.

        Example:
            # In application startup
            await IndexManager.warm_indexes()
            # All registered index backends now populated
        """
        # Get all registered index backends
        repo = cls.repository()

        for backend_id, backend_class in repo.items():
            # Instantiate backend
            backend = cls.get(backend_id)

            # Warm the index
            await backend.warm()

    @classmethod
    def query_optimization(
        cls,
        query_params: dict
    ) -> Optional['IndexBackend']:
        """
        Find best index for query.

        Tries each index backend in registration order until one
        reports it can optimize the query. Returns None if no
        index available (fall back to DB).

        Args:
            query_params: Query parameters (affinities, traits, fields)

        Returns:
            Best index backend or None (fall back to DB)

        Example:
            # In FragRegistry.get()
            backend = IndexManager.query_optimization({'slug': 'my-post'})
            if backend:
                ids = await backend.query(slug='my-post')
                if ids:
                    return await storage.load(ids[0])

            # Fall back to DB query
            return await storage.query().condition('slug', 'my-post').execute()
        """
        # Try each index backend in order
        repo = cls.repository()

        for backend_id, backend_class in repo.items():
            backend = cls.get(backend_id)

            if backend.can_optimize(query_params):
                return backend

        return None
