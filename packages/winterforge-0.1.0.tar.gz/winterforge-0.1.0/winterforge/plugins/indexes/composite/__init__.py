"""
Composite index backend - multi-field queries.

Provides efficient lookups for multi-field queries by maintaining
composite keys in a hash map.
"""

from __future__ import annotations

from typing import Dict, Set, List, Tuple, Any, TYPE_CHECKING

from winterforge.plugins.decorators import index_backend

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@index_backend('composite')
class CompositeIndex:
    """
    Composite index for multi-field queries.

    Maintains hash map of composite keys (field values as tuple)
    to sets of Frag IDs. Enables fast multi-field queries without
    scanning all Frags.

    Optimized for:
    - Multi-field queries (affinities + traits)
    - Common query patterns (e.g., ['user'] + ['authenticatable'])
    - Set-based lookups

    Not suitable for:
    - Range queries on individual fields
    - Queries with many permutations (exponential combinations)

    Example:
        # Create composite index for affinities + traits
        index = CompositeIndex(('affinities', 'traits'))
        await index.warm()

        # Query: users with authenticatable trait
        ids = await index.query(
            affinities=['user'],
            traits=['authenticatable']
        )
        # [1, 2, 3] in O(1) time
    """

    def __init__(self, fields: Tuple[str, ...]):
        """
        Initialize composite index.

        Args:
            fields: Tuple of field names (e.g., ('affinities', 'traits'))

        Example:
            # Index for composition queries
            comp_index = CompositeIndex(('affinities', 'traits'))

            # Index for affinity + trait + slug
            custom_index = CompositeIndex(('affinities', 'traits', 'slug'))
        """
        self._fields = fields
        self._index: Dict[Tuple, Set[int]] = {}  # composite_key → Frag IDs

    async def warm(self) -> None:
        """
        Build index from existing Frags.

        Loads all Frags and builds composite key map.
        Optional - index updates automatically as Frags are saved.

        Example:
            index = CompositeIndex(('affinities', 'traits'))
            await index.warm()
            # Index now contains all Frag compositions
        """
        from winterforge.frags.registries.frag_registry import FragRegistry

        all_frags = await FragRegistry.all()

        for frag in all_frags:
            self.add(frag)

    def can_optimize(self, query_params: dict) -> bool:
        """
        Check if all our fields are in query.

        Args:
            query_params: Query parameters dict

        Returns:
            True if we can optimize this query

        Example:
            index = CompositeIndex(('affinities', 'traits'))

            # Can optimize
            index.can_optimize({
                'affinities': ['user'],
                'traits': ['authenticatable']
            })  # True

            # Cannot optimize (missing traits)
            index.can_optimize({'affinities': ['user']})  # False

            # Cannot optimize (extra field)
            index.can_optimize({
                'affinities': ['user'],
                'traits': ['authenticatable'],
                'slug': 'alice'
            })  # False (depends on strictness)
        """
        return all(field in query_params for field in self._fields)

    async def query(self, **criteria) -> List[int]:
        """
        Query index for matching Frag IDs.

        Args:
            **criteria: Query criteria (should include all our fields)

        Returns:
            List of Frag IDs matching criteria

        Example:
            ids = await index.query(
                affinities=['user'],
                traits=['authenticatable']
            )
            # [1, 2, 3, 5, 8]
        """
        # Build key tuple from criteria
        key = self._build_key(criteria)

        if key in self._index:
            return list(self._index[key])
        return []

    def add(self, frag: 'Frag') -> None:
        """
        Add Frag to index.

        Builds composite key from Frag fields and adds to index.
        Called automatically when Frag is saved.

        Args:
            frag: Frag instance

        Example:
            # After frag.save()
            index.add(frag)  # Automatic via events
        """
        # Build key from Frag
        key = self._build_key_from_frag(frag)

        if key not in self._index:
            self._index[key] = set()
        self._index[key].add(frag.id)

    def remove(self, frag_id: int) -> None:
        """
        Remove Frag from index.

        Removes Frag ID from all composite keys.
        Called automatically when Frag is deleted.

        Args:
            frag_id: Frag ID to remove

        Example:
            # After frag.delete()
            index.remove(frag.id)  # Automatic via events
        """
        for frag_ids in self._index.values():
            frag_ids.discard(frag_id)

    def _build_key(self, criteria: dict) -> Tuple:
        """
        Build composite key tuple from query criteria.

        Args:
            criteria: Query criteria dict

        Returns:
            Tuple of normalized field values

        Example:
            key = self._build_key({
                'affinities': ['user'],
                'traits': ['authenticatable']
            })
            # (('user',), ('authenticatable',))
        """
        values = []
        for field in self._fields:
            value = criteria.get(field)
            # Normalize lists to sorted tuples
            if isinstance(value, list):
                value = tuple(sorted(value))
            values.append(value)

        return tuple(values)

    def _build_key_from_frag(self, frag: 'Frag') -> Tuple:
        """
        Build composite key tuple from Frag.

        Args:
            frag: Frag instance

        Returns:
            Tuple of normalized field values
        """
        values = []
        for field in self._fields:
            value = frag.get(field)
            # Normalize lists to sorted tuples
            if isinstance(value, list):
                value = tuple(sorted(value))
            values.append(value)

        return tuple(values)
