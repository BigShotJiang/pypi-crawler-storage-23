"""Index system for fast Frag queries."""

from ._manager import IndexManager
from ._backend import IndexBackend

__all__ = ['IndexManager', 'IndexBackend']
