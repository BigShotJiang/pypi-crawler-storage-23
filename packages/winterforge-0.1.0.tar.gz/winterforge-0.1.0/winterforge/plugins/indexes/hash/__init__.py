"""
Hash index backend - O(1) field lookups.

Provides constant-time lookups for single-field queries using
an in-memory hash map.
"""

from __future__ import annotations

from typing import Dict, List, TYPE_CHECKING

from winterforge.plugins.decorators import index_backend

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@index_backend('hash')
class HashIndex:
    """
    Hash-based index for field lookups.

    Provides O(1) lookups for single field queries by maintaining
    an in-memory hash map of field_value → Frag instance.

    Optimized for:
    - Single field queries (e.g., slug='my-post')
    - Unique or low-cardinality fields
    - Fast exact-match lookups

    Not suitable for:
    - Multi-field queries (use CompositeIndex)
    - Range queries (use DB indexes)
    - High-cardinality fields (memory overhead)

    Example:
        # Registry.get() uses hash index automatically
        user = await registry.get('alice')
        # → O(1) via username hash index

        # Create hash index for slug field
        slug_index = HashIndex('slug')
        await slug_index.warm()

        # Query index
        ids = await slug_index.query(slug='my-post')
        # [42] in O(1) time
    """

    def __init__(self, field: str):
        """
        Initialize hash index.

        Args:
            field: Field name to index (e.g., 'slug', 'username')

        Example:
            slug_index = HashIndex('slug')
            username_index = HashIndex('username')
        """
        self._field = field
        self._index: Dict[str, 'Frag'] = {}  # field_value → Frag

    async def warm(self) -> None:
        """
        Build index from existing Frags.

        Loads all Frags from storage and builds hash map.
        Optional - index updates automatically as Frags are saved.

        Example:
            index = HashIndex('slug')
            await index.warm()
            # Index now contains all Frags with slug field
        """
        from winterforge.frags.registries.frag_registry import FragRegistry

        # Load all Frags
        all_frags = await FragRegistry.all()

        for frag in all_frags:
            value = frag.get(self._field)
            if value is not None:
                self._index[value] = frag

    def can_optimize(self, query_params: dict) -> bool:
        """
        Check if query is single field matching our field.

        Args:
            query_params: Query parameters dict

        Returns:
            True if we can optimize this query

        Example:
            index = HashIndex('slug')

            index.can_optimize({'slug': 'my-post'})  # True
            index.can_optimize({'title': 'My Post'})  # False
            index.can_optimize({'slug': 'x', 'title': 'y'})  # False
        """
        return len(query_params) == 1 and self._field in query_params

    async def query(self, **criteria) -> List[int]:
        """
        Query index for matching Frag IDs.

        Args:
            **criteria: Query criteria (should match our field)

        Returns:
            List of Frag IDs (single ID or empty)

        Example:
            ids = await index.query(slug='my-post')
            # [42]
        """
        value = criteria.get(self._field)
        if value and value in self._index:
            return [self._index[value].id]
        return []

    def add(self, frag: 'Frag') -> None:
        """
        Add Frag to index.

        Extracts field value and updates hash map.
        Called automatically when Frag is saved.

        Args:
            frag: Frag instance

        Example:
            # After frag.save()
            index.add(frag)  # Automatic via events
        """
        value = frag.get(self._field)
        if value is not None:
            self._index[value] = frag

    def remove(self, frag_id: int) -> None:
        """
        Remove Frag from index.

        Finds and removes Frag by ID from hash map.
        Called automatically when Frag is deleted.

        Args:
            frag_id: Frag ID to remove

        Example:
            # After frag.delete()
            index.remove(frag.id)  # Automatic via events
        """
        # Find and remove by ID (linear search unavoidable)
        for key, frag in list(self._index.items()):
            if frag.id == frag_id:
                del self._index[key]
                break
