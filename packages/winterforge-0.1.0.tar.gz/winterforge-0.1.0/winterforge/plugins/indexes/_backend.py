"""
Index backend protocol.

Defines the interface for index backends that provide fast
lookups for specific query patterns.
"""

from __future__ import annotations

from typing import Protocol, List, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class IndexBackend(Protocol):
    """
    Protocol for index backends.

    Index backends provide fast lookups for specific query patterns
    without loading full Frag data. They work alongside database
    indexes (Tier 1) as in-memory accelerators (Tier 2).

    Implementations should be specialized for specific query patterns:
    - HashIndex: O(1) single-field lookups
    - CompositeIndex: Multi-field queries
    - Future: Full-text index, geospatial index

    Example:
        class HashIndex:
            def __init__(self, field: str):
                self._field = field
                self._index = {}

            async def warm(self):
                # Build index from existing Frags
                pass

            def can_optimize(self, query_params: dict) -> bool:
                return len(query_params) == 1 and self._field in query_params

            async def query(self, **criteria) -> List[int]:
                value = criteria.get(self._field)
                if value and value in self._index:
                    return [self._index[value].id]
                return []

            def add(self, frag: Frag):
                value = frag.get(self._field)
                if value is not None:
                    self._index[value] = frag

            def remove(self, frag_id: int):
                # Remove by ID
                pass
    """

    async def warm(self) -> None:
        """
        Build index from existing Frags.

        Called during system startup to populate index from
        persistent storage. Optional - system works without warming.

        Example:
            index = HashIndex('slug')
            await index.warm()  # Loads all Frags, builds index
        """
        ...

    def can_optimize(self, query_params: dict) -> bool:
        """
        Check if this index can optimize the query.

        Args:
            query_params: Query parameters dict
                         (e.g., {'slug': 'my-post', 'affinities': ['post']})

        Returns:
            True if this index can handle the query efficiently

        Example:
            # HashIndex for 'slug' field
            index.can_optimize({'slug': 'my-post'})  # True
            index.can_optimize({'title': 'My Post'})  # False
            index.can_optimize({'slug': 'x', 'title': 'y'})  # False
        """
        ...

    async def query(self, **criteria) -> List[int]:
        """
        Query index for matching Frag IDs.

        Args:
            **criteria: Query criteria (field names and values)

        Returns:
            List of Frag IDs matching criteria (may be empty)

        Example:
            # HashIndex for 'slug' field
            ids = await index.query(slug='my-post')
            # [42]

            # CompositeIndex for ('affinities', 'traits')
            ids = await index.query(
                affinities=['post'],
                traits=['titled']
            )
            # [42, 43, 44]
        """
        ...

    def add(self, frag: 'Frag') -> None:
        """
        Add Frag to index.

        Called automatically when Frag is saved. Index should
        extract relevant fields and update internal structures.

        Args:
            frag: Frag instance to index

        Example:
            # After Frag.save()
            index.add(frag)  # Index updated automatically
        """
        ...

    def remove(self, frag_id: int) -> None:
        """
        Remove Frag from index.

        Called automatically when Frag is deleted. Index should
        remove all references to this Frag ID.

        Args:
            frag_id: Frag ID to remove

        Example:
            # After Frag.delete()
            index.remove(frag.id)  # Index cleaned automatically
        """
        ...
