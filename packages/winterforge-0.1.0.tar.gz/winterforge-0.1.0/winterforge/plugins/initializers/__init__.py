"""Initialization plugins."""

from winterforge.plugins.initializers.manager import InitializerManager

__all__ = ['InitializerManager']
