"""Initializer plugin manager."""

from winterforge.plugins._base import PluginManagerBase


class InitializerManager(PluginManagerBase):
    """
    Manager for initialization plugins.

    Initializers execute as ordered stack for idempotent
    application setup. Each initializer:
    - Checks if already initialized (idempotent)
    - Performs setup if needed
    - Returns without error if already done

    Plugins can inject custom initializers with explicit
    ordering via dependencies, not priorities.

    Ordering via dependency resolution ensures proper
    initialization sequence (e.g., application before storage).

    Example:
        # Core initializer
        @plugin('initializer', 'application')
        class ApplicationInitializer:
            async def execute(self, context: dict) -> None:
                # Check if application exists
                apps = await ApplicationRegistry.all()
                if apps.resolve(lambda f: True):
                    return  # Already initialized

                # Create application Frag
                app = await ApplicationRegistry.create(
                    name=context['name'],
                    description=context.get('description', '')
                )
                await app.save()

        # Plugin initializer with dependency
        @plugin('initializer', 'blog_setup')
        @depends_on('application')
        class BlogInitializer:
            async def execute(self, context: dict) -> None:
                # Setup blog-specific configuration
                pass

        # Execute all initializers
        from winterforge.plugins.initializers.manager import InitializerManager
        import asyncio

        context = {'name': 'My Blog'}
        initializers = InitializerManager.repository()

        # Accumulate async tasks via resolve_all
        tasks = initializers.resolve_all(
            lambda acc, init: acc + [init.execute(context)],
            initial=[]
        )

        # Execute all (ordered by dependencies)
        await asyncio.gather(*tasks)
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Plugin manager identifier."""
        return 'winterforge.initializers'
