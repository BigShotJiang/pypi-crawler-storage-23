"""Application initializer plugin."""

from typing import Dict, Any, Optional, TYPE_CHECKING
from winterforge.plugins.decorators import plugin

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@plugin('winterforge.initializers', 'application')
class ApplicationInitializer:
    """
    Create application identity Frag (idempotent).

    This initializer:
    - Checks if application Frag exists
    - Creates one if missing
    - Skips if already initialized

    Application Frag provides:
    - Application identity (via Frag UUID)
    - Human-readable name
    - Optional description
    - Export/import signal (portable vs non-portable)

    Example:
        # Executed during winterforge init
        initializer = ApplicationInitializer()
        await initializer.execute({
            'name': 'Production Blog',
            'description': 'Main production instance'
        })

        # Idempotent - safe to run multiple times
        await initializer.execute({'name': 'Production Blog'})
        # No-op if already exists
    """

    async def _get_first_app(self) -> Optional['Frag']:
        """
        Get first application Frag from registry.

        Returns:
            First app Frag or None if no apps exist
        """
        from winterforge.frags.registries.application_registry import (
            ApplicationRegistry
        )
        from winterforge.frags.manifest import Manifest

        registry = ApplicationRegistry()
        apps_list = await registry.all()
        apps = Manifest(apps_list)
        return apps.resolve(lambda f: True)

    async def execute(self, context: Dict[str, Any]) -> None:
        """
        Execute application initialization (idempotent).

        Args:
            context: Initialization context with:
                - name: Application name (required)
                - description: Application description (optional)

        Returns:
            None (idempotent - no error if already exists)

        Example:
            await initializer.execute({
                'name': 'My Blog',
                'description': 'Personal blog site'
            })
        """
        from winterforge.frags.registries.application_registry import (
            ApplicationRegistry
        )

        # Check if application already exists (idempotent)
        if await self._get_first_app():
            return  # Already initialized

        # Create application Frag
        name = context.get('name', 'Winterforge Application')
        description = context.get('description', '')

        registry = ApplicationRegistry()
        app = await registry.create(
            name=name,
            description=description
        )
        await app.save()
