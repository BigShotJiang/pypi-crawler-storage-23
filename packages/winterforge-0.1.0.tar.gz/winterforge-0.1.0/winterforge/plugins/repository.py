"""Immutable plugin repository with ordering and resolution."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TypeVar, Generic, List, Dict, Iterator, Tuple, Optional, Callable, Any

T = TypeVar('T')


class RepositoryBase(ABC, Generic[T]):
    """
    Abstract base class for repositories.

    Repositories are immutable ordered collections with resolution capabilities.
    All operations that modify ordering return NEW repository instances.

    Must be extended for concrete usage (base classes never instantiated directly).

    Type parameter:
        T: The type of items stored in this repository
    """

    @abstractmethod
    def get(self, item_id: str) -> T:
        """
        Get an item by ID.

        Args:
            item_id: Item identifier

        Returns:
            The item

        Raises:
            KeyError: If item_id not found
        """
        ...

    @abstractmethod
    def has(self, item_id: str) -> bool:
        """
        Check if item exists.

        Args:
            item_id: Item identifier

        Returns:
            True if item exists, False otherwise
        """
        ...

    @abstractmethod
    def order(self) -> List[str]:
        """
        Get current item order.

        Returns:
            List of item IDs in current order
        """
        ...

    @abstractmethod
    def all(self) -> List[T]:
        """
        Get all items in current order.

        Returns:
            List of items in order
        """
        ...

    @abstractmethod
    def values(self) -> Iterator[T]:
        """
        Iterate over items in order.

        Yields:
            Items in order
        """
        ...

    @abstractmethod
    def items(self) -> Iterator[Tuple[str, T]]:
        """
        Iterate over (id, item) pairs in order.

        Yields:
            Tuples of (item_id, item)
        """
        ...

    @abstractmethod
    def resolve(self, predicate: Callable[[T], bool]) -> Optional[T]:
        """
        First-match resolution using predicate.

        Tries each item in order until predicate returns True.

        Args:
            predicate: Function that returns True if item matches

        Returns:
            First matching item, or None if no match
        """
        ...

    @abstractmethod
    def resolve_all(self, reducer: Callable[[Any, T], Any], initial: Any = None) -> Any:
        """
        Chain of responsibility - accumulate through all items in order.

        Passes each item through the reducer function, allowing each to
        transform/override/merge the accumulated value.

        Args:
            reducer: Function(accumulated_value, item) -> new_value
            initial: Starting value for accumulation

        Returns:
            Final accumulated value after passing through all items
        """
        ...


class PluginRepository(RepositoryBase[T]):
    """
    Immutable repository representing an ordered snapshot of plugins.

    Provides ordering, data presentation, and first-match resolution.
    Ordering operations return NEW repositories (immutable pattern).
    Can be passed between processes as an ordered snapshot.

    Type parameter:
        T: The plugin type stored in this repository

    Examples:
        # Manager creates a repository
        repo = manager.repository()

        # Get ordered list
        backends = repo.all()  # [SQLiteBackend, PostgreSQLBackend]

        # Reorder (creates NEW repository)
        new_repo = repo.with_front('postgresql')
        new_repo.order()  # ['postgresql', 'sqlite']

        # Original unchanged
        repo.order()  # ['sqlite', 'postgresql']

        # First-match resolution
        result = repo.resolve(lambda plugin: plugin.can_handle(data))
    """

    def __init__(self, plugins: Dict[str, T], order: List[str]) -> None:
        """
        Initialize repository (called by PluginManager).

        Args:
            plugins: Dictionary of plugin_id -> plugin
            order: List of plugin IDs in order

        Note: This constructor is intended for internal use by plugin managers.
        """
        # Store immutable copies
        self._plugins: Dict[str, T] = plugins.copy()
        self._order: List[str] = order.copy()

    def get(self, plugin_id: str) -> T:
        """
        Get a plugin by ID.

        Args:
            plugin_id: Plugin identifier

        Returns:
            The plugin instance or class

        Raises:
            KeyError: If plugin_id not found
        """
        return self._plugins[plugin_id]

    def has(self, plugin_id: str) -> bool:
        """
        Check if plugin exists.

        Args:
            plugin_id: Plugin identifier

        Returns:
            True if plugin exists, False otherwise
        """
        return plugin_id in self._plugins

    def order(self) -> List[str]:
        """
        Get current plugin order.

        Returns:
            List of plugin IDs in current order
        """
        return self._order.copy()

    def with_order(self, order: List[str]) -> PluginRepository[T]:
        """
        Create new repository with specified order.

        Args:
            order: List of plugin IDs in desired order

        Returns:
            New repository with the specified order

        Raises:
            ValueError: If order doesn't contain all plugins exactly once
        """
        # Validate that order contains exactly the same plugins
        if set(order) != set(self._order):
            missing = set(self._order) - set(order)
            extra = set(order) - set(self._order)
            msg = []
            if missing:
                msg.append(f"Missing plugins: {missing}")
            if extra:
                msg.append(f"Unknown plugins: {extra}")
            raise ValueError("; ".join(msg))

        return PluginRepository(self._plugins, order)

    def with_front(self, plugin_id: str) -> PluginRepository[T]:
        """
        Create new repository with plugin at front.

        Args:
            plugin_id: Plugin identifier

        Returns:
            New repository with plugin at front

        Raises:
            ValueError: If plugin_id not found
        """
        if plugin_id not in self._order:
            raise ValueError(f"Plugin '{plugin_id}' not found")

        new_order = [plugin_id] + [pid for pid in self._order if pid != plugin_id]
        return PluginRepository(self._plugins, new_order)

    def with_back(self, plugin_id: str) -> PluginRepository[T]:
        """
        Create new repository with plugin at back.

        Args:
            plugin_id: Plugin identifier

        Returns:
            New repository with plugin at back

        Raises:
            ValueError: If plugin_id not found
        """
        if plugin_id not in self._order:
            raise ValueError(f"Plugin '{plugin_id}' not found")

        new_order = [pid for pid in self._order if pid != plugin_id] + [plugin_id]
        return PluginRepository(self._plugins, new_order)

    def with_before(self, plugin_id: str, target_id: str) -> PluginRepository[T]:
        """
        Create new repository with plugin before target.

        Args:
            plugin_id: Plugin to position
            target_id: Plugin to insert before

        Returns:
            New repository with plugin before target

        Raises:
            ValueError: If either plugin not found
        """
        if plugin_id not in self._order:
            raise ValueError(f"Plugin '{plugin_id}' not found")
        if target_id not in self._order:
            raise ValueError(f"Target plugin '{target_id}' not found")

        new_order = []
        for pid in self._order:
            if pid == plugin_id:
                continue
            if pid == target_id:
                new_order.append(plugin_id)
            new_order.append(pid)

        return PluginRepository(self._plugins, new_order)

    def with_after(self, plugin_id: str, target_id: str) -> PluginRepository[T]:
        """
        Create new repository with plugin after target.

        Args:
            plugin_id: Plugin to position
            target_id: Plugin to insert after

        Returns:
            New repository with plugin after target

        Raises:
            ValueError: If either plugin not found
        """
        if plugin_id not in self._order:
            raise ValueError(f"Plugin '{plugin_id}' not found")
        if target_id not in self._order:
            raise ValueError(f"Target plugin '{target_id}' not found")

        new_order = []
        for pid in self._order:
            if pid == plugin_id:
                continue
            new_order.append(pid)
            if pid == target_id:
                new_order.append(plugin_id)

        return PluginRepository(self._plugins, new_order)

    def filter(self, predicate: Callable[[T], bool]) -> PluginRepository[T]:
        """
        Create new repository containing only plugins matching predicate.

        Instantiates each plugin (if it's a class) and passes it to the predicate.
        Plugins where predicate returns True are included in the new repository.
        Original ordering is preserved.

        Args:
            predicate: Function receiving plugin instance, returns True to include

        Returns:
            New repository with only matching plugins

        Examples:
            # Filter identity resolvers by capability
            applicable = repo.filter(lambda r: r.can_resolve('my-post'))

            # Filter storage backends by feature
            transactional = repo.filter(lambda b: b.supports_transactions())

            # Chain with reordering
            custom = IdentityResolverManager.repository()\\
                .with_front('slug')\\
                .filter(lambda r: r.can_resolve(identity))
        """
        filtered_ids = []
        filtered_plugins = {}

        for plugin_id, plugin_class in self.items():
            # Instantiate if it's a class
            plugin = plugin_class() if isinstance(plugin_class, type) else plugin_class

            # Check predicate
            if predicate(plugin):
                filtered_ids.append(plugin_id)
                filtered_plugins[plugin_id] = plugin_class

        return PluginRepository(filtered_plugins, filtered_ids)

    def ordered(
        self,
        key: Callable[[T], Any],
        reverse: bool = False
    ) -> PluginRepository[T]:
        """
        Create new repository with items sorted by key function.

        Instantiates each plugin (if it's a class) and passes it to key
        function for sorting. Returns new repository with sorted order.

        Args:
            key: Function receiving plugin instance, returns sort key
            reverse: Sort in descending order if True

        Returns:
            New repository with sorted order

        Examples:
            # Sort by priority attribute
            repo.ordered(lambda p: p.priority)

            # Sort by name (descending)
            repo.ordered(lambda p: p.name, reverse=True)

            # Sort by multiple criteria
            repo.ordered(lambda p: (p.priority, p.name))

            # Chain with filtering
            repo.filter(lambda p: p.active).ordered(lambda p: p.priority)
        """
        # Create list of (plugin_id, sort_key) tuples
        sorted_items = []
        for plugin_id, plugin_class in self.items():
            # Instantiate if it's a class
            plugin = (
                plugin_class()
                if isinstance(plugin_class, type)
                else plugin_class
            )
            sort_key = key(plugin)
            sorted_items.append((plugin_id, sort_key))

        # Sort by key
        sorted_items.sort(key=lambda item: item[1], reverse=reverse)

        # Extract ordered IDs
        new_order = [plugin_id for plugin_id, _ in sorted_items]

        return PluginRepository(self._plugins, new_order)

    def resolve(self, predicate: Callable[[T], bool]) -> Optional[T]:
        """
        First-match resolution using predicate.

        Tries each plugin in order until predicate returns True.

        Args:
            predicate: Function that returns True if plugin matches

        Returns:
            First matching plugin, or None if no match

        Examples:
            # Find first storage backend supporting transactions
            backend = repo.resolve(lambda b: b.supports_transactions())

            # Find first resolver that can handle an identity
            resolver = repo.resolve(lambda r: r.is_match(identity))
        """
        for plugin in self.values():
            if predicate(plugin):
                return plugin
        return None

    def resolve_all(self, reducer: Callable[[Any, T], Any], initial: Any = None) -> Any:
        """
        Chain of responsibility - accumulate through all plugins in order.

        Passes each plugin through the reducer function, allowing each to
        transform/override/merge the accumulated value.

        Args:
            reducer: Function(accumulated_value, plugin) -> new_value
            initial: Starting value for accumulation

        Returns:
            Final accumulated value after passing through all plugins

        Examples:
            # Config: each provider overrides previous (last wins)
            value = repo.resolve_all(
                lambda val, provider: provider.get(key, val) if provider.has(key) else val,
                initial=None
            )

            # Merge lists from all providers
            items = repo.resolve_all(
                lambda acc, plugin: acc + plugin.get_items(),
                initial=[]
            )

            # Count matching plugins
            count = repo.resolve_all(
                lambda acc, plugin: acc + 1 if plugin.matches(criteria) else acc,
                initial=0
            )
        """
        result = initial
        for plugin in self.values():
            result = reducer(result, plugin)
        return result

    def resolve_with_id(self, predicate: Callable[[T], bool]) -> Optional[Tuple[str, T]]:
        """
        First-match resolution returning (id, plugin) tuple.

        Args:
            predicate: Function that returns True if plugin matches

        Returns:
            Tuple of (plugin_id, plugin) for first match, or None
        """
        for plugin_id, plugin in self.items():
            if predicate(plugin):
                return (plugin_id, plugin)
        return None

    def resolve_all_with_id(self, reducer: Callable[[Any, Tuple[str, T]], Any], initial: Any = None) -> Any:
        """
        Chain of responsibility with plugin IDs - accumulate through all plugins.

        Like resolve_all, but the reducer receives (plugin_id, plugin) tuples.

        Args:
            reducer: Function(accumulated_value, (plugin_id, plugin)) -> new_value
            initial: Starting value for accumulation

        Returns:
            Final accumulated value after passing through all plugins

        Example:
            # Build dict of plugin_id -> value
            values = repo.resolve_all_with_id(
                lambda acc, (pid, plugin): {**acc, pid: plugin.get_value()},
                initial={}
            )
        """
        result = initial
        for plugin_id, plugin in self.items():
            result = reducer(result, (plugin_id, plugin))
        return result

    def all(self) -> List[T]:
        """
        Get all plugins in current order.

        Returns:
            List of plugin instances/classes in order
        """
        return [self._plugins[pid] for pid in self._order]

    def items(self) -> Iterator[Tuple[str, T]]:
        """
        Iterate over (id, plugin) pairs in order.

        Yields:
            Tuples of (plugin_id, plugin)
        """
        for pid in self._order:
            yield pid, self._plugins[pid]

    def ids(self) -> Iterator[str]:
        """
        Iterate over plugin IDs in order.

        Yields:
            Plugin IDs
        """
        return iter(self._order)

    def values(self) -> Iterator[T]:
        """
        Iterate over plugins in order.

        Yields:
            Plugin instances/classes
        """
        for pid in self._order:
            yield self._plugins[pid]

    def __len__(self) -> int:
        """Return number of plugins."""
        return len(self._plugins)

    def __iter__(self) -> Iterator[str]:
        """Iterate over plugin IDs in order."""
        return iter(self._order)

    def __contains__(self, plugin_id: str) -> bool:
        """Check if plugin exists."""
        return plugin_id in self._plugins

    def __getitem__(self, plugin_id: str) -> T:
        """Get plugin by ID using [] notation."""
        return self._plugins[plugin_id]
