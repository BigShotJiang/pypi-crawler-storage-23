"""
Plugin system for Winterforge.

Provides decorator-based plugin registration, lazy instantiation,
and plugin derivatives for dynamic generation.
"""

from winterforge.plugins._base import (
    PluginManagerBase,
    ReorderablePluginManager,
    ReorderablePluginManagerBase,
)
from winterforge.plugins._matchable import MatchablePlugin
from winterforge.plugins._discovery import PluginDiscoverer
from winterforge.plugins._manager_manager import PluginManagerManager
from winterforge.plugins.decorators import (
    plugin,
    deriver,
    storage_backend,
    frag_trait,
    identity_resolver,
    hashing_provider,
    session_provider,
    authentication_provider,
    token_provider,
    email_provider,
    counter_provider,
    http_request_handler,
    http_response_handler,
    http_authenticator,
    http_app_provider,
    http_endpoint,
    version_root,
    HTTPEndpointConfig,
    decorator_provider,
    cli_command,
    root,
)
from winterforge.plugins._discovery import discover_plugins
from winterforge.plugins.lifecycle import (
    LifecycleManager,
    get_lifecycle_manager,
    reset_lifecycle_manager,
)
from winterforge.plugins._protocols import (
    LifecycleAware,
    StorageBackend,
    FragTrait,
    IdentityResolverProvider,
    ReadOnlyStorage,
)
from winterforge.plugins.storage.manager import StorageManager
from winterforge.frags.traits._manager import FragTraitManager
from winterforge.plugins.identity.manager import IdentityResolverManager
from winterforge.plugins.status_printers.manager import StatusPrinterManager
from winterforge.plugins.output_redirects.manager import OutputRedirectManager
from winterforge.plugins.hashing import HashingProviderManager
from winterforge.plugins.session import SessionProviderManager
from winterforge.plugins.authentication import AuthenticationProviderManager
from winterforge.plugins.token import TokenProviderManager
from winterforge.plugins.email import EmailProviderManager
from winterforge.plugins.http_request import HTTPRequestHandlerManager
from winterforge.plugins.http_response import HTTPResponseHandlerManager
from winterforge.plugins.http_authenticator import HTTPAuthenticatorManager
from winterforge.plugins.http_app import HTTPAppProviderManager
from winterforge.plugins.counter import CounterProviderManager

__all__ = [
    # Base
    'PluginManagerBase',
    'ReorderablePluginManager',
    'ReorderablePluginManagerBase',
    'MatchablePlugin',

    # Discovery
    'PluginDiscoverer',
    'PluginManagerManager',

    # Decorators
    'plugin',
    'deriver',
    'storage_backend',
    'frag_trait',
    'identity_resolver',
    'hashing_provider',
    'session_provider',
    'authentication_provider',
    'token_provider',
    'email_provider',
    'counter_provider',
    'http_request_handler',
    'http_response_handler',
    'http_authenticator',
    'http_app_provider',
    'http_endpoint',
    'version_root',
    'HTTPEndpointConfig',
    'decorator_provider',
    'cli_command',
    'root',

    # Managers
    'StorageManager',
    'FragTraitManager',
    'IdentityResolverManager',
    'StatusPrinterManager',
    'OutputRedirectManager',
    'HashingProviderManager',
    'SessionProviderManager',
    'AuthenticationProviderManager',
    'TokenProviderManager',
    'EmailProviderManager',
    'HTTPRequestHandlerManager',
    'HTTPResponseHandlerManager',
    'HTTPAuthenticatorManager',
    'HTTPAppProviderManager',
    'CounterProviderManager',

    # Lifecycle
    'LifecycleManager',
    'get_lifecycle_manager',
    'reset_lifecycle_manager',
    'LifecycleAware',

    # Protocols
    'StorageBackend',
    'ReadOnlyStorage',
    'FragTrait',
    'IdentityResolverProvider',

    # Discovery
    'discover_plugins',
]
