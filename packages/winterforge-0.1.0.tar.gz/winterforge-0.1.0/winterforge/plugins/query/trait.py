"""Trait filter plugin for query builder."""

from winterforge.plugins.decorators import query_builder, root


@query_builder()
@root('trait')
class TraitPlugin:
    """
    Filter by trait presence.

    Traits are capabilities or behaviors (titled, sluggable, persistable)
    that define what a Frag can do.

    Examples:
        # Single trait filter
        query.trait('titled')

        # Multiple traits (chained) - AND logic
        query.trait('titled').trait('sluggable')

        # Equivalent to:
        query.condition('traits', 'titled', QueryOperator.CONTAINS)
    """

    def __init__(self, trait: str):
        """
        Initialize trait filter.

        Args:
            trait: Trait ID to filter by
        """
        self.trait = trait

    def to_dict(self):
        """
        Convert to dict for storage execution.

        Returns:
            Dict with type and trait
        """
        return {
            'type': 'trait',
            'trait': self.trait
        }
