"""Orphaned filter plugin for query building."""

from winterforge.plugins.decorators import query_builder, root


@query_builder()
@root('orphaned')
class OrphanedPlugin:
    """
    Orphaned Frag filter.

    Filters by whether Frags have missing traits (orphaned).
    Applied after loading Frags (checks trait existence).

    Examples:
        # Find orphaned Frags
        orphaned = OrphanedPlugin(only_orphaned=True)

        # Find valid (non-orphaned) Frags
        valid = OrphanedPlugin(only_orphaned=False)
    """

    def __init__(self, only_orphaned: bool):
        """
        Initialize orphaned filter.

        Args:
            only_orphaned: True = only orphaned, False = only valid
        """
        self.only_orphaned = only_orphaned

    def to_dict(self) -> dict:
        """
        Serialize to dict for executor.

        Returns:
            Dict with type and only_orphaned flag

        Example:
            orphaned.to_dict()
            # {'type': 'orphaned', 'only_orphaned': True}
        """
        return {
            'type': 'orphaned',
            'only_orphaned': self.only_orphaned
        }
