"""Affinity filter plugin for query builder."""

from winterforge.plugins.decorators import query_builder, root


@query_builder()
@root('affinity')
class AffinityPlugin:
    """
    Filter by affinity tag.

    Affinities are domain classifications (user, post, comment, etc.)
    that categorize Frags by their purpose or role in the system.

    Examples:
        # Single affinity filter
        query.affinity('user')

        # Multiple affinities (chained)
        query.affinity('user').affinity('admin')

        # Equivalent to:
        query.condition('affinities', 'user', QueryOperator.CONTAINS)
    """

    def __init__(self, affinity: str):
        """
        Initialize affinity filter.

        Args:
            affinity: Affinity tag to filter by
        """
        self.affinity = affinity

    def to_dict(self):
        """
        Convert to dict for storage execution.

        Returns:
            Dict with type and affinity
        """
        return {
            'type': 'affinity',
            'affinity': self.affinity
        }
