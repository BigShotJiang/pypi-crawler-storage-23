"""Query builder plugin manager."""

from __future__ import annotations

from winterforge.plugins._base import ReorderablePluginManagerBase


class QueryBuilderManager(ReorderablePluginManagerBase):
    """
    Manages query builder plugins.

    Query builders provide composable query operations like conditions,
    sorting, filtering, and execution strategies.

    Example:
        from winterforge.query.manager import QueryBuilderManager
        condition_plugin = QueryBuilderManager.get('condition')
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return plugin manager identifier for query builders."""
        return 'winterforge.query_builders'
