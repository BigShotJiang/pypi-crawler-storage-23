"""Memory execution strategy - filters in-memory when data already loaded."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from winterforge.plugins.decorators import query_execution_strategy, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.plugins._protocols.query_execution import QueryContext


@query_execution_strategy()
@root('memory')
class MemoryExecutionStrategy:
    """
    Execute queries via in-memory filtering.

    When data is already loaded in a Manifest, filter in-memory
    instead of going back to the database.

    Can execute when:
    - Data source is a Manifest (data already loaded)
    - No joins (can't resolve relationships in-memory)
    - Simple conditions (equality, comparisons)

    Priority: Typically ordered second (after index, before storage)

    Example:
        # Query returns Manifest
        admins = await users.query().condition('admin', True).execute()
        # admins is Manifest with data loaded

        # Further filter
        active = await admins.query().condition('active', True).execute()
        # Memory strategy handles this (filters in-memory)
    """

    def can_execute(self, context: 'QueryContext') -> bool:
        """
        Check if can filter in-memory.

        Args:
            context: Query context

        Returns:
            True if data already loaded and query is simple

        Conditions:
            - Data source is Manifest
            - No joins (can't resolve in-memory)
        """
        from winterforge.frags.manifest import Manifest

        # Must have Manifest data source
        if not isinstance(context.data_source, Manifest):
            return False

        # Joins disqualify in-memory filtering
        if context.params.get('joins'):
            return False

        return True

    async def execute(self, context: 'QueryContext') -> List['Frag']:
        """
        Execute query via in-memory filtering.

        Args:
            context: Query context

        Returns:
            List of Frags filtered in-memory
        """
        # Start with all frags from Manifest
        frags = list(context.data_source)

        # Apply conditions
        for condition in context.params.get('conditions', []):
            frags = self._apply_condition(frags, condition)

        # Apply orphaned filter if present
        frags = self._apply_orphaned_filter(frags, context.plugins)

        # Apply sorting
        for sort in context.params.get('sort', []):
            frags = self._apply_sort(frags, sort)

        # Apply offset
        offset = context.params.get('offset')
        if offset:
            frags = frags[offset:]

        # Apply limit
        limit = context.params.get('limit')
        if limit:
            frags = frags[:limit]

        return frags

    def _apply_condition(
        self,
        frags: List['Frag'],
        condition: dict
    ) -> List['Frag']:
        """
        Apply single condition to frag list.

        Args:
            frags: List of Frags
            condition: Condition dict with field, value, operator

        Returns:
            Filtered list of Frags
        """
        field = condition['field']
        value = condition['value']
        operator = condition['operator']

        filtered = []

        for frag in frags:
            frag_value = getattr(frag, field, None)

            # Handle different operators
            if operator == '=':
                if frag_value == value:
                    filtered.append(frag)
            elif operator == '!=':
                if frag_value != value:
                    filtered.append(frag)
            elif operator == '>':
                if frag_value is not None and frag_value > value:
                    filtered.append(frag)
            elif operator == '>=':
                if frag_value is not None and frag_value >= value:
                    filtered.append(frag)
            elif operator == '<':
                if frag_value is not None and frag_value < value:
                    filtered.append(frag)
            elif operator == '<=':
                if frag_value is not None and frag_value <= value:
                    filtered.append(frag)
            elif operator == 'CONTAINS':
                # For JSON arrays (affinities, traits)
                if isinstance(frag_value, (list, tuple)):
                    if value in frag_value:
                        filtered.append(frag)
            elif operator == 'IN':
                # Check if frag value is in list
                if frag_value in value:
                    filtered.append(frag)

        return filtered

    def _apply_sort(
        self,
        frags: List['Frag'],
        sort: dict
    ) -> List['Frag']:
        """
        Apply sorting to frag list.

        Args:
            frags: List of Frags
            sort: Sort dict with field, direction

        Returns:
            Sorted list of Frags
        """
        field = sort['field']
        direction = sort.get('direction', 'ASC')

        reverse = (direction == 'DESC')

        return sorted(
            frags,
            key=lambda f: getattr(f, field, None) or '',
            reverse=reverse
        )

    def _apply_orphaned_filter(
        self,
        frags: List['Frag'],
        plugins: List
    ) -> List['Frag']:
        """
        Filter by orphaned status if plugin present.

        Args:
            frags: List of Frags to filter
            plugins: Plugin stack

        Returns:
            Filtered list of Frags
        """
        orphaned_plugin = next(
            (p for p in plugins if p.to_dict()['type'] == 'orphaned'),
            None
        )

        if not orphaned_plugin:
            return frags

        only_orphaned = orphaned_plugin.to_dict()['only_orphaned']

        if only_orphaned:
            return [f for f in frags if f.is_orphaned]
        else:
            return [f for f in frags if not f.is_orphaned]
