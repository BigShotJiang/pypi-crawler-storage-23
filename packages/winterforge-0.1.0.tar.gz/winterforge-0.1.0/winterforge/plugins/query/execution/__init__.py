"""Query execution strategy plugins."""

from ._manager import QueryExecutionStrategyManager

__all__ = ['QueryExecutionStrategyManager']
