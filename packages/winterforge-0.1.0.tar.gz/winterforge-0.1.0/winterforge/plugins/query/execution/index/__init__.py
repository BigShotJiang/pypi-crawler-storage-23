"""Index execution strategy - uses IndexManager for fast lookups."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from winterforge.plugins.decorators import query_execution_strategy, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.plugins._protocols.query_execution import QueryContext


@query_execution_strategy()
@root('index')
class IndexExecutionStrategy:
    """
    Execute queries using index optimization.

    Uses IndexManager to perform fast lookups when suitable
    indexes exist for the query conditions.

    Can execute when:
    - No joins in query (indexes don't support joins)
    - Simple equality conditions on indexed fields
    - IndexManager reports available index

    Priority: Typically ordered first (fastest when available)

    Example:
        # Query with indexed field
        query = QueryRepository().condition('slug', 'my-post')
        # Index strategy handles this (O(1) lookup)

        # Query with join
        query = QueryRepository().join('author_uuid', 'uuid')
        # Index strategy cannot handle (skipped)
    """

    def can_execute(self, context: 'QueryContext') -> bool:
        """
        Check if index optimization available.

        Args:
            context: Query context

        Returns:
            True if index can optimize this query

        Conditions:
            - No joins (indexes don't support joins)
            - IndexManager reports available optimizer
        """
        # Joins disqualify index
        if context.params.get('joins'):
            return False

        # Check if IndexManager has suitable index
        from winterforge.plugins.indexes._manager import IndexManager

        query_params = self._build_index_params(context)
        optimizer = IndexManager.query_optimization(query_params)

        return optimizer is not None

    async def execute(self, context: 'QueryContext') -> List['Frag']:
        """
        Execute query using index.

        Args:
            context: Query context

        Returns:
            List of Frags from index lookup
        """
        from winterforge.plugins.indexes._manager import IndexManager

        # Build params for index
        query_params = self._build_index_params(context)

        # Get optimizer
        optimizer = IndexManager.query_optimization(query_params)

        # Query index
        frag_ids = await optimizer.query(**query_params)

        # Load Frags
        frags = await self._load_frags(frag_ids, context.storage)

        # Apply orphaned filter if present
        frags = self._apply_orphaned_filter(frags, context.plugins)

        return frags

    def _build_index_params(self, context: 'QueryContext') -> dict:
        """
        Build parameters for index query.

        Args:
            context: Query context

        Returns:
            Query parameters dict
        """
        params = {}

        for condition in context.params.get('conditions', []):
            params[condition['field']] = condition['value']

        return params

    async def _load_frags(
        self,
        frag_ids: List[int],
        storage
    ) -> List['Frag']:
        """
        Load Frags from IDs.

        Args:
            frag_ids: List of Frag IDs
            storage: Storage backend

        Returns:
            List of loaded Frags
        """
        frags = []

        for frag_id in frag_ids:
            try:
                frag = await storage.load(frag_id)
                if frag:
                    frags.append(frag)
            except Exception:
                # Frag failed to load (orphaned?) - skip
                continue

        return frags

    def _apply_orphaned_filter(
        self,
        frags: List['Frag'],
        plugins: List
    ) -> List['Frag']:
        """
        Filter by orphaned status if plugin present.

        Args:
            frags: List of Frags to filter
            plugins: Plugin stack

        Returns:
            Filtered list of Frags
        """
        orphaned_plugin = next(
            (p for p in plugins if p.to_dict()['type'] == 'orphaned'),
            None
        )

        if not orphaned_plugin:
            return frags

        only_orphaned = orphaned_plugin.to_dict()['only_orphaned']

        if only_orphaned:
            return [f for f in frags if f.is_orphaned]
        else:
            return [f for f in frags if not f.is_orphaned]
