"""Query execution strategy manager."""

from __future__ import annotations

from winterforge.plugins._base import ReorderablePluginManagerBase


class QueryExecutionStrategyManager(ReorderablePluginManagerBase):
    """
    Manages query execution strategy plugins.

    Execution strategies determine HOW to execute queries:
    - Index optimization (fast lookups)
    - In-memory filtering (when data loaded)
    - Database queries (fallback)

    Strategies are tried in Repository order via resolve() until
    one can handle the query.

    Example:
        # Get strategy that can handle query
        strategies = QueryExecutionStrategyManager.repository()
        strategy = strategies.resolve(lambda s: s().can_execute(context))

        if strategy:
            frags = await strategy().execute(context)
        else:
            # Handle no strategy found
            frags = []

    Strategy Registration:
        @query_execution_strategy('index')
        class IndexExecutionStrategy:
            def can_execute(self, context) -> bool:
                return IndexManager.has_index(context.params)

            async def execute(self, context) -> List[Frag]:
                # Use index
                pass
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return plugin manager identifier."""
        return 'winterforge.query_execution_strategies'
