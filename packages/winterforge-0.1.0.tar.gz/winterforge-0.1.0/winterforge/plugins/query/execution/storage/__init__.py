"""Storage execution strategy - database queries (fallback)."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from winterforge.plugins.decorators import query_execution_strategy, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.plugins._protocols.query_execution import QueryContext


@query_execution_strategy()
@root('storage')
class StorageExecutionStrategy:
    """
    Execute queries via storage backend (database).

    Fallback strategy that always works. Translates query plugins
    into storage backend query format and executes via SQL/YAML/etc.

    Can execute: Always (fallback strategy)

    Priority: Typically ordered last (slowest, but always works)

    Example:
        # Complex query with joins
        query = QueryRepository()\\
            .condition('status', 'published')\\
            .join('author_uuid', 'uuid', alias='author')\\
            .condition('author.verified', True)

        # Storage strategy handles this (SQL joins)
    """

    def can_execute(self, context: 'QueryContext') -> bool:
        """
        Check if can execute via storage.

        Args:
            context: Query context

        Returns:
            True if storage is available, False otherwise

        Note:
            This is the fallback strategy, but it requires
            a configured storage backend to work.
        """
        return context.storage is not None

    async def execute(self, context: 'QueryContext') -> List['Frag']:
        """
        Execute query via storage backend.

        Args:
            context: Query context

        Returns:
            List of Frags from database query
        """
        # Translate plugins to storage backend query
        query_dict = self._translate_to_storage(context.plugins)

        # Execute query
        rows = await context.storage.execute(query_dict)

        # Extract IDs
        frag_ids = [row['id'] for row in rows]

        # Load Frags
        frags = await self._load_frags(frag_ids, context.storage)

        # Apply orphaned filter if present
        frags = self._apply_orphaned_filter(frags, context.plugins)

        return frags

    def _translate_to_storage(self, plugins: List) -> dict:
        """
        Translate plugins to storage backend format.

        Returns backend-agnostic query structure that storage
        backends can execute.

        Args:
            plugins: Plugin stack

        Returns:
            Query dict for storage backend
        """
        query = {
            'affinities': [],
            'traits': [],
            'conditions': [],
            'condition_groups': [],
            'joins': [],
            'sort': [],
            'limit': None,
            'offset': None
        }

        for plugin in plugins:
            plugin_dict = plugin.to_dict()
            ptype = plugin_dict['type']

            if ptype == 'affinity':
                query['affinities'].append(plugin_dict['affinity'])
            elif ptype == 'trait':
                query['traits'].append(plugin_dict['trait'])
            elif ptype == 'condition':
                query['conditions'].append(plugin_dict)
            elif ptype == 'condition_group':
                query['condition_groups'].append(plugin_dict)
            elif ptype == 'join':
                query['joins'].append(plugin_dict)
            elif ptype == 'sort':
                query['sort'].append(plugin_dict)
            elif ptype == 'limit':
                query['limit'] = plugin_dict['limit']
            elif ptype == 'offset':
                query['offset'] = plugin_dict['offset']

        return query

    async def _load_frags(
        self,
        frag_ids: List[int],
        storage
    ) -> List['Frag']:
        """
        Load Frags from IDs.

        Args:
            frag_ids: List of Frag IDs
            storage: Storage backend

        Returns:
            List of loaded Frags
        """
        frags = []

        for frag_id in frag_ids:
            try:
                frag = await storage.load(frag_id)
                if frag:
                    frags.append(frag)
            except Exception:
                # Frag failed to load (orphaned?) - skip
                continue

        return frags

    def _apply_orphaned_filter(
        self,
        frags: List['Frag'],
        plugins: List
    ) -> List['Frag']:
        """
        Filter by orphaned status if plugin present.

        Args:
            frags: List of Frags to filter
            plugins: Plugin stack

        Returns:
            Filtered list of Frags
        """
        orphaned_plugin = next(
            (p for p in plugins if p.to_dict()['type'] == 'orphaned'),
            None
        )

        if not orphaned_plugin:
            return frags

        only_orphaned = orphaned_plugin.to_dict()['only_orphaned']

        if only_orphaned:
            return [f for f in frags if f.is_orphaned]
        else:
            return [f for f in frags if not f.is_orphaned]
