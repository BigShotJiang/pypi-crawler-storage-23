"""Query repository - immutable fluent interface."""

from typing import List, Optional, Any, Union, TYPE_CHECKING
from ._operators import QueryOperator
from winterforge.plugins.decorators import query_builder, root

if TYPE_CHECKING:
    from winterforge.plugins.repository import RepositoryBase
    from winterforge.frags.base import Frag


@query_builder()
@root('repository')
class QueryRepository:
    """
    Immutable query repository.

    Each operation returns a new QueryRepository with plugin appended.
    Uses Repository pattern internally for plugin stack.

    Key principle: Immutability - every method returns NEW instance.

    Examples:
        # Each operation returns new instance
        query = QueryRepository()
        query2 = query.condition('title', 'Hello', QueryOperator.EQUALS)
        query3 = query2.sort('created_at', 'DESC')
        results = await query3.execute()

        # Or chained (more common)
        results = await (QueryRepository()
            .condition('affinities', 'blog-post', QueryOperator.CONTAINS)
            .sort('created_at', 'DESC')
            .limit(10)
            .execute()
        )

        # Unconditional queries return all Frags
        results = await QueryRepository().execute()
        # Returns: Manifest with all Frags from storage
    """

    def __init__(
        self,
        plugins: Optional[List[Any]] = None,
        storage: Optional[Any] = None
    ):
        """
        Initialize query repository.

        Args:
            plugins: Internal plugin list (None creates empty)
            storage: Storage backend (None uses default)
        """
        self._plugins = plugins or []
        self._storage = storage
        self._data_source = None  # Set by Manifest.query()

    # ========== Conditions ==========

    def condition(
        self,
        field: str,
        value: Any,
        operator: QueryOperator = QueryOperator.EQUALS
    ) -> 'QueryRepository':
        """
        Add condition (returns new instance).

        Args:
            field: Field name
            value: Comparison value
            operator: QueryOperator enum

        Returns:
            New QueryRepository with condition appended

        Examples:
            query.condition('title', 'Hello', QueryOperator.EQUALS)
            query.condition('affinities', 'blog-post', QueryOperator.CONTAINS)
            query.condition('created_at', datetime.now(), QueryOperator.GREATER_THAN)
        """
        from winterforge.plugins.query.condition import ConditionPlugin

        condition = ConditionPlugin(field, value, operator)
        new_plugins = self._plugins + [condition]

        new_repo = QueryRepository(new_plugins, self._storage)
        new_repo._data_source = self._data_source
        return new_repo

    def and_group(self):
        """
        Create AND condition group.

        Returns:
            Condition group plugin (append to query via .end())

        Example:
            query = (QueryRepository()
                .and_group()
                    .condition('status', 'published')
                    .condition('featured', True)
                .end()
                .execute()
            )
        """
        from winterforge.plugins.query.condition_group import ConditionGroupPlugin

        return ConditionGroupPlugin(self, 'AND')

    def or_group(self):
        """
        Create OR condition group.

        Returns:
            Condition group plugin

        Example:
            query = (QueryRepository()
                .or_group()
                    .condition('status', 'published')
                    .condition('author_id', 123)
                .end()
                .execute()
            )
        """
        from winterforge.plugins.query.condition_group import ConditionGroupPlugin

        return ConditionGroupPlugin(self, 'OR')

    # ========== Affinities and Traits ==========

    def affinity(self, name: Union[str, 'Frag']) -> 'QueryRepository':
        """
        Filter by affinity tag (returns new instance).

        Convenience method for affinity filtering. More readable
        than using condition() with CONTAINS operator.

        Args:
            name: Affinity tag (string) or Affinity Frag

        Returns:
            New QueryRepository with affinity filter appended

        Examples:
            # String (traditional)
            query.affinity('user')

            # Frag (after materialization)
            user_affinity = Affinity(name='user')
            query.affinity(user_affinity)  # Auto-converts via __str__()

            # Multiple affinities (AND logic)
            query.affinity('user').affinity('admin')

            # Equivalent to:
            query.condition('affinities', 'user', QueryOperator.CONTAINS)
        """
        from winterforge.plugins.query.affinity import AffinityPlugin

        # Convert Frag to string via __str__() (returns primitive_id)
        affinity_str = str(name) if not isinstance(name, str) else name

        plugin = AffinityPlugin(affinity_str)
        new_plugins = self._plugins + [plugin]

        new_repo = QueryRepository(new_plugins, self._storage)
        new_repo._data_source = self._data_source
        return new_repo

    def trait(self, name: Union[str, 'Frag']) -> 'QueryRepository':
        """
        Filter by trait presence (returns new instance).

        Convenience method for trait filtering. More readable
        than using condition() with CONTAINS operator.

        Args:
            name: Trait ID (string) or Trait Frag

        Returns:
            New QueryRepository with trait filter appended

        Examples:
            # String (traditional)
            query.trait('titled')

            # Frag (after materialization)
            titled_trait = Trait(name='titled')
            query.trait(titled_trait)  # Auto-converts via __str__()

            # Multiple traits (AND logic)
            query.trait('titled').trait('sluggable')

            # Equivalent to:
            query.condition('traits', 'titled', QueryOperator.CONTAINS)
        """
        from winterforge.plugins.query.trait import TraitPlugin

        # Convert Frag to string via __str__() (returns primitive_id)
        trait_str = str(name) if not isinstance(name, str) else name

        plugin = TraitPlugin(trait_str)
        new_plugins = self._plugins + [plugin]

        new_repo = QueryRepository(new_plugins, self._storage)
        new_repo._data_source = self._data_source
        return new_repo

    # ========== Joins ==========

    def join(
        self,
        left_field: str,
        right_field: str = 'uuid',
        alias: Optional[str] = None,
        type: str = 'INNER'
    ) -> 'QueryRepository':
        """
        Add join (returns new instance).

        Args:
            left_field: Field containing Frag UUID reference
            right_field: Field to join on (usually 'uuid')
            alias: Alias for joined Frags
            type: Join type (INNER, LEFT, RIGHT)

        Returns:
            New QueryRepository with join appended

        Example:
            query.join('author_uuid', 'uuid', alias='author')
            query.condition('author.name', 'Alice')
        """
        from winterforge.plugins.query.join import JoinPlugin

        join = JoinPlugin(left_field, right_field, alias, type)
        new_plugins = self._plugins + [join]

        new_repo = QueryRepository(new_plugins, self._storage)
        new_repo._data_source = self._data_source
        return new_repo

    # ========== Sorting ==========

    def sort(
        self,
        field: str,
        direction: str = 'ASC'
    ) -> 'QueryRepository':
        """
        Add sort (returns new instance).

        Args:
            field: Field to sort by
            direction: ASC or DESC

        Returns:
            New QueryRepository with sort appended

        Example:
            query.sort('created_at', 'DESC')
        """
        from winterforge.plugins.query.sort import SortPlugin

        sort = SortPlugin(field, direction)
        new_plugins = self._plugins + [sort]

        new_repo = QueryRepository(new_plugins, self._storage)
        new_repo._data_source = self._data_source
        return new_repo

    # ========== Paging ==========

    def limit(self, limit: int) -> 'QueryRepository':
        """
        Set limit (returns new instance).

        Args:
            limit: Max results

        Returns:
            New QueryRepository

        Example:
            query.limit(10)
        """
        from winterforge.plugins.query.limit import LimitPlugin

        limit_plugin = LimitPlugin(limit)
        new_plugins = self._plugins + [limit_plugin]

        new_repo = QueryRepository(new_plugins, self._storage)
        new_repo._data_source = self._data_source
        return new_repo

    def offset(self, offset: int) -> 'QueryRepository':
        """
        Set offset (returns new instance).

        Args:
            offset: Number to skip

        Returns:
            New QueryRepository

        Example:
            query.offset(20)
        """
        from winterforge.plugins.query.offset import OffsetPlugin

        offset_plugin = OffsetPlugin(offset)
        new_plugins = self._plugins + [offset_plugin]

        new_repo = QueryRepository(new_plugins, self._storage)
        new_repo._data_source = self._data_source
        return new_repo

    def range(self, start: int, length: int) -> 'QueryRepository':
        """
        Set range (returns new instance).

        Convenience method for offset + limit.

        Args:
            start: Offset
            length: Limit

        Returns:
            New QueryRepository

        Example:
            query.range(20, 10)  # Skip 20, take 10
        """
        return self.offset(start).limit(length)

    # ========== Orphaned ==========

    def orphaned(self, only_orphaned: bool = True) -> 'QueryRepository':
        """
        Filter by orphaned status (returns new instance).

        Orphaned Frags have traits that don't exist (extension uninstalled).

        Args:
            only_orphaned: True = only orphaned, False = only valid

        Returns:
            New QueryRepository

        Example:
            # Find orphaned Frags
            query.orphaned(True)

            # Find valid Frags only
            query.orphaned(False)
        """
        from winterforge.plugins.query.orphaned import OrphanedPlugin

        orphaned_plugin = OrphanedPlugin(only_orphaned)
        new_plugins = self._plugins + [orphaned_plugin]

        new_repo = QueryRepository(new_plugins, self._storage)
        new_repo._data_source = self._data_source
        return new_repo

    # ========== Storage Management ==========

    def setDatasource(self, storage: 'StorageBackend') -> 'QueryRepository':
        """
        Set storage backend (returns new instance).

        Args:
            storage: Storage backend to use

        Returns:
            New QueryRepository with storage configured

        Example:
            query = query.setDatasource(my_storage)
        """
        new_repo = QueryRepository(self._plugins, storage)
        new_repo._data_source = self._data_source
        return new_repo

    def getDatasource(self) -> Optional['StorageBackend']:
        """
        Get current storage backend.

        Returns:
            Storage backend or None

        Example:
            storage = query.getDatasource()
        """
        return self._storage

    # ========== Execution ==========

    async def execute(self) -> 'Manifest':
        """
        Execute query and return Manifest.

        Returns:
            Manifest of matching Frags (all Frags if no conditions)

        Example:
            manifest = await query.execute()
            for frag in manifest:
                print(frag.title)
        """
        # Import here to avoid circular dependency
        from winterforge.frags.manifest import Manifest
        from winterforge.plugins.query.executor import ExecutorPlugin

        # Empty query executes unconditionally (returns ALL Frags)
        # This is correct SQL behavior: SELECT * FROM frags (no WHERE clause)
        executor = ExecutorPlugin(
            self._plugins,
            data_source=self._data_source,
            storage=self._storage
        )
        frags = await executor.execute()

        return Manifest(frags, storage=self._storage)

    async def count(self) -> int:
        """
        Count results without loading Frags.

        Returns:
            Number of matching Frags (all Frags if no conditions)

        Example:
            total = await query.count()
        """
        from winterforge.plugins.query.executor import ExecutorPlugin

        executor = ExecutorPlugin(
            self._plugins,
            data_source=self._data_source,
            storage=self._storage
        )
        return await executor.count()

    async def ids(self) -> List[int]:
        """
        Get Frag IDs without loading Frags.

        Returns:
            List of Frag IDs (all IDs if no conditions)

        Example:
            frag_ids = await query.ids()
        """
        from winterforge.plugins.query.executor import ExecutorPlugin

        executor = ExecutorPlugin(
            self._plugins,
            data_source=self._data_source,
            storage=self._storage
        )
        return await executor.ids()

    async def uuids(self) -> List[str]:
        """
        Get Frag UUIDs without loading Frags.

        Returns:
            List of UUID strings (all UUIDs if no conditions)

        Example:
            uuids = await query.uuids()
        """
        from winterforge.plugins.query.executor import ExecutorPlugin

        executor = ExecutorPlugin(
            self._plugins,
            data_source=self._data_source,
            storage=self._storage
        )
        return await executor.uuids()

    async def first(self) -> Optional['Frag']:
        """
        Get first result.

        Returns:
            First Frag or None if no results

        Example:
            first_post = await query.first()
        """
        results = await self.limit(1).execute()
        return results[0] if results else None

    async def exists(self) -> bool:
        """
        Check if any results exist.

        Returns:
            True if at least one result

        Example:
            has_posts = await query.exists()
        """
        count = await self.count()
        return count > 0
