"""Offset plugin for query building."""

from winterforge.plugins.decorators import query_builder, root


@query_builder()
@root('offset')
class OffsetPlugin:
    """
    Offset specification.

    Skips a number of results (for pagination).

    Examples:
        # Skip first 20 results
        offset = OffsetPlugin(20)

        # Page 3 (with limit=10)
        offset = OffsetPlugin(20)  # Skip 20 (page 1 & 2)
    """

    def __init__(self, offset: int):
        """
        Initialize offset.

        Args:
            offset: Number of results to skip
        """
        self.offset = offset

    def to_dict(self) -> dict:
        """
        Serialize to dict for executor.

        Returns:
            Dict with type and offset

        Example:
            offset.to_dict()
            # {'type': 'offset', 'offset': 20}
        """
        return {
            'type': 'offset',
            'offset': self.offset
        }
