"""Query system for WinterForge.

Plugin-based query builder with immutable repository pattern.
"""

from winterforge.plugins.query._operators import QueryOperator
from winterforge.plugins.query._manager import QueryBuilderManager

__all__ = ['QueryOperator', 'QueryBuilderManager']
