"""Join plugin for query building."""

from typing import Optional
from winterforge.plugins.decorators import query_builder, root


@query_builder()
@root('join')
class JoinPlugin:
    """
    Frag join specification.

    Joins on Frag reference fields (e.g., author_uuid → Frag.uuid).
    Enables querying across Frag relationships.

    Examples:
        # Join on author UUID
        join = JoinPlugin('author_uuid', 'uuid', alias='author')

        # Inner join (default)
        join = JoinPlugin('category_uuid', 'uuid', alias='category', type='INNER')

        # Left join (include posts without category)
        join = JoinPlugin('category_uuid', 'uuid', alias='category', type='LEFT')
    """

    def __init__(
        self,
        left_field: str,
        right_field: str,
        alias: Optional[str] = None,
        type: str = 'INNER'
    ):
        """
        Initialize join specification.

        Args:
            left_field: Field containing UUID reference
            right_field: Field to join on (usually 'uuid')
            alias: Alias for joined Frags
            type: Join type (INNER, LEFT, RIGHT)
        """
        self.left_field = left_field
        self.right_field = right_field
        self.alias = alias
        self.type = type.upper()

    def to_dict(self) -> dict:
        """
        Serialize to dict for executor.

        Returns:
            Dict with type, fields, alias, join_type

        Example:
            join.to_dict()
            # {
            #     'type': 'join',
            #     'left_field': 'author_uuid',
            #     'right_field': 'uuid',
            #     'alias': 'author',
            #     'join_type': 'INNER'
            # }
        """
        return {
            'type': 'join',
            'left_field': self.left_field,
            'right_field': self.right_field,
            'alias': self.alias,
            'join_type': self.type
        }
