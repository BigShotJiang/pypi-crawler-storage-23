"""Composition filter plugin for query builder."""

from winterforge.plugins.decorators import query_builder, root
from winterforge.frags.composition import Composition


@query_builder()
@root('composition')
class CompositionPlugin:
    """
    Filter by composition pattern (affinities + traits).

    Composition defines what a Frag IS (identity) and what it CAN DO
    (capability). This plugin filters for Frags matching a composition
    pattern.

    Matching uses subset logic:
    - Frag must have ALL required affinities
    - Frag must have ALL required traits
    - Frag can have additional affinities/traits

    Examples:
        # Filter for config Frags
        query.composition(Composition(affinities=('config',)))

        # Filter for injectable, persistable configs
        query.composition(
            Composition(
                affinities=('config',),
                traits=('injectable', 'persistable')
            )
        )

        # Equivalent to combining individual filters:
        query.affinity('config').trait('injectable').trait('persistable')
    """

    def __init__(self, composition: Composition):
        """
        Initialize composition filter.

        Args:
            composition: Composition pattern to match
        """
        self.composition = composition

    def to_dict(self):
        """
        Convert to dict for storage execution.

        Returns:
            Dict with type and composition data
        """
        return {
            'type': 'composition',
            'composition': self.composition.to_dict()
        }
