"""Sort plugin for query building."""

from winterforge.plugins.decorators import query_builder, root


@query_builder()
@root('sort')
class SortPlugin:
    """
    Sort specification.

    Defines field and direction for ordering results.

    Examples:
        # Ascending
        sort = SortPlugin('title', 'ASC')

        # Descending (most recent first)
        sort = SortPlugin('created_at', 'DESC')
    """

    def __init__(self, field: str, direction: str):
        """
        Initialize sort specification.

        Args:
            field: Field to sort by
            direction: 'ASC' or 'DESC'
        """
        self.field = field
        self.direction = direction.upper()

    def to_dict(self) -> dict:
        """
        Serialize to dict for executor.

        Returns:
            Dict with type, field, direction

        Example:
            sort.to_dict()
            # {
            #     'type': 'sort',
            #     'field': 'created_at',
            #     'direction': 'DESC'
            # }
        """
        return {
            'type': 'sort',
            'field': self.field,
            'direction': self.direction
        }
