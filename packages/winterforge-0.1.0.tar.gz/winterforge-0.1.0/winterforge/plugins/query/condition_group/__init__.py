"""Condition group plugin for query building."""

from typing import Literal, List, TYPE_CHECKING
from winterforge.plugins.decorators import query_builder, root
from .._operators import QueryOperator

if TYPE_CHECKING:
    from .._repository import QueryRepository


@query_builder()
@root('condition-group')
class ConditionGroupPlugin:
    """
    Condition group (AND/OR).

    Builder pattern - collects conditions, then appends to parent query.
    Enables complex boolean logic in queries.

    Examples:
        # (status = 'published' OR featured = True)
        group = ConditionGroupPlugin(parent_query, 'OR')
        group.condition('status', 'published')
        group.condition('featured', True)
        query = group.end()  # Returns parent with group appended

        # Via QueryRepository (more common)
        query = (QueryRepository()
            .or_group()
                .condition('status', 'published')
                .condition('featured', True)
            .end()
            .execute()
        )
    """

    def __init__(
        self,
        parent: 'QueryRepository',
        conjunction: Literal['AND', 'OR']
    ):
        """
        Initialize condition group.

        Args:
            parent: Parent QueryRepository
            conjunction: 'AND' or 'OR'
        """
        self._parent = parent
        self.conjunction = conjunction
        self.conditions: List = []

    def condition(
        self,
        field: str,
        value,
        operator: QueryOperator = QueryOperator.EQUALS
    ) -> 'ConditionGroupPlugin':
        """
        Add condition to group.

        Args:
            field: Field name
            value: Comparison value
            operator: QueryOperator enum

        Returns:
            Self (for chaining within group)

        Example:
            group.condition('status', 'published')
                 .condition('featured', True)
        """
        from ..condition import ConditionPlugin

        condition = ConditionPlugin(field, value, operator)
        self.conditions.append(condition)
        return self

    def end(self) -> 'QueryRepository':
        """
        End group, return parent query.

        Appends group to parent as plugin.

        Returns:
            Parent QueryRepository with group appended

        Example:
            query = group.end()  # Returns to parent
            results = await query.execute()
        """
        new_plugins = self._parent._plugins + [self]
        return self._parent.__class__(new_plugins)

    def to_dict(self) -> dict:
        """
        Serialize to dict for executor.

        Returns:
            Dict with type, conjunction, conditions

        Example:
            group.to_dict()
            # {
            #     'type': 'condition_group',
            #     'conjunction': 'OR',
            #     'conditions': [
            #         {'type': 'condition', 'field': 'status', ...},
            #         {'type': 'condition', 'field': 'featured', ...}
            #     ]
            # }
        """
        return {
            'type': 'condition_group',
            'conjunction': self.conjunction,
            'conditions': [c.to_dict() for c in self.conditions]
        }
