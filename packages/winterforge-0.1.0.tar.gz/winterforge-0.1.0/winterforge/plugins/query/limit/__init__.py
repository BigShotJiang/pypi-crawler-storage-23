"""Limit plugin for query building."""

from winterforge.plugins.decorators import query_builder, root


@query_builder()
@root('limit')
class LimitPlugin:
    """
    Limit specification.

    Restricts number of results returned.

    Examples:
        # First 10 results
        limit = LimitPlugin(10)

        # Single result
        limit = LimitPlugin(1)
    """

    def __init__(self, limit: int):
        """
        Initialize limit.

        Args:
            limit: Maximum number of results
        """
        self.limit = limit

    def to_dict(self) -> dict:
        """
        Serialize to dict for executor.

        Returns:
            Dict with type and limit

        Example:
            limit.to_dict()
            # {'type': 'limit', 'limit': 10}
        """
        return {
            'type': 'limit',
            'limit': self.limit
        }
