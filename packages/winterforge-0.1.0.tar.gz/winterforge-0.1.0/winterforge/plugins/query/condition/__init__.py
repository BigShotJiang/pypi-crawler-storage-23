"""Condition plugin for query building."""

from winterforge.plugins.decorators import query_builder, root
from .._operators import QueryOperator


@query_builder()
@root('condition')
class ConditionPlugin:
    """
    Single field condition.

    Immutable plugin representing a field comparison.
    Used by QueryRepository to build queries.

    Examples:
        # Equality
        condition = ConditionPlugin('title', 'Hello', QueryOperator.EQUALS)

        # Affinity check
        condition = ConditionPlugin(
            'affinities',
            'blog-post',
            QueryOperator.CONTAINS
        )

        # Range comparison
        condition = ConditionPlugin('age', 18, QueryOperator.GREATER_THAN)
    """

    def __init__(self, field: str, value, operator: QueryOperator):
        """
        Initialize condition.

        Args:
            field: Field name to compare
            value: Comparison value
            operator: QueryOperator enum
        """
        self.field = field
        self.value = value
        self.operator = operator

    def to_dict(self) -> dict:
        """
        Serialize to dict for executor.

        Returns:
            Dict with type, field, value, operator

        Example:
            condition.to_dict()
            # {
            #     'type': 'condition',
            #     'field': 'title',
            #     'value': 'Hello',
            #     'operator': '='
            # }
        """
        return {
            'type': 'condition',
            'field': self.field,
            'value': self.value,
            'operator': self.operator.value
        }
