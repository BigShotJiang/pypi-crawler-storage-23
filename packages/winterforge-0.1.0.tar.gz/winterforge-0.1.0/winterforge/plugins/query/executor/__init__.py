"""Query executor plugin."""

from typing import List, Optional, TYPE_CHECKING
from winterforge.plugins.decorators import query_builder, root

if TYPE_CHECKING:
    from winterforge.plugins.repository import RepositoryBase
    from winterforge.frags.base import Frag


@query_builder()
@root('executor')
class ExecutorPlugin:
    """
    Execute query using execution strategy plugins.

    Uses resolve() pattern to find suitable execution strategy:
    1. Index optimization (fast lookups)
    2. In-memory filtering (when data already loaded)
    3. Storage backend query (fallback)

    Strategies tried in Repository order until one can handle query.

    Supports multiple output formats:
    - execute() - Full Frags
    - count() - Result count
    - ids() - Frag IDs only
    - uuids() - UUIDs only

    Examples:
        # Via QueryRepository (typical usage)
        results = await QueryRepository().condition('title', 'Hello').execute()

        # Count without loading
        count = await QueryRepository().condition('status', 'published').count()

        # IDs only
        ids = await QueryRepository().condition('affinities', 'post').ids()
    """

    def __init__(self, plugins: List, data_source=None, storage=None):
        """
        Initialize executor.

        Args:
            plugins: List of query plugins
            data_source: Optional Manifest or other data source
            storage: Storage backend (uses default if None)
        """
        self.plugins = plugins
        self.data_source = data_source

        # Use provided storage or fall back to global default
        if storage is None:
            from winterforge.frags.traits.persistable import get_storage
            storage = get_storage()

        self.storage = storage

    async def execute(self) -> List['Frag']:
        """
        Execute query using strategy plugins.

        Uses resolve() to find first strategy that can handle query.
        Strategies tried in Repository order (typically: index, memory, storage).

        Returns:
            List of Frags matching query

        Example:
            # Index strategy handles if suitable index exists
            # Memory strategy handles if data in Manifest
            # Storage strategy handles as fallback
        """
        from ..execution._manager import (
            QueryExecutionStrategyManager
        )
        from winterforge.plugins._protocols.query_execution import QueryContext

        # Build context
        context = QueryContext(
            plugins=self.plugins,
            data_source=self.data_source,
            storage=self.storage
        )

        # Get strategies and find one that can execute
        strategies = QueryExecutionStrategyManager.repository()

        # Use resolve() to find first strategy that can handle query
        strategy_class = strategies.resolve(
            lambda s: s().can_execute(context)
        )

        if strategy_class:
            # Instantiate and execute
            strategy = strategy_class()
            return await strategy.execute(context)

        # No strategy found - return empty list
        # (User is responsible for ensuring strategies registered)
        return []

    async def count(self) -> int:
        """
        Count results without loading Frags.

        Returns:
            Number of matching Frags
        """
        # Execute and count
        frags = await self.execute()
        return len(frags)

    async def ids(self) -> List[int]:
        """
        Get Frag IDs without loading Frags.

        Returns:
            List of Frag IDs
        """
        # Execute and extract IDs
        frags = await self.execute()
        return [f.id for f in frags]

    async def uuids(self) -> List[str]:
        """
        Get UUIDs without loading Frags.

        Returns:
            List of UUID strings
        """
        # Execute and extract UUIDs
        frags = await self.execute()
        return [f.uuid for f in frags]
