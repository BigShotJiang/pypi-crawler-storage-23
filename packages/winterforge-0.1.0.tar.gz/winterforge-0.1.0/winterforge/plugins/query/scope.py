"""Scope filter plugin for query builder."""

from winterforge.plugins.decorators import query_builder, root
from winterforge.frags.scope import Scope


@query_builder()
@root('scope')
class ScopePlugin:
    """
    Filter by scope (composition + categorical membership).

    Scope defines the complete matching pattern:
    - Composition: What a Frag IS (affinities + traits)
    - Aliases: What it BELONGS TO (categorical membership)

    Scope matching combines compositional and categorical constraints:
    - Composition uses subset matching (Frag must have ALL required)
    - Aliases support multiple constraint types:
      - Exact values: {'environment': 'production'}
      - Key existence: {'publication_id': ...}
      - Value sets: {'role': ['admin', 'moderator']}
      - Predicates: {'id': lambda v: int(v) > 100}

    Examples:
        # Production database configs
        query.scope(Scope(
            composition=Composition(affinities=('config',)),
            aliases={'environment': 'production', 'service': 'database'}
        ))

        # Articles in publication range
        query.scope(Scope(
            composition=Composition(affinities=('article',)),
            aliases={'publication_id': lambda v: 92 <= int(v) <= 204}
        ))

        # Any post with external_id
        query.scope(Scope(
            composition=Composition(affinities=('post',)),
            aliases={'external_id': ...}
        ))

        # Users with elevated roles
        query.scope(Scope(
            composition=Composition(affinities=('user',)),
            aliases={'role': ['admin', 'moderator']}
        ))
    """

    def __init__(self, scope: Scope):
        """
        Initialize scope filter.

        Args:
            scope: Scope pattern to match
        """
        self.scope = scope

    def to_dict(self):
        """
        Convert to dict for storage execution.

        Note: Callable alias predicates cannot be serialized and will
        require in-memory filtering.

        Returns:
            Dict with type and scope data
        """
        return {
            'type': 'scope',
            'scope': self.scope.to_dict()
        }
