"""Query operators enum."""

from enum import Enum


class QueryOperator(Enum):
    """
    Query comparison operators.

    Standard SQL-style operators for conditions.
    Type-safe alternative to string operators.

    Examples:
        query.condition('title', 'Hello', QueryOperator.EQUALS)
        query.condition('age', 18, QueryOperator.GREATER_THAN)
        query.condition('affinities', 'blog-post', QueryOperator.CONTAINS)
    """

    # Equality
    EQUALS = '='
    NOT_EQUALS = '!='

    # Comparison
    LESS_THAN = '<'
    LESS_THAN_OR_EQUAL = '<='
    GREATER_THAN = '>'
    GREATER_THAN_OR_EQUAL = '>='

    # Pattern matching
    LIKE = 'LIKE'
    NOT_LIKE = 'NOT LIKE'
    ILIKE = 'ILIKE'  # Case-insensitive

    # Membership
    IN = 'IN'
    NOT_IN = 'NOT IN'

    # JSONB operations (for affinities/traits arrays)
    CONTAINS = 'CONTAINS'
    CONTAINED_BY = 'CONTAINED_BY'
    HAS_KEY = 'HAS_KEY'

    # Null checks
    IS_NULL = 'IS NULL'
    IS_NOT_NULL = 'IS NOT NULL'

    # Range
    BETWEEN = 'BETWEEN'

    def __str__(self):
        """Return operator value for SQL generation."""
        return self.value
