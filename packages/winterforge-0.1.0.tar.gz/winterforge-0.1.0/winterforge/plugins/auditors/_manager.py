"""Field auditor plugin manager."""

from __future__ import annotations

from winterforge.plugins._base import ReorderablePluginManagerBase


class FieldAuditorManager(ReorderablePluginManagerBase):
    """
    Manages field auditor plugins.

    Field auditors analyze database schema and detect orphaned fields,
    unused columns, and provide cleanup strategies with safety controls.

    Example:
        from winterforge.auditors.manager import FieldAuditorManager
        auditor = FieldAuditorManager.get('orphaned_fields')
        orphaned = await auditor.audit()
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return plugin manager identifier for field auditors."""
        return 'winterforge.field_auditors'
