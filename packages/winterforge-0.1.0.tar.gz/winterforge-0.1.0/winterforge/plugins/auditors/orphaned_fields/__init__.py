"""Orphaned field auditor."""

from typing import Dict, List, Optional, TYPE_CHECKING
from winterforge.plugins.decorators import field_auditor, root

if TYPE_CHECKING:
    from winterforge.plugins._protocols.storage import StorageBackend


@field_auditor()
@root('orphaned-fields')
class OrphanedFieldAuditor:
    """
    Audit orphaned fields.

    Finds database columns with no corresponding trait code.
    Uses column name provenance ({trait_id}__{field_name}) for organization.

    Key Features:
    - Automatic discovery (no manual tracking)
    - Package-level organization
    - Safe cleanup mode (only empty columns)
    - Destructive cleanup option (with data)

    Examples:
        auditor = OrphanedFieldAuditor()

        # Find orphaned fields
        orphaned = await auditor.audit()
        # {
        #     'winterforge_blog.blog_post': [
        #         {'field': 'published_date', 'column': '...', 'rows': 1247},
        #         {'field': 'author_id', 'column': '...', 'rows': 1247}
        #     ]
        # }

        # Cleanup safe (only empty fields)
        result = await auditor.cleanup_fields(safe_mode=True)
        # {'dropped': [], 'skipped': [('published_date', 1247)]}

        # Cleanup destructive (all fields from package)
        result = await auditor.cleanup_fields(
            package='winterforge_blog',
            safe_mode=False
        )
        # {'dropped': ['published_date', 'author_id'], 'skipped': []}
    """

    async def audit(self) -> Dict[str, List[dict]]:
        """
        Find orphaned fields.

        Returns:
            Dict organized by package.trait:
            {
                'winterforge_blog.blog_post': [
                    {'field': 'published_date', 'column': '...', 'rows': 1247},
                    ...
                ],
                ...
            }

        Example:
            auditor = OrphanedFieldAuditor()
            orphaned = await auditor.audit()

            # Print report
            for key, fields in orphaned.items():
                print(f"\n{key}:")
                for field_info in fields:
                    print(f"  - {field_info['field']} ({field_info['rows']} rows)")
        """
        from winterforge.plugins.storage.manager import StorageManager
        from winterforge.plugins import FragTraitManager

        storage = StorageManager.get('sqlite')

        # Get all columns from DB
        columns = await storage.get_table_columns('frags')

        orphaned = {}

        for col_name in columns:
            # Skip base columns
            if col_name in ['id', 'uuid', 'affinities', 'traits', 'aliases']:
                continue

            # Parse: winterforge_blog__blog_post__published_date
            # Format: {package}__{trait_id}__{field_name}
            parts = col_name.split('__')
            if len(parts) < 3:
                continue  # Not a trait field

            # Extract components
            # Note: Package and trait might have underscores, field might too
            # So we take first part as package, second as trait, rest as field
            package = parts[0]
            trait_id = parts[1]
            field_name = '__'.join(parts[2:])  # Rejoin in case field has __

            # Check if trait exists
            if not FragTraitManager.has(trait_id):
                # Trait missing - orphaned!
                key = f"{package}.{trait_id}"
                if key not in orphaned:
                    orphaned[key] = []

                # Get row count (how many Frags use this field)
                row_count = await storage.count_column_usage(col_name)

                orphaned[key].append({
                    'field': field_name,
                    'column': col_name,
                    'rows': row_count
                })

        return orphaned

    async def cleanup_fields(
        self,
        package: Optional[str] = None,
        safe_mode: bool = True
    ) -> dict:
        """
        Drop orphaned fields.

        Args:
            package: Only drop fields from this package (None = all)
            safe_mode: Only drop fields with no data (True = safe)

        Returns:
            Dict with dropped/skipped counts

        Example:
            # Safe cleanup (only empty fields)
            result = await auditor.cleanup_fields(safe_mode=True)
            # {'dropped': ['unused_field'], 'skipped': [('has_data', 1247)]}

            # Package-specific cleanup
            result = await auditor.cleanup_fields(
                package='winterforge_blog',
                safe_mode=True
            )

            # Destructive cleanup (careful!)
            result = await auditor.cleanup_fields(
                package='winterforge_blog',
                safe_mode=False
            )
        """
        from winterforge.plugins.storage.manager import StorageManager

        storage = StorageManager.get('sqlite')
        orphaned = await self.audit()

        dropped = []
        skipped = []

        for key, fields in orphaned.items():
            pkg, trait = key.split('.')

            # Filter by package if specified
            if package and pkg != package:
                continue

            for field_info in fields:
                col_name = field_info['column']
                row_count = field_info['rows']

                # Safe mode: only drop empty columns
                if safe_mode and row_count > 0:
                    skipped.append((field_info['field'], row_count))
                    continue

                # Drop column
                await storage.drop_column('frags', col_name)
                dropped.append(field_info['field'])

        return {
            'dropped': dropped,
            'skipped': skipped
        }

    async def get_summary(self) -> dict:
        """
        Get summary statistics of orphaned fields.

        Returns:
            Dict with counts and data volume

        Example:
            summary = await auditor.get_summary()
            # {
            #     'total_fields': 15,
            #     'total_rows': 12458,
            #     'by_package': {
            #         'winterforge_blog': {'fields': 10, 'rows': 10000},
            #         'acme_commerce': {'fields': 5, 'rows': 2458}
            #     }
            # }
        """
        orphaned = await self.audit()

        total_fields = 0
        total_rows = 0
        by_package = {}

        for key, fields in orphaned.items():
            package = key.split('.')[0]

            if package not in by_package:
                by_package[package] = {'fields': 0, 'rows': 0}

            for field_info in fields:
                total_fields += 1
                total_rows += field_info['rows']
                by_package[package]['fields'] += 1
                by_package[package]['rows'] += field_info['rows']

        return {
            'total_fields': total_fields,
            'total_rows': total_rows,
            'by_package': by_package
        }
