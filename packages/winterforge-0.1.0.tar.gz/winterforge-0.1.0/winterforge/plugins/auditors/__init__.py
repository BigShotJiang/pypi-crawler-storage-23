"""Field auditing system for WinterForge.

Auditors analyze database fields for orphaned columns, unused fields,
and field provenance.
"""

from ._manager import FieldAuditorManager

__all__ = ['FieldAuditorManager']
