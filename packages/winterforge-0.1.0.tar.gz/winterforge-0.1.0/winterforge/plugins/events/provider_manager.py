"""
Event provider management.

Manages event providers that define allowed event types via
decorated methods. Method signatures serve as event schemas.
"""

from __future__ import annotations

from winterforge.plugins._base import ReorderablePluginManagerBase
from winterforge.plugins.decorators.provider_type import provider_type


@provider_type('event_providers')
class EventProviderManager(ReorderablePluginManagerBase):
    """
    Manage event providers.

    Event providers define allowed event types via decorated methods.
    Method signatures define event schema (parameters and types).

    Auto-generated methods (via @provider_type):
    - validate(path) - Check if event defined
    - get_schema(path) - Get event parameters
    - get_description(path) - Get event docstring

    Example:
        # Check if event exists
        if EventProviderManager.validate('user.save'):
            await user.emit('user.save', email='user@example.com')

        # Get event schema
        schema = EventProviderManager.get_schema('user.save')
        # {'user': 'Frag', 'email': 'str', 'created_at': 'datetime'}

        # Get event description
        desc = EventProviderManager.get_description('user.save')
        # "Emitted when user is saved."
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.event_providers'
