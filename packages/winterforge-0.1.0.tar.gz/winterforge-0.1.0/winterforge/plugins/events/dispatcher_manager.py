"""
Event dispatcher management.

Manages event dispatchers that route events to listeners.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from winterforge.plugins._base import ReorderablePluginManagerBase
from winterforge.plugins.decorators.provider_type import provider_type

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@provider_type('event_dispatchers')
class EventDispatcherManager(ReorderablePluginManagerBase):
    """
    Manage event dispatchers.

    Dispatchers route events to listeners. The framework provides
    a default 'event' dispatcher, but custom dispatchers can be
    added (e.g., async queue dispatcher, filtered dispatcher).

    Auto-generated methods (via @provider_type):
    - validate(path) - Check if dispatcher defined
    - get_schema(path) - Get dispatcher parameters
    - get_description(path) - Get dispatcher docstring

    Example:
        # Dispatch event to all dispatchers
        await EventDispatcherManager.dispatch(event, source)

        # Check if dispatcher exists
        if EventDispatcherManager.has('event'):
            dispatcher = EventDispatcherManager.get('event')
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.event_dispatchers'

    @classmethod
    async def dispatch(cls, event: 'Frag', source: 'Frag') -> None:
        """
        Dispatch event to all registered dispatchers.

        Invokes the dispatch() method on each registered dispatcher
        plugin in registration order.

        Args:
            event: Event Frag (with loaded context)
            source: Source Frag (loaded)

        Example:
            # After creating Event Frag
            await EventDispatcherManager.dispatch(event_frag, user_frag)
        """
        # Get all registered dispatcher plugins
        for dispatcher_id in cls._order:
            dispatcher = cls.get(dispatcher_id)
            await dispatcher.dispatch(event, source)
