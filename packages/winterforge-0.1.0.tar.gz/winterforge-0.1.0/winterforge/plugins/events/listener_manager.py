"""
Event listener management.

Manages event listeners which are arbitrary callables registered
to respond to specific event types.
"""

from __future__ import annotations

from typing import Dict, List, Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class EventListenerManager:
    """
    Manage event listeners.

    Listeners are arbitrary callables registered via @event_listener.
    Not plugins - uses direct registration without plugin system.

    All listeners receive (event, source) where:
    - event: Event Frag with loaded context
    - source: Source Frag that emitted the event

    Example:
        # Register listener
        @event_listener(events=['user.save'])
        async def audit_user(event: Frag, source: Frag):
            context = event.get_loaded_context()
            user = context['user']
            print(f"User {user.id} saved")

        # Manual registration
        EventListenerManager.register('user.save', my_listener)

        # Get listeners
        listeners = EventListenerManager.get_listeners('user.save')

        # Notify all listeners
        await EventListenerManager.notify('user.save', event, source)
    """

    # Registry of event path → list of listener callables
    _listeners: Dict[str, List[Callable]] = {}

    @classmethod
    def register(cls, event_path: str, listener: Callable) -> None:
        """
        Register listener for event type.

        Registration is idempotent - same listener can be registered
        multiple times (useful for module reloads during development).

        Args:
            event_path: Event path (e.g., 'user.save')
            listener: Async callable(event: Frag, source: Frag)

        Example:
            async def my_listener(event: Frag, source: Frag):
                await log(event)

            EventListenerManager.register('user.save', my_listener)
        """
        if event_path not in cls._listeners:
            cls._listeners[event_path] = []

        cls._listeners[event_path].append(listener)

    @classmethod
    def get_listeners(cls, event_path: str) -> List[Callable]:
        """
        Get all listeners for event type.

        Args:
            event_path: Event path

        Returns:
            List of listener callables (may be empty)

        Example:
            listeners = EventListenerManager.get_listeners('user.save')
            for listener in listeners:
                await listener(event, source)
        """
        return cls._listeners.get(event_path, [])

    @classmethod
    async def notify(
        cls,
        event_path: str,
        event: 'Frag',
        source: 'Frag'
    ) -> None:
        """
        Notify all listeners for event.

        Calls each listener in registration order with loaded Frags.
        Listeners execute sequentially (not concurrently) to maintain
        predictable ordering.

        Args:
            event_path: Event path
            event: Event Frag (with loaded context)
            source: Source Frag (loaded)

        Example:
            # After event emission
            await EventListenerManager.notify(
                'user.save',
                event_frag,
                user_frag
            )
        """
        listeners = cls.get_listeners(event_path)

        for listener in listeners:
            await listener(event, source)

    @classmethod
    def clear(cls) -> None:
        """
        Clear all listeners.

        Useful for testing or dynamic reconfiguration.
        """
        cls._listeners.clear()

    @classmethod
    def has_listeners(cls, event_path: str) -> bool:
        """
        Check if event has any listeners.

        Args:
            event_path: Event path

        Returns:
            True if at least one listener is registered
        """
        return event_path in cls._listeners and bool(
            cls._listeners[event_path]
        )
