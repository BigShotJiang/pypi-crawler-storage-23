"""Event dispatcher plugins."""

from winterforge.plugins.events.dispatchers.event import EventDispatcher

__all__ = ['EventDispatcher']
