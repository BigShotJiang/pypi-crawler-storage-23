"""
Simple event dispatcher.

Routes events to registered listeners via EventListenerManager.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from winterforge.plugins.decorators import event_dispatcher, root
from winterforge.plugins.events.listener_manager import EventListenerManager

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@event_dispatcher()
@root('event')
class EventDispatcher:
    """
    Simple event dispatcher.

    Routes events to registered listeners via EventListenerManager.
    Acts as a thin proxy - listeners decide execution behavior.

    This is the default dispatcher. Custom dispatchers can be added
    for specialized routing (e.g., queue-based, filtered).

    Example:
        # Dispatcher is used automatically
        await user.emit('user.save', email='user@example.com')
        # → EventDispatcherManager.dispatch() called
        # → EventDispatcher.dispatch() routes to listeners
    """

    async def dispatch(self, event: 'Frag', source: 'Frag') -> None:
        """
        Dispatch event to listeners.

        Extracts event type from Event Frag and notifies all
        registered listeners for that event type.

        Args:
            event: Event Frag (contains type, loaded context)
            source: Source Frag (loaded)

        Example:
            dispatcher = EventDispatcher()
            await dispatcher.dispatch(event_frag, user_frag)
        """
        # Extract event type from Event Frag
        event_type = event.get('type')

        if not event_type:
            # No event type specified - skip
            return

        # Notify all listeners via EventListenerManager
        await EventListenerManager.notify(event_type, event, source)
