"""SQLite storage backend for Frags (async version with aiosqlite)."""

from __future__ import annotations

import aiosqlite
import json
from typing import Optional, List, Dict, Any
from winterforge.frags import Frag
from winterforge.plugins.decorators import storage_backend, root
from winterforge.plugins.slug_convertors import SlugConvertorManager
from winterforge.plugins.storage._sql_base import (
    SQLStorageBase,
    _validate_sql_identifier
)

try:
    from pydantic import BaseModel as PydanticBaseModel
    HAS_PYDANTIC = True
except ImportError:
    PydanticBaseModel = object  # Fallback type
    HAS_PYDANTIC = False


@storage_backend()
@root('sqlite')
class SQLiteStorageBackend(SQLStorageBase):
    """
    Async SQLite storage backend for Frags using aiosqlite.

    Uses single table with composition-based schema:
    - id: Global Frag ID
    - affinities: JSON array of affinity tags
    - traits: JSON array of trait IDs
    - aliases: JSON object of alias relationships
    - Dynamic columns for trait fields

    **Thread-safe by design:** Uses native async I/O with aiosqlite.
    No `check_same_thread=False` danger.

    Example:
        storage = StorageManager.get('sqlite', db_path='app.db')
        await storage.save(frag)  # Native async
    """

    def __init__(self, db_path: str = ':memory:') -> None:
        """
        Initialize SQLite storage backend.

        Note: Schema initialization is lazy (on first use) since
        aiosqlite requires async operations.

        Args:
            db_path: Path to SQLite database file (default: in-memory)
        """
        self.db_path = db_path
        self._conn: Optional[aiosqlite.Connection] = None
        self._initialized = False
        self._counter_synced = False  # Track if ID counter has been synced

    async def _ensure_connection(self) -> aiosqlite.Connection:
        """
        Ensure database connection exists and is initialized.

        Lazy initialization pattern for async operations.

        Returns:
            Active database connection
        """
        if self._conn is None:
            # check_same_thread=False is safe with aiosqlite since it manages
            # thread safety by running all operations in a dedicated thread
            self._conn = await aiosqlite.connect(
                self.db_path,
                check_same_thread=False
            )
            self._conn.row_factory = aiosqlite.Row

            # Check if database has existing data BEFORE initializing schema
            has_existing_data = await self._has_existing_data()

            await self._init_schema()

            # Only sync counter once AND only if database had existing data
            # If database is new/empty, leave counter alone (tests manage it)
            if not self._counter_synced and has_existing_data:
                await self._sync_id_counter()
                self._counter_synced = True

            await self._ensure_registered_trait_columns()
            self._initialized = True

        return self._conn

    @property
    def conn(self):
        """
        Backward compatibility: Access underlying sync connection.

        DEPRECATED: This property exists for test compatibility only.
        Use async methods instead.

        Returns:
            Underlying sqlite3.Connection if available, None otherwise
        """
        if self._conn and hasattr(self._conn, '_conn'):
            return self._conn._conn
        return None

    async def close(self) -> None:
        """
        Close database connection.

        Call during application shutdown to release resources.
        """
        if self._conn:
            await self._conn.close()
            self._conn = None
            self._initialized = False

    @staticmethod
    def _sanitize_field_name(field_name: str) -> str:
        """
        Sanitize field name for SQL column names.

        SQL column names cannot contain hyphens. Always convert to underscores.
        Strip leading underscores from Python private fields.

        Args:
            field_name: Field name (may contain hyphens or leading underscore)

        Returns:
            SQL-safe field name (only underscores, alphanumeric)
        """
        # Replace hyphens with underscores (for slugs: db-path → db_path)
        sanitized = field_name.replace('-', '_')
        # Strip leading underscores (for Python fields: _count → count)
        return sanitized.lstrip('_')

    async def _init_schema(self) -> None:
        """Initialize database schema (async)."""
        conn = await self._ensure_connection()

        # Create frags table with core composition fields
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS frags (
                id INTEGER PRIMARY KEY,
                uuid TEXT NOT NULL UNIQUE,
                affinities TEXT NOT NULL DEFAULT '[]',
                traits TEXT NOT NULL DEFAULT '[]',
                aliases TEXT NOT NULL DEFAULT '{}'
            )
        """)

        # Create index on affinities for fast queries
        await conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_affinities
            ON frags(affinities)
        """)

        # Create index on traits
        await conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_traits
            ON frags(traits)
        """)

        # Create unique index on UUID
        await conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_uuid
            ON frags(uuid)
        """)

        await conn.commit()

    async def _has_existing_data(self) -> bool:
        """
        Check if database has existing Frag data.

        Returns:
            True if frags table exists and contains data
        """
        if not self._conn:
            return False

        # Check if frags table exists
        async with self._conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='frags'"
        ) as cursor:
            table_exists = await cursor.fetchone() is not None

        if not table_exists:
            return False

        # Check if table has any data
        async with self._conn.execute(
            "SELECT COUNT(*) FROM frags"
        ) as cursor:
            result = await cursor.fetchone()
            count = result[0] if result else 0

        return count > 0

    async def _sync_id_counter(self) -> None:
        """
        Sync the Frag ID counter using counter provider plugins.

        Uses CounterProviderManager.resolve() to find the appropriate
        counter provider based on storage state. This follows WinterForge's
        plugin-based architecture.

        Providers:
        - DatabaseSyncedCounter: Syncs with existing data (MAX(id) + 1)
        - FreshCounter: Returns count(1) for new/empty databases

        Note: Should only be called from _ensure_connection() after
        self._conn has been established.
        """
        from winterforge.plugins.counter import CounterProviderManager

        # Use plugin resolution pattern to find appropriate counter
        provider = CounterProviderManager.resolve({'storage': self})

        if provider:
            # Get counter from matched provider
            Frag._id_counter = await provider.get(self)
        else:
            # No provider matched - this shouldn't happen with FreshCounter
            # as fallback, but handle gracefully
            import logging
            logging.warning(
                "No counter provider matched for %s - "
                "using default count(1)",
                self.__class__.__name__
            )
            import itertools
            Frag._id_counter = itertools.count(1)

    async def _ensure_registered_trait_columns(self) -> None:
        """
        Ensure columns exist for all registered traits.

        This eagerly creates schema columns for traits that are registered
        in the system, preventing "column not found" errors during queries.
        """
        from winterforge.frags.traits._manager import FragTraitManager

        # Get all registered traits
        trait_repository = FragTraitManager.repository()
        trait_ids = trait_repository.ids()

        for trait_id in trait_ids:
            if not FragTraitManager.has(trait_id):
                continue

            try:
                # Get trait field definitions
                trait_fields = FragTraitManager.get_trait_fields(trait_id)

                # Get type hints from trait class for proper column types
                try:
                    from typing import get_type_hints
                    trait_class = FragTraitManager._get_trait_class(trait_id)
                    type_hints = get_type_hints(trait_class)
                except Exception:
                    type_hints = {}

                # Ensure columns exist for each field
                for field_name, field_info in trait_fields.items():
                    # Skip internal fields (except _storage_backend)
                    if field_name.startswith('_') and field_name != '_storage_backend':
                        continue

                    # Get field type from type hints (if available)
                    field_type = type_hints.get(field_name)

                    # Unwrap Optional[T] to T for column type determination
                    if field_type:
                        import typing
                        if hasattr(typing, 'get_origin') and hasattr(typing, 'get_args'):
                            origin = typing.get_origin(field_type)
                            if origin is typing.Union:
                                args = typing.get_args(field_type)
                                non_none_args = [arg for arg in args if arg is not type(None)]
                                if len(non_none_args) == 1:
                                    field_type = non_none_args[0]

                    # Create column with appropriate type
                    column_name = f"{trait_id}__{self._sanitize_field_name(field_name)}"
                    await self._ensure_column_exists(column_name, field_type)
            except Exception:
                # Skip traits that can't be introspected
                continue

    async def _ensure_column_exists(self, column_name: str, field_type: type = None) -> None:
        """
        Ensure a column exists in the frags table.

        Args:
            column_name: Name of the column to create
            field_type: Python type of the field (for SQL type mapping)
        """
        conn = await self._ensure_connection()

        # Check if column already exists
        async with conn.execute("PRAGMA table_info(frags)") as cursor:
            rows = await cursor.fetchall()
            existing_columns = [row[1] for row in rows]

        if column_name in existing_columns:
            return  # Column already exists

        # Determine SQL type
        if field_type is None:
            sql_type = "TEXT"
        elif field_type == bool:
            sql_type = "INTEGER"  # SQLite stores booleans as integers
        elif field_type == int:
            sql_type = "INTEGER"
        elif field_type == float:
            sql_type = "REAL"
        elif field_type in (list, dict):
            sql_type = "TEXT"  # Store as JSON
        else:
            sql_type = "TEXT"  # Default to TEXT for unknown types

        # Add column to table
        try:
            await conn.execute(f"ALTER TABLE frags ADD COLUMN {column_name} {sql_type}")
            await conn.commit()
        except Exception:
            # Column might have been added by another process
            pass

    async def save(self, frag: Any) -> None:
        """
        Persist a Frag to storage (fully async).

        Args:
            frag: Frag instance to save
        """
        conn = await self._ensure_connection()

        # Serialize composition fields (use properties)
        affinities_json = json.dumps(frag.affinities)
        traits_json = json.dumps(frag.traits)
        aliases_json = json.dumps(frag.aliases)
        frag_id = frag.id
        frag_uuid = frag.uuid

        # Check if Frag exists in database
        async with conn.execute("SELECT id FROM frags WHERE id = ?", (frag_id,)) as cursor:
            exists = await cursor.fetchone() is not None

        if exists:
            # Update existing
            sql = """
                UPDATE frags
                SET uuid = ?, affinities = ?, traits = ?, aliases = ?
                WHERE id = ?
            """
            await conn.execute(sql, (frag_uuid, affinities_json, traits_json, aliases_json, frag_id))
        else:
            # Insert new with ID from counter (synced with database)
            sql = """
                INSERT INTO frags (id, uuid, affinities, traits, aliases)
                VALUES (?, ?, ?, ?, ?)
            """
            await conn.execute(sql, (frag_id, frag_uuid, affinities_json, traits_json, aliases_json))

        # Save trait fields (use composed traits to include dependencies)
        composed_traits = (
            getattr(frag, '_composed_traits', set()) or set(frag.traits)
        )
        if composed_traits:
            await self._save_trait_fields(frag, conn, exists, composed_traits)

        await conn.commit()

    async def _save_trait_fields(
        self,
        frag: Any,
        conn: aiosqlite.Connection,
        exists: bool,
        composed_traits: set
    ) -> None:
        """
        Save trait field values to normalized columns.

        Creates columns for new traits and stores field values.
        For fieldable's Pydantic data, extracts individual fields
        to {trait}_{field_name} columns using _field_origins mapping.

        Args:
            frag: Frag instance
            conn: Database connection
            exists: Whether Frag already exists in database
            composed_traits: Set of all composed trait IDs (includes dependencies)
        """
        from winterforge.frags.traits._manager import FragTraitManager

        set_clauses = []
        values = []

        for trait_id in composed_traits:
            # Ensure columns exist for this trait
            await self._ensure_trait_columns(trait_id, conn)

            # Get trait fields
            trait_fields = FragTraitManager.get_trait_fields(trait_id)

            # Save regular trait fields (metadata, etc.)
            for field_name in trait_fields.keys():
                # Skip Pydantic model and schema (handled separately)
                if field_name in ('_fieldable_schema', '_fieldable_data'):
                    continue

                column_name = f"{self._get_sql_trait_id(trait_id)}__{self._sanitize_field_name(field_name)}"
                if hasattr(frag, field_name):
                    field_value = getattr(frag, field_name)

                    # Skip non-serializable types
                    if isinstance(field_value, type):
                        continue

                    # Serialize using base class method
                    field_value = self._serialize_field_value(field_value)

                    set_clauses.append(f"{column_name} = ?")
                    values.append(field_value)

            # Special handling for fieldable Pydantic data
            if trait_id == 'fieldable' and hasattr(frag, '_fieldable_data'):
                # Save individual fields from Pydantic model to normalized columns
                await self._save_fieldable_fields(frag, conn, set_clauses, values)

        # Execute single UPDATE with all fields
        if set_clauses:
            sql = f"UPDATE frags SET {', '.join(set_clauses)} WHERE id = ?"
            values.append(frag.id)
            await conn.execute(sql, values)

    async def _save_fieldable_fields(
        self,
        frag: Any,
        conn: aiosqlite.Connection,
        set_clauses: list,
        values: list
    ) -> None:
        """
        Save individual fields from Pydantic model to normalized columns.

        Uses _field_origins mapping to determine {trait}_{field_name} columns.

        Args:
            frag: Frag instance
            conn: Database connection
            set_clauses: List to append SET clauses to
            values: List to append values to
        """
        if not hasattr(frag, '_fieldable_data') or frag._fieldable_data is None:
            return

        fieldable_data = frag._fieldable_data
        field_origins = getattr(frag, '_field_origins', {})

        # Get all field values from Pydantic model
        if hasattr(fieldable_data, 'model_dump'):
            field_values = fieldable_data.model_dump()
        else:
            field_values = fieldable_data.dict()

        # Save each field to its {trait}_{field_name} column
        for field_name, field_value in field_values.items():
            # Determine source trait (default to 'fieldable' if not tracked)
            source_trait = field_origins.get(field_name, 'fieldable')
            column_name = f"{source_trait}__{self._sanitize_field_name(field_name)}"

            # Ensure column exists
            await self._ensure_field_column(source_trait, field_name, conn)

            # Serialize using base class method
            field_value = self._serialize_field_value(field_value)

            set_clauses.append(f"{column_name} = ?")
            values.append(field_value)

    async def _ensure_field_column(
        self,
        trait_id: str,
        field_name: str,
        conn: aiosqlite.Connection
    ) -> None:
        """
        Ensure a field column exists for normalized storage.

        Args:
            trait_id: Source trait ID
            field_name: Field name
            conn: Database connection
        """
        # Sanitize both trait ID and field name for SQL (hyphens → underscores)
        sanitized_trait_id = self._get_sql_trait_id(trait_id)
        sanitized_field_name = self._sanitize_field_name(field_name)
        column_name = f"{sanitized_trait_id}__{sanitized_field_name}"

        # Validate SQL identifier to prevent injection
        column_name = _validate_sql_identifier(column_name)

        # Check if column exists
        async with conn.execute("PRAGMA table_info(frags)") as cursor:
            rows = await cursor.fetchall()
            columns = [row[1] for row in rows]

        if column_name not in columns:
            await conn.execute(f"ALTER TABLE frags ADD COLUMN {column_name} TEXT")

    async def _ensure_trait_columns(self, trait_id: str, conn: aiosqlite.Connection) -> None:
        """
        Ensure trait columns exist in database.

        Args:
            trait_id: Trait identifier
            conn: Database connection
        """
        from winterforge.frags.traits._manager import FragTraitManager

        trait_fields = FragTraitManager.get_trait_fields(trait_id)

        # Get type hints from trait class for proper column types
        try:
            from typing import get_type_hints
            trait_class = FragTraitManager._get_trait_class(trait_id)
            type_hints = get_type_hints(trait_class)
        except Exception:
            type_hints = {}

        for field_name, field_info in trait_fields.items():
            column_name = f"{self._get_sql_trait_id(trait_id)}__{self._sanitize_field_name(field_name)}"

            # Validate SQL identifier
            column_name = _validate_sql_identifier(column_name)

            # Check if column exists
            async with conn.execute("PRAGMA table_info(frags)") as cursor:
                rows = await cursor.fetchall()
                columns = [row[1] for row in rows]

            if column_name not in columns:
                # Get field type from type hints (if available)
                field_type = type_hints.get(field_name)

                # Unwrap Optional[T] to T for column type determination
                if field_type:
                    import typing
                    if hasattr(typing, 'get_origin') and hasattr(typing, 'get_args'):
                        origin = typing.get_origin(field_type)
                        if origin is typing.Union:
                            args = typing.get_args(field_type)
                            non_none_args = [arg for arg in args if arg is not type(None)]
                            if len(non_none_args) == 1:
                                field_type = non_none_args[0]

                await self._ensure_column_exists(column_name, field_type)

    async def load(self, frag_id: int) -> Optional[Any]:
        """
        Load a Frag from storage by ID (async).

        Args:
            frag_id: Frag ID

        Returns:
            Frag instance or None if not found
        """
        conn = await self._ensure_connection()

        async with conn.execute("SELECT * FROM frags WHERE id = ?", (frag_id,)) as cursor:
            row = await cursor.fetchone()

        if row is None:
            return None

        return await self._row_to_frag(row)

    async def _load_fieldable_fields(self, frag: Any, row: Any) -> None:
        """
        Load fieldable Pydantic fields from normalized columns.

        Args:
            frag: Frag instance
            row: Database row
        """
        # Ensure schema is built
        if hasattr(frag, '_ensure_schema'):
            frag._ensure_schema()
        else:
            return

        # Get field origins mapping
        if not hasattr(frag, '_field_origins'):
            return

        field_origins = frag._field_origins
        field_data = {}

        # Get field type hints from Pydantic schema
        field_types = {}
        if hasattr(frag, '_fieldable_schema') and frag._fieldable_schema:
            schema = frag._fieldable_schema
            if hasattr(schema, 'model_fields'):
                # Pydantic v2
                for fname, field_info in schema.model_fields.items():
                    field_types[fname] = field_info.annotation
            elif hasattr(schema, '__fields__'):
                # Pydantic v1
                for fname, field_info in schema.__fields__.items():
                    field_types[fname] = field_info.outer_type_

        # Load each field from its {trait}_{field_name} column
        for field_name, source_trait in field_origins.items():
            column_name = f"{source_trait}__{self._sanitize_field_name(field_name)}"

            try:
                if column_name in row.keys():
                    value = row[column_name]
                    if value is not None:
                        # Deserialize with type hint for proper conversion
                        field_type = field_types.get(field_name)
                        field_data[field_name] = self._deserialize_field_value(
                            value,
                            field_type
                        )
            except (KeyError, IndexError):
                # Column doesn't exist in this row
                continue

        # Reconstruct Pydantic model if we have data
        if field_data and hasattr(frag, '_fieldable_schema'):
            schema = frag._fieldable_schema
            if schema is not None:
                frag._fieldable_data = schema(**field_data)

    async def _row_to_frag(self, row: Any) -> Frag:
        """
        Convert database row to Frag instance.

        Args:
            row: Database row

        Returns:
            Reconstructed Frag instance
        """
        # Parse composition from JSON
        affinities = json.loads(row['affinities'])
        traits = json.loads(row['traits'])
        aliases = json.loads(row['aliases'])

        # Create Frag with composition
        frag = Frag(
            affinities=affinities,
            traits=traits,
            aliases=aliases
        )

        # Override auto-generated ID with stored ID
        frag._id = row['id']

        # Override UUID
        frag._uuid = row['uuid']

        # Load trait fields from columns
        composed_traits = getattr(frag, '_composed_traits', set()) or set(traits)

        from winterforge.frags.traits._manager import FragTraitManager

        for trait_id in composed_traits:
            # Get trait field definitions
            trait_fields = FragTraitManager.get_trait_fields(trait_id)

            # Get type hints from trait class for proper deserialization
            try:
                from typing import get_type_hints
                trait_class = FragTraitManager._get_trait_class(trait_id)
                type_hints = get_type_hints(trait_class)
            except Exception:
                # Trait class not found or no type hints
                type_hints = {}

            for field_name, field_info in trait_fields.items():
                # Skip Pydantic model (handled separately)
                if field_name in ('_fieldable_schema', '_fieldable_data'):
                    continue

                # Skip read-only fields (handled by fieldable trait)
                if not field_info.writable:
                    continue

                column_name = f"{self._get_sql_trait_id(trait_id)}__{self._sanitize_field_name(field_name)}"

                try:
                    if column_name in row.keys():
                        value = row[column_name]
                        if value is not None:
                            # Get field type from type hints
                            field_type = type_hints.get(field_name)
                            # Deserialize with type hint for proper conversion
                            value = self._deserialize_field_value(value, field_type)
                            # Set using field_info (storage backend privilege)
                            field_info.set(frag, value)
                except (KeyError, IndexError):
                    # Column doesn't exist in this row
                    continue

        # Load fieldable Pydantic data
        if 'fieldable' in composed_traits:
            await self._load_fieldable_fields(frag, row)

        return frag

    async def delete(self, frag_id: int) -> bool:
        """
        Delete a Frag from storage (async).

        Args:
            frag_id: Frag ID

        Returns:
            True if deleted, False if not found
        """
        conn = await self._ensure_connection()

        async with conn.execute("DELETE FROM frags WHERE id = ?", (frag_id,)) as cursor:
            await conn.commit()
            return cursor.rowcount > 0

    def query(self) -> 'QueryRepository':
        """
        Create a query builder for this storage backend.

        Returns:
            QueryRepository instance
        """
        from winterforge.plugins.query._repository import QueryRepository
        return QueryRepository(storage=self)

    async def get_distinct_affinities(self) -> List[str]:
        """
        Get list of all unique affinities in storage.

        Optimized: Uses JSON extraction without loading all Frags.

        Returns:
            List of unique affinity strings
        """
        conn = await self._ensure_connection()

        # Use json_each to extract affinity values from JSON arrays
        async with conn.execute("""
            SELECT DISTINCT value
            FROM frags, json_each(frags.affinities)
            ORDER BY value
        """) as cursor:
            rows = await cursor.fetchall()

        return [row[0] for row in rows]

    async def get_distinct_traits(self) -> List[str]:
        """
        Get list of all unique traits in storage.

        Optimized: Uses JSON extraction without loading all Frags.

        Returns:
            List of unique trait strings
        """
        conn = await self._ensure_connection()

        # Use json_each to extract trait values from JSON arrays
        async with conn.execute("""
            SELECT DISTINCT value
            FROM frags, json_each(frags.traits)
            ORDER BY value
        """) as cursor:
            rows = await cursor.fetchall()

        return [row[0] for row in rows]

    async def get_affinity_counts(self) -> Dict[str, int]:
        """
        Get usage counts for each affinity.

        Returns:
            Dict mapping affinity to count
        """
        conn = await self._ensure_connection()

        # Count occurrences of each affinity
        async with conn.execute("""
            SELECT value, COUNT(*) as count
            FROM frags, json_each(frags.affinities)
            GROUP BY value
            ORDER BY count DESC
        """) as cursor:
            rows = await cursor.fetchall()

        return {row[0]: row[1] for row in rows}

    async def get_trait_counts(self) -> Dict[str, int]:
        """
        Get usage counts for each trait.

        Returns:
            Dict mapping trait to count
        """
        conn = await self._ensure_connection()

        # Count occurrences of each trait
        async with conn.execute("""
            SELECT value, COUNT(*) as count
            FROM frags, json_each(frags.traits)
            GROUP BY value
            ORDER BY count DESC
        """) as cursor:
            rows = await cursor.fetchall()

        return {row[0]: row[1] for row in rows}

    def get_trait_columns(self, traits: List[str]) -> List[str]:
        """
        Get database columns for given traits (sync, no DB access).

        Args:
            traits: List of trait IDs

        Returns:
            List of column names
        """
        from winterforge.frags.traits._manager import FragTraitManager

        columns = []
        for trait_id in traits:
            trait_fields = FragTraitManager.get_trait_fields(trait_id)
            for field_name in trait_fields.keys():
                column_name = f"{self._get_sql_trait_id(trait_id)}__{self._sanitize_field_name(field_name)}"
                columns.append(column_name)

        return columns

    def create_trait_columns(self, trait_id: str, fields: Dict[str, Any]) -> None:
        """
        Create columns for a trait's fields (sync wrapper).

        Note: This is a legacy sync method. Prefer using async methods directly.

        Args:
            trait_id: Trait identifier
            fields: Field definitions from trait
        """
        # This method is called during trait registration which happens at import time
        # We can't run async code during imports, so we'll defer column creation
        # until first database access
        pass  # Columns created lazily by _ensure_trait_columns

    async def get_table_columns(self, table_name: str) -> List[str]:
        """
        Get list of columns in a table.

        Args:
            table_name: Name of table

        Returns:
            List of column names
        """
        conn = await self._ensure_connection()

        async with conn.execute(f"PRAGMA table_info({table_name})") as cursor:
            rows = await cursor.fetchall()

        return [row[1] for row in rows]

    async def count_column_usage(self, column_name: str) -> int:
        """
        Count how many Frags use a column (have non-NULL values).

        Args:
            column_name: Column to check

        Returns:
            Count of Frags with non-NULL value in this column
        """
        conn = await self._ensure_connection()

        # Validate column name to prevent SQL injection
        column_name = _validate_sql_identifier(column_name)

        async with conn.execute(
            f"SELECT COUNT(*) FROM frags WHERE {column_name} IS NOT NULL"
        ) as cursor:
            row = await cursor.fetchone()

        return row[0] if row else 0

    async def drop_column(self, table_name: str, column_name: str) -> None:
        """
        Drop a column from a table.

        Args:
            table_name: Table name
            column_name: Column to drop
        """
        conn = await self._ensure_connection()

        # Validate identifiers
        table_name = _validate_sql_identifier(table_name)
        column_name = _validate_sql_identifier(column_name)

        # SQLite doesn't support DROP COLUMN directly until 3.35.0
        # For older versions, we'd need to recreate the table
        # For now, assume SQLite 3.35.0+ is available
        try:
            await conn.execute(f"ALTER TABLE {table_name} DROP COLUMN {column_name}")
            await conn.commit()
        except aiosqlite.OperationalError:
            # Older SQLite version - would need table recreation
            # Skip for now
            pass

    async def execute(self, query_dict: dict) -> List[dict]:
        """
        Execute a query dictionary and return results.

        Args:
            query_dict: Query parameters from QueryRepository

        Returns:
            List of Frag instances matching query
        """
        conn = await self._ensure_connection()

        # Build WHERE clause
        where_clauses = []
        params = []

        # Filter by affinities
        if 'affinities' in query_dict:
            affinity_filter = query_dict['affinities']
            if isinstance(affinity_filter, str):
                # Single affinity - check if it's in the JSON array
                where_clauses.append("EXISTS (SELECT 1 FROM json_each(frags.affinities) WHERE value = ?)")
                params.append(affinity_filter)
            elif isinstance(affinity_filter, list):
                # Multiple affinities - all must be present
                for affinity in affinity_filter:
                    where_clauses.append("EXISTS (SELECT 1 FROM json_each(frags.affinities) WHERE value = ?)")
                    params.append(affinity)

        # Filter by traits
        if 'traits' in query_dict:
            trait_filter = query_dict['traits']
            if isinstance(trait_filter, str):
                where_clauses.append("EXISTS (SELECT 1 FROM json_each(frags.traits) WHERE value = ?)")
                params.append(trait_filter)
            elif isinstance(trait_filter, list):
                for trait in trait_filter:
                    where_clauses.append("EXISTS (SELECT 1 FROM json_each(frags.traits) WHERE value = ?)")
                    params.append(trait)

        # Filter by field conditions
        if 'conditions' in query_dict:
            for condition in query_dict['conditions']:
                field = condition['field']
                operator = condition.get('operator', '=')
                value = condition['value']

                # Map field to column
                column = await self._map_field_to_column(field)

                # Skip if column doesn't exist (schema not initialized yet)
                if column is None:
                    continue

                # Build condition based on operator
                if operator == '=':
                    # Special handling for JSON fields
                    if field in ('affinities', 'traits', 'aliases'):
                        # JSON containment check
                        where_clauses.append(f"{column} LIKE ?")
                        params.append(f'%"{value}"%')
                    else:
                        where_clauses.append(f"{column} = ?")
                        params.append(value)
                elif operator == '!=':
                    where_clauses.append(f"{column} != ?")
                    params.append(value)
                elif operator == '<':
                    where_clauses.append(f"{column} < ?")
                    params.append(value)
                elif operator == '>':
                    where_clauses.append(f"{column} > ?")
                    params.append(value)
                elif operator == 'LIKE':
                    where_clauses.append(f"{column} LIKE ?")
                    params.append(value)
                elif operator == 'IN':
                    placeholders = ','.join('?' * len(value))
                    where_clauses.append(f"{column} IN ({placeholders})")
                    params.extend(value)
                elif operator == 'CONTAINS':
                    # For JSON fields (affinities, traits, etc)
                    where_clauses.append(f"{column} LIKE ?")
                    params.append(f'%"{value}"%')

        # Build SQL
        sql = "SELECT * FROM frags"
        if where_clauses:
            sql += " WHERE " + " AND ".join(where_clauses)

        # Add sorting
        sorts = query_dict.get('sort', [])
        if sorts:
            order_clauses = []
            for sort in sorts:
                field = sort['field']
                direction = sort.get('direction', 'ASC')
                column = await self._map_field_to_column(field)
                # Skip if column doesn't exist
                if column is not None:
                    order_clauses.append(f"{column} {direction}")
            if order_clauses:
                sql += f" ORDER BY {', '.join(order_clauses)}"

        # Add limit/offset
        if 'limit' in query_dict and query_dict['limit'] is not None:
            sql += f" LIMIT {query_dict['limit']}"
        if 'offset' in query_dict and query_dict['offset'] is not None:
            sql += f" OFFSET {query_dict['offset']}"

        # Execute query
        async with conn.execute(sql, params) as cursor:
            rows = await cursor.fetchall()
            # Get column names for dict conversion
            columns = [desc[0] for desc in cursor.description]

        # Convert rows to dictionaries (same as old code)
        return [dict(zip(columns, row)) for row in rows]

    async def _map_field_to_column(self, field: str) -> str | None:
        """
        Map a field name to database column.

        Args:
            field: Field name (e.g., 'title', 'affinities')

        Returns:
            Column name (e.g., 'titled__title', 'affinities') or None if not found
        """
        # Core composition fields
        if field in ('id', 'uuid', 'affinities', 'traits', 'aliases'):
            return field

        # If already in trait__field format
        if '__' in field:
            return field

        # Schema fields - check which trait contributes this field
        # Common patterns: titled__title, sluggable__slug, etc.
        conn = await self._ensure_connection()
        async with conn.execute("PRAGMA table_info(frags)") as cursor:
            rows = await cursor.fetchall()
            columns = [row[1] for row in rows]

        # Look for {trait}__{field} pattern
        for column in columns:
            if '__' in column and column.endswith(f"__{field}"):
                return column

        # Check if field exists as a direct column
        if field in columns:
            return field

        # Column doesn't exist - return None to skip this condition
        return None
