"""YAML-based storage backend for Frags.

Human-readable, version-control friendly storage. Perfect for:
- Development and prototyping
- Configuration management
- Exporting/importing Frags
- Small datasets
- Portability

Each Frag is stored as a separate YAML file in the specified directory.
"""

from __future__ import annotations

import asyncio
from typing import Any, Optional, List, Dict
from pathlib import Path
import yaml

from winterforge.plugins import storage_backend
from winterforge.plugins.decorators import root
from winterforge.frags.manifest import Manifest


@storage_backend()
@root('yaml')
class YamlStorageBackend:
    """
    YAML file-based storage backend.

    Stores each Frag as a separate YAML file in a directory.
    Files are named by Frag ID: {path}/{frag_id}.yaml

    This backend is ideal for development, configuration, and
    human-readable exports. Not recommended for large datasets
    or high-performance requirements.

    Examples:
        # Create backend
        storage = YamlStorageBackend(path='./frags')

        # Save Frag
        frag = Frag(traits=['titled'])
        frag.set_title("My Frag")
        await storage.save(frag)
        # Creates: ./frags/1.yaml

        # Load Frag
        loaded = await storage.load(1)

        # Query Frags
        posts = await storage.query().affinity('post').execute()
    """

    def __init__(self, path: str = './winterforge_data/frags'):
        """
        Initialize YAML storage backend.

        Args:
            path: Directory path for storing YAML files
        """
        self.path = Path(path)
        self.path.mkdir(parents=True, exist_ok=True)

        # Track next ID for new Frags
        self._next_id = self._compute_next_id()

    def _compute_next_id(self) -> int:
        """Compute next available Frag ID by scanning existing files."""
        if not self.path.exists():
            return 1

        max_id = 0
        for yaml_file in self.path.glob('*.yaml'):
            try:
                frag_id = int(yaml_file.stem)
                max_id = max(max_id, frag_id)
            except ValueError:
                # Skip non-numeric filenames
                continue

        return max_id + 1

    def _get_file_path(self, frag_id: int) -> Path:
        """Get file path for a Frag ID."""
        return self.path / f"{frag_id}.yaml"

    async def save(self, frag: Any) -> None:
        """
        Save a Frag to YAML file.

        Args:
            frag: Frag instance to save
        """
        def _save_sync():
            # Assign ID if new Frag
            if frag.id >= 1000000:  # Temporary ID from Frag._id_counter
                frag._set_id(self._next_id)
                self._next_id += 1

            # Collect all Frag data
            data = {
                'id': frag.id,
                'affinities': list(frag.affinities),
                'traits': list(frag.traits),
            }

            # Add aliases if present
            if frag.aliases:
                data['aliases'] = dict(frag.aliases)

            # Collect fields from all traits
            fields = {}
            from winterforge.plugins.managers import FragTraitManager

            # Use composed traits to include dependencies
            composed_traits = (
                getattr(frag, '_composed_traits', set()) or set(frag.traits)
            )
            for trait_id in composed_traits:
                if not FragTraitManager.has(trait_id):
                    continue

                trait_fields = FragTraitManager.get_trait_fields(trait_id)
                for field_name in trait_fields.keys():
                    if hasattr(frag, field_name):
                        value = getattr(frag, field_name)
                        # Skip internal/private attributes from persistable trait
                        if field_name.startswith('_') and field_name != '_storage_backend':
                            fields[field_name] = value

            if fields:
                data['fields'] = fields

            # Write to YAML file
            file_path = self._get_file_path(frag.id)
            with open(file_path, 'w') as f:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False)

            # Mark Frag as unchanged
            frag.mark_unchanged()

        await asyncio.to_thread(_save_sync)

    async def load(self, frag_id: int) -> Optional[Any]:
        """
        Load a Frag from YAML file.

        Args:
            frag_id: Frag ID to load

        Returns:
            Frag instance or None if not found
        """
        def _load_sync():
            file_path = self._get_file_path(frag_id)

            if not file_path.exists():
                return None

            # Load YAML data
            with open(file_path) as f:
                data = yaml.safe_load(f)

            # Import here to avoid circular dependency
            from winterforge.frags.base import Frag

            # Create Frag with composition
            frag = Frag(
                affinities=data.get('affinities', []),
                traits=data.get('traits', []),
                aliases=data.get('aliases', {})
            )

            # Set ID
            frag._set_id(data['id'])

            # Restore field values
            fields = data.get('fields', {})
            for field_name, value in fields.items():
                setattr(frag, field_name, value)

            # Mark as unchanged
            frag.mark_unchanged()

            return frag

        return await asyncio.to_thread(_load_sync)

    async def delete(self, frag_id: int) -> bool:
        """
        Delete a Frag's YAML file.

        Args:
            frag_id: Frag ID to delete

        Returns:
            True if deleted, False if not found
        """
        def _delete_sync():
            file_path = self._get_file_path(frag_id)

            if not file_path.exists():
                return False

            file_path.unlink()
            return True

        return await asyncio.to_thread(_delete_sync)

    def query(self) -> 'QueryRepository':
        """
        Return query builder for this storage backend.

        Returns:
            QueryRepository configured with this storage

        Example:
            results = await storage.query()\\
                .affinity('config')\\
                .trait('titled')\\
                .execute()
        """
        from winterforge.plugins.query._repository import QueryRepository
        return QueryRepository(storage=self)

    async def get_distinct_affinities(self) -> List[str]:
        """
        Get all unique affinities without fully loading Frags.

        Scans YAML files and extracts affinities metadata efficiently.

        Returns:
            Sorted list of unique affinity strings
        """
        def _get_affinities_sync():
            affinities = set()
            yaml_files = list(self.path.glob('*.yaml'))

            for yaml_file in yaml_files:
                try:
                    with open(yaml_file, 'r') as f:
                        data = yaml.safe_load(f)
                        if data and 'affinities' in data:
                            affinities.update(data['affinities'])
                except (yaml.YAMLError, IOError):
                    # Skip invalid files
                    continue

            return sorted(list(affinities))

        return await asyncio.to_thread(_get_affinities_sync)

    async def get_distinct_traits(self) -> List[str]:
        """
        Get all unique traits without fully loading Frags.

        Scans YAML files and extracts traits metadata efficiently.

        Returns:
            Sorted list of unique trait strings
        """
        def _get_traits_sync():
            traits = set()
            yaml_files = list(self.path.glob('*.yaml'))

            for yaml_file in yaml_files:
                try:
                    with open(yaml_file, 'r') as f:
                        data = yaml.safe_load(f)
                        if data and 'traits' in data:
                            traits.update(data['traits'])
                except (yaml.YAMLError, IOError):
                    # Skip invalid files
                    continue

            return sorted(list(traits))

        return await asyncio.to_thread(_get_traits_sync)

    async def get_affinity_counts(self) -> Dict[str, int]:
        """
        Get affinity usage counts without fully loading Frags.

        Scans YAML files and counts affinity occurrences efficiently.

        Returns:
            Dict mapping affinity name to count, sorted by affinity
        """
        def _get_counts_sync():
            counts: Dict[str, int] = {}
            yaml_files = list(self.path.glob('*.yaml'))

            for yaml_file in yaml_files:
                try:
                    with open(yaml_file, 'r') as f:
                        data = yaml.safe_load(f)
                        if data and 'affinities' in data:
                            for affinity in data['affinities']:
                                counts[affinity] = counts.get(affinity, 0) + 1
                except (yaml.YAMLError, IOError):
                    # Skip invalid files
                    continue

            return dict(sorted(counts.items()))

        return await asyncio.to_thread(_get_counts_sync)

    async def get_trait_counts(self) -> Dict[str, int]:
        """
        Get trait usage counts without fully loading Frags.

        Scans YAML files and counts trait occurrences efficiently.

        Returns:
            Dict mapping trait name to count, sorted by trait
        """
        def _get_counts_sync():
            counts: Dict[str, int] = {}
            yaml_files = list(self.path.glob('*.yaml'))

            for yaml_file in yaml_files:
                try:
                    with open(yaml_file, 'r') as f:
                        data = yaml.safe_load(f)
                        if data and 'traits' in data:
                            for trait in data['traits']:
                                counts[trait] = counts.get(trait, 0) + 1
                except (yaml.YAMLError, IOError):
                    # Skip invalid files
                    continue

            return dict(sorted(counts.items()))

        return await asyncio.to_thread(_get_counts_sync)

    async def execute(self, query_dict: dict) -> List[dict]:
        """
        Execute query and return rows as dicts.

        YAML backend loads all files and filters in memory.

        Args:
            query_dict: Query specification dict with:
                - affinities: list of affinity tags (AND logic)
                - traits: list of trait IDs (AND logic)
                - conditions: list of condition dicts
                - sort: list of sort dicts
                - limit: int or None
                - offset: int or None

        Returns:
            List of row dicts with Frag data
        """
        def _execute_sync():
            results = []
            yaml_files = list(self.path.glob('*.yaml'))

            # Extract query parameters
            affinities = query_dict.get('affinities', [])
            traits = query_dict.get('traits', [])
            conditions = query_dict.get('conditions', [])
            sorts = query_dict.get('sort', [])
            limit = query_dict.get('limit')
            offset = query_dict.get('offset')

            for yaml_file in yaml_files:
                try:
                    frag_id = int(yaml_file.stem)
                    with open(yaml_file) as f:
                        data = yaml.safe_load(f)

                    if data is None:
                        continue

                    # Filter by affinities (AND logic)
                    if affinities:
                        frag_affinities = data.get('affinities', [])
                        if not all(aff in frag_affinities for aff in affinities):
                            continue

                    # Filter by traits (AND logic)
                    if traits:
                        frag_traits = data.get('traits', [])
                        if not all(trait in frag_traits for trait in traits):
                            continue

                    # Filter by conditions
                    if conditions:
                        match = True
                        for cond in conditions:
                            field = cond['field']
                            value = cond['value']
                            operator = cond['operator']

                            # Get field value from data
                            if field in data:
                                field_value = data[field]
                            elif 'fields' in data and field in data['fields']:
                                field_value = data['fields'][field]
                            else:
                                match = False
                                break

                            # Apply operator
                            if operator == '=' and field_value != value:
                                match = False
                                break
                            elif operator == '!=' and field_value == value:
                                match = False
                                break
                            elif operator == '<' and not (field_value < value):
                                match = False
                                break
                            elif operator == '>' and not (field_value > value):
                                match = False
                                break
                            elif operator == 'LIKE' and value not in str(field_value):
                                match = False
                                break
                            elif operator == 'CONTAINS' and value not in field_value:
                                match = False
                                break

                        if not match:
                            continue

                    # Add to results (convert to row dict)
                    row = {
                        'id': data.get('id', frag_id),
                        'affinities': data.get('affinities', []),
                        'traits': data.get('traits', []),
                        'aliases': data.get('aliases', {}),
                    }
                    # Add fields
                    if 'fields' in data:
                        row.update(data['fields'])

                    results.append(row)

                except (ValueError, yaml.YAMLError):
                    # Skip invalid files
                    continue

            # Apply sorting
            if sorts:
                for sort in reversed(sorts):
                    field = sort['field']
                    direction = sort.get('direction', 'ASC')
                    reverse = (direction == 'DESC')
                    results.sort(
                        key=lambda r: r.get(field, ''),
                        reverse=reverse
                    )

            # Apply offset
            if offset:
                results = results[offset:]

            # Apply limit
            if limit:
                results = results[:limit]

            return results

        return await asyncio.to_thread(_execute_sync)

    def transaction(self):
        """
        YAML backend does not support transactions.

        Returns a no-op context manager for API compatibility.
        """
        from contextlib import nullcontext
        return nullcontext()
