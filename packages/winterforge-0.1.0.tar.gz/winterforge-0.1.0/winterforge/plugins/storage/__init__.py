"""Storage backend plugins for Winterforge.

Storage backend implementations are registered via decorators and
discovered through entry points or explicit imports during initialization.
Import specific backends directly when needed:

    from winterforge.plugins.storage.sqlite import SQLiteStorageBackend
    from winterforge.plugins.storage.postgresql import PostgreSQLStorageBackend

Or access via manager after initialization:

    from winterforge.plugins.storage.manager import StorageManager
    backend = StorageManager.get('sqlite')
"""

from winterforge.plugins.storage.manager import StorageManager

__all__ = ['StorageManager']
