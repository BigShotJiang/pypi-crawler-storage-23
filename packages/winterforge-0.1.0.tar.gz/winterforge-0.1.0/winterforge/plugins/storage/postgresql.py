"""
PostgreSQL storage backend with async operations and JSONB support.

This backend provides production-ready storage with:
- Async connection pooling via asyncpg
- JSONB columns for composition data
- Dynamic schema evolution for trait fields
- Transaction support
"""

from typing import Any, Optional, AsyncIterator
from contextlib import asynccontextmanager
import asyncpg
import json
from winterforge.frags.base import Frag
from winterforge.frags.manifest import Manifest
from winterforge.plugins.decorators import storage_backend, root
from winterforge.plugins.storage._sql_base import (
    SQLStorageBase,
    _validate_sql_identifier
)


@storage_backend()
@root('postgresql')
class PostgreSQLStorageBackend(SQLStorageBase):
    """
    Async PostgreSQL storage backend for Frags.

    Features:
    - Connection pooling for performance
    - JSONB columns for affinities, traits, aliases
    - Dynamic ALTER TABLE for trait-specific fields
    - Full ACID compliance

    Example:
        >>> pool = await asyncpg.create_pool(...)
        >>> storage = PostgreSQLStorageBackend(pool=pool)
        >>> frag = Frag(affinities=['user'], traits=['titled'])
        >>> frag.title = "Alice"
        >>> await storage.save(frag)
        >>> loaded = await storage.load(frag.id)
    """

    def __init__(
        self,
        pool: Optional[asyncpg.Pool] = None,
        **pool_config: Any
    ):
        """
        Initialize PostgreSQL storage backend.

        Args:
            pool: Existing connection pool (optional)
            **pool_config: Pool configuration if creating new pool
                - host: str = 'localhost'
                - port: int = 5432
                - database: str = 'winterforge'
                - user: str
                - password: str
                - min_size: int = 10
                - max_size: int = 50
                - timeout: float = 30.0
                - max_queries: int = 50000
                - max_inactive_connection_lifetime: float = 300.0
        """
        self.pool = pool
        self.pool_config = pool_config
        self._known_columns: set[str] = set()

    async def _ensure_pool(self) -> asyncpg.Pool:
        """Lazy pool creation if not provided in __init__."""
        if self.pool is None:
            self.pool = await asyncpg.create_pool(**self.pool_config)
        return self.pool

    async def _ensure_schema(self) -> None:
        """
        Create frags table if it doesn't exist.

        Schema:
            id BIGSERIAL PRIMARY KEY
            affinities JSONB NOT NULL DEFAULT '[]'
            traits JSONB NOT NULL DEFAULT '[]'
            aliases JSONB NOT NULL DEFAULT '{}'
            -- Dynamic columns added via ALTER TABLE
        """
        pool = await self._ensure_pool()
        async with pool.acquire() as conn:
            await conn.execute("""
                CREATE TABLE IF NOT EXISTS frags (
                    id BIGSERIAL PRIMARY KEY,
                    uuid UUID NOT NULL UNIQUE,
                    affinities JSONB NOT NULL DEFAULT '[]'::jsonb,
                    traits JSONB NOT NULL DEFAULT '[]'::jsonb,
                    aliases JSONB NOT NULL DEFAULT '{}'::jsonb
                )
            """)

            # Create GIN indexes for JSONB containment queries
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_frags_affinities
                ON frags USING GIN (affinities)
            """)
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_frags_traits
                ON frags USING GIN (traits)
            """)
            await conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_frags_aliases
                ON frags USING GIN (aliases)
            """)

            # Create unique index on UUID
            await conn.execute("""
                CREATE UNIQUE INDEX IF NOT EXISTS idx_frags_uuid
                ON frags(uuid)
            """)

            # Cache existing columns
            rows = await conn.fetch("""
                SELECT column_name
                FROM information_schema.columns
                WHERE table_name = 'frags'
            """)
            self._known_columns = {row['column_name'] for row in rows}

    async def save(self, frag: Frag) -> None:
        """
        Save Frag to database.

        Workflow:
        1. Ensure schema exists
        2. Add any new trait columns
        3. INSERT or UPDATE frag

        Args:
            frag: Frag instance to save
        """
        from winterforge.frags.traits._manager import FragTraitManager

        await self._ensure_schema()
        pool = await self._ensure_pool()

        # Collect trait field values (using private attributes)
        # Use composed traits to include dependencies
        composed_traits = (
            getattr(frag, '_composed_traits', set()) or set(frag.traits)
        )
        trait_columns: dict[str, Any] = {}
        for trait_id in composed_traits:
            # Get trait fields
            trait_fields = FragTraitManager.get_trait_fields(trait_id)

            # Save regular trait fields (metadata, etc.)
            for field_name, field_info in trait_fields.items():
                # Skip Pydantic model and schema (handled separately)
                if field_name in ('_fieldable_schema', '_fieldable_data'):
                    continue

                column_name = f"{self._get_sql_trait_id(trait_id)}__{field_name}"
                if hasattr(frag, field_name):
                    field_value = field_info.get(frag)

                    # Skip non-serializable types
                    if isinstance(field_value, type):
                        continue

                    trait_columns[column_name] = field_value

            # Special handling for fieldable Pydantic data
            if trait_id == 'fieldable':
                # Extract individual fields to normalized columns
                self._collect_fieldable_columns(frag, trait_columns)

        # Ensure columns exist
        await self._create_trait_columns(trait_columns)

        # Build INSERT ... ON CONFLICT UPDATE query
        async with pool.acquire() as conn:
            # Base columns (use getters)
            columns = ['id', 'uuid', 'affinities', 'traits', 'aliases']
            values = [
                frag.id,
                frag.uuid,
                json.dumps(frag.affinities),
                json.dumps(frag.traits),
                json.dumps(frag.aliases)
            ]
            placeholders = ['$1', '$2', '$3', '$4', '$5']

            # Add trait columns
            param_idx = 6
            for col_name, col_value in trait_columns.items():
                columns.append(col_name)
                values.append(col_value)
                placeholders.append(f'${param_idx}')
                param_idx += 1

            # Build conflict update clause
            update_assignments = [
                f"{col} = EXCLUDED.{col}"
                for col in columns if col != 'id'
            ]

            query = f"""
                INSERT INTO frags ({', '.join(columns)})
                VALUES ({', '.join(placeholders)})
                ON CONFLICT (id) DO UPDATE SET
                    {', '.join(update_assignments)}
            """

            await conn.execute(query, *values)

    async def load(self, frag_id: int) -> Optional[Frag]:
        """
        Load Frag by ID.

        Args:
            frag_id: Frag ID to load

        Returns:
            Frag instance or None if not found
        """
        from winterforge.frags.traits._manager import FragTraitManager

        await self._ensure_schema()
        pool = await self._ensure_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM frags WHERE id = $1",
                frag_id
            )

            if row is None:
                return None

            # Reconstruct Frag
            frag = Frag(
                affinities=row['affinities'],
                traits=row['traits'],
                aliases=row['aliases']
            )
            # Override ID (using internal method)
            frag._set_id(row['id'])

            # Restore UUID from storage (using internal method)
            frag._set_uuid(row['uuid'])

            # Populate trait fields (private attributes)
            # Use composed traits to include dependencies
            composed_traits = (
                getattr(frag, '_composed_traits', set()) or set(frag.traits)
            )
            for trait_id in composed_traits:
                trait_fields = FragTraitManager.get_trait_fields(trait_id)

                # Get type hints from trait class for proper deserialization
                try:
                    from typing import get_type_hints
                    trait_class = FragTraitManager._get_trait_class(trait_id)
                    type_hints = get_type_hints(trait_class)
                except Exception:
                    # Trait class not found or no type hints
                    type_hints = {}

                for field_name, field_info in trait_fields.items():
                    # Skip _fieldable_data and _fieldable_schema (handled separately)
                    if field_name in ('_fieldable_data', '_fieldable_schema'):
                        continue

                    # Skip read-only fields (handled separately)
                    if not field_info.writable:
                        continue

                    column_name = f"{self._get_sql_trait_id(trait_id)}__{field_name}"
                    if column_name in row:
                        value = row[column_name]
                        # Get field type from type hints
                        field_type = type_hints.get(field_name)
                        # Deserialize with type hint for proper conversion
                        value = self._deserialize_field_value(value, field_type)
                        # Set using field_info (storage backend privilege)
                        field_info.set(frag, value)

            # After loading all trait fields, reconstruct fieldable Pydantic model from normalized columns
            if 'fieldable' in frag.traits:
                self._load_fieldable_fields(frag, row)

            return frag

    def _collect_fieldable_columns(
        self,
        frag: Frag,
        trait_columns: dict[str, Any]
    ) -> None:
        """
        Collect fieldable fields from Pydantic model to normalized columns.

        Uses _field_origins mapping to determine {trait}_{field_name} columns.

        Args:
            frag: Frag instance
            trait_columns: Dict to add column:value mappings to
        """
        if not hasattr(frag, '_fieldable_data') or frag._fieldable_data is None:
            return

        fieldable_data = frag._fieldable_data
        field_origins = getattr(frag, '_field_origins', {})

        # Get all field values from Pydantic model
        if hasattr(fieldable_data, 'model_dump'):
            field_values = fieldable_data.model_dump()
        else:
            field_values = fieldable_data.dict()

        # Collect each field with its {trait}_{field_name} column name
        for field_name, field_value in field_values.items():
            # Determine source trait (default to 'fieldable' if not tracked)
            source_trait = field_origins.get(field_name, 'fieldable')
            column_name = f"{source_trait}__{field_name}"
            # Serialize using base class method
            trait_columns[column_name] = self._serialize_field_value(field_value)

    def _load_fieldable_fields(self, frag: Frag, row: dict) -> None:
        """
        Load fieldable fields from normalized {trait}__{field_name} columns.

        Collects all field values and reconstructs the Pydantic model.

        Args:
            frag: Frag instance
            row: Database row (dict-like)
        """
        # Ensure schema is built
        if hasattr(frag, '_ensure_schema'):
            frag._ensure_schema()
        else:
            return

        # Get field type hints from Pydantic schema
        field_types = {}
        if hasattr(frag, '_fieldable_schema') and frag._fieldable_schema:
            schema = frag._fieldable_schema
            if hasattr(schema, 'model_fields'):
                # Pydantic v2
                for fname, field_info in schema.model_fields.items():
                    field_types[fname] = field_info.annotation
            elif hasattr(schema, '__fields__'):
                # Pydantic v1
                for fname, field_info in schema.__fields__.items():
                    field_types[fname] = field_info.outer_type_

        # Collect field values from all {trait}__{field_name} columns
        field_values = {}

        # Scan row for columns matching pattern
        for column_name in row.keys():
            if '__' in column_name:
                parts = column_name.split('__', 1)
                if len(parts) == 2:
                    trait_id, field_name = parts
                    # Only load fieldable columns
                    if trait_id == 'fieldable':
                        value = row[column_name]

                        # Deserialize with type hint for proper conversion
                        field_type = field_types.get(field_name)
                        value = self._deserialize_field_value(value, field_type)

                        field_values[field_name] = value

        # Reconstruct Pydantic model if we have data
        if field_values and hasattr(frag, '_fieldable_schema') and frag._fieldable_schema:
            frag._fieldable_data = frag._fieldable_schema(**field_values)

    async def delete(self, frag_id: int) -> bool:
        """
        Delete Frag by ID.

        Args:
            frag_id: Frag ID to delete

        Returns:
            True if deleted, False if not found
        """
        await self._ensure_schema()
        pool = await self._ensure_pool()

        async with pool.acquire() as conn:
            result: str = await conn.execute(
                "DELETE FROM frags WHERE id = $1",
                frag_id
            )
            # Result is like "DELETE 1" or "DELETE 0"
            return result.endswith(' 1')

    def query(self) -> 'QueryRepository':
        """
        Return query builder for this storage backend.

        Returns:
            QueryRepository configured with this storage

        Example:
            # Fluent query API
            results = await storage.query()\\
                .affinity('user')\\
                .trait('titled')\\
                .condition('active', True)\\
                .sort('created_at', 'DESC')\\
                .limit(10)\\
                .execute()

            # Get first result
            user = await storage.query().affinity('user').first()
        """
        from winterforge.plugins.query._repository import QueryRepository
        return QueryRepository(storage=self)

    async def get_distinct_affinities(self) -> list[str]:
        """
        Get all unique affinities without loading Frags.

        Uses PostgreSQL JSONB operations to extract affinities
        directly from the database.

        Returns:
            Sorted list of unique affinity strings
        """
        await self._ensure_schema()
        pool = await self._ensure_pool()

        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT DISTINCT jsonb_array_elements_text(affinities) AS affinity
                FROM frags
                ORDER BY affinity
            """)

        return [row['affinity'] for row in rows]

    async def get_distinct_traits(self) -> list[str]:
        """
        Get all unique traits without loading Frags.

        Uses PostgreSQL JSONB operations to extract traits
        directly from the database.

        Returns:
            Sorted list of unique trait strings
        """
        await self._ensure_schema()
        pool = await self._ensure_pool()

        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT DISTINCT jsonb_array_elements_text(traits) AS trait
                FROM frags
                ORDER BY trait
            """)

        return [row['trait'] for row in rows]

    async def get_affinity_counts(self) -> dict[str, int]:
        """
        Get affinity usage counts without loading Frags.

        Uses PostgreSQL JSONB operations to count affinity
        occurrences directly from the database.

        Returns:
            Dict mapping affinity name to count, sorted by affinity
        """
        await self._ensure_schema()
        pool = await self._ensure_pool()

        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT
                    jsonb_array_elements_text(affinities) AS affinity,
                    COUNT(*) AS count
                FROM frags
                GROUP BY affinity
                ORDER BY affinity
            """)

        return {row['affinity']: row['count'] for row in rows}

    async def get_trait_counts(self) -> dict[str, int]:
        """
        Get trait usage counts without loading Frags.

        Uses PostgreSQL JSONB operations to count trait
        occurrences directly from the database.

        Returns:
            Dict mapping trait name to count, sorted by trait
        """
        await self._ensure_schema()
        pool = await self._ensure_pool()

        async with pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT
                    jsonb_array_elements_text(traits) AS trait,
                    COUNT(*) AS count
                FROM frags
                GROUP BY trait
                ORDER BY trait
            """)

        return {row['trait']: row['count'] for row in rows}

    async def execute(self, query_dict: dict) -> list[dict]:
        """
        Execute query and return rows as dicts.

        Args:
            query_dict: Query specification dict with:
                - affinities: list of affinity tags (AND logic)
                - traits: list of trait IDs (AND logic)
                - conditions: list of condition dicts
                - sort: list of sort dicts
                - limit: int or None
                - offset: int or None

        Returns:
            List of row dicts with column names as keys
        """
        await self._ensure_schema()
        pool = await self._ensure_pool()

        # Build SQL
        sql = "SELECT * FROM frags"
        params = []
        where_clauses = []
        param_idx = 1

        # Handle affinities (JSONB containment, AND logic)
        affinities = query_dict.get('affinities', [])
        for affinity in affinities:
            where_clauses.append(f"affinities @> ${param_idx}::jsonb")
            params.append(json.dumps([affinity]))
            param_idx += 1

        # Handle traits (JSONB containment, AND logic)
        traits = query_dict.get('traits', [])
        for trait in traits:
            where_clauses.append(f"traits @> ${param_idx}::jsonb")
            params.append(json.dumps([trait]))
            param_idx += 1

        # Handle conditions
        conditions = query_dict.get('conditions', [])
        for cond in conditions:
            field = cond['field']
            value = cond['value']
            operator = cond['operator']

            # Map field to column (for trait fields)
            if field in ('affinities', 'traits', 'aliases', 'id', 'uuid'):
                column_name = field
            else:
                # Assume it's a trait field
                # Find the column by scanning known columns
                matching_columns = [
                    col for col in self._known_columns
                    if col.endswith(f"__{field}")
                ]
                column_name = matching_columns[0] if matching_columns else field

            # Build condition based on operator
            if operator == '=':
                where_clauses.append(f"{column_name} = ${param_idx}")
                params.append(value)
            elif operator == '!=':
                where_clauses.append(f"{column_name} != ${param_idx}")
                params.append(value)
            elif operator == '<':
                where_clauses.append(f"{column_name} < ${param_idx}")
                params.append(value)
            elif operator == '>':
                where_clauses.append(f"{column_name} > ${param_idx}")
                params.append(value)
            elif operator == 'LIKE':
                where_clauses.append(f"{column_name} LIKE ${param_idx}")
                params.append(value)
            elif operator == 'IN':
                placeholders = ','.join(f'${param_idx + i}' for i in range(len(value)))
                where_clauses.append(f"{column_name} IN ({placeholders})")
                params.extend(value)
                param_idx += len(value) - 1
            elif operator == 'CONTAINS':
                where_clauses.append(f"{column_name} @> ${param_idx}::jsonb")
                params.append(json.dumps([value]))

            param_idx += 1

        # Apply WHERE clause
        if where_clauses:
            sql += f" WHERE {' AND '.join(where_clauses)}"

        # Handle ORDER BY
        sorts = query_dict.get('sort', [])
        if sorts:
            order_clauses = []
            for sort in sorts:
                field = sort['field']
                direction = sort.get('direction', 'ASC')
                # Map field to column
                if field in ('id', 'uuid', 'affinities', 'traits', 'aliases'):
                    column_name = field
                else:
                    matching_columns = [
                        col for col in self._known_columns
                        if col.endswith(f"__{field}")
                    ]
                    column_name = matching_columns[0] if matching_columns else field
                order_clauses.append(f"{column_name} {direction}")
            sql += f" ORDER BY {', '.join(order_clauses)}"

        # Handle LIMIT
        limit = query_dict.get('limit')
        if limit is not None:
            sql += f" LIMIT {limit}"

        # Handle OFFSET
        offset = query_dict.get('offset')
        if offset is not None:
            sql += f" OFFSET {offset}"

        # Execute query
        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)

        # Convert to list of dicts
        return [dict(row) for row in rows]

    async def _create_trait_columns(self, trait_columns: dict[str, Any]) -> None:
        """
        Create columns for trait fields if they don't exist.

        Args:
            trait_columns: Dict of column_name -> value
        """
        pool = await self._ensure_pool()

        for column_name, column_value in trait_columns.items():
            if column_name not in self._known_columns:
                # Validate SQL identifier to prevent injection
                column_name = _validate_sql_identifier(column_name)
                pg_type = self._get_postgres_type(column_value)

                async with pool.acquire() as conn:
                    await conn.execute(f"""
                        ALTER TABLE frags
                        ADD COLUMN IF NOT EXISTS {column_name} {pg_type}
                    """)

                self._known_columns.add(column_name)

    def _get_postgres_type(self, value: Any) -> str:
        """
        Map Python type to PostgreSQL type.

        Args:
            value: Python value to inspect

        Returns:
            PostgreSQL type string
        """
        if isinstance(value, bool):
            return "BOOLEAN"
        elif isinstance(value, int):
            return "BIGINT"
        elif isinstance(value, float):
            return "DOUBLE PRECISION"
        elif isinstance(value, (list, dict)):
            return "JSONB"
        else:
            return "TEXT"

    @asynccontextmanager
    async def transaction(
        self,
        isolation: str = 'READ COMMITTED'
    ) -> AsyncIterator['TransactionContext']:
        """
        Transaction context manager.

        Args:
            isolation: Transaction isolation level
                - 'READ UNCOMMITTED' (treated as READ COMMITTED in PostgreSQL)
                - 'READ COMMITTED' (default)
                - 'REPEATABLE READ'
                - 'SERIALIZABLE'

        Yields:
            TransactionContext with rollback capability

        Example:
            >>> async with storage.transaction():
            ...     await storage.save(frag1)
            ...     await storage.save(frag2)
            ...     # Auto-commit on clean exit

            >>> async with storage.transaction() as txn:
            ...     await storage.save(frag)
            ...     if error:
            ...         await txn.rollback()
            ...     # Otherwise auto-commit
        """
        pool = await self._ensure_pool()
        async with pool.acquire() as conn:
            async with conn.transaction(isolation=isolation):
                txn_context = TransactionContext(conn)
                try:
                    yield txn_context
                except Exception:
                    # Exception triggers automatic rollback
                    raise

    async def close(self) -> None:
        """Close connection pool gracefully."""
        if self.pool:
            await self.pool.close()
            self.pool = None


class TransactionContext:
    """Context for explicit transaction control."""

    def __init__(self, conn: asyncpg.Connection):
        self.conn = conn
        self._rolled_back = False

    async def rollback(self) -> None:
        """Explicitly rollback transaction."""
        if not self._rolled_back:
            # Note: asyncpg's transaction context handles the actual rollback
            # This just marks that we've requested it
            self._rolled_back = True
            raise TransactionRollback("Explicit rollback requested")


class TransactionRollback(Exception):
    """Raised to trigger transaction rollback."""
    pass
