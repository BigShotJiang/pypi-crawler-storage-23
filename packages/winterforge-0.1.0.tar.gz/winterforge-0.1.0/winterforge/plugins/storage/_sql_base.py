"""
Shared base class for SQL-based storage backends.

Consolidates common logic between SQLite, PostgreSQL, and future SQL backends.
Reduces ~450 lines of duplication while preserving backend-specific optimizations.
"""

from abc import ABC, abstractmethod
from typing import Any, Optional, List, Dict
import re
import json
from datetime import datetime


def _validate_sql_identifier(identifier: str) -> str:
    """
    Validate SQL identifier for use in DDL/DML statements.

    Prevents SQL injection by ensuring identifier contains only
    safe characters: alphanumeric and underscore, starting with
    letter or underscore.

    Args:
        identifier: Column/table name to validate

    Returns:
        The validated identifier

    Raises:
        ValueError: If identifier contains unsafe characters

    Examples:
        >>> _validate_sql_identifier('user_table')
        'user_table'
        >>> _validate_sql_identifier('with-history')  # doctest: +SKIP
        ValueError: Invalid SQL identifier
    """
    if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', identifier):
        raise ValueError(
            f"Invalid SQL identifier '{identifier}': "
            f"must start with letter/underscore and contain "
            f"only alphanumeric/underscore characters"
        )
    return identifier


class SQLStorageBase(ABC):
    """
    Abstract base class for SQL-based storage backends.

    Provides shared implementation of:
    - SQL identifier validation
    - Trait ID sanitization (kebab-case → snake_case)
    - Field value serialization/deserialization
    - Fieldable data column handling

    Subclasses must implement backend-specific:
    - JSON aggregation queries
    - Upsert syntax
    - Schema manipulation
    """

    def _get_sql_trait_id(self, trait_id: str) -> str:
        """
        Get SQL-safe trait identifier from metadata.

        Retrieves the pre-computed sql_identifier from trait metadata,
        which was set during trait registration. This "soft canonical"
        form converts kebab-case keys to snake_case for SQL compatibility.

        Args:
            trait_id: Trait key (e.g., 'with-history')

        Returns:
            SQL-safe identifier (e.g., 'with_history')

        Examples:
            >>> backend._get_sql_trait_id('with-history')
            'with_history'
            >>> backend._get_sql_trait_id('is-dirty')
            'is_dirty'
        """
        from winterforge.frags.traits._manager import FragTraitManager

        try:
            metadata = FragTraitManager.get_metadata(trait_id)
            return metadata.get('sql_identifier', trait_id.replace('-', '_'))
        except KeyError:
            # Trait not registered yet (shouldn't happen in normal flow)
            return trait_id.replace('-', '_')

    def _serialize_field_value(self, value: Any) -> Optional[str]:
        """
        Serialize Python value for SQL storage.

        Handles JSON serialization for complex types (list, dict)
        and ISO format for datetime objects.

        Args:
            value: Python value to serialize

        Returns:
            String representation for SQL storage, or None

        Examples:
            >>> backend._serialize_field_value([1, 2, 3])
            '[1, 2, 3]'
            >>> backend._serialize_field_value({'key': 'value'})
            '{"key": "value"}'
            >>> backend._serialize_field_value(datetime(2024, 1, 1))
            '2024-01-01T00:00:00'
        """
        if value is None:
            return None

        # DateTime → ISO 8601 string
        if isinstance(value, datetime):
            return value.isoformat()

        # Complex types → JSON
        if isinstance(value, (list, dict)):
            return json.dumps(value)

        # Primitives → string
        return str(value)

    def _deserialize_field_value(
        self,
        value: Optional[str],
        field_type_hint: Optional[type] = None
    ) -> Any:
        """
        Deserialize SQL storage value to Python type.

        Deserializes JSON arrays/objects and converts primitives based on type hint.
        Handles Optional[T] by unwrapping to T for conversion.

        Args:
            value: SQL storage value (string or None)
            field_type_hint: Expected Python type (optional, can be Optional[T])

        Returns:
            Deserialized Python value

        Examples:
            >>> backend._deserialize_field_value('[1, 2, 3]')
            [1, 2, 3]
            >>> backend._deserialize_field_value('{"key": "value"}')
            {'key': 'value'}
            >>> backend._deserialize_field_value('5432', int)
            5432
            >>> backend._deserialize_field_value('42', Optional[int])
            42
        """
        if value is None:
            return None

        # Unwrap Optional[T] to get the actual type T
        import typing
        actual_type = field_type_hint
        if field_type_hint:
            # Check if type is Optional[T] (Union[T, None])
            if hasattr(typing, 'get_origin') and hasattr(typing, 'get_args'):
                origin = typing.get_origin(field_type_hint)
                if origin is typing.Union:
                    args = typing.get_args(field_type_hint)
                    # Optional[T] is Union[T, None]
                    non_none_args = [arg for arg in args if arg is not type(None)]
                    if len(non_none_args) == 1:
                        actual_type = non_none_args[0]

        # If value is already the correct type, return it
        if actual_type and not isinstance(value, str):
            if isinstance(value, actual_type):
                return value

        # Handle string values
        if isinstance(value, str):
            # JSON arrays/objects
            if value.startswith(('[', '{')):
                try:
                    return json.loads(value)
                except (json.JSONDecodeError, ValueError):
                    pass

            # Type conversion based on hint
            if actual_type:
                try:
                    if actual_type == bool:
                        # Handle bool specially (bool('0') is True in Python)
                        return value.lower() in ('true', '1', 'yes')
                    elif actual_type in (int, float):
                        return actual_type(value)
                    elif actual_type == datetime:
                        # Parse ISO 8601 datetime string
                        return datetime.fromisoformat(value)
                    # For other types, let them handle conversion
                    elif actual_type != str:
                        return actual_type(value)
                except (ValueError, TypeError):
                    # Conversion failed - return as string
                    pass

        return value

    def _collect_fieldable_columns(
        self,
        frag: 'Frag',
        trait_columns: Dict[str, Any]
    ) -> None:
        """
        Extract Pydantic fields from _fieldable_data to normalized columns.

        Fieldable trait stores structured data in a Pydantic model.
        This method flattens model fields into individual SQL columns
        with the naming pattern: fieldable__<field_name>

        Args:
            frag: Frag instance with _fieldable_data
            trait_columns: Dict to populate with column_name → value

        Side Effects:
            Modifies trait_columns dict in place

        Examples:
            >>> frag._fieldable_data = FieldableSchema(title="Test", count=42)
            >>> columns = {}
            >>> backend._collect_fieldable_columns(frag, columns)
            >>> columns
            {'fieldable__title': 'Test', 'fieldable__count': '42'}
        """
        if not hasattr(frag, '_fieldable_data') or frag._fieldable_data is None:
            return

        schema = frag._fieldable_data

        # Extract fields from Pydantic model
        if hasattr(schema, 'model_dump'):
            # Pydantic v2
            field_data = schema.model_dump()
        elif hasattr(schema, 'dict'):
            # Pydantic v1
            field_data = schema.dict()
        else:
            return

        # Flatten to normalized columns: fieldable__<field> → value
        for field_name, field_value in field_data.items():
            if field_value is not None:
                column_name = f"fieldable__{field_name}"
                trait_columns[column_name] = self._serialize_field_value(field_value)

    def _load_fieldable_fields(self, frag: 'Frag', row: Dict[str, Any]) -> None:
        """
        Reconstruct Pydantic model from normalized SQL columns.

        Inverse of _collect_fieldable_columns. Scans row for fieldable__*
        columns and rebuilds the _fieldable_data Pydantic model.

        Args:
            frag: Frag instance to populate
            row: SQL row dict with column_name → value

        Side Effects:
            Sets frag._fieldable_data if fieldable columns found

        Examples:
            >>> row = {'fieldable__title': 'Test', 'fieldable__count': '42'}
            >>> backend._load_fieldable_fields(frag, row)
            >>> frag._fieldable_data.title
            'Test'
            >>> frag._fieldable_data.count
            42
        """
        if not hasattr(frag, '_fieldable_schema'):
            return

        # Collect fieldable__* columns from row
        field_data = {}
        for column_name, value in row.items():
            if column_name.startswith('fieldable__'):
                field_name = column_name.replace('fieldable__', '', 1)
                field_data[field_name] = self._deserialize_field_value(value)

        if not field_data:
            return

        # Reconstruct Pydantic model
        try:
            frag._fieldable_data = frag._fieldable_schema(**field_data)
        except Exception:
            # Schema mismatch - skip fieldable reconstruction
            pass

    # === Abstract methods - must be implemented by subclasses ===

    @abstractmethod
    async def save(self, frag: 'Frag') -> None:
        """
        Save Frag to storage.

        Must implement backend-specific upsert logic.
        """
        pass

    @abstractmethod
    async def load(self, frag_id: int) -> Optional['Frag']:
        """
        Load Frag by ID.

        Must implement backend-specific SELECT logic.
        """
        pass

    @abstractmethod
    async def query(
        self,
        affinities: Optional[List[str]] = None,
        traits: Optional[List[str]] = None,
        **conditions: Any
    ) -> 'Manifest':
        """
        Query Frags by composition and field conditions.

        Must implement backend-specific WHERE clause construction.
        """
        pass
