"""SQLite storage backend for Frags."""

from __future__ import annotations

import asyncio
import sqlite3
import json
from typing import Optional, List, Dict, Any
from winterforge.frags import Frag
from winterforge.plugins.decorators import storage_backend, root
from winterforge.plugins.slug_convertors import SlugConvertorManager
from winterforge.plugins.storage._sql_base import (
    SQLStorageBase,
    _validate_sql_identifier
)

try:
    from pydantic import BaseModel as PydanticBaseModel
    HAS_PYDANTIC = True
except ImportError:
    PydanticBaseModel = object  # Fallback type
    HAS_PYDANTIC = False


@storage_backend()
@root('sqlite')
class SQLiteStorageBackend(SQLStorageBase):
    """
    Simple SQLite storage backend for Frags.

    Uses single table with composition-based schema:
    - id: Global Frag ID
    - affinities: JSON array of affinity tags
    - traits: JSON array of trait IDs
    - aliases: JSON object of alias relationships
    - Dynamic columns for trait fields

    This is a reference implementation demonstrating the composition model.
    """

    def __init__(self, db_path: str = ':memory:') -> None:
        """
        Initialize SQLite storage backend.

        Args:
            db_path: Path to SQLite database file (default: in-memory)
        """
        self.db_path = db_path
        # check_same_thread=False allows async/await with asyncio.to_thread()
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row  # Access columns by name
        self._init_schema()
        self._sync_id_counter()
        self._ensure_registered_trait_columns()

    @staticmethod
    def _sanitize_field_name(field_name: str) -> str:
        """
        Sanitize field name for SQL column names.

        SQL column names cannot contain hyphens. Always convert to underscores.
        Strip leading underscores from Python private fields.

        Args:
            field_name: Field name (may contain hyphens or leading underscore)

        Returns:
            SQL-safe field name (only underscores, alphanumeric)
        """
        # Replace hyphens with underscores (for slugs: db-path → db_path)
        sanitized = field_name.replace('-', '_')
        # Strip leading underscores (for Python fields: _count → count)
        return sanitized.lstrip('_')

    def _init_schema(self) -> None:
        """Initialize database schema."""
        cursor = self.conn.cursor()

        # Create frags table with core composition fields
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS frags (
                id INTEGER PRIMARY KEY,
                uuid TEXT NOT NULL UNIQUE,
                affinities TEXT NOT NULL DEFAULT '[]',
                traits TEXT NOT NULL DEFAULT '[]',
                aliases TEXT NOT NULL DEFAULT '{}'
            )
        """)

        # Create index on affinities for fast queries
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_affinities
            ON frags(affinities)
        """)

        # Create index on traits
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_traits
            ON frags(traits)
        """)

        # Create unique index on UUID
        cursor.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_uuid
            ON frags(uuid)
        """)

        self.conn.commit()

    def _sync_id_counter(self) -> None:
        """
        Sync the Frag ID counter with the database.

        This ensures new Frags get IDs that don't conflict with existing ones.
        """
        cursor = self.conn.cursor()
        cursor.execute("SELECT MAX(id) FROM frags")
        result = cursor.fetchone()
        max_id = result[0] if result and result[0] is not None else 0

        # Reset the global Frag counter to start after the max ID
        import itertools
        Frag._id_counter = itertools.count(max_id + 1)

    def _ensure_registered_trait_columns(self) -> None:
        """
        Ensure columns exist for all registered traits.

        This eagerly creates schema columns for traits that are registered
        in the system, preventing "column not found" errors during queries.
        """
        from winterforge.frags.traits._manager import FragTraitManager

        # Get all registered traits
        trait_repository = FragTraitManager.repository()
        trait_ids = trait_repository.ids()

        for trait_id in trait_ids:
            if not FragTraitManager.has(trait_id):
                continue

            try:
                # Get trait field definitions
                trait_fields = FragTraitManager.get_trait_fields(trait_id)

                # Ensure columns exist for each field
                for field_name, field_info in trait_fields.items():
                    # Skip internal fields (except _storage_backend)
                    if field_name.startswith('_') and field_name != '_storage_backend':
                        continue

                    # Create column if it doesn't exist
                    # Use TEXT as default type - safer than trying to infer
                    column_name = f"{trait_id}__{self._sanitize_field_name(field_name)}"
                    self._ensure_column_exists(column_name, None)
            except Exception:
                # Skip traits that can't be introspected
                continue

    def _ensure_column_exists(self, column_name: str, field_type: type = None) -> None:
        """
        Ensure a column exists in the frags table.

        Args:
            column_name: Name of the column to create
            field_type: Python type of the field (for SQL type mapping)
        """
        cursor = self.conn.cursor()

        # Check if column already exists
        cursor.execute("PRAGMA table_info(frags)")
        existing_columns = [row[1] for row in cursor.fetchall()]

        if column_name in existing_columns:
            return  # Column already exists

        # Determine SQL type
        if field_type is None:
            sql_type = "TEXT"
        elif field_type == bool:
            sql_type = "INTEGER"  # SQLite stores booleans as integers
        elif field_type == int:
            sql_type = "INTEGER"
        elif field_type == float:
            sql_type = "REAL"
        elif field_type in (list, dict):
            sql_type = "TEXT"  # Store as JSON
        else:
            sql_type = "TEXT"  # Default to TEXT for unknown types

        # Add column to table
        try:
            cursor.execute(f"ALTER TABLE frags ADD COLUMN {column_name} {sql_type}")
            self.conn.commit()
        except Exception:
            # Column might have been added by another process
            pass

    async def save(self, frag: Any) -> None:
        """
        Persist a Frag to storage.

        Args:
            frag: Frag instance to save
        """
        def _save_sync():
            cursor = self.conn.cursor()

            # Serialize composition fields (use properties)
            affinities_json = json.dumps(frag.affinities)
            traits_json = json.dumps(frag.traits)
            aliases_json = json.dumps(frag.aliases)
            frag_id = frag.id
            frag_uuid = frag.uuid

            # Check if Frag exists in database
            cursor.execute("SELECT id FROM frags WHERE id = ?", (frag_id,))
            exists = cursor.fetchone() is not None

            if exists:
                # Update existing
                sql = """
                    UPDATE frags
                    SET uuid = ?, affinities = ?, traits = ?, aliases = ?
                    WHERE id = ?
                """
                cursor.execute(sql, (frag_uuid, affinities_json, traits_json, aliases_json, frag_id))
            else:
                # Insert new with ID from counter (synced with database)
                sql = """
                    INSERT INTO frags (id, uuid, affinities, traits, aliases)
                    VALUES (?, ?, ?, ?, ?)
                """
                cursor.execute(sql, (frag_id, frag_uuid, affinities_json, traits_json, aliases_json))

            # Save trait fields (use composed traits to include dependencies)
            composed_traits = (
                getattr(frag, '_composed_traits', set()) or set(frag.traits)
            )
            if composed_traits:
                self._save_trait_fields(frag, cursor, exists, composed_traits)

            self.conn.commit()

        await asyncio.to_thread(_save_sync)

    def _save_trait_fields(
        self,
        frag: Any,
        cursor: Any,
        exists: bool,
        composed_traits: set
    ) -> None:
        """
        Save trait field values to normalized columns.

        Creates columns for new traits and stores field values.
        For fieldable's Pydantic data, extracts individual fields
        to {trait}_{field_name} columns using _field_origins mapping.

        Args:
            frag: Frag instance
            cursor: Database cursor
            exists: Whether Frag already exists in database
            composed_traits: Set of all composed trait IDs (includes dependencies)
        """
        from winterforge.frags.traits._manager import FragTraitManager

        set_clauses = []
        values = []

        for trait_id in composed_traits:
            # Ensure columns exist for this trait
            self._ensure_trait_columns(trait_id, cursor)

            # Get trait fields
            trait_fields = FragTraitManager.get_trait_fields(trait_id)

            # Save regular trait fields (metadata, etc.)
            for field_name in trait_fields.keys():
                # Skip Pydantic model and schema (handled separately)
                if field_name in ('_fieldable_schema', '_fieldable_data'):
                    continue

                column_name = f"{self._get_sql_trait_id(trait_id)}__{self._sanitize_field_name(field_name)}"
                if hasattr(frag, field_name):
                    field_value = getattr(frag, field_name)

                    # Skip non-serializable types
                    if isinstance(field_value, type):
                        continue

                    # Serialize using base class method
                    field_value = self._serialize_field_value(field_value)

                    set_clauses.append(f"{column_name} = ?")
                    values.append(field_value)

            # Special handling for fieldable Pydantic data
            if trait_id == 'fieldable' and hasattr(frag, '_fieldable_data'):
                # Save individual fields from Pydantic model to normalized columns
                self._save_fieldable_fields(frag, cursor, set_clauses, values)

        # Execute single UPDATE with all fields
        if set_clauses:
            sql = f"UPDATE frags SET {', '.join(set_clauses)} WHERE id = ?"
            values.append(frag.id)
            cursor.execute(sql, values)

    def _save_fieldable_fields(
        self,
        frag: Any,
        cursor: Any,
        set_clauses: list,
        values: list
    ) -> None:
        """
        Save individual fields from Pydantic model to normalized columns.

        Uses _field_origins mapping to determine {trait}_{field_name} columns.

        Args:
            frag: Frag instance
            cursor: Database cursor
            set_clauses: List to append SET clauses to
            values: List to append values to
        """
        if not hasattr(frag, '_fieldable_data') or frag._fieldable_data is None:
            return

        fieldable_data = frag._fieldable_data
        field_origins = getattr(frag, '_field_origins', {})

        # Get all field values from Pydantic model
        if hasattr(fieldable_data, 'model_dump'):
            field_values = fieldable_data.model_dump()
        else:
            field_values = fieldable_data.dict()

        # Save each field to its {trait}_{field_name} column
        for field_name, field_value in field_values.items():
            # Determine source trait (default to 'fieldable' if not tracked)
            source_trait = field_origins.get(field_name, 'fieldable')
            column_name = f"{source_trait}__{self._sanitize_field_name(field_name)}"

            # Ensure column exists
            self._ensure_field_column(source_trait, field_name, cursor)

            # Serialize using base class method
            field_value = self._serialize_field_value(field_value)

            set_clauses.append(f"{column_name} = ?")
            values.append(field_value)

    def _ensure_field_column(
        self,
        trait_id: str,
        field_name: str,
        cursor: Any
    ) -> None:
        """
        Ensure a field column exists for normalized storage.

        Args:
            trait_id: Source trait ID
            field_name: Field name
            cursor: Database cursor
        """
        # Sanitize both trait ID and field name for SQL (hyphens → underscores)
        sanitized_trait_id = self._get_sql_trait_id(trait_id)
        sanitized_field_name = self._sanitize_field_name(field_name)
        column_name = f"{sanitized_trait_id}__{sanitized_field_name}"

        # Validate SQL identifier to prevent injection
        column_name = _validate_sql_identifier(column_name)

        # Check if column exists
        cursor.execute("PRAGMA table_info(frags)")
        columns = [row[1] for row in cursor.fetchall()]

        if column_name not in columns:
            cursor.execute(f"ALTER TABLE frags ADD COLUMN {column_name} TEXT")

    def _ensure_trait_columns(self, trait_id: str, cursor: Any) -> None:
        """
        Ensure trait columns exist in database.

        Args:
            trait_id: Trait identifier
            cursor: Database cursor
        """
        from winterforge.frags.traits._manager import FragTraitManager

        trait_fields = FragTraitManager.get_trait_fields(trait_id)

        for field_name, field_info in trait_fields.items():
            column_name = f"{self._get_sql_trait_id(trait_id)}__{self._sanitize_field_name(field_name)}"

            # Validate SQL identifier to prevent injection
            column_name = _validate_sql_identifier(column_name)

            # Check if column exists
            cursor.execute("PRAGMA table_info(frags)")
            columns = [row[1] for row in cursor.fetchall()]

            if column_name not in columns:
                # Determine column type from default value
                field_value = field_info.default_value
                if isinstance(field_value, int):
                    col_type = "INTEGER"
                elif isinstance(field_value, float):
                    col_type = "REAL"
                else:
                    col_type = "TEXT"

                # Add column
                cursor.execute(f"ALTER TABLE frags ADD COLUMN {column_name} {col_type}")

    async def load(self, frag_id: int) -> Optional[Any]:
        """
        Load a Frag from storage by ID.

        Args:
            frag_id: Global Frag ID

        Returns:
            Frag instance or None if not found
        """
        def _load_sync():
            cursor = self.conn.cursor()
            cursor.execute("SELECT * FROM frags WHERE id = ?", (frag_id,))
            row = cursor.fetchone()

            if row is None:
                return None

            return self._row_to_frag(row)

        return await asyncio.to_thread(_load_sync)

    def _load_fieldable_fields(self, frag: Any, row: Any) -> None:
        """
        Load fieldable fields from normalized {trait}_{field_name} columns.

        Collects all field values and reconstructs the Pydantic model.

        Args:
            frag: Frag instance
            row: Database row
        """
        # Ensure schema is built
        if hasattr(frag, '_ensure_schema'):
            frag._ensure_schema()
        else:
            return

        # Get field origins mapping
        field_origins = getattr(frag, '_field_origins', {})

        # Collect field values from all {trait}_{field_name} columns
        field_values = {}
        row_keys = row.keys()

        for field_name, source_trait in field_origins.items():
            column_name = f"{source_trait}__{self._sanitize_field_name(field_name)}"

            if column_name in row_keys:
                value = row[column_name]

                # Deserialize using base class method
                value = self._deserialize_field_value(value)

                field_values[field_name] = value

        # Reconstruct Pydantic model if we have data
        if field_values and hasattr(frag, '_fieldable_schema') and frag._fieldable_schema:
            frag._fieldable_data = frag._fieldable_schema(**field_values)

    def _row_to_frag(self, row: Any) -> Frag:
        """
        Convert database row to Frag instance.

        Loads trait fields and reconstructs Pydantic model from
        normalized {trait}_{field_name} columns.

        Args:
            row: Database row

        Returns:
            Frag instance
        """
        from winterforge.frags.traits._manager import FragTraitManager

        # Deserialize composition fields
        affinities = json.loads(row['affinities'])
        traits = json.loads(row['traits'])
        aliases = json.loads(row['aliases'])

        # Create Frag
        frag = Frag(affinities=affinities, traits=traits, aliases=aliases)

        # Override ID with stored value (using internal method)
        frag._set_id(row['id'])

        # Restore UUID from storage (using internal method)
        frag._set_uuid(row['uuid'])

        # Load trait field values (use composed traits to include dependencies)
        composed_traits = (
            getattr(frag, '_composed_traits', set()) or set(traits)
        )
        for trait_id in composed_traits:
            trait_fields = FragTraitManager.get_trait_fields(trait_id)

            # Get trait class to access type annotations
            trait_class = FragTraitManager.get(trait_id)

            for field_name, field_info in trait_fields.items():
                # Skip _fieldable_data and _fieldable_schema (handled separately)
                if field_name in ('_fieldable_data', '_fieldable_schema'):
                    continue

                # Skip read-only fields (handled by fieldable trait)
                if not field_info.writable:
                    continue

                # field_name is private attribute like '_field_refs'
                column_name = f"{self._get_sql_trait_id(trait_id)}__{self._sanitize_field_name(field_name)}"
                if column_name in row.keys():
                    value = row[column_name]

                    # Deserialize using base class method
                    # Note: Type conversion must happen based on type hints
                    if value is not None and isinstance(value, str):
                        # Import datetime for comparison
                        from datetime import datetime

                        # Check field type annotation
                        annotations = getattr(trait_class, '__annotations__', {})
                        field_type_str = str(annotations.get(field_name, ''))

                        # Check if annotation contains 'datetime', 'date', or 'time'
                        is_datetime_field = any(dt_type in field_type_str
                                               for dt_type in ['datetime', 'date', 'time'])

                        if is_datetime_field:
                            # Field expects datetime - convert from ISO string
                            if 'T' in value or '-' in value[:10]:  # Likely ISO datetime
                                try:
                                    value = datetime.fromisoformat(value)
                                except (ValueError, TypeError):
                                    pass  # Keep as string if conversion fails
                        elif field_type_str in ('int', 'Optional[int]'):
                            # Field expects int (not List[int] or other composite)
                            try:
                                value = int(value)
                            except (ValueError, TypeError):
                                pass  # Keep as string if conversion fails
                        elif field_type_str in ('float', 'Optional[float]'):
                            # Field expects float (not List[float] or other composite)
                            try:
                                value = float(value)
                            except (ValueError, TypeError):
                                pass  # Keep as string if conversion fails
                        elif field_type_str in ('bool', 'Optional[bool]'):
                            # Field expects bool - convert from string
                            if value.lower() in ('true', '1', 'yes'):
                                value = True
                            elif value.lower() in ('false', '0', 'no'):
                                value = False
                        else:
                            # Use base class deserialization for other types
                            value = self._deserialize_field_value(value)

                    # Set using field_info (storage backend privilege)
                    field_info.set(frag, value)

        # After loading all trait fields, reconstruct fieldable Pydantic model from normalized columns
        if 'fieldable' in composed_traits:
            self._load_fieldable_fields(frag, row)

        return frag

    async def delete(self, frag_id: int) -> bool:
        """
        Delete a Frag from storage by ID.

        Args:
            frag_id: Global Frag ID

        Returns:
            True if deleted, False if not found
        """
        def _delete_sync():
            cursor = self.conn.cursor()
            cursor.execute("DELETE FROM frags WHERE id = ?", (frag_id,))
            self.conn.commit()
            return cursor.rowcount > 0

        return await asyncio.to_thread(_delete_sync)

    def query(self) -> 'QueryRepository':
        """
        Return query builder for this storage backend.

        Returns:
            QueryRepository configured with this storage

        Example:
            # Fluent query API
            results = await storage.query()\\
                .affinity('user')\\
                .trait('titled')\\
                .condition('active', True)\\
                .sort('created_at', 'DESC')\\
                .limit(10)\\
                .execute()

            # Get first result
            user = await storage.query().affinity('user').first()
        """
        from winterforge.plugins.query._repository import QueryRepository
        return QueryRepository(storage=self)

    async def get_distinct_affinities(self) -> List[str]:
        """
        Get all unique affinities without loading Frags.

        Uses SQLite JSON aggregation to extract affinities
        directly from the database.

        Returns:
            Sorted list of unique affinity strings
        """
        def _get_affinities_sync():
            cursor = self.conn.cursor()

            # Use json_each to extract all affinities
            cursor.execute("""
                SELECT DISTINCT json_each.value
                FROM frags, json_each(frags.affinities)
                ORDER BY json_each.value
            """)

            return [row[0] for row in cursor.fetchall()]

        return await asyncio.to_thread(_get_affinities_sync)

    async def get_distinct_traits(self) -> List[str]:
        """
        Get all unique traits without loading Frags.

        Uses SQLite JSON aggregation to extract traits
        directly from the database.

        Returns:
            Sorted list of unique trait strings
        """
        def _get_traits_sync():
            cursor = self.conn.cursor()

            # Use json_each to extract all traits
            cursor.execute("""
                SELECT DISTINCT json_each.value
                FROM frags, json_each(frags.traits)
                ORDER BY json_each.value
            """)

            return [row[0] for row in cursor.fetchall()]

        return await asyncio.to_thread(_get_traits_sync)

    async def get_affinity_counts(self) -> Dict[str, int]:
        """
        Get affinity usage counts without loading Frags.

        Uses SQLite JSON aggregation to count affinity
        occurrences directly from the database.

        Returns:
            Dict mapping affinity name to count, sorted by affinity
        """
        def _get_counts_sync():
            cursor = self.conn.cursor()

            # Count occurrences of each affinity
            cursor.execute("""
                SELECT json_each.value, COUNT(*) as count
                FROM frags, json_each(frags.affinities)
                GROUP BY json_each.value
                ORDER BY json_each.value
            """)

            return dict(cursor.fetchall())

        return await asyncio.to_thread(_get_counts_sync)

    async def get_trait_counts(self) -> Dict[str, int]:
        """
        Get trait usage counts without loading Frags.

        Uses SQLite JSON aggregation to count trait
        occurrences directly from the database.

        Returns:
            Dict mapping trait name to count, sorted by trait
        """
        def _get_counts_sync():
            cursor = self.conn.cursor()

            # Count occurrences of each trait
            cursor.execute("""
                SELECT json_each.value, COUNT(*) as count
                FROM frags, json_each(frags.traits)
                GROUP BY json_each.value
                ORDER BY json_each.value
            """)

            return dict(cursor.fetchall())

        return await asyncio.to_thread(_get_counts_sync)

    def get_trait_columns(self, traits: List[str]) -> List[str]:
        """
        Get storage column names for given trait IDs.

        Args:
            traits: List of trait IDs

        Returns:
            List of column names in storage
        """
        from winterforge.frags.traits._manager import FragTraitManager

        columns = []
        for trait_id in traits:
            trait_fields = FragTraitManager.get_trait_fields(trait_id)
            for field_name in trait_fields.keys():
                columns.append(f"{self._get_sql_trait_id(trait_id)}__{self._sanitize_field_name(field_name)}")
        return columns

    def create_trait_columns(self, trait_id: str, fields: Dict[str, Any]) -> None:
        """
        Add storage columns for a newly registered trait.

        Args:
            trait_id: Trait identifier
            fields: Field definitions from trait
        """
        cursor = self.conn.cursor()

        for field_name, field_value in fields.items():
            column_name = f"{self._get_sql_trait_id(trait_id)}__{self._sanitize_field_name(field_name)}"

            # Validate SQL identifier to prevent injection
            column_name = _validate_sql_identifier(column_name)

            # Determine column type
            if isinstance(field_value, int):
                col_type = "INTEGER"
            elif isinstance(field_value, float):
                col_type = "REAL"
            else:
                col_type = "TEXT"

            # Add column (if not exists is handled by trying)
            try:
                cursor.execute(f"ALTER TABLE frags ADD COLUMN {column_name} {col_type}")
                self.conn.commit()
            except sqlite3.OperationalError:
                # Column already exists
                pass

    async def get_table_columns(self, table_name: str) -> List[str]:
        """
        Get list of column names for a table.

        Args:
            table_name: Name of table to inspect

        Returns:
            List of column names
        """
        table_name = _validate_sql_identifier(table_name)
        cursor = self.conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name})")
        return [row[1] for row in cursor.fetchall()]

    async def count_column_usage(self, column_name: str) -> int:
        """
        Count rows with non-null values in a column.

        Args:
            column_name: Column to check

        Returns:
            Number of rows with data in this column
        """
        column_name = _validate_sql_identifier(column_name)
        cursor = self.conn.cursor()
        cursor.execute(
            f"SELECT COUNT(*) FROM frags WHERE {column_name} IS NOT NULL"
        )
        return cursor.fetchone()[0]

    async def drop_column(self, table_name: str, column_name: str) -> None:
        """
        Drop a column from a table.

        Note: SQLite doesn't support DROP COLUMN directly,
        so this recreates the table without the column.

        Args:
            table_name: Table to modify
            column_name: Column to drop
        """
        table_name = _validate_sql_identifier(table_name)
        column_name = _validate_sql_identifier(column_name)
        cursor = self.conn.cursor()

        # Get current columns
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns = [(row[1], row[2]) for row in cursor.fetchall()]

        # Remove target column
        columns = [(name, type_) for name, type_ in columns if name != column_name]

        if not columns:
            return  # Can't drop all columns

        # Create new table
        # Validate all column names from database
        validated_columns = [
            (_validate_sql_identifier(name), type_)
            for name, type_ in columns
        ]
        column_defs = ", ".join(f"{name} {type_}" for name, type_ in validated_columns)
        cursor.execute(f"CREATE TABLE {table_name}_new ({column_defs})")

        # Copy data
        column_names = ", ".join(name for name, _ in validated_columns)
        cursor.execute(
            f"INSERT INTO {table_name}_new ({column_names}) "
            f"SELECT {column_names} FROM {table_name}"
        )

        # Replace old table
        cursor.execute(f"DROP TABLE {table_name}")
        cursor.execute(f"ALTER TABLE {table_name}_new RENAME TO {table_name}")

        self.conn.commit()

    async def execute(self, query_dict: dict) -> List[dict]:
        """
        Execute query and return rows as dicts.

        Args:
            query_dict: Query specification dict with:
                - affinities: list of affinity tags (AND logic)
                - traits: list of trait IDs (AND logic)
                - conditions: list of condition dicts
                - sort: list of sort dicts
                - limit: int or None
                - offset: int or None

        Returns:
            List of row dicts with column names as keys
        """
        cursor = self.conn.cursor()

        # Build SQL
        sql = "SELECT * FROM frags"
        params = []
        where_clauses = []

        # Handle affinities (AND logic - all must be present)
        affinities = query_dict.get('affinities', [])
        for affinity in affinities:
            where_clauses.append("affinities LIKE ?")
            params.append(f'%"{affinity}"%')

        # Handle traits (AND logic - all must be present)
        traits = query_dict.get('traits', [])
        for trait in traits:
            where_clauses.append("traits LIKE ?")
            params.append(f'%"{trait}"%')

        # Build WHERE clause from conditions
        conditions = query_dict.get('conditions', [])
        for cond in conditions:
                field = cond['field']
                value = cond['value']
                operator = cond['operator']

                # Map field name to column name
                column_name = self._map_field_to_column(field)

                # Skip if column doesn't exist (schema not initialized yet)
                if column_name is None:
                    continue

                # Build condition
                if operator == '=':
                    # Special handling for JSON fields
                    if field in ('affinities', 'traits', 'aliases'):
                        # JSON containment check
                        where_clauses.append(f"{column_name} LIKE ?")
                        params.append(f'%"{value}"%')
                    else:
                        where_clauses.append(f"{column_name} = ?")
                        params.append(value)
                elif operator == '!=':
                    where_clauses.append(f"{column_name} != ?")
                    params.append(value)
                elif operator == '<':
                    where_clauses.append(f"{column_name} < ?")
                    params.append(value)
                elif operator == '>':
                    where_clauses.append(f"{column_name} > ?")
                    params.append(value)
                elif operator == 'LIKE':
                    where_clauses.append(f"{column_name} LIKE ?")
                    params.append(value)
                elif operator == 'IN':
                    placeholders = ','.join('?' * len(value))
                    where_clauses.append(f"{column_name} IN ({placeholders})")
                    params.extend(value)
                elif operator == 'CONTAINS':
                    # For JSON fields (affinities, traits, etc)
                    where_clauses.append(f"{column_name} LIKE ?")
                    params.append(f'%"{value}"%')

        # Apply WHERE clause if any conditions exist
        if where_clauses:
            sql += f" WHERE {' AND '.join(where_clauses)}"

        # Build ORDER BY
        sorts = query_dict.get('sort', [])
        if sorts:
            order_clauses = []
            for sort in sorts:
                field = sort['field']
                direction = sort.get('direction', 'ASC')
                column_name = self._map_field_to_column(field)
                # Skip if column doesn't exist
                if column_name is not None:
                    order_clauses.append(f"{column_name} {direction}")
            if order_clauses:
                sql += f" ORDER BY {', '.join(order_clauses)}"

        # Add LIMIT
        limit = query_dict.get('limit')
        if limit is not None:
            sql += f" LIMIT {limit}"

        # Add OFFSET
        offset = query_dict.get('offset')
        if offset is not None:
            sql += f" OFFSET {offset}"

        # Execute
        cursor.execute(sql, params)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        return [dict(zip(columns, row)) for row in rows]

    def _map_field_to_column(self, field: str) -> str | None:
        """
        Map field name to database column name.

        Args:
            field: Field name (e.g., 'title', 'affinities')

        Returns:
            Column name (e.g., 'titled__title', 'affinities') or None if not found
        """
        # Core composition fields
        if field in ('id', 'uuid', 'affinities', 'traits', 'aliases'):
            return field

        # Schema fields - check which trait contributes this field
        # Common patterns: titled__title, sluggable__slug, etc.
        # Check database schema to find the actual column
        cursor = self.conn.cursor()
        cursor.execute("PRAGMA table_info(frags)")
        columns = [row[1] for row in cursor.fetchall()]

        # Look for {trait}__{field} pattern
        for column in columns:
            if '__' in column and column.endswith(f"__{field}"):
                return column

        # Check if field exists as a direct column
        if field in columns:
            return field

        # Column doesn't exist - return None to skip this condition
        return None

