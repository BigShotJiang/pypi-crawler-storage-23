"""Environment variable storage backend for Frags.

Read-only storage that exposes environment variables as Frags.
Perfect for:
- Deployment configuration
- Runtime overrides
- Container/cloud environments
- Immutable configuration sources

Each environment variable becomes a Frag with 'config' affinity.
"""

from __future__ import annotations

import os
from typing import Any, Optional, List, Dict

from winterforge.plugins import storage_backend
from winterforge.plugins.decorators import root
from winterforge.frags.manifest import Manifest


@storage_backend()
@root('env')
class EnvStorageBackend:
    """
    Read-only environment variable storage backend.

    Exposes environment variables as Frags with 'config' affinity.
    Each env var matching the prefix becomes a Frag:
    - Affinity: ['config']
    - Traits: ['sluggable', 'titled']
    - Slug: env var key (lowercased with dots)
    - Title: env var value

    This backend is read-only - save() and delete() raise NotImplementedError.

    Examples:
        # Environment:
        # WINTERFORGE_DATABASE_HOST=localhost
        # WINTERFORGE_DATABASE_PORT=5432

        storage = EnvStorageBackend(prefix='WINTERFORGE_')

        # Query for config
        configs = await storage.query().affinity('config').execute()

        # Access via FragRegistry
        config = FragRegistry({'affinities': ['config']})
        db_host = config.get('database.host')  # Resolves by slug
        print(db_host.title)  # → 'localhost'
    """

    def __init__(self, prefix: str = 'WINTERFORGE_'):
        """
        Initialize environment variable storage backend.

        Args:
            prefix: Prefix for environment variables to include
                   (default: 'WINTERFORGE_')
        """
        self.prefix = prefix

        # Create a mapping of slug -> (frag_id, env_key, env_value)
        self._env_frags: Dict[str, tuple[int, str, str]] = {}
        self._load_env_vars()

    def _load_env_vars(self) -> None:
        """Scan environment variables and build Frag mapping."""
        frag_id = 1

        for key, value in os.environ.items():
            if key.startswith(self.prefix):
                # Remove prefix and convert to slug format
                # WINTERFORGE_DATABASE_HOST → database.host
                slug_key = key[len(self.prefix):].lower().replace('_', '.')

                self._env_frags[slug_key] = (frag_id, key, value)
                frag_id += 1

    def _create_frag_from_env(self, frag_id: int, env_key: str, env_value: str, slug: str) -> Any:
        """
        Create a Frag from environment variable data.

        Args:
            frag_id: Frag ID
            env_key: Original environment variable name
            env_value: Environment variable value
            slug: Computed slug from env key

        Returns:
            Frag instance with config affinity and env data
        """
        from winterforge.frags.base import Frag

        # Create Frag with config affinity
        frag = Frag(
            affinities=['config'],
            traits=['sluggable', 'titled']
        )

        # Set ID (bypass normal ID generation)
        object.__setattr__(frag, '_id', frag_id)

        # Set fields from environment variable
        frag.set_slug(slug)
        frag.set_title(self._coerce_value(env_value))

        # Mark as not changed (it's from read-only source)
        object.__setattr__(frag, '_changed', False)

        return frag

    def _coerce_value(self, value: str) -> Any:
        """
        Coerce environment variable string to appropriate type.

        Tries to convert to bool, int, float, or keeps as string.

        Args:
            value: Environment variable string value

        Returns:
            Coerced value
        """
        # Boolean
        if value.lower() in ('true', 'yes', '1', 'on'):
            return True
        if value.lower() in ('false', 'no', '0', 'off'):
            return False

        # Integer
        try:
            return int(value)
        except ValueError:
            pass

        # Float
        try:
            return float(value)
        except ValueError:
            pass

        # String
        return value

    async def save(self, frag: Any) -> None:
        """
        Not supported - environment storage is read-only.

        Raises:
            NotImplementedError: Always, as env storage is immutable
        """
        raise NotImplementedError(
            "Environment variable storage is read-only. "
            "Use YAML, SQLite, or PostgreSQL storage for writable config."
        )

    async def load(self, frag_id: int) -> Optional[Any]:
        """
        Load a Frag from environment variables by ID.

        Args:
            frag_id: Frag ID

        Returns:
            Frag instance or None if not found
        """
        # Find env var with matching frag_id (in-memory, no I/O needed)
        for slug, (env_frag_id, env_key, env_value) in self._env_frags.items():
            if env_frag_id == frag_id:
                return self._create_frag_from_env(frag_id, env_key, env_value, slug)

        return None

    async def delete(self, frag_id: int) -> bool:
        """
        Not supported - environment storage is read-only.

        Raises:
            NotImplementedError: Always, as env storage is immutable
        """
        raise NotImplementedError(
            "Environment variable storage is read-only. "
            "Cannot delete environment variables."
        )

    def query(self) -> 'QueryRepository':
        """
        Return query builder for this storage backend.

        Returns:
            QueryRepository configured with this storage

        Example:
            results = await storage.query()\\
                .affinity('config')\\
                .condition('slug', 'database.host')\\
                .execute()
        """
        from winterforge.plugins.query._repository import QueryRepository
        return QueryRepository(storage=self)

    async def execute(self, query_dict: dict) -> List[dict]:
        """
        Execute query and return rows as dicts.

        Env backend filters env vars in memory.

        Args:
            query_dict: Query specification dict with:
                - affinities: list of affinity tags (AND logic)
                - traits: list of trait IDs (AND logic)
                - conditions: list of condition dicts
                - sort: list of sort dicts
                - limit: int or None
                - offset: int or None

        Returns:
            List of row dicts with config Frag data
        """
        results = []

        # Extract query parameters
        affinities = query_dict.get('affinities', [])
        traits = query_dict.get('traits', [])
        conditions = query_dict.get('conditions', [])
        sorts = query_dict.get('sort', [])
        limit = query_dict.get('limit')
        offset = query_dict.get('offset')

        # All env frags have 'config' affinity and 'sluggable', 'titled' traits
        env_affinities = ['config']
        env_traits = ['sluggable', 'titled']

        # Filter by affinities (must include 'config')
        if affinities and not all(aff in env_affinities for aff in affinities):
            return []

        # Filter by traits (must be subset of available)
        if traits and not all(trait in env_traits for trait in traits):
            return []

        # Build results from env vars
        for slug, (frag_id, env_key, env_value) in self._env_frags.items():
            row = {
                'id': frag_id,
                'affinities': env_affinities,
                'traits': env_traits,
                'aliases': {},
                'slug': slug,
                'title': env_value,
                'env_key': env_key
            }

            # Filter by conditions
            if conditions:
                match = True
                for cond in conditions:
                    field = cond['field']
                    value = cond['value']
                    operator = cond['operator']

                    field_value = row.get(field)
                    if field_value is None:
                        match = False
                        break

                    # Apply operator
                    if operator == '=' and field_value != value:
                        match = False
                        break
                    elif operator == '!=' and field_value == value:
                        match = False
                        break
                    elif operator == 'LIKE' and value not in str(field_value):
                        match = False
                        break
                    elif operator == 'CONTAINS' and value not in field_value:
                        match = False
                        break

                if not match:
                    continue

            results.append(row)

        # Apply sorting
        if sorts:
            for sort in reversed(sorts):
                field = sort['field']
                direction = sort.get('direction', 'ASC')
                reverse = (direction == 'DESC')
                results.sort(key=lambda r: r.get(field, ''), reverse=reverse)

        # Apply offset
        if offset:
            results = results[offset:]

        # Apply limit
        if limit:
            results = results[:limit]

        return results

    def get_trait_columns(self, traits: List[str]) -> List[str]:
        """
        Get storage column names for traits.

        For env storage, returns empty list as there's no schema.

        Args:
            traits: List of trait IDs

        Returns:
            Empty list
        """
        return []

    def create_trait_columns(self, trait_id: str, fields: Dict[str, Any]) -> None:
        """
        Not supported - environment storage is read-only.

        Raises:
            NotImplementedError: Always, as env storage is immutable
        """
        raise NotImplementedError(
            "Environment variable storage is read-only. "
            "Cannot modify schema."
        )
