"""Storage backend plugin manager."""

from __future__ import annotations

from winterforge.plugins._base import ReorderablePluginManagerBase


class StorageManager(ReorderablePluginManagerBase):
    """
    Manages storage backend plugins.

    Storage backends are registered as plugins and can be accessed via
    the manager's repository for first-match resolution.

    Example:
        from winterforge.frags.traits.persistable import set_storage
        storage = StorageManager.get('sqlite')
        set_storage(storage)
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier for storage backends."""
        return 'winterforge.storage_backends'
