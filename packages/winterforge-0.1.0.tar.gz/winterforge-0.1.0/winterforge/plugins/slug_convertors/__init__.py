"""Slug convertor plugins for naming convention transformations."""

from winterforge.plugins.slug_convertors.manager import (
    SlugConvertor,
    SlugConvertorManager,
)
from winterforge.plugins.slug_convertors.bootstrap import register_builtin_convertors

__all__ = [
    'SlugConvertor',
    'SlugConvertorManager',
    'register_builtin_convertors',
]
