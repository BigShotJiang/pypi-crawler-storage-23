"""Bootstrap registration for built-in slug convertors."""

from winterforge.plugins.slug_convertors.manager import SlugConvertorManager
from winterforge.plugins.slug_convertors.python_slug import PythonSlugConvertor
from winterforge.plugins.slug_convertors.sql_slug import SQLSlugConvertor


def register_builtin_convertors() -> None:
    """
    Register built-in slug convertors.

    Order matters for first-match-wins reconciliation:
    1. PythonSlugConvertor - Python ↔ Slug
    2. SQLSlugConvertor - Slug ↔ SQL
    """
    # Python ↔ Slug conversion
    SlugConvertorManager.register('python_slug', PythonSlugConvertor())

    # Slug ↔ SQL conversion
    SlugConvertorManager.register('sql_slug', SQLSlugConvertor())
