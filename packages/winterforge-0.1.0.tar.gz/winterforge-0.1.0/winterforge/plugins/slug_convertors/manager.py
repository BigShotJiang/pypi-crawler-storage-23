"""SlugConvertor plugin manager for naming convention conversions."""

from __future__ import annotations

from typing import Protocol, Dict, Optional


class SlugConvertor(Protocol):
    """
    Protocol for converting between naming conventions.

    SlugConvertors handle transformations between different naming domains:
    - Application layer (Python naming: snake_case)
    - Slug layer (URL/slug format: kebab-case)
    - SQL layer (Database naming: snake_case, sanitized)

    Pattern Recognition:
    "The need to supply domain logic usually implies multiple applicable
    domains. So it becomes a good candidate for a plugin type."
    """

    def applies_to(self, source_domain: str, target_domain: str) -> bool:
        """
        Check if this convertor handles the source→target transformation.

        Args:
            source_domain: Source naming domain ('python', 'slug', 'sql')
            target_domain: Target naming domain ('python', 'slug', 'sql')

        Returns:
            True if this convertor handles the transformation
        """
        ...

    def convert(self, name: str) -> str:
        """
        Convert name from source domain to target domain.

        Args:
            name: Name in source domain format

        Returns:
            Name in target domain format
        """
        ...


class SlugConvertorManager:
    """
    Manager for SlugConvertor plugins.

    Handles conversions between naming domains via registered convertors.
    Uses first-match-wins reconciliation pattern.
    """

    _convertors: Dict[str, SlugConvertor] = {}
    _order: list[str] = []

    @classmethod
    def register(cls, convertor_id: str, convertor: SlugConvertor) -> None:
        """
        Register a slug convertor plugin.

        Args:
            convertor_id: Unique convertor identifier
            convertor: SlugConvertor implementation
        """
        cls._convertors[convertor_id] = convertor
        if convertor_id not in cls._order:
            cls._order.append(convertor_id)

    @classmethod
    def convert(
        cls, name: str, source_domain: str, target_domain: str
    ) -> Optional[str]:
        """
        Convert name between domains using registered convertors.

        Uses first-match-wins: tries convertors in registration order
        until one signals it applies.

        Args:
            name: Name to convert
            source_domain: Source naming domain ('python', 'slug', 'sql')
            target_domain: Target naming domain ('python', 'slug', 'sql')

        Returns:
            Converted name, or None if no convertor applies

        Example:
            # Python → Slug
            slug = SlugConvertorManager.convert('db_path', 'python', 'slug')
            # Returns: 'db-path'

            # Slug → SQL
            sql = SlugConvertorManager.convert('db-path', 'slug', 'sql')
            # Returns: 'db_path'
        """
        # Identity conversion (same domain)
        if source_domain == target_domain:
            return name

        # Try convertors in order (first match wins)
        for convertor_id in cls._order:
            convertor = cls._convertors.get(convertor_id)
            if convertor and convertor.applies_to(source_domain, target_domain):
                return convertor.convert(name)

        return None

    @classmethod
    def clear(cls) -> None:
        """Clear all registered convertors (for testing)."""
        cls._convertors.clear()
        cls._order.clear()
