"""PythonSlugConvertor - converts between Python naming and slug format."""


class PythonSlugConvertor:
    """
    Convert between Python naming (snake_case) and slug format (kebab-case).

    Domains: python ↔ slug

    Conversions:
    - Python → Slug: underscores to hyphens (db_path → db-path)
    - Slug → Python: hyphens to underscores (db-path → db_path)
    """

    def applies_to(self, source_domain: str, target_domain: str) -> bool:
        """Check if this handles python↔slug conversion."""
        return (source_domain == 'python' and target_domain == 'slug') or (
            source_domain == 'slug' and target_domain == 'python'
        )

    def convert(self, name: str) -> str:
        """
        Convert between Python and slug naming.

        Bidirectional: underscores ↔ hyphens

        Args:
            name: Name in source format

        Returns:
            Name in target format
        """
        # Python → Slug: underscores to hyphens
        if '_' in name:
            return name.replace('_', '-')

        # Slug → Python: hyphens to underscores
        if '-' in name:
            return name.replace('-', '_')

        # No conversion needed (no special chars)
        return name
