"""SQLSlugConvertor - converts between slug format and SQL-safe naming."""


class SQLSlugConvertor:
    """
    Convert between slug format (kebab-case) and SQL-safe naming (snake_case).

    Domains: slug ↔ sql

    SQL column names don't allow hyphens without quoting.
    This convertor sanitizes slugs for SQL storage.

    Conversions:
    - Slug → SQL: hyphens to underscores (db-path → db_path)
    - SQL → Slug: underscores to hyphens (db_path → db-path)

    Note: Python and SQL both use snake_case, but this is conceptually
    different - SQL conversion is about storage sanitization, not
    application naming.
    """

    def applies_to(self, source_domain: str, target_domain: str) -> bool:
        """Check if this handles slug↔sql conversion."""
        return (source_domain == 'slug' and target_domain == 'sql') or (
            source_domain == 'sql' and target_domain == 'slug'
        )

    def convert(self, name: str) -> str:
        """
        Convert between slug and SQL naming.

        Bidirectional: hyphens ↔ underscores (for SQL sanitization)

        Args:
            name: Name in source format

        Returns:
            Name in target format (SQL-safe)
        """
        # Slug → SQL: hyphens to underscores (sanitization)
        if '-' in name:
            return name.replace('-', '_')

        # SQL → Slug: underscores to hyphens (restoration)
        if '_' in name:
            return name.replace('_', '-')

        # No conversion needed (no special chars)
        return name
