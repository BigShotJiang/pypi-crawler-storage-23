"""Required field validator."""

from typing import Tuple
from winterforge.plugins.validators.manager import validator


@validator('required')
class RequiredValidator:
    """
    Validates that field is not empty.

    Checks for:
    - Not None
    - Not empty string
    - Not whitespace-only string
    """

    def validate(
        self,
        value: str,
        field_name: str = None
    ) -> Tuple[bool, str]:
        """
        Validate field is not empty.

        Args:
            value: Value to validate
            field_name: Optional field name for error messages

        Returns:
            Tuple of (is_valid, error_message)
        """
        if value is None or not value.strip():
            field = field_name or "Field"
            return False, f"{field} is required"

        return True, ""
