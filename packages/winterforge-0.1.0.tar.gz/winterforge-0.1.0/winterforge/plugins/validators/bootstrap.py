"""Bootstrap registration for built-in validators."""

# Import validators to trigger @validator decorator registration
from winterforge.plugins.validators import email
from winterforge.plugins.validators import required
from winterforge.plugins.validators import username

# Import password validators (nested plugin pattern)
from winterforge.plugins.validators.password_validators import (
    simple,
    strong
)
