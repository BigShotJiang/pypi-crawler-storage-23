"""Simple password validator with minimal requirements."""

from typing import Tuple
from winterforge.plugins.validators.manager import validator


@validator('password_validators.simple')
class SimplePasswordValidator:
    """
    Simple password validator with minimal requirements.

    Requirements:
    - Minimum 6 characters
    - Not empty

    Use case: Development, testing, low-security contexts
    """

    MIN_LENGTH = 6

    def validate(
        self,
        value: str,
        field_name: str = None
    ) -> Tuple[bool, str]:
        """Validate password with simple requirements."""
        if not value:
            field = field_name or "Password"
            return False, f"{field} cannot be empty"

        if len(value) < self.MIN_LENGTH:
            field = field_name or "Password"
            return (
                False,
                f"{field} must be at least {self.MIN_LENGTH} characters"
            )

        return True, ""
