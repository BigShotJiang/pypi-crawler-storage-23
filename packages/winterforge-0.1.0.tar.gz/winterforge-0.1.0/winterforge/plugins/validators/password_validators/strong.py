"""Strong password validator with security requirements."""

from typing import Tuple
from winterforge.plugins.validators.manager import validator


@validator('password_validators.strong')
class StrongPasswordValidator:
    """
    Strong password validator with security requirements.

    Requirements:
    - Minimum 8 characters
    - At least one uppercase letter
    - At least one lowercase letter
    - At least one digit

    Use case: Production, security-critical applications
    """

    MIN_LENGTH = 8

    def validate(
        self,
        value: str,
        field_name: str = None
    ) -> Tuple[bool, str]:
        """
        Validate password strength.

        Args:
            value: Password to validate
            field_name: Optional field name for error messages

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not value:
            field = field_name or "Password"
            return False, f"{field} cannot be empty"

        if len(value) < self.MIN_LENGTH:
            field = field_name or "Password"
            return (
                False,
                f"{field} must be at least {self.MIN_LENGTH} characters"
            )

        if not any(c.isupper() for c in value):
            field = field_name or "Password"
            return False, f"{field} must contain an uppercase letter"

        if not any(c.islower() for c in value):
            field = field_name or "Password"
            return False, f"{field} must contain a lowercase letter"

        if not any(c.isdigit() for c in value):
            field = field_name or "Password"
            return False, f"{field} must contain a digit"

        return True, ""
