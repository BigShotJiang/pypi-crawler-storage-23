"""Manager for validator plugins."""

from typing import Dict, Type, Tuple, List
from winterforge.plugins._base import ReorderablePluginManagerBase
from winterforge.plugins._protocols.validator import Validator


class ValidationManager(ReorderablePluginManagerBase):
    """
    Manages validator plugins.

    Validators register via @validator decorator.
    Applications use validate_input() to run validations.
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Entry point group for validator plugins."""
        return 'winterforge.validators'

    @classmethod
    def validate(
        cls,
        value: str,
        validator_ids: List[str],
        field_name: str = None
    ) -> Tuple[bool, str]:
        """
        Validate value using specified validators.

        Args:
            value: Value to validate
            validator_ids: List of validator IDs to apply
            field_name: Optional field name for error messages

        Returns:
            Tuple of (is_valid, error_message)
            First validation failure stops execution

        Example:
            is_valid, error = ValidationManager.validate(
                'user@example.com',
                ['email', 'required'],
                'admin_email'
            )
        """
        for validator_id in validator_ids:
            validator_class = cls._plugins.get(validator_id)
            if not validator_class:
                return False, f"Unknown validator: {validator_id}"

            validator = validator_class()
            is_valid, error = validator.validate(value, field_name)
            if not is_valid:
                return False, error

        return True, ""


def validator(validator_id: str):
    """
    Decorator to register validator plugin.

    Example:
        @validator('email')
        class EmailValidator:
            def validate(self, value: str, field_name: str = None):
                if '@' not in value:
                    return False, "Invalid email format"
                return True, ""
    """
    def decorator(validator_class):
        ValidationManager.register(validator_id, validator_class)
        return validator_class
    return decorator


def validate_input(
    value: str,
    validators: List[str],
    field_name: str = None
) -> Tuple[bool, str]:
    """
    Convenience function for validating input.

    Args:
        value: Value to validate
        validators: List of validator IDs
        field_name: Optional field name for error messages

    Returns:
        Tuple of (is_valid, error_message)

    Example:
        is_valid, error = validate_input(
            user_input,
            ['required', 'email'],
            'email_address'
        )
        if not is_valid:
            print(f"Error: {error}")
    """
    return ValidationManager.validate(value, validators, field_name)
