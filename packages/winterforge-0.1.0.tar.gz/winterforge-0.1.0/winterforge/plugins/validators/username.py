"""Username validator.

Based on common username standards with reasonable flexibility.
Not as strict as email RFC, but maintains basic sanity.

References:
- GitHub usernames: alphanumeric + hyphens, 1-39 chars
- Twitter handles: alphanumeric + underscores, 1-15 chars
- Common practice: alphanumeric + underscore/hyphen, 3-30 chars

This validator uses a middle-ground approach suitable for
most applications.
"""

import re
from typing import Tuple
from winterforge.plugins.validators.manager import validator


@validator('username')
class UsernameValidator:
    """
    Username validator with reasonable constraints.

    Rules:
    - 3-30 characters (configurable via MIN_LENGTH, MAX_LENGTH)
    - Alphanumeric (a-z, A-Z, 0-9)
    - Underscores (_) and hyphens (-) allowed
    - Must start with alphanumeric (not special char)
    - Must end with alphanumeric (not special char)
    - No consecutive special characters (no __, --, _-, -_)
    - Case-insensitive (stored as entered, matched case-insensitive)

    Valid examples:
    - bob
    - alice_smith
    - user-123
    - john_doe_jr

    Invalid examples:
    - ab (too short)
    - _user (starts with special char)
    - user_ (ends with special char)
    - user__name (consecutive special chars)
    - user@domain (invalid character)
    """

    MIN_LENGTH = 3
    MAX_LENGTH = 30

    # Pattern explanation:
    # ^                 - Start of string
    # [a-zA-Z0-9]       - First char must be alphanumeric
    # (?!.*[-_]{2})     - No consecutive hyphens or underscores
    # [a-zA-Z0-9_-]*    - Middle chars (alphanumeric, _, -)
    # [a-zA-Z0-9]       - Last char must be alphanumeric
    # $                 - End of string
    USERNAME_PATTERN = re.compile(
        r'^[a-zA-Z0-9](?!.*[-_]{2})[a-zA-Z0-9_-]*[a-zA-Z0-9]$'
    )

    # For 3-character usernames, allow no middle chars
    USERNAME_PATTERN_SHORT = re.compile(
        r'^[a-zA-Z0-9]{3}$'
    )

    def validate(
        self,
        value: str,
        field_name: str = None
    ) -> Tuple[bool, str]:
        """
        Validate username.

        Args:
            value: Username to validate
            field_name: Optional field name for error messages

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not value or not value.strip():
            field = field_name or "Username"
            return False, f"{field} cannot be empty"

        value = value.strip()

        # Check length
        if len(value) < self.MIN_LENGTH:
            field = field_name or "Username"
            return (
                False,
                f"{field} must be at least {self.MIN_LENGTH} characters"
            )

        if len(value) > self.MAX_LENGTH:
            field = field_name or "Username"
            return (
                False,
                f"{field} must be at most {self.MAX_LENGTH} characters"
            )

        # Check pattern (special case for exactly 3 chars)
        if len(value) == 3:
            if not self.USERNAME_PATTERN_SHORT.match(value):
                field = field_name or "Username"
                return (
                    False,
                    f"{field} must contain only letters and numbers"
                )
        else:
            if not self.USERNAME_PATTERN.match(value):
                field = field_name or "Username"
                # Give specific error based on what failed
                if value[0] in '_-':
                    return (
                        False,
                        f"{field} must start with a letter or number"
                    )
                if value[-1] in '_-':
                    return (
                        False,
                        f"{field} must end with a letter or number"
                    )
                if '--' in value or '__' in value or '_-' in value or '-_' in value:
                    return (
                        False,
                        f"{field} cannot have consecutive special characters"
                    )
                # Generic invalid chars
                if not all(c.isalnum() or c in '_-' for c in value):
                    return (
                        False,
                        f"{field} can only contain letters, numbers, "
                        "underscores, and hyphens"
                    )

        return True, ""


@validator('username-strict')
class StrictUsernameValidator:
    """
    Strict username validator (alphanumeric only).

    Rules:
    - 3-20 characters
    - Alphanumeric only (a-z, A-Z, 0-9)
    - No special characters

    Use case: Systems requiring maximum compatibility.
    """

    MIN_LENGTH = 3
    MAX_LENGTH = 20

    USERNAME_PATTERN = re.compile(r'^[a-zA-Z0-9]+$')

    def validate(
        self,
        value: str,
        field_name: str = None
    ) -> Tuple[bool, str]:
        """Validate username (strict mode)."""
        if not value or not value.strip():
            field = field_name or "Username"
            return False, f"{field} cannot be empty"

        value = value.strip()

        if len(value) < self.MIN_LENGTH:
            field = field_name or "Username"
            return (
                False,
                f"{field} must be at least {self.MIN_LENGTH} characters"
            )

        if len(value) > self.MAX_LENGTH:
            field = field_name or "Username"
            return (
                False,
                f"{field} must be at most {self.MAX_LENGTH} characters"
            )

        if not self.USERNAME_PATTERN.match(value):
            field = field_name or "Username"
            return (
                False,
                f"{field} can only contain letters and numbers"
            )

        return True, ""
