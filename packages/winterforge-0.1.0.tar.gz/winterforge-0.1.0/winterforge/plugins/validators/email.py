"""Email validator.

NOTE: This is a BASIC email validator, not RFC 5321/5322 compliant.

For production use, consider:
- email-validator library (RFC compliant)
- dns_validator for MX record checking
- Dedicated email validation service

This validator is suitable for:
- Development/testing
- Basic format checking
- Non-critical applications
"""

import re
from typing import Tuple
from winterforge.plugins.validators.manager import validator


@validator('email')
class EmailValidator:
    """
    Basic email format validator.

    WARNING: Not RFC compliant. Validates basic format only:
    - Has @ symbol
    - Has local part before @
    - Has domain with TLD after @

    Does NOT validate:
    - Special characters per RFC 5321
    - Quoted strings
    - Comments
    - International domains (IDN)
    - IP address literals
    - MX record existence
    """

    # Basic email pattern (NOT RFC compliant)
    EMAIL_PATTERN = re.compile(
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    )

    def validate(
        self,
        value: str,
        field_name: str = None
    ) -> Tuple[bool, str]:
        """
        Validate basic email format.

        Args:
            value: Email address to validate
            field_name: Optional field name for error messages

        Returns:
            Tuple of (is_valid, error_message)
        """
        if not value or not value.strip():
            field = field_name or "Email"
            return False, f"{field} cannot be empty"

        value = value.strip()

        if not self.EMAIL_PATTERN.match(value):
            field = field_name or "Email"
            return False, f"{field} must be a valid email address"

        return True, ""
