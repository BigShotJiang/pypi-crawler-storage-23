"""Base class for all plugin managers."""

from __future__ import annotations

from typing import Dict, Type, Any, Optional, Callable, List
from abc import ABC, abstractmethod
from winterforge.plugins.repository import PluginRepository


class PluginManagerBase(ABC):
    """
    Base class for all plugin managers.

    Plugin managers provide decorator-based registration, lazy instantiation,
    instance caching, and derivative support. Each manager maintains an isolated
    registry for its plugin type.

    Subclasses must implement plugin_id() classmethod to declare their
    identifier for auto-registration and discovery.
    """

    # Plugin registries (isolated per manager via __init_subclass__)
    _plugins: Dict[str, Type]         # Plugin class definitions
    _order: List[str]                 # Plugin registration order
    _instances: Dict[str, Any]        # Instantiated plugin cache (singletons)
    _metadata: Dict[str, dict]        # Plugin metadata storage
    _derivers: Dict[str, Callable]    # Derivative generators
    _scope_reverse_map: Dict[str, List[str]]  # parent_id -> [child_ids]
    _dependency_repo_cache: Optional[PluginRepository]  # Cached dependency repo

    @classmethod
    @abstractmethod
    def plugin_id(cls) -> str:
        """
        Return the plugin manager identifier.

        The manager ID serves as the unique identifier for this plugin manager
        throughout the framework. It is used for:
        - Manager registry lookup (via PluginDiscoverer)
        - Decorator registration (@deriver uses this ID)
        - Entry point discovery (external packages use this as the group name)

        Example: 'winterforge.storage_backends'

        Note: This ID is also used as the setuptools entry point group name,
        allowing external packages to register plugins for this manager.

        Returns:
            Plugin manager identifier string
        """
        ...

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Initialize isolated registries and auto-register the manager."""
        super().__init_subclass__(**kwargs)

        # Create isolated registries for this manager
        cls._plugins = {}
        cls._order = []
        cls._instances = {}
        cls._metadata = {}
        cls._derivers = {}
        cls._scope_reverse_map = {}
        cls._dependency_repo_cache = None

        # Auto-register this manager with PluginDiscoverer
        # Only register if this is a concrete class (not still abstract)
        if not getattr(cls, '__abstractmethods__', None):
            from winterforge.plugins._discovery import PluginDiscoverer
            manager_id = cls.plugin_id()
            PluginDiscoverer.register_manager(manager_id, cls)

    @classmethod
    def repository(cls) -> PluginRepository[Type]:
        """
        Get an immutable repository snapshot for this manager.

        Returns:
            Immutable plugin repository with ordering and resolution support
        """
        return PluginRepository(cls._plugins, cls._order)

    @classmethod
    def register(
        cls,
        plugin_id: str,
        plugin_class: Type,
        metadata: Optional[dict] = None
    ) -> None:
        """
        Register a plugin class with the manager.

        Registration is idempotent - if a plugin with the same ID is already
        registered, silently skip to allow both decorator and entry point registration.

        Automatically tracks scope relationships from @scope decorator.

        Args:
            plugin_id: Unique plugin identifier
            plugin_class: Plugin class definition
            metadata: Optional metadata dictionary
        """
        if plugin_id in cls._plugins:
            # Silently skip if already registered (idempotent)
            return

        cls._plugins[plugin_id] = plugin_class
        cls._order.append(plugin_id)
        cls._metadata[plugin_id] = metadata or {}

        # Track scope relationship if scoped
        if hasattr(plugin_class, '__scope__'):
            parent_id = plugin_class.__scope__
            if parent_id not in cls._scope_reverse_map:
                cls._scope_reverse_map[parent_id] = []
            cls._scope_reverse_map[parent_id].append(plugin_id)

            # Invalidate cache (eager warm on next access)
            cls._dependency_repo_cache = None

    @classmethod
    def get(cls, plugin_id: str, **kwargs: Any) -> Any:
        """
        Retrieve plugin instance with lazy instantiation and caching.

        Instances are cached when retrieved without arguments. Custom
        instantiation arguments bypass the cache.

        Args:
            plugin_id: Plugin identifier
            **kwargs: Instantiation arguments (bypasses cache)

        Returns:
            Plugin instance

        Raises:
            KeyError: Unknown plugin_id
        """
        if plugin_id not in cls._plugins:
            raise KeyError(
                f"Plugin '{plugin_id}' not found in {cls.__name__}"
            )

        # Return cached instance if exists and no custom kwargs
        if not kwargs and plugin_id in cls._instances:
            return cls._instances[plugin_id]

        # Instantiate
        plugin_class = cls._plugins[plugin_id]
        instance = plugin_class(**kwargs)

        # Cache if no custom kwargs
        if not kwargs:
            cls._instances[plugin_id] = instance

        return instance

    @classmethod
    def has(cls, plugin_id: str) -> bool:
        """Check plugin registration status."""
        return plugin_id in cls._plugins

    @classmethod
    def get_definitions(cls) -> Dict[str, Type]:
        """Return all registered plugin class definitions as a dict."""
        return cls._plugins.copy()

    @classmethod
    def get_metadata(cls, plugin_id: str) -> dict:
        """Return plugin metadata (empty dict if none)."""
        return cls._metadata.get(plugin_id, {})

    @classmethod
    def register_deriver(cls, deriver_id: str, deriver_func: Callable) -> None:
        """
        Register a derivative generator.

        Args:
            deriver_id: Unique deriver identifier
            deriver_func: Generator function yielding plugin definitions
        """
        cls._derivers[deriver_id] = deriver_func

    @classmethod
    def derive_plugins(cls) -> None:
        """
        Execute all derivative generators to register dynamic plugins.

        Typically called during framework initialization after configuration load.
        """
        for deriver_id, deriver_func in cls._derivers.items():
            for derived_def in deriver_func():
                # derived_def = {'id': 'plugin_id', 'class': PluginClass, 'metadata': {...}}
                cls.register(
                    plugin_id=derived_def['id'],
                    plugin_class=derived_def['class'],
                    metadata=derived_def.get('metadata', {})
                )

    @classmethod
    def clear_cache(cls) -> None:
        """Clear the instantiated plugin cache."""
        cls._instances.clear()

    @classmethod
    def reset(cls) -> None:
        """Reset the plugin manager to empty state."""
        cls._plugins.clear()
        cls._order.clear()
        cls._instances.clear()
        cls._metadata.clear()
        cls._derivers.clear()
        cls._scope_reverse_map.clear()
        cls._dependency_repo_cache = None

    @classmethod
    async def startup_all(cls) -> None:
        """
        Call startup() on all LifecycleAware plugin instances.

        Instantiates all registered plugins (triggering lazy loading)
        and calls startup() on any implementing LifecycleAware protocol.
        Invoked once during application initialization, after plugin
        registration and derivative generation.

        Used for initializing long-lived resources such as connection pools,
        caches, or background workers.
        """
        from winterforge.plugins._protocols import LifecycleAware

        for plugin_id in cls._order:
            instance = cls.get(plugin_id)
            if isinstance(instance, LifecycleAware):
                await instance.startup()

    @classmethod
    async def shutdown_all(cls) -> None:
        """
        Call shutdown() on all LifecycleAware plugin instances.

        Only affects already-instantiated plugins (does not trigger
        lazy loading). Invoked once during application termination,
        typically in response to shutdown signals.

        Used for releasing long-lived resources such as connection pools,
        caches, or background workers.
        """
        from winterforge.plugins._protocols import LifecycleAware

        for plugin_id, instance in cls._instances.items():
            if isinstance(instance, LifecycleAware):
                await instance.shutdown()

    @classmethod
    def dependency_tree(cls) -> PluginRepository:
        """
        Get all plugins in dependency order (child→sibling→parent).

        Returns Repository where iteration processes scoped plugins
        before their parents. Cached and rebuilt eagerly on invalidation.

        Returns:
            PluginRepository with dependency-ordered plugins

        Example:
            # Element plugins scoped to 'prettier' formatter
            repo = FormatterManager.dependency_tree()

            # Iteration processes in dependency order
            for plugin_id, plugin_class in repo:
                print(f"Process: {plugin_id}")
            # Output: panel, table, prettier (children first)
        """
        # Return cached if available
        if cls._dependency_repo_cache is not None:
            return cls._dependency_repo_cache

        from winterforge.utils.dependency_resolver import (
            DependencyResolver
        )

        # Find root plugins (those not scoped to anything)
        roots = cls._find_roots()
        ordered_items = []

        for root_id in roots:
            # Build tree for this root
            tree = DependencyResolver.build_tree(
                root_id,
                cls._scope_reverse_map
            )

            # Traverse to flat list (child→sibling→parent)
            items = DependencyResolver.traverse_to_list(
                tree,
                cls._plugins
            )
            ordered_items.extend(items)

        # Build Repository (preserves order)
        plugins_dict = dict(ordered_items)
        order = [item_id for item_id, _ in ordered_items]

        # Cache
        cls._dependency_repo_cache = PluginRepository(plugins_dict, order)

        return cls._dependency_repo_cache

    @classmethod
    def _find_roots(cls) -> List[str]:
        """
        Find root plugins (those not scoped to anything in this manager).

        Includes:
        - Plugins with no __scope__ attribute (truly unscoped)
        - Plugins scoped to parents in other managers (external scope)

        Returns:
            List of plugin IDs that are roots for this manager
        """
        all_plugins = set(cls._plugins.keys())
        internal_scoped = set()

        # Find plugins scoped to parents within this manager
        for parent_id, children in cls._scope_reverse_map.items():
            # Only count as internal scope if parent exists in this manager
            if parent_id in cls._plugins:
                internal_scoped.update(children)

        # Roots are plugins not internally scoped
        roots = all_plugins - internal_scoped
        return sorted(roots)  # Deterministic order

    @classmethod
    def with_scope(cls, scope: str):
        """
        Create scoped manager instance.

        Returns a manager instance that filters plugins to only
        those matching the specified scope.

        Args:
            scope: Scope identifier (parent plugin ID)

        Returns:
            Scoped manager instance

        Example:
            # Get all elements
            all_elements = ElementManager().all()

            # Get only prettier-scoped elements
            prettier_mgr = ElementManager.with_scope('prettier')
            prettier_elements = prettier_mgr.all()
        """
        return cls(scope=scope)

    def __init__(self, scope: str | None = None):
        """
        Initialize manager with optional scope filter.

        Args:
            scope: Optional scope identifier for filtering plugins
        """
        self._scope = scope

    def get_scoped(self, plugin_id: str, **kwargs: Any) -> Any:
        """
        Get plugin instance respecting scope filter.

        Args:
            plugin_id: Plugin identifier
            **kwargs: Instantiation arguments

        Returns:
            Plugin instance or None if filtered by scope

        Raises:
            KeyError: Plugin not found
        """
        if plugin_id not in self.__class__._plugins:
            raise KeyError(
                f"Plugin '{plugin_id}' not found in {self.__class__.__name__}"
            )

        plugin_class = self.__class__._plugins[plugin_id]

        # Filter by scope
        if self._scope is not None:
            plugin_scope = getattr(plugin_class, '__scope__', None)
            if plugin_scope != self._scope:
                return None

        # Return cached or create new
        if not kwargs and plugin_id in self.__class__._instances:
            return self.__class__._instances[plugin_id]

        instance = plugin_class(**kwargs)

        if not kwargs:
            self.__class__._instances[plugin_id] = instance

        return instance

    def all(self) -> List[Any]:
        """
        Get all plugin instances respecting scope.

        Returns:
            List of plugin instances matching scope filter
        """
        result = []
        for plugin_id in self.__class__._order:
            plugin = self.get_scoped(plugin_id)
            if plugin is not None:
                result.append(plugin)
        return result


class ReorderablePluginManager:
    """
    Mixin providing plugin reordering capabilities.

    Adds the ability to accept reordered plugin repositories and apply
    them to the manager's internal ordering. Allows runtime customization
    of plugin resolution order.

    This mixin should be combined with PluginManagerBase to create
    managers that support runtime reordering.
    """

    @classmethod
    def reorder(cls, repository: PluginRepository) -> None:
        """
        Apply ordering from a repository to this manager.

        Updates the manager's internal plugin order to match the
        repository's order. Useful for customizing plugin resolution
        order at runtime or during initialization.

        Args:
            repository: Repository with desired plugin ordering

        Raises:
            ValueError: If repository contains different plugins than manager

        Example:
            repo = StorageManager.repository()
            repo = repo.with_front('postgresql')
            StorageManager.reorder(repo)
        """
        # Validate that repository contains exactly our plugins
        if set(repository.order()) != set(cls._order):
            missing = set(cls._order) - set(repository.order())
            extra = set(repository.order()) - set(cls._order)
            msg = []
            if missing:
                msg.append(f"Missing plugins: {missing}")
            if extra:
                msg.append(f"Unknown plugins: {extra}")
            raise ValueError("; ".join(msg))

        # Update internal ordering
        cls._order = repository.order()


class ReorderablePluginManagerBase(PluginManagerBase, ReorderablePluginManager):
    """
    Convenience base class combining PluginManagerBase with reordering.

    Most plugin managers should extend this class to get both core
    plugin management and reordering capabilities.

    Use plain PluginManagerBase when reordering doesn't make sense
    (e.g., PluginManagerManager - manager ordering is meaningless).

    Example:
        class StorageManager(ReorderablePluginManagerBase):
            @classmethod
            def plugin_id(cls) -> str:
                return 'winterforge.storage_backends'
    """
    pass
