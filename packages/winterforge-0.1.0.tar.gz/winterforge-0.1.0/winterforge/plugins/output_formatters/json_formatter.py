"""JSON output formatter - structured JSON output."""

import json
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.plugins.output_formatters.source import FormatterSource


class JsonFormatter:
    """
    JSON formatter for CLI output.

    Provides structured JSON output for script consumption.
    Applies when --format=json flag is set.
    """

    def applies_to(self, source: 'FormatterSource') -> bool:
        """
        Apply when --format=json is set.

        Args:
            source: Formatter source

        Returns:
            True if --format=json is set
        """
        return source.flags.get('format') == 'json'

    def format(self, result: Any, source: 'FormatterSource') -> str:
        """
        Format result as JSON.

        Args:
            result: Command result
            source: Formatter source

        Returns:
            JSON string
        """
        # Handle None
        if result is None:
            return json.dumps(None)

        # Handle Frags
        if hasattr(result, 'affinities'):
            data = {
                'id': getattr(result, 'id', None),
                'affinities': list(getattr(result, 'affinities', [])),
                'traits': list(getattr(result, 'traits', [])),
            }

            # Add common fields if present
            if hasattr(result, 'slug'):
                data['slug'] = result.slug
            if hasattr(result, 'value') and callable(result.value):
                # Try to get 'value' field
                try:
                    data['value'] = result.value('value')
                except:
                    pass

            return json.dumps(data, indent=2)

        # Handle strings, lists, dicts
        if isinstance(result, (str, list, dict, int, float, bool)):
            return json.dumps(result, indent=2)

        # Fallback: try to convert to dict
        try:
            if hasattr(result, '__dict__'):
                return json.dumps(result.__dict__, indent=2)
        except:
            pass

        # Last resort: string representation
        return json.dumps(str(result))
