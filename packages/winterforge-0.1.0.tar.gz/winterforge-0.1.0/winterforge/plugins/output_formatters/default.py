"""Default output formatter - human-readable with colors."""

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.plugins.output_formatters.source import FormatterSource


class DefaultFormatter:
    """
    Default formatter for CLI output.

    Provides human-readable output with colors and formatting.
    Applies when no special flags are set.
    """

    def applies_to(self, source: 'FormatterSource') -> bool:
        """
        Apply as fallback when no other formatter claims the source.

        This should be registered LAST in the repository so it only
        applies after all other formatters have been checked.

        Args:
            source: Formatter source

        Returns:
            True (always applies as fallback)
        """
        # Don't apply if specific format flags are set
        if (
            source.flags.get('quiet')
            or source.flags.get('debug')
            or source.flags.get('format')
        ):
            return False

        return True

    def format(self, result: Any, source: 'FormatterSource') -> str:
        """
        Format result as human-readable text.

        Args:
            result: Command result
            source: Formatter source

        Returns:
            Formatted string
        """
        # Handle None results
        if result is None:
            return ""

        # Handle Frags with cli_result affinity
        if hasattr(result, 'affinities') and 'cli_result' in result.affinities:
            return result.message

        # Handle other Frags
        if hasattr(result, 'affinities'):
            # Format based on Frag type
            if hasattr(result, 'id'):
                return f"✓ Operation complete (Frag ID: {result.id})"
            return "✓ Operation complete"

        # Handle strings
        if isinstance(result, str):
            return result

        # Handle lists/collections
        if isinstance(result, (list, tuple)):
            if not result:
                return "(empty)"
            return "\n".join(str(item) for item in result)

        # Handle dicts
        if isinstance(result, dict):
            lines = []
            for key, value in result.items():
                lines.append(f"{key}: {value}")
            return "\n".join(lines)

        # Fallback: string representation
        return str(result)
