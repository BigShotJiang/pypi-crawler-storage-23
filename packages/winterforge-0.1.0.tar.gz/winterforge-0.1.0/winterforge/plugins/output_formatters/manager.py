"""
Output Formatter Manager.

Manages registration and reconciliation of output formatter plugins.
Uses standard "first match wins" pattern based on applicability.
"""

from typing import Any, Dict, Optional, Protocol, TYPE_CHECKING
from winterforge.plugins.repository import PluginRepository

if TYPE_CHECKING:
    from winterforge.plugins.output_formatters.source import FormatterSource


class OutputFormatter(Protocol):
    """
    Protocol for output formatter plugins.

    Formatters signal applicability based on context (flags, args, command metadata)
    and format command results for CLI output.
    """

    def applies_to(self, source: 'FormatterSource') -> bool:
        """
        Check if this formatter applies to the given source.

        Args:
            source: Formatter source with flags, args, metadata, result

        Returns:
            True if this formatter should handle the output
        """
        ...

    def format(self, result: Any, source: 'FormatterSource') -> str:
        """
        Format command result for output.

        Args:
            result: Command result (Frag, string, dict, list, etc.)
            source: Formatter source

        Returns:
            Formatted string for output
        """
        ...


class OutputFormatterManager:
    """
    Manager for output formatter plugins.

    Uses standard reconciliation pattern: query all formatters,
    first one that applies_to() wins.
    """

    _formatters: Dict[str, OutputFormatter] = {}
    _order: list[str] = []

    @classmethod
    def register(cls, formatter_id: str, formatter: OutputFormatter) -> None:
        """
        Register an output formatter plugin.

        Args:
            formatter_id: Unique formatter identifier
            formatter: OutputFormatter plugin instance
        """
        cls._formatters[formatter_id] = formatter
        if formatter_id not in cls._order:
            cls._order.append(formatter_id)

    @classmethod
    def get(cls, formatter_id: str) -> Optional[OutputFormatter]:
        """Get formatter by ID."""
        return cls._formatters.get(formatter_id)

    @classmethod
    def has(cls, formatter_id: str) -> bool:
        """Check if formatter is registered."""
        return formatter_id in cls._formatters

    @classmethod
    def repository(cls) -> PluginRepository:
        """Get formatter repository for ordering control."""
        return PluginRepository(cls._formatters.copy(), cls._order.copy())

    @classmethod
    def format(cls, result: Any, source: 'FormatterSource') -> str:
        """
        Format command result using first applicable formatter.

        Queries all formatters in order, uses first match.

        Args:
            result: Command result
            source: Formatter source with flags, args, metadata, result

        Returns:
            Formatted string for output

        Raises:
            RuntimeError: If no formatter applies
        """
        # Query formatters in order
        for formatter_id in cls._order:
            formatter = cls._formatters.get(formatter_id)
            if formatter and formatter.applies_to(source):
                return formatter.format(result, source)

        # Fallback: no formatter applied
        raise RuntimeError(
            f"No output formatter applies to source: {source.flags}"
        )

    @classmethod
    def reset(cls) -> None:
        """Reset all formatters (for testing)."""
        cls._formatters = {}
        cls._order = []
