"""Output formatter plugins for CLI output."""

from winterforge.plugins.output_formatters.manager import OutputFormatterManager

__all__ = ['OutputFormatterManager']
