"""Bootstrap output formatters."""

from winterforge.plugins.output_formatters.manager import OutputFormatterManager
from winterforge.plugins.output_formatters.quiet import QuietFormatter
from winterforge.plugins.output_formatters.json_formatter import JsonFormatter
from winterforge.plugins.output_formatters.debug import DebugFormatter
from winterforge.plugins.output_formatters.default import DefaultFormatter


def register_builtin_formatters() -> None:
    """
    Register built-in output formatters.

    Order matters - first match wins. Register specific formatters first,
    fallback (default) last.
    """
    # Specific formatters (checked first)
    OutputFormatterManager.register('quiet', QuietFormatter())
    OutputFormatterManager.register('json', JsonFormatter())
    OutputFormatterManager.register('debug', DebugFormatter())

    # Fallback formatter (checked last)
    OutputFormatterManager.register('default', DefaultFormatter())
