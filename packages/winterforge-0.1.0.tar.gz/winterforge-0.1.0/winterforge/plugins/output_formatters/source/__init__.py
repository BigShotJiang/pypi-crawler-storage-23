"""Source objects for output formatters."""

from winterforge.plugins.output_formatters.source.formatter_source import (
    FormatterSource,
)

__all__ = ['FormatterSource']
