"""Source object for formatter context."""

from dataclasses import dataclass
from typing import Any, Dict


@dataclass(frozen=True)
class FormatterSource:
    """
    Immutable source object for output formatters.

    Provides context about the CLI execution environment
    to help formatters decide applicability and format output.

    Attributes:
        flags: CLI flags (verbose, quiet, debug, format)
        args: Command arguments passed by user
        metadata: Command metadata (name, help, options, etc.)
        result: Command execution result to be formatted
    """

    flags: Dict[str, bool]
    args: Dict[str, Any]
    metadata: Dict[str, Any]
    result: Any
