"""Debug output formatter - verbose output with details."""

from typing import Any, TYPE_CHECKING
import traceback

if TYPE_CHECKING:
    from winterforge.plugins.output_formatters.source import FormatterSource


class DebugFormatter:
    """
    Debug formatter for CLI output.

    Provides verbose output with stack traces, types, and internals.
    Applies when --debug flag is set.
    """

    def applies_to(self, source: 'FormatterSource') -> bool:
        """
        Apply when --debug flag is set.

        Args:
            source: Formatter source

        Returns:
            True if --debug flag is set
        """
        return source.flags.get('debug', False) is True

    def format(self, result: Any, source: 'FormatterSource') -> str:
        """
        Format result with debug information.

        Args:
            result: Command result
            source: Formatter source

        Returns:
            Verbose formatted string with debug info
        """
        lines = []

        # Result type
        lines.append(f"[DEBUG] Result type: {type(result).__name__}")

        # Handle None
        if result is None:
            lines.append("[DEBUG] Result: None")
            return "\n".join(lines)

        # Handle Frags - show full composition
        if hasattr(result, 'affinities'):
            lines.append("[DEBUG] Frag composition:")
            lines.append(f"  ID: {getattr(result, 'id', 'N/A')}")
            lines.append(f"  Affinities: {list(getattr(result, 'affinities', []))}")
            lines.append(f"  Traits: {list(getattr(result, 'traits', []))}")

            # Show all attributes
            if hasattr(result, '__dict__'):
                lines.append("[DEBUG] Frag attributes:")
                for key, value in result.__dict__.items():
                    if not key.startswith('_'):
                        lines.append(f"  {key}: {repr(value)[:100]}")

        # Handle other types
        else:
            lines.append(f"[DEBUG] Result: {repr(result)[:500]}")

        # Show source
        lines.append("[DEBUG] Source:")
        lines.append(f"  Flags: {source.flags}")
        lines.append(f"  Args: {source.args}")

        return "\n".join(lines)
