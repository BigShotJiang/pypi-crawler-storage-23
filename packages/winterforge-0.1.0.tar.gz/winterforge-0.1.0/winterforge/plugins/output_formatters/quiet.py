"""Quiet output formatter - minimal output."""

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.plugins.output_formatters.source import FormatterSource


class QuietFormatter:
    """
    Quiet formatter for CLI output.

    Provides minimal output - just essential data.
    Applies when --quiet flag is set.
    """

    def applies_to(self, source: 'FormatterSource') -> bool:
        """
        Apply when --quiet flag is set.

        Args:
            source: Formatter source

        Returns:
            True if --quiet flag is set
        """
        return source.flags.get('quiet', False) is True

    def format(self, result: Any, source: 'FormatterSource') -> str:
        """
        Format result with minimal output.

        Args:
            result: Command result
            source: Formatter source

        Returns:
            Minimal formatted string
        """
        # Handle None results
        if result is None:
            return ""

        # Handle Frags - just return ID
        if hasattr(result, 'id'):
            return str(result.id)

        # Handle strings - return as-is
        if isinstance(result, str):
            return result

        # Handle lists - return count
        if isinstance(result, (list, tuple)):
            return str(len(result))

        # Handle dicts - return count
        if isinstance(result, dict):
            return str(len(result))

        # Fallback
        return str(result)
