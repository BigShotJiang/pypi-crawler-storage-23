"""
Permission provider management.

Manages permission providers that define allowed permissions via
decorated methods. Method signatures serve as permission schemas.
"""

from __future__ import annotations

from winterforge.plugins._base import ReorderablePluginManagerBase
from winterforge.plugins.decorators.provider_type import provider_type


@provider_type('permission_providers')
class PermissionProviderManager(ReorderablePluginManagerBase):
    """
    Manage permission providers.

    Permission providers define allowed permissions via decorated
    methods. Method signatures define permission check parameters
    (though validation is not enforced - they're documentation).

    Auto-generated methods (via @provider_type):
    - validate(path) - Check if permission defined
    - get_schema(path) - Get permission parameters
    - get_description(path) - Get permission docstring

    Example:
        # Check if permission exists
        if PermissionProviderManager.validate('content.create'):
            await user.grant_permission('content.create')

        # Get permission schema
        schema = PermissionProviderManager.get_schema('content.create')
        # {'user_id': 'int'}

        # Get permission description
        desc = PermissionProviderManager.get_description('content.create')
        # "Permission to create content."
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.permission_providers'
