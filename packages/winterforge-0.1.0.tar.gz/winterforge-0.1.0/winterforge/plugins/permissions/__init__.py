"""Permission system plugins and managers."""

from winterforge.plugins.permissions.provider_manager import (
    PermissionProviderManager,
)

__all__ = ['PermissionProviderManager']
