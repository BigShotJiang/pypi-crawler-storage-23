"""JSON HTTP response handler."""

import json
from typing import Any, Dict, TYPE_CHECKING
from winterforge.plugins.decorators import http_response_handler, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@http_response_handler()
@root('json')
class JSONResponseHandler:
    """
    JSON HTTP response handler.

    Formats Frags as JSON responses.
    Applies when Accept header includes application/json (default).
    """

    def applies_to(self, frag: 'Frag', config: Dict[str, Any]) -> bool:
        """
        Apply when Accept header includes application/json.

        Args:
            frag: Frag to format
            config: Handler configuration (includes accept header)

        Returns:
            True if JSON is acceptable
        """
        # Default to JSON if no Accept header specified
        accept = config.get('accept', 'application/json')
        return 'application/json' in accept or '*/*' in accept

    async def format(
        self,
        frag: 'Frag',
        config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Format Frag as JSON response.

        Args:
            frag: Frag to format
            config: Handler configuration

        Returns:
            Dict with status_code, body, headers
        """
        # Determine status code
        status_code = 200
        if hasattr(frag, 'status_code'):
            status_code = frag.status_code
        elif hasattr(frag, 'get'):
            # Check if Frag has status_code field
            status = frag.get('status_code')
            if status is not None:
                status_code = status

        # Check if Frag has explicit body (http-response trait)
        if hasattr(frag, 'body') and frag.body is not None:
            # Use the explicit body from http-response trait
            body = frag.body
        elif hasattr(frag, 'to_dict'):
            # Serialize the Frag to dict
            body = frag.to_dict()

            # Normalize _fields to fields (without underscore) for JSON output
            if '_fields' in body:
                body['fields'] = body.pop('_fields')
        else:
            # Fallback: basic Frag structure
            body = {
                'id': getattr(frag, 'id', None),
                'affinities': list(getattr(frag, 'affinities', [])),
                'traits': list(getattr(frag, 'traits', [])),
            }

            # Add fields if present
            if hasattr(frag, '_fields') and frag._fields:
                body['fields'] = frag._fields

        # Build response
        return {
            'status_code': status_code,
            'body': json.dumps(body),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
