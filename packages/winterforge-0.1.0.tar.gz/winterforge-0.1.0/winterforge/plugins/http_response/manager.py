"""HTTP response handler manager.

Manages registration and resolution of HTTP response handler plugins.
Uses standard "first match wins" pattern based on applicability.
"""

from typing import Any, Dict, TYPE_CHECKING
from winterforge.plugins._base import ReorderablePluginManagerBase

if TYPE_CHECKING:
    from winterforge.plugins._protocols.http import HTTPResponseHandler
    from winterforge.frags.base import Frag


class HTTPResponseHandlerManager(ReorderablePluginManagerBase):
    """
    Manager for HTTP response handler plugins.

    Uses standard reconciliation pattern: query all handlers,
    first one that applies_to() wins.

    Example:
        # Format Frag using first applicable handler
        response_data = await HTTPResponseHandlerManager.format(
            frag,
            config={'accept': 'application/json'}
        )
        # response_data = {
        #     'status_code': 200,
        #     'body': {...},
        #     'headers': {'Content-Type': 'application/json'}
        # }
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.http_response_handlers'

    @classmethod
    async def format(
        cls,
        frag: 'Frag',
        config: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Format Frag into HTTP response using first applicable handler.

        Queries all handlers in order, uses first match.

        Args:
            frag: Frag to format as HTTP response
            config: Handler configuration (includes Accept header)

        Returns:
            Dict with status_code, body, headers

        Raises:
            RuntimeError: If no handler applies
        """
        config = config or {}

        # Query handlers in order
        for handler_id in cls.repository().order():
            handler = cls.get(handler_id)
            if handler and handler.applies_to(frag, config):
                return await handler.format(frag, config)

        # Fallback: no handler applied
        raise RuntimeError(
            f"No HTTP response handler applies to Frag: "
            f"affinities={frag.affinities}, traits={frag.traits}"
        )
