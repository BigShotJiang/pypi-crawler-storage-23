"""XML HTTP response handler."""

from typing import Any, Dict, TYPE_CHECKING
from winterforge.plugins.decorators import http_response_handler, root

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@http_response_handler()
@root('xml')
class XMLResponseHandler:
    """
    XML HTTP response handler.

    Formats Frags as XML responses.
    Applies when Accept header includes application/xml or text/xml.
    """

    def applies_to(self, frag: 'Frag', config: Dict[str, Any]) -> bool:
        """
        Apply when Accept header includes XML.

        Args:
            frag: Frag to format
            config: Handler configuration (includes accept header)

        Returns:
            True if XML is acceptable
        """
        accept = config.get('accept', '')
        return (
            'application/xml' in accept or
            'text/xml' in accept
        )

    async def format(
        self,
        frag: 'Frag',
        config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Format Frag as XML response.

        Args:
            frag: Frag to format
            config: Handler configuration

        Returns:
            Dict with status_code, body, headers
        """
        # Determine status code
        status_code = 200
        if hasattr(frag, 'status_code'):
            status_code = frag.status_code

        # Convert Frag to dict
        if hasattr(frag, 'to_dict'):
            data = frag.to_dict()
        else:
            data = {
                'id': getattr(frag, 'id', None),
                'affinities': list(getattr(frag, 'affinities', [])),
                'traits': list(getattr(frag, 'traits', [])),
            }

        # Convert dict to simple XML
        xml_body = self._dict_to_xml(data, root_tag='frag')

        return {
            'status_code': status_code,
            'body': xml_body,
            'headers': {
                'Content-Type': 'application/xml'
            }
        }

    def _dict_to_xml(
        self,
        data: Dict[str, Any],
        root_tag: str = 'root'
    ) -> str:
        """
        Convert dict to simple XML.

        Args:
            data: Dict to convert
            root_tag: Root XML element name

        Returns:
            XML string
        """
        xml = f'<?xml version="1.0" encoding="UTF-8"?>\n'
        xml += f'<{root_tag}>\n'

        for key, value in data.items():
            xml += self._value_to_xml(key, value, indent='  ')

        xml += f'</{root_tag}>'
        return xml

    def _value_to_xml(self, key: str, value: Any, indent: str = '') -> str:
        """
        Convert value to XML element.

        Args:
            key: Element name
            value: Element value
            indent: Indentation string

        Returns:
            XML element string
        """
        if isinstance(value, dict):
            xml = f'{indent}<{key}>\n'
            for k, v in value.items():
                xml += self._value_to_xml(k, v, indent + '  ')
            xml += f'{indent}</{key}>\n'
            return xml

        elif isinstance(value, list):
            xml = ''
            for item in value:
                xml += f'{indent}<{key}>{self._escape_xml(item)}</{key}>\n'
            return xml

        else:
            return f'{indent}<{key}>{self._escape_xml(value)}</{key}>\n'

    def _escape_xml(self, value: Any) -> str:
        """
        Escape XML special characters.

        Args:
            value: Value to escape

        Returns:
            Escaped string
        """
        s = str(value)
        s = s.replace('&', '&amp;')
        s = s.replace('<', '&lt;')
        s = s.replace('>', '&gt;')
        s = s.replace('"', '&quot;')
        s = s.replace("'", '&apos;')
        return s
