"""HTTP response handler plugins."""

from winterforge.plugins.http_response.manager import (
    HTTPResponseHandlerManager
)

# Import plugins to trigger decorator registration
from winterforge.plugins.http_response import (  # noqa: F401
    json_handler,
    xml_handler,
)

__all__ = [
    'HTTPResponseHandlerManager',
    'json_handler',
    'xml_handler',
]
