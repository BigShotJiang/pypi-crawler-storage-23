"""Slug-based identity resolver for Frags."""

from __future__ import annotations

from typing import Any, Optional, TYPE_CHECKING
from winterforge.plugins import identity_resolver, MatchablePlugin
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.plugins._protocols.storage import StorageBackend


@identity_resolver()
@root('slug')
class SlugResolver(MatchablePlugin):
    """
    Identity resolver that maps string slugs to Frag IDs.

    Resolves human-readable slugs (e.g., "my-blog-post", "about-page")
    to their canonical Frag IDs by querying for Frags with matching
    slug field values.

    Requires Frags to have a trait that provides a "slug" field.

    Examples:
        resolver = SlugIdentityResolver()

        # Check if can resolve
        resolver.can_resolve("my-blog-post")  # → True
        resolver.can_resolve(12345)           # → False

        # Resolve to Frag ID
        frag_id = resolver.resolve("my-blog-post", storage)
        # → 456 (or None if not found)
    """

    def is_match(self, identity: Any) -> bool:
        """Check if identity is a non-empty string (slug)."""
        return isinstance(identity, str) and len(identity) > 0

    async def resolve(
        self,
        identity: Any,
        storage: StorageBackend,
        context: Optional[dict] = None
    ) -> Optional[int]:
        """
        Resolve slug to Frag ID.

        Queries storage for Frags with matching slug field value.

        Args:
            identity: Slug string to resolve
            storage: Storage backend to query
            context: Optional context data (can specify field_name)

        Returns:
            Frag ID if found, None otherwise
        """
        if not self.is_match(identity):
            return None

        if context is None:
            context = {}

        # Allow context to specify custom field name
        field_name = context.get('field_name', 'slug')

        # Query storage for Frags with matching slug field
        results = await storage.query()\
            .condition(field_name, identity)\
            .execute()

        if not results:
            return None

        # Return first match (slugs should be unique)
        return results[0].id
