"""Frag identity resolver - accepts Frags directly."""

from __future__ import annotations

from typing import Any, Optional, TYPE_CHECKING
from winterforge.plugins import identity_resolver, MatchablePlugin
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.frags import Frag
    from winterforge.plugins._protocols.storage import StorageBackend


@identity_resolver()
@root('frag')
class FragResolver(MatchablePlugin):
    """
    Frag identity resolver.

    Accepts Frag objects and extracts their canonical ID.
    This enables Frags to be passed anywhere identity is expected.

    Resolution Priority: 2nd (after FragIdResolver for int)
    - Handles Frag objects directly
    - Extracts canonical ID (frag.id)
    - Passes ID to next resolver in chain (or direct lookup)

    Example:
        user = Frag(affinities=['user'], traits=['userable'])
        await user.save()

        # Pass Frag directly
        result = await registry.get(user)  # Works!

        # FragResolver extracts user.id and resolves
    """

    def is_match(self, identity: Any) -> bool:
        """Check if identity is a Frag (uses is_match pattern)."""
        from winterforge.frags.base import Frag
        return isinstance(identity, Frag)

    async def resolve(
        self,
        identity: 'Frag',
        storage: 'StorageBackend',
        context: Optional[dict] = None
    ) -> Optional[int]:
        """
        Resolve Frag identity to Frag ID.

        Extracts canonical ID from Frag and returns it.

        Args:
            identity: Frag instance
            storage: Storage backend (unused - Frag already has ID)
            context: Optional context (unused)

        Returns:
            Frag ID if valid, None otherwise
        """
        # Simply return the Frag's ID
        return identity.id if identity.id else None


__all__ = ['FragResolver']
