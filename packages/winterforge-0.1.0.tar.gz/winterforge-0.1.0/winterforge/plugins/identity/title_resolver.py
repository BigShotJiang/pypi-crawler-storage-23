"""Title identity resolver.

Resolves Frags with 'titled' trait by their title field.
"""

from __future__ import annotations

from typing import Any, Optional

from winterforge.plugins import identity_resolver, MatchablePlugin
from winterforge.plugins.decorators import root


@identity_resolver()
@root('title')
class TitleIdentityResolver(MatchablePlugin):
    """
    Resolve Frags by title.

    Works with any Frag that has the 'titled' trait.

    Example:
        roles = RoleRegistry()
        admin_role = await roles.get('admin')  # Resolves by title

        perms = PermissionRegistry()
        delete_perm = await perms.get('user.delete')  # Resolves by title
    """

    def is_match(self, identity: Any) -> bool:
        """Check if identity is a string (title)."""
        return isinstance(identity, str)

    async def resolve(self, identity: str, storage) -> Optional[int]:
        """
        Query for Frag with matching title.

        Note: This resolver returns the FIRST Frag with the given title.
        Registry filtering will ensure it matches the expected composition.

        Args:
            identity: Title string
            storage: Storage backend

        Returns:
            Frag ID if found, None otherwise
        """
        # Query for any Frag with this title
        # Registry will filter by composition after resolution
        frags = await storage.query()\
            .condition('title', identity)\
            .execute()

        return frags[0].id if frags else None
