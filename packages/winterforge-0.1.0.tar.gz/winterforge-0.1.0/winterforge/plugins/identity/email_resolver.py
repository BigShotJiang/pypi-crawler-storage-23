"""Email identity resolver.

Resolves user Frags by email field.
"""

from typing import Any, Optional
from winterforge.plugins import identity_resolver, MatchablePlugin
from winterforge.plugins.decorators import root


@identity_resolver()
@root('email')
class EmailIdentityResolver(MatchablePlugin):
    """Resolve users by email."""

    def is_match(self, identity: Any) -> bool:
        """Check if identity is an email (string with @)."""
        return isinstance(identity, str) and '@' in identity

    async def resolve(self, identity: Any, storage) -> Optional[int]:
        """
        Query for user with matching email.

        Args:
            identity: Email (any type, checked by can_resolve)
            storage: Storage backend

        Returns:
            Frag ID if found, None otherwise
        """
        users = await storage.query()\
            .affinity('user')\
            .trait('userable')\
            .condition('email', identity)\
            .execute()

        return users[0].id if users else None
