"""Identity resolvers for Winterforge - Plugin system.

Identity resolver implementations are registered via decorators and discovered
during initialization. Import specific resolvers directly when needed:

    from winterforge.plugins.identity.frag_id_resolver import FragIdResolver
    from winterforge.plugins.identity.email_resolver import EmailIdentityResolver

Or access via manager after initialization:

    from winterforge.plugins.identity.manager import IdentityResolverManager
    resolver = IdentityResolverManager.get('email')
"""

from winterforge.plugins.identity.manager import IdentityResolverManager
from winterforge.plugins.identity.frag_resolver import FragResolver

__all__ = [
    'IdentityResolverManager',
    'FragResolver',
]
