"""Username identity resolver.

Resolves user Frags by username field.
"""

from typing import Any, Optional
from winterforge.plugins import identity_resolver, MatchablePlugin
from winterforge.plugins.decorators import root


@identity_resolver()
@root('username')
class UsernameIdentityResolver(MatchablePlugin):
    """Resolve users by username."""

    def is_match(self, identity: Any) -> bool:
        """Check if identity is a username (string without @)."""
        return (
            isinstance(identity, str) and
            '@' not in identity and
            len(identity) >= 3
        )

    async def resolve(self, identity: Any, storage) -> Optional[int]:
        """
        Query for user with matching username.

        Args:
            identity: Username (any type, checked by can_resolve)
            storage: Storage backend

        Returns:
            Frag ID if found, None otherwise
        """
        users = await storage.query()\
            .affinity('user')\
            .trait('userable')\
            .condition('username', identity)\
            .execute()

        return users[0].id if users else None
