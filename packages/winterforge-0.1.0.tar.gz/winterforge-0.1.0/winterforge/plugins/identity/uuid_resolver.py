"""UUID-based identity resolver for Frags."""

from __future__ import annotations

import uuid
from typing import Any, Optional, TYPE_CHECKING
from winterforge.plugins import identity_resolver, MatchablePlugin
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.plugins._protocols.storage import StorageBackend


@identity_resolver()
@root('uuid')
class UuidResolver(MatchablePlugin):
    """
    Identity resolver that maps UUIDs to Frag IDs.

    Resolves UUIDs (useful for external system integration) to their
    canonical Frag IDs by querying for Frags with matching uuid field values.

    Accepts both UUID objects and string representations.

    All Frags have UUIDs as a core feature (auto-generated on instantiation).
    UUIDs enable portable identity across systems and environments.

    Examples:
        resolver = UUIDIdentityResolver()

        # Check if can resolve
        from uuid import UUID
        resolver.can_resolve(UUID('...'))                    # → True
        resolver.can_resolve('550e8400-e29b-41d4-a716-...')  # → True
        resolver.can_resolve("my-slug")                      # → False

        # Resolve to Frag ID
        frag_id = resolver.resolve(UUID('...'), storage)
        # → 789 (or None if not found)
    """

    def is_match(self, identity: Any) -> bool:
        """Check if identity is a valid UUID."""
        # Already a UUID object
        if isinstance(identity, uuid.UUID):
            return True

        # Try to parse as UUID string
        try:
            uuid.UUID(str(identity))
            return True
        except (ValueError, AttributeError):
            return False

    async def resolve(
        self,
        identity: Any,
        storage: StorageBackend,
        context: Optional[dict] = None
    ) -> Optional[int]:
        """
        Resolve UUID to Frag ID.

        Queries storage for Frags with matching uuid field value.

        Args:
            identity: UUID string to resolve
            storage: Storage backend to query
            context: Optional context data (can specify field_name)

        Returns:
            Frag ID if found, None otherwise
        """
        if not self.is_match(identity):
            return None

        if context is None:
            context = {}

        # Allow context to specify custom field name
        field_name = context.get('field_name', 'uuid')

        # Query storage for Frags with matching uuid field
        results = await storage.query()\
            .condition(field_name, identity)\
            .execute()

        if not results:
            return None

        # Return first match (UUIDs should be unique)
        return results[0].id
