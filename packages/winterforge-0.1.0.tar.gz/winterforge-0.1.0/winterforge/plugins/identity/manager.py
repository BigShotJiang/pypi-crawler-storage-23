"""Identity resolver provider plugin manager."""

from __future__ import annotations

from typing import Optional, List, TYPE_CHECKING
from winterforge.plugins._base import ReorderablePluginManagerBase

if TYPE_CHECKING:
    from winterforge.plugins._protocols.storage import StorageBackend


class IdentityResolverManager(ReorderablePluginManagerBase):
    """
    Manages identity resolver provider plugins.

    Resolvers are tried in order when resolving identities to Frag IDs.
    Repository operations allow runtime reordering.

    Example:
        repo = IdentityResolverManager.repository()
        repo = repo.with_front('uuid')  # Try UUID first
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier for identity resolvers."""
        return 'winterforge.identity_resolvers'

    @classmethod
    def get_applicable(cls, identity, resolver_repo: Optional['PluginRepository'] = None) -> 'PluginRepository':
        """
        Get repository of resolvers that can handle the given identity.

        Filters the resolver chain to only include resolvers whose is_match()
        returns True for the given identity. The resulting repository maintains
        the original ordering.

        This is a convenience method that delegates to PluginRepository.filter().

        Args:
            identity: The identity to check (int, str, UUID, slug, etc.)
            resolver_repo: Optional custom repository (defaults to manager's repository)

        Returns:
            PluginRepository containing only applicable resolvers in original order

        Example:
            # Get resolvers that can handle an email
            applicable = IdentityResolverManager.get_applicable('user@example.com')
            # Returns repository with only email resolver

            # Use with custom repository
            custom_repo = IdentityResolverManager.repository().with_front('slug')
            applicable = IdentityResolverManager.get_applicable('my-post', custom_repo)

            # Or call filter() directly on repository
            applicable = IdentityResolverManager.repository()\\
                .with_front('slug')\\
                .filter(lambda r: r.is_match('my-post'))
        """
        if resolver_repo is None:
            resolver_repo = cls.repository()

        return resolver_repo.filter(lambda resolver: resolver.is_match(identity))

    @classmethod
    async def resolve(cls, identity, storage: StorageBackend) -> Optional[int]:
        """
        Resolve an identity to a Frag ID using the default resolver chain.

        Coordinates identity resolution across all registered resolvers,
        trying each in order until one succeeds. Uses the default repository
        order from IdentityResolverManager.repository().

        All identity resolvers are async - this method must be awaited.

        Args:
            identity: The identity to resolve (int, str, UUID, slug, etc.)
            storage: Storage backend to query

        Returns:
            Frag ID if resolved, None otherwise

        Example:
            frag_id = await IdentityResolverManager.resolve('user@example.com', storage)
        """
        return await cls.resolve_with_repo(identity, storage, cls.repository())

    @classmethod
    async def resolve_with_repo(
        cls,
        identity,
        storage: StorageBackend,
        resolver_repo: 'PluginRepository'
    ) -> Optional[int]:
        """
        Resolve an identity using a custom resolver repository.

        Allows registries to use custom resolver ordering for identity resolution.

        All identity resolvers are async - this method must be awaited.

        Args:
            identity: The identity to resolve
            storage: Storage backend to query
            resolver_repo: Custom resolver repository with specific ordering

        Returns:
            Frag ID if resolved, None otherwise

        Example:
            custom_repo = IdentityResolverManager.repository().with_front('slug')
            frag_id = await IdentityResolverManager.resolve_with_repo(
                'my-post', storage, custom_repo
            )
        """
        # Filter to only applicable resolvers
        applicable_repo = cls.get_applicable(identity, resolver_repo)

        # Try each applicable resolver in order
        for resolver_id in applicable_repo:
            resolver_class = cls.get(resolver_id)

            # Instantiate the resolver
            resolver = resolver_class() if isinstance(resolver_class, type) else resolver_class

            # Resolve (all resolvers are async - await the result)
            result = await resolver.resolve(identity, storage)

            if result is not None:
                return result

        # No applicable resolver could resolve it
        return None
