"""Frag ID resolver - resolves canonical integer IDs."""

from __future__ import annotations

from typing import Any, Optional, TYPE_CHECKING
from winterforge.plugins import identity_resolver, MatchablePlugin
from winterforge.plugins.decorators import root

if TYPE_CHECKING:
    from winterforge.plugins._protocols.storage import StorageBackend


@identity_resolver()
@root('frag-id')
class FragIdResolver(MatchablePlugin):
    """
    Resolves canonical Frag integer IDs.

    This resolver handles direct integer ID lookups, which is the
    most common and fastest resolution method.

    Examples:
        "123" -> 123
        "42" -> 42
    """

    def is_match(self, identity: Any) -> bool:
        """Check if identity is a valid integer or numeric string."""
        if isinstance(identity, int):
            return True
        if isinstance(identity, str):
            return identity.isdigit()
        return False

    async def resolve(self, identity, storage: StorageBackend, context: Optional[dict] = None) -> Optional[int]:
        """
        Resolve integer ID.

        Args:
            identity: The identity (str or int, must be numeric if string)
            storage: Storage backend (unused - no lookup needed)
            context: Optional context data (unused)

        Returns:
            The integer ID if valid, None otherwise
        """
        if not self.is_match(identity):
            return None

        # If already an int, return as-is
        if isinstance(identity, int):
            return identity

        # Convert string to int
        try:
            return int(identity)
        except (ValueError, OverflowError):
            return None
