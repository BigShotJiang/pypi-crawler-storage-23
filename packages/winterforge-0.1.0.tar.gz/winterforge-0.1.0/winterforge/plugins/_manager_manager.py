"""Plugin Manager Manager - manages all plugin managers."""

from __future__ import annotations
from typing import Type
from winterforge.plugins._base import PluginManagerBase
from winterforge.plugins._discovery import PluginDiscoverer
from winterforge.plugins.repository import PluginRepository


class PluginManagerManager(PluginManagerBase, PluginDiscoverer):
    """
    Manager for plugin managers with discovery coordination.

    This manager manages all other plugin managers in the system. It:
    - Provides a repository of all registered plugin managers
    - Coordinates plugin discovery across all plugin types
    - Does NOT support reordering (manager ordering is meaningless)

    Unlike other managers, this manager:
    - Uses PluginRepository (not ReorderablePluginRepository)
    - Doesn't extend ReorderablePluginManagerBase
    - Acts as both a manager AND the discovery coordinator

    Example:
        # Get all plugin managers
        managers = PluginManagerManager.repository()

        # Discover plugins for all managers
        PluginManagerManager.discover_all_plugins()

        # Get specific manager
        storage_manager = PluginManagerManager.get('winterforge.storage_backends')
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.plugin_managers'

    @classmethod
    def repository(cls) -> PluginRepository[Type[PluginManagerBase]]:
        """
        Get repository of all registered plugin managers.

        Returns a plain PluginRepository (not reorderable) since
        manager ordering is meaningless.

        Returns:
            Repository of all plugin manager classes

        Example:
            managers = PluginManagerManager.repository()
            for manager_id, manager_class in managers.items():
                print(f"{manager_id}: {manager_class.__name__}")
        """
        # Use _PLUGIN_MANAGERS from PluginDiscoverer mixin
        manager_ids = list(cls._PLUGIN_MANAGERS.keys())
        return PluginRepository(cls._PLUGIN_MANAGERS, manager_ids)

    @classmethod
    def get(cls, manager_id: str) -> Type[PluginManagerBase]:
        """
        Get a plugin manager by ID.

        Args:
            manager_id: Plugin manager identifier (e.g., 'winterforge.storage_backends')

        Returns:
            Plugin manager class

        Raises:
            KeyError: If manager_id not found

        Example:
            StorageManager = PluginManagerManager.get('winterforge.storage_backends')
            backend = StorageManager.get('sqlite')
        """
        return cls.get_manager(manager_id)

    @classmethod
    def has(cls, manager_id: str) -> bool:
        """
        Check if a plugin manager is registered.

        Args:
            manager_id: Plugin manager identifier

        Returns:
            True if manager is registered

        Example:
            if PluginManagerManager.has('winterforge.storage_backends'):
                # Use storage manager
        """
        return cls.has_manager(manager_id)

    @classmethod
    def all(cls) -> list[Type[PluginManagerBase]]:
        """
        Get all registered plugin managers as a list.

        Returns:
            List of all plugin manager classes

        Example:
            for manager_class in PluginManagerManager.all():
                print(manager_class.plugin_id())
        """
        return list(cls._PLUGIN_MANAGERS.values())
