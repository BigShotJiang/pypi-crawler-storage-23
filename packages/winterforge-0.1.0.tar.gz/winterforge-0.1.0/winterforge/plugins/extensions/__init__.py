"""Extension management system for WinterForge.

Handles extension installation, uninstallation, and field preservation.
"""

from ._manager import ExtensionInstallerManager

__all__ = ['ExtensionInstallerManager']
