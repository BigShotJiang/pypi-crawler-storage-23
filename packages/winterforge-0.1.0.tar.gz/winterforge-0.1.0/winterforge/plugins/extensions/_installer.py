"""Extension installer base class."""

from typing import List, Dict, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class ExtensionInstaller:
    """
    Base class for extension installers.

    Extensions define install/uninstall behavior for WinterForge modules.
    Traits are discovered automatically via package introspection.

    Key Features:
    - Auto-discovery of provided traits (no manual tagging)
    - Impact analysis before uninstall
    - Field preservation (data not deleted)
    - Optional custom data management

    Examples:
        @extension_installer('blog')
        class BlogExtension(ExtensionInstaller):
            extension_id = 'blog'
            version = '1.0.0'

            async def install_data(self):
                # Create default categories
                categories = ['Tutorial', 'News', 'Opinion']
                for name in categories:
                    category = Frag(
                        affinities=['blog-category'],
                        traits=['titled', 'sluggable']
                    )
                    category.set_title(name)
                    category.set_slug(name.lower())
                    await category.save()

                return {
                    'categories': len(categories),
                    'message': f"Created {len(categories)} default categories"
                }
    """

    extension_id: str = None
    version: str = '1.0.0'

    def get_provided_traits(self) -> List[str]:
        """
        Discover traits provided by this extension.

        Introspects package namespace to find traits.
        No manual tagging needed - automatic discovery.

        Returns:
            List of trait IDs

        Example:
            # For 'winterforge_blog' extension
            blog = BlogExtension()
            traits = blog.get_provided_traits()
            # Returns: ['blog_post', 'blog_category', ...]
        """
        # Get this extension's package
        package_name = self.__module__.split('.')[0]

        # Find all traits in this package
        from winterforge.plugins import FragTraitManager

        all_traits = FragTraitManager.repository().items()

        # Filter to traits from this package
        provided = []
        for trait_id, trait_class in all_traits:
            trait_module = trait_class.__module__
            if trait_module.startswith(package_name):
                provided.append(trait_id)

        return provided

    async def install_data(self) -> dict:
        """
        Install default data.

        Called during: winterforge install extension {id}

        Override in subclass to create default categories, templates,
        configurations, etc.

        Returns:
            Installation statistics

        Example:
            async def install_data(self):
                # Create default post types
                types = ['article', 'tutorial', 'news']
                for type_name in types:
                    # Create Frag
                    pass

                return {
                    'post_types': len(types),
                    'message': 'Default post types created'
                }
        """
        return {}

    async def uninstall_check(self) -> dict:
        """
        Analyze impact of uninstall.

        Returns info about Frags using extension traits.
        Does NOT delete anything - just reports.

        Returns:
            Dict with impact analysis

        Example:
            check = await blog_ext.uninstall_check()
            # {
            #     'affected_frags': {'blog_post': 247, 'blog_category': 12},
            #     'total': 259,
            #     'message': 'Found 259 Frags using blog traits...'
            # }
        """
        from winterforge.plugins.query._repository import QueryRepository
        from winterforge.plugins.query._operators import QueryOperator

        # Get traits provided by this extension
        provided_traits = self.get_provided_traits()

        # Find Frags using these traits
        affected = {}
        for trait_id in provided_traits:
            query = QueryRepository().condition(
                'traits',
                trait_id,
                QueryOperator.CONTAINS
            )
            count = await query.count()
            if count > 0:
                affected[trait_id] = count

        total = sum(affected.values())

        return {
            'affected_frags': affected,
            'total': total,
            'message': (
                f"Found {total} Frags using {self.extension_id} traits. "
                "These will lose functionality if extension uninstalled. "
                "Data will be preserved for export."
            )
        }

    async def uninstall_data(self):
        """
        Handle data during uninstall.

        Default: Do nothing (preserve all data).

        Override in subclass for custom behavior:
        - Export important data before cleanup
        - Archive to alternative location
        - Migrate to different extension

        Example:
            async def uninstall_data(self):
                # Export all blog posts before uninstall
                transport = YamlDataTransport()
                await transport.dump(
                    'blog_backup.yaml',
                    query=QueryRepository().condition('affinities', 'blog-post')
                )

                return {
                    'exported': True,
                    'message': 'Blog posts exported to blog_backup.yaml'
                }
        """
        return {}
