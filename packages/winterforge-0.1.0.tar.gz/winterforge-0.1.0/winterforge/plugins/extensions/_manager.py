"""Extension installer plugin manager."""

from __future__ import annotations

from winterforge.plugins._base import ReorderablePluginManagerBase


class ExtensionInstallerManager(ReorderablePluginManagerBase):
    """
    Manages extension installer plugins.

    Extension installers handle lifecycle management for WinterForge
    extensions including installation, data setup, and uninstallation
    with field preservation.

    Example:
        from winterforge.extensions.manager import ExtensionInstallerManager
        blog_installer = ExtensionInstallerManager.get('blog')
        await blog_installer.install_data()
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return plugin manager identifier for extension installers."""
        return 'winterforge.extension_installers'
