"""Lifecycle management for plugins.

Coordinates startup and shutdown of plugins implementing LifecycleAware.
"""

from __future__ import annotations

import asyncio
from typing import List, Any
from winterforge.plugins._protocols import LifecycleAware


class LifecycleManager:
    """
    Manages plugin lifecycle events.

    Tracks plugins implementing LifecycleAware and ensures proper
    startup/shutdown sequencing with error handling.

    Example:
        >>> manager = LifecycleManager()
        >>> manager.register(database_pool)
        >>> manager.register(cache_manager)
        >>>
        >>> # At application startup
        >>> await manager.startup_all()
        >>>
        >>> # At application shutdown
        >>> await manager.shutdown_all()
    """

    def __init__(self) -> None:
        """Initialize lifecycle manager."""
        self._plugins: List[LifecycleAware] = []
        self._started: bool = False

    def register(self, plugin: Any) -> None:
        """
        Register plugin for lifecycle management.

        Only plugins implementing LifecycleAware are registered.
        Non-lifecycle plugins are safely ignored.

        Args:
            plugin: Plugin instance to register
        """
        if isinstance(plugin, LifecycleAware):
            self._plugins.append(plugin)

    def get_registered_count(self) -> int:
        """
        Get count of registered lifecycle-aware plugins.

        Returns:
            int: Number of registered plugins
        """
        return len(self._plugins)

    async def startup_all(self) -> None:
        """
        Start all registered plugins.

        Calls startup() on each plugin in registration order.
        Continues even if individual plugins fail, collecting errors.

        Raises:
            RuntimeError: If any plugin startup fails (after attempting all)
        """
        if self._started:
            return

        errors = []
        for plugin in self._plugins:
            try:
                await plugin.startup()
            except Exception as e:
                plugin_name = plugin.__class__.__name__
                errors.append(f"{plugin_name}: {e}")

        self._started = True

        if errors:
            error_msg = f"Plugin startup failures:\n{'\n'.join(f'  - {e}' for e in errors)}"
            raise RuntimeError(error_msg)

    async def shutdown_all(self) -> None:
        """
        Shutdown all registered plugins.

        Calls shutdown() on each plugin in reverse registration order.
        Continues even if individual plugins fail, collecting errors.

        Safe to call multiple times or even if startup_all() failed.
        """
        if not self._started:
            return

        errors = []
        # Shutdown in reverse order
        for plugin in reversed(self._plugins):
            try:
                await plugin.shutdown()
            except Exception as e:
                plugin_name = plugin.__class__.__name__
                errors.append(f"{plugin_name}: {e}")

        self._started = False

        if errors:
            # Log but don't raise - shutdown should be best-effort
            import warnings
            error_msg = f"Plugin shutdown failures:\n{'\n'.join(f'  - {e}' for e in errors)}"
            warnings.warn(error_msg, RuntimeWarning)

    def reset(self) -> None:
        """Reset manager state (primarily for testing)."""
        self._plugins = []
        self._started = False


# Global singleton instance
_lifecycle_manager: LifecycleManager | None = None


def get_lifecycle_manager() -> LifecycleManager:
    """
    Get global lifecycle manager instance.

    Returns:
        LifecycleManager: Global singleton
    """
    global _lifecycle_manager
    if _lifecycle_manager is None:
        _lifecycle_manager = LifecycleManager()
    return _lifecycle_manager


def reset_lifecycle_manager() -> None:
    """Reset global lifecycle manager (for testing)."""
    global _lifecycle_manager
    if _lifecycle_manager is not None:
        _lifecycle_manager.reset()
    _lifecycle_manager = None
