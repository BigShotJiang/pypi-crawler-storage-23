"""CLI entry point for python -m winterforge.plugins.cli"""

from . import cli

if __name__ == '__main__':
    cli()
