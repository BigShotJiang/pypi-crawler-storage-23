"""CLI context detection and result helpers."""

import contextvars
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from winterforge.frags.base import Frag

# Context variable to track CLI execution
_cli_context = contextvars.ContextVar('cli_context', default=False)


def in_cli_context() -> bool:
    """
    Check if currently executing in CLI context.

    Returns:
        True if in CLI, False if programmatic
    """
    return _cli_context.get()


def set_cli_context(value: bool):
    """
    Set CLI context flag.

    Args:
        value: True for CLI context, False for programmatic
    """
    _cli_context.set(value)


def cli_result(
    success: bool,
    message: str,
    result_frag: Optional['Frag'] = None,
    data: Optional[dict] = None
) -> 'Frag':
    """
    Create a CLI result Frag.

    Args:
        success: Whether operation succeeded
        message: Human-readable output message
        result_frag: Optional reference to created/modified Frag
        data: Optional additional structured data

    Returns:
        CLIResult Frag

    Example:
        return cli_result(
            success=True,
            message=f"✓ User created: {user.username} (ID: {user.id})",
            result_frag=user,
            data={'roles': ['admin']}
        )
    """
    from winterforge.frags.base import Frag

    result = Frag(
        affinities=['cli_result'],
        traits=['cli_result']
    )

    result.set_success(success)
    result.set_message(message)

    if result_frag:
        result.set_result_frag_id(result_frag.id)

    if data:
        result.set_data(data)

    return result


def cli_error(message: str, data: Optional[dict] = None) -> 'Frag':
    """
    Create a CLI error result.

    Args:
        message: Error message
        data: Optional additional error data

    Returns:
        CLIResult Frag with success=False

    Example:
        return cli_error(f"Error: User not found: {identity}")
    """
    return cli_result(success=False, message=message, data=data)
