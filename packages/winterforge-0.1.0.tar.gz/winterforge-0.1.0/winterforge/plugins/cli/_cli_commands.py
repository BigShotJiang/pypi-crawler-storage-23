"""Dynamic CLI builder.

Builds Click CLI application from registered @cli_command decorators.
"""

import sys
import click
import asyncio
from functools import wraps
from typing import Any, Dict
from click.exceptions import Exit

from ._manager import CLICommandManager
from winterforge.plugins.output_formatters.source import FormatterSource


def async_command(f):
    """Decorator to run async Click commands."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        return asyncio.run(f(*args, **kwargs))
    return wrapper


def build_cli() -> click.Group:
    """
    Build Click CLI application from registered commands.

    Discovers all @cli_command decorated classes and methods,
    and constructs a Click command hierarchy.

    Returns:
        click.Group: Root CLI application
    """
    # Resolve parent commands first
    CLICommandManager.resolve_parent_commands()

    # Create root CLI group
    @click.group()
    @click.option('--quiet', '-q', is_flag=True, help='Minimal output')
    @click.option('--debug', is_flag=True, help='Verbose debug output')
    @click.option(
        '--format',
        type=click.Choice(['json', 'yaml', 'csv'], case_sensitive=False),
        help='Output format for structured data',
    )
    @click.pass_context
    def cli(ctx, quiet, debug, format):
        """Winterforge management CLI."""
        # Store flags in context for formatters
        ctx.ensure_object(dict)
        ctx.obj['flags'] = {
            'quiet': quiet,
            'debug': debug,
            'format': format,
        }

    # Add command groups
    for group_name, group_meta in CLICommandManager.get_all_groups().items():
        group_cmd = _build_group(group_name, group_meta)
        cli.add_command(group_cmd)

    # Add standalone commands
    for cmd_meta in CLICommandManager.get_standalone_commands():
        cmd = _build_command(cmd_meta)
        cli.add_command(cmd)

    return cli


def _build_group(group_name: str, group_meta: Dict[str, Any]) -> click.Group:
    """
    Build a Click command group.

    Args:
        group_name: Name of the group
        group_meta: Group metadata

    Returns:
        click.Group: Command group
    """
    @click.group(name=group_name, help=group_meta.get('help'), hidden=group_meta.get('hidden', False))
    def group():
        pass

    # Add epilog if provided
    if group_meta.get('epilog'):
        group.epilog = group_meta['epilog']

    # Add commands to this group
    for cmd_meta in CLICommandManager.get_commands_for_group(group_name):
        cmd = _build_command(cmd_meta)
        group.add_command(cmd)

    return group


def _build_command(cmd_meta: Dict[str, Any]) -> click.Command:
    """
    Build a Click command from metadata.

    Args:
        cmd_meta: Command metadata

    Returns:
        click.Command: Click command
    """
    cmd_name = cmd_meta['name']
    help_text = cmd_meta.get('help')
    arguments = cmd_meta.get('arguments', [])
    options = cmd_meta.get('options', {})
    is_async = cmd_meta.get('is_async', False)
    hidden = cmd_meta.get('hidden', False)
    epilog = cmd_meta.get('epilog')

    # Create the command function
    @click.pass_context
    async def command_impl(ctx, **kwargs):
        """Execute the registered command."""
        from ._context import set_cli_context
        from winterforge.plugins.output_formatters.manager import (
            OutputFormatterManager,
        )
        from winterforge.plugins.cli.main import StorageBootstrap

        # Set CLI context for this execution
        set_cli_context(True)

        # Ensure storage is bootstrapped before command execution
        # This allows CLI commands to work in both main() and CliRunner contexts
        await StorageBootstrap.ensure()

        try:
            result = await CLICommandManager.execute_command(cmd_meta, **kwargs)

            # Check for failed GET operations (success=False in cli_result)
            # Only GET operations should exit with code 1 on failure
            # Other operations (delete, create, etc.) can fail gracefully with code 0
            if hasattr(result, 'affinities') and 'cli_result' in result.affinities:
                if result.success is False:
                    cmd_name = cmd_meta.get('name', '').lower()
                    is_get_operation = cmd_name in ('get', 'show', 'find', 'load')
                    if is_get_operation:
                        # Failed GET: resource not found - print message and raise Exit
                        if hasattr(result, 'message'):
                            click.echo(result.message)
                        raise Exit(1)

            # Build formatter source
            flags = ctx.obj.get('flags', {}) if ctx.obj else {}
            formatter_source = FormatterSource(
                flags=flags,
                args=kwargs,
                metadata=cmd_meta,
                result=result,
            )

            # Format output using OutputFormatterManager
            try:
                formatted = OutputFormatterManager.format(result, formatter_source)
                if formatted:
                    click.echo(formatted)
            except RuntimeError as e:
                # No formatter applied - fallback to string representation
                if result:
                    click.echo(str(result))

            return result

        finally:
            # Reset CLI context
            set_cli_context(False)

    # Wrap async commands
    if is_async:
        command_impl = async_command(command_impl)

    # Apply Click decorators in reverse order (bottom-up)
    # Start with options
    for opt_name, opt_config in reversed(options.items()):
        # Build option name (e.g., 'role' -> '--role')
        opt_flag = f"--{opt_name.replace('_', '-')}"

        # Extract Click option parameters
        is_flag = opt_config.get('is_flag', False)
        default = opt_config.get('default')
        help_str = opt_config.get('help')
        prompt = opt_config.get('prompt', False)
        hide_input = opt_config.get('hide_input', False)
        confirmation_prompt = opt_config.get('confirmation_prompt', False)
        opt_type = opt_config.get('type')

        # Build Click option
        if is_flag:
            command_impl = click.option(
                opt_flag,
                opt_name,
                is_flag=True,
                default=default,
                help=help_str
            )(command_impl)

        elif prompt:
            command_impl = click.option(
                opt_flag,
                opt_name,
                prompt=prompt if isinstance(prompt, str) else opt_name,
                hide_input=hide_input,
                confirmation_prompt=confirmation_prompt,
                help=help_str
            )(command_impl)

        else:
            kwargs_dict = {
                'default': default,
                'help': help_str,
            }
            if opt_type:
                kwargs_dict['type'] = opt_type
            # Check for multiple option
            if opt_config.get('multiple', False):
                kwargs_dict['multiple'] = True
            command_impl = click.option(
                opt_flag,
                opt_name,
                **{k: v for k, v in kwargs_dict.items() if v is not None}
            )(command_impl)

    # Apply arguments
    for arg_name in reversed(arguments):
        command_impl = click.argument(arg_name)(command_impl)
    # Create the command
    cmd = click.command(
        name=cmd_name,
        help=help_text,
        hidden=hidden,
    )(command_impl)
    # Add epilog if provided
    if epilog:
        cmd.epilog = epilog
    return cmd


if __name__ == '__main__':
    # CLI commands are registered via imports in main.py
    # Build and run CLI
    cli = build_cli()
    cli()
