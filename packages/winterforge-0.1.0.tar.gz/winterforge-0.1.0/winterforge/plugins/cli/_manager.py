"""CLI Command Manager.

Manages registration and discovery of CLI commands from plugins, managers, and registries.
"""

from __future__ import annotations
from typing import Dict, List, Any, Optional
import asyncio


class CLICommandManager:
    """
    Manager for CLI command registration and discovery.

    Commands are registered via the @cli_command decorator and organized into
    groups (command classes) and subcommands (methods).
    """

    # Storage for registered commands
    _groups: Dict[str, Dict[str, Any]] = {}
    _commands: Dict[str, List[Dict[str, Any]]] = {}  # group_name -> [commands]
    _standalone_commands: List[Dict[str, Any]] = []

    @classmethod
    def register_command_group(cls, metadata: Dict[str, Any]) -> None:
        """
        Register a command group (decorated class).

        Multiple classes can share the same root namespace - their commands
        are merged into the same group.

        Args:
            metadata: Group metadata including name, class, inject config
        """
        group_name = metadata['name']
        group_class = metadata['class']

        if group_name in cls._groups:
            # Group exists - merge this class into it
            existing = cls._groups[group_name]

            # Add class to classes list
            if group_class not in existing['classes']:
                existing['classes'].append(group_class)

                # Merge inject configs
                if metadata.get('inject'):
                    existing.setdefault('inject', {}).update(metadata['inject'])
        else:
            # New group - create with classes list
            metadata['classes'] = [group_class]
            cls._groups[group_name] = metadata

        # Initialize command list for this group
        if group_name not in cls._commands:
            cls._commands[group_name] = []

    @classmethod
    def register_command(cls, metadata: Dict[str, Any]) -> None:
        """
        Register a CLI command (decorated method/function).

        Args:
            metadata: Command metadata including name, callable, arguments, options
        """
        group = metadata.get('group')

        if group and group != '__PARENT__':
            # Command belongs to a group
            if group not in cls._commands:
                cls._commands[group] = []
            cls._commands[group].append(metadata)
        else:
            # Standalone command or needs parent resolution
            cls._standalone_commands.append(metadata)

    @classmethod
    def resolve_parent_commands(cls) -> None:
        """
        Resolve commands marked with __PARENT__ to their actual parent group.

        Called after all classes are loaded to link methods to their parent groups.
        Commands that can't find a parent group are converted to standalone commands.
        """
        unresolved = [cmd for cmd in cls._standalone_commands if cmd.get('group') == '__PARENT__']

        for cmd in unresolved:
            callable_obj = cmd['callable']
            resolved = False

            # Get the parent class from __qualname__
            if hasattr(callable_obj, '__qualname__') and '.' in callable_obj.__qualname__:
                # Extract parent class name from qualname
                # e.g., 'UserCommands.create_user' -> 'UserCommands'
                # e.g., 'test_function.<locals>.UserCommands.create_user' -> 'UserCommands'
                class_qualname = callable_obj.__qualname__.rsplit('.', 1)[0]
                simple_class_name = class_qualname.split('.')[-1]

                # Try to find the parent class object (may not be in _groups yet)
                parent_class = None
                for group_meta in cls._groups.values():
                    # Check all classes in the group
                    for cls_obj in group_meta.get('classes', []):
                        if (cls_obj and
                            (cls_obj.__qualname__ == class_qualname or
                             cls_obj.__name__ == simple_class_name)):
                            parent_class = cls_obj
                            break
                    if parent_class:
                        break

                # If no group found, try to find class in loaded modules
                if not parent_class:
                    import sys
                    for module in sys.modules.values():
                        if module and hasattr(module, simple_class_name):
                            potential_class = getattr(module, simple_class_name)
                            import inspect
                            if (inspect.isclass(potential_class) and
                                (potential_class.__qualname__ == class_qualname or
                                 potential_class.__name__ == simple_class_name)):
                                parent_class = potential_class
                                break

                # Check if parent class has @root namespace
                if parent_class:
                    from winterforge.plugins.decorators.root import get_root_namespace
                    root_ns = get_root_namespace(parent_class)
                    if root_ns:
                        if root_ns not in cls._groups:
                            # Auto-register new group from @root namespace
                            import inspect
                            from winterforge.plugins.decorators.root import get_root_metadata
                            inject = get_root_metadata(parent_class, 'inject', {})
                            # Use explicit help, or class docstring, or default
                            help_text = get_root_metadata(parent_class, 'help', None)
                            if help_text is None:
                                help_text = inspect.getdoc(parent_class) or f'{root_ns.title()} commands'
                            hidden = get_root_metadata(parent_class, 'hidden', False)
                            epilog = get_root_metadata(parent_class, 'epilog', None)

                            group_metadata = {
                                'type': 'group',
                                'name': root_ns,
                                'help': help_text,
                                'class': parent_class,
                                'inject': inject,
                                'hidden': hidden,
                                'epilog': epilog,
                            }
                            cls.register_command_group(group_metadata)
                        else:
                            # Group exists - ensure this class is in the classes list
                            existing = cls._groups[root_ns]
                            if parent_class not in existing.get('classes', []):
                                existing.setdefault('classes', []).append(parent_class)
                                # Merge inject configs
                                from winterforge.plugins.decorators.root import get_root_metadata
                                inject = get_root_metadata(parent_class, 'inject', {})
                                if inject:
                                    existing.setdefault('inject', {}).update(inject)

                # Find matching group by comparing against all classes in each group
                for group_name, group_meta in cls._groups.items():
                    # Check all classes in this group
                    for parent_class in group_meta.get('classes', []):
                        # Match on either full qualname or simple name
                        if (parent_class.__qualname__ == class_qualname or
                            parent_class.__name__ == simple_class_name):
                            cmd['group'] = group_name
                            cmd['parent_class'] = parent_class
                            cmd['parent_inject'] = group_meta.get('inject', {})

                            # Move to group commands
                            if group_name not in cls._commands:
                                cls._commands[group_name] = []
                            cls._commands[group_name].append(cmd)
                            cls._standalone_commands.remove(cmd)
                            resolved = True
                            break
                    if resolved:
                        break

            # If no parent group found, convert to standalone command
            if not resolved:
                # Standalone command - group name is the command name
                cmd['group'] = cmd['name']

                # Extract parent class for method binding during execution
                # For methods on non-decorated classes, we need to find the parent class
                import inspect
                import sys

                sig = inspect.signature(callable_obj)
                params = list(sig.parameters.values())
                if params and params[0].name == 'self':
                    # This is a method - find the class that owns it
                    if hasattr(callable_obj, '__self__'):
                        # Already bound
                        cmd['parent_class'] = callable_obj.__self__.__class__
                    else:
                        # Unbound method - search for the owning class
                        # Get expected class name from qualname
                        class_qualname = callable_obj.__qualname__.rsplit('.', 1)[0]
                        simple_class_name = class_qualname.split('.')[-1]

                        # Search through all classes in all modules
                        found_class = None

                        # First check globals
                        if hasattr(callable_obj, '__globals__'):
                            for obj in callable_obj.__globals__.values():
                                if inspect.isclass(obj):
                                    # Check if this method belongs to this class
                                    for attr_name, attr_value in inspect.getmembers(obj):
                                        if attr_value is callable_obj:
                                            found_class = obj
                                            break
                                if found_class:
                                    break

                        # If not found in globals, use gc to find referrers
                        if not found_class:
                            import gc
                            # Get all objects that reference this function
                            referrers = gc.get_referrers(callable_obj)
                            for ref in referrers:
                                if isinstance(ref, dict):
                                    # This might be a class __dict__
                                    # Check if this dict belongs to a class
                                    for obj in gc.get_referrers(ref):
                                        if inspect.isclass(obj) and obj.__name__ == simple_class_name:
                                            # Verify this method belongs to this class
                                            if hasattr(obj, callable_obj.__name__) and getattr(obj, callable_obj.__name__) is callable_obj:
                                                found_class = obj
                                                break
                                if found_class:
                                    break

                        if found_class:
                            cmd['parent_class'] = found_class

                            # Check if found_class has @root namespace
                            from winterforge.plugins.decorators.root import get_root_namespace, get_root_metadata
                            root_ns = get_root_namespace(found_class)
                            if root_ns:
                                if root_ns not in cls._groups:
                                    # Auto-register new group from @root namespace
                                    inject = get_root_metadata(found_class, 'inject', {})
                                    # Use explicit help, or class docstring, or default
                                    help_text = get_root_metadata(found_class, 'help', None)
                                    if help_text is None:
                                        help_text = inspect.getdoc(found_class) or f'{root_ns.title()} commands'
                                    hidden = get_root_metadata(found_class, 'hidden', False)
                                    epilog = get_root_metadata(found_class, 'epilog', None)

                                    group_metadata = {
                                        'type': 'group',
                                        'name': root_ns,
                                        'help': help_text,
                                        'class': found_class,
                                        'inject': inject,
                                        'hidden': hidden,
                                        'epilog': epilog,
                                    }
                                    cls.register_command_group(group_metadata)
                                else:
                                    # Group exists - ensure this class is in the classes list
                                    existing = cls._groups[root_ns]
                                    if found_class not in existing.get('classes', []):
                                        existing.setdefault('classes', []).append(found_class)
                                        # Merge inject configs
                                        inject = get_root_metadata(found_class, 'inject', {})
                                        if inject:
                                            existing.setdefault('inject', {}).update(inject)

                                # Move command to the root namespace group
                                cmd['group'] = root_ns
                                cmd['parent_inject'] = inject
                                if root_ns not in cls._commands:
                                    cls._commands[root_ns] = []
                                cls._commands[root_ns].append(cmd)
                                cls._standalone_commands.remove(cmd)

    @classmethod
    def get_all_groups(cls) -> Dict[str, Dict[str, Any]]:
        """Get all registered command groups."""
        return cls._groups.copy()

    @classmethod
    def get_commands_for_group(cls, group_name: str) -> List[Dict[str, Any]]:
        """Get all commands for a specific group."""
        return cls._commands.get(group_name, []).copy()

    @classmethod
    def get_standalone_commands(cls) -> List[Dict[str, Any]]:
        """Get all standalone commands (not in a group)."""
        return [cmd for cmd in cls._standalone_commands if cmd.get('group') != '__PARENT__']

    @classmethod
    async def resolve_injection(cls, inject_config: Dict[str, str]) -> Dict[str, Any]:
        """
        Resolve injection identities to actual Frags.

        Args:
            inject_config: Dict of {param_name: identity}

        Returns:
            Dict of {param_name: resolved_frag}

        Example:
            inject_config = {'admin': 'admin@system.com', 'role': 'superadmin'}
            result = {'admin': <User Frag>, 'role': <Role Frag>}
        """
        from winterforge.frags.registries.user_registry import UserRegistry

        resolved = {}

        for param_name, identity in inject_config.items():
            # Try to resolve as user first (most common case)
            users = UserRegistry()
            frag = await users.get(identity)

            if frag:
                resolved[param_name] = frag
            else:
                # Could extend to try other registries
                # For now, just skip if not found
                pass

        return resolved

    @classmethod
    def reset(cls) -> None:
        """Reset all registered commands (for testing)."""
        cls._groups = {}
        cls._commands = {}
        cls._standalone_commands = []

    @classmethod
    async def execute_command(cls, metadata: Dict[str, Any], **kwargs) -> Any:
        """
        Execute a registered command.

        Handles:
        - Class instantiation with identity injection
        - Async vs sync execution
        - Argument passing

        Args:
            metadata: Command metadata
            **kwargs: Arguments to pass to the command

        Returns:
            Command result
        """
        import inspect

        callable_obj = metadata['callable']
        is_async = metadata.get('is_async', False)

        # Check if this is a method that needs parent class instantiation
        parent_class = metadata.get('parent_class')
        parent_inject = metadata.get('parent_inject', {})

        # Also check if callable is a method (has self parameter)
        if not parent_class and hasattr(callable_obj, '__qualname__') and '.' in callable_obj.__qualname__:
            # This is a method on a non-decorated class (standalone command)
            # Need to extract and instantiate the parent class
            sig = inspect.signature(callable_obj)
            params = list(sig.parameters.values())
            if params and params[0].name == 'self':
                # Get the class from the method's qualname
                class_qualname = callable_obj.__qualname__.rsplit('.', 1)[0]
                # Try to get the class from the callable's globals
                if hasattr(callable_obj, '__globals__'):
                    simple_class_name = class_qualname.split('.')[-1]
                    parent_class = callable_obj.__globals__.get(simple_class_name)

        if parent_class:
            # Resolve injection identities
            inject_kwargs = await cls.resolve_injection(parent_inject) if parent_inject else {}

            # Instantiate parent class
            instance = parent_class(**inject_kwargs)

            # Bind method to instance
            bound_method = callable_obj.__get__(instance, parent_class)

            # Execute
            if is_async:
                result = await bound_method(**kwargs)
            else:
                result = bound_method(**kwargs)
        else:
            # Standalone function
            if is_async:
                result = await callable_obj(**kwargs)
            else:
                result = callable_obj(**kwargs)

        # Auto-wrap domain Frags in CLIResult when in CLI context
        result = await cls._auto_wrap_cli_result(result, metadata, kwargs)
        return result

    @classmethod
    async def _auto_wrap_cli_result(cls, result: Any, metadata: Dict[str, Any], kwargs: Dict[str, Any]) -> Any:
        """
        Auto-wrap command results in CLIResult when in CLI context.

        Intelligently handles all result types:
        - Booleans: Uses message_success/message_failure from decorator
        - None: "Not found" errors with entity context
        - Frags: Success messages with entity details
        - Lists: Count summaries
        - Custom printers via @cli_command(printer='custom')

        Args:
            result: The original method return value
            metadata: Command metadata (includes message templates)
            kwargs: Command arguments (for token replacement)

        Returns:
            Original result (if not CLI) or CLIResult Frag
        """
        from ._context import in_cli_context, cli_result, cli_error
        from winterforge.plugins.status_printers.manager import StatusPrinterManager

        # Only wrap if in CLI context
        if not in_cli_context():
            return result

        # Don't wrap if already a CLIResult
        if hasattr(result, 'affinities') and 'cli_result' in result.affinities:
            return result

        # Get printer preference from metadata
        printer_id = metadata.get('printer')

        # Format using StatusPrinter plugins
        message = await StatusPrinterManager.format_result(result, metadata, kwargs, printer_id)

        # If no printer could format it, pass through unchanged
        if message is None:
            return result

        # Determine success based on result type
        if isinstance(result, bool):
            # Boolean results: True = success, False = failure
            success = result
        elif result is None:
            # None results: Always failure (not found)
            success = False
        else:
            # Other results (Frags, lists): Always success
            success = True

        # Wrap in CLIResult
        # For single Frags, include the result_frag reference
        result_frag = result if hasattr(result, 'id') else None

        return cli_result(
            success=success,
            message=message,
            result_frag=result_frag
        )
