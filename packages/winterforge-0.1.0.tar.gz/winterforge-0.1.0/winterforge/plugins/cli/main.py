"""
WinterForge CLI entry point.

Discovers and executes commands via @cli_command decorators.
"""

import sys
from rich.console import Console
from rich.traceback import install

# Install rich tracebacks for debugging
install(show_locals=True)

console = Console(stderr=True)  # Errors to stderr

# Register slug convertors (needed before plugin discovery)
from winterforge.plugins.slug_convertors.bootstrap import (
    register_builtin_convertors,
)

register_builtin_convertors()

# Discover plugins (traits, storage, etc.)
from winterforge.plugins import discover_plugins

discover_plugins()

# Import cli_result trait explicitly (for CLI output formatting)
import winterforge.frags.traits.cli_result

# Register bootstrap source providers
from winterforge.plugins.bootstrap.bootstrap import register_builtin_providers

register_builtin_providers()

# Discover and configure storage from bootstrap
import asyncio
from winterforge.plugins.bootstrap import BootstrapSourceManager
from winterforge.frags.traits.persistable import set_storage


class StorageBootstrap:
    """
    Manages lazy initialization of storage backend.

    Encapsulates bootstrap state to avoid module-level globals.
    """
    _initialized = False
    _last_config_hash = None

    @classmethod
    async def ensure(cls):
        """
        Ensure storage is bootstrapped (lazy initialization).

        Re-bootstraps if environment has changed (for testing with CliRunner).
        Handles ContextVar reset between CLI invocations.
        """
        # Check if we need to re-bootstrap due to environment changes
        import os
        from winterforge.frags.traits.persistable import get_storage

        config_hash = hash((
            os.environ.get('WINTERFORGE_DB'),
            os.environ.get('WINTERFORGE_STORAGE_BACKEND'),
        ))

        # Check if storage is set in current context (ContextVar)
        # Even if initialized, context might be fresh (e.g., between CliRunner invokes)
        if cls._initialized and cls._last_config_hash == config_hash and get_storage():
            # Already initialized with same config AND storage set in context
            return

        storage = await cls._discover()
        if storage:
            set_storage(storage)

        cls._initialized = True
        cls._last_config_hash = config_hash

    @classmethod
    async def _discover(cls):
        """
        Discover and instantiate storage from bootstrap sources.

        Returns:
            Storage backend instance, or None if no config found
        """
        config = await BootstrapSourceManager.discover()
        if not config:
            return None

        backend = config.pop('backend')

        # Use plugin manager to instantiate backend
        from winterforge.plugins.storage import StorageManager
        storage = StorageManager.get(backend, **config)

        # Ensure connection is established (creates database file)
        # Only for real storage backends (not mocks in tests)
        if storage and hasattr(storage, '_ensure_connection'):
            import inspect
            if inspect.iscoroutinefunction(storage._ensure_connection):
                await storage._ensure_connection()

        return storage

# Register output formatters
from winterforge.plugins.output_formatters.bootstrap import (
    register_builtin_formatters,
)

register_builtin_formatters()

# Register validators
from winterforge.plugins.validators import bootstrap as validator_bootstrap

# Import modules containing @cli_command decorated classes/methods
# Imports trigger decorator registration automatically
from winterforge.installer import commands as installer_commands
from winterforge.installer import profile_installer

from winterforge.frags.registries import (
    user_registry,
    role_registry,
    permission_registry,
    session_registry,
    config_registry,
    field_registry,
    profile_registry,
)

# Build Click CLI from registered commands
from ._cli_commands import build_cli

cli = build_cli()


def main():
    """
    WinterForge CLI entry point.

    Executes the Click command tree with error handling.

    Exit Codes:
        0: Success
        1: Error
        130: Keyboard interrupt
    """
    try:
        # Lazy storage bootstrap (only runs once)
        asyncio.run(StorageBootstrap.ensure())

        # Execute Click command tree
        # Click handles arg parsing, help text, command routing
        cli()

    except KeyboardInterrupt:
        # Ctrl+C pressed
        console.print("\n[yellow]Interrupted[/yellow]")
        sys.exit(130)

    except Exception as e:
        # Application error
        console.print(f"[red]Error:[/red] {e}")

        # Show full traceback if --debug flag present
        if "--debug" in sys.argv:
            raise

        sys.exit(1)


if __name__ == "__main__":
    main()
