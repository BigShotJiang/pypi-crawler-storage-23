"""CLI command name validation utilities."""

import re
import warnings
from typing import Optional


class CommandNameValidator:
    """Validates command names for CLI usage."""

    # Valid: lowercase, numbers, hyphens (kebab-case)
    # Invalid: uppercase, underscores, spaces, special chars
    VALID_PATTERN = re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')

    @classmethod
    def validate(cls, name: str, context: str = 'command') -> None:
        """
        Validate command name.

        Args:
            name: Command name to validate
            context: Context for error messages ('command', 'alias', etc.)

        Raises:
            ValueError: If name is invalid

        Example:
            CommandNameValidator.validate('delete')  # OK
            CommandNameValidator.validate('Delete')  # Raises ValueError
        """
        if not name:
            raise ValueError(f"Empty {context} name")

        if not cls.VALID_PATTERN.match(name):
            raise ValueError(
                f"Invalid {context} name: '{name}'\n"
                f"Must be lowercase, numbers, and hyphens only (kebab-case).\n"
                f"Examples: 'delete', 'set-password', 'list-v2'"
            )

    @classmethod
    def normalize(cls, method_name: str) -> str:
        """
        Normalize method name to command name.

        Rules:
        - Underscores → hyphens
        - Lowercase
        - Validate result

        Args:
            method_name: Python method name

        Returns:
            Normalized command name

        Raises:
            ValueError: If normalized name is invalid

        Examples:
            delete_user → delete-user
            show → show
            export_PDF → export-pdf
            list_v2 → list-v2
        """
        # Convert to lowercase
        normalized = method_name.lower()

        # Underscores → hyphens
        normalized = normalized.replace('_', '-')

        # Validate
        cls.validate(normalized, context='command')

        return normalized

    @classmethod
    def check_redundancy(
        cls,
        root_name: str,
        command_name: str
    ) -> Optional[str]:
        """
        Check for redundant identifiers.

        Args:
            root_name: Root namespace
            command_name: Command name

        Returns:
            Warning message if redundant, None otherwise

        Examples:
            root='user', command='delete-user' → "delete-user contains user"
            root='user', command='delete' → None
        """
        if root_name in command_name:
            # Suggest non-redundant version
            suggestion = (
                command_name
                .replace(f'-{root_name}', '')
                .replace(root_name, '')
                .strip('-')
            )

            # Don't warn if command IS just the root name
            if command_name == root_name:
                return None

            return (
                f"Command '{command_name}' contains root '{root_name}'.\n"
                f"Consider renaming to '{suggestion}' for clarity.\n"
                f"CLI will be: winterforge {root_name} {command_name}"
            )

        return None
