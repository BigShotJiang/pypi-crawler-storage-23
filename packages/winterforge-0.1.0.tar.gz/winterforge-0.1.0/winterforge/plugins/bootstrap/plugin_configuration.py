"""Plugin configuration bootstrapper."""

from __future__ import annotations

from pathlib import Path
from typing import Any
import yaml

from winterforge.plugins.decorators.bootstrapper import bootstrapper


@bootstrapper
class PluginConfiguration:
    """
    Import default plugin orderings from YAML.

    Loads plugins.yaml and creates config Frags for each
    manager's default ordering.
    """

    async def bootstrap(self) -> dict[str, Any]:
        """
        Import plugin configuration.

        Returns:
            Dict with status and count of configs created
        """
        from winterforge.frags.registries.config_registry import (
            ConfigRegistry
        )

        # Check if already imported (idempotent)
        config_registry = ConfigRegistry()
        existing = await config_registry.get('storage-backends-order')

        if existing:
            return {
                'status': 'skipped',
                'reason': 'already_imported'
            }

        # Load YAML
        defaults_dir = Path(__file__).parent.parent.parent / 'installer' / 'defaults'
        plugins_yaml = defaults_dir / 'plugins.yaml'

        with open(plugins_yaml) as f:
            plugin_config = yaml.safe_load(f)

        # Create config Frags for each manager's ordering
        count = 0
        for manager_type, settings in plugin_config.items():
            if 'order' in settings:
                # Store as comma-separated string
                slug = f'{manager_type.replace("_", "-")}-order'
                value = ','.join(settings['order'])

                await config_registry.set_value(slug, value)
                count += 1

        return {
            'status': 'created',
            'configs': count
        }


__all__ = ['PluginConfiguration']
