"""Framework configuration bootstrapper."""

from __future__ import annotations

from pathlib import Path
from typing import Any
import yaml
import secrets

from winterforge.plugins.decorators.bootstrapper import bootstrapper


@bootstrapper
class FrameworkConfiguration:
    """
    Import framework configuration from YAML.

    Loads config.yaml and creates config Frags for framework
    settings, generating secrets where needed.
    """

    async def bootstrap(self) -> dict[str, Any]:
        """
        Import framework configuration.

        Returns:
            Dict with status and count of configs created
        """
        from winterforge.frags.registries.config_registry import (
            ConfigRegistry
        )

        # Check if already imported (idempotent)
        config_registry = ConfigRegistry()
        existing = await config_registry.get('jwt-secret')

        if existing:
            return {
                'status': 'skipped',
                'reason': 'already_imported'
            }

        # Load YAML
        defaults_dir = (
            Path(__file__).parent.parent.parent
            / 'installer'
            / 'defaults'
        )
        config_yaml = defaults_dir / 'config.yaml'

        with open(config_yaml) as f:
            config_data = yaml.safe_load(f)

        # Generate JWT secret
        jwt_secret = secrets.token_hex(32)  # 64-character hex

        # Flatten nested config and create Frags
        count = 0
        for section, settings in config_data.items():
            for key, value in settings.items():
                slug = f"{section}-{key}".replace("_", "-")

                # Handle special values
                if value == '__GENERATED__':
                    if section == 'jwt' and key == 'secret':
                        value = jwt_secret
                    else:
                        value = secrets.token_hex(16)
                elif value == '__PROMPTED__':
                    # Skip prompted values (handled elsewhere)
                    continue

                await config_registry.set_value(slug, value)
                count += 1

        return {
            'status': 'created',
            'configs': count,
            'jwt_generated': True
        }


__all__ = ['FrameworkConfiguration']
