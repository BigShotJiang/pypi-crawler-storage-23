"""YAML bootstrap source provider - load config from .winterforge.yaml file."""

from pathlib import Path
from typing import Any, Dict
import yaml


class YamlBootstrapSourceProvider:
    """
    Load bootstrap configuration from YAML file.

    Checks for .winterforge.yaml and parses storage configuration.
    Useful for deployment scenarios where file-based config is preferred.
    """

    def __init__(self, config_path: str = '.winterforge.yaml'):
        """
        Initialize YAML bootstrap source.

        Args:
            config_path: Path to YAML config file (default: .winterforge.yaml)
        """
        self.config_path = config_path

    def applies_to(self) -> bool:
        """Check if YAML config file exists."""
        return Path(self.config_path).exists()

    async def load_config(self) -> Dict[str, Any]:
        """
        Load bootstrap config from YAML file.

        Expected YAML structure:
            storage:
              backend: sqlite
              db_path: ./winterforge.db

            # OR for PostgreSQL:
            storage:
              backend: postgresql
              host: localhost
              port: 5432
              database: winterforge
              username: winterforge
              password: secret

        Returns:
            Storage configuration dict
        """
        with open(self.config_path, 'r') as f:
            data = yaml.safe_load(f)

        if 'storage' not in data:
            raise RuntimeError(
                f"YAML config {self.config_path} missing 'storage' section"
            )

        config = data['storage']

        if 'backend' not in config:
            raise RuntimeError("YAML storage config missing 'backend' field")

        return config
