"""Manager for bootstrap plugins."""

from __future__ import annotations

from typing import Any

from winterforge.plugins._base import ReorderablePluginManagerBase


class BootstrapperManager(ReorderablePluginManagerBase):
    """
    Manages bootstrap plugins with ordered execution.

    Bootstrap plugins run once during initialization to set up
    system primitives, defaults, and configuration. They execute
    in repository order (registration order by default).

    Use repository().reorder() to control execution order.

    Example:
        # Register bootstrappers via decorator or entry point
        @bootstrapper
        class MaterializationBootstrapper:
            async def bootstrap(self):
                return {'status': 'created', 'traits': 15}

        # Run all bootstrappers in order
        results = await BootstrapperManager.run_all()

        # Reorder if needed
        repo = BootstrapperManager.repository()
        reordered = repo.reorder(['materialization', 'config', 'roles'])
        BootstrapperManager.reorder(reordered)
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return bootstrap plugin manager identifier."""
        return 'winterforge.bootstrappers'


__all__ = ['BootstrapperManager']
