"""Application Frag bootstrap."""

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class AppBootstrap:
    """
    Winterforge kernel bootstrap.

    Ensures Winterforge has an Application Frag (`app`) as its kernel.
    Lazy initialization - runs once per session.

    The moment AppBootstrap.ensure() completes, Winterforge has:
    - Application identity (UUID)
    - Kernel metadata (name, description)
    - Foundation for everything else

    This is Winterforge eating its own dog food - we follow the exact
    pattern documented for users in BUILDING_APPLICATIONS.md.

    Example:
        # CLI initialization
        await StorageBootstrap.ensure()  # First - need storage
        app = await AppBootstrap.ensure()  # Second - kernel identity
        # Winterforge now has its kernel

        # Query Winterforge's kernel
        from winterforge.frags.registries.application_registry import (
            ApplicationRegistry
        )
        apps = await ApplicationRegistry.all()
        app = apps.resolve(lambda f: True)
        print(f"Winterforge: {app.name} ({app.uuid})")
    """

    _initialized: bool = False
    _app: Optional['Frag'] = None

    @classmethod
    async def _get_first_app(cls) -> Optional['Frag']:
        """
        Get first application Frag from registry.

        Returns:
            First app Frag or None if no apps exist
        """
        from winterforge.frags.registries.application_registry import (
            ApplicationRegistry
        )
        from winterforge.frags.manifest import Manifest

        registry = ApplicationRegistry()
        apps_list = await registry.all()
        apps = Manifest(apps_list)
        return apps.resolve(lambda f: True)

    @classmethod
    async def ensure(cls) -> 'Frag':
        """
        Load or create Winterforge Application Frag (kernel).

        Idempotent - safe to call multiple times.
        Runs once per session.

        Returns:
            Winterforge's app kernel Frag

        Example:
            app = await AppBootstrap.ensure()
            print(f"Kernel: {app.name}")
            # Kernel: Winterforge
        """
        if cls._initialized:
            return cls._app

        # Try to load existing app
        cls._app = await cls._get_first_app()

        if not cls._app:
            # First boot - run initializers to create app
            await cls._initialize_application()

            # Reload after initialization
            cls._app = await cls._get_first_app()

        cls._initialized = True
        return cls._app

    @classmethod
    async def _initialize_application(cls) -> None:
        """
        Execute all initializers in dependency order.

        Creates Winterforge's app kernel via ApplicationInitializer
        plus any other registered initializers.
        """
        from winterforge.plugins.initializers.manager import (
            InitializerManager
        )
        import asyncio

        context = {
            'name': 'Winterforge',
            'description': 'Winterforge framework instance'
        }

        # Get ordered initializer stack
        repo = InitializerManager.repository()

        # Collect async tasks from all initializers
        tasks = [init_cls().execute(context) for init_cls in repo.values()]

        # Execute all initializers (ordered by dependencies)
        await asyncio.gather(*tasks)

    @classmethod
    def reset(cls) -> None:
        """
        Reset bootstrap state (for testing).

        Allows AppBootstrap.ensure() to run again.
        """
        cls._initialized = False
        cls._app = None
