"""Environment variable bootstrap source provider - load config from env vars."""

import os
from pathlib import Path
from typing import Any, Dict


class EnvVarBootstrapSourceProvider:
    """
    Load bootstrap configuration from environment variables.

    Checks for WINTERFORGE_DB or other env vars and constructs
    storage configuration. Useful for containerized deployments.
    """

    def applies_to(self) -> bool:
        """Check if WINTERFORGE_DB environment variable is set."""
        return 'WINTERFORGE_DB' in os.environ

    async def load_config(self) -> Dict[str, Any]:
        """
        Load bootstrap config from environment variables.

        Supported env vars:
            WINTERFORGE_DB: Path to SQLite database
            WINTERFORGE_STORAGE_BACKEND: Override backend type
            WINTERFORGE_PG_HOST: PostgreSQL host
            WINTERFORGE_PG_PORT: PostgreSQL port
            WINTERFORGE_PG_DATABASE: PostgreSQL database name
            WINTERFORGE_PG_USERNAME: PostgreSQL username
            WINTERFORGE_PG_PASSWORD: PostgreSQL password

        Returns:
            Storage configuration dict
        """
        # Check for explicit backend override
        backend = os.environ.get('WINTERFORGE_STORAGE_BACKEND', 'sqlite')

        if backend == 'sqlite':
            db_path = os.environ.get('WINTERFORGE_DB', './winterforge.db')

            # If database exists at that location, try to load bootstrap from it
            if Path(db_path).exists():
                # Try to load actual bootstrap config from database
                storage = None
                try:
                    from winterforge.plugins.storage.sqlite import (
                        SQLiteStorageBackend,
                    )

                    storage = SQLiteStorageBackend(db_path=db_path)
                    bootstrap_frags = await storage.query()\
                        .affinity('bootstrap')\
                        .affinity('config')\
                        .execute()

                    if bootstrap_frags:
                        # Found bootstrap config in database
                        config = {}
                        for frag in bootstrap_frags:
                            if (
                                hasattr(frag, 'slug')
                                and frag.slug.startswith('bootstrap.')
                            ):
                                key = frag.slug.replace('bootstrap.', '')
                                config[key] = frag.value('value')
                        # Only return if we found actual config (has backend key)
                        if config and 'backend' in config:
                            return config
                except Exception:
                    pass  # Fall through to env var config
                finally:
                    # Always close temporary storage connection
                    if storage and hasattr(storage, 'close'):
                        await storage.close()

            # No database or no bootstrap in it - use env var as config
            return {'backend': 'sqlite', 'db_path': db_path}

        elif backend == 'postgresql':
            return {
                'backend': 'postgresql',
                'host': os.environ.get('WINTERFORGE_PG_HOST', 'localhost'),
                'port': int(os.environ.get('WINTERFORGE_PG_PORT', '5432')),
                'database': os.environ.get(
                    'WINTERFORGE_PG_DATABASE', 'winterforge'
                ),
                'username': os.environ.get(
                    'WINTERFORGE_PG_USERNAME', 'winterforge'
                ),
                'password': os.environ.get('WINTERFORGE_PG_PASSWORD', ''),
            }

        else:
            raise RuntimeError(
                f"Unsupported storage backend from env var: {backend}"
            )
