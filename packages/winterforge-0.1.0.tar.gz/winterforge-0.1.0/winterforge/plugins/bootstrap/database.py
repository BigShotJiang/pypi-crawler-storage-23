"""Database bootstrap source provider - load config from database bootstrap Frags."""

from pathlib import Path
from typing import Any, Dict
from winterforge.plugins.slug_convertors import SlugConvertorManager


class DatabaseBootstrapSourceProvider:
    """
    Load bootstrap configuration from database.

    Checks for ./winterforge.db and looks for bootstrap config Frags inside.
    This is the primary bootstrap method after installation.
    """

    def __init__(self, db_path: str = './winterforge.db'):
        """
        Initialize database bootstrap source.

        Args:
            db_path: Path to SQLite database (default: ./winterforge.db)
        """
        self.db_path = db_path

    def applies_to(self) -> bool:
        """Check if database file exists."""
        return Path(self.db_path).exists()

    async def load_config(self) -> Dict[str, Any]:
        """
        Load bootstrap config from database.

        Queries for Frags with affinities=['bootstrap', 'config']
        and extracts storage configuration.

        Returns:
            Storage configuration dict
        """
        # Import here to avoid circular dependencies
        from winterforge.plugins.storage.sqlite import SQLiteStorageBackend

        # Create temporary storage to read bootstrap config
        storage = SQLiteStorageBackend(db_path=self.db_path)

        try:
            # Query for bootstrap config Frag (single Frag with multiple fields)
            bootstrap_frags = await storage.query()\
                .affinity('bootstrap')\
                .affinity('config')\
                .condition('slug', 'bootstrap')\
                .execute()

            if not bootstrap_frags:
                raise RuntimeError(
                    f"Database exists at {self.db_path} but no bootstrap config found"
                )

            # Get the bootstrap Frag (should be only one)
            bootstrap = bootstrap_frags[0]

            # Extract configuration from Frag fields
            config = {}

            # Get all field values from the bootstrap Frag
            # Fields are stored as slugs (kebab-case), convert to Python naming
            if hasattr(bootstrap, 'value'):
                # Try common field names (convert slug → python)
                slug_names = [
                    'backend',
                    'db-path',
                    'host',
                    'port',
                    'database',
                    'username',
                    'password',
                ]
                for slug in slug_names:
                    try:
                        value = bootstrap.value(slug)
                        if value is not None:
                            # Convert slug format to Python naming
                            python_key = (
                                SlugConvertorManager.convert(slug, 'slug', 'python')
                                or slug
                            )
                            config[python_key] = value
                    except (KeyError, AttributeError):
                        pass  # Field doesn't exist, that's ok

            # Validate required fields
            if 'backend' not in config:
                raise RuntimeError("Bootstrap config missing 'backend' field")

            return config
        finally:
            # Always close temporary storage connection
            await storage.close()
