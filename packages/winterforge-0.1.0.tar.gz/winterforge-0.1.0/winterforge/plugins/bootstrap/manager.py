"""
Bootstrap Source Provider Manager.

Manages discovery of WinterForge installation configuration.
Uses standard "first match wins" reconciliation pattern.

Like BIOS boot order - try providers in order until one succeeds.
"""

from typing import Any, Dict, Optional, Protocol
from winterforge.plugins.repository import PluginRepository


class BootstrapSourceProvider(Protocol):
    """
    Protocol for bootstrap source provider plugins.

    Defines the plugin-specific API for discovering WinterForge
    installation configuration from various sources (database, YAML, env vars, etc.).

    Plugin-Specific API:
        - applies_to() -> bool: Check if this source has config available
        - load_config() -> Dict[str, Any]: Load the configuration
    """

    def applies_to(self) -> bool:
        """
        Check if this source has bootstrap config available.

        Returns:
            True if bootstrap configuration can be loaded from this source

        Example:
            def applies_to(self) -> bool:
                return Path('./winterforge.db').exists()
        """
        ...

    async def load_config(self) -> Dict[str, Any]:
        """
        Load bootstrap configuration from this source.

        Returns:
            Dict with storage configuration:
                {
                    'backend': 'sqlite',
                    'db_path': './winterforge.db',
                    # OR for PostgreSQL:
                    'host': 'localhost',
                    'port': 5432,
                    'database': 'winterforge',
                    'username': 'winterforge',
                    'password': 'secret'
                }

        Raises:
            RuntimeError: If bootstrap cannot be loaded despite applies_to() returning True
        """
        ...


class BootstrapSourceManager:
    """
    Manager for bootstrap source provider plugins.

    Uses standard reconciliation pattern: query all providers in order,
    first one that applies_to() wins.

    Like BIOS boot order - try each provider until one succeeds.
    No match = no compatible installation found.
    """

    _providers: Dict[str, BootstrapSourceProvider] = {}
    _order: list[str] = []

    @classmethod
    def register(cls, provider_id: str, provider: BootstrapSourceProvider) -> None:
        """
        Register a bootstrap source provider plugin.

        Args:
            provider_id: Unique provider identifier
            provider: BootstrapSourceProvider plugin instance
        """
        cls._providers[provider_id] = provider
        if provider_id not in cls._order:
            cls._order.append(provider_id)

    @classmethod
    def get(cls, provider_id: str) -> Optional[BootstrapSourceProvider]:
        """Get bootstrap source provider by ID."""
        return cls._providers.get(provider_id)

    @classmethod
    def has(cls, provider_id: str) -> bool:
        """Check if bootstrap source provider is registered."""
        return provider_id in cls._providers

    @classmethod
    def repository(cls) -> PluginRepository:
        """Get bootstrap source provider repository for ordering control."""
        return PluginRepository(cls._providers.copy(), cls._order.copy())

    @classmethod
    async def discover(cls) -> Optional[Dict[str, Any]]:
        """
        Discover bootstrap configuration.

        Queries all providers in order (BIOS boot order pattern),
        uses first match.

        Returns:
            Storage configuration dict if found, None otherwise

        Example:
            config = await BootstrapSourceManager.discover()
            if config:
                # Found installation
                storage = create_storage(config)
            else:
                # No installation found
                print("Run 'winterforge init' first")
        """
        for provider_id in cls._order:
            provider = cls._providers.get(provider_id)
            if provider and provider.applies_to():
                try:
                    return await provider.load_config()
                except Exception:
                    # This provider failed, try next one
                    continue

        return None  # No compatible installation

    @classmethod
    def reset(cls) -> None:
        """Reset all providers (for testing)."""
        cls._providers = {}
        cls._order = []
