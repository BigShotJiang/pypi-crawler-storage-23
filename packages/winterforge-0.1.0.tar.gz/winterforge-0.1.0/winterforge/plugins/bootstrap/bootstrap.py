"""Bootstrap source provider registration."""

from winterforge.plugins.bootstrap.manager import BootstrapSourceManager
from winterforge.plugins.bootstrap.database import DatabaseBootstrapSourceProvider
from winterforge.plugins.bootstrap.yaml import YamlBootstrapSourceProvider
from winterforge.plugins.bootstrap.env_var import EnvVarBootstrapSourceProvider


def register_builtin_providers() -> None:
    """
    Register built-in bootstrap source providers.

    Order matters - BIOS boot order pattern.
    First provider that applies_to() wins.

    Default order:
    1. Environment variables - Explicit override (containers, CI/CD, testing)
    2. Database (./winterforge.db) - Primary after installation
    3. YAML file (.winterforge.yaml) - File-based deployments
    """
    # Primary: Environment variables (explicit override)
    BootstrapSourceManager.register('env_var', EnvVarBootstrapSourceProvider())

    # Secondary: Database bootstrap (post-installation default)
    BootstrapSourceManager.register('database', DatabaseBootstrapSourceProvider())

    # Tertiary: YAML file (traditional config file)
    BootstrapSourceManager.register('yaml', YamlBootstrapSourceProvider())
