"""Materialization bootstrapper for creating primitive Frags."""

from __future__ import annotations

from typing import Any

from winterforge.plugins.decorators.bootstrapper import bootstrapper


@bootstrapper
class Materialization:
    """
    Create Affinity/Trait primitive Frags.

    Runs early in bootstrap sequence. Idempotent - checks if primitives
    already exist before creating.

    Materializes traits and affinities as first-class Frag objects,
    enabling them to be queried like any other Frag.
    """

    async def bootstrap(self) -> dict[str, Any]:
        """
        Materialize traits and affinities as Frags.

        Returns:
            Dict with status and counts:
                - status: 'created' or 'skipped'
                - traits: Number of trait Frags
                - affinities: Number of affinity Frags (if created)
                - reason: Skip reason (if skipped)
        """
        from winterforge.frags.registries.trait_registry import TraitRegistry

        # Check if already materialized (idempotent)
        trait_reg = TraitRegistry()
        existing_traits = await trait_reg.all()

        if len(existing_traits) > 0:
            # Already materialized, skip
            return {
                'status': 'skipped',
                'reason': 'already_materialized',
                'traits': len(existing_traits)
            }

        # Materialize primitives
        from winterforge.frags.materialization import materialize_primitives

        primitives = await materialize_primitives()

        # Build result with counts for each primitive type
        result = {'status': 'created'}
        for type_id, manifest in primitives.items():
            result[type_id] = len(manifest)

        return result


__all__ = ['Materialization']
