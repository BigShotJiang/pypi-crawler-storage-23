"""CliOutputRedirect - standard CLI output via click.echo()."""

import click

from winterforge.plugins.decorators import output_redirect, root


@output_redirect()
@root('cli')
class CliOutputRedirect:
    """
    Standard CLI output redirect using click.echo().

    Writes messages to stdout using Click's echo function,
    which handles ANSI colors and Unicode properly.

    Registered as: 'cli' (default)
    """

    def write(self, message: str) -> None:
        """
        Write message to stdout via click.echo().

        Args:
            message: The message to output
        """
        click.echo(message)
