"""Built-in OutputRedirect plugins for CLI output destinations."""

# Import redirects to trigger registration
import winterforge.plugins.output_redirects.cli_output_redirect   # Default
import winterforge.plugins.output_redirects.null_output_redirect  # For testing
