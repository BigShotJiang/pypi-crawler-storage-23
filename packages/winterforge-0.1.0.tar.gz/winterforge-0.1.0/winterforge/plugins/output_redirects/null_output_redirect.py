"""NullOutputRedirect - silent output for testing."""

from winterforge.plugins.decorators import output_redirect, root


@output_redirect()
@root('null')
class NullOutputRedirect:
    """
    Silent output redirect that discards all messages.

    Useful for testing CLI commands without producing output.

    Registered as: 'null'

    Example:
        # In test setup
        OutputRedirectManager.set_default_redirect('null')

        # Run CLI commands silently
        result = runner.invoke(cli, ['user', 'create', 'test'])

        # Restore CLI output
        OutputRedirectManager.set_default_redirect('cli')
    """

    def write(self, message: str) -> None:
        """
        Discard message silently.

        Args:
            message: The message to discard
        """
        pass  # Intentionally do nothing
