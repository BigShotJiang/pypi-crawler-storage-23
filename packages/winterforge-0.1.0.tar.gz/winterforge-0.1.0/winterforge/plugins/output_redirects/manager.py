"""OutputRedirectManager - manages CLI output destination plugins."""

from typing import Optional

from winterforge.plugins._base import ReorderablePluginManagerBase


class OutputRedirectManager(ReorderablePluginManagerBase):
    """
    Manages OutputRedirect plugins for CLI output destinations.

    OutputRedirects determine where CLI output is sent (stdout, file, log, etc.).
    Default redirect is 'cli' (click.echo to stdout).

    Built-in redirects:
    - cli: Standard CLI output via click.echo() (default)
    - null: Silent output (for testing)

    Example:
        # Register custom redirect
        @output_redirect('file')
        class FileOutputRedirect:
            def write(self, message):
                with open('/tmp/cli.log', 'a') as f:
                    f.write(message + '\\n')

        # Use in command
        @cli_command('export', output='file')
        async def export_data(self):
            return data  # Output goes to file instead of stdout
    """

    _default_redirect_id: str = 'cli'

    @classmethod
    def set_default_redirect(cls, redirect_id: str) -> None:
        """
        Set the default output redirect.

        Args:
            redirect_id: ID of the redirect to use as default

        Example:
            # Use null output by default (testing)
            OutputRedirectManager.set_default_redirect('null')

            # Restore CLI output
            OutputRedirectManager.set_default_redirect('cli')
        """
        cls._default_redirect_id = redirect_id

    @classmethod
    def get_default_redirect(cls) -> Optional[any]:
        """
        Get the default output redirect.

        Returns:
            Default redirect plugin

        Example:
            redirect = OutputRedirectManager.get_default_redirect()
            redirect.write("Hello, World!")
        """
        return cls.get(cls._default_redirect_id)

    @classmethod
    def write(cls, message: str, redirect_id: Optional[str] = None) -> None:
        """
        Write a message using the specified or default redirect.

        Args:
            message: The message to output
            redirect_id: Optional specific redirect to use

        Example:
            # Use default redirect
            OutputRedirectManager.write("✓ Operation complete")

            # Use specific redirect
            OutputRedirectManager.write("Log entry", redirect_id='file')
        """
        if redirect_id:
            redirect = cls.get(redirect_id)
        else:
            redirect = cls.get_default_redirect()

        if redirect:
            redirect.write(message)
