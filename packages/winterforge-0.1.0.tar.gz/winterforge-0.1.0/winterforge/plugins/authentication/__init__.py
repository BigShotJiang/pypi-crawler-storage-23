"""Authentication provider plugins."""

from winterforge.plugins.authentication.manager import AuthenticationProviderManager
from winterforge.plugins.authentication.password_provider import PasswordAuthProvider

__all__ = [
    'AuthenticationProviderManager',
    'PasswordAuthProvider',
]
