"""Password authentication provider.

Username/password authentication with lockout protection.
"""

from __future__ import annotations

from typing import Optional

from winterforge.plugins.decorators import authentication_provider, root


@authentication_provider()
@root('password')
class PasswordAuthProvider:
    """
    Username/password authentication.

    Authenticates users by username/email and password, with automatic
    account lockout after failed attempts.

    Example:
        provider = AuthenticationProviderManager.get('password')
        user = await provider.authenticate({
            'username': 'beau',  # or 'beau@example.com'
            'password': 'secure_password'
        })

        if user:
            print(f"Authenticated: {user.username}")
    """

    async def authenticate(self, credentials: dict):
        """
        Authenticate with username/email and password.

        Expected credentials:
        {
            'username': 'beau' or 'beau@example.com',
            'password': 'plain_password'
        }

        Args:
            credentials: Dict with username and password

        Returns:
            User Frag on success, None on failure
        """
        from winterforge.frags.registries.frag_registry import FragRegistry

        username = credentials.get('username')
        password = credentials.get('password')

        if not username or not password:
            return None

        # Resolve user by username or email
        # Prioritize username/email for authentication context
        from winterforge.plugins.identity.manager import (
            IdentityResolverManager
        )

        users = FragRegistry({
            'affinities': ['user'],
            'traits': ['userable', 'authenticatable']
        }).with_resolvers(
            IdentityResolverManager.repository()
                .with_front('email')
                .with_front('username')
        )

        try:
            user = await users.get(username)
        except Exception:
            return None

        if not user:
            return None

        # Check if account is locked
        if user.is_locked():
            return None

        # Verify password
        if not user.verify_password(password):
            # Record failed login
            user.record_failed_login()
            await user.save()
            return None

        # Success - reset failed login counter
        user.clear_failed_logins()
        await user.save()

        return user

    def get_credential_schema(self) -> dict:
        """
        Return expected credential structure.

        Returns:
            Dict describing credential schema
        """
        return {
            'username': 'string (username or email)',
            'password': 'string (plain text)'
        }
