"""Authentication provider manager.

Manages authentication implementations (password, token, OAuth, etc.).
"""

from __future__ import annotations

from typing import Optional

from winterforge.plugins._base import ReorderablePluginManagerBase


class AuthenticationProviderManager(ReorderablePluginManagerBase):
    """
    Manages authentication provider implementations.

    Provides centralized access to authentication providers with
    fallback behavior (tries all providers in order).

    Example:
        # Authenticate using default provider
        user = await AuthenticationProviderManager.authenticate({
            'username': 'beau',
            'password': 'secure_password'
        })

        # Use specific provider
        user = await AuthenticationProviderManager.authenticate(
            credentials={'username': 'beau', 'password': 'secure'},
            provider_id='password'
        )
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.authentication_providers'

    @classmethod
    async def authenticate(cls, credentials: dict, provider_id: str = None):
        """
        Authenticate using specified or all providers.

        Args:
            credentials: Credential dict (structure varies by provider)
            provider_id: Optional specific provider to use

        Returns:
            User Frag on success, None on failure
        """
        from winterforge.frags.base import Frag

        if provider_id:
            provider = cls.get(provider_id)
            return await provider.authenticate(credentials)

        # Try all providers in order until one succeeds
        for provider_id in cls.repository().order():
            provider = cls.get(provider_id)
            user = await provider.authenticate(credentials)
            if user:
                return user

        return None
