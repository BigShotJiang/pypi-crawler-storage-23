"""Email provider plugins for email delivery."""

from winterforge.plugins.email.manager import EmailProviderManager
from winterforge.plugins.email.smtp_provider import SMTPEmailProvider
from winterforge.plugins.email.console_provider import ConsoleEmailProvider

__all__ = [
    'EmailProviderManager',
    'SMTPEmailProvider',
    'ConsoleEmailProvider',
]
