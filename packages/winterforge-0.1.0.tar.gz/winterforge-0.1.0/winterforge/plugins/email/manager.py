"""Email provider manager.

Manages email delivery implementations (SMTP, Console, SendGrid, etc.).
"""

from __future__ import annotations

from winterforge.plugins._base import ReorderablePluginManagerBase


class EmailProviderManager(ReorderablePluginManagerBase):
    """
    Manages email delivery provider implementations.

    Provides centralized access to email providers with fallback
    to the first registered provider.

    Example:
        # Send email using default provider
        success = await EmailProviderManager.send_email(
            to='user@example.com',
            subject='Password Reset',
            body='Click here to reset...'
        )

        # Use specific provider
        smtp = EmailProviderManager.get('smtp')
        await smtp.send(
            to='user@example.com',
            subject='Welcome!',
            body='Welcome to Winterforge'
        )
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.email_providers'

    @classmethod
    async def send_email(
        cls,
        to: str,
        subject: str,
        body: str,
        html: str = None,
        provider_id: str = None,
        **options
    ) -> bool:
        """
        Send email using specified or default provider.

        Args:
            to: Recipient email address
            subject: Email subject
            body: Plain text body
            html: Optional HTML body
            provider_id: Optional specific provider to use
            **options: Provider-specific options (from, cc, bcc, etc.)

        Returns:
            True if sent successfully, False otherwise
        """
        if not provider_id:
            provider_id = cls.repository().order()[0]
        provider = cls.get(provider_id)
        return await provider.send(to, subject, body, html, **options)
