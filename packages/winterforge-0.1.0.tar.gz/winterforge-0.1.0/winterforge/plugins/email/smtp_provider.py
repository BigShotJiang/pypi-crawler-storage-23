"""SMTP email provider.

Standard SMTP email delivery.
"""

from __future__ import annotations

from winterforge.plugins.decorators import email_provider, root


@email_provider()
@root('smtp')
class SMTPEmailProvider:
    """
    SMTP email delivery.

    Sends emails via SMTP server with optional TLS encryption.

    Example:
        provider = EmailProviderManager.get('smtp')
        await provider.send(
            to='user@example.com',
            subject='Welcome',
            body='Welcome to Winterforge!'
        )
    """

    def __init__(
        self,
        host: str = None,
        port: int = None,
        username: str = None,
        password: str = None,
        use_tls: bool = True
    ):
        """
        Initialize SMTP settings from config or params.

        Args:
            host: SMTP server host
            port: SMTP server port
            username: SMTP username
            password: SMTP password
            use_tls: Use TLS encryption (default: True)
        """
        if not all([host, port, username, password]):
            # Load from environment or config Frags
            import os
            host = host or os.environ.get('SMTP_HOST')
            port = port or int(os.environ.get('SMTP_PORT', '587'))
            username = username or os.environ.get('SMTP_USERNAME')
            password = password or os.environ.get('SMTP_PASSWORD')

            # Config Frag loading removed - use env vars or pass params directly
            # (config.get() is async and can't be called from __init__)

        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.use_tls = use_tls

    async def send(self, to: str, subject: str, body: str, html: str = None, **options) -> bool:
        """
        Send email via SMTP.

        Args:
            to: Recipient email address
            subject: Email subject
            body: Plain text body
            html: Optional HTML body
            **options: Additional options (from, cc, bcc, etc.)

        Returns:
            True if sent successfully, False otherwise
        """
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart

        try:
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = options.get('from', self.username)
            msg['To'] = to

            if options.get('cc'):
                msg['Cc'] = options['cc']
            if options.get('bcc'):
                msg['Bcc'] = options['bcc']

            msg.attach(MIMEText(body, 'plain'))
            if html:
                msg.attach(MIMEText(html, 'html'))

            with smtplib.SMTP(self.host, self.port) as server:
                if self.use_tls:
                    server.starttls()
                if self.username and self.password:
                    server.login(self.username, self.password)
                server.send_message(msg)

            return True
        except Exception as e:
            # Log error (future: use logging system)
            print(f"Email send failed: {e}")
            return False
