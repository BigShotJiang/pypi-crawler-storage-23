"""Console email provider.

Prints emails to console (development/testing).
"""

from __future__ import annotations

from winterforge.plugins.decorators import email_provider, root


@email_provider()
@root('console')
class ConsoleEmailProvider:
    """
    Print emails to console (development/testing).

    Instead of actually sending emails, this provider prints them
    to stdout. Useful for development and testing.

    Example:
        provider = EmailProviderManager.get('console')
        await provider.send(
            to='user@example.com',
            subject='Test',
            body='Test email'
        )
        # Prints to console instead of sending
    """

    async def send(self, to: str, subject: str, body: str, html: str = None, **options) -> bool:
        """
        Print email to stdout.

        Args:
            to: Recipient email address
            subject: Email subject
            body: Plain text body
            html: Optional HTML body
            **options: Additional options (from, cc, bcc, etc.)

        Returns:
            True (always succeeds)
        """
        print("=" * 80)
        print(f"EMAIL: {subject}")
        print(f"TO: {to}")
        print(f"FROM: {options.get('from', 'noreply@winterforge.local')}")

        if options.get('cc'):
            print(f"CC: {options['cc']}")
        if options.get('bcc'):
            print(f"BCC: {options['bcc']}")

        print("-" * 80)
        print(body)

        if html:
            print("-" * 80)
            print("HTML VERSION:")
            print(html)

        print("=" * 80)
        return True
