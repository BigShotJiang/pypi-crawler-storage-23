"""Import plugin manager."""

from winterforge.plugins._base import PluginManagerBase


class ImportManager(PluginManagerBase):
    """
    Manager for data import plugins.

    Import plugins read Frag data from various sources:
    - File systems (YAML, JSON, CSV)
    - Cloud storage (S3, Azure, GCS)
    - APIs (HTTP, GraphQL)
    - Databases (direct import)

    Plugins are configured and added to data_source Frags,
    which can contain multiple importers for fallback/redundancy.

    Example:
        # YAML file importer
        yaml_imp = YamlFileImporter(path='/backup/export.yaml')

        # S3 importer (fallback)
        s3_imp = S3Importer(bucket='backups', key='export.yaml')

        # Compose into Frag
        input = Frag(affinities=['data_source'], traits=['has_data_source'])
        input.importers = [yaml_imp, s3_imp]

        # Import from first available source
        await transport.load_raw(input=input)
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Plugin manager identifier."""
        return 'winterforge.importers'
