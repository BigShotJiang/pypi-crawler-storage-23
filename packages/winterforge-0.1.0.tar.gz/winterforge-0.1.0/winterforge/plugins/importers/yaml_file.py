"""YAML file import plugin."""

from pathlib import Path
from typing import Any, Dict, List
import yaml

from winterforge.plugins.decorators import plugin


@plugin('winterforge.importers', 'yaml_file')
class YamlFileImporter:
    """
    Import data from YAML file.

    Pre-configured instance specifies input path.
    Reads Frag data from YAML file for import processing.

    Example:
        importer = YamlFileImporter(path='/backup/export.yaml')
        input = Frag(affinities=['data_source'], traits=['has_data_source'])
        input.add_importer(importer)
    """

    def __init__(self, path: str = None):
        """
        Initialize YAML file importer.

        Args:
            path: Input file path (optional, can be set later)
        """
        self.path = path

    async def read(self, source_frag: 'Frag') -> Dict[str, Any]:
        """
        Read Frag data from YAML file.

        Args:
            source_frag: Data source Frag (provides path, etc.)

        Returns:
            Import data structure with metadata and Frags

        Example:
            importer = YamlFileImporter(path='/backup.yaml')
            data = await importer.read(source_frag)
            # → {'version': '1.0', 'frags': {...}, ...}
        """
        # Use path from instance or source_frag
        file_path = self.path or getattr(source_frag, 'path', None)

        if not file_path:
            raise ValueError("No path specified for YAML import")

        # Read YAML file
        with open(file_path, 'r') as f:
            export_data = yaml.safe_load(f)

        if not export_data or 'frags' not in export_data:
            raise ValueError(f"Invalid export format in {file_path}")

        return export_data

    async def can_read(self, source_frag: 'Frag') -> bool:
        """
        Check if source is readable.

        Useful for fallback chains - try first importer,
        if it can't read, try next in stack.

        Args:
            source_frag: Data source Frag

        Returns:
            True if file exists and is readable
        """
        file_path = self.path or getattr(source_frag, 'path', None)

        if not file_path:
            return False

        path = Path(file_path)
        return path.exists() and path.is_file()
