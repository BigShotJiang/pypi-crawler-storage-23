"""Protocol for input prompt plugins."""

from __future__ import annotations

from typing import Protocol, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags import Frag


class InputPromptProtocol(Protocol):
    """
    Protocol for input prompt strategies.

    Input prompt plugins handle prompting users for field values
    based on field metadata (prompt text, validators, help text).
    """

    async def prompt_for_field(
        self,
        field: 'Frag',
        interactive: bool = True,
        default_value: Any = None
    ) -> Any:
        """
        Prompt for single field value.

        Args:
            field: Field Frag with metadata (prompt, validators, etc.)
            interactive: Whether to prompt interactively
            default_value: Default value if not interactive

        Returns:
            Validated field value

        Examples:
            email = await prompter.prompt_for_field(email_field)
            password = await prompter.prompt_for_field(
                password_field,
                interactive=True
            )
        """
        ...

    async def prompt_for_fields(
        self,
        frag: 'Frag',
        field_names: list[str] | None = None,
        interactive: bool = True,
        defaults: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """
        Prompt for multiple field values.

        Args:
            frag: Frag containing field references
            field_names: List of field names to prompt (None = all)
            interactive: Whether to prompt interactively
            defaults: Default values by field name

        Returns:
            Dict of {field_name: value}

        Examples:
            values = await prompter.prompt_for_fields(
                user_frag,
                ['username', 'email'],
                interactive=True
            )
        """
        ...

    def get_field_metadata(self, field: 'Frag') -> dict[str, Any]:
        """
        Extract metadata from field Frag.

        Args:
            field: Field Frag

        Returns:
            Dict with metadata keys: prompt, validators, help_text,
            required, default

        Example:
            metadata = prompter.get_field_metadata(email_field)
            print(metadata['prompt'])  # "Email address"
        """
        ...
