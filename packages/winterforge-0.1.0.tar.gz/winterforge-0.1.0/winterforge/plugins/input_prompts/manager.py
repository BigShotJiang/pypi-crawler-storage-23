"""Input Prompt Plugin Manager."""

from __future__ import annotations

from typing import TYPE_CHECKING

from winterforge.plugins import PluginManagerBase

if TYPE_CHECKING:
    from winterforge.plugins.input_prompts.protocols import (
        InputPromptProtocol,
    )


class InputPromptManager(PluginManagerBase):
    """
    Manager for input prompt plugins.

    Provides pluggable strategies for prompting users for field values.

    Examples:
        # Get interactive CLI prompter
        prompter = InputPromptManager.get('interactive_cli')

        # Prompt for field
        email = await prompter.prompt_for_field(email_field)

        # Prompt for multiple fields
        values = await prompter.prompt_for_fields(
            user_frag,
            ['username', 'email', 'password']
        )

        # Silent mode (use defaults)
        silent = InputPromptManager.get('silent')
        values = await silent.prompt_for_fields(
            user_frag,
            defaults={'username': 'admin', 'email': 'admin@example.com'}
        )
    """

    _entry_point = 'winterforge.input_prompts'

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.input_prompts'

    @classmethod
    def get(cls, plugin_id: str) -> 'InputPromptProtocol':
        """
        Get input prompt plugin by ID.

        Args:
            plugin_id: Plugin identifier (e.g., 'interactive_cli')

        Returns:
            InputPromptProtocol instance

        Raises:
            ValueError: If plugin not found

        Examples:
            prompter = InputPromptManager.get('interactive_cli')
        """
        return super().get(plugin_id)
