"""
Silent input prompt plugin.

Returns default values without prompting - for automated/scripted use.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from winterforge.plugins.decorators import plugin

if TYPE_CHECKING:
    from winterforge.frags import Frag


@plugin('winterforge.input_prompts', 'silent')
class SilentPrompt:
    """
    Silent (non-interactive) prompter.

    Returns default values without user interaction.
    Useful for:
    - Automated scripts
    - Testing
    - API/programmatic field population
    - Batch operations

    Examples:
        prompter = InputPromptManager.get('silent')

        # Returns defaults
        values = await prompter.prompt_for_fields(
            user_frag,
            defaults={
                'username': 'admin',
                'email': 'admin@example.com',
                'password': 'changeme'
            }
        )
    """

    async def prompt_for_field(
        self,
        field: 'Frag',
        interactive: bool = True,
        default_value: Any = None
    ) -> Any:
        """
        Return default value without prompting.

        Args:
            field: Field definition Frag
            interactive: Ignored (always non-interactive)
            default_value: Default value to return

        Returns:
            Default value or field's default

        Example:
            email = await prompter.prompt_for_field(
                email_field,
                default_value='user@example.com'
            )
        """
        # Return provided default
        if default_value is not None:
            return default_value

        # Return field's default
        metadata = self.get_field_metadata(field)
        return metadata['default']

    async def prompt_for_fields(
        self,
        frag: 'Frag',
        field_names: list[str] | None = None,
        interactive: bool = True,
        defaults: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """
        Return default values without prompting.

        Args:
            frag: Frag containing field references
            field_names: List of field names (None = all)
            interactive: Ignored (always non-interactive)
            defaults: Default values by field name

        Returns:
            Dict of {field_name: default_value}

        Example:
            values = await prompter.prompt_for_fields(
                user_frag,
                defaults={
                    'username': 'testuser',
                    'email': 'test@example.com'
                }
            )
        """
        from winterforge.frags.registries.field_registry import (
            FieldRegistry,
        )
        from winterforge.frags.traits.persistable import get_storage

        defaults = defaults or {}
        values = {}

        # Get field references from Frag
        if not hasattr(frag, 'get_field_references'):
            return values

        field_ref_ids = frag.get_field_references()

        # Load Field Frags from storage
        storage = get_storage()
        if not storage:
            return values

        for field_id in field_ref_ids:
            # Load field Frag
            field_frag = await storage.load(field_id)
            if not field_frag:
                continue

            field_slug = field_frag.slug

            # Skip if not in requested field_names
            if field_names and field_slug not in field_names:
                continue

            # Get default value
            value = (
                defaults.get(field_slug)
                if field_slug in defaults
                else (
                    field_frag.get_default()
                    if hasattr(field_frag, 'get_default')
                    else None
                )
            )

            values[field_slug] = value

        return values

    def get_field_metadata(self, field: 'Frag') -> dict[str, Any]:
        """
        Extract metadata from field Frag.

        Args:
            field: Field definition Frag

        Returns:
            Dict with metadata (same as InteractiveCLIPrompt)
        """
        validators_str = field.get_alias('validators') or ''
        validators = [
            v.strip() for v in validators_str.split(',') if v.strip()
        ]

        return {
            'prompt': field.get_alias('prompt') or field.slug,
            'validators': validators,
            'help_text': field.get_alias('help-text'),
            'required': field.get_alias('required') == 'true',
            'default': (
                field.get_default()
                if hasattr(field, 'get_default')
                else None
            ),
        }
