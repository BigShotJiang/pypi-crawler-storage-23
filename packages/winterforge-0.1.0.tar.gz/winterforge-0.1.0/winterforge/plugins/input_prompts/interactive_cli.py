"""
Interactive CLI input prompt plugin.

Prompts users interactively on the command line with validation,
help text, and default values.
"""

from __future__ import annotations

import getpass
from typing import Any, TYPE_CHECKING

from winterforge.plugins.decorators import plugin

if TYPE_CHECKING:
    from winterforge.frags import Frag


@plugin('winterforge.input_prompts', 'interactive_cli')
class InteractiveCLIPrompt:
    """
    Interactive command-line input prompter.

    Prompts users for field values using:
    - Field metadata (prompt, help text, validators)
    - Password masking for password fields
    - Validation loops until valid input
    - Default values

    Examples:
        prompter = InputPromptManager.get('interactive_cli')

        # Single field
        email = await prompter.prompt_for_field(email_field)

        # Multiple fields
        values = await prompter.prompt_for_fields(
            user_frag,
            ['username', 'email', 'password']
        )
    """

    async def prompt_for_field(
        self,
        field: 'Frag',
        interactive: bool = True,
        default_value: Any = None
    ) -> Any:
        """
        Prompt user for field value using field's metadata.

        Reads metadata from field Frag:
        - prompt: Prompt text to display
        - validators: Comma-separated validator IDs
        - help-text: Help text
        - required: Whether field is required

        Args:
            field: Field definition Frag with metadata
            interactive: Whether to prompt interactively
            default_value: Default value if not interactive

        Returns:
            User input value (validated)

        Example:
            email_field = await fields.ensure_field(
                'email',
                str,
                prompt='Email',
                validators=['required', 'email']
            )
            email = await prompter.prompt_for_field(email_field)
        """
        # Extract metadata
        metadata = self.get_field_metadata(field)
        prompt_text = metadata['prompt']
        help_text = metadata['help_text']
        validators = metadata['validators']
        is_required = metadata['required']
        default = metadata['default']

        # Check for password field
        is_password = 'password' in field.slug.lower()

        # Non-interactive mode
        if not interactive:
            return (
                default_value if default_value is not None
                else default
            )

        # Interactive prompting
        if help_text:
            print(f"  ({help_text})")

        # Prompt text with default
        prompt_display = (
            f"{prompt_text} [{default}]" if default is not None
            else f"{prompt_text}"
        )

        # Validation loop
        while True:
            # Get input
            value = (
                getpass.getpass(f"{prompt_display}: ")
                if is_password
                else input(f"{prompt_display}: ").strip()
            )

            # Use default if empty
            if not value and default is not None:
                value = str(default)

            # Validate
            if validators:
                is_valid, error = self._validate_input(
                    value,
                    validators,
                    prompt_text
                )
                if not is_valid:
                    print(f"✗ {error}")
                    continue

            # Check required
            if is_required and not value:
                print(f"✗ {prompt_text} is required")
                continue

            break

        return value

    async def prompt_for_fields(
        self,
        frag: 'Frag',
        field_names: list[str] | None = None,
        interactive: bool = True,
        defaults: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """
        Prompt for multiple field values.

        Args:
            frag: Frag containing field references
            field_names: List of field names to prompt for (None = all)
            interactive: Whether to prompt interactively
            defaults: Default values by field name

        Returns:
            Dict of {field_name: value}

        Example:
            user = Frag(affinities=['user'], traits=['userable'])
            values = await prompter.prompt_for_fields(
                user,
                ['username', 'email']
            )
        """
        from winterforge.frags.registries.field_registry import (
            FieldRegistry,
        )
        from winterforge.frags.traits.persistable import get_storage

        defaults = defaults or {}
        fields_registry = FieldRegistry()
        values = {}

        # Get field references from Frag
        if not hasattr(frag, 'get_field_references'):
            return values

        field_ref_ids = frag.get_field_references()

        # Load Field Frags from storage
        storage = get_storage()
        if not storage:
            return values

        for field_id in field_ref_ids:
            # Load field Frag from storage
            field_frag = await storage.load(field_id)
            if not field_frag:
                continue

            field_slug = field_frag.slug

            # Skip if not in requested field_names
            if field_names and field_slug not in field_names:
                continue

            # Get default value
            default_value = defaults.get(field_slug)

            # Prompt for value
            value = await self.prompt_for_field(
                field_frag,
                interactive=interactive,
                default_value=default_value
            )
            values[field_slug] = value

        return values

    def get_field_metadata(self, field: 'Frag') -> dict[str, Any]:
        """
        Extract metadata from field Frag.

        Args:
            field: Field definition Frag

        Returns:
            Dict with metadata keys:
            - prompt: Prompt text
            - validators: List of validator IDs
            - help_text: Help text
            - required: Boolean
            - default: Default value

        Example:
            metadata = prompter.get_field_metadata(email_field)
            print(metadata['prompt'])  # "Email address"
        """
        validators_str = field.get_alias('validators') or ''
        validators = [
            v.strip() for v in validators_str.split(',') if v.strip()
        ]

        return {
            'prompt': field.get_alias('prompt') or field.slug,
            'validators': validators,
            'help_text': field.get_alias('help-text'),
            'required': field.get_alias('required') == 'true',
            'default': (
                field.get_default()
                if hasattr(field, 'get_default')
                else None
            ),
        }

    def _validate_input(
        self,
        value: Any,
        validators: list[str],
        field_name: str
    ) -> tuple[bool, str]:
        """
        Validate input value.

        Args:
            value: Value to validate
            validators: List of validator IDs
            field_name: Field name for error messages

        Returns:
            Tuple of (is_valid, error_message)
        """
        from winterforge.plugins.validators import validate_input

        return validate_input(value, validators, field_name)
