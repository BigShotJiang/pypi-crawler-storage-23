"""
Input Prompt Plugins - Field value prompting strategies.

Provides pluggable strategies for prompting users for field values
based on field metadata.

Strategies:
- interactive_cli - Interactive CLI prompting with validation
- silent - Use defaults, no interaction
- (Future) web_form - Generate web form HTML
- (Future) api_schema - Generate API schema

Examples:
    # Get interactive prompter
    prompter = InputPromptManager.get('interactive_cli')
    email = await prompter.prompt_for_field(email_field)

    # Silent mode (automated)
    prompter = InputPromptManager.get('silent')
    values = await prompter.prompt_for_fields(user_frag, defaults={...})
"""

from winterforge.plugins.input_prompts.manager import InputPromptManager
from winterforge.plugins.input_prompts.protocols import (
    InputPromptProtocol,
)

__all__ = [
    'InputPromptManager',
    'InputPromptProtocol',
]
