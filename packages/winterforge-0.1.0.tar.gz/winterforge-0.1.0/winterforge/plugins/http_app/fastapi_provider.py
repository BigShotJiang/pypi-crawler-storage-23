"""FastAPI HTTP application provider."""

import inspect
from typing import Any, Dict, List, Type, get_type_hints
from winterforge.plugins.decorators import http_app_provider, root


@http_app_provider()
@root('fastapi')
class FastAPIProvider:
    """
    FastAPI HTTP application provider.

    Creates and configures FastAPI applications.
    Handles endpoint registration and OpenAPI documentation.
    """

    def __init__(self):
        """Initialize provider."""
        self._app = None

    def create_app(self, **config: Any) -> Any:
        """
        Create FastAPI application.

        Args:
            **config: FastAPI configuration (title, version, etc)

        Returns:
            FastAPI application instance
        """
        from fastapi import FastAPI

        # Create FastAPI app with config
        self._app = FastAPI(**config)
        return self._app

    def add_route(
        self,
        method: str,
        path: str,
        handler: Any,
        **options: Any
    ) -> None:
        """
        Register route with FastAPI app.

        Args:
            method: HTTP method (GET, POST, etc)
            path: URL path (/api/users/{id})
            handler: Async handler function
            **options: FastAPI route options
        """
        if not self._app:
            raise RuntimeError("App not created - call create_app() first")

        # Get FastAPI route decorator for method
        route_method = getattr(self._app, method.lower())

        # Register route
        route_method(path, **options)(handler)

    def _generate_endpoint_path(
        self,
        registry_class: Type,
        method: Any,
        original_func: Any
    ) -> str:
        """
        Generate HTTP endpoint path from @root, @version_root, and method signature.

        Args:
            registry_class: Registry class (should have @root)
            method: Decorated method
            original_func: Original undecorated function

        Returns:
            Generated path: /{root}/{version}/{method-name}/{args}

        Raises:
            ValueError: If @root not found on registry class
        """
        from winterforge.plugins.decorators.root import (
            get_root_namespace,
        )
        from winterforge.plugins.decorators.version_root import (
            get_version_root
        )

        # Get @root namespace from class - REQUIRED
        root_namespace = get_root_namespace(registry_class)
        if not root_namespace:
            raise ValueError(
                f"@http_endpoint requires @root decorator on {registry_class.__name__}. "
                f"Add @root('namespace') to the class."
            )

        # Get @version_root (default to 'v1' if not present)
        # Check the method first, then the class
        version = get_version_root(method) or get_version_root(registry_class) or 'v1'

        # Normalize function name to kebab-case
        func_name = original_func.__name__
        normalized_name = func_name.replace('_', '-')

        # Extract function signature
        sig = inspect.signature(original_func)
        params = list(sig.parameters.items())

        # Remove 'self' if present
        if params and params[0][0] == 'self':
            params = params[1:]

        # Separate required args (path params) from optional args (query params)
        path_params = []
        for param_name, param_obj in params:
            # Required parameters (no default) become path params
            if param_obj.default == inspect.Parameter.empty:
                path_params.append(param_name)

        # Build path: /{root}/{version}/{method-name}/{arg1}/{arg2}
        http_path = f'/{root_namespace}/{version}/{normalized_name}'

        # Add path parameters
        for param in path_params:
            http_path += f'/{{{param}}}'

        return http_path

    def register_endpoints(
        self,
        registry_classes: list,
        **options: Any
    ) -> None:
        """
        Register HTTP endpoints from registry classes.

        Scans registry classes for @http_endpoint decorated methods
        and registers them with FastAPI.

        Args:
            registry_classes: List of registry classes to scan
            **options: Registration options
        """
        if not self._app:
            raise RuntimeError("App not created - call create_app() first")

        from winterforge.plugins.http_request import HTTPRequestHandlerManager
        from winterforge.plugins.http_response import HTTPResponseHandlerManager
        from winterforge.plugins.http_authenticator import (
            HTTPAuthenticatorManager
        )

        for registry_class in registry_classes:
            # Scan class for HTTP endpoint methods
            for attr_name in dir(registry_class):
                attr = getattr(registry_class, attr_name)
                if not callable(attr):
                    continue

                # Check if decorated with @http_endpoint
                if not hasattr(attr, '__http_endpoint__'):
                    continue

                metadata = attr.__http_endpoint__
                http_method = metadata['method']
                http_path = metadata['path']
                auth_required = metadata['auth_required']
                route_options = metadata['options']
                original_func = metadata['original_func']

                # Auto-generate path if not provided
                if http_path is None:
                    http_path = self._generate_endpoint_path(
                        registry_class,
                        attr,
                        original_func
                    )

                # Extract path parameters from URL path (not function signature)
                # Path params are in {braces} in the path like /api/users/{identity}
                import re
                path_param_names = re.findall(r'\{(\w+)\}', http_path)

                # Create route handler with proper closure
                def make_handler(func, requires_auth, reg_class, path_params):
                    """Create FastAPI route handler."""
                    from fastapi import Request, Response

                    # Build handler signature dynamically
                    # FastAPI needs explicit path parameters
                    handler_params = [
                        inspect.Parameter(
                            'request',
                            inspect.Parameter.POSITIONAL_OR_KEYWORD,
                            annotation=Request
                        )
                    ]

                    # Add path parameters
                    for param_name in path_params:
                        handler_params.append(
                            inspect.Parameter(
                                param_name,
                                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                                annotation=str
                            )
                        )

                    async def handler(request: Request, **kwargs):
                        """FastAPI route handler."""
                        # Authenticate if required
                        user = None
                        if requires_auth:
                            user = await HTTPAuthenticatorManager.authenticate(
                                request,
                                {'required': True}
                            )

                        # Extract request data
                        request_frag = await HTTPRequestHandlerManager.extract(
                            request,
                            {}
                        )

                        # Merge path params with request body
                        call_kwargs = {**kwargs}
                        if request_frag.body and isinstance(
                            request_frag.body,
                            dict
                        ):
                            call_kwargs.update(request_frag.body)

                        # Call original method
                        registry = reg_class()
                        result = await func(registry, **call_kwargs)

                        # Format response
                        try:
                            response_data = await HTTPResponseHandlerManager.format(
                                result,
                                {
                                    'accept': request.headers.get(
                                        'accept',
                                        'application/json'
                                    )
                                }
                            )

                            # Return FastAPI response
                            return Response(
                                content=response_data['body'],
                                status_code=response_data['status_code'],
                                headers=response_data['headers']
                            )
                        except RuntimeError as e:
                            # No handler available for requested content type
                            return Response(
                                content=str(e),
                                status_code=500,
                                headers={'Content-Type': 'text/plain'}
                            )

                    # Update handler signature
                    handler.__signature__ = inspect.Signature(handler_params)

                    return handler

                # Register with FastAPI
                route_handler = make_handler(
                    original_func,
                    auth_required,
                    registry_class,
                    path_param_names
                )
                route_method = getattr(self._app, http_method.lower())
                route_method(http_path, **route_options)(route_handler)

    def generate_openapi_spec(
        self,
        registry_classes: list,
        title: str = "API",
        version: str = "1.0.0",
        description: str = ""
    ) -> Dict[str, Any]:
        """
        Generate OpenAPI 3.0 specification.

        Args:
            registry_classes: List of registry classes to document
            title: API title
            version: API version
            description: API description

        Returns:
            OpenAPI 3.0 spec dict
        """
        spec = {
            'openapi': '3.0.0',
            'info': {
                'title': title,
                'version': version,
                'description': description
            },
            'paths': {},
            'components': {
                'schemas': {},
                'securitySchemes': {
                    'bearerAuth': {
                        'type': 'http',
                        'scheme': 'bearer'
                    },
                    'basicAuth': {
                        'type': 'http',
                        'scheme': 'basic'
                    }
                }
            }
        }

        # Scan each registry class
        for registry_class in registry_classes:
            self._scan_registry(registry_class, spec)

        return spec

    def _scan_registry(
        self,
        registry_class: Type,
        spec: Dict[str, Any]
    ) -> None:
        """
        Scan registry class for HTTP endpoints.

        Args:
            registry_class: Registry class to scan
            spec: OpenAPI spec dict to update
        """
        # Get registry name for tags
        registry_name = registry_class.__name__.replace('Registry', '')

        # Scan for @http_endpoint methods
        for attr_name in dir(registry_class):
            attr = getattr(registry_class, attr_name)
            if not callable(attr):
                continue

            # Check for @http_endpoint
            if not hasattr(attr, '__http_endpoint__'):
                continue

            metadata = attr.__http_endpoint__
            http_method = metadata['method'].lower()
            http_path = metadata['path']
            auth_required = metadata['auth_required']
            original_func = metadata['original_func']

            # Auto-generate path if not provided
            if http_path is None:
                http_path = self._generate_endpoint_path(
                    registry_class,
                    attr,
                    original_func
                )

            # Create path entry if not exists
            if http_path not in spec['paths']:
                spec['paths'][http_path] = {}

            # Generate operation
            operation = self._generate_operation(
                original_func,
                registry_name,
                auth_required
            )

            spec['paths'][http_path][http_method] = operation

    def _generate_operation(
        self,
        func: Any,
        tag: str,
        auth_required: bool
    ) -> Dict[str, Any]:
        """
        Generate OpenAPI operation from function.

        Args:
            func: Function to document
            tag: OpenAPI tag (registry name)
            auth_required: Whether auth is required

        Returns:
            OpenAPI operation dict
        """
        # Extract docstring
        docstring = inspect.getdoc(func) or func.__name__

        # Parse docstring for summary/description
        lines = docstring.split('\n')
        summary = lines[0]
        description = '\n'.join(lines[1:]).strip() if len(lines) > 1 else summary

        operation = {
            'summary': summary,
            'description': description,
            'tags': [tag],
            'parameters': [],
            'responses': {
                '200': {
                    'description': 'Successful response',
                    'content': {
                        'application/json': {
                            'schema': {'type': 'object'}
                        }
                    }
                }
            }
        }

        # Add security if required
        if auth_required:
            operation['security'] = [{'bearerAuth': []}, {'basicAuth': []}]

        # Extract parameters from signature
        sig = inspect.signature(func)
        try:
            type_hints = get_type_hints(func)
        except Exception:
            type_hints = {}

        for param_name, param in sig.parameters.items():
            if param_name == 'self':
                continue

            # Determine parameter type
            param_type = type_hints.get(param_name, str)
            schema_type = self._python_type_to_json_schema(param_type)

            required = param.default == inspect.Parameter.empty

            if required:
                # Required body parameter (for POST/PUT/PATCH)
                if 'requestBody' not in operation:
                    operation['requestBody'] = {
                        'required': True,
                        'content': {
                            'application/json': {
                                'schema': {
                                    'type': 'object',
                                    'properties': {},
                                    'required': []
                                }
                            }
                        }
                    }

                schema = operation['requestBody']['content'][
                    'application/json'
                ]['schema']
                schema['properties'][param_name] = schema_type
                schema['required'].append(param_name)
            else:
                # Optional query parameter
                operation['parameters'].append({
                    'name': param_name,
                    'in': 'query',
                    'required': False,
                    'schema': schema_type
                })

        return operation

    def _python_type_to_json_schema(self, py_type: Any) -> Dict[str, str]:
        """
        Convert Python type to JSON Schema type.

        Args:
            py_type: Python type annotation

        Returns:
            JSON Schema type dict
        """
        type_map = {
            str: {'type': 'string'},
            int: {'type': 'integer'},
            float: {'type': 'number'},
            bool: {'type': 'boolean'},
            list: {'type': 'array'},
            dict: {'type': 'object'},
        }

        # Handle type strings
        if isinstance(py_type, str):
            py_type = {
                'str': str,
                'int': int,
                'float': float,
                'bool': bool
            }.get(py_type, str)

        return type_map.get(py_type, {'type': 'string'})

    def add_openapi_routes(self, spec: Dict[str, Any]) -> None:
        """
        Add OpenAPI spec and documentation routes.

        Adds /openapi.json endpoint serving the spec.
        FastAPI automatically uses this for /docs Swagger UI.

        Args:
            spec: OpenAPI 3.0 spec dict
        """
        if not self._app:
            raise RuntimeError("App not created - call create_app() first")

        @self._app.get("/openapi.json", include_in_schema=False)
        def get_openapi():
            """Serve OpenAPI specification."""
            return spec

        # FastAPI automatically provides /docs using /openapi.json

    async def startup(self) -> None:
        """Application startup lifecycle hook."""
        # FastAPI lifespan events can be configured here
        pass

    async def shutdown(self) -> None:
        """Application shutdown lifecycle hook."""
        # Cleanup resources
        pass
