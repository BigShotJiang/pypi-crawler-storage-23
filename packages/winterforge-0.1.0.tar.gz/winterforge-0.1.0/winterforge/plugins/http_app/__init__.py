"""HTTP application provider plugins."""

from winterforge.plugins.http_app.manager import (
    HTTPAppProviderManager
)

# Import plugins to trigger decorator registration
from winterforge.plugins.http_app import fastapi_provider  # noqa: F401

__all__ = ['HTTPAppProviderManager', 'fastapi_provider']
