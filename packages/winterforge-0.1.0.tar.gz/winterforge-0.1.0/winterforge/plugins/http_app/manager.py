"""HTTP app provider manager.

Manages registration and resolution of HTTP application provider plugins.
"""

from typing import Any, Optional
from winterforge.plugins._base import ReorderablePluginManagerBase


class HTTPAppProviderManager(ReorderablePluginManagerBase):
    """
    Manager for HTTP application provider plugins.

    Providers create and configure HTTP applications (FastAPI, Flask, etc).

    Example:
        # Create app using default provider
        app = HTTPAppProviderManager.create_app(
            title="WinterForge API",
            version="1.0.0"
        )

        # Get provider for advanced operations
        provider = HTTPAppProviderManager.get('fastapi')
        provider.add_route('get', '/users', handle_list_users)
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.http_app_providers'

    @classmethod
    def create_app(cls, provider_id: str = None, **config: Any) -> Any:
        """
        Create HTTP application using specified or default provider.

        Args:
            provider_id: Specific provider ('fastapi', 'flask', etc)
            **config: Provider-specific configuration

        Returns:
            Application instance

        Raises:
            RuntimeError: If no provider available
        """
        if provider_id:
            try:
                provider = cls.get(provider_id)
            except KeyError:
                raise RuntimeError(f"No HTTP app provider: {provider_id}")
            if not provider:
                raise RuntimeError(f"No HTTP app provider: {provider_id}")
        else:
            # Use first registered provider
            provider_id = cls.repository().order()[0] if cls.repository().order() else None
            if not provider_id:
                raise RuntimeError("No HTTP app providers registered")
            provider = cls.get(provider_id)

        return provider.create_app(**config)
