"""HTTP authenticator manager.

Manages registration and resolution of HTTP authenticator plugins.
Uses standard "first match wins" pattern based on applicability.
"""

from typing import Any, Dict, Optional, TYPE_CHECKING
from winterforge.plugins._base import ReorderablePluginManagerBase

if TYPE_CHECKING:
    from winterforge.plugins._protocols.http import HTTPAuthenticator
    from winterforge.frags.base import Frag


class HTTPAuthenticatorManager(ReorderablePluginManagerBase):
    """
    Manager for HTTP authenticator plugins.

    Uses standard reconciliation pattern: query all authenticators,
    first one that applies_to() wins.

    Example:
        # Authenticate user from HTTP request
        user = await HTTPAuthenticatorManager.authenticate(
            request,
            config={'required': True}
        )
        if user:
            print(f"Authenticated: {user.username}")
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.http_authenticators'

    @classmethod
    async def authenticate(
        cls,
        request: Any,
        config: Dict[str, Any] = None
    ) -> Optional['Frag']:
        """
        Authenticate user from HTTP request using first applicable handler.

        Queries all authenticators in order, uses first match.

        Args:
            request: HTTP request object
            config: Authenticator configuration

        Returns:
            User Frag on success, None on failure

        Raises:
            RuntimeError: If authentication required but no authenticator applies
        """
        config = config or {}
        required = config.get('required', False)

        # Query authenticators in order
        for auth_id in cls.repository().order():
            authenticator = cls.get(auth_id)
            if authenticator and authenticator.applies_to(request, config):
                user = await authenticator.authenticate(request, config)
                if user:
                    return user
                # Authenticator applied but authentication failed
                if required:
                    raise RuntimeError("Authentication required but failed")
                return None

        # No authenticator applied
        if required:
            raise RuntimeError("Authentication required but no authenticator applies")
        return None
