"""HTTP authenticator plugins."""

from winterforge.plugins.http_authenticator.manager import (
    HTTPAuthenticatorManager
)

# Import plugins to trigger decorator registration
from winterforge.plugins.http_authenticator import (  # noqa: F401
    bearer_authenticator,
    basic_authenticator,
)

__all__ = [
    'HTTPAuthenticatorManager',
    'bearer_authenticator',
    'basic_authenticator',
]
