"""Basic HTTP authenticator."""

import base64
from typing import Any, Dict, Optional, TYPE_CHECKING
from winterforge.plugins.decorators import http_authenticator, root
from winterforge.plugins.authentication import AuthenticationProviderManager

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@http_authenticator()
@root('basic')
class BasicAuthenticator:
    """
    Basic HTTP authenticator.

    Authenticates users via Basic auth in Authorization header.
    Uses AuthenticationProviderManager to verify username/password.
    """

    def applies_to(self, request: Any, config: Dict[str, Any]) -> bool:
        """
        Apply when Authorization header has Basic auth.

        Args:
            request: HTTP request object
            config: Authenticator configuration

        Returns:
            True if Authorization: Basic <credentials> present
        """
        if not hasattr(request, 'headers'):
            return False

        auth = request.headers.get('authorization', '')
        return auth.lower().startswith('basic ')

    async def authenticate(
        self,
        request: Any,
        config: Dict[str, Any]
    ) -> Optional['Frag']:
        """
        Authenticate user from Basic auth.

        Args:
            request: HTTP request object
            config: Authenticator configuration

        Returns:
            User Frag on success, None on failure
        """
        # Extract credentials from Authorization header
        auth = request.headers.get('authorization', '')
        if not auth.lower().startswith('basic '):
            return None

        # Decode base64 credentials
        try:
            encoded = auth[6:].strip()
            decoded = base64.b64decode(encoded).decode('utf-8')
            username, password = decoded.split(':', 1)
        except Exception:
            return None

        # Authenticate using AuthenticationProviderManager
        try:
            credentials = {
                'username': username,
                'password': password
            }
            user = await AuthenticationProviderManager.authenticate(
                credentials
            )
            return user
        except Exception:
            return None
