"""Bearer token HTTP authenticator."""

from typing import Any, Dict, Optional, TYPE_CHECKING
from winterforge.plugins.decorators import http_authenticator, root
from winterforge.plugins.session import SessionProviderManager

if TYPE_CHECKING:
    from winterforge.frags.base import Frag
    from winterforge.frags.registries.user_registry import UserRegistry


@http_authenticator()
@root('bearer')
class BearerAuthenticator:
    """
    Bearer token HTTP authenticator.

    Authenticates users via Bearer tokens in Authorization header.
    Uses SessionProviderManager to verify tokens and load users.
    """

    def applies_to(self, request: Any, config: Dict[str, Any]) -> bool:
        """
        Apply when Authorization header has Bearer token.

        Args:
            request: HTTP request object
            config: Authenticator configuration

        Returns:
            True if Authorization: Bearer <token> present
        """
        if not hasattr(request, 'headers'):
            return False

        auth = request.headers.get('authorization', '')
        return auth.lower().startswith('bearer ')

    async def authenticate(
        self,
        request: Any,
        config: Dict[str, Any]
    ) -> Optional['Frag']:
        """
        Authenticate user from Bearer token.

        Args:
            request: HTTP request object
            config: Authenticator configuration

        Returns:
            User Frag on success, None on failure
        """
        # Extract token from Authorization header
        auth = request.headers.get('authorization', '')
        if not auth.lower().startswith('bearer '):
            return None

        token = auth[7:].strip()  # Remove "Bearer " prefix
        if not token:
            return None

        # Verify token using SessionProviderManager
        try:
            # verify_session returns user_id or None
            user_id = await SessionProviderManager.verify_session(token)
            if not user_id:
                return None

            # Load user Frag (lazy import to avoid circular dependency)
            from winterforge.frags.registries.user_registry import UserRegistry
            users = UserRegistry()
            user = await users.get(user_id)
            return user

        except Exception:
            # Token verification failed
            return None
