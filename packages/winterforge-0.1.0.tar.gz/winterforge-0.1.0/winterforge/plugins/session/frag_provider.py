"""Frag session provider.

Stateful session storage using Frags (revocable, trackable).
"""

from __future__ import annotations

from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
import secrets

from winterforge.plugins.decorators import session_provider, root


@session_provider()
@root('frag')
class FragSessionProvider:
    """
    Stateful session storage using Frags (revocable, trackable).

    Sessions are stored as Frags with affinity=['session'] and traits=['tokenable',
    'timestamped', 'ownable']. This allows sessions to be revoked, listed, and
    tracked across the application.

    Example:
        provider = await SessionProviderManager.get('frag')
        token = await provider.create(user_id=123, ttl=86400)
        session_data = await provider.verify(token)
        await provider.invalidate(token)
    """

    async def create(self, user_id: int, ttl: int, **claims) -> str:
        """
        Create session Frag and return token.

        Args:
            user_id: User Frag ID
            ttl: Time-to-live in seconds
            **claims: Additional metadata to store

        Returns:
            Session token string
        """
        from winterforge.frags.base import Frag

        token = secrets.token_urlsafe(32)
        expires_at = datetime.now() + timedelta(seconds=ttl)

        session = Frag(
            affinities=['session'],
            traits=['tokenable', 'timestamped', 'ownable', 'persistable']
        )
        session.set_token(token)
        session.set_owner(user_id)
        session.set_expires_at(expires_at)
        session.set_token_type('session')

        # TODO: Store additional claims as metadata once metadata trait is implemented
        # if claims:
        #     for key, value in claims.items():
        #         session.set_metadata(key, value)

        await session.save()
        return token

    async def verify(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Look up session Frag by token.

        Args:
            token: Session token string

        Returns:
            Session data dict if valid, None otherwise
        """
        from winterforge.frags.registries.frag_registry import FragRegistry

        registry = FragRegistry({'affinities': ['session'], 'traits': ['tokenable']})

        # Query for non-expired sessions with matching token
        filtered_registry = await registry.filter(
            lambda s: (
                s.token == token and
                s.expires_at > datetime.now() and
                s.token_type == 'session'
            )
        )
        sessions = await filtered_registry.all()

        if not sessions:
            return None

        session = sessions[0]
        return {
            'user_id': session.owner_id,
            'expires_at': session.expires_at,
            'created_on': session.created_on,
            'token': session.token
        }

    async def invalidate(self, token: str) -> bool:
        """
        Delete session Frag.

        Args:
            token: Session token string

        Returns:
            True if invalidated, False if not found
        """
        from winterforge.frags.registries.frag_registry import FragRegistry

        registry = FragRegistry({'affinities': ['session'], 'traits': ['tokenable']})
        filtered_registry = await registry.filter(lambda s: s.token == token)
        sessions = await filtered_registry.all()

        if sessions:
            await sessions[0].delete()
            return True
        return False

    async def get_user_sessions(self, user_id: int) -> List[Dict[str, Any]]:
        """
        Get all active sessions for user.

        Args:
            user_id: User Frag ID

        Returns:
            List of session data dicts
        """
        from winterforge.frags.registries.frag_registry import FragRegistry

        registry = FragRegistry({'affinities': ['session'], 'traits': ['tokenable', 'ownable']})
        filtered_registry = await registry.filter(
            lambda s: (
                s.owner_id == user_id and
                s.expires_at > datetime.now() and
                s.token_type == 'session'
            )
        )
        sessions = await filtered_registry.all()

        return [
            {
                'token': s.token,
                'expires_at': s.expires_at,
                'created_on': s.created_on
            }
            for s in sessions
        ]
