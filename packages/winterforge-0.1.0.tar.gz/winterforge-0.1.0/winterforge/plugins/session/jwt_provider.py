"""JWT session provider.

Stateless JWT sessions (fast, scalable, not revocable).
"""

from __future__ import annotations

from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta, timezone

from winterforge.plugins.decorators import session_provider, root


@session_provider()
@root('jwt')
class JWTSessionProvider:
    """
    Stateless JWT sessions (fast, scalable, not revocable).

    Sessions are encoded as JWTs with no server-side storage. This makes
    them fast and scalable, but they cannot be revoked before expiration.

    Example:
        provider = SessionProviderManager.get('jwt')
        token = await provider.create(user_id=123, ttl=3600)
        session_data = await provider.verify(token)
    """

    def __init__(self, secret_key: str = None):
        """
        Initialize with JWT secret from config.

        Args:
            secret_key: Optional JWT secret (loads from config if not provided)
        """
        if not secret_key:
            # Load from environment or config Frag
            import os
            secret_key = os.environ.get('WINTERFORGE_JWT_SECRET')

            # Config Frag loading removed - use env var or pass secret_key directly
            # (config.get() is async and can't be called from __init__)

            if not secret_key:
                # Use default secret for development (warn in production)
                import secrets
                secret_key = secrets.token_urlsafe(32)
                import warnings
                warnings.warn(
                    "Using auto-generated JWT secret. Set WINTERFORGE_JWT_SECRET environment "
                    "variable or create config Frag for production use.",
                    UserWarning
                )

        self.secret_key = secret_key

    async def create(self, user_id: int, ttl: int, **claims) -> str:
        """
        Create JWT token.

        Args:
            user_id: User Frag ID
            ttl: Time-to-live in seconds
            **claims: Additional claims to include in JWT

        Returns:
            JWT token string
        """
        import jwt

        payload = {
            'user_id': user_id,
            'exp': datetime.now(timezone.utc) + timedelta(seconds=ttl),
            'iat': datetime.now(timezone.utc),
            'type': 'session',
            **claims
        }

        return jwt.encode(payload, self.secret_key, algorithm='HS256')

    async def verify(self, token: str) -> Optional[Dict[str, Any]]:
        """
        Verify JWT token.

        Args:
            token: JWT token string

        Returns:
            Session data dict if valid, None otherwise
        """
        import jwt

        try:
            payload = jwt.decode(token, self.secret_key, algorithms=['HS256'])
            if payload.get('type') != 'session':
                return None
            return payload
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None

    async def invalidate(self, token: str) -> bool:
        """
        Cannot invalidate JWT tokens (stateless).

        Args:
            token: JWT token string

        Returns:
            False (JWTs cannot be revoked)
        """
        return False  # Stateless - no revocation possible

    async def get_user_sessions(self, user_id: int) -> List[Dict[str, Any]]:
        """
        Cannot list JWT sessions (stateless).

        Args:
            user_id: User Frag ID

        Returns:
            Empty list (JWTs have no session tracking)
        """
        return []  # Stateless - no session tracking
