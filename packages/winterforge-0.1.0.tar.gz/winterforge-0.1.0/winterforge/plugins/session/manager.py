"""Session provider manager.

Manages session implementations (Frag, JWT, etc.).
"""

from __future__ import annotations

from typing import Optional, Dict, Any, List

from winterforge.plugins._base import ReorderablePluginManagerBase


class SessionProviderManager(ReorderablePluginManagerBase):
    """
    Manages session provider implementations.

    Provides centralized access to session providers with automatic
    fallback to the first registered provider.

    Example:
        # Create session using default provider
        provider_id = SessionProviderManager.repository().order()[0]
            provider = SessionProviderManager.get(provider_id)
        token = await provider.create(user_id=123, ttl=86400)

        # Verify session
        session_data = await provider.verify(token)
        print(f"User ID: {session_data['user_id']}")

        # Use specific provider
        jwt_provider = SessionProviderManager.get('jwt')
        token = await jwt_provider.create(user_id=123, ttl=3600)
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.session_providers'

    @classmethod
    async def create_session(
        cls,
        user_id: int,
        ttl: int = 86400,
        provider_id: str = None,
        **claims
    ) -> str:
        """
        Create session using specified or default provider.

        Args:
            user_id: User Frag ID
            ttl: Time-to-live in seconds
            provider_id: Optional specific provider to use
            **claims: Additional session claims

        Returns:
            Session token string
        """
        if not provider_id:
            provider_id = cls.repository().order()[0]
        provider_class = cls.get(provider_id)
        provider = provider_class() if isinstance(provider_class, type) else provider_class
        return await provider.create(user_id, ttl, **claims)

    @classmethod
    async def verify_session(cls, token: str, provider_id: str = None) -> Optional[Dict[str, Any]]:
        """
        Verify session token using specified or all providers.

        Args:
            token: Session token string
            provider_id: Optional specific provider to use

        Returns:
            Session data dict if valid, None otherwise
        """
        if provider_id:
            provider_class = cls.get(provider_id)
            provider = provider_class() if isinstance(provider_class, type) else provider_class
            return await provider.verify(token)

        # Try all providers
        for provider_class in cls.repository().values():
            provider = provider_class() if isinstance(provider_class, type) else provider_class
            session_data = await provider.verify(token)
            if session_data:
                return session_data

        return None

    @classmethod
    async def invalidate_session(cls, token: str, provider_id: str = None) -> bool:
        """
        Invalidate session using specified or all providers.

        Args:
            token: Session token string
            provider_id: Optional specific provider to use

        Returns:
            True if invalidated, False otherwise
        """
        if provider_id:
            provider_class = cls.get(provider_id)
            provider = provider_class() if isinstance(provider_class, type) else provider_class
            return await provider.invalidate(token)

        # Try all providers
        for provider_class in cls.repository().values():
            provider = provider_class() if isinstance(provider_class, type) else provider_class
            if await provider.invalidate(token):
                return True

        return False

    @classmethod
    async def get_user_sessions(cls, user_id: int, provider_id: str = None) -> List[Dict[str, Any]]:
        """
        Get all active sessions for user.

        Args:
            user_id: User Frag ID
            provider_id: Optional specific provider to use

        Returns:
            List of session data dicts
        """
        if not provider_id:
            provider_id = cls.repository().order()[0]
        provider = cls.get(provider_id)
        return await provider.get_user_sessions(user_id)
