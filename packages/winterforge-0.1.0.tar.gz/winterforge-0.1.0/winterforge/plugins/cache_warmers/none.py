"""None cache warmer - never warm automatically."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.plugins.cache._backend import CacheBackend


class NoneCacheWarmer:
    """
    None cache warmer.

    Never warms cache automatically. Cache must be warmed
    manually by calling cache.warm() directly.

    Example:
        warmer = NoneCacheWarmer()
        result = await warmer.warm(cache)
        # Returns 'skipped' - cache remains cold
    """

    async def warm(self, cache: 'CacheBackend') -> dict[str, Any]:
        """
        Skip warming.

        Cache remains cold until manually warmed.

        Args:
            cache: Cache backend (not warmed)

        Returns:
            Dict indicating warming was skipped
        """
        return {
            'status': 'skipped',
            'strategy': 'none',
            'count': 0
        }


# Auto-register with manager
from winterforge.plugins.cache_warmers.manager import CacheWarmerManager

CacheWarmerManager.register('none', NoneCacheWarmer)

__all__ = ['NoneCacheWarmer']
