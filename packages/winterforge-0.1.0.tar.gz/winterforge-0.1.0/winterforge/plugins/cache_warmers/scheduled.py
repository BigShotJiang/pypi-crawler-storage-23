"""Scheduled cache warmer - warm at intervals."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.plugins.cache._backend import CacheBackend


class ScheduledCacheWarmer:
    """
    Scheduled cache warmer.

    Warms cache at specified intervals using event system.
    interval=0 means instant (warm immediately on cache creation).

    This is the DEFAULT warming strategy.

    Example:
        # Instant warming (default)
        warmer = ScheduledCacheWarmer(interval=0)
        await warmer.warm(cache)

        # Periodic warming (every 60 seconds)
        warmer = ScheduledCacheWarmer(interval=60)
        await warmer.warm(cache)
    """

    def __init__(self, interval: int = 0):
        """
        Initialize scheduled warmer.

        Args:
            interval: Warming interval in seconds
                     0 = instant (warm immediately)
                     >0 = periodic (schedule recurring warming)
        """
        self.interval = interval

    async def warm(self, cache: 'CacheBackend') -> dict[str, Any]:
        """
        Warm cache on schedule.

        For interval=0: Warm immediately
        For interval>0: Schedule periodic warming via event system

        Args:
            cache: Cache backend to warm

        Returns:
            Dict with warming results
        """
        if self.interval == 0:
            # Instant warming - warm now
            await cache.warm()
            return {
                'status': 'warmed',
                'interval': 0,
                'count': cache.size() if hasattr(cache, 'size') else 0
            }
        else:
            # Periodic warming - schedule via events
            # TODO: Emit 'cache.warm' event on interval
            # For now, just warm once
            await cache.warm()
            return {
                'status': 'warmed',
                'interval': self.interval,
                'count': cache.size() if hasattr(cache, 'size') else 0
            }


# Auto-register with manager
from winterforge.plugins.cache_warmers.manager import CacheWarmerManager

CacheWarmerManager.register('scheduled', ScheduledCacheWarmer)

__all__ = ['ScheduledCacheWarmer']
