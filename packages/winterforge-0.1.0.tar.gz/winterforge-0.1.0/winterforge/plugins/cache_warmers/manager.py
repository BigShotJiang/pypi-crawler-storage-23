"""Manager for cache warmer plugins."""

from __future__ import annotations

from typing import Optional, TYPE_CHECKING

from winterforge.plugins._base import ReorderablePluginManagerBase

if TYPE_CHECKING:
    from winterforge.plugins.cache_warmers.protocol import CacheWarmer


class CacheWarmerManager(ReorderablePluginManagerBase):
    """
    Manager for cache warmer plugins.

    Cache warmers are subsidiary to cache backends, defining
    WHEN and HOW caches are warmed (populated).

    Uses first-match resolution via repository().resolve():
    - scheduled → lazy → none

    Default behavior: Scheduled with interval=0 (instant warming).

    Example:
        # Get default warmer for a cache
        repo = CacheWarmerManager.repository()
        warmer = repo.resolve(lambda w: w.can_warm())

        # Warm the cache
        await warmer.warm(cache_backend)
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return cache warmer manager identifier."""
        return 'winterforge.cache_warmers'

    @classmethod
    async def warm_cache(
        cls,
        cache_id: str,
        cache_backend: 'CacheBackend'
    ) -> dict:
        """
        Warm cache using first applicable warmer.

        Uses repository resolution to find first warmer
        that can handle this cache.

        Args:
            cache_id: Cache backend identifier
            cache_backend: Cache backend instance to warm

        Returns:
            Dict with warming results:
                - warmer: Warmer type used
                - status: 'warmed' or 'skipped'
                - count: Items warmed (if applicable)

        Example:
            results = await CacheWarmerManager.warm_cache(
                'user_cache',
                user_cache_backend
            )
        """
        repo = cls.repository()

        # First-match resolution
        warmer_class = repo.resolve(lambda w: True)  # First registered

        if not warmer_class:
            return {
                'warmer': 'none',
                'status': 'skipped',
                'reason': 'no_warmers_registered'
            }

        # Instantiate warmer
        warmer = warmer_class()

        # Warm the cache
        result = await warmer.warm(cache_backend)

        return {
            'warmer': warmer.__class__.__name__.lower(),
            'status': result.get('status', 'unknown'),
            'count': result.get('count', 0)
        }


__all__ = ['CacheWarmerManager']
