"""Protocol for cache warmer plugins."""

from __future__ import annotations

from typing import Protocol, Any, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.plugins.cache._backend import CacheBackend


class CacheWarmer(Protocol):
    """
    Protocol for cache warmer plugins.

    Cache warmers define WHEN and HOW caches are populated:
    - Scheduled: Warm at intervals (0=instant, >0=periodic)
    - Lazy: Warm on first access
    - None: Never warm (manual only)

    Warmers are subsidiary to cache backends via @scope decorator.
    """

    async def warm(self, cache: 'CacheBackend') -> dict[str, Any]:
        """
        Warm the cache.

        Args:
            cache: Cache backend to warm

        Returns:
            Dict with warming results:
                - status: 'warmed', 'skipped', or 'deferred'
                - count: Number of items warmed
                - interval: Next warming interval (if scheduled)
        """
        ...


__all__ = ['CacheWarmer']
