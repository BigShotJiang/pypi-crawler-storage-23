"""Argon2 password hashing provider.

Uses Argon2id algorithm for memory-hard, GPU-resistant password hashing.
"""

from __future__ import annotations

from winterforge.plugins.decorators import hashing_provider, root


@hashing_provider()
@root('argon2')
class Argon2HashingProvider:
    """
    Argon2id password hashing.

    Argon2 is a memory-hard hashing algorithm that won the Password Hashing
    Competition in 2015. It's resistant to GPU cracking attacks.

    Example:
        provider = HashingProviderManager.get('argon2')
        hashed = provider.hash('my_password')
        is_valid = provider.verify('my_password', hashed)
    """

    def __init__(
        self,
        time_cost: int = 2,
        memory_cost: int = 65536,
        parallelism: int = 1
    ):
        """
        Initialize Argon2 hasher.

        Args:
            time_cost: Number of iterations (higher = slower)
            memory_cost: Memory usage in KB (higher = more resistant)
            parallelism: Number of parallel threads
        """
        from argon2 import PasswordHasher

        self.hasher = PasswordHasher(
            time_cost=time_cost,
            memory_cost=memory_cost,
            parallelism=parallelism
        )

    def hash(self, plain: str) -> str:
        """
        Hash plain text password.

        Args:
            plain: Plain text password

        Returns:
            Argon2 hash string
        """
        return self.hasher.hash(plain)

    def verify(self, plain: str, hashed: str) -> bool:
        """
        Verify plain text against hash.

        Args:
            plain: Plain text password
            hashed: Argon2 hash

        Returns:
            True if matches, False otherwise
        """
        from argon2.exceptions import VerifyMismatchError

        try:
            self.hasher.verify(hashed, plain)
            return True
        except (VerifyMismatchError, Exception):
            return False
