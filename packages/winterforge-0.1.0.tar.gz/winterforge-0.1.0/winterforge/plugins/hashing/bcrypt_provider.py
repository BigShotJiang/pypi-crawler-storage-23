"""Bcrypt password hashing provider.

Uses bcrypt algorithm for password hashing (proven, widely used).
"""

from __future__ import annotations

from winterforge.plugins.decorators import hashing_provider, root


@hashing_provider()
@root('bcrypt')
class BcryptHashingProvider:
    """
    Bcrypt password hashing.

    Bcrypt is a proven password hashing algorithm that's been in use
    for over 20 years. Slower than Argon2 but very reliable.

    Example:
        provider = HashingProviderManager.get('bcrypt')
        hashed = provider.hash('my_password')
        is_valid = provider.verify('my_password', hashed)
    """

    def __init__(self, rounds: int = 12):
        """
        Initialize Bcrypt hasher.

        Args:
            rounds: Cost factor (higher = slower, more secure)
        """
        import bcrypt
        self.rounds = rounds
        self.bcrypt = bcrypt

    def hash(self, plain: str) -> str:
        """
        Hash plain text password.

        Args:
            plain: Plain text password

        Returns:
            Bcrypt hash string
        """
        return self.bcrypt.hashpw(
            plain.encode('utf-8'),
            self.bcrypt.gensalt(rounds=self.rounds)
        ).decode('utf-8')

    def verify(self, plain: str, hashed: str) -> bool:
        """
        Verify plain text against hash.

        Args:
            plain: Plain text password
            hashed: Bcrypt hash

        Returns:
            True if matches, False otherwise
        """
        try:
            return self.bcrypt.checkpw(
                plain.encode('utf-8'),
                hashed.encode('utf-8')
            )
        except Exception:
            return False
