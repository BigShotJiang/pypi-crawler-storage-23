"""Hashing provider manager.

Manages password hashing implementations (Argon2, Bcrypt, etc.).
"""

from __future__ import annotations

from winterforge.plugins._base import ReorderablePluginManagerBase


class HashingProviderManager(ReorderablePluginManagerBase):
    """
    Manages password hashing implementations.

    Provides centralized access to password hashing providers with
    automatic fallback to the first registered provider.

    Example:
        # Hash password using default provider
        hashed = HashingProviderManager.hash_password('my_password')

        # Verify password
        if HashingProviderManager.verify_password('my_password', hashed):
            print('Password correct!')

        # Use specific provider
        hashed = HashingProviderManager.hash_password('my_password', provider_id='argon2')
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.hashing_providers'

    @classmethod
    def hash_password(cls, plain: str, provider_id: str = None) -> str:
        """
        Hash password using specified or default provider.

        Args:
            plain: Plain text password
            provider_id: Optional specific provider to use

        Returns:
            Hashed password string
        """
        if not provider_id:
            provider_id = cls.repository().order()[0]
        provider = cls.get(provider_id)
        return provider.hash(plain)

    @classmethod
    def verify_password(cls, plain: str, hashed: str, provider_id: str = None) -> bool:
        """
        Verify password using specified or all providers.

        Args:
            plain: Plain text password
            hashed: Hashed password
            provider_id: Optional specific provider to use

        Returns:
            True if password matches, False otherwise
        """
        if provider_id:
            provider = cls.get(provider_id)
            return provider.verify(plain, hashed)

        # Try all providers (useful when hash format unknown)
        for provider_id in cls.repository().order():
            provider = cls.get(provider_id)
            if provider.verify(plain, hashed):
                return True

        return False
