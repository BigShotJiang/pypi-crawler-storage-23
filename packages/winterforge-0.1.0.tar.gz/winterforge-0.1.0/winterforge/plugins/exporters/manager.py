"""Export plugin manager."""

from winterforge.plugins._base import PluginManagerBase


class ExportManager(PluginManagerBase):
    """
    Manager for data export plugins.

    Export plugins write Frag data to various targets:
    - File systems (YAML, JSON, CSV)
    - Cloud storage (S3, Azure, GCS)
    - APIs (HTTP, GraphQL)
    - Databases (direct export)

    Plugins are configured and added to data_target Frags,
    which can contain multiple exporters for simultaneous
    multi-target exports.

    Example:
        # YAML file exporter
        yaml_exp = YamlFileExporter(path='/backup/export.yaml')

        # S3 exporter
        s3_exp = S3Exporter(bucket='backups', key='export.yaml')

        # Compose into Frag
        output = Frag(affinities=['data_target'], traits=['has_data_target'])
        output.exporters = [yaml_exp, s3_exp]

        # Export to both targets
        await transport.dump_raw(output=output)
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Plugin manager identifier."""
        return 'winterforge.exporters'
