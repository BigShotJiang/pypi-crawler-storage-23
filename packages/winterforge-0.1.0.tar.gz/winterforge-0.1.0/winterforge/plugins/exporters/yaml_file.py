"""YAML file export plugin."""

from pathlib import Path
from typing import Any, Dict, List
import yaml
from datetime import datetime

from winterforge.plugins.decorators import plugin


@plugin('winterforge.exporters', 'yaml_file')
class YamlFileExporter:
    """
    Export data to YAML file.

    Pre-configured instance specifies output path and formatting.
    Writes Frag data to YAML file with metadata header.

    Example:
        exporter = YamlFileExporter(path='/backup/export.yaml')
        output = Frag(affinities=['data_target'], traits=['has_data_target'])
        output.add_exporter(exporter)
        output.set_portable(True)
    """

    def __init__(self, path: str = None):
        """
        Initialize YAML file exporter.

        Args:
            path: Output file path (optional, can be set later)
        """
        self.path = path

    async def write(
        self,
        rows: List[Dict[str, Any]],
        target_frag: 'Frag'
    ) -> Dict[str, Any]:
        """
        Write Frag data to YAML file.

        Args:
            rows: Raw Frag data rows from storage
            target_frag: Data target Frag (provides portable setting, etc.)

        Returns:
            Export statistics

        Example:
            exporter = YamlFileExporter(path='/backup.yaml')
            stats = await exporter.write(rows, target_frag)
            # → {'exported': 247, 'file': '/backup.yaml'}
        """
        from winterforge.frags.traits._manager import FragTraitManager

        # Detect orphaned columns (provenance-based naming)
        base_columns = {'id', 'uuid', 'affinities', 'traits', 'aliases'}
        orphaned_columns = set()

        if rows:
            for col_name in rows[0].keys():
                if col_name in base_columns:
                    continue

                # Parse: {package}__{trait_id}__{field_name}
                parts = col_name.split('__')
                if len(parts) >= 3:
                    trait_id = parts[1]
                    if not FragTraitManager.has(trait_id):
                        orphaned_columns.add(col_name)

        # Build export structure
        export_data = {
            'version': '1.0',
            'exported_at': datetime.now().isoformat(),
            'export_type': 'portable' if target_frag.portable else 'recovery',
            'frag_count': len(rows),
            'orphaned_columns': sorted(orphaned_columns),
            'frags': {}
        }

        # Use UUID as key
        for row in rows:
            uuid = row.get('uuid', f"no-uuid-{row['id']}")
            export_data['frags'][uuid] = row

        # Write YAML
        output_file = Path(self.path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        with output_file.open('w') as f:
            f.write("# WinterForge Frag Export\n")
            if target_frag.portable:
                f.write("# Portable export (no application Frags)\n")
            else:
                f.write("# Recovery export (includes application Frags)\n")
            f.write(f"# Exported: {export_data['exported_at']}\n")
            if orphaned_columns:
                f.write(
                    f"# Orphaned fields: {len(orphaned_columns)} "
                    f"(traits missing)\n"
                )
            f.write("\n")

            yaml.dump(
                export_data,
                f,
                default_flow_style=False,
                allow_unicode=True,
                sort_keys=False
            )

        return {
            'exported': len(rows),
            'orphaned_columns': sorted(orphaned_columns),
            'orphaned_count': len(orphaned_columns),
            'file': str(output_file),
            'size_kb': output_file.stat().st_size / 1024
        }
