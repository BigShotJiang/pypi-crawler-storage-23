"""
Cache backend management.

Manages cache backends using Repository pattern for
layered caching and global cache operations.
"""

from __future__ import annotations

from typing import Optional, TYPE_CHECKING

from winterforge.plugins._base import ReorderablePluginManagerBase

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class CacheBackendManager(ReorderablePluginManagerBase):
    """
    Manage cache backends.

    Coordinates cache backends using Repository pattern:
    - resolve() - First-match (get from first cache)
    - resolve_all() - Chain-of-responsibility (set in all caches)

    Provides global cache operations across all backends.
    Backends can be layered (e.g., L1 in-memory + L2 Redis).

    Example:
        # Get from cache (first-match across backends)
        frag = CacheBackendManager.get(42)

        # Set in cache (all backends)
        CacheBackendManager.set(42, frag)

        # Invalidate across all backends
        CacheBackendManager.invalidate(42)

        # Get statistics across all backends
        stats = CacheBackendManager.get_stats()
        # {'lru': {'hits': 1523, 'size': 987}}
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return the plugin manager identifier."""
        return 'winterforge.cache_backends'

    @classmethod
    def get(cls, frag_id: int) -> Optional['Frag']:
        """
        Get Frag from cache.

        Uses resolve() - first-match logic across backends.
        Tries backends in registration order until one returns a Frag.

        Args:
            frag_id: Frag ID

        Returns:
            Cached Frag or None

        Example:
            frag = CacheBackendManager.get(42)
            if frag:
                # Cache hit
                return frag
            else:
                # Cache miss - load from storage
                frag = await storage.load(42)
                CacheBackendManager.set(42, frag)
        """
        # Get repository
        repo = cls.repository()

        # Try each backend (first-match)
        for backend_id, backend_class in repo.items():
            # Use parent's get() to retrieve backend instance
            backend = super(CacheBackendManager, cls).get(backend_id)
            if backend:
                frag = backend.get(frag_id)
                if frag:
                    return frag

        return None

    @classmethod
    def set(cls, frag_id: int, frag: 'Frag') -> None:
        """
        Store Frag in cache.

        Uses resolve_all() - chain-of-responsibility.
        All backends receive the Frag (layered caching).

        Args:
            frag_id: Frag ID
            frag: Frag instance

        Example:
            # After loading from storage
            frag = await storage.load(42)
            CacheBackendManager.set(42, frag)
            # Now cached in all backends
        """
        repo = cls.repository()

        # Store in all backends
        for backend_id, backend_class in repo.items():
            backend = super(CacheBackendManager, cls).get(backend_id)
            if backend:
                backend.set(frag_id, frag)

    @classmethod
    def invalidate(cls, frag_id: int) -> None:
        """
        Invalidate Frag across all backends.

        Removes Frag from all cache backends to ensure consistency
        after modifications.

        Args:
            frag_id: Frag ID to invalidate

        Example:
            # After Frag modification
            await frag.save()
            CacheBackendManager.invalidate(frag.id)
        """
        repo = cls.repository()

        for backend_id, backend_class in repo.items():
            backend = super(CacheBackendManager, cls).get(backend_id)
            if backend:
                backend.invalidate(frag_id)

    @classmethod
    def clear(cls) -> None:
        """
        Clear all caches.

        Empties all cache backends. Rarely needed - typically only
        for testing or explicit cache flush operations.

        Example:
            CacheBackendManager.clear()
            # All caches now empty
        """
        repo = cls.repository()

        for backend_id, backend_class in repo.items():
            backend = super(CacheBackendManager, cls).get(backend_id)
            if backend:
                backend.clear()

    @classmethod
    def get_stats(cls) -> dict:
        """
        Get cache statistics across all backends.

        Returns:
            Dict of backend_id → stats

        Example:
            stats = CacheBackendManager.get_stats()
            # {
            #     'lru': {
            #         'hits': 1523,
            #         'misses': 234,
            #         'size': 987,
            #         'hit_rate': 86.7
            #     }
            # }
        """
        stats = {}
        repo = cls.repository()

        for backend_id, backend_class in repo.items():
            backend = cls.get(backend_id)
            backend_stats = backend.get_stats()
            stats[backend_id] = backend_stats

        return stats
