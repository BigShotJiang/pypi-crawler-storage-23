"""
Cache invalidation listeners.

Event-based cache invalidation ensures cache consistency
automatically when Frags are modified or deleted.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from winterforge.plugins.decorators import event_listener
from ._manager import CacheBackendManager

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@event_listener(events=['frag.post_save', 'frag.post_delete'])
async def invalidate_cache_on_change(event: 'Frag', source: 'Frag') -> None:
    """
    Invalidate cache when Frag changes.

    Automatically called via event system when Frags are saved
    or deleted. Ensures cache never has stale data.

    Listens for:
    - frag.post_save: After Frag saved to storage
    - frag.post_delete: After Frag deleted from storage

    Args:
        event: Event Frag (contains operation metadata)
        source: Frag that changed (loaded)

    Example:
        # Automatic - no manual invocation needed
        await frag.save()
        # → frag.post_save event emitted
        # → invalidate_cache_on_change() called automatically
        # → CacheBackendManager.invalidate(frag.id)
        # → Cache now consistent

    Note:
        This listener is registered at import time when the
        winterforge.cache.listeners module is imported. It will
        be loaded automatically during application startup if
        the module is imported in conftest.py or similar.
    """
    CacheBackendManager.invalidate(source.id)
