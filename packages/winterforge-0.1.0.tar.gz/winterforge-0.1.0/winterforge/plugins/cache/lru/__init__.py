"""
LRU cache backend.

Provides Least Recently Used (LRU) eviction policy for
in-memory Frag caching.
"""

from __future__ import annotations

from typing import Optional, TYPE_CHECKING
from collections import OrderedDict

from winterforge.plugins.decorators import cache_backend

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


@cache_backend('lru')
class LRUCache:
    """
    LRU (Least Recently Used) cache backend.

    Auto-evicts least recently used Frags when cache is full.
    Default max_size: 10,000 Frags (~20-50MB depending on Frag size).

    Characteristics:
    - O(1) get and set operations
    - Automatic eviction (no manual management)
    - Statistics tracking (hits, misses, hit rate)
    - Configurable max_size

    Example:
        # Default cache (10k Frags)
        cache = LRUCache()

        # Custom size
        cache = LRUCache(max_size=50000)  # 50k Frags

        # Usage
        frag = cache.get(42)  # None (cache miss)
        cache.set(42, my_frag)  # Cache Frag
        frag = cache.get(42)  # my_frag (cache hit)

        # Stats
        stats = cache.get_stats()
        # {'hits': 1523, 'misses': 234, 'hit_rate': 86.7}
    """

    def __init__(self, max_size: int = 10000):
        """
        Initialize LRU cache.

        Args:
            max_size: Maximum number of Frags to cache (default: 10,000)

        Example:
            cache = LRUCache()  # 10k Frags
            cache = LRUCache(max_size=50000)  # 50k Frags
        """
        self.max_size = max_size
        self._cache: OrderedDict[int, 'Frag'] = OrderedDict()
        self._hits = 0
        self._misses = 0

    def get(self, frag_id: int) -> Optional['Frag']:
        """
        Get Frag from cache.

        Updates LRU order (moves to end = most recently used).

        Args:
            frag_id: Frag ID

        Returns:
            Cached Frag or None

        Example:
            frag = cache.get(42)
            if frag:
                # Cache hit - Frag moved to end (MRU)
                self._hits += 1
            else:
                # Cache miss
                self._misses += 1
        """
        if frag_id in self._cache:
            # Move to end (most recently used)
            self._cache.move_to_end(frag_id)
            self._hits += 1
            return self._cache[frag_id]

        self._misses += 1
        return None

    def set(self, frag_id: int, frag: 'Frag') -> None:
        """
        Store Frag in cache.

        Evicts LRU if cache is full. Updates existing entries.

        Args:
            frag_id: Frag ID
            frag: Frag instance

        Example:
            cache.set(42, frag)
            # If cache full, LRU Frag evicted first
        """
        if frag_id in self._cache:
            # Update existing, move to end
            self._cache.move_to_end(frag_id)
        else:
            # Check if full
            if len(self._cache) >= self.max_size:
                # Evict LRU (first item)
                self._cache.popitem(last=False)

        self._cache[frag_id] = frag

    def invalidate(self, frag_id: int) -> None:
        """
        Remove Frag from cache.

        Args:
            frag_id: Frag ID

        Example:
            # After Frag modification
            await frag.save()
            cache.invalidate(frag.id)  # Remove from cache
        """
        if frag_id in self._cache:
            del self._cache[frag_id]

    def clear(self) -> None:
        """
        Clear entire cache.

        Resets cache and statistics.

        Example:
            cache.clear()
            # Cache empty, stats reset
        """
        self._cache.clear()
        self._hits = 0
        self._misses = 0

    def get_stats(self) -> dict:
        """
        Get cache statistics.

        Returns:
            Dict with hits, misses, size, max_size, hit_rate

        Example:
            stats = cache.get_stats()
            # {
            #     'hits': 1523,
            #     'misses': 234,
            #     'size': 987,
            #     'max_size': 10000,
            #     'hit_rate': 86.7
            # }
        """
        total = self._hits + self._misses
        hit_rate = (self._hits / total * 100) if total > 0 else 0

        return {
            'hits': self._hits,
            'misses': self._misses,
            'size': len(self._cache),
            'max_size': self.max_size,
            'hit_rate': round(hit_rate, 2),
        }

    def configure(self, **settings) -> None:
        """
        Update cache configuration.

        Args:
            **settings: Configuration options (e.g., max_size)

        Example:
            cache.configure(max_size=20000)
            # Cache now holds up to 20k Frags
            # Trims cache if new size smaller
        """
        if 'max_size' in settings:
            self.max_size = settings['max_size']

            # Trim cache if new size is smaller
            while len(self._cache) > self.max_size:
                self._cache.popitem(last=False)
