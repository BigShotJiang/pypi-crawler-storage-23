"""
Cache backend protocol.

Defines the interface for cache backends that store Frag
instances for fast retrieval.
"""

from __future__ import annotations

from typing import Protocol, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.base import Frag


class CacheBackend(Protocol):
    """
    Protocol for cache backends.

    Cache backends store Frag instances in memory for fast
    retrieval. All Frags are cached automatically - no opt-out,
    no configuration needed.

    Implementations handle eviction, statistics, and resource
    management. The framework provides LRUCache as default.

    Example:
        class LRUCache:
            def __init__(self, max_size: int = 10000):
                self.max_size = max_size
                self._cache = OrderedDict()

            def get(self, frag_id: int) -> Optional[Frag]:
                if frag_id in self._cache:
                    self._cache.move_to_end(frag_id)
                    return self._cache[frag_id]
                return None

            def set(self, frag_id: int, frag: Frag):
                if len(self._cache) >= self.max_size:
                    self._cache.popitem(last=False)  # Evict LRU
                self._cache[frag_id] = frag

            def invalidate(self, frag_id: int):
                if frag_id in self._cache:
                    del self._cache[frag_id]

            def clear(self):
                self._cache.clear()

            def get_stats(self) -> dict:
                return {'size': len(self._cache)}
    """

    def get(self, frag_id: int) -> Optional['Frag']:
        """
        Get Frag from cache.

        Args:
            frag_id: Frag ID

        Returns:
            Cached Frag or None if not in cache

        Example:
            frag = cache.get(42)
            if frag:
                # Cache hit - use cached Frag
                pass
            else:
                # Cache miss - load from storage
                frag = await storage.load(42)
                cache.set(42, frag)
        """
        ...

    def set(self, frag_id: int, frag: 'Frag') -> None:
        """
        Store Frag in cache.

        Args:
            frag_id: Frag ID
            frag: Frag instance

        Example:
            # After loading from storage
            frag = await storage.load(42)
            cache.set(42, frag)  # Cache for future access
        """
        ...

    def invalidate(self, frag_id: int) -> None:
        """
        Remove Frag from cache.

        Args:
            frag_id: Frag ID

        Example:
            # After Frag modification
            await frag.save()
            cache.invalidate(frag.id)  # Ensure cache consistency
        """
        ...

    def clear(self) -> None:
        """
        Clear entire cache.

        Example:
            cache.clear()  # Empty cache completely
        """
        ...

    def get_stats(self) -> dict:
        """
        Get cache statistics.

        Returns:
            Dict with cache metrics (hits, misses, size, hit_rate, etc.)

        Example:
            stats = cache.get_stats()
            # {'hits': 1523, 'misses': 234, 'size': 987, 'hit_rate': 86.7}
        """
        ...
