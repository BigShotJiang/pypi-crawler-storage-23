"""Counter provider manager for ID counter management."""

from typing import Any, Optional, Dict
from winterforge.plugins._base import PluginManagerBase


class CounterProviderManager(PluginManagerBase):
    """
    Manager for counter provider plugins.

    Counter providers implement different ID generation strategies
    for Frags. The manager uses Repository.resolve() to find the
    appropriate provider based on storage state.

    Plugins register using @counter_provider decorator.

    Example:
        # Get appropriate counter for storage state
        provider = CounterProviderManager.resolve({'storage': backend})
        if provider:
            Frag._id_counter = await provider.get(backend)
        else:
            # No provider matched - log warning
            logger.warning("No counter provider matched storage state")
    """

    @classmethod
    def resolve(cls, context: Dict[str, Any]) -> Optional[Any]:
        """
        Resolve appropriate counter provider based on context.

        Uses first-match resolution pattern: returns the first
        provider where is_match(context) returns True.

        Args:
            context: Context dict with keys like 'storage', 'initialized'

        Returns:
            Matched counter provider instance or None

        Example:
            provider = CounterProviderManager.resolve({'storage': backend})
            if provider:
                counter = await provider.get(backend)
        """
        # Get repository and use resolve pattern
        repo = cls.repository()

        # Find first provider that matches context
        # Note: Providers are stored as classes, need to instantiate
        provider_class = repo.resolve(
            lambda pclass: pclass().is_match(context)
        )

        # Return instance if matched
        return provider_class() if provider_class else None
