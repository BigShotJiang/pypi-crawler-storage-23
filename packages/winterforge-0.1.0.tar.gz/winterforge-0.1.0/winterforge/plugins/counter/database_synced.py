"""Database-synced counter provider."""

import itertools
from typing import Any
from winterforge.plugins.decorators import counter_provider, root


@counter_provider()
@root('database-synced')
class DatabaseSyncedCounter:
    """
    Counter provider that syncs with existing database data.

    Matches when the storage backend contains existing Frags.
    Queries the database for MAX(id) and starts counting from there.

    This prevents ID collisions when loading from an existing database.

    Example:
        # Database has Frags with IDs 1-100
        counter = await provider.get(storage)
        # Returns: count(101)
    """

    def is_match(self, context: dict[str, Any]) -> bool:
        """
        Match if storage backend is a database type.

        This provider syncs with any database backend (SQLite, PostgreSQL, etc.)
        and handles both empty and populated databases by querying MAX(id).

        Args:
            context: Dict with 'storage' key

        Returns:
            True if storage is a database backend with connection
        """
        storage = context.get('storage')
        if not storage:
            return False

        # Match if storage has a database connection
        # This includes SQLite, PostgreSQL, etc.
        return hasattr(storage, '_conn')

    async def get(self, storage: Any) -> itertools.count:
        """
        Get counter synced with database MAX(id).

        Args:
            storage: Storage backend instance

        Returns:
            Counter starting after maximum ID in database
        """
        # Query database for maximum ID
        if not storage._conn:
            return itertools.count(1)

        async with storage._conn.execute(
            "SELECT MAX(id) FROM frags"
        ) as cursor:
            result = await cursor.fetchone()
            max_id = result[0] if result and result[0] is not None else 0

        # Start counter after max ID
        # If no data (max_id = 0), start at 1
        return itertools.count(max_id + 1)
