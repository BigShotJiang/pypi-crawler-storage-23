"""Fresh counter provider for new databases."""

import itertools
from typing import Any
from winterforge.plugins.decorators import counter_provider, root


@counter_provider()
@root('fresh')
class FreshCounter:
    """
    Counter provider for new/empty databases.

    Always matches (fallback provider) and returns a counter starting at 1.

    This is used when:
    - Storage backend is being initialized for the first time
    - Tests are manually managing ID counters
    - No existing data in storage

    Example:
        # New database or test environment
        counter = await provider.get(storage)
        # Returns: count(1)
    """

    def is_match(self, context: dict[str, Any]) -> bool:
        """
        Always match as fallback provider.

        Args:
            context: Context dict (unused)

        Returns:
            Always True
        """
        return True

    async def get(self, storage: Any) -> itertools.count:
        """
        Get fresh counter starting at 1.

        Args:
            storage: Storage backend instance (unused)

        Returns:
            Counter starting at 1
        """
        return itertools.count(1)
