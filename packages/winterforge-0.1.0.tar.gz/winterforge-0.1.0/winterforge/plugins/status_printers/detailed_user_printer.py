"""Detailed user status printer for show commands."""

from typing import Any, Dict

from winterforge.plugins.decorators import status_printer, root


@status_printer()
@root('detailed-user')
class DetailedUserPrinter:
    """
    StatusPrinter for detailed user information display.

    Used by user show commands to display full user details including
    email, roles, and verification status.
    """

    def is_applicable(self, result: Any, metadata: Dict[str, Any]) -> bool:
        """
        Check if this printer applies to the result.

        Applies to single user Frags from 'show' commands.
        """
        # Must be a single Frag (not list)
        if not hasattr(result, 'affinities'):
            return False

        if isinstance(result, (list, tuple)):
            return False

        # Must be a user Frag
        if 'user' not in result.affinities:
            return False

        # Must be from a show/get command
        command_name = metadata.get('name', '')
        return command_name in ('show', 'get', 'find')

    async def format(self, result: Any, metadata: Dict[str, Any], kwargs: Dict[str, Any]) -> str:
        """
        Format user details as multi-line output.

        Args:
            result: User Frag
            metadata: Command metadata
            kwargs: Command arguments

        Returns:
            Formatted multi-line user details
        """
        lines = []

        # Username/title line
        username = getattr(result, 'username', None)
        if username:
            lines.append(f"User: {username}")
        else:
            lines.append(f"User ID: {result.id}")

        # Email
        email = getattr(result, 'email', None)
        if email:
            lines.append(f"Email: {email}")

        # ID
        lines.append(f"ID: {result.id}")

        # Email verification status
        if hasattr(result, 'is_email_verified'):
            verified = result.is_email_verified()
            status = "verified" if verified else "not verified"
            lines.append(f"Status: {status}")

        # Roles
        if hasattr(result, 'get_roles'):
            roles = await result.get_roles()
            if roles:
                role_names = [r.title for r in roles]
                lines.append(f"Roles: {', '.join(role_names)}")

        # Lock status
        if hasattr(result, 'is_locked') and result.is_locked():
            lines.append(f"Account: locked until {result.locked_until.strftime('%Y-%m-%d %H:%M')}")

        return "\n".join(lines)
