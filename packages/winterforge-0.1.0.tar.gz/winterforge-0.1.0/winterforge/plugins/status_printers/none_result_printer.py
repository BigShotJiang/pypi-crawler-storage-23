"""NoneResultPrinter - formats None returns (errors/not found)."""

from typing import Any, Dict

from winterforge.plugins.decorators import status_printer, root


@status_printer()
@root('none-result')
class NoneResultPrinter:
    """
    Formats None returns as error messages.

    Applies to None returns, typically indicating "not found" errors.
    Uses command metadata to generate appropriate error messages.

    Registered as: 'none_result'
    Priority: Highest (checked first)
    """

    def is_applicable(self, result: Any, metadata: Dict[str, Any]) -> bool:
        """
        Check if result is None.

        Args:
            result: Command return value
            metadata: Command metadata

        Returns:
            True if None
        """
        return result is None

    def format(self, result: Any, metadata: Dict[str, Any], kwargs: Dict[str, Any]) -> str:
        """
        Format None as error message.

        Args:
            result: None
            metadata: Command metadata
            kwargs: Command arguments (to extract identity/name)

        Returns:
            Error message string
        """
        command_name = metadata.get('name', 'operation')
        entity = metadata.get('group', 'item')

        # Try to extract what was being looked for
        identity = self._extract_identity(kwargs, metadata)

        if command_name in ('show', 'get', 'find'):
            return f"{entity.capitalize()} not found: {identity}"
        elif command_name == 'delete':
            return f"{entity.capitalize()} not found for deletion: {identity}"
        else:
            return f"{entity.capitalize()} not found"

    def _extract_identity(self, kwargs: Dict[str, Any], metadata: Dict[str, Any]) -> str:
        """
        Extract the identity that was searched for.

        Tries common parameter names: identity, id, name, username, title.
        """
        # Check arguments list first
        arguments = metadata.get('arguments', [])
        if arguments:
            first_arg = arguments[0]
            if first_arg in kwargs:
                return str(kwargs[first_arg])

        # Try common identity fields
        for field in ['identity', 'id', 'name', 'username', 'title', 'slug']:
            if field in kwargs and kwargs[field]:
                return str(kwargs[field])

        return 'unknown'
