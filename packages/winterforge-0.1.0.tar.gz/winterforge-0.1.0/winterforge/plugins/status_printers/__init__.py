"""Built-in StatusPrinter plugins for CLI output formatting."""

# Import printers to trigger registration
# Order matters - first-match wins!
import winterforge.plugins.status_printers.boolean_result_printer   # Priority: 1 (booleans)
import winterforge.plugins.status_printers.none_result_printer      # Priority: 2 (not found)
import winterforge.plugins.status_printers.list_frag_printer        # Priority: 3 (lists)
import winterforge.plugins.status_printers.detailed_user_printer    # Priority: 4 (specific)
import winterforge.plugins.status_printers.single_frag_printer      # Priority: 5 (default)
import winterforge.plugins.status_printers.string_result_printer    # Priority: 6 (primitives)
