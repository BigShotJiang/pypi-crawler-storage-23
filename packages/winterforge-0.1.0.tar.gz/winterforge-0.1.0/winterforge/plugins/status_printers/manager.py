"""StatusPrinterManager - manages CLI output formatting plugins."""

from typing import Optional, Dict, Any

from winterforge.plugins._base import ReorderablePluginManagerBase


class StatusPrinterManager(ReorderablePluginManagerBase):
    """
    Manages StatusPrinter plugins for CLI output formatting.

    StatusPrinters use the strategy pattern with first-match ordering.
    The first printer whose is_applicable() returns True will format the output.

    Built-in printers (in order):
    1. NoneResultPrinter - Handles None returns (errors)
    2. ListFragPrinter - Handles list/collection returns
    3. SingleFragPrinter - Handles single Frag returns (default)

    Example:
        # Register custom printer
        @status_printer('detailed_user')
        class DetailedUserPrinter:
            def is_applicable(self, result, metadata):
                return (hasattr(result, 'affinities') and
                        'user' in result.affinities)

            def format(self, result, metadata, kwargs):
                return f"User: {result.username}\\n  Email: {result.email}"

        # Use in command
        @cli_command('show', printer='detailed_user')
        async def show_user(self, identity: str):
            return self.get(identity)
    """

    @classmethod
    def find_applicable_printer(
        cls,
        result: Any,
        metadata: Dict[str, Any]
    ) -> Optional[Any]:
        """
        Find the first applicable printer for a result.

        Uses first-match ordering - tries each printer in registration order
        until one returns True from is_applicable().

        Args:
            result: Command return value
            metadata: Command metadata

        Returns:
            First applicable printer plugin, or None

        Example:
            printer = StatusPrinterManager.find_applicable_printer(user_frag, metadata)
            if printer:
                message = printer.format(user_frag, metadata, kwargs)
        """
        for printer_id in cls.repository():
            printer = cls.get(printer_id)
            if printer and printer.is_applicable(result, metadata):
                return printer

        return None

    @classmethod
    async def format_result(
        cls,
        result: Any,
        metadata: Dict[str, Any],
        kwargs: Dict[str, Any],
        printer_id: Optional[str] = None
    ) -> Optional[str]:
        """
        Format a command result using the appropriate printer.

        If printer_id is specified, uses that printer directly.
        Otherwise, finds the first applicable printer.

        Args:
            result: Command return value
            metadata: Command metadata
            kwargs: Command arguments
            printer_id: Optional specific printer to use

        Returns:
            Formatted message string, or None if no applicable printer

        Example:
            # Auto-select printer
            message = await StatusPrinterManager.format_result(user, metadata, kwargs)

            # Use specific printer
            message = await StatusPrinterManager.format_result(
                user, metadata, kwargs, printer_id='detailed_user'
            )
        """
        import inspect

        # Use specific printer if requested
        if printer_id:
            printer = cls.get(printer_id)
            if printer:
                format_result = printer.format(result, metadata, kwargs)
                # Check if format() is async
                if inspect.iscoroutine(format_result):
                    return await format_result
                return format_result
            return None

        # Find first applicable printer
        printer = cls.find_applicable_printer(result, metadata)
        if printer:
            format_result = printer.format(result, metadata, kwargs)
            # Check if format() is async
            if inspect.iscoroutine(format_result):
                return await format_result
            return format_result

        return None
