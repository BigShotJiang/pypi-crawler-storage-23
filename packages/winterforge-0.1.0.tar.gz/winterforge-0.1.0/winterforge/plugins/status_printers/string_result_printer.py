"""StringResultPrinter - formats string returns with custom messages."""

from typing import Any, Dict

from winterforge.plugins.decorators import status_printer, root


@status_printer()
@root('string-result')
class StringResultPrinter:
    """
    Formats primitive and dict returns using message templates.

    Applies to string/int/float/dict returns, typically tokens or data objects.
    Uses command metadata (message_success) for custom messages.

    Registered as: 'string_result'
    Priority: Medium (checked after Frag/List printers)
    """

    def is_applicable(self, result: Any, metadata: Dict[str, Any]) -> bool:
        """
        Check if result is a string, int, float, or dict.

        Args:
            result: Command return value
            metadata: Command metadata

        Returns:
            True if result is a primitive type or dict
        """
        return isinstance(result, (str, int, float, dict))

    def format(
        self,
        result: Any,
        metadata: Dict[str, Any],
        kwargs: Dict[str, Any]
    ) -> str:
        """
        Format primitive or dict result using message template.

        Uses message_success from metadata if available,
        otherwise returns the result as-is.

        Args:
            result: Primitive value or dict
            metadata: Command metadata
            kwargs: Command arguments (for token replacement)

        Returns:
            Formatted message string
        """
        # If custom message template provided, use it
        if metadata.get('message_success'):
            return self._apply_tokens(
                metadata['message_success'],
                metadata,
                kwargs,
                result
            )

        # No template - just return result as string
        return str(result)

    def _apply_tokens(
        self,
        template: str,
        metadata: Dict[str, Any],
        kwargs: Dict[str, Any],
        result: Any
    ) -> str:
        """
        Apply token replacement to message template.

        Available tokens:
        - {action}: Command name
        - {entity}: Entity type (from group)
        - {result}: The actual result value
        - {result[key]}: Dict key access (for dict results)
        - Any command argument by name

        Args:
            template: Message template with {token} placeholders
            metadata: Command metadata
            kwargs: Command arguments
            result: The actual result value

        Returns:
            Template with tokens replaced
        """
        replacements = {
            'action': metadata.get('name', 'operation'),
            'entity': metadata.get('group', 'item'),
            'result': result,
            **kwargs  # Include all command arguments
        }

        # If result is dict, add keys for indexed access
        if isinstance(result, dict):
            replacements['result'] = result

        try:
            return template.format(**replacements)
        except KeyError:
            # If token not found, return template as-is
            return template
