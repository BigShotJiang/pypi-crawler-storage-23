"""ListFragPrinter - formats list/collection returns."""

from typing import Any, Dict

from winterforge.plugins.decorators import status_printer, root


@status_printer()
@root('list-frag')
class ListFragPrinter:
    """
    Formats list/collection returns with count and summary.

    Applies to list or tuple returns containing Frags.
    Provides a summary count and basic details.

    Registered as: 'list_frag'
    Priority: Medium (before single_frag)
    """

    def is_applicable(self, result: Any, metadata: Dict[str, Any]) -> bool:
        """
        Check if result is a list/tuple of Frags.

        Args:
            result: Command return value
            metadata: Command metadata

        Returns:
            True if list/tuple that needs formatting
        """
        return isinstance(result, (list, tuple))

    def format(self, result: Any, metadata: Dict[str, Any], kwargs: Dict[str, Any]) -> str:
        """
        Format list/tuple with count and summary.

        Args:
            result: The list/tuple to format
            metadata: Command metadata
            kwargs: Command arguments

        Returns:
            Formatted message string
        """
        count = len(result)
        entity = metadata.get('group', 'item')

        if count == 0:
            return f"No {entity}s found"

        # Build message
        lines = [f"\nFound {count} {entity}(s):\n"]

        # Format each item
        for item in result:
            if hasattr(item, 'affinities'):
                # It's a Frag - show ID and display name
                display_name = self._get_display_name(item)
                lines.append(f"  {item.id:4d}  {display_name}")
            else:
                # Generic item
                lines.append(f"  {item}")

        return "\n".join(lines)

    def _get_display_name(self, frag: Any) -> str:
        """Extract display name from Frag."""
        for field in ['title', 'username', 'name', 'email']:
            if hasattr(frag, field):
                value = getattr(frag, field)
                if value:
                    return str(value)
        return 'untitled'
