"""SingleFragPrinter - formats single Frag returns using token templates."""

from typing import Any, Dict

from winterforge.plugins.decorators import status_printer, root


@status_printer()
@root('single-frag')
class SingleFragPrinter:
    """
    Formats single Frag returns using token templates.

    Applies to any single Frag return that isn't already a CLIResult.
    Uses token replacement with customizable templates.

    Registered as: 'single_frag'
    Priority: Last (catch-all for single Frags)
    """

    def is_applicable(self, result: Any, metadata: Dict[str, Any]) -> bool:
        """
        Check if result is a single Frag (not CLIResult, not list).

        Args:
            result: Command return value
            metadata: Command metadata

        Returns:
            True if single Frag that needs formatting
        """
        # Must be a Frag
        if not hasattr(result, 'affinities'):
            return False

        # Skip if already a CLIResult
        if 'cli_result' in result.affinities:
            return False

        # Skip if it's a list/collection
        if isinstance(result, (list, tuple)):
            return False

        return True

    def format(self, result: Any, metadata: Dict[str, Any], kwargs: Dict[str, Any]) -> str:
        """
        Format single Frag using token templates.

        Args:
            result: The Frag to format
            metadata: Command metadata (contains message_success template)
            kwargs: Command arguments (for token replacement)

        Returns:
            Formatted message string
        """
        command_name = metadata.get('name', 'operation')

        # Get custom template or use default
        message_template = metadata.get('message_success')
        if not message_template:
            message_template = self._get_default_template(command_name)

        # Build tokens
        tokens = self._build_tokens(result, command_name, metadata.get('group', ''), kwargs)

        # Format with tokens (handle missing tokens gracefully)
        try:
            message = message_template.format(**tokens)
        except KeyError:
            # Add missing tokens as empty strings
            import string
            formatter = string.Formatter()
            field_names = [fn for _, fn, _, _ in formatter.parse(message_template) if fn]
            for field_name in field_names:
                if field_name not in tokens:
                    tokens[field_name] = ''
            message = message_template.format(**tokens)

        return message

    def _get_default_template(self, command_name: str) -> str:
        """Get default message template for command type."""
        templates = {
            'create': "✓ {entity} created: {display_name} (ID: {id})",
            'delete': "✓ {entity} deleted: {display_name}",
            'update': "✓ {entity} updated: {display_name} (ID: {id})",
            'edit': "✓ {entity} edited: {display_name} (ID: {id})",
            'show': "{entity}: {display_name} (ID: {id})",
        }
        return templates.get(command_name, "✓ {action} complete (ID: {id})")

    def _build_tokens(self, frag: Any, command_name: str, group_name: str, kwargs: Dict[str, Any]) -> Dict[str, str]:
        """Build token dictionary for message formatting."""
        # Extract entity type
        entity_type = group_name or (frag.affinities[0] if frag.affinities else 'item')

        # Base tokens
        tokens = {
            'action': command_name,
            'entity': entity_type.capitalize(),
            'display_name': self._get_display_name(frag),
            'id': str(frag.id),
        }

        # Add kwargs as tokens
        for key, value in kwargs.items():
            if value is None:
                tokens[key] = ''
                tokens[f'{key}_count'] = '0'
                tokens[f'{key}_info'] = ''
            elif isinstance(value, (str, int, float, bool)):
                tokens[key] = str(value)
            elif isinstance(value, (list, tuple)):
                if value:
                    tokens[key] = ', '.join(str(v) for v in value)
                    tokens[f'{key}_count'] = str(len(value))
                    tokens[f'{key}_info'] = f"\n  Assigned {key}s: {', '.join(str(v) for v in value)}"
                else:
                    tokens[key] = ''
                    tokens[f'{key}_count'] = '0'
                    tokens[f'{key}_info'] = ''

        return tokens

    def _get_display_name(self, frag: Any) -> str:
        """Extract display name from Frag."""
        for field in ['title', 'username', 'name', 'email']:
            if hasattr(frag, field):
                value = getattr(frag, field)
                if value:
                    return str(value)
        return 'untitled'
