"""BooleanResultPrinter - formats boolean returns (success/failure)."""

from typing import Any, Dict

from winterforge.plugins.decorators import status_printer, root


@status_printer()
@root('boolean-result')
class BooleanResultPrinter:
    """
    Formats boolean returns as success/failure messages.

    Applies to True/False returns, typically indicating operation success.
    Uses command metadata (message_success/message_failure) for custom messages.

    Registered as: 'boolean_result'
    Priority: High (checked early)
    """

    def is_applicable(self, result: Any, metadata: Dict[str, Any]) -> bool:
        """
        Check if result is a boolean.

        Args:
            result: Command return value
            metadata: Command metadata

        Returns:
            True if boolean
        """
        return isinstance(result, bool)

    def format(
        self,
        result: Any,
        metadata: Dict[str, Any],
        kwargs: Dict[str, Any]
    ) -> str:
        """
        Format boolean as success/failure message.

        Uses message_success/message_failure from metadata if available,
        otherwise generates generic messages based on command context.

        Args:
            result: Boolean value
            metadata: Command metadata
            kwargs: Command arguments (for token replacement)

        Returns:
            Success or failure message string
        """
        if result:
            # Success case
            if metadata.get('message_success'):
                return self._apply_tokens(
                    metadata['message_success'],
                    metadata,
                    kwargs
                )

            # Generic success message
            command_name = metadata.get('name', 'operation')
            entity = metadata.get('group', 'item')
            return f"✓ {entity.capitalize()} {command_name} completed"
        else:
            # Failure case
            if metadata.get('message_failure'):
                return self._apply_tokens(
                    metadata['message_failure'],
                    metadata,
                    kwargs
                )

            # Generic failure message
            command_name = metadata.get('name', 'operation')
            entity = metadata.get('group', 'item')
            identity = self._extract_identity(kwargs, metadata)
            return f"✗ {entity.capitalize()} {command_name} failed: {identity}"

    def _extract_identity(
        self,
        kwargs: Dict[str, Any],
        metadata: Dict[str, Any]
    ) -> str:
        """
        Extract the identity from command arguments.

        Tries common parameter names: identity, id, name, username, title.
        """
        # Check arguments list first
        arguments = metadata.get('arguments', [])
        if arguments:
            first_arg = arguments[0]
            if first_arg in kwargs:
                return str(kwargs[first_arg])

        # Try common identity fields
        for field in ['identity', 'id', 'name', 'username', 'title', 'slug']:
            if field in kwargs and kwargs[field]:
                return str(kwargs[field])

        return 'unknown'

    def _apply_tokens(
        self,
        template: str,
        metadata: Dict[str, Any],
        kwargs: Dict[str, Any]
    ) -> str:
        """
        Apply token replacement to message template.

        Available tokens:
        - {action}: Command name
        - {entity}: Entity type (from group)
        - Any command argument by name

        Args:
            template: Message template with {token} placeholders
            metadata: Command metadata
            kwargs: Command arguments

        Returns:
            Template with tokens replaced
        """
        replacements = {
            'action': metadata.get('name', 'operation'),
            'entity': metadata.get('group', 'item'),
            **kwargs  # Include all command arguments
        }

        try:
            return template.format(**replacements)
        except KeyError:
            # If token not found, return template as-is
            return template
