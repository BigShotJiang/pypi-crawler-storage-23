"""Endpoint generator - creates FastAPI routes from decorated methods.

Auto-generates REST endpoints from WinterForge CLI commands.
"""
from typing import Dict, Any
from fastapi import APIRouter, Request
from winterforge.plugins.cli._manager import CLICommandManager
from winterforge_dx_tools.utils.http_method_detector import (
    HTTPMethodDetector,
)
from winterforge_dx_tools.server.request_handler import RequestHandler
from winterforge_dx_tools.server.response_handler import ResponseHandler
from winterforge_dx_tools.utils.introspection import MethodIntrospector


class EndpointGenerator:
    """Generates FastAPI endpoints from CLI commands."""

    @classmethod
    def generate_router(cls, root_name: str) -> APIRouter:
        """Generate FastAPI router for root namespace.

        Args:
            root_name: Root namespace (e.g., 'user')

        Returns:
            FastAPI router with all endpoints
        """
        router = APIRouter(prefix=f'/api/{root_name}', tags=[root_name])

        # Get commands for this root
        commands = CLICommandManager.get_commands_for_group(root_name)

        for command in commands:
            cls._register_endpoint(router, root_name, command)

        return router

    @classmethod
    def _register_endpoint(
        cls, router: APIRouter, root_name: str, command: Dict[str, Any]
    ) -> None:
        """Register single endpoint on router.

        Args:
            router: FastAPI router
            root_name: Root namespace
            command: Command metadata
        """
        method_name = command['name']
        callable_obj = command['callable']

        # If callable is an unbound method, instantiate the class
        import inspect

        if not inspect.ismethod(callable_obj) and hasattr(
            callable_obj, '__self__'
        ):
            # It's a classmethod or static, use as-is
            pass
        elif not inspect.ismethod(callable_obj):
            # Unbound instance method - need to create instance
            # Get the class from the callable
            if '.' in callable_obj.__qualname__:
                class_name = callable_obj.__qualname__.rsplit('.', 1)[0]
                # Find the class in sys.modules
                import sys

                for module in sys.modules.values():
                    if module and hasattr(module, class_name.split('.')[-1]):
                        parent_cls = getattr(module, class_name.split('.')[-1])
                        if inspect.isclass(parent_cls):
                            # Create instance and bind method
                            instance = parent_cls()
                            method_name_attr = callable_obj.__name__
                            callable_obj = getattr(
                                instance,
                                method_name_attr
                            )
                            break

        # Get parameters
        params = MethodIntrospector.get_parameters(callable_obj)
        has_params = len(params) > 0

        # Detect HTTP method
        http_method = HTTPMethodDetector.detect(method_name, has_params)

        # Build path
        path = f'/{method_name}'

        # Get docstring for summary
        summary = MethodIntrospector.get_docstring_summary(callable_obj)

        # Create endpoint handler
        async def endpoint_handler(request: Request):
            try:
                # Extract query parameters
                query_params = dict(request.query_params)

                # Extract path parameters
                # (would be in path, but we don't use them)
                path_params = None

                # Extract body if needed
                body = None
                if HTTPMethodDetector.requires_body(http_method):
                    body_bytes = await request.body()
                    if body_bytes:
                        body = await request.json()

                # Execute method
                result = await RequestHandler.execute(
                    method=callable_obj,
                    path_params=path_params,
                    query_params=query_params,
                    body=body,
                )

                # Return response
                return ResponseHandler.create_response(result)

            except ValueError as e:
                # Bad request (missing parameters, etc.)
                return ResponseHandler.error_response(e, status_code=400)
            except Exception as e:
                # Internal server error
                return ResponseHandler.error_response(e, status_code=500)

        # Set summary/description for OpenAPI docs
        endpoint_handler.__doc__ = summary or f"{method_name} endpoint"

        # Generate unique operation ID
        operation_id = f"{root_name}_{method_name}"

        # Register with router - disable request validation
        # since we handle everything manually
        route_method = getattr(router, http_method.lower())
        route_method(
            path,
            summary=summary,
            operation_id=operation_id,
            include_in_schema=False,  # Disable FastAPI validation
        )(endpoint_handler)
