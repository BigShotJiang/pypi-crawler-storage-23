"""Response handler - converts method results to HTTP responses.

Handles serialization and status code determination.
"""
from typing import Any, Dict, Union, List
from fastapi.responses import JSONResponse
from pydantic import BaseModel


class ResponseHandler:
    """Handles conversion of method results to HTTP responses."""

    @classmethod
    def serialize(
        cls, result: Any
    ) -> Union[Dict, List, str, int, float, bool, None]:
        """Serialize result to JSON-compatible format.

        Args:
            result: Method execution result

        Returns:
            JSON-serializable value
        """
        # None
        if result is None:
            return None

        # Basic types
        if isinstance(result, (str, int, float, bool)):
            return result

        # Dict
        if isinstance(result, dict):
            return {k: cls.serialize(v) for k, v in result.items()}

        # List/tuple
        if isinstance(result, (list, tuple)):
            return [cls.serialize(item) for item in result]

        # Pydantic model
        if isinstance(result, BaseModel):
            return result.model_dump()

        # Frag (WinterForge)
        if hasattr(result, 'to_dict'):
            return result.to_dict()

        # Object with __dict__
        if hasattr(result, '__dict__'):
            return cls.serialize(result.__dict__)

        # Fallback: convert to string
        return str(result)

    @classmethod
    def create_response(
        cls, result: Any, status_code: int = 200
    ) -> JSONResponse:
        """Create HTTP response from result.

        Args:
            result: Method execution result
            status_code: HTTP status code

        Returns:
            FastAPI JSON response
        """
        serialized = cls.serialize(result)

        return JSONResponse(content=serialized, status_code=status_code)

    @classmethod
    def error_response(
        cls, error: Exception, status_code: int = 500
    ) -> JSONResponse:
        """Create error response.

        Args:
            error: Exception that occurred
            status_code: HTTP status code

        Returns:
            Error response
        """
        return JSONResponse(
            content={'error': type(error).__name__, 'message': str(error)},
            status_code=status_code,
        )
