"""FastAPI application factory.

Creates FastAPI app with all WinterForge endpoints.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from winterforge.plugins.cli._manager import CLICommandManager
from winterforge_dx_tools.server.endpoint_generator import (
    EndpointGenerator,
)
from winterforge_dx_tools.openapi.generator import OpenAPIGenerator


def create_app(enable_graphql: bool = False) -> FastAPI:
    """Create FastAPI application with all WinterForge endpoints.

    Args:
        enable_graphql: Whether to enable GraphQL endpoint

    Returns:
        Configured FastAPI app
    """
    app = FastAPI(
        title="WinterForge API",
        description="Auto-generated REST API from WinterForge commands",
        version="1.0.0",
    )

    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Get all registered command groups
    groups = CLICommandManager.get_all_groups()

    # Generate router for each group
    for root_name in groups.keys():
        router = EndpointGenerator.generate_router(root_name)
        app.include_router(router)

    # Add OpenAPI spec endpoint
    @app.get("/openapi.json")
    async def get_openapi_spec():
        """Get complete OpenAPI specification."""
        # Combine specs from all roots
        combined_spec = {
            'openapi': '3.1.0',
            'info': {'title': 'WinterForge API', 'version': '1.0.0'},
            'paths': {},
        }

        for root_name in groups.keys():
            spec = OpenAPIGenerator.generate_spec(root_name)
            combined_spec['paths'].update(spec['paths'])

        return combined_spec

    # Add GraphQL endpoint if enabled
    if enable_graphql:
        from winterforge_dx_tools.graphql.server import (
            create_graphql_router,
        )

        graphql_router = create_graphql_router()
        app.include_router(graphql_router)

    # Health check endpoint
    @app.get("/health")
    async def health():
        """Health check endpoint."""
        return {"status": "healthy"}

    return app
