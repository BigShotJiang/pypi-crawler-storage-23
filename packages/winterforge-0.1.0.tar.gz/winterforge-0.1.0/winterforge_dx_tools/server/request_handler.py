"""Request handler - converts HTTP requests to method calls.

Bridges FastAPI request context to WinterForge method execution.
"""
from typing import Any, Dict, Callable, Optional
import inspect


class RequestHandler:
    """Handles conversion of HTTP requests to method calls."""

    @classmethod
    async def execute(
        cls,
        method: Callable,
        path_params: Optional[Dict[str, Any]] = None,
        query_params: Optional[Dict[str, Any]] = None,
        body: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Execute method with request parameters.

        Args:
            method: Method to execute
            path_params: URL path parameters
            query_params: URL query parameters
            body: Request body

        Returns:
            Method execution result
        """
        # Combine all parameters
        params = {}

        if path_params:
            params.update(path_params)

        if query_params:
            params.update(query_params)

        if body:
            params.update(body)

        # Get method signature and type hints
        sig = inspect.signature(method)

        # Try to get type hints for conversion
        try:
            from typing import get_type_hints

            type_hints = get_type_hints(method)
        except Exception:
            type_hints = {}

        # Build kwargs matching signature with type conversion
        kwargs = {}
        for param_name, param in sig.parameters.items():
            if param_name in ('self', 'cls'):
                continue

            if param_name in params:
                value = params[param_name]

                # Convert type if we have type hint and value is not
                # already correct type
                if (
                    param_name in type_hints
                    and not isinstance(value, type_hints[param_name])
                ):
                    param_type = type_hints[param_name]
                    # Handle basic type conversions
                    if param_type is int:
                        value = int(value)
                    elif param_type is float:
                        value = float(value)
                    elif param_type is bool:
                        if isinstance(value, str):
                            value = value.lower() in ('true', '1', 'yes')
                        else:
                            value = bool(value)
                    elif param_type is str:
                        value = str(value)

                kwargs[param_name] = value
            elif param.default != inspect.Parameter.empty:
                # Has default, optional
                pass
            else:
                # Required parameter missing
                raise ValueError(
                    f"Missing required parameter: {param_name}"
                )

        # Execute method
        if inspect.iscoroutinefunction(method):
            result = await method(**kwargs)
        else:
            result = method(**kwargs)

        return result
