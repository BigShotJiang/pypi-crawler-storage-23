"""REST API server components.

Provides FastAPI-based REST endpoint generation from WinterForge commands.
"""
from winterforge_dx_tools.server.app import create_app

__all__ = ['create_app']
