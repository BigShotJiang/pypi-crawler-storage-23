"""Python type to GraphQL type mapping.

Converts Python type hints to GraphQL type descriptions.
Returns simple type descriptions that can be converted to actual
GraphQL types by the schema generator.
"""
from typing import Any, Optional, Union, get_origin, get_args, Dict


class GraphQLTypeMapper:
    """Maps Python types to GraphQL type descriptions."""

    @classmethod
    def map_type(cls, type_hint: Any) -> str:
        """Map Python type hint to GraphQL type string.

        Args:
            type_hint: Python type annotation

        Returns:
            GraphQL type string (e.g., 'String', 'Int', '[String!]')
        """
        # Handle None
        if type_hint is None or type_hint is type(None):
            return 'Boolean'  # Fallback

        # Basic types
        if type_hint is str:
            return 'String'
        if type_hint is int:
            return 'Int'
        if type_hint is float:
            return 'Float'
        if type_hint is bool:
            return 'Boolean'

        # Get type origin for generic types
        origin = get_origin(type_hint)

        # Handle Optional[T] (Union[T, None])
        if origin is Union:
            args = get_args(type_hint)
            # Check if this is Optional (Union with None)
            if type(None) in args:
                # Get non-None type
                non_none_types = [a for a in args if a is not type(None)]
                if non_none_types:
                    inner_type = cls.map_type(non_none_types[0])
                    return inner_type  # Optional types are not marked with !
            # Non-Optional union - use first type
            if args:
                return cls.map_type(args[0])

        # Handle List[T]
        if origin is list:
            args = get_args(type_hint)
            if args:
                inner_type = cls.map_type(args[0])
                return f'[{inner_type}!]'
            return '[String!]'

        # Handle Dict - map to JSON scalar
        if origin is dict:
            return 'JSON'

        # Handle Pydantic models - return the model name
        from pydantic import BaseModel
        if isinstance(type_hint, type) and issubclass(
            type_hint, BaseModel
        ):
            return type_hint.__name__

        # Handle Frag
        if (
            hasattr(type_hint, '__name__')
            and 'Frag' in type_hint.__name__
        ):
            return 'Frag'

        # Object types with __name__
        if hasattr(type_hint, '__name__'):
            return type_hint.__name__

        # Fallback
        return 'String'

    @classmethod
    def get_pydantic_fields(cls, model: type) -> Dict[str, str]:
        """Extract field names and types from Pydantic model.

        Args:
            model: Pydantic model class

        Returns:
            Dict mapping field names to GraphQL type strings
        """
        from pydantic import BaseModel
        if not (
            isinstance(model, type) and issubclass(model, BaseModel)
        ):
            return {}

        fields = {}
        for field_name, field_info in model.model_fields.items():
            field_type = cls.map_type(field_info.annotation)
            fields[field_name] = field_type

        return fields
