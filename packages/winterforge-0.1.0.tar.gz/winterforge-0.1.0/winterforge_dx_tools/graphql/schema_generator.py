"""GraphQL schema generator from CLI commands.

Generates GraphQL Schema Definition Language (SDL) from WinterForge
CLI command registrations.
"""
from typing import List, Dict, Any
from winterforge.plugins.cli._manager import CLICommandManager
from winterforge_dx_tools.graphql.type_mapper import GraphQLTypeMapper
from winterforge_dx_tools.utils.http_method_detector import (
    HTTPMethodDetector,
)
from winterforge_dx_tools.utils.introspection import MethodIntrospector


class GraphQLSchemaGenerator:
    """Generates GraphQL schemas from CLI commands."""

    @classmethod
    def generate_schema(cls, root_name: str) -> str:
        """Generate GraphQL schema SDL for root namespace.

        Args:
            root_name: Root namespace (e.g., 'user')

        Returns:
            GraphQL schema definition language (SDL)
        """
        commands = CLICommandManager.get_commands_for_group(root_name)

        # Separate queries and mutations
        queries = []
        mutations = []

        for command in commands:
            method_name = command['name']
            callable_obj = command['callable']

            # Detect if query or mutation
            params = MethodIntrospector.get_parameters(callable_obj)
            has_params = len(params) > 0
            http_method = HTTPMethodDetector.detect(
                method_name, has_params
            )

            if http_method == 'GET':
                queries.append(cls._generate_field(command, root_name))
            else:
                mutations.append(
                    cls._generate_field(command, root_name)
                )

        # Build SDL
        sdl_parts = []

        if queries:
            query_fields = '\n  '.join(queries)
            sdl_parts.append(f"type Query {{\n  {query_fields}\n}}")

        if mutations:
            mutation_fields = '\n  '.join(mutations)
            sdl_parts.append(
                f"type Mutation {{\n  {mutation_fields}\n}}"
            )

        return '\n\n'.join(sdl_parts)

    @classmethod
    def _generate_field(
        cls, command: Dict[str, Any], root_name: str
    ) -> str:
        """Generate GraphQL field SDL for command.

        Args:
            command: Command metadata
            root_name: Root namespace

        Returns:
            GraphQL field definition
        """
        method_name = command['name']
        callable_obj = command['callable']

        # Get parameters
        params = MethodIntrospector.get_parameters(callable_obj)
        return_type = MethodIntrospector.get_return_type(callable_obj)
        docstring = MethodIntrospector.get_docstring_summary(
            callable_obj
        )

        # Build parameter list
        param_defs = []
        for param in params:
            param_name = param['name']
            param_type_str = GraphQLTypeMapper.map_type(
                param['type_hint']
            )
            required = '!' if param['required'] else ''
            param_defs.append(f"{param_name}: {param_type_str}{required}")

        params_str = ', '.join(param_defs) if param_defs else ''

        # Build return type
        return_type_str = GraphQLTypeMapper.map_type(return_type)

        # Build field with description
        field = f"{method_name}({params_str}): {return_type_str}"

        if docstring:
            field = f'"""{docstring}"""\n  {field}'

        return field
