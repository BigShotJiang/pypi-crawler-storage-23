"""GraphQL schema and resolver generation."""
