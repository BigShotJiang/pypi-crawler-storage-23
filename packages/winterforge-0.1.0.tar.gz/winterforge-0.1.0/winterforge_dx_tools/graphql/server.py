"""GraphQL server integration with Strawberry.

Creates a GraphQL router with auto-generated schema from CLI commands.

NOTE: This module requires strawberry-graphql to be properly installed.
Due to pytest/strawberry import compatibility issues in some environments,
this feature may not work in all testing scenarios.
"""
from typing import Optional
from winterforge.plugins.cli._manager import CLICommandManager
from winterforge_dx_tools.graphql.resolver_factory import ResolverFactory
from winterforge_dx_tools.utils.http_method_detector import (
    HTTPMethodDetector,
)
from winterforge_dx_tools.utils.introspection import MethodIntrospector

# Check if strawberry is available
try:
    import strawberry
    from strawberry.fastapi import GraphQLRouter

    STRAWBERRY_AVAILABLE = True
except ImportError:
    STRAWBERRY_AVAILABLE = False
    strawberry = None
    GraphQLRouter = None


def create_graphql_router():
    """Create GraphQL router with all WinterForge commands.

    Returns:
        Strawberry GraphQL router for FastAPI

    Raises:
        RuntimeError: If strawberry is not available
    """
    if not STRAWBERRY_AVAILABLE:
        raise RuntimeError(
            "Strawberry GraphQL is not available. "
            "Install with: pip install strawberry-graphql[fastapi]"
        )

    # Get all command groups
    groups = CLICommandManager.get_all_groups()

    # Collect resolvers by type
    query_resolvers = {}
    mutation_resolvers = {}

    for root_name in groups.keys():
        commands = CLICommandManager.get_commands_for_group(root_name)
        resolvers = ResolverFactory.create_resolvers(root_name)

        for command in commands:
            method_name = command['name']
            callable_obj = command['callable']

            if method_name not in resolvers:
                continue

            # Determine if query or mutation
            params = MethodIntrospector.get_parameters(callable_obj)
            has_params = len(params) > 0
            http_method = HTTPMethodDetector.detect(
                method_name, has_params
            )

            if http_method == 'GET':
                query_resolvers[method_name] = resolvers[method_name]
            else:
                mutation_resolvers[method_name] = resolvers[
                    method_name
                ]

    # Create Query type
    if query_resolvers:
        query_fields = {}
        for name, resolver in query_resolvers.items():
            # Wrap resolver as strawberry field
            query_fields[name] = strawberry.field(resolver=resolver)

        Query = type('Query', (), query_fields)
        Query = strawberry.type(Query)
    else:
        # Empty query type (required by GraphQL spec)
        @strawberry.type
        class Query:
            @strawberry.field
            def _placeholder(self) -> str:
                return "No queries available"

    # Create Mutation type
    if mutation_resolvers:
        mutation_fields = {}
        for name, resolver in mutation_resolvers.items():
            mutation_fields[name] = strawberry.field(resolver=resolver)

        Mutation = type('Mutation', (), mutation_fields)
        Mutation = strawberry.type(Mutation)
    else:
        Mutation = None

    # Create schema
    schema = strawberry.Schema(query=Query, mutation=Mutation)

    # Create router with GraphiQL enabled
    return GraphQLRouter(schema, graphiql=True, path="/graphql")
