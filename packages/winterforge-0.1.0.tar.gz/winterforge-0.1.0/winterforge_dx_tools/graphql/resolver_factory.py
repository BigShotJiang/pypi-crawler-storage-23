"""GraphQL resolver factory from CLI commands.

Creates executable GraphQL resolvers from WinterForge CLI command methods.
"""
from typing import Dict, Any, Callable
from winterforge.plugins.cli._manager import CLICommandManager
from winterforge_dx_tools.server.request_handler import RequestHandler


class ResolverFactory:
    """Creates GraphQL resolvers from CLI commands."""

    @classmethod
    def create_resolvers(cls, root_name: str) -> Dict[str, Callable]:
        """Create resolvers for all commands in root namespace.

        Args:
            root_name: Root namespace (e.g., 'user')

        Returns:
            Dict mapping method names to resolver functions
        """
        commands = CLICommandManager.get_commands_for_group(root_name)

        resolvers = {}
        for command in commands:
            method_name = command['name']
            resolver = cls._create_resolver(command)
            resolvers[method_name] = resolver

        return resolvers

    @classmethod
    def _create_resolver(cls, command: Dict[str, Any]) -> Callable:
        """Create resolver function for command.

        Args:
            command: Command metadata from CLI manager

        Returns:
            Async resolver function
        """
        callable_obj = command['callable']

        # Instantiate class if needed (same pattern as REST endpoints)
        import inspect

        if not inspect.ismethod(callable_obj):
            if '.' in callable_obj.__qualname__:
                class_name = callable_obj.__qualname__.rsplit('.', 1)[0]
                import sys

                for module in sys.modules.values():
                    if (
                        module
                        and hasattr(module, class_name.split('.')[-1])
                    ):
                        parent_cls = getattr(
                            module, class_name.split('.')[-1]
                        )
                        if inspect.isclass(parent_cls):
                            instance = parent_cls()
                            callable_obj = getattr(
                                instance, callable_obj.__name__
                            )
                            break

        # Create resolver wrapper
        async def resolver(**kwargs):
            """GraphQL resolver wrapper.

            Executes the CLI command method with GraphQL arguments.
            """
            # Execute using RequestHandler (same as REST)
            result = await RequestHandler.execute(
                method=callable_obj, body=kwargs
            )
            return result

        return resolver

    @classmethod
    def create_all_resolvers(cls) -> Dict[str, Dict[str, Callable]]:
        """Create resolvers for all registered command groups.

        Returns:
            Dict mapping root names to resolver dicts
        """
        all_groups = CLICommandManager.get_all_groups()
        all_resolvers = {}

        for root_name in all_groups.keys():
            resolvers = cls.create_resolvers(root_name)
            if resolvers:
                all_resolvers[root_name] = resolvers

        return all_resolvers
