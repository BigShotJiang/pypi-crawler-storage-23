"""
FormatterBuilder - fluent API for composing CLI output.

Uses ApiBuilderMixin to auto-generate methods from element plugins.

Example:
    output = (FormatterBuilder('prettier')
        .panel(title='Status', content='System ready')
        .table(data=[['Name', 'Alice'], ['Age', '30']])
        .progress(label='Loading', total=100)
        .render()
    )
"""

from typing import Any, TYPE_CHECKING
from winterforge.frags.traits.api_builder import ApiBuilderMixin

# Import and register element plugins before FormatterBuilder is defined
# This ensures __init_subclass__ can discover and generate methods
from winterforge_dx_tools.elements.manager import ElementManager
from winterforge_dx_tools.elements.builder_panel import PanelElement
from winterforge_dx_tools.elements.builder_table import TableElement
from winterforge_dx_tools.elements.builder_progress import ProgressElement
from winterforge_dx_tools.elements.builder_tree import TreeElement

# Register plugins with ElementManager
ElementManager.register('panel', PanelElement)
ElementManager.register('table', TableElement)
ElementManager.register('progress', ProgressElement)
ElementManager.register('tree', TreeElement)

if TYPE_CHECKING:
    pass


class FormatterBuilder(ApiBuilderMixin):
    """
    Builder for CLI formatting output.

    Auto-generates methods from element plugins scoped to formatter.

    Methods auto-generated from plugins in 'winterforge.dx.elements'
    scoped to the specified formatter.

    Configuration:
        _api_builder_manager: 'winterforge.dx.elements'
        _api_builder_collection: '_elements'
        _api_builder_scope: formatter_id (e.g., 'prettier')

    Usage:
        builder = FormatterBuilder('prettier')
        output = builder.panel(title='Hello').table(data=rows).render()
    """

    _api_builder_manager = 'winterforge.dx.elements'
    _api_builder_collection = '_elements'

    def __init__(
        self,
        formatter_id: str = 'prettier',
        elements: list[Any] = None
    ):
        """
        Initialize formatter builder.

        Args:
            formatter_id: Formatter to use (e.g., 'prettier')
            elements: List of element plugin instances
        """
        self.formatter_id = formatter_id
        self._elements = elements or []

        # Set scope for ApiBuilderMixin
        self.__class__._api_builder_scope = formatter_id

    def render(self) -> str:
        """
        Render all elements to output string.

        Accumulates output from all elements in stack.

        Returns:
            Rendered output string

        Example:
            output = (FormatterBuilder('prettier')
                .panel(title='Status', content='Ready')
                .table(data=[['A', 'B']])
                .render()
            )
            print(output)
        """
        # Accumulate output from all elements
        output = ''
        for element in self._elements:
            output += element.render()
        return output

    async def render_async(self) -> str:
        """
        Async version of render for async element rendering.

        Returns:
            Rendered output string

        Example:
            output = await builder.render_async()
        """
        result = ''
        for element in self._elements:
            if hasattr(element, 'render_async'):
                result += await element.render_async()
            else:
                result += element.render()
        return result

    def clear(self) -> 'FormatterBuilder':
        """
        Clear all elements and return new empty builder.

        Returns:
            New FormatterBuilder with no elements

        Example:
            builder = builder.panel(...).table(...)
            builder = builder.clear()  # Fresh start
        """
        return FormatterBuilder(
            formatter_id=self.formatter_id,
            elements=[]
        )

    def elements(self) -> list[Any]:
        """
        Get current element stack.

        Returns:
            List of element plugin instances

        Example:
            for element in builder.elements():
                print(type(element).__name__)
        """
        return list(self._elements)

    def __repr__(self):
        """String representation for debugging."""
        element_names = [
            type(e).__name__ for e in self._elements
        ]
        return (
            f"FormatterBuilder(formatter={self.formatter_id!r}, "
            f"elements={element_names})"
        )
