"""
Developer tools CLI commands.

Integrates with WinterForge CLI via @root('dx').
"""
from winterforge.plugins.decorators import (
    root,
    decorator_provider,
    CLICommandConfig
)
import yaml
import json


@root('dx')
class DXCommands:
    """Developer experience tools."""

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ OpenAPI spec generated for {root_name}"
        )
    )
    async def openapi(
        self,
        root_name: str,
        output: str = None,
        format: str = 'yaml',
        title: str = None,
        version: str = '1.0.0'
    ) -> dict:
        """
        Generate OpenAPI specification for root namespace.

        Args:
            root_name: Root namespace (e.g., 'user')
            output: Output file path (default: stdout)
            format: Output format (yaml or json)
            title: API title
            version: API version
        """
        from winterforge_dx_tools.openapi import OpenAPIGenerator

        # Generate spec
        spec = OpenAPIGenerator.generate_spec(
            root_name=root_name,
            title=title,
            version=version
        )

        # Format output
        if format == 'yaml':
            output_text = yaml.dump(
                spec,
                sort_keys=False,
                default_flow_style=False
            )
        elif format == 'json':
            output_text = json.dumps(spec, indent=2)
        else:
            raise ValueError(f"Unsupported format: {format}")

        # Write to file or stdout
        if output:
            with open(output, 'w') as f:
                f.write(output_text)
        else:
            print(output_text)

        return {
            'root': root_name,
            'format': format,
            'output': output or 'stdout'
        }

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ Server started on {host}:{port}"
        )
    )
    async def serve(
        self,
        host: str = '127.0.0.1',
        port: int = 8000,
        reload: bool = False,
        workers: int = 1,
        graphql: bool = False,
    ) -> dict:
        """Start development server with auto-generated endpoints.

        Args:
            host: Host to bind to
            port: Port to bind to
            reload: Enable auto-reload on code changes
            workers: Number of worker processes
            graphql: Enable GraphQL endpoint
        """
        import uvicorn
        from winterforge_dx_tools.server.app import create_app
        from winterforge.plugins.cli._manager import CLICommandManager

        # Create app with optional GraphQL
        app = create_app(enable_graphql=graphql)

        # Print available endpoints
        print(f"\n🚀 WinterForge Development Server")
        print(f"   URL: http://{host}:{port}")
        print(f"   Docs: http://{host}:{port}/docs")
        print(f"   ReDoc: http://{host}:{port}/redoc")
        print(f"   OpenAPI: http://{host}:{port}/openapi.json")

        if graphql:
            print(f"   GraphQL: http://{host}:{port}/graphql")
            print(
                f"   GraphiQL: http://{host}:{port}/graphql (browser)"
            )

        print(f"\n📋 Available endpoints:")

        groups = CLICommandManager.get_all_groups()

        for root_name in sorted(groups.keys()):
            commands = CLICommandManager.get_commands_for_group(root_name)
            if commands:
                print(f"\n   /api/{root_name}:")
                for cmd in commands:
                    print(f"     - {cmd['name']}")

        print(f"\n✨ Server starting...\n")

        # Run server
        uvicorn.run(
            app, host=host, port=port, reload=reload, workers=workers
        )

        return {'host': host, 'port': port}

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ GraphQL schema generated for {root_name}"
        )
    )
    async def graphql(
        self,
        root_name: str,
        output: str = None,
    ) -> dict:
        """Generate GraphQL schema for root namespace.

        Args:
            root_name: Root namespace (e.g., 'user')
            output: Output file path (default: stdout)
        """
        from winterforge_dx_tools.graphql.schema_generator import (
            GraphQLSchemaGenerator,
        )

        # Generate schema
        schema_sdl = GraphQLSchemaGenerator.generate_schema(root_name)

        # Write to file or stdout
        if output:
            with open(output, 'w') as f:
                f.write(schema_sdl)
        else:
            print(schema_sdl)

        return {'root': root_name, 'output': output or 'stdout'}

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ Generated {component_type}: {output}"
        )
    )
    async def generate(
        self,
        component_type: str,
        name: str,
        output_dir: str = ".",
        traits: str = None,
    ) -> dict:
        """Generate WinterForge component boilerplate.

        Args:
            component_type: Type (frag, registry, trait)
            name: Component name
            output_dir: Output directory
            traits: Comma-separated trait list (for frags)
        """
        from winterforge_dx_tools.generators.generator import (
            generate_frag,
            generate_registry,
            generate_trait,
        )

        if component_type == "frag":
            trait_list = traits.split(",") if traits else None
            output = generate_frag(name, output_dir, trait_list)
        elif component_type == "registry":
            output = generate_registry(name, output_dir)
        elif component_type == "trait":
            output = generate_trait(name, output_dir)
        else:
            raise ValueError(f"Unknown type: {component_type}")

        return {"component_type": component_type, "output": output}

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ Migration created: {output}"
        )
    )
    async def migration_create(
        self,
        name: str,
        migrations_dir: str = "migrations"
    ) -> dict:
        """Create a new migration file.

        Args:
            name: Migration name (e.g., 'add_user_bio_field')
            migrations_dir: Directory for migration files
        """
        from winterforge_dx_tools.migrations import MigrationGenerator

        output = MigrationGenerator.create_migration(
            name=name,
            migrations_dir=migrations_dir
        )

        return {"output": output}

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ Applied {count} migration(s)"
        )
    )
    async def migration_up(
        self,
        steps: int = None,
        migrations_dir: str = "migrations"
    ) -> dict:
        """Run pending migrations.

        Args:
            steps: Number of migrations to run (default: all)
            migrations_dir: Directory containing migrations
        """
        from winterforge_dx_tools.migrations import MigrationExecutor
        from winterforge.plugins._manager_manager import ManagerManager

        # Get storage from WinterForge
        storage_manager = ManagerManager().get_manager('storage')
        storage = storage_manager.get_first()

        if not storage:
            raise RuntimeError("No storage backend available")

        # Run migrations
        executor = MigrationExecutor(storage, migrations_dir)
        applied = await executor.up(steps)

        # Print applied migrations
        if applied:
            for migration in applied:
                print(f"  Applied: {migration}")

        return {"count": len(applied), "applied": applied}

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="✓ Reverted {count} migration(s)"
        )
    )
    async def migration_down(
        self,
        steps: int = 1,
        migrations_dir: str = "migrations"
    ) -> dict:
        """Rollback migrations.

        Args:
            steps: Number of migrations to rollback
            migrations_dir: Directory containing migrations
        """
        from winterforge_dx_tools.migrations import MigrationExecutor
        from winterforge.plugins._manager_manager import ManagerManager

        # Get storage from WinterForge
        storage_manager = ManagerManager().get_manager('storage')
        storage = storage_manager.get_first()

        if not storage:
            raise RuntimeError("No storage backend available")

        # Rollback migrations
        executor = MigrationExecutor(storage, migrations_dir)
        reverted = await executor.down(steps)

        # Print reverted migrations
        if reverted:
            for migration in reverted:
                print(f"  Reverted: {migration}")

        return {"count": len(reverted), "reverted": reverted}

    @decorator_provider(
        cli_command=CLICommandConfig(
            success="Migration status"
        )
    )
    async def migration_status(
        self,
        migrations_dir: str = "migrations"
    ) -> dict:
        """Show migration status.

        Args:
            migrations_dir: Directory containing migrations
        """
        from winterforge_dx_tools.migrations import MigrationExecutor
        from winterforge.plugins._manager_manager import ManagerManager

        # Get storage from WinterForge
        storage_manager = ManagerManager().get_manager('storage')
        storage = storage_manager.get_first()

        if not storage:
            raise RuntimeError("No storage backend available")

        # Get status
        executor = MigrationExecutor(storage, migrations_dir)
        status = executor.status()

        # Print status
        print(f"\n📊 Migration Status:")
        print(f"   Total: {status['total']}")
        print(f"   Applied: {status['applied']}")
        print(f"   Pending: {status['pending']}")

        if status['last_applied']:
            print(f"   Last: {status['last_applied']}")

        if status['pending_migrations']:
            print(f"\n⏳ Pending migrations:")
            for migration in status['pending_migrations']:
                print(f"   - {migration}")

        return status

