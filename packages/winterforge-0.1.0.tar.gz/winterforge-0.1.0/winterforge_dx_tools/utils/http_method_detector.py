"""HTTP method detection from method names.

Determines appropriate HTTP verb based on method naming conventions.
"""
from typing import Literal

HTTPMethod = Literal['GET', 'POST', 'PUT', 'DELETE', 'PATCH']


class HTTPMethodDetector:
    """Detects HTTP method from method name and signature."""

    # Method name patterns
    GET_PATTERNS = [
        'show',
        'get',
        'list',
        'find',
        'search',
        'view',
        'fetch',
        'retrieve',
    ]
    POST_PATTERNS = [
        'create',
        'add',
        'insert',
        'generate',
        'new',
        'make',
    ]
    PUT_PATTERNS = [
        'update',
        'edit',
        'modify',
        'set',
        'change',
        'replace',
    ]
    DELETE_PATTERNS = ['delete', 'remove', 'destroy', 'drop']
    PATCH_PATTERNS = ['patch', 'partial_update', 'partial']

    @classmethod
    def detect(
        cls, method_name: str, has_body_params: bool = True
    ) -> HTTPMethod:
        """Detect HTTP method from method name.

        Args:
            method_name: Name of the method (e.g., 'create_user')
            has_body_params: Whether method has parameters (body expected)

        Returns:
            HTTP method verb
        """
        method_lower = method_name.lower().replace('_', '').replace('-', '')

        # Check patterns in priority order
        for pattern in cls.GET_PATTERNS:
            if pattern in method_lower:
                return 'GET'

        for pattern in cls.DELETE_PATTERNS:
            if pattern in method_lower:
                return 'DELETE'

        # Check PATCH before PUT (patch/partial_update before update)
        for pattern in cls.PATCH_PATTERNS:
            if pattern in method_lower:
                return 'PATCH'

        for pattern in cls.PUT_PATTERNS:
            if pattern in method_lower:
                return 'PUT'

        for pattern in cls.POST_PATTERNS:
            if pattern in method_lower:
                return 'POST'

        # Default based on parameters
        # Methods with no params are likely queries (GET)
        # Methods with params are likely mutations (POST)
        return 'GET' if not has_body_params else 'POST'

    @classmethod
    def requires_body(cls, http_method: HTTPMethod) -> bool:
        """Check if HTTP method typically has request body.

        Args:
            http_method: HTTP method verb

        Returns:
            True if method typically has request body
        """
        return http_method in ('POST', 'PUT', 'PATCH')

    @classmethod
    def is_mutation(cls, http_method: HTTPMethod) -> bool:
        """Check if HTTP method mutates state.

        Args:
            http_method: HTTP method verb

        Returns:
            True if method mutates state
        """
        return http_method in ('POST', 'PUT', 'PATCH', 'DELETE')
