"""
Method signature introspection utilities.

Extracts parameter information from method signatures.
"""
import inspect
from typing import Dict, List, Any, get_type_hints


class MethodIntrospector:
    """Introspects method signatures for parameter information."""

    @classmethod
    def get_parameters(cls, method) -> List[Dict[str, Any]]:
        """
        Extract parameter information from method.

        Returns:
            List of parameter dicts with name, type, required, default
        """
        sig = inspect.signature(method)

        # Try to get type hints, but handle forward reference errors
        try:
            type_hints = get_type_hints(method)
        except (NameError, AttributeError):
            # Fall back to raw annotations if evaluation fails
            type_hints = {}
            if hasattr(method, '__annotations__'):
                type_hints = method.__annotations__.copy()

        params = []

        for param_name, param in sig.parameters.items():
            # Skip 'self' and 'cls'
            if param_name in ('self', 'cls'):
                continue

            param_info = {
                'name': param_name,
                'type_hint': type_hints.get(param_name),
                'required': (
                    param.default == inspect.Parameter.empty
                ),
                'default': (
                    None if param.default == inspect.Parameter.empty
                    else param.default
                )
            }

            params.append(param_info)

        return params

    @classmethod
    def get_return_type(cls, method) -> Any:
        """Extract return type annotation."""
        try:
            type_hints = get_type_hints(method)
            return type_hints.get('return')
        except (NameError, AttributeError):
            # Fall back to raw annotation if evaluation fails
            if hasattr(method, '__annotations__'):
                return method.__annotations__.get('return')
            return None

    @classmethod
    def get_docstring_summary(cls, method) -> str:
        """Extract first line of docstring."""
        doc = inspect.getdoc(method)
        if not doc:
            return ""

        lines = doc.split('\n')
        return lines[0].strip()

    @classmethod
    def get_docstring_full(cls, method) -> str:
        """Extract full docstring."""
        return inspect.getdoc(method) or ""
