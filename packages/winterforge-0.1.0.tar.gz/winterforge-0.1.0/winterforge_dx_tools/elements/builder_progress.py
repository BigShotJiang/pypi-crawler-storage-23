"""
Progress element for FormatterBuilder.

Value object holding progress bar configuration, rendered on demand.

Example:
    progress = ProgressElement(
        label='Processing',
        current=45,
        total=100
    )
    output = progress.render()
"""

from typing import Optional
from winterforge.plugins.decorators import scope, root


@root('progress')
@scope('prettier')
class ProgressElement:
    """
    Progress bar element for builder pattern.

    Holds progress configuration and renders to string.
    """

    def __init__(
        self,
        label: str = 'Progress',
        current: int = 0,
        total: int = 100,
        show_percentage: bool = True,
        show_count: bool = True
    ):
        """
        Initialize progress element.

        Args:
            label: Progress bar label
            current: Current progress value
            total: Total progress value
            show_percentage: Show percentage
            show_count: Show count (current/total)
        """
        self.label = label
        self.current = current
        self.total = total
        self.show_percentage = show_percentage
        self.show_count = show_count

    def render(self) -> str:
        """
        Render progress bar to string.

        Returns:
            Rendered progress output
        """
        try:
            from rich.progress import Progress as RichProgress
            from rich.console import Console
            from io import StringIO
        except ImportError:
            raise ImportError(
                "Rich library required. "
                "Install with: pip install winterforge[dx]"
            )

        # Capture output to string
        string_io = StringIO()
        console = Console(file=string_io, force_terminal=True)

        # Create progress bar
        with RichProgress(console=console) as progress:
            task = progress.add_task(
                self.label,
                total=self.total
            )
            progress.update(task, completed=self.current)

        return string_io.getvalue()
