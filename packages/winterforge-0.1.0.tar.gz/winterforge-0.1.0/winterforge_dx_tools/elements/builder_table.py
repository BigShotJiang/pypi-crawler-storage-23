"""
Table element for FormatterBuilder.

Value object holding table configuration, rendered on demand.

Example:
    table = TableElement(
        data=[['Name', 'Alice'], ['Age', '30']],
        title='User Info'
    )
    output = table.render()
"""

from typing import Optional, Any
from winterforge.plugins.decorators import scope, root


@root('table')
@scope('prettier')
class TableElement:
    """
    Table element for builder pattern.

    Holds table configuration and renders to string.
    """

    def __init__(
        self,
        data: list[list[Any]] = None,
        headers: list[str] = None,
        title: Optional[str] = None,
        show_header: bool = True,
        show_lines: bool = False
    ):
        """
        Initialize table element.

        Args:
            data: Table data (rows)
            headers: Column headers (if None, uses first row)
            title: Optional table title
            show_header: Show header row
            show_lines: Show lines between rows
        """
        self.data = data or []
        self.headers = headers
        self.title = title
        self.show_header = show_header
        self.show_lines = show_lines

    def render(self) -> str:
        """
        Render table to string.

        Returns:
            Rendered table output
        """
        try:
            from rich.table import Table
            from rich.console import Console
            from io import StringIO
        except ImportError:
            raise ImportError(
                "Rich library required. "
                "Install with: pip install winterforge[dx]"
            )

        # Capture output to string
        string_io = StringIO()
        console = Console(file=string_io, force_terminal=True)

        # Create table
        table = Table(
            title=self.title,
            show_header=self.show_header,
            show_lines=self.show_lines
        )

        # Add columns
        if self.headers:
            for header in self.headers:
                table.add_column(str(header))
        elif self.data and self.show_header:
            # Use first row as headers
            for header in self.data[0]:
                table.add_column(str(header))
            # Remove first row from data
            data_rows = self.data[1:]
        else:
            data_rows = self.data

        # Add rows
        if self.headers:
            data_rows = self.data

        for row in data_rows:
            table.add_row(*[str(cell) for cell in row])

        console.print(table)
        return string_io.getvalue()
