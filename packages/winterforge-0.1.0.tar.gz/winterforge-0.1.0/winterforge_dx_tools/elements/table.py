"""Table element for prettier formatter."""

from typing import List, Optional, Any
from winterforge.plugins.decorators import scope


@scope('prettier')
class TableElement:
    """
    Renders tabular data using Rich.

    Provides table rendering capability for prettier formatter.
    Automatically scoped to prettier via @scope decorator.

    Example:
        data = [["Alice", "30"], ["Bob", "25"]]
        formatter.table(data, headers=["Name", "Age"])
    """

    def __init__(self, formatter: Optional[Any] = None):
        """
        Initialize table element.

        Args:
            formatter: Parent formatter instance (injected)
        """
        self.formatter = formatter

    def render(
        self,
        rows: List[List[str]],
        headers: Optional[List[str]] = None,
        title: Optional[str] = None,
        show_header: bool = True,
        show_lines: bool = False
    ) -> None:
        """
        Render data as a table.

        Args:
            rows: List of row data
            headers: Optional column headers
            title: Optional table title
            show_header: Whether to show header row
            show_lines: Whether to show row divider lines
        """
        try:
            from rich.table import Table
            from rich.console import Console
        except ImportError:
            raise ImportError(
                "Rich library required. "
                "Install with: pip install winterforge[dx]"
            )

        console = Console()
        table = Table(
            title=title,
            show_header=show_header,
            show_lines=show_lines
        )

        # Add columns
        if headers:
            for header in headers:
                table.add_column(header)
        elif rows and show_header:
            # Use first row as headers if not provided
            for i, _ in enumerate(rows[0]):
                table.add_column(f"Column {i+1}")

        # Add rows
        for row in rows:
            table.add_row(*[str(cell) for cell in row])

        console.print(table)
