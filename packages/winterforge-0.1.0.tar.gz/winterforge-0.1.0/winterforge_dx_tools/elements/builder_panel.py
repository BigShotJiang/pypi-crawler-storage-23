"""
Panel element for FormatterBuilder.

Value object holding panel configuration, rendered on demand.

Example:
    panel = PanelElement(title='Status', content='Ready')
    output = panel.render()
"""

from typing import Optional
from winterforge.plugins.decorators import scope, root


@root('panel')
@scope('prettier')
class PanelElement:
    """
    Panel element for builder pattern.

    Holds panel configuration and renders to string.
    """

    def __init__(
        self,
        content: str = '',
        title: Optional[str] = None,
        border_style: str = 'blue',
        padding: tuple = (1, 2)
    ):
        """
        Initialize panel element.

        Args:
            content: Content to display
            title: Optional panel title
            border_style: Rich style for border
            padding: Panel padding (vertical, horizontal)
        """
        self.content = content
        self.title = title
        self.border_style = border_style
        self.padding = padding

    def render(self) -> str:
        """
        Render panel to string.

        Returns:
            Rendered panel output
        """
        try:
            from rich.panel import Panel
            from rich.console import Console
            from io import StringIO
        except ImportError:
            raise ImportError(
                "Rich library required. "
                "Install with: pip install winterforge[dx]"
            )

        # Capture output to string
        string_io = StringIO()
        console = Console(file=string_io, force_terminal=True)

        panel = Panel(
            self.content,
            title=self.title,
            border_style=self.border_style,
            padding=self.padding
        )
        console.print(panel)

        return string_io.getvalue()
