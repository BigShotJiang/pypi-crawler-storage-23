"""
Tree element for FormatterBuilder.

Value object holding tree configuration, rendered on demand.

Example:
    tree = TreeElement(
        root='Project',
        children={'src': ['main.py', 'utils.py'], 'tests': ['test_main.py']}
    )
    output = tree.render()
"""

from typing import Any, Union
from winterforge.plugins.decorators import scope, root


@root('tree')
@scope('prettier')
class TreeElement:
    """
    Tree element for builder pattern.

    Holds tree configuration and renders to string.
    """

    def __init__(
        self,
        root_label: str = 'Root',
        data: Union[dict, list] = None,
        guide_style: str = 'tree'
    ):
        """
        Initialize tree element.

        Args:
            root_label: Label for root node
            data: Tree data (dict for nested, list for flat)
            guide_style: Rich guide style ('tree', 'line', 'ascii')
        """
        self.root_label = root_label
        self.data = data or {}
        self.guide_style = guide_style

    def render(self) -> str:
        """
        Render tree to string.

        Returns:
            Rendered tree output
        """
        try:
            from rich.tree import Tree
            from rich.console import Console
            from io import StringIO
        except ImportError:
            raise ImportError(
                "Rich library required. "
                "Install with: pip install winterforge[dx]"
            )

        # Capture output to string
        string_io = StringIO()
        console = Console(file=string_io, force_terminal=True)

        # Create tree
        tree = Tree(
            self.root_label,
            guide_style=self.guide_style
        )

        # Add nodes
        self._add_nodes(tree, self.data)

        console.print(tree)
        return string_io.getvalue()

    def _add_nodes(
        self,
        parent: Any,
        data: Union[dict, list, str]
    ):
        """
        Recursively add nodes to tree.

        Args:
            parent: Parent tree node
            data: Data to add (dict, list, or string)
        """
        if isinstance(data, dict):
            for key, value in data.items():
                branch = parent.add(str(key))
                if value:
                    self._add_nodes(branch, value)
        elif isinstance(data, list):
            for item in data:
                if isinstance(item, (dict, list)):
                    self._add_nodes(parent, item)
                else:
                    parent.add(str(item))
        else:
            parent.add(str(data))
