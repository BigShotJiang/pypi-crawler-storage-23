"""Tree element for prettier formatter."""

from typing import Optional, Any, List, Dict
from winterforge.plugins.decorators import scope


@scope('prettier')
class TreeElement:
    """
    Renders hierarchical tree structures using Rich.

    Provides tree rendering capability for prettier formatter.
    Automatically scoped to prettier via @scope decorator.

    Example:
        tree_data = {
            'label': 'Root',
            'children': [
                {'label': 'Child 1'},
                {'label': 'Child 2', 'children': [
                    {'label': 'Grandchild'}
                ]}
            ]
        }
        formatter.tree(tree_data)
    """

    def __init__(self, formatter: Optional[Any] = None):
        """
        Initialize tree element.

        Args:
            formatter: Parent formatter instance (injected)
        """
        self.formatter = formatter

    def render(
        self,
        data: Dict[str, Any],
        guide_style: str = "tree"
    ) -> None:
        """
        Render hierarchical data as a tree.

        Args:
            data: Tree data structure with 'label' and 'children'
            guide_style: Style for tree guide lines
        """
        try:
            from rich.tree import Tree
            from rich.console import Console
        except ImportError:
            raise ImportError(
                "Rich library required. "
                "Install with: pip install winterforge[dx]"
            )

        console = Console()

        def build_tree(node_data: Dict, parent=None):
            """Recursively build Rich tree."""
            label = node_data.get('label', 'Node')

            if parent is None:
                # Root node
                tree = Tree(label, guide_style=guide_style)
                current = tree
            else:
                # Child node
                current = parent.add(label)

            # Add children recursively
            for child_data in node_data.get('children', []):
                build_tree(child_data, current)

            return tree if parent is None else current

        tree = build_tree(data)
        console.print(tree)
