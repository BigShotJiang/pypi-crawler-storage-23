"""Panel element for prettier formatter."""

from typing import Optional, Any
from winterforge.plugins.decorators import scope


@scope('prettier')
class PanelElement:
    """
    Renders content in a bordered panel using Rich.

    Provides panel rendering capability for prettier formatter.
    Automatically scoped to prettier via @scope decorator.

    Example:
        formatter.panel("Hello", title="Greeting")
    """

    def __init__(self, formatter: Optional[Any] = None):
        """
        Initialize panel element.

        Args:
            formatter: Parent formatter instance (injected)
        """
        self.formatter = formatter

    def render(
        self,
        content: str,
        title: Optional[str] = None,
        border_style: str = "blue",
        padding: tuple = (1, 2)
    ) -> None:
        """
        Render content in a panel.

        Args:
            content: Content to display in panel
            title: Optional panel title
            border_style: Rich style for panel border
            padding: Panel padding (vertical, horizontal)
        """
        try:
            from rich.panel import Panel
            from rich.console import Console
        except ImportError:
            raise ImportError(
                "Rich library required. "
                "Install with: pip install winterforge[dx]"
            )

        console = Console()
        panel = Panel(
            content,
            title=title,
            border_style=border_style,
            padding=padding
        )
        console.print(panel)
