"""Progress element for prettier formatter."""

from typing import Optional, Any
from winterforge.plugins.decorators import scope


@scope('prettier')
class ProgressElement:
    """
    Renders progress bars using Rich.

    Provides progress bar rendering capability for prettier formatter.
    Automatically scoped to prettier via @scope decorator.

    Example:
        with formatter.progress() as progress:
            task = progress.add_task("Processing", total=100)
            for i in range(100):
                progress.update(task, advance=1)
    """

    def __init__(self, formatter: Optional[Any] = None):
        """
        Initialize progress element.

        Args:
            formatter: Parent formatter instance (injected)
        """
        self.formatter = formatter

    def render(
        self,
        transient: bool = False,
        console: Optional[Any] = None
    ) -> Any:
        """
        Create a progress context manager.

        Args:
            transient: Remove progress bar when complete
            console: Optional console instance

        Returns:
            Rich Progress context manager
        """
        try:
            from rich.progress import Progress
        except ImportError:
            raise ImportError(
                "Rich library required. "
                "Install with: pip install winterforge[dx]"
            )

        return Progress(transient=transient, console=console)
