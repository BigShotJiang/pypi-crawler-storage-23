"""Element plugin manager."""

from winterforge.plugins._base import ReorderablePluginManagerBase


class ElementManager(ReorderablePluginManagerBase):
    """
    Manages CLI formatting element plugins.

    Elements are subsidiary plugins scoped to specific formatters.
    They provide specialized rendering capabilities (panels, tables,
    progress bars, trees, etc.) for their parent formatter.

    Example:
        # Get all elements scoped to prettier
        prettier_mgr = ElementManager.with_scope('prettier')
        elements = prettier_mgr.all()
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return plugin manager identifier."""
        return 'winterforge.dx.elements'
