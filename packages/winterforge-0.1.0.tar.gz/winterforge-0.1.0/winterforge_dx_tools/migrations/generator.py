"""Migration file generator."""
from pathlib import Path
from datetime import datetime
from winterforge_dx_tools.migrations.template import MIGRATION_TEMPLATE


class MigrationGenerator:
    """Generates migration files."""

    @classmethod
    def create_migration(
        cls,
        name: str,
        migrations_dir: str = 'migrations'
    ) -> str:
        """
        Create a new migration file.

        Args:
            name: Migration name (e.g., 'add_user_bio_field')
            migrations_dir: Directory for migration files

        Returns:
            Path to created migration file
        """
        # Generate timestamp prefix
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

        # Generate filename
        filename = f'{timestamp}_{name}.py'

        # Create migrations directory if needed
        migrations_path = Path(migrations_dir)
        migrations_path.mkdir(parents=True, exist_ok=True)

        # Generate file content
        description = name.replace('_', ' ').title()
        timestamp_iso = datetime.now().isoformat()
        content = (
            f'"""\n'
            f'{description}\n'
            f'\n'
            f'Created: {timestamp_iso}\n'
            f'"""\n'
            f'from winterforge.plugins._protocols.storage import StorageBackend\n'
            f'\n'
            f'\n'
            f'async def up(storage: StorageBackend):\n'
            f'    """\n'
            f'    Apply migration.\n'
            f'\n'
            f'    Args:\n'
            f'        storage: Storage backend instance\n'
            f'    """\n'
            f'    # Add your migration logic here\n'
            f'    pass\n'
            f'\n'
            f'\n'
            f'async def down(storage: StorageBackend):\n'
            f'    """\n'
            f'    Rollback migration.\n'
            f'\n'
            f'    Args:\n'
            f'        storage: Storage backend instance\n'
            f'    """\n'
            f'    # Add your rollback logic here\n'
            f'    pass\n'
        )

        # Write file
        filepath = migrations_path / filename
        filepath.write_text(content)

        return str(filepath)

    @classmethod
    def get_migration_files(cls, migrations_dir: str = 'migrations'):
        """
        Get all migration files in directory.

        Args:
            migrations_dir: Directory containing migrations

        Returns:
            Sorted list of migration file paths
        """
        migrations_path = Path(migrations_dir)

        if not migrations_path.exists():
            return []

        # Get all .py files except __init__.py
        files = [
            f for f in migrations_path.glob('*.py')
            if f.name != '__init__.py'
        ]

        # Sort by filename (timestamp prefix ensures correct order)
        return sorted([str(f) for f in files])

    @classmethod
    def get_migration_name(cls, filepath: str) -> str:
        """
        Extract migration name from filepath.

        Args:
            filepath: Path to migration file

        Returns:
            Migration name (timestamp_name format)
        """
        return Path(filepath).stem
