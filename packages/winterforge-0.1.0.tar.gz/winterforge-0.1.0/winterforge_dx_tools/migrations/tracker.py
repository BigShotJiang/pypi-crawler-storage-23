"""Migration tracking system."""
import json
from pathlib import Path
from typing import List, Dict
from datetime import datetime


class MigrationTracker:
    """Tracks which migrations have been applied."""

    def __init__(self, tracker_file: str = '.migrations.json'):
        """
        Initialize tracker.

        Args:
            tracker_file: Path to tracker file
        """
        self._tracker_file = Path(tracker_file)
        self._data = None

    def _load_data(self) -> Dict:
        """Load tracker data from file."""
        if self._data is None:
            if self._tracker_file.exists():
                self._data = json.loads(
                    self._tracker_file.read_text()
                )
            else:
                self._data = {'migrations': []}

        return self._data

    def _save_data(self):
        """Save tracker data to file."""
        self._tracker_file.write_text(
            json.dumps(self._data, indent=2)
        )

    def mark_applied(self, migration_name: str):
        """
        Mark migration as applied.

        Args:
            migration_name: Migration identifier
        """
        data = self._load_data()

        # Check if already applied
        if not any(m['name'] == migration_name for m in data['migrations']):
            data['migrations'].append({
                'name': migration_name,
                'applied_at': datetime.now().isoformat()
            })

        self._save_data()
        self._data = None  # Clear cache

    def mark_reverted(self, migration_name: str):
        """
        Mark migration as reverted.

        Args:
            migration_name: Migration identifier
        """
        data = self._load_data()

        data['migrations'] = [
            m for m in data['migrations']
            if m['name'] != migration_name
        ]

        self._save_data()
        self._data = None  # Clear cache

    def is_applied(self, migration_name: str) -> bool:
        """
        Check if migration has been applied.

        Args:
            migration_name: Migration identifier

        Returns:
            True if applied, False otherwise
        """
        data = self._load_data()

        return any(
            m['name'] == migration_name
            for m in data['migrations']
        )

    def get_applied_migrations(self) -> List[str]:
        """
        Get list of applied migration names.

        Returns:
            List of migration names
        """
        data = self._load_data()

        return [m['name'] for m in data['migrations']]

    def get_pending_migrations(
        self,
        all_migrations: List[str]
    ) -> List[str]:
        """
        Get list of pending migrations.

        Args:
            all_migrations: List of all available migrations

        Returns:
            List of pending migration names
        """
        applied = set(self.get_applied_migrations())

        return [m for m in all_migrations if m not in applied]

    def get_last_applied(self) -> str:
        """
        Get last applied migration.

        Returns:
            Migration name or None
        """
        data = self._load_data()

        if data['migrations']:
            return data['migrations'][-1]['name']

        return None
