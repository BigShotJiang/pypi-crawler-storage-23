"""Migration file template."""

MIGRATION_TEMPLATE = '''"""
{description}

Created: {timestamp}
"""
from winterforge.plugins._protocols.storage import StorageBackend


async def up(storage: StorageBackend):
    """
    Apply migration.

    Args:
        storage: Storage backend instance
    """
    # Add your migration logic here
    pass


async def down(storage: StorageBackend):
    """
    Rollback migration.

    Args:
        storage: Storage backend instance
    """
    # Add your rollback logic here
    pass
'''
