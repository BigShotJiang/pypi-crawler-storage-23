"""Migration execution system."""
import importlib.util
import sys
from pathlib import Path
from typing import List, Dict, Any
from winterforge.plugins._protocols.storage import StorageBackend
from winterforge_dx_tools.migrations.tracker import MigrationTracker
from winterforge_dx_tools.migrations.generator import MigrationGenerator


class MigrationExecutor:
    """Executes migrations up and down."""

    def __init__(
        self,
        storage: StorageBackend,
        migrations_dir: str = 'migrations',
        tracker_file: str = '.migrations.json'
    ):
        """
        Initialize executor.

        Args:
            storage: Storage backend
            migrations_dir: Directory containing migrations
            tracker_file: Migration tracker file
        """
        self._storage = storage
        self._migrations_dir = migrations_dir
        self._tracker = MigrationTracker(tracker_file)

    async def up(self, steps: int = None) -> List[str]:
        """
        Run pending migrations.

        Args:
            steps: Number of migrations to run (None = all)

        Returns:
            List of applied migration names
        """
        # Get all migrations
        all_files = MigrationGenerator.get_migration_files(
            self._migrations_dir
        )

        all_names = [
            MigrationGenerator.get_migration_name(f)
            for f in all_files
        ]

        # Get pending migrations
        pending = self._tracker.get_pending_migrations(all_names)

        # Limit to steps if specified
        if steps is not None:
            pending = pending[:steps]

        # Apply each pending migration
        applied = []

        for migration_name in pending:
            # Find file for this migration
            migration_file = next(
                f for f in all_files
                if MigrationGenerator.get_migration_name(f) ==
                migration_name
            )

            # Load and execute migration
            module = self._load_migration_module(migration_file)
            await module.up(self._storage)

            # Mark as applied
            self._tracker.mark_applied(migration_name)

            applied.append(migration_name)

        return applied

    async def down(self, steps: int = 1) -> List[str]:
        """
        Rollback migrations.

        Args:
            steps: Number of migrations to rollback

        Returns:
            List of reverted migration names
        """
        # Get all migrations
        all_files = MigrationGenerator.get_migration_files(
            self._migrations_dir
        )

        all_names = [
            MigrationGenerator.get_migration_name(f)
            for f in all_files
        ]

        # Get applied migrations in reverse order
        applied = self._tracker.get_applied_migrations()
        to_revert = list(reversed(applied))[:steps]

        # Revert each migration
        reverted = []

        for migration_name in to_revert:
            # Find file for this migration
            migration_file = next(
                (f for f in all_files
                 if MigrationGenerator.get_migration_name(f) ==
                 migration_name),
                None
            )

            if not migration_file:
                # Migration file not found, mark as reverted anyway
                self._tracker.mark_reverted(migration_name)
                reverted.append(migration_name)
                continue

            # Load and execute migration
            module = self._load_migration_module(migration_file)
            await module.down(self._storage)

            # Mark as reverted
            self._tracker.mark_reverted(migration_name)

            reverted.append(migration_name)

        return reverted

    def status(self) -> Dict[str, Any]:
        """
        Get migration status.

        Returns:
            Dict with applied, pending counts and lists
        """
        # Get all migrations
        all_files = MigrationGenerator.get_migration_files(
            self._migrations_dir
        )

        all_names = [
            MigrationGenerator.get_migration_name(f)
            for f in all_files
        ]

        # Get applied and pending
        applied = self._tracker.get_applied_migrations()
        pending = self._tracker.get_pending_migrations(all_names)

        return {
            'total': len(all_names),
            'applied': len(applied),
            'pending': len(pending),
            'applied_migrations': applied,
            'pending_migrations': pending,
            'last_applied': self._tracker.get_last_applied()
        }

    def _load_migration_module(self, filepath: str):
        """
        Load migration module from file.

        Args:
            filepath: Path to migration file

        Returns:
            Loaded module
        """
        spec = importlib.util.spec_from_file_location(
            'migration',
            filepath
        )

        module = importlib.util.module_from_spec(spec)

        # Add to sys.modules temporarily
        sys.modules['migration'] = module

        spec.loader.exec_module(module)

        # Remove from sys.modules
        del sys.modules['migration']

        return module
