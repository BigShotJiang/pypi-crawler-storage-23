"""Prettier formatter using Rich library."""

from typing import Any, Optional, List, Dict


class PrettierFormatter:
    """
    Rich-based formatter for beautiful terminal output.

    Provides methods for formatting CLI output using Rich library's
    components. Elements are automatically discovered and made available
    as methods on this formatter.

    Example:
        formatter = FormatterManager.get('prettier')
        formatter.panel("Hello", title="Greeting")
        formatter.table(data, headers=["Name", "Value"])
    """

    def __init__(self):
        """Initialize formatter with Rich console."""
        try:
            from rich.console import Console
            self.console = Console()
        except ImportError:
            raise ImportError(
                "Rich library required for prettier formatter. "
                "Install with: pip install winterforge[dx]"
            )

        # Load elements scoped to this formatter
        self._load_elements()

    def _load_elements(self):
        """Load element plugins scoped to prettier."""
        from winterforge_dx_tools.elements import ElementManager

        # Get scoped manager for prettier elements
        scoped_mgr = ElementManager.with_scope('prettier')

        # Load all elements
        self._elements = {}
        for plugin_id in ElementManager._order:
            element = scoped_mgr.get_scoped(plugin_id)
            if element is not None:
                # Bind element to this formatter instance
                element_name = plugin_id.replace('_element', '')
                self._elements[element_name] = element
                # Make element callable as method
                setattr(self, element_name, element.render)

    def print(self, *args: Any, **kwargs: Any) -> None:
        """Print output using Rich console."""
        self.console.print(*args, **kwargs)

    def rule(
        self,
        title: str = "",
        characters: str = "─",
        style: str = "rule.line"
    ) -> None:
        """
        Render a horizontal rule.

        Args:
            title: Optional title for the rule
            characters: Characters to use for the rule
            style: Rich style for the rule
        """
        from rich.rule import Rule
        self.console.print(Rule(title, characters=characters, style=style))

    def status(self, message: str, spinner: str = "dots") -> Any:
        """
        Create a status context manager.

        Args:
            message: Status message to display
            spinner: Spinner style

        Returns:
            Rich status context manager
        """
        return self.console.status(message, spinner=spinner)
