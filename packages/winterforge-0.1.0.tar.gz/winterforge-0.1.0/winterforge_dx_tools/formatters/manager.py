"""Formatter plugin manager."""

from winterforge.plugins._base import ReorderablePluginManagerBase


class FormatterManager(ReorderablePluginManagerBase):
    """
    Manages CLI formatter plugins.

    Formatters provide rich terminal output using libraries like Rich.
    Each formatter can have subsidiary element plugins scoped to it.

    Example:
        # Get prettier formatter
        prettier = FormatterManager.get('prettier')

        # Format output
        prettier.panel("Hello, World!", title="Greeting")
    """

    @classmethod
    def plugin_id(cls) -> str:
        """Return plugin manager identifier."""
        return 'winterforge.dx.formatters'
