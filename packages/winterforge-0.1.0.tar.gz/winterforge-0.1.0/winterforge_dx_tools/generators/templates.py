"""Templates for code generation."""

FRAG_TEMPLATE = '''"""
{description}
"""
from winterforge.frags import Frag


class {class_name}(Frag):
    """
{class_doc}
    """

    def __init__(self, **kwargs):
        """Initialize {class_name}."""
        # Set affinities and traits
        kwargs.setdefault('affinities', {affinities})
        kwargs.setdefault('traits', {traits})

        super().__init__(**kwargs)
'''

REGISTRY_TEMPLATE = '''"""
{description}
"""
from winterforge.frags.registries.frag_registry import FragRegistry


class {class_name}(FragRegistry):
    """
{class_doc}
    """

    def __init__(self, composition=None):
        """Initialize {class_name}."""
        super().__init__(composition=composition or {{}})
'''

TRAIT_TEMPLATE = '''"""
{description}
"""
from winterforge.frags.traits import trait


@trait('{trait_id}')
class {class_name}Trait:
    """
{class_doc}
    """

    def apply(self, frag):
        """Apply trait to Frag."""
        pass
'''
