"""Code generator for WinterForge components."""
from pathlib import Path
from typing import List
from winterforge_dx_tools.generators.templates import (
    FRAG_TEMPLATE,
    REGISTRY_TEMPLATE,
    TRAIT_TEMPLATE,
)


def to_snake_case(name: str) -> str:
    """Convert CamelCase to snake_case."""
    import re

    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


def generate_frag(
    name: str,
    output_dir: str = '.',
    traits: List[str] = None,
    affinities: List[str] = None,
) -> str:
    """Generate a Frag class file.

    Args:
        name: Class name (e.g., 'BlogPost')
        output_dir: Output directory
        traits: List of traits
        affinities: List of affinities

    Returns:
        Path to generated file
    """
    traits = traits or ['persistable']
    affinities = affinities or [to_snake_case(name)]

    # Use f-string instead of .format()
    traits_repr = repr(traits)
    affinities_repr = repr(affinities)
    description = f"{name} Frag"
    class_doc = f"Represents a {name}."
    code = (
        f'"""\n'
        f'{description}\n'
        f'"""\n'
        f'from winterforge.frags import Frag\n'
        f'\n'
        f'\n'
        f'class {name}(Frag):\n'
        f'    """\n'
        f'{class_doc}\n'
        f'    """\n'
        f'\n'
        f'    def __init__(self, **kwargs):\n'
        f'        """Initialize {name}."""\n'
        f'        # Set affinities and traits\n'
        f"        kwargs.setdefault('affinities', {affinities_repr})\n"
        f"        kwargs.setdefault('traits', {traits_repr})\n"
        f'\n'
        f'        super().__init__(**kwargs)\n'
    )

    filename = to_snake_case(name) + '.py'
    filepath = Path(output_dir) / filename

    filepath.write_text(code)
    return str(filepath)


def generate_registry(name: str, output_dir: str = '.') -> str:
    """Generate a Registry class file."""
    # Use f-string instead of .format()
    description = f"{name} registry"
    class_doc = f"Registry for managing {name} instances."
    code = (
        f'"""\n'
        f'{description}\n'
        f'"""\n'
        f'from winterforge.frags.registries.frag_registry '
        f'import FragRegistry\n'
        f'\n'
        f'\n'
        f'class {name}(FragRegistry):\n'
        f'    """\n'
        f'{class_doc}\n'
        f'    """\n'
        f'\n'
        f'    def __init__(self, composition=None):\n'
        f'        """Initialize {name}."""\n'
        f'        super().__init__(composition=composition or {{}})\n'
    )

    filename = to_snake_case(name) + '.py'
    filepath = Path(output_dir) / filename

    filepath.write_text(code)
    return str(filepath)


def generate_trait(name: str, output_dir: str = '.') -> str:
    """Generate a Trait file."""
    trait_id = to_snake_case(name)
    class_name = name.capitalize()
    description = f"{name} trait"
    class_doc = f"Provides {name} functionality."

    # Use f-string instead of .format()
    code = (
        f'"""\n'
        f'{description}\n'
        f'"""\n'
        f'from winterforge.frags.traits import trait\n'
        f'\n'
        f'\n'
        f"@trait('{trait_id}')\n"
        f'class {class_name}Trait:\n'
        f'    """\n'
        f'{class_doc}\n'
        f'    """\n'
        f'\n'
        f'    def apply(self, frag):\n'
        f'        """Apply trait to Frag."""\n'
        f'        pass\n'
    )

    filename = trait_id + '.py'
    filepath = Path(output_dir) / filename

    filepath.write_text(code)
    return str(filepath)
