"""
OpenAPI 3.1 specification generator.

Generates OpenAPI specs from WinterForge CLI commands.
"""
from typing import Dict, Any, List
from winterforge_dx_tools.openapi.schemas import SchemaMapper
from winterforge_dx_tools.utils.introspection import MethodIntrospector


class OpenAPIGenerator:
    """Generates OpenAPI 3.1 specifications from decorated methods."""

    @classmethod
    def generate_spec(
        cls,
        root_name: str,
        title: str = None,
        version: str = "1.0.0",
        description: str = None
    ) -> Dict[str, Any]:
        """
        Generate OpenAPI spec for root namespace.

        Args:
            root_name: Root namespace (e.g., 'user')
            title: API title (defaults to "{root_name} API")
            version: API version
            description: API description

        Returns:
            OpenAPI 3.1 spec dict
        """
        # Import here to avoid circular dependency
        from winterforge.plugins.cli._manager import CLICommandManager

        # Get commands for this root
        commands = CLICommandManager.get_commands_for_group(root_name)

        spec = {
            'openapi': '3.1.0',
            'info': {
                'title': title or f'{root_name.title()} API',
                'version': version,
                'description': (
                    description or f'API for {root_name} operations'
                )
            },
            'paths': {},
            'components': {
                'schemas': {}
            }
        }

        # Generate path for each command
        for command in commands:
            path_spec = cls._generate_path(root_name, command)
            spec['paths'].update(path_spec)

        return spec

    @classmethod
    def _generate_path(
        cls,
        root_name: str,
        command: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Generate OpenAPI path spec for command.

        Args:
            root_name: Root namespace
            command: Command metadata

        Returns:
            Path specification dict
        """
        # Default path: /api/{root}/{command}
        path = f'/api/{root_name}/{command["name"]}'

        # Get method information
        callable_obj = command['callable']
        params = MethodIntrospector.get_parameters(callable_obj)
        return_type = MethodIntrospector.get_return_type(callable_obj)
        summary = MethodIntrospector.get_docstring_summary(
            callable_obj
        )
        full_description = MethodIntrospector.get_docstring_full(
            callable_obj
        )

        # Build request body schema from parameters
        request_schema = cls._build_request_schema(params)

        # Build response schema from return type
        response_schema = SchemaMapper.map_type(return_type)

        path_spec = {
            path: {
                'post': {  # Default to POST for commands
                    'summary': summary,
                    'description': full_description,
                    'operationId': f'{root_name}_{command["name"]}',
                    'requestBody': {
                        'required': True,
                        'content': {
                            'application/json': {
                                'schema': request_schema
                            }
                        }
                    },
                    'responses': {
                        '200': {
                            'description': 'Successful operation',
                            'content': {
                                'application/json': {
                                    'schema': response_schema
                                }
                            }
                        },
                        '400': {
                            'description': 'Invalid request'
                        },
                        '401': {
                            'description': 'Unauthorized'
                        },
                        '500': {
                            'description': 'Server error'
                        }
                    },
                    'tags': [root_name]
                }
            }
        }

        return path_spec

    @classmethod
    def _build_request_schema(
        cls,
        params: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Build request body schema from parameters.

        Args:
            params: List of parameter dicts

        Returns:
            OpenAPI schema object
        """
        schema = {
            'type': 'object',
            'properties': {},
            'required': []
        }

        for param in params:
            param_schema = SchemaMapper.map_type(param['type_hint'])
            schema['properties'][param['name']] = param_schema

            if param['required']:
                schema['required'].append(param['name'])

        if not schema['required']:
            del schema['required']

        return schema
