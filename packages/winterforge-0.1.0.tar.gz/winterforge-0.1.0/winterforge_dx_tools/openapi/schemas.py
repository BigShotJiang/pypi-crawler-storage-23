"""
Type hint to OpenAPI schema mapping.

Maps Python type hints to OpenAPI 3.1 schema objects.
"""
from typing import Any, Dict, Optional, Union, get_origin, get_args
from pydantic import BaseModel


class SchemaMapper:
    """Maps Python types to OpenAPI schemas."""

    # Basic type mappings
    BASIC_TYPES = {
        str: {'type': 'string'},
        int: {'type': 'integer'},
        float: {'type': 'number'},
        bool: {'type': 'boolean'},
        list: {'type': 'array', 'items': {}},
        dict: {'type': 'object'},
    }

    @classmethod
    def map_type(cls, type_hint: Any) -> Dict[str, Any]:
        """
        Map Python type hint to OpenAPI schema.

        Args:
            type_hint: Python type annotation

        Returns:
            OpenAPI schema dict
        """
        # Handle None
        if type_hint is None or type_hint is type(None):
            return {'type': 'null'}

        # Handle basic types (including bare list/dict)
        if type_hint in cls.BASIC_TYPES:
            return cls.BASIC_TYPES[type_hint].copy()

        # Get generic origin and args
        origin = get_origin(type_hint)
        args = get_args(type_hint)

        # Handle Union types (including Optional)
        if origin is Union:
            # Check if this is Optional (Union with None)
            if type(None) in args:
                # This is Optional[T]
                non_none_args = [
                    arg for arg in args if arg is not type(None)
                ]
                if len(non_none_args) == 1:
                    inner_schema = cls.map_type(non_none_args[0])
                    # OpenAPI 3.1 uses anyOf for nullable
                    return {
                        'anyOf': [
                            inner_schema,
                            {'type': 'null'}
                        ]
                    }
            # Other Union types - use anyOf for all variants
            return {
                'anyOf': [cls.map_type(arg) for arg in args]
            }

        # Handle List[T]
        if origin is list:
            if args:
                return {
                    'type': 'array',
                    'items': cls.map_type(args[0])
                }
            return {'type': 'array', 'items': {}}

        # Handle Dict[K, V]
        if origin is dict:
            if len(args) == 2:
                return {
                    'type': 'object',
                    'additionalProperties': cls.map_type(args[1])
                }
            return {'type': 'object'}

        # Handle Pydantic models
        if isinstance(type_hint, type) and issubclass(
            type_hint, BaseModel
        ):
            return cls._map_pydantic_model(type_hint)

        # Handle Frag (WinterForge)
        if hasattr(type_hint, '__name__') and (
            'Frag' in type_hint.__name__
        ):
            return {
                'type': 'object',
                'properties': {
                    'id': {'type': 'integer'},
                    'affinities': {
                        'type': 'array',
                        'items': {'type': 'string'}
                    },
                    'traits': {
                        'type': 'array',
                        'items': {'type': 'string'}
                    }
                },
                'required': ['id', 'affinities', 'traits']
            }

        # Fallback: generic object
        return {'type': 'object'}

    @classmethod
    def _map_pydantic_model(cls, model: type) -> Dict[str, Any]:
        """Map Pydantic model to OpenAPI schema."""
        schema = {
            'type': 'object',
            'properties': {},
            'required': []
        }

        for field_name, field in model.model_fields.items():
            schema['properties'][field_name] = cls.map_type(
                field.annotation
            )

            if field.is_required():
                schema['required'].append(field_name)

        if not schema['required']:
            del schema['required']

        return schema
