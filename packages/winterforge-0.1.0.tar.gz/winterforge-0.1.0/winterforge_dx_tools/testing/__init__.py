"""Testing utilities for WinterForge applications.

Provides fixtures, factories, assertions, and helpers to make testing
WinterForge applications easier and more maintainable.
"""
from winterforge_dx_tools.testing.factories import (
    FragFactory,
    UserFactory,
    RegistryFactory,
)
from winterforge_dx_tools.testing.assertions import (
    assert_frag_exists,
    assert_frag_has_affinity,
    assert_frag_has_trait,
    assert_registry_contains,
    assert_command_succeeds,
    assert_command_fails,
)
from winterforge_dx_tools.testing.builders import FragBuilder

__all__ = [
    'FragFactory',
    'UserFactory',
    'RegistryFactory',
    'assert_frag_exists',
    'assert_frag_has_affinity',
    'assert_frag_has_trait',
    'assert_registry_contains',
    'assert_command_succeeds',
    'assert_command_fails',
    'FragBuilder',
]
