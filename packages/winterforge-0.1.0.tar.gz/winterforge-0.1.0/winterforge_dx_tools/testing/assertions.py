"""Custom assertions for WinterForge testing.

Provides clear, domain-specific assertions for testing WinterForge
applications.
"""
from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags import Frag
    from winterforge.frags.registries._base import RegistryBase
    from winterforge.plugins._protocols.storage import StorageBackend


def assert_frag_exists(
    frag_id: int,
    storage_backend: 'StorageBackend'
) -> None:
    """Assert that a Frag exists in storage.

    Args:
        frag_id: ID of the Frag
        storage_backend: Storage backend to check

    Raises:
        AssertionError: If Frag doesn't exist
    """
    # Query storage for the Frag
    results = storage_backend.query({'id': frag_id})

    if not results:
        raise AssertionError(f"Frag with ID {frag_id} not found in storage")


def assert_frag_has_affinity(frag: 'Frag', affinity: str) -> None:
    """Assert that a Frag has a specific affinity.

    Args:
        frag: Frag to check
        affinity: Expected affinity

    Raises:
        AssertionError: If Frag doesn't have the affinity
    """
    if not hasattr(frag, 'composition'):
        raise AssertionError(f"Frag has no composition attribute")

    if affinity not in frag.composition.affinities:
        raise AssertionError(
            f"Frag does not have affinity '{affinity}'. "
            f"Has: {frag.composition.affinities}"
        )


def assert_frag_has_trait(frag: 'Frag', trait: str) -> None:
    """Assert that a Frag has a specific trait.

    Args:
        frag: Frag to check
        trait: Expected trait

    Raises:
        AssertionError: If Frag doesn't have the trait
    """
    if not hasattr(frag, 'composition'):
        raise AssertionError(f"Frag has no composition attribute")

    if trait not in frag.composition.traits:
        raise AssertionError(
            f"Frag does not have trait '{trait}'. " f"Has: {frag.composition.traits}"
        )


def assert_registry_contains(
    registry: 'RegistryBase',
    frag: 'Frag'
) -> None:
    """Assert that a registry contains a Frag.

    Args:
        registry: Registry to check
        frag: Frag that should be in registry

    Raises:
        AssertionError: If registry doesn't contain the Frag
    """
    try:
        # Try to get the Frag from registry
        result = registry.get(frag.id)

        if result is None:
            raise AssertionError(
                f"Registry does not contain Frag with ID {frag.id}"
            )

    except (KeyError, AttributeError):
        raise AssertionError(
            f"Registry does not contain Frag with ID {frag.id}"
        )


def assert_command_succeeds(result: Any) -> None:
    """Assert that a CLI command succeeded.

    Args:
        result: Command result object

    Raises:
        AssertionError: If command failed
    """
    # Check exit code if available
    if hasattr(result, 'exit_code'):
        if result.exit_code != 0:
            output = getattr(result, 'output', '')
            raise AssertionError(
                f"Command failed with exit code {result.exit_code}. "
                f"Output: {output}"
            )

    # Check exception if available
    if hasattr(result, 'exception'):
        if result.exception is not None:
            raise AssertionError(
                f"Command raised exception: {result.exception}"
            )


def assert_command_fails(
    result: Any, expected_error: Optional[str] = None
) -> None:
    """Assert that a CLI command failed.

    Args:
        result: Command result object
        expected_error: Optional expected error message substring

    Raises:
        AssertionError: If command succeeded or wrong error
    """
    # Check exit code if available
    if hasattr(result, 'exit_code'):
        if result.exit_code == 0:
            raise AssertionError(
                "Command succeeded but was expected to fail"
            )

    # Check for exception
    failed = False

    if hasattr(result, 'exception'):
        if result.exception is not None:
            failed = True

            # Check expected error message if provided
            if expected_error:
                error_str = str(result.exception)
                if expected_error not in error_str:
                    raise AssertionError(
                        f"Command failed but error message doesn't "
                        f"contain '{expected_error}'. "
                        f"Got: {error_str}"
                    )

    # Check exit code as fallback
    elif hasattr(result, 'exit_code'):
        if result.exit_code != 0:
            failed = True

    if not failed:
        raise AssertionError("Command succeeded but was expected to fail")
