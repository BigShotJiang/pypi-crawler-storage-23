"""Factory pattern for creating test data.

Provides factories for creating Frags, users, and other WinterForge
objects with sensible defaults for testing.
"""
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from winterforge.frags.registries._base import RegistryBase

from winterforge.frags import Frag


class FragFactory:
    """Factory for creating test Frags."""

    _counter = 0

    @classmethod
    def create(cls, **kwargs) -> Frag:
        """Create a Frag with sensible defaults.

        Args:
            **kwargs: Override default values

        Returns:
            Created Frag instance
        """
        cls._counter += 1

        # Default values (excluding 'id' which Frag manages)
        defaults = {
            'affinities': ['test'],
            'traits': ['persistable'],
        }

        # Merge with provided kwargs
        data = {**defaults, **kwargs}

        # Separate Frag __init__ params from extra fields
        frag_params = {}
        extra_fields = {}

        for key, value in data.items():
            if key in ('affinities', 'traits'):
                frag_params[key] = value
            else:
                extra_fields[key] = value

        # Create Frag
        frag = Frag(**frag_params)

        # Set extra fields as attributes (skip properties without setters)
        for key, value in extra_fields.items():
            try:
                setattr(frag, key, value)
            except AttributeError:
                # Property without setter - skip it
                # These are typically managed by traits
                pass

        return frag

    @classmethod
    def create_batch(cls, count: int, **kwargs) -> List[Frag]:
        """Create multiple Frags.

        Args:
            count: Number of Frags to create
            **kwargs: Shared attributes for all Frags

        Returns:
            List of created Frags
        """
        return [cls.create(**kwargs) for _ in range(count)]

    @classmethod
    def build(cls, **kwargs) -> Dict[str, Any]:
        """Build Frag data without creating instance.

        Args:
            **kwargs: Frag attributes

        Returns:
            Dict of Frag data
        """
        # Don't include 'id' in build data (Frag manages it)
        defaults = {
            'affinities': ['test'],
            'traits': ['persistable'],
        }

        return {**defaults, **kwargs}

    @classmethod
    def reset_counter(cls) -> None:
        """Reset the ID counter (useful for test isolation)."""
        cls._counter = 0


class UserFactory(FragFactory):
    """Factory for user Frags."""

    @classmethod
    def create(cls, **kwargs) -> Frag:
        """Create a user Frag with sensible defaults.

        Args:
            **kwargs: Override default values

        Returns:
            Created user Frag
        """
        # Default user attributes
        defaults = {
            'affinities': ['user', 'authenticatable'],
            'traits': ['persistable', 'userable', 'authenticatable'],
            'username': f'user_{cls._counter + 1}',
            'email': f'user{cls._counter + 1}@example.com',
        }

        # Merge defaults with kwargs
        data = {**defaults, **kwargs}

        return super().create(**data)

    @classmethod
    def create_admin(cls, **kwargs) -> Frag:
        """Create an admin user Frag.

        Args:
            **kwargs: Override default values

        Returns:
            Created admin user Frag
        """
        defaults = {
            'affinities': ['user', 'admin', 'authenticatable'],
            'traits': [
                'persistable',
                'userable',
                'authenticatable',
                'authorizable',
            ],
            'username': f'admin_{cls._counter + 1}',
            'email': f'admin{cls._counter + 1}@example.com',
        }

        data = {**defaults, **kwargs}

        return super().create(**data)


class RegistryFactory:
    """Factory for creating test registries."""

    @classmethod
    def create(
        cls,
        storage_backend=None,
        frags: Optional[List[Frag]] = None
    ) -> 'RegistryBase':
        """Create a registry with test data.

        Args:
            storage_backend: Optional storage backend
            frags: Optional list of Frags to pre-populate

        Returns:
            Registry instance with test data
        """
        from winterforge.frags.registries.frag_registry import (
            FragRegistry,
        )

        # Create registry (composition can be None/empty dict)
        registry = FragRegistry(composition={})

        # Set storage if provided
        if storage_backend:
            registry._storage = storage_backend

        # Pre-populate with Frags if provided
        if frags:
            for frag in frags:
                if hasattr(registry, '_cache'):
                    registry._cache[frag.id] = frag

        return registry
