"""Fluent builders for test data.

Provides builder pattern for constructing complex test objects
with a readable, chainable API.
"""
from typing import Any, Dict, List
from winterforge.frags import Frag


class FragBuilder:
    """Fluent builder for test Frags.

    Example:
        frag = (FragBuilder()
            .with_affinity('user')
            .with_trait('authenticatable')
            .with_field('username', 'alice')
            .build())
    """

    def __init__(self):
        """Initialize builder with empty data."""
        self._data: Dict[str, Any] = {
            'affinities': [],
            'traits': [],
        }
        self._counter = 0

    def with_id(self, frag_id: int) -> 'FragBuilder':
        """Set the Frag ID.

        Note: Frag manages IDs internally, so this may not work as expected.

        Args:
            frag_id: Frag ID

        Returns:
            Self for chaining
        """
        # Note: This is stored but Frag may ignore it
        self._data['_requested_id'] = frag_id
        return self

    def with_affinity(self, affinity: str) -> 'FragBuilder':
        """Add an affinity.

        Args:
            affinity: Affinity to add

        Returns:
            Self for chaining
        """
        if 'affinities' not in self._data:
            self._data['affinities'] = []

        if affinity not in self._data['affinities']:
            self._data['affinities'].append(affinity)

        return self

    def with_affinities(self, affinities: List[str]) -> 'FragBuilder':
        """Add multiple affinities.

        Args:
            affinities: List of affinities to add

        Returns:
            Self for chaining
        """
        for affinity in affinities:
            self.with_affinity(affinity)

        return self

    def with_trait(self, trait: str) -> 'FragBuilder':
        """Add a trait.

        Args:
            trait: Trait to add

        Returns:
            Self for chaining
        """
        if 'traits' not in self._data:
            self._data['traits'] = []

        if trait not in self._data['traits']:
            self._data['traits'].append(trait)

        return self

    def with_traits(self, traits: List[str]) -> 'FragBuilder':
        """Add multiple traits.

        Args:
            traits: List of traits to add

        Returns:
            Self for chaining
        """
        for trait in traits:
            self.with_trait(trait)

        return self

    def with_field(self, name: str, value: Any) -> 'FragBuilder':
        """Add a field.

        Args:
            name: Field name
            value: Field value

        Returns:
            Self for chaining
        """
        self._data[name] = value
        return self

    def with_fields(self, fields: Dict[str, Any]) -> 'FragBuilder':
        """Add multiple fields.

        Args:
            fields: Dict of field names to values

        Returns:
            Self for chaining
        """
        for name, value in fields.items():
            self.with_field(name, value)

        return self

    def build(self) -> Frag:
        """Build the Frag.

        Returns:
            Constructed Frag instance
        """
        # Separate Frag __init__ params from extra fields
        frag_params = {}
        extra_fields = {}

        for key, value in self._data.items():
            if key in ('affinities', 'traits'):
                frag_params[key] = value
            elif key.startswith('_'):
                continue  # Skip internal fields
            else:
                extra_fields[key] = value

        # Create Frag
        frag = Frag(**frag_params)

        # Set extra fields as attributes (skip properties without setters)
        for key, value in extra_fields.items():
            try:
                setattr(frag, key, value)
            except AttributeError:
                # Property without setter - skip it
                pass

        return frag

    def build_dict(self) -> Dict[str, Any]:
        """Build Frag data as dict without creating instance.

        Returns:
            Dict of Frag data
        """
        # Return copy of data (excluding internal fields)
        data = dict(self._data)
        data.pop('_requested_id', None)
        return data


class UserFragBuilder(FragBuilder):
    """Fluent builder for user Frags with defaults."""

    def __init__(self):
        """Initialize with user defaults."""
        super().__init__()

        # Set user defaults
        self._data['affinities'] = ['user', 'authenticatable']
        self._data['traits'] = [
            'persistable',
            'userable',
            'authenticatable',
        ]

    def as_admin(self) -> 'UserFragBuilder':
        """Make this user an admin.

        Returns:
            Self for chaining
        """
        self.with_affinity('admin')
        self.with_trait('authorizable')
        return self

    def with_username(self, username: str) -> 'UserFragBuilder':
        """Set username.

        Args:
            username: Username value

        Returns:
            Self for chaining
        """
        return self.with_field('username', username)

    def with_email(self, email: str) -> 'UserFragBuilder':
        """Set email.

        Args:
            email: Email value

        Returns:
            Self for chaining
        """
        return self.with_field('email', email)
