"""Tests for canonical resolution pattern (Resolvable protocol)."""

import pytest
from winterforge.frags.manifest import Manifest
from winterforge.frags.base import Frag
from winterforge.plugins.repository import PluginRepository


class MockValidator:
    """Mock validator implementing Resolvable protocol."""

    def __init__(self, name: str, validates: str, should_succeed: bool = True):
        self.name = name
        self.validates = validates
        self.should_succeed = should_succeed

    def is_match(self, context: dict) -> bool:
        """Check if this validator matches the context."""
        return context.get('field') == self.validates

    def execute(self, context: dict, source=None) -> bool:
        """Execute validation and return success/failure."""
        return self.should_succeed


class MockHandler:
    """Mock handler implementing Resolvable protocol."""

    def __init__(self, name: str, handles: str):
        self.name = name
        self.handles = handles

    def is_match(self, context: dict) -> bool:
        """Check if this handler matches the context."""
        return context.get('type') == self.handles

    def execute(self, context: dict, source=None) -> bool:
        """Execute handler action."""
        context['handled_by'] = self.name
        return True


@pytest.mark.skip(reason="Resolvable protocol not yet implemented")
class TestCanonicalResolution:
    """Test canonical resolution pattern."""

    def test_repository_resolve_executes_first_match(self):
        """Test resolve() executes first match and removes from collection."""
        plugins = {
            'json': MockHandler('JSON', 'json'),
            'xml': MockHandler('XML', 'xml'),
            'yaml': MockHandler('YAML', 'yaml'),
        }
        repo = PluginRepository(plugins, ['json', 'xml', 'yaml'])

        context = {'type': 'xml', 'data': '<root/>'}
        result = repo.resolve(context)

        # Result should be repository without 'xml' handler
        assert len(result) == 2
        assert not result.has('xml')
        assert result.has('json')
        assert result.has('yaml')

        # Context should be modified by handler
        assert context['handled_by'] == 'XML'

    def test_repository_resolve_all_returns_failures(self):
        """Test resolve_all() returns only failures."""
        plugins = {
            'req': MockValidator('Required', 'name', should_succeed=True),
            'email': MockValidator('Email', 'email', should_succeed=False),
            'len': MockValidator('Length', 'name', should_succeed=True),
        }
        repo = PluginRepository(plugins, ['req', 'email', 'len'])

        context = {'field': 'email', 'value': 'invalid'}
        result = repo.resolve_all(context)

        # Result should contain only the failed validator
        assert len(result) == 1
        assert result.has('email')

    def test_repository_resolve_all_boolean_comparison_success(self):
        """Test resolve_all() == True when all succeed."""
        plugins = {
            'req': MockValidator('Required', 'name', should_succeed=True),
            'len': MockValidator('Length', 'name', should_succeed=True),
        }
        repo = PluginRepository(plugins, ['req', 'len'])

        context = {'field': 'name', 'value': 'Alice'}
        result = repo.resolve_all(context)

        # All succeeded - empty result
        assert result == True  # noqa: E712
        assert len(result) == 0

    def test_repository_resolve_all_boolean_comparison_failure(self):
        """Test resolve_all() == False when some fail."""
        plugins = {
            'req': MockValidator('Required', 'name', should_succeed=True),
            'email': MockValidator('Email', 'email', should_succeed=False),
        }
        repo = PluginRepository(plugins, ['req', 'email'])

        context = {'field': 'email', 'value': 'invalid'}
        result = repo.resolve_all(context)

        # Some failed - non-empty result
        assert result == False  # noqa: E712
        assert len(result) == 1

    def test_repository_resolve_all_empty_collection_is_success(self):
        """Test resolve_all() on empty collection returns empty (success)."""
        repo = PluginRepository({}, [])

        context = {'field': 'name', 'value': 'Alice'}
        result = repo.resolve_all(context)

        # Empty collection returns empty (== True)
        assert result == True  # noqa: E712
        assert len(result) == 0

    def test_manifest_resolve_executes_first_match(self):
        """Test Manifest resolve() executes first match."""
        # Create Frags with is_match/execute
        class ValidatorFrag(Frag):
            def __init__(self, name: str, validates: str, succeeds: bool):
                super().__init__()
                self._name = name
                self._validates = validates
                self._succeeds = succeeds

            def is_match(self, context: dict) -> bool:
                return context.get('field') == self._validates

            def execute(self, context: dict, source=None) -> bool:
                context['validated_by'] = self._name
                return self._succeeds

        frags = [
            ValidatorFrag('Required', 'name', True),
            ValidatorFrag('Email', 'email', True),
            ValidatorFrag('Length', 'name', True),
        ]
        manifest = Manifest(frags)

        context = {'field': 'email', 'value': 'alice@example.com'}
        result = manifest.resolve(context)

        # Result should be manifest without Email validator
        assert len(result) == 2
        assert context['validated_by'] == 'Email'

    def test_manifest_resolve_all_returns_failures(self):
        """Test Manifest resolve_all() returns only failures."""
        class ValidatorFrag(Frag):
            def __init__(self, name: str, validates: str, succeeds: bool):
                super().__init__()
                self._name = name
                self._validates = validates
                self._succeeds = succeeds

            def is_match(self, context: dict) -> bool:
                return context.get('field') == self._validates

            def execute(self, context: dict, source=None) -> bool:
                return self._succeeds

        frags = [
            ValidatorFrag('Required', 'name', True),
            ValidatorFrag('Email', 'name', False),  # Fails
            ValidatorFrag('Length', 'name', True),
        ]
        manifest = Manifest(frags)

        context = {'field': 'name', 'value': 'Alice'}
        result = manifest.resolve_all(context)

        # Result should contain only failed validator
        assert len(result) == 1
        assert result == False  # noqa: E712

    def test_manifest_resolve_all_boolean_comparison(self):
        """Test Manifest resolve_all() boolean comparison."""
        class AlwaysSucceeds(Frag):
            def is_match(self, context: dict) -> bool:
                return True

            def execute(self, context: dict, source=None) -> bool:
                return True

        frags = [AlwaysSucceeds(), AlwaysSucceeds()]
        manifest = Manifest(frags)

        context = {'field': 'test'}
        result = manifest.resolve_all(context)

        # All succeeded
        assert result == True  # noqa: E712
        assert len(result) == 0

    def test_resolve_with_source_parameter(self):
        """Test resolve() passes source parameter to execute()."""
        class SourceAware:
            def is_match(self, context: dict) -> bool:
                return True

            def execute(self, context: dict, source=None) -> bool:
                context['source'] = source
                return True

        plugins = {'aware': SourceAware()}
        repo = PluginRepository(plugins, ['aware'])

        context = {}
        source_frag = Frag()
        repo.resolve(context, source=source_frag)

        assert context['source'] == source_frag

    def test_repository_last_match_single(self):
        """Test last_match tracks single resolved item."""
        plugins = {
            'json': MockHandler('JSON', 'json'),
            'xml': MockHandler('XML', 'xml'),
            'yaml': MockHandler('YAML', 'yaml'),
        }
        repo = PluginRepository(plugins, ['json', 'xml', 'yaml'])
        context = {'type': 'xml'}
        result = repo.resolve(context)

        # Result should have last_match with the resolved handler
        assert result.last_match is not None
        assert len(result.last_match) == 1
        assert result.last_match.has('xml')

    def test_repository_last_match_all(self):
        """Test last_match tracks all succeeded items."""
        plugins = {
            'v1': MockValidator('V1', 'name', True),
            'v2': MockValidator('V2', 'name', False),
            'v3': MockValidator('V3', 'name', True),
        }
        repo = PluginRepository(plugins, ['v1', 'v2', 'v3'])

        context = {'field': 'name'}
        result = repo.resolve_all(context)

        # Result should have failures
        assert len(result) == 1
        assert result.has('v2')

        # last_match should have successes
        assert result.last_match is not None
        assert len(result.last_match) == 2
        assert result.last_match.has('v1')
        assert result.last_match.has('v3')

    def test_manifest_last_match_single(self):
        """Test Manifest last_match tracks single resolved item."""
        class Handler(Frag):
            def __init__(self, name: str):
                super().__init__()
                self.name = name

            def is_match(self, context: dict) -> bool:
                return True

            def execute(self, context: dict, source=None) -> bool:
                context['handled'] = self.name
                return True

        handlers = Manifest([Handler('A'), Handler('B')])
        context = {}
        result = handlers.resolve(context)

        # Should have last_match
        assert result.last_match is not None
        assert len(result.last_match) == 1

    def test_manifest_last_match_all(self):
        """Test Manifest last_match tracks all succeeded items."""
        class Validator(Frag):
            def __init__(self, name: str, succeeds: bool):
                super().__init__()
                self.name = name
                self.succeeds = succeeds

            def is_match(self, context: dict) -> bool:
                return True

            def execute(self, context: dict, source=None) -> bool:
                return self.succeeds

        validators = Manifest([
            Validator('A', True),
            Validator('B', False),
            Validator('C', True),
        ])
        context = {}
        result = validators.resolve_all(context)

        # Should have 1 failure
        assert len(result) == 1

        # Should have 2 successes in last_match
        assert result.last_match is not None
        assert len(result.last_match) == 2
