"""
Acceptance criteria validation tests.

These tests validate that all acceptance criteria from the spec are met.
"""

import pytest
from winterforge.plugins import (
    storage_backend,
    frag_trait,
    deriver,
    StorageManager,
    FragTraitManager,
    root,
)


class TestAcceptanceCriteria:
    """Validate acceptance criteria from specification."""

    def test_public_api_decorator_registration(self) -> None:
        """
        Acceptance: Public API works - decorator registration.

        from winterforge.plugins import storage_backend, StorageManager

        @storage_backend('test')
        class TestBackend:
            pass

        backend = StorageManager.get('test')
        assert backend is not None
        """
        StorageManager.reset()

        @storage_backend()
        @root('test-ac-1')
        class TestBackend:
            pass

        backend = StorageManager.get('test-ac-1')
        assert backend is not None
        assert isinstance(backend, TestBackend)

    def test_public_api_import_structure(self) -> None:
        """
        Acceptance: All components importable from top-level.
        """
        # Should be able to import everything from winterforge.plugins
        from winterforge.plugins import (
            PluginManagerBase,
            plugin,
            deriver,
            storage_backend,
            frag_trait,
            identity_resolver,
            StorageManager,
            FragTraitManager,
            IdentityResolverManager,
            StorageBackend,
            ReadOnlyStorage,
            FragTrait,
            IdentityResolverProvider,
            discover_plugins,
        )

        # All imports successful
        assert PluginManagerBase is not None
        assert plugin is not None
        assert deriver is not None
        assert StorageManager is not None
        assert ReadOnlyStorage is not None

    def test_plugin_derivatives_work(self) -> None:
        """
        Acceptance: Plugin derivatives work.

        from winterforge.plugins import deriver, StorageManager

        @deriver('winterforge.storage_backends')
        def test_deriver():
            yield {'id': 'derived', 'class': object}

        StorageManager.derive_plugins()
        assert StorageManager.has('derived')
        """
        StorageManager.reset()

        class DerivedClass:
            pass

        @deriver('winterforge.storage_backends')
        def test_deriver_ac():
            yield {'id': 'derived_ac', 'class': DerivedClass}

        StorageManager.derive_plugins()
        assert StorageManager.has('derived_ac')

        instance = StorageManager.get('derived_ac')
        assert isinstance(instance, DerivedClass)

    def test_lazy_instantiation_with_caching(self) -> None:
        """Acceptance: Lazy instantiation with caching works."""
        StorageManager.reset()

        instantiation_count = 0

        @storage_backend()
        @root('cached')
        class CachedBackend:
            def __init__(self):
                nonlocal instantiation_count
                instantiation_count += 1

        # Not instantiated yet
        assert instantiation_count == 0

        # First access
        instance1 = StorageManager.get('cached')
        assert instantiation_count == 1

        # Second access - cached
        instance2 = StorageManager.get('cached')
        assert instantiation_count == 1
        assert instance1 is instance2

    def test_metadata_support(self) -> None:
        """Acceptance: Plugin metadata works."""
        StorageManager.reset()

        @storage_backend(description='Test', version='1.0')
        @root('with-meta')
        class MetaBackend:
            pass

        metadata = StorageManager.get_metadata('with-meta')
        assert metadata['description'] == 'Test'
        assert metadata['version'] == '1.0'

    def test_manager_methods_work(self) -> None:
        """Acceptance: All manager methods work correctly."""
        StorageManager.reset()

        @storage_backend()
        @root('method-test')
        class MethodTestBackend:
            pass

        # has()
        assert StorageManager.has('method-test')

        # get()
        backend = StorageManager.get('method-test')
        assert backend is not None

        # get_definitions()
        defs = StorageManager.get_definitions()
        assert 'method-test' in defs

        # get_metadata()
        meta = StorageManager.get_metadata('method-test')
        assert isinstance(meta, dict)

        # clear_cache()
        instance1 = StorageManager.get('method-test')
        StorageManager.clear_cache()
        instance2 = StorageManager.get('method-test')
        assert instance1 is not instance2

        # reset()
        StorageManager.reset()
        assert not StorageManager.has('method-test')

    def test_trait_manager_get_trait_fields(self) -> None:
        """Acceptance: FragTraitManager.get_trait_fields() works."""
        FragTraitManager.reset()

        class MockField:
            pass

        @frag_trait()
        @root('fields-test')
        class FieldsTrait:
            # Use private attributes (new convention)
            _field1 = MockField()
            _field2 = MockField()

        fields = FragTraitManager.get_trait_fields('fields-test')
        assert '_field1' in fields
        assert '_field2' in fields

    def test_custom_instantiation_args(self) -> None:
        """Acceptance: Custom instantiation args work (not cached)."""
        StorageManager.reset()

        @storage_backend()
        @root('custom-args')
        class CustomArgsBackend:
            def __init__(self, value=None):
                self.value = value

        instance1 = StorageManager.get('custom-args', value='a')
        instance2 = StorageManager.get('custom-args', value='b')

        assert instance1.value == 'a'
        assert instance2.value == 'b'
        assert instance1 is not instance2

    def test_all_plugin_types(self) -> None:
        """Acceptance: All plugin types work."""
        from winterforge.plugins import (
            storage_backend,
            frag_trait,
            identity_resolver,
            StorageManager,
            FragTraitManager,
            IdentityResolverManager,
            root,
        )

        StorageManager.reset()
        FragTraitManager.reset()
        IdentityResolverManager.reset()

        @storage_backend()
        @root('storage-test')
        class StorageTest:
            pass

        @frag_trait()
        @root('trait-test')
        class TraitTest:
            pass

        @identity_resolver()
        @root('resolver-test')
        class ResolverTest:
            pass

        assert StorageManager.has('storage-test')
        assert FragTraitManager.has('trait-test')
        assert IdentityResolverManager.has('resolver-test')

    def test_error_handling(self) -> None:
        """Acceptance: Proper error handling."""
        StorageManager.reset()

        # Duplicate registration is now idempotent (silently skips)
        @storage_backend()
        @root('dup-test')
        class DupTest:
            pass

        # Second registration should silently succeed (idempotent)
        StorageManager.register('dup-test', DupTest)
        assert StorageManager.has('dup-test')

        # Plugin not found
        with pytest.raises(KeyError, match="not found"):
            StorageManager.get('nonexistent')

        # Trait not found
        with pytest.raises(KeyError, match="not found"):
            FragTraitManager.get_trait_fields('nonexistent')


class TestIntegrationScenarios:
    """Test real-world integration scenarios."""

    def test_complete_workflow(self) -> None:
        """Test complete plugin workflow from registration to use."""
        StorageManager.reset()

        # 1. Register a plugin
        @storage_backend(description='Test workflow')
        @root('workflow-test')
        class WorkflowBackend:
            def __init__(self):
                self.saved_items = []

            def save(self, item):
                self.saved_items.append(item)

        # 2. Check registration
        assert StorageManager.has('workflow-test')

        # 3. Get instance
        backend = StorageManager.get('workflow-test')

        # 4. Use plugin
        backend.save('item1')
        backend.save('item2')

        # 5. Verify caching
        backend2 = StorageManager.get('workflow-test')
        assert backend is backend2
        assert len(backend2.saved_items) == 2

    def test_derivative_workflow(self) -> None:
        """Test complete derivative workflow."""
        StorageManager.reset()

        # 1. Define base class
        class DatabaseBackend:
            def __init__(self, config=None):
                self.config = config

        # 2. Register deriver
        @deriver('winterforge.storage_backends')
        def db_deriver():
            configs = {'primary': {'host': 'localhost'}, 'backup': {'host': 'remote'}}
            for name, config in configs.items():
                yield {
                    'id': f'db_{name}',
                    'class': DatabaseBackend,
                    'metadata': {'config': config}
                }

        # 3. Derive plugins
        StorageManager.derive_plugins()

        # 4. Verify derived plugins exist
        assert StorageManager.has('db_primary')
        assert StorageManager.has('db_backup')

        # 5. Use derived plugins
        primary = StorageManager.get('db_primary')
        backup = StorageManager.get('db_backup')

        assert isinstance(primary, DatabaseBackend)
        assert isinstance(backup, DatabaseBackend)
