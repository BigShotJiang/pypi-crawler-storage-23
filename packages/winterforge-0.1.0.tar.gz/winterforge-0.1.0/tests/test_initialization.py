"""Tests for Winterforge initialization and shutdown."""

import pytest
import os
from winterforge import async_initialize, async_shutdown, initialize, shutdown
from winterforge.plugins.storage.manager import StorageManager
from winterforge.frags.traits._manager import FragTraitManager
from winterforge.plugins.identity.manager import IdentityResolverManager


class TestAsyncInitialization:
    """Test async initialization functions."""

    @pytest.mark.asyncio
    async def test_async_initialize_calls_startup(self) -> None:
        """Test async_initialize calls startup_all on all managers."""
        # Reset all managers to clean state
        StorageManager.reset()
        FragTraitManager.reset()
        IdentityResolverManager.reset()

        # Register lifecycle-aware plugins
        startup_events = []

        class LifecycleStorage:
            async def startup(self) -> None:
                startup_events.append('storage')

            async def shutdown(self) -> None:
                pass

        class LifecycleTrait:
            async def startup(self) -> None:
                startup_events.append('trait')

            async def shutdown(self) -> None:
                pass

        StorageManager.register('lifecycle_storage', LifecycleStorage)
        FragTraitManager.register('lifecycle_trait', LifecycleTrait)

        # Call startup directly (not full initialize which includes discovery/derivers)
        await StorageManager.startup_all()
        await FragTraitManager.startup_all()

        # Verify startup was called
        assert 'storage' in startup_events
        assert 'trait' in startup_events

        # Cleanup
        StorageManager.reset()
        FragTraitManager.reset()

    @pytest.mark.asyncio
    async def test_async_shutdown_calls_shutdown(self) -> None:
        """Test async_shutdown calls shutdown_all on all managers."""
        # Reset to clean state
        StorageManager.reset()
        FragTraitManager.reset()

        shutdown_events = []

        class LifecycleStorage:
            async def startup(self) -> None:
                pass

            async def shutdown(self) -> None:
                shutdown_events.append('storage')

        class LifecycleTrait:
            async def startup(self) -> None:
                pass

            async def shutdown(self) -> None:
                shutdown_events.append('trait')

        StorageManager.register('lifecycle_storage', LifecycleStorage)
        FragTraitManager.register('lifecycle_trait', LifecycleTrait)

        # Instantiate plugins (required for shutdown to call them)
        StorageManager.get('lifecycle_storage')
        FragTraitManager.get('lifecycle_trait')

        # Call shutdown directly
        await StorageManager.shutdown_all()
        await FragTraitManager.shutdown_all()

        # Verify shutdown was called
        assert 'storage' in shutdown_events
        assert 'trait' in shutdown_events

        # Cleanup
        StorageManager.reset()
        FragTraitManager.reset()

    @pytest.mark.asyncio
    async def test_full_async_lifecycle(self) -> None:
        """Test complete async initialization and shutdown cycle."""
        # Reset to clean state
        IdentityResolverManager.reset()

        lifecycle_events = []

        class FullLifecyclePlugin:
            async def startup(self) -> None:
                lifecycle_events.append('startup')

            async def shutdown(self) -> None:
                lifecycle_events.append('shutdown')

        IdentityResolverManager.register('full_lifecycle', FullLifecyclePlugin)

        # Full lifecycle using manager methods directly
        await IdentityResolverManager.startup_all()
        await IdentityResolverManager.shutdown_all()

        assert lifecycle_events == ['startup', 'shutdown']

        # Cleanup
        IdentityResolverManager.reset()


class TestSynchronousWrappers:
    """Test synchronous wrapper functions."""

    @pytest.mark.asyncio
    async def test_async_initialize_and_shutdown_integration(self) -> None:
        """Test async_initialize and async_shutdown work together."""
        # Set JWT secret to avoid auto-generation warnings in tests
        os.environ['WINTERFORGE_JWT_SECRET'] = 'test-secret-key-for-integration-tests'

        # Reset all managers
        StorageManager.reset()
        FragTraitManager.reset()
        IdentityResolverManager.reset()

        lifecycle_events = []

        class IntegrationPlugin:
            async def startup(self) -> None:
                lifecycle_events.append('startup')

            async def shutdown(self) -> None:
                lifecycle_events.append('shutdown')

        StorageManager.register('integration', IntegrationPlugin)

        # Full async lifecycle
        await async_initialize()
        await async_shutdown()

        assert lifecycle_events == ['startup', 'shutdown']

        # Cleanup
        StorageManager.reset()
        FragTraitManager.reset()
        IdentityResolverManager.reset()

        # Clean up environment variable
        if 'WINTERFORGE_JWT_SECRET' in os.environ:
            del os.environ['WINTERFORGE_JWT_SECRET']

    def test_initialize_wrapper(self) -> None:
        """Test initialize() synchronous wrapper works."""
        # Reset all managers
        StorageManager.reset()
        FragTraitManager.reset()
        IdentityResolverManager.reset()

        startup_called = []

        class InitPlugin:
            async def startup(self) -> None:
                startup_called.append(True)

            async def shutdown(self) -> None:
                pass

        StorageManager.register('init_plugin', InitPlugin)

        # Should not raise
        initialize()

        assert len(startup_called) == 1

        # Cleanup
        StorageManager.reset()
        FragTraitManager.reset()
        IdentityResolverManager.reset()

    def test_shutdown_wrapper(self) -> None:
        """Test shutdown() synchronous wrapper works."""
        # Reset to clean state
        StorageManager.reset()

        # Register and instantiate a lifecycle plugin
        shutdown_called = []

        class SyncLifecyclePlugin:
            async def startup(self) -> None:
                pass

            async def shutdown(self) -> None:
                shutdown_called.append(True)

        StorageManager.register('sync_lifecycle', SyncLifecyclePlugin)
        StorageManager.get('sync_lifecycle')

        # Should not raise
        shutdown()

        assert len(shutdown_called) == 1

        # Cleanup
        StorageManager.reset()
