"""Integration tests for complete User System workflow.

Tests the full Phase 4 User System implementation including:
- User CRUD operations
- Role management
- Permission management
- Session management
- All CLI commands
"""

import pytest
from winterforge.frags.registries.user_registry import UserRegistry
from winterforge.frags.registries.role_registry import RoleRegistry
from winterforge.frags.registries.permission_registry import PermissionRegistry
from winterforge.frags.registries.session_registry import SessionRegistry
from winterforge.plugins import StorageManager, discover_plugins
from winterforge.frags.traits.persistable import set_storage


@pytest.fixture(autouse=True)
def setup_storage():
    """Ensure storage is initialized for all tests."""
    discover_plugins()
    storage = StorageManager.get('sqlite')
    set_storage(storage)
    yield
    # Clear all data between tests
    storage.conn.execute("DELETE FROM frags")
    storage.conn.commit()
    # Reset Frag ID counter
    from winterforge.frags.base import Frag
    import itertools
    Frag._id_counter = itertools.count(1)


@pytest.mark.asyncio
async def test_complete_user_lifecycle():
    """Test complete user creation, role assignment, and permission checking."""

    # Create permission
    perms = PermissionRegistry()
    delete_perm = await perms.create('user.delete')
    assert delete_perm.title == 'user.delete'

    # Create role with permission
    roles = RoleRegistry()
    admin_role = await roles.create('admin')
    await roles.add_permission('admin', 'user.delete')

    # Verify permission was added
    admin_role = await roles.get('admin')
    role_perms = await admin_role.get_permissions()
    assert len(role_perms) == 1
    assert role_perms[0].title == 'user.delete'

    # Create user
    users = UserRegistry()
    user = await users.create('testuser', 'test@example.com', 'password123')
    assert user.username == 'testuser'
    assert user.email == 'test@example.com'
    assert not user.is_email_verified()

    # Assign role to user
    await users.add_role('testuser', 'admin')
    user = await users.get('testuser')
    assert await user.has_role('admin')
    assert await user.has_permission('user.delete')

    # Test user operations
    await users.verify_email('testuser')
    user = await users.get('testuser')
    assert user.is_email_verified()

    # Test password update
    await users.set_password('testuser', 'newpassword')
    user = await users.get('testuser')
    assert user.verify_password('newpassword')

    # Test email update
    await users.set_email('testuser', 'newemail@example.com')
    user = await users.get('testuser')
    assert user.email == 'newemail@example.com'
    assert not user.is_email_verified()  # Should reset on email change

    # Cleanup
    await users.delete_user('testuser')
    await roles.delete_role('admin')
    await perms.delete_permission('user.delete')


@pytest.mark.asyncio
async def test_user_locking():
    """Test user account locking and unlocking."""

    users = UserRegistry()
    user = await users.create('locktest', 'lock@example.com', 'password123')

    # Initially not locked
    assert not user.is_locked()

    # Lock user
    await users.lock('locktest', duration=900)
    user = await users.get('locktest')
    assert user.is_locked()

    # Unlock user
    await users.unlock('locktest')
    user = await users.get('locktest')
    assert not user.is_locked()

    # Cleanup
    await users.delete_user('locktest')


@pytest.mark.asyncio
async def test_role_permission_management():
    """Test adding and removing permissions from roles."""

    perm_registry = PermissionRegistry()
    perm1 = await perm_registry.create('post.create')
    perm2 = await perm_registry.create('post.delete')

    roles = RoleRegistry()
    editor_role = await roles.create('editor')

    # Add permissions
    await roles.add_permission('editor', 'post.create')
    await roles.add_permission('editor', 'post.delete')

    editor_role = await roles.get('editor')
    perms = await editor_role.get_permissions()
    assert len(perms) == 2

    # Remove permission
    await roles.remove_permission('editor', 'post.delete')
    editor_role = await roles.get('editor')
    perms = await editor_role.get_permissions()
    assert len(perms) == 1
    assert perms[0].title == 'post.create'

    # Cleanup
    await roles.delete_role('editor')
    await perm_registry.delete_permission('post.create')
    await perm_registry.delete_permission('post.delete')


@pytest.mark.asyncio
async def test_multiple_roles_permission_merging():
    """Test that user permissions are merged from all assigned roles."""

    # Create permissions
    perms = PermissionRegistry()
    await perms.create('user.create')
    await perms.create('user.delete')
    await perms.create('post.create')

    # Create roles with different permissions
    roles = RoleRegistry()
    await roles.create('user_admin')
    await roles.create('content_admin')

    await roles.add_permission('user_admin', 'user.create')
    await roles.add_permission('user_admin', 'user.delete')
    await roles.add_permission('content_admin', 'post.create')

    # Create user with both roles
    users = UserRegistry()
    user = await users.create('multiuser', 'multi@example.com', 'password123')
    await users.add_role('multiuser', 'user_admin')
    await users.add_role('multiuser', 'content_admin')

    # Verify user has all permissions from both roles
    user = await users.get('multiuser')
    assert await user.has_role('user_admin')
    assert await user.has_role('content_admin')
    assert await user.has_permission('user.create')
    assert await user.has_permission('user.delete')
    assert await user.has_permission('post.create')

    # Remove one role
    await users.remove_role('multiuser', 'user_admin')
    user = await users.get('multiuser')
    assert not await user.has_role('user_admin')
    assert await user.has_role('content_admin')
    assert not await user.has_permission('user.create')
    assert not await user.has_permission('user.delete')
    assert await user.has_permission('post.create')

    # Cleanup
    await users.delete_user('multiuser')
    await roles.delete_role('user_admin')
    await roles.delete_role('content_admin')
    await perms.delete_permission('user.create')
    await perms.delete_permission('user.delete')
    await perms.delete_permission('post.create')


@pytest.mark.asyncio
async def test_user_filtering():
    """Test user registry filtering methods."""

    # Create role and permissions
    roles = RoleRegistry()
    await roles.create('verified_role')

    # Create users with different attributes
    users = UserRegistry()
    await users.create('user1', 'user1@example.com', 'pass', verified=True)
    await users.create('user2', 'user2@example.com', 'pass', verified=False)
    await users.create('user3', 'user3@example.com', 'pass', role=['verified_role'], verified=True)

    # Test verified_only filter
    verified_users = await users.verified_only()
    all_verified = await verified_users.all()
    assert len(all_verified) == 2

    # Test with_role filter
    role_users = await users.with_role('verified_role')
    all_role_users = await role_users.all()
    assert len(all_role_users) == 1
    assert all_role_users[0].username == 'user3'

    # Cleanup
    await users.delete_user('user1')
    await users.delete_user('user2')
    await users.delete_user('user3')
    await roles.delete_role('verified_role')


@pytest.mark.asyncio
async def test_session_workflow():
    """Test session creation, verification, and invalidation."""

    # Create user
    users = UserRegistry()
    user = await users.create('sessiontest', 'session@example.com', 'password123')

    # Create session
    sessions = SessionRegistry()
    token = await sessions.create(user.username)
    assert token

    # Verify session
    session_data = await sessions.verify(token)
    assert session_data is not None
    assert session_data['user_id'] == user.id

    # List user sessions
    user_sessions = await sessions.list_sessions(user.username)
    # In CLI context this returns CLIResult, programmatically returns list

    # Invalidate session
    success = await sessions.invalidate(token)
    assert success

    # Verify session is invalid
    session_data = await sessions.verify(token)
    assert session_data is None

    # Cleanup
    await users.delete_user('sessiontest')


@pytest.mark.asyncio
async def test_list_operations():
    """Test list operations for all registries."""

    # Create test data
    perms = PermissionRegistry()
    await perms.create('test.perm1')
    await perms.create('test.perm2')

    roles = RoleRegistry()
    await roles.create('test_role')

    users = UserRegistry()
    await users.create('testlist1', 'list1@example.com', 'pass')
    await users.create('testlist2', 'list2@example.com', 'pass')

    # Test list operations (programmatic mode)
    all_perms = await perms.list_permissions()
    assert len(all_perms) >= 2

    all_roles = await roles.list_roles()
    assert len(all_roles) >= 1

    all_users = await users.list_users()
    assert len(all_users) >= 2

    # Cleanup
    await users.delete_user('testlist1')
    await users.delete_user('testlist2')
    await roles.delete_role('test_role')
    await perms.delete_permission('test.perm1')
    await perms.delete_permission('test.perm2')


@pytest.mark.asyncio
async def test_identity_resolution():
    """Test user identity resolution by username, email, and ID."""

    users = UserRegistry()
    user = await users.create('resolvetest', 'resolve@example.com', 'password123')

    # Resolve by username
    by_username = await users.get('resolvetest')
    assert by_username is not None
    assert by_username.id == user.id

    # Resolve by email
    by_email = await users.get('resolve@example.com')
    assert by_email is not None
    assert by_email.id == user.id

    # Resolve by ID
    by_id = await users.get(user.id)
    assert by_id is not None
    assert by_id.username == 'resolvetest'

    # Cleanup
    await users.delete_user('resolvetest')
