"""
End-to-end integration tests for Phase 3.

Tests all components working together:
- Frags with traits
- Storage backends
- Lifecycle management
"""

import pytest
import tempfile
import os
from pathlib import Path
from datetime import datetime, UTC

from winterforge.frags import Frag
from winterforge.plugins import (
    StorageManager,
    FragTraitManager,
    LifecycleManager,
    reset_lifecycle_manager,
)


@pytest.fixture
def temp_paths():
    """Create temporary file paths."""
    temp_dir = Path(tempfile.mkdtemp())
    yield {
        'dir': temp_dir,
        'db': temp_dir / 'test.db',
        'config_yaml': temp_dir / 'config.yaml',
        'config_db': temp_dir / 'config.db',
    }
    # Cleanup
    import shutil
    if temp_dir.exists():
        shutil.rmtree(temp_dir)


@pytest.mark.asyncio
async def test_full_stack_integration(temp_paths):
    """Test full stack: Storage + Traits + Frags."""
    # Setup plugins

    # Create storage
    storage = StorageManager.get('sqlite', db_path=str(temp_paths['db']))

    # Create Frag with multiple traits
    now = datetime.now(UTC).isoformat()
    frag = Frag(
        affinities=['content', 'test'],
        traits=['fieldable', 'titled', 'timestamped', 'sluggable']
    )

    # Use trait methods
    frag.set_title('Integration Test') \
        .set_subtitle('Testing all components') \
        .generate_slug('Integration Test') \
        .set_created_time(now) \
        .set_updated_time(now)

    # Save
    await storage.save(frag)

    # Load back
    loaded = await storage.load(frag.id)

    # Verify everything persisted
    assert loaded.title == 'Integration Test'
    assert loaded.subtitle == 'Testing all components'
    assert loaded.slug == 'integration-test'
    assert loaded.created_on == now
    assert 'content' in loaded.affinities
    assert 'titled' in loaded.traits


@pytest.mark.asyncio
async def test_multi_frag_composition(temp_paths):
    """Test composition: related Frags via aliases."""

    storage = StorageManager.get('sqlite', db_path=str(temp_paths['db']))

    # Create parent Frag (author)
    author = Frag(
        affinities=['author'],
        traits=['fieldable', 'titled']
    )
    author.set_title('Test Author')
    await storage.save(author)

    # Create child Frags (posts) linked via aliases
    post1 = Frag(
        affinities=['post'],
        traits=['fieldable', 'titled'],
        aliases={'author': author.id}
    )
    post1.set_title('Post 1')
    await storage.save(post1)

    post2 = Frag(
        affinities=['post'],
        traits=['fieldable', 'titled'],
        aliases={'author': author.id}
    )
    post2.set_title('Post 2')
    await storage.save(post2)

    # Query by alias
    author_posts = await storage.query()\
        .affinity('post')\
        .execute()
    # TODO: Add .alias('author', author.id) when alias querying is implemented

    assert len(author_posts) == 2
    assert {p.title for p in author_posts} == {'Post 1', 'Post 2'}


@pytest.mark.asyncio
async def test_trait_methods_and_validation(temp_paths):
    """Test trait methods with validation."""

    frag = Frag(traits=['fieldable', 'titled', 'timestamped', 'sluggable'])

    # Titled trait validation
    with pytest.raises(ValueError, match="Title must be a string"):
        frag.set_title(123)

    # Timestamp validation
    with pytest.raises(ValueError, match="Invalid ISO 8601 timestamp"):
        frag.set_created_time("not-a-timestamp")

    # Slug validation
    with pytest.raises(ValueError, match="Invalid slug format"):
        frag.set_slug("Invalid Slug!")

    # Valid operations
    now = datetime.now(UTC).isoformat()
    frag.set_title("Valid Title").set_created_time(now).set_slug("valid-slug")

    assert frag.has_title()
    assert frag.is_created()
    assert frag.has_slug()


@pytest.mark.asyncio
async def test_fluent_interface(temp_paths):
    """Test fluent interface (method chaining)."""

    frag = Frag(traits=['fieldable', 'titled', 'timestamped', 'sluggable'])

    # Chain setter methods
    now = datetime.now(UTC).isoformat()
    result = frag.set_title("Chained") \
                 .set_subtitle("Methods") \
                 .generate_slug("Chained") \
                 .set_created_time(now)

    # Should return self
    assert result is frag

    # All values set
    assert frag.title == "Chained"
    assert frag.subtitle == "Methods"
    assert frag.slug == "chained"
    assert frag.created_on == now


@pytest.mark.asyncio
async def test_is_new_tracking(temp_paths):
    """Test is_new() through save/load cycle (persistable trait only)."""

    from winterforge.frags.traits.persistable import set_storage

    storage = StorageManager.get('sqlite', db_path=str(temp_paths['db']))
    set_storage(storage)

    # Frag with persistable trait has is_new() tracking
    frag = Frag(affinities=['test'], traits=['fieldable', 'titled', 'persistable'])

    # New Frag starts as new (not yet in storage)
    assert await frag.is_new()

    # Save to storage
    await frag.save()

    # No longer new (exists in storage)
    assert not await frag.is_new()

    # Load from storage - also not new
    loaded = await storage.load(frag.id)
    assert not await loaded.is_new()

    # Modifications don't affect is_new status
    frag.set_title("Modified Title")
    frag.add_affinity('modified')
    assert not await frag.is_new()  # Still exists in storage


@pytest.mark.asyncio
async def test_lifecycle_integration():
    """Test lifecycle management integration."""
    reset_lifecycle_manager()
    lifecycle = LifecycleManager()

    class MockPlugin:
        def __init__(self):
            self.started = False
            self.stopped = False

        async def startup(self):
            self.started = True

        async def shutdown(self):
            self.stopped = True

    plugin = MockPlugin()
    lifecycle.register(plugin)

    await lifecycle.startup_all()
    assert plugin.started

    await lifecycle.shutdown_all()
    assert plugin.stopped


@pytest.mark.asyncio
async def test_complex_query_patterns(temp_paths):
    """Test complex querying with multiple filters."""

    storage = StorageManager.get('sqlite', db_path=str(temp_paths['db']))

    # Create diverse Frags
    frag1 = Frag(
        affinities=['post', 'published'],
        traits=['fieldable', 'titled']
    )
    frag1.set_title('Published Post')
    await storage.save(frag1)

    frag2 = Frag(
        affinities=['post', 'draft'],
        traits=['fieldable', 'titled']
    )
    frag2.set_title('Draft Post')
    await storage.save(frag2)

    frag3 = Frag(
        affinities=['page', 'published'],
        traits=['fieldable', 'titled']
    )
    frag3.set_title('Published Page')
    await storage.save(frag3)

    # Query: published posts only
    published_posts = await storage.query()\
        .affinity('post')\
        .affinity('published')\
        .execute()
    assert len(published_posts) == 1
    assert published_posts[0].title == 'Published Post'

    # Query: all published content
    published = await storage.query().affinity('published').execute()
    assert len(published) == 2

    # Query: all posts
    posts = await storage.query().affinity('post').execute()
    assert len(posts) == 2


@pytest.mark.asyncio
async def test_property_access_compatibility(temp_paths):
    """Test readonly properties work alongside fluent setter methods."""

    frag = Frag(traits=['fieldable', 'titled', 'timestamped', 'sluggable'])

    # Fluent setter methods for writing
    frag.set_title("Property Title").set_slug("property-slug")

    # Getter method access
    assert frag.title == "Property Title"
    assert frag.slug == "property-slug"

    # Readonly property access for reading
    assert frag.title == "Property Title"
    assert frag.slug == "property-slug"
