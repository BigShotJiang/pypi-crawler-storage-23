class CrunchException(Exception):
    pass
