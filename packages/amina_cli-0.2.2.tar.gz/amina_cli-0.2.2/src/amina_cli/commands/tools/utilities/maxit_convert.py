"""MAXIT Format Converter tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

METADATA = {
    "name": "maxit-convert",
    "display_name": "MAXIT Converter",
    "category": "utilities",
    "description": "Convert between PDB and mmCIF structure file formats",
    "modal_function_name": "maxit_convert_worker",
    "modal_app_name": "maxit-convert-api",
    "status": "available",
    "outputs": {
        "pdb_filepath": "Converted PDB file (for mmcif_to_pdb)",
        "cif_filepath": "Converted mmCIF file (for pdb_to_mmcif)",
    },
}

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("maxit-convert")
    def run_maxit_convert(
        pdb: Optional[Path] = typer.Option(
            None,
            "--pdb",
            "-p",
            help="Path to PDB file to convert to mmCIF",
            exists=True,
        ),
        cif: Optional[Path] = typer.Option(
            None,
            "--cif",
            "-c",
            help="Path to mmCIF file to convert to PDB",
            exists=True,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required unless --background)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: uses input filename)",
        ),
    ):
        """
        Convert between PDB and mmCIF structure file formats using MAXIT.

        MAXIT is the official RCSB tool used by the Protein Data Bank for
        format conversion. Provide either --pdb (to convert PDB to mmCIF)
        or --cif (to convert mmCIF to PDB).

        Examples:
            amina run maxit-convert --pdb ./1A2J.pdb -o ./output/
            amina run maxit-convert --cif ./1A2J.cif -o ./output/
            amina run maxit-convert --pdb ./structure.pdb -j converted -o ./output/
        """
        # Validate required options
        if output is None and not background:
            console.print("[red]Error:[/red] --output / -o is required (unless using --background)")
            raise typer.Exit(1)

        # Validate mutual exclusivity
        if not pdb and not cif:
            console.print("[red]Error:[/red] Provide either --pdb or --cif input file")
            raise typer.Exit(1)

        if pdb and cif:
            console.print("[red]Error:[/red] Provide only one of --pdb or --cif, not both")
            raise typer.Exit(1)

        # Build params based on input type
        params = {}

        if pdb:
            # PDB to mmCIF conversion
            params["pdb_content"] = pdb.read_text()
            params["input_filename"] = pdb.stem
            params["conversion_direction"] = "pdb_to_mmcif"
        else:
            # mmCIF to PDB conversion
            params["cif_content"] = cif.read_text()
            params["input_filename"] = cif.stem
            params["conversion_direction"] = "mmcif_to_pdb"

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("maxit-convert", params, output, background=background)
