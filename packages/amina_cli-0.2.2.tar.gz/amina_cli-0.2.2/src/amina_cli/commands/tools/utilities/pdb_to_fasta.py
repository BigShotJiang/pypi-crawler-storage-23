"""PDB to FASTA tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

METADATA = {
    "name": "pdb-to-fasta",
    "display_name": "PDB to FASTA",
    "category": "utilities",
    "description": "Convert PDB structure files to FASTA sequence format",
    "modal_function_name": "pdb_to_fasta_worker",
    "modal_app_name": "pdb-to-fasta-api",
    "status": "available",
    "outputs": {
        "fasta_filepath": "FASTA file with extracted sequences",
    },
}

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("pdb-to-fasta")
    def run_pdb_to_fasta(
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to PDB file to convert",
            exists=True,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required unless --background)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: uses input filename)",
        ),
    ):
        """
        Convert PDB structure files to FASTA sequence format.

        Extracts protein sequences from all chains in a PDB file.
        Handles non-canonical amino acids and multi-model structures.

        Examples:
            amina run pdb-to-fasta --pdb ./1A2J.pdb -o ./output/
            amina run pdb-to-fasta --pdb ./structure.pdb -j myjob -o ./output/
        """
        # Validate required options
        if output is None and not background:
            console.print("[red]Error:[/red] --output / -o is required (unless using --background)")
            raise typer.Exit(1)

        # Read PDB file content
        pdb_content = pdb.read_text()

        params = {
            "pdb_content": pdb_content,
            "pdb_filename": pdb.name,  # e.g., "1A2J.pdb"
        }

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("pdb-to-fasta", params, output, background=background)
