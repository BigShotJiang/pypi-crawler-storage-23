"""Molecule Size Calculator tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

METADATA = {
    "name": "mol-size-calculator",
    "display_name": "Molecule Size Calculator",
    "category": "utilities",
    "description": "Calculate molecule dimensions using bounding box method",
    "modal_function_name": "mol_size_calculator_worker",
    "modal_app_name": "mol-size-calculator-api",
    "status": "available",
    "outputs": {
        "json_filepath": "JSON file with molecule dimensions and volume",
    },
}

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("mol-size-calculator")
    def run_mol_size_calculator(
        input_file: Path = typer.Option(
            ...,
            "--input",
            "-i",
            help="Path to molecule file (PDB, SDF, MOL, XYZ)",
            exists=True,
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required unless --background)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
    ):
        """
        Calculate molecule dimensions using bounding box method.

        Returns box center, size, min/max coordinates, and volume in Angstroms.
        Supports PDB, SDF, MOL, and XYZ file formats.

        Examples:
            amina run mol-size-calculator --input ./ligand.sdf -o ./results/
            amina run mol-size-calculator --input ./protein.pdb -j myjob -o ./results/
            amina run mol-size-calculator -i ./molecule.mol -o ./results/
        """
        # Validate required options
        if output is None and not background:
            console.print("[red]Error:[/red] --output / -o is required (unless using --background)")
            raise typer.Exit(1)

        # Read file content
        mol_content = input_file.read_text()

        params = {
            "mol_content": mol_content,
            "mol_filename": input_file.name,  # e.g., "ligand.sdf"
        }

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("mol-size-calculator", params, output, background=background)
