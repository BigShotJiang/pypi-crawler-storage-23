"""Initialize Claude Code skills for Amina."""

import io
import zipfile
from pathlib import Path

import httpx
import typer
from rich.console import Console
from rich.panel import Panel

app = typer.Typer(no_args_is_help=True)
console = Console()

SKILLS_REPO = "AminoAnalytica/amina-skills"
SKILLS_BRANCH = "main"
GITHUB_ZIPBALL_URL = f"https://github.com/{SKILLS_REPO}/archive/refs/heads/{SKILLS_BRANCH}.zip"


@app.command("claude-skills")
def init_claude_skills():
    """Download and install Claude Code skills for Amina.

    Installs skills to .claude/skills/ in the current directory,
    enabling Claude Code to assist with protein engineering tasks.

    Always updates to the latest skills from the repository.
    """
    skills_dir = Path.cwd() / ".claude" / "skills"

    console.print("[bold]Downloading Amina skills for Claude Code...[/bold]\n")

    try:
        # Download zipball from GitHub
        with console.status("[dim]Fetching from GitHub...[/dim]"):
            response = httpx.get(GITHUB_ZIPBALL_URL, follow_redirects=True, timeout=60)
            response.raise_for_status()

        # Extract skills
        with console.status("[dim]Extracting skills...[/dim]"):
            skills_dir.mkdir(parents=True, exist_ok=True)

            with zipfile.ZipFile(io.BytesIO(response.content)) as zf:
                # Find the claude-skills/ directory in the archive
                # Archive structure: amina-skills-main/claude-skills/...
                prefix = None
                for name in zf.namelist():
                    if "/claude-skills/" in name:
                        prefix = name.split("/claude-skills/")[0] + "/claude-skills/"
                        break

                if not prefix:
                    console.print("[red]Error: Could not find skills in archive[/red]")
                    raise typer.Exit(1)

                # Extract each skill
                skill_names = set()
                for name in zf.namelist():
                    if name.startswith(prefix) and name != prefix:
                        # Get relative path within skills/
                        rel_path = name[len(prefix) :]
                        if rel_path:
                            skill_name = rel_path.split("/")[0]
                            skill_names.add(skill_name)

                            # Extract file
                            target_path = skills_dir / rel_path
                            if name.endswith("/"):
                                target_path.mkdir(parents=True, exist_ok=True)
                            else:
                                target_path.parent.mkdir(parents=True, exist_ok=True)
                                target_path.write_bytes(zf.read(name))

        # Print success
        console.print("[green]Installed skills:[/green]")
        for skill in sorted(skill_names):
            if skill:  # Skip empty strings
                console.print(f"  [dim]•[/dim] {skill}")

        console.print(
            Panel(
                "Run [bold]claude[/bold] from this directory to use Amina skills.",
                title="Done",
                border_style="green",
            )
        )

    except httpx.HTTPError as e:
        console.print(
            Panel(
                f"[red]Failed to download skills:[/red] {e}\n\nCheck your internet connection and try again.",
                title="Error",
                border_style="red",
            )
        )
        raise typer.Exit(1)
