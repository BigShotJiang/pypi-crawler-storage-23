"""
Tool execution commands for Amina CLI.

The 'run' command is the main way to execute computational biology tools.
Tool commands are auto-registered from the tools/ folder.

Commands:
    amina run esmfold --sequence "MKFL..."
    amina run pdb-cleaner --pdb ./structure.pdb
"""

import typer
from rich.console import Console

# Auto-register all tool commands from tools/ folder
from amina_cli.commands.tools import register_all_tools, get_all_tools

app = typer.Typer(no_args_is_help=True)
console = Console()

register_all_tools(app)


@app.callback(invoke_without_command=True)
def run_callback(ctx: typer.Context):
    """
    Run computational biology tools.

    Discover tools and parameters:
        amina tools                  # List all tools
        amina tools <name>           # View tool parameters
        amina run <tool> --help      # View CLI options
    """
    if ctx.invoked_subcommand is None:
        # Show available tools
        console.print("[bold]Available tools:[/bold]\n")
        tools = get_all_tools()
        for tool in tools:
            name = tool["name"]
            desc = tool.get("description", "")
            status = tool.get("status", "available")
            if status == "pending":
                console.print(f"  [dim]{name:20}[/dim] [dim]{desc} (coming soon)[/dim]")
            else:
                console.print(f"  [cyan]{name:20}[/cyan] {desc}")
        console.print("\nUse: amina run <tool> --help")
