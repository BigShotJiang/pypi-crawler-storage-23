def add(a, b):
    """
    Return the sum of two numbers.
    """
    return a + b