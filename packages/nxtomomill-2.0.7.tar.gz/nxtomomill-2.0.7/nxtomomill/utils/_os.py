from __future__ import annotations

import os
from tomoscan.utils.io import filter_esrf_mounting_points


def abspath(path: str):
    """
    File absolute path, removing 'esrf' mounting point.
    Those mounting point must be remove because they might be differente from one computer to the other
    """
    return filter_esrf_mounting_points(os.path.abspath(path))
