import click
import os
import shutil
from pathlib import Path
import questionary

# --- KONFIGURASI I18N ---
TEMPLATES_FILES = ["ssh.md", "git.md", "node.md", "nvm.md", "angular.md", "gh.md"]

LANGUAGES = {
    "id": "Bahasa Indonesia 🇮🇩",
    "en": "English 🇺🇸",
    "es": "Español 🇪🇸",
    "ja": "日本語 🇯🇵",
    "zh": "中文 🇨🇳"
}

# Kamus pesan sistem untuk setiap bahasa
I18N = {
    "id": {
        "menu_prompt": "Apa yang ingin Anda lakukan dengan sendok?",
        "menu_init": "init",
        "menu_list": "list",
        "menu_clean": "clean",
        "menu_help": "help",
        "menu_about": "about",
        "menu_exit": "exit",
        "select_lang_prompt": "Pilih bahasa untuk dokumentasi:",
        "folder_created": "📁 Folder {path} berhasil dibuat.",
        "folder_exists": "ℹ️ Folder {path} sudah ada.",
        "using_lang": "🌐 Menggunakan bahasa: {lang}",
        "file_copied": "✅ Berhasil menyendok: {file}",
        "file_exists_skipping": "⏭️ File {file} sudah ada, melewati.",
        "file_overwritten": "🔄 File {file} diperbarui ke bahasa {lang}.",
        "done_msg": "\n🥄 Selesai! Selamat mendokumentasikan proyek Anda.",
        "list_title": "\n📋 Daftar Template Dokumentasi (sendok):",
        "total": "Total: {count} template tersedia.\n",
        "clean_confirm": "Apakah Anda yakin ingin menghapus folder {path} beserta isinya?",
        "clean_yes": "Yes (Hapus Sekarang)",
        "clean_no": "No (Batalkan)",
        "clean_success": "🗑️ Folder {path} berhasil dihapus.",
        "clean_cancel": "❌ Pembatalan penghapusan.",
        "clean_not_found": "ℹ️ Folder docs tidak ditemukan.",
        "template_not_found": "⚠️ Template {file} tidak ditemukan di '{lang}', membuat file kosong.",
        "about_msg": "\n🥄 sendok (Scaffolding Engine for Nimble Documentation Organizer Kit)\n👤 Pembuat: marhaendev\n🌐 Website: hasanaskari.com\n📧 Email  : marhaendev@gmail.com\n✨ Simpel. Cepat. Menyendok dokumen dengan mahir!",
        "farewell": "Sampai jumpa! 🥄",
        "desc_ssh.md": "Panduan Setup SSH",
        "desc_git.md": "Panduan Lengkap Git",
        "desc_node.md": "Panduan Node.js & NPM",
        "desc_nvm.md": "Panduan NVM untuk Windows",
        "desc_angular.md": "Panduan Angular CLI",
        "desc_gh.md": "Panduan GitHub CLI",
        "help_usage": "Penggunaan: python -m sendok [COMMAND] [BAHASA]",
        "help_desc": "Alat bantu pembuatan dokumentasi proyek otomasi.",
        "help_commands_title": "Perintah yang Tersedia:",
        "help_cmd_init": "Inisialisasi dokumen di folder docs/",
        "help_cmd_list": "Lihat daftar template yang tersedia",
        "help_cmd_clean": "Bersihkan/hapus folder dokumentasi",
        "help_cmd_about": "Informasi pengembang aplikasi",
        "help_cmd_bum": "Backup Manager: Cadangkan proyek ke .bum",
        "help_cmd_id": "Jalankan menu dalam Bahasa Indonesia",
        "help_cmd_en": "Jalankan menu dalam Bahasa Inggris",
        "help_cmd_es": "Jalankan menu dalam Bahasa Spanyol",
        "help_cmd_ja": "Jalankan menu dalam Bahasa Jepang",
        "help_cmd_zh": "Jalankan menu dalam Bahasa Mandarin",
        "help_footer": "\nGunakan 'python -m sendok [COMMAND] --help' untuk bantuan lebih lanjut.",
        "menu_docs": "docs (Kelola Dokumentasi)",
        "menu_create": "create",
        "menu_bum": "bum (Backup Manager)",
        "bum_confirm": "Apakah Anda yakin ingin mencadangkan folder ini ke {path}?",
        "bum_yes": "Yes (Cadangkan Sekarang)",
        "bum_no": "No (Batalkan)",
        "bum_start": "📦 Memulai pencadangan proyek...",
        "bum_success": "✅ Berhasil! Cadangan disimpan di: {path}",
        "bum_cancel": "❌ Pencadangan dibatalkan.",
        "help_cmd_c": "Bersihkan layar terminal (clear/cls)",
        "help_cmd_l": "Jalankan 'npm start'",
        "help_cmd_ll": "Jalankan 'npm run dev'",
        "help_cmd_lll": "Jalankan 'npm run build'",
        "help_cmd_p": "Tampilkan informasi IP (ipconfig/ifconfig)",
        "help_cmd_gg": "Jalankan Git GUI Helper (Interaktif)",
        "help_cmd_reload": "Refresh terminal & VS Code (r)"
    },
    "es": {
        "menu_prompt": "¿Qué te gustaría hacer con sendok?",
        "menu_init": "init",
        "menu_list": "list",
        "menu_clean": "clean",
        "menu_help": "help",
        "menu_about": "about",
        "menu_exit": "exit",
        "select_lang_prompt": "Selecciona el idioma de la documentación:",
        "folder_created": "📁 Carpeta {path} creada con éxito.",
        "folder_exists": "ℹ️ La carpeta {path} ya existe.",
        "using_lang": "🌐 Usando idioma: {lang}",
        "file_copied": "✅ Documento copiado con éxito: {file}",
        "file_exists_skipping": "⏭️ El archivo {file} ya existe, omitiendo.",
        "file_overwritten": "🔄 Archivo {file} actualizado al idioma {lang}.",
        "done_msg": "\n🥄 ¡Hecho! Disfruta documentando tu proyecto.",
        "list_title": "\n📋 Lista de Plantillas de Documentación (sendok):",
        "total": "Total: {count} plantillas disponibles.\n",
        "clean_confirm": "¿Estás seguro de que deseas eliminar la carpeta {path} dan todo su contenido?",
        "clean_yes": "Sí (Eliminar ahora)",
        "clean_no": "No (Cancelar)",
        "clean_success": "🗑️ Carpeta {path} eliminada con éxito.",
        "clean_cancel": "❌ Eliminación cancelada.",
        "clean_not_found": "ℹ️ No se encontró la carpeta docs.",
        "template_not_found": "⚠️ Plantilla {file} no encontrada en '{lang}', creando archivo vacío.",
        "about_msg": "\n🥄 sendok (Scaffolding Engine for Nimble Documentation Organizer Kit)\n👤 Autor: marhaendev\n🌐 Website: hasanaskari.com\n📧 Email : marhaendev@gmail.com\n✨ ¡Simple. Rápido. Documentando como un profesional!",
        "farewell": "¡Hasta luego! 🥄",
        "desc_ssh.md": "Guía de configuración de SSH",
        "desc_git.md": "Guía completa de Git",
        "desc_node.md": "Guía de Node.js y NPM",
        "desc_nvm.md": "Guía de NVM para Windows",
        "desc_angular.md": "Guía de Angular CLI",
        "desc_gh.md": "Guía de GitHub CLI",
        "help_usage": "Uso: python -m sendok [COMMAND] [IDIOMA]",
        "help_desc": "Herramienta de automatización para la creación de documentación de proyectos.",
        "help_commands_title": "Comandos Disponibles:",
        "help_cmd_init": "Inicializar documentos en la carpeta docs/",
        "help_cmd_list": "Ver lista de plantillas disponibles",
        "help_cmd_clean": "Limpiar/eliminar carpeta de documentación",
        "help_cmd_about": "Informasi pengembang aplikasi",
        "help_cmd_bum": "Backup Manager: Respaldar proyecto en .bum",
        "help_cmd_id": "Ejecutar menú en indonesio",
        "help_cmd_en": "Ejecutar menú en inglés",
        "help_cmd_es": "Ejecutar menú en español",
        "help_cmd_ja": "Ejecutar menú en japonés",
        "help_cmd_zh": "Ejecutar menú en chino",
        "help_footer": "\nUsa 'python -m sendok [COMMAND] --help' para más información.",
        "menu_docs": "docs (Gestionar Documentación)",
        "menu_create": "create",
        "menu_bum": "bum (Backup Manager)",
        "bum_confirm": "¿Estás seguro de que deseas respaldar esta carpeta en {path}?",
        "bum_yes": "Sí (Respaldar ahora)",
        "bum_no": "No (Cancelar)",
        "bum_start": "📦 Iniciando respaldo del proyecto...",
        "bum_success": "✅ ¡Éxito! Respaldo guardado en: {path}",
        "bum_cancel": "❌ Respaldo cancelado.",
        "help_cmd_c": "Limpiar pantalla de la terminal",
        "help_cmd_l": "Ejecutar 'npm start'",
        "help_cmd_ll": "Ejecutar 'npm run dev'",
        "help_cmd_lll": "Ejecutar 'npm run build'",
        "help_cmd_p": "Mostrar información de IP (ipconfig/ifconfig)",
        "help_cmd_gg": "Ejecutar Git GUI Helper (Interactivo)",
        "help_cmd_reload": "Refrescar terminal y VS Code (r)"
    },
    "ja": {
        "menu_prompt": "sendokで何をしますか？",
        "menu_init": "init",
        "menu_list": "list",
        "menu_clean": "clean",
        "menu_help": "help",
        "menu_about": "about",
        "menu_exit": "exit",
        "select_lang_prompt": "ドキュメントの言語を選択してください：",
        "folder_created": "📁 フォルダ {path} が正常に作成されました。",
        "folder_exists": "ℹ️ フォルダ {path} は既に存在します。",
        "using_lang": "🌐 使用言語: {lang}",
        "file_copied": "✅ ドキュメントのコピーに成功しました: {file}",
        "file_exists_skipping": "⏭️ ファイル {file} は既に存在するため、スキップします。",
        "file_overwritten": "🔄 ファイル {file} を {lang} 言語に更新しました。",
        "done_msg": "\n🥄 完了！プロジェクトのドキュメント作成をお楽しみください。",
        "list_title": "\n📋 利用可能なドキュメントテンプレート（sendok）:",
        "total": "合計: {count} 個のテンプレートが利用可能です。\n",
        "clean_confirm": "フォルダ {path} とその全内容を削除してもよろしいですか？",
        "clean_yes": "はい（今すぐ削除）",
        "clean_no": "いいえ（キャンセル）",
        "clean_success": "🗑️ フォルダ {path} が正常に削除されました。",
        "clean_cancel": "❌ 削除がキャンセルされました。",
        "clean_not_found": "ℹ️ docsフォルダが見つかりません。",
        "template_not_found": "⚠️ '{lang}' にテンプレート {file} が見つかりません。空の文件を作成します。",
        "about_msg": "\n🥄 sendok (Scaffolding Engine for Nimble Documentation Organizer Kit)\n👤 作成者: marhaendev\n🌐 Website: hasanaskari.com\n📧 メール: marhaendev@gmail.com\n✨ シンプル。スピーディ。プロのようにドキュメントを作成！",
        "farewell": "またお会いしましょう！ 🥄",
        "desc_ssh.md": "SSHセットアップガイド",
        "desc_git.md": "Git完全ガイド",
        "desc_node.md": "Node.js & NPMガイド",
        "desc_nvm.md": "Windows用NVMガイド",
        "desc_angular.md": "Angular CLIガイド",
        "desc_gh.md": "GitHub CLIガイド",
        "help_usage": "使用法: python -m sendok [COMMAND] [言語]",
        "help_desc": "プロジェクトドキュメント作成自動化ツール。",
        "help_commands_title": "利用可能なコマンド:",
        "help_cmd_init": "docs/ フォルダにドキュメントを初期化する",
        "help_cmd_list": "利用可能なテンプレート一覧を表示",
        "help_cmd_clean": "ドキュメントフォルダをクリーンアップ/削除",
        "help_cmd_about": "Informasi pengembang aplikasi",
        "help_cmd_bum": "Backup Manager: プロジェクトを .bum にバックアップ",
        "help_cmd_id": "インドネシア語でメニューを実行",
        "help_cmd_en": "英語でメニューを実行",
        "help_cmd_es": "スペイン語でメニューを実行",
        "help_cmd_ja": "日本語でメニューを実行",
        "help_cmd_zh": "中国語でメニューを実行",
        "help_footer": "\n詳細は 'python -m sendok [COMMAND] --help' を使用してください。",
        "menu_docs": "docs (ドキュメント管理)",
        "menu_create": "create",
        "menu_bum": "bum (バックアップマネージャー)",
        "bum_confirm": "このフォルダを {path} にバックアップしてもよろしいですか？",
        "bum_yes": "はい（今すぐバックアップ）",
        "bum_no": "いいえ（キャンセル）",
        "bum_start": "📦 プロジェクトのバックアップを開始しています...",
        "bum_success": "✅ 成功！バックアップが保存されました: {path}",
        "bum_cancel": "❌ バックアップがキャンセルされました。",
        "help_cmd_c": "ターミナル画面をクリアする",
        "help_cmd_l": "'npm start' を実行する",
        "help_cmd_ll": "'npm run dev' を実行する",
        "help_cmd_lll": "'npm run build' を実行する",
        "help_cmd_p": "IP情報を表示する (ipconfig/ifconfig)",
        "help_cmd_gg": "Git GUI ヘルパーを実行する (対話型)",
        "help_cmd_reload": "ターミナルと VS Code を更新 (r)"
    },
    "zh": {
        "menu_prompt": "你想用 sendok 做什么？",
        "menu_init": "init",
        "menu_list": "list",
        "menu_clean": "clean",
        "menu_help": "help",
        "menu_about": "about",
        "menu_exit": "exit",
        "select_lang_prompt": "选择文档语言：",
        "folder_created": "📁 文件夹 {path} 创建成功。",
        "folder_exists": "ℹ️ 文件夹 {path} 已存在。",
        "using_lang": "🌐 使用语言: {lang}",
        "file_copied": "✅ 成功复制文档: {file}",
        "file_exists_skipping": "⏭️ 文件 {file} 已存在，跳过。",
        "file_overwritten": "🔄 文件 {file} 已更新为 {lang} 语言。",
        "done_msg": "\n🥄 完成！祝你文档编写愉快。",
        "list_title": "\n📋 可用文档模板 (sendok):",
        "total": "总计: {count} 个可用模板。\n",
        "clean_confirm": "你确定要删除文件夹 {path} 及其所有内容吗？",
        "clean_yes": "是（立即删除）",
        "clean_no": "否（取消）",
        "clean_success": "🗑️ 文件夹 {path} 已成功删除。",
        "clean_cancel": "❌ 删除已取消。",
        "clean_not_found": "ℹ️ 未找到 docs 文件夹。",
        "template_not_found": "⚠️ 在 '{lang}' 中未找到模板 {file}，正创建一个空文件。",
        "about_msg": "\n🥄 sendok (Scaffolding Engine for Nimble Documentation Organizer Kit)\n👤 作者: marhaendev\n🌐 网站: hasanaskari.com\n邮箱: marhaendev@gmail.com\n✨ 简单。快速。像专业人士一样编写文档！",
        "farewell": "再见！ 🥄",
        "desc_ssh.md": "SSH 设置指南",
        "desc_git.md": "Git 完整指南",
        "desc_node.md": "Node.js & NPM 指南",
        "desc_nvm.md": "Windows 版 NVM 指南",
        "desc_angular.md": "Angular CLI 指南",
        "desc_gh.md": "GitHub CLI 指南",
        "help_usage": "用法: python -m sendok [COMMAND] [语言]",
        "help_desc": "项目文档支架自动化工具。",
        "help_commands_title": "可用命令:",
        "help_cmd_init": "在 docs/ 文件夹中初始化文档",
        "help_cmd_list": "查看可用模板列表",
        "help_cmd_clean": "清理/删除文档文件夹",
        "help_cmd_about": "查看应用开发人员信息",
        "help_cmd_bum": "Backup Manager: 将项目备份到 .bum",
        "help_cmd_id": "运行印尼语菜单",
        "help_cmd_en": "运行英语菜单",
        "help_cmd_es": "运行西班牙语菜单",
        "help_cmd_ja": "运行日语菜单",
        "help_cmd_zh": "运行中文菜单",
        "help_footer": "\n使用 'python -m sendok [COMMAND] --help' 获取更多信息。",
        "menu_docs": "docs (管理文档)",
        "menu_create": "create",
        "menu_bum": "bum (备份管理器)",
        "bum_confirm": "你确定要将此文件夹备份到 {path} 吗？",
        "bum_yes": "是（立即备份）",
        "bum_no": "否（取消）",
        "bum_start": "📦 正在开始项目备份...",
        "bum_success": "✅ 成功！备份已存储在: {path}",
        "bum_cancel": "❌ 备份已取消。",
        "help_cmd_c": "清屏",
        "help_cmd_l": "运行 'npm start'",
        "help_cmd_ll": "运行 'npm run dev'",
        "help_cmd_lll": "运行 'npm run build'",
        "help_cmd_p": "显示 IP 信息 (ipconfig/ifconfig)",
        "help_cmd_gg": "运行 Git GUI 助手 (交互式)",
        "help_cmd_reload": "刷新终端和 VS Code (r)"
    },
    "en": {
        "menu_prompt": "What would you like to do with sendok?",
        "menu_init": "init",
        "menu_list": "list",
        "menu_clean": "clean",
        "menu_help": "help",
        "menu_about": "about",
        "menu_exit": "exit",
        "select_lang_prompt": "Select documentation language:",
        "folder_created": "📁 Folder {path} successfully created.",
        "folder_exists": "ℹ️ Folder {path} already exists.",
        "using_lang": "🌐 Using language: {lang}",
        "file_copied": "✅ Successfully spooned: {file}",
        "file_exists_skipping": "⏭️ File {file} already exists, skipping.",
        "file_overwritten": "🔄 File {file} updated to {lang}.",
        "done_msg": "\n🥄 Done! Happy documenting your project.",
        "list_title": "\n📋 Available Documentation Templates (sendok):",
        "total": "Total: {count} templates available.\n",
        "clean_confirm": "Are you sure you want to delete {path} and all its contents?",
        "clean_yes": "Yes (Delete Now)",
        "clean_no": "No (Cancel)",
        "clean_success": "🗑️ Folder {path} successfully deleted.",
        "clean_cancel": "❌ Deletion cancelled.",
        "clean_not_found": "ℹ️ Folder docs not found.",
        "template_not_found": "⚠️ Template {file} not found in '{lang}', creating empty file.",
        "about_msg": "\n🥄 sendok (Scaffolding Engine for Nimble Documentation Organizer Kit)\n👤 Author: marhaendev\n🌐 Website: hasanaskari.com\n📧 Email : marhaendev@gmail.com\n✨ Simple. Fast. Spooning documents like a pro!",
        "farewell": "See you later! 🥄",
        "desc_ssh.md": "SSH Setup Guide",
        "desc_git.md": "Git Complete Guide",
        "desc_node.md": "Node.js & NPM Guide",
        "desc_nvm.md": "NVM for Windows Guide",
        "desc_angular.md": "Angular CLI Guide",
        "desc_gh.md": "GitHub CLI Guide",
        "help_usage": "Usage: python -m sendok [COMMAND] [LANGUAGE]",
        "help_desc": "Project documentation scaffolding automation tool.",
        "help_commands_title": "Available Commands:",
        "help_cmd_init": "Initialize documents in docs/ folder",
        "help_cmd_list": "List available documentation templates",
        "help_cmd_clean": "Clean/delete documentation folder",
        "help_cmd_about": "Application developer information",
        "help_cmd_bum": "Backup Manager: Backup project to .bum",
        "help_cmd_id": "Run interactive menu in Indonesian",
        "help_cmd_en": "Run interactive menu in English",
        "help_cmd_es": "Run interactive menu in Spanish",
        "help_cmd_ja": "Run interactive menu in Japanese",
        "help_cmd_zh": "Run interactive menu in Chinese",
        "help_footer": "\nUse 'python -m sendok [COMMAND] --help' for more info.",
        "menu_docs": "docs (Manage Documentation)",
        "menu_create": "create",
        "menu_bum": "bum (Backup Manager)",
        "bum_confirm": "Are you sure you want to backup this folder to {path}?",
        "bum_yes": "Yes (Backup Now)",
        "bum_no": "No (Cancel)",
        "bum_start": "📦 Starting project backup...",
        "bum_success": "✅ Success! Backup stored at: {path}",
        "bum_cancel": "❌ Backup cancelled.",
        "help_cmd_c": "Clear terminal screen",
        "help_cmd_l": "Run 'npm start'",
        "help_cmd_ll": "Run 'npm run dev'",
        "help_cmd_lll": "Run 'npm run build'",
        "help_cmd_p": "Show IP information (ipconfig/ifconfig)",
        "help_cmd_gg": "Run Git GUI Helper (Interactive)",
        "help_cmd_reload": "Refresh terminal & VS Code (r)"
    }
}

def _t(key, ui_lang='en', **kwargs):
    """Fungsi pembantu untuk mengambil pesan i18n. Default ke 'en'."""
    lang_dict = I18N.get(ui_lang, I18N['en'])
    # Pastikan fallback ke 'en' jika key tidak ada di 'id'
    text = lang_dict.get(key, I18N['en'].get(key, f"Missing key: {key}"))
    return text.format(**kwargs)

def show_custom_help(lang='en'):
    """Menampilkan bantuan Click yang sudah diterjemahkan."""
    click.echo(f"\n{_t('help_usage', lang)}")
    click.echo(f"\n{_t('help_desc', lang)}")
    click.echo(f"\n{_t('help_commands_title', lang)}")
    click.echo(f"  {'r':16} : {_t('help_cmd_reload', lang)}")
    click.echo(f"  {'gg':16} : {_t('help_cmd_gg', lang)}")
    click.echo(f"  {'p':16} : {_t('help_cmd_p', lang)}")
    click.echo(f"  {'c':16} : {_t('help_cmd_c', lang)}")
    click.echo(f"  {'l':16} : {_t('help_cmd_l', lang)}")
    click.echo(f"  {'ll':16} : {_t('help_cmd_ll', lang)}")
    click.echo(f"  {'lll':16} : {_t('help_cmd_lll', lang)}")
    click.echo(f"  {'bum':16} : {_t('help_cmd_bum', lang)}")
    click.echo(f"  {'sendok id':16} : {_t('help_cmd_id', lang)}")
    click.echo(f"  {'sendok en':16} : {_t('help_cmd_en', lang)}")
    click.echo(f"  {'sendok es':16} : {_t('help_cmd_es', lang)}")
    click.echo(f"  {'sendok ja':16} : {_t('help_cmd_ja', lang)}")
    click.echo(f"  {'sendok zh':16} : {_t('help_cmd_zh', lang)}")
    click.echo(f"  {'sendok init':16} : {_t('help_cmd_init', lang)}")
    click.echo(f"  {'sendok list':16} : {_t('help_cmd_list', lang)}")
    click.echo(f"  {'sendok clean':16} : {_t('help_cmd_clean', lang)}")
    click.echo(_t('help_footer', lang))
    click.echo(_t('about_msg', lang))

# --- CLI IMPLEMENTATION ---

@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """sendok (Scaffolding Engine for Nimble Documentation Organizer Kit) CLI Tool."""
    # Deteksi bahasa dari subcommand jika ada, default adalah 'en'
    lang = 'en'
    if ctx.invoked_subcommand in LANGUAGES:
        lang = ctx.invoked_subcommand

    if ctx.invoked_subcommand is None:
        _run_interactive_menu(ctx, lang)

@cli.command(name='gg')
def git_gui_command():
    """Git GUI Helper: Manage your git repository interactively."""
    from . import git_gui
    git_gui.main_menu()

def git_gui_shorthand():
    """Shorthand 'gg' to run Git GUI directly."""
    from sendok import git_gui
    git_gui.main_menu()

@cli.command(name='reload')
def reload_command():
    """Refresh terminal and VS Code UI."""
    clear_screen()
    # Try to trigger VS Code refresh by running 'code .'
    try:
        subprocess.run("code .", shell=True, check=False)
        click.secho("🥄 Spoon Reload: Success! Terminal cleaned and VS Code refreshed.", fg="green")
    except Exception:
        click.secho("🥄 Spoon Reload: Terminal cleaned.", fg="green")

def reload_shorthand():
    """Shorthand 'r' to reload."""
    reload_command.callback()

@cli.command(name="list")
@click.option('--lang', default='en', help='Language for terminal output')
def list_templates(lang):
    """View available documentation templates."""
    click.echo(_t("list_title", lang))
    click.echo("-" * 45)
    for filename in TEMPLATES_FILES:
        description = _t(f"desc_{filename}", lang)
        click.echo(f"🔹 {filename:12} : {description}")
    click.echo("-" * 45)
    click.echo(_t("total", lang, count=len(TEMPLATES_FILES)))

@cli.command()
@click.argument('lang', default='en', type=click.Choice(['id', 'en', 'es', 'ja', 'zh']))
@click.option('--force', is_flag=True, help='Overwrite existing files')
def init(lang, force):
    """Create docs/ folder and spoon documentation templates."""
    docs_dir = Path("docs")
    
    if not docs_dir.exists():
        docs_dir.mkdir()
        click.echo(_t("folder_created", lang, path=docs_dir))
    else:
        click.echo(_t("folder_exists", lang, path=docs_dir))

    # Robust template path detection
    base_dir = Path(__file__).resolve().parent
    template_src_dir = base_dir / "templates" / lang

    if not template_src_dir.exists():
        # Fallback check for different installation structures
        alt_path = base_dir / "sendok" / "templates" / lang
        if alt_path.exists():
            template_src_dir = alt_path
        else:
            click.echo(f"❌ Error: {lang} templates not found at {template_src_dir}")
            click.echo("Please try reinstalling the package: pip install --force-reinstall sendok")
            return

    click.echo(_t("using_lang", lang, lang=LANGUAGES.get(lang)))

    for filename in TEMPLATES_FILES:
        target_file = docs_dir / filename
        source_file = template_src_dir / filename
        
        if not target_file.exists() or force or True: # Always update/sync content
            if source_file.exists():
                shutil.copy(source_file, target_file)
                if not target_file.exists():
                    click.echo(_t("file_copied", lang, file=filename))
                else:
                    click.echo(_t("file_overwritten", lang, file=filename, lang=lang))
            else:
                with open(target_file, "w", encoding="utf-8") as f:
                    description = _t(f"desc_{filename}", lang)
                    f.write(f"# {description}\n")
                click.echo(_t("template_not_found", lang, file=filename, lang=lang))

    click.echo(_t("done_msg", lang))

@cli.command()
@click.option('--lang', default='en', help='Language for terminal output')
def about(lang):
    """Show information about the author."""
    click.echo(_t("about_msg", lang))

@cli.command()
@click.option('--lang', default='en', help='Language for terminal output')
def bum(lang):
    """Backup Manager: Backup current folder to .bum."""
    from datetime import datetime
    import os
    
    # Ambil nama folder saat ini
    current_folder_name = Path(os.getcwd()).name
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    
    bum_dir = Path(".bum")
    # Format baru: namafolder-YYYYMMDD-HHMMSS
    backup_path = bum_dir / f"{current_folder_name}-{timestamp}"
    
    confirmation = questionary.select(
        _t("bum_confirm", lang, path=bum_dir),
        choices=[
            _t("bum_no", lang),
            _t("bum_yes", lang)
        ],
        default=_t("bum_no", lang)
    ).ask()

    if confirmation == _t("bum_yes", lang):
        if not bum_dir.exists():
            bum_dir.mkdir()
        
        click.echo(_t("bum_start", lang))
        
        # Logika Ignore
        ignore_list = [
            "node_modules", ".git", "venv", ".venv", 
            "dist", "build", "__pycache__", ".bum",
            ".pytest_cache", ".mypy_cache"
        ]
        
        def ignore_func(directory, contents):
            return [c for c in contents if c in ignore_list]

        shutil.copytree(".", backup_path, ignore=ignore_func, dirs_exist_ok=True)
        click.echo(_t("bum_success", lang, path=backup_path))
    else:
        click.echo(_t("bum_cancel", lang))

@cli.command(name='p')
def ip_info():
    """Show IP information."""
    os.system('ipconfig' if os.name == 'nt' else 'ifconfig')

@cli.command(name='c')
def clear_screen():
    """Clear terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

@cli.command(name='l')
def npm_start():
    """Run 'npm start'."""
    os.system('npm start')

@cli.command(name='ll')
def npm_dev():
    """Run 'npm run dev'."""
    os.system('npm run dev')

@cli.command(name='lll')
def npm_build():
    """Run 'npm run build'."""
    os.system('npm run build')

# Alias subcommands
@cli.command(name='id', help='Bahasa Indonesia UI')
@click.pass_context
def lang_id(ctx):
    _run_interactive_menu(ctx, 'id')

@cli.command(name='en', help='English UI')
@click.pass_context
def lang_en(ctx):
    _run_interactive_menu(ctx, 'en')

@cli.command(name='es', help='Español UI')
@click.pass_context
def lang_es(ctx):
    _run_interactive_menu(ctx, 'es')

@cli.command(name='ja', help='日本語 UI')
@click.pass_context
def lang_ja(ctx):
    _run_interactive_menu(ctx, 'ja')

@cli.command(name='zh', help='中文 UI')
@click.pass_context
def lang_zh(ctx):
    _run_interactive_menu(ctx, 'zh')

def _run_interactive_menu(ctx, lang):
    """Run interactive menu in specific language."""
    choice = questionary.select(
        _t("menu_prompt", lang),
        choices=[
            _t("menu_exit", lang),
            _t("menu_help", lang),
            _t("menu_docs", lang),
            _t("menu_bum", lang)
        ]
    ).ask()

    if choice == _t("menu_docs", lang):
        # Sub-menu untuk docs
        docs_choice = questionary.select(
            _t("menu_docs", lang),
            choices=[
                _t("menu_create", lang),
                _t("menu_list", lang),
                _t("menu_clean", lang)
            ]
        ).ask()
        
        if docs_choice == _t("menu_create", lang):
            selected_lang = questionary.select(
                _t("select_lang_prompt", lang),
                choices=[f"{code}: {name}" for code, name in LANGUAGES.items()]
            ).ask().split(":")[0]
            ctx.invoke(init, lang=selected_lang)
        elif docs_choice == _t("menu_list", lang):
            ctx.invoke(list_templates, lang=lang)
        elif docs_choice == _t("menu_clean", lang):
            ctx.invoke(clean, lang=lang)
            
    elif choice == _t("menu_bum", lang):
        ctx.invoke(bum, lang=lang)
    elif choice == _t("menu_help", lang):
        show_custom_help(lang)
    elif choice == _t("menu_exit", lang):
        click.echo(_t("farewell", lang))

@cli.command()
@click.option('--lang', default='en', help='Language for terminal output')
def clean(lang):
    """Delete existing docs/ folder."""
    docs_dir = Path("docs")
    if docs_dir.exists():
        confirmation = questionary.select(
            _t("clean_confirm", lang, path=docs_dir),
            choices=[
                _t("clean_no", lang),
                _t("clean_yes", lang)
            ],
            default=_t("clean_no", lang)
        ).ask()

        if confirmation == _t("clean_yes", lang):
            shutil.rmtree(docs_dir)
            click.echo(_t("clean_success", lang, path=docs_dir))
        else:
            click.echo(_t("clean_cancel", lang))
    else:
        click.echo(_t("clean_not_found", lang))

if __name__ == "__main__":
    cli()
