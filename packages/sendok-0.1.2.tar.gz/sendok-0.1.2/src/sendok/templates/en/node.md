# Node.js & NPM (Node Package Manager) Guide

Node.js is an environment to run JavaScript code outside the browser, while NPM is a tool to manage third-party libraries.

---

## 1. Check Version
Make sure Node.js and NPM are installed:
```powershell
node -v
npm -v
```

## 2. Managing Packages (Library)
NPM makes it easy for us to add features to a project without writing code from scratch.

### Package Installation
```powershell
# Install all dependencies listed in package.json
npm install

# Install a new package and save it to the project
npm install <package-name>

# Install a package for development only (e.g., tester)
npm install --save-dev <package-name>

# Install a package globally (to be available in any terminal)
npm install -g <package-name>
```

### Uninstall Package
```powershell
npm uninstall <package-name>
```

## 3. NPM Scripts (`package.json`)
In every Node.js project, there is a `package.json` file. The `scripts` section is very useful for running long commands with abbreviations.

Example in `package.json`:
```json
"scripts": {
  "start": "node app.js",
  "dev": "nodemon app.js",
  "test": "jest"
}
```

How to run:
```powershell
npm run start
# (Specifically for 'start' and 'test', you can run: npm start)
```

## 4. Introduction to `npx` (Node Package Execute)
`npx` is used to run Node.js packages without having to install them permanently. Very useful for tools that are rarely used or one-time use.
```powershell
# Example of running an app creator without permanent installation
npx create-react-app my-app
```

## 5. `node_modules` Folder
- Never modify the contents of this folder manually.
- **Never include this folder in Git/GitLab** (always add it to `.gitignore`). This folder can be very large and can be recreated by running `npm install`.

## 6. Security Tips
Always run this command occasionally to check if any libraries have security issues:
```powershell
npm audit
# To fix automatically:
npm audit fix
```

---
*Use Node.js wisely to build backend applications or automation tools.*
