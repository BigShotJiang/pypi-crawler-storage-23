# Angular CLI Guide

Angular CLI (Command Line Interface) is a tool for creating, developing, and maintaining Angular applications directly from the terminal.

---

## 1. Angular CLI Installation
Install globally so the `ng` command can be used anywhere:
```powershell
npm install -g @angular/cli
```
Check version:
```powershell
ng version
```

## 2. Creating a New Project
```powershell
ng new your-project-name
```
*Tip: Choose CSS/SCSS and Routing options according to the project requirements.*

## 3. Running the Application (Development)
```powershell
# Run the local server (usually at localhost:4200)
ng serve

# Run and automatically open the browser
ng serve -o

# Run on a different port
ng serve --port 5000
```

## 4. Generate (Creating New Components)
Angular CLI is very helpful in creating standard and tidy file structures.

| Command | Abbreviation | Description |
| :--- | :--- | :--- |
| `ng generate component` | `ng g c` | Create a new component (html, css, ts, spec). |
| `ng generate service` | `ng g s` | Create a service for data logic. |
| `ng generate module` | `ng g m` | Create a new module. |
| `ng generate interface` | `ng g i` | Create a data type/interface. |

Example: `ng g c components/header`

## 5. Build for Production
If the application is ready to be deployed to the server:
```powershell
ng build --configuration production
```
The build result will appear in the `/dist` folder.

## 6. Testing & Linting
```powershell
# Run unit tests (Karma/Jasmine)
ng test

# Check code quality (linting)
ng lint
```

## 7. Angular CLI Tips
- **Dry Run**: Want to know what files will be created without actually creating them? Use the `--dry-run` flag.
  Example: `ng g c test-component --dry-run`
- **Inline Style/Template**: If the component is very simple, use:
  `ng g c simple --inline-style --inline-template`

---
*Angular CLI ensures tidy code standardization for large-scale projects.*
