# SSH Setup Guide (Office GitLab)

This document contains the steps to connect your device to the office GitLab (**git.citraborneo.co.id**) using an SSH key.

## 1. Check for Existing Keys
Open your terminal (PowerShell or Bash) and run:
```powershell
ls ~/.ssh
```
If the file `id_ed25519_office` already exists, you can go straight to step 3.

## 2. Generate a New SSH Key
If it doesn't exist, create a new key with the command:
```powershell
ssh-keygen -t ed25519 -C "device_description" -f "$HOME/.ssh/id_ed25519_office"
```
*Note: When prompted for a passphrase, just leave it blank (press Enter 2x).*

## 3. SSH File Configuration
Open the `~/.ssh/config` file (create a new one if it doesn't exist) and ensure the content looks like this:

```text
Host git.citraborneo.co.id
  HostName git.citraborneo.co.id
  User git
  IdentityFile ~/.ssh/id_ed25519_office
  IdentitiesOnly yes

Host github.com
  HostName github.com
  User git
  IdentityFile ~/.ssh/id_ed25519_office
  IdentitiesOnly yes

Host *
  AddKeysToAgent yes
  IdentitiesOnly yes
```

## 4. Add to GitLab
1. Get the public key content:
   ```powershell
   cat ~/.ssh/id_ed25519_office.pub
   ```
2. Copy the entire text that appears (starting with `ssh-ed25519 ...`).
3. Open [https://git.citraborneo.co.id/-/profile/keys](https://git.citraborneo.co.id/-/profile/keys).
4. Click **Add new key**, paste the content, select **Usage Type: Authentication**, then save.

## 5. Verify Connection
Run this command to make sure everything is successful:
```powershell
ssh -T git@git.citraborneo.co.id
```
If the message: **"Welcome to GitLab, @username!"** appears, the connection is successful.

---
**Tips:** If asked for a password during `ssh -T`, double-check the format in the `~/.ssh/config` file. Make sure there are no typos in the `IdentityFile` path.
