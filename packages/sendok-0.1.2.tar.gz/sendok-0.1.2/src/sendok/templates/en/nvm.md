# NVM for Windows (Node Version Manager) Guide

NVM (Node Version Manager) is a tool to install and manage multiple versions of Node.js on a single computer. This is very important if you work on multiple projects with different Node.js version requirements.

---

## 1. Basic Commands
Here are the most commonly used commands:

| Command | Description |
| :--- | :--- |
| `nvm list` | View the list of already installed Node.js versions. |
| `nvm list available` | View the list of Node.js versions available for download. |
| `nvm install <version>` | Download and install a specific version (e.g., `nvm install 18.16.0`). |
| `nvm use <version>` | Switch to a specific Node.js version (requires Administrator access in CMD/PowerShell). |
| `nvm uninstall <version>` | Uninstall a specific Node.js version. |

## 2. How to Switch Versions
To switch versions, run your terminal (PowerShell) as **Administrator**:
```powershell
# Example: switch to version 18
nvm use 18.20.2
```
After that, check if the version has changed:
```powershell
node -v
```

## 3. Troubleshooting

### `node` Command Not Recognized
Usually occurs because `nvm use` has never been run or environment variables haven't updated.
1. Run `nvm use <version>` again.
2. Restart terminal or computer.

### Access Denied
If an "Access Denied" error appears when running `nvm use`, make sure you open the terminal by **Right-Click > Run as Administrator**.

## 4. Tips
- Always use **LTS (Long Term Support)** versions for production projects for better stability.
- Type `nvm install latest` if you want to try the latest Node.js features.
- You can see the full list of commands by just typing `nvm`.

---
*This documentation helps ensure the team uses a uniform environment version.*
