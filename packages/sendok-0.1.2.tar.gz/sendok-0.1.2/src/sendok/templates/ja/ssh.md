# SSHセットアップガイド 🥄⚡

### 1. 新しいキーを生成する
```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
```

### 2. SSHエージェントを開始する
```bash
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519
```

### 3. 公開キーを確認する
```bash
cat ~/.ssh/id_ed25519.pub
```
