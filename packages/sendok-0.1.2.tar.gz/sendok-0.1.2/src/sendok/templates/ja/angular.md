# Angular CLIガイド 🥄🅰️

### 作成コマンド
- `ng new my-app`: 新しいプロジェクト
- `ng serve`: ローカルで実行
- `ng generate component my-comp`: 新しいコンポーネント
- `ng build`: プロジェクトをビルド
