# Node.js & NPMガイド 🥄📦

### 一般的なコマンド
- `npm init -y`: プロジェクトの初期化
- `npm install`: 依存関係のインストール
- `npm start`: アプリを実行
- `npm run dev`: 開発モード
- `npm run build`: プロダクション用にビルdう
