# GitHub CLI (gh) ガイド 🥄🐙

### 便利なコマンド
- `gh auth login`: ログイン
- `gh repo create`: リポジトリを作成
- `gh pr list`: プルリクエストを表示
- `gh issue status`: イシューのステータス
