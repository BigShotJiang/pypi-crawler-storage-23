# Guía de configuración de SSH 🥄⚡

### 1. Generar nueva clave
```bash
ssh-keygen -t ed25519 -C "tu_email@example.com"
```

### 2. Iniciar SSH Agent
```bash
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519
```

### 3. Ver clave pública
```bash
cat ~/.ssh/id_ed25519.pub
```
