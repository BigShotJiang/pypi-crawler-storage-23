# Guía de GitHub CLI (gh) 🥄🐙

### Comandos útiles
- `gh auth login`: Iniciar sesión
- `gh repo create`: Crear repositorio
- `gh pr list`: Ver Pull Requests
- `gh issue status`: Estado de Issues
