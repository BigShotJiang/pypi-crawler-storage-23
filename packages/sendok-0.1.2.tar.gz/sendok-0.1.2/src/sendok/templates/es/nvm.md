# Guía de NVM para Windows 🥄🐍

### Gestión de versiones
- `nvm list`: Ver versiones instaladas
- `nvm install latest`: Instalar última versión
- `nvm use 18.16.0`: Cambiar versión
- `nvm alias default 18.16.0`: Versión por defecto
