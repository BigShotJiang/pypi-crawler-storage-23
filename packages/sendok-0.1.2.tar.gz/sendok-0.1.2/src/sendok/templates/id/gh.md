# Panduan Lengkap GitHub CLI (`gh`)

GitHub CLI (`gh`) adalah alat baris perintah resmi dari GitHub yang membawa fitur-fitur web GitHub (Issues, PR, Repo) langsung ke terminal Anda.

---

## 1. Cek Instalasi
Pastikan `gh` sudah terinstal di sistem Anda:
```powershell
gh --version
```

## 2. Autentikasi (Penting!)
Sebelum memulai, Anda harus login ke akun GitHub Anda:
```powershell
# Mulai proses login interaktif
gh auth login
```
*Pilih: GitHub.com > SSH > Yes (jika ingin menggunakan kunci yang sudah ada) > Login with a web browser.*

Untuk mengecek status login:
```powershell
gh auth status
```

## 3. Manajemen Repositori
| Perintah | Deskripsi |
| :--- | :--- |
| `gh repo create` | Membuat repositori baru di GitHub. |
| `gh repo clone <owner/repo>` | Mengkloning repo (otomatis menggunakan SSH jika dikonfigurasi). |
| `gh repo fork` | Membuat fork dari repositori orang lain. |
| `gh repo view --web` | Membuka halaman repositori saat ini di browser. |

## 4. Bekerja dengan Pull Requests (PR)
Ini adalah fitur terkuat dari GitHub CLI.
```powershell
# Melihat daftar PR yang terbuka
gh pr list

# Membuat PR baru dari branch saat ini
gh pr create --title "Pesan PR" --body "Deskripsi perubahan"

# Melihat status PR Anda
gh pr status

# Melakukan checkout ke branch PR milik orang lain
gh pr checkout <nomor-pr>

# Melakukan merge PR (langsung dari terminal!)
gh pr merge
```

## 5. Mengelola Issues
```powershell
# Melihat daftar issue
gh issue list

# Membuat issue baru
gh issue create --title "Bug pada login" --body "Diskripsi detail bug"

# Melihat detail issue tertentu
gh issue view <nomor-issue>
```

## 6. Gist (Catatan Kode Cepat)
Gist sangat berguna untuk menyimpan potongan kode (snippets).
```powershell
# Membuat Gist dari file
gh gist create script.py

# Membuat Gist publik (default adalah rahasia)
gh gist create script.py --public
```

## 7. Aliases (Singkatan Perintah)
Anda bisa membuat singkatan sendiri agar bekerja lebih cepat.
```powershell
# Contoh: buat 'gh pv' untuk membuka repo di web
gh alias set pv 'repo view --web'

# Contoh: buat 'gh lpr' untuk melihat PR saya
gh alias set lpr 'pr list --author "@me"'
```

## 8. Tips Produktivitas
- **Buka di Browser**: Hampir semua perintah mendukung flag `--web` atau `-w` untuk langsung membuka halaman terkait di browser.
- **Auto-Completion**: Jika menggunakan PowerShell, pastikan auto-completion aktif agar menekan TAB bisa melengkapi perintah otomatis.
- **Integrasi SSH**: Karena kita sudah mengatur kunci SSH di `ssh.md`, pastikan saat `gh auth login` Anda memilih protokol **SSH**, bukan HTTPS.

---
*Gunakan panduan ini bersamaan dengan `git.md` untuk efisiensi maksimal di terminal.*
