# Windows 版 NVM 指南 🥄🐍

### 版本管理
- `nvm list`: 查看已安装版本
- `nvm install latest`: 安装最新版本
- `nvm use 18.16.0`: 切换版本
- `nvm alias default 18.16.0`: 设置默认版本
