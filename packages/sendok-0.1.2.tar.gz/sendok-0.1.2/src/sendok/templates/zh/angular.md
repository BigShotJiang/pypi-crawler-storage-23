# Angular CLI 指南 🥄🅰️

### 创建命令
- `ng new my-app`: 创建新项目
- `ng serve`: 本地运行
- `ng generate component my-comp`: 创建新组件
- `ng build`: 构建项目
