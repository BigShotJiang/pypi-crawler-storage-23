# SSH 设置指南 🥄⚡

### 1. 生成新密钥
```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
```

### 2. 启动 SSH 代理
```bash
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519
```

### 3. 查看公钥
```bash
cat ~/.ssh/id_ed25519.pub
```
