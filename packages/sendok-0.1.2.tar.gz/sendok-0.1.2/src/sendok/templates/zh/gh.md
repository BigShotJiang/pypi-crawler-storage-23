# GitHub CLI (gh) 指南 🥄🐙

### 常用命令
- `gh auth login`: 登录
- `gh repo create`: 创建仓库
- `gh pr list`: 查看拉取请求
- `gh issue status`: Issue 状态
