# sendok 🥄

**sendok** (Scaffolding Engine for Nimble Documentation Organizer Kit) は、プロジェクトのドキュメント作成を管理し、ターミナルのワークフローを高速化するための、シンプルで高速な開発ツールです。

[🇺🇸 English](README.md) | [🇮🇩 Bahasa Indonesia](README_id.md) | [🇪🇸 Español](README_es.md) | [🇨🇳 中文](README_zh.md)

---

## ✨ 主な機能

- **🚀 インスタントドキュメント**: 標準テンプレート（SSH、Git、Node、NVM、Angular、GitHub CLI）を使用して `docs/` フォルダを初期化します。
- **🌐 多言語サポート**: 5つの言語（EN、ID、ES、JA、ZH）のテンプレートが利用可能です。
- **🍴 Git Helper (gg)**: Git を対話的に管理！Auto-init、Staging (Unstage/Discard)、*dubious ownership* エラーの自動修復をサポートします。
- **🛡️ バックアップマネージャー (bum)**: プロジェクトをスマートにバックアップします。重いフォルダ (`node_modules`) を無視し、重要なファイル (`.env`) は保持します。
- **⚡ グローバルショートハンド**: 一般的なタスク用の1文字コマンド（Reload、画面クリア、IP情報など）。
- **🎨 インタラクティブインターフェース**: `questionary` を使用した使いやすいメニュー。

---

## 🛠️ インストール

### ソースから（グローバルショートハンドに推奨）
1. このリポジトリをクローンします。
2. プロジェクトフォルダに入ります。
3. 次のコマンドを実行します：
```bash
pip install -e .
```

---

## 🚀 使用方法

### 1. インタラクティブメニュー
お好みの言語でツールを実行して、ナビゲーションメニューを開きます：
- **`sendok ja`** : 日本語メニュー。
- **`sendok en`** : 英語メニュー。
- **`sendok id`** : インドネシア語メニュー。
- **`sendok es`** : スペイン語メニュー。
- **`sendok zh`** : 中国語メニュー。

### 2. グローバルショートハンド（ターミナルで直接）
インストール後、ターミナルから直接これらのコマンドを使用できます：

| コマンド | 機能 |
| :--- | :--- |
| **`r`** | ターミナルと VS Code を更新 |
| **`gg`** | Git GUI ヘルパーを実行する (対話型) |
| **`c`** | ターミナル画面をクリア (`cls` または `clear`) |
| **`p`** | IP情報を表示 (`ipconfig` または `ifconfig`) |
| **`bum`** | 現在のフォルダに対してバックアップマネージャーを実行 |
| **`lll`** | `npm run build` を実行 |
| **`bum`** | 現在のフォルダに対してバックアップマネージャーを実行 |

### 3. Git Helper (`gg`) の機能
ターミナルコマンドを覚えなくても、**`gg`** コマンドで簡単に Git を管理できます：

| メニューアクション | 対応する Git コマンド | 説明 |
| :--- | :--- | :--- |
| **Auto-Init** | `git init` | レポジトリがない場合に自動で作成します。 |
| **Staging** | `git add` | ファイルをコミット待ち状態に追加します。 |
| **Unstage** | `git reset` | ファイルを待ち状態から除外します（安全）。 |
| **Discard** | `git restore` | 編集を破棄してファイルをリセットします（注意！）。 |
| **Commit** | `git commit` | 変更を永続的に記録します。 |
| **Push/Pull** | `git push/pull` | サーバー（GitLab/GitHub）と同期します。 |
| **Branch** | `git branch` | コーディングのブランチを管理します。 |
| **Remove Git** | `rd /s /q .git` | フォルダを通常の状態に戻します（Gitを削除）。 |
| **Auto-Fix** | `git config ...` | *dubious ownership* エラーを自動で修復します。 |

### 4. 標準サブコマンド
- **`sendok init [id|en|es|ja|zh]`**: ドキュメントフォルダを作成。
- **`sendok reload`**: ターミナルと VS Code の UI を更新。
- **`sendok list`**: 利用可能なドキュメントテンプレートを表示。
- **`sendok clean`**: `docs/` フォルダを削除。
- **`sendok about`**: アプリ開発者の情報を表示。

---

## 🛡️ バックアップマネージャー (bum)

`bum` 機能は、`.bum/[プロジェクトフォルダ]-[日付]-[時刻]` にタイムスタンプ付きのバックアップフォルダを作成します。
このプロセスは以下を自動的に無視します：
- `node_modules`, `.git`, `venv`, `.venv`
- `dist`, `build`, `__pycache__`
- `.bum` フォルダ自体（再帰を避けるため）

---

## 👤 著者
- **Hasan Askari** (marhaendev)
- **Website**: [hasanaskari.com](https://hasanaskari.com)
- **メール**: marhaendev@gmail.com

 🥄 *シンプル。スピーディ。プロのようにドキュメントを作成！*

---

### ❓ トラブルシューティング：「コマンドが見つかりません」
インストール後に `command not found: sendok` や `gg` などのエラーが表示される場合：
1. **Windows**: Python の `Scripts` フォルダがシステムの PATH に含まれていることを確認してください（通常は `C:\Users\<User>\AppData\Roaming\Python\Python3x\Scripts`）。
2. **Linux/macOS**: `~/.local/bin` が PATH に含まれていることを確認してください。これを `.bashrc` または `.zshrc` に追加します：
   ```bash
   export PATH="$HOME/.local/bin:$PATH"
   ```
3. **ターミナルの再起動**: 変更を適用した後、ターミナルを一度閉じてから再度開いてください。
