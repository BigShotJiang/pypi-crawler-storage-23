# sendok 🥄

**sendok** (Scaffolding Engine for Nimble Documentation Organizer Kit) is a simple and fast development tool to manage project documentation and speed up your terminal workflow.

[🇮🇩 Bahasa Indonesia](README_id.md) | [🇪🇸 Español](README_es.md) | [🇯🇵 日本語](README_ja.md) | [🇨🇳 中文](README_zh.md)

---

## ✨ Key Features

- **🚀 Instant Documentation**: Initialize `docs/` folder with standard templates (SSH, Git, Node, NVM, Angular, GitHub CLI).
- **🌐 Multi-language Support**: Templates available in 5 languages (EN, ID, ES, JA, ZH).
- **🍴 Git Helper (gg)**: Manage Git interactively! Supports auto-init, staging (unstage/discard), and automatic fix for *dubious ownership* errors.
- **🛡️ Backup Manager (bum)**: Smartly backup your project. Ignores heavy folders (`node_modules`) while keeping sensitive files (`.env`).
- **⚡ Global Shorthands**: One-letter commands for common tasks (Reload, Clear screen, IP Info, etc).
- **🎨 Interactive Interface**: User-friendly menu powered by `questionary`.

---

## 🛠️ Installation

### From Source (Recommended for Global Shorthands)
1. Clone this repository.
2. Enter the project folder.
3. Run the following command:
```bash
pip install -e .
```

---

## 🚀 Usage Guide

### 1. Interactive Menu
Run the tool with your preferred language to open the navigation menu:
- **`sendok en`** : Menu in English (Default).
- **`sendok id`** : Menu in Indonesian.
- **`sendok es`** : Menu in Spanish.
- **`sendok ja`** : Menu in Japanese.
- **`sendok zh`** : Menu in Chinese.

### 2. Global Shorthands (Direct in Terminal)
After installation, you can use these commands directly from your terminal:

| Command | Function |
| :--- | :--- |
| **`r`** | Refresh terminal & VS Code UI |
| **`gg`** | Run Git GUI Helper (Interactive) |
| **`c`** | Clear terminal screen (`cls` or `clear`) |
| **`p`** | Show IP information (`ipconfig` or `ifconfig`) |
| **`bum`** | Run Backup Manager for the current folder |
| **`lll`** | Run `npm run build` |
| **`bum`** | Run Backup Manager for the current folder |

### 3. Git Helper (`gg`) Features
Use the **`gg`** command for easier Git management without memorizing terminal commands:

| Menu Action | Git Command Equivalent | Description |
| :--- | :--- | :--- |
| **Auto-Init** | `git init` | Automatically creates a repo if not found. |
| **Staging** | `git add` | Add files to the commit queue. |
| **Unstage** | `git reset` | Remove files from the queue (safe). |
| **Discard** | `git restore` | Discard edits & reset file (be careful!). |
| **Commit** | `git commit` | Record changes permanently. |
| **Push/Pull** | `git push/pull` | Sync with server (GitLab/GitHub). |
| **Branch** | `git branch` | Manage coding branches. |
| **Remove Git** | `rd /s /q .git` | Restore folder to normal (delete Git). |
| **Auto-Fix** | `git config ...` | Automatically fix *dubious ownership* errors. |

### 4. Standard Subcommands
- **`sendok init [id|en|es|ja|zh]`**: Create documentation folder.
- **`sendok reload`**: Refresh terminal and VS Code UI.
- **`sendok list`**: View available documentation templates.
- **`sendok clean`**: Delete `docs/` folder.
- **`sendok about`**: Show application developer information.

---

## 🛡️ Backup Manager (bum)

The `bum` feature creates a timestamped backup folder at `.bum/[project_folder]-[date]-[time]`.
This process automatically ignores:
- `node_modules`, `.git`, `venv`, `.venv`
- `dist`, `build`, `__pycache__`
- The `.bum` folder itself (to avoid recursion)

---

## 👤 Author
- **Hasan Askari** (marhaendev)
- **Website**: [hasanaskari.com](https://hasanaskari.com)
- **Email**: marhaendev@gmail.com

🥄 *Simple. Fast. Spooning documents like a pro!*

---

### ❓ Troubleshooting: "Command Not Found"
If you see an error like `command not found: sendok` or `gg` after installation:
1. **Windows**: Ensure your Python `Scripts` folder is in your System PATH (usually `C:\Users\<User>\AppData\Roaming\Python\Python3x\Scripts`).
2. **Linux/macOS**: Ensure `~/.local/bin` is in your PATH. Add this to your `.bashrc` or `.zshrc`:
   ```bash
   export PATH="$HOME/.local/bin:$PATH"
   ```
3. **Restart Terminal**: Close and reopen your terminal after making changes.
