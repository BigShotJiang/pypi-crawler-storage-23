# Panduan Lengkap Git (Indonesian Edition)

Dokumen ini adalah panduan lengkap untuk menggunakan Git dari dasar hingga tingkat menengah untuk alur kerja pengembangan sehari-hari.

---

## 1. Konfigurasi Awal
Sebelum mulai, pastikan nama dan email Anda sudah terdaftar di sistem lokal Anda.
```powershell
# Mengatur nama pengguna
git config --global user.name "Nama Anda"

# Mengatur email
git config --global user.email "email@kantor.com"

# Cek hasil konfigurasi
git config --list
```

## 2. Alur Kerja Dasar (Day-to-Day)
Setiap kali Anda mulai mengerjakan sesuatu, ini adalah perintah yang paling sering digunakan:

| Perintah | Deskripsi |
| :--- | :--- |
| `git init` | Membuat repositori git baru di folder saat ini. |
| `git status` | Melihat status file (mana yang berubah, mana yang belum di-add). |
| `git add .` | Memasukkan **semua** perubahan ke area staging (siap komit). |
| `git add <nama_file>` | Memasukkan file spesifik saja ke area staging. |
| `git commit -m "Pesan"` | Menyimpan perubahan secara permanen (snapshot). |
| `git log` | Melihat riwayat komit. |

## 3. Bekerja dengan Remote (Server)
Setelah Anda punya kunci SSH yang terhubung ke **git.citraborneo.co.id**:

```powershell
# Mengkloning (mendownload) repositori yang sudah ada
git clone git@git.citraborneo.co.id:username/nama-proyek.git

# Mengambil perubahan terbaru dari server
git pull origin <nama_branch>

# Mengirim perubahan lokal ke server
git push origin <nama_branch>

# Menambahkan remote (jika belum ada)
git remote add origin git@git.citraborneo.co.id:username/nama-proyek.git
```

## 4. Branching (Percabangan)
Branching memungkinkan Anda mengerjakan fitur baru tanpa merusak kode utama yang sedang berjalan.

```powershell
# Melihat daftar branch
git branch

# Membuat branch baru
git branch fitur-baru

# Berpindah ke branch lain
git checkout fitur-baru
# (Cara cepat buat & pindah: git checkout -b fitur-baru)

# Menghapus branch lokal
git branch -d nama-branch

# Menggabungkan fitur-baru ke main (lakukan ini di branch main)
git merge fitur-baru
```

## 5. Menangani Konflik (Merge Conflict)
Konflik terjadi jika dua orang mengubah baris yang sama di file yang sama.
1. Git akan menandai file yang konflik.
2. Buka file tersebut, cari tanda `<<<<<<<`, `=======`, dan `>>>>>>>`.
3. Pilih kode mana yang mau dipertahankan, hapus tanda-tanda tersebut.
4. Simpan file, lalu:
   ```powershell
   git add <file_konflik>
   git commit -m "Menyelesaikan konflik"
   ```

## 6. Perintah Tingkat Lanjut (Useful Tools)

### Stashing (Menyimpan Sementara)
Gunakan ini jika Anda sedang di tengah kerjaan dan tiba-tiba harus pindah branch, tapi belum mau komit.
```powershell
# Menyimpan sementara
git stash

# Mengambil kembali kerjaan tadi
git stash pop
```

### Membatalkan Perubahan
```powershell
# Membatalkan perubahan di file yang belum di-add (restore)
git restore <nama_file>

# Membatalkan git add (unstage)
git restore --staged <nama_file>

# Membatalkan komit terakhir (tapi kode tetap ada di file)
git reset --soft HEAD~1
```

## 7. Praktik Terbaik (Best Practices)
- **Komit Sedikit tapi Sering**: Jangan tunggu kerjaan selesai 100% baru komit. Komit setiap kali satu unit kecil selesai.
- **Pesan Komit yang Jelas**: Gunakan *"Menambahkan fitur login"* lebih baik daripada *"Update"*.
- **Sync Dulu Sebelum Push**: Selalu lakukan `git pull` sebelum `git push` untuk menghindari konflik.
- **Main/Master Harus Selalu Berjalan**: Pastikan kode di branch utama selalu bisa di-run. Gunakan branch lain untuk eksperimen.

---
*Dokumen ini dibuat untuk mempermudah alur kerja tim IT Citra Borneo Indah.*
