# Panduan Node.js & NPM (Node Package Manager)

Node.js adalah tempat menjalankan kode JavaScript di luar browser, sedangkan NPM adalah alat untuk mengelola pustaka (library) dari pihak ketiga.

---

## 1. Cek Versi
Pastikan Node.js dan NPM sudah terinstal:
```powershell
node -v
npm -v
```

## 2. Mengelola Paket (Library)
NPM mempermudah kita menambahkan fitur ke dalam proyek tanpa menulis kode dari nol.

### Instalasi Paket
```powershell
# Menginstal semua dependensi yang ada di package.json
npm install

# Menginstal paket baru dan menyimpannya ke proyek
npm install <nama-paket>

# Menginstal paket khusus untuk pengembangan saja (contoh: tester)
npm install --save-dev <nama-paket>

# Menginstal paket secara global (agar bisa dipanggil di terminal mana saja)
npm install -g <nama-paket>
```

### Menghapus Paket
```powershell
npm uninstall <nama-paket>
```

## 3. Skrip NPM (`package.json`)
Dalam setiap proyek Node.js, terdapat file `package.json`. Bagian `scripts` sangat berguna untuk menjalankan perintah panjang dengan singkatan.

Contoh di `package.json`:
```json
"scripts": {
  "start": "node app.js",
  "dev": "nodemon app.js",
  "test": "jest"
}
```

Cara menjalankannya:
```powershell
npm run start
# (Khusus untuk 'start' dan 'test', bisa langsung: npm start)
```

## 4. Mengenal `npx` (Node Package Execute)
`npx` digunakan untuk menjalankan paket Node.js tanpa harus menginstalnya secara permanen. Sangat berguna untuk alat-alat yang jarang dipakai atau sekali pakai.
```powershell
# Contoh menjalankan pembuat aplikasi tanpa instal permanen
npx create-react-app my-app
```

## 5. Folder `node_modules`
- Jangan pernah mengubah isi folder ini secara manual.
- **Jangan pernah masukkan folder ini ke Git/GitLab** (selalu masukkan ke `.gitignore`). Folder ini bisa sangat besar dan bisa dibuat ulang cukup dengan menjalankan `npm install`.

## 6. Tips Keamanan
Selalu jalankan perintah ini sesekali untuk mengecek apakah ada pustaka yang punya masalah keamanan:
```powershell
npm audit
# Untuk memperbaiki otomatis:
npm audit fix
```

---
*Gunakan Node.js dengan bijak untuk membangun aplikasi backend atau alat otomatisasi.*
