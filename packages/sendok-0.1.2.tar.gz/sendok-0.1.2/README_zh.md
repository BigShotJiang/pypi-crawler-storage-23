# sendok 🥄

**sendok** (Scaffolding Engine for Nimble Documentation Organizer Kit) 是一个简单快捷的开发工具，用于管理项目文档并加快终端工作流。

[🇺🇸 English](README.md) | [🇮🇩 Bahasa Indonesia](README_id.md) | [🇪🇸 Español](README_es.md) | [🇯🇵 日本語](README_ja.md)

---

## ✨ 主要功能

- **🚀 即时文档**: 使用标准模板（SSH、Git、Node、NVM、Angular、GitHub CLI）初始化 `docs/` 文件夹。
- **🌐 多语言支持**: 支持 5 种语言（EN、ID、ES、JA、ZH）。
- **🍴 Git Helper (gg)**: 交互式管理 Git！支持 auto-init、staging (unstage/discard) 以及自动修复 *dubious ownership* 错误。
- **🛡️ 备份管理器 (bum)**: 一键智能备份项目。自动忽略庞大文件夹 (`node_modules`)，同时保留敏感文件 (`.env`)。
- **⚡ 全局快捷命令 (Shorthands)**: 常用任务的单字母命令（Reload、清屏、IP 信息等）。
- **🎨 交互式界面**: 基于 `questionary` 的用户友好菜单。

---

## 🛠️ 安装

### 从源码安装（推荐用于全局快捷命令）
1. 克隆此仓库。
2. 进入项目文件夹。
3. 运行以下命令：
```bash
pip install -e .
```

---

## 🚀 使用指南

### 1. 交互式菜单
使用你偏好的语言运行工具以打开导航菜单：
- **`sendok zh`** : 中文菜单。
- **`sendok en`** : 英文菜单。
- **`sendok id`** : 印尼语菜单。
- **`sendok es`** : 西班牙语菜单。
- **`sendok ja`** : 日语菜单。

### 2. 全局快捷命令（直接在终端运行）
安装后，你可以直接从终端使用这些命令：

| 命令 | 功能 |
| :--- | :--- |
| **`r`** | 刷新终端和 VS Code |
| **`gg`** | 运行 Git GUI 助手 (交互式) |
| **`c`** | 清除终端屏幕 (`cls` 或 `clear`) |
| **`p`** | 显示 IP 信息 (`ipconfig` 或 `ifconfig`) |
| **`bum`** | 对当前文件夹运行备份管理器 |
| **`lll`** | 运行 `npm run build` |
| **`bum`** | 对当前文件夹运行备份管理器 |

### 3. Git Helper (`gg`) 功能详解
无需记忆终端命令，使用 **`gg`** 命令即可轻松管理 Git：

| 菜单操作 | 对应 Git 命令 | 描述 |
| :--- | :--- | :--- |
| **自动初始化** | `git init` | 如果未发现仓库，则自动创建。 |
| **暂存 (Staging)** | `git add` | 将文件添加到提交队列。 |
| **取消暂存** | `git reset` | 从队列中移除文件（安全）。 |
| **丢弃更改** | `git restore` | 丢弃所有修改并重置文件（小心使用！）。 |
| **提交 (Commit)** | `git commit` | 永久记录更改。 |
| **推送/拉取** | `git push/pull` | 与服务器（GitLab/GitHub）同步。 |
| **分支管理** | `git branch` | 管理代码分支。 |
| **移除 Git** | `rd /s /q .git` | 将文件夹复原（删除 Git 配置）。 |
| **自动修复** | `git config ...` | 自动修复 *dubious ownership* 安全错误。 |

### 4. 标准子命令
- **`sendok init [id|en|es|ja|zh]`**: 创建文档文件夹。
- **`sendok reload`**: 刷新终端和 VS Code 界面。
- **`sendok list`**: 查看可用文档模板列表。
- **`sendok clean`**: 删除 `docs/` 文件夹。
- **`sendok about`**: 显示应用开发人员信息。

---

## 🛡️ 备份管理器 (bum)

`bum` 功能会在 `.bum/[项目文件夹]-[日期]-[时间]` 创建一个带有时间戳的备份文件夹。
此过程会自动忽略：
- `node_modules`, `.git`, `venv`, `.venv`
- `dist`, `build`, `__pycache__`
- `.bum` 文件夹本身（避免递归）

---

## 👤 作者
- **Hasan Askari** (marhaendev)
- **Website**: [hasanaskari.com](https://hasanaskari.com)
- **电子邮件**: marhaendev@gmail.com

 🥄 *简单。快速。像专业人士一样编写文档！*

---

### ❓ 故障排除：“找不到命令”
如果安装后出现 `command not found: sendok` 或 `gg` 等错误：
1. **Windows**: 确保 Python 的 `Scripts` 文件夹已加入系统 PATH（通常为 `C:\Users\<User>\AppData\Roaming\Python\Python3x\Scripts`）。
2. **Linux/macOS**: 确保 `~/.local/bin` 在您的 PATH 中。将以下内容添加到您的 `.bashrc` 或 `.zshrc`：
   ```bash
   export PATH="$HOME/.local/bin:$PATH"
   ```
3. **重启终端**: 更改后，请关闭并重新打开终端。
