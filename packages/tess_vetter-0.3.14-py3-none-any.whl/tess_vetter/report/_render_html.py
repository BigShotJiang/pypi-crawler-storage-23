"""Lightweight HTML renderer for LC-only vetting reports.

Consumes a ReportData object and produces a self-contained HTML string
with interactive Plotly charts.  No external dependencies beyond the
Plotly.js CDN.
"""

from __future__ import annotations

import json
from typing import Any

from tess_vetter.report._data import ReportData

_PLOTLY_CDN = "https://cdn.plot.ly/plotly-2.35.2.min.js"

# -- Color palette (dark terminal aesthetic) ----------------------------------
_BG = "#1a1a2e"
_BG_CARD = "#16213e"
_BG_SURFACE = "#0f3460"
_ACCENT = "#f0b429"
_TEXT = "#e0e0e0"
_TEXT_DIM = "#8a8a9a"
_OK = "#2ecc71"
_FAIL = "#e74c3c"
_SKIP = "#7f8c8d"
_TRANSIT_COLOR = "#e74c3c"
_OOT_COLOR = "#5dade2"
_BIN_COLOR = "#f0b429"


def render_html(report: ReportData, *, title: str | None = None) -> str:
    """Render a ReportData object to a self-contained HTML string.

    Args:
        report: The assembled report data packet.
        title: Optional page title. Defaults to "TESS Vetting Report".

    Returns:
        A complete HTML document as a string with embedded Plotly charts.
    """
    return render_html_from_payload(report.to_json(), title=title)


def render_html_from_payload(payload: dict[str, Any], *, title: str | None = None) -> str:
    """Render from already-serialized report payload."""
    data = payload
    summary = _summary_view(data)
    page_title = title or _build_default_title(summary)
    data_json = json.dumps(data, indent=None, allow_nan=False)

    return f"""\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{_esc(page_title)}</title>
<script src="{_PLOTLY_CDN}"></script>
{_css_block()}
</head>
<body>

{_header_section(summary)}
{_lc_summary_section(summary)}

<div class="plot-panel">
  <h2>Full Light Curve</h2>
  <div id="full-lc-plot" class="plot-container"></div>
</div>

<div class="plot-panel">
  <h2>Phase-Folded Transit</h2>
  <div id="phase-plot" class="plot-container"></div>
</div>

<div class="plot-panel">
  <h2>Per-Transit Stack</h2>
  <div id="per-transit-plot" class="plot-container"></div>
</div>

<div class="plot-panel">
  <h2>Local Detrend Baseline Diagnostic</h2>
  <div id="local-detrend-plot" class="plot-container"></div>
</div>

<div class="plot-panel">
  <h2>Odd vs Even Transits</h2>
  <div id="odd-even-plot" class="plot-container"></div>
</div>

<div class="plot-panel">
  <h2>Secondary Eclipse / Phase Scan</h2>
  <div id="secondary-scan-plot" class="plot-container"></div>
</div>

<div class="plot-panel">
  <h2>Out-of-Transit Noise Context</h2>
  <div id="oot-context-plot" class="plot-container"></div>
</div>

{_custom_views_section(data)}

{_lc_robustness_section(summary)}

{_enrichment_section(summary)}

{_checks_section(summary)}

{_bibliography_section(summary)}

<script>
// Embed report data
var REPORT = {data_json};

{_percentile_helper_js()}

{_full_lc_js()}

{_phase_folded_js()}

{_per_transit_stack_js()}

{_local_detrend_js()}

{_odd_even_js()}

{_secondary_scan_js()}

{_oot_context_js()}

{_custom_views_js()}
</script>

<footer class="footer">
  <span>tess-vetter &middot; report v{_esc(str(data.get("schema_version", "?")))}</span>
</footer>
</body>
</html>"""


# -- Private helpers ----------------------------------------------------------


def _build_default_title(data: dict[str, Any]) -> str:
    parts = ["TESS Vetting Report"]
    if data.get("toi"):
        parts.append(str(data["toi"]))
    elif data.get("tic_id") is not None:
        parts.append(f"TIC {data['tic_id']}")
    return " - ".join(parts)


def _summary_view(data: dict[str, Any]) -> dict[str, Any]:
    return dict(data.get("summary", data))


def _plots_view(data: dict[str, Any]) -> dict[str, Any]:
    return dict(data.get("plot_data", data))


def _esc(text: str) -> str:
    """Minimal HTML escaping."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _fmt(value: Any, precision: int = 2, suffix: str = "") -> str:
    """Format a numeric value for display, handling None gracefully."""
    if value is None:
        return "&mdash;"
    if isinstance(value, float):
        return f"{value:.{precision}f}{suffix}"
    return f"{value}{suffix}"


# -- CSS ----------------------------------------------------------------------


def _css_block() -> str:
    return f"""\
<style>
  *, *::before, *::after {{ box-sizing: border-box; }}
  body {{
    margin: 0; padding: 20px;
    font-family: 'Menlo', 'Consolas', 'Monaco', monospace;
    background: {_BG}; color: {_TEXT};
    line-height: 1.5;
  }}
  h1, h2, h3 {{ color: {_ACCENT}; margin-top: 0; font-weight: 600; }}
  h1 {{ font-size: 1.4em; margin-bottom: 4px; }}
  h2 {{ font-size: 1.1em; margin-bottom: 12px; }}

  .header {{
    background: {_BG_CARD};
    border: 1px solid {_BG_SURFACE};
    border-radius: 8px;
    padding: 20px 24px;
    margin-bottom: 16px;
  }}
  .header .subtitle {{
    color: {_TEXT_DIM}; font-size: 0.85em; margin: 0;
  }}
  .ephemeris-grid {{
    display: flex; flex-wrap: wrap; gap: 16px 32px;
    margin-top: 12px;
  }}
  .eph-item {{
    display: flex; flex-direction: column;
  }}
  .eph-label {{ color: {_TEXT_DIM}; font-size: 0.75em; text-transform: uppercase; }}
  .eph-value {{ color: {_TEXT}; font-size: 1.0em; font-weight: 600; }}

  .summary-panel {{
    background: {_BG_CARD};
    border: 1px solid {_BG_SURFACE};
    border-radius: 8px;
    padding: 20px 24px;
    margin-bottom: 16px;
  }}
  .vitals-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 12px;
  }}
  .vital {{
    background: {_BG_SURFACE};
    border-radius: 6px;
    padding: 10px 14px;
  }}
  .vital-label {{ color: {_TEXT_DIM}; font-size: 0.7em; text-transform: uppercase; }}
  .vital-value {{ color: {_TEXT}; font-size: 1.05em; font-weight: 600; }}
  .section-note {{ color: {_TEXT_DIM}; font-size: 0.8em; margin: 0 0 10px 0; }}

  .plot-panel {{
    background: {_BG_CARD};
    border: 1px solid {_BG_SURFACE};
    border-radius: 8px;
    padding: 20px 24px;
    margin-bottom: 16px;
  }}
  .plot-container {{
    width: 100%; min-height: 340px;
  }}
  .plot-status-note {{
    color: {_TEXT_DIM};
    font-size: 0.8em;
    margin: 0 0 10px 0;
  }}
  .custom-view-status {{
    display: inline-block;
    margin-left: 8px;
    padding: 1px 8px;
    border-radius: 4px;
    font-size: 0.72em;
    text-transform: uppercase;
    letter-spacing: 0.02em;
    background: {_SKIP}22;
    color: {_SKIP};
  }}
  .custom-view-status.ready {{
    background: {_OK}22;
    color: {_OK};
  }}
  .custom-view-status.unavailable,
  .custom-view-status.unsupported {{
    background: {_FAIL}22;
    color: {_FAIL};
  }}
  .custom-view-status.degraded {{
    background: {_ACCENT}22;
    color: {_ACCENT};
  }}

  .checks-panel {{
    background: {_BG_CARD};
    border: 1px solid {_BG_SURFACE};
    border-radius: 8px;
    padding: 20px 24px;
    margin-bottom: 16px;
  }}
  .checks-grid {{
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 12px;
  }}
  .check-card {{
    background: {_BG_SURFACE};
    border-radius: 6px;
    padding: 14px 16px;
    border-left: 4px solid {_SKIP};
  }}
  .check-card.ok {{ border-left-color: {_OK}; }}
  .check-card.error {{ border-left-color: {_FAIL}; }}
  .check-card.skipped {{ border-left-color: {_SKIP}; }}
  .check-header {{
    display: flex; align-items: center; gap: 8px;
    margin-bottom: 6px;
  }}
  .check-id {{
    font-weight: 700; font-size: 0.9em;
  }}
  .check-name {{
    color: {_TEXT_DIM}; font-size: 0.8em;
  }}
  .check-status {{
    margin-left: auto;
    font-size: 0.75em; font-weight: 700;
    text-transform: uppercase;
    padding: 2px 8px; border-radius: 4px;
  }}
  .check-status.ok {{ background: {_OK}22; color: {_OK}; }}
  .check-status.error {{ background: {_FAIL}22; color: {_FAIL}; }}
  .check-status.skipped {{ background: {_SKIP}22; color: {_SKIP}; }}
  .check-metrics {{
    font-size: 0.78em; color: {_TEXT_DIM};
    margin-top: 4px;
  }}
  .check-metrics span {{
    display: inline-block; margin-right: 12px;
  }}
  .check-flags {{
    font-size: 0.73em; color: {_FAIL}; margin-top: 4px;
  }}
  .check-notes {{
    font-size: 0.73em; color: {_TEXT_DIM}; margin-top: 2px; font-style: italic;
  }}
  .check-methods {{
    font-size: 0.73em; color: {_TEXT_DIM}; margin-top: 4px;
  }}
  .check-methods a {{
    color: {_ACCENT}; text-decoration: none;
  }}
  .check-methods a:hover {{
    text-decoration: underline;
  }}

  .bibliography-list {{
    margin: 0; padding-left: 18px;
  }}
  .bibliography-list li {{
    margin: 0 0 8px 0;
  }}
  .bibliography-key {{
    color: {_ACCENT};
    font-weight: 700;
  }}
  .bibliography-notes {{
    font-size: 0.73em; color: {_TEXT_DIM};
  }}

  .bundle-bar {{
    display: flex; gap: 16px; margin-bottom: 14px;
    font-size: 0.85em;
  }}
  .bundle-stat {{
    padding: 4px 12px;
    border-radius: 4px;
    font-weight: 600;
  }}
  .bundle-ok {{ background: {_OK}22; color: {_OK}; }}
  .bundle-fail {{ background: {_FAIL}22; color: {_FAIL}; }}
  .bundle-skip {{ background: {_SKIP}22; color: {_SKIP}; }}

  .footer {{
    text-align: center;
    color: {_TEXT_DIM}; font-size: 0.7em;
    padding: 16px 0 8px;
  }}

  @media (max-width: 640px) {{
    body {{ padding: 10px; }}
    .vitals-grid {{ grid-template-columns: repeat(2, 1fr); }}
    .checks-grid {{ grid-template-columns: 1fr; }}
  }}
</style>"""


# -- Header section -----------------------------------------------------------


def _header_section(data: dict[str, Any]) -> str:
    tic_id = data.get("tic_id")
    toi = data.get("toi")
    eph = data.get("ephemeris", {})
    input_depth = data.get("input_depth_ppm")

    # Title line
    if toi:
        title_text = _esc(str(toi))
        subtitle = f"TIC {tic_id}" if tic_id is not None else ""
    elif tic_id is not None:
        title_text = f"TIC {tic_id}"
        subtitle = ""
    else:
        title_text = "TESS Candidate"
        subtitle = ""

    subtitle_html = f'<p class="subtitle">{_esc(subtitle)}</p>' if subtitle else ""

    # Ephemeris items
    eph_items = ""
    if eph:
        eph_items = f"""\
    <div class="ephemeris-grid">
      <div class="eph-item">
        <span class="eph-label">Period</span>
        <span class="eph-value">{_fmt(eph.get("period_days"), 6, " d")}</span>
      </div>
      <div class="eph-item">
        <span class="eph-label">T0 (BTJD)</span>
        <span class="eph-value">{_fmt(eph.get("t0_btjd"), 6)}</span>
      </div>
      <div class="eph-item">
        <span class="eph-label">Duration</span>
        <span class="eph-value">{_fmt(eph.get("duration_hours"), 3, " hr")}</span>
      </div>
      <div class="eph-item">
        <span class="eph-label">Input Depth</span>
        <span class="eph-value">{_fmt(input_depth, 0, " ppm")}</span>
      </div>
    </div>"""

    return f"""\
<div class="header">
  <h1>{title_text}</h1>
  {subtitle_html}
  {eph_items}
</div>"""


# -- LC Summary section -------------------------------------------------------


def _lc_summary_section(data: dict[str, Any]) -> str:
    lc = data.get("lc_summary")
    if not lc:
        return ""

    def _vital(label: str, value: str) -> str:
        return f"""\
      <div class="vital">
        <div class="vital-label">{label}</div>
        <div class="vital-value">{value}</div>
      </div>"""

    depth_str = _fmt(lc.get("depth_ppm"), 0, " ppm")
    err = lc.get("depth_err_ppm")
    if err is not None:
        depth_str += f" &plusmn; {_fmt(err, 0)}"

    vitals = [
        _vital("SNR", _fmt(lc.get("snr"), 1)),
        _vital("Depth", depth_str),
        _vital("Transits", _fmt(lc.get("n_transits"))),
        _vital("In-transit pts", _fmt(lc.get("n_in_transit_total"))),
        _vital("Scatter (std)", _fmt(lc.get("flux_std_ppm"), 0, " ppm")),
        _vital("Scatter (MAD)", _fmt(lc.get("flux_mad_ppm"), 0, " ppm")),
        _vital("Cadence", _fmt(lc.get("cadence_seconds"), 0, " s")),
        _vital("Baseline", _fmt(lc.get("duration_days"), 1, " d")),
        _vital("Gap fraction", _fmt(lc.get("gap_fraction"), 3)),
        _vital("Points", f"{_fmt(lc.get('n_valid'))} / {_fmt(lc.get('n_points'))}"),
    ]

    return f"""\
<div class="summary-panel">
  <h2>Light Curve Summary</h2>
  <div class="vitals-grid">
{"".join(vitals)}
  </div>
</div>"""


def _lc_robustness_section(data: dict[str, Any]) -> str:
    lc_robustness = data.get("lc_robustness_summary")
    if not lc_robustness:
        return ""

    def _vital(label: str, value: str) -> str:
        return f"""\
      <div class="vital">
        <div class="vital-label">{label}</div>
        <div class="vital-value">{value}</div>
      </div>"""

    loto_triplet = (
        f"{_fmt(lc_robustness.get('loto_snr_min'), 2)} / "
        f"{_fmt(lc_robustness.get('loto_snr_mean'), 2)} / "
        f"{_fmt(lc_robustness.get('loto_snr_max'), 2)}"
    )
    beta_triplet = (
        f"{_fmt(lc_robustness.get('beta_30m'), 2)} / "
        f"{_fmt(lc_robustness.get('beta_60m'), 2)} / "
        f"{_fmt(lc_robustness.get('beta_duration'), 2)}"
    )

    vitals = [
        _vital("LC Robustness Version", _fmt(lc_robustness.get("version"))),
        _vital("Epochs (stored/measured)", f"{_fmt(lc_robustness.get('n_epochs_stored'))} / {_fmt(lc_robustness.get('n_epochs_measured'))}"),
        _vital("Dominance Index", _fmt(lc_robustness.get("dominance_index"), 3)),
        _vital("LOTO SNR (min/mean/max)", loto_triplet),
        _vital("LOTO Depth Shift", _fmt(lc_robustness.get("loto_depth_shift_ppm_max"), 1, " ppm")),
        _vital("Red Noise β (30m/60m/dur)", beta_triplet),
        _vital("Odd-Even Δ Depth", _fmt(lc_robustness.get("odd_even_depth_diff_sigma"), 2, " sigma")),
        _vital("Secondary Depth", _fmt(lc_robustness.get("secondary_depth_sigma"), 2, " sigma")),
        _vital("Phase 0.5 Depth", _fmt(lc_robustness.get("phase_0p5_bin_depth_ppm"), 1, " ppm")),
    ]

    return f"""\
<div class="summary-panel">
  <h2>LC Robustness Summary</h2>
  <p class="section-note">Computed LC-only fragility and false-positive summary metrics.</p>
  <div class="vitals-grid">
{"".join(vitals)}
  </div>
</div>"""


def _enrichment_section(data: dict[str, Any]) -> str:
    enrichment = data.get("enrichment")
    if not enrichment:
        return ""

    cards = [
        _enrichment_block_card("Pixel Diagnostics", enrichment.get("pixel_diagnostics")),
        _enrichment_block_card("Catalog Context", enrichment.get("catalog_context")),
        _enrichment_block_card("Followup Context", enrichment.get("followup_context")),
    ]

    return f"""\
<div class="checks-panel">
  <h2>Enrichment Summary</h2>
  <p class="section-note">Operational block status only (not scientific pass/fail).</p>
  <div class="checks-grid">
{"".join(cards)}
  </div>
</div>"""


def _custom_views_section(data: dict[str, Any]) -> str:
    custom_views = data.get("custom_views")
    views = custom_views.get("views") if isinstance(custom_views, dict) else None
    if not isinstance(views, list) or not views:
        return ""

    cards: list[str] = []
    for i, raw_view in enumerate(views):
        view = raw_view if isinstance(raw_view, dict) else {}
        title = str(view.get("title") or view.get("id") or f"Custom View {i + 1}")
        chart = view.get("chart", {})
        chart_type = str(chart.get("type") if isinstance(chart, dict) else "").strip().lower()
        quality = view.get("quality", {})
        declared_status = (
            str(quality.get("status") if isinstance(quality, dict) else "").strip().lower()
        )
        raw_flags = quality.get("flags") if isinstance(quality, dict) else []
        flags = raw_flags if isinstance(raw_flags, list) else []
        reason = ", ".join(str(flag) for flag in flags if str(flag).strip())

        status = "ready"
        if declared_status in {"unavailable", "degraded"}:
            status = declared_status
        elif chart_type and chart_type not in {"scatter", "line", "bar"}:
            status = "unsupported"
            if not reason:
                reason = f"Unsupported chart_type '{chart_type}'."

        status_label = status.upper()
        note_html = (
            f'<p id="custom-view-note-{i}" class="plot-status-note">{_esc(reason)}</p>'
            if reason
            else f'<p id="custom-view-note-{i}" class="plot-status-note"></p>'
        )
        cards.append(
            f"""\
<div class="plot-panel">
  <h2>{_esc(title)}<span id="custom-view-status-{i}" class="custom-view-status {_esc(status)}">{_esc(status_label)}</span></h2>
  {note_html}
  <div id="custom-view-plot-{i}" class="plot-container"></div>
</div>"""
        )

    return (
        '<div class="summary-panel"><h2>Custom Views</h2>'
        '<p class="section-note">User-defined chart views rendered from report payload data only.</p></div>'
        + "".join(cards)
    )


def _enrichment_block_card(label: str, block: dict[str, Any] | None) -> str:
    if block is None:
        status = "skipped"
        flags: list[str] = ["BLOCK_DISABLED"]
        quality: dict[str, Any] = {}
        provenance: dict[str, Any] = {}
        payload: dict[str, Any] = {}
    else:
        status = str(block.get("status", "skipped"))
        flags = list(block.get("flags", []))
        quality = dict(block.get("quality", {}))
        provenance = dict(block.get("provenance", {}))
        payload = dict(block.get("payload", {}))

    status_cls = status if status in {"ok", "error", "skipped"} else "skipped"
    status_label = {"ok": "READY", "error": "ERROR", "skipped": "SKIPPED"}[status_cls]
    flags_html = (
        f'<div class="check-flags">{_esc(", ".join(str(f) for f in flags))}</div>' if flags else ""
    )

    quality_items = "".join(
        f"<span><strong>{_esc(str(k))}:</strong> {_esc(str(v))}</span>"
        for k, v in sorted(quality.items())
    )
    quality_html = f'<div class="check-metrics">{quality_items}</div>' if quality_items else ""

    prov_bits: list[str] = []
    block_name = provenance.get("block")
    if block_name is not None:
        prov_bits.append(f"<span><strong>block:</strong> {_esc(str(block_name))}</span>")
    budget = provenance.get("budget")
    if isinstance(budget, dict):
        for k in ("budget_applied", "n_points", "max_pixel_points"):
            if k in budget:
                prov_bits.append(f"<span><strong>{_esc(k)}:</strong> {_esc(str(budget[k]))}</span>")
    if "cache_hit" in provenance:
        prov_bits.append(f"<span><strong>cache_hit:</strong> {_esc(str(provenance['cache_hit']))}</span>")
    if "sector_selected" in provenance:
        prov_bits.append(
            f"<span><strong>sector_selected:</strong> {_esc(str(provenance['sector_selected']))}</span>"
        )
    if "selected_sector" in payload:
        prov_bits.append(
            f"<span><strong>selected_sector:</strong> {_esc(str(payload['selected_sector']))}</span>"
        )
    if "n_checks" in payload:
        prov_bits.append(f"<span><strong>n_checks:</strong> {_esc(str(payload['n_checks']))}</span>")
    if "catalog_rows" in payload:
        prov_bits.append(
            f"<span><strong>catalog_rows:</strong> {_esc(str(payload['catalog_rows']))}</span>"
        )
    prov_html = f'<div class="check-metrics">{"".join(prov_bits)}</div>' if prov_bits else ""

    return f"""\
    <div class="check-card {status_cls}">
      <div class="check-header">
        <span class="check-id">{_esc(label)}</span>
        <span class="check-status {status_cls}">{_esc(status_label)}</span>
      </div>
      {quality_html}
      {prov_html}
      {flags_html}
    </div>"""


# -- Checks section -----------------------------------------------------------


def _checks_section(data: dict[str, Any]) -> str:
    checks = data.get("checks", {})
    bundle = data.get("bundle_summary")

    if not checks:
        return ""

    # Bundle bar
    bundle_html = ""
    if bundle:
        bundle_html = f"""\
  <div class="bundle-bar">
    <span class="bundle-stat bundle-ok">{bundle.get("n_ok", 0)} passed</span>
    <span class="bundle-stat bundle-fail">{bundle.get("n_failed", 0)} failed</span>
    <span class="bundle-stat bundle-skip">{bundle.get("n_skipped", 0)} skipped</span>
  </div>"""

    # Order by check ID
    ordered = data.get("checks_run", sorted(checks.keys()))
    cards = []
    for cid in ordered:
        cr = checks.get(cid)
        if cr is None:
            continue
        cards.append(_check_card(cid, cr))

    return f"""\
<div class="checks-panel">
  <h2>Check Results</h2>
  {bundle_html}
  <div class="checks-grid">
{"".join(cards)}
  </div>
</div>"""


def _slugify(text: str) -> str:
    parts = [c.lower() if c.isalnum() else "-" for c in text]
    slug = "".join(parts).strip("-")
    while "--" in slug:
        slug = slug.replace("--", "-")
    return slug or "ref"


def _bibliography_section(data: dict[str, Any]) -> str:
    references = data.get("references")
    if not isinstance(references, list) or not references:
        return ""

    entries: list[str] = []
    for ref in references:
        if not isinstance(ref, dict):
            continue
        key = str(ref.get("key", "")).strip()
        if not key:
            continue

        anchor_id = f"ref-{_slugify(key)}"
        citation = ref.get("citation")
        title = ref.get("title")
        authors = ref.get("authors")
        year = ref.get("year")
        venue = ref.get("venue")
        doi = ref.get("doi")
        url = ref.get("url")
        notes = ref.get("notes")

        if isinstance(citation, str) and citation.strip():
            body = _esc(citation.strip())
        else:
            pieces: list[str] = []
            if isinstance(authors, list) and authors:
                pieces.append(", ".join(_esc(str(a)) for a in authors if str(a).strip()))
            if year is not None:
                pieces.append(_esc(str(year)))
            if isinstance(title, str) and title.strip():
                pieces.append(_esc(title.strip()))
            if isinstance(venue, str) and venue.strip():
                pieces.append(_esc(venue.strip()))
            if isinstance(doi, str) and doi.strip():
                pieces.append(f"DOI: {_esc(doi.strip())}")
            if isinstance(url, str) and url.strip():
                safe_url = _esc(url.strip())
                pieces.append(f'<a href="{safe_url}" target="_blank" rel="noopener noreferrer">{safe_url}</a>')
            body = " · ".join(pieces) if pieces else "&mdash;"

        notes_html = ""
        if isinstance(notes, list) and notes:
            joined_notes = "; ".join(_esc(str(n)) for n in notes if str(n).strip())
            if joined_notes:
                notes_html = f'<div class="bibliography-notes">{joined_notes}</div>'

        entries.append(
            f'<li id="{_esc(anchor_id)}"><span class="bibliography-key">[{_esc(key)}]</span> {body}{notes_html}</li>'
        )

    if not entries:
        return ""

    return f"""\
<div class="summary-panel">
  <h2>Bibliography</h2>
  <ol class="bibliography-list">
    {"".join(entries)}
  </ol>
</div>"""


def _check_card(check_id: str, cr: dict[str, Any]) -> str:
    status = cr.get("status", "skipped")
    name = cr.get("name", "")
    metrics = cr.get("metrics", {})
    flags = cr.get("flags", [])
    notes = cr.get("notes", [])
    method_refs = cr.get("method_refs", [])

    # Metrics display
    metrics_html = ""
    if metrics:
        spans = []
        for k, v in metrics.items():
            spans.append(f"<span><strong>{_esc(str(k))}:</strong> {_esc(str(v))}</span>")
        metrics_html = f'<div class="check-metrics">{"".join(spans)}</div>'

    # Flags display
    flags_html = ""
    if flags:
        flags_html = f'<div class="check-flags">{_esc(", ".join(str(f) for f in flags))}</div>'

    # Notes display
    notes_html = ""
    if notes:
        notes_html = f'<div class="check-notes">{_esc("; ".join(str(n) for n in notes))}</div>'

    method_refs_html = ""
    if isinstance(method_refs, list) and method_refs:
        links = []
        for ref in method_refs:
            ref_text = str(ref).strip()
            if not ref_text:
                continue
            links.append(
                f'<a href="#ref-{_esc(_slugify(ref_text))}" '
                f'data-method-ref="{_esc(ref_text)}">{_esc(ref_text)}</a>'
            )
        if links:
            method_refs_html = f'<div class="check-methods"><strong>Methods:</strong> {", ".join(links)}</div>'

    return f"""\
    <div class="check-card {_esc(status)}" data-check-id="{_esc(check_id)}">
      <div class="check-header">
        <span class="check-id">{_esc(check_id)}</span>
        <span class="check-name">{_esc(name)}</span>
        <span class="check-status {_esc(status)}">{_esc(status)}</span>
      </div>
      {metrics_html}
      {method_refs_html}
      {flags_html}
      {notes_html}
    </div>"""


# -- Plotly JS builders -------------------------------------------------------


def _plotly_layout_defaults() -> str:
    """Return a JS object string with shared Plotly layout defaults."""
    return f"""\
{{
    paper_bgcolor: '{_BG_CARD}',
    plot_bgcolor: '{_BG}',
    font: {{ family: 'Menlo, Consolas, Monaco, monospace', color: '{_TEXT}', size: 11 }},
    margin: {{ t: 30, r: 20, b: 50, l: 60 }},
    xaxis: {{
      gridcolor: '{_BG_SURFACE}',
      zerolinecolor: '{_BG_SURFACE}',
    }},
    yaxis: {{
      gridcolor: '{_BG_SURFACE}',
      zerolinecolor: '{_BG_SURFACE}',
    }},
    legend: {{
      bgcolor: 'rgba(0,0,0,0)',
      font: {{ size: 10 }},
    }},
  }}"""


def _percentile_helper_js() -> str:
    """Return a JS function for computing percentile-based y-axis range."""
    return """\
function percentileRange(values, lo, hi, pad) {
  // Compute percentile-based y-axis range with padding.
  // lo/hi are percentiles (0-100), pad is fractional padding (e.g. 0.1).
  var sorted = values.slice().filter(function(v) { return isFinite(v); });
  if (sorted.length === 0) return null;
  sorted.sort(function(a, b) { return a - b; });
  var loIdx = Math.floor(lo / 100.0 * (sorted.length - 1));
  var hiIdx = Math.ceil(hi / 100.0 * (sorted.length - 1));
  var yLo = sorted[loIdx];
  var yHi = sorted[hiIdx];
  var span = yHi - yLo;
  if (span <= 0) span = Math.abs(yHi) * 0.01 || 1e-6;
  return [yLo - pad * span, yHi + pad * span];
}"""


def _full_lc_js() -> str:
    return f"""\
(function() {{
  var d = REPORT.plot_data ? REPORT.plot_data.full_lc : null;
  if (!d) return;

  var ootTime = [], ootFlux = [], itTime = [], itFlux = [];
  for (var i = 0; i < d.time.length; i++) {{
    if (d.transit_mask[i]) {{
      itTime.push(d.time[i]);
      itFlux.push(d.flux[i]);
    }} else {{
      ootTime.push(d.time[i]);
      ootFlux.push(d.flux[i]);
    }}
  }}

  // Percentile-based y-axis range (2nd-98th with 10% padding)
  var yRange = percentileRange(d.flux, 2, 98, 0.1);

  var traceOOT = {{
    x: ootTime, y: ootFlux,
    mode: 'markers',
    type: 'scattergl',
    marker: {{ color: '{_OOT_COLOR}', size: 2, opacity: 0.5 }},
    name: 'Out-of-transit',
  }};

  var traceIT = {{
    x: itTime, y: itFlux,
    mode: 'markers',
    type: 'scattergl',
    marker: {{ color: '{_TRANSIT_COLOR}', size: 3, opacity: 0.8 }},
    name: 'In-transit',
  }};

  var yaxisCfg = Object.assign({{}}, {_plotly_layout_defaults()}.yaxis, {{
    title: {{ text: 'Normalized Flux', standoff: 8 }},
  }});
  if (yRange) yaxisCfg.range = yRange;

  var layout = Object.assign({{}}, {_plotly_layout_defaults()}, {{
    xaxis: Object.assign({{}}, {_plotly_layout_defaults()}.xaxis, {{
      title: {{ text: 'Time (BTJD)', standoff: 8 }},
    }}),
    yaxis: yaxisCfg,
  }});

  Plotly.newPlot('full-lc-plot', [traceOOT, traceIT], layout, {{responsive: true}});
}})();"""


def _phase_folded_js() -> str:
    return f"""\
(function() {{
  var d = REPORT.plot_data ? REPORT.plot_data.phase_folded : null;
  if (!d) return;

  var phaseRange = d.phase_range;
  var halfDur = d.transit_duration_phase / 2.0;

  // Raw scatter (within view range for performance)
  var rawPhase = [], rawFlux = [];
  for (var i = 0; i < d.phase.length; i++) {{
    rawPhase.push(d.phase[i]);
    rawFlux.push(d.flux[i]);
  }}

  // Percentile-based y-axis range (2nd-98th with 10% padding)
  var yRange = percentileRange(d.flux, 2, 98, 0.1);

  var traceRaw = {{
    x: rawPhase, y: rawFlux,
    mode: 'markers',
    type: 'scattergl',
    marker: {{ color: '{_OOT_COLOR}', size: 2, opacity: 0.3 }},
    name: 'Raw',
  }};

  // Binned data with error bars
  var binErr = [];
  var binErrVisible = [];
  for (var i = 0; i < d.bin_err.length; i++) {{
    if (d.bin_err[i] !== null) {{
      binErr.push(d.bin_err[i]);
      binErrVisible.push(true);
    }} else {{
      binErr.push(0);
      binErrVisible.push(false);
    }}
  }}

  // Build asymmetric error bars that respect per-point visibility
  // (Plotly doesn't support per-point visible, so set to 0 for hidden)
  var traceBin = {{
    x: d.bin_centers, y: d.bin_flux,
    mode: 'markers',
    type: 'scatter',
    marker: {{ color: '{_BIN_COLOR}', size: 8, symbol: 'circle' }},
    error_y: {{
      type: 'data',
      array: binErr,
      visible: true,
      color: '{_BIN_COLOR}',
      thickness: 2,
      width: 4,
    }},
    name: 'Binned (' + d.bin_minutes + ' min)',
  }};

  // Transit duration shaded region
  var shapes = [
    {{
      type: 'rect',
      x0: -halfDur, x1: halfDur,
      y0: 0, y1: 1,
      xref: 'x', yref: 'paper',
      fillcolor: '{_TRANSIT_COLOR}',
      opacity: 0.08,
      line: {{ width: 0 }},
    }},
    {{
      type: 'line',
      x0: -halfDur, x1: -halfDur,
      y0: 0, y1: 1,
      xref: 'x', yref: 'paper',
      line: {{ color: '{_TRANSIT_COLOR}', width: 1, dash: 'dot' }},
    }},
    {{
      type: 'line',
      x0: halfDur, x1: halfDur,
      y0: 0, y1: 1,
      xref: 'x', yref: 'paper',
      line: {{ color: '{_TRANSIT_COLOR}', width: 1, dash: 'dot' }},
    }},
  ];

  // Transit depth reference line (if input_depth_ppm is available)
  var depthPpm = (REPORT.summary && REPORT.summary.input_depth_ppm != null) ? REPORT.summary.input_depth_ppm : null;
  if (depthPpm !== null) {{
    var depthFlux = 1.0 - depthPpm / 1e6;
    shapes.push({{
      type: 'line',
      x0: phaseRange[0], x1: phaseRange[1],
      y0: depthFlux, y1: depthFlux,
      xref: 'x', yref: 'y',
      line: {{ color: '{_ACCENT}', width: 1.5, dash: 'dash' }},
    }});
  }}

  var yaxisCfg = Object.assign({{}}, {_plotly_layout_defaults()}.yaxis, {{
    title: {{ text: 'Normalized Flux', standoff: 8 }},
  }});
  if (yRange) yaxisCfg.range = yRange;

  var layout = Object.assign({{}}, {_plotly_layout_defaults()}, {{
    xaxis: Object.assign({{}}, {_plotly_layout_defaults()}.xaxis, {{
      title: {{ text: 'Orbital Phase', standoff: 8 }},
      range: [phaseRange[0], phaseRange[1]],
    }}),
    yaxis: yaxisCfg,
    shapes: shapes,
  }});

  Plotly.newPlot('phase-plot', [traceRaw, traceBin], layout, {{responsive: true}});
}})();"""


def _per_transit_stack_js() -> str:
    return f"""\
(function() {{
  var d = REPORT.plot_data ? REPORT.plot_data.per_transit_stack : null;
  if (!d || !d.windows || d.windows.length === 0) return;

  var allFlux = [];
  for (var i = 0; i < d.windows.length; i++) {{
    var w = d.windows[i];
    for (var j = 0; j < w.flux.length; j++) allFlux.push(w.flux[j]);
  }}
  var yBase = percentileRange(allFlux, 2, 98, 0.0);
  var span = (yBase && yBase[1] > yBase[0]) ? (yBase[1] - yBase[0]) : 0.002;
  var offset = span * 1.4;

  var traces = [];
  for (var i = 0; i < d.windows.length; i++) {{
    var w = d.windows[i];
    var y = [];
    for (var j = 0; j < w.flux.length; j++) y.push(w.flux[j] + i * offset);
    traces.push({{
      x: w.dt_hours,
      y: y,
      mode: 'markers',
      type: 'scattergl',
      marker: {{ color: '{_OOT_COLOR}', size: 3, opacity: 0.55 }},
      name: 'E' + w.epoch,
      showlegend: false,
      hovertemplate: 'Epoch ' + w.epoch + '<br>dt=%{{x:.2f}} h<br>flux=%{{customdata:.6f}}<extra></extra>',
      customdata: w.flux,
    }});

    var xIT = [], yIT = [];
    for (var j = 0; j < w.dt_hours.length; j++) {{
      if (w.in_transit_mask[j]) {{
        xIT.push(w.dt_hours[j]);
        yIT.push(w.flux[j] + i * offset);
      }}
    }}
    if (xIT.length > 0) {{
      traces.push({{
        x: xIT,
        y: yIT,
        mode: 'markers',
        type: 'scattergl',
        marker: {{ color: '{_TRANSIT_COLOR}', size: 4, opacity: 0.85 }},
        showlegend: false,
        hoverinfo: 'skip',
      }});
    }}
  }}

  var shapes = [
    {{
      type: 'rect',
      x0: -(d.window_half_hours / 3.0) / 2.0,
      x1: (d.window_half_hours / 3.0) / 2.0,
      y0: 0, y1: 1,
      xref: 'x', yref: 'paper',
      fillcolor: '{_TRANSIT_COLOR}',
      opacity: 0.06,
      line: {{ width: 0 }},
    }}
  ];

  var layout = Object.assign({{}}, {_plotly_layout_defaults()}, {{
    xaxis: Object.assign({{}}, {_plotly_layout_defaults()}.xaxis, {{
      title: {{ text: 'Hours From Transit Midpoint', standoff: 8 }},
      range: [-d.window_half_hours, d.window_half_hours],
    }}),
    yaxis: Object.assign({{}}, {_plotly_layout_defaults()}.yaxis, {{
      title: {{ text: 'Flux (Stacked Offsets)', standoff: 8 }},
      showticklabels: false,
    }}),
    shapes: shapes,
  }});

  Plotly.newPlot('per-transit-plot', traces, layout, {{responsive: true}});
}})();"""


def _odd_even_js() -> str:
    return f"""\
(function() {{
  var d = REPORT.plot_data ? REPORT.plot_data.odd_even_phase : null;
  if (!d) return;

  var traces = [];
  if (d.odd_phase && d.odd_phase.length > 0) {{
    traces.push({{
      x: d.odd_phase, y: d.odd_flux,
      mode: 'markers',
      type: 'scattergl',
      marker: {{ color: '{_OOT_COLOR}', size: 2, opacity: 0.28 }},
      name: 'Odd (raw)',
    }});
  }}
  if (d.even_phase && d.even_phase.length > 0) {{
    traces.push({{
      x: d.even_phase, y: d.even_flux,
      mode: 'markers',
      type: 'scattergl',
      marker: {{ color: '{_ACCENT}', size: 2, opacity: 0.28 }},
      name: 'Even (raw)',
    }});
  }}
  if (d.odd_bin_centers && d.odd_bin_centers.length > 0) {{
    traces.push({{
      x: d.odd_bin_centers, y: d.odd_bin_flux,
      mode: 'lines+markers',
      type: 'scatter',
      line: {{ color: '{_OOT_COLOR}', width: 2 }},
      marker: {{ size: 5 }},
      name: 'Odd (binned)',
    }});
  }}
  if (d.even_bin_centers && d.even_bin_centers.length > 0) {{
    traces.push({{
      x: d.even_bin_centers, y: d.even_bin_flux,
      mode: 'lines+markers',
      type: 'scatter',
      line: {{ color: '{_ACCENT}', width: 2 }},
      marker: {{ size: 5 }},
      name: 'Even (binned)',
    }});
  }}
  if (traces.length === 0) return;

  var allFlux = [];
  if (d.odd_flux) allFlux = allFlux.concat(d.odd_flux);
  if (d.even_flux) allFlux = allFlux.concat(d.even_flux);
  var yRange = percentileRange(allFlux, 2, 98, 0.12);

  var yaxisCfg = Object.assign({{}}, {_plotly_layout_defaults()}.yaxis, {{
    title: {{ text: 'Normalized Flux', standoff: 8 }},
  }});
  if (yRange) yaxisCfg.range = yRange;

  var layout = Object.assign({{}}, {_plotly_layout_defaults()}, {{
    xaxis: Object.assign({{}}, {_plotly_layout_defaults()}.xaxis, {{
      title: {{ text: 'Orbital Phase', standoff: 8 }},
      range: d.phase_range,
    }}),
    yaxis: yaxisCfg,
  }});

  Plotly.newPlot('odd-even-plot', traces, layout, {{responsive: true}});
}})();"""


def _local_detrend_js() -> str:
    return f"""\
(function() {{
  var d = REPORT.plot_data ? REPORT.plot_data.local_detrend : null;
  if (!d || !d.windows || d.windows.length === 0) return;

  var allResidual = [];
  for (var i = 0; i < d.windows.length; i++) {{
    var w = d.windows[i];
    for (var j = 0; j < w.flux.length; j++) {{
      var f = w.flux[j];
      var b = w.baseline_flux[j];
      if (isFinite(f) && isFinite(b)) allResidual.push(f - b);
    }}
  }}
  var yBase = percentileRange(allResidual, 2, 98, 0.0);
  var span = (yBase && yBase[1] > yBase[0]) ? (yBase[1] - yBase[0]) : 0.0008;
  var offset = span * 1.8;

  var traces = [];
  for (var i = 0; i < d.windows.length; i++) {{
    var w = d.windows[i];
    var yResidual = [];
    var yZeroLine = [];
    var residualPpm = [];
    for (var j = 0; j < w.flux.length; j++) {{
      var f = w.flux[j];
      var b = w.baseline_flux[j];
      if (isFinite(f) && isFinite(b)) {{
        var r = f - b;
        yResidual.push(r + i * offset);
        residualPpm.push(r * 1e6);
      }} else {{
        yResidual.push(null);
        residualPpm.push(null);
      }}
      yZeroLine.push(i * offset);
    }}
    traces.push({{
      x: w.dt_hours,
      y: yResidual,
      mode: 'markers',
      type: 'scattergl',
      marker: {{ color: '{_OOT_COLOR}', size: 3, opacity: 0.45 }},
      name: 'E' + w.epoch + ' residual',
      showlegend: false,
      hovertemplate: 'Epoch ' + w.epoch + '<br>dt=%{{x:.2f}} h<br>resid=%{{customdata:.0f}} ppm<extra></extra>',
      customdata: residualPpm,
    }});
    traces.push({{
      x: w.dt_hours,
      y: yZeroLine,
      mode: 'lines',
      type: 'scatter',
      line: {{ color: '{_ACCENT}', width: 1.3 }},
      name: 'E' + w.epoch + ' baseline zero',
      showlegend: false,
      hoverinfo: 'skip',
    }});

    var xIT = [], yIT = [];
    for (var j = 0; j < w.dt_hours.length; j++) {{
      if (w.in_transit_mask[j]) {{
        var f = w.flux[j];
        var b = w.baseline_flux[j];
        if (!isFinite(f) || !isFinite(b)) continue;
        var r = f - b;
        xIT.push(w.dt_hours[j]);
        yIT.push(r + i * offset);
      }}
    }}
    if (xIT.length > 0) {{
      traces.push({{
        x: xIT,
        y: yIT,
        mode: 'markers',
        type: 'scattergl',
        marker: {{ color: '{_TRANSIT_COLOR}', size: 4, opacity: 0.85 }},
        showlegend: false,
        hoverinfo: 'skip',
      }});
    }}
  }}

  var halfTransitHours = (d.window_half_hours / 3.0) / 2.0;
  var shapes = [
    {{
      type: 'rect',
      x0: -halfTransitHours,
      x1: halfTransitHours,
      y0: 0, y1: 1,
      xref: 'x', yref: 'paper',
      fillcolor: '{_TRANSIT_COLOR}',
      opacity: 0.05,
      line: {{ width: 0 }},
    }}
  ];

  var layout = Object.assign({{}}, {_plotly_layout_defaults()}, {{
    xaxis: Object.assign({{}}, {_plotly_layout_defaults()}.xaxis, {{
      title: {{ text: 'Hours From Transit Midpoint', standoff: 8 }},
      range: [-d.window_half_hours, d.window_half_hours],
    }}),
    yaxis: Object.assign({{}}, {_plotly_layout_defaults()}.yaxis, {{
      title: {{ text: 'Flux - Local Baseline (Stacked)', standoff: 8 }},
      showticklabels: false,
    }}),
    shapes: shapes,
  }});

  Plotly.newPlot('local-detrend-plot', traces, layout, {{responsive: true}});
}})();"""


def _secondary_scan_js() -> str:
    return f"""\
(function() {{
  var d = REPORT.plot_data ? REPORT.plot_data.secondary_scan : null;
  if (!d) return;
  var hints = d.render_hints || {{}};

  var traceRaw = {{
    x: d.phase, y: d.flux,
    mode: 'markers',
    type: 'scattergl',
    marker: {{
      color: '{_OOT_COLOR}',
      size: 2,
      opacity: (hints.raw_marker_opacity != null) ? hints.raw_marker_opacity : 0.25
    }},
    name: 'Raw',
  }};

  var connectBins = (hints.connect_bins !== false);
  var maxGap = (hints.max_connect_phase_gap != null) ? hints.max_connect_phase_gap : 0.02;
  var showErrorBars = (hints.show_error_bars === true);
  var errStride = Math.max(1, (hints.error_bar_stride != null) ? hints.error_bar_stride : 1);
  var styleMode = (hints.style_mode != null) ? hints.style_mode : 'normal';

  var binnedMode;
  if (styleMode === 'normal') {{
    binnedMode = 'lines';
  }} else {{
    binnedMode = connectBins ? 'lines+markers' : 'markers';
  }}
  var lineWidth = (hints.binned_line_width != null) ? hints.binned_line_width : 1.5;
  var markerSize = (hints.binned_marker_size != null) ? hints.binned_marker_size : 5;
  var lineOpacity = (styleMode === 'normal') ? 0.8 : 1.0;

  var binX = [];
  var binY = [];
  if (connectBins) {{
    for (var i = 0; i < d.bin_centers.length; i++) {{
      if (i > 0 && (d.bin_centers[i] - d.bin_centers[i - 1]) > maxGap) {{
        // Break line across sparse/gap regions to avoid misleading zig-zags.
        binX.push(null);
        binY.push(null);
      }}
      binX.push(d.bin_centers[i]);
      binY.push(d.bin_flux[i]);
    }}
  }} else {{
    binX = d.bin_centers.slice();
    binY = d.bin_flux.slice();
  }}

  var binErr = [];
  for (var i = 0; i < d.bin_err.length; i++) {{
    var e = d.bin_err[i];
    if (!showErrorBars || e === null || (i % errStride) !== 0) {{
      binErr.push(0);
    }} else {{
      binErr.push(e);
    }}
  }}

  var traceBin = {{
    x: binX, y: binY,
    mode: binnedMode,
    type: 'scatter',
    connectgaps: false,
    opacity: lineOpacity,
    line: {{ color: '{_BIN_COLOR}', width: lineWidth }},
    marker: {{ color: '{_BIN_COLOR}', size: markerSize }},
    error_y: {{
      type: 'data',
      array: binErr,
      visible: showErrorBars
    }},
    name: 'Binned (' + d.bin_minutes + ' min)',
  }};

  var shapes = [
    {{
      type: 'line',
      x0: d.primary_phase, x1: d.primary_phase,
      y0: 0, y1: 1,
      xref: 'x', yref: 'paper',
      line: {{ color: '{_TRANSIT_COLOR}', width: 1.5, dash: 'dot' }},
    }},
    {{
      type: 'line',
      x0: d.secondary_phase, x1: d.secondary_phase,
      y0: 0, y1: 1,
      xref: 'x', yref: 'paper',
      line: {{ color: '{_ACCENT}', width: 1.5, dash: 'dot' }},
    }},
  ];

  var ann = [];
  if (d.strongest_dip_phase !== null && d.strongest_dip_flux !== null) {{
    ann.push({{
      x: d.strongest_dip_phase,
      y: d.strongest_dip_flux,
      xref: 'x',
      yref: 'y',
      text: 'strongest dip',
      showarrow: true,
      arrowcolor: '{_TEXT_DIM}',
      font: {{ color: '{_TEXT_DIM}', size: 10 }},
      ax: 0,
      ay: -30,
    }});
  }}

  var yRange = percentileRange(d.flux, 2, 98, 0.12);
  var yaxisCfg = Object.assign({{}}, {_plotly_layout_defaults()}.yaxis, {{
    title: {{ text: 'Normalized Flux', standoff: 8 }},
  }});
  if (yRange) yaxisCfg.range = yRange;

  var layout = Object.assign({{}}, {_plotly_layout_defaults()}, {{
    xaxis: Object.assign({{}}, {_plotly_layout_defaults()}.xaxis, {{
      title: {{ text: 'Orbital Phase', standoff: 8 }},
      range: [-0.5, 0.5],
    }}),
    yaxis: yaxisCfg,
    shapes: shapes,
    annotations: ann,
  }});

  Plotly.newPlot('secondary-scan-plot', [traceRaw, traceBin], layout, {{responsive: true}});
}})();"""


def _oot_context_js() -> str:
    return f"""\
(function() {{
  var d = REPORT.plot_data ? REPORT.plot_data.oot_context : null;
  if (!d) return;
  var hasHist = d.hist_centers && d.hist_centers.length > 0;
  var hasSample = d.flux_residual_ppm_sample && d.flux_residual_ppm_sample.length > 0;
  if (!hasHist && !hasSample) return;

  var traces = [];
  if (hasSample) {{
    traces.push({{
      x: d.sample_indices,
      y: d.flux_residual_ppm_sample,
      mode: 'markers',
      type: 'scattergl',
      marker: {{ color: '{_OOT_COLOR}', size: 2, opacity: 0.35 }},
      name: 'OOT sample',
      xaxis: 'x2',
      yaxis: 'y2',
    }});
  }}
  if (hasHist) {{
    traces.push({{
      x: d.hist_centers,
      y: d.hist_counts,
      type: 'bar',
      marker: {{ color: '{_BIN_COLOR}', opacity: 0.7 }},
      name: 'Histogram',
      xaxis: 'x',
      yaxis: 'y',
    }});
  }}

  var annText = '';
  if (d.robust_sigma_ppm !== null) annText += 'robust sigma: ' + d.robust_sigma_ppm.toFixed(0) + ' ppm';
  if (d.mad_ppm !== null) annText += (annText ? ' | ' : '') + 'MAD: ' + d.mad_ppm.toFixed(0) + ' ppm';
  if (d.std_ppm !== null) annText += (annText ? ' | ' : '') + 'std: ' + d.std_ppm.toFixed(0) + ' ppm';
  if (d.n_oot_points !== null) annText += (annText ? ' | ' : '') + 'N=' + d.n_oot_points;

  var layout = Object.assign({{}}, {_plotly_layout_defaults()}, {{
    grid: {{rows: 1, columns: 2, pattern: 'independent'}},
    xaxis: Object.assign({{}}, {_plotly_layout_defaults()}.xaxis, {{
      title: {{ text: 'OOT Residual (ppm)', standoff: 8 }},
    }}),
    yaxis: Object.assign({{}}, {_plotly_layout_defaults()}.yaxis, {{
      title: {{ text: 'Count', standoff: 8 }},
    }}),
    xaxis2: Object.assign({{}}, {_plotly_layout_defaults()}.xaxis, {{
      title: {{ text: 'Sample Index (OOT)', standoff: 8 }},
    }}),
    yaxis2: Object.assign({{}}, {_plotly_layout_defaults()}.yaxis, {{
      title: {{ text: 'OOT Residual (ppm)', standoff: 8 }},
    }}),
    annotations: annText ? [{{
      text: annText,
      xref: 'paper',
      yref: 'paper',
      x: 0.5,
      y: 1.1,
      showarrow: false,
      font: {{ color: '{_TEXT_DIM}', size: 11 }},
    }}] : [],
  }});

  Plotly.newPlot('oot-context-plot', traces, layout, {{responsive: true}});
}})();"""


def _custom_views_js() -> str:
    return f"""\
(function() {{
  function customViewsFromReport() {{
    if (REPORT && REPORT.custom_views && Array.isArray(REPORT.custom_views.views)) {{
      return REPORT.custom_views.views;
    }}
    return [];
  }}

  function setViewState(index, state, note) {{
    var statusEl = document.getElementById('custom-view-status-' + index);
    var noteEl = document.getElementById('custom-view-note-' + index);
    if (statusEl) {{
      statusEl.textContent = String(state || 'UNAVAILABLE').toUpperCase();
      statusEl.className = 'custom-view-status ' + String(state || 'unavailable').toLowerCase();
    }}
    if (noteEl && note) {{
      noteEl.textContent = String(note);
    }}
  }}

  function decodePointerToken(token) {{
    return String(token).replace(/~1/g, '/').replace(/~0/g, '~');
  }}

  function resolvePath(path) {{
    if (typeof path !== 'string' || !path) return null;
    if (!path.startsWith('/')) return null;
    var tokens = path.split('/');
    if (tokens.length < 2 || tokens[0] !== '') return null;
    var rootToken = decodePointerToken(tokens[1]);
    if (rootToken !== 'summary' && rootToken !== 'plot_data') return null;

    var cur = rootToken === 'summary' ? REPORT.summary : REPORT.plot_data;
    for (var i = 2; i < tokens.length; i++) {{
      var key = decodePointerToken(tokens[i]);
      if (cur == null || typeof cur !== 'object' || !(key in cur)) return null;
      cur = cur[key];
    }}
    return cur;
  }}

  function toNumberArray(value) {{
    if (!Array.isArray(value)) return null;
    var out = [];
    for (var i = 0; i < value.length; i++) {{
      var n = value[i];
      if (typeof n !== 'number' || !isFinite(n)) return null;
      out.push(n);
    }}
    return out;
  }}

  var views = customViewsFromReport();
  if (!views.length) return;

  for (var i = 0; i < views.length; i++) {{
    var v = views[i];
    if (!v || typeof v !== 'object') {{
      setViewState(i, 'unsupported', 'View spec must be an object.');
      continue;
    }}

    var chart = (v && typeof v.chart === 'object') ? v.chart : null;
    var chartType = String((chart && chart.type) || '').toLowerCase();
    var quality = (v && typeof v.quality === 'object') ? v.quality : null;
    var declaredStatus = String((quality && quality.status) || '').toLowerCase();
    var flags = (quality && Array.isArray(quality.flags)) ? quality.flags : [];
    var reason = flags.length ? flags.join(', ') : '';
    if (declaredStatus === 'unavailable') {{
      setViewState(i, declaredStatus, reason || 'Marked by producer.');
      continue;
    }}
    if (chartType !== 'scatter' && chartType !== 'line' && chartType !== 'bar') {{
      setViewState(i, 'unsupported', 'Unsupported chart_type: ' + chartType);
      continue;
    }}

    var series = chart && Array.isArray(chart.series) ? chart.series : [];
    if (!series.length) {{
      setViewState(i, 'unavailable', 'No series provided.');
      continue;
    }}
    var traces = [];
    var viewDegraded = declaredStatus === 'degraded';
    var degradeReason = reason;

    for (var j = 0; j < series.length; j++) {{
      var s = series[j] || {{}};
      var xPath = (s.x && s.x.path) || null;
      var yPath = (s.y && s.y.path) || null;
      var yErrPath = (s.y_err && s.y_err.path) || null;
      var xVals = toNumberArray(resolvePath(xPath));
      var yVals = toNumberArray(resolvePath(yPath));
      if (!xVals || !yVals || xVals.length !== yVals.length || xVals.length === 0) {{
        viewDegraded = true;
        if (!degradeReason) degradeReason = 'Series data unavailable or invalid for x/y paths.';
        continue;
      }}

      var trace = {{
        x: xVals,
        y: yVals,
        name: String(s.label || ('Series ' + (j + 1))),
      }};
      var yErrVals = toNumberArray(resolvePath(yErrPath));
      if (yErrVals && yErrVals.length === yVals.length) {{
        trace.error_y = {{
          type: 'data',
          array: yErrVals,
          visible: true,
        }};
      }}
      if (chartType === 'bar') {{
        trace.type = 'bar';
      }} else {{
        trace.type = 'scattergl';
        trace.mode = chartType === 'line' ? 'lines' : 'markers';
        trace.marker = {{ size: 4, opacity: 0.75 }};
      }}
      traces.push(trace);
    }}

    if (!traces.length) {{
      setViewState(i, 'unavailable', degradeReason || 'No renderable series.');
      continue;
    }}

    var options = (chart && typeof chart.options === 'object') ? chart.options : {{}};
    var layout = Object.assign({{}}, {_plotly_layout_defaults()}, {{
      xaxis: Object.assign({{}}, {_plotly_layout_defaults()}.xaxis, {{
        title: {{ text: String(options.x_label || 'x'), standoff: 8 }},
        range: Array.isArray(options.x_range) ? options.x_range : undefined,
      }}),
      yaxis: Object.assign({{}}, {_plotly_layout_defaults()}.yaxis, {{
        title: {{ text: String(options.y_label || 'y'), standoff: 8 }},
        range: Array.isArray(options.y_range) ? options.y_range : undefined,
      }}),
      showlegend: options.legend !== false,
    }});

    try {{
      Plotly.newPlot('custom-view-plot-' + i, traces, layout, {{responsive: true}});
      if (viewDegraded) {{
        setViewState(i, 'degraded', degradeReason || 'Rendered with partial data.');
      }} else {{
        setViewState(i, 'ready', reason);
      }}
    }} catch (err) {{
      setViewState(i, 'unavailable', 'Render error: ' + (err && err.message ? err.message : 'unknown'));
    }}
  }}
}})();"""
