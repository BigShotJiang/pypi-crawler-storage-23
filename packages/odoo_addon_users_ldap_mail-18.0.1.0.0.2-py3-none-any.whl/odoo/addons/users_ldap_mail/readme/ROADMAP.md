- Add tests (use LDAP Mocking through something like
  <https://mockldap.readthedocs.io/en/latest/overview.html>)
