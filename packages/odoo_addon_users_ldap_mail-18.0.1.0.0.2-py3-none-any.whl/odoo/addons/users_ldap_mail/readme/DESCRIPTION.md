This module extends the functionality of the auth_ldap module to support
mail from LDAP and to allow you to get an e-mail address from LDAP
accounts to Odoo users.
