# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""Validate that model specs do not contain tags (system metadata)."""

import argparse
import re
import yaml
import sys
from pathlib import Path
from typing import List

import azureml.assets as assets
import azureml.assets.util as util
from azureml.assets.util import logger


def validate_model_system_metadata(input_dirs: List[Path],
                                   asset_config_filename: str,
                                   changed_files: List[Path] = None,
                                   skip_pattern: re.Pattern = None) -> bool:
    """Validate that model specs do not contain tags.

    Tags in model specs are being deprecated in favor of system metadata.
    This function checks all model assets and raises errors if tags are found.

    Args:
        input_dirs (List[Path]): Directories containing assets.
        asset_config_filename (str): Asset config filename to search for.
        changed_files (List[Path], optional): List of changed files, used to filter assets. Defaults to None.
        skip_pattern (re.Pattern, optional): Regex pattern to skip validation for matching model names.

    Returns:
        bool: True if validation passed (no tags found), False otherwise.
    """
    error_count = 0
    model_count = 0

    changed_assets = util.find_asset_config_files(input_dirs, asset_config_filename, changed_files) if changed_files else None  # noqa: E501

    for input_dir in input_dirs:
        for asset_config in util.find_assets(input_dir, asset_config_filename):
            if asset_config.type != assets.AssetType.MODEL:
                continue

            # Only validate changed assets if changed_files was provided
            if changed_assets is not None and asset_config.file_name_with_path not in changed_assets:
                continue

            model_count += 1

            if skip_pattern and skip_pattern.fullmatch(asset_config.full_name):
                logger.log_debug(f"Skipping system metadata validation for {asset_config.full_name}")
                continue

            with open(asset_config.spec_with_path, "r", encoding="utf-8") as f:
                spec = yaml.safe_load(f)

            if spec and spec.get('tags'):
                logger.log_error(
                    f"Model '{asset_config.name}' contains tags in spec "
                    f"({asset_config.spec_with_path}). "
                    f"Tags are not allowed in model specs. Please use system metadata instead. "
                    f"See http://aka.ms/azureml/model-system-metadata for more details.")
                error_count += 1

    logger.print(f"Validated system metadata for {model_count} model(s), {error_count} error(s)")
    return error_count == 0


if __name__ == "__main__":
    # Handle command-line args
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input-dirs", required=True,
                        help="Comma-separated list of directories containing assets")
    parser.add_argument("-a", "--asset-config-filename", default=assets.DEFAULT_ASSET_FILENAME,
                        help="Asset config file name to search for")
    parser.add_argument("-c", "--changed-files",
                        help="Comma-separated list of changed files, used to filter assets")
    parser.add_argument("-S", "--skip-pattern", type=re.compile,
                        help="Regex pattern to skip validation for matching models, in the format <type>/<name>/<version>")
    args = parser.parse_args()

    # Convert comma-separated values to lists
    input_dirs = [Path(d) for d in args.input_dirs.split(",")]
    changed_files = [Path(f) for f in args.changed_files.split(",")] if args.changed_files else []

    # Validate model system metadata
    success = validate_model_system_metadata(input_dirs=input_dirs,
                                             asset_config_filename=args.asset_config_filename,
                                             changed_files=changed_files,
                                             skip_pattern=args.skip_pattern)

    if not success:
        sys.exit(1)
