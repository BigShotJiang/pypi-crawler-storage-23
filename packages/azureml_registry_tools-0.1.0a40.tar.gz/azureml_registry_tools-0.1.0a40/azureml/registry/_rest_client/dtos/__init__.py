# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""DTO definitions for IP Publisher related endpoints."""

from .ippublisher_dtos import AuthorCreateDTO  # noqa: F401

__all__ = [
    "AuthorCreateDTO",
]
