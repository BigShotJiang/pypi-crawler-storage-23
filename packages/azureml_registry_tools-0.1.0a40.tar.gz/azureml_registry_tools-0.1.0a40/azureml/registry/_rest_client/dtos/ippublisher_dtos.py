# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""DTO definitions for IP Publisher author endpoints."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Any


@dataclass
class AuthorCreateDTO:
    """POST body for author creation at publisherDetails/{pub}/authorDetails/{name}."""

    name: str
    display_name: str
    is_public: bool = True
    icon_light_base64: Optional[str] = None
    icon_dark_base64: Optional[str] = None

    def to_wire(self) -> dict[str, Any]:
        """Serialize to camelCase payload for authorDetails endpoint."""
        body: dict[str, Any] = {
            "authorName": self.name,
            "displayName": self.display_name,
            "isPublic": self.is_public,
        }
        if self.icon_light_base64 is not None:
            body["iconLight"] = self.icon_light_base64
        if self.icon_dark_base64 is not None:
            body["iconDark"] = self.icon_dark_base64
        return body
