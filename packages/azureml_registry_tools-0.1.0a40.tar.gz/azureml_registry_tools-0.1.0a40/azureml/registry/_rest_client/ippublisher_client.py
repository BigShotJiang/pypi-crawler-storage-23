# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Client for IntellectualPropertyPublisher author endpoints."""
from __future__ import annotations

import urllib.parse
from typing import Any

from .base_rest_client import BaseAzureRestClient
from .dtos import AuthorCreateDTO


class IPPublisherClient(BaseAzureRestClient):
    """REST client for IP Publisher author operations.

    Extends BaseAzureRestClient with token scope override for ml.azure.com.
    """

    _PUBLISHER_DETAILS_ENDPOINT = "/publisherDetails"
    _AUTHOR_DETAILS_ENDPOINT = "/authorDetails"

    def __init__(
        self,
        *,
        region: str = "eastus2euap",
        token_scope: str = "https://ml.azure.com/.default",
        max_retries: int = 5,
        backoff_factor: int = 1,
    ) -> None:
        """Initialize the IPPublisherClient.

        Args:
            region: Azure region for the API endpoint.
            token_scope: OAuth token scope. Defaults to ml.azure.com.
            max_retries: Maximum retries for failed requests.
            backoff_factor: Exponential backoff factor.
        """
        base_url = f"https://{region}.api.azureml.ms"
        super().__init__(base_url=base_url, max_retries=max_retries, backoff_factor=backoff_factor)
        self._token_scope = token_scope
        # Re-acquire token with the correct scope
        self._refresh_token_with_scope()

    def _refresh_token_with_scope(self) -> None:
        """Refresh the API token using the ml.azure.com scope."""
        if self._credential is None:
            return
        token = self._credential.get_token(self._token_scope)
        self.api_key = token.token
        self.session.headers.update({"Authorization": f"Bearer {self.api_key}"})
        self._token_expires_on = token.expires_on

    def _ensure_token(self) -> None:
        """Ensure the token is valid, refreshing if needed."""
        import time
        now = int(time.time())
        if not getattr(self, "_token_expires_on", None) or self._token_expires_on - now < 600:
            self._refresh_token_with_scope()

    def _intellectual_base(self) -> str:
        """Return the IntellectualPropertyPublisher service base URL."""
        return f"{self.base_url}/intellectualPropertyPublisher/v1.0"

    def create_author(self, publisher_name: str, author_name: str, req: AuthorCreateDTO) -> dict[str, Any]:
        """Create an author under a publisher.

        Args:
            publisher_name: Parent publisher name.
            author_name: Author name (must not contain ':').
            req: Author creation DTO.

        Returns:
            dict: API response.
        """
        self._ensure_token()
        url = (
            f"{self._intellectual_base()}{self._PUBLISHER_DETAILS_ENDPOINT}"
            f"/{urllib.parse.quote(publisher_name)}/authorDetails/{urllib.parse.quote(author_name)}"
        )
        resp = self.post(url, json=req.to_wire())
        return resp.json() if resp.content else req.to_wire()

    def list_authors(self, publisher_name: str = None) -> dict[str, Any]:
        """List all authors, optionally filtered by publisher name.

        Args:
            publisher_name: Optional publisher name to filter results.

        Returns:
            dict: API response containing authors list.
        """
        self._ensure_token()
        url = f"{self._intellectual_base()}{self._AUTHOR_DETAILS_ENDPOINT}"
        resp = self.get(url)
        data = resp.json()
        if publisher_name and "value" in data:
            data["value"] = [
                a for a in data["value"]
                if a.get("authorName", "").startswith(f"{publisher_name}:")
            ]
        return data
