# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""CLI entry point for author management.

Usage:
    author-mgmt create --publisher foo --name bar --display-name "Bar" --icon-light light.svg --icon-dark dark.svg
    author-mgmt list --publisher foo
"""
import argparse
import base64
from urllib.parse import quote

from azureml.registry.mgmt.author import Author


def encode_icon(icon_path: str) -> str:
    """Read and base64 encode an icon file.

    Args:
        icon_path: Path to the icon file.

    Returns:
        str: Base64 encoded content of the icon.
    """
    with open(icon_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def create_author(args) -> None:
    """Create a new author under a publisher."""
    print("\n=== CREATING AUTHOR ===")
    print(f"Publisher: {args.publisher}")
    print(f"Author: {args.name}")
    print(f"Display Name: {args.display_name}")
    print()

    author = Author(publisher_name=args.publisher, name=args.name, region=args.region)
    result = author.create(
        display_name=args.display_name,
        is_public=args.public,
        icon_light_base64=encode_icon(args.icon_light),
        icon_dark_base64=encode_icon(args.icon_dark),
    )
    print("Author created successfully!")
    if result:
        print(f"Response: {result}")

    check_url = (
        f"https://{args.region}.api.azureml.ms/intellectualpropertypublisher"
        f"/v1.0/authordetails/{quote(args.publisher)}:{quote(args.name)}"
    )
    print(f"\nCheck author details at:\n  {check_url}")


def list_authors(args) -> None:
    """List all authors for a publisher."""
    try:
        data = Author.list_all(publisher_name=args.publisher, region=args.region)
    except Exception as e:
        if "not found" in str(e).lower():
            print(f"\n=== AUTHORS for {args.publisher} ===")
            print("  (none - no authors found for this publisher)")
            return
        raise

    print(f"\n=== AUTHORS for {args.publisher} ===")
    authors = data.get("value", [])
    if not authors:
        print("  (none)")
    else:
        for author in authors:
            print(f"  - {author.get('authorName')} ({author.get('displayName')})")


def main() -> None:
    """CLI entry point for author management.

    Examples:
      # Create an author under a publisher
      author-mgmt create --publisher mypub --name myauthor --display-name "My Author" --icon-light light.svg --icon-dark dark.svg

      # Create a private author
      author-mgmt create --publisher mypub --name myauthor --display-name "My Author" --icon-light light.svg --icon-dark dark.svg --private

      # List authors for a publisher
      author-mgmt list --publisher mypub

      # Specify a different region
      author-mgmt list --publisher mypub --region eastus
    """
    parser = argparse.ArgumentParser(prog="author-mgmt", description="AzureML Author Management CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # create subcommand
    create_parser = subparsers.add_parser("create", help="Create a new author under a publisher.")
    create_parser.add_argument("--publisher", required=True, help="Publisher name the author belongs to.")
    create_parser.add_argument("--name", required=True, help="Author name (unique identifier).")
    create_parser.add_argument("--display-name", required=True, help="Display name for the author.")
    create_parser.add_argument("--icon-light", required=True, help="Path to light theme icon file.")
    create_parser.add_argument("--icon-dark", required=True, help="Path to dark theme icon file.")
    create_parser.add_argument("--private", action="store_true", help="Make author private (default: public).")
    create_parser.add_argument("--region", type=str, default="eastus2euap",
                               help="Azure region for the API endpoint (default: eastus2euap).")
    create_parser.set_defaults(func=create_author, public=True)

    # list subcommand
    list_parser = subparsers.add_parser("list", help="List all authors for a publisher.")
    list_parser.add_argument("--publisher", required=True, help="Publisher name to list authors for.")
    list_parser.add_argument("--region", type=str, default="eastus2euap",
                             help="Azure region for the API endpoint (default: eastus2euap).")
    list_parser.set_defaults(func=list_authors)

    args = parser.parse_args()

    # Handle --private flag
    if hasattr(args, "private") and args.private:
        args.public = False

    args.func(args)


if __name__ == "__main__":
    main()
