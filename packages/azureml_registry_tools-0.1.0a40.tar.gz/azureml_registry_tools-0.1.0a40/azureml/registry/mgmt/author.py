# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Author class for managing authors under IP Publishers."""
from __future__ import annotations

import logging
from typing import Optional, Any

from .._rest_client.ippublisher_client import IPPublisherClient
from .._rest_client.dtos import AuthorCreateDTO

logger = logging.getLogger(__name__)


class Author:
    """High-level Author class for create/list operations under a publisher."""

    def __init__(
        self,
        publisher_name: str,
        name: str,
        region: str = "eastus2euap",
    ) -> None:
        """Initialize Author.

        Args:
            publisher_name: Parent publisher name.
            name: Author name.
            region: Azure region. Defaults to "eastus2euap".
        """
        self.publisher_name = publisher_name
        self.name = name
        self.region = region
        self.client = IPPublisherClient(region=region)

    def _validate_author_name(self) -> None:
        """Validate that the author name does not contain ':'."""
        if ":" in self.name:
            raise ValueError(
                f"Author name must not contain ':' or include the publisher name prefix. "
                f"Got '{self.name}'"
            )

    def create(
        self,
        display_name: str,
        is_public: bool = True,
        icon_light_base64: Optional[str] = None,
        icon_dark_base64: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new author under the publisher.

        Args:
            display_name: Display name for the author.
            is_public: Whether the author is public. Defaults to True.
            icon_light_base64: Base64-encoded light icon.
            icon_dark_base64: Base64-encoded dark icon.

        Returns:
            dict[str, Any]: Response from the API call.
        """
        self._validate_author_name()
        logger.info(f"Creating author {self.name} under publisher {self.publisher_name}")
        dto = AuthorCreateDTO(
            name=self.name,
            display_name=display_name,
            is_public=is_public,
            icon_light_base64=icon_light_base64,
            icon_dark_base64=icon_dark_base64,
        )
        result = self.client.create_author(self.publisher_name, self.name, dto)
        logger.info(f"Successfully created author {self.name}")
        return result

    @staticmethod
    def list_all(
        publisher_name: str,
        region: str = "eastus2euap",
    ) -> dict[str, Any]:
        """List all authors for a publisher.

        Args:
            publisher_name: Publisher name to list authors for.
            region: Azure region.

        Returns:
            dict[str, Any]: Response containing authors list.
        """
        logger.info(f"Listing authors for publisher {publisher_name}")
        client = IPPublisherClient(region=region)
        return client.list_authors(publisher_name)
