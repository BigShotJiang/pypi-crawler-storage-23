"""
Utility functions for GeoCommunes GeoPortal
"""

import hashlib
import random
import string
from datetime import datetime


def generate_password(length: int = 12) -> str:
    """Generate a secure random password."""
    characters = string.ascii_letters + string.digits + string.punctuation
    return ''.join(random.choice(characters) for _ in range(length))


def hash_string(data: str) -> str:
    """Generate SHA256 hash of a string."""
    return hashlib.sha256(data.encode()).hexdigest()


def get_current_timestamp() -> str:
    """Return current UTC timestamp in ISO format."""
    return datetime.utcnow().isoformat()
