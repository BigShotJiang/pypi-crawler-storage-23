# geocommunes_geoportal

A utility package for GeoCommunes GeoPortal.

## Features

- Generate secure passwords
- Hash strings using SHA256
- Get current UTC timestamp

## Installation

```bash
pip install geomapfishapp_geoportal
```

## Usage

```python
from geomapfishapp_geoportal import generate_password, hash_string

print(generate_password())
print(hash_string("hello"))
```
