from buganize.cli.main import start

start()
