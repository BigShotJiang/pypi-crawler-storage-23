from omlish.__about__ import ProjectBase
from omlish.__about__ import SetuptoolsBase
from omlish.__about__ import __version__


class Project(ProjectBase):
    name = 'omxtra'
    description = 'omxtra'

    dependencies = [
        # FIXME: text.antlr.cli deps omdev.cache.data, yet this lib is 'under' omdev.
        # f'omdev == {__version__}',

        f'omlish == {__version__}',
    ]

    optional_dependencies: dict = {
        'server': [
            'h11 ~= 0.16',
            'h2 ~= 4.3',
            'priority ~= 2.0',
            'wsproto ~= 1.3',
        ],

        'templates': [
            'jinja2 ~= 3.1',
        ],
    }

    entry_points = {
        'omlish.manifests': {name: name},
    }


class Setuptools(SetuptoolsBase):
    cext = True

    find_packages = {
        'include': [Project.name, f'{Project.name}.*'],
        'exclude': [*SetuptoolsBase.find_packages['exclude']],
    }
