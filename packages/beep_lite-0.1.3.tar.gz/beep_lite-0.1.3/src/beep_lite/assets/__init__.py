# This file makes assets a package for importlib.resources compatibility
