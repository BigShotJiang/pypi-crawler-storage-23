"""poroflow -- Physics-informed machine learning for flow in porous media."""

__version__ = "0.1.0"
