# poroflow

> **This package is under active development and not yet ready for production use.**

Physics-informed machine learning for simulation of flow in porous media.

## Overview

`poroflow` provides methods for simulating multiphase flow in porous media using physics-informed machine learning approaches, including:

- **Finite Volume Graph Networks (FVGN)** -- GNN-based solvers with built-in conservation guarantees
- **Differentiable numerical fluxes** -- Godunov flux for correct shock handling
- **Progressive rollout training** -- autoregressive stability for long-horizon predictions

The initial focus is on the Buckley-Leverett equation for two-phase immiscible displacement, with plans to extend to 2D problems, capillary pressure effects, and parametric surrogates.

## Installation

```bash
pip install poroflow
```

## Status

This is an early release to reserve the package name. Functional code will be published in upcoming versions.

## License

MIT
