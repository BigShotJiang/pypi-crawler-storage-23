import poroflow


def test_version():
    assert poroflow.__version__ == "0.1.0"
