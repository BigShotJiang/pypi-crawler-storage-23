```
# Pydantic AI

> GenAI Agent Framework, the Pydantic way

Pydantic AI is a Python agent framework designed to make it less painful to build production grade
applications with Generative AI.

## Introduction

- [Pydantic AI](https://ai.pydantic.dev/index.md)
- [Installation](https://ai.pydantic.dev/install/index.md)
- [Getting Help](https://ai.pydantic.dev/help/index.md)
- [Troubleshooting](https://ai.pydantic.dev/troubleshooting/index.md)

## Concepts documentation

- [Agent2Agent (A2A)](https://ai.pydantic.dev/a2a/index.md)
- [Agents](https://ai.pydantic.dev/agent/index.md)
- [Built-in Tools](https://ai.pydantic.dev/builtin-tools/index.md)
- [Dependencies](https://ai.pydantic.dev/dependencies/index.md)
- [Deferred Tools](https://ai.pydantic.dev/deferred-tools/index.md)
- [Direct Model Requests](https://ai.pydantic.dev/direct/index.md)
- [Embeddings](https://ai.pydantic.dev/embeddings/index.md)
- [Pydantic AI Gateway](https://ai.pydantic.dev/gateway/index.md)
- [Image, Audio, Video &amp; Document Input](https://ai.pydantic.dev/input/index.md)
- [Function Tools](https://ai.pydantic.dev/tools/index.md)
- [Common Tools](https://ai.pydantic.dev/common-tools/index.md)
- [Output](https://ai.pydantic.dev/output/index.md)
- [HTTP Request Retries](https://ai.pydantic.dev/retries/index.md)
- [Messages and chat history](https://ai.pydantic.dev/message-history/index.md)
- [Multi-Agent Patterns](https://ai.pydantic.dev/multi-agent-applications/index.md)
- [Thinking](https://ai.pydantic.dev/thinking/index.md)
- [Third-Party Tools](https://ai.pydantic.dev/third-party-tools/index.md)
- [Advanced Tool Features](https://ai.pydantic.dev/tools-advanced/index.md)
- [Toolsets](https://ai.pydantic.dev/toolsets/index.md)
- [Web Chat UI](https://ai.pydantic.dev/web/index.md)

## Models

- [Anthropic](https://ai.pydantic.dev/models/anthropic/index.md)
- [Bedrock](https://ai.pydantic.dev/models/bedrock/index.md)
- [Cerebras](https://ai.pydantic.dev/models/cerebras/index.md)
- [Cohere](https://ai.pydantic.dev/models/cohere/index.md)
- [Google](https://ai.pydantic.dev/models/google/index.md)
- [Groq](https://ai.pydantic.dev/models/groq/index.md)
- [Hugging Face](https://ai.pydantic.dev/models/huggingface/index.md)
- [Mistral](https://ai.pydantic.dev/models/mistral/index.md)
- [OpenAI](https://ai.pydantic.dev/models/openai/index.md)
- [OpenRouter](https://ai.pydantic.dev/models/openrouter/index.md)
- [Outlines](https://ai.pydantic.dev/models/outlines/index.md)
- [Overview](https://ai.pydantic.dev/models/overview/index.md)
- [xAI](https://ai.pydantic.dev/models/xai/index.md)

## Graphs

- [Overview](https://ai.pydantic.dev/graph/index.md)
- [Getting Started](https://ai.pydantic.dev/graph/beta/index.md)
- [Decisions](https://ai.pydantic.dev/graph/beta/decisions/index.md)
- [Joins & Reducers](https://ai.pydantic.dev/graph/beta/joins/index.md)
- [Parallel Execution](https://ai.pydantic.dev/graph/beta/parallel/index.md)
- [Steps](https://ai.pydantic.dev/graph/beta/steps/index.md)

## API Reference

- [pydantic_ai.ag_ui](https://ai.pydantic.dev/api/ag_ui/index.md)
- [pydantic_ai.agent](https://ai.pydantic.dev/api/agent/index.md)
- [pydantic_ai.builtin_tools](https://ai.pydantic.dev/api/builtin_tools/index.md)
- [pydantic_ai.common_tools](https://ai.pydantic.dev/api/common_tools/index.md)
- [pydantic_ai â€” Concurrency](https://ai.pydantic.dev/api/concurrency/index.md)
- [pydantic_ai.direct](https://ai.pydantic.dev/api/direct/index.md)
- [pydantic_ai.durable_exec](https://ai.pydantic.dev/api/durable_exec/index.md)
- [pydantic_ai.embeddings](https://ai.pydantic.dev/api/embeddings/index.md)
- [pydantic_ai.exceptions](https://ai.pydantic.dev/api/exceptions/index.md)
- [pydantic_ai.ext](https://ai.pydantic.dev/api/ext/index.md)
- [fasta2a](https://ai.pydantic.dev/api/fasta2a/index.md)
- [pydantic_ai.format_prompt](https://ai.pydantic.dev/api/format_prompt/index.md)
- [pydantic_ai.mcp](https://ai.pydantic.dev/api/mcp/index.md)
- [pydantic_ai.messages](https://ai.pydantic.dev/api/messages/index.md)
- [pydantic_ai.output](https://ai.pydantic.dev/api/output/index.md)
- [pydantic_ai.profiles](https://ai.pydantic.dev/api/profiles/index.md)
- [pydantic_ai.providers](https://ai.pydantic.dev/api/providers/index.md)
- [pydantic_ai.result](https://ai.pydantic.dev/api/result/index.md)
- [pydantic_ai.retries](https://ai.pydantic.dev/api/retries/index.md)
- [pydantic_ai.run](https://ai.pydantic.dev/api/run/index.md)
- [pydantic_ai.settings](https://ai.pydantic.dev/api/settings/index.md)
- [pydantic_ai.tools](https://ai.pydantic.dev/api/tools/index.md)
- [pydantic_ai.toolsets](https://ai.pydantic.dev/api/toolsets/index.md)
- [pydantic_ai.usage](https://ai.pydantic.dev/api/usage/index.md)
- [pydantic_ai.models.anthropic](https://ai.pydantic.dev/api/models/anthropic/index.md)
- [pydantic_ai.models](https://ai.pydantic.dev/api/models/base/index.md)
- [pydantic_ai.models.bedrock](https://ai.pydantic.dev/api/models/bedrock/index.md)
- [pydantic_ai.models.cerebras](https://ai.pydantic.dev/api/models/cerebras/index.md)
- [pydantic_ai.models.cohere](https://ai.pydantic.dev/api/models/cohere/index.md)
- [pydantic_ai.models.fallback](https://ai.pydantic.dev/api/models/fallback/index.md)
- [pydantic_ai.models.function](https://ai.pydantic.dev/api/models/function/index.md)
- [pydantic_ai.models.google](https://ai.pydantic.dev/api/models/google/index.md)
- [pydantic_ai.models.groq](https://ai.pydantic.dev/api/models/groq/index.md)
- [pydantic_ai.models.huggingface](https://ai.pydantic.dev/api/models/huggingface/index.md)
- [pydantic_ai.models.instrumented](https://ai.pydantic.dev/api/models/instrumented/index.md)
- [pydantic_ai.models.mcp_sampling](https://ai.pydantic.dev/api/models/mcp-sampling/index.md)
- [pydantic_ai.models.mistral](https://ai.pydantic.dev/api/models/mistral/index.md)
- [pydantic_ai.models.openai](https://ai.pydantic.dev/api/models/openai/index.md)
- [pydantic_ai.models.openrouter](https://ai.pydantic.dev/api/models/openrouter/index.md)
- [pydantic_ai.models.outlines](https://ai.pydantic.dev/api/models/outlines/index.md)
- [pydantic_ai.models.test](https://ai.pydantic.dev/api/models/test/index.md)
- [pydantic_ai.models.wrapper](https://ai.pydantic.dev/api/models/wrapper/index.md)
- [pydantic_ai.models.xai](https://ai.pydantic.dev/api/models/xai/index.md)
- [pydantic_evals.dataset](https://ai.pydantic.dev/api/pydantic_evals/dataset/index.md)
- [pydantic_evals.evaluators](https://ai.pydantic.dev/api/pydantic_evals/evaluators/index.md)
- [pydantic_evals.generation](https://ai.pydantic.dev/api/pydantic_evals/generation/index.md)
- [pydantic_evals.otel](https://ai.pydantic.dev/api/pydantic_evals/otel/index.md)
- [pydantic_evals.reporting](https://ai.pydantic.dev/api/pydantic_evals/reporting/index.md)
- [pydantic_graph.beta](https://ai.pydantic.dev/api/pydantic_graph/beta/index.md)
- [pydantic_graph.beta.decision](https://ai.pydantic.dev/api/pydantic_graph/beta_decision/index.md)
- [pydantic_graph.beta.graph](https://ai.pydantic.dev/api/pydantic_graph/beta_graph/index.md)
- [pydantic_graph.beta.graph_builder](https://ai.pydantic.dev/api/pydantic_graph/beta_graph_builder/index.md)
- [pydantic_graph.beta.join](https://ai.pydantic.dev/api/pydantic_graph/beta_join/index.md)
- [pydantic_graph.beta.node](https://ai.pydantic.dev/api/pydantic_graph/beta_node/index.md)
- [pydantic_graph.beta.step](https://ai.pydantic.dev/api/pydantic_graph/beta_step/index.md)
- [pydantic_graph.exceptions](https://ai.pydantic.dev/api/pydantic_graph/exceptions/index.md)
- [pydantic_graph](https://ai.pydantic.dev/api/pydantic_graph/graph/index.md)
- [pydantic_graph.mermaid](https://ai.pydantic.dev/api/pydantic_graph/mermaid/index.md)
- [pydantic_graph.nodes](https://ai.pydantic.dev/api/pydantic_graph/nodes/index.md)
- [pydantic_graph.persistence](https://ai.pydantic.dev/api/pydantic_graph/persistence/index.md)
- [pydantic_ai.ui.ag_ui](https://ai.pydantic.dev/api/ui/ag_ui/index.md)
- [pydantic_ai.ui](https://ai.pydantic.dev/api/ui/base/index.md)
- [pydantic_ai.ui.vercel_ai](https://ai.pydantic.dev/api/ui/vercel_ai/index.md)

## Evals

- [Overview](https://ai.pydantic.dev/evals/index.md)
- [Core Concepts](https://ai.pydantic.dev/evals/core-concepts/index.md)
- [Quick Start](https://ai.pydantic.dev/evals/quick-start/index.md)
- [Built-in Evaluators](https://ai.pydantic.dev/evals/evaluators/built-in/index.md)
- [Custom Evaluators](https://ai.pydantic.dev/evals/evaluators/custom/index.md)
- [LLM Judge](https://ai.pydantic.dev/evals/evaluators/llm-judge/index.md)
- [Overview](https://ai.pydantic.dev/evals/evaluators/overview/index.md)
- [Report Evaluators](https://ai.pydantic.dev/evals/evaluators/report-evaluators/index.md)
- [Span-Based](https://ai.pydantic.dev/evals/evaluators/span-based/index.md)
- [Simple Validation](https://ai.pydantic.dev/evals/examples/simple-validation/index.md)
- [Concurrency & Performance](https://ai.pydantic.dev/evals/how-to/concurrency/index.md)
- [Dataset Management](https://ai.pydantic.dev/evals/how-to/dataset-management/index.md)
- [Dataset Serialization](https://ai.pydantic.dev/evals/how-to/dataset-serialization/index.md)
- [Logfire Integration](https://ai.pydantic.dev/evals/how-to/logfire-integration/index.md)
- [Metrics & Attributes](https://ai.pydantic.dev/evals/how-to/metrics-attributes/index.md)
- [Multi-Run Evaluation](https://ai.pydantic.dev/evals/how-to/multi-run/index.md)
- [Retry Strategies](https://ai.pydantic.dev/evals/how-to/retry-strategies/index.md)

## Durable Execution

- [DBOS](https://ai.pydantic.dev/durable_execution/dbos/index.md)
- [Overview](https://ai.pydantic.dev/durable_execution/overview/index.md)
- [Prefect](https://ai.pydantic.dev/durable_execution/prefect/index.md)
- [Temporal](https://ai.pydantic.dev/durable_execution/temporal/index.md)

## MCP

- [Client](https://ai.pydantic.dev/mcp/client/index.md)
- [FastMCP Client](https://ai.pydantic.dev/mcp/fastmcp-client/index.md)
- [Overview](https://ai.pydantic.dev/mcp/overview/index.md)
- [Server](https://ai.pydantic.dev/mcp/server/index.md)

## UI Event Streams

- [AG-UI](https://ai.pydantic.dev/ui/ag-ui/index.md)
- [Overview](https://ai.pydantic.dev/ui/overview/index.md)
- [Vercel AI](https://ai.pydantic.dev/ui/vercel-ai/index.md)

## Optional

- [Testing](https://ai.pydantic.dev/testing/index.md)
- [clai](https://ai.pydantic.dev/cli/index.md)
- [Debugging & Monitoring with Pydantic Logfire](https://ai.pydantic.dev/logfire/index.md)
- [Contributing](https://ai.pydantic.dev/contributing/index.md)
- [Upgrade Guide](https://ai.pydantic.dev/changelog/index.md)
- [Version policy](https://ai.pydantic.dev/version-policy/index.md)

## Examples

- [Agent User Interaction (AG-UI)](https://ai.pydantic.dev/examples/ag-ui/index.md)
- [Bank support](https://ai.pydantic.dev/examples/bank-support/index.md)
- [Chat App with FastAPI](https://ai.pydantic.dev/examples/chat-app/index.md)
- [Data Analyst](https://ai.pydantic.dev/examples/data-analyst/index.md)
- [Flight booking](https://ai.pydantic.dev/examples/flight-booking/index.md)
- [Pydantic Model](https://ai.pydantic.dev/examples/pydantic-model/index.md)
- [Question Graph](https://ai.pydantic.dev/examples/question-graph/index.md)
- [RAG](https://ai.pydantic.dev/examples/rag/index.md)
- [Setup](https://ai.pydantic.dev/examples/setup/index.md)
- [Slack Lead Qualifier with Modal](https://ai.pydantic.dev/examples/slack-lead-qualifier/index.md)
- [SQL Generation](https://ai.pydantic.dev/examples/sql-gen/index.md)
- [Stream markdown](https://ai.pydantic.dev/examples/stream-markdown/index.md)
- [Stream whales](https://ai.pydantic.dev/examples/stream-whales/index.md)
- [Weather agent](https://ai.pydantic.dev/examples/weather-agent/index.md)


```
