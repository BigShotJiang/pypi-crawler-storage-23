[ Skip to content ](https://ai.pydantic.dev/changelog/#upgrade-guide)
**Join us at the inaugural PyAI Conf in San Francisco on March 10th![Learn More](https://pyai.events/?utm_source=pydantic-ai) **
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI")
Pydantic AI
Upgrade Guide
Type to start searching
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI") Pydantic AI
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
  * [ Pydantic AI  ](https://ai.pydantic.dev/)
  * [ Installation  ](https://ai.pydantic.dev/install/)
  * [ Getting Help  ](https://ai.pydantic.dev/help/)
  * [ Troubleshooting  ](https://ai.pydantic.dev/troubleshooting/)
  * [ Pydantic AI Gateway  ](https://ai.pydantic.dev/gateway/)
  * Documentation
    * Core Concepts
      * [ Agents  ](https://ai.pydantic.dev/agent/)
      * [ Dependencies  ](https://ai.pydantic.dev/dependencies/)
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Output  ](https://ai.pydantic.dev/output/)
      * [ Messages and chat history  ](https://ai.pydantic.dev/message-history/)
      * [ Direct Model Requests  ](https://ai.pydantic.dev/direct/)
    * Models & Providers
      * [ Overview  ](https://ai.pydantic.dev/models/overview/)
      * [ OpenAI  ](https://ai.pydantic.dev/models/openai/)
      * [ Anthropic  ](https://ai.pydantic.dev/models/anthropic/)
      * [ Google  ](https://ai.pydantic.dev/models/google/)
      * [ xAI  ](https://ai.pydantic.dev/models/xai/)
      * [ Bedrock  ](https://ai.pydantic.dev/models/bedrock/)
      * [ Cerebras  ](https://ai.pydantic.dev/models/cerebras/)
      * [ Cohere  ](https://ai.pydantic.dev/models/cohere/)
      * [ Groq  ](https://ai.pydantic.dev/models/groq/)
      * [ Hugging Face  ](https://ai.pydantic.dev/models/huggingface/)
      * [ Mistral  ](https://ai.pydantic.dev/models/mistral/)
      * [ OpenRouter  ](https://ai.pydantic.dev/models/openrouter/)
      * [ Outlines  ](https://ai.pydantic.dev/models/outlines/)
    * Tools & Toolsets
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Advanced Tool Features  ](https://ai.pydantic.dev/tools-advanced/)
      * [ Toolsets  ](https://ai.pydantic.dev/toolsets/)
      * [ Deferred Tools  ](https://ai.pydantic.dev/deferred-tools/)
      * [ Built-in Tools  ](https://ai.pydantic.dev/builtin-tools/)
      * [ Common Tools  ](https://ai.pydantic.dev/common-tools/)
      * [ Third-Party Tools  ](https://ai.pydantic.dev/third-party-tools/)
    * Advanced Features
      * [ Image, Audio, Video & Document Input  ](https://ai.pydantic.dev/input/)
      * [ Thinking  ](https://ai.pydantic.dev/thinking/)
      * [ HTTP Request Retries  ](https://ai.pydantic.dev/retries/)
    * MCP
      * [ Overview  ](https://ai.pydantic.dev/mcp/overview/)
      * [ Client  ](https://ai.pydantic.dev/mcp/client/)
      * [ FastMCP Client  ](https://ai.pydantic.dev/mcp/fastmcp-client/)
      * [ Server  ](https://ai.pydantic.dev/mcp/server/)
    * [ Multi-Agent Patterns  ](https://ai.pydantic.dev/multi-agent-applications/)
    * [ Web Chat UI  ](https://ai.pydantic.dev/web/)
    * [ Embeddings  ](https://ai.pydantic.dev/embeddings/)
    * [ Testing  ](https://ai.pydantic.dev/testing/)
  * Pydantic Evals
    * [ Overview  ](https://ai.pydantic.dev/evals/)
    * Getting Started
      * [ Quick Start  ](https://ai.pydantic.dev/evals/quick-start/)
      * [ Core Concepts  ](https://ai.pydantic.dev/evals/core-concepts/)
    * Evaluators
      * [ Overview  ](https://ai.pydantic.dev/evals/evaluators/overview/)
      * [ Built-in Evaluators  ](https://ai.pydantic.dev/evals/evaluators/built-in/)
      * [ LLM Judge  ](https://ai.pydantic.dev/evals/evaluators/llm-judge/)
      * [ Custom Evaluators  ](https://ai.pydantic.dev/evals/evaluators/custom/)
      * [ Report Evaluators  ](https://ai.pydantic.dev/evals/evaluators/report-evaluators/)
      * [ Span-Based  ](https://ai.pydantic.dev/evals/evaluators/span-based/)
    * How-To Guides
      * [ Logfire Integration  ](https://ai.pydantic.dev/evals/how-to/logfire-integration/)
      * [ Dataset Management  ](https://ai.pydantic.dev/evals/how-to/dataset-management/)
      * [ Dataset Serialization  ](https://ai.pydantic.dev/evals/how-to/dataset-serialization/)
      * [ Concurrency & Performance  ](https://ai.pydantic.dev/evals/how-to/concurrency/)
      * [ Multi-Run Evaluation  ](https://ai.pydantic.dev/evals/how-to/multi-run/)
      * [ Retry Strategies  ](https://ai.pydantic.dev/evals/how-to/retry-strategies/)
      * [ Metrics & Attributes  ](https://ai.pydantic.dev/evals/how-to/metrics-attributes/)
    * Examples
      * [ Simple Validation  ](https://ai.pydantic.dev/evals/examples/simple-validation/)
  * Pydantic Graph
    * [ Overview  ](https://ai.pydantic.dev/graph/)
    * [ Beta API  ](https://ai.pydantic.dev/graph/beta/)
      * [ Steps  ](https://ai.pydantic.dev/graph/beta/steps/)
      * [ Joins & Reducers  ](https://ai.pydantic.dev/graph/beta/joins/)
      * [ Decisions  ](https://ai.pydantic.dev/graph/beta/decisions/)
      * [ Parallel Execution  ](https://ai.pydantic.dev/graph/beta/parallel/)
  * Integrations
    * [ Debugging & Monitoring with Pydantic Logfire  ](https://ai.pydantic.dev/logfire/)
    * Durable Execution
      * [ Overview  ](https://ai.pydantic.dev/durable_execution/overview/)
      * [ Temporal  ](https://ai.pydantic.dev/durable_execution/temporal/)
      * [ DBOS  ](https://ai.pydantic.dev/durable_execution/dbos/)
      * [ Prefect  ](https://ai.pydantic.dev/durable_execution/prefect/)
    * UI Event Streams
      * [ Overview  ](https://ai.pydantic.dev/ui/overview/)
      * [ AG-UI  ](https://ai.pydantic.dev/ui/ag-ui/)
      * [ Vercel AI  ](https://ai.pydantic.dev/ui/vercel-ai/)
    * [ Agent2Agent (A2A)  ](https://ai.pydantic.dev/a2a/)
  * Related Packages
    * [ clai  ](https://ai.pydantic.dev/cli/)
  * Examples
    * [ Setup  ](https://ai.pydantic.dev/examples/setup/)
    * Getting Started
      * [ Pydantic Model  ](https://ai.pydantic.dev/examples/pydantic-model/)
      * [ Weather agent  ](https://ai.pydantic.dev/examples/weather-agent/)
    * Conversational Agents
      * [ Chat App with FastAPI  ](https://ai.pydantic.dev/examples/chat-app/)
      * [ Bank support  ](https://ai.pydantic.dev/examples/bank-support/)
    * Data & Analytics
      * [ SQL Generation  ](https://ai.pydantic.dev/examples/sql-gen/)
      * [ Data Analyst  ](https://ai.pydantic.dev/examples/data-analyst/)
      * [ RAG  ](https://ai.pydantic.dev/examples/rag/)
    * Streaming
      * [ Stream markdown  ](https://ai.pydantic.dev/examples/stream-markdown/)
      * [ Stream whales  ](https://ai.pydantic.dev/examples/stream-whales/)
    * Complex Workflows
      * [ Flight booking  ](https://ai.pydantic.dev/examples/flight-booking/)
      * [ Question Graph  ](https://ai.pydantic.dev/examples/question-graph/)
    * Business Applications
      * [ Slack Lead Qualifier with Modal  ](https://ai.pydantic.dev/examples/slack-lead-qualifier/)
    * UI Examples
      * [ Agent User Interaction (AG-UI)  ](https://ai.pydantic.dev/examples/ag-ui/)
  * API Reference
    * pydantic_ai
      * [ pydantic_ai.ag_ui  ](https://ai.pydantic.dev/api/ag_ui/)
      * [ pydantic_ai.agent  ](https://ai.pydantic.dev/api/agent/)
      * [ pydantic_ai.builtin_tools  ](https://ai.pydantic.dev/api/builtin_tools/)
      * [ pydantic_ai.common_tools  ](https://ai.pydantic.dev/api/common_tools/)
      * [ pydantic_ai — Concurrency  ](https://ai.pydantic.dev/api/concurrency/)
      * [ pydantic_ai.direct  ](https://ai.pydantic.dev/api/direct/)
      * [ pydantic_ai.durable_exec  ](https://ai.pydantic.dev/api/durable_exec/)
      * [ pydantic_ai.embeddings  ](https://ai.pydantic.dev/api/embeddings/)
      * [ pydantic_ai.exceptions  ](https://ai.pydantic.dev/api/exceptions/)
      * [ pydantic_ai.ext  ](https://ai.pydantic.dev/api/ext/)
      * [ pydantic_ai.format_prompt  ](https://ai.pydantic.dev/api/format_prompt/)
      * [ pydantic_ai.mcp  ](https://ai.pydantic.dev/api/mcp/)
      * [ pydantic_ai.messages  ](https://ai.pydantic.dev/api/messages/)
      * [ pydantic_ai.models.anthropic  ](https://ai.pydantic.dev/api/models/anthropic/)
      * [ pydantic_ai.models  ](https://ai.pydantic.dev/api/models/base/)
      * [ pydantic_ai.models.bedrock  ](https://ai.pydantic.dev/api/models/bedrock/)
      * [ pydantic_ai.models.cerebras  ](https://ai.pydantic.dev/api/models/cerebras/)
      * [ pydantic_ai.models.cohere  ](https://ai.pydantic.dev/api/models/cohere/)
      * [ pydantic_ai.models.fallback  ](https://ai.pydantic.dev/api/models/fallback/)
      * [ pydantic_ai.models.function  ](https://ai.pydantic.dev/api/models/function/)
      * [ pydantic_ai.models.google  ](https://ai.pydantic.dev/api/models/google/)
      * [ pydantic_ai.models.xai  ](https://ai.pydantic.dev/api/models/xai/)
      * [ pydantic_ai.models.groq  ](https://ai.pydantic.dev/api/models/groq/)
      * [ pydantic_ai.models.huggingface  ](https://ai.pydantic.dev/api/models/huggingface/)
      * [ pydantic_ai.models.instrumented  ](https://ai.pydantic.dev/api/models/instrumented/)
      * [ pydantic_ai.models.mcp_sampling  ](https://ai.pydantic.dev/api/models/mcp-sampling/)
      * [ pydantic_ai.models.mistral  ](https://ai.pydantic.dev/api/models/mistral/)
      * [ pydantic_ai.models.openai  ](https://ai.pydantic.dev/api/models/openai/)
      * [ pydantic_ai.models.openrouter  ](https://ai.pydantic.dev/api/models/openrouter/)
      * [ pydantic_ai.models.outlines  ](https://ai.pydantic.dev/api/models/outlines/)
      * [ pydantic_ai.models.test  ](https://ai.pydantic.dev/api/models/test/)
      * [ pydantic_ai.models.wrapper  ](https://ai.pydantic.dev/api/models/wrapper/)
      * [ pydantic_ai.output  ](https://ai.pydantic.dev/api/output/)
      * [ pydantic_ai.profiles  ](https://ai.pydantic.dev/api/profiles/)
      * [ pydantic_ai.providers  ](https://ai.pydantic.dev/api/providers/)
      * [ pydantic_ai.result  ](https://ai.pydantic.dev/api/result/)
      * [ pydantic_ai.retries  ](https://ai.pydantic.dev/api/retries/)
      * [ pydantic_ai.run  ](https://ai.pydantic.dev/api/run/)
      * [ pydantic_ai.settings  ](https://ai.pydantic.dev/api/settings/)
      * [ pydantic_ai.tools  ](https://ai.pydantic.dev/api/tools/)
      * [ pydantic_ai.toolsets  ](https://ai.pydantic.dev/api/toolsets/)
      * [ pydantic_ai.ui.ag_ui  ](https://ai.pydantic.dev/api/ui/ag_ui/)
      * [ pydantic_ai.ui  ](https://ai.pydantic.dev/api/ui/base/)
      * [ pydantic_ai.ui.vercel_ai  ](https://ai.pydantic.dev/api/ui/vercel_ai/)
      * [ pydantic_ai.usage  ](https://ai.pydantic.dev/api/usage/)
    * pydantic_evals
      * [ pydantic_evals.dataset  ](https://ai.pydantic.dev/api/pydantic_evals/dataset/)
      * [ pydantic_evals.evaluators  ](https://ai.pydantic.dev/api/pydantic_evals/evaluators/)
      * [ pydantic_evals.reporting  ](https://ai.pydantic.dev/api/pydantic_evals/reporting/)
      * [ pydantic_evals.otel  ](https://ai.pydantic.dev/api/pydantic_evals/otel/)
      * [ pydantic_evals.generation  ](https://ai.pydantic.dev/api/pydantic_evals/generation/)
    * pydantic_graph
      * [ pydantic_graph  ](https://ai.pydantic.dev/api/pydantic_graph/graph/)
      * [ pydantic_graph.nodes  ](https://ai.pydantic.dev/api/pydantic_graph/nodes/)
      * [ pydantic_graph.persistence  ](https://ai.pydantic.dev/api/pydantic_graph/persistence/)
      * [ pydantic_graph.mermaid  ](https://ai.pydantic.dev/api/pydantic_graph/mermaid/)
      * [ pydantic_graph.exceptions  ](https://ai.pydantic.dev/api/pydantic_graph/exceptions/)
      * Beta API
        * [ pydantic_graph.beta  ](https://ai.pydantic.dev/api/pydantic_graph/beta/)
        * [ pydantic_graph.beta.graph  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph/)
        * [ pydantic_graph.beta.graph_builder  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph_builder/)
        * [ pydantic_graph.beta.step  ](https://ai.pydantic.dev/api/pydantic_graph/beta_step/)
        * [ pydantic_graph.beta.join  ](https://ai.pydantic.dev/api/pydantic_graph/beta_join/)
        * [ pydantic_graph.beta.decision  ](https://ai.pydantic.dev/api/pydantic_graph/beta_decision/)
        * [ pydantic_graph.beta.node  ](https://ai.pydantic.dev/api/pydantic_graph/beta_node/)
    * fasta2a
      * [ fasta2a  ](https://ai.pydantic.dev/api/fasta2a/)
  * Project
    * [ Contributing  ](https://ai.pydantic.dev/contributing/)
    * Upgrade Guide  [ Upgrade Guide  ](https://ai.pydantic.dev/changelog/)
      * [ Breaking Changes  ](https://ai.pydantic.dev/changelog/#breaking-changes)
        * [ v1.0.1 (2025-09-05)  ](https://ai.pydantic.dev/changelog/#v101-2025-09-05)
        * [ v1.0.0 (2025-09-04)  ](https://ai.pydantic.dev/changelog/#v100-2025-09-04)
        * [ v0.x.x  ](https://ai.pydantic.dev/changelog/#v0xx)
      * [ Full Changelog  ](https://ai.pydantic.dev/changelog/#full-changelog)
    * [ Version policy  ](https://ai.pydantic.dev/version-policy/)


  * [ Breaking Changes  ](https://ai.pydantic.dev/changelog/#breaking-changes)
    * [ v1.0.1 (2025-09-05)  ](https://ai.pydantic.dev/changelog/#v101-2025-09-05)
    * [ v1.0.0 (2025-09-04)  ](https://ai.pydantic.dev/changelog/#v100-2025-09-04)
    * [ v0.x.x  ](https://ai.pydantic.dev/changelog/#v0xx)
  * [ Full Changelog  ](https://ai.pydantic.dev/changelog/#full-changelog)


  1. [ Pydantic AI  ](https://ai.pydantic.dev/)
  2. [ Project  ](https://ai.pydantic.dev/contributing/)


# Upgrade Guide
In September 2025, Pydantic AI reached V1, which means we're committed to API stability: we will not introduce changes that break your code until V2. For more information, review our [Version Policy](https://ai.pydantic.dev/version-policy/).
## Breaking Changes
Here's a filtered list of the breaking changes for each version to help you upgrade Pydantic AI.
### v1.0.1 (2025-09-05)
The following breaking change was accidentally left out of v1.0.0:
  * See [#2808](https://github.com/pydantic/pydantic-ai/pull/2808) - Remove `Python` evaluator from `pydantic_evals` for security reasons


### v1.0.0 (2025-09-04)
  * See [#2725](https://github.com/pydantic/pydantic-ai/pull/2725) - Drop support for Python 3.9
  * See [#2738](https://github.com/pydantic/pydantic-ai/pull/2738) - Make many dataclasses require keyword arguments
  * See [#2715](https://github.com/pydantic/pydantic-ai/pull/2715) - Remove `cases` and `averages` attributes from `pydantic_evals` spans
  * See [#2798](https://github.com/pydantic/pydantic-ai/pull/2798) - Change `ModelRequest.parts` and `ModelResponse.parts` types from `list` to `Sequence`
  * See [#2726](https://github.com/pydantic/pydantic-ai/pull/2726) - Default `InstrumentationSettings` version to 2
  * See [#2717](https://github.com/pydantic/pydantic-ai/pull/2717) - Remove errors when passing `AsyncRetrying` or `Retrying` object to `AsyncTenacityTransport` or `TenacityTransport` instead of `RetryConfig`


### v0.x.x
Before V1, minor versions were used to introduce breaking changes:
**v0.8.0 (2025-08-26)**
See [#2689](https://github.com/pydantic/pydantic-ai/pull/2689) - `AgentStreamEvent` was expanded to be a union of `ModelResponseStreamEvent` and `HandleResponseEvent`, simplifying the `event_stream_handler` function signature. Existing code accepting `AgentStreamEvent | HandleResponseEvent` will continue to work.
**v0.7.6 (2025-08-26)**
The following breaking change was inadvertently released in a patch version rather than a minor version:
See [#2670](https://github.com/pydantic/pydantic-ai/pull/2670) - `TenacityTransport` and `AsyncTenacityTransport` now require the use of `pydantic_ai.retries.RetryConfig` (which is just a `TypedDict` containing the kwargs to `tenacity.retry`) instead of `tenacity.Retrying` or `tenacity.AsyncRetrying`.
**v0.7.0 (2025-08-12)**
See [#2458](https://github.com/pydantic/pydantic-ai/pull/2458) - `pydantic_ai.models.StreamedResponse` now yields a `FinalResultEvent` along with the existing `PartStartEvent` and `PartDeltaEvent`. If you're using `pydantic_ai.direct.model_request_stream` or `pydantic_ai.direct.model_request_stream_sync`, you may need to update your code to account for this.
See [#2458](https://github.com/pydantic/pydantic-ai/pull/2458) - `pydantic_ai.models.Model.request_stream` now receives a `run_context` argument. If you've implemented a custom `Model` subclass, you will need to account for this.
See [#2458](https://github.com/pydantic/pydantic-ai/pull/2458) - `pydantic_ai.models.StreamedResponse` now requires a `model_request_parameters` field and constructor argument. If you've implemented a custom `Model` subclass and implemented `request_stream`, you will need to account for this.
**v0.6.0 (2025-08-06)**
This release was meant to clean some old deprecated code, so we can get a step closer to V1.
See [#2440](https://github.com/pydantic/pydantic-ai/pull/2440) - The `next` method was removed from the `Graph` class. Use `async with graph.iter(...) as run:  run.next()` instead.
See [#2441](https://github.com/pydantic/pydantic-ai/pull/2441) - The `result_type`, `result_tool_name` and `result_tool_description` arguments were removed from the `Agent` class. Use `output_type` instead.
See [#2441](https://github.com/pydantic/pydantic-ai/pull/2441) - The `result_retries` argument was also removed from the `Agent` class. Use `output_retries` instead.
See [#2443](https://github.com/pydantic/pydantic-ai/pull/2443) - The `data` property was removed from the `FinalResult` class. Use `output` instead.
See [#2445](https://github.com/pydantic/pydantic-ai/pull/2445) - The `get_data` and `validate_structured_result` methods were removed from the `StreamedRunResult` class. Use `get_output` and `validate_structured_output` instead.
See [#2446](https://github.com/pydantic/pydantic-ai/pull/2446) - The `format_as_xml` function was moved to the `pydantic_ai.format_as_xml` module. Import it via `from pydantic_ai import format_as_xml` instead.
See [#2451](https://github.com/pydantic/pydantic-ai/pull/2451) - Removed deprecated `Agent.result_validator` method, `Agent.last_run_messages` property, `AgentRunResult.data` property, and `result_tool_return_content` parameters from result classes.
**v0.5.0 (2025-08-04)**
See [#2388](https://github.com/pydantic/pydantic-ai/pull/2388) - The `source` field of an `EvaluationResult` is now of type `EvaluatorSpec` rather than the actual source `Evaluator` instance, to help with serialization/deserialization.
See [#2163](https://github.com/pydantic/pydantic-ai/pull/2163) - The `EvaluationReport.print` and `EvaluationReport.console_table` methods now require most arguments be passed by keyword.
**v0.4.0 (2025-07-08)**
See [#1799](https://github.com/pydantic/pydantic-ai/pull/1799) - Pydantic Evals `EvaluationReport` and `ReportCase` are now generic dataclasses instead of Pydantic models. If you were serializing them using `model_dump()`, you will now need to use the `EvaluationReportAdapter` and `ReportCaseAdapter` type adapters instead.
See [#1507](https://github.com/pydantic/pydantic-ai/pull/1507) - The `ToolDefinition` `description` argument is now optional and the order of positional arguments has changed from `name, description, parameters_json_schema, ...` to `name, parameters_json_schema, description, ...` to account for this.
**v0.3.0 (2025-06-18)**
See [#1142](https://github.com/pydantic/pydantic-ai/pull/1142) — Adds support for thinking parts.
We now convert the thinking blocks (`"<think>..."</think>"`) in provider specific text parts to Pydantic AI `ThinkingPart`s. Also, as part of this release, we made the choice to not send back the `ThinkingPart`s to the provider - the idea is to save costs on behalf of the user. In the future, we intend to add a setting to customize this behavior.
**v0.2.0 (2025-05-12)**
See [#1647](https://github.com/pydantic/pydantic-ai/pull/1647) — usage makes sense as part of `ModelResponse`, and could be really useful in "messages" (really a sequence of requests and response). In this PR:
  * Adds `usage` to `ModelResponse` (field has a default factory of `Usage()` so it'll work to load data that doesn't have usage)
  * changes the return type of `Model.request` to just `ModelResponse` instead of `tuple[ModelResponse, Usage]`


**v0.1.0 (2025-04-15)**
See [#1248](https://github.com/pydantic/pydantic-ai/pull/1248) — the attribute/parameter name `result` was renamed to `output` in many places. Hopefully all changes keep a deprecated attribute or parameter with the old name, so you should get many deprecation warnings.
See [#1484](https://github.com/pydantic/pydantic-ai/pull/1484) — `format_as_xml` was moved and made available to import from the package root, e.g. `from pydantic_ai import format_as_xml`.
## Full Changelog
### v1.63.0 (2026-02-23)
#### What's Changed
##### 🚀 Features
  * Add Gemini 3.1 Pro Preview support by [@majdalsado](https://github.com/majdalsado) in [#4372](https://github.com/pydantic/pydantic-ai/pull/4372)
  * feat(gemini): Logprob Support by [@DRXD1000](https://github.com/DRXD1000) in [#4269](https://github.com/pydantic/pydantic-ai/pull/4269)
  * Add `args_validator` parameter to tools for pre-execution validation by [@jerry-reevo](https://github.com/jerry-reevo) in [#4016](https://github.com/pydantic/pydantic-ai/pull/4016)


##### 🐛 Bug Fixes
  * Fix Temporal and DBOS MCP to use cached tools instead of fetching each time by [@DouweM](https://github.com/DouweM) in [#4331](https://github.com/pydantic/pydantic-ai/pull/4331)
  * Updated Cohere content item typing to fix the incompatibility by [@DarthJuri](https://github.com/DarthJuri) in [#4384](https://github.com/pydantic/pydantic-ai/pull/4384)
  * Fix Anthropic model on Bedrock incorrectly being treated as supporting json schema output by [@vimota](https://github.com/vimota) in [#4369](https://github.com/pydantic/pydantic-ai/pull/4369)
  * fix(pydantic-evals): gracefully handle custom `TracerProviders` without `add_span_processor` by [@AtharvaJaiswal005](https://github.com/AtharvaJaiswal005) in [#4328](https://github.com/pydantic/pydantic-ai/pull/4328)
  * fix: use non-greedy regex in `strip_markdown_fences` to stop at closing fence by [@sksvineeth](https://github.com/sksvineeth) in [#4398](https://github.com/pydantic/pydantic-ai/pull/4398)
  * fix: add defaults for optional fields in OpenRouter streaming models by [@majdalsado](https://github.com/majdalsado) in [#4371](https://github.com/pydantic/pydantic-ai/pull/4371)
  * Set `BuiltinToolCallPart.id` for OpenAI Responses WebSearch/FileSearch by [@yipstar](https://github.com/yipstar) in [#4391](https://github.com/pydantic/pydantic-ai/pull/4391)
  * fix: Identify new messages by `run_id` instead of index by [@madanlalit](https://github.com/madanlalit) in [#4086](https://github.com/pydantic/pydantic-ai/pull/4086)


#### New Contributors
  * [@majdalsado](https://github.com/majdalsado) made their first contribution in [#4372](https://github.com/pydantic/pydantic-ai/pull/4372)
  * [@DarthJuri](https://github.com/DarthJuri) made their first contribution in [#4384](https://github.com/pydantic/pydantic-ai/pull/4384)
  * [@AtharvaJaiswal005](https://github.com/AtharvaJaiswal005) made their first contribution in [#4328](https://github.com/pydantic/pydantic-ai/pull/4328)
  * [@sksvineeth](https://github.com/sksvineeth) made their first contribution in [#4398](https://github.com/pydantic/pydantic-ai/pull/4398)
  * [@DRXD1000](https://github.com/DRXD1000) made their first contribution in [#4269](https://github.com/pydantic/pydantic-ai/pull/4269)
  * [@yipstar](https://github.com/yipstar) made their first contribution in [#4391](https://github.com/pydantic/pydantic-ai/pull/4391)


[](https://github.com/pydantic/pydantic-ai/compare/v1.62.0...v1.63.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.63.0).
### v1.62.0 (2026-02-18)
#### What's Changed
##### 🚀 Features
  * Add tool approval integration for Vercel AI adapter by [@bendrucker](https://github.com/bendrucker) in [#3772](https://github.com/pydantic/pydantic-ai/pull/3772)
  * Add LinePlot analysis type, ROCAUCEvaluator, and KolmogorovSmirnovEvaluator by [@dmontagu](https://github.com/dmontagu) in [#4356](https://github.com/pydantic/pydantic-ai/pull/4356)


##### 🐛 Bug Fixes
  * Fix missing pages in llms.txt and llms-full.txt by [@DouweM](https://github.com/DouweM) in [#4355](https://github.com/pydantic/pydantic-ai/pull/4355)
  * Handle Groq `tool_use_failed` errors without tool name/args by retrying by [@DouweM](https://github.com/DouweM) in [#4354](https://github.com/pydantic/pydantic-ai/pull/4354)
  * fix: handle content filter refusals for Google `prompt_feedback` and OpenAI refusals by [@DouweM](https://github.com/DouweM) in [#4315](https://github.com/pydantic/pydantic-ai/pull/4315)


##### 📦 Dependencies
  * bump `huggingface` to 1.3.4 by [@dsfaccini](https://github.com/dsfaccini) in [#4119](https://github.com/pydantic/pydantic-ai/pull/4119)
  * Use `griffelib` instead of `griffe` by [@dsfaccini](https://github.com/dsfaccini) in [#4313](https://github.com/pydantic/pydantic-ai/pull/4313)


[](https://github.com/pydantic/pydantic-ai/compare/v1.61.0...v1.62.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.62.0).
### v1.61.0 (2026-02-17)
#### What's Changed
##### 🚀 Features
  * Support Python 3.14 by [@Kludex](https://github.com/Kludex) in [#4138](https://github.com/pydantic/pydantic-ai/pull/4138)


##### 📦 Dependencies
  * Upgrade anthropic to 0.80.0, add Claude Sonnet 4.6 by [@DouweM](https://github.com/DouweM) in [#4345](https://github.com/pydantic/pydantic-ai/pull/4345)


[](https://github.com/pydantic/pydantic-ai/compare/v1.60.0...v1.61.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.61.0).
### v1.60.0 (2026-02-16)
#### What's Changed
##### 🚀 Features
  * Add ‍`video_url` support to `OpenRouterModel` by [@Adversarian](https://github.com/Adversarian) in [#3824](https://github.com/pydantic/pydantic-ai/pull/3824)
  * Add instrumentation version 4 to match OTel GenAI semantic conventions for multimodal input by [@admackin](https://github.com/admackin) in [#4219](https://github.com/pydantic/pydantic-ai/pull/4219)


##### 🐛 Bug Fixes
  * Fix AG-UI `parent_message_id` for back-to-back builtin tool calls by [@DouweM](https://github.com/DouweM) in [#4332](https://github.com/pydantic/pydantic-ai/pull/4332)
  * Only suggest 'call a tool' in retry when tools are available by [@Baniskos](https://github.com/Baniskos) in [#4234](https://github.com/pydantic/pydantic-ai/pull/4234)
  * Wrap `_stream_text_deltas` with `aclosing` to prevent `StopAsyncIteration` on client disconnect by [@sheginabo](https://github.com/sheginabo) in [#4205](https://github.com/pydantic/pydantic-ai/pull/4205)


#### New Contributors
  * [@SamKomesarook](https://github.com/SamKomesarook) made their first contribution in [#4327](https://github.com/pydantic/pydantic-ai/pull/4327)
  * [@Baniskos](https://github.com/Baniskos) made their first contribution in [#4234](https://github.com/pydantic/pydantic-ai/pull/4234)
  * [@Adversarian](https://github.com/Adversarian) made their first contribution in [#3824](https://github.com/pydantic/pydantic-ai/pull/3824)
  * [@sheginabo](https://github.com/sheginabo) made their first contribution in [#4205](https://github.com/pydantic/pydantic-ai/pull/4205)
  * [@admackin](https://github.com/admackin) made their first contribution in [#4219](https://github.com/pydantic/pydantic-ai/pull/4219)


[](https://github.com/pydantic/pydantic-ai/compare/v1.59.0...v1.60.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.60.0).
### v1.59.0 (2026-02-13)
#### What's Changed
##### 🚀 Features
  * Add `Model.model_id` property that returns `provider:model` by [@tdevelope](https://github.com/tdevelope) in [#3917](https://github.com/pydantic/pydantic-ai/pull/3917)
  * Add opt-in flag for aggregated usage attribute names by [@thiagohora](https://github.com/thiagohora) in [#4277](https://github.com/pydantic/pydantic-ai/pull/4277)
  * Enhance `Contains` evaluator to support `pydantic.BaseModel` by [@tomsquest](https://github.com/tomsquest) in [#4003](https://github.com/pydantic/pydantic-ai/pull/4003)
  * Vercel AI adapter: let `BaseChunk`s be injected through `ToolReturnPart.metadata` by [@0xyjk](https://github.com/0xyjk) in [#4230](https://github.com/pydantic/pydantic-ai/pull/4230)


##### 🐛 Bug Fixes
  * XAI: lazily create AsyncClient per event loop to avoid gRPC loop mismatch by [@DouweM](https://github.com/DouweM) in [#4316](https://github.com/pydantic/pydantic-ai/pull/4316)


#### New Contributors
  * [@tdevelope](https://github.com/tdevelope) made their first contribution in [#3917](https://github.com/pydantic/pydantic-ai/pull/3917)
  * [@thiagohora](https://github.com/thiagohora) made their first contribution in [#4277](https://github.com/pydantic/pydantic-ai/pull/4277)
  * [@0xyjk](https://github.com/0xyjk) made their first contribution in [#4230](https://github.com/pydantic/pydantic-ai/pull/4230)


[](https://github.com/pydantic/pydantic-ai/compare/v1.58.0...v1.59.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.59.0).
### v1.58.0 (2026-02-10)
#### What's Changed
##### 🚀 Features
  * Report-level evaluators & experiment-wide analyses by [@dmontagu](https://github.com/dmontagu) in [#4243](https://github.com/pydantic/pydantic-ai/pull/4243)
  * Add multi-run aggregation support (repeat parameter) to pydantic-evals by [@dmontagu](https://github.com/dmontagu) in [#4253](https://github.com/pydantic/pydantic-ai/pull/4253)
  * Add `extra_headers` support for Google model provider by [@saakshigupta2002](https://github.com/saakshigupta2002) in [#4241](https://github.com/pydantic/pydantic-ai/pull/4241)


#### New Contributors
  * [@saakshigupta2002](https://github.com/saakshigupta2002) made their first contribution in [#4241](https://github.com/pydantic/pydantic-ai/pull/4241)


[](https://github.com/pydantic/pydantic-ai/compare/v1.57.0...v1.58.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.58.0).
### v1.57.0 (2026-02-09)
#### What's Changed
##### 🐛 Bug Fixes
  * Fix A2A FilePart base64 decoding for image/file uploads by [@Red5d](https://github.com/Red5d) in [#4181](https://github.com/pydantic/pydantic-ai/pull/4181)


#### New Contributors
  * [@Mr-Neutr0n](https://github.com/Mr-Neutr0n) made their first contribution in [#4208](https://github.com/pydantic/pydantic-ai/pull/4208)
  * [@Tamles](https://github.com/Tamles) made their first contribution in [#4257](https://github.com/pydantic/pydantic-ai/pull/4257)
  * [@Red5d](https://github.com/Red5d) made their first contribution in [#4181](https://github.com/pydantic/pydantic-ai/pull/4181)


[](https://github.com/pydantic/pydantic-ai/compare/v1.56.0...v1.57.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.57.0).
### v1.56.0 (2026-02-05)
#### What's Changed
##### 🚀 Features
  * Add Claude Opus 4.6, `anthropic_effort` and `anthropic_thinking.type='adaptive'` by [@dsfaccini](https://github.com/dsfaccini) in [#4216](https://github.com/pydantic/pydantic-ai/pull/4216)
  * Add `anthropic_betas` to `AnthropicModelSettings` by [@bohdanhr](https://github.com/bohdanhr) in [#4180](https://github.com/pydantic/pydantic-ai/pull/4180)


##### 🐛 Bug Fixes
  * Fix Bedrock `CachePoint` placement with multiple trailing documents by [@psg2](https://github.com/psg2) in [#4207](https://github.com/pydantic/pydantic-ai/pull/4207)
  * Disallow downloading `FileUrl`s pointing at the local network by default by [@DouweM](https://github.com/DouweM) in [#4227](https://github.com/pydantic/pydantic-ai/pull/4227)


[](https://github.com/pydantic/pydantic-ai/compare/v1.55.0...v1.56.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.56.0).
### v1.55.0 (2026-02-04)
#### What's Changed
##### 🐛 Bug Fixes
  * Fix error when using `OpenAIResponsesModel` with "compatible" provider that returns `reasoning_tokens` as `None` instead by [@alibeyram](https://github.com/alibeyram) in [#4151](https://github.com/pydantic/pydantic-ai/pull/4151)
  * Fix `MultiModalContent` union missing discriminator causing incorrect deserialization by [@jerry-reevo](https://github.com/jerry-reevo) in [#4191](https://github.com/pydantic/pydantic-ai/pull/4191)


[](https://github.com/pydantic/pydantic-ai/compare/v1.54.0...v1.55.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.55.0).
### v1.54.0 (2026-02-04)
#### What's Changed
##### 🚀 Features
  * Add concurrency limiting for Agents and Models by [@dmontagu](https://github.com/dmontagu) in [#4149](https://github.com/pydantic/pydantic-ai/pull/4149)


[](https://github.com/pydantic/pydantic-ai/compare/v1.53.0...v1.54.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.54.0).
### v1.53.0 (2026-02-04)
#### What's Changed
##### 🚀 Features
  * Infer gateway base URL from token region by [@Kludex](https://github.com/Kludex) in [#4192](https://github.com/pydantic/pydantic-ai/pull/4192)


[](https://github.com/pydantic/pydantic-ai/compare/v1.52.0...v1.53.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.53.0).
### v1.52.0 (2026-02-02)
#### What's Changed
##### 🚀 Features
  * Add `openai_store` setting to control data retention by [@EliMeed](https://github.com/EliMeed) in [#4142](https://github.com/pydantic/pydantic-ai/pull/4142)
  * Add number of output validation retries to agent's run context by [@coccoinomane](https://github.com/coccoinomane) in [#4084](https://github.com/pydantic/pydantic-ai/pull/4084)
  * Have `OpenAIChatModel` send back reasoning content via field it's received in by [@safina57](https://github.com/safina57) in [#4009](https://github.com/pydantic/pydantic-ai/pull/4009)


##### 🐛 Bug Fixes
  * Fix compatibility with Vercel AI SDK v5 by adding SDK version param by [@dsfaccini](https://github.com/dsfaccini) in [#4166](https://github.com/pydantic/pydantic-ai/pull/4166)
  * Handle non-primitive types in `BaseModel` in `format_as_xml` by [@bohdanhr](https://github.com/bohdanhr) in [#4131](https://github.com/pydantic/pydantic-ai/pull/4131)


#### New Contributors
  * [@EliMeed](https://github.com/EliMeed) made their first contribution in [#4142](https://github.com/pydantic/pydantic-ai/pull/4142)
  * [@bohdanhr](https://github.com/bohdanhr) made their first contribution in [#4131](https://github.com/pydantic/pydantic-ai/pull/4131)
  * [@coccoinomane](https://github.com/coccoinomane) made their first contribution in [#4084](https://github.com/pydantic/pydantic-ai/pull/4084)


[](https://github.com/pydantic/pydantic-ai/compare/v1.51.0...v1.52.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.52.0).
### v1.51.0 (2026-01-30)
#### What's Changed
##### 🚀 Features
  * feat(ui): Add `html_source` parameter to customize Chat UI source by [@madanlalit](https://github.com/madanlalit) in [#3974](https://github.com/pydantic/pydantic-ai/pull/3974)


##### 🐛 Bug Fixes
  * Fix error when Gemini calls tools in agent run with instructions but no user prompt by [@dsfaccini](https://github.com/dsfaccini) in [#4148](https://github.com/pydantic/pydantic-ai/pull/4148)
  * Fix Bedrock caching when user message ended on non-text content by [@DouweM](https://github.com/DouweM) in [#4152](https://github.com/pydantic/pydantic-ai/pull/4152)


#### New Contributors
  * [@madanlalit](https://github.com/madanlalit) made their first contribution in [#3974](https://github.com/pydantic/pydantic-ai/pull/3974)


[](https://github.com/pydantic/pydantic-ai/compare/v1.50.0...v1.51.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.51.0).
### v1.50.0 (2026-01-29)
#### What's Changed
##### 🚀 Features
  * Expose `usage_limits` and `model_settings` to users running with `to_cli()` by [@tommy-waltmann](https://github.com/tommy-waltmann) in [#4133](https://github.com/pydantic/pydantic-ai/pull/4133)
  * Add setting to include OpenAI raw text annotations in `TextPart.provider_details` by [@corytomlinson](https://github.com/corytomlinson) in [#3787](https://github.com/pydantic/pydantic-ai/pull/3787)


##### 🐛 Bug Fixes
  * Fix serialization of `BinaryContent` returned by tool in Temporal by [@dsfaccini](https://github.com/dsfaccini) in [#4043](https://github.com/pydantic/pydantic-ai/pull/4043)
  * Fix serialization of `DocumentUrl` with custom `media_type` in Temporal by [@dsfaccini](https://github.com/dsfaccini) in [#3968](https://github.com/pydantic/pydantic-ai/pull/3968)
  * Retry instead of raising error when Google returns 0 candidates by [@wassafshahzad](https://github.com/wassafshahzad) in [#4125](https://github.com/pydantic/pydantic-ai/pull/4125)
  * Correct OpenAI `prompt_cache_retention` literal from 'in-memory' to 'in_memory' by [@davidfertube](https://github.com/davidfertube) in [#4126](https://github.com/pydantic/pydantic-ai/pull/4126)


#### New Contributors
  * [@tommy-waltmann](https://github.com/tommy-waltmann) made their first contribution in [#4133](https://github.com/pydantic/pydantic-ai/pull/4133)
  * [@corytomlinson](https://github.com/corytomlinson) made their first contribution in [#3787](https://github.com/pydantic/pydantic-ai/pull/3787)
  * [@davidfertube](https://github.com/davidfertube) made their first contribution in [#4126](https://github.com/pydantic/pydantic-ai/pull/4126)


[](https://github.com/pydantic/pydantic-ai/compare/v1.49.0...v1.50.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.50.0).
### v1.49.0 (2026-01-28)
#### What's Changed
##### 🚀 Features
  * Support parallel tool calls in `DBOSAgent` by [@qianl15](https://github.com/qianl15) in [#4077](https://github.com/pydantic/pydantic-ai/pull/4077)
  * Add `BedrockEmbeddingModel` for Nova, Cohere and Titan endpoints by [@bitnahian](https://github.com/bitnahian) in [#4008](https://github.com/pydantic/pydantic-ai/pull/4008)
  * Match Vercel AI SDK types with AI SDK v6 by [@bendrucker](https://github.com/bendrucker) in [#4127](https://github.com/pydantic/pydantic-ai/pull/4127)


[](https://github.com/pydantic/pydantic-ai/compare/v1.48.0...v1.49.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.49.0).
### v1.48.0 (2026-01-27)
#### What's Changed
##### 🚀 Features
  * Add `allowed_domains` support for `WebSearchTool` with OpenAI by [@eduardojdiniz](https://github.com/eduardojdiniz) in [#4037](https://github.com/pydantic/pydantic-ai/pull/4037)
  * Add `continuous_usage_stats` model setting for OpenAI by [@kousun12](https://github.com/kousun12) in [#4056](https://github.com/pydantic/pydantic-ai/pull/4056)
  * Apply `model_settings` to Mistral streaming JSON mode by [@Goldokpa](https://github.com/Goldokpa) in [#4079](https://github.com/pydantic/pydantic-ai/pull/4079)


##### 🐛 Bug Fixes
  * Allow sampling params for GPT-5.1+ when reasoning is off by [@dsfaccini](https://github.com/dsfaccini) in [#4015](https://github.com/pydantic/pydantic-ai/pull/4015)
  * Support "OpenAI-compatible" embeddings APIs that omit usage by [@wassafshahzad](https://github.com/wassafshahzad) in [#4089](https://github.com/pydantic/pydantic-ai/pull/4089)


#### New Contributors
  * [@Goldokpa](https://github.com/Goldokpa) made their first contribution in [#4079](https://github.com/pydantic/pydantic-ai/pull/4079)
  * [@rgbkrk](https://github.com/rgbkrk) made their first contribution in [#4094](https://github.com/pydantic/pydantic-ai/pull/4094)
  * [@DougTrajano](https://github.com/DougTrajano) made their first contribution in [#4081](https://github.com/pydantic/pydantic-ai/pull/4081)
  * [@wassafshahzad](https://github.com/wassafshahzad) made their first contribution in [#4089](https://github.com/pydantic/pydantic-ai/pull/4089)
  * [@kousun12](https://github.com/kousun12) made their first contribution in [#4056](https://github.com/pydantic/pydantic-ai/pull/4056)
  * [@eduardojdiniz](https://github.com/eduardojdiniz) made their first contribution in [#4037](https://github.com/pydantic/pydantic-ai/pull/4037)


[](https://github.com/pydantic/pydantic-ai/compare/v1.47.0...v1.48.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.48.0).
### v1.47.0 (2026-01-23)
#### What's Changed
##### 🚀 Features
  * Ensure thought signatures and other provider metadata survive a round trip through a Vercel AI frontend by [@Light2Dark](https://github.com/Light2Dark) in [#3754](https://github.com/pydantic/pydantic-ai/pull/3754)


#### New Contributors
  * [@Light2Dark](https://github.com/Light2Dark) made their first contribution in [#3754](https://github.com/pydantic/pydantic-ai/pull/3754)


[](https://github.com/pydantic/pydantic-ai/compare/v1.46.0...v1.47.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.47.0).
### v1.46.0 (2026-01-22)
#### What's Changed
##### 🚀 Features
  * Add `XaiModel` that uses the xAI SDK and deprecate `GrokProvider` that used the OpenAI-compatible API by [@brightsparc](https://github.com/brightsparc) in [#3400](https://github.com/pydantic/pydantic-ai/pull/3400)
  * Bump `mcp` and other dependencies for Dependabot alerts by [@dsfaccini](https://github.com/dsfaccini) in [#4047](https://github.com/pydantic/pydantic-ai/pull/4047)


#### New Contributors
  * [@brightsparc](https://github.com/brightsparc) made their first contribution in [#3400](https://github.com/pydantic/pydantic-ai/pull/3400)


[](https://github.com/pydantic/pydantic-ai/compare/v1.45.0...v1.46.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.46.0).
### v1.45.0 (2026-01-21)
#### What's Changed
##### 🚀 Features
  * VoyageAI embeddings support by [@ggozad](https://github.com/ggozad) in [#3856](https://github.com/pydantic/pydantic-ai/pull/3856)


##### 🐛 Bug Fixes
  * Update the default behavior for `OpenRouter` from downloading `DocumentUrl`s and sending them as bytes, to sending them as URLs by [@dsfaccini](https://github.com/dsfaccini) in [#3997](https://github.com/pydantic/pydantic-ai/pull/3997)
  * fix(google): Set timeout in `HttpOptions` to prevent requests hanging indefinitely by [@assafeisr](https://github.com/assafeisr) in [#4032](https://github.com/pydantic/pydantic-ai/pull/4032)
  * Fix Gemini ignoring user prompt when continuing conversation that ended on structured output by [@tomsquest](https://github.com/tomsquest) in [#3996](https://github.com/pydantic/pydantic-ai/pull/3996)
  * bug: Fix gateway snippet auto-generation for the `google-gla` shorthand by [@dsfaccini](https://github.com/dsfaccini) in [#4058](https://github.com/pydantic/pydantic-ai/pull/4058)
  * Use `get_type_hints()` in `function_schema()` by [@Viicos](https://github.com/Viicos) in [#3693](https://github.com/pydantic/pydantic-ai/pull/3693)


#### New Contributors
  * [@qwaz-theori](https://github.com/qwaz-theori) made their first contribution in [#4055](https://github.com/pydantic/pydantic-ai/pull/4055)
  * [@polybuildr](https://github.com/polybuildr) made their first contribution in [#4046](https://github.com/pydantic/pydantic-ai/pull/4046)
  * [@HeAndres](https://github.com/HeAndres) made their first contribution in [#4034](https://github.com/pydantic/pydantic-ai/pull/4034)
  * [@tomsquest](https://github.com/tomsquest) made their first contribution in [#3996](https://github.com/pydantic/pydantic-ai/pull/3996)
  * [@ggozad](https://github.com/ggozad) made their first contribution in [#3856](https://github.com/pydantic/pydantic-ai/pull/3856)
  * [@assafeisr](https://github.com/assafeisr) made their first contribution in [#4032](https://github.com/pydantic/pydantic-ai/pull/4032)


[](https://github.com/pydantic/pydantic-ai/compare/v1.44.0...v1.45.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.45.0).
### v1.44.0 (2026-01-16)
#### What's Changed
##### 🚀 Features
  * feat: Add Exa search tools integration by [@10ishq](https://github.com/10ishq) in [#3736](https://github.com/pydantic/pydantic-ai/pull/3736)
  * Add support for Bedrock Nova 2.0 built-in `Code Interpreter` tool by [@gmetzker](https://github.com/gmetzker) in [#3892](https://github.com/pydantic/pydantic-ai/pull/3892)


##### 🐛 Bug Fixes
  * Make `count_tokens()` work on `WrapperModel` by [@DouweM](https://github.com/DouweM) in [#3982](https://github.com/pydantic/pydantic-ai/pull/3982)


#### New Contributors
  * [@10ishq](https://github.com/10ishq) made their first contribution in [#3736](https://github.com/pydantic/pydantic-ai/pull/3736)
  * [@gmetzker](https://github.com/gmetzker) made their first contribution in [#3892](https://github.com/pydantic/pydantic-ai/pull/3892)


[](https://github.com/pydantic/pydantic-ai/compare/v1.43.0...v1.44.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.44.0).
### v1.43.0 (2026-01-15)
#### What's Changed
##### 🚀 Features
  * Support Google embedding models by [@tboser](https://github.com/tboser) in [#3841](https://github.com/pydantic/pydantic-ai/pull/3841)


##### 🐛 Bug Fixes
  * Fix OpenAI never populating `dict[str, ...]` tool args by [@hinnefe2](https://github.com/hinnefe2) in [#3712](https://github.com/pydantic/pydantic-ai/pull/3712)


[](https://github.com/pydantic/pydantic-ai/compare/v1.42.0...v1.43.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.43.0).
### v1.42.0 (2026-01-13)
#### What's Changed
##### 🚀 Features
  * Add SambaNova provider support by [@Pavanmanikanta98](https://github.com/Pavanmanikanta98) in [#3887](https://github.com/pydantic/pydantic-ai/pull/3887)
  * Consistently raise `ContentFilterError` when model response is empty because of content filter by [@AlanPonnachan](https://github.com/AlanPonnachan) in [#3634](https://github.com/pydantic/pydantic-ai/pull/3634)
  * Bump google-genai to 1.56.0 by [@petersli](https://github.com/petersli) in [#3782](https://github.com/pydantic/pydantic-ai/pull/3782)
  * Add OTel GenAI semantic convention attributes by [@jimilp7](https://github.com/jimilp7) in [#3844](https://github.com/pydantic/pydantic-ai/pull/3844)


##### 🐛 Bug Fixes
  * Cancel tool calls when `Agent.run` or `Agent.run_stream_events` coroutine is cancelled by [@smthngslv](https://github.com/smthngslv) in [#3961](https://github.com/pydantic/pydantic-ai/pull/3961)


#### New Contributors
  * [@jimilp7](https://github.com/jimilp7) made their first contribution in [#3844](https://github.com/pydantic/pydantic-ai/pull/3844)
  * [@smthngslv](https://github.com/smthngslv) made their first contribution in [#3961](https://github.com/pydantic/pydantic-ai/pull/3961)
  * [@psg2](https://github.com/psg2) made their first contribution in [#3914](https://github.com/pydantic/pydantic-ai/pull/3914)


[](https://github.com/pydantic/pydantic-ai/compare/v1.41.0...v1.42.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.42.0).
### v1.41.0 (2026-01-09)
#### What's Changed
##### 🚀 Features
  * Add YAML and TOML media type support in `BinaryContent.from_path` by [@majiayu000](https://github.com/majiayu000) in [#3907](https://github.com/pydantic/pydantic-ai/pull/3907)
  * Add `metadata` support for `DeferredToolResults` by [@Wh1isper](https://github.com/Wh1isper) in [#3811](https://github.com/pydantic/pydantic-ai/pull/3811)


##### 🐛 Bug Fixes
  * Don't raise error when Mistral returns `ReferenceChunk` by [@ilancoulon](https://github.com/ilancoulon) in [#3958](https://github.com/pydantic/pydantic-ai/pull/3958)


#### New Contributors
  * [@ilancoulon](https://github.com/ilancoulon) made their first contribution in [#3958](https://github.com/pydantic/pydantic-ai/pull/3958)


[](https://github.com/pydantic/pydantic-ai/compare/v1.40.0...v1.41.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.41.0).
### v1.40.0 (2026-01-06)
#### What's Changed
##### 🚀 Features
  * Set human-readable Temporal activity summaries by [@DouweM](https://github.com/DouweM) in [#3919](https://github.com/pydantic/pydantic-ai/pull/3919)
  * Let agent call nonexistent tool as often as `Agent` `retries` limit specifies by [@geodavic](https://github.com/geodavic) in [#3597](https://github.com/pydantic/pydantic-ai/pull/3597)


##### 🐛 Bug Fixes
  * Ensure `stream_output()` always calls output function/validator with `partial_output=False` at the end of streaming by [@DouweM](https://github.com/DouweM) in [#3918](https://github.com/pydantic/pydantic-ai/pull/3918)
  * Fix `PydanticAIPlugin` to preserve custom `payload_codec` and respect `PydanticPayloadConverter` subclasses by [@DouweM](https://github.com/DouweM) in [#3920](https://github.com/pydantic/pydantic-ai/pull/3920)


#### New Contributors
  * [@gkarthi-signoz](https://github.com/gkarthi-signoz) made their first contribution in [#3928](https://github.com/pydantic/pydantic-ai/pull/3928)
  * [@geodavic](https://github.com/geodavic) made their first contribution in [#3597](https://github.com/pydantic/pydantic-ai/pull/3597)


[](https://github.com/pydantic/pydantic-ai/compare/v1.39.1...v1.40.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.40.0).
### v1.39.1 (2026-01-05)
#### What's Changed
##### 🐛 Bug Fixes
  * Fix `partial_output` flag in `TextOutput` during streaming by [@Danipulok](https://github.com/Danipulok) in [#3845](https://github.com/pydantic/pydantic-ai/pull/3845)
  * Fix duplicated tool calls with `partial_output=False` and cache result by [@Danipulok](https://github.com/Danipulok) in [#3848](https://github.com/pydantic/pydantic-ai/pull/3848)
  * Update `thoughtSignature` for Vertex Gemini 3 compatibility by [@jerry-heygen](https://github.com/jerry-heygen) in [#3882](https://github.com/pydantic/pydantic-ai/pull/3882)
  * Fix `input_tokens` calculation for Bedrock model (###3850) by [@Tshapislav](https://github.com/Tshapislav) in [#3853](https://github.com/pydantic/pydantic-ai/pull/3853)


#### New Contributors
  * [@Tshapislav](https://github.com/Tshapislav) made their first contribution in [#3853](https://github.com/pydantic/pydantic-ai/pull/3853)


[](https://github.com/pydantic/pydantic-ai/compare/v1.39.0...v1.39.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.39.1).
### v1.39.0 (2025-12-23)
#### What's Changed
  * Support embedding models by [@DouweM](https://github.com/DouweM) and [@dmontagu](https://github.com/dmontagu) in [#3252](https://github.com/pydantic/pydantic-ai/pull/3252)
  * Add Agent and agent run metadata and expose it on result objects and span attributes by [@sstanovnik](https://github.com/sstanovnik) in [#3370](https://github.com/pydantic/pydantic-ai/pull/3370)
  * Support system prompts functions returning `None` by [@mrdkucher](https://github.com/mrdkucher) in [#3834](https://github.com/pydantic/pydantic-ai/pull/3834)
  * Handle ThinkingPart in MCP Sampling by [@eekstunt](https://github.com/eekstunt) in [#3823](https://github.com/pydantic/pydantic-ai/pull/3823)
  * Add `bedrock_service_tier` setting to `BedrockModelSettings` by [@lukekh](https://github.com/lukekh) in [#3773](https://github.com/pydantic/pydantic-ai/pull/3773)
  * Add docs and tests for `RunContext.partial_output` in output tools by [@Danipulok](https://github.com/Danipulok) in [#3726](https://github.com/pydantic/pydantic-ai/pull/3726)
  * Update docs about choosing priority of output and deferred tool calls with run_stream by [@Danipulok](https://github.com/Danipulok) in [#3725](https://github.com/pydantic/pydantic-ai/pull/3725)
  * docs: Fix cross references by [@sanxiyn](https://github.com/sanxiyn) in [#3809](https://github.com/pydantic/pydantic-ai/pull/3809)
  * Add pydantic-deep + toolsets to docs by [@DouweM](https://github.com/DouweM) in [#3837](https://github.com/pydantic/pydantic-ai/pull/3837)


#### New Contributors
  * [@sanxiyn](https://github.com/sanxiyn) made their first contribution in [#3809](https://github.com/pydantic/pydantic-ai/pull/3809)
  * [@eekstunt](https://github.com/eekstunt) made their first contribution in [#3823](https://github.com/pydantic/pydantic-ai/pull/3823)
  * [@sstanovnik](https://github.com/sstanovnik) made their first contribution in [#3370](https://github.com/pydantic/pydantic-ai/pull/3370)
  * [@mrdkucher](https://github.com/mrdkucher) made their first contribution in [#3834](https://github.com/pydantic/pydantic-ai/pull/3834)


[](https://github.com/pydantic/pydantic-ai/compare/v1.38.0...v1.39.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.39.0).
### v1.38.0 (2025-12-22)
#### What's Changed
  * Add local timestamps to request and response models - include provider timestamp in `provider_details` by [@dsfaccini](https://github.com/dsfaccini) in [#3598](https://github.com/pydantic/pydantic-ai/pull/3598)
  * Respect `VideoUrl.vendor_metadata` for GCS URIs on google-vertex by [@barapa](https://github.com/barapa) in [#3806](https://github.com/pydantic/pydantic-ai/pull/3806)
  * Fix media type inference for URLs with query parameters by [@fedexman](https://github.com/fedexman) in [#3501](https://github.com/pydantic/pydantic-ai/pull/3501)
  * Allow typed `RunContext[Deps]` in `TextOutput` signature by [@dsfaccini](https://github.com/dsfaccini) in [#3732](https://github.com/pydantic/pydantic-ai/pull/3732)
  * Silently ignore AG-UI `ActivityMessage` instead of raising error by [@tseaver](https://github.com/tseaver) in [#3803](https://github.com/pydantic/pydantic-ai/pull/3803)
  * docs: Add Azure, Bedrock and Vertex examples to use Anthropic models by [@dsfaccini](https://github.com/dsfaccini) in [#3705](https://github.com/pydantic/pydantic-ai/pull/3705)
  * docs: Add note on persistence to beta graph docs by [@dsfaccini](https://github.com/dsfaccini) in [#3801](https://github.com/pydantic/pydantic-ai/pull/3801)


#### New Contributors
  * [@fedexman](https://github.com/fedexman) made their first contribution in [#3501](https://github.com/pydantic/pydantic-ai/pull/3501)
  * [@tseaver](https://github.com/tseaver) made their first contribution in [#3803](https://github.com/pydantic/pydantic-ai/pull/3803)


[](https://github.com/pydantic/pydantic-ai/compare/v1.37.0...v1.38.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.38.0).
### v1.37.0 (2025-12-19)
#### What's Changed
  * Allow `TemporalAgent` to switch model at `agent.run`-time by [@mattbrandman](https://github.com/mattbrandman) in [#3537](https://github.com/pydantic/pydantic-ai/pull/3537)
  * Add `DynamicToolset` support in Temporal by [@dsfaccini](https://github.com/dsfaccini) in [#3682](https://github.com/pydantic/pydantic-ai/pull/3682)
  * Add support for `ImageGenerationTool` `output_compression` and `output_format` for Vertex AI Gemini image models by [@h0rv](https://github.com/h0rv) in [#3759](https://github.com/pydantic/pydantic-ai/pull/3759)
  * Update known Groq model names (add production/preview, remove deprecated) by [@hima12-awny](https://github.com/hima12-awny) in [#3774](https://github.com/pydantic/pydantic-ai/pull/3774)
  * Add model profile flag for APIs that support native output but still require JSON schema in instructions by [@xcpky](https://github.com/xcpky) in [#3744](https://github.com/pydantic/pydantic-ai/pull/3744)
  * Set `ToolRetryError` message by [@jamesaud](https://github.com/jamesaud) in [#3718](https://github.com/pydantic/pydantic-ai/pull/3718)
  * Fix `StreamedRunResult.get_output()` creating duplicate messages if `stream_output()` has already been called by [@DouweM](https://github.com/DouweM) in [#3777](https://github.com/pydantic/pydantic-ai/pull/3777)
  * Re-add `clai --help` output to clai README by [@dsfaccini](https://github.com/dsfaccini) in [#3766](https://github.com/pydantic/pydantic-ai/pull/3766)


#### New Contributors
  * [@hima12-awny](https://github.com/hima12-awny) made their first contribution in [#3774](https://github.com/pydantic/pydantic-ai/pull/3774)
  * [@jamesaud](https://github.com/jamesaud) made their first contribution in [#3718](https://github.com/pydantic/pydantic-ai/pull/3718)


[](https://github.com/pydantic/pydantic-ai/compare/v1.36.0...v1.37.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.37.0).
### v1.36.0 (2025-12-18)
#### What's Changed
  * Add AI SDK data chunk ID and tool approval types by [@bendrucker](https://github.com/bendrucker) in [#3760](https://github.com/pydantic/pydantic-ai/pull/3760)
  * Ensure `type` field when converting `const` to `enum` in `GoogleJsonSchemaTransformer` by [@majiayu000](https://github.com/majiayu000) in [#3751](https://github.com/pydantic/pydantic-ai/pull/3751)
  * Bump `google-genai` to 1.56.0 by [@petersli](https://github.com/petersli) in [#3770](https://github.com/pydantic/pydantic-ai/pull/3770)


#### New Contributors
  * [@majiayu000](https://github.com/majiayu000) made their first contribution in [#3751](https://github.com/pydantic/pydantic-ai/pull/3751)
  * [@bendrucker](https://github.com/bendrucker) made their first contribution in [#3760](https://github.com/pydantic/pydantic-ai/pull/3760)


[](https://github.com/pydantic/pydantic-ai/compare/v1.35.0...v1.36.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.36.0).
### v1.35.0 (2025-12-17)
#### What's Changed
  * Add `FileSearchTool` with support for OpenAI and Google by [@gorkachea](https://github.com/gorkachea) in [#3396](https://github.com/pydantic/pydantic-ai/pull/3396)
  * Add support for `ImageGenerationTool.size` to Gemini image models by [@h0rv](https://github.com/h0rv) in [#3720](https://github.com/pydantic/pydantic-ai/pull/3720)
  * Adding Gemini 3 flash by [@jhammarstedt](https://github.com/jhammarstedt) in [#3755](https://github.com/pydantic/pydantic-ai/pull/3755)
  * Add Alibaba Cloud `DashScopeProvider` and support audio input for Qwen Omni by [@Pavanmanikanta98](https://github.com/Pavanmanikanta98) in [#3596](https://github.com/pydantic/pydantic-ai/pull/3596)
  * Added support for AG-UI Multi-modal Messages by [@bojan2501](https://github.com/bojan2501) in [#3715](https://github.com/pydantic/pydantic-ai/pull/3715)
  * Set timestamps on AG-UI events by [@thejens](https://github.com/thejens) in [#3742](https://github.com/pydantic/pydantic-ai/pull/3742)
  * Support OpenAI reasoning summary option 'auto' by [@DouweM](https://github.com/DouweM) in [#3753](https://github.com/pydantic/pydantic-ai/pull/3753)
  * Operate on a deepcopy of `$defs` in `JsonSchemaTransformer` instead of the original schema by [@thomasst](https://github.com/thomasst) in [#3758](https://github.com/pydantic/pydantic-ai/pull/3758)
  * Fix typing issue when using `UIAdapter.dispatch_request` with agent with `output_type` by [@DouweM](https://github.com/DouweM) in [#3749](https://github.com/pydantic/pydantic-ai/pull/3749)


#### New Contributors
  * [@h0rv](https://github.com/h0rv) made their first contribution in [#3720](https://github.com/pydantic/pydantic-ai/pull/3720)
  * [@thejens](https://github.com/thejens) made their first contribution in [#3742](https://github.com/pydantic/pydantic-ai/pull/3742)
  * [@gorkachea](https://github.com/gorkachea) made their first contribution in [#3396](https://github.com/pydantic/pydantic-ai/pull/3396)
  * [@bojan2501](https://github.com/bojan2501) made their first contribution in [#3715](https://github.com/pydantic/pydantic-ai/pull/3715)
  * [@thomasst](https://github.com/thomasst) made their first contribution in [#3758](https://github.com/pydantic/pydantic-ai/pull/3758)


[](https://github.com/pydantic/pydantic-ai/compare/v1.34.0...v1.35.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.35.0).
### v1.34.0 (2025-12-16)
#### What's Changed
  * Add Web Chat UI for any agent that can be launched using `clai web` or `Agent.to_web()` by [@dsfaccini](https://github.com/dsfaccini) in [#3456](https://github.com/pydantic/pydantic-ai/pull/3456)
  * Support `FileUrl.force_download` in `AnthropicModel` and `OpenAIResponsesModel` by [@dsfaccini](https://github.com/dsfaccini) in [#3694](https://github.com/pydantic/pydantic-ai/pull/3694)
  * Fix using sync history processors, instructions functions, and output functions with `TemporalAgent` by [@dsfaccini](https://github.com/dsfaccini) in [#3704](https://github.com/pydantic/pydantic-ai/pull/3704)
  * Make `OpenRouterProvider` and `DeepSeekProvider` `__init__` overloads less restrictive by [@xcpky](https://github.com/xcpky) in [#3739](https://github.com/pydantic/pydantic-ai/pull/3739)
  * Bump min version of griffe to `1.14.0` by [@jerry-reevo](https://github.com/jerry-reevo) in [#3743](https://github.com/pydantic/pydantic-ai/pull/3743)


[](https://github.com/pydantic/pydantic-ai/compare/v1.33.0...v1.34.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.34.0).
### v1.33.0 (2025-12-15)
#### What's Changed
  * Pass `s3://` file URLs directly to API in `BedrockConverseModel` by [@mochow13](https://github.com/mochow13) in [#3663](https://github.com/pydantic/pydantic-ai/pull/3663)
  * Insert agent `instructions` after `system_prompt`s for models that don't natively support instructions by [@siddhantbhagat8](https://github.com/siddhantbhagat8) in [#3614](https://github.com/pydantic/pydantic-ai/pull/3614)
  * Bump google-genai to 1.55 by [@dsfaccini](https://github.com/dsfaccini) in [#3727](https://github.com/pydantic/pydantic-ai/pull/3727)
  * docs: Update mkdocstrings-python to 2.x and fix cross-reference paths by [@dsfaccini](https://github.com/dsfaccini) in [#3706](https://github.com/pydantic/pydantic-ai/pull/3706)


#### New Contributors
  * [@siddhantbhagat8](https://github.com/siddhantbhagat8) made their first contribution in [#3614](https://github.com/pydantic/pydantic-ai/pull/3614)


[](https://github.com/pydantic/pydantic-ai/compare/v1.32.0...v1.33.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.33.0).
### v1.32.0 (2025-12-12)
#### What's Changed
  * Add tool timeout support by [@DEENUU1](https://github.com/DEENUU1) in [#3594](https://github.com/pydantic/pydantic-ai/pull/3594)
  * Let `TemporalAgent`s be registered to a Temporal workflow using `__pydantic_ai_agents__` field by [@adtyavrdhn](https://github.com/adtyavrdhn) in [#3676](https://github.com/pydantic/pydantic-ai/pull/3676)
  * Make `end_strategy` also work for output tools, not just tools by [@Danipulok](https://github.com/Danipulok) in [#3523](https://github.com/pydantic/pydantic-ai/pull/3523)
  * Replace OTel events with logs by [@alexmojaki](https://github.com/alexmojaki) in [#3641](https://github.com/pydantic/pydantic-ai/pull/3641)
  * Fix `UIAdapter.dispatch_request` typing by [@dmontagu](https://github.com/dmontagu) in [#3721](https://github.com/pydantic/pydantic-ai/pull/3721)


#### New Contributors
  * [@DEENUU1](https://github.com/DEENUU1) made their first contribution in [#3594](https://github.com/pydantic/pydantic-ai/pull/3594)


[](https://github.com/pydantic/pydantic-ai/compare/v1.31.0...v1.32.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.32.0).
### v1.31.0 (2025-12-11)
#### What's Changed
  * Add prompt caching support for AWS Bedrock by [@DenysMoskalenko](https://github.com/DenysMoskalenko) in [#3438](https://github.com/pydantic/pydantic-ai/pull/3438)
  * Add `Agent.output_json_schema()` method by [@g-eoj](https://github.com/g-eoj) in [#3454](https://github.com/pydantic/pydantic-ai/pull/3454)
  * Allow custom `clientInfo` when connecting to MCP servers by [@atinylittleshell](https://github.com/atinylittleshell) in [#3572](https://github.com/pydantic/pydantic-ai/pull/3572)
  * Add `provider_url` to `ModelResponse` and use it in `cost()` by [@mahiro72](https://github.com/mahiro72) in [#3648](https://github.com/pydantic/pydantic-ai/pull/3648)
  * Add GPT-5.2 and bump openai to v2.11.0 by [@DouweM](https://github.com/DouweM) in [#3713](https://github.com/pydantic/pydantic-ai/pull/3713)
  * Allow model to be a string in `LLMJudge` by [@samuelcolvin](https://github.com/samuelcolvin) in [#3711](https://github.com/pydantic/pydantic-ai/pull/3711)
  * Fix `OpenAIResponsesModel` web search `find_in_page` action handling by [@DouweM](https://github.com/DouweM) in [#3709](https://github.com/pydantic/pydantic-ai/pull/3709)


#### New Contributors
  * [@mahiro72](https://github.com/mahiro72) made their first contribution in [#3648](https://github.com/pydantic/pydantic-ai/pull/3648)
  * [@atinylittleshell](https://github.com/atinylittleshell) made their first contribution in [#3572](https://github.com/pydantic/pydantic-ai/pull/3572)


[](https://github.com/pydantic/pydantic-ai/compare/v1.30.0...v1.31.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.31.0).
### v1.30.1 (2025-12-11)
#### What's Changed
  * Restore compatibility with `openai` v1 by [@DouweM](https://github.com/DouweM) in <https://github.com/pydantic/pydantic-ai/issues/3707>
  * Temporarily revert support for OpenAI prompt caching options ([#3678](https://github.com/pydantic/pydantic-ai/pull/3678)) by [@DouweM](https://github.com/DouweM) in <https://github.com/pydantic/pydantic-ai/issues/3707>
    * This feature will return in v1.31.0


[](https://github.com/pydantic/pydantic-ai/compare/v1.30.0...v1.30.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.30.1).
### v1.30.0 (2025-12-10)
#### What's Changed
  * Add prompt caching options to OpenAIChatModelSettings by [@kichanyurd](https://github.com/kichanyurd) in [#3678](https://github.com/pydantic/pydantic-ai/pull/3678)
  * Support multi-modal output in `LLMJudge` by [@Clement-Lelievre](https://github.com/Clement-Lelievre) in [#3696](https://github.com/pydantic/pydantic-ai/pull/3696)
  * Add `CerebrasModel` by [@sebastiand-cerebras](https://github.com/sebastiand-cerebras) in [#3486](https://github.com/pydantic/pydantic-ai/pull/3486)
  * Fix `GraphBuildingError` when using `g.stream` multiple times by [@adtyavrdhn](https://github.com/adtyavrdhn) in [#3695](https://github.com/pydantic/pydantic-ai/pull/3695)
  * Fix `BedrockConverseModel` error when `ModelResponse.parts` is empty by [@ffineis](https://github.com/ffineis) in [#3689](https://github.com/pydantic/pydantic-ai/pull/3689)
  * Pin deno to v2.5.x by [@DouweM](https://github.com/DouweM) in [#3700](https://github.com/pydantic/pydantic-ai/pull/3700)


#### New Contributors
  * [@ffineis](https://github.com/ffineis) made their first contribution in [#3689](https://github.com/pydantic/pydantic-ai/pull/3689)
  * [@sebastiand-cerebras](https://github.com/sebastiand-cerebras) made their first contribution in [#3486](https://github.com/pydantic/pydantic-ai/pull/3486)
  * [@kichanyurd](https://github.com/kichanyurd) made their first contribution in [#3678](https://github.com/pydantic/pydantic-ai/pull/3678)
  * [@Clement-Lelievre](https://github.com/Clement-Lelievre) made their first contribution in [#3696](https://github.com/pydantic/pydantic-ai/pull/3696)


[](https://github.com/pydantic/pydantic-ai/compare/v1.29.0...v1.30.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.30.0).
### v1.29.0 (2025-12-09)
#### What's Changed
  * Add support for aspect ratio in Gemini image generation by [@mwildehahn](https://github.com/mwildehahn) and [@ajac-zero](https://github.com/ajac-zero) in [#3672](https://github.com/pydantic/pydantic-ai/pull/3672)
  * Pass `container_id` back to Anthropic API by [@mattbrandman](https://github.com/mattbrandman) in [#3637](https://github.com/pydantic/pydantic-ai/pull/3637)
  * Upgrade temporalio to 1.20.0 by [@akrivka](https://github.com/akrivka) in [#3679](https://github.com/pydantic/pydantic-ai/pull/3679)
  * Fix error when OpenRouter response includes file annotations by [@dsfaccini](https://github.com/dsfaccini) in [#3671](https://github.com/pydantic/pydantic-ai/pull/3671)
  * Suppress broken resource errors if cancelling by [@dmontagu](https://github.com/dmontagu) in [#3675](https://github.com/pydantic/pydantic-ai/pull/3675)
  * Fix GoogleModel thinking signature not stored on tool calls when streaming by [@jerry-heygen](https://github.com/jerry-heygen) in [#3647](https://github.com/pydantic/pydantic-ai/pull/3647)
  * Don't require `anthropic` dependency when using Anthropic model with other provider by [@dsfaccini](https://github.com/dsfaccini) in [#3652](https://github.com/pydantic/pydantic-ai/pull/3652)


#### New Contributors
  * [@akrivka](https://github.com/akrivka) made their first contribution in [#3679](https://github.com/pydantic/pydantic-ai/pull/3679)


[](https://github.com/pydantic/pydantic-ai/compare/v1.28.0...v1.29.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.29.0).
### v1.28.0 (2025-12-08)
#### What's Changed
  * Adds native structured output support for `claude-haiku-4-5` by [@dsfaccini](https://github.com/dsfaccini) in [#3670](https://github.com/pydantic/pydantic-ai/pull/3670)
  * Support `us-gov.` and other multi-character Bedrock geo prefixes by [@Leundai](https://github.com/Leundai) in [#3645](https://github.com/pydantic/pydantic-ai/pull/3645)
  * Allow missing content in streamed OpenRouter reasoning details by [@ajac-zero](https://github.com/ajac-zero) in [#3674](https://github.com/pydantic/pydantic-ai/pull/3674)
  * Remove typings stubs by [@dsfaccini](https://github.com/dsfaccini) in [#3673](https://github.com/pydantic/pydantic-ai/pull/3673)


#### New Contributors
  * [@Leundai](https://github.com/Leundai) made their first contribution in [#3645](https://github.com/pydantic/pydantic-ai/pull/3645)


[](https://github.com/pydantic/pydantic-ai/compare/v1.27.0...v1.28.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.28.0).
### v1.27.0 (2025-12-04)
#### What's Changed
  * feat: Allow dynamic configuration of built-in tools via RunContext by [@AlanPonnachan](https://github.com/AlanPonnachan) in [#3600](https://github.com/pydantic/pydantic-ai/pull/3600)
  * Support tool and resource caching for MCP servers that support change notifications by [@dsfaccini](https://github.com/dsfaccini) in [#3560](https://github.com/pydantic/pydantic-ai/pull/3560)
  * Support raw CoT reasoning from LM Studio and other OpenAI Responses-compatible APIs by [@dsfaccini](https://github.com/dsfaccini) in [#3559](https://github.com/pydantic/pydantic-ai/pull/3559)
  * Fix structured output with nested definitions with Gemini via OpenRouter by [@dsfaccini](https://github.com/dsfaccini) in [#3618](https://github.com/pydantic/pydantic-ai/pull/3618)
  * fix: Copy `extra_headers` to allow `model_settings` reuse by [@Wh1isper](https://github.com/Wh1isper) in [#3628](https://github.com/pydantic/pydantic-ai/pull/3628)
  * Add `VercelAIAdapter.dump_messages` to convert Pydantic AI messages to Vercel AI messages by [@dsfaccini](https://github.com/dsfaccini) in [#3392](https://github.com/pydantic/pydantic-ai/pull/3392)
  * Disable use of `tool_choice=required` for deepseek-reasoner by [@ZeroAurora](https://github.com/ZeroAurora) in [#3644](https://github.com/pydantic/pydantic-ai/pull/3644)
  * Use custom reasoning field for OpenRouter by [@xcpky](https://github.com/xcpky) in [#3626](https://github.com/pydantic/pydantic-ai/pull/3626)


#### New Contributors
  * [@AlanPonnachan](https://github.com/AlanPonnachan) made their first contribution in [#3600](https://github.com/pydantic/pydantic-ai/pull/3600)


[](https://github.com/pydantic/pydantic-ai/compare/v1.26.0...v1.27.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.27.0).
### v1.26.0 (2025-12-02)
#### What's Changed
  * Support JSON object output for Deepseek provider by [@xcpky](https://github.com/xcpky) in [#3601](https://github.com/pydantic/pydantic-ai/pull/3601)
  * Clarify `FallbackModel` behavior on `ValidationError`s by [@dsfaccini](https://github.com/dsfaccini) in [#3603](https://github.com/pydantic/pydantic-ai/pull/3603)
  * Add latest Grok (xAI) models by [@darjeeling](https://github.com/darjeeling) in [#3613](https://github.com/pydantic/pydantic-ai/pull/3613)
  * Automatically omit TTL from `cache_control` when `AnthropicModel` is used with Bedrock client by [@Wh1isper](https://github.com/Wh1isper) in [#3616](https://github.com/pydantic/pydantic-ai/pull/3616)
  * Add custom reasoning field support to OpenAI model profiles by [@ZeroAurora](https://github.com/ZeroAurora) in [#3536](https://github.com/pydantic/pydantic-ai/pull/3536)
  * Add `gateway/...:...` to Known Model Names by [@dsfaccini](https://github.com/dsfaccini) in [#3593](https://github.com/pydantic/pydantic-ai/pull/3593)


#### New Contributors
  * [@darjeeling](https://github.com/darjeeling) made their first contribution in [#3613](https://github.com/pydantic/pydantic-ai/pull/3613)
  * [@ZeroAurora](https://github.com/ZeroAurora) made their first contribution in [#3536](https://github.com/pydantic/pydantic-ai/pull/3536)


[](https://github.com/pydantic/pydantic-ai/compare/v1.25.1...v1.26.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.26.0).
### v1.25.1 (2025-11-28)
#### What's Changed
  * Make `FastMCPToolset` work with DBOS by [@qianl15](https://github.com/qianl15) in [#3540](https://github.com/pydantic/pydantic-ai/pull/3540)
  * Fix `OpenRouterModel` error when `native_finish_reason` is `None` by [@reuben-if](https://github.com/reuben-if) in [#3584](https://github.com/pydantic/pydantic-ai/pull/3584)
  * Fix error when OpenRouter API returns `None` tool call arguments by [@barp](https://github.com/barp) in [#3571](https://github.com/pydantic/pydantic-ai/pull/3571)


#### New Contributors
  * [@reuben-if](https://github.com/reuben-if) made their first contribution in [#3584](https://github.com/pydantic/pydantic-ai/pull/3584)


[](https://github.com/pydantic/pydantic-ai/compare/v1.25.0...v1.25.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.25.1).
### v1.25.0 (2025-11-27)
#### What's Changed
  * Support `gemini-3-pro-image-preview` with Nano Banana Pro by [@DouweM](https://github.com/DouweM) in [#3576](https://github.com/pydantic/pydantic-ai/pull/3576)
  * Return tool error to Google in 'error' key by [@DouweM](https://github.com/DouweM) in [#3583](https://github.com/pydantic/pydantic-ai/pull/3583)


[](https://github.com/pydantic/pydantic-ai/compare/v1.24.0...v1.25.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.25.0).
### v1.24.0 (2025-11-26)
#### What's Changed
  * Support native JSON output and strict tool calls for Anthropic by [@dsfaccini](https://github.com/dsfaccini) in [#3457](https://github.com/pydantic/pydantic-ai/pull/3457)
  * Support Pydantic validation context by [@NicolasPllr1](https://github.com/NicolasPllr1) in [#3448](https://github.com/pydantic/pydantic-ai/pull/3448)
  * Support logprobs output from Responses API by [@tim-becker](https://github.com/tim-becker) in [#3535](https://github.com/pydantic/pydantic-ai/pull/3535)
  * Support instructions-only agent run with `OpenAIResponsesModel` by [@Cody-learns](https://github.com/Cody-learns) in [#3470](https://github.com/pydantic/pydantic-ai/pull/3470)
  * Enable `PLW1514` rule (use `utf-8` encoding) by [@Danipulok](https://github.com/Danipulok) in [#3524](https://github.com/pydantic/pydantic-ai/pull/3524)
  * Replace direct `_model_name` access with `model_name` property in OpenAI models and streamed responses by [@BBYNAI](https://github.com/BBYNAI) in [#3564](https://github.com/pydantic/pydantic-ai/pull/3564)
  * Update docs on multi-modal file URLs being downloaded or sent directly by [@marmor7](https://github.com/marmor7) in [#3492](https://github.com/pydantic/pydantic-ai/pull/3492)


#### New Contributors
  * [@Danipulok](https://github.com/Danipulok) made their first contribution in [#3524](https://github.com/pydantic/pydantic-ai/pull/3524)
  * [@Cody-learns](https://github.com/Cody-learns) made their first contribution in [#3470](https://github.com/pydantic/pydantic-ai/pull/3470)
  * [@marmor7](https://github.com/marmor7) made their first contribution in [#3492](https://github.com/pydantic/pydantic-ai/pull/3492)
  * [@tim-becker](https://github.com/tim-becker) made their first contribution in [#3535](https://github.com/pydantic/pydantic-ai/pull/3535)


[](https://github.com/pydantic/pydantic-ai/compare/v1.23.0...v1.24.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.24.0).
### v1.23.0 (2025-11-25)
#### What's Changed
  * Add Anthropic built-in `WebFetchTool` support by [@sarth6](https://github.com/sarth6) in [#3427](https://github.com/pydantic/pydantic-ai/pull/3427)
  * Allow `user_prompt` in HITL by [@Wh1isper](https://github.com/Wh1isper) in [#3528](https://github.com/pydantic/pydantic-ai/pull/3528)
  * Add `anthropic_cache_messages` model setting and automatically strip cache points over the limit by [@Wh1isper](https://github.com/Wh1isper) in [#3442](https://github.com/pydantic/pydantic-ai/pull/3442)
  * Add Gemini 3 Pro support to `OpenRouterModel` by [@zeyuyuyu](https://github.com/zeyuyuyu) in [#3548](https://github.com/pydantic/pydantic-ai/pull/3548)
  * Ensure `openrouter_reasoning` model setting is sent to API by [@xcpky](https://github.com/xcpky) in [#3545](https://github.com/pydantic/pydantic-ai/pull/3545)
  * Don't close custom httpx client provided to `MCPServerHTTP` by [@DouweM](https://github.com/DouweM) in [#3534](https://github.com/pydantic/pydantic-ai/pull/3534)
  * Fix double counting of request tokens in evals by [@dmontagu](https://github.com/dmontagu) in [#3553](https://github.com/pydantic/pydantic-ai/pull/3553)
  * Fix `pydantic_graph.beta.GraphRun` `GeneratorExit` handling by [@michgur](https://github.com/michgur) in [#3525](https://github.com/pydantic/pydantic-ai/pull/3525)
  * Add test to ensure we allow message history starting with assistant message (model response) by [@restless](https://github.com/restless) in [#3519](https://github.com/pydantic/pydantic-ai/pull/3519)
  * Remove `README.md` from wheel for `pydantic-ai` by [@johnslavik](https://github.com/johnslavik) in [#3521](https://github.com/pydantic/pydantic-ai/pull/3521)
  * Upgrade `Ruff` to v0.14.6 by [@Viicos](https://github.com/Viicos) in [#3547](https://github.com/pydantic/pydantic-ai/pull/3547)
  * Use `model_name` property in `OpenAIChatModel` chat completion create request by [@BBYNAI](https://github.com/BBYNAI) in [#3543](https://github.com/pydantic/pydantic-ai/pull/3543)
  * Pin `huggingface-hub` to `<1` by [@Kludex](https://github.com/Kludex) in [#3557](https://github.com/pydantic/pydantic-ai/pull/3557)
  * Add docs examples to use the Gateway aside from the `gateway/<provider>:<model>` shorthand by [@dsfaccini](https://github.com/dsfaccini) in [#3484](https://github.com/pydantic/pydantic-ai/pull/3484)


#### New Contributors
  * [@restless](https://github.com/restless) made their first contribution in [#3519](https://github.com/pydantic/pydantic-ai/pull/3519)
  * [@johnslavik](https://github.com/johnslavik) made their first contribution in [#3521](https://github.com/pydantic/pydantic-ai/pull/3521)
  * [@michgur](https://github.com/michgur) made their first contribution in [#3525](https://github.com/pydantic/pydantic-ai/pull/3525)
  * [@zeyuyuyu](https://github.com/zeyuyuyu) made their first contribution in [#3548](https://github.com/pydantic/pydantic-ai/pull/3548)
  * [@BBYNAI](https://github.com/BBYNAI) made their first contribution in [#3543](https://github.com/pydantic/pydantic-ai/pull/3543)
  * [@sarth6](https://github.com/sarth6) made their first contribution in [#3427](https://github.com/pydantic/pydantic-ai/pull/3427)


[](https://github.com/pydantic/pydantic-ai/compare/v1.22.0...v1.23.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.23.0).
### v1.22.0 (2025-11-21)
#### What's Changed
  * Add OpenRouterModel as OpenAIChatModel subclass with additional feature support by [@ajac-zero](https://github.com/ajac-zero) in [#3089](https://github.com/pydantic/pydantic-ai/pull/3089)
  * Make `FallbackModel` fall back on all model API errors, not just HTTP status 400+ by [@dsfaccini](https://github.com/dsfaccini) in [#3494](https://github.com/pydantic/pydantic-ai/pull/3494)
  * Don't skip model request when history ends on response but there are new instructions by [@DouweM](https://github.com/DouweM) in [#3509](https://github.com/pydantic/pydantic-ai/pull/3509)
  * Revert "feat: enforce message history starts with user message" by [@DouweM](https://github.com/DouweM) in [#3508](https://github.com/pydantic/pydantic-ai/pull/3508)
  * Don't send Google messages with 0 parts by [@DouweM](https://github.com/DouweM) in [#3511](https://github.com/pydantic/pydantic-ai/pull/3511)
  * Immediately raise error when response is empty because of token limit by [@DouweM](https://github.com/DouweM) in [#3512](https://github.com/pydantic/pydantic-ai/pull/3512)
  * Relax UserError into a warning when state deps is not provided with AG-UI by [@MikeRyanDev](https://github.com/MikeRyanDev) in [#3510](https://github.com/pydantic/pydantic-ai/pull/3510)
  * Add type stubs for some third-party libraries by [@lars20070](https://github.com/lars20070) in [#3443](https://github.com/pydantic/pydantic-ai/pull/3443)
  * Add document to allowed `cacheable_types` for anthropic by [@marpulli](https://github.com/marpulli) in [#3513](https://github.com/pydantic/pydantic-ai/pull/3513)
  * Don't insert empty `ThinkingPart` when `Google` response ends in text with `thought_signature` by [@DouweM](https://github.com/DouweM) in [#3516](https://github.com/pydantic/pydantic-ai/pull/3516)
  * Fix deprecated `GeminiModel` structured output and tool call thought signatures by [@DouweM](https://github.com/DouweM) in [#3517](https://github.com/pydantic/pydantic-ai/pull/3517)


#### New Contributors
  * [@marpulli](https://github.com/marpulli) made their first contribution in [#3513](https://github.com/pydantic/pydantic-ai/pull/3513)


[](https://github.com/pydantic/pydantic-ai/compare/v1.21.0...v1.22.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.22.0).
### v1.21.0 (2025-11-20)
#### What's Changed
  * Feature: MCP client Resources support by [@fennb](https://github.com/fennb) in [#3024](https://github.com/pydantic/pydantic-ai/pull/3024)
  * Expose MCP server instructions in `MCPServer.instructions` property by [@mochow13](https://github.com/mochow13) in [#3431](https://github.com/pydantic/pydantic-ai/pull/3431)
  * Add `BinaryContent.from_path` convenience method by [@dsfaccini](https://github.com/dsfaccini) in [#3482](https://github.com/pydantic/pydantic-ai/pull/3482)
  * Enforce message history starts with user message by [@Pavanmanikanta98](https://github.com/Pavanmanikanta98) in [#3440](https://github.com/pydantic/pydantic-ai/pull/3440)
  * Always strip Markdown fences from structured output by [@DouweM](https://github.com/DouweM) in [#3475](https://github.com/pydantic/pydantic-ai/pull/3475)
  * Fix Gemini nested tool argument schemas by removing `title` from `$defs` by [@conradlee](https://github.com/conradlee) in [#3487](https://github.com/pydantic/pydantic-ai/pull/3487)
  * Fix issue with Gemini and Prefect by removing unused `GoogleModel._url` by [@DouweM](https://github.com/DouweM) in [#3499](https://github.com/pydantic/pydantic-ai/pull/3499)


#### New Contributors
  * [@Pavanmanikanta98](https://github.com/Pavanmanikanta98) made their first contribution in [#3440](https://github.com/pydantic/pydantic-ai/pull/3440)
  * [@fennb](https://github.com/fennb) made their first contribution in [#3024](https://github.com/pydantic/pydantic-ai/pull/3024)


[](https://github.com/pydantic/pydantic-ai/compare/v1.20.0...v1.21.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.21.0).
### v1.20.0 (2025-11-18)
#### What's Changed
  * Add support for Gemini 3 Pro by [@DouweM](https://github.com/DouweM) in [#3464](https://github.com/pydantic/pydantic-ai/pull/3464)
  * Support Gemini enhanced JSON Schema features by [@conradlee](https://github.com/conradlee) in [#3357](https://github.com/pydantic/pydantic-ai/pull/3357)
  * Wrap `GoogleModel` `google.genai.errors.APIError` in `ModelHTTPError` so it works with `FallbackModel` by [@timothy-jeong](https://github.com/timothy-jeong) in [#3139](https://github.com/pydantic/pydantic-ai/pull/3139)
  * fix: Change handling of empty state objects for AG-UI by [@MikeRyanDev](https://github.com/MikeRyanDev) in [#3462](https://github.com/pydantic/pydantic-ai/pull/3462)
  * Adds `{ModelRequest,ModelResponse}.metadata` fields by [@adtyavrdhn](https://github.com/adtyavrdhn) in [#3422](https://github.com/pydantic/pydantic-ai/pull/3422)
  * Make `RunContext.usage` available with Temporal by [@mattbrandman](https://github.com/mattbrandman) in [#3434](https://github.com/pydantic/pydantic-ai/pull/3434)
  * Add `ttl` to `CachePoint` and Anthropic caching model settings by [@Wh1isper](https://github.com/Wh1isper) in [#3450](https://github.com/pydantic/pydantic-ai/pull/3450)
  * Extract google model usage using genai-prices by [@alexmojaki](https://github.com/alexmojaki) in [#3466](https://github.com/pydantic/pydantic-ai/pull/3466)
  * Update has_content method to check content data by [@dsfaccini](https://github.com/dsfaccini) in [#3436](https://github.com/pydantic/pydantic-ai/pull/3436)


#### New Contributors
  * [@conradlee](https://github.com/conradlee) made their first contribution in [#3357](https://github.com/pydantic/pydantic-ai/pull/3357)
  * [@MikeRyanDev](https://github.com/MikeRyanDev) made their first contribution in [#3462](https://github.com/pydantic/pydantic-ai/pull/3462)
  * [@timothy-jeong](https://github.com/timothy-jeong) made their first contribution in [#3139](https://github.com/pydantic/pydantic-ai/pull/3139)


[](https://github.com/pydantic/pydantic-ai/compare/v1.19.0...v1.20.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.20.0).
### v1.19.0 (2025-11-17)
#### What's Changed
  * Let `metadata` be passed to `CallDeferred` and `ApprovalRequired` exceptions and end up on `DeferredToolRequests` by [@cjohnhanson](https://github.com/cjohnhanson) in [#3345](https://github.com/pydantic/pydantic-ai/pull/3345)
  * Add AnthropicModel `count_tokens` and support `UsageLimits.count_tokens_before_request` by [@nathan-gage](https://github.com/nathan-gage) in [#3458](https://github.com/pydantic/pydantic-ai/pull/3458)
  * Fix bug with running graphs in temporal workflows by [@dmontagu](https://github.com/dmontagu) in [#3460](https://github.com/pydantic/pydantic-ai/pull/3460)
  * Fix Gateway with Temporal by adding sniffio to sandbox passthrough modules by [@DouweM](https://github.com/DouweM) in [#3455](https://github.com/pydantic/pydantic-ai/pull/3455)
  * Fix Gateway links in code blocks by [@NicolasPllr1](https://github.com/NicolasPllr1) in [#3444](https://github.com/pydantic/pydantic-ai/pull/3444)


#### New Contributors
  * [@NicolasPllr1](https://github.com/NicolasPllr1) made their first contribution in [#3444](https://github.com/pydantic/pydantic-ai/pull/3444)


[](https://github.com/pydantic/pydantic-ai/compare/v1.18.0...v1.19.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.19.0).
### v1.18.0 (2025-11-14)
#### What's Changed
  * Add Anthropic prompt caching support by [@ronakrm](https://github.com/ronakrm) in [#3363](https://github.com/pydantic/pydantic-ai/pull/3363)
  * Bump `openai` to v2.8.0 (v1 still supported), add GPT-5.1 to known model names by [@DouweM](https://github.com/DouweM) in [#3419](https://github.com/pydantic/pydantic-ai/pull/3419)
  * Bump `google-genai` to v1.50.1 and remove patches by [@DouweM](https://github.com/DouweM) in [#3340](https://github.com/pydantic/pydantic-ai/pull/3340)
  * Bump `temporalio` to v1.19.0 and use `SimplePlugin` by [@DouweM](https://github.com/DouweM) in [#3214](https://github.com/pydantic/pydantic-ai/pull/3214)


#### New Contributors
  * [@notrudyyy](https://github.com/notrudyyy) made their first contribution in [#3421](https://github.com/pydantic/pydantic-ai/pull/3421)
  * [@ronakrm](https://github.com/ronakrm) made their first contribution in [#3363](https://github.com/pydantic/pydantic-ai/pull/3363)


[](https://github.com/pydantic/pydantic-ai/compare/v1.17.0...v1.18.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.18.0).
### v1.17.0 (2025-11-13)
#### What's Changed
  * Add [Pydantic AI Gateway](https://ai.pydantic.dev/gateway) docs by [@laisbsc](https://github.com/laisbsc) in [#3402](https://github.com/pydantic/pydantic-ai/pull/3402)
  * Make `FastMCPToolset` work with `Temporal` by [@DouweM](https://github.com/DouweM) in [#3413](https://github.com/pydantic/pydantic-ai/pull/3413)
  * Support `mcp.json` environment variable expansion in `load_mcp_servers()` by [@wgillett](https://github.com/wgillett) in [#3380](https://github.com/pydantic/pydantic-ai/pull/3380)


#### New Contributors
  * [@laisbsc](https://github.com/laisbsc) made their first contribution in [#3402](https://github.com/pydantic/pydantic-ai/pull/3402)
  * [@wgillett](https://github.com/wgillett) made their first contribution in [#3380](https://github.com/pydantic/pydantic-ai/pull/3380)


[](https://github.com/pydantic/pydantic-ai/compare/v1.16.0...v1.17.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.17.0).
### v1.16.0 (2025-11-13)
#### What's Changed
  * refactor(gateway): add `upstream_provider` back by [@Kludex](https://github.com/Kludex) in [#3391](https://github.com/pydantic/pydantic-ai/pull/3391)


[](https://github.com/pydantic/pydantic-ai/compare/v1.15.0...v1.16.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.16.0).
### v1.15.0 (2025-11-12)
#### What's Changed
  * Wrap `BedrockConverseModel` errors in `ModelHTTPError` to work well with `FallbackModel` by [@cjermain](https://github.com/cjermain) in [#3377](https://github.com/pydantic/pydantic-ai/pull/3377)
  * Add unique `run_id` to run, run result, and message (request, response) classes by [@adtyavrdhn](https://github.com/adtyavrdhn) in [#3366](https://github.com/pydantic/pydantic-ai/pull/3366)
  * Add `BedrockConverseModel.count_tokens` so it works with `UsageLimits.count_tokens_before_request` by [@DenysMoskalenko](https://github.com/DenysMoskalenko) in [#3367](https://github.com/pydantic/pydantic-ai/pull/3367)


[](https://github.com/pydantic/pydantic-ai/compare/v1.14.1...v1.15.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.15.0).
### v1.14.1 (2025-11-11)
#### What's Changed
  * Fix Vercel AI tool input/output always showing up as a JSON string rather than object by [@DouweM](https://github.com/DouweM) in [#3399](https://github.com/pydantic/pydantic-ai/pull/3399)
  * Make `ModelRetry` hashable by [@nathan-gage](https://github.com/nathan-gage) in [#3394](https://github.com/pydantic/pydantic-ai/pull/3394)
  * Don't run CI steps that require secrets on PRs from fork branch to fork `main` by [@lars20070](https://github.com/lars20070) in [#3385](https://github.com/pydantic/pydantic-ai/pull/3385)


#### New Contributors
  * [@lars20070](https://github.com/lars20070) made their first contribution in [#3385](https://github.com/pydantic/pydantic-ai/pull/3385)
  * [@nathan-gage](https://github.com/nathan-gage) made their first contribution in [#3394](https://github.com/pydantic/pydantic-ai/pull/3394)


[](https://github.com/pydantic/pydantic-ai/compare/v1.14.0...v1.15.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.14.1).
### v1.14.0 (2025-11-10)
#### What's Changed
  * Allow custom provider factory to be passed into `infer_model` by [@slkoo-cc](https://github.com/slkoo-cc) in [#3341](https://github.com/pydantic/pydantic-ai/pull/3341)
  * Fix error when Google returns only empty text parts by [@naveen-corpusant](https://github.com/naveen-corpusant) in [#3388](https://github.com/pydantic/pydantic-ai/pull/3388)
  * Docs: AWS Bedrock retry behavior by [@cjermain](https://github.com/cjermain) in [#3379](https://github.com/pydantic/pydantic-ai/pull/3379)
  * docs: fix link to AG-UI Dojo by [@echarles](https://github.com/echarles) in [#3387](https://github.com/pydantic/pydantic-ai/pull/3387)


#### New Contributors
  * [@cjermain](https://github.com/cjermain) made their first contribution in [#3379](https://github.com/pydantic/pydantic-ai/pull/3379)
  * [@echarles](https://github.com/echarles) made their first contribution in [#3387](https://github.com/pydantic/pydantic-ai/pull/3387)


[](https://github.com/pydantic/pydantic-ai/compare/v1.13.0...v1.13.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.14.0).
### v1.13.0 (2025-11-10)
#### What's Changed
  * Ignore empty text parts in `GoogleModel` by [@naveen-corpusant](https://github.com/naveen-corpusant) in [#3360](https://github.com/pydantic/pydantic-ai/pull/3360)
  * Add `AgentRun.{all,new}_messages{_json}` by [@tibbe](https://github.com/tibbe) in [#3354](https://github.com/pydantic/pydantic-ai/pull/3354)
  * Update known models on Cerebras and Heroku by [@Kludex](https://github.com/Kludex) in [#3375](https://github.com/pydantic/pydantic-ai/pull/3375)
  * feat(gateway): support `api_type` by [@Kludex](https://github.com/Kludex) in [#3362](https://github.com/pydantic/pydantic-ai/pull/3362)
  * feat(gateway): support `profile` and `routing_group` by [@Kludex](https://github.com/Kludex) in [#3361](https://github.com/pydantic/pydantic-ai/pull/3361)


#### New Contributors
  * [@tibbe](https://github.com/tibbe) made their first contribution in [#3354](https://github.com/pydantic/pydantic-ai/pull/3354)
  * [@cjohnhanson](https://github.com/cjohnhanson) made their first contribution in [#3371](https://github.com/pydantic/pydantic-ai/pull/3371)


[](https://github.com/pydantic/pydantic-ai/compare/v1.12.0...v1.13.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.13.0).
### v1.12.0 (2025-11-06)
#### What's Changed
  * Fix tool call incorrectly being considered approved when agent run is resumed with history ending in unapproved tool call by [@DouweM](https://github.com/DouweM) in [#3355](https://github.com/pydantic/pydantic-ai/pull/3355)
  * Bump `temporalio` to v1.18.2 as v1.18.0 is broken by [@crossk3](https://github.com/crossk3) in [#3356](https://github.com/pydantic/pydantic-ai/pull/3356)
  * docs: Add Braintrust to integrations by [@choochootrain](https://github.com/choochootrain) in [#3346](https://github.com/pydantic/pydantic-ai/pull/3346)


#### New Contributors
  * [@choochootrain](https://github.com/choochootrain) made their first contribution in [#3346](https://github.com/pydantic/pydantic-ai/pull/3346)
  * [@crossk3](https://github.com/crossk3) made their first contribution in [#3356](https://github.com/pydantic/pydantic-ai/pull/3356)


[](https://github.com/pydantic/pydantic-ai/compare/v1.11.1...v1.12.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.12.0).
### v1.11.1 (2025-11-05)
#### What's Changed
  * `FallbackModel` support for Native output mode and `ModelProfile.default_structured_output_mode` by [@DouweM](https://github.com/DouweM) in [#3303](https://github.com/pydantic/pydantic-ai/pull/3303)
  * Fix task cancellation bug in graph beta API triggered by using `MCPServerStreamableHTTP` with `agent.run_stream` by [@dmontagu](https://github.com/dmontagu) in [#3338](https://github.com/pydantic/pydantic-ai/pull/3338)
  * Fix type annotation for `DuckDuckGoTool` with latest version of `ddgs` package by [@jhammarstedt](https://github.com/jhammarstedt) in [#3330](https://github.com/pydantic/pydantic-ai/pull/3330)
  * Fix typo in docs variable name by [@DenysMoskalenko](https://github.com/DenysMoskalenko) in [#3343](https://github.com/pydantic/pydantic-ai/pull/3343)


#### New Contributors
  * [@jhammarstedt](https://github.com/jhammarstedt) made their first contribution in [#3330](https://github.com/pydantic/pydantic-ai/pull/3330)


[](https://github.com/pydantic/pydantic-ai/compare/v1.11.0...v1.11.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.11.1).
### v1.11.0 (2025-11-04)
#### What's Changed
  * Improve validation error retry message by [@dmontagu](https://github.com/dmontagu) in [#3193](https://github.com/pydantic/pydantic-ai/pull/3193)
  * OpenAI gpt-5-chat does not support (encrypted) reasoning by [@DouweM](https://github.com/DouweM) in [#3332](https://github.com/pydantic/pydantic-ai/pull/3332)
  * Complete thinking.md documentation with AWS Bedrock examples by [@daniilr](https://github.com/daniilr) in [#3328](https://github.com/pydantic/pydantic-ai/pull/3328)
  * Fix graph execution bug with multiple joins downstream of same fork by [@dmontagu](https://github.com/dmontagu) in [#3337](https://github.com/pydantic/pydantic-ai/pull/3337)
  * Skip installing outlines dependencies mlx, vllm, torch on Intel Macs by [@pcustic](https://github.com/pcustic) in [#3312](https://github.com/pydantic/pydantic-ai/pull/3312)
  * Let additional `instructions` be provided at `agent.run` time. by [@baek54321](https://github.com/baek54321) in [#3309](https://github.com/pydantic/pydantic-ai/pull/3309)
  * Add `partial_output` to `RunContext` provided to output validators by [@petersli](https://github.com/petersli) in [#3286](https://github.com/pydantic/pydantic-ai/pull/3286)


#### New Contributors
  * [@daniilr](https://github.com/daniilr) made their first contribution in [#3328](https://github.com/pydantic/pydantic-ai/pull/3328)
  * [@pcustic](https://github.com/pcustic) made their first contribution in [#3312](https://github.com/pydantic/pydantic-ai/pull/3312)
  * [@baek54321](https://github.com/baek54321) made their first contribution in [#3309](https://github.com/pydantic/pydantic-ai/pull/3309)
  * [@petersli](https://github.com/petersli) made their first contribution in [#3286](https://github.com/pydantic/pydantic-ai/pull/3286)


[](https://github.com/pydantic/pydantic-ai/compare/v1.10.0...v1.11.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.11.0).
### v1.10.0 (2025-11-03)
#### What's Changed
  * Fix `MCPServer` error handling with Temporal by [@wreed4](https://github.com/wreed4) in [#3299](https://github.com/pydantic/pydantic-ai/pull/3299)
  * Update directory path in ag-ui.md example by [@sabman](https://github.com/sabman) in [#3310](https://github.com/pydantic/pydantic-ai/pull/3310)
  * Implement `OpenAIResponsesModel.base_url` property by [@chasefarmer-pixee](https://github.com/chasefarmer-pixee) in [#3281](https://github.com/pydantic/pydantic-ai/pull/3281)
  * Fix types to let `OpenRouterProvider` be created with only `http_client` by [@xcpky](https://github.com/xcpky) in [#3308](https://github.com/pydantic/pydantic-ai/pull/3308)
  * Add `Agent.run_stream_sync` method and sync convenience methods on `StreamedRunResult` by [@ajac-zero](https://github.com/ajac-zero) in [#3146](https://github.com/pydantic/pydantic-ai/pull/3146)
  * Fix typevar variance for agent deps by [@dmontagu](https://github.com/dmontagu) in [#3319](https://github.com/pydantic/pydantic-ai/pull/3319)
  * Add support for detecting and handling `application/msword` files. by [@DenysMoskalenko](https://github.com/DenysMoskalenko) in [#3318](https://github.com/pydantic/pydantic-ai/pull/3318)
  * Ensure AG-UI `ToolCallStartEvent` doesn't use a `parent_message_id` from a previous request/response by [@DouweM](https://github.com/DouweM) in [#3325](https://github.com/pydantic/pydantic-ai/pull/3325)


#### New Contributors
  * [@wreed4](https://github.com/wreed4) made their first contribution in [#3299](https://github.com/pydantic/pydantic-ai/pull/3299)
  * [@sabman](https://github.com/sabman) made their first contribution in [#3310](https://github.com/pydantic/pydantic-ai/pull/3310)
  * [@chasefarmer-pixee](https://github.com/chasefarmer-pixee) made their first contribution in [#3281](https://github.com/pydantic/pydantic-ai/pull/3281)
  * [@xcpky](https://github.com/xcpky) made their first contribution in [#3308](https://github.com/pydantic/pydantic-ai/pull/3308)
  * [@ajac-zero](https://github.com/ajac-zero) made their first contribution in [#3146](https://github.com/pydantic/pydantic-ai/pull/3146)
  * [@DenysMoskalenko](https://github.com/DenysMoskalenko) made their first contribution in [#3318](https://github.com/pydantic/pydantic-ai/pull/3318)


[](https://github.com/pydantic/pydantic-ai/compare/v1.9.1...v1.10.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.10.0).
### v1.9.1 (2025-10-30)
#### What's Changed
  * Support AsyncAnthropicVertex as AnthropicProvider.anthropic_client by [@DouweM](https://github.com/DouweM) in [#3292](https://github.com/pydantic/pydantic-ai/pull/3292)
  * Set AG-UI frontend state directly on provided `deps` so it can be read from `on_complete` handler by [@DouweM](https://github.com/DouweM) in [#3297](https://github.com/pydantic/pydantic-ai/pull/3297)
  * Retry instead of error when Google response is empty with `MALFORMED_FUNCTION_CALL` or other recoverable finish reason by [@ArneZsng](https://github.com/ArneZsng) in [#3300](https://github.com/pydantic/pydantic-ai/pull/3300)
  * Add Version Policy to docs by [@DouweM](https://github.com/DouweM) in [#3301](https://github.com/pydantic/pydantic-ai/pull/3301)


[](https://github.com/pydantic/pydantic-ai/compare/v1.9.0...v1.9.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.9.1).
### v1.9.0 (2025-10-29)
#### What's Changed
  * Support Vercel AI Data Stream Protocol by [@samuelcolvin](https://github.com/samuelcolvin) in [#2923](https://github.com/pydantic/pydantic-ai/pull/2923)
  * Fix docs custom retry logic example by [@yf-yang](https://github.com/yf-yang) in [#3276](https://github.com/pydantic/pydantic-ai/pull/3276)


#### New Contributors
  * [@yf-yang](https://github.com/yf-yang) made their first contribution in [#3276](https://github.com/pydantic/pydantic-ai/pull/3276)


[](https://github.com/pydantic/pydantic-ai/compare/v1.8.0...v1.9.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.9.0).
### v1.8.0 (2025-10-29)
#### What's Changed
  * Add experiment metadata by [@dmontagu](https://github.com/dmontagu) in [#3263](https://github.com/pydantic/pydantic-ai/pull/3263)
  * Respect `openai_supports_tool_choice_required` model profile setting in `OpenAIResponsesModel` by [@pamelafox](https://github.com/pamelafox) in [#3272](https://github.com/pydantic/pydantic-ai/pull/3272)
  * Use latest OpenAI, Google, Anthropic models in all examples by [@DouweM](https://github.com/DouweM) in [#3278](https://github.com/pydantic/pydantic-ai/pull/3278)
  * Fix agent name inference when using `run_stream_events` by [@DouweM](https://github.com/DouweM) in [#3279](https://github.com/pydantic/pydantic-ai/pull/3279)


#### New Contributors
  * [@pamelafox](https://github.com/pamelafox) made their first contribution in [#3272](https://github.com/pydantic/pydantic-ai/pull/3272)


[](https://github.com/pydantic/pydantic-ai/compare/v1.7.0...v1.8.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.8.0).
### v1.7.0 (2025-10-27)
#### What's Changed
  * Add `OutlinesModel` to run local models using Transformers, Llama.cpp, MLXLM, SGLang and vLLM via Outlines by [@RobinPicard](https://github.com/RobinPicard) in [#2623](https://github.com/pydantic/pydantic-ai/pull/2623)
  * Fix pydantic-graph importing pydantic-ai by [@dmontagu](https://github.com/dmontagu) in [#3265](https://github.com/pydantic/pydantic-ai/pull/3265)


#### New Contributors
  * [@RobinPicard](https://github.com/RobinPicard) made their first contribution in [#2623](https://github.com/pydantic/pydantic-ai/pull/2623)


[](https://github.com/pydantic/pydantic-ai/compare/v1.6.0...v1.7.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.7.0).
### v1.6.0 (2025-10-24)
#### What's Changed
  * Add `FastMCPToolset` by [@strawgate](https://github.com/strawgate) in [#2784](https://github.com/pydantic/pydantic-ai/pull/2784)
  * Add `OpenAIModelProfile.openai_responses_requires_function_call_status_none` flag to satisfy vLLM Responses API by [@DouweM](https://github.com/DouweM) in [#3246](https://github.com/pydantic/pydantic-ai/pull/3246)
  * Sanitize auto-generated output tool name to support generic types by [@lionpeloux](https://github.com/lionpeloux) in [#2979](https://github.com/pydantic/pydantic-ai/pull/2979)
  * Ensure `ToolCallPart.args` resulting from `TestModel(custom_output_args=...)` is always a `dict` by [@DouweM](https://github.com/DouweM) in [#3254](https://github.com/pydantic/pydantic-ai/pull/3254)


[](https://github.com/pydantic/pydantic-ai/compare/v1.5.0...v1.6.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.6.0).
### v1.5.0 (2025-10-24)
#### What's Changed
  * Introduce new graph API in beta by [@dmontagu](https://github.com/dmontagu) in [#2982](https://github.com/pydantic/pydantic-ai/pull/2982)
  * Preformat run graph/node span names for other OTel backends by [@alexmojaki](https://github.com/alexmojaki) in [#3244](https://github.com/pydantic/pydantic-ai/pull/3244)
  * Ensure that google-genai doesn't close httpx client provided by Pydantic AI or user by [@DouweM](https://github.com/DouweM) in [#3243](https://github.com/pydantic/pydantic-ai/pull/3243)


[](https://github.com/pydantic/pydantic-ai/compare/v1.4.0...v1.5.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.5.0).
### v1.4.0 (2025-10-23)
#### What's Changed
  * Support OpenAI and Anthropic native MCP support via `MCPServerTool` builtin tool by [@Artui](https://github.com/Artui) in [#3101](https://github.com/pydantic/pydantic-ai/pull/3101), [#3239](https://github.com/pydantic/pydantic-ai/pull/3239)
  * Use correct agent's instructions when telling model to retry output by [@dsfaccini](https://github.com/dsfaccini) in [#3209](https://github.com/pydantic/pydantic-ai/pull/3209)
  * Raise clear error when any Google content filter is hit resulting in empty response by [@DouweM](https://github.com/DouweM) in [#3236](https://github.com/pydantic/pydantic-ai/pull/3236)
  * Expand docs for pydantic-evals by [@dmontagu](https://github.com/dmontagu) in [#3213](https://github.com/pydantic/pydantic-ai/pull/3213)


#### New Contributors
  * [@Artui](https://github.com/Artui) made their first contribution in [#3101](https://github.com/pydantic/pydantic-ai/pull/3101)


[](https://github.com/pydantic/pydantic-ai/compare/v1.3.0...v1.4.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.4.0).
### v1.3.0 (2025-10-22)
#### What's Changed
  * Raise `IncompleteToolCall` when token limit is reached during generation of tool call by [@erhuve](https://github.com/erhuve) in [#3137](https://github.com/pydantic/pydantic-ai/pull/3137)
  * Include evals report averages in span attributes by [@cetra3](https://github.com/cetra3) in [#3053](https://github.com/pydantic/pydantic-ai/pull/3053)
  * Make `AbstractBuiltinTool` serializable and work with durable execution by [@DouweM](https://github.com/DouweM) in [#3176](https://github.com/pydantic/pydantic-ai/pull/3176)
  * Ignore empty text deltas when streaming gpt-oss on Bedrock by [@DouweM](https://github.com/DouweM) in [#3215](https://github.com/pydantic/pydantic-ai/pull/3215)
  * Ignore empty text deltas when streaming gpt-oss via Ollama by [@DouweM](https://github.com/DouweM) in [#3216](https://github.com/pydantic/pydantic-ai/pull/3216)
  * docs: Replace deprecated Cohere model 'command' with 'command-r7b-12-… by [@sijanonly](https://github.com/sijanonly) in [#3201](https://github.com/pydantic/pydantic-ai/pull/3201)
  * Include all usage fields in OTel attributes by [@DouweM](https://github.com/DouweM) in [#3221](https://github.com/pydantic/pydantic-ai/pull/3221)
  * Correct Prefect `.serve` example by [@desertaxle](https://github.com/desertaxle) in [#3192](https://github.com/pydantic/pydantic-ai/pull/3192)
  * Ensure toolset spans (e.g. MCP sampling) are nested under agent run span by [@DouweM](https://github.com/DouweM) in [#3224](https://github.com/pydantic/pydantic-ai/pull/3224)
  * Update genai-prices, fix default `api_flavor`, fixes anthropic usage extraction by [@alexmojaki](https://github.com/alexmojaki) in [#3226](https://github.com/pydantic/pydantic-ai/pull/3226)
  * feat(gateway): support AWS Bedrock by [@Kludex](https://github.com/Kludex) in [#3203](https://github.com/pydantic/pydantic-ai/pull/3203)
  * Add OVHcloud AI Endpoints provider by [@eliasto](https://github.com/eliasto) in [#3188](https://github.com/pydantic/pydantic-ai/pull/3188)
  * Use `gateway/<upstream_provider>:` as provider name prefix for Gateway by [@DouweM](https://github.com/DouweM) in [#3229](https://github.com/pydantic/pydantic-ai/pull/3229)
  * Add `http_client` option to `GoogleProvider`, support `api_key` for Vertex AI, and use Pydantic AI's cached httpx client by default by [@DouweM](https://github.com/DouweM) in [#3217](https://github.com/pydantic/pydantic-ai/pull/3217)


#### New Contributors
  * [@erhuve](https://github.com/erhuve) made their first contribution in [#3137](https://github.com/pydantic/pydantic-ai/pull/3137)
  * [@cetra3](https://github.com/cetra3) made their first contribution in [#3053](https://github.com/pydantic/pydantic-ai/pull/3053)
  * [@sijanonly](https://github.com/sijanonly) made their first contribution in [#3201](https://github.com/pydantic/pydantic-ai/pull/3201)
  * [@eliasto](https://github.com/eliasto) made their first contribution in [#3188](https://github.com/pydantic/pydantic-ai/pull/3188)


[](https://github.com/pydantic/pydantic-ai/compare/v1.2.0...v1.3.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.3.0).
### v1.2.0 (2025-10-20)
#### What's Changed
  * Strip markdown fences when generating evals datasets by [@jlegewie](https://github.com/jlegewie) in [#3141](https://github.com/pydantic/pydantic-ai/pull/3141)
  * Include `final_result` agent span attribute after streaming by [@DouweM](https://github.com/DouweM) in [#3170](https://github.com/pydantic/pydantic-ai/pull/3170)
  * Add Claude Haiku 4.5 model by [@rian-dolphin](https://github.com/rian-dolphin) in [#3183](https://github.com/pydantic/pydantic-ai/pull/3183)
  * change paig base url by [@samuelcolvin](https://github.com/samuelcolvin) in [#3200](https://github.com/pydantic/pydantic-ai/pull/3200)
  * Extract openai usage using genai-prices by [@alexmojaki](https://github.com/alexmojaki) in [#3123](https://github.com/pydantic/pydantic-ai/pull/3123)


#### New Contributors
  * [@jlegewie](https://github.com/jlegewie) made their first contribution in [#3141](https://github.com/pydantic/pydantic-ai/pull/3141)
  * [@rian-dolphin](https://github.com/rian-dolphin) made their first contribution in [#3183](https://github.com/pydantic/pydantic-ai/pull/3183)


[](https://github.com/pydantic/pydantic-ai/compare/v1.1.0...v1.2.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.2.0).
### v1.1.0 (2025-10-15)
#### Features in v1.1.0
  * Add support for durable execution with Prefect by [@desertaxle](https://github.com/desertaxle) in [#3074](https://github.com/pydantic/pydantic-ai/pull/3074), [#3156](https://github.com/pydantic/pydantic-ai/pull/3156)


#### Selected Features since v1.0.0
  * Support image generation and output with Google and OpenAI by [@DouweM](https://github.com/DouweM) in [#2970](https://github.com/pydantic/pydantic-ai/pull/2970)
  * Add Pydantic AI Gateway provider by [@Kludex](https://github.com/Kludex) in [#2816](https://github.com/pydantic/pydantic-ai/pull/2816), [#2863](https://github.com/pydantic/pydantic-ai/pull/2863)
  * Add support for `previous_response_id` from OpenAI Responses API by [@GDaamn](https://github.com/GDaamn) in [#2756](https://github.com/pydantic/pydantic-ai/pull/2756)
  * Add support for durable execution with DBOS by [@qianl15](https://github.com/qianl15) in [#2638](https://github.com/pydantic/pydantic-ai/pull/2638)
  * Built-in tool call streaming from OpenAI, Google, Anthropic by [@DouweM](https://github.com/DouweM) in [#2877](https://github.com/pydantic/pydantic-ai/pull/2877)
  * Support Anthropic built-in memory tool by [@DouweM](https://github.com/DouweM) in [#3042](https://github.com/pydantic/pydantic-ai/pull/3042)
  * Support text, JSON, XML and YAML `DocumentUrl` and `BinaryContent` on OpenAI by [@pulphix](https://github.com/pulphix) in [#2851](https://github.com/pydantic/pydantic-ai/pull/2851)
  * Added MCP metadata and annotations to `ToolDefinition.metadata` for use in filtering by [@ChuckJonas](https://github.com/ChuckJonas) in [#2880](https://github.com/pydantic/pydantic-ai/pull/2880)
  * Let agent `name` be overridden contextually by [@MinuraPunchihewa](https://github.com/MinuraPunchihewa) in [#3094](https://github.com/pydantic/pydantic-ai/pull/3094)
  * Support contextually overriding agent `instructions` by [@mwildehahn](https://github.com/mwildehahn) in [#2926](https://github.com/pydantic/pydantic-ai/pull/2926)
  * Tools can now return AG-UI events separate from result sent to model by [@DouweM](https://github.com/DouweM) in [#2922](https://github.com/pydantic/pydantic-ai/pull/2922)
  * Add `AgentRunResult.response` convenience method to get latest model response by [@DouweM](https://github.com/DouweM) in [#2970](https://github.com/pydantic/pydantic-ai/pull/2970)
  * Add `ModelResponse.text`, `thinking`, `files`, `images`, `tool_calls`, and `builtin_tool_calls` convenience methods by [@DouweM](https://github.com/DouweM) in [#2970](https://github.com/pydantic/pydantic-ai/pull/2970)
  * Add `Agent.run_stream_events()` convenience method wrapping `run(event_stream_handler=...)` by [@DouweM](https://github.com/DouweM) in [#3084](https://github.com/pydantic/pydantic-ai/pull/3084)


#### Other Changes in v1.1.0
  * Record instructions on the agent run span even when they are dynamic by [@dmontagu](https://github.com/dmontagu) in [#3131](https://github.com/pydantic/pydantic-ai/pull/3131)
  * Add `description` arg to tool function decorators by [@zhcn000000](https://github.com/zhcn000000) in [#3153](https://github.com/pydantic/pydantic-ai/pull/3153)
  * fix(gateway): update base_url by [@Kludex](https://github.com/Kludex) in [#3164](https://github.com/pydantic/pydantic-ai/pull/3164)
  * Document OpenAI-compatible provider prefixes by [@DouweM](https://github.com/DouweM) in [#3169](https://github.com/pydantic/pydantic-ai/pull/3169)
  * Explicitly request image response modality from Google API when model supports it by [@DouweM](https://github.com/DouweM) in [#3172](https://github.com/pydantic/pydantic-ai/pull/3172)


#### New Contributors
  * [@zhcn000000](https://github.com/zhcn000000) made their first contribution in [#3153](https://github.com/pydantic/pydantic-ai/pull/3153)
  * [@certainly-param](https://github.com/certainly-param) made their first contribution in [#3133](https://github.com/pydantic/pydantic-ai/pull/3133)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.18...v1.1.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.1.0).
### v1.0.18 (2025-10-13)
#### What's Changed
  * Add `render` method to `EvaluationReport` class by [@dmontagu](https://github.com/dmontagu) in [#3116](https://github.com/pydantic/pydantic-ai/pull/3116)
  * Omit `previous_response_id` when unset instead of sending `null` to OpenAI Responses by [@DouweM](https://github.com/DouweM) in [#3134](https://github.com/pydantic/pydantic-ai/pull/3134)
  * Include all API docs in llms.txt by [@DouweM](https://github.com/DouweM) in [#3152](https://github.com/pydantic/pydantic-ai/pull/3152)
  * Add anyio and httpcore to Temporal passthrough modules by [@slumbi](https://github.com/slumbi) in [#3147](https://github.com/pydantic/pydantic-ai/pull/3147)
  * Add Nebius AI Studio provider support by [@antoncp](https://github.com/antoncp) in [#3124](https://github.com/pydantic/pydantic-ai/pull/3124)
  * Add new `ToolCallPart.id` field for OpenAI Responses by [@DouweM](https://github.com/DouweM) in [#3151](https://github.com/pydantic/pydantic-ai/pull/3151)


#### New Contributors
  * [@slumbi](https://github.com/slumbi) made their first contribution in [#3147](https://github.com/pydantic/pydantic-ai/pull/3147)
  * [@antoncp](https://github.com/antoncp) made their first contribution in [#3124](https://github.com/pydantic/pydantic-ai/pull/3124)
  * [@desertaxle](https://github.com/desertaxle) made their first contribution in [#3074](https://github.com/pydantic/pydantic-ai/pull/3074)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.17...v1.0.18).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.18).
### v1.0.17 (2025-10-09)
#### What's Changed
  * Let `builtin_tools` be specified at agent run time by [@safina57](https://github.com/safina57) in [#3009](https://github.com/pydantic/pydantic-ai/pull/3009)
  * Make `BinaryImage` work with inline-snapshot by [@alexmojaki](https://github.com/alexmojaki) in [#3125](https://github.com/pydantic/pydantic-ai/pull/3125)
  * Document `InstrumentationSettings(version=3)` by [@alexmojaki](https://github.com/alexmojaki) in [#3127](https://github.com/pydantic/pydantic-ai/pull/3127)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.16...v1.0.17).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.17).
### v1.0.16 (2025-10-08)
#### What's Changed
  * Add support for datetime.time/timedelta to format_as_xml by [@nurikk](https://github.com/nurikk) in [#3087](https://github.com/pydantic/pydantic-ai/pull/3087)
  * Ensure graph persistence snapshots are not mutated when run is resumed by [@lienminhquang](https://github.com/lienminhquang) in [#3077](https://github.com/pydantic/pydantic-ai/pull/3077)
  * Use `Sequence[ModelMessage]` instead of `list` for method arg types by [@moritzwilksch](https://github.com/moritzwilksch) in [#3040](https://github.com/pydantic/pydantic-ai/pull/3040)
  * Let agent name be overridden contextually by [@MinuraPunchihewa](https://github.com/MinuraPunchihewa) in [#3094](https://github.com/pydantic/pydantic-ai/pull/3094)
  * Respect `FileUrl.force_download` flag in OpenAI Chat and Responses models by [@nicolas-chaulet](https://github.com/nicolas-chaulet) in [#3106](https://github.com/pydantic/pydantic-ai/pull/3106)
  * Ensure `FileUrl` and `BinaryContent` without `identifier` are valid by [@DouweM](https://github.com/DouweM) in [#3110](https://github.com/pydantic/pydantic-ai/pull/3110)
  * Don't include ToolResultPart for external tool call when streaming by [@DouweM](https://github.com/DouweM) in [#3112](https://github.com/pydantic/pydantic-ai/pull/3112)
  * Fix token usage for anthropic streaming by [@alexmojaki](https://github.com/alexmojaki) in [#3111](https://github.com/pydantic/pydantic-ai/pull/3111) and [#3115](https://github.com/pydantic/pydantic-ai/pull/3115)
  * plain text docs, fix redirects and add logfire by [@samuelcolvin](https://github.com/samuelcolvin) in [#3096](https://github.com/pydantic/pydantic-ai/pull/3096)


#### New Contributors
  * [@nurikk](https://github.com/nurikk) made their first contribution in [#3087](https://github.com/pydantic/pydantic-ai/pull/3087)
  * [@lienminhquang](https://github.com/lienminhquang) made their first contribution in [#3077](https://github.com/pydantic/pydantic-ai/pull/3077)
  * [@MinuraPunchihewa](https://github.com/MinuraPunchihewa) made their first contribution in [#3094](https://github.com/pydantic/pydantic-ai/pull/3094)
  * [@nicolas-chaulet](https://github.com/nicolas-chaulet) made their first contribution in [#3106](https://github.com/pydantic/pydantic-ai/pull/3106)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.15...v1.0.16).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.16).
### v1.0.15 (2025-10-03)
#### What's Changed
  * Support image generation and output with Google and OpenAI by [@DouweM](https://github.com/DouweM) in [#2970](https://github.com/pydantic/pydantic-ai/pull/2970)
  * Add `AgentRunResult.response` convenience method to get latest model response by [@DouweM](https://github.com/DouweM) in [#2970](https://github.com/pydantic/pydantic-ai/pull/2970)
  * Add `ModelResponse.text`, `thinking`, `files`, `images`, `tool_calls`, and `builtin_tool_calls` convenience methods by [@DouweM](https://github.com/DouweM) in [#2970](https://github.com/pydantic/pydantic-ai/pull/2970)
  * Add `Agent.run_stream_events()` convenience method wrapping `run(event_stream_handler=...)` by [@DouweM](https://github.com/DouweM) in [#3084](https://github.com/pydantic/pydantic-ai/pull/3084)
  * Add content (e.g. files) returned by tool to `FunctionToolResultEvent` by [@DouweM](https://github.com/DouweM) in [#3082](https://github.com/pydantic/pydantic-ai/pull/3082)
  * Set `MCPServer` `id` and `tool_prefix` in `load_mcp_servers` by [@DouweM](https://github.com/DouweM) in [#3052](https://github.com/pydantic/pydantic-ai/pull/3052)
  * Add latest gemini 2.5 flash(-lite) model names and aliases by [@moritzwilksch](https://github.com/moritzwilksch) in [#3060](https://github.com/pydantic/pydantic-ai/pull/3060)
  * Support enums in `format_as_xml` by [@DouweM](https://github.com/DouweM) in [#3064](https://github.com/pydantic/pydantic-ai/pull/3064)
  * Fix dataset serialization when inputs have discriminators with defaults by [@DouweM](https://github.com/DouweM) in [#3079](https://github.com/pydantic/pydantic-ai/pull/3079)
  * Fix parallel tool call limit enforcement by [@tradeqvest](https://github.com/tradeqvest) in [#2978](https://github.com/pydantic/pydantic-ai/pull/2978)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.14...v1.0.15).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.15).
### v1.0.14 (2025-10-02)
#### What's Changed
  * Remove leftover debug `print` statement by [@KostyaGukish](https://github.com/KostyaGukish) in [#3070](https://github.com/pydantic/pydantic-ai/pull/3070)
  * Fix duplicate output tool return part when concatenating first run messages with follow-up `new_messages` by [@DouweM](https://github.com/DouweM) in [#3075](https://github.com/pydantic/pydantic-ai/pull/3075)


#### New Contributors
  * [@KostyaGukish](https://github.com/KostyaGukish) made their first contribution in [#3070](https://github.com/pydantic/pydantic-ai/pull/3070)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.13...v1.0.14).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.14).
### v1.0.13 (2025-10-01)
#### What's Changed
  * feat: Otel instrumentation version 3 by [@bitnahian](https://github.com/bitnahian) in [#3021](https://github.com/pydantic/pydantic-ai/pull/3021)
  * Don't send strict to HuggingFace API as it's not supported by their types and at least some models by [@DouweM](https://github.com/DouweM) in [#3062](https://github.com/pydantic/pydantic-ai/pull/3062)
  * Correctly merge `Model.settings` with `model_settings` in direct mode by [@moritzwilksch](https://github.com/moritzwilksch) in [#2980](https://github.com/pydantic/pydantic-ai/pull/2980)
  * Expose `server_info` in `MCPServer` by [@Whadup](https://github.com/Whadup) in [#3055](https://github.com/pydantic/pydantic-ai/pull/3055)
  * Support contextually overriding agent instructions by [@mwildehahn](https://github.com/mwildehahn) in [#2926](https://github.com/pydantic/pydantic-ai/pull/2926)
  * Update evals attributes by [@dmontagu](https://github.com/dmontagu) in [#2924](https://github.com/pydantic/pydantic-ai/pull/2924)


#### New Contributors
  * [@Whadup](https://github.com/Whadup) made their first contribution in [#3055](https://github.com/pydantic/pydantic-ai/pull/3055)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.12...v1.0.13).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.13).
### v1.0.12 (2025-09-30)
#### What's Changed
  * Support Anthropic built-in memory tool by [@DouweM](https://github.com/DouweM) in [#3042](https://github.com/pydantic/pydantic-ai/pull/3042)
  * Support text, JSON, XML and YAML `DocumentUrl` and `BinaryContent` on OpenAI by [@pulphix](https://github.com/pulphix) in [#2851](https://github.com/pydantic/pydantic-ai/pull/2851)
  * Prefer `structuredContent` MCP tool result when present by [@shaheerzaman](https://github.com/shaheerzaman) in [#2854](https://github.com/pydantic/pydantic-ai/pull/2854)
  * Expose `.messages`, `.toolsets` types in top-level `pydantic_ai` to aid IDE auto-import by [@moritzwilksch](https://github.com/moritzwilksch) in [#2957](https://github.com/pydantic/pydantic-ai/pull/2957)
  * Add cost metric to the pydantic-evals output by [@dmontagu](https://github.com/dmontagu) in [#2984](https://github.com/pydantic/pydantic-ai/pull/2984)
  * Add retry args to `pydantic_evals.Dataset.evaluate_sync` by [@m7mdhka](https://github.com/m7mdhka) in [#3022](https://github.com/pydantic/pydantic-ai/pull/3022)
  * Change type of common_tools to work with agent with any deps type by [@lukekh](https://github.com/lukekh) in [#3037](https://github.com/pydantic/pydantic-ai/pull/3037)
  * Don't error when Gemini returns more than one candidate response by [@DouweM](https://github.com/DouweM) in [#3043](https://github.com/pydantic/pydantic-ai/pull/3043)
  * Handle Ollama responses without `finish_reason` and document Ollama Cloud by [@DouweM](https://github.com/DouweM) in [#3045](https://github.com/pydantic/pydantic-ai/pull/3045)
  * Add custom Vertex AI Model Garden example by [@stefannae](https://github.com/stefannae) in [#2868](https://github.com/pydantic/pydantic-ai/pull/2868)
  * Fix StructuredDict with nested JSON schemas using $ref by [@ChiaXinLiang](https://github.com/ChiaXinLiang) in [#2570](https://github.com/pydantic/pydantic-ai/pull/2570)


#### New Contributors
  * [@m7mdhka](https://github.com/m7mdhka) made their first contribution in [#3022](https://github.com/pydantic/pydantic-ai/pull/3022)
  * [@lukekh](https://github.com/lukekh) made their first contribution in [#3037](https://github.com/pydantic/pydantic-ai/pull/3037)
  * [@pulphix](https://github.com/pulphix) made their first contribution in [#2851](https://github.com/pydantic/pydantic-ai/pull/2851)
  * [@stefannae](https://github.com/stefannae) made their first contribution in [#2868](https://github.com/pydantic/pydantic-ai/pull/2868)
  * [@ChiaXinLiang](https://github.com/ChiaXinLiang) made their first contribution in [#2570](https://github.com/pydantic/pydantic-ai/pull/2570)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.11...v1.0.12).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.12).
### v1.0.11 (2025-09-29)
#### What's Changed
  * Support OpenAI image detail on `ImageUrl` and `BinaryContent` via `vendor_metadata` by [@moritzwilksch](https://github.com/moritzwilksch) in [#2987](https://github.com/pydantic/pydantic-ai/pull/2987)
  * Support callable classes as history processors by [@bitnahian](https://github.com/bitnahian) in [#2988](https://github.com/pydantic/pydantic-ai/pull/2988)
  * Add `claude-sonnet-4-5` to known model names by [@DouweM](https://github.com/DouweM) in [#3033](https://github.com/pydantic/pydantic-ai/pull/3033)
  * Add `operation.cost` metric to instrumented models by [@alexmojaki](https://github.com/alexmojaki) in [#3013](https://github.com/pydantic/pydantic-ai/pull/3013)
  * Fix streaming gpt-oss using Ollama by [@DouweM](https://github.com/DouweM) in [#3035](https://github.com/pydantic/pydantic-ai/pull/3035)
  * Raise error when using Anthropic thinking with output tools by [@DouweM](https://github.com/DouweM) in [#3025](https://github.com/pydantic/pydantic-ai/pull/3025)
  * Make `OutputObjectDefinition` public on `pydantic_ai.output` by [@moritzwilksch](https://github.com/moritzwilksch) in [#2991](https://github.com/pydantic/pydantic-ai/pull/2991)
  * Update `pyproject.toml` to be PEP639 compliant by [@Kludex](https://github.com/Kludex) in [#3001](https://github.com/pydantic/pydantic-ai/pull/3001)
  * Bump temporalio to 1.18.0 by [@DouweM](https://github.com/DouweM) in [#3027](https://github.com/pydantic/pydantic-ai/pull/3027)
  * Bump genai-prices to 0.0.28 by [@DouweM](https://github.com/DouweM) in [#3030](https://github.com/pydantic/pydantic-ai/pull/3030)
  * Document that Gemini requires native or prompted output mode for structured output streaming by [@DouweM](https://github.com/DouweM) in [#3032](https://github.com/pydantic/pydantic-ai/pull/3032)
  * Update Ollama docs instructions by [@slkoo-cc](https://github.com/slkoo-cc) in [#2993](https://github.com/pydantic/pydantic-ai/pull/2993)
  * Update docs and tests for DBOS v2.0 by [@qianl15](https://github.com/qianl15) in [#3004](https://github.com/pydantic/pydantic-ai/pull/3004)


#### New Contributors
  * [@slkoo-cc](https://github.com/slkoo-cc) made their first contribution in [#2993](https://github.com/pydantic/pydantic-ai/pull/2993)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.10...v1.0.11).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.11).
### v1.0.10 (2025-09-19)
#### What's Changed
  * Fix OTel for built-in tools returning a list (e.g. Anthropic web search) by [@DouweM](https://github.com/DouweM) in [#2959](https://github.com/pydantic/pydantic-ai/pull/2959)
  * Drop assertion that Google streaming chunk has candidates by [@DouweM](https://github.com/DouweM) in [#2960](https://github.com/pydantic/pydantic-ai/pull/2960)
  * Retry model request that produced an empty response by [@DouweM](https://github.com/DouweM) in [#2961](https://github.com/pydantic/pydantic-ai/pull/2961)
  * Clarify `Agent(retries=...)` description by [@DouweM](https://github.com/DouweM) in [#2963](https://github.com/pydantic/pydantic-ai/pull/2963)
  * Stop redundantly encoding binary data as base64 when sending to Google genai SDK by [@DouweM](https://github.com/DouweM) in [#2962](https://github.com/pydantic/pydantic-ai/pull/2962)
  * Use model class names as tags in `format_as_xml` and add option to include field titles and descriptions as attributes by [@giacbrd](https://github.com/giacbrd) in [#2313](https://github.com/pydantic/pydantic-ai/pull/2313)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.9...v1.0.10).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.10).
### v1.0.9 (2025-09-18)
#### What's Changed
  * Stream built-in tool calls from OpenAI, Google, Anthropic and return them on next request (required for OpenAI reasoning) by [@DouweM](https://github.com/DouweM) in [#2877](https://github.com/pydantic/pydantic-ai/pull/2877)
  * Include built-in tool calls and results in OTel messages by [@DouweM](https://github.com/DouweM) in [#2954](https://github.com/pydantic/pydantic-ai/pull/2954)
  * Add `RunContext.max_retries` and `.last_attempt` by [@DouweM](https://github.com/DouweM) in [#2952](https://github.com/pydantic/pydantic-ai/pull/2952)
  * Fix `StreamedResponse.model_name` for Azure OpenAI with content filter by [@DouweM](https://github.com/DouweM) in [#2951](https://github.com/pydantic/pydantic-ai/pull/2951)
  * Fix TemporalAgent dropping model-specific `ModelSettings` (e.g. `openai_reasoning_effort`) by [@DouweM](https://github.com/DouweM) in [#2938](https://github.com/pydantic/pydantic-ai/pull/2938)
  * Don't send item IDs to Responses API for non-reasoning models by [@DouweM](https://github.com/DouweM) in [#2950](https://github.com/pydantic/pydantic-ai/pull/2950)
  * Update DBOS version by [@qianl15](https://github.com/qianl15) in [#2939](https://github.com/pydantic/pydantic-ai/pull/2939)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.8...v1.0.9).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.9).
### v1.0.8 (2025-09-16)
#### What's Changed
  * Tools can now return AG-UI events separate from result sent to model by [@DouweM](https://github.com/DouweM) in [#2922](https://github.com/pydantic/pydantic-ai/pull/2922)
  * Fix bug causing doubled reasoning tokens usage by deepcopying by [@DouweM](https://github.com/DouweM) in [#2920](https://github.com/pydantic/pydantic-ai/pull/2920)
  * Fix auto-detection of HTTP proxy settings by [@maxnilz](https://github.com/maxnilz) in [#2917](https://github.com/pydantic/pydantic-ai/pull/2917)
  * Fix `new_messages()` and `capture_run_messages()` when history processors are used by [@DouweM](https://github.com/DouweM) in [#2921](https://github.com/pydantic/pydantic-ai/pull/2921)
  * chore: Remove 'text' from RunUsage docstrings by [@alexmojaki](https://github.com/alexmojaki) in [#2919](https://github.com/pydantic/pydantic-ai/pull/2919)


#### New Contributors
  * [@maxnilz](https://github.com/maxnilz) made their first contribution in [#2917](https://github.com/pydantic/pydantic-ai/pull/2917)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.7...v1.0.8).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.8).
### v1.0.7 (2025-09-15)
#### What's Changed
  * Added MCP metadata and annotations to `ToolDefinition.metadata` for use in filtering by [@ChuckJonas](https://github.com/ChuckJonas) in [#2880](https://github.com/pydantic/pydantic-ai/pull/2880)
  * When starting run with message history ending in `ModelRequest`, make its content available in `RunContext.prompt` by [@DouweM](https://github.com/DouweM) in [#2891](https://github.com/pydantic/pydantic-ai/pull/2891)
  * Let `FunctionToolset` take default values for `strict`, `sequential`, `requires_approval`, `metadata` by [@DouweM](https://github.com/DouweM) in [#2909](https://github.com/pydantic/pydantic-ai/pull/2909)
  * Don't require `mcp` or `logfire` to use Temporal or DBOS by [@DouweM](https://github.com/DouweM) in [#2908](https://github.com/pydantic/pydantic-ai/pull/2908)
  * Combine consecutive AG-UI user and assistant messages into the same model request/response by [@DouweM](https://github.com/DouweM) in [#2912](https://github.com/pydantic/pydantic-ai/pull/2912)
  * Fix `new_messages()` when `deferred_tool_results` is used with `message_history` ending in `ToolReturnPart`s by [@DouweM](https://github.com/DouweM) in [#2913](https://github.com/pydantic/pydantic-ai/pull/2913)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.6...v1.0.7).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.7).
### v1.0.6 (2025-09-12)
#### What's Changed
  * Add support for `previous_response_id` from Responses API by [@GDaamn](https://github.com/GDaamn) in [#2756](https://github.com/pydantic/pydantic-ai/pull/2756)
  * Let MCP servers be loaded from file by [@Kludex](https://github.com/Kludex) in [#2698](https://github.com/pydantic/pydantic-ai/pull/2698)
  * Fix how thinking summaries are sent back to Responses API by [@DouweM](https://github.com/DouweM) in [#2883](https://github.com/pydantic/pydantic-ai/pull/2883)
  * Bump Cohere SDK and remove incorrect typing workaround by [@DouweM](https://github.com/DouweM) in [#2886](https://github.com/pydantic/pydantic-ai/pull/2886)
  * Update MCP tool call customisation docs by [@MasterOdin](https://github.com/MasterOdin) in [#2817](https://github.com/pydantic/pydantic-ai/pull/2817)


#### New Contributors
  * [@MasterOdin](https://github.com/MasterOdin) made their first contribution in [#2817](https://github.com/pydantic/pydantic-ai/pull/2817)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.5...v1.0.6).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.6).
### v1.0.5 (2025-09-11)
#### What's Changed
  * Don't lose Azure OpenAI Responses encrypted_content if no summary was included by [@DouweM](https://github.com/DouweM) in [#2874](https://github.com/pydantic/pydantic-ai/pull/2874)
  * Store OpenAI Responses text part ID to prevent error with reasoning by [@DouweM](https://github.com/DouweM) in [#2882](https://github.com/pydantic/pydantic-ai/pull/2882)
  * Make OpenAIResponsesModel work with reasoning from other models and modified history by [@DouweM](https://github.com/DouweM) in [#2881](https://github.com/pydantic/pydantic-ai/pull/2881)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.4...v1.0.5).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.5).
### v1.0.4 (2025-09-11)
#### What's Changed
  * Add Pydantic AI Gateway provider by [@Kludex](https://github.com/Kludex) in [#2816](https://github.com/pydantic/pydantic-ai/pull/2816), [#2863](https://github.com/pydantic/pydantic-ai/pull/2863)
  * Fix OpenAI Responses API tool calls with reasoning by [@DouweM](https://github.com/DouweM) in [#2869](https://github.com/pydantic/pydantic-ai/pull/2869)
  * Support OpenAI Responses API returning encrypted reasoning content without summary by [@DouweM](https://github.com/DouweM) in [#2866](https://github.com/pydantic/pydantic-ai/pull/2866)
  * Don't ask for OpenAI Responses API to include encrypted reasoning content for models that don't support it by [@DouweM](https://github.com/DouweM) in [#2867](https://github.com/pydantic/pydantic-ai/pull/2867)
  * docs: update builtin-tools md by [@tberends](https://github.com/tberends) in [#2857](https://github.com/pydantic/pydantic-ai/pull/2857)


#### New Contributors
  * [@tberends](https://github.com/tberends) made their first contribution in [#2857](https://github.com/pydantic/pydantic-ai/pull/2857)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.3...v1.0.4).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.4).
### v1.0.3 (2025-09-10)
#### What's Changed
  * Include thinking parts in subsequent model requests to improve performance and cache hit rates by [@DouweM](https://github.com/DouweM) in [#2823](https://github.com/pydantic/pydantic-ai/pull/2823)
  * Add `on_complete` callback to AG-UI functions to get access to `AgentRunResult` by [@ChuckJonas](https://github.com/ChuckJonas) in [#2429](https://github.com/pydantic/pydantic-ai/pull/2429)
  * Support `ModelSettings.seed` in `GoogleModel` by [@DouweM](https://github.com/DouweM) in [#2842](https://github.com/pydantic/pydantic-ai/pull/2842)
  * Add `with agent.sequential_tool_calls():` contextmanager and use it in `DBOSAgent` by [@DouweM](https://github.com/DouweM) in [#2856](https://github.com/pydantic/pydantic-ai/pull/2856)
  * Ensure `ModelResponse` fields are set from actual model response when streaming by [@DouweM](https://github.com/DouweM) in [#2848](https://github.com/pydantic/pydantic-ai/pull/2848)
  * Send AG-UI thinking start and end events by [@DouweM](https://github.com/DouweM) in [#2855](https://github.com/pydantic/pydantic-ai/pull/2855)
  * Support models that return output tool args as `{"response': "<JSON string>"}` by [@shaheerzaman](https://github.com/shaheerzaman) in [#2836](https://github.com/pydantic/pydantic-ai/pull/2836)
  * Support `NativeOutput` with `FunctionModel` by [@DouweM](https://github.com/DouweM) in [#2843](https://github.com/pydantic/pydantic-ai/pull/2843)
  * Raise error when `WebSearchTool` is used with `OpenAIChatModel` and unsupported model by [@safina57](https://github.com/safina57) in [#2824](https://github.com/pydantic/pydantic-ai/pull/2824)


#### New Contributors
  * [@safina57](https://github.com/safina57) made their first contribution in [#2824](https://github.com/pydantic/pydantic-ai/pull/2824)
  * [@shaheerzaman](https://github.com/shaheerzaman) made their first contribution in [#2836](https://github.com/pydantic/pydantic-ai/pull/2836)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.2...v1.0.3).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.3).
### v1.0.2 (2025-09-08)
#### What's Changed
  * Add support for durable execution with DBOS by [@qianl15](https://github.com/qianl15) in [#2638](https://github.com/pydantic/pydantic-ai/pull/2638)
  * Support sequential tool calling by [@strawgate](https://github.com/strawgate) in [#2718](https://github.com/pydantic/pydantic-ai/pull/2718)
  * Add `GoogleModelSettings.google_cached_content` to pass `cached_content` by [@Hojland](https://github.com/Hojland) in [#2832](https://github.com/pydantic/pydantic-ai/pull/2832)
  * Add `ModelResponse.finish_reason` and set `provider_response_id` while streaming by [@fatelei](https://github.com/fatelei) in [#2590](https://github.com/pydantic/pydantic-ai/pull/2590)
  * Add support for `gen_ai.response.id` by [@Kludex](https://github.com/Kludex) in [#2831](https://github.com/pydantic/pydantic-ai/pull/2831)
  * Only send tool choice to Bedrock Converse API for Anthropic and Nova models by [@DouweM](https://github.com/DouweM) in [#2819](https://github.com/pydantic/pydantic-ai/pull/2819)
  * Handle errors in cost calculation in InstrumentedModel by [@alexmojaki](https://github.com/alexmojaki) in [#2834](https://github.com/pydantic/pydantic-ai/pull/2834)


#### New Contributors
  * [@Hojland](https://github.com/Hojland) made their first contribution in [#2832](https://github.com/pydantic/pydantic-ai/pull/2832)
  * [@qianl15](https://github.com/qianl15) made their first contribution in [#2638](https://github.com/pydantic/pydantic-ai/pull/2638)
  * [@fatelei](https://github.com/fatelei) made their first contribution in [#2590](https://github.com/pydantic/pydantic-ai/pull/2590)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.1...v1.0.2).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.2).
### v1.0.1 (2025-09-05)
#### Breaking Changes
The following breaking change was slated to go into v1.0.0 but accidentally left out. Because it's a security issue, an uncommonly used feature, and few people will have updated to v1 yet within 24 hours, we decided it was justified to make an exception to the no-breaking-changes policy to get it out ASAP.
  * Remove `Python` evaluator from `pydantic_evals` for security reasons by [@dmontagu](https://github.com/dmontagu) in [#2808](https://github.com/pydantic/pydantic-ai/pull/2808)


#### Other Changes
  * Remove `eval-type-backport` dependency by [@Viicos](https://github.com/Viicos) in [#2814](https://github.com/pydantic/pydantic-ai/pull/2814)


[](https://github.com/pydantic/pydantic-ai/compare/v1.0.0...v1.0.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.1).
### v1.0.0 (2025-09-04)
#### What's Changed
  * Drop support for Python 3.9 by [@Kludex](https://github.com/Kludex) in [#2725](https://github.com/pydantic/pydantic-ai/pull/2725)
  * Deprecate `OpenAIModelProfile.openai_supports_sampling_settings` by [@Kludex](https://github.com/Kludex) in [#2730](https://github.com/pydantic/pydantic-ai/pull/2730)
  * Add support for human-in-the-loop tool call approval by [@DouweM](https://github.com/DouweM) in [#2581](https://github.com/pydantic/pydantic-ai/pull/2581)
  * Add `tool_calls_limit` to `UsageLimits` and `tool_calls` to `RunUsage` by [@tradeqvest](https://github.com/tradeqvest) in [#2633](https://github.com/pydantic/pydantic-ai/pull/2633)
  * Add LiteLLM provider for OpenAI API compatible models by [@mochow13](https://github.com/mochow13) in [#2606](https://github.com/pydantic/pydantic-ai/pull/2606)
  * Add `identifier` field to `FileUrl` and subclasses by [@kyuam32](https://github.com/kyuam32) in [#2636](https://github.com/pydantic/pydantic-ai/pull/2636)
  * Support `NativeOutput` with Groq by [@DouweM](https://github.com/DouweM) in [#2772](https://github.com/pydantic/pydantic-ai/pull/2772)
  * Add `docstring_format`, `require_parameter_descriptions`, `schema_generator` to `FunctionToolset` by [@g-eoj](https://github.com/g-eoj) in [#2601](https://github.com/pydantic/pydantic-ai/pull/2601)
  * Gracefully handle errors in evals by [@dmontagu](https://github.com/dmontagu) in [#2295](https://github.com/pydantic/pydantic-ai/pull/2295)
  * Include `logfire` with pydantic-ai package by [@Kludex](https://github.com/Kludex) in [#2683](https://github.com/pydantic/pydantic-ai/pull/2683)
  * Let almost all types used in docs examples be imported directly from `pydantic_ai` by [@DouweM](https://github.com/DouweM) in [#2736](https://github.com/pydantic/pydantic-ai/pull/2736)
  * Bump `temporalio` to 1.17.0 by [@DouweM](https://github.com/DouweM) in [#2811](https://github.com/pydantic/pydantic-ai/pull/2811)
  * Default `InstrumentationSettings` `version` to 2 by [@alexmojaki](https://github.com/alexmojaki) in [#2726](https://github.com/pydantic/pydantic-ai/pull/2726)
  * Remove cases and averages from eval span by [@DouweM](https://github.com/DouweM) in [#2715](https://github.com/pydantic/pydantic-ai/pull/2715)
  * Make many more dataclasses kw-only by [@dmontagu](https://github.com/dmontagu) in [#2738](https://github.com/pydantic/pydantic-ai/pull/2738)
  * Don't emit empty AG-UI thinking message events by [@DouweM](https://github.com/DouweM) in [#2754](https://github.com/pydantic/pydantic-ai/pull/2754)
  * Update `mcp` package version by [@BrokenDuck](https://github.com/BrokenDuck) in [#2741](https://github.com/pydantic/pydantic-ai/pull/2741)
  * Raise error if MCP server `__aexit__` is called when `_running_count` is already `0` by [@federicociner](https://github.com/federicociner) in [#2696](https://github.com/pydantic/pydantic-ai/pull/2696)
  * Fix error when streaming from Gemini includes only `executable_code` or `code_execution_result` by [@binaryCrossEntropy](https://github.com/binaryCrossEntropy) in [#2719](https://github.com/pydantic/pydantic-ai/pull/2719)
  * Close original response when retrying HTTP request by [@DouweM](https://github.com/DouweM) in [#2753](https://github.com/pydantic/pydantic-ai/pull/2753)
  * `Agent.__aenter__` returns `Self`, use default instrumentation for MCP sampling model by [@alexmojaki](https://github.com/alexmojaki) in [#2765](https://github.com/pydantic/pydantic-ai/pull/2765)
  * Fix Anthropic streaming usage counting by [@DouweM](https://github.com/DouweM) in [#2771](https://github.com/pydantic/pydantic-ai/pull/2771)
  * Create separate `ThinkingParts` for separate OpenAI Responses reasoning summary parts by [@DouweM](https://github.com/DouweM) in [#2775](https://github.com/pydantic/pydantic-ai/pull/2775)
  * Handle Groq `tool_use_failed` errors by getting model to retry by [@DouweM](https://github.com/DouweM) in [#2774](https://github.com/pydantic/pydantic-ai/pull/2774)
  * Raise error when trying to use Google built-in tools with user/output tools by [@DouweM](https://github.com/DouweM) in [#2777](https://github.com/pydantic/pydantic-ai/pull/2777)
  * Move `mcp-run-python` to its own repo by [@samuelcolvin](https://github.com/samuelcolvin) in [#2776](https://github.com/pydantic/pydantic-ai/pull/2776)
  * Fix Azure OpenAI streaming when async content filter is enabled by [@frednijsvrt](https://github.com/frednijsvrt) in [#2763](https://github.com/pydantic/pydantic-ai/pull/2763)
  * Don't emit AG-UI text message content events with empty text part deltas by [@celeritatem](https://github.com/celeritatem) in [#2779](https://github.com/pydantic/pydantic-ai/pull/2779)
  * Handle streaming thinking signature deltas from Bedrock Converse API by [@DouweM](https://github.com/DouweM) in [#2785](https://github.com/pydantic/pydantic-ai/pull/2785)
  * Don't require `MCPServerStreamableHTTP` and `MCPServerSSE` `url` to be a keyword argument by [@franciscovilchezv](https://github.com/franciscovilchezv) in [#2758](https://github.com/pydantic/pydantic-ai/pull/2758)
  * Add `operation.cost` span attribute to model request spans, rename `ModelResponse.price()` to `.cost()` by [@alexmojaki](https://github.com/alexmojaki) in [#2767](https://github.com/pydantic/pydantic-ai/pull/2767)
  * Ensure that old `ModelResponse`s stored in a DB can still be deserialized by [@DouweM](https://github.com/DouweM) in [#2792](https://github.com/pydantic/pydantic-ai/pull/2792)
  * Type `ModelRequest.parts` and `ModelResponse.parts` as `Sequence` by [@moritzwilksch](https://github.com/moritzwilksch) in [#2798](https://github.com/pydantic/pydantic-ai/pull/2798)
  * Always run `event_stream_handler` inside Temporal activity by [@DouweM](https://github.com/DouweM) in [#2806](https://github.com/pydantic/pydantic-ai/pull/2806)
  * Document that various functions need to be async to be used with Temporal by [@DouweM](https://github.com/DouweM) in [#2809](https://github.com/pydantic/pydantic-ai/pull/2809)


#### New Contributors
  * [@BrokenDuck](https://github.com/BrokenDuck) made their first contribution in [#2741](https://github.com/pydantic/pydantic-ai/pull/2741)
  * [@federicociner](https://github.com/federicociner) made their first contribution in [#2696](https://github.com/pydantic/pydantic-ai/pull/2696)
  * [@g-eoj](https://github.com/g-eoj) made their first contribution in [#2601](https://github.com/pydantic/pydantic-ai/pull/2601)
  * [@binaryCrossEntropy](https://github.com/binaryCrossEntropy) made their first contribution in [#2719](https://github.com/pydantic/pydantic-ai/pull/2719)
  * [@Trollgeir](https://github.com/Trollgeir) made their first contribution in [#2729](https://github.com/pydantic/pydantic-ai/pull/2729)
  * [@kyuam32](https://github.com/kyuam32) made their first contribution in [#2636](https://github.com/pydantic/pydantic-ai/pull/2636)
  * [@richhuth](https://github.com/richhuth) made their first contribution in [#2680](https://github.com/pydantic/pydantic-ai/pull/2680)
  * [@frednijsvrt](https://github.com/frednijsvrt) made their first contribution in [#2763](https://github.com/pydantic/pydantic-ai/pull/2763)
  * [@celeritatem](https://github.com/celeritatem) made their first contribution in [#2779](https://github.com/pydantic/pydantic-ai/pull/2779)
  * [@mochow13](https://github.com/mochow13) made their first contribution in [#2606](https://github.com/pydantic/pydantic-ai/pull/2606)
  * [@franciscovilchezv](https://github.com/franciscovilchezv) made their first contribution in [#2758](https://github.com/pydantic/pydantic-ai/pull/2758)
  * [@moritzwilksch](https://github.com/moritzwilksch) made their first contribution in [#2798](https://github.com/pydantic/pydantic-ai/pull/2798)


[](https://github.com/pydantic/pydantic-ai/compare/v0.8.1...v1.0.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.0).
### v1.0.0b1 (2025-08-30)
#### What's Changed
  * Drop support for Python 3.9 by [@Kludex](https://github.com/Kludex) in [#2725](https://github.com/pydantic/pydantic-ai/pull/2725)
  * Add support for human-in-the-loop tool call approval by [@DouweM](https://github.com/DouweM) in [#2581](https://github.com/pydantic/pydantic-ai/pull/2581)
  * Deprecate `OpenAIModelProfile.openai_supports_sampling_settings` by [@Kludex](https://github.com/Kludex) in [#2730](https://github.com/pydantic/pydantic-ai/pull/2730)
  * Gracefully handle errors in evals by [@dmontagu](https://github.com/dmontagu) in [#2295](https://github.com/pydantic/pydantic-ai/pull/2295)
  * Include logfire with pydantic-ai package by [@Kludex](https://github.com/Kludex) in [#2683](https://github.com/pydantic/pydantic-ai/pull/2683)
  * Remove errors when passing Retrying instead of RetryConfig to TenacityTransport by [@DouweM](https://github.com/DouweM) in [#2717](https://github.com/pydantic/pydantic-ai/pull/2717)
  * Default `InstrumentationSettings` `version` to 2 by [@alexmojaki](https://github.com/alexmojaki) in [#2726](https://github.com/pydantic/pydantic-ai/pull/2726)
  * Remove cases and averages from eval span by [@DouweM](https://github.com/DouweM) in [#2715](https://github.com/pydantic/pydantic-ai/pull/2715)
  * Make many more dataclasses kw-only by [@dmontagu](https://github.com/dmontagu) in [#2738](https://github.com/pydantic/pydantic-ai/pull/2738)


[](https://github.com/pydantic/pydantic-ai/compare/v0.8.1...v1.0.0b1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v1.0.0b1).
### v0.8.1 (2025-08-29)
#### What's Changed
  * Add `gen_ai.system_instructions` attribute to agent run spans by [@alexmojaki](https://github.com/alexmojaki) in [#2699](https://github.com/pydantic/pydantic-ai/pull/2699)
  * Bump `temporalio` to 1.16.0 by [@DouweM](https://github.com/DouweM) in [#2703](https://github.com/pydantic/pydantic-ai/pull/2703)
  * Rename `StreamedRunResult` methods to be consistent with `AgentStream` by [@DouweM](https://github.com/DouweM) in [#2692](https://github.com/pydantic/pydantic-ai/pull/2692)
  * Deprecate specifying a model name without a provider prefix, and the `vertexai` provider name by [@DouweM](https://github.com/DouweM) in [#2711](https://github.com/pydantic/pydantic-ai/pull/2711)
  * Rename `ModelResponse.provider_request_id` to `provider_response_id` by [@DouweM](https://github.com/DouweM) in [#2710](https://github.com/pydantic/pydantic-ai/pull/2710)
  * docs: Add `message_history` parameter documentation for CLI methods by [@ryx2](https://github.com/ryx2) in [#2695](https://github.com/pydantic/pydantic-ai/pull/2695)


[](https://github.com/pydantic/pydantic-ai/compare/v0.8.0...v0.8.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.8.1).
### v0.8.0 (2025-08-26)
#### What's Changed
  * Add elicitation callback support to MCP servers by [@yamanahlawat](https://github.com/yamanahlawat) in [#2373](https://github.com/pydantic/pydantic-ai/pull/2373)
  * Add `message_history` parameter to `agent.to_cli()` by [@ryx2](https://github.com/ryx2) in [#2674](https://github.com/pydantic/pydantic-ai/pull/2674)
  * Properly deserialize complex tool arguments with Temporal by [@DouweM](https://github.com/DouweM) in [#2686](https://github.com/pydantic/pydantic-ai/pull/2686)
  * Fix serialization / deserialization of `FileUrl.media_type` by [@mwildehahn](https://github.com/mwildehahn) in [#2677](https://github.com/pydantic/pydantic-ai/pull/2677)
  * Handle missing token details in vLLM/OpenAI-compatible APIs by [@DouweM](https://github.com/DouweM) in [#2669](https://github.com/pydantic/pydantic-ai/pull/2669)
  * Make AgentStreamEvent union of ModelResponseStreamEvent and HandleResponseEvent by [@DouweM](https://github.com/DouweM) in [#2689](https://github.com/pydantic/pydantic-ai/pull/2689)


[](https://github.com/pydantic/pydantic-ai/compare/v0.7.6...v0.8.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.8.0).
### v0.7.6 (2025-08-26)
#### What's Changed
  * Replace `all_messages_events` with `pydantic_ai.all_messages` for `InstrumentationSettings(version=2)` by [@alexmojaki](https://github.com/alexmojaki) in [#2658](https://github.com/pydantic/pydantic-ai/pull/2658)
  * Fix inability to call response.raise_for_status in AsyncTenacityTransport by [@dmontagu](https://github.com/dmontagu) in [#2668](https://github.com/pydantic/pydantic-ai/pull/2668)
  * Deprecate `OpenAIModel` in favor of `OpenAIChatModel` by [@Kludex](https://github.com/Kludex) in [#2676](https://github.com/pydantic/pydantic-ai/pull/2676)
  * anthropic: drop new lines on empty system prompt by [@Kludex](https://github.com/Kludex) in [#2678](https://github.com/pydantic/pydantic-ai/pull/2678)
  * fix(bedrock): skip SystemPromptPart with empty content by [@essamgouda97](https://github.com/essamgouda97) in [#2672](https://github.com/pydantic/pydantic-ai/pull/2672)
  * BREAKING CHANGE: Fix tenacity implementation for improved retry behavior by [@dmontagu](https://github.com/dmontagu) in [#2670](https://github.com/pydantic/pydantic-ai/pull/2670)
  * Add Cerebras provider by [@Kludex](https://github.com/Kludex) in [#2643](https://github.com/pydantic/pydantic-ai/pull/2643)


#### New Contributors
  * [@essamgouda97](https://github.com/essamgouda97) made their first contribution in [#2672](https://github.com/pydantic/pydantic-ai/pull/2672)


[](https://github.com/pydantic/pydantic-ai/compare/v0.7.5...v0.7.6).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.7.6).
### v0.7.5 (2025-08-25)
#### What's Changed
  * Handle 'STOP' finish_reason in GeminiStreamedResponse by [@ArneZsng](https://github.com/ArneZsng) in [#2631](https://github.com/pydantic/pydantic-ai/pull/2631)
  * Add `price()` method to `ModelResponse` by [@Kludex](https://github.com/Kludex) in [#2584](https://github.com/pydantic/pydantic-ai/pull/2584)
  * Include thoughts tokens in output_tokens for Google models by [@alexmojaki](https://github.com/alexmojaki) in [#2634](https://github.com/pydantic/pydantic-ai/pull/2634)
  * Add `span_id` and `trace_id` to `EvaluationReport` by [@Kludex](https://github.com/Kludex) in [#2627](https://github.com/pydantic/pydantic-ai/pull/2627)
  * Allow proper type on `AnthropicProvider` when using Bedrock by [@akoshel](https://github.com/akoshel) in [#2490](https://github.com/pydantic/pydantic-ai/pull/2490)
  * Use new OpenTelemetry GenAI chat span attribute conventions by [@alexmojaki](https://github.com/alexmojaki) in [#2349](https://github.com/pydantic/pydantic-ai/pull/2349)
  * Ensure `content` is always set for assistant tool call messages for OpenAI. by [@vimota](https://github.com/vimota) in [#2641](https://github.com/pydantic/pydantic-ai/pull/2641)


#### New Contributors
  * [@ArneZsng](https://github.com/ArneZsng) made their first contribution in [#2631](https://github.com/pydantic/pydantic-ai/pull/2631)
  * [@akoshel](https://github.com/akoshel) made their first contribution in [#2490](https://github.com/pydantic/pydantic-ai/pull/2490)
  * [@vimota](https://github.com/vimota) made their first contribution in [#2641](https://github.com/pydantic/pydantic-ai/pull/2641)


[](https://github.com/pydantic/pydantic-ai/compare/v0.7.4...v0.7.5).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.7.5).
### v0.7.4 (2025-08-20)
#### What's Changed
  * Fix bug with google model safety handling by [@dmontagu](https://github.com/dmontagu) in [#2066](https://github.com/pydantic/pydantic-ai/pull/2066)
  * Add `takes_ctx` arg to `Tool.from_schema` by [@dedeswim](https://github.com/dedeswim) in [#2615](https://github.com/pydantic/pydantic-ai/pull/2615)
  * feat: support Google's url_context builtin tool by [@vinnymeller](https://github.com/vinnymeller) in [#2604](https://github.com/pydantic/pydantic-ai/pull/2604)
  * Add missing UrlContextTool into **all** by [@Kludex](https://github.com/Kludex) in [#2617](https://github.com/pydantic/pydantic-ai/pull/2617)
  * Drop assertion on Google streaming by [@Kludex](https://github.com/Kludex) in [#2618](https://github.com/pydantic/pydantic-ai/pull/2618)


#### New Contributors
  * [@dedeswim](https://github.com/dedeswim) made their first contribution in [#2615](https://github.com/pydantic/pydantic-ai/pull/2615)
  * [@vinnymeller](https://github.com/vinnymeller) made their first contribution in [#2604](https://github.com/pydantic/pydantic-ai/pull/2604)
  * [@ivo-1](https://github.com/ivo-1) made their first contribution in [#2610](https://github.com/pydantic/pydantic-ai/pull/2610)


[](https://github.com/pydantic/pydantic-ai/compare/v0.7.3...v0.7.4).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.7.4).
### v0.7.3 (2025-08-19)
#### What's Changed
  * Deprecate `Usage` in favour of `RequestUsage` and `RunUsage` by [@samuelcolvin](https://github.com/samuelcolvin) in [#2378](https://github.com/pydantic/pydantic-ai/pull/2378)
  * Make `FallbackModel` accept string model names by [@vikigenius](https://github.com/vikigenius) in [#2564](https://github.com/pydantic/pydantic-ai/pull/2564)
  * Move `system_prompt_role` from `OpenAIModel` to `OpenAIModelProfile` by [@Kludex](https://github.com/Kludex) in [#2573](https://github.com/pydantic/pydantic-ai/pull/2573)
  * Add `/cp` command to CLI to copy last response to clipboard by [@07pepa](https://github.com/07pepa) in [#2386](https://github.com/pydantic/pydantic-ai/pull/2386)
  * Pin temporalio to 1.15.0 as plugins API is still experimental by [@DouweM](https://github.com/DouweM) in [#2582](https://github.com/pydantic/pydantic-ai/pull/2582)
  * Use `_provider.name` instead of `_system` by [@Kludex](https://github.com/Kludex) in [#2596](https://github.com/pydantic/pydantic-ai/pull/2596)


#### New Contributors
  * [@vikigenius](https://github.com/vikigenius) made their first contribution in [#2564](https://github.com/pydantic/pydantic-ai/pull/2564)
  * [@07pepa](https://github.com/07pepa) made their first contribution in [#2386](https://github.com/pydantic/pydantic-ai/pull/2386)
  * [@jscheel](https://github.com/jscheel) made their first contribution in [#2576](https://github.com/pydantic/pydantic-ai/pull/2576)
  * [@cyonii](https://github.com/cyonii) made their first contribution in [#2579](https://github.com/pydantic/pydantic-ai/pull/2579)


[](https://github.com/pydantic/pydantic-ai/compare/v0.7.2...v0.7.3).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.7.3).
### v0.7.2 (2025-08-14)
#### What's Changed
  * Let message history end on ModelResponse and execute pending tool calls by [@DouweM](https://github.com/DouweM) in [#2562](https://github.com/pydantic/pydantic-ai/pull/2562)
  * Ignore leading whitespace when streaming from Qwen or DeepSeek by [@DouweM](https://github.com/DouweM) in [#2554](https://github.com/pydantic/pydantic-ai/pull/2554)
  * Stop calling MCP server `get_tools` ahead of `agent run` span by [@DouweM](https://github.com/DouweM) in [#2545](https://github.com/pydantic/pydantic-ai/pull/2545)
  * Remove anthropic-beta default header set in `AnthropicModel` by [@jerry-reevo](https://github.com/jerry-reevo) in [#2544](https://github.com/pydantic/pydantic-ai/pull/2544)
  * Add `OllamaProvider` by [@DouweM](https://github.com/DouweM) in [#2554](https://github.com/pydantic/pydantic-ai/pull/2554)
  * Add `profile` and `settings` to `HuggingfaceModel` by [@DouweM](https://github.com/DouweM) in [#2554](https://github.com/pydantic/pydantic-ai/pull/2554)
  * Ask model to try again if it produced a response without text or tool calls, only thinking by [@ethanabrooks](https://github.com/ethanabrooks) in [#2556](https://github.com/pydantic/pydantic-ai/pull/2556)
  * Forward max_uses parameter to Anthropic WebSearchTool by [@eballesteros](https://github.com/eballesteros) in [#2561](https://github.com/pydantic/pydantic-ai/pull/2561)


#### New Contributors
  * [@ethanabrooks](https://github.com/ethanabrooks) made their first contribution in [#2556](https://github.com/pydantic/pydantic-ai/pull/2556)
  * [@eballesteros](https://github.com/eballesteros) made their first contribution in [#2561](https://github.com/pydantic/pydantic-ai/pull/2561)


[](https://github.com/pydantic/pydantic-ai/compare/v0.7.1...v0.7.2).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.7.2).
### v0.7.1 (2025-08-13)
#### What's Changed
  * Add new OpenAI GPT-5 models by [@medaminezghal](https://github.com/medaminezghal) in [#2503](https://github.com/pydantic/pydantic-ai/pull/2503)
  * Add support for OpenAI verbosity parameter in Responses API by [@ryx2](https://github.com/ryx2) in [#2493](https://github.com/pydantic/pydantic-ai/pull/2493)
  * Add support for `"openai-responses"` model inference string by [@Kludex](https://github.com/Kludex) in [#2528](https://github.com/pydantic/pydantic-ai/pull/2528)
  * Add `UsageLimits.count_tokens_before_request` using Gemini `count_tokens` API by [@kauabh](https://github.com/kauabh) in [#2137](https://github.com/pydantic/pydantic-ai/pull/2137)
  * Fix `FallbackModel` to respect each model's model settings by [@jerry-reevo](https://github.com/jerry-reevo) in [#2540](https://github.com/pydantic/pydantic-ai/pull/2540)


#### New Contributors
  * [@spike-spiegel-21](https://github.com/spike-spiegel-21) made their first contribution in [#2529](https://github.com/pydantic/pydantic-ai/pull/2529)
  * [@ryx2](https://github.com/ryx2) made their first contribution in [#2493](https://github.com/pydantic/pydantic-ai/pull/2493)


[](https://github.com/pydantic/pydantic-ai/compare/v0.7.0...v0.7.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.7.1).
### v0.7.0 (2025-08-12)
#### What's Changed
  * Let Agent be run in a Temporal workflow by moving model requests, tool calls, and MCP to Temporal activities by [@DouweM](https://github.com/DouweM) in [#2225](https://github.com/pydantic/pydantic-ai/pull/2225)
  * Let toolsets be built dynamically based on run context by [@strawgate](https://github.com/strawgate) in [#2366](https://github.com/pydantic/pydantic-ai/pull/2366)
  * Add `event_stream_handler` to agent and run methods by [@DouweM](https://github.com/DouweM) in [#2458](https://github.com/pydantic/pydantic-ai/pull/2458)
  * History processor replaces message history by [@AlexEnrique](https://github.com/AlexEnrique) in [#2324](https://github.com/pydantic/pydantic-ai/pull/2324)
  * Add `AbstractAgent` and `WrapperAgent` by [@DouweM](https://github.com/DouweM) in [#2458](https://github.com/pydantic/pydantic-ai/pull/2458)
  * Add `Agent.override(tools=...)` by [@DouweM](https://github.com/DouweM) in [#2458](https://github.com/pydantic/pydantic-ai/pull/2458)
  * Bump mcp-run-python by [@Kludex](https://github.com/Kludex) in [#2470](https://github.com/pydantic/pydantic-ai/pull/2470)
  * Fix error when using GPT-5 with a temperature setting by [@DouweM](https://github.com/DouweM) in [#2483](https://github.com/pydantic/pydantic-ai/pull/2483)
  * Fix KeyError when parsing video metadata without audio track in Google models by [@jerry-heygen](https://github.com/jerry-heygen) in [#2507](https://github.com/pydantic/pydantic-ai/pull/2507)
  * Make OpenAIResponsesModelSettings.openai_builtin_tools work again by [@DouweM](https://github.com/DouweM) in [#2520](https://github.com/pydantic/pydantic-ai/pull/2520)


#### New Contributors
  * [@AlexEnrique](https://github.com/AlexEnrique) made their first contribution in [#2324](https://github.com/pydantic/pydantic-ai/pull/2324)
  * [@jerry-heygen](https://github.com/jerry-heygen) made their first contribution in [#2507](https://github.com/pydantic/pydantic-ai/pull/2507)


[](https://github.com/pydantic/pydantic-ai/compare/v0.6.2...v0.7.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.7.0).
### v0.6.2 (2025-08-07)
#### What's Changed
  * Add `builtin_tools` to `Agent` by [@mattbrandman](https://github.com/mattbrandman) in [#2102](https://github.com/pydantic/pydantic-ai/pull/2102)


#### New Contributors
  * [@mattbrandman](https://github.com/mattbrandman) made their first contribution in [#2102](https://github.com/pydantic/pydantic-ai/pull/2102)


[](https://github.com/pydantic/pydantic-ai/compare/v0.6.1...v0.6.2).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.6.2).
### v0.6.1 (2025-08-07)
#### What's Changed
  * Automatically use OpenAI strict mode for strict-compatible native output types by [@DouweM](https://github.com/DouweM) in [#2447](https://github.com/pydantic/pydantic-ai/pull/2447)
  * Make `InlineDefsJsonSchemaTransformer` public by [@DouweM](https://github.com/DouweM) in [#2455](https://github.com/pydantic/pydantic-ai/pull/2455)
  * Send `ThinkingPart`s back to Anthropic used through Bedrock by [@DouweM](https://github.com/DouweM) in [#2454](https://github.com/pydantic/pydantic-ai/pull/2454)
  * Support `AWS_BEARER_TOKEN_BEDROCK` API key env var by [@DouweM](https://github.com/DouweM) in [#2456](https://github.com/pydantic/pydantic-ai/pull/2456)
  * Add new Heroku models by [@Kludex](https://github.com/Kludex) in [#2459](https://github.com/pydantic/pydantic-ai/pull/2459)


[](https://github.com/pydantic/pydantic-ai/compare/v0.6.0...v0.6.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.6.1).
### v0.6.0 (2025-08-06)
#### What's Changed
  * Remove older deprecated models and add new model of Anthropic by [@medaminezghal](https://github.com/medaminezghal) in [#2435](https://github.com/pydantic/pydantic-ai/pull/2435)
  * BREAKING CHANGE: Remove `next()` method from `Graph` by [@Kludex](https://github.com/Kludex) in [#2440](https://github.com/pydantic/pydantic-ai/pull/2440)
  * BREAKING CHANGE: Remove `data` from `FinalResult` by [@Kludex](https://github.com/Kludex) in [#2443](https://github.com/pydantic/pydantic-ai/pull/2443)
  * BREAKING CHANGE: Remove `get_data` and `validate_structured_result` from `StreamedRunResult` by [@Kludex](https://github.com/Kludex) in [#2445](https://github.com/pydantic/pydantic-ai/pull/2445)
  * docs: add `griffe_warnings_deprecated` by [@Kludex](https://github.com/Kludex) in [#2444](https://github.com/pydantic/pydantic-ai/pull/2444)
  * BREAKING CHANGE: Remove `format_as_xml` module by [@Kludex](https://github.com/Kludex) in [#2446](https://github.com/pydantic/pydantic-ai/pull/2446)
  * BREAKING CHANGE: Remove `result_type` parameter and similar from `Agent` by [@Kludex](https://github.com/Kludex) in [#2441](https://github.com/pydantic/pydantic-ai/pull/2441)
  * Deprecate `GoogleGLAProvider` and `GoogleVertexProvider` by [@Kludex](https://github.com/Kludex) in [#2450](https://github.com/pydantic/pydantic-ai/pull/2450)
  * BREAKING CHANGE: drop 4 months old deprecation warnings by [@Kludex](https://github.com/Kludex) in [#2451](https://github.com/pydantic/pydantic-ai/pull/2451)


[](https://github.com/pydantic/pydantic-ai/compare/v0.5.1...v0.6.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.6.0).
### v0.5.1 (2025-08-06)
#### What's Changed
  * google: add more information about schema on union by [@Kludex](https://github.com/Kludex) in [#2426](https://github.com/pydantic/pydantic-ai/pull/2426)
  * Deprecate `GeminiModel` in favor of `GoogleModel` by [@Kludex](https://github.com/Kludex) in [#2416](https://github.com/pydantic/pydantic-ai/pull/2416)
  * Use `httpx` on `GoogleProvider` by [@Kludex](https://github.com/Kludex) in [#2438](https://github.com/pydantic/pydantic-ai/pull/2438)


#### New Contributors
  * [@Tiksagol](https://github.com/Tiksagol) made their first contribution in [#2427](https://github.com/pydantic/pydantic-ai/pull/2427)


[](https://github.com/pydantic/pydantic-ai/compare/v0.5.0...v0.5.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.5.1).
### v0.5.0 (2025-08-04)
#### What's Changed
  * Breaking Change: The `EvaluationReport.print` and `EvaluationReport.console_table` methods now require most arguments be passed by keyword. by [@dmontagu](https://github.com/dmontagu) in [#2163](https://github.com/pydantic/pydantic-ai/pull/2163)
  * Breaking Change: The `source` field of an `EvaluationResult` is now of type `EvaluatorSpec` rather than the actual source `Evaluator` instance, to help with serialization/deserialization by [@dmontagu](https://github.com/dmontagu) in [#2388](https://github.com/pydantic/pydantic-ai/pull/2388)
  * Let more `BaseModel`s use OpenAI strict JSON mode by defaulting to `additionalProperties=False` by [@DouweM](https://github.com/DouweM) in [#2419](https://github.com/pydantic/pydantic-ai/pull/2419)
  * Allow string format, pattern and others in OpenAI strict JSON mode by [@DouweM](https://github.com/DouweM) in [#2420](https://github.com/pydantic/pydantic-ai/pull/2420)
  * Include default values in tool arguments JSON schema by [@DouweM](https://github.com/DouweM) in [#2418](https://github.com/pydantic/pydantic-ai/pull/2418)
  * Fix ImageUrl, VideoUrl, AudioUrl and DocumentUrl not being serializable by [@DouweM](https://github.com/DouweM) in [#2422](https://github.com/pydantic/pydantic-ai/pull/2422)
  * Fix `test_download_item_no_content_type` test failing on macOS by [@strawgate](https://github.com/strawgate) in [#2404](https://github.com/pydantic/pydantic-ai/pull/2404)
  * Document performance implications of async vs sync tools by [@GuillermoBlasco](https://github.com/GuillermoBlasco) in [#2298](https://github.com/pydantic/pydantic-ai/pull/2298)
  * Document that tools become toolset internally by [@HamzaFarhan](https://github.com/HamzaFarhan) in [#2395](https://github.com/pydantic/pydantic-ai/pull/2395)
  * docs: add missing optional packages in `install.md` by [@Kludex](https://github.com/Kludex) in [#2412](https://github.com/pydantic/pydantic-ai/pull/2412)


#### New Contributors
  * [@GuillermoBlasco](https://github.com/GuillermoBlasco) made their first contribution in [#2298](https://github.com/pydantic/pydantic-ai/pull/2298)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.11...v0.5.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.5.0).
### v0.4.11 (2025-08-01)
#### What's Changed
  * Add convenience functions to handle AG-UI requests with request-specific deps by [@DouweM](https://github.com/DouweM) in [#2397](https://github.com/pydantic/pydantic-ai/pull/2397)
  * Support custom thinking tags specified on the model profile by [@xjose97x](https://github.com/xjose97x) in [#2364](https://github.com/pydantic/pydantic-ai/pull/2364)
  * Rename gemini-2.5-flash-lite-preview-06-17 to gemini-2.5-flash-lite as it's out of preview by [@ethan01x](https://github.com/ethan01x) in [#2387](https://github.com/pydantic/pydantic-ai/pull/2387)
  * Fix toggleable toolset example so toolset state is not shared across agent runs by [@DouweM](https://github.com/DouweM) in [#2396](https://github.com/pydantic/pydantic-ai/pull/2396)
  * Docs: add an example of using RunContext to pass data among tools by [@tonyxwz](https://github.com/tonyxwz) in [#2316](https://github.com/pydantic/pydantic-ai/pull/2316)


#### New Contributors
  * [@tonyxwz](https://github.com/tonyxwz) made their first contribution in [#2316](https://github.com/pydantic/pydantic-ai/pull/2316)
  * [@ethan01x](https://github.com/ethan01x) made their first contribution in [#2387](https://github.com/pydantic/pydantic-ai/pull/2387)
  * [@xjose97x](https://github.com/xjose97x) made their first contribution in [#2364](https://github.com/pydantic/pydantic-ai/pull/2364)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.10...v0.4.11).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.11).
### v0.4.10 (2025-07-30)
#### What's Changed
  * Fix parallel tool calling with tools returning ToolReturn with content by [@DouweM](https://github.com/DouweM) in [#2365](https://github.com/pydantic/pydantic-ai/pull/2365)
  * Always enter Toolset context when running agent by [@strawgate](https://github.com/strawgate) in [#2361](https://github.com/pydantic/pydantic-ai/pull/2361)
  * Add `priority` `service_tier` to `OpenAIModelSettings` and respect it in `OpenAIResponsesModel` by [@akenarsari](https://github.com/akenarsari) in [#2368](https://github.com/pydantic/pydantic-ai/pull/2368)
  * Add HTTP Referer request header to Vercel AI Gateway provider by [@joshualipman123](https://github.com/joshualipman123) in [#2369](https://github.com/pydantic/pydantic-ai/pull/2369)


#### New Contributors
  * [@akenarsari](https://github.com/akenarsari) made their first contribution in [#2368](https://github.com/pydantic/pydantic-ai/pull/2368)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.9...v0.4.10).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.10).
### v0.4.9 (2025-07-28)
#### What's Changed
  * Ensure AG-UI state is isolated between requests by [@DouweM](https://github.com/DouweM) in [#2343](https://github.com/pydantic/pydantic-ai/pull/2343)
  * Refine retry logic for parallel tool calling by [@DouweM](https://github.com/DouweM) in [#2317](https://github.com/pydantic/pydantic-ai/pull/2317)
  * Fix AgentStream.stream_output and StreamedRunResult.stream_structured with output tools by [@DouweM](https://github.com/DouweM) in [#2314](https://github.com/pydantic/pydantic-ai/pull/2314)
  * Allow `default` in tool schema with Gemini by [@strawgate](https://github.com/strawgate) in [#2309](https://github.com/pydantic/pydantic-ai/pull/2309)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.8...v0.4.9).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.9).
### v0.4.8 (2025-07-28)
#### What's Changed
  * Add tenacity utilities/integration for improved retry handling by [@dmontagu](https://github.com/dmontagu) in [#2282](https://github.com/pydantic/pydantic-ai/pull/2282)
  * fix: close initialized MCP server if any MCP server fails to initalize by [@hartungstenio](https://github.com/hartungstenio) in [#2312](https://github.com/pydantic/pydantic-ai/pull/2312)
  * Adding thinkingpart to otel_events in ModelResponse by [@adtyavrdhn](https://github.com/adtyavrdhn) in [#2237](https://github.com/pydantic/pydantic-ai/pull/2237)
  * Fix: TypeError in MCPServerSSE due to improper initialization by [@tradeqvest](https://github.com/tradeqvest) in [#2319](https://github.com/pydantic/pydantic-ai/pull/2319)
  * Fix: AG-UI assistant text and tool call order by [@ChuckJonas](https://github.com/ChuckJonas) in [#2328](https://github.com/pydantic/pydantic-ai/pull/2328)


#### New Contributors
  * [@hartungstenio](https://github.com/hartungstenio) made their first contribution in [#2312](https://github.com/pydantic/pydantic-ai/pull/2312)
  * [@tradeqvest](https://github.com/tradeqvest) made their first contribution in [#2319](https://github.com/pydantic/pydantic-ai/pull/2319)
  * [@ChuckJonas](https://github.com/ChuckJonas) made their first contribution in [#2328](https://github.com/pydantic/pydantic-ai/pull/2328)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.7...v0.4.8).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.8).
### v0.4.7 (2025-07-24)
#### What's Changed
  * Add MoonshotAI provider with Kimi-K2 model support by [@zachmayer](https://github.com/zachmayer) in [#2211](https://github.com/pydantic/pydantic-ai/pull/2211)
  * Add Vercel AI Gateway provider by [@joshualipman123](https://github.com/joshualipman123) in [#2277](https://github.com/pydantic/pydantic-ai/pull/2277)
  * Support passing files uploaded to Gemini Files API and setting custom media type by [@dprov](https://github.com/dprov) in [#2270](https://github.com/pydantic/pydantic-ai/pull/2270)
  * Parse '' tags in streamed text as thinking parts by [@DouweM](https://github.com/DouweM) in [#2290](https://github.com/pydantic/pydantic-ai/pull/2290)
  * Rename `MCPServer` `sse_read_timeout` to `read_timeout` and pass to `ClientSession` by [@AntSan813](https://github.com/AntSan813) in [#2240](https://github.com/pydantic/pydantic-ai/pull/2240)
  * Update cohere and MCP, add support for MCP ResourceLink returned from tools by [@medaminezghal](https://github.com/medaminezghal) in [#2094](https://github.com/pydantic/pydantic-ai/pull/2094)
  * Ignore empty text alongside tool calls when streaming from Ollama by [@DouweM](https://github.com/DouweM) in [#2286](https://github.com/pydantic/pydantic-ai/pull/2286)
  * Ignore leading whitespace when streaming text, fixing run_stream + Ollama + Qwen3 by [@DouweM](https://github.com/DouweM) in [#2294](https://github.com/pydantic/pydantic-ai/pull/2294)
  * Fix AG-UI parallel tool calls by [@DouweM](https://github.com/DouweM) in [#2301](https://github.com/pydantic/pydantic-ai/pull/2301)
  * Fix initial tool call args not being streamed with AG-UI by [@DouweM](https://github.com/DouweM) in [#2303](https://github.com/pydantic/pydantic-ai/pull/2303)
  * Handle `None` `created` timestamp coming from OpenRouter API by [@R0boji](https://github.com/R0boji) in [#2247](https://github.com/pydantic/pydantic-ai/pull/2247)
  * Update MCP docs to show you can pass ssl options via the http_client arg by [@assadyousuf](https://github.com/assadyousuf) in [#2214](https://github.com/pydantic/pydantic-ai/pull/2214)
  * Include ThinkingPart in messages.md API documentation graph by [@lfloeer](https://github.com/lfloeer) in [#2299](https://github.com/pydantic/pydantic-ai/pull/2299)


#### New Contributors
  * [@R0boji](https://github.com/R0boji) made their first contribution in [#2247](https://github.com/pydantic/pydantic-ai/pull/2247)
  * [@AntSan813](https://github.com/AntSan813) made their first contribution in [#2240](https://github.com/pydantic/pydantic-ai/pull/2240)
  * [@joshualipman123](https://github.com/joshualipman123) made their first contribution in [#2277](https://github.com/pydantic/pydantic-ai/pull/2277)
  * [@dprov](https://github.com/dprov) made their first contribution in [#2270](https://github.com/pydantic/pydantic-ai/pull/2270)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.6...v0.4.7).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.7).
### v0.4.6 (2025-07-23)
#### What's Changed
  * Enable URL and binary PDF for Mistral by [@pintaf](https://github.com/pintaf) in [#2267](https://github.com/pydantic/pydantic-ai/pull/2267)
  * Fix pydantic-evals panel rendering with evaluators by [@dmontagu](https://github.com/dmontagu) in [#2274](https://github.com/pydantic/pydantic-ai/pull/2274)
  * Fix mp3 handling by [@dmontagu](https://github.com/dmontagu) in [#2279](https://github.com/pydantic/pydantic-ai/pull/2279)
  * Handle built-in tool errors better in tool registration by [@fswair](https://github.com/fswair) in [#2252](https://github.com/pydantic/pydantic-ai/pull/2252)
  * fix: use `FileUrl.format` to find the extension by [@Kludex](https://github.com/Kludex) in [#2280](https://github.com/pydantic/pydantic-ai/pull/2280)
  * Correct code snippet for native output by [@minhduc0711](https://github.com/minhduc0711) in [#2271](https://github.com/pydantic/pydantic-ai/pull/2271)
  * chore: simplify output function call with model retry by [@bitnahian](https://github.com/bitnahian) in [#2273](https://github.com/pydantic/pydantic-ai/pull/2273)
  * Reduce duplication between StreamedRunResult and AgentStream by [@DouweM](https://github.com/DouweM) in [#2275](https://github.com/pydantic/pydantic-ai/pull/2275)
  * chore: add `CLAUDE.md` by [@Kludex](https://github.com/Kludex) in [#2281](https://github.com/pydantic/pydantic-ai/pull/2281)
  * Speed up function `_estimate_string_tokens` by [@misrasaurabh1](https://github.com/misrasaurabh1) in [#2156](https://github.com/pydantic/pydantic-ai/pull/2156)


#### New Contributors
  * [@minhduc0711](https://github.com/minhduc0711) made their first contribution in [#2271](https://github.com/pydantic/pydantic-ai/pull/2271)
  * [@pintaf](https://github.com/pintaf) made their first contribution in [#2267](https://github.com/pydantic/pydantic-ai/pull/2267)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.5...v0.4.6).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.6).
### v0.4.5 (2025-07-22)
#### What's Changed
  * Add `async with self` in `agent_to_a2a` by [@Kludex](https://github.com/Kludex) in [#2266](https://github.com/pydantic/pydantic-ai/pull/2266)
  * Fix include_content not working as expected by [@adtyavrdhn](https://github.com/adtyavrdhn) in [#2206](https://github.com/pydantic/pydantic-ai/pull/2206)
  * Support streamable HTTP in mcp-run-python by [@Kigstn](https://github.com/Kigstn) in [#2230](https://github.com/pydantic/pydantic-ai/pull/2230)
  * change `format_as_xml` defaults by [@samuelcolvin](https://github.com/samuelcolvin) in [#2228](https://github.com/pydantic/pydantic-ai/pull/2228)
  * Fix LLMJudge input handling to preserve BinaryContent as separate message part instead of stringifying by [@adtyavrdhn](https://github.com/adtyavrdhn) in [#2173](https://github.com/pydantic/pydantic-ai/pull/2173)
  * validate OpenAI responses by [@samuelcolvin](https://github.com/samuelcolvin) in [#2226](https://github.com/pydantic/pydantic-ai/pull/2226)
  * Remove duplicate field on GeminiModelSettings by [@strawgate](https://github.com/strawgate) in [#2269](https://github.com/pydantic/pydantic-ai/pull/2269)
  * Fix AG-UI shared state example by [@stevenh](https://github.com/stevenh) in [#2272](https://github.com/pydantic/pydantic-ai/pull/2272)


#### New Contributors
  * [@Kigstn](https://github.com/Kigstn) made their first contribution in [#2230](https://github.com/pydantic/pydantic-ai/pull/2230)
  * [@strawgate](https://github.com/strawgate) made their first contribution in [#2269](https://github.com/pydantic/pydantic-ai/pull/2269)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.4...v0.4.5).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.5).
### v0.4.4 (2025-07-18)
#### What's Changed
  * Add Toolsets and Deferred Tools by [@DouweM](https://github.com/DouweM) in [#2024](https://github.com/pydantic/pydantic-ai/pull/2024)
  * Support AG-UI protocol for frontend-agent communication by [@stevenh](https://github.com/stevenh) in [#2223](https://github.com/pydantic/pydantic-ai/pull/2223)
  * Add identifier field to BinaryContent class by [@GDaamn](https://github.com/GDaamn) in [#2231](https://github.com/pydantic/pydantic-ai/pull/2231)
  * Add OpenAI models o1-pro, o3-pro, o3-deep-research, computer-use by [@zachmayer](https://github.com/zachmayer) in [#2234](https://github.com/pydantic/pydantic-ai/pull/2234)
  * Add grok-4 and groq kimi-k2 models by [@zachmayer](https://github.com/zachmayer) in [#2235](https://github.com/pydantic/pydantic-ai/pull/2235)
  * Remove old Google models by [@DouweM](https://github.com/DouweM) in [#2220](https://github.com/pydantic/pydantic-ai/pull/2220)
  * Change clai default model to gpt-4.1 by [@samuelcolvin](https://github.com/samuelcolvin) in [#2227](https://github.com/pydantic/pydantic-ai/pull/2227)
  * Fix VertexAI Empty Model Parts Error by [@caesarnine](https://github.com/caesarnine) in [#2203](https://github.com/pydantic/pydantic-ai/pull/2203)
  * Remove incorrect tool call id from OpenAI tool call delta by [@naveen-corpusant](https://github.com/naveen-corpusant) in [#2210](https://github.com/pydantic/pydantic-ai/pull/2210)
  * Speed up method `AgentRunResult._set_output_tool_return` by 18798% by [@misrasaurabh1](https://github.com/misrasaurabh1) in [#2196](https://github.com/pydantic/pydantic-ai/pull/2196)
  * Speed up method `Usage.opentelemetry_attributes` by 85% by [@misrasaurabh1](https://github.com/misrasaurabh1) in [#2198](https://github.com/pydantic/pydantic-ai/pull/2198)
  * Nicer errors under the capture_run_messages context by [@alonme](https://github.com/alonme) in [#2219](https://github.com/pydantic/pydantic-ai/pull/2219)


#### New Contributors
  * [@naveen-corpusant](https://github.com/naveen-corpusant) made their first contribution in [#2210](https://github.com/pydantic/pydantic-ai/pull/2210)
  * [@caesarnine](https://github.com/caesarnine) made their first contribution in [#2203](https://github.com/pydantic/pydantic-ai/pull/2203)
  * [@GSemikozov](https://github.com/GSemikozov) made their first contribution in [#2193](https://github.com/pydantic/pydantic-ai/pull/2193)
  * [@alonme](https://github.com/alonme) made their first contribution in [#2219](https://github.com/pydantic/pydantic-ai/pull/2219)
  * [@GDaamn](https://github.com/GDaamn) made their first contribution in [#2231](https://github.com/pydantic/pydantic-ai/pull/2231)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.3...v0.4.4).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.4).
### v0.4.3 (2025-07-16)
#### What's Changed
  * Include content.1571 by [@adtyavrdhn](https://github.com/adtyavrdhn) in [#2180](https://github.com/pydantic/pydantic-ai/pull/2180)
  * `duckduckgo-search` is renamed to `ddgs` by [@basnijholt](https://github.com/basnijholt) in [#2172](https://github.com/pydantic/pydantic-ai/pull/2172)
  * Add base64 encoding to `tool_return_ta` by [@adtyavrdhn](https://github.com/adtyavrdhn) in [#2186](https://github.com/pydantic/pydantic-ai/pull/2186)
  * Bugfix: avoid race condition when refreshing google token by [@JadHADDAD92](https://github.com/JadHADDAD92) in [#2100](https://github.com/pydantic/pydantic-ai/pull/2100)
  * feat: Add output function tracing by [@bitnahian](https://github.com/bitnahian) in [#2191](https://github.com/pydantic/pydantic-ai/pull/2191)
  * Add Hugging Face as a provider by [@hanouticelina](https://github.com/hanouticelina) in [#1911](https://github.com/pydantic/pydantic-ai/pull/1911)


#### New Contributors
  * [@mmabrouk](https://github.com/mmabrouk) made their first contribution in [#2192](https://github.com/pydantic/pydantic-ai/pull/2192)
  * [@basnijholt](https://github.com/basnijholt) made their first contribution in [#2172](https://github.com/pydantic/pydantic-ai/pull/2172)
  * [@JadHADDAD92](https://github.com/JadHADDAD92) made their first contribution in [#2100](https://github.com/pydantic/pydantic-ai/pull/2100)
  * [@bitnahian](https://github.com/bitnahian) made their first contribution in [#2191](https://github.com/pydantic/pydantic-ai/pull/2191)
  * [@hanouticelina](https://github.com/hanouticelina) made their first contribution in [#1911](https://github.com/pydantic/pydantic-ai/pull/1911)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.2...v0.4.3).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.3).
### v0.4.2 (2025-07-10)
#### What's Changed
  * Let model `settings` be passed to model classes by [@svilupp](https://github.com/svilupp) in [#2136](https://github.com/pydantic/pydantic-ai/pull/2136)
  * Add `StructuredDict` for structured outputs with custom JSON schema by [@fswair](https://github.com/fswair) in [#2157](https://github.com/pydantic/pydantic-ai/pull/2157)
  * Handle DeepSeek reasoning_content in streamed responses by [@tarruda](https://github.com/tarruda) in [#2174](https://github.com/pydantic/pydantic-ai/pull/2174)
  * Drop FastA2A from PydanticAI repository by [@Kludex](https://github.com/Kludex) in [#2171](https://github.com/pydantic/pydantic-ai/pull/2171)
  * Fix type annotations for `Agent.iter()` by [@erosennin](https://github.com/erosennin) in [#2168](https://github.com/pydantic/pydantic-ai/pull/2168)
  * Fix chat-app example doc - python code appear twice by [@itayB](https://github.com/itayB) in [#2169](https://github.com/pydantic/pydantic-ai/pull/2169)
  * Speed up function `_ensure_decodeable` by 634% by [@misrasaurabh1](https://github.com/misrasaurabh1) in [#2155](https://github.com/pydantic/pydantic-ai/pull/2155)


#### New Contributors
  * [@misrasaurabh1](https://github.com/misrasaurabh1) made their first contribution in [#2155](https://github.com/pydantic/pydantic-ai/pull/2155)
  * [@erosennin](https://github.com/erosennin) made their first contribution in [#2168](https://github.com/pydantic/pydantic-ai/pull/2168)
  * [@itayB](https://github.com/itayB) made their first contribution in [#2169](https://github.com/pydantic/pydantic-ai/pull/2169)
  * [@tarruda](https://github.com/tarruda) made their first contribution in [#2174](https://github.com/pydantic/pydantic-ai/pull/2174)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.1...v0.4.2).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.2).
### v0.4.1 (2025-07-08)
#### What's Changed
  * Support evaluating sync tasks by [@dmontagu](https://github.com/dmontagu) in [#2150](https://github.com/pydantic/pydantic-ai/pull/2150)
  * Upgrade a2a to spec v0.2.5 by [@physicsrob](https://github.com/physicsrob) in [#2144](https://github.com/pydantic/pydantic-ai/pull/2144)
  * Drop FastA2A as PydanticAI dependency by [@Kludex](https://github.com/Kludex) in [#2164](https://github.com/pydantic/pydantic-ai/pull/2164)


#### New Contributors
  * [@physicsrob](https://github.com/physicsrob) made their first contribution in [#2144](https://github.com/pydantic/pydantic-ai/pull/2144)


[](https://github.com/pydantic/pydantic-ai/compare/v0.4.0...v0.4.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.1).
### v0.4.0 (2025-07-08)
#### What's Changed
  * BREAKING CHANGE: Make `EvaluationReport` and `ReportCase` into generic dataclasses by [@dmontagu](https://github.com/dmontagu) in [#1799](https://github.com/pydantic/pydantic-ai/pull/1799)
  * Make `ToolDefinition.description` optional and fix Bedrock description handling by [@dmontagu](https://github.com/dmontagu) in [#1507](https://github.com/pydantic/pydantic-ai/pull/1507)
  * Add all audio types supported by Gemini to AudioUrl by [@ChenghaoMou](https://github.com/ChenghaoMou) in [#2151](https://github.com/pydantic/pydantic-ai/pull/2151)
  * Improve number_to_datetime performance by building TypeAdapter only once by [@DouweM](https://github.com/DouweM) in [#2153](https://github.com/pydantic/pydantic-ai/pull/2153)
  * Retain defaults in non-strict openai schemas by [@dmontagu](https://github.com/dmontagu) in [#1519](https://github.com/pydantic/pydantic-ai/pull/1519)


[](https://github.com/pydantic/pydantic-ai/compare/v0.3.7...v0.4.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.4.0).
### v0.3.7 (2025-07-07)
#### What's Changed
  * Make `AgentStream.stream_output` (available inside `agent.iter`) stream validated output data instead of raising validation errors by [@DouweM](https://github.com/DouweM) in [#2134](https://github.com/pydantic/pydantic-ai/pull/2134)
  * Add `model_request_stream_sync` to direct API by [@hewliyang](https://github.com/hewliyang) in [#2116](https://github.com/pydantic/pydantic-ai/pull/2116)
  * Add GitHub Models provider by [@sgoedecke](https://github.com/sgoedecke) in [#2114](https://github.com/pydantic/pydantic-ai/pull/2114)
  * Added support for google specific arguments for video analysis by [@Sumered](https://github.com/Sumered) in [#2110](https://github.com/pydantic/pydantic-ai/pull/2110)
  * Implemented a convenient way to use ACI.dev Tools in PydanticAI by [@Kamal-Moha](https://github.com/Kamal-Moha) in [#2093](https://github.com/pydantic/pydantic-ai/pull/2093)
  * Fix list rendering in documentation by [@Viicos](https://github.com/Viicos) in [#2145](https://github.com/pydantic/pydantic-ai/pull/2145)
  * Raise consistent deprecation warnings by [@Viicos](https://github.com/Viicos) in [#2148](https://github.com/pydantic/pydantic-ai/pull/2148)
  * Move docstring warning of model settings as a comment by [@Viicos](https://github.com/Viicos) in [#2146](https://github.com/pydantic/pydantic-ai/pull/2146)


#### New Contributors
  * [@hewliyang](https://github.com/hewliyang) made their first contribution in [#2116](https://github.com/pydantic/pydantic-ai/pull/2116)
  * [@sgoedecke](https://github.com/sgoedecke) made their first contribution in [#2114](https://github.com/pydantic/pydantic-ai/pull/2114)
  * [@Kamal-Moha](https://github.com/Kamal-Moha) made their first contribution in [#2093](https://github.com/pydantic/pydantic-ai/pull/2093)
  * [@Sumered](https://github.com/Sumered) made their first contribution in [#2110](https://github.com/pydantic/pydantic-ai/pull/2110)


[](https://github.com/pydantic/pydantic-ai/compare/v0.3.6...v0.3.7).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.3.7).
### v0.3.6 (2025-07-04)
#### What's Changed
  * Deprecate `{FunctionToolCallEvent,FunctionToolResultEvent}.call_id` in favor of `tool_call_id` by [@proever](https://github.com/proever) in [#2028](https://github.com/pydantic/pydantic-ai/pull/2028)
  * Indicate to the model that a `RetryPromptPart` not tied to a tool call contains validation feedback rather than a user message by [@hovi](https://github.com/hovi) in [#2008](https://github.com/pydantic/pydantic-ai/pull/2008)
  * Update starlette subdomain in docs by [@alDuncanson](https://github.com/alDuncanson) in [#2099](https://github.com/pydantic/pydantic-ai/pull/2099)
  * Update client.md - Typo by [@kauabh](https://github.com/kauabh) in [#2105](https://github.com/pydantic/pydantic-ai/pull/2105)
  * Add support for predicted outputs in OpenAIModelSettings by [@webholics](https://github.com/webholics) in [#2106](https://github.com/pydantic/pydantic-ai/pull/2106)
  * Record tool response in tool run span by [@alexmojaki](https://github.com/alexmojaki) in [#2109](https://github.com/pydantic/pydantic-ai/pull/2109)
  * Use contextvars for agent overriding, rather than a local attribute by [@dmontagu](https://github.com/dmontagu) in [#2118](https://github.com/pydantic/pydantic-ai/pull/2118)
  * Fix model parameters not being customized in fallback model request stream by [@almeidaalajoel](https://github.com/almeidaalajoel) in [#2120](https://github.com/pydantic/pydantic-ai/pull/2120)
  * simplify weather example by [@samuelcolvin](https://github.com/samuelcolvin) in [#2129](https://github.com/pydantic/pydantic-ai/pull/2129)


#### New Contributors
  * [@alDuncanson](https://github.com/alDuncanson) made their first contribution in [#2099](https://github.com/pydantic/pydantic-ai/pull/2099)
  * [@webholics](https://github.com/webholics) made their first contribution in [#2106](https://github.com/pydantic/pydantic-ai/pull/2106)
  * [@almeidaalajoel](https://github.com/almeidaalajoel) made their first contribution in [#2120](https://github.com/pydantic/pydantic-ai/pull/2120)


[](https://github.com/pydantic/pydantic-ai/compare/v0.3.5...v0.3.6).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.3.6).
### v0.3.5 (2025-06-30)
#### What's Changed
  * Add progress bar on evaluate by [@davide-andreoli](https://github.com/davide-andreoli) in [#1871](https://github.com/pydantic/pydantic-ai/pull/1871)
  * Fix deprecation warning under Pydantic 2.11 by [@medaminezghal](https://github.com/medaminezghal) in [#2076](https://github.com/pydantic/pydantic-ai/pull/2076)
  * fix: async fixtures in conftest.py by [@stevenh](https://github.com/stevenh) in [#2068](https://github.com/pydantic/pydantic-ai/pull/2068)
  * fix: docs examples python version in tests by [@stevenh](https://github.com/stevenh) in [#2069](https://github.com/pydantic/pydantic-ai/pull/2069)
  * Set 'us-central1' by default on `GoogleProvider` by [@Kludex](https://github.com/Kludex) in [#2031](https://github.com/pydantic/pydantic-ai/pull/2031)
  * Move `ThinkingPart` to preceed `TextPart` in `OpenAIResponsesModel` by [@Kludex](https://github.com/Kludex) in [#2043](https://github.com/pydantic/pydantic-ai/pull/2043)
  * Fix deprecated kwargs validation to prevent silent failures by [@svilupp](https://github.com/svilupp) in [#2047](https://github.com/pydantic/pydantic-ai/pull/2047)
  * Support strict mode in NativeOutput by [@severinh](https://github.com/severinh) in [#2084](https://github.com/pydantic/pydantic-ai/pull/2084)
  * Let tools return ToolReturn to pass additional content to model, or attach metadata that's not passed to the model by [@Wh1isper](https://github.com/Wh1isper) in [#2060](https://github.com/pydantic/pydantic-ai/pull/2060)
  * Add ability to include snippets in docs with inline-named sections for fragments and highlighting by [@dmontagu](https://github.com/dmontagu) in [#2088](https://github.com/pydantic/pydantic-ai/pull/2088)
  * Add Slack Lead Qualifier example by [@DouweM](https://github.com/DouweM) in [#2079](https://github.com/pydantic/pydantic-ai/pull/2079)


#### New Contributors
  * [@medaminezghal](https://github.com/medaminezghal) made their first contribution in [#2076](https://github.com/pydantic/pydantic-ai/pull/2076)
  * [@svilupp](https://github.com/svilupp) made their first contribution in [#2047](https://github.com/pydantic/pydantic-ai/pull/2047)
  * [@severinh](https://github.com/severinh) made their first contribution in [#2084](https://github.com/pydantic/pydantic-ai/pull/2084)


[](https://github.com/pydantic/pydantic-ai/compare/v0.3.4...v0.3.5).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.3.5).
### v0.3.4 (2025-06-26)
#### What's Changed
  * Scrubbing sensitive content by [@adtyavrdhn](https://github.com/adtyavrdhn) in [#2014](https://github.com/pydantic/pydantic-ai/pull/2014)
  * fix(anthropic): send `ThinkingPart` back when using tool calls by [@Kludex](https://github.com/Kludex) in [#2072](https://github.com/pydantic/pydantic-ai/pull/2072)


#### New Contributors
  * [@adtyavrdhn](https://github.com/adtyavrdhn) made their first contribution in [#2014](https://github.com/pydantic/pydantic-ai/pull/2014)


[](https://github.com/pydantic/pydantic-ai/compare/v0.3.3...v0.3.4).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.3.4).
### v0.3.3 (2025-06-24)
#### What's Changed
  * Support `NativeOutput` and `PromptedOutput` modes in addition to `ToolOutput` by [@DouweM](https://github.com/DouweM) in [#1628](https://github.com/pydantic/pydantic-ai/pull/1628)
  * Improve Dynamic Instructions Documentation by [@xflashxx](https://github.com/xflashxx) in [#1819](https://github.com/pydantic/pydantic-ai/pull/1819)
  * docs: add API reference to `UserPromptNode` by [@Kludex](https://github.com/Kludex) in [#2052](https://github.com/pydantic/pydantic-ai/pull/2052)
  * Include additional usage fields from OpenAI-compatible APIs in usage details by [@Wh1isper](https://github.com/Wh1isper) in [#2038](https://github.com/pydantic/pydantic-ai/pull/2038)
  * Fix: Handled and pretty-printed exceptions without exiting the CLI. by [@fswair](https://github.com/fswair) in [#2055](https://github.com/pydantic/pydantic-ai/pull/2055)
  * document alternative otel backends by [@samuelcolvin](https://github.com/samuelcolvin) in [#2062](https://github.com/pydantic/pydantic-ai/pull/2062)
  * note on self-hosting logfire by [@samuelcolvin](https://github.com/samuelcolvin) in [#2063](https://github.com/pydantic/pydantic-ai/pull/2063)
  * Make Edge hashable by [@dmontagu](https://github.com/dmontagu) in [#2064](https://github.com/pydantic/pydantic-ai/pull/2064)


#### New Contributors
  * [@xflashxx](https://github.com/xflashxx) made their first contribution in [#1819](https://github.com/pydantic/pydantic-ai/pull/1819)


[](https://github.com/pydantic/pydantic-ai/compare/v0.3.2...v0.3.3).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.3.3).
### v0.3.2 (2025-06-21)
#### What's Changed
  * Support MCP sampling by [@samuelcolvin](https://github.com/samuelcolvin) in [#1884](https://github.com/pydantic/pydantic-ai/pull/1884)


[](https://github.com/pydantic/pydantic-ai/compare/v0.3.1...v0.3.2).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.3.2).
### v0.3.1 (2025-06-18)
#### What's Changed
  * Update Google models by [@tacoo](https://github.com/tacoo) in [#2010](https://github.com/pydantic/pydantic-ai/pull/2010)
  * fix: update `ThinkingPart` when delta contains `signature` by [@Kludex](https://github.com/Kludex) in [#2012](https://github.com/pydantic/pydantic-ai/pull/2012)


#### New Contributors
  * [@tacoo](https://github.com/tacoo) made their first contribution in [#2010](https://github.com/pydantic/pydantic-ai/pull/2010)
  * [@a-klos](https://github.com/a-klos) made their first contribution in [#2013](https://github.com/pydantic/pydantic-ai/pull/2013)


[](https://github.com/pydantic/pydantic-ai/compare/v0.3.0...v0.3.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.3.1).
### v0.3.0 (2025-06-18)
#### Breaking Changes
See [###1142](https://ai.pydantic.dev/changelog/%5B#1142%5D\(https://github.com/pydantic/pydantic-ai/pull/1142\)) — Adds support for thinking parts.
We now convert the thinking blocks (`"<think>..."</think>"`) in provider specific text parts to PydanticAI `ThinkingPart`s. Also, as part of this release, we made the choice to not send back the `ThinkingPart`s to the provider - the idea is to save costs on behalf of the user. In the future, we intend to add a setting to customize this behavior.
* * *
#### What's Changed
  * Support Thinking part by [@Kludex](https://github.com/Kludex) in [#1142](https://github.com/pydantic/pydantic-ai/pull/1142)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.20...v0.3.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.3.0).
### v0.2.20 (2025-06-18)
#### What's Changed
  * Handle `McpError` from MCP tool calls by [@ppcantidio](https://github.com/ppcantidio) in [#1999](https://github.com/pydantic/pydantic-ai/pull/1999)
  * Add `process_tool_call` hook to MCP servers to modify tool args, metadata, and return value by [@stevenh](https://github.com/stevenh) in [#2000](https://github.com/pydantic/pydantic-ai/pull/2000)
  * Respect `ModelSettings.timeout` in `GoogleModel` by [@DouweM](https://github.com/DouweM) in [#2006](https://github.com/pydantic/pydantic-ai/pull/2006)
  * feat: add `RunContext` support to history processors by [@Wh1isper](https://github.com/Wh1isper) in [#2002](https://github.com/pydantic/pydantic-ai/pull/2002)


#### New Contributors
  * [@ppcantidio](https://github.com/ppcantidio) made their first contribution in [#1999](https://github.com/pydantic/pydantic-ai/pull/1999)
  * [@stevenh](https://github.com/stevenh) made their first contribution in [#2000](https://github.com/pydantic/pydantic-ai/pull/2000)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.19...v0.2.20).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.20).
### v0.2.19 (2025-06-16)
#### What's Changed
  * Proper check if callable is async by [@Kludex](https://github.com/Kludex) in [#1972](https://github.com/pydantic/pydantic-ai/pull/1972)
  * More flexible method infer_provider by [@hovi](https://github.com/hovi) in [#1945](https://github.com/pydantic/pydantic-ai/pull/1945)
  * Ignore dynamic instructions returning an empty string by [@giacbrd](https://github.com/giacbrd) in [#1961](https://github.com/pydantic/pydantic-ai/pull/1961)
  * uprev Pyodide to 0.27.6 by [@samuelcolvin](https://github.com/samuelcolvin) in [#1944](https://github.com/pydantic/pydantic-ai/pull/1944)
  * refactor: updated tools doc with function naming: roll_die → roll_dice by [@yamanahlawat](https://github.com/yamanahlawat) in [#1986](https://github.com/pydantic/pydantic-ai/pull/1986)
  * Set Anthropic `max_tokens` to 4096 by default by [@Kludex](https://github.com/Kludex) in [#1994](https://github.com/pydantic/pydantic-ai/pull/1994)
  * feat: add `history_processors` parameter to `Agent` for message processing by [@Kludex](https://github.com/Kludex) in [#1970](https://github.com/pydantic/pydantic-ai/pull/1970)
  * Yield events for unknown tool calls by [@proever](https://github.com/proever) in [#1960](https://github.com/pydantic/pydantic-ai/pull/1960)
  * Always set a parameters schema on a Gemini function declaration, even when it's an empty object by [@DouweM](https://github.com/DouweM) in [#1998](https://github.com/pydantic/pydantic-ai/pull/1998)


#### New Contributors
  * [@hovi](https://github.com/hovi) made their first contribution in [#1945](https://github.com/pydantic/pydantic-ai/pull/1945)
  * [@giacbrd](https://github.com/giacbrd) made their first contribution in [#1961](https://github.com/pydantic/pydantic-ai/pull/1961)
  * [@yamanahlawat](https://github.com/yamanahlawat) made their first contribution in [#1986](https://github.com/pydantic/pydantic-ai/pull/1986)
  * [@proever](https://github.com/proever) made their first contribution in [#1960](https://github.com/pydantic/pydantic-ai/pull/1960)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.18...v0.2.19).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.19).
### v0.2.18 (2025-06-13)
#### What's Changed
  * Reuse last request from message history if no user prompt was provided by [@DouweM](https://github.com/DouweM) in [#1955](https://github.com/pydantic/pydantic-ai/pull/1955)
  * Prevent Anthropic API errors from empty message content by [@mike-luabase](https://github.com/mike-luabase) in [#1934](https://github.com/pydantic/pydantic-ai/pull/1934)
  * Add MCP Streamable HTTP implementation by [@Kludex](https://github.com/Kludex) in [#1965](https://github.com/pydantic/pydantic-ai/pull/1965)
  * feat(openai): expose Responses API id as vendor_id by [@sarunas-zebra](https://github.com/sarunas-zebra) in [#1949](https://github.com/pydantic/pydantic-ai/pull/1949)
  * Use `GoogleModel` instead of `GeminiModel` on inference by [@Kludex](https://github.com/Kludex) in [#1881](https://github.com/pydantic/pydantic-ai/pull/1881)


#### New Contributors
  * [@sarunas-zebra](https://github.com/sarunas-zebra) made their first contribution in [#1949](https://github.com/pydantic/pydantic-ai/pull/1949)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.17...v0.2.18).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.18).
### v0.2.17 (2025-06-12)
#### What's Changed
  * Add token usage metrics to `InstrumentedModel` by [@alexmojaki](https://github.com/alexmojaki) in [#1898](https://github.com/pydantic/pydantic-ai/pull/1898)
  * Add `service_tier` to `OpenAIModelSettings` by [@empezarcero](https://github.com/empezarcero) in [#1923](https://github.com/pydantic/pydantic-ai/pull/1923)
  * Allow users to supply `httpx.AsyncClient` in `MCPServerHTTP` by [@mpfaffenberger](https://github.com/mpfaffenberger) in [#1925](https://github.com/pydantic/pydantic-ai/pull/1925)
  * Don't send sampling settings like `temperature` and `top_p` to OpenAI reasoning models by [@DouweM](https://github.com/DouweM) in [#1956](https://github.com/pydantic/pydantic-ai/pull/1956)
  * Support field `fileData` (direct file URL) for `GeminiModel` and `GoogleModel` by [@vricciardulli](https://github.com/vricciardulli) in [#1136](https://github.com/pydantic/pydantic-ai/pull/1136)


#### New Contributors
  * [@Deriverx2](https://github.com/Deriverx2) made their first contribution in [#1946](https://github.com/pydantic/pydantic-ai/pull/1946)
  * [@amihalik](https://github.com/amihalik) made their first contribution in [#1912](https://github.com/pydantic/pydantic-ai/pull/1912)
  * [@empezarcero](https://github.com/empezarcero) made their first contribution in [#1923](https://github.com/pydantic/pydantic-ai/pull/1923)
  * [@mpfaffenberger](https://github.com/mpfaffenberger) made their first contribution in [#1925](https://github.com/pydantic/pydantic-ai/pull/1925)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.16...v0.2.17).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.17).
### v0.2.16 (2025-06-08)
#### What's Changed
  * Stop sharing tool retry count across all runs of the same agent by [@dmontagu](https://github.com/dmontagu) in [#1918](https://github.com/pydantic/pydantic-ai/pull/1918)
  * Add support for `HerokuProvider` by [@Kludex](https://github.com/Kludex) in [#1933](https://github.com/pydantic/pydantic-ai/pull/1933)
  * Add `stop_sequences` to Google models by [@Kludex](https://github.com/Kludex) in [#1935](https://github.com/pydantic/pydantic-ai/pull/1935)
  * Handle model response timestamps in milliseconds rather than seconds by [@DouweM](https://github.com/DouweM) in [#1937](https://github.com/pydantic/pydantic-ai/pull/1937)
  * Add convenience method to use LangChain community tools by [@matthewfranglen](https://github.com/matthewfranglen) in [#1832](https://github.com/pydantic/pydantic-ai/pull/1832)
  * Infer the right type on output when callables are provided by [@Kludex](https://github.com/Kludex) in [#1931](https://github.com/pydantic/pydantic-ai/pull/1931)
  * Revert pyodide to a version that doesn't print to stdout when installing packages by [@samuelcolvin](https://github.com/samuelcolvin) in [#1930](https://github.com/pydantic/pydantic-ai/pull/1930)


#### New Contributors
  * [@matthewfranglen](https://github.com/matthewfranglen) made their first contribution in [#1832](https://github.com/pydantic/pydantic-ai/pull/1832)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.15...v0.2.16).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.16).
### v0.2.15 (2025-06-05)
#### What's Changed
  * Allow empty messages when using `GoogleModel` by [@Kludex](https://github.com/Kludex) in [#1922](https://github.com/pydantic/pydantic-ai/pull/1922)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.14...v0.2.15).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.15).
### v0.2.14 (2025-06-03)
#### What's Changed
  * Temporarily revert "Add support for MCP's Streamable HTTP transport (###1716)" by [@DouweM](https://github.com/DouweM) in [#1903](https://github.com/pydantic/pydantic-ai/pull/1903)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.13...v0.2.14).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.14).
### v0.2.13 (2025-06-03)
#### What's Changed
  * Make parallel_evaluation_example more robust by [@DouweM](https://github.com/DouweM) in [#1861](https://github.com/pydantic/pydantic-ai/pull/1861)
  * Ensure tool call parts with custom argument model validation errors are serializable by [@DouweM](https://github.com/DouweM) in [#1862](https://github.com/pydantic/pydantic-ai/pull/1862)
  * Add option to pass expected output to LLMJudge by [@hinnefe2](https://github.com/hinnefe2) in [#1853](https://github.com/pydantic/pydantic-ai/pull/1853)
  * Fix unexpected part error when Google model returns empty text delta by [@Blue9](https://github.com/Blue9) in [#1875](https://github.com/pydantic/pydantic-ai/pull/1875)
  * Generate ToolCallPart.tool_call_id when OpenAI-compatible API returned an empty string by [@DouweM](https://github.com/DouweM) in [#1892](https://github.com/pydantic/pydantic-ai/pull/1892)
  * docs: Fix import for BaseModel in graph example code by [@briann](https://github.com/briann) in [#1894](https://github.com/pydantic/pydantic-ai/pull/1894)
  * Add new _GeminiThoughtPart to adhere to Gemini response by [@dnouri](https://github.com/dnouri) in [#1897](https://github.com/pydantic/pydantic-ai/pull/1897)


#### New Contributors
  * [@hinnefe2](https://github.com/hinnefe2) made their first contribution in [#1853](https://github.com/pydantic/pydantic-ai/pull/1853)
  * [@Blue9](https://github.com/Blue9) made their first contribution in [#1875](https://github.com/pydantic/pydantic-ai/pull/1875)
  * [@briann](https://github.com/briann) made their first contribution in [#1894](https://github.com/pydantic/pydantic-ai/pull/1894)
  * [@dnouri](https://github.com/dnouri) made their first contribution in [#1897](https://github.com/pydantic/pydantic-ai/pull/1897)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.12...v0.2.13).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.13).
### v0.2.12 (2025-05-29)
#### What's Changed
  * Add `vendor_id` and `vendor_details.finish_reason` to Gemini/Google model responses by [@davide-andreoli](https://github.com/davide-andreoli) in [#1800](https://github.com/pydantic/pydantic-ai/pull/1800)
  * Fix units of `sse_read_timeout` `timedelta` by [@alexmojaki](https://github.com/alexmojaki) in [#1843](https://github.com/pydantic/pydantic-ai/pull/1843)
  * Support functions as `output_type`, as well as lists of functions and other types by [@DouweM](https://github.com/DouweM) in [#1785](https://github.com/pydantic/pydantic-ai/pull/1785)
  * Enhance Gemini usage tracking to collect comprehensive token data by [@kiqaps](https://github.com/kiqaps) in [#1752](https://github.com/pydantic/pydantic-ai/pull/1752)
  * docs: add scope when loading credentials from file in google by [@Kludex](https://github.com/Kludex) in [#1850](https://github.com/pydantic/pydantic-ai/pull/1850)
  * Add support for Claude 4 Sonnet and Opus models in Bedrock by [@samtin0x](https://github.com/samtin0x) in [#1838](https://github.com/pydantic/pydantic-ai/pull/1838)
  * Add `ModelProfile` to let model-specific behaviors be configured independent of the model class by [@DouweM](https://github.com/DouweM) in [#1835](https://github.com/pydantic/pydantic-ai/pull/1835)
  * Add new provider classes for Together AI, Fireworks AI, and Grok with automatic model profile selection by [@DouweM](https://github.com/DouweM) in [#1842](https://github.com/pydantic/pydantic-ai/pull/1842)
  * Fix weather agent example with UI by [@vp777](https://github.com/vp777) in [#1851](https://github.com/pydantic/pydantic-ai/pull/1851)


#### New Contributors
  * [@davide-andreoli](https://github.com/davide-andreoli) made their first contribution in [#1800](https://github.com/pydantic/pydantic-ai/pull/1800)
  * [@samtin0x](https://github.com/samtin0x) made their first contribution in [#1838](https://github.com/pydantic/pydantic-ai/pull/1838)
  * [@vp777](https://github.com/vp777) made their first contribution in [#1851](https://github.com/pydantic/pydantic-ai/pull/1851)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.11...v0.2.12).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.12).
### v0.2.11 (2025-05-27)
#### What's Changed
  * Require `mcp>=1.9.0` on the `pydantic-ai-slim[mcp]` extra by [@DouweM](https://github.com/DouweM) in [#1840](https://github.com/pydantic/pydantic-ai/pull/1840)
  * Don't send empty messages to Anthropic by [@oscar-broman](https://github.com/oscar-broman) in [#1027](https://github.com/pydantic/pydantic-ai/pull/1027)


#### New Contributors
  * [@oscar-broman](https://github.com/oscar-broman) made their first contribution in [#1027](https://github.com/pydantic/pydantic-ai/pull/1027)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.10...v0.2.11).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.11).
### v0.2.10 (2025-05-27)
#### What's Changed
  * Update Google models by [@Kludex](https://github.com/Kludex) in [#1829](https://github.com/pydantic/pydantic-ai/pull/1829)
  * Support Claude Sonnet 4 by [@Kludex](https://github.com/Kludex) in [#1824](https://github.com/pydantic/pydantic-ai/pull/1824)
  * Add support for MCP's Streamable HTTP transport by [@BrandonShar](https://github.com/BrandonShar) in [#1716](https://github.com/pydantic/pydantic-ai/pull/1716)
  * Timeout for initializing MCP client by [@alexmojaki](https://github.com/alexmojaki) in [#1833](https://github.com/pydantic/pydantic-ai/pull/1833)


#### New Contributors
  * [@BrandonShar](https://github.com/BrandonShar) made their first contribution in [#1716](https://github.com/pydantic/pydantic-ai/pull/1716)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.9...v0.2.10).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.10).
### v0.2.9 (2025-05-26)
#### What's Changed
  * Cast non-textual responses in `Agent.to_cli` to `str` by [@barp](https://github.com/barp) in [#1823](https://github.com/pydantic/pydantic-ai/pull/1823)
  * Support field `labels` for `GeminiModel` and `GoogleModel` on Vertex AI by [@vricciardulli](https://github.com/vricciardulli) in [#1056](https://github.com/pydantic/pydantic-ai/pull/1056)


#### New Contributors
  * [@barp](https://github.com/barp) made their first contribution in [#1823](https://github.com/pydantic/pydantic-ai/pull/1823)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.8...v0.2.9).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.9).
### v0.2.8 (2025-05-25)
#### What's Changed
  * Improve assertion on Anthropic by [@Kludex](https://github.com/Kludex) in [#1825](https://github.com/pydantic/pydantic-ai/pull/1825)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.7...v0.2.8).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.8).
### v0.2.7 (2025-05-24)
#### What's Changed
  * Support streaming tool calls from models that pass args as None when there are no function parameters by [@DouweM](https://github.com/DouweM) in [#1802](https://github.com/pydantic/pydantic-ai/pull/1802)
  * Stream tool calls and structured output from Anthropic as it's received instead of in one go by [@DouweM](https://github.com/DouweM) in [#1669](https://github.com/pydantic/pydantic-ai/pull/1669)
  * Remove hardcoded `n` parameter from OpenAIModel requests by [@kiqaps](https://github.com/kiqaps) in [#1807](https://github.com/pydantic/pydantic-ai/pull/1807)
  * Add `tool_prefix` option to MCP servers and error on conflicting tool names by [@Wh1isper](https://github.com/Wh1isper) in [#1266](https://github.com/pydantic/pydantic-ai/pull/1266)
  * Allow `RunContext` to not be documented when `require_parameter_descriptions=True` as it's not passed to the model anyway by [@Kevsnz](https://github.com/Kevsnz) in [#1750](https://github.com/pydantic/pydantic-ai/pull/1750)
  * Clean up dataclasses reprs by [@dmontagu](https://github.com/dmontagu) in [#1812](https://github.com/pydantic/pydantic-ai/pull/1812)
  * Addition: Make `prog_name` customizable by [@fswair](https://github.com/fswair) in [#1804](https://github.com/pydantic/pydantic-ai/pull/1804)
  * Use `AsyncBeta` instead of `AsyncAnthropic` by [@Kludex](https://github.com/Kludex) in [#1818](https://github.com/pydantic/pydantic-ai/pull/1818)


#### New Contributors
  * [@kiqaps](https://github.com/kiqaps) made their first contribution in [#1807](https://github.com/pydantic/pydantic-ai/pull/1807)
  * [@Kevsnz](https://github.com/Kevsnz) made their first contribution in [#1750](https://github.com/pydantic/pydantic-ai/pull/1750)
  * [@fswair](https://github.com/fswair) made their first contribution in [#1804](https://github.com/pydantic/pydantic-ai/pull/1804)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.6...v0.2.7).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.7).
### v0.2.6 (2025-05-20)
#### What's Changed
  * Add `prepare_tools` param to Agent class by [@rmaceissoft](https://github.com/rmaceissoft) in [#1474](https://github.com/pydantic/pydantic-ai/pull/1474)
  * fix: remove forgotten print on `GoogleModel` by [@Kludex](https://github.com/Kludex) in [#1780](https://github.com/pydantic/pydantic-ai/pull/1780)
  * fasta2a: be more strict on agent card by [@Kludex](https://github.com/Kludex) in [#1781](https://github.com/pydantic/pydantic-ai/pull/1781)
  * fix: rename `prepare_tools` to `_prepare_tools` by [@Kludex](https://github.com/Kludex) in [#1789](https://github.com/pydantic/pydantic-ai/pull/1789)
  * fix: create prompt history file when using `Agent.to_cli()` by [@Kludex](https://github.com/Kludex) in [#1791](https://github.com/pydantic/pydantic-ai/pull/1791)
  * fix: add `'openrouter'` string to `OpenAIModel` provider param by [@Kludex](https://github.com/Kludex) in [#1792](https://github.com/pydantic/pydantic-ai/pull/1792)


#### New Contributors
  * [@rmaceissoft](https://github.com/rmaceissoft) made their first contribution in [#1474](https://github.com/pydantic/pydantic-ai/pull/1474)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.5...v0.2.6).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.6).
### v0.2.5 (2025-05-20)
#### What's Changed
  * fasta2a: make `capabilities` required on `AgentCard` by [@Kludex](https://github.com/Kludex) in [#1733](https://github.com/pydantic/pydantic-ai/pull/1733)
  * Fix formatting of ints in eval reports by [@dmontagu](https://github.com/dmontagu) in [#1738](https://github.com/pydantic/pydantic-ai/pull/1738)
  * Bugfix: record instructions properly on agent run span when using structured output by [@dmontagu](https://github.com/dmontagu) in [#1740](https://github.com/pydantic/pydantic-ai/pull/1740)
  * Add ability to specify the evaluation name for all provided Evaluators by [@dmontagu](https://github.com/dmontagu) in [#1725](https://github.com/pydantic/pydantic-ai/pull/1725)
  * Add `include_binary_content` flag to `InstrumentationSettings`, rename OTel attribute key from `content` to `binary_content` for `BinaryPart`s by [@alexmojaki](https://github.com/alexmojaki) in [#1739](https://github.com/pydantic/pydantic-ai/pull/1739)
  * Add logprobs to OpenAI model settings and response by [@eliassoares](https://github.com/eliassoares) in [#1238](https://github.com/pydantic/pydantic-ai/pull/1238)
  * Added `vendor_id` to the model response. by [@peterHoburg](https://github.com/peterHoburg) in [#1547](https://github.com/pydantic/pydantic-ai/pull/1547)
  * Fix ImportError when opentelemetry is not installed by [@dmontagu](https://github.com/dmontagu) in [#1773](https://github.com/pydantic/pydantic-ai/pull/1773)
  * Add licenses to all packages. by [@tobiasraabe](https://github.com/tobiasraabe) in [#1775](https://github.com/pydantic/pydantic-ai/pull/1775)
  * Add OpenRouter provider by [@Kludex](https://github.com/Kludex) in [#1778](https://github.com/pydantic/pydantic-ai/pull/1778)
  * Add Google GenAI provider by [@Kludex](https://github.com/Kludex) in [#1751](https://github.com/pydantic/pydantic-ai/pull/1751)


#### New Contributors
  * [@eliassoares](https://github.com/eliassoares) made their first contribution in [#1238](https://github.com/pydantic/pydantic-ai/pull/1238)
  * [@peterHoburg](https://github.com/peterHoburg) made their first contribution in [#1547](https://github.com/pydantic/pydantic-ai/pull/1547)
  * [@iandolge](https://github.com/iandolge) made their first contribution in [#1762](https://github.com/pydantic/pydantic-ai/pull/1762)
  * [@tobiasraabe](https://github.com/tobiasraabe) made their first contribution in [#1775](https://github.com/pydantic/pydantic-ai/pull/1775)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.4...v0.2.5).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.5).
### v0.2.4 (2025-05-14)
#### What's Changed
  * `clai` should not require `OPENAI_API_KEY` by [@samuelcolvin](https://github.com/samuelcolvin) in [#1724](https://github.com/pydantic/pydantic-ai/pull/1724)


#### New Contributors
  * [@chandy](https://github.com/chandy) made their first contribution in [#1727](https://github.com/pydantic/pydantic-ai/pull/1727)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.3...v0.2.4).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.4).
### v0.2.3 (2025-05-13)
#### What's Changed
  * cli: add current path to `sys.path` by [@Kludex](https://github.com/Kludex) in [#1703](https://github.com/pydantic/pydantic-ai/pull/1703)
  * evals: use the correct render object on `include_metadata` and `include_expected_output` by [@lionpeloux](https://github.com/lionpeloux) in [#1700](https://github.com/pydantic/pydantic-ai/pull/1700)
  * Add A2A server by [@Kludex](https://github.com/Kludex) in [#1537](https://github.com/pydantic/pydantic-ai/pull/1537)
  * Allow definition of Model Settings for LLMJudge by [@assadyousuf](https://github.com/assadyousuf) in [#1662](https://github.com/pydantic/pydantic-ai/pull/1662)
  * improve messages coverage by [@samuelcolvin](https://github.com/samuelcolvin) in [#1704](https://github.com/pydantic/pydantic-ai/pull/1704)
  * Add `direct` public API by [@samuelcolvin](https://github.com/samuelcolvin) in [#1599](https://github.com/pydantic/pydantic-ai/pull/1599)
  * Ensure CLI prompt history directory and file exist before usage by [@zboyles](https://github.com/zboyles) in [#1707](https://github.com/pydantic/pydantic-ai/pull/1707)


#### New Contributors
  * [@lionpeloux](https://github.com/lionpeloux) made their first contribution in [#1700](https://github.com/pydantic/pydantic-ai/pull/1700)
  * [@assadyousuf](https://github.com/assadyousuf) made their first contribution in [#1662](https://github.com/pydantic/pydantic-ai/pull/1662)
  * [@zboyles](https://github.com/zboyles) made their first contribution in [#1707](https://github.com/pydantic/pydantic-ai/pull/1707)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.2...v0.2.3).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.3).
### v0.2.2 (2025-05-13)
#### What's Changed
  * Add `to_cli()` method to `Agent` by [@AndrewHannigan](https://github.com/AndrewHannigan) in [#1642](https://github.com/pydantic/pydantic-ai/pull/1642)


#### New Contributors
  * [@AndrewHannigan](https://github.com/AndrewHannigan) made their first contribution in [#1642](https://github.com/pydantic/pydantic-ai/pull/1642)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.1...v0.2.2).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.2).
### v0.2.1 (2025-05-13)
#### What's Changed
  * Add AWS Profile Feature by [@prescod](https://github.com/prescod) in [#1634](https://github.com/pydantic/pydantic-ai/pull/1634)
  * Change Agent.is_?_node() to use TypeIs instead by [@chasewalden](https://github.com/chasewalden) in [#1622](https://github.com/pydantic/pydantic-ai/pull/1622)
  * Add newline separation between Anthropic system prompts by [@timesler](https://github.com/timesler) in [#1638](https://github.com/pydantic/pydantic-ai/pull/1638)
  * cli: store prompt and config under `~/.pydantic-ai` by [@Kludex](https://github.com/Kludex) in [#1701](https://github.com/pydantic/pydantic-ai/pull/1701)
  * otel: send `BinaryContent` information by [@Kludex](https://github.com/Kludex) in [#1603](https://github.com/pydantic/pydantic-ai/pull/1603)


#### New Contributors
  * [@prescod](https://github.com/prescod) made their first contribution in [#1634](https://github.com/pydantic/pydantic-ai/pull/1634)
  * [@chasewalden](https://github.com/chasewalden) made their first contribution in [#1622](https://github.com/pydantic/pydantic-ai/pull/1622)


[](https://github.com/pydantic/pydantic-ai/compare/v0.2.0...v0.2.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.1).
### v0.2.0 (2025-05-12)
#### Breaking Changes
See [###1647](https://ai.pydantic.dev/changelog/%5B#1647%5D\(https://github.com/pydantic/pydantic-ai/pull/1647\)) — usage makes sense as part of `ModelResponse`, and could be really useful in "messages" (really a sequence of requests and response). In this PR:
  * Adds `usage` to `ModelResponse` (field has a default factory of `Usage()` so it'll work to load data that doesn't have usage)
  * changes the return type of `Model.request` to just `ModelResponse` instead of `tuple[ModelResponse, Usage]`


#### Other Changes
  * Add support for non-string enums in Gemini by [@zaidhaan](https://github.com/zaidhaan) in [#1564](https://github.com/pydantic/pydantic-ai/pull/1564)
  * Fix parallel tool calls on Bedrock with Nova and Claude models by [@pandersen-uncharted](https://github.com/pandersen-uncharted) in [#1656](https://github.com/pydantic/pydantic-ai/pull/1656)
  * Fix Anthropic streaming by [@samuelcolvin](https://github.com/samuelcolvin) in [#1686](https://github.com/pydantic/pydantic-ai/pull/1686)
  * Fix serializability of ModelRequestParameters by [@dmontagu](https://github.com/dmontagu) in [#1690](https://github.com/pydantic/pydantic-ai/pull/1690)
  * Stop incorrectly treating side-by-side JSON schema $refs as recursion by [@DouweM](https://github.com/DouweM) in [#1697](https://github.com/pydantic/pydantic-ai/pull/1697)
  * Set `ToolCallPartDelta.tool_call_id` when known from previous delta by [@DouweM](https://github.com/DouweM) in [#1694](https://github.com/pydantic/pydantic-ai/pull/1694)


#### New Contributors
  * [@zaidhaan](https://github.com/zaidhaan) made their first contribution in [#1564](https://github.com/pydantic/pydantic-ai/pull/1564)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.11...v0.2.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.2.0).
### v0.1.11 (2025-05-10)
#### What's Changed
  * Switch CLI to `clai` by [@samuelcolvin](https://github.com/samuelcolvin) in [#1504](https://github.com/pydantic/pydantic-ai/pull/1504)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.10...v0.1.11).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.11).
### v0.1.10 (2025-05-06)
#### What's Changed
  * Allow setting `temperature` to 0 on `BedrockConverseModel` by [@pandersen-uncharted](https://github.com/pandersen-uncharted) in [#1631](https://github.com/pydantic/pydantic-ai/pull/1631)
  * Add `extra_headers` to `ModelSettings` by [@ramanan-ravi](https://github.com/ramanan-ravi) in [#1644](https://github.com/pydantic/pydantic-ai/pull/1644)
  * Add `thinking_config` to `GeminiModel` by [@Kludex](https://github.com/Kludex) in [#1609](https://github.com/pydantic/pydantic-ai/pull/1609)


#### New Contributors
  * [@pandersen-uncharted](https://github.com/pandersen-uncharted) made their first contribution in [#1631](https://github.com/pydantic/pydantic-ai/pull/1631)
  * [@ramanan-ravi](https://github.com/ramanan-ravi) made their first contribution in [#1644](https://github.com/pydantic/pydantic-ai/pull/1644)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.9...v0.1.10).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.10).
### v0.1.9 (2025-05-02)
#### What's Changed
  * Use the correct discriminator string in `HandleResponseEvent` by [@DouweM](https://github.com/DouweM) in [#1619](https://github.com/pydantic/pydantic-ai/pull/1619)
  * Handle multi-modal and error responses from MCP tool calls by [@DouweM](https://github.com/DouweM) in [#1618](https://github.com/pydantic/pydantic-ai/pull/1618)
  * Store additional usage details from Anthropic by [@timesler](https://github.com/timesler) in [#1549](https://github.com/pydantic/pydantic-ai/pull/1549)
  * Add `base_url` to Mistral Provider by [@alibeyram](https://github.com/alibeyram) in [#1617](https://github.com/pydantic/pydantic-ai/pull/1617)


#### New Contributors
  * [@derluke](https://github.com/derluke) made their first contribution in [#1240](https://github.com/pydantic/pydantic-ai/pull/1240)
  * [@alibeyram](https://github.com/alibeyram) made their first contribution in [#1617](https://github.com/pydantic/pydantic-ai/pull/1617)
  * [@damyantilev](https://github.com/damyantilev) made their first contribution in [#1630](https://github.com/pydantic/pydantic-ai/pull/1630)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.8...v0.1.9).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.9).
### v0.1.8 (2025-04-28)
#### What's Changed
  * Support returning multi-modal content from tools by [@DouweM](https://github.com/DouweM) in [#1517](https://github.com/pydantic/pydantic-ai/pull/1517)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.7...v0.1.8).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.8).
### v0.1.7 (2025-04-28)
#### What's Changed
  * Allow multiple instructions and fix instruction concatenation in Agent by [@HamzaFarhan](https://github.com/HamzaFarhan) in [#1591](https://github.com/pydantic/pydantic-ai/pull/1591)
  * Fix OpenAI AudioUrl by [@alexmojaki](https://github.com/alexmojaki) in [#1594](https://github.com/pydantic/pydantic-ai/pull/1594)
  * Gemini Video Support by [@kylesf](https://github.com/kylesf) in [#1584](https://github.com/pydantic/pydantic-ai/pull/1584)
  * Set `use_attribute_docstrings=True` by default on tools by [@Kludex](https://github.com/Kludex) in [#1605](https://github.com/pydantic/pydantic-ai/pull/1605)
  * Copy context to new thread for sync tool calls by [@tboser](https://github.com/tboser) in [#1576](https://github.com/pydantic/pydantic-ai/pull/1576)
  * Record agent run attributes in case of streaming and exception by [@alexmojaki](https://github.com/alexmojaki) in [#1610](https://github.com/pydantic/pydantic-ai/pull/1610)


#### New Contributors
  * [@kylesf](https://github.com/kylesf) made their first contribution in [#1584](https://github.com/pydantic/pydantic-ai/pull/1584)
  * [@angelol](https://github.com/angelol) made their first contribution in [#1578](https://github.com/pydantic/pydantic-ai/pull/1578)
  * [@tboser](https://github.com/tboser) made their first contribution in [#1576](https://github.com/pydantic/pydantic-ai/pull/1576)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.6...v0.1.7).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.7).
### v0.1.6 (2025-04-25)
#### What's Changed
  * otel: send `AudioUrl`, `VideoUrl`, `DocumentUrl` and `ImageUrl` information by [@Kludex](https://github.com/Kludex) in [#1592](https://github.com/pydantic/pydantic-ai/pull/1592)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.5...v0.1.6).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.6).
### v0.1.5 (2025-04-25)
#### What's Changed
  * Drop `requests` minimum version to 2.32.2 by [@Kludex](https://github.com/Kludex) in [#1588](https://github.com/pydantic/pydantic-ai/pull/1588)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.4...v0.1.5).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.5).
### v0.1.4 (2025-04-24)
#### What's Changed
  * Use `report_case_name` in span by [@alexmojaki](https://github.com/alexmojaki) in [#1544](https://github.com/pydantic/pydantic-ai/pull/1544)
  * Make agent and graph runs serializable again by [@dmontagu](https://github.com/dmontagu) in [#1545](https://github.com/pydantic/pydantic-ai/pull/1545)
  * support MCP logging, increase minimum mcp version to 1.6.0 by [@samuelcolvin](https://github.com/samuelcolvin) in [#1436](https://github.com/pydantic/pydantic-ai/pull/1436)
  * Add support for o3 and o4-mini by [@zachmayer](https://github.com/zachmayer) in [#1557](https://github.com/pydantic/pydantic-ai/pull/1557)
  * OpenAI: Enable DocumentUrl and BinaryContent documents by [@gearheart](https://github.com/gearheart) in [#1552](https://github.com/pydantic/pydantic-ai/pull/1552)
  * gemini: move `list` type inside the `Annotated` on `function_declarations` field by [@gitraffe](https://github.com/gitraffe) in [#1570](https://github.com/pydantic/pydantic-ai/pull/1570)
  * Replaced incorrect all_message() with new_messages() by [@ag14774](https://github.com/ag14774) in [#1566](https://github.com/pydantic/pydantic-ai/pull/1566)


#### New Contributors
  * [@zachmayer](https://github.com/zachmayer) made their first contribution in [#1557](https://github.com/pydantic/pydantic-ai/pull/1557)
  * [@gearheart](https://github.com/gearheart) made their first contribution in [#1552](https://github.com/pydantic/pydantic-ai/pull/1552)
  * [@gitraffe](https://github.com/gitraffe) made their first contribution in [#1570](https://github.com/pydantic/pydantic-ai/pull/1570)
  * [@ag14774](https://github.com/ag14774) made their first contribution in [#1566](https://github.com/pydantic/pydantic-ai/pull/1566)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.3...v0.1.4).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.4).
### v0.1.3 (2025-04-18)
#### What's Changed
  * Return last text parts on empty message by [@samuelcolvin](https://github.com/samuelcolvin) in [#1408](https://github.com/pydantic/pydantic-ai/pull/1408)
  * move `prepare_env.py` to Python file in `mcp-run-python` by [@samuelcolvin](https://github.com/samuelcolvin) in [#1461](https://github.com/pydantic/pydantic-ai/pull/1461)
  * Don't set non-recording span as current by [@alexmojaki](https://github.com/alexmojaki) in [#1527](https://github.com/pydantic/pydantic-ai/pull/1527)
  * opentelemetry: add span event for `instructions` by [@Kludex](https://github.com/Kludex) in [#1529](https://github.com/pydantic/pydantic-ai/pull/1529)
  * Add `extra_body` to `ModelSettings` by [@Kludex](https://github.com/Kludex) in [#1538](https://github.com/pydantic/pydantic-ai/pull/1538)
  * Do not raise an error when no results are found by [@bputzeys](https://github.com/bputzeys) in [#1536](https://github.com/pydantic/pydantic-ai/pull/1536)
  * Add support for gemini-2.5-flash-preview-04-17 by [@barapa](https://github.com/barapa) in [#1531](https://github.com/pydantic/pydantic-ai/pull/1531)
  * fix: allow multiple `BinaryContent` in `message_history` by [@arde100](https://github.com/arde100) in [#1523](https://github.com/pydantic/pydantic-ai/pull/1523)
  * fix: handle empty args for ToolCallPart by [@arnaudstiegler](https://github.com/arnaudstiegler) in [#1515](https://github.com/pydantic/pydantic-ai/pull/1515)


#### New Contributors
  * [@bputzeys](https://github.com/bputzeys) made their first contribution in [#1536](https://github.com/pydantic/pydantic-ai/pull/1536)
  * [@arde100](https://github.com/arde100) made their first contribution in [#1523](https://github.com/pydantic/pydantic-ai/pull/1523)
  * [@arnaudstiegler](https://github.com/arnaudstiegler) made their first contribution in [#1515](https://github.com/pydantic/pydantic-ai/pull/1515)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.2...v0.1.3).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.3).
### v0.1.2 (2025-04-17)
#### What's Changed
  * Fix max length handling by [@dmontagu](https://github.com/dmontagu) in [#1510](https://github.com/pydantic/pydantic-ai/pull/1510)
  * Do a better job of inferring openai strict mode by [@dmontagu](https://github.com/dmontagu) in [#1511](https://github.com/pydantic/pydantic-ai/pull/1511)
  * Properly validate serialized messages with `BinaryContent` by decoding `base64` by [@DouweM](https://github.com/DouweM) in [#1513](https://github.com/pydantic/pydantic-ai/pull/1513)
  * Expose the `StdioServerParameters.cwd` param by [@timesler](https://github.com/timesler) in [#1514](https://github.com/pydantic/pydantic-ai/pull/1514)


#### New Contributors
  * [@DouweM](https://github.com/DouweM) made their first contribution in [#1513](https://github.com/pydantic/pydantic-ai/pull/1513)
  * [@timesler](https://github.com/timesler) made their first contribution in [#1514](https://github.com/pydantic/pydantic-ai/pull/1514)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.1...v0.1.2).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.2).
### v0.1.1 (2025-04-16)
#### What's Changed
  * fix: Allow empty tool call args by [@Wh1isper](https://github.com/Wh1isper) in [#1407](https://github.com/pydantic/pydantic-ai/pull/1407)
  * fix: add instructions on further requests besides `UserPromptNode` by [@Kludex](https://github.com/Kludex) in [#1503](https://github.com/pydantic/pydantic-ai/pull/1503)
  * Fix handling of `additionalProperties` by gemini by [@Kludex](https://github.com/Kludex) in [#1506](https://github.com/pydantic/pydantic-ai/pull/1506)


[](https://github.com/pydantic/pydantic-ai/compare/v0.1.0...v0.1.1).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.1).
### v0.1.0 (2025-04-15)
#### What's Changed
  * feat(bedrock): add VideoUrl input for `BedrockConverseModel` by [@leandrodamascena](https://github.com/leandrodamascena) in [#1435](https://github.com/pydantic/pydantic-ai/pull/1435)
  * Add spans as an attribute on agent/graph runs/runresults by [@dmontagu](https://github.com/dmontagu) in [#1415](https://github.com/pydantic/pydantic-ai/pull/1415)
  * BREAKING CHANGE: rename `result` -> `output` by [@samuelcolvin](https://github.com/samuelcolvin) in [#1248](https://github.com/pydantic/pydantic-ai/pull/1248)
  * Bugfix: ensure parameters are customized when making streaming requests by [@dmontagu](https://github.com/dmontagu) in [#1475](https://github.com/pydantic/pydantic-ai/pull/1475)
  * Customize the parameters as appropriate for the model when using fallback model by [@dmontagu](https://github.com/dmontagu) in [#1477](https://github.com/pydantic/pydantic-ai/pull/1477)
  * Update min openai version by [@dmontagu](https://github.com/dmontagu) in [#1479](https://github.com/pydantic/pydantic-ai/pull/1479)
  * feat(`BedrockConverseModel`): add additional configuration fields to Bedrock Runtime API by [@leandrodamascena](https://github.com/leandrodamascena) in [#1458](https://github.com/pydantic/pydantic-ai/pull/1458)
  * Add support for `gemini-2.5-pro-preview-03-25` model (paid version of gemini 2.5 pro) by [@barapa](https://github.com/barapa) in [#1473](https://github.com/pydantic/pydantic-ai/pull/1473)
  * BREAKING CHANGE (minor) move `format_as_xml` by [@samuelcolvin](https://github.com/samuelcolvin) in [#1484](https://github.com/pydantic/pydantic-ai/pull/1484)
  * Add Changelog by [@samuelcolvin](https://github.com/samuelcolvin) in [#1487](https://github.com/pydantic/pydantic-ai/pull/1487)
  * Add `instructions` parameter by [@Kludex](https://github.com/Kludex) in [#1360](https://github.com/pydantic/pydantic-ai/pull/1360)
  * Generalize the JSON schema transformations by [@dmontagu](https://github.com/dmontagu) in [#1481](https://github.com/pydantic/pydantic-ai/pull/1481)
  * Switch gemini request to camelCase as required by API by [@piercefreeman](https://github.com/piercefreeman) in [#1456](https://github.com/pydantic/pydantic-ai/pull/1456)


#### New Contributors
  * [@VildMedPap](https://github.com/VildMedPap) made their first contribution in [#1441](https://github.com/pydantic/pydantic-ai/pull/1441)
  * [@leandrodamascena](https://github.com/leandrodamascena) made their first contribution in [#1435](https://github.com/pydantic/pydantic-ai/pull/1435)
  * [@ehaca](https://github.com/ehaca) made their first contribution in [#1389](https://github.com/pydantic/pydantic-ai/pull/1389)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.55...v0.1.0).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.1.0).
### v0.0.55 2025-04-09
#### What's Changed
  * Allow empty user_prompt in run_stream by [@lfloeer](https://github.com/lfloeer) in [#1421](https://github.com/pydantic/pydantic-ai/pull/1421)
  * fix: infer azure provider and environment for key by [@Wh1isper](https://github.com/Wh1isper) in [#1422](https://github.com/pydantic/pydantic-ai/pull/1422)
  * Fix bug with JSON schema generation when using InstrumentedModel by [@dmontagu](https://github.com/dmontagu) in [#1424](https://github.com/pydantic/pydantic-ai/pull/1424)
  * Add PydanticAI User-Agent header by [@Kludex](https://github.com/Kludex) in [#1425](https://github.com/pydantic/pydantic-ai/pull/1425)


#### New Contributors
  * [@lfloeer](https://github.com/lfloeer) made their first contribution in [#1421](https://github.com/pydantic/pydantic-ai/pull/1421)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.54...v0.0.55).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.55).
### v0.0.54 2025-04-09
#### What's Changed
  * evals: error when opentelemetry-sdk is not installed by [@Kludex](https://github.com/Kludex) in [#1403](https://github.com/pydantic/pydantic-ai/pull/1403)
  * bedrock: allow empty system prompt by [@Kludex](https://github.com/Kludex) in [#1405](https://github.com/pydantic/pydantic-ai/pull/1405)
  * fix import for the bedrock model by [@yilololo](https://github.com/yilololo) in [#1410](https://github.com/pydantic/pydantic-ai/pull/1410)
  * Yield initial node during Graph (and therefore Agent) iteration by [@dmontagu](https://github.com/dmontagu) in [#1412](https://github.com/pydantic/pydantic-ai/pull/1412)
  * Make `user_prompt` optional by [@Kludex](https://github.com/Kludex) in [#1406](https://github.com/pydantic/pydantic-ai/pull/1406)
  * Add `stop_sequences` to `ModelSettings` by [@Kludex](https://github.com/Kludex) in [#1419](https://github.com/pydantic/pydantic-ai/pull/1419)


#### New Contributors
  * [@yilololo](https://github.com/yilololo) made their first contribution in [#1410](https://github.com/pydantic/pydantic-ai/pull/1410)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.53...v0.0.54).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.54).
### v0.0.53 2025-04-07
#### What's Changed
  * Improve some error messages by [@dmontagu](https://github.com/dmontagu) in [#1366](https://github.com/pydantic/pydantic-ai/pull/1366)
  * Improve serialization of LLMJudge and custom evaluators by [@dmontagu](https://github.com/dmontagu) in [#1367](https://github.com/pydantic/pydantic-ai/pull/1367)
  * Use `handle_stream.stream_output()` in the CLI by [@Kludex](https://github.com/Kludex) in [#1376](https://github.com/pydantic/pydantic-ai/pull/1376)
  * Feature/add openai strict mode by [@mscherrmann](https://github.com/mscherrmann) in [#1304](https://github.com/pydantic/pydantic-ai/pull/1304)


#### New Contributors
  * [@mscherrmann](https://github.com/mscherrmann) made their first contribution in [#1304](https://github.com/pydantic/pydantic-ai/pull/1304)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.52...v0.0.53).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.53).
### v0.0.52 2025-04-03
#### What's Changed
  * Add dependencies to evals by [@Kludex](https://github.com/Kludex) in [#1358](https://github.com/pydantic/pydantic-ai/pull/1358)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.51...v0.0.52).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.52).
### v0.0.51 2025-04-03
#### What's Changed
  * Match OpenAI models in strictness by [@Kludex](https://github.com/Kludex) in [#1356](https://github.com/pydantic/pydantic-ai/pull/1356)
  * Switch `mcp-run-python` server to use deno by [@samuelcolvin](https://github.com/samuelcolvin) in [#1340](https://github.com/pydantic/pydantic-ai/pull/1340)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.50...v0.0.51).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.51).
### v0.0.50 2025-04-03
#### What's Changed
  * Fix some issues with non-serializable inputs in evals by [@dmontagu](https://github.com/dmontagu) in [#1333](https://github.com/pydantic/pydantic-ai/pull/1333)
  * Add expected output to logfire attributes for the evals task span by [@dmontagu](https://github.com/dmontagu) in [#1334](https://github.com/pydantic/pydantic-ai/pull/1334)
  * Drop `exclusiveMaximum`/`exclusiveMinimum` from Gemini by [@Kludex](https://github.com/Kludex) in [#1341](https://github.com/pydantic/pydantic-ai/pull/1341)
  * Drop JSON schema url from schema on Gemini by [@Kludex](https://github.com/Kludex) in [#1342](https://github.com/pydantic/pydantic-ai/pull/1342)
  * Add py.typed marker to pydantic_evals package by [@t94j0](https://github.com/t94j0) in [#1349](https://github.com/pydantic/pydantic-ai/pull/1349)


#### New Contributors
  * [@mike-luabase](https://github.com/mike-luabase) made their first contribution in [#1331](https://github.com/pydantic/pydantic-ai/pull/1331)
  * [@t94j0](https://github.com/t94j0) made their first contribution in [#1349](https://github.com/pydantic/pydantic-ai/pull/1349)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.49...v0.0.50).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.50).
### v0.0.49 2025-04-01
#### What's Changed
  * Add Gemini 2.5 pro and improve CLI by [@samuelcolvin](https://github.com/samuelcolvin) in [#1317](https://github.com/pydantic/pydantic-ai/pull/1317)
  * Add OpenAI built-in tools by [@Kludex](https://github.com/Kludex) in [#1327](https://github.com/pydantic/pydantic-ai/pull/1327)
  * Add `generate_summary` and `truncation` to `OpenAIResponsesModelSettings` by [@Kludex](https://github.com/Kludex) in [#1328](https://github.com/pydantic/pydantic-ai/pull/1328)
  * Move imports to try-except block by [@Kludex](https://github.com/Kludex) in [#1329](https://github.com/pydantic/pydantic-ai/pull/1329)
  * Don't download content on `ImageUrl` and `DocumentUrl` for Anthropic Models by [@jnishiyama](https://github.com/jnishiyama) in [#1318](https://github.com/pydantic/pydantic-ai/pull/1318)


#### New Contributors
  * [@jnishiyama](https://github.com/jnishiyama) made their first contribution in [#1318](https://github.com/pydantic/pydantic-ai/pull/1318)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.48...v0.0.49).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.49).
### v0.0.48 2025-03-31
#### What's Changed
  * Add OpenAI Responses API by [@Kludex](https://github.com/Kludex) in [#1256](https://github.com/pydantic/pydantic-ai/pull/1256)
  * Add dynamic version on evals extras by [@Kludex](https://github.com/Kludex) in [#1315](https://github.com/pydantic/pydantic-ai/pull/1315)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.47...v0.0.48).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.48).
### v0.0.47 2025-03-31
#### What's Changed
  * Ensure model settings' prefixes are enforced by [@Kludex](https://github.com/Kludex) in [#1257](https://github.com/pydantic/pydantic-ai/pull/1257)
  * Bump logfire by [@Kludex](https://github.com/Kludex) in [#1262](https://github.com/pydantic/pydantic-ai/pull/1262)
  * improvements while playing with the CLI by [@samuelcolvin](https://github.com/samuelcolvin) in [#1263](https://github.com/pydantic/pydantic-ai/pull/1263)
  * add span around tool calls by [@samuelcolvin](https://github.com/samuelcolvin) in [#1158](https://github.com/pydantic/pydantic-ai/pull/1158)
  * Add `pydantic-evals` package by [@dmontagu](https://github.com/dmontagu) in [#935](https://github.com/pydantic/pydantic-ai/pull/935)
  * remove "preparing model request params" span by [@samuelcolvin](https://github.com/samuelcolvin) in [#1281](https://github.com/pydantic/pydantic-ai/pull/1281)
  * Clean up SpanQuery and related APIs by [@dmontagu](https://github.com/dmontagu) in [#1287](https://github.com/pydantic/pydantic-ai/pull/1287)
  * Fix the default types of generic params to EvaluatorContext by [@dmontagu](https://github.com/dmontagu) in [#1290](https://github.com/pydantic/pydantic-ai/pull/1290)
  * More otel cleanup for evals by [@dmontagu](https://github.com/dmontagu) in [#1291](https://github.com/pydantic/pydantic-ai/pull/1291)
  * Clean up public evals API by [@dmontagu](https://github.com/dmontagu) in [#1298](https://github.com/pydantic/pydantic-ai/pull/1298)
  * [Bugfix] Unknown tool called by agent will cause response 400 by [@BeautyyuYanli](https://github.com/BeautyyuYanli) in [#1255](https://github.com/pydantic/pydantic-ai/pull/1255)
  * feat: Add read timeout and connect timeout for bedrock provider by [@Wh1isper](https://github.com/Wh1isper) in [#1259](https://github.com/pydantic/pydantic-ai/pull/1259)
  * allow str as model, fix Groq models by [@samuelcolvin](https://github.com/samuelcolvin) in [#1306](https://github.com/pydantic/pydantic-ai/pull/1306)
  * CLI fixes and improvements by [@dmontagu](https://github.com/dmontagu) in [#1299](https://github.com/pydantic/pydantic-ai/pull/1299)
  * Allow use of `PYTHONOPTIMIZE=1` by [@Kludex](https://github.com/Kludex) in [#1307](https://github.com/pydantic/pydantic-ai/pull/1307)
  * disable cohere with emscripten by [@samuelcolvin](https://github.com/samuelcolvin) in [#1296](https://github.com/pydantic/pydantic-ai/pull/1296)


#### New Contributors
  * [@yaswhar](https://github.com/yaswhar) made their first contribution in [#1224](https://github.com/pydantic/pydantic-ai/pull/1224)
  * [@sarunas-llm](https://github.com/sarunas-llm) made their first contribution in [#1280](https://github.com/pydantic/pydantic-ai/pull/1280)
  * [@BeautyyuYanli](https://github.com/BeautyyuYanli) made their first contribution in [#1255](https://github.com/pydantic/pydantic-ai/pull/1255)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.46...v0.0.47).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.47).
### v0.0.46
#### What's Changed
  * Use different HTTP clients based on providers by [@Kludex](https://github.com/Kludex) in [#1242](https://github.com/pydantic/pydantic-ai/pull/1242)
  * Add `headers`, `timeout`, and `sse_read_timeout` to `MCPServerHTTP` by [@JohnUiterwyk](https://github.com/JohnUiterwyk) in [#1218](https://github.com/pydantic/pydantic-ai/pull/1218)
  * Revert "Use `get_running_loop` instead of `get_event_loop`" by [@Kludex](https://github.com/Kludex) in [#1252](https://github.com/pydantic/pydantic-ai/pull/1252)


#### New Contributors
  * [@JohnUiterwyk](https://github.com/JohnUiterwyk) made their first contribution in [#1218](https://github.com/pydantic/pydantic-ai/pull/1218)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.45...v0.0.46).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.46).
### v0.0.45
#### What's Changed
  * Generate tool call id if not present by [@Kludex](https://github.com/Kludex) in [#1229](https://github.com/pydantic/pydantic-ai/pull/1229)
  * add `user` mapping in openai chat completion by [@ovisek](https://github.com/ovisek) in [#1174](https://github.com/pydantic/pydantic-ai/pull/1174)
  * Remove non-provider parameters from models by [@Kludex](https://github.com/Kludex) in [#1239](https://github.com/pydantic/pydantic-ai/pull/1239)


#### New Contributors
  * [@ovisek](https://github.com/ovisek) made their first contribution in [#1174](https://github.com/pydantic/pydantic-ai/pull/1174)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.44...v0.0.45).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.45).
### v0.0.44
#### What's Changed
  * Migrate OpenAI models away from `max_tokens` to `max_completion_tokens` by [@barapa](https://github.com/barapa) in [#1206](https://github.com/pydantic/pydantic-ai/pull/1206)
  * Add return docstring to the function description by [@Kludex](https://github.com/Kludex) in [#1207](https://github.com/pydantic/pydantic-ai/pull/1207)
  * Add `model_request_parameters` attribute (containing tool definitions) to chat spans by [@alexmojaki](https://github.com/alexmojaki) in [#1177](https://github.com/pydantic/pydantic-ai/pull/1177)
  * Use `get_running_loop` instead of `get_event_loop` by [@Kludex](https://github.com/Kludex) in [#1204](https://github.com/pydantic/pydantic-ai/pull/1204)
  * Bump openai to 1.66.0 by [@Kludex](https://github.com/Kludex) in [#1202](https://github.com/pydantic/pydantic-ai/pull/1202)
  * Use `pydantic-ai-slim` version on CLI instead of `pydantic-ai` by [@samuelcolvin](https://github.com/samuelcolvin) in [#1213](https://github.com/pydantic/pydantic-ai/pull/1213)
  * Drop `system` parameter from `OpenAIModel` by [@Kludex](https://github.com/Kludex) in [#1235](https://github.com/pydantic/pydantic-ai/pull/1235)
  * Use provider on models inference by [@Kludex](https://github.com/Kludex) in [#1234](https://github.com/pydantic/pydantic-ai/pull/1234)
  * Add cohere provider class by [@hrahmadi71](https://github.com/hrahmadi71) in [#1225](https://github.com/pydantic/pydantic-ai/pull/1225)


#### New Contributors
  * [@derekwsgray](https://github.com/derekwsgray) made their first contribution in [#1227](https://github.com/pydantic/pydantic-ai/pull/1227)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.43...v0.0.44).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.44).
### v0.0.43 2025-03-21
#### What's Changed
  * Add timestamp to `SystemPromptPart` by [@vricciardulli](https://github.com/vricciardulli) in [#1154](https://github.com/pydantic/pydantic-ai/pull/1154)
  * Recreate access token on 401 for Google Vertex provider by [@Kludex](https://github.com/Kludex) in [#1195](https://github.com/pydantic/pydantic-ai/pull/1195)


#### New Contributors
  * [@dsfaccini](https://github.com/dsfaccini) made their first contribution in [#1181](https://github.com/pydantic/pydantic-ai/pull/1181)
  * [@vricciardulli](https://github.com/vricciardulli) made their first contribution in [#1154](https://github.com/pydantic/pydantic-ai/pull/1154)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.42...v0.0.43).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.43).
### v0.0.42 2025-03-19
#### What's Changed
  * Add support for MCP servers by [@Kludex](https://github.com/Kludex) in [#1100](https://github.com/pydantic/pydantic-ai/pull/1100)
  * Make it possible to override JSON schema generation for tools by [@dmontagu](https://github.com/dmontagu) in [#1108](https://github.com/pydantic/pydantic-ai/pull/1108)
  * MCP server to run Python code in a sandbox by [@samuelcolvin](https://github.com/samuelcolvin) in [#1140](https://github.com/pydantic/pydantic-ai/pull/1140)
  * change api_key check flow by [@ChenghaoMou](https://github.com/ChenghaoMou) in [#1164](https://github.com/pydantic/pydantic-ai/pull/1164)
  * require 3.12 for development by [@samuelcolvin](https://github.com/samuelcolvin) in [#1173](https://github.com/pydantic/pydantic-ai/pull/1173)
  * improved MCP documentation by [@samuelcolvin](https://github.com/samuelcolvin) in [#1171](https://github.com/pydantic/pydantic-ai/pull/1171)
  * rename `MCPServerSSE` to `MCPServerHTTP` and more docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#1176](https://github.com/pydantic/pydantic-ai/pull/1176)
  * uprev to 0.0.42 by [@samuelcolvin](https://github.com/samuelcolvin) in [#1178](https://github.com/pydantic/pydantic-ai/pull/1178)


#### New Contributors
  * [@ChenghaoMou](https://github.com/ChenghaoMou) made their first contribution in [#1164](https://github.com/pydantic/pydantic-ai/pull/1164)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.41...v0.0.42).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.42).
### v0.0.41 2025-03-17
#### What's Changed
  * Improve generic typehints in graph.py by [@dmontagu](https://github.com/dmontagu) in [#1139](https://github.com/pydantic/pydantic-ai/pull/1139)
  * Fix span attributes when instrumenting FallbackModel streaming by [@alexmojaki](https://github.com/alexmojaki) in [#1147](https://github.com/pydantic/pydantic-ai/pull/1147)
  * Add Anthropic provider classes by [@hrahmadi71](https://github.com/hrahmadi71) in [#1120](https://github.com/pydantic/pydantic-ai/pull/1120)
  * Add Mistral provider by [@Viicos](https://github.com/Viicos) in [#1118](https://github.com/pydantic/pydantic-ai/pull/1118)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.40...v0.0.41).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.41).
### v0.0.40 2025-03-15
#### What's Changed
  * Update `OpenAIProvider` to use environment variable for base URL by [@hrahmadi71](https://github.com/hrahmadi71) in [#1117](https://github.com/pydantic/pydantic-ai/pull/1117)
  * Add `AzureProvider` by [@Kludex](https://github.com/Kludex) in [#1091](https://github.com/pydantic/pydantic-ai/pull/1091)
  * State persistence by [@samuelcolvin](https://github.com/samuelcolvin) in [#955](https://github.com/pydantic/pydantic-ai/pull/955)
  * `InstrumentedModel` and `FallbackModel` fixes by [@alexmojaki](https://github.com/alexmojaki) in [#1121](https://github.com/pydantic/pydantic-ai/pull/1121)
  * Add PDF support to Anthropic by [@camilovelezr](https://github.com/camilovelezr) in [#1123](https://github.com/pydantic/pydantic-ai/pull/1123)


#### New Contributors
  * [@camilovelezr](https://github.com/camilovelezr) made their first contribution in [#1123](https://github.com/pydantic/pydantic-ai/pull/1123)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.39...v0.0.40).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.40).
### v0.0.39 2025-03-13
#### What's Changed
  * Add Groq provider classes by [@hrahmadi71](https://github.com/hrahmadi71) in [#1084](https://github.com/pydantic/pydantic-ai/pull/1084)
  * fix: ModuleNotFoundError for mypy_boto3_bedrock_runtime by [@Wh1isper](https://github.com/Wh1isper) in [#1113](https://github.com/pydantic/pydantic-ai/pull/1113)


#### New Contributors
  * [@leowalker89](https://github.com/leowalker89) made their first contribution in [#1095](https://github.com/pydantic/pydantic-ai/pull/1095)
  * [@Wh1isper](https://github.com/Wh1isper) made their first contribution in [#1113](https://github.com/pydantic/pydantic-ai/pull/1113)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.38...v0.0.39).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.39).
### v0.0.38 2025-03-13
#### What's Changed
  * Fix instrumentation of FallbackModel by [@alexmojaki](https://github.com/alexmojaki) in [#1076](https://github.com/pydantic/pydantic-ai/pull/1076)
  * Add `DocumentUrl` and support document via `BinaryContent` by [@Kludex](https://github.com/Kludex) in [#987](https://github.com/pydantic/pydantic-ai/pull/987)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.37...v0.0.38).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.38).
### v0.0.37 2025-03-12
#### What's Changed
  * Add `base_url` to models, populate `server.address` and `server.port` in spans by [@alexmojaki](https://github.com/alexmojaki) in [#1074](https://github.com/pydantic/pydantic-ai/pull/1074)
  * Add support for pre-loaded VertexAI service account info by [@jerry-reevo](https://github.com/jerry-reevo) in [#1066](https://github.com/pydantic/pydantic-ai/pull/1066)
  * Add support for specifying tool name when using decorator. by [@phemmer](https://github.com/phemmer) in [#1087](https://github.com/pydantic/pydantic-ai/pull/1087)
  * Serialize bytes as base64 for JSON by [@Kludex](https://github.com/Kludex) in [#1089](https://github.com/pydantic/pydantic-ai/pull/1089)


#### New Contributors
  * [@jerry-reevo](https://github.com/jerry-reevo) made their first contribution in [#1066](https://github.com/pydantic/pydantic-ai/pull/1066)
  * [@phemmer](https://github.com/phemmer) made their first contribution in [#1087](https://github.com/pydantic/pydantic-ai/pull/1087)
  * [@bllchmbrs](https://github.com/bllchmbrs) made their first contribution in [#1067](https://github.com/pydantic/pydantic-ai/pull/1067)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.36...v0.0.37).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.37).
### v0.0.36 2025-03-07
#### What's Changed
  * Update regions url and VertexAIRegion Literal by [@tuxthepenguin84](https://github.com/tuxthepenguin84) in [#1068](https://github.com/pydantic/pydantic-ai/pull/1068)
  * Add support for AWS Bedrock Converse API by [@Kludex](https://github.com/Kludex) in [#994](https://github.com/pydantic/pydantic-ai/pull/994)


#### New Contributors
  * [@tuxthepenguin84](https://github.com/tuxthepenguin84) made their first contribution in [#1068](https://github.com/pydantic/pydantic-ai/pull/1068)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.35...v0.0.36).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.36).
### v0.0.35 2025-03-05
This release only makes sure that `pydantic-ai-examples` have the right dependency versions.
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.35).
### v0.0.34 2025-03-05
#### What's Changed
  * Add `Agent.instrument_all()` method to instrument all agents by default by [@alexmojaki](https://github.com/alexmojaki) in [#1047](https://github.com/pydantic/pydantic-ai/pull/1047)
  * Add tool name to tool response events by [@alexmojaki](https://github.com/alexmojaki) in [#1061](https://github.com/pydantic/pydantic-ai/pull/1061)
  * Add `pai` CLI by [@Kludex](https://github.com/Kludex) in [#1031](https://github.com/pydantic/pydantic-ai/pull/1031)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.33...v0.0.34).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.34).
### v0.0.33 2025-03-05
#### What's Changed
  * Make use of `typing-inspection` by [@Viicos](https://github.com/Viicos) in [#1019](https://github.com/pydantic/pydantic-ai/pull/1019)
  * Add `Provider`s API by [@Kludex](https://github.com/Kludex) in [#1013](https://github.com/pydantic/pydantic-ai/pull/1013)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.32...v0.0.33).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.33).
### v0.0.32 2025-03-04
#### What's Changed
  * **Disable instrumentation by default** , add `instrument` param to `Agent`, use plain OpenTelemetry by [@alexmojaki](https://github.com/alexmojaki) in [#1005](https://github.com/pydantic/pydantic-ai/pull/1005)
  * Add support for claude sonnet 3-7 by [@ilanbenb](https://github.com/ilanbenb) in [#1034](https://github.com/pydantic/pydantic-ai/pull/1034)
  * Add support for `gemini-2.0-pro-exp-02-05` by [@barapa](https://github.com/barapa) in [#1038](https://github.com/pydantic/pydantic-ai/pull/1038)
  * Misc instrumentation followups by [@alexmojaki](https://github.com/alexmojaki) in [#1044](https://github.com/pydantic/pydantic-ai/pull/1044)


#### New Contributors
  * [@ilanbenb](https://github.com/ilanbenb) made their first contribution in [#1034](https://github.com/pydantic/pydantic-ai/pull/1034)
  * [@barapa](https://github.com/barapa) made their first contribution in [#1038](https://github.com/pydantic/pydantic-ai/pull/1038)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.31...v0.0.32).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.32).
### v0.0.31 2025-03-03
#### What's Changed
  * Accept recursive objects in `return_type` by [@Kludex](https://github.com/Kludex) in [#1017](https://github.com/pydantic/pydantic-ai/pull/1017)
  * Rename HandleResponseNode to CallToolsNode by [@dmontagu](https://github.com/dmontagu) in [#1020](https://github.com/pydantic/pydantic-ai/pull/1020)
  * Make Graph.iter into an _async_ contextmanager by [@dmontagu](https://github.com/dmontagu) in [#958](https://github.com/pydantic/pydantic-ai/pull/958)
  * Fix bug related to handling multiple result tools by [@dmontagu](https://github.com/dmontagu) in [#926](https://github.com/pydantic/pydantic-ai/pull/926)
  * Replace `model request` span with `InstrumentedModel` by [@alexmojaki](https://github.com/alexmojaki) in [#1012](https://github.com/pydantic/pydantic-ai/pull/1012)
  * Replace `all_messages` in agent span with `all_messages_events` in same format as `InstrumentedModel` span by [@alexmojaki](https://github.com/alexmojaki) in [#1018](https://github.com/pydantic/pydantic-ai/pull/1018)


#### New Contributors
  * [@logankilpatrick](https://github.com/logankilpatrick) made their first contribution in [#1030](https://github.com/pydantic/pydantic-ai/pull/1030)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.30...v0.0.31).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.31).
### v0.0.30 2025-02-27
#### What's Changed
  * Use `.iter()` API to fully replace existing streaming implementation by [@dmontagu](https://github.com/dmontagu) in [#951](https://github.com/pydantic/pydantic-ai/pull/951)
  * Added gpt-4.5-preview support for OpenAIModel by [@dorukgezici](https://github.com/dorukgezici) in [#1011](https://github.com/pydantic/pydantic-ai/pull/1011)
  * Add attributes mode to InstrumentedModel by [@alexmojaki](https://github.com/alexmojaki) in [#1010](https://github.com/pydantic/pydantic-ai/pull/1010)
  * Support different content inputs in `TestModel` by [@Kludex](https://github.com/Kludex) in [#1015](https://github.com/pydantic/pydantic-ai/pull/1015)


#### New Contributors
  * [@dorukgezici](https://github.com/dorukgezici) made their first contribution in [#1011](https://github.com/pydantic/pydantic-ai/pull/1011)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.29...v0.0.30).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.30).
### v0.0.29 2025-02-27
#### What's Changed
  * Add `max_results` parameter to DuckDuckGo search tool by [@HamzaFarhan](https://github.com/HamzaFarhan) in [#1003](https://github.com/pydantic/pydantic-ai/pull/1003)
  * Create a new event loop on each thread by [@Kludex](https://github.com/Kludex) in [#1004](https://github.com/pydantic/pydantic-ai/pull/1004)


#### New Contributors
  * [@HamzaFarhan](https://github.com/HamzaFarhan) made their first contribution in [#1003](https://github.com/pydantic/pydantic-ai/pull/1003)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.28...v0.0.29).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.29).
### v0.0.28 2025-02-27
#### What's Changed
  * Allow Anthropic Models to use more broad mime types for `ImageUrl` by [@pedroallenrevez](https://github.com/pedroallenrevez) in [#993](https://github.com/pydantic/pydantic-ai/pull/993)
  * Add DuckDuckGoSearch tool by [@Kludex](https://github.com/Kludex) in [#997](https://github.com/pydantic/pydantic-ai/pull/997)
  * Add tool_call_id to RunContext and update context replacement by [@gmr](https://github.com/gmr) in [#998](https://github.com/pydantic/pydantic-ai/pull/998)
  * Add TavilySearch tool by [@Kludex](https://github.com/Kludex) in [#1001](https://github.com/pydantic/pydantic-ai/pull/1001)


#### New Contributors
  * [@pedroallenrevez](https://github.com/pedroallenrevez) made their first contribution in [#993](https://github.com/pydantic/pydantic-ai/pull/993)
  * [@schmaxXximilian](https://github.com/schmaxXximilian) made their first contribution in [#995](https://github.com/pydantic/pydantic-ai/pull/995)
  * [@gmr](https://github.com/gmr) made their first contribution in [#998](https://github.com/pydantic/pydantic-ai/pull/998)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.27...v0.0.28).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.28).
### v0.0.27 2025-02-26
#### What's Changed
  * Add `FallbackModel` support by [@sydney-runkle](https://github.com/sydney-runkle) in [#894](https://github.com/pydantic/pydantic-ai/pull/894)
  * fix: send the right data format to gemini image input by [@Kludex](https://github.com/Kludex) in [#991](https://github.com/pydantic/pydantic-ai/pull/991)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.26...v0.0.27).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.27).
### v0.0.26 2025-02-25
#### What's Changed
  * Support multimodal inputs by [@Kludex](https://github.com/Kludex) in [#971](https://github.com/pydantic/pydantic-ai/pull/971)
  * Fix agent graph types by [@dmontagu](https://github.com/dmontagu) in [#983](https://github.com/pydantic/pydantic-ai/pull/983)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.25...v0.0.26).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.26).
### v0.0.25 2025-02-24
#### What's Changed
  * Add `InstrumentedModel` by [@alexmojaki](https://github.com/alexmojaki) in [#892](https://github.com/pydantic/pydantic-ai/pull/892)
  * Fix JSON streaming unicode issues with gemini by [@dmontagu](https://github.com/dmontagu) in [#917](https://github.com/pydantic/pydantic-ai/pull/917)
  * Remove stale `name` methods from openai and mistral models by [@sydney-runkle](https://github.com/sydney-runkle) in [#925](https://github.com/pydantic/pydantic-ai/pull/925)
  * Add placeholder API key for OpenAI compatible models by [@sydney-runkle](https://github.com/sydney-runkle) in [#929](https://github.com/pydantic/pydantic-ai/pull/929)
  * Add `request_stream` to `InstrumentedModel` by [@alexmojaki](https://github.com/alexmojaki) in [#922](https://github.com/pydantic/pydantic-ai/pull/922)
  * Add GraphRun object to make use of `next` more ergonomic by [@dmontagu](https://github.com/dmontagu) in [#833](https://github.com/pydantic/pydantic-ai/pull/833)
  * Use raw OTel and actual event loggers in `InstrumentedModel` by [@alexmojaki](https://github.com/alexmojaki) in [#945](https://github.com/pydantic/pydantic-ai/pull/945)
  * fix: anthropic parallel tool call results. by [@ioga](https://github.com/ioga) in [#653](https://github.com/pydantic/pydantic-ai/pull/653)


#### New Contributors
  * [@ioga](https://github.com/ioga) made their first contribution in [#653](https://github.com/pydantic/pydantic-ai/pull/653)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.24...v0.0.25).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.25).
### v0.0.24 2025-02-12
#### What's Changed
  * Remove now-invalid reference to graph extra from docs by [@dmontagu](https://github.com/dmontagu) in [#873](https://github.com/pydantic/pydantic-ai/pull/873)
  * New gemini 2.0 models for production by [@mvaldi](https://github.com/mvaldi) in [#880](https://github.com/pydantic/pydantic-ai/pull/880)
  * Remove `async` from` _get_model` by [@alexmojaki](https://github.com/alexmojaki) in [#893](https://github.com/pydantic/pydantic-ai/pull/893)
  * Populate `ModelResponse.model_name` from responses by [@alexmojaki](https://github.com/alexmojaki) in [#883](https://github.com/pydantic/pydantic-ai/pull/883)
  * Fix OpenAI Model for working with local Ollama without passing an API key by [@mageos](https://github.com/mageos) in [#874](https://github.com/pydantic/pydantic-ai/pull/874)
  * Use abstract properties for otel semantic attributes on models and stream responses by [@sydney-runkle](https://github.com/sydney-runkle) in [#904](https://github.com/pydantic/pydantic-ai/pull/904)


#### New Contributors
  * [@mvaldi](https://github.com/mvaldi) made their first contribution in [#880](https://github.com/pydantic/pydantic-ai/pull/880)
  * [@jexp](https://github.com/jexp) made their first contribution in [#876](https://github.com/pydantic/pydantic-ai/pull/876)
  * [@mageos](https://github.com/mageos) made their first contribution in [#874](https://github.com/pydantic/pydantic-ai/pull/874)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.23...v0.0.24).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.24).
### v0.0.23 2025-02-07
#### What's Changed
  * Fix error in evals example by [@samuelcolvin](https://github.com/samuelcolvin) in [#852](https://github.com/pydantic/pydantic-ai/pull/852)
  * Add `o3` support for `OpenAIModel` by [@sydney-runkle](https://github.com/sydney-runkle) in [#853](https://github.com/pydantic/pydantic-ai/pull/853)
  * Remove the `AgentModel` class by [@dmontagu](https://github.com/dmontagu) in [#800](https://github.com/pydantic/pydantic-ai/pull/800)
  * Support `reasoning_effort` param for `OpenAIModel` by [@sydney-runkle](https://github.com/sydney-runkle) in [#854](https://github.com/pydantic/pydantic-ai/pull/854)
  * Fix OpenAI env var tests following by [@samuelcolvin](https://github.com/samuelcolvin) in [#855](https://github.com/pydantic/pydantic-ai/pull/855)
  * Replace search UI with Algolia backed one by [@petyosi](https://github.com/petyosi) in [#845](https://github.com/pydantic/pydantic-ai/pull/845)
  * Add support for gemini safety settings by [@dAIsySHEng1](https://github.com/dAIsySHEng1) in [#790](https://github.com/pydantic/pydantic-ai/pull/790)
  * Fix: missing graph extra by [@mplemay](https://github.com/mplemay) in [#863](https://github.com/pydantic/pydantic-ai/pull/863)
  * Remove unnecessary `project_id == creds_id` check for vertexai by [@sydney-runkle](https://github.com/sydney-runkle) in [#862](https://github.com/pydantic/pydantic-ai/pull/862)
  * Using `model_name` and `system` model properties by [@sydney-runkle](https://github.com/sydney-runkle) in [#865](https://github.com/pydantic/pydantic-ai/pull/865)


#### New Contributors
  * [@mplemay](https://github.com/mplemay) made their first contribution in [#863](https://github.com/pydantic/pydantic-ai/pull/863)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.22...v0.0.23).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.23).
### v0.0.22 2025-02-04
#### What's Changed
  * Port `pydantic_ai.Agent` to using `pydantic_graph` by [@dmontagu](https://github.com/dmontagu) in [#725](https://github.com/pydantic/pydantic-ai/pull/725)
  * PR previews by [@samuelcolvin](https://github.com/samuelcolvin) in [#815](https://github.com/pydantic/pydantic-ai/pull/815)
  * Various docs improvements by [@sydney-runkle](https://github.com/sydney-runkle) in [#809](https://github.com/pydantic/pydantic-ai/pull/809)
  * Adding new gemini experimental models by [@sydney-runkle](https://github.com/sydney-runkle) in [#811](https://github.com/pydantic/pydantic-ai/pull/811)
  * Various minor fixes by [@dmontagu](https://github.com/dmontagu) in [#834](https://github.com/pydantic/pydantic-ai/pull/834)
  * Build docs for python<3.12 by [@samuelcolvin](https://github.com/samuelcolvin) in [#841](https://github.com/pydantic/pydantic-ai/pull/841)
  * Weather Agent Sample: Only include `tool_call_id` to chatbot.append if it's set by [@chug2k](https://github.com/chug2k) in [#771](https://github.com/pydantic/pydantic-ai/pull/771)
  * Support locally served models which do not require an api key by [@mikeedjones](https://github.com/mikeedjones) in [#814](https://github.com/pydantic/pydantic-ai/pull/814)


#### New Contributors
  * [@chug2k](https://github.com/chug2k) made their first contribution in [#771](https://github.com/pydantic/pydantic-ai/pull/771)
  * [@mikeedjones](https://github.com/mikeedjones) made their first contribution in [#814](https://github.com/pydantic/pydantic-ai/pull/814)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.21...v0.0.22).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.22).
### v0.0.21 2025-01-30
#### What's Changed
  * Update index.md by [@kauabh](https://github.com/kauabh) in [#759](https://github.com/pydantic/pydantic-ai/pull/759)
  * Add codespell support (config, workflow to detect/not fix) and make it fix few typos by [@yarikoptic](https://github.com/yarikoptic) in [#757](https://github.com/pydantic/pydantic-ai/pull/757)
  * Ensure custom args are used when retried by [@jlowin](https://github.com/jlowin) in [#692](https://github.com/pydantic/pydantic-ai/pull/692)
  * update `AgentDeps` refs to `AgentDepsT` by [@zzstoatzz](https://github.com/zzstoatzz) in [#767](https://github.com/pydantic/pydantic-ai/pull/767)
  * Adding subclasses of `ModelSettings` to support specialized model requests by [@sydney-runkle](https://github.com/sydney-runkle) in [#766](https://github.com/pydantic/pydantic-ai/pull/766)
  * Remove `_utils.Either` by [@dmontagu](https://github.com/dmontagu) in [#768](https://github.com/pydantic/pydantic-ai/pull/768)
  * Remove ArgsDict and ArgsJson by [@dmontagu](https://github.com/dmontagu) in [#769](https://github.com/pydantic/pydantic-ai/pull/769)
  * Fix typo in Google VertexAIModel documentation (mkdocs) by [@chris-dare](https://github.com/chris-dare) in [#772](https://github.com/pydantic/pydantic-ai/pull/772)
  * Fix CI by removing references to shutdown groq models by [@dmontagu](https://github.com/dmontagu) in [#780](https://github.com/pydantic/pydantic-ai/pull/780)
  * Updated Docs by [@kauabh](https://github.com/kauabh) in [#773](https://github.com/pydantic/pydantic-ai/pull/773)
  * Clean up known model names by [@dmontagu](https://github.com/dmontagu) in [#781](https://github.com/pydantic/pydantic-ai/pull/781)
  * Update Function tools docs with usage of `docstring_format` and `require_parameter_descriptions` by [@chris-dare](https://github.com/chris-dare) in [#776](https://github.com/pydantic/pydantic-ai/pull/776)
  * Disable running gemini tests in test_live.py by [@dmontagu](https://github.com/dmontagu) in [#788](https://github.com/pydantic/pydantic-ai/pull/788)
  * Update graph.md by [@kauabh](https://github.com/kauabh) in [#791](https://github.com/pydantic/pydantic-ai/pull/791)
  * Minor clean up in preparation of graph agent by [@dmontagu](https://github.com/dmontagu) in [#779](https://github.com/pydantic/pydantic-ai/pull/779)
  * Fix o1 usage with tool calls by [@sydney-runkle](https://github.com/sydney-runkle) in [#764](https://github.com/pydantic/pydantic-ai/pull/764)
  * added documentation to visualize a graph within a jupyter-notebook by [@jonathanbouchet](https://github.com/jonathanbouchet) in [#786](https://github.com/pydantic/pydantic-ai/pull/786)
  * Remove `OllamaModel` in favor of usage with `OpenAIModel` by [@sydney-runkle](https://github.com/sydney-runkle) in [#805](https://github.com/pydantic/pydantic-ai/pull/805)
  * Docs fix: use model provider prefix in all examples by [@sydney-runkle](https://github.com/sydney-runkle) in [#806](https://github.com/pydantic/pydantic-ai/pull/806)
  * Add `Cohere` docs and additional (live) tests by [@sydney-runkle](https://github.com/sydney-runkle) in [#810](https://github.com/pydantic/pydantic-ai/pull/810)
  * uprev to 0.0.21 by [@samuelcolvin](https://github.com/samuelcolvin) in [#813](https://github.com/pydantic/pydantic-ai/pull/813)


#### New Contributors
  * [@kauabh](https://github.com/kauabh) made their first contribution in [#759](https://github.com/pydantic/pydantic-ai/pull/759)
  * [@yarikoptic](https://github.com/yarikoptic) made their first contribution in [#757](https://github.com/pydantic/pydantic-ai/pull/757)
  * [@chris-dare](https://github.com/chris-dare) made their first contribution in [#772](https://github.com/pydantic/pydantic-ai/pull/772)
  * [@jonathanbouchet](https://github.com/jonathanbouchet) made their first contribution in [#786](https://github.com/pydantic/pydantic-ai/pull/786)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.20...v0.0.21).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.21).
### v0.0.20 2025-01-23
#### What's Changed
  * Add missing `allow_model_requests` check by [@YanSte](https://github.com/YanSte) in [#697](https://github.com/pydantic/pydantic-ai/pull/697)
  * Improve Algolia indexing by [@petyosi](https://github.com/petyosi) in [#721](https://github.com/pydantic/pydantic-ai/pull/721)
  * Add support for Cohere models by [@rafidka](https://github.com/rafidka) in [#203](https://github.com/pydantic/pydantic-ai/pull/203)
  * Add `model_name` to `ModelResponse` by [@sydney-runkle](https://github.com/sydney-runkle) in [#701](https://github.com/pydantic/pydantic-ai/pull/701)
  * Adding `'deepseek-r1'` to the list of Ollama Model Names by [@izzyacademy](https://github.com/izzyacademy) in [#735](https://github.com/pydantic/pydantic-ai/pull/735)
  * Test minimum versions by [@samuelcolvin](https://github.com/samuelcolvin) in [#743](https://github.com/pydantic/pydantic-ai/pull/743)
  * Fix handling of OpenAI system prompts in order to support `o1` by [@sydney-runkle](https://github.com/sydney-runkle) in [#740](https://github.com/pydantic/pydantic-ai/pull/740)
  * Removing `from_text` and `from_tool_call` utilities that complicate snapshot testing by [@sydney-runkle](https://github.com/sydney-runkle) in [#744](https://github.com/pydantic/pydantic-ai/pull/744)
  * Add support for controlling direction of state diagram generated by Mermaid code by [@izzyacademy](https://github.com/izzyacademy) in [#716](https://github.com/pydantic/pydantic-ai/pull/716)
  * Increase default `IsNow()` delta by [@dmontagu](https://github.com/dmontagu) in [#746](https://github.com/pydantic/pydantic-ai/pull/746)
  * Auto-use the `set_event_loop` fixture by [@dmontagu](https://github.com/dmontagu) in [#747](https://github.com/pydantic/pydantic-ai/pull/747)
  * Make non-required parameters not required by [@dmontagu](https://github.com/dmontagu) in [#742](https://github.com/pydantic/pydantic-ai/pull/742)
  * Improve variance of classes by [@dmontagu](https://github.com/dmontagu) in [#726](https://github.com/pydantic/pydantic-ai/pull/726)
  * Support `parallel_tool_calls` in `ModelSettings` by [@sydney-runkle](https://github.com/sydney-runkle) in [#750](https://github.com/pydantic/pydantic-ai/pull/750)
  * Add support for `user` role system prompts `o1-preview-2024-09-12` by [@siavashg](https://github.com/siavashg) in [#754](https://github.com/pydantic/pydantic-ai/pull/754)
  * Anthropic streaming support by [@piercefreeman](https://github.com/piercefreeman) in [#684](https://github.com/pydantic/pydantic-ai/pull/684)
  * Fix an issue with retry counting by [@dmontagu](https://github.com/dmontagu) in [#749](https://github.com/pydantic/pydantic-ai/pull/749)


#### New Contributors
  * [@rafidka](https://github.com/rafidka) made their first contribution in [#203](https://github.com/pydantic/pydantic-ai/pull/203)
  * [@hrahmadi71](https://github.com/hrahmadi71) made their first contribution in [#753](https://github.com/pydantic/pydantic-ai/pull/753)
  * [@siavashg](https://github.com/siavashg) made their first contribution in [#754](https://github.com/pydantic/pydantic-ai/pull/754)
  * [@piercefreeman](https://github.com/piercefreeman) made their first contribution in [#684](https://github.com/pydantic/pydantic-ai/pull/684)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.19...v0.0.20).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.20).
### v0.0.19 2025-01-15
#### What's Changed
  * Docs: add `asyncio` to all examples that need it. by [@ME-Msc](https://github.com/ME-Msc) in [#638](https://github.com/pydantic/pydantic-ai/pull/638)
  * fix: typo by [@hwong557](https://github.com/hwong557) in [#641](https://github.com/pydantic/pydantic-ai/pull/641)
  * Add Gradio Demo for weather agent example by [@freddyaboulton](https://github.com/freddyaboulton) in [#230](https://github.com/pydantic/pydantic-ai/pull/230)
  * Docs: fix freeze frame for gradio demo video by [@sydney-runkle](https://github.com/sydney-runkle) in [#644](https://github.com/pydantic/pydantic-ai/pull/644)
  * Support `docstring_format` and `require_parameter_descriptions` on tools by [@sydney-runkle](https://github.com/sydney-runkle) in [#643](https://github.com/pydantic/pydantic-ai/pull/643)
  * Generate llms.txt by [@petyosi](https://github.com/petyosi) in [#649](https://github.com/pydantic/pydantic-ai/pull/649)
  * Refactor streaming by [@dmontagu](https://github.com/dmontagu) in [#468](https://github.com/pydantic/pydantic-ai/pull/468)
  * Adds `phi4` to Ollama by [@josead](https://github.com/josead) in [#668](https://github.com/pydantic/pydantic-ai/pull/668)
  * Use Algolia for docs search by [@petyosi](https://github.com/petyosi) in [#669](https://github.com/pydantic/pydantic-ai/pull/669)
  * Fix agent `run`/ `run_sync` docs by [@KranthiGV](https://github.com/KranthiGV) in [#688](https://github.com/pydantic/pydantic-ai/pull/688)
  * docs: fix typos in `testing-evals` and RAG example by [@lealre](https://github.com/lealre) in [#694](https://github.com/pydantic/pydantic-ai/pull/694)
  * Graph Support by [@samuelcolvin](https://github.com/samuelcolvin) in [#528](https://github.com/pydantic/pydantic-ai/pull/528)
  * Upgrade "inline-snapshot" by [@samuelcolvin](https://github.com/samuelcolvin) in [#657](https://github.com/pydantic/pydantic-ai/pull/657)
  * uprev to v0.0.19 by [@samuelcolvin](https://github.com/samuelcolvin) in [#696](https://github.com/pydantic/pydantic-ai/pull/696)


#### New Contributors
  * [@ME-Msc](https://github.com/ME-Msc) made their first contribution in [#638](https://github.com/pydantic/pydantic-ai/pull/638)
  * [@hwong557](https://github.com/hwong557) made their first contribution in [#641](https://github.com/pydantic/pydantic-ai/pull/641)
  * [@freddyaboulton](https://github.com/freddyaboulton) made their first contribution in [#230](https://github.com/pydantic/pydantic-ai/pull/230)
  * [@petyosi](https://github.com/petyosi) made their first contribution in [#649](https://github.com/pydantic/pydantic-ai/pull/649)
  * [@KranthiGV](https://github.com/KranthiGV) made their first contribution in [#688](https://github.com/pydantic/pydantic-ai/pull/688)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.18...v0.0.19).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.19).
### v0.0.18 2025-01-07
#### What's Changed
  * Added docs contribution docs, a troubleshooting item for docs changes by [@andrewdmalone](https://github.com/andrewdmalone) in [#600](https://github.com/pydantic/pydantic-ai/pull/600)
  * Improve null handling for Gemini by [@dmontagu](https://github.com/dmontagu) in [#608](https://github.com/pydantic/pydantic-ai/pull/608)
  * Improve string format handling for gemini by [@dmontagu](https://github.com/dmontagu) in [#609](https://github.com/pydantic/pydantic-ai/pull/609)
  * Suppress griffe logging related to return type by [@dmontagu](https://github.com/dmontagu) in [#606](https://github.com/pydantic/pydantic-ai/pull/606)
  * readme links by [@samuelcolvin](https://github.com/samuelcolvin) in [#622](https://github.com/pydantic/pydantic-ai/pull/622)
  * Docs: Add screenshot for chat-app example. by [@hengoren](https://github.com/hengoren) in [#612](https://github.com/pydantic/pydantic-ai/pull/612)
  * docs: add OpenAI-compatible models section for Grok (xAI) and DeepSeek by [@imfing](https://github.com/imfing) in [#613](https://github.com/pydantic/pydantic-ai/pull/613)
  * add diff coverage check by [@samuelcolvin](https://github.com/samuelcolvin) in [#623](https://github.com/pydantic/pydantic-ai/pull/623)
  * set `UV_FROZEN` globally in CI by [@samuelcolvin](https://github.com/samuelcolvin) in [#626](https://github.com/pydantic/pydantic-ai/pull/626)
  * Adds `dynamic` to `system_prompt` decorator, allowing reevaluation by [@josead](https://github.com/josead) in [#560](https://github.com/pydantic/pydantic-ai/pull/560)
  * Use `--reinstall` instead of uninstall/install for docs insiders packages by [@T-256](https://github.com/T-256) in [#627](https://github.com/pydantic/pydantic-ai/pull/627)
  * Custom `result_type` on a run by [@samuelcolvin](https://github.com/samuelcolvin) in [#629](https://github.com/pydantic/pydantic-ai/pull/629)
  * Prefix all models with provider for consistency by [@sydney-runkle](https://github.com/sydney-runkle) in [#593](https://github.com/pydantic/pydantic-ai/pull/593)
  * prepare for v0.0.18 by [@samuelcolvin](https://github.com/samuelcolvin) in [#635](https://github.com/pydantic/pydantic-ai/pull/635)


#### New Contributors
  * [@hengoren](https://github.com/hengoren) made their first contribution in [#612](https://github.com/pydantic/pydantic-ai/pull/612)
  * [@josead](https://github.com/josead) made their first contribution in [#560](https://github.com/pydantic/pydantic-ai/pull/560)
  * [@T-256](https://github.com/T-256) made their first contribution in [#627](https://github.com/pydantic/pydantic-ai/pull/627)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.17...v0.0.18).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.18).
### v0.0.17 2025-01-03
#### What's Changed
  * Multi-agent application documentation by [@samuelcolvin](https://github.com/samuelcolvin) in [#541](https://github.com/pydantic/pydantic-ai/pull/541)
  * Added troubleshooting section to the docs page by [@andrewdmalone](https://github.com/andrewdmalone) in [#583](https://github.com/pydantic/pydantic-ai/pull/583)
  * GCP VertexAI: pass explicit `scope` to `google.auth.default()` by [@jtbaker](https://github.com/jtbaker) in [#579](https://github.com/pydantic/pydantic-ai/pull/579)
  * Docs fix - remove unnecessary line in multi agent docs by [@sydney-runkle](https://github.com/sydney-runkle) in [#588](https://github.com/pydantic/pydantic-ai/pull/588)
  * Fix parallel Gemini function calls by [@montasaurus](https://github.com/montasaurus) in [#585](https://github.com/pydantic/pydantic-ai/pull/585)
  * Add troubleshooting docs by [@dAIsySHEng1](https://github.com/dAIsySHEng1) in [#584](https://github.com/pydantic/pydantic-ai/pull/584)
  * Docs fix - change to pydantic-ai.git on contributing page by [@dAIsySHEng1](https://github.com/dAIsySHEng1) in [#590](https://github.com/pydantic/pydantic-ai/pull/590)
  * `AgentDeps` default to `None`. by [@samuelcolvin](https://github.com/samuelcolvin) in [#592](https://github.com/pydantic/pydantic-ai/pull/592)
  * added support for formatting examples by [@abhishekvarma12345](https://github.com/abhishekvarma12345) in [#515](https://github.com/pydantic/pydantic-ai/pull/515)
  * fix: update module name and include devtools as dev dependency for example scripts by [@w121211](https://github.com/w121211) in [#597](https://github.com/pydantic/pydantic-ai/pull/597)
  * uprev to 0.0.17 by [@samuelcolvin](https://github.com/samuelcolvin) in [#604](https://github.com/pydantic/pydantic-ai/pull/604)


#### New Contributors
  * [@andrewdmalone](https://github.com/andrewdmalone) made their first contribution in [#583](https://github.com/pydantic/pydantic-ai/pull/583)
  * [@jtbaker](https://github.com/jtbaker) made their first contribution in [#579](https://github.com/pydantic/pydantic-ai/pull/579)
  * [@dAIsySHEng1](https://github.com/dAIsySHEng1) made their first contribution in [#584](https://github.com/pydantic/pydantic-ai/pull/584)
  * [@abhishekvarma12345](https://github.com/abhishekvarma12345) made their first contribution in [#515](https://github.com/pydantic/pydantic-ai/pull/515)
  * [@w121211](https://github.com/w121211) made their first contribution in [#597](https://github.com/pydantic/pydantic-ai/pull/597)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.16...v0.0.17).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.17).
### v0.0.16 2024-12-30
#### What's Changed
  * multi-agent usage by [@samuelcolvin](https://github.com/samuelcolvin) in [#538](https://github.com/pydantic/pydantic-ai/pull/538)
  * support `X | None = None` with Gemini by [@samuelcolvin](https://github.com/samuelcolvin) in [#540](https://github.com/pydantic/pydantic-ai/pull/540)
  * Link to diff in version warning by [@samuelcolvin](https://github.com/samuelcolvin) in [#542](https://github.com/pydantic/pydantic-ai/pull/542)
  * fix docs icons by [@samuelcolvin](https://github.com/samuelcolvin) in [#549](https://github.com/pydantic/pydantic-ai/pull/549)
  * Use Griffe's public API by [@pawamoy](https://github.com/pawamoy) in [#550](https://github.com/pydantic/pydantic-ai/pull/550)
  * Clean `chat_app` example by [@DurandA](https://github.com/DurandA) in [#553](https://github.com/pydantic/pydantic-ai/pull/553)
  * Gemini empty text by [@samuelcolvin](https://github.com/samuelcolvin) in [#568](https://github.com/pydantic/pydantic-ai/pull/568)
  * correct chat app ordering by [@samuelcolvin](https://github.com/samuelcolvin) in [#569](https://github.com/pydantic/pydantic-ai/pull/569)
  * Add Ollama API Key Configuration Support by [@ruanwz](https://github.com/ruanwz) in [#566](https://github.com/pydantic/pydantic-ai/pull/566)
  * extend `RunContext` by [@samuelcolvin](https://github.com/samuelcolvin) in [#570](https://github.com/pydantic/pydantic-ai/pull/570)
  * Make `capture_run_messages` support nested agent calls by [@samuelcolvin](https://github.com/samuelcolvin) in [#573](https://github.com/pydantic/pydantic-ai/pull/573)
  * Ensure `TestModel` handles result retries correctly by [@jlowin](https://github.com/jlowin) in [#572](https://github.com/pydantic/pydantic-ai/pull/572)
  * uprev to v0.0.16 by [@samuelcolvin](https://github.com/samuelcolvin) in [#574](https://github.com/pydantic/pydantic-ai/pull/574)


#### New Contributors
  * [@pawamoy](https://github.com/pawamoy) made their first contribution in [#550](https://github.com/pydantic/pydantic-ai/pull/550)
  * [@ruanwz](https://github.com/ruanwz) made their first contribution in [#566](https://github.com/pydantic/pydantic-ai/pull/566)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.15...v0.0.16).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.16).
### v0.0.15 2024-12-23
#### What's Changed
  * docs: fix typo in pydantic link for /api/models/gemini/ by [@lealre](https://github.com/lealre) in [#506](https://github.com/pydantic/pydantic-ai/pull/506)
  * Prioritize tool calls over eager text responses by [@sydney-runkle](https://github.com/sydney-runkle) in [#505](https://github.com/pydantic/pydantic-ai/pull/505)
  * add a default to `ResultData`, some related cleanup by [@samuelcolvin](https://github.com/samuelcolvin) in [#512](https://github.com/pydantic/pydantic-ai/pull/512)
  * Fix typo in type checking note by [@juanfiguera](https://github.com/juanfiguera) in [#518](https://github.com/pydantic/pydantic-ai/pull/518)
  * docs: fix typo in `Agents` page by [@lealre](https://github.com/lealre) in [#521](https://github.com/pydantic/pydantic-ai/pull/521)
  * Adding commentary and tests re heterogenous behavior by [@sydney-runkle](https://github.com/sydney-runkle) in [#517](https://github.com/pydantic/pydantic-ai/pull/517)
  * fix settings docs formatting by [@samuelcolvin](https://github.com/samuelcolvin) in [#524](https://github.com/pydantic/pydantic-ai/pull/524)
  * Add warning about being ahead of release by [@samuelcolvin](https://github.com/samuelcolvin) in [#525](https://github.com/pydantic/pydantic-ai/pull/525)
  * Reorganize examples by [@dmontagu](https://github.com/dmontagu) in [#507](https://github.com/pydantic/pydantic-ai/pull/507)
  * tweak warning rendering by [@samuelcolvin](https://github.com/samuelcolvin) in [#526](https://github.com/pydantic/pydantic-ai/pull/526)
  * Remove `last_run_messages`, add `capture_run_messages` by [@samuelcolvin](https://github.com/samuelcolvin) in [#536](https://github.com/pydantic/pydantic-ai/pull/536)
  * Mistral optimised by [@YanSte](https://github.com/YanSte) in [#396](https://github.com/pydantic/pydantic-ai/pull/396)
  * prepare for v0.0.15 by [@samuelcolvin](https://github.com/samuelcolvin) in [#537](https://github.com/pydantic/pydantic-ai/pull/537)


#### New Contributors
  * [@lealre](https://github.com/lealre) made their first contribution in [#506](https://github.com/pydantic/pydantic-ai/pull/506)
  * [@juanfiguera](https://github.com/juanfiguera) made their first contribution in [#518](https://github.com/pydantic/pydantic-ai/pull/518)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.14...v0.0.15).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.15).
### v0.0.14 2024-12-19
#### What's Changed
  * Fix `ModelMessage` discriminator in chat_app example by [@DurandA](https://github.com/DurandA) in [#402](https://github.com/pydantic/pydantic-ai/pull/402)
  * Ignore empty text parts by [@samuelcolvin](https://github.com/samuelcolvin) in [#466](https://github.com/pydantic/pydantic-ai/pull/466)
  * Rename `Cost` to `Usage` by [@dmontagu](https://github.com/dmontagu) in [#403](https://github.com/pydantic/pydantic-ai/pull/403)
  * Add support for usage limits by [@dmontagu](https://github.com/dmontagu) in [#409](https://github.com/pydantic/pydantic-ai/pull/409)
  * Fix error when getting messages from DB in chat_app example by [@DurandA](https://github.com/DurandA) in [#488](https://github.com/pydantic/pydantic-ai/pull/488)
  * Docs: add grids, tables to make intro info easier to digest by [@sydney-runkle](https://github.com/sydney-runkle) in [#276](https://github.com/pydantic/pydantic-ai/pull/276)
  * Add `openai:o1` model support by [@sydney-runkle](https://github.com/sydney-runkle) in [#498](https://github.com/pydantic/pydantic-ai/pull/498)
  * Use `RunContext` more widely by [@samuelcolvin](https://github.com/samuelcolvin) in [#500](https://github.com/pydantic/pydantic-ai/pull/500)
  * Make args handling more robust by [@dmontagu](https://github.com/dmontagu) in [#489](https://github.com/pydantic/pydantic-ai/pull/489)


#### New Contributors
  * [@imfing](https://github.com/imfing) made their first contribution in [#281](https://github.com/pydantic/pydantic-ai/pull/281)
  * [@DurandA](https://github.com/DurandA) made their first contribution in [#402](https://github.com/pydantic/pydantic-ai/pull/402)
  * [@Kludex](https://github.com/Kludex) made their first contribution in [#467](https://github.com/pydantic/pydantic-ai/pull/467)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.13...v0.0.14).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.14).
### v0.0.13 2024-12-16
#### Breaking changes
All releases prior to V1 can contain breaking changes according to [semvar](https://semver.org/), but this release contains more than usual:
  * The format of [messages](https://ai.pydantic.dev/api/messages/) has changed significantly since the last release, see [#232](https://github.com/pydantic/pydantic-ai/pull/232) and [#259](https://github.com/pydantic/pydantic-ai/pull/259)
  * more messages/parts are added that before as a result of adding [`ToolReturnPart`](https://ai.pydantic.dev/api/messages/###pydantic_ai.messages.ToolReturnPart) for each tool call, see [#184](https://github.com/pydantic/pydantic-ai/pull/184) and [#274](https://github.com/pydantic/pydantic-ai/pull/274)
  * given how much we've changed since the last release, other things have probably changed along the way


#### What's Changed
  * Minor docs updates by [@sydney-runkle](https://github.com/sydney-runkle) in [#159](https://github.com/pydantic/pydantic-ai/pull/159)
  * use sqlite for chat_app example by [@samuelcolvin](https://github.com/samuelcolvin) in [#107](https://github.com/pydantic/pydantic-ai/pull/107)
  * Rename tool_id to tool_call_id by [@dmontagu](https://github.com/dmontagu) in [#206](https://github.com/pydantic/pydantic-ai/pull/206)
  * upate docs to include remote server example by [@cal859](https://github.com/cal859) in [#210](https://github.com/pydantic/pydantic-ai/pull/210)
  * Add new llama-3.3-70b-versatile to GroqModelName by [@kenjihikmatullah](https://github.com/kenjihikmatullah) in [#202](https://github.com/pydantic/pydantic-ai/pull/202)
  * Documentation: minor spelling and phrasing fixes by [@carlsonp](https://github.com/carlsonp) in [#212](https://github.com/pydantic/pydantic-ai/pull/212)
  * Adding a minimal contributing guide by [@sydney-runkle](https://github.com/sydney-runkle) in [#213](https://github.com/pydantic/pydantic-ai/pull/213)
  * Add note about jupyter workaround for conflicting event loops by [@sydney-runkle](https://github.com/sydney-runkle) in [#214](https://github.com/pydantic/pydantic-ai/pull/214)
  * Standardize "py" -> "python" in code blocks with pre-commit by [@sydney-runkle](https://github.com/sydney-runkle) in [#217](https://github.com/pydantic/pydantic-ai/pull/217)
  * Add Anthropic (non-streaming) Support by [@sydney-runkle](https://github.com/sydney-runkle) in [#193](https://github.com/pydantic/pydantic-ai/pull/193)
  * fix double anthropic reference by [@montasaurus](https://github.com/montasaurus) in [#222](https://github.com/pydantic/pydantic-ai/pull/222)
  * Add support for new Gemini model 'gemini-2.0-flash-exp' by [@Etelis](https://github.com/Etelis) in [#223](https://github.com/pydantic/pydantic-ai/pull/223)
  * Move description onto tool when appropriate by [@samuelcolvin](https://github.com/samuelcolvin) in [#228](https://github.com/pydantic/pydantic-ai/pull/228)
  * fix formatting of `tests/test_tools.py` by [@samuelcolvin](https://github.com/samuelcolvin) in [#229](https://github.com/pydantic/pydantic-ai/pull/229)
  * Move function tools docs to a new page by [@samuelcolvin](https://github.com/samuelcolvin) in [#231](https://github.com/pydantic/pydantic-ai/pull/231)
  * added makefile help target by [@janas-adam](https://github.com/janas-adam) in [#226](https://github.com/pydantic/pydantic-ai/pull/226)
  * [docs] update contributing guide to indicate minimum `uv` version by [@zzstoatzz](https://github.com/zzstoatzz) in [#236](https://github.com/pydantic/pydantic-ai/pull/236)
  * Support tool calling when a structured result is provided by [@jlowin](https://github.com/jlowin) in [#184](https://github.com/pydantic/pydantic-ai/pull/184)
  * Basic `ModelSettings` logic by [@sydney-runkle](https://github.com/sydney-runkle) in [#227](https://github.com/pydantic/pydantic-ai/pull/227)
  * Unify model responses by [@dmontagu](https://github.com/dmontagu) in [#232](https://github.com/pydantic/pydantic-ai/pull/232)
  * Disable pyright reportUnnecessaryIsInstance by [@dmontagu](https://github.com/dmontagu) in [#244](https://github.com/pydantic/pydantic-ai/pull/244)
  * pin ollama action by [@samuelcolvin](https://github.com/samuelcolvin) in [#246](https://github.com/pydantic/pydantic-ai/pull/246)
  * Mistral Support by [@YanSte](https://github.com/YanSte) in [#173](https://github.com/pydantic/pydantic-ai/pull/173)
  * feat: add optional base_url kwarg to OpenAIModel by [@sambarnes](https://github.com/sambarnes) in [#243](https://github.com/pydantic/pydantic-ai/pull/243)
  * Update install.md for Ollama by [@Navanit-git](https://github.com/Navanit-git) in [#225](https://github.com/pydantic/pydantic-ai/pull/225)
  * live tests for mistral by [@samuelcolvin](https://github.com/samuelcolvin) in [#249](https://github.com/pydantic/pydantic-ai/pull/249)
  * Change: Internal Discriminator Modification by [@sydney-runkle](https://github.com/sydney-runkle) in [#247](https://github.com/pydantic/pydantic-ai/pull/247)
  * add model documentation by [@samuelcolvin](https://github.com/samuelcolvin) in [#250](https://github.com/pydantic/pydantic-ai/pull/250)
  * Formatting nitpicks in `messages.py` by [@sydney-runkle](https://github.com/sydney-runkle) in [#255](https://github.com/pydantic/pydantic-ai/pull/255)
  * Get chat app working with new messages format by [@sydney-runkle](https://github.com/sydney-runkle) in [#251](https://github.com/pydantic/pydantic-ai/pull/251)
  * Use `defer_build` with type adapters, not custom `_LazyTypeAdapter` by [@sydney-runkle](https://github.com/sydney-runkle) in [#253](https://github.com/pydantic/pydantic-ai/pull/253)
  * Use `isinstance` checks for message kinds by [@sydney-runkle](https://github.com/sydney-runkle) in [#252](https://github.com/pydantic/pydantic-ai/pull/252)
  * add `messages` to `RunContext` by [@samuelcolvin](https://github.com/samuelcolvin) in [#257](https://github.com/pydantic/pydantic-ai/pull/257)
  * Reformat messages so messages become simple `list[ModelRequest | ModelResponse]` by [@samuelcolvin](https://github.com/samuelcolvin) in [#259](https://github.com/pydantic/pydantic-ai/pull/259)
  * Fix typo in agent documentation example by [@Viicos](https://github.com/Viicos) in [#271](https://github.com/pydantic/pydantic-ai/pull/271)
  * Enhance Mistral: Improved Test Coverage, Code Optimization, and Bug Fixes by [@YanSte](https://github.com/YanSte) in [#263](https://github.com/pydantic/pydantic-ai/pull/263)
  * Streamed response messages by [@samuelcolvin](https://github.com/samuelcolvin) in [#274](https://github.com/pydantic/pydantic-ai/pull/274)
  * Fix doc error in ollama.md by [@asmith26](https://github.com/asmith26) in [#279](https://github.com/pydantic/pydantic-ai/pull/279)
  * Alternative intro by [@samuelcolvin](https://github.com/samuelcolvin) in [#270](https://github.com/pydantic/pydantic-ai/pull/270)
  * uprev to v0.0.13 by [@samuelcolvin](https://github.com/samuelcolvin) in [#280](https://github.com/pydantic/pydantic-ai/pull/280)


#### New Contributors
  * [@sydney-runkle](https://github.com/sydney-runkle) made their first contribution in [#159](https://github.com/pydantic/pydantic-ai/pull/159)
  * [@kenjihikmatullah](https://github.com/kenjihikmatullah) made their first contribution in [#202](https://github.com/pydantic/pydantic-ai/pull/202)
  * [@carlsonp](https://github.com/carlsonp) made their first contribution in [#212](https://github.com/pydantic/pydantic-ai/pull/212)
  * [@montasaurus](https://github.com/montasaurus) made their first contribution in [#222](https://github.com/pydantic/pydantic-ai/pull/222)
  * [@Etelis](https://github.com/Etelis) made their first contribution in [#223](https://github.com/pydantic/pydantic-ai/pull/223)
  * [@janas-adam](https://github.com/janas-adam) made their first contribution in [#226](https://github.com/pydantic/pydantic-ai/pull/226)
  * [@YanSte](https://github.com/YanSte) made their first contribution in [#173](https://github.com/pydantic/pydantic-ai/pull/173)
  * [@sambarnes](https://github.com/sambarnes) made their first contribution in [#243](https://github.com/pydantic/pydantic-ai/pull/243)
  * [@Navanit-git](https://github.com/Navanit-git) made their first contribution in [#225](https://github.com/pydantic/pydantic-ai/pull/225)
  * [@Viicos](https://github.com/Viicos) made their first contribution in [#271](https://github.com/pydantic/pydantic-ai/pull/271)
  * [@asmith26](https://github.com/asmith26) made their first contribution in [#279](https://github.com/pydantic/pydantic-ai/pull/279)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.12...v0.0.13).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.13).
### v0.0.12 2024-12-09
#### What's Changed
  * docs: update README.md by [@eltociear](https://github.com/eltociear) in [#165](https://github.com/pydantic/pydantic-ai/pull/165)
  * Dynamic tools by [@samuelcolvin](https://github.com/samuelcolvin) in [#157](https://github.com/pydantic/pydantic-ai/pull/157)
  * fix validation errors serialization by [@samuelcolvin](https://github.com/samuelcolvin) in [#176](https://github.com/pydantic/pydantic-ai/pull/176)
  * add note to docs about `.stream_text(delta=True)` by [@samuelcolvin](https://github.com/samuelcolvin) in [#178](https://github.com/pydantic/pydantic-ai/pull/178)
  * Generate tool results when using structured result by [@jlowin](https://github.com/jlowin) in [#179](https://github.com/pydantic/pydantic-ai/pull/179)
  * fix `IndexError` when streaming `OpenAI` by [@samuelcolvin](https://github.com/samuelcolvin) in [#181](https://github.com/pydantic/pydantic-ai/pull/181)
  * Ollama support by [@cal859](https://github.com/cal859) in [#162](https://github.com/pydantic/pydantic-ai/pull/162)
  * add tests for Ollama by [@samuelcolvin](https://github.com/samuelcolvin) in [#182](https://github.com/pydantic/pydantic-ai/pull/182)
  * uprev to v0.0.12 by [@samuelcolvin](https://github.com/samuelcolvin) in [#185](https://github.com/pydantic/pydantic-ai/pull/185)


#### New Contributors
  * [@eltociear](https://github.com/eltociear) made their first contribution in [#165](https://github.com/pydantic/pydantic-ai/pull/165)
  * [@jlowin](https://github.com/jlowin) made their first contribution in [#179](https://github.com/pydantic/pydantic-ai/pull/179)
  * [@cal859](https://github.com/cal859) made their first contribution in [#162](https://github.com/pydantic/pydantic-ai/pull/162)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.11...v0.0.12).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.12).
### v0.0.11 2024-12-06
#### What's Changed
  * fix agent name by [@samuelcolvin](https://github.com/samuelcolvin) in [#156](https://github.com/pydantic/pydantic-ai/pull/156)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.10...v0.0.11).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.11).
### v0.0.10 2024-12-06
#### What's Changed
  * Adding `Agent.name` by [@samuelcolvin](https://github.com/samuelcolvin) in [#141](https://github.com/pydantic/pydantic-ai/pull/141)
  * Update `bank_support.py` -- fix docstring typo by [@akgerber](https://github.com/akgerber) in [#143](https://github.com/pydantic/pydantic-ai/pull/143)
  * Add help page to docs by [@alexmojaki](https://github.com/alexmojaki) in [#147](https://github.com/pydantic/pydantic-ai/pull/147)
  * uprev to v0.0.10, fix `logfire` optional group by [@samuelcolvin](https://github.com/samuelcolvin) in [#154](https://github.com/pydantic/pydantic-ai/pull/154)


#### New Contributors
  * [@akgerber](https://github.com/akgerber) made their first contribution in [#143](https://github.com/pydantic/pydantic-ai/pull/143)
  * [@alexmojaki](https://github.com/alexmojaki) made their first contribution in [#147](https://github.com/pydantic/pydantic-ai/pull/147)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.9...v0.0.10).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.10).
### v0.0.9 2024-12-04
#### What's Changed
  * readme improvements by [@samuelcolvin](https://github.com/samuelcolvin) in [#109](https://github.com/pydantic/pydantic-ai/pull/109)
  * Fix typo: `nee` -> `need` by [@patrick91](https://github.com/patrick91) in [#111](https://github.com/pydantic/pydantic-ai/pull/111)
  * Update README.md to make the comment fitted in screen by [@hramezani](https://github.com/hramezani) in [#115](https://github.com/pydantic/pydantic-ai/pull/115)
  * add `.vscode/` to `.gitignore` by [@zzstoatzz](https://github.com/zzstoatzz) in [#113](https://github.com/pydantic/pydantic-ai/pull/113)
  * fix formatting of api docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#117](https://github.com/pydantic/pydantic-ai/pull/117)
  * add missing popovers to evals by [@samuelcolvin](https://github.com/samuelcolvin) in [#119](https://github.com/pydantic/pydantic-ai/pull/119)
  * Fix run sync by [@samuelcolvin](https://github.com/samuelcolvin) in [#124](https://github.com/pydantic/pydantic-ai/pull/124)
  * allow adding tools via `Agent(tools_[...])` by [@samuelcolvin](https://github.com/samuelcolvin) in [#128](https://github.com/pydantic/pydantic-ai/pull/128)
  * allow tools to return any by [@samuelcolvin](https://github.com/samuelcolvin) in [#136](https://github.com/pydantic/pydantic-ai/pull/136)
  * uprev to 0.0.9 by [@samuelcolvin](https://github.com/samuelcolvin) in [#137](https://github.com/pydantic/pydantic-ai/pull/137)


#### New Contributors
  * [@patrick91](https://github.com/patrick91) made their first contribution in [#111](https://github.com/pydantic/pydantic-ai/pull/111)
  * [@hramezani](https://github.com/hramezani) made their first contribution in [#115](https://github.com/pydantic/pydantic-ai/pull/115)
  * [@zzstoatzz](https://github.com/zzstoatzz) made their first contribution in [#113](https://github.com/pydantic/pydantic-ai/pull/113)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.8...v0.0.9).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.9).
### v0.0.8 2024-12-02
#### What's Changed
  * stop ignoring some D linting errors by [@samuelcolvin](https://github.com/samuelcolvin) in [#105](https://github.com/pydantic/pydantic-ai/pull/105)
  * Logfire docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#106](https://github.com/pydantic/pydantic-ai/pull/106)
  * add readme by [@samuelcolvin](https://github.com/samuelcolvin) in [#108](https://github.com/pydantic/pydantic-ai/pull/108)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.7...v0.0.8).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.8).
### v0.0.7 2024-11-29
#### What's Changed
  * fix numerous typos by [@samuelcolvin](https://github.com/samuelcolvin) in [#95](https://github.com/pydantic/pydantic-ai/pull/95)
  * Rename `retreiver` to `tool` by [@samuelcolvin](https://github.com/samuelcolvin) in [#96](https://github.com/pydantic/pydantic-ai/pull/96)
  * fix broken links and add type checking function by [@samuelcolvin](https://github.com/samuelcolvin) in [#97](https://github.com/pydantic/pydantic-ai/pull/97)
  * Install setup by [@samuelcolvin](https://github.com/samuelcolvin) in [#98](https://github.com/pydantic/pydantic-ai/pull/98)
  * adding docs for testing and evals by [@samuelcolvin](https://github.com/samuelcolvin) in [#99](https://github.com/pydantic/pydantic-ai/pull/99)
  * evals docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#100](https://github.com/pydantic/pydantic-ai/pull/100)
  * rename `CallContext` -> `RunContext` by [@samuelcolvin](https://github.com/samuelcolvin) in [#101](https://github.com/pydantic/pydantic-ai/pull/101)
  * improvements to docs index by [@samuelcolvin](https://github.com/samuelcolvin) in [#102](https://github.com/pydantic/pydantic-ai/pull/102)
  * test with `pydantic-ai-slim` only by [@samuelcolvin](https://github.com/samuelcolvin) in [#103](https://github.com/pydantic/pydantic-ai/pull/103)
  * uprev to v0.0.7 by [@samuelcolvin](https://github.com/samuelcolvin) in [#104](https://github.com/pydantic/pydantic-ai/pull/104)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.6...v0.0.7).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.7).
### v0.0.6 2024-11-25
#### What's Changed
  * Fix docs CI? by [@samuelcolvin](https://github.com/samuelcolvin) in [#87](https://github.com/pydantic/pydantic-ai/pull/87)
  * Add vertex AI by [@samuelcolvin](https://github.com/samuelcolvin) in [#85](https://github.com/pydantic/pydantic-ai/pull/85)
  * add Groq client support by [@ricklamers](https://github.com/ricklamers) in [#84](https://github.com/pydantic/pydantic-ai/pull/84)
  * fix `test-live` by [@samuelcolvin](https://github.com/samuelcolvin) in [#90](https://github.com/pydantic/pydantic-ai/pull/90)
  * Support VertexAI models in `infer_model` by [@samuelcolvin](https://github.com/samuelcolvin) in [#89](https://github.com/pydantic/pydantic-ai/pull/89)
  * Make openai optional by [@samuelcolvin](https://github.com/samuelcolvin) in [#91](https://github.com/pydantic/pydantic-ai/pull/91)
  * Uv workspaces and `pydantic-ai-slim` by [@samuelcolvin](https://github.com/samuelcolvin) in [#92](https://github.com/pydantic/pydantic-ai/pull/92)
  * uprev to v0.0.6 by [@samuelcolvin](https://github.com/samuelcolvin) in [#94](https://github.com/pydantic/pydantic-ai/pull/94)


#### New Contributors
  * [@ricklamers](https://github.com/ricklamers) made their first contribution in [#84](https://github.com/pydantic/pydantic-ai/pull/84)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.5...v0.0.6).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.6).
### v0.0.6a4 2024-11-25
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.6a4).
### v0.0.5 2024-11-20
#### What's Changed
  * Change behaviour to behavior by [@dmontagu](https://github.com/dmontagu) in [#76](https://github.com/pydantic/pydantic-ai/pull/76)
  * More minor cleanup by [@dmontagu](https://github.com/dmontagu) in [#77](https://github.com/pydantic/pydantic-ai/pull/77)
  * adding whale video by [@samuelcolvin](https://github.com/samuelcolvin) in [#78](https://github.com/pydantic/pydantic-ai/pull/78)
  * support Pydantic v2.10 by [@samuelcolvin](https://github.com/samuelcolvin) in [#79](https://github.com/pydantic/pydantic-ai/pull/79)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.4...v0.0.5).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.5).
### v0.0.4 2024-11-19
#### What's Changed
  * tweak agent docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#65](https://github.com/pydantic/pydantic-ai/pull/65)
  * tweaking index and other docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#66](https://github.com/pydantic/pydantic-ai/pull/66)
  * install improvements by [@samuelcolvin](https://github.com/samuelcolvin) in [#67](https://github.com/pydantic/pydantic-ai/pull/67)
  * rename `retriever_context` -> `retriever` by [@samuelcolvin](https://github.com/samuelcolvin) in [#68](https://github.com/pydantic/pydantic-ai/pull/68)
  * Decorator signatures by [@samuelcolvin](https://github.com/samuelcolvin) in [#69](https://github.com/pydantic/pydantic-ai/pull/69)
  * Index improvements by [@dmontagu](https://github.com/dmontagu) in [#73](https://github.com/pydantic/pydantic-ai/pull/73)
  * Replace dice diagram svgs with mermaid by [@dmontagu](https://github.com/dmontagu) in [#74](https://github.com/pydantic/pydantic-ai/pull/74)
  * Result docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#72](https://github.com/pydantic/pydantic-ai/pull/72)
  * coverage badge and uprev by [@samuelcolvin](https://github.com/samuelcolvin) in [#75](https://github.com/pydantic/pydantic-ai/pull/75)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.3...v0.0.4).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.4).
### v0.0.3 2024-11-19
#### What's Changed
  * uprev uv and distribute examples by [@samuelcolvin](https://github.com/samuelcolvin) in [#27](https://github.com/pydantic/pydantic-ai/pull/27)
  * chat app example by [@samuelcolvin](https://github.com/samuelcolvin) in [#28](https://github.com/pydantic/pydantic-ai/pull/28)
  * rename and split `shared.py` by [@samuelcolvin](https://github.com/samuelcolvin) in [#29](https://github.com/pydantic/pydantic-ai/pull/29)
  * tweak chat app by [@samuelcolvin](https://github.com/samuelcolvin) in [#30](https://github.com/pydantic/pydantic-ai/pull/30)
  * Streamed responses by [@samuelcolvin](https://github.com/samuelcolvin) in [#31](https://github.com/pydantic/pydantic-ai/pull/31)
  * Stream improvements by [@samuelcolvin](https://github.com/samuelcolvin) in [#33](https://github.com/pydantic/pydantic-ai/pull/33)
  * Rename `ToolCall` to `Structured` in most places by [@samuelcolvin](https://github.com/samuelcolvin) in [#34](https://github.com/pydantic/pydantic-ai/pull/34)
  * Remove agent error by [@samuelcolvin](https://github.com/samuelcolvin) in [#35](https://github.com/pydantic/pydantic-ai/pull/35)
  * revert to `ResultData`, rename method/attributes appropriately by [@samuelcolvin](https://github.com/samuelcolvin) in [#36](https://github.com/pydantic/pydantic-ai/pull/36)
  * Documentation by [@samuelcolvin](https://github.com/samuelcolvin) in [#37](https://github.com/pydantic/pydantic-ai/pull/37)
  * further docs improvements by [@samuelcolvin](https://github.com/samuelcolvin) in [#38](https://github.com/pydantic/pydantic-ai/pull/38)
  * remove `Either` from `_handle_model_response` and `_handle_streamed_model_response` by [@samuelcolvin](https://github.com/samuelcolvin) in [#39](https://github.com/pydantic/pydantic-ai/pull/39)
  * Change `Agent` initialization to take deps type, not deps by [@samuelcolvin](https://github.com/samuelcolvin) in [#40](https://github.com/pydantic/pydantic-ai/pull/40)
  * allow overriding deps, e.g. in testing by [@samuelcolvin](https://github.com/samuelcolvin) in [#41](https://github.com/pydantic/pydantic-ai/pull/41)
  * Gemini coverage and other tweaks by [@samuelcolvin](https://github.com/samuelcolvin) in [#42](https://github.com/pydantic/pydantic-ai/pull/42)
  * Docs insiders by [@samuelcolvin](https://github.com/samuelcolvin) in [#43](https://github.com/pydantic/pydantic-ai/pull/43)
  * Examples in docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#44](https://github.com/pydantic/pydantic-ai/pull/44)
  * adding logo by [@samuelcolvin](https://github.com/samuelcolvin) in [#45](https://github.com/pydantic/pydantic-ai/pull/45)
  * add docs stubs by [@samuelcolvin](https://github.com/samuelcolvin) in [#46](https://github.com/pydantic/pydantic-ai/pull/46)
  * docs social cards and cleanup by [@samuelcolvin](https://github.com/samuelcolvin) in [#47](https://github.com/pydantic/pydantic-ai/pull/47)
  * add streaming to chat app by [@samuelcolvin](https://github.com/samuelcolvin) in [#48](https://github.com/pydantic/pydantic-ai/pull/48)
  * test against real models by [@samuelcolvin](https://github.com/samuelcolvin) in [#49](https://github.com/pydantic/pydantic-ai/pull/49)
  * Better test functionality by [@samuelcolvin](https://github.com/samuelcolvin) in [#50](https://github.com/pydantic/pydantic-ai/pull/50)
  * Smokeshow coverage by [@samuelcolvin](https://github.com/samuelcolvin) in [#52](https://github.com/pydantic/pydantic-ai/pull/52)
  * Concepts docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#51](https://github.com/pydantic/pydantic-ai/pull/51)
  * Pytest examples by [@samuelcolvin](https://github.com/samuelcolvin) in [#53](https://github.com/pydantic/pydantic-ai/pull/53)
  * Agent docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#54](https://github.com/pydantic/pydantic-ai/pull/54)
  * fix header images by [@samuelcolvin](https://github.com/samuelcolvin) in [#55](https://github.com/pydantic/pydantic-ai/pull/55)
  * remove top menu by [@samuelcolvin](https://github.com/samuelcolvin) in [#56](https://github.com/pydantic/pydantic-ai/pull/56)
  * Try to fix menu by [@samuelcolvin](https://github.com/samuelcolvin) in [#57](https://github.com/pydantic/pydantic-ai/pull/57)
  * fixing agent docs and refactoring retriever return types by [@samuelcolvin](https://github.com/samuelcolvin) in [#60](https://github.com/pydantic/pydantic-ai/pull/60)
  * add UA to requests by [@samuelcolvin](https://github.com/samuelcolvin) in [#61](https://github.com/pydantic/pydantic-ai/pull/61)
  * Add back api docs by [@samuelcolvin](https://github.com/samuelcolvin) in [#62](https://github.com/pydantic/pydantic-ai/pull/62)
  * New intro by [@samuelcolvin](https://github.com/samuelcolvin) in [#64](https://github.com/pydantic/pydantic-ai/pull/64)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.2...v0.0.3).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.3).
### v0.0.2 2024-10-30
#### What's Changed
  * Add timezones by [@dmontagu](https://github.com/dmontagu) in [#25](https://github.com/pydantic/pydantic-ai/pull/25)
  * support `TypeAliasType` unions by [@samuelcolvin](https://github.com/samuelcolvin) in [#26](https://github.com/pydantic/pydantic-ai/pull/26)


#### New Contributors
  * [@dmontagu](https://github.com/dmontagu) made their first contribution in [#25](https://github.com/pydantic/pydantic-ai/pull/25)


[](https://github.com/pydantic/pydantic-ai/compare/v0.0.1...v0.0.2).
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.2).
### v0.0.1 2024-10-29
initial release 🎉
[](https://github.com/pydantic/pydantic-ai/releases/tag/v0.0.1).
© Pydantic Services Inc. 2024 to present
