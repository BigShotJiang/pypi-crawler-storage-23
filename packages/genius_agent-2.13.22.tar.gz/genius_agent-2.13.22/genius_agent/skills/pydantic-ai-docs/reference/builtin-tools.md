[ Skip to content ](https://ai.pydantic.dev/builtin-tools/#built-in-tools)
**Join us at the inaugural PyAI Conf in San Francisco on March 10th![Learn More](https://pyai.events/?utm_source=pydantic-ai) **
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI")
Pydantic AI
Built-in Tools
Type to start searching
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI") Pydantic AI
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
  * [ Pydantic AI  ](https://ai.pydantic.dev/)
  * [ Installation  ](https://ai.pydantic.dev/install/)
  * [ Getting Help  ](https://ai.pydantic.dev/help/)
  * [ Troubleshooting  ](https://ai.pydantic.dev/troubleshooting/)
  * [ Pydantic AI Gateway  ](https://ai.pydantic.dev/gateway/)
  * Documentation
    * Core Concepts
      * [ Agents  ](https://ai.pydantic.dev/agent/)
      * [ Dependencies  ](https://ai.pydantic.dev/dependencies/)
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Output  ](https://ai.pydantic.dev/output/)
      * [ Messages and chat history  ](https://ai.pydantic.dev/message-history/)
      * [ Direct Model Requests  ](https://ai.pydantic.dev/direct/)
    * Models & Providers
      * [ Overview  ](https://ai.pydantic.dev/models/overview/)
      * [ OpenAI  ](https://ai.pydantic.dev/models/openai/)
      * [ Anthropic  ](https://ai.pydantic.dev/models/anthropic/)
      * [ Google  ](https://ai.pydantic.dev/models/google/)
      * [ xAI  ](https://ai.pydantic.dev/models/xai/)
      * [ Bedrock  ](https://ai.pydantic.dev/models/bedrock/)
      * [ Cerebras  ](https://ai.pydantic.dev/models/cerebras/)
      * [ Cohere  ](https://ai.pydantic.dev/models/cohere/)
      * [ Groq  ](https://ai.pydantic.dev/models/groq/)
      * [ Hugging Face  ](https://ai.pydantic.dev/models/huggingface/)
      * [ Mistral  ](https://ai.pydantic.dev/models/mistral/)
      * [ OpenRouter  ](https://ai.pydantic.dev/models/openrouter/)
      * [ Outlines  ](https://ai.pydantic.dev/models/outlines/)
    * Tools & Toolsets
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Advanced Tool Features  ](https://ai.pydantic.dev/tools-advanced/)
      * [ Toolsets  ](https://ai.pydantic.dev/toolsets/)
      * [ Deferred Tools  ](https://ai.pydantic.dev/deferred-tools/)
      * Built-in Tools  [ Built-in Tools  ](https://ai.pydantic.dev/builtin-tools/)
        * [ Overview  ](https://ai.pydantic.dev/builtin-tools/#overview)
        * [ Dynamic Configuration  ](https://ai.pydantic.dev/builtin-tools/#dynamic-configuration)
        * [ Web Search Tool  ](https://ai.pydantic.dev/builtin-tools/#web-search-tool)
          * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support)
          * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage)
          * [ Configuration Options  ](https://ai.pydantic.dev/builtin-tools/#configuration-options)
            * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_1)
        * [ Code Execution Tool  ](https://ai.pydantic.dev/builtin-tools/#code-execution-tool)
          * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_2)
          * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_1)
        * [ Image Generation Tool  ](https://ai.pydantic.dev/builtin-tools/#image-generation-tool)
          * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_3)
          * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_2)
          * [ Configuration Options  ](https://ai.pydantic.dev/builtin-tools/#configuration-options_1)
            * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_4)
        * [ Web Fetch Tool  ](https://ai.pydantic.dev/builtin-tools/#web-fetch-tool)
          * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_5)
          * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_3)
          * [ Configuration Options  ](https://ai.pydantic.dev/builtin-tools/#configuration-options_2)
            * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_6)
        * [ Memory Tool  ](https://ai.pydantic.dev/builtin-tools/#memory-tool)
          * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_7)
          * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_4)
        * [ MCP Server Tool  ](https://ai.pydantic.dev/builtin-tools/#mcp-server-tool)
          * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_8)
          * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_5)
          * [ Configuration Options  ](https://ai.pydantic.dev/builtin-tools/#configuration-options_3)
            * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_9)
        * [ File Search Tool  ](https://ai.pydantic.dev/builtin-tools/#file-search-tool)
          * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_10)
          * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_6)
            * [ OpenAI Responses  ](https://ai.pydantic.dev/builtin-tools/#openai-responses)
            * [ Google (Gemini)  ](https://ai.pydantic.dev/builtin-tools/#google-gemini)
        * [ API Reference  ](https://ai.pydantic.dev/builtin-tools/#api-reference)
      * [ Common Tools  ](https://ai.pydantic.dev/common-tools/)
      * [ Third-Party Tools  ](https://ai.pydantic.dev/third-party-tools/)
    * Advanced Features
      * [ Image, Audio, Video & Document Input  ](https://ai.pydantic.dev/input/)
      * [ Thinking  ](https://ai.pydantic.dev/thinking/)
      * [ HTTP Request Retries  ](https://ai.pydantic.dev/retries/)
    * MCP
      * [ Overview  ](https://ai.pydantic.dev/mcp/overview/)
      * [ Client  ](https://ai.pydantic.dev/mcp/client/)
      * [ FastMCP Client  ](https://ai.pydantic.dev/mcp/fastmcp-client/)
      * [ Server  ](https://ai.pydantic.dev/mcp/server/)
    * [ Multi-Agent Patterns  ](https://ai.pydantic.dev/multi-agent-applications/)
    * [ Web Chat UI  ](https://ai.pydantic.dev/web/)
    * [ Embeddings  ](https://ai.pydantic.dev/embeddings/)
    * [ Testing  ](https://ai.pydantic.dev/testing/)
  * Pydantic Evals
    * [ Overview  ](https://ai.pydantic.dev/evals/)
    * Getting Started
      * [ Quick Start  ](https://ai.pydantic.dev/evals/quick-start/)
      * [ Core Concepts  ](https://ai.pydantic.dev/evals/core-concepts/)
    * Evaluators
      * [ Overview  ](https://ai.pydantic.dev/evals/evaluators/overview/)
      * [ Built-in Evaluators  ](https://ai.pydantic.dev/evals/evaluators/built-in/)
      * [ LLM Judge  ](https://ai.pydantic.dev/evals/evaluators/llm-judge/)
      * [ Custom Evaluators  ](https://ai.pydantic.dev/evals/evaluators/custom/)
      * [ Report Evaluators  ](https://ai.pydantic.dev/evals/evaluators/report-evaluators/)
      * [ Span-Based  ](https://ai.pydantic.dev/evals/evaluators/span-based/)
    * How-To Guides
      * [ Logfire Integration  ](https://ai.pydantic.dev/evals/how-to/logfire-integration/)
      * [ Dataset Management  ](https://ai.pydantic.dev/evals/how-to/dataset-management/)
      * [ Dataset Serialization  ](https://ai.pydantic.dev/evals/how-to/dataset-serialization/)
      * [ Concurrency & Performance  ](https://ai.pydantic.dev/evals/how-to/concurrency/)
      * [ Multi-Run Evaluation  ](https://ai.pydantic.dev/evals/how-to/multi-run/)
      * [ Retry Strategies  ](https://ai.pydantic.dev/evals/how-to/retry-strategies/)
      * [ Metrics & Attributes  ](https://ai.pydantic.dev/evals/how-to/metrics-attributes/)
    * Examples
      * [ Simple Validation  ](https://ai.pydantic.dev/evals/examples/simple-validation/)
  * Pydantic Graph
    * [ Overview  ](https://ai.pydantic.dev/graph/)
    * [ Beta API  ](https://ai.pydantic.dev/graph/beta/)
      * [ Steps  ](https://ai.pydantic.dev/graph/beta/steps/)
      * [ Joins & Reducers  ](https://ai.pydantic.dev/graph/beta/joins/)
      * [ Decisions  ](https://ai.pydantic.dev/graph/beta/decisions/)
      * [ Parallel Execution  ](https://ai.pydantic.dev/graph/beta/parallel/)
  * Integrations
    * [ Debugging & Monitoring with Pydantic Logfire  ](https://ai.pydantic.dev/logfire/)
    * Durable Execution
      * [ Overview  ](https://ai.pydantic.dev/durable_execution/overview/)
      * [ Temporal  ](https://ai.pydantic.dev/durable_execution/temporal/)
      * [ DBOS  ](https://ai.pydantic.dev/durable_execution/dbos/)
      * [ Prefect  ](https://ai.pydantic.dev/durable_execution/prefect/)
    * UI Event Streams
      * [ Overview  ](https://ai.pydantic.dev/ui/overview/)
      * [ AG-UI  ](https://ai.pydantic.dev/ui/ag-ui/)
      * [ Vercel AI  ](https://ai.pydantic.dev/ui/vercel-ai/)
    * [ Agent2Agent (A2A)  ](https://ai.pydantic.dev/a2a/)
  * Related Packages
    * [ clai  ](https://ai.pydantic.dev/cli/)
  * Examples
    * [ Setup  ](https://ai.pydantic.dev/examples/setup/)
    * Getting Started
      * [ Pydantic Model  ](https://ai.pydantic.dev/examples/pydantic-model/)
      * [ Weather agent  ](https://ai.pydantic.dev/examples/weather-agent/)
    * Conversational Agents
      * [ Chat App with FastAPI  ](https://ai.pydantic.dev/examples/chat-app/)
      * [ Bank support  ](https://ai.pydantic.dev/examples/bank-support/)
    * Data & Analytics
      * [ SQL Generation  ](https://ai.pydantic.dev/examples/sql-gen/)
      * [ Data Analyst  ](https://ai.pydantic.dev/examples/data-analyst/)
      * [ RAG  ](https://ai.pydantic.dev/examples/rag/)
    * Streaming
      * [ Stream markdown  ](https://ai.pydantic.dev/examples/stream-markdown/)
      * [ Stream whales  ](https://ai.pydantic.dev/examples/stream-whales/)
    * Complex Workflows
      * [ Flight booking  ](https://ai.pydantic.dev/examples/flight-booking/)
      * [ Question Graph  ](https://ai.pydantic.dev/examples/question-graph/)
    * Business Applications
      * [ Slack Lead Qualifier with Modal  ](https://ai.pydantic.dev/examples/slack-lead-qualifier/)
    * UI Examples
      * [ Agent User Interaction (AG-UI)  ](https://ai.pydantic.dev/examples/ag-ui/)
  * API Reference
    * pydantic_ai
      * [ pydantic_ai.ag_ui  ](https://ai.pydantic.dev/api/ag_ui/)
      * [ pydantic_ai.agent  ](https://ai.pydantic.dev/api/agent/)
      * [ pydantic_ai.builtin_tools  ](https://ai.pydantic.dev/api/builtin_tools/)
      * [ pydantic_ai.common_tools  ](https://ai.pydantic.dev/api/common_tools/)
      * [ pydantic_ai — Concurrency  ](https://ai.pydantic.dev/api/concurrency/)
      * [ pydantic_ai.direct  ](https://ai.pydantic.dev/api/direct/)
      * [ pydantic_ai.durable_exec  ](https://ai.pydantic.dev/api/durable_exec/)
      * [ pydantic_ai.embeddings  ](https://ai.pydantic.dev/api/embeddings/)
      * [ pydantic_ai.exceptions  ](https://ai.pydantic.dev/api/exceptions/)
      * [ pydantic_ai.ext  ](https://ai.pydantic.dev/api/ext/)
      * [ pydantic_ai.format_prompt  ](https://ai.pydantic.dev/api/format_prompt/)
      * [ pydantic_ai.mcp  ](https://ai.pydantic.dev/api/mcp/)
      * [ pydantic_ai.messages  ](https://ai.pydantic.dev/api/messages/)
      * [ pydantic_ai.models.anthropic  ](https://ai.pydantic.dev/api/models/anthropic/)
      * [ pydantic_ai.models  ](https://ai.pydantic.dev/api/models/base/)
      * [ pydantic_ai.models.bedrock  ](https://ai.pydantic.dev/api/models/bedrock/)
      * [ pydantic_ai.models.cerebras  ](https://ai.pydantic.dev/api/models/cerebras/)
      * [ pydantic_ai.models.cohere  ](https://ai.pydantic.dev/api/models/cohere/)
      * [ pydantic_ai.models.fallback  ](https://ai.pydantic.dev/api/models/fallback/)
      * [ pydantic_ai.models.function  ](https://ai.pydantic.dev/api/models/function/)
      * [ pydantic_ai.models.google  ](https://ai.pydantic.dev/api/models/google/)
      * [ pydantic_ai.models.xai  ](https://ai.pydantic.dev/api/models/xai/)
      * [ pydantic_ai.models.groq  ](https://ai.pydantic.dev/api/models/groq/)
      * [ pydantic_ai.models.huggingface  ](https://ai.pydantic.dev/api/models/huggingface/)
      * [ pydantic_ai.models.instrumented  ](https://ai.pydantic.dev/api/models/instrumented/)
      * [ pydantic_ai.models.mcp_sampling  ](https://ai.pydantic.dev/api/models/mcp-sampling/)
      * [ pydantic_ai.models.mistral  ](https://ai.pydantic.dev/api/models/mistral/)
      * [ pydantic_ai.models.openai  ](https://ai.pydantic.dev/api/models/openai/)
      * [ pydantic_ai.models.openrouter  ](https://ai.pydantic.dev/api/models/openrouter/)
      * [ pydantic_ai.models.outlines  ](https://ai.pydantic.dev/api/models/outlines/)
      * [ pydantic_ai.models.test  ](https://ai.pydantic.dev/api/models/test/)
      * [ pydantic_ai.models.wrapper  ](https://ai.pydantic.dev/api/models/wrapper/)
      * [ pydantic_ai.output  ](https://ai.pydantic.dev/api/output/)
      * [ pydantic_ai.profiles  ](https://ai.pydantic.dev/api/profiles/)
      * [ pydantic_ai.providers  ](https://ai.pydantic.dev/api/providers/)
      * [ pydantic_ai.result  ](https://ai.pydantic.dev/api/result/)
      * [ pydantic_ai.retries  ](https://ai.pydantic.dev/api/retries/)
      * [ pydantic_ai.run  ](https://ai.pydantic.dev/api/run/)
      * [ pydantic_ai.settings  ](https://ai.pydantic.dev/api/settings/)
      * [ pydantic_ai.tools  ](https://ai.pydantic.dev/api/tools/)
      * [ pydantic_ai.toolsets  ](https://ai.pydantic.dev/api/toolsets/)
      * [ pydantic_ai.ui.ag_ui  ](https://ai.pydantic.dev/api/ui/ag_ui/)
      * [ pydantic_ai.ui  ](https://ai.pydantic.dev/api/ui/base/)
      * [ pydantic_ai.ui.vercel_ai  ](https://ai.pydantic.dev/api/ui/vercel_ai/)
      * [ pydantic_ai.usage  ](https://ai.pydantic.dev/api/usage/)
    * pydantic_evals
      * [ pydantic_evals.dataset  ](https://ai.pydantic.dev/api/pydantic_evals/dataset/)
      * [ pydantic_evals.evaluators  ](https://ai.pydantic.dev/api/pydantic_evals/evaluators/)
      * [ pydantic_evals.reporting  ](https://ai.pydantic.dev/api/pydantic_evals/reporting/)
      * [ pydantic_evals.otel  ](https://ai.pydantic.dev/api/pydantic_evals/otel/)
      * [ pydantic_evals.generation  ](https://ai.pydantic.dev/api/pydantic_evals/generation/)
    * pydantic_graph
      * [ pydantic_graph  ](https://ai.pydantic.dev/api/pydantic_graph/graph/)
      * [ pydantic_graph.nodes  ](https://ai.pydantic.dev/api/pydantic_graph/nodes/)
      * [ pydantic_graph.persistence  ](https://ai.pydantic.dev/api/pydantic_graph/persistence/)
      * [ pydantic_graph.mermaid  ](https://ai.pydantic.dev/api/pydantic_graph/mermaid/)
      * [ pydantic_graph.exceptions  ](https://ai.pydantic.dev/api/pydantic_graph/exceptions/)
      * Beta API
        * [ pydantic_graph.beta  ](https://ai.pydantic.dev/api/pydantic_graph/beta/)
        * [ pydantic_graph.beta.graph  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph/)
        * [ pydantic_graph.beta.graph_builder  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph_builder/)
        * [ pydantic_graph.beta.step  ](https://ai.pydantic.dev/api/pydantic_graph/beta_step/)
        * [ pydantic_graph.beta.join  ](https://ai.pydantic.dev/api/pydantic_graph/beta_join/)
        * [ pydantic_graph.beta.decision  ](https://ai.pydantic.dev/api/pydantic_graph/beta_decision/)
        * [ pydantic_graph.beta.node  ](https://ai.pydantic.dev/api/pydantic_graph/beta_node/)
    * fasta2a
      * [ fasta2a  ](https://ai.pydantic.dev/api/fasta2a/)
  * Project
    * [ Contributing  ](https://ai.pydantic.dev/contributing/)
    * [ Upgrade Guide  ](https://ai.pydantic.dev/changelog/)
    * [ Version policy  ](https://ai.pydantic.dev/version-policy/)


  * [ Overview  ](https://ai.pydantic.dev/builtin-tools/#overview)
  * [ Dynamic Configuration  ](https://ai.pydantic.dev/builtin-tools/#dynamic-configuration)
  * [ Web Search Tool  ](https://ai.pydantic.dev/builtin-tools/#web-search-tool)
    * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support)
    * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage)
    * [ Configuration Options  ](https://ai.pydantic.dev/builtin-tools/#configuration-options)
      * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_1)
  * [ Code Execution Tool  ](https://ai.pydantic.dev/builtin-tools/#code-execution-tool)
    * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_2)
    * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_1)
  * [ Image Generation Tool  ](https://ai.pydantic.dev/builtin-tools/#image-generation-tool)
    * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_3)
    * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_2)
    * [ Configuration Options  ](https://ai.pydantic.dev/builtin-tools/#configuration-options_1)
      * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_4)
  * [ Web Fetch Tool  ](https://ai.pydantic.dev/builtin-tools/#web-fetch-tool)
    * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_5)
    * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_3)
    * [ Configuration Options  ](https://ai.pydantic.dev/builtin-tools/#configuration-options_2)
      * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_6)
  * [ Memory Tool  ](https://ai.pydantic.dev/builtin-tools/#memory-tool)
    * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_7)
    * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_4)
  * [ MCP Server Tool  ](https://ai.pydantic.dev/builtin-tools/#mcp-server-tool)
    * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_8)
    * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_5)
    * [ Configuration Options  ](https://ai.pydantic.dev/builtin-tools/#configuration-options_3)
      * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_9)
  * [ File Search Tool  ](https://ai.pydantic.dev/builtin-tools/#file-search-tool)
    * [ Provider Support  ](https://ai.pydantic.dev/builtin-tools/#provider-support_10)
    * [ Usage  ](https://ai.pydantic.dev/builtin-tools/#usage_6)
      * [ OpenAI Responses  ](https://ai.pydantic.dev/builtin-tools/#openai-responses)
      * [ Google (Gemini)  ](https://ai.pydantic.dev/builtin-tools/#google-gemini)
  * [ API Reference  ](https://ai.pydantic.dev/builtin-tools/#api-reference)


  1. [ Pydantic AI  ](https://ai.pydantic.dev/)
  2. [ Documentation  ](https://ai.pydantic.dev/agent/)
  3. [ Tools & Toolsets  ](https://ai.pydantic.dev/tools/)


# Built-in Tools
Built-in tools are native tools provided by LLM providers that can be used to enhance your agent's capabilities. Unlike [common tools](https://ai.pydantic.dev/common-tools/), which are custom implementations that Pydantic AI executes, built-in tools are executed directly by the model provider.
## Overview
Pydantic AI supports the following built-in tools:
  * **[`WebSearchTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.WebSearchTool "WebSearchTool



      dataclass
  ")**: Allows agents to search the web
  * **[`CodeExecutionTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.CodeExecutionTool "CodeExecutionTool



      dataclass
  ")**: Enables agents to execute code in a secure environment
  * **[`ImageGenerationTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.ImageGenerationTool "ImageGenerationTool



      dataclass
  ")**: Enables agents to generate images
  * **[`WebFetchTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.WebFetchTool "WebFetchTool



      dataclass
  ")**: Enables agents to fetch web pages
  * **[`MemoryTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.MemoryTool "MemoryTool



      dataclass
  ")**: Enables agents to use memory
  * **[`MCPServerTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.MCPServerTool "MCPServerTool



      dataclass
  ")**: Enables agents to use remote MCP servers with communication handled by the model provider
  * **[`FileSearchTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.FileSearchTool "FileSearchTool



      dataclass
  ")**: Enables agents to search through uploaded files using vector search (RAG)


These tools are passed to the agent via the `builtin_tools` parameter and are executed by the model provider's infrastructure.
Provider Support
Not all model providers support built-in tools. If you use a built-in tool with an unsupported provider, Pydantic AI will raise a [`UserError`](https://ai.pydantic.dev/api/exceptions/#pydantic_ai.exceptions.UserError "UserError") when you try to run the agent.
If a provider supports a built-in tool that is not currently supported by Pydantic AI, please file an issue.
## Dynamic Configuration
Sometimes you need to configure a built-in tool dynamically based on the [run context](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.RunContext "RunContext



      dataclass
  ") (e.g., user dependencies), or conditionally omit it. You can achieve this by passing a function to `builtin_tools` that takes [`RunContext`](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.RunContext "RunContext



      dataclass
  ") as an argument and returns an [`AbstractBuiltinTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.AbstractBuiltinTool "AbstractBuiltinTool



      dataclass
  ") or `None`.
This is particularly useful for tools like [`WebSearchTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.WebSearchTool "WebSearchTool



      dataclass
  ") where you might want to set the user's location based on the current request, or disable the tool if the user provides no location.
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_1_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_1_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) dynamic_builtin_tool.py```
from pydantic_ai import Agent, RunContext, WebSearchTool


async def prepared_web_search(ctx: RunContext[dict]) -> WebSearchTool | None:
    if not ctx.deps.get('location'):
        return None

    return WebSearchTool(
        user_location={'city': ctx.deps['location']},
    )

agent = Agent(
    'gateway/openai-responses:gpt-5.2',
    builtin_tools=[prepared_web_search],
    deps_type=dict,
)

# Run with location
result = agent.run_sync(
    'What is the weather like?',
    deps={'location': 'London'},
)
print(result.output)
#> It's currently raining in London.

# Run without location (tool will be omitted)
result = agent.run_sync(
    'What is the capital of France?',
    deps={'location': None},
)
print(result.output)
#> The capital of France is Paris.

```

dynamic_builtin_tool.py```
from pydantic_ai import Agent, RunContext, WebSearchTool


async def prepared_web_search(ctx: RunContext[dict]) -> WebSearchTool | None:
    if not ctx.deps.get('location'):
        return None

    return WebSearchTool(
        user_location={'city': ctx.deps['location']},
    )

agent = Agent(
    'openai-responses:gpt-5.2',
    builtin_tools=[prepared_web_search],
    deps_type=dict,
)

# Run with location
result = agent.run_sync(
    'What is the weather like?',
    deps={'location': 'London'},
)
print(result.output)
#> It's currently raining in London.

# Run without location (tool will be omitted)
result = agent.run_sync(
    'What is the capital of France?',
    deps={'location': None},
)
print(result.output)
#> The capital of France is Paris.

```

## Web Search Tool
The [`WebSearchTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.WebSearchTool "WebSearchTool



      dataclass
  ") allows your agent to search the web, making it ideal for queries that require up-to-date data.
### Provider Support
Provider | Supported | Notes
---|---|---
OpenAI Responses | ✅ | Full feature support. To include search results on the [`BuiltinToolReturnPart`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.BuiltinToolReturnPart "BuiltinToolReturnPart



      dataclass
  ") that's available via [`ModelResponse.builtin_tool_calls`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.ModelResponse.builtin_tool_calls "builtin_tool_calls



      property
  "), enable the [`OpenAIResponsesModelSettings.openai_include_web_search_sources`](https://ai.pydantic.dev/api/models/openai/#pydantic_ai.models.openai.OpenAIResponsesModelSettings.openai_include_web_search_sources "openai_include_web_search_sources



      instance-attribute
  ") [model setting](https://ai.pydantic.dev/agent/#model-run-settings).
Anthropic | ✅ | Full feature support
Google | ✅ | No parameter support. No [`BuiltinToolCallPart`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.BuiltinToolCallPart "BuiltinToolCallPart



      dataclass
  ") or [`BuiltinToolReturnPart`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.BuiltinToolReturnPart "BuiltinToolReturnPart



      dataclass
  ") is generated when streaming. Using built-in tools and function tools (including [output tools](https://ai.pydantic.dev/output/#tool-output)) at the same time is not supported; to use structured output, use [`PromptedOutput`](https://ai.pydantic.dev/output/#prompted-output) instead.
xAI | ✅ | Supports `blocked_domains` and `allowed_domains` parameters.
Groq | ✅ | Limited parameter support. To use web search capabilities with Groq, you need to use the [compound models](https://console.groq.com/docs/compound).
OpenAI Chat Completions | ❌ | Not supported
Bedrock | ❌ | Not supported
Mistral | ❌ | Not supported
Cohere | ❌ | Not supported
HuggingFace | ❌ | Not supported
Outlines | ❌ | Not supported
### Usage
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_2_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_2_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) web_search_anthropic.py```
from pydantic_ai import Agent, WebSearchTool

agent = Agent('gateway/anthropic:claude-sonnet-4-6', builtin_tools=[WebSearchTool()])

result = agent.run_sync('Give me a sentence with the biggest news in AI this week.')
print(result.output)
#> Scientists have developed a universal AI detector that can identify deepfake videos.

```

web_search_anthropic.py```
from pydantic_ai import Agent, WebSearchTool

agent = Agent('anthropic:claude-sonnet-4-6', builtin_tools=[WebSearchTool()])

result = agent.run_sync('Give me a sentence with the biggest news in AI this week.')
print(result.output)
#> Scientists have developed a universal AI detector that can identify deepfake videos.

```

_(This example is complete, it can be run "as is")_
With OpenAI, you must use their Responses API to access the web search tool.
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_3_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_3_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) web_search_openai.py```
from pydantic_ai import Agent, WebSearchTool

agent = Agent('gateway/openai-responses:gpt-5.2', builtin_tools=[WebSearchTool()])

result = agent.run_sync('Give me a sentence with the biggest news in AI this week.')
print(result.output)
#> Scientists have developed a universal AI detector that can identify deepfake videos.

```

web_search_openai.py```
from pydantic_ai import Agent, WebSearchTool

agent = Agent('openai-responses:gpt-5.2', builtin_tools=[WebSearchTool()])

result = agent.run_sync('Give me a sentence with the biggest news in AI this week.')
print(result.output)
#> Scientists have developed a universal AI detector that can identify deepfake videos.

```

_(This example is complete, it can be run "as is")_
### Configuration Options
The `WebSearchTool` supports several configuration parameters:
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_4_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_4_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) web_search_configured.py```
from pydantic_ai import Agent, WebSearchTool, WebSearchUserLocation

agent = Agent(
    'gateway/anthropic:claude-sonnet-4-6',
    builtin_tools=[
        WebSearchTool(
            search_context_size='high',
            user_location=WebSearchUserLocation(
                city='San Francisco',
                country='US',
                region='CA',
                timezone='America/Los_Angeles',
            ),
            blocked_domains=['example.com', 'spam-site.net'],
            allowed_domains=None,  # Cannot use both blocked_domains and allowed_domains with Anthropic
            max_uses=5,  # Anthropic only: limit tool usage
        )
    ],
)

result = agent.run_sync('Use the web to get the current time.')
print(result.output)
#> In San Francisco, it's 8:21:41 pm PDT on Wednesday, August 6, 2025.

```

web_search_configured.py```
from pydantic_ai import Agent, WebSearchTool, WebSearchUserLocation

agent = Agent(
    'anthropic:claude-sonnet-4-6',
    builtin_tools=[
        WebSearchTool(
            search_context_size='high',
            user_location=WebSearchUserLocation(
                city='San Francisco',
                country='US',
                region='CA',
                timezone='America/Los_Angeles',
            ),
            blocked_domains=['example.com', 'spam-site.net'],
            allowed_domains=None,  # Cannot use both blocked_domains and allowed_domains with Anthropic
            max_uses=5,  # Anthropic only: limit tool usage
        )
    ],
)

result = agent.run_sync('Use the web to get the current time.')
print(result.output)
#> In San Francisco, it's 8:21:41 pm PDT on Wednesday, August 6, 2025.

```

_(This example is complete, it can be run "as is")_
#### Provider Support
Parameter | OpenAI | Anthropic | xAI | Groq
---|---|---|---|---
`search_context_size` | ✅ | ❌ | ❌ | ❌
`user_location` | ✅ | ✅ | ❌ | ❌
`blocked_domains` | ❌ | ✅ | ✅ | ✅
`allowed_domains` | ✅ | ✅ | ✅ | ✅
`max_uses` | ❌ | ✅ | ❌ | ❌
Anthropic Domain Filtering
With Anthropic, you can only use either `blocked_domains` or `allowed_domains`, not both.
## Code Execution Tool
The [`CodeExecutionTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.CodeExecutionTool "CodeExecutionTool



      dataclass
  ") enables your agent to execute code in a secure environment, making it perfect for computational tasks, data analysis, and mathematical operations.
### Provider Support
Provider | Supported | Notes
---|---|---
OpenAI | ✅ | To include code execution output on the [`BuiltinToolReturnPart`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.BuiltinToolReturnPart "BuiltinToolReturnPart



      dataclass
  ") that's available via [`ModelResponse.builtin_tool_calls`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.ModelResponse.builtin_tool_calls "builtin_tool_calls



      property
  "), enable the [`OpenAIResponsesModelSettings.openai_include_code_execution_outputs`](https://ai.pydantic.dev/api/models/openai/#pydantic_ai.models.openai.OpenAIResponsesModelSettings.openai_include_code_execution_outputs "openai_include_code_execution_outputs



      instance-attribute
  ") [model setting](https://ai.pydantic.dev/agent/#model-run-settings). If the code execution generated images, like charts, they will be available on [`ModelResponse.images`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.ModelResponse.images "images



      property
  ") as [`BinaryImage`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.BinaryImage "BinaryImage") objects. The generated image can also be used as [image output](https://ai.pydantic.dev/output/#image-output) for the agent run.
Google | ✅ | Using built-in tools and function tools (including [output tools](https://ai.pydantic.dev/output/#tool-output)) at the same time is not supported; to use structured output, use [`PromptedOutput`](https://ai.pydantic.dev/output/#prompted-output) instead.
Anthropic | ✅ |
xAI | ✅ | Full feature support.
Groq | ❌ |
Bedrock | ✅ | Only available for Nova 2.0 models.
Mistral | ❌ |
Cohere | ❌ |
HuggingFace | ❌ |
Outlines | ❌ |
### Usage
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_5_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_5_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) code_execution_basic.py```
from pydantic_ai import Agent, CodeExecutionTool

agent = Agent('gateway/anthropic:claude-sonnet-4-6', builtin_tools=[CodeExecutionTool()])

result = agent.run_sync('Calculate the factorial of 15.')
print(result.output)
#> The factorial of 15 is **1,307,674,368,000**.
print(result.response.builtin_tool_calls)
"""
[
    (
        BuiltinToolCallPart(
            tool_name='code_execution',
            args={
                'code': 'import math\n\n# Calculate factorial of 15\nresult = math.factorial(15)\nprint(f"15! = {result}")\n\n# Let\'s also show it in a more readable format with commas\nprint(f"15! = {result:,}")'
            },
            tool_call_id='srvtoolu_017qRH1J3XrhnpjP2XtzPCmJ',
            provider_name='anthropic',
        ),
        BuiltinToolReturnPart(
            tool_name='code_execution',
            content={
                'content': [],
                'return_code': 0,
                'stderr': '',
                'stdout': '15! = 1307674368000\n15! = 1,307,674,368,000',
                'type': 'code_execution_result',
            },
            tool_call_id='srvtoolu_017qRH1J3XrhnpjP2XtzPCmJ',
            timestamp=datetime.datetime(...),
            provider_name='anthropic',
        ),
    )
]
"""

```

code_execution_basic.py```
from pydantic_ai import Agent, CodeExecutionTool

agent = Agent('anthropic:claude-sonnet-4-6', builtin_tools=[CodeExecutionTool()])

result = agent.run_sync('Calculate the factorial of 15.')
print(result.output)
#> The factorial of 15 is **1,307,674,368,000**.
print(result.response.builtin_tool_calls)
"""
[
    (
        BuiltinToolCallPart(
            tool_name='code_execution',
            args={
                'code': 'import math\n\n# Calculate factorial of 15\nresult = math.factorial(15)\nprint(f"15! = {result}")\n\n# Let\'s also show it in a more readable format with commas\nprint(f"15! = {result:,}")'
            },
            tool_call_id='srvtoolu_017qRH1J3XrhnpjP2XtzPCmJ',
            provider_name='anthropic',
        ),
        BuiltinToolReturnPart(
            tool_name='code_execution',
            content={
                'content': [],
                'return_code': 0,
                'stderr': '',
                'stdout': '15! = 1307674368000\n15! = 1,307,674,368,000',
                'type': 'code_execution_result',
            },
            tool_call_id='srvtoolu_017qRH1J3XrhnpjP2XtzPCmJ',
            timestamp=datetime.datetime(...),
            provider_name='anthropic',
        ),
    )
]
"""

```

_(This example is complete, it can be run "as is")_
In addition to text output, code execution with OpenAI can generate images as part of their response. Accessing this image via [`ModelResponse.images`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.ModelResponse.images "images



      property
  ") or [image output](https://ai.pydantic.dev/output/#image-output) requires the [`OpenAIResponsesModelSettings.openai_include_code_execution_outputs`](https://ai.pydantic.dev/api/models/openai/#pydantic_ai.models.openai.OpenAIResponsesModelSettings.openai_include_code_execution_outputs "openai_include_code_execution_outputs



      instance-attribute
  ") [model setting](https://ai.pydantic.dev/agent/#model-run-settings) to be enabled.
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_6_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_6_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) code_execution_openai.py```
from pydantic_ai import Agent, BinaryImage, CodeExecutionTool
from pydantic_ai.models.openai import OpenAIResponsesModelSettings

agent = Agent(
    'gateway/openai-responses:gpt-5.2',
    builtin_tools=[CodeExecutionTool()],
    output_type=BinaryImage,
    model_settings=OpenAIResponsesModelSettings(openai_include_code_execution_outputs=True),
)

result = agent.run_sync('Generate a chart of y=x^2 for x=-5 to 5.')
assert isinstance(result.output, BinaryImage)

```

code_execution_openai.py```
from pydantic_ai import Agent, BinaryImage, CodeExecutionTool
from pydantic_ai.models.openai import OpenAIResponsesModelSettings

agent = Agent(
    'openai-responses:gpt-5.2',
    builtin_tools=[CodeExecutionTool()],
    output_type=BinaryImage,
    model_settings=OpenAIResponsesModelSettings(openai_include_code_execution_outputs=True),
)

result = agent.run_sync('Generate a chart of y=x^2 for x=-5 to 5.')
assert isinstance(result.output, BinaryImage)

```

_(This example is complete, it can be run "as is")_
## Image Generation Tool
The [`ImageGenerationTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.ImageGenerationTool "ImageGenerationTool



      dataclass
  ") enables your agent to generate images.
### Provider Support
Provider | Supported | Notes
---|---|---
OpenAI Responses | ✅ | Full feature support. Only supported by models newer than `gpt-5.2`. Metadata about the generated image, like the [`revised_prompt`](https://platform.openai.com/docs/guides/tools-image-generation#revised-prompt) sent to the underlying image model, is available on the [`BuiltinToolReturnPart`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.BuiltinToolReturnPart "BuiltinToolReturnPart



      dataclass
  ") that's available via [`ModelResponse.builtin_tool_calls`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.ModelResponse.builtin_tool_calls "builtin_tool_calls



      property
  ").
Google | ✅ | Limited parameter support. Only supported by [image generation models](https://ai.google.dev/gemini-api/docs/image-generation) like `gemini-3-pro-image-preview` and `gemini-3-pro-image-preview`. These models do not support [function tools](https://ai.pydantic.dev/tools/) and will always have the option of generating images, even if this built-in tool is not explicitly specified.
Anthropic | ❌ |
xAI | ❌ |
Groq | ❌ |
Bedrock | ❌ |
Mistral | ❌ |
Cohere | ❌ |
HuggingFace | ❌ |
### Usage
Generated images are available on [`ModelResponse.images`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.ModelResponse.images "images



      property
  ") as [`BinaryImage`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.BinaryImage "BinaryImage") objects:
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_7_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_7_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) image_generation_openai.py```
from pydantic_ai import Agent, BinaryImage, ImageGenerationTool

agent = Agent('gateway/openai-responses:gpt-5.2', builtin_tools=[ImageGenerationTool()])

result = agent.run_sync('Tell me a two-sentence story about an axolotl with an illustration.')
print(result.output)
"""
Once upon a time, in a hidden underwater cave, lived a curious axolotl named Pip who loved to explore. One day, while venturing further than usual, Pip discovered a shimmering, ancient coin that granted wishes!
"""

assert isinstance(result.response.images[0], BinaryImage)

```

image_generation_openai.py```
from pydantic_ai import Agent, BinaryImage, ImageGenerationTool

agent = Agent('openai-responses:gpt-5.2', builtin_tools=[ImageGenerationTool()])

result = agent.run_sync('Tell me a two-sentence story about an axolotl with an illustration.')
print(result.output)
"""
Once upon a time, in a hidden underwater cave, lived a curious axolotl named Pip who loved to explore. One day, while venturing further than usual, Pip discovered a shimmering, ancient coin that granted wishes!
"""

assert isinstance(result.response.images[0], BinaryImage)

```

_(This example is complete, it can be run "as is")_
Image generation with Google [image generation models](https://ai.google.dev/gemini-api/docs/image-generation) does not require the `ImageGenerationTool` built-in tool to be explicitly specified:
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_8_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_8_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) image_generation_google.py```
from pydantic_ai import Agent, BinaryImage

agent = Agent('gateway/gemini:gemini-3-pro-image-preview')

result = agent.run_sync('Tell me a two-sentence story about an axolotl with an illustration.')
print(result.output)
"""
Once upon a time, in a hidden underwater cave, lived a curious axolotl named Pip who loved to explore. One day, while venturing further than usual, Pip discovered a shimmering, ancient coin that granted wishes!
"""

assert isinstance(result.response.images[0], BinaryImage)

```

image_generation_google.py```
from pydantic_ai import Agent, BinaryImage

agent = Agent('google-gla:gemini-3-pro-image-preview')

result = agent.run_sync('Tell me a two-sentence story about an axolotl with an illustration.')
print(result.output)
"""
Once upon a time, in a hidden underwater cave, lived a curious axolotl named Pip who loved to explore. One day, while venturing further than usual, Pip discovered a shimmering, ancient coin that granted wishes!
"""

assert isinstance(result.response.images[0], BinaryImage)

```

_(This example is complete, it can be run "as is")_
The `ImageGenerationTool` can be used together with `output_type=BinaryImage` to get [image output](https://ai.pydantic.dev/output/#image-output). If the `ImageGenerationTool` built-in tool is not explicitly specified, it will be enabled automatically:
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_9_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_9_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) image_generation_output.py```
from pydantic_ai import Agent, BinaryImage

agent = Agent('gateway/openai-responses:gpt-5.2', output_type=BinaryImage)

result = agent.run_sync('Generate an image of an axolotl.')
assert isinstance(result.output, BinaryImage)

```

image_generation_output.py```
from pydantic_ai import Agent, BinaryImage

agent = Agent('openai-responses:gpt-5.2', output_type=BinaryImage)

result = agent.run_sync('Generate an image of an axolotl.')
assert isinstance(result.output, BinaryImage)

```

_(This example is complete, it can be run "as is")_
### Configuration Options
The `ImageGenerationTool` supports several configuration parameters:
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_10_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_10_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) image_generation_configured.py```
from pydantic_ai import Agent, BinaryImage, ImageGenerationTool

agent = Agent(
    'gateway/openai-responses:gpt-5.2',
    builtin_tools=[
        ImageGenerationTool(
            background='transparent',
            input_fidelity='high',
            moderation='low',
            output_compression=100,
            output_format='png',
            partial_images=3,
            quality='high',
            size='1024x1024',
        )
    ],
    output_type=BinaryImage,
)

result = agent.run_sync('Generate an image of an axolotl.')
assert isinstance(result.output, BinaryImage)

```

image_generation_configured.py```
from pydantic_ai import Agent, BinaryImage, ImageGenerationTool

agent = Agent(
    'openai-responses:gpt-5.2',
    builtin_tools=[
        ImageGenerationTool(
            background='transparent',
            input_fidelity='high',
            moderation='low',
            output_compression=100,
            output_format='png',
            partial_images=3,
            quality='high',
            size='1024x1024',
        )
    ],
    output_type=BinaryImage,
)

result = agent.run_sync('Generate an image of an axolotl.')
assert isinstance(result.output, BinaryImage)

```

_(This example is complete, it can be run "as is")_
OpenAI Responses models also respect the `aspect_ratio` parameter. Because the OpenAI API only exposes discrete image sizes, Pydantic AI maps `'1:1'` -> `1024x1024`, `'2:3'` -> `1024x1536`, and `'3:2'` -> `1536x1024`. Providing any other aspect ratio results in an error, and if you also set `size` it must match the computed value.
To control the aspect ratio when using Gemini image models, include the `ImageGenerationTool` explicitly:
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_11_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_11_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) image_generation_google_aspect_ratio.py```
from pydantic_ai import Agent, BinaryImage, ImageGenerationTool

agent = Agent(
    'gateway/gemini:gemini-3-pro-image-preview',
    builtin_tools=[ImageGenerationTool(aspect_ratio='16:9')],
    output_type=BinaryImage,
)

result = agent.run_sync('Generate a wide illustration of an axolotl city skyline.')
assert isinstance(result.output, BinaryImage)

```

image_generation_google_aspect_ratio.py```
from pydantic_ai import Agent, BinaryImage, ImageGenerationTool

agent = Agent(
    'google-gla:gemini-3-pro-image-preview',
    builtin_tools=[ImageGenerationTool(aspect_ratio='16:9')],
    output_type=BinaryImage,
)

result = agent.run_sync('Generate a wide illustration of an axolotl city skyline.')
assert isinstance(result.output, BinaryImage)

```

_(This example is complete, it can be run "as is")_
To control the image resolution with Google image generation models (starting with Gemini 3 Pro Image), use the `size` parameter:
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_12_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_12_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) image_generation_google_resolution.py```
from pydantic_ai import Agent, BinaryImage, ImageGenerationTool

agent = Agent(
    'gateway/gemini:gemini-3-pro-image-preview',
    builtin_tools=[ImageGenerationTool(aspect_ratio='16:9', size='4K')],
    output_type=BinaryImage,
)

result = agent.run_sync('Generate a high-resolution wide landscape illustration of an axolotl.')
assert isinstance(result.output, BinaryImage)

```

image_generation_google_resolution.py```
from pydantic_ai import Agent, BinaryImage, ImageGenerationTool

agent = Agent(
    'google-gla:gemini-3-pro-image-preview',
    builtin_tools=[ImageGenerationTool(aspect_ratio='16:9', size='4K')],
    output_type=BinaryImage,
)

result = agent.run_sync('Generate a high-resolution wide landscape illustration of an axolotl.')
assert isinstance(result.output, BinaryImage)

```

_(This example is complete, it can be run "as is")_
For more details, check the [API documentation](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.ImageGenerationTool "ImageGenerationTool



      dataclass
  ").
#### Provider Support
Parameter | OpenAI | Google
---|---|---
`background` | ✅ | ❌
`input_fidelity` | ✅ | ❌
`moderation` | ✅ | ❌
`output_compression` | ✅ (100 (default), jpeg or webp only) | ✅ (75 (default), jpeg only, Vertex AI only)
`output_format` | ✅ | ✅ (Vertex AI only)
`partial_images` | ✅ | ❌
`quality` | ✅ | ❌
`size` | ✅ (auto (default), 1024x1024, 1024x1536, 1536x1024) | ✅ (1K (default), 2K, 4K)
`aspect_ratio` | ✅ (1:1, 2:3, 3:2) | ✅ (1:1, 2:3, 3:2, 3:4, 4:3, 4:5, 5:4, 9:16, 16:9, 21:9)
Notes
  * **OpenAI** : `auto` lets the model select the value.
  * **Google (Vertex AI)** : Setting `output_compression` will default `output_format` to `jpeg` if not specified.


## Web Fetch Tool
The [`WebFetchTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.WebFetchTool "WebFetchTool



      dataclass
  ") enables your agent to pull URL contents into its context, allowing it to pull up-to-date information from the web.
### Provider Support
Provider | Supported | Notes
---|---|---
Anthropic | ✅ | Full feature support. Uses Anthropic's [Web Fetch Tool](https://docs.claude.com/en/docs/agents-and-tools/tool-use/web-fetch-tool) internally to retrieve URL contents.
Google | ✅ | No parameter support. The limits are fixed at 20 URLs per request with a maximum of 34MB per URL. Using built-in tools and function tools (including [output tools](https://ai.pydantic.dev/output/#tool-output)) at the same time is not supported; to use structured output, use [`PromptedOutput`](https://ai.pydantic.dev/output/#prompted-output) instead.
xAI | ❌ | Web browsing is implemented as part of [`WebSearchTool`](https://ai.pydantic.dev/builtin-tools/#web-search-tool) with xAI.
OpenAI | ❌ |
Groq | ❌ |
Bedrock | ❌ |
Mistral | ❌ |
Cohere | ❌ |
HuggingFace | ❌ |
Outlines | ❌ |
### Usage
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_13_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_13_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) web_fetch_basic.py```
from pydantic_ai import Agent, WebFetchTool

agent = Agent('gateway/gemini:gemini-3-flash-preview', builtin_tools=[WebFetchTool()])

result = agent.run_sync('What is this? https://ai.pydantic.dev')
print(result.output)
#> A Python agent framework for building Generative AI applications.

```

web_fetch_basic.py```
from pydantic_ai import Agent, WebFetchTool

agent = Agent('google-gla:gemini-3-flash-preview', builtin_tools=[WebFetchTool()])

result = agent.run_sync('What is this? https://ai.pydantic.dev')
print(result.output)
#> A Python agent framework for building Generative AI applications.

```

_(This example is complete, it can be run "as is")_
### Configuration Options
The `WebFetchTool` supports several configuration parameters:
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_14_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_14_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) web_fetch_configured.py```
from pydantic_ai import Agent, WebFetchTool

agent = Agent(
    'gateway/anthropic:claude-sonnet-4-6',
    builtin_tools=[
        WebFetchTool(
            allowed_domains=['ai.pydantic.dev', 'docs.pydantic.dev'],
            max_uses=10,
            enable_citations=True,
            max_content_tokens=50000,
        )
    ],
)

result = agent.run_sync(
    'Compare the documentation at https://ai.pydantic.dev and https://docs.pydantic.dev'
)
print(result.output)
"""
Both sites provide comprehensive documentation for Pydantic projects. ai.pydantic.dev focuses on PydanticAI, a framework for building AI agents, while docs.pydantic.dev covers Pydantic, the data validation library. They share similar documentation styles and both emphasize type safety and developer experience.
"""

```

web_fetch_configured.py```
from pydantic_ai import Agent, WebFetchTool

agent = Agent(
    'anthropic:claude-sonnet-4-6',
    builtin_tools=[
        WebFetchTool(
            allowed_domains=['ai.pydantic.dev', 'docs.pydantic.dev'],
            max_uses=10,
            enable_citations=True,
            max_content_tokens=50000,
        )
    ],
)

result = agent.run_sync(
    'Compare the documentation at https://ai.pydantic.dev and https://docs.pydantic.dev'
)
print(result.output)
"""
Both sites provide comprehensive documentation for Pydantic projects. ai.pydantic.dev focuses on PydanticAI, a framework for building AI agents, while docs.pydantic.dev covers Pydantic, the data validation library. They share similar documentation styles and both emphasize type safety and developer experience.
"""

```

_(This example is complete, it can be run "as is")_
#### Provider Support
Parameter | Anthropic | Google
---|---|---
`max_uses` | ✅ | ❌
`allowed_domains` | ✅ | ❌
`blocked_domains` | ✅ | ❌
`enable_citations` | ✅ | ❌
`max_content_tokens` | ✅ | ❌
Anthropic Domain Filtering
With Anthropic, you can only use either `blocked_domains` or `allowed_domains`, not both.
## Memory Tool
The [`MemoryTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.MemoryTool "MemoryTool



      dataclass
  ") enables your agent to use memory.
### Provider Support
Provider | Supported | Notes
---|---|---
Anthropic | ✅ | Requires a tool named `memory` to be defined that implements [specific sub-commands](https://docs.claude.com/en/docs/agents-and-tools/tool-use/memory-tool#tool-commands). You can use a subclass of [`anthropic.lib.tools.BetaAbstractMemoryTool`](https://github.com/anthropics/anthropic-sdk-python/blob/main/src/anthropic/lib/tools/_beta_builtin_memory_tool.py) as documented below.
Google | ❌ |
OpenAI | ❌ |
Groq | ❌ |
Bedrock | ❌ |
Mistral | ❌ |
Cohere | ❌ |
HuggingFace | ❌ |
### Usage
The Anthropic SDK provides an abstract [`BetaAbstractMemoryTool`](https://github.com/anthropics/anthropic-sdk-python/blob/main/src/anthropic/lib/tools/_beta_builtin_memory_tool.py) class that you can subclass to create your own memory storage solution (e.g., database, cloud storage, encrypted files, etc.). Their [`LocalFilesystemMemoryTool`](https://github.com/anthropics/anthropic-sdk-python/blob/main/examples/memory/basic.py) example can serve as a starting point.
The following example uses a subclass that hard-codes a specific memory. The bits specific to Pydantic AI are the `MemoryTool` built-in tool and the `memory` tool definition that forwards commands to the `call` method of the `BetaAbstractMemoryTool` subclass.
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_15_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_15_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) anthropic_memory.py```
from typing import Any

from anthropic.lib.tools import BetaAbstractMemoryTool
from anthropic.types.beta import (
    BetaMemoryTool20250818CreateCommand,
    BetaMemoryTool20250818DeleteCommand,
    BetaMemoryTool20250818InsertCommand,
    BetaMemoryTool20250818RenameCommand,
    BetaMemoryTool20250818StrReplaceCommand,
    BetaMemoryTool20250818ViewCommand,
)

from pydantic_ai import Agent, MemoryTool


class FakeMemoryTool(BetaAbstractMemoryTool):
    def view(self, command: BetaMemoryTool20250818ViewCommand) -> str:
        return 'The user lives in Mexico City.'

    def create(self, command: BetaMemoryTool20250818CreateCommand) -> str:
        return f'File created successfully at {command.path}'

    def str_replace(self, command: BetaMemoryTool20250818StrReplaceCommand) -> str:
        return f'File {command.path} has been edited'

    def insert(self, command: BetaMemoryTool20250818InsertCommand) -> str:
        return f'Text inserted at line {command.insert_line} in {command.path}'

    def delete(self, command: BetaMemoryTool20250818DeleteCommand) -> str:
        return f'File deleted: {command.path}'

    def rename(self, command: BetaMemoryTool20250818RenameCommand) -> str:
        return f'Renamed {command.old_path} to {command.new_path}'

    def clear_all_memory(self) -> str:
        return 'All memory cleared'

fake_memory = FakeMemoryTool()

agent = Agent('gateway/anthropic:claude-sonnet-4-6', builtin_tools=[MemoryTool()])


@agent.tool_plain
def memory(**command: Any) -> Any:
    return fake_memory.call(command)


result = agent.run_sync('Remember that I live in Mexico City')
print(result.output)
"""
Got it! I've recorded that you live in Mexico City. I'll remember this for future reference.
"""

result = agent.run_sync('Where do I live?')
print(result.output)
#> You live in Mexico City.

```

anthropic_memory.py```
from typing import Any

from anthropic.lib.tools import BetaAbstractMemoryTool
from anthropic.types.beta import (
    BetaMemoryTool20250818CreateCommand,
    BetaMemoryTool20250818DeleteCommand,
    BetaMemoryTool20250818InsertCommand,
    BetaMemoryTool20250818RenameCommand,
    BetaMemoryTool20250818StrReplaceCommand,
    BetaMemoryTool20250818ViewCommand,
)

from pydantic_ai import Agent, MemoryTool


class FakeMemoryTool(BetaAbstractMemoryTool):
    def view(self, command: BetaMemoryTool20250818ViewCommand) -> str:
        return 'The user lives in Mexico City.'

    def create(self, command: BetaMemoryTool20250818CreateCommand) -> str:
        return f'File created successfully at {command.path}'

    def str_replace(self, command: BetaMemoryTool20250818StrReplaceCommand) -> str:
        return f'File {command.path} has been edited'

    def insert(self, command: BetaMemoryTool20250818InsertCommand) -> str:
        return f'Text inserted at line {command.insert_line} in {command.path}'

    def delete(self, command: BetaMemoryTool20250818DeleteCommand) -> str:
        return f'File deleted: {command.path}'

    def rename(self, command: BetaMemoryTool20250818RenameCommand) -> str:
        return f'Renamed {command.old_path} to {command.new_path}'

    def clear_all_memory(self) -> str:
        return 'All memory cleared'

fake_memory = FakeMemoryTool()

agent = Agent('anthropic:claude-sonnet-4-6', builtin_tools=[MemoryTool()])


@agent.tool_plain
def memory(**command: Any) -> Any:
    return fake_memory.call(command)


result = agent.run_sync('Remember that I live in Mexico City')
print(result.output)
"""
Got it! I've recorded that you live in Mexico City. I'll remember this for future reference.
"""

result = agent.run_sync('Where do I live?')
print(result.output)
#> You live in Mexico City.

```

_(This example is complete, it can be run "as is")_
## MCP Server Tool
The [`MCPServerTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.MCPServerTool "MCPServerTool



      dataclass
  ") allows your agent to use remote MCP servers with communication handled by the model provider.
This requires the MCP server to live at a public URL the provider can reach and does not support many of the advanced features of Pydantic AI's agent-side [MCP support](https://ai.pydantic.dev/mcp/client/), but can result in optimized context use and caching, and faster performance due to the lack of a round-trip back to Pydantic AI.
### Provider Support
Provider | Supported | Notes
---|---|---
OpenAI Responses | ✅ | Full feature support. [Connectors](https://platform.openai.com/docs/guides/tools-connectors-mcp#connectors) can be used by specifying a special `x-openai-connector:<connector_id>` URL.
Anthropic | ✅ | Full feature support
xAI | ✅ | Full feature support
Google | ❌ | Not supported
Groq | ❌ | Not supported
OpenAI Chat Completions | ❌ | Not supported
Bedrock | ❌ | Not supported
Mistral | ❌ | Not supported
Cohere | ❌ | Not supported
HuggingFace | ❌ | Not supported
### Usage
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_16_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_16_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) mcp_server_anthropic.py```
from pydantic_ai import Agent, MCPServerTool

agent = Agent(
    'gateway/anthropic:claude-sonnet-4-6',
    builtin_tools=[
        MCPServerTool(
            id='deepwiki',
            url='https://mcp.deepwiki.com/mcp',  # [](https://ai.pydantic.dev/builtin-tools/#__code_30_annotation_1)
        )
    ]
)

result = agent.run_sync('Tell me about the pydantic/pydantic-ai repo.')
print(result.output)
"""
The pydantic/pydantic-ai repo is a Python agent framework for building Generative AI applications.
"""

```

mcp_server_anthropic.py```
from pydantic_ai import Agent, MCPServerTool

agent = Agent(
    'anthropic:claude-sonnet-4-6',
    builtin_tools=[
        MCPServerTool(
            id='deepwiki',
            url='https://mcp.deepwiki.com/mcp',  #

[](https://ai.pydantic.dev/builtin-tools/#__code_31_annotation_1)
        )
    ]
)

result = agent.run_sync('Tell me about the pydantic/pydantic-ai repo.')
print(result.output)
"""
The pydantic/pydantic-ai repo is a Python agent framework for building Generative AI applications.
"""

```

  1. The [DeepWiki MCP server](https://docs.devin.ai/work-with-devin/deepwiki-mcp) does not require authorization.


_(This example is complete, it can be run "as is")_
With OpenAI, you must use their Responses API to access the MCP server tool:
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_17_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_17_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) mcp_server_openai.py```
from pydantic_ai import Agent, MCPServerTool

agent = Agent(
    'gateway/openai-responses:gpt-5.2',
    builtin_tools=[
        MCPServerTool(
            id='deepwiki',
            url='https://mcp.deepwiki.com/mcp',  # [](https://ai.pydantic.dev/builtin-tools/#__code_32_annotation_1)
        )
    ]
)

result = agent.run_sync('Tell me about the pydantic/pydantic-ai repo.')
print(result.output)
"""
The pydantic/pydantic-ai repo is a Python agent framework for building Generative AI applications.
"""

```

mcp_server_openai.py```
from pydantic_ai import Agent, MCPServerTool

agent = Agent(
    'openai-responses:gpt-5.2',
    builtin_tools=[
        MCPServerTool(
            id='deepwiki',
            url='https://mcp.deepwiki.com/mcp',  #

[](https://ai.pydantic.dev/builtin-tools/#__code_33_annotation_1)
        )
    ]
)

result = agent.run_sync('Tell me about the pydantic/pydantic-ai repo.')
print(result.output)
"""
The pydantic/pydantic-ai repo is a Python agent framework for building Generative AI applications.
"""

```

  1. The [DeepWiki MCP server](https://docs.devin.ai/work-with-devin/deepwiki-mcp) does not require authorization.


_(This example is complete, it can be run "as is")_
### Configuration Options
The `MCPServerTool` supports several configuration parameters for custom MCP servers:
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_18_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_18_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) mcp_server_configured_url.py```
import os

from pydantic_ai import Agent, MCPServerTool

agent = Agent(
    'gateway/openai-responses:gpt-5.2',
    builtin_tools=[
        MCPServerTool(
            id='github',
            url='https://api.githubcopilot.com/mcp/',
            authorization_token=os.getenv('GITHUB_ACCESS_TOKEN', 'mock-access-token'),  # [](https://ai.pydantic.dev/builtin-tools/#__code_34_annotation_1)
            allowed_tools=['search_repositories', 'list_commits'],
            description='GitHub MCP server',
            headers={'X-Custom-Header': 'custom-value'},
        )
    ]
)

result = agent.run_sync('Tell me about the pydantic/pydantic-ai repo.')
print(result.output)
"""
The pydantic/pydantic-ai repo is a Python agent framework for building Generative AI applications.
"""

```

mcp_server_configured_url.py```
import os

from pydantic_ai import Agent, MCPServerTool

agent = Agent(
    'openai-responses:gpt-5.2',
    builtin_tools=[
        MCPServerTool(
            id='github',
            url='https://api.githubcopilot.com/mcp/',
            authorization_token=os.getenv('GITHUB_ACCESS_TOKEN', 'mock-access-token'),  #

[](https://ai.pydantic.dev/builtin-tools/#__code_35_annotation_1)
            allowed_tools=['search_repositories', 'list_commits'],
            description='GitHub MCP server',
            headers={'X-Custom-Header': 'custom-value'},
        )
    ]
)

result = agent.run_sync('Tell me about the pydantic/pydantic-ai repo.')
print(result.output)
"""
The pydantic/pydantic-ai repo is a Python agent framework for building Generative AI applications.
"""

```

  1. The [GitHub MCP server](https://github.com/github/github-mcp-server) requires an authorization token.


For OpenAI Responses, you can use a [connector](https://platform.openai.com/docs/guides/tools-connectors-mcp#connectors) by specifying a special `x-openai-connector:` URL:
_(This example is complete, it can be run "as is")_
[With Pydantic AI Gateway](https://ai.pydantic.dev/builtin-tools/#__tabbed_19_1)[Directly to Provider API](https://ai.pydantic.dev/builtin-tools/#__tabbed_19_2)
[Learn about Gateway](https://ai.pydantic.dev/gateway) mcp_server_configured_connector_id.py```
import os

from pydantic_ai import Agent, MCPServerTool

agent = Agent(
    'gateway/openai-responses:gpt-5.2',
    builtin_tools=[
        MCPServerTool(
            id='google-calendar',
            url='x-openai-connector:connector_googlecalendar',
            authorization_token=os.getenv('GOOGLE_API_KEY', 'mock-api-key'), # [](https://ai.pydantic.dev/builtin-tools/#__code_36_annotation_1)
        )
    ]
)

result = agent.run_sync('What do I have on my calendar today?')
print(result.output)
#> You're going to spend all day playing with Pydantic AI.

```

mcp_server_configured_connector_id.py```
import os

from pydantic_ai import Agent, MCPServerTool

agent = Agent(
    'openai-responses:gpt-5.2',
    builtin_tools=[
        MCPServerTool(
            id='google-calendar',
            url='x-openai-connector:connector_googlecalendar',
            authorization_token=os.getenv('GOOGLE_API_KEY', 'mock-api-key'), #

[](https://ai.pydantic.dev/builtin-tools/#__code_37_annotation_1)
        )
    ]
)

result = agent.run_sync('What do I have on my calendar today?')
print(result.output)
#> You're going to spend all day playing with Pydantic AI.

```

  1. OpenAI's Google Calendar connector requires an [authorization token](https://platform.openai.com/docs/guides/tools-connectors-mcp#authorizing-a-connector).


_(This example is complete, it can be run "as is")_
#### Provider Support
Parameter | OpenAI | Anthropic | xAI
---|---|---|---
`authorization_token` | ✅ | ✅ | ✅
`allowed_tools` | ✅ | ✅ | ✅
`description` | ✅ | ❌ | ✅
`headers` | ✅ | ❌ | ✅
## File Search Tool
The [`FileSearchTool`](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.FileSearchTool "FileSearchTool



      dataclass
  ") enables your agent to search through uploaded files using vector search, providing a fully managed Retrieval-Augmented Generation (RAG) system. This tool handles file storage, chunking, embedding generation, and context injection into prompts.
### Provider Support
Provider | Supported | Notes
---|---|---
OpenAI Responses | ✅ | Full feature support. Requires files to be uploaded to vector stores via the [OpenAI Files API](https://platform.openai.com/docs/api-reference/files). To include search results on the [`BuiltinToolReturnPart`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.BuiltinToolReturnPart "BuiltinToolReturnPart



      dataclass
  ") available via [`ModelResponse.builtin_tool_calls`](https://ai.pydantic.dev/api/messages/#pydantic_ai.messages.ModelResponse.builtin_tool_calls "builtin_tool_calls



      property
  "), enable the [`OpenAIResponsesModelSettings.openai_include_file_search_results`](https://ai.pydantic.dev/api/models/openai/#pydantic_ai.models.openai.OpenAIResponsesModelSettings.openai_include_file_search_results "openai_include_file_search_results



      instance-attribute
  ") [model setting](https://ai.pydantic.dev/agent/#model-run-settings).
Google (Gemini) | ✅ | Requires files to be uploaded via the [Gemini Files API](https://ai.google.dev/gemini-api/docs/files). Files are automatically deleted after 48 hours. Supports up to 2 GB per file and 20 GB per project. Using built-in tools and function tools (including [output tools](https://ai.pydantic.dev/output/#tool-output)) at the same time is not supported; to use structured output, use [`PromptedOutput`](https://ai.pydantic.dev/output/#prompted-output) instead.
| Google (Vertex AI) | ❌
Anthropic | ❌ | Not supported
Groq | ❌ | Not supported
OpenAI Chat Completions | ❌ | Not supported
Bedrock | ❌ | Not supported
Mistral | ❌ | Not supported
Cohere | ❌ | Not supported
HuggingFace | ❌ | Not supported
Outlines | ❌ | Not supported
### Usage
#### OpenAI Responses
With OpenAI, you need to first [upload files to a vector store](https://platform.openai.com/docs/assistants/tools/file-search), then reference the vector store IDs when using the `FileSearchTool`.
file_search_openai_upload.py```
import asyncio

from pydantic_ai import Agent, FileSearchTool
from pydantic_ai.models.openai import OpenAIResponsesModel


async def main():
    model = OpenAIResponsesModel('gpt-5.2')

    with open('my_document.txt', 'rb') as f:
        file = await model.client.files.create(file=f, purpose='assistants')

    vector_store = await model.client.vector_stores.create(name='my-docs')
    await model.client.vector_stores.files.create(
        vector_store_id=vector_store.id,
        file_id=file.id
    )

    agent = Agent(
        model,
        builtin_tools=[FileSearchTool(file_store_ids=[vector_store.id])]
    )

    result = await agent.run('What information is in my documents about pydantic?')
    print(result.output)
    #> Based on your documents, Pydantic is a data validation library for Python...

asyncio.run(main())

```

#### Google (Gemini)
With Gemini, you need to first [create a file search store via the Files API](https://ai.google.dev/gemini-api/docs/files), then reference the file search store names.
file_search_google_upload.py```
import asyncio

from pydantic_ai import Agent, FileSearchTool
from pydantic_ai.models.google import GoogleModel


async def main():
    model = GoogleModel('gemini-3-flash-preview')

    store = await model.client.aio.file_search_stores.create(
        config={'display_name': 'my-docs'}
    )

    with open('my_document.txt', 'rb') as f:
        await model.client.aio.file_search_stores.upload_to_file_search_store(
            file_search_store_name=store.name,
            file=f,
            config={'mime_type': 'text/plain'}
        )

    agent = Agent(
        model,
        builtin_tools=[FileSearchTool(file_store_ids=[store.name])]
    )

    result = await agent.run('Summarize the key points from my uploaded documents.')
    print(result.output)
    #> The documents discuss the following key points: ...

asyncio.run(main())

```

## API Reference
For complete API documentation, see the [API Reference](https://ai.pydantic.dev/api/builtin_tools/).
© Pydantic Services Inc. 2024 to present
