"""Generate a skeleton (dummy) programme from a ScheduleConfig.

The dummy programme contains all time-slots (sessions, breaks, lunch, dinner,
plenary/reserved slots) but no papers, rooms, or chairs assigned yet.
Session IDs are generated so they can be referenced in subsequent constraints.
"""

from __future__ import annotations

from .config import ScheduleConfig
from .models import (
    DayProgram,
    Program,
    Session,
    SlotKind,
    TimeSlot,
)


def _minutes(t: str) -> int:
    h, m = map(int, t.split(":"))
    return h * 60 + m


def _fmt(minutes: int) -> str:
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def _parse_break_overrides(cfg: ScheduleConfig) -> dict[str, dict[int, int]]:
    """Extract per-day break/lunch/dinner time overrides from constraints.

    Returns e.g. {"morning_break": {1: 615}, "lunch": {2: 750}, ...}
    where values are minutes-since-midnight.
    """
    overrides: dict[str, dict[int, int]] = {}
    for kind in ("morning_break", "afternoon_break", "lunch", "dinner"):
        overrides[kind] = {}
    for c in cfg.constraints:
        if c.subject_type in overrides and c.op.value == "=" and c.value:
            try:
                day_num = int(c.subject_id)
                overrides[c.subject_type][day_num] = _minutes(c.value[0])
            except (ValueError, TypeError):
                pass
    return overrides


def _build_day_slots(
    cfg: ScheduleConfig,
    day: int,
    session_counter: list[int],
) -> list[dict]:
    """Build the list of time-slot dicts for one day.

    Returns a list of slot dicts:
      {"time_slot": TimeSlot, "sessions": [Session, ...]}
    """
    start = _minutes(cfg.effective_day_start(day))
    end = _minutes(cfg.effective_day_end(day))

    # Collect plenary slots for this day, sorted by start time
    prelims = sorted(
        [ps for ps in cfg.plenary_slots if ps.day == day],
        key=lambda ps: _minutes(ps.start),
    )

    # Collect constraints that fix a session label
    fixed_labels: dict[str, str] = {}
    for c in cfg.constraints:
        if c.subject_type == "section" and c.op.value == "=" and c.value:
            fixed_labels[c.subject_id] = c.value[0]

    # Per-day break/lunch/dinner time overrides
    break_overrides = _parse_break_overrides(cfg)

    slots: list[dict] = []
    cursor = start
    prelim_idx = 0

    # Place breaks and lunch at configurable target times.
    # Find when regular sessions actually begin (after contiguous opening plenaries).
    eff_start = start
    for ps in prelims:
        ps_start = _minutes(ps.start)
        ps_end = _minutes(ps.end)
        # Only count prelims that start within room_change_penalty of current eff_start
        if ps_start <= eff_start + cfg.room_change_penalty_min:
            eff_start = ps_end
        else:
            break

    # Apply per-day overrides if present, otherwise use global targets
    mb_target = break_overrides["morning_break"].get(
        day, _minutes(cfg.morning_break_target) if cfg.morning_break_target else _minutes("10:30"),
    )
    lu_target = break_overrides["lunch"].get(
        day, _minutes(cfg.lunch_target) if cfg.lunch_target else _minutes("12:00"),
    )
    ab_target = break_overrides["afternoon_break"].get(
        day, _minutes(cfg.afternoon_break_target) if cfg.afternoon_break_target else _minutes("15:00"),
    )

    has_explicit_lunch = day in break_overrides["lunch"]
    has_explicit_ab = day in break_overrides["afternoon_break"]

    # If effective start is already past the morning break target, skip it
    can_morning = cfg.morning_break and eff_start < mb_target
    morning_break_target = mb_target if can_morning else end + 1
    # Explicit per-day overrides bypass the eff_start guard
    if has_explicit_lunch:
        lunch_target = lu_target
    else:
        lunch_target = max(lu_target, eff_start + 80)
    if has_explicit_ab:
        afternoon_break_target = ab_target
    else:
        afternoon_break_target = max(ab_target, lunch_target + cfg.lunch_duration_min + 80)

    placed_morning_break = not can_morning
    placed_lunch = not cfg.lunch_included
    placed_afternoon_break = not cfg.afternoon_break

    # Track whether a room-change gap is needed before the next session
    need_room_change = False
    # Per-day session counters for morning/afternoon naming
    morning_session_num = 0
    afternoon_session_num = 0
    is_afternoon = False  # flips after lunch is placed

    # Determine day prefix for session IDs (e.g. "Tue", "Wed")
    day_prefix = ""
    if cfg.day_names and day - 1 < len(cfg.day_names):
        day_prefix = cfg.day_names[day - 1][:3]

    while cursor + cfg.presentation_duration_min <= end or prelim_idx < len(prelims):
        # Check if a plenary slot starts here (or before the next session)
        if prelim_idx < len(prelims):
            ps = prelims[prelim_idx]
            ps_start = _minutes(ps.start)
            ps_end = _minutes(ps.end)
            if ps_start <= cursor + cfg.room_change_penalty_min:
                # Insert the plenary slot
                ts = TimeSlot(
                    start=_fmt(ps_start),
                    end=_fmt(ps_end),
                    kind=SlotKind.PLENARY,
                    label=ps.label,
                    day=day,
                    chair=getattr(ps, "chair", "") or "",
                    speaker=getattr(ps, "speaker", "") or "",
                )
                sid = f"P{day}_{prelim_idx + 1}"
                sess = Session(
                    session_id=sid,
                    day=day,
                    time_slot=ts,
                    label=ps.label,
                    is_fixed=True,
                )
                slots.append({"time_slot": ts, "sessions": [sess]})
                cursor = max(ps_end, cursor)
                prelim_idx += 1
                need_room_change = True
                continue

        # If we're past end but still have plenaries, advance to next plenary
        if cursor + cfg.presentation_duration_min > end:
            if prelim_idx < len(prelims):
                cursor = _minutes(prelims[prelim_idx].start)
                continue
            break

        # Morning break
        if not placed_morning_break and cursor >= morning_break_target:
            ts = TimeSlot(
                start=_fmt(cursor),
                end=_fmt(cursor + cfg.break_duration_min),
                kind=SlotKind.BREAK,
                label="Morning Break",
                day=day,
            )
            slots.append({"time_slot": ts, "sessions": []})
            cursor += cfg.break_duration_min
            placed_morning_break = True
            need_room_change = False  # break already provides a gap
            continue

        # Lunch
        if not placed_lunch and cursor >= lunch_target:
            ts = TimeSlot(
                start=_fmt(cursor),
                end=_fmt(cursor + cfg.lunch_duration_min),
                kind=SlotKind.LUNCH,
                label="Lunch",
                day=day,
            )
            slots.append({"time_slot": ts, "sessions": []})
            cursor += cfg.lunch_duration_min
            placed_lunch = True
            is_afternoon = True
            need_room_change = False  # lunch already provides a gap
            continue

        # Afternoon break
        if not placed_afternoon_break and cursor >= afternoon_break_target:
            ts = TimeSlot(
                start=_fmt(cursor),
                end=_fmt(cursor + cfg.break_duration_min),
                kind=SlotKind.BREAK,
                label="Afternoon Break",
                day=day,
            )
            slots.append({"time_slot": ts, "sessions": []})
            cursor += cfg.break_duration_min
            placed_afternoon_break = True
            need_room_change = False  # break already provides a gap
            continue

        # Apply room-change penalty gap before sessions
        if need_room_change:
            cursor += cfg.room_change_penalty_min
            need_room_change = False

        # Regular session slot
        sess_end = min(cursor + cfg.max_session_duration_min, end)
        # Don't overshoot into the next plenary
        if prelim_idx < len(prelims):
            ps_start = _minutes(prelims[prelim_idx].start)
            sess_end = min(sess_end, ps_start)
        # Don't overshoot into upcoming lunch/break targets
        if not placed_lunch:
            sess_end = min(sess_end, lunch_target)
        if not placed_morning_break:
            sess_end = min(sess_end, morning_break_target)
        if not placed_afternoon_break:
            sess_end = min(sess_end, afternoon_break_target)

        if sess_end - cursor < cfg.presentation_duration_min:
            cursor = sess_end
            continue

        ts = TimeSlot(
            start=_fmt(cursor),
            end=_fmt(sess_end),
            kind=SlotKind.SESSION,
            label="",
            day=day,
        )
        # Create parallel sessions (one per room available)
        sessions: list[Session] = []
        rooms_this_day = min(cfg.num_available_rooms, cfg.max_rooms_per_day)
        for r in range(rooms_this_day):
            session_counter[0] += 1
            # Session naming: {DayPrefix}{M|A}{num} or fallback S{nn}
            if day_prefix:
                period = "A" if is_afternoon else "M"
                num = (afternoon_session_num if is_afternoon else morning_session_num) + r + 1
                sid = f"{day_prefix}{period}{num:02d}"
            else:
                sid = f"S{session_counter[0]:02d}"
            label = fixed_labels.get(sid, "")
            is_fixed = sid in fixed_labels
            sess = Session(
                session_id=sid,
                day=day,
                time_slot=ts,
                label=label,
                is_fixed=is_fixed,
            )
            sessions.append(sess)
        # Advance per-period counter by the number of parallel sessions
        if is_afternoon:
            afternoon_session_num += rooms_this_day
        else:
            morning_session_num += rooms_this_day

        slots.append({"time_slot": ts, "sessions": sessions})
        cursor = sess_end
        need_room_change = True

    # Dinner (after day_end if included)
    if cfg.dinner_included:
        dinner_start = break_overrides["dinner"].get(day, _minutes(cfg.dinner_start))
        dinner_end = dinner_start + 120  # 2 hours default
        ts = TimeSlot(
            start=_fmt(dinner_start),
            end=_fmt(dinner_end),
            kind=SlotKind.DINNER,
            label="Conference Dinner",
            day=day,
        )
        slots.append({"time_slot": ts, "sessions": []})

    return slots


def generate_dummy_program(cfg: ScheduleConfig) -> Program:
    """Create a skeleton programme respecting the schedule configuration."""
    counter = [0]  # mutable counter shared across days
    days: list[DayProgram] = []
    for d in range(1, cfg.num_days + 1):
        day_slots = _build_day_slots(cfg, d, counter)
        days.append(DayProgram(day=d, slots=day_slots))

    meta = {
        "num_days": cfg.num_days,
        "presentation_duration_min": cfg.presentation_duration_min,
        "max_session_duration_min": cfg.max_session_duration_min,
        "papers_per_session": cfg.papers_per_session,
        "generated": "dummy",
    }
    return Program(days=days, metadata=meta)
