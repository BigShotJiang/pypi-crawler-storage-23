# Project Instructions

## Commit Messages
- Do not put line breaks in the middle of a paragraph.
- Do not reference Claude.
