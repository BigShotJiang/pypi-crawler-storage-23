# Tests for atomic types serialization in PersiDict
import pytest

pytestmark = pytest.mark.slow
