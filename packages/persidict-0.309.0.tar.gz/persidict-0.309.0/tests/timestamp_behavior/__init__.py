import pytest

pytestmark = [pytest.mark.slow, pytest.mark.integration]
