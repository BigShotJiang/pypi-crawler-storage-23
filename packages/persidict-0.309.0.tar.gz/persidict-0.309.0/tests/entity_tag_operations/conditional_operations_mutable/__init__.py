"""ETag conditional operation tests."""
