def main():
    print("Hello from magbox!")


if __name__ == "__main__":
    main()
