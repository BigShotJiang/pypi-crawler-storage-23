# Flask Example

## Setup

```bash
# From the repository root
pip install -e ".[flask]"

# Run the server
cd examples/flask_example
python app.py
```

## Usage

Open http://localhost:5000/logs/ in your browser.

**Credentials:** `admin` / `admin`
