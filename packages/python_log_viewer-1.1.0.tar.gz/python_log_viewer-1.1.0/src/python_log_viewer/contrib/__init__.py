# Framework integrations for python-log-viewer.
