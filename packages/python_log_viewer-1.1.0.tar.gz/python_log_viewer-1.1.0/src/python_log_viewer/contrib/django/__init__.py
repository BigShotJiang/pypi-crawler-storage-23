# Django integration for python-log-viewer.
#
# Add ``"python_log_viewer.contrib.django"`` to ``INSTALLED_APPS`` and include
# ``python_log_viewer.contrib.django.urls`` in your URL configuration.
