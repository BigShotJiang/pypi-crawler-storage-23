"""Type stubs for tenuo."""
