from setuptools import setup, Extension

# minimal build script to support the optional C extension.
# All other metadata lives in pyproject.toml (PEP 621).

setup(
    ext_modules=[
        Extension(
            "basemesh._algorithms._algorithms_c",
            ["basemesh/_algorithms/_algorithms_c.c"],
            optional=True,
        )
    ]
)
