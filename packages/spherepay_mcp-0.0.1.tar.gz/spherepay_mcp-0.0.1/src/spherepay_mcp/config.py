from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)


class EnvironmentConfig:
    """Configuration loaded from environment variables."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.sandbox.spherepay.co",
        timeout_seconds: float = 30.0,
        max_retries: int = 3,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries

    @property
    def is_sandbox(self) -> bool:
        return "sandbox" in self.base_url

    @classmethod
    def from_env(cls) -> EnvironmentConfig:
        api_key = os.environ.get("SPHEREPAY_API_KEY", "")
        if not api_key:
            raise ValueError("SPHEREPAY_API_KEY environment variable is required")

        base_url = os.environ.get("SPHEREPAY_BASE_URL", "https://api.sandbox.spherepay.co")
        timeout = float(os.environ.get("SPHEREPAY_TIMEOUT", "30"))
        max_retries = int(os.environ.get("SPHEREPAY_MAX_RETRIES", "3"))

        config = cls(
            api_key=api_key,
            base_url=base_url,
            timeout_seconds=timeout,
            max_retries=max_retries,
        )

        if not config.is_sandbox:
            confirm = os.environ.get("SPHEREPAY_CONFIRM_PRODUCTION", "")
            if confirm.lower() != "true":
                raise ValueError(
                    f"Production base URL detected ({base_url}). Set SPHEREPAY_CONFIRM_PRODUCTION=true to acknowledge."
                )

        return config
