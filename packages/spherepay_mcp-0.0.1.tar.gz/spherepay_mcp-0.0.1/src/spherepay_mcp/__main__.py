# Application entry point (starts the server)

import logging
import sys

from spherepay_mcp.server import main

logging.basicConfig(
    level=logging.INFO, stream=sys.stderr, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

if __name__ == "__main__":
    main()
