"""MCP resource registration for LLM discovery.

Exposes reference data (currencies, networks, ID formats, types) as
MCP resources so LLMs can query valid options before calling tools.
See ADR-0015 for rationale.
"""

from __future__ import annotations

import json

from fastmcp import FastMCP

from spherepay_mcp.domain.value_objects import Currency, Network

_FIAT_CURRENCIES = {Currency.USD, Currency.EUR}
_FIAT_NETWORKS = {Network.ACH, Network.WIRE, Network.SEPA}


def register_resources(mcp: FastMCP) -> None:
    """Register reference data resources on the MCP server."""

    @mcp.resource("spherepay://reference/currencies")
    async def currencies_resource() -> str:
        """List of supported currencies with their types."""
        return json.dumps(
            {
                "currencies": [
                    {
                        "code": c.value,
                        "type": "fiat" if c in _FIAT_CURRENCIES else "crypto",
                    }
                    for c in Currency
                ]
            },
            indent=2,
        )

    @mcp.resource("spherepay://reference/networks")
    async def networks_resource() -> str:
        """List of supported payment networks with their types."""
        return json.dumps(
            {
                "networks": [
                    {
                        "name": n.value,
                        "type": "fiat" if n in _FIAT_NETWORKS else "crypto",
                    }
                    for n in Network
                ]
            },
            indent=2,
        )

    @mcp.resource("spherepay://reference/id-formats")
    async def id_formats_resource() -> str:
        """ID format patterns for each entity type."""
        return json.dumps(
            {
                "id_formats": {
                    "customer": {
                        "pattern": "customer_<32 hex chars>",
                        "example": "customer_aaaabbbbccccddddeeeeffffaaaabbbb",
                    },
                    "bank_account": {
                        "pattern": "bankAccount_<32 hex chars>",
                        "example": "bankAccount_aaaabbbbccccddddeeeeffffaaaabbbb",
                    },
                    "wallet": {
                        "pattern": "wallet_<32 hex chars>",
                        "example": "wallet_aaaabbbbccccddddeeeeffffaaaabbbb",
                    },
                    "transfer": {
                        "pattern": "transfer_<32 hex chars>",
                        "example": "transfer_aaaabbbbccccddddeeeeffffaaaabbbb",
                    },
                    "business_rep": {
                        "pattern": "businessRep_<32 hex chars>",
                        "example": "businessRep_aaaabbbbccccddddeeeeffffaaaabbbb",
                    },
                }
            },
            indent=2,
        )

    @mcp.resource("spherepay://reference/instrument-types")
    async def instrument_types_resource() -> str:
        """Funding instrument types and their required fields."""
        return json.dumps(
            {
                "instrument_types": {
                    "bank_account": {
                        "required_fields": [
                            "customer_id",
                            "bank_name",
                            "account_name",
                            "currency",
                            "account_details",
                            "account_owner",
                        ],
                        "optional_fields": ["networks"],
                        "account_details_usd": {
                            "accountNumber": "string",
                            "routingNumber": "string",
                            "accountType": "checking | savings",
                        },
                        "account_details_eur": {"iban": "string"},
                    },
                    "wallet": {
                        "required_fields": [
                            "customer_id",
                            "address",
                            "network",
                        ],
                        "description": "Blockchain wallet address on a supported crypto network",
                    },
                }
            },
            indent=2,
        )

    @mcp.resource("spherepay://reference/customer-types")
    async def customer_types_resource() -> str:
        """Customer types and their required fields."""
        return json.dumps(
            {
                "customer_types": {
                    "individual": {
                        "required_fields": ["email", "phone", "address"],
                        "optional_fields": [
                            "first_name",
                            "last_name",
                            "date_of_birth",
                        ],
                    },
                    "business": {
                        "required_fields": ["email", "phone"],
                        "optional_fields": [
                            "business_information",
                            "registered_address",
                            "operating_address",
                        ],
                    },
                }
            },
            indent=2,
        )
