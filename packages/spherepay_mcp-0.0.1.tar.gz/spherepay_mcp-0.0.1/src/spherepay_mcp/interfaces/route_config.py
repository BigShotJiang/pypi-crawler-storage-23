"""Route map and tool exposure configuration.

Defines the curated tool surface as a canonical allowlist.
Used by tool visibility tests to verify only approved operations are exposed.
See ADR-0003 and ADR-0005 for rationale.

Note: Read-only tools are hand-registered in tools.py (not via FastMCP.from_openapi)
for richer parameter control and consistent error handling. This module provides
the canonical list of approved tool names for contract testing.
"""

from __future__ import annotations

# Canonical list of approved tool names in the default MCP surface.
# This is the single source of truth for tool visibility contract tests.
WORKFLOW_TOOLS: frozenset[str] = frozenset(
    {
        "onboard_customer",
        "verify_customer",
        "setup_funding",
        "execute_transfer",
        "onboard_business_rep",
        "setup_virtual_account",
        "setup_offloader_wallet",
        "create_webhook",
        "submit_cctp_offramp",
    }
)

READ_TOOLS: frozenset[str] = frozenset(
    {
        "get_customer",
        "list_customers",
        "get_transfer",
        "list_transfers",
        "get_bank_account",
        "list_bank_accounts",
        "get_wallet",
        "list_wallets",
        "get_virtual_account",
        "list_virtual_accounts",
        "list_virtual_account_transfers",
        "get_offloader_wallet",
        "list_offloader_wallets",
        "get_webhook",
        "get_event",
    }
)

APPROVED_TOOLS: frozenset[str] = WORKFLOW_TOOLS | READ_TOOLS

# Patterns that indicate destructive operations — must never appear in tool names.
DESTRUCTIVE_PATTERNS: frozenset[str] = frozenset({"delete", "remove", "destroy", "cancel"})

# Sensitive fields that must be redacted in logs.
SENSITIVE_FIELDS: frozenset[str] = frozenset(
    {
        "accountNumber",
        "routingNumber",
        "iban",
        "bic",
        "api_key",
        "Authorization",
        "dateOfBirth",
        "phone",
        "phoneNumber",
        "email",
        "ssn",
        "ein",
        "firstName",
        "lastName",
        "secret",
    }
)
