from __future__ import annotations

import logging
from typing import Any

from spherepay_mcp.ports.spherepay_gateway import SpherePayGateway

logger = logging.getLogger(__name__)


class OffloaderWalletService:
    """Orchestrates offloader wallet creation with validation."""

    def __init__(self, gateway: SpherePayGateway):
        self._gw = gateway

    async def setup_offloader_wallet(
        self,
        customer_id: str,
        currency: str,
        network: str,
        wallet_address: str,
    ) -> dict[str, Any]:
        payload = {
            "customerId": customer_id,
            "currency": currency,
            "network": network,
            "walletAddress": wallet_address,
        }
        result = await self._gw.create_offloader_wallet(payload)
        wallet = result.get("data", {}).get("offloaderWallet", result.get("data", result))

        return {
            "offloader_wallet": wallet,
            "next_steps": [
                "Offloader wallet is ready to receive off-ramp transfers",
                "Use execute_transfer to create transfers to this offloader wallet",
                "Use get_offloader_wallet to check wallet status",
            ],
        }
