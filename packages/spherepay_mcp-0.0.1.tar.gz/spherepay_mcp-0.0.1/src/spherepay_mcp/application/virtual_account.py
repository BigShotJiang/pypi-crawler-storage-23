from __future__ import annotations

import logging
from typing import Any

from spherepay_mcp.ports.spherepay_gateway import SpherePayGateway

logger = logging.getLogger(__name__)


class VirtualAccountService:
    """Orchestrates virtual account creation with validation."""

    def __init__(self, gateway: SpherePayGateway):
        self._gw = gateway

    async def setup_virtual_account(
        self,
        customer_id: str,
        source_currency: str,
        destination_currency: str,
        network: str,
        wallet_address: str,
        integrator_bps_fee: str = "0",
    ) -> dict[str, Any]:
        payload = {
            "customerId": customer_id,
            "sourceCurrency": source_currency,
            "destinationCurrency": destination_currency,
            "network": network,
            "walletAddress": wallet_address,
            "integratorBpsFee": integrator_bps_fee,
        }
        result = await self._gw.create_virtual_account(payload)
        va = result.get("data", {}).get("virtualAccount", result.get("data", result))

        return {
            "virtual_account": va,
            "deposit_instructions": va.get("depositInstructions") if isinstance(va, dict) else None,
            "next_steps": [
                "Send funds in the source currency to the bank details in deposit_instructions",
                "Deposits will auto-convert and deliver to the destination wallet",
                "Use list_virtual_account_transfers to monitor deposit activity",
                "Use get_virtual_account to check account status",
            ],
        }
