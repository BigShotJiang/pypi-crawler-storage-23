"""Request correlation context for tracing tool invocations.

Uses contextvars to propagate a correlation ID through the call stack
without threading it through every function signature.
See ADR-0014 for rationale.
"""

from __future__ import annotations

import contextvars
import uuid

_correlation_id: contextvars.ContextVar[str] = contextvars.ContextVar("correlation_id", default="")


def new_correlation_id() -> str:
    """Generate a new correlation ID and set it in the current context."""
    cid = uuid.uuid4().hex[:12]
    _correlation_id.set(cid)
    return cid


def get_correlation_id() -> str:
    """Get the current correlation ID (empty string if not set)."""
    return _correlation_id.get()
