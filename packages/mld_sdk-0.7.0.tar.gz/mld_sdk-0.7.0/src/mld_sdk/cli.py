"""CLI entry point for the MLD SDK.

Provides the ``mld build`` command to package plugins into ``.mld`` bundles.
"""

import argparse
import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:  # Python < 3.11
    import tomli as tomllib  # type: ignore[no-redef]


def _read_pyproject(project_dir: Path) -> dict:
    """Read and return the [project] table from pyproject.toml."""
    path = project_dir / "pyproject.toml"
    if not path.exists():
        print(f"Error: {path} not found.", file=sys.stderr)
        sys.exit(1)
    with open(path, "rb") as f:
        data = tomllib.load(f)
    if "project" not in data:
        print("Error: pyproject.toml has no [project] table.", file=sys.stderr)
        sys.exit(1)
    return data["project"]


def _build_wheel(project_dir: Path, output_dir: Path) -> Path:
    """Build a wheel using ``uv build`` and return its path.

    If a wheel already exists in the output directory, it is reused.
    """
    result = subprocess.run(
        ["uv", "build", "--wheel", "--out-dir", str(output_dir)],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"Error: uv build failed:\n{result.stderr}", file=sys.stderr)
        sys.exit(1)

    whls = list(output_dir.glob("*.whl"))
    if not whls:
        print("Error: uv build produced no .whl file.", file=sys.stderr)
        sys.exit(1)
    return whls[0]


def _download_deps(project_dir: Path, dest: Path) -> list[Path]:
    """Download binary dependency wheels into *dest*."""
    result = subprocess.run(
        [
            "uv",
            "pip",
            "download",
            "--only-binary",
            ":all:",
            "--dest",
            str(dest),
            "--requirement",
            str(project_dir / "pyproject.toml"),
        ],
        cwd=project_dir,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(
            f"Warning: dependency download failed (non-fatal):\n{result.stderr}",
            file=sys.stderr,
        )
        return []
    return list(dest.glob("*.whl"))


def _build_manifest(
    project: dict,
    main_whl_name: str,
    dep_whl_names: list[str],
) -> dict:
    """Build the manifest.json content."""
    return {
        "format_version": 1,
        "plugin": {
            "name": project["name"],
            "version": project["version"],
            "description": project.get("description", ""),
            "requires_mld": project.get("requires_mld", ">=0.1.0"),
        },
        "wheels": {
            "main": main_whl_name,
            "dependencies": dep_whl_names,
        },
    }


def cmd_build(args: argparse.Namespace) -> None:
    """Execute the ``mld build`` command."""
    project_dir = Path(args.path).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    project = _read_pyproject(project_dir)
    name = project["name"]
    version = project["version"]

    # Build the wheel
    with tempfile.TemporaryDirectory() as build_tmp:
        build_path = Path(build_tmp)
        main_whl = _build_wheel(project_dir, build_path)

        # Optionally vendor dependencies
        dep_whls: list[Path] = []
        if args.vendor_deps:
            dep_dir = build_path / "deps"
            dep_dir.mkdir()
            dep_whls = _download_deps(project_dir, dep_dir)
            # Exclude the main wheel if it ended up in deps
            dep_whls = [w for w in dep_whls if w.name != main_whl.name]

        # Build manifest
        manifest = _build_manifest(
            project,
            main_whl.name,
            [w.name for w in dep_whls],
        )

        # Create .mld archive
        mld_filename = f"{name}-{version}.mld"
        mld_path = output_dir / mld_filename

        with zipfile.ZipFile(mld_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
            zf.write(main_whl, main_whl.name)
            for dep in dep_whls:
                zf.write(dep, dep.name)

    print(f"Built {mld_path}")


def main(argv: list[str] | None = None) -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="mld",
        description="MLD SDK command-line tools",
    )
    subparsers = parser.add_subparsers(dest="command")

    build_parser = subparsers.add_parser(
        "build",
        help="Package a plugin into a .mld bundle",
    )
    build_parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Plugin project directory (default: current dir)",
    )
    build_parser.add_argument(
        "--vendor-deps",
        action="store_true",
        help="Include dependency wheels in the .mld bundle",
    )
    build_parser.add_argument(
        "--output-dir",
        default="dist",
        help="Output directory (default: dist/)",
    )

    args = parser.parse_args(argv)

    if args.command == "build":
        cmd_build(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
