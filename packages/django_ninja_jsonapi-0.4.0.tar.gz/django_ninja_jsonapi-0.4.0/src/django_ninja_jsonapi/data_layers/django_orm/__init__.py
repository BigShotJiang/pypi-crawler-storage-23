from django_ninja_jsonapi.data_layers.django_orm.orm import DjangoORMDataLayer

__all__ = ["DjangoORMDataLayer"]
