from django_ninja_jsonapi.misc.django_orm.generics.base import ViewBaseGeneric

__all__ = ["ViewBaseGeneric"]
