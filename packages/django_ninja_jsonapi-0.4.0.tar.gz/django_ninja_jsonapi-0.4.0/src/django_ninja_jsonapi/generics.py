from django_ninja_jsonapi.misc.generics.base import ViewBaseGeneric

__all__ = ["ViewBaseGeneric"]
