from udata.auth import Permission


class PostEditPermission(Permission):
    pass
