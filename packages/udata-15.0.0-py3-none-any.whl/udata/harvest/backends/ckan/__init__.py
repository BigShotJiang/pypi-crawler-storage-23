"""
CKAN integration for udata
"""
