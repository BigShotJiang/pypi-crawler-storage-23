import collections.abc
import inspect
from collections.abc import Generator, Iterable, Iterator, Mapping, Sequence
from os import PathLike, fspath
from typing import AbstractSet, Any, Callable, NoReturn, TypeAlias, TypeVar, overload  # noqa: UP035

from typing_extensions import Never

from dagster_shared.check.record import is_record

TypeOrTupleOfTypes: TypeAlias = type | tuple[type, ...]
Numeric: TypeAlias = int | float
T = TypeVar("T")
U = TypeVar("U")
V = TypeVar("V")

TTypeOrTupleOfTTypes: TypeAlias = type[T] | tuple[type[T], ...]


# This module contains runtime type-checking code used throughout Dagster. It is divided into three
# sections:
#
# - TYPE CHECKS: functions that check the type of a single value
# - OTHER CHECKS: functions that check conditions other than the type of a single value
# - ERRORS/UTILITY: error generation code and other utility functions invoked by the check functions
#
# TYPE CHECKS is divided into subsections for each type (e.g. bool, list). Each subsection contains
# multiple functions that implement the same check logic, but differ in how the target value is
# extracted and how the error message is generated. Call this dimension the "check context". Check
# contexts are:
#
# - Parameter checks (`<type>_param`): Used to type-check the arguments to a function, typically
#   before any business logic executes.
# - Element checks (`<type>_elem`): Used to type-check an element of a dictionary under a specific
#   key.
# - General checks (`[is_]<type>`): Used to type-check a value in an arbitrary context. When the
#   function name would conflict with a python built-in, the prefix `is_` is used to disambiguate--
#   e.g. we have `check.is_list` instead of `check.list`.
#
# Using the right check for the calling context ensures an appropriate error message can be generated.

# ###################################################################################################
# ##### TYPE CHECKS
# ###################################################################################################

# ########################
# ##### BOOL
# ########################


def bool_param(obj: object, param_name: str, additional_message: str | None = None) -> bool:
    if not isinstance(obj, bool):
        raise _param_type_mismatch_exception(obj, bool, param_name, additional_message)
    return obj


@overload
def opt_bool_param(
    obj: object, param_name: str, default: bool, additional_message: str | None = None
) -> bool: ...


@overload
def opt_bool_param(
    obj: object,
    param_name: str,
    default: bool | None = ...,
    additional_message: str | None = None,
) -> bool | None: ...


def opt_bool_param(
    obj: object,
    param_name: str,
    default: bool | None = None,
    additional_message: str | None = None,
) -> bool | None:
    if obj is not None and not isinstance(obj, bool):
        raise _param_type_mismatch_exception(obj, bool, param_name, additional_message)
    return default if obj is None else obj


def bool_elem(ddict: Mapping, key: str, additional_message: str | None = None) -> bool:
    dict_param(ddict, "ddict")
    str_param(key, "key")

    value = ddict[key]
    if not isinstance(value, bool):
        raise _element_check_error(key, value, ddict, bool, additional_message)
    return value


def opt_bool_elem(ddict: Mapping, key: str, additional_message: str | None = None) -> bool | None:
    dict_param(ddict, "ddict")
    str_param(key, "key")

    value = ddict.get(key)
    if value is None:
        return None
    if not isinstance(value, bool):
        raise _element_check_error(key, value, ddict, bool, additional_message)
    return value


# ########################
# ##### CALLABLE
# ########################

T_Callable = TypeVar("T_Callable", bound=Callable)


def callable_param(
    obj: T_Callable, param_name: str, additional_message: str | None = None
) -> T_Callable:
    if not callable(obj):
        raise _param_not_callable_exception(obj, param_name, additional_message)
    return obj


@overload
def opt_callable_param(
    obj: None, param_name: str, default: None = ..., additional_message: str | None = None
) -> None: ...


@overload
def opt_callable_param(
    obj: None, param_name: str, default: T_Callable, additional_message: str | None = None
) -> T_Callable: ...


@overload
def opt_callable_param(
    obj: T_Callable,
    param_name: str,
    default: Callable | None = ...,
    additional_message: str | None = None,
) -> T_Callable: ...


def opt_callable_param(
    obj: Callable | None,
    param_name: str,
    default: Callable | None = None,
    additional_message: str | None = None,
) -> Callable | None:
    if obj is not None and not callable(obj):
        raise _param_not_callable_exception(obj, param_name, additional_message)
    return default if obj is None else obj


def is_callable(obj: T_Callable, additional_message: str | None = None) -> T_Callable:
    if not callable(obj):
        raise CheckError(
            "Must be callable. Got"
            f" {obj}.{(additional_message and f' Description: {additional_message}.') or ''}"
        )
    return obj


# ########################
# ##### CLASS
# ########################

T_Type = TypeVar("T_Type", bound=type)


def class_param(
    obj: T_Type,
    param_name: str,
    superclass: type | None = None,
    additional_message: str | None = None,
) -> T_Type:
    if not isinstance(obj, type):
        raise _param_class_mismatch_exception(
            obj, param_name, superclass, False, additional_message
        )

    if superclass and not issubclass(obj, superclass):
        raise _param_class_mismatch_exception(
            obj, param_name, superclass, False, additional_message
        )

    return obj


@overload
def opt_class_param(
    obj: object,
    param_name: str,
    default: type,
    superclass: type | None = None,
    additional_message: str | None = None,
) -> type: ...


@overload
def opt_class_param(
    obj: object,
    param_name: str,
    default: None = ...,
    superclass: type | None = None,
    additional_message: str | None = None,
) -> type | None: ...


def opt_class_param(
    obj: object,
    param_name: str,
    default: type | None = None,
    superclass: type | None = None,
    additional_message: str | None = None,
) -> type | None:
    if obj is not None and not isinstance(obj, type):
        raise _param_class_mismatch_exception(obj, param_name, superclass, True, additional_message)

    if obj is None:
        return default

    if superclass and not issubclass(obj, superclass):
        raise _param_class_mismatch_exception(obj, param_name, superclass, True, additional_message)

    return obj


# ########################
# ##### DICT
# ########################


def dict_param(
    obj: object,
    param_name: str,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> dict[Any, Any]:
    """Ensures argument obj is a native Python dictionary, raises an exception if not, and otherwise
    returns obj.
    """
    if not isinstance(obj, dict):
        raise _param_type_mismatch_exception(
            obj, dict, param_name, additional_message=additional_message
        )

    if not (key_type or value_type):
        return obj

    return _check_mapping_entries(obj, key_type, value_type, mapping_type=dict)


def opt_dict_param(
    obj: dict[T, U] | None,
    param_name: str,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> dict[T, U]:
    """Ensures argument obj is either a dictionary or None; if the latter, instantiates an empty
    dictionary.
    """
    if obj is not None and not isinstance(obj, dict):
        raise _param_type_mismatch_exception(obj, dict, param_name, additional_message)

    if not obj:
        return {}

    return _check_mapping_entries(obj, key_type, value_type, mapping_type=dict)


@overload
def opt_nullable_dict_param(  # pyright: ignore[reportOverlappingOverload]
    obj: None,
    param_name: str,
    key_type: TypeOrTupleOfTypes | None = ...,
    value_type: TypeOrTupleOfTypes | None = ...,
    additional_message: str | None = None,
) -> None: ...


@overload
def opt_nullable_dict_param(
    obj: object,
    param_name: str,
    key_type: TypeOrTupleOfTypes | None = ...,
    value_type: TypeOrTupleOfTypes | None = ...,
    additional_message: str | None = None,
) -> dict: ...


def opt_nullable_dict_param(
    obj: object,
    param_name: str,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> dict | None:
    """Ensures argument obj is either a dictionary or None."""
    if obj is not None and not isinstance(obj, dict):
        raise _param_type_mismatch_exception(obj, dict, param_name, additional_message)

    if not obj:
        return None if obj is None else {}

    return _check_mapping_entries(obj, key_type, value_type, mapping_type=dict)


def two_dim_dict_param(
    obj: object,
    param_name: str,
    key_type: TypeOrTupleOfTypes = str,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> dict:
    if not isinstance(obj, dict):
        raise _param_type_mismatch_exception(obj, dict, param_name, additional_message)

    return _check_two_dim_mapping_entries(obj, key_type, value_type, mapping_type=dict)


def opt_two_dim_dict_param(
    obj: object,
    param_name: str,
    key_type: TypeOrTupleOfTypes = str,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> dict:
    if obj is not None and not isinstance(obj, dict):
        raise _param_type_mismatch_exception(obj, dict, param_name, additional_message)

    if not obj:
        return {}

    return _check_two_dim_mapping_entries(obj, key_type, value_type, mapping_type=dict)


def dict_elem(
    obj: Mapping,
    key: str,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> dict:
    dict_param(obj, "obj")
    str_param(key, "key")

    if key not in obj:
        raise CheckError(f"{key} not present in dictionary {obj}")

    value = obj[key]
    if not isinstance(value, dict):
        raise _element_check_error(key, value, obj, dict, additional_message)
    else:
        return _check_mapping_entries(value, key_type, value_type, mapping_type=dict)


def opt_dict_elem(
    obj: Mapping[str, Any],
    key: str,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> dict:
    dict_param(obj, "obj")
    str_param(key, "key")

    value = obj.get(key)

    if value is None:
        return {}
    elif not isinstance(value, dict):
        raise _element_check_error(key, value, obj, dict, additional_message)
    else:
        return _check_mapping_entries(value, key_type, value_type, mapping_type=dict)


def opt_nullable_dict_elem(
    obj: Mapping[str, Any],
    key: str,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> dict | None:
    dict_param(obj, "obj")
    str_param(key, "key")

    value = obj.get(key)

    if value is None:
        return None
    elif not isinstance(value, dict):
        raise _element_check_error(key, value, obj, dict, additional_message)
    else:
        return _check_mapping_entries(value, key_type, value_type, mapping_type=dict)


@overload
def is_dict(
    obj: dict[U, V],
    key_type: TypeOrTupleOfTypes | None = ...,
    value_type: TypeOrTupleOfTypes | None = ...,
    additional_message: str | None = ...,
) -> dict[U, V]: ...


@overload
def is_dict(
    obj: object,
    key_type: TypeOrTupleOfTypes | None = ...,
    value_type: TypeOrTupleOfTypes | None = ...,
    additional_message: str | None = ...,
) -> dict[Any, Any]: ...


def is_dict(
    obj: object,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> dict:
    if not isinstance(obj, dict):
        raise _type_mismatch_error(obj, dict, additional_message)

    if not (key_type or value_type):
        return obj

    return _check_mapping_entries(obj, key_type, value_type, mapping_type=dict)


# ########################
# ##### FLOAT
# ########################


def float_param(obj: object, param_name: str, additional_message: str | None = None) -> float:
    if not isinstance(obj, float):
        raise _param_type_mismatch_exception(obj, float, param_name, additional_message)
    return obj


@overload
def opt_float_param(
    obj: object, param_name: str, default: float, additional_message: str | None = None
) -> float: ...


@overload
def opt_float_param(
    obj: object,
    param_name: str,
    default: float | None = ...,
    additional_message: str | None = None,
) -> float | None: ...


def opt_float_param(
    obj: object,
    param_name: str,
    default: float | None = None,
    additional_message: str | None = None,
) -> float | None:
    if obj is not None and not isinstance(obj, float):
        raise _param_type_mismatch_exception(obj, float, param_name, additional_message)
    return default if obj is None else obj


def float_elem(ddict: Mapping, key: str, additional_message: str | None = None) -> float:
    dict_param(ddict, "ddict")
    str_param(key, "key")

    value = ddict[key]
    if not isinstance(value, float):
        raise _element_check_error(key, value, ddict, float, additional_message)
    return value


def opt_float_elem(ddict: Mapping, key: str, additional_message: str | None = None) -> float | None:
    dict_param(ddict, "ddict")
    str_param(key, "key")

    value = ddict.get(key)
    if value is None:
        return None
    if not isinstance(value, float):
        raise _element_check_error(key, value, ddict, float, additional_message)
    return value


# ########################
# ##### GENERATOR
# ########################


def generator_param(
    obj: Generator[T, U, V],
    param_name: str,
) -> Generator[T, U, V]:
    if not inspect.isgenerator(obj):
        raise ParameterCheckError(
            f'Param "{param_name}" is not a generator (return value of function that yields) Got '
            f"{obj} instead"
        )
    return obj


def opt_generator_param(
    obj: object,
    param_name: str,
) -> Generator | None:
    if obj is not None and not inspect.isgenerator(obj):
        raise ParameterCheckError(
            f'Param "{param_name}" is not a generator (return value of function that yields) Got '
            f"{obj} instead"
        )
    return obj


def generator(
    obj: object,
) -> Generator:
    if not inspect.isgenerator(obj):
        raise ParameterCheckError(
            f"Not a generator (return value of function that yields) Got {obj} instead"
        )
    return obj


def opt_generator(
    obj: object,
) -> Generator | None:
    if obj is not None and not inspect.isgenerator(obj):
        raise ParameterCheckError(
            f"Not a generator (return value of function that yields) Got {obj} instead"
        )
    return obj


# ########################
# ##### INT
# ########################


def int_param(obj: object, param_name: str, additional_message: str | None = None) -> int:
    if not isinstance(obj, int):
        raise _param_type_mismatch_exception(obj, int, param_name, additional_message)
    return obj


@overload
def opt_int_param(
    obj: object, param_name: str, default: int, additional_message: str | None = ...
) -> int: ...


@overload
def opt_int_param(
    obj: object,
    param_name: str,
    default: int | None = None,
    additional_message: str | None = None,
) -> int | None: ...


def opt_int_param(
    obj: object,
    param_name: str,
    default: int | None = None,
    additional_message: str | None = None,
) -> int | None:
    if obj is not None and not isinstance(obj, int):
        raise _param_type_mismatch_exception(obj, int, param_name, additional_message)
    return default if obj is None else obj


def int_value_param(
    obj: object, value: int, param_name: str, additional_message: str | None = None
) -> int:
    if not isinstance(obj, int):
        raise _param_type_mismatch_exception(obj, int, param_name, additional_message)
    if obj != value:
        raise _param_invariant_exception(param_name, f"Should be equal to {value}")

    return obj


def int_elem(ddict: Mapping, key: str, additional_message: str | None = None) -> int:
    dict_param(ddict, "ddict")
    str_param(key, "key")

    value = ddict[key]
    if not isinstance(value, int):
        raise _element_check_error(key, value, ddict, int, additional_message)
    return value


def opt_int_elem(ddict: Mapping, key: str, additional_message: str | None = None) -> int | None:
    dict_param(ddict, "ddict")
    str_param(key, "key")

    value = ddict.get(key)
    if value is None:
        return None
    if not isinstance(value, int):
        raise _element_check_error(key, value, ddict, int, additional_message)
    return value


# ########################
# ##### INST
# ########################

# NOTE: inst() and opt_inst() perform narrowing, while inst_param() and opt_inst_param() do not. The
# reason for this is that there is a trade-off between narrowing and passing type information
# through untouched. The only working narrowing implementation will sometimes lose type information.
# This is because not every static type can be expressed as a runtime-checkable type:
#
#     foo = Foo(Bar())  # type is Foo[Bar]
#     inst(foo, Foo[Bar])  # illegal, can't pass parameterized types to inst()
#     inst(foo, Foo)  # type is Foo; because we couldn't pass parameterized type, we lost info
#
# In contrast, we don't lose type information when we pass the type of the checked argument through
# without modification.
#
# Because of this trade-off, it makes sense for inst() to perform narrowing but not inst_param().
# With inst(), we rarely have rich type information at the callsite (if we did we wouldn't be
# calling inst()). With inst_param(), on the other hand, we should always have rich type information
# at the callsite from the type annotation, so we should never need to narrow.


def inst_param(
    obj: T, param_name: str, ttype: TypeOrTupleOfTypes, additional_message: str | None = None
) -> T:
    if not isinstance(obj, ttype):
        raise _param_type_mismatch_exception(
            obj, ttype, param_name, additional_message=additional_message
        )
    return obj


@overload
def opt_inst_param(
    obj: T | None,
    param_name: str,
    ttype: TypeOrTupleOfTypes,
    default: None = ...,
    additional_message: str | None = None,
) -> T | None: ...


@overload
def opt_inst_param(
    obj: T | None,
    param_name: str,
    ttype: TypeOrTupleOfTypes,
    default: T,
    additional_message: str | None = None,
) -> T: ...


@overload
def opt_inst_param(
    obj: T,
    param_name: str,
    ttype: TypeOrTupleOfTypes,
    default: T | None = ...,
    additional_message: str | None = None,
) -> T: ...


def opt_inst_param(
    obj: T | None,
    param_name: str,
    ttype: TypeOrTupleOfTypes,
    default: T | None = None,
    additional_message: str | None = None,
) -> T | None:
    if obj is not None and not isinstance(obj, ttype):
        raise _param_type_mismatch_exception(obj, ttype, param_name, additional_message)
    return default if obj is None else obj


def inst(
    obj: object,
    ttype: type[T] | tuple[type[T], ...],
    additional_message: str | None = None,
) -> T:
    if not isinstance(obj, ttype):
        raise _type_mismatch_error(obj, ttype, additional_message)
    return obj


def opt_inst(
    obj: object,
    ttype: type[T] | tuple[type[T], ...],
    additional_message: str | None = None,
) -> T | None:
    if obj is not None and not isinstance(obj, ttype):
        raise _type_mismatch_error(obj, ttype, additional_message)
    return obj


# ########################
# ##### ITERATOR
# ########################


def iterator_param(
    obj: Iterator[T],
    param_name: str,
    additional_message: str | None = None,
) -> Iterator[T]:
    if not isinstance(obj, Iterator):
        raise _param_type_mismatch_exception(obj, Iterator, param_name, additional_message)
    return obj


# ########################
# ##### LIST
# ########################


def list_param(
    obj: object,
    param_name: str,
    of_type: TTypeOrTupleOfTTypes[T] | None = None,
    additional_message: str | None = None,
) -> list[T]:
    if not isinstance(obj, list):
        raise _param_type_mismatch_exception(obj, list, param_name, additional_message)

    if not of_type:
        return obj

    return _check_iterable_items(obj, of_type, "list")


def opt_list_param(
    obj: object,
    param_name: str,
    of_type: TTypeOrTupleOfTTypes[T] | None = None,
    additional_message: str | None = None,
) -> list[T]:
    """Ensures argument obj is a list or None; in the latter case, instantiates an empty list
    and returns it.

    If the of_type argument is provided, also ensures that list items conform to the type specified
    by of_type.
    """
    if obj is not None and not isinstance(obj, list):
        raise _param_type_mismatch_exception(obj, list, param_name, additional_message)

    if not obj:
        return []
    if not of_type:
        return obj

    return _check_iterable_items(obj, of_type, "list")


@overload
def opt_nullable_list_param(
    obj: None,
    param_name: str,
    of_type: TTypeOrTupleOfTTypes[T] | None = ...,
    additional_message: str | None = None,
) -> None: ...


@overload
def opt_nullable_list_param(
    obj: list[T],
    param_name: str,
    of_type: TTypeOrTupleOfTTypes[T] | None = ...,
    additional_message: str | None = None,
) -> list[T]: ...


def opt_nullable_list_param(
    obj: object,
    param_name: str,
    of_type: TTypeOrTupleOfTTypes[T] | None = None,
    additional_message: str | None = None,
) -> list[T] | None:
    """Ensures argument obj is a list or None. Returns None if input is None.

    If the of_type argument is provided, also ensures that list items conform to the type specified
    by of_type.
    """
    if obj is not None and not isinstance(obj, list):
        raise _param_type_mismatch_exception(obj, list, param_name, additional_message)

    if not obj:
        return None if obj is None else []
    if not of_type:
        return obj

    return _check_iterable_items(obj, of_type, "list")


def two_dim_list_param(
    obj: object,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> list[list]:
    obj = list_param(obj, param_name, of_type=list, additional_message=additional_message)
    if not obj:
        raise CheckError("You must pass a list of lists. Received an empty list.")
    for sublist in obj:
        list_param(
            sublist, f"sublist_{param_name}", of_type=of_type, additional_message=additional_message
        )
        if len(sublist) != len(obj[0]):
            raise CheckError("All sublists in obj must have the same length")
    return obj


def list_elem(
    ddict: Mapping,
    key: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> list:
    dict_param(ddict, "ddict")
    str_param(key, "key")
    opt_class_param(of_type, "of_type")

    value = ddict.get(key)

    if isinstance(value, list):
        if not of_type:
            return value

        return _check_iterable_items(value, of_type, "list")

    raise _element_check_error(key, value, ddict, list, additional_message)


def opt_list_elem(
    ddict: Mapping,
    key: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> list:
    dict_param(ddict, "ddict")
    str_param(key, "key")
    opt_class_param(of_type, "of_type")

    value = ddict.get(key)

    if value is None:
        return []

    if not isinstance(value, list):
        raise _element_check_error(key, value, ddict, list, additional_message)

    if not of_type:
        return value

    return _check_iterable_items(value, of_type, "list")


def is_list(
    obj: object,
    of_type: TTypeOrTupleOfTTypes[T] | None = None,
    additional_message: str | None = None,
) -> list[T]:
    if not isinstance(obj, list):
        raise _type_mismatch_error(obj, list, additional_message)

    if not of_type:
        return obj

    return list(_check_iterable_items(obj, of_type, "list"))


# ########################
# ##### LITERAL
# ########################


def literal_param(
    obj: T, param_name: str, values: Sequence[object], additional_message: str | None = None
) -> T:
    if obj not in values:
        raise _param_value_mismatch_exception(obj, values, param_name, additional_message)
    return obj


def opt_literal_param(
    obj: T, param_name: str, values: Sequence[object], additional_message: str | None = None
) -> T:
    if obj is not None and obj not in values:
        raise _param_value_mismatch_exception(
            obj, values, param_name, additional_message, optional=True
        )
    return obj


# ########################
# ##### MAPPING
# ########################


def mapping_param(
    obj: Mapping[T, U],
    param_name: str,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> Mapping[T, U]:
    ttype = type(obj)
    # isinstance check against abc is costly, so try to handle common cases with cheapest check possible
    if not (ttype is dict or isinstance(obj, collections.abc.Mapping)):
        raise _param_type_mismatch_exception(
            obj, (collections.abc.Mapping,), param_name, additional_message=additional_message
        )

    if not (key_type or value_type):
        return obj

    return _check_mapping_entries(obj, key_type, value_type, mapping_type=collections.abc.Mapping)


def opt_mapping_param(
    obj: Mapping[T, U] | None,
    param_name: str,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> Mapping[T, U]:
    if obj is None:
        return dict()
    else:
        return mapping_param(obj, param_name, key_type, value_type, additional_message)


@overload
def opt_nullable_mapping_param(
    obj: None,
    param_name: str,
    key_type: TypeOrTupleOfTypes | None = ...,
    value_type: TypeOrTupleOfTypes | None = ...,
    additional_message: str | None = ...,
) -> None: ...


@overload
def opt_nullable_mapping_param(
    obj: Mapping[T, U],
    param_name: str,
    key_type: TypeOrTupleOfTypes | None = ...,
    value_type: TypeOrTupleOfTypes | None = ...,
    additional_message: str | None = ...,
) -> Mapping[T, U]: ...


def opt_nullable_mapping_param(
    obj: Mapping[T, U] | None,
    param_name: str,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> Mapping[T, U] | None:
    if obj is None:
        return None
    else:
        return mapping_param(obj, param_name, key_type, value_type, additional_message)


def two_dim_mapping_param(
    obj: object,
    param_name: str,
    key_type: TypeOrTupleOfTypes = str,
    value_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> Mapping:
    if not isinstance(obj, Mapping):
        raise _param_type_mismatch_exception(obj, dict, param_name, additional_message)
    return _check_two_dim_mapping_entries(obj, key_type, value_type)


# ########################
# ##### NOT NONE
# ########################


def not_none_param(obj: T | None, param_name: str, additional_message: str | None = None) -> T:
    if obj is None:
        additional_message = " " + additional_message if additional_message else ""
        raise _param_invariant_exception(
            param_name, f"Param {param_name} cannot be none.{additional_message}"
        )
    return obj


def not_none(value: T | None, additional_message: str | None = None) -> T:
    if value is None:
        raise CheckError(f"Expected non-None value: {additional_message}")
    return value


# ########################
# ##### NUMERIC
# ########################


def numeric_param(obj: object, param_name: str, additional_message: str | None = None) -> Numeric:
    if not isinstance(obj, (int, float)):
        raise _param_type_mismatch_exception(obj, (int, float), param_name, additional_message)
    return obj


@overload
def opt_numeric_param(
    obj: object, param_name: str, default: Numeric, additional_message: str | None = ...
) -> Numeric: ...


@overload
def opt_numeric_param(
    obj: object,
    param_name: str,
    default: Numeric | None = ...,
    additional_message: str | None = ...,
) -> Numeric | None: ...


def opt_numeric_param(
    obj: object,
    param_name: str,
    default: Numeric | None = None,
    additional_message: str | None = None,
) -> Numeric | None:
    if obj is not None and not isinstance(obj, (int, float)):
        raise _param_type_mismatch_exception(obj, (int, float), param_name, additional_message)
    return default if obj is None else obj


# ########################
# ##### PATH
# ########################


def path_param(obj: str | PathLike, param_name: str, additional_message: str | None = None) -> str:
    if not isinstance(obj, (str, PathLike)):
        raise _param_type_mismatch_exception(obj, (str, PathLike), param_name, additional_message)
    return fspath(obj)


@overload
def opt_path_param(
    obj: None, param_name: str, default: None = ..., additional_message: str | None = ...
) -> None: ...


@overload
def opt_path_param(
    obj: None,
    param_name: str,
    default: str | PathLike,
    additional_message: str | None = ...,
) -> str: ...


@overload
def opt_path_param(
    obj: str | PathLike,
    param_name: str,
    default: str | PathLike | None = ...,
    additional_message: str | None = ...,
) -> str: ...


def opt_path_param(
    obj: str | PathLike | None,
    param_name: str,
    default: str | PathLike | None = None,
    additional_message: str | None = None,
) -> str | PathLike | None:
    if obj is None:
        return str(default) if default is not None else None
    else:
        return path_param(obj, param_name, additional_message)


# ########################
# ##### SEQUENCE
# ########################


def sequence_param(
    obj: Sequence[T],
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> Sequence[T]:
    """Ensures argument obj is a Sequence.

    Despite technically being a sequences, str and bytes are not allowed as they are
    almost always unintended and cause bugs.

    If the of_type argument is provided, also ensures that sequence items conform to the
    type specified by of_type.
    """
    ttype = type(obj)
    # isinstance check against abc is costly, so try to handle common cases with cheapest check possible
    if not (
        ttype is list
        or ttype is tuple
        # even though str/bytes are technically sequences
        # its likely not desired so error unless allow_str is set
        or (
            isinstance(obj, collections.abc.Sequence)
            and (ttype not in (str, bytes))
            and not is_record(obj)
        )
    ):
        if ttype in (str, bytes):
            msg = f"{ttype.__name__} is a disallowed Sequence type due to its likeliness to cause bugs."
            additional_message = (
                msg if additional_message is None else f"{msg} {additional_message}"
            )

        raise _param_type_mismatch_exception(
            obj,
            collections.abc.Sequence,
            param_name,
            additional_message,
        )

    if not of_type:
        return obj

    return _check_iterable_items(obj, of_type, "sequence")


def opt_sequence_param(
    obj: Sequence[T] | None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> Sequence[T]:
    """Ensures argument obj is a Sequence or None, returning an empty list when None.

    Despite technically being a sequences, str and bytes are not allowed as they are
    almost always unintended and cause bugs.

    If the of_type argument is provided, also ensures that sequence items conform to the
    type specified by of_type.
    """
    ttype = type(obj)
    if obj is None:
        return []
    # isinstance check against abc is costly, so try to handle common cases with cheapest check possible
    elif not (
        ttype is list
        or ttype is tuple
        or (
            isinstance(obj, collections.abc.Sequence)
            and ttype not in (bytes, str)
            and not is_record(obj)
        )
    ):
        if ttype in (str, bytes):
            msg = f"{ttype.__name__} is a disallowed Sequence type due to its likeliness to cause bugs."
            additional_message = (
                msg if additional_message is None else f"{msg} {additional_message}"
            )

        raise _param_type_mismatch_exception(
            obj,
            collections.abc.Sequence,
            param_name,
            additional_message,
        )
    elif of_type is not None:
        return _check_iterable_items(obj, of_type, "sequence")
    else:
        return obj


@overload
def opt_nullable_sequence_param(
    obj: None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = ...,
    additional_message: str | None = ...,
) -> None: ...


@overload
def opt_nullable_sequence_param(
    obj: Sequence[T],
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = ...,
) -> Sequence[T]: ...


def opt_nullable_sequence_param(
    obj: Sequence[T] | None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> Sequence[T] | None:
    if obj is None:
        return None
    else:
        return opt_sequence_param(obj, param_name, of_type, additional_message)


# ########################
# ##### Iterable
# ########################


def iterable_param(
    obj: Iterable[T],
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> Iterable[T]:
    ttype = type(obj)
    # isinstance check against abc is costly, so try to handle common cases with cheapest check possible
    if not (
        ttype is list
        or ttype is tuple
        or (
            isinstance(obj, collections.abc.Iterable)
            and ttype not in (str, bytes)
            and not is_record(obj)
        )
    ):
        raise _param_type_mismatch_exception(
            obj, collections.abc.Iterable, param_name, additional_message
        )

    if not of_type:
        return obj

    return _check_iterable_items(obj, of_type, "iterable")


def opt_iterable_param(
    obj: Iterable[T] | None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> Iterable[T]:
    if obj is None:
        return []

    return iterable_param(obj, param_name, of_type, additional_message)


def opt_nullable_iterable_param(
    obj: Iterable[T] | None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> Iterable[T] | None:
    if obj is None:
        return None

    return iterable_param(obj, param_name, of_type, additional_message)


def is_iterable(
    obj: object,
    of_type: TTypeOrTupleOfTTypes[T] | None = None,
    additional_message: str | None = None,
) -> Iterable[T]:
    # short-circuit for common collections
    # separate if statement to make that explicit
    if not isinstance(obj, (list, tuple)):
        if not isinstance(obj, Iterable):
            raise _type_mismatch_error(obj, list, additional_message)

    return obj if not of_type else _check_iterable_items(obj, of_type, "iterable")


# ########################
# ##### SET
# ########################

T_Set = TypeVar("T_Set", bound=AbstractSet)


def set_param(
    obj: T_Set,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> T_Set:
    if not isinstance(obj, (frozenset, set)):
        raise _param_type_mismatch_exception(obj, (frozenset, set), param_name, additional_message)

    if not of_type:
        return obj

    return _check_iterable_items(obj, of_type, "set")


def opt_set_param(
    obj: T_Set | None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> T_Set:
    """Ensures argument obj is a set or None; in the latter case, instantiates an empty set
    and returns it.

    If the of_type argument is provided, also ensures that list items conform to the type specified
    by of_type.
    """
    if obj is None:
        return frozenset()  # type: ignore # 2 hot 4 cast
    elif obj is not None and not isinstance(obj, (frozenset, set)):
        raise _param_type_mismatch_exception(obj, (frozenset, set), param_name, additional_message)
    elif not of_type:
        return obj

    return _check_iterable_items(obj, of_type, "set")


@overload
def opt_nullable_set_param(
    obj: None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = ...,
    additional_message: str | None = ...,
) -> None: ...


@overload
def opt_nullable_set_param(
    obj: T_Set,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = ...,
    additional_message: str | None = ...,
) -> T_Set: ...


def opt_nullable_set_param(
    obj: T_Set | None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> T_Set | None:
    """Ensures argument obj is a set or None. Returns None if input is None.
    and returns it.

    If the of_type argument is provided, also ensures that list items conform to the type specified
    by of_type.
    """
    if obj is None:
        return None
    elif not isinstance(obj, (frozenset, set)):
        raise _param_type_mismatch_exception(obj, (frozenset, set), param_name, additional_message)
    elif not of_type:
        return obj

    return _check_iterable_items(obj, of_type, "set")


# ########################
# ##### STR
# ########################


def str_param(obj: object, param_name: str, additional_message: str | None = None) -> str:
    if not isinstance(obj, str):
        raise _param_type_mismatch_exception(obj, str, param_name, additional_message)
    return obj


@overload
def opt_str_param(
    obj: object, param_name: str, default: str, additional_message: str | None = ...
) -> str: ...


@overload
def opt_str_param(
    obj: object,
    param_name: str,
    default: str | None = ...,
    additional_message: str | None = ...,
) -> str | None: ...


def opt_str_param(
    obj: object,
    param_name: str,
    default: str | None = None,
    additional_message: str | None = None,
) -> str | None:
    if obj is not None and not isinstance(obj, str):
        raise _param_type_mismatch_exception(obj, str, param_name, additional_message)
    return default if obj is None else obj


def opt_nonempty_str_param(
    obj: object,
    param_name: str,
    default: str | None = None,
    additional_message: str | None = None,
) -> str | None:
    if obj is not None and not isinstance(obj, str):
        raise _param_type_mismatch_exception(obj, str, param_name, additional_message)
    return default if obj is None or obj == "" else obj


def str_elem(ddict: Mapping, key: str, additional_message: str | None = None) -> str:
    dict_param(ddict, "ddict")
    str_param(key, "key")

    value = ddict[key]
    if not isinstance(value, str):
        raise _element_check_error(key, value, ddict, str, additional_message)
    return value


def opt_str_elem(ddict: Mapping, key: str, additional_message: str | None = None) -> str | None:
    dict_param(ddict, "ddict")
    str_param(key, "key")

    value = ddict.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise _element_check_error(key, value, ddict, str, additional_message)
    return value


# ########################
# ##### TUPLE
# ########################


def tuple_param(
    obj: tuple[T, ...],
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    of_shape: tuple[TypeOrTupleOfTypes, ...] | None = None,
    additional_message: str | None = None,
) -> tuple[T, ...]:
    """Ensure param is a tuple and is of a specified type. `of_type` defines a variadic tuple type--
    `obj` may be of any length, but each element must match the `of_type` argmument. `of_shape`
    defines a fixed-length tuple type-- each element must match the corresponding element in
    `of_shape`. Passing both `of_type` and `of_shape` will raise an error.
    """
    if not isinstance(obj, tuple):
        raise _param_type_mismatch_exception(obj, tuple, param_name, additional_message)

    if of_type is None and of_shape is None:
        return obj

    if of_type and of_shape:
        raise CheckError("Must specify exactly one `of_type` or `of_shape`")

    return _check_tuple_items(obj, of_type, of_shape)


@overload
def opt_tuple_param(
    obj: tuple[T, ...] | None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = ...,
    of_shape: tuple[TypeOrTupleOfTypes, ...] | None = ...,
    additional_message: str | None = ...,
) -> tuple[T, ...]: ...


@overload
def opt_tuple_param(
    obj: object,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = ...,
    of_shape: tuple[TypeOrTupleOfTypes, ...] | None = ...,
    additional_message: str | None = ...,
) -> tuple[object, ...]: ...


def opt_tuple_param(
    obj: object,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    of_shape: tuple[TypeOrTupleOfTypes, ...] | None = None,
    additional_message: str | None = None,
) -> tuple[Any, ...]:
    """Ensures argument obj is a tuple or None; in the latter case, instantiates an empty tuple
    and returns it.
    """
    if obj is not None and not isinstance(obj, tuple):
        raise _param_type_mismatch_exception(obj, tuple, param_name, additional_message)

    if obj is None:
        return tuple()

    if of_type is None and of_shape is None:
        return obj

    if of_type and of_shape:
        raise CheckError("Must specify exactly one `of_type` or `of_shape`")

    return _check_tuple_items(obj, of_type, of_shape)


@overload
def opt_nullable_tuple_param(
    obj: None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = ...,
    of_shape: tuple[TypeOrTupleOfTypes, ...] | None = ...,
    additional_message: str | None = ...,
) -> None: ...


@overload
def opt_nullable_tuple_param(
    obj: tuple[T, ...],
    param_name: str,
    of_type: TypeOrTupleOfTypes = ...,
    of_shape: tuple[TypeOrTupleOfTypes, ...] | None = ...,
    additional_message: str | None = None,
) -> tuple[T, ...]: ...


def opt_nullable_tuple_param(
    obj: tuple[T, ...] | None,
    param_name: str,
    of_type: TypeOrTupleOfTypes | None = None,
    of_shape: tuple[TypeOrTupleOfTypes, ...] | None = None,
    additional_message: str | None = None,
) -> tuple[T, ...] | None:
    """Ensure optional param is a tuple and is of a specified type. `default` is returned if `obj`
    is None. `of_type` defines a variadic tuple type-- `obj` may be of any length, but each element
    must match the `of_type` argmument. `of_shape` defines a fixed-length tuple type-- each element
    must match the corresponding element in `of_shape`. Passing both `of_type` and `of_shape` will
    raise an error.
    """
    if obj is not None and not isinstance(obj, tuple):
        raise _param_type_mismatch_exception(obj, tuple, param_name, additional_message)

    if obj is None:
        return None

    if of_type is None and of_shape is None:
        return obj

    if of_type and of_shape:
        raise CheckError("Must specify exactly one `of_type` or `of_shape`")

    return _check_tuple_items(obj, of_type, of_shape)


def is_tuple(
    obj: object,
    of_type: TypeOrTupleOfTypes | None = None,
    of_shape: tuple[TypeOrTupleOfTypes, ...] | None = None,
    additional_message: str | None = None,
) -> tuple:
    """Ensure target is a tuple and is of a specified type. `of_type` defines a variadic tuple
    type-- `obj` may be of any length, but each element must match the `of_type` argmument.
    `of_shape` defines a fixed-length tuple type-- each element must match the corresponding element
    in `of_shape`. Passing both `of_type` and `of_shape` will raise an error.
    """
    if not isinstance(obj, tuple) or is_record(obj):
        raise _type_mismatch_error(obj, tuple, additional_message)

    if of_type is None and of_shape is None:
        return obj

    if of_type and of_shape:
        raise CheckError("Must specify exactly one `of_type` or `of_shape`")

    return _check_tuple_items(obj, of_type, of_shape)


def _check_tuple_items(
    obj_tuple: tuple[T, ...],
    of_type: TypeOrTupleOfTypes | None = None,
    of_shape: tuple[TypeOrTupleOfTypes, ...] | None = None,
) -> tuple[T, ...]:
    if of_shape is not None:
        len_tuple = len(obj_tuple)
        len_type = len(of_shape)
        if not len_tuple == len_type:
            raise CheckError(
                f"Tuple mismatches type: tuple had {len_tuple} members but type had {len_type}"
            )

        for i, obj in enumerate(obj_tuple):
            of_shape_i = of_shape[i]
            if not isinstance(obj, of_shape_i):
                if isinstance(obj, type):
                    additional_message = (
                        " Did you pass a class where you were expecting an instance of the class?"
                    )
                else:
                    additional_message = ""
                raise CheckError(
                    f"Member of tuple mismatches type at index {i}. Expected {of_shape_i}. Got "
                    f"{obj!r} of type {type(obj)}.{additional_message}"
                )

    elif of_type is not None:
        _check_iterable_items(obj_tuple, of_type, "tuple")

    return obj_tuple


def tuple_elem(
    ddict: Mapping,
    key: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> tuple:
    dict_param(ddict, "ddict")
    str_param(key, "key")
    opt_class_param(of_type, "of_type")

    value = ddict.get(key)

    if isinstance(value, tuple) and not is_record(value):
        if not of_type:
            return value

        return _check_iterable_items(value, of_type, "tuple")

    raise _element_check_error(key, value, ddict, tuple, additional_message)


def opt_tuple_elem(
    ddict: Mapping,
    key: str,
    of_type: TypeOrTupleOfTypes | None = None,
    additional_message: str | None = None,
) -> tuple:
    dict_param(ddict, "ddict")
    str_param(key, "key")
    opt_class_param(of_type, "of_type")

    value = ddict.get(key)

    if value is None:
        return tuple()

    if isinstance(value, tuple) and not is_record(value):
        if not of_type:
            return value

        return _check_iterable_items(value, of_type, "tuple")

    raise _element_check_error(key, value, ddict, tuple, additional_message)


# ###################################################################################################
# ##### OTHER CHECKS
# ###################################################################################################


def param_invariant(condition: Any, param_name: str, desc: str | None = None):
    if not condition:
        raise _param_invariant_exception(param_name, desc)


def invariant(condition: Any, desc: str | None = None) -> bool:
    if not condition:
        if desc:
            raise CheckError(f"Invariant failed. Description: {desc}")
        else:
            raise CheckError("Invariant failed.")

    return True


def assert_never(value: Never) -> Never:
    failed(f"Unhandled value: {value} ({type(value).__name__})")


def failed(desc: str) -> NoReturn:
    if not isinstance(desc, str):
        raise CheckError("desc argument must be a string")

    raise CheckError(f"Failure condition: {desc}")


def not_implemented(desc: str) -> NoReturn:
    if not isinstance(desc, str):
        raise CheckError("desc argument must be a string")

    raise NotImplementedCheckError(f"Not implemented: {desc}")


# ###################################################################################################
# ##### ERRORS / UTILITY
# ###################################################################################################


class CheckError(Exception):
    pass


class ParameterCheckError(CheckError):
    pass


class ElementCheckError(CheckError):
    pass


class NotImplementedCheckError(CheckError):
    pass


def _element_check_error(
    key: object,
    value: object,
    ddict: Mapping,
    ttype: TypeOrTupleOfTypes,
    additional_message: str | None = None,
) -> ElementCheckError:
    additional_message = " " + additional_message if additional_message else ""
    return ElementCheckError(
        f"Value {value!r} from key {key} is not a {ttype!r}. Dict: {ddict!r}.{additional_message}"
    )


def _param_value_mismatch_exception(
    obj: object,
    values: Sequence[object],
    param_name: str,
    additional_message: str | None = None,
    optional: bool = False,
) -> ParameterCheckError:
    allow_none_clause = " or None" if optional else ""
    additional_message = " " + additional_message if additional_message else ""
    return ParameterCheckError(
        f'Param "{param_name}" is not equal to one of {values}{allow_none_clause}. Got'
        f" {obj!r}.{additional_message}"
    )


def _param_type_mismatch_exception(
    obj: object,
    ttype: TypeOrTupleOfTypes,
    param_name: str,
    additional_message: str | None = None,
) -> ParameterCheckError:
    additional_message = " " + additional_message if additional_message else ""
    if isinstance(ttype, tuple):
        type_names = sorted([t.__name__ for t in ttype])
        return ParameterCheckError(
            f'Param "{param_name}" is not one of {type_names}. Got {obj!r} which is type'
            f" {type(obj)}.{additional_message}"
        )
    else:
        return ParameterCheckError(
            f'Param "{param_name}" is not a {ttype.__name__}. Got {obj!r} which is type'
            f" {type(obj)}.{additional_message}"
        )


def _param_class_mismatch_exception(
    obj: object,
    param_name: str,
    superclass: type | None,
    optional: bool,
    additional_message: str | None = None,
) -> ParameterCheckError:
    additional_message = " " + additional_message if additional_message else ""
    opt_clause = (optional and "be None or") or ""
    subclass_clause = (superclass and f"that inherits from {superclass.__name__}") or ""
    return ParameterCheckError(
        f'Param "{param_name}" must {opt_clause}be a class{subclass_clause}. Got {obj!r} of'
        f" type {type(obj)}.{additional_message}"
    )


def _type_mismatch_error(
    obj: object, ttype: TypeOrTupleOfTypes, additional_message: str | None = None
) -> CheckError:
    type_message = (
        f"not one of {sorted([t.__name__ for t in ttype])}"
        if isinstance(ttype, tuple)
        else f"not a {ttype.__name__}"
    )
    repr_obj = repr(obj)
    additional_message = " " + additional_message if additional_message else ""
    return CheckError(
        f"Object {repr_obj} is {type_message}. Got {repr_obj} with type"
        f" {type(obj)}.{additional_message}"
    )


def _param_not_callable_exception(
    obj: Any, param_name: str, additional_message: str | None = None
) -> ParameterCheckError:
    additional_message = " " + additional_message if additional_message else ""
    return ParameterCheckError(
        f'Param "{param_name}" is not callable. Got {obj!r} with type {type(obj)}.'
        f"{additional_message}"
    )


def _param_invariant_exception(param_name: str, desc: str | None = None) -> ParameterCheckError:
    return ParameterCheckError(
        f"Invariant violation for parameter {param_name}. Description: {desc}"
    )


T_Iterable = TypeVar("T_Iterable", bound=Iterable)


def _check_iterable_items(
    obj_iter: T_Iterable, of_type: TypeOrTupleOfTypes, collection_name: str = "iterable"
) -> T_Iterable:
    for obj in obj_iter:
        if not isinstance(obj, of_type):
            if isinstance(obj, type):
                additional_message = (
                    " Did you pass a class where you were expecting an instance of the class?"
                )
            else:
                additional_message = ""
            raise CheckError(
                f"Member of {collection_name} mismatches type. Expected {of_type}. Got"
                f" {obj!r} of type {type(obj)}.{additional_message}"
            )

    return obj_iter


W = TypeVar("W", bound=Mapping)
X = TypeVar("X", bound=Mapping)


def _check_mapping_entries(
    obj: W,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    key_check: Callable[..., Any] = isinstance,
    value_check: Callable[..., Any] = isinstance,
    mapping_type: type = collections.abc.Mapping,
) -> W:
    """Enforces that the keys/values conform to the types specified by key_type, value_type."""
    for key, value in obj.items():
        if key_type and not key_check(key, key_type):
            raise CheckError(
                f"Key in {mapping_type.__name__} mismatches type. Expected {key_type!r}. Got"
                f" {key!r}"
            )

        if value_type and not value_check(value, value_type):
            raise CheckError(
                f"Value in {mapping_type.__name__} mismatches expected type for key {key}. Expected"
                f" value of type {value_type!r}. Got value {value} of type {type(value)}."
            )

    return obj


def _check_two_dim_mapping_entries(
    obj: W,
    key_type: TypeOrTupleOfTypes | None = None,
    value_type: TypeOrTupleOfTypes | None = None,
    mapping_type: type = collections.abc.Mapping,
) -> W:
    _check_mapping_entries(
        obj, key_type, mapping_type, mapping_type=mapping_type
    )  # check level one

    for inner_mapping in obj.values():
        _check_mapping_entries(
            inner_mapping, key_type, value_type, mapping_type=mapping_type
        )  # check level two

    return obj
