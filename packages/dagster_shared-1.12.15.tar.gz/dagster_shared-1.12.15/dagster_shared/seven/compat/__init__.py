"""This module is intended for compatibility shims between versions of our third-party
dependencies.
"""
