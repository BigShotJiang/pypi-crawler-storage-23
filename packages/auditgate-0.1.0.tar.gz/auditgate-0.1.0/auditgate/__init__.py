"""AuditGate: Compliance-grade audit logging for agent systems."""

from .core import (
    MISSING,
    AuditEntry,
    AuditPolicy,
    Decision,
    IntegrityMode,
    Mode,
    Result,
    Severity,
    Status,
    StoreErrorMode,
    Trail,
    Verdict,
    compute_hash,
    verify_chain,
    wall_clock,
)
from .engine import AuditError, Engine
from .store import MemoryStore, QueryFilter, Store

__all__ = [
    "Trail",
    "AuditPolicy",
    "AuditEntry",
    "Decision",
    "Result",
    "MISSING",
    "compute_hash",
    "verify_chain",
    "wall_clock",
    "Mode",
    "Status",
    "Severity",
    "Verdict",
    "IntegrityMode",
    "StoreErrorMode",
    "Engine",
    "AuditError",
    "Store",
    "MemoryStore",
    "QueryFilter",
]

__version__ = "0.1.0"
