"""Embedding Adapter to abstract provider specific implementation details"""
from typing import Protocol, List
import time
import asyncio

from fastembed import TextEmbedding
from openai import AzureOpenAI, OpenAI
import google.generativeai as genai 

from app.config.settings import settings

import logging
logger = logging.getLogger(__name__)

class EmbeddingsAdapter(Protocol):
    """Contract for an Embeddings Adapter"""
    async def generate_embedding(self, text: str) -> List[float]:
        ...

class FastEmbeddingAdapter(EmbeddingsAdapter):
    """Generate embeddings using the fastembed libary"""
    
    def __init__(self):
        logger.info("Initialising Fastembed model", extra={
            "embedding_model": settings.EMBEDDING_MODEL,
            "cache_dir": settings.FASTEMBED_CACHE_DIR
        })

        start_time = time.time()
        self.model = TextEmbedding(
            model_name=settings.EMBEDDING_MODEL,
            cache_dir=settings.FASTEMBED_CACHE_DIR
        )
        elapsed = time.time() - start_time

        logger.info("FasteEmbed model loaded successfully", extra={
            "elapsed_time": f"{elapsed:.2f}s",
            "cache_dir": settings.FASTEMBED_CACHE_DIR
        })
        
    async def generate_embedding(self, text: str) -> List[float]:
        try:
            embeddings = list(self.model.embed(text))
        except Exception:
            logger.error("Error generating embeddings", exc_info=True, extra={
                "embedding provider": "fastembed",
                "embedding model": settings.EMBEDDING_MODEL
            })
            raise
        
        if embeddings is None:
            raise RuntimeError("FastEmbedding response did not contain embedding vector")
        
        return list(map(float, embeddings[0]))
    
class AzureOpenAIAdapter(EmbeddingsAdapter):
    """Generate embeddings using Azure Open AI Embeddings Provider"""
    
    def __init__(self):
        logger.info("Intialising Azure Open AI embeddings adapter", extra={
            "embedding_model": settings.EMBEDDING_MODEL
        })
        self.client = AzureOpenAI(
            api_version=settings.AZURE_API_VERSION,
            azure_endpoint=settings.AZURE_ENDPOINT,
            api_key=settings.AZURE_API_KEY
        )
        self.model = settings.AZURE_DEPLOYMENT
        
    async def generate_embedding(self, text) -> List[float]:
        try:
            response = self.client.embeddings.create(
                input=[text],
                model=self.model,
                dimensions=settings.EMBEDDING_DIMENSIONS
            )
        except Exception:
            logger.error("Error generatring embeddings", exc_info=True, extra={
                "embedding provider": "Azure",
                "embedding model": self.model
            })
            raise
        
        if response is None:
            raise RuntimeError("Azure response did not contain embedding vector")

        embeddings  = response.data[0].embedding 

        return embeddings

class GoogleEmbeddingsAdapter(EmbeddingsAdapter):
    """Generate embeddings using Google Generative AI embedding models."""

    def __init__(self):
        logger.info("Initialising Google Generative AI embeddings adapter", extra={
            "embedding_model": settings.EMBEDDING_MODEL
        })

        self.api_key = settings.GOOGLE_AI_API_KEY
        self.model = settings.EMBEDDING_MODEL

        if not self.api_key:
            raise ValueError("GOOGLE_AI_API_KEY must be configured for GoogleEmbeddingsAdapter")

        genai.configure(api_key=self.api_key)

    async def generate_embedding(self, text: str) -> List[float]:
        try:
            result = await asyncio.to_thread(
                genai.embed_content,
                model=self.model,
                content=text,
                output_dimensionality=settings.EMBEDDING_DIMENSIONS
            )
        except Exception:
            logger.error("Error generating embeddings", exc_info=True, extra={
                "embedding_provider": "google",
                "embedding_model": self.model
            })
            raise

        embedding = result.get("embedding")
        if embedding is None:
            raise RuntimeError("Google Generative AI response did not contain embedding vector")
        return list(map(float, embedding))


class OpenAIEmbeddingsAdapter(EmbeddingsAdapter):
    """Generate embeddings using OpenAI's embedding models.

    Supports custom base_url for OpenAI-compatible endpoints (llama.cpp, vLLM, LiteLLM).
    When base_url is set and no API key is provided, a placeholder key is used.
    Set OPENAI_SUPPORTS_DIMENSIONS=false for endpoints that don't support the dimensions param.
    """

    def __init__(self):
        base_url = settings.OPENAI_BASE_URL or None
        self.supports_dimensions = settings.OPENAI_SUPPORTS_DIMENSIONS

        logger.info("Initialising OpenAI embeddings adapter", extra={
            "embedding_model": settings.EMBEDDING_MODEL,
            "base_url": base_url or "(default)",
            "supports_dimensions": self.supports_dimensions,
        })

        api_key = settings.OPENAI_API_KEY
        if not api_key:
            if base_url:
                api_key = "no-key-required"
            else:
                raise ValueError("OPENAI_API_KEY must be configured for OpenAIEmbeddingsAdapter")

        client_kwargs = {"api_key": api_key}
        if base_url:
            client_kwargs["base_url"] = base_url

        self.client = OpenAI(**client_kwargs)
        self.model = settings.EMBEDDING_MODEL

    async def generate_embedding(self, text: str) -> List[float]:
        kwargs = {
            "input": [text],
            "model": self.model,
        }
        if self.supports_dimensions:
            kwargs["dimensions"] = settings.EMBEDDING_DIMENSIONS

        try:
            response = await asyncio.to_thread(
                self.client.embeddings.create,
                **kwargs,
            )
        except Exception:
            logger.error("Error generating embeddings", exc_info=True, extra={
                "embedding_provider": "openai",
                "embedding_model": self.model
            })
            raise

        if response is None:
            raise RuntimeError("OpenAI response did not contain embedding vector")

        return response.data[0].embedding


class OllamaEmbeddingsAdapter(EmbeddingsAdapter):
    """Generate embeddings using Ollama's native API."""

    def __init__(self):
        from ollama import AsyncClient

        logger.info("Initialising Ollama embeddings adapter", extra={
            "embedding_model": settings.EMBEDDING_MODEL,
            "base_url": settings.OLLAMA_BASE_URL,
        })
        self.client = AsyncClient(host=settings.OLLAMA_BASE_URL)
        self.model = settings.EMBEDDING_MODEL

    async def generate_embedding(self, text: str) -> List[float]:
        try:
            response = await self.client.embed(
                model=self.model,
                input=text,
                dimensions=settings.EMBEDDING_DIMENSIONS,
            )
        except Exception:
            logger.error("Error generating embeddings", exc_info=True, extra={
                "embedding_provider": "ollama",
                "embedding_model": self.model,
            })
            raise

        if not response or not response.embeddings:
            raise RuntimeError("Ollama did not return embedding vector")

        return list(response.embeddings[0])
