"""
ORCA Modified Redundant Coordinate (Modred) CLI Module

This module provides the command-line interface for ORCA modified redundant
coordinate calculations. Modred calculations allow users to constrain or
modify specific internal coordinates during geometry optimizations, enabling
controlled structural changes and conformational searches.
"""

import logging

import click

from chemsmart.cli.job import click_job_options
from chemsmart.cli.orca.orca import click_orca_jobtype_options, orca
from chemsmart.cli.orca.qmmm import create_orca_qmmm_subcommand
from chemsmart.utils.cli import MyGroup, get_setting_from_jobtype_for_orca
from chemsmart.utils.utils import check_charge_and_multiplicity

logger = logging.getLogger(__name__)


@orca.group("modred", cls=MyGroup, invoke_without_command=True)
@click_job_options
@click_orca_jobtype_options
@click.pass_context
def modred(
    ctx,
    jobtype,
    coordinates,
    dist_start,
    dist_end,
    num_steps,
    skip_completed,
    **kwargs,
):
    """
    Run ORCA modified redundant coordinate (modred) calculations.

    This command performs geometry optimizations with modified redundant
    coordinates, allowing users to constrain or fix specific internal
    coordinates during the optimization process. This is useful for
    conformational searches, reaction coordinate analysis, and studying
    specific structural changes.
    """
    # set default job type if not specified
    if jobtype is None:
        jobtype = "modred"
        logger.debug("Using default jobtype: modred")

    # get modred settings from project configuration based on job type
    project_settings = ctx.obj["project_settings"]
    modred_settings = get_setting_from_jobtype_for_orca(
        project_settings, jobtype, coordinates, dist_start, dist_end, num_steps
    )
    logger.debug(
        f"Loaded modred settings for jobtype {jobtype}: {modred_settings}"
    )

    # job setting from filename or default, with updates from user in cli
    # specified in keywords
    # e.g., `chemsmart sub orca -c <user_charge> -m <user_multiplicity> modred`
    job_settings = ctx.obj["job_settings"]
    keywords = ctx.obj["keywords"]

    # merge project modred settings with job settings from cli keywords
    modred_settings = modred_settings.merge(job_settings, keywords=keywords)
    logger.info(f"Final modred settings: {modred_settings.__dict__}")

    ctx.obj["parent_skip_completed"] = skip_completed
    ctx.obj["parent_kwargs"] = kwargs
    ctx.obj["parent_settings"] = modred_settings
    ctx.obj["parent_jobtype"] = jobtype

    if ctx.invoked_subcommand is not None:
        return

    # validate charge and multiplicity consistency for direct modred jobs
    check_charge_and_multiplicity(modred_settings)

    # get molecules from context
    molecules = ctx.obj["molecules"]

    # get label for the job output files
    label = ctx.obj["label"]
    logger.debug(f"Job label: {label}")

    from chemsmart.jobs.orca.modred import ORCAModredJob

    # Get the original molecule indices from context
    molecule_indices = ctx.obj.get(
        "molecule_indices", list(range(1, len(molecules) + 1))
    )

    # Handle multiple molecules: create one job per molecule
    if len(molecules) > 1 and molecule_indices is not None:
        logger.info(f"Creating {len(molecules)} ORCA modred jobs")
        jobs = []
        for molecule, idx in zip(molecules, molecule_indices):
            molecule_label = f"{label}_idx{idx}"
            logger.info(
                f"Running modred for molecule {idx}: {molecule} with label {molecule_label}"
            )

            job = ORCAModredJob(
                molecule=molecule,
                settings=modred_settings,
                label=molecule_label,
                skip_completed=skip_completed,
                **kwargs,
            )
            jobs.append(job)
        logger.debug(f"Created {len(jobs)} ORCA modred jobs")
        return jobs
    else:
        # Single molecule case
        molecule = molecules[-1]
        logger.info(f"Running modred calculation on molecule: {molecule}")

        job = ORCAModredJob(
            molecule=molecule,
            settings=modred_settings,
            label=label,
            skip_completed=skip_completed,
            **kwargs,
        )
        logger.debug(f"Created ORCA modred job: {job}")
        return job


create_orca_qmmm_subcommand(modred)
