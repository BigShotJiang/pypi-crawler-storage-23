def main() -> None:
    print("fastapi-tenancy CLI — Coming soon 🚀")
