# `fastapi-tenancy` is multi-tenancy solution for SAAS
