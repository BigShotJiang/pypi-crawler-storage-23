from .recommender import EmbeddingRecommender

__all__ = ["EmbeddingRecommender"]
