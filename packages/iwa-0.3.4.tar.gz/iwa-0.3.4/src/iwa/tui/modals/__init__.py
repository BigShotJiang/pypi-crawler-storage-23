"""Modals for the IWA TUI."""

from .base import CreateEOAModal, CreateSafeModal

__all__ = ["CreateEOAModal", "CreateSafeModal"]
