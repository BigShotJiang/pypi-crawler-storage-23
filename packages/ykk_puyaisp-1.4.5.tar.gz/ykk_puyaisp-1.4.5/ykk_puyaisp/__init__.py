from .ykk_puyaisp import _main

__all__ = ['_main']
