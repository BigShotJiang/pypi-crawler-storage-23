def main():
    print("tpl placeholder")