# pkgprobe 🔍

**pkgprobe** is a Windows-first CLI tool that statically analyzes
EXE and MSI installers and produces a **machine-readable install plan**
for endpoint management and packaging workflows.

> Think: **package intelligence** for Intune, SCCM, Jamf, RMM, and
> Client Platform Engineering teams.

Available on [PyPI](https://pypi.org/project/pkgprobe/).

------------------------------------------------------------------------

## ✨ Why pkgprobe exists

Packaging software on Windows is still more art than science:

-   Silent install flags are undocumented or inconsistent\
-   Installer technologies vary wildly (Inno, NSIS, InstallShield, Burn,
    etc.)
-   Detection rules are often copied, guessed, or discovered via
    trial-and-error
-   Testing installers directly is slow and risky on production machines

**pkgprobe** focuses on the *analysis* phase first:

> **Understand what an installer is likely to do --- before you ever run
> it.**

------------------------------------------------------------------------

## 🧩 What it does (v0.1)

Given an `.msi` or `.exe`, pkgprobe outputs a structured
**install plan** containing:

### Installer Intelligence

-   Installer type detection (MSI, Inno Setup, NSIS, InstallShield,
    Burn, Squirrel, etc.)
-   Confidence-scored classification with supporting evidence

### Command Inference

-   Probable silent install command(s), ranked by confidence
-   Probable uninstall command(s)
-   Evidence explaining *why* each command was suggested

### Detection Guidance

-   MSI product code--based detection (when available)
-   Follow-up guidance for improving detection accuracy
-   Designed to integrate cleanly into Intune / SCCM detection logic

### Automation-Friendly Output

-   JSON output suitable for pipelines and tooling
-   Human-readable CLI summary for engineers

⚠️ **Safety-first by design**\
This version performs **static analysis only**.\
No installers are executed.

------------------------------------------------------------------------

## 📦 Example

``` powershell
pkgprobe analyze .\setup.exe --out installplan.json
```

CLI summary:

    Type: Inno Setup (confidence 0.92)

    Install candidates:
      setup.exe /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP- (0.88)
      setup.exe /SILENT /SUPPRESSMSGBOXES /NORESTART /SP-     (0.62)

    Uninstall candidates:
      unins000.exe /VERYSILENT (0.55)

Generated `installplan.json` (excerpt):

``` json
{
  "installer_type": "Inno Setup",
  "confidence": 0.92,
  "install_candidates": [
    {
      "command": "setup.exe /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-",
      "confidence": 0.88
    }
  ]
}
```

------------------------------------------------------------------------

## 🚀 Installation

**From PyPI** (recommended for users):

``` powershell
pip install pkgprobe
pkgprobe --version
pkgprobe analyze .\setup.exe --out installplan.json
```

**From source** (development):

This project uses **uv** for fast, reproducible Python environments.

``` powershell
pip install uv
git clone https://github.com/Zeph3r/pkgprobe.git
cd pkgprobe
uv venv
uv sync
uv run pkgprobe --help
```

Use `--quiet` / `-q` to suppress the banner when scripting (e.g. in CI or pipes).

------------------------------------------------------------------------

## 🖥️ Supported Inputs

  File Type   Status   Notes
  ----------- -------- -----------------------------------------------------
  MSI         ✅       Metadata parsed via Windows Installer APIs
  EXE         ✅       Heuristic detection via string & signature analysis
  MSIX/AppX   🔍       Detection hints only (wrapper detection)

------------------------------------------------------------------------

## 🧠 How detection works

pkgprobe combines:

-   Static string extraction (ASCII + UTF-16LE)
-   Known installer signature patterns
-   Heuristic confidence scoring
-   Evidence tracking (matched strings, metadata clues)

This keeps analysis **fast, safe, and explainable**.

------------------------------------------------------------------------

## ⚠️ Current limitations

-   Windows-first (intentional --- this targets Windows endpoints)
-   EXE analysis is heuristic-based (not guaranteed)
-   No execution or sandbox tracing in v0.1
-   Detection rules improve significantly with runtime tracing (planned)

------------------------------------------------------------------------

## 🛣️ Roadmap

### v0.2.0 (next)

**CLI UX**

-   **JSON to stdout** – Support `pkgprobe analyze <file> --format json` (or `-o -`) so scripts can consume JSON only from stdout without writing a file.
-   **--summary-only** – Option to print only the human summary (no JSON file, no "Wrote: ..."); useful for quick terminal checks.
-   **Exit codes** – Document and standardize exit codes (e.g. 0 = success, 1 = usage, 2 = file/analysis error) for scripting.
-   **Subcommand examples** – Add a one-line example in `pkgprobe analyze --help` so first-time users see usage immediately.

**Output & format**

-   **--format yaml** – Optional YAML output for install plan (alongside JSON).

**Later (v0.3.0+)**

-   install4j / Java-based installer detection
-   Partial-read scanning for very large EXEs
-   ProcMon-backed trace mode
-   Optional trace-install mode (opt-in, sandboxed)

------------------------------------------------------------------------

## 👤 Who this is for

-   Client Platform Engineers
-   Endpoint / EUC Engineers
-   Intune / SCCM / Jamf admins
-   Security teams validating installer behavior
-   Anyone tired of guessing silent install flags

------------------------------------------------------------------------

## 📄 License

MIT License

------------------------------------------------------------------------

## 🔍 Philosophy

pkgprobe is intentionally **conservative**.

It prefers: - explainability over magic - confidence scoring over
certainty - safety over speed

If it can't be confident, it tells you *why*.

That's how real platform tooling should behave.
