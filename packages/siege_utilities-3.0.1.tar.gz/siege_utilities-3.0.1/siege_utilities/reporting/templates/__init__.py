"""
Templates submodule - Report templates and layouts
"""
# Import template classes as they're defined


