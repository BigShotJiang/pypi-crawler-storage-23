from django.urls import path
urlpatterns = [
    # Define your user-related URL patterns here
]