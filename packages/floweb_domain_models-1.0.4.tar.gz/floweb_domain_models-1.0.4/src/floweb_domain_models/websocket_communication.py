# Synced from python-models/floweb_models/websocket_communication.py
