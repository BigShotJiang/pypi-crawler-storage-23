# Synced from python-models/floweb_models/execution_results.py
