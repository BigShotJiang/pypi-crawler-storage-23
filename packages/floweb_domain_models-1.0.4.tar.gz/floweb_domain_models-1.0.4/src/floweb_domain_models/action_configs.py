# Synced from python-models/floweb_models/action_configs.py
