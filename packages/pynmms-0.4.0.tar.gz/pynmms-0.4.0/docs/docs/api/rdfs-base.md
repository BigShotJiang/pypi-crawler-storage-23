# RDFS Material Base

::: pynmms.rdfs.base
    options:
      members:
        - RDFSMaterialBase
        - CommitmentStore
