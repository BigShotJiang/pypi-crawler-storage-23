# RDFS Syntax

::: pynmms.rdfs.syntax
    options:
      members:
        - RDFSSentence
        - parse_rdfs_sentence
        - is_rdfs_atomic
        - all_rdfs_atomic
        - make_concept_assertion
        - make_role_assertion
