# NMMSReasoner

::: pynmms.reasoner.NMMSReasoner
    options:
      show_source: true
      members:
        - __init__
        - derives
        - query

::: pynmms.reasoner.ProofResult
    options:
      show_source: true
