from .paddleocr_vl import PaddleOCRVLLoader

__all__ = ["PaddleOCRVLLoader"]
