from .document_loaders import PaddleOCRVLLoader

__all__ = ["PaddleOCRVLLoader"]
