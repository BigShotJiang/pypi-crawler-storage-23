"""Monitoring: heartbeat, stall detection, TUI screen scraping."""
