"""Artifact schema, reading, and writing."""
