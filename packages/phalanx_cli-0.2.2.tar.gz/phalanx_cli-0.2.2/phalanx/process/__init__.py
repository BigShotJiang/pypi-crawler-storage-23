"""Process management via tmux (TUI mode)."""
