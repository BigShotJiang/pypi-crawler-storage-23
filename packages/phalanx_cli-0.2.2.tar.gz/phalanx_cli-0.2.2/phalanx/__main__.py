"""Allow running as `python -m phalanx`."""

from phalanx.cli import main

main()
