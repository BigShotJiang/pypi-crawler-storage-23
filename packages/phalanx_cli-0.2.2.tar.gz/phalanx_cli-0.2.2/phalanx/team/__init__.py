"""Team management: create, spawn, orchestrate."""
