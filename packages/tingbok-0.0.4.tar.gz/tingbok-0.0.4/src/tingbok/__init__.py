"""Tingbok — Product and category lookup service."""

try:
    from tingbok._version import __version__
except ImportError:
    __version__ = "0.0.0+unknown"
