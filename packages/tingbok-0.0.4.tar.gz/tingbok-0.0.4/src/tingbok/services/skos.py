"""SKOS lookup service — wraps upstream AGROVOC, DBpedia, Wikidata sources.

This module will be populated when SKOS logic is migrated from inventory-md.
"""
