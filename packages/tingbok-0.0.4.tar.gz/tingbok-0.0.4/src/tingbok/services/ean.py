"""EAN lookup service — wraps upstream OFF, UPCitemdb, Open Library sources.

This module will be populated when EAN logic is migrated from inventory-md.
"""
