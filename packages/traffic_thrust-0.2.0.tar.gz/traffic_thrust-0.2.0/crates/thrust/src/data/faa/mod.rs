#[cfg(not(target_arch = "wasm32"))]
pub mod arcgis;
pub mod nasr;
#[cfg(not(target_arch = "wasm32"))]
pub mod nat;
