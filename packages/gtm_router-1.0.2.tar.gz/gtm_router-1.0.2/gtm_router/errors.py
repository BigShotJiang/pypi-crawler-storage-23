"""Typed error classes for GTM Router API responses."""


class GTMRouterError(Exception):
    """Base error for all GTM Router API failures."""

    def __init__(self, message: str, status_code: int = 0, code: str = ""):
        self.message = message
        self.status_code = status_code
        self.code = code
        super().__init__(message)

    def __repr__(self) -> str:
        return f"GTMRouterError(code={self.code!r}, status={self.status_code}, message={self.message!r})"


class AuthenticationError(GTMRouterError):
    """Raised when the API key is missing or invalid."""


class RateLimitError(GTMRouterError):
    """Raised when the API rate limit is exceeded."""

    def __init__(self, message: str, retry_after: float | None = None):
        super().__init__(message, status_code=429, code="RATE_LIMITED")
        self.retry_after = retry_after


class InsufficientBalanceError(GTMRouterError):
    """Raised when the account balance is too low."""


class ValidationError(GTMRouterError):
    """Raised for 400 validation errors."""


class PollTimeoutError(GTMRouterError):
    """Raised when auto-polling exceeds the configured timeout."""

    def __init__(self, job_id: str, elapsed: float):
        self.job_id = job_id
        self.elapsed = elapsed
        super().__init__(
            f"Polling timed out for job {job_id} after {elapsed:.0f}s",
            code="POLL_TIMEOUT",
        )
