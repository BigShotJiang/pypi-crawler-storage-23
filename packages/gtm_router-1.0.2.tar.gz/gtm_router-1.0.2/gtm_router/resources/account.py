"""Account and billing information."""

from __future__ import annotations

from typing import Any

from ..client import HttpClient


class AccountResource:
    def __init__(self, client: HttpClient):
        self._client = client

    def get(self) -> dict[str, Any]:
        return self._client.request("GET", "/account")
