# hexi-python-lib

A minimal Python library template with Hexi wired in from day one.

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
make hexi-doctor
make test
```

## First Hexi task
```bash
make hexi-run TASK="Add edge-case tests for normalize_text"
```
