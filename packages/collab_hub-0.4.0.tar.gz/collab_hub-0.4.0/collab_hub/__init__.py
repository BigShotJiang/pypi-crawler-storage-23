"""DEPRECATED: collab-hub has been renamed to modelmux."""
