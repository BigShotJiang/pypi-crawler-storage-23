# collab-hub (DEPRECATED)

This package has been renamed to **modelmux**.

```bash
pip install modelmux
```

See https://pypi.org/project/modelmux/ for the latest version.
