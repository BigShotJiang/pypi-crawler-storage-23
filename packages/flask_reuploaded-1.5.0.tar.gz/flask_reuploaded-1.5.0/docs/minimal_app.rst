Minimal Example Application
----------------------------

The Github repository contains an `examples` directory. Please take a look
at it at `the examples <https://github.com/jugmac00/flask-reuploaded/tree/master/examples>`_ 



.. include:: ../examples/example.rst

