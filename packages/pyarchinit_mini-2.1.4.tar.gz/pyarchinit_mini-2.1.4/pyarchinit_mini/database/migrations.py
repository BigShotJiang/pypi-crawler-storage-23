"""
Database migrations for PyArchInit-Mini
"""

import logging
from sqlalchemy import text, inspect
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class DatabaseMigrations:
    """
    Handle database schema migrations
    """
    
    def __init__(self, db_manager):
        self.db_manager = db_manager
        self.connection = db_manager.connection
    
    def check_column_exists(self, table_name: str, column_name: str) -> bool:
        """Check if a column exists in a table"""
        try:
            inspector = inspect(self.connection.engine)
            columns = inspector.get_columns(table_name)
            return any(col['name'] == column_name for col in columns)
        except Exception as e:
            logger.error(f"Error checking column {column_name} in table {table_name}: {e}")
            return False
    
    def add_column_if_not_exists(self, table_name: str, column_name: str, column_type: str, default_value: str = None):
        """Add a column to a table if it doesn't exist"""
        try:
            if not self.check_column_exists(table_name, column_name):
                with self.connection.get_session() as session:
                    # Build ALTER TABLE statement
                    alter_sql = f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}"
                    if default_value is not None:
                        alter_sql += f" DEFAULT {default_value}"
                    
                    session.execute(text(alter_sql))
                    session.commit()
                    logger.info(f"Added column {column_name} to table {table_name}")
                    return True
            else:
                logger.info(f"Column {column_name} already exists in table {table_name}")
                return False
        except Exception as e:
            logger.error(f"Error adding column {column_name} to table {table_name}: {e}")
            raise
    
    def migrate_inventario_materiali_table(self):
        """Migrate inventario_materiali_table to include all new fields"""
        try:
            logger.info("Starting migration for inventario_materiali_table...")
            
            # List of new columns to add
            new_columns = [
                ('schedatore', 'TEXT'),
                ('date_scheda', 'TEXT'),
                ('punto_rinv', 'TEXT'),
                ('negativo_photo', 'TEXT'),
                ('diapositiva', 'TEXT')
            ]
            
            migrations_applied = 0
            
            for column_name, column_type in new_columns:
                if self.add_column_if_not_exists('inventario_materiali_table', column_name, column_type):
                    migrations_applied += 1
            
            logger.info(f"Migration completed. {migrations_applied} new columns added to inventario_materiali_table")
            return migrations_applied
            
        except Exception as e:
            logger.error(f"Error during inventario_materiali_table migration: {e}")
            raise
    
    def migrate_i18n_columns(self):
        """Add i18n columns (_en) for translatable fields"""
        try:
            logger.info("Starting i18n column migrations...")
            
            migrations_applied = 0
            
            # Site table i18n columns
            site_columns = [
                ('definizione_sito_en', 'VARCHAR(250)'),
                ('descrizione_en', 'TEXT')
            ]
            
            for column_name, column_type in site_columns:
                if self.add_column_if_not_exists('site_table', column_name, column_type):
                    migrations_applied += 1
            
            # US table i18n columns
            us_text_columns = [
                ('descrizione_en', 'TEXT'),
                ('interpretazione_en', 'TEXT'),
                ('inclusi_en', 'TEXT'),
                ('campioni_en', 'TEXT'),
                ('documentazione_en', 'TEXT'),
                ('osservazioni_en', 'TEXT')
            ]
            
            us_varchar_columns = [
                ('d_stratigrafica_en', 'VARCHAR(350)'),
                ('d_interpretativa_en', 'VARCHAR(350)'),
                ('formazione_en', 'VARCHAR(20)'),
                ('stato_di_conservazione_en', 'VARCHAR(20)'),
                ('colore_en', 'VARCHAR(20)'),
                ('consistenza_en', 'VARCHAR(20)'),
                ('struttura_en', 'VARCHAR(30)')
            ]
            
            for column_name, column_type in us_text_columns + us_varchar_columns:
                if self.add_column_if_not_exists('us_table', column_name, column_type):
                    migrations_applied += 1
            
            # Inventario materiali table i18n columns
            inv_text_columns = [
                ('tipo_reperto_en', 'TEXT'),
                ('criterio_schedatura_en', 'TEXT'),
                ('definizione_en', 'TEXT'),
                ('descrizione_en', 'TEXT'),
                ('elementi_reperto_en', 'TEXT')
            ]
            
            inv_varchar_columns = [
                ('stato_conservazione_en', 'VARCHAR(200)'),
                ('corpo_ceramico_en', 'VARCHAR(200)'),
                ('rivestimento_en', 'VARCHAR(200)'),
                ('tipo_contenitore_en', 'VARCHAR(200)')
            ]
            
            for column_name, column_type in inv_text_columns + inv_varchar_columns:
                if self.add_column_if_not_exists('inventario_materiali_table', column_name, column_type):
                    migrations_applied += 1
            
            logger.info(f"i18n migration completed. {migrations_applied} new columns added")
            return migrations_applied
            
        except Exception as e:
            logger.error(f"Error during i18n migration: {e}")
            raise
    
    def migrate_tipo_documento(self):
        """Add tipo_documento and file_path columns to US table"""
        try:
            logger.info("Starting tipo_documento migration...")

            migrations_applied = 0

            # Add tipo_documento column
            if self.add_column_if_not_exists('us_table', 'tipo_documento', 'VARCHAR(100)'):
                migrations_applied += 1

            # Add file_path column (for document files)
            if self.add_column_if_not_exists('us_table', 'file_path', 'TEXT'):
                migrations_applied += 1

            logger.info(f"tipo_documento migration completed. {migrations_applied} new columns added")
            return migrations_applied

        except Exception as e:
            logger.error(f"Error during tipo_documento migration: {e}")
            raise

    def migrate_concurrency_columns(self):
        """Add concurrency tracking columns to all main tables."""
        import uuid as uuid_mod
        try:
            logger.info("Starting concurrency columns migration...")
            migrations_applied = 0

            tables = [
                'site_table', 'us_table', 'us_relationships_table',
                'harris_matrix_table', 'period_table', 'datazioni_table',
                'extended_matrix_table',
                'inventario_materiali_table',
                'periodizzazione_table', 'media_table', 'media_thumb_table',
                'documentation_table',
                'pyarchinit_thesaurus_sigle', 'thesaurus_field', 'thesaurus_category',
                'users',
            ]

            concurrency_columns = [
                ('entity_uuid', 'VARCHAR(36)'),
                ('version_number', 'INTEGER', '1'),
                ('last_modified_by', 'VARCHAR(100)'),
                ('last_modified_timestamp', 'TIMESTAMP'),
                ('sync_status', 'VARCHAR(20)', "'new'"),
                ('editing_by', 'VARCHAR(100)'),
                ('editing_since', 'TIMESTAMP'),
            ]

            for table in tables:
                for col_def in concurrency_columns:
                    col_name = col_def[0]
                    col_type = col_def[1]
                    default = col_def[2] if len(col_def) > 2 else None
                    if self.add_column_if_not_exists(table, col_name, col_type, default):
                        migrations_applied += 1

            # Back-fill entity_uuid for existing rows that have NULL
            for table in tables:
                try:
                    with self.connection.get_session() as session:
                        rows = session.execute(
                            text(f"SELECT rowid FROM {table} WHERE entity_uuid IS NULL")
                        ).fetchall()
                        for row in rows:
                            new_uuid = str(uuid_mod.uuid4())
                            session.execute(
                                text(f"UPDATE {table} SET entity_uuid = :uuid WHERE rowid = :rid"),
                                {"uuid": new_uuid, "rid": row[0]}
                            )
                        session.commit()
                except Exception as e:
                    logger.warning(f"UUID backfill for {table}: {e}")

            logger.info(f"Concurrency migration done. {migrations_applied} columns added")
            return migrations_applied
        except Exception as e:
            logger.error(f"Error during concurrency migration: {e}")
            raise

    def migrate_inventario_extra_columns(self):
        """Add missing columns to inventario_materiali_table."""
        try:
            logger.info("Starting inventario extra columns migration...")
            migrations_applied = 0
            extra = [
                ('quota_usm', 'NUMERIC(10,3)'),
                ('unita_misura_quota', 'VARCHAR(20)'),
                ('photo_id', 'TEXT'),
                ('drawing_id', 'TEXT'),
            ]
            for col_name, col_type in extra:
                if self.add_column_if_not_exists('inventario_materiali_table', col_name, col_type):
                    migrations_applied += 1
            return migrations_applied
        except Exception as e:
            logger.error(f"Error during inventario extra migration: {e}")
            raise

    def migrate_us_extra_columns(self):
        """Add all missing pyarchinit US columns to us_table."""
        try:
            logger.info("Starting US extra columns migration...")
            migrations_applied = 0
            columns = [
                ('elem_datanti', 'TEXT'), ('funz_statica', 'TEXT'),
                ('lavorazione', 'TEXT'), ('spess_giunti', 'TEXT'),
                ('letti_posa', 'TEXT'), ('alt_mod', 'TEXT'),
                ('un_ed_riass', 'TEXT'), ('reimp', 'TEXT'),
                ('posa_opera', 'TEXT'),
                ('quota_min_usm', 'NUMERIC(6,2)'), ('quota_max_usm', 'NUMERIC(6,2)'),
                ('cons_legante', 'TEXT'), ('col_legante', 'TEXT'),
                ('aggreg_legante', 'TEXT'), ('con_text_mat', 'TEXT'),
                ('col_materiale', 'TEXT'), ('inclusi_materiali_usm', 'TEXT'),
                ('ref_tm', 'TEXT'), ('ref_ra', 'TEXT'), ('ref_n', 'TEXT'),
                ('posizione', 'TEXT'), ('criteri_distinzione', 'TEXT'),
                ('modo_formazione', 'TEXT'),
                ('componenti_organici', 'TEXT'), ('componenti_inorganici', 'TEXT'),
                ('quota_max_abs', 'NUMERIC(6,2)'), ('quota_max_rel', 'NUMERIC(6,2)'),
                ('quota_min_abs', 'NUMERIC(6,2)'), ('quota_min_rel', 'NUMERIC(6,2)'),
                ('cod_ente_schedatore', 'TEXT'),
                ('data_rilevazione', 'VARCHAR(20)'), ('data_rielaborazione', 'VARCHAR(20)'),
                ('lunghezza_usm', 'NUMERIC(6,2)'), ('altezza_usm', 'NUMERIC(6,2)'),
                ('spessore_usm', 'NUMERIC(6,2)'),
                ('tecnica_muraria_usm', 'TEXT'), ('modulo_usm', 'TEXT'),
                ('campioni_malta_usm', 'TEXT'), ('campioni_mattone_usm', 'TEXT'),
                ('campioni_pietra_usm', 'TEXT'),
                ('provenienza_materiali_usm', 'TEXT'),
                ('criteri_distinzione_usm', 'TEXT'), ('uso_primario_usm', 'TEXT'),
                ('tipologia_opera', 'TEXT'), ('sezione_muraria', 'TEXT'),
                ('superficie_analizzata', 'TEXT'), ('orientamento', 'TEXT'),
                ('materiali_lat', 'TEXT'), ('lavorazione_lat', 'TEXT'),
                ('consistenza_lat', 'TEXT'), ('forma_lat', 'TEXT'),
                ('colore_lat', 'TEXT'), ('impasto_lat', 'TEXT'),
                ('forma_p', 'TEXT'), ('colore_p', 'TEXT'),
                ('taglio_p', 'TEXT'), ('posa_opera_p', 'TEXT'),
                ('inerti_usm', 'TEXT'), ('tipo_legante_usm', 'TEXT'),
                ('rifinitura_usm', 'TEXT'),
                ('materiale_p', 'TEXT'), ('consistenza_p', 'TEXT'),
                ('rapporti2', 'TEXT'), ('doc_usv', 'TEXT'),
            ]
            for col_name, col_type in columns:
                if self.add_column_if_not_exists('us_table', col_name, col_type):
                    migrations_applied += 1
            return migrations_applied
        except Exception as e:
            logger.error(f"Error during US extra migration: {e}")
            raise

    def migrate_all_tables(self):
        """Run all necessary migrations"""
        try:
            logger.info("Starting database migrations...")

            total_migrations = 0

            # Migrate inventario_materiali_table
            total_migrations += self.migrate_inventario_materiali_table()

            # Add i18n columns
            total_migrations += self.migrate_i18n_columns()

            # Add tipo_documento and file_path columns to US table
            total_migrations += self.migrate_tipo_documento()

            # Add other table migrations here as needed

            # Add concurrency columns to all tables
            total_migrations += self.migrate_concurrency_columns()

            # Add missing inventario columns
            total_migrations += self.migrate_inventario_extra_columns()

            # Add missing US columns
            total_migrations += self.migrate_us_extra_columns()

            logger.info(f"All migrations completed. Total migrations applied: {total_migrations}")
            return total_migrations

        except Exception as e:
            logger.error(f"Error during database migrations: {e}")
            raise
    
    def get_table_info(self, table_name: str) -> Dict[str, Any]:
        """Get information about a table structure"""
        try:
            inspector = inspect(self.connection.engine)
            
            # Check if table exists
            if not inspector.has_table(table_name):
                return {'exists': False}
            
            # Get columns info
            columns = inspector.get_columns(table_name)
            column_names = [col['name'] for col in columns]
            
            return {
                'exists': True,
                'columns': columns,
                'column_names': column_names,
                'column_count': len(columns)
            }
            
        except Exception as e:
            logger.error(f"Error getting table info for {table_name}: {e}")
            return {'exists': False, 'error': str(e)}
    
    def check_migration_needed(self, table_name: str, required_columns: List[str]) -> List[str]:
        """Check which columns are missing from a table"""
        try:
            table_info = self.get_table_info(table_name)
            
            if not table_info['exists']:
                return required_columns  # All columns are missing if table doesn't exist
            
            existing_columns = table_info['column_names']
            missing_columns = [col for col in required_columns if col not in existing_columns]
            
            return missing_columns
            
        except Exception as e:
            logger.error(f"Error checking migration for {table_name}: {e}")
            return required_columns