"""Port management tools: list, open, close serial ports."""

from __future__ import annotations

from collections import deque
from typing import Literal

import serial
import serial.tools.list_ports

from mcserial._helpers import (
    _detect_baud_rate_internal,
    _validate_port_path,
)
from mcserial._state import (
    DEFAULT_BAUDRATE,
    DEFAULT_TIMEOUT,
    MAX_CONNECTIONS,
    SerialConnection,
    _connections,
    _log,
    mcp,
)


@mcp.tool()
def list_serial_ports(usb_only: bool = True, grep: str | None = None) -> list[dict] | dict:
    """List available serial ports on the system.

    Args:
        usb_only: If True (default), only show USB serial devices.
                  Set False to include legacy/phantom ttyS ports.
        grep: Optional regex pattern to filter ports. Matches against device path,
              description, hardware ID, manufacturer, product, and serial number.
              Examples: "FTDI", "ttyUSB", "VID:PID=0403:6001", "CP210"

    Returns a list of ports with their device path, description, and hardware ID.
    Call this first to discover what ports are available before opening one.
    """
    import re

    # Compile grep pattern if provided
    try:
        pattern = re.compile(grep, re.IGNORECASE) if grep else None
    except re.error as e:
        return {"error": f"Invalid grep pattern: {e}", "success": False}

    ports = []
    for port in serial.tools.list_ports.comports():
        # Filter out phantom/legacy ports if usb_only is True
        if usb_only and port.hwid == "n/a":
            continue

        # Apply grep filter across all fields
        if pattern:
            searchable = " ".join(str(v) for v in [
                port.device, port.description, port.hwid,
                port.manufacturer, port.product, port.serial_number,
            ] if v)
            if not pattern.search(searchable):
                continue

        ports.append({
            "device": port.device,
            "description": port.description,
            "hwid": port.hwid,
            "manufacturer": port.manufacturer,
            "product": port.product,
            "serial_number": port.serial_number,
            "is_open": port.device in _connections,
        })
    # Sort USB ports first (ttyUSB, ttyACM), then others
    ports.sort(key=lambda p: (0 if "USB" in p["device"] or "ACM" in p["device"] else 1, p["device"]))
    return ports


@mcp.tool()
def open_serial_port(
    port: str,
    baudrate: int | None = None,
    bytesize: Literal[5, 6, 7, 8] = 8,
    parity: Literal["N", "E", "O", "M", "S"] = "N",
    stopbits: Literal[1, 1.5, 2] = 1,
    timeout: float = DEFAULT_TIMEOUT,
    write_timeout: float | None = None,
    inter_byte_timeout: float | None = None,
    xonxoff: bool = False,
    rtscts: bool = False,
    dsrdtr: bool = False,
    exclusive: bool = False,
    autobaud_probe: str | None = None,
    autobaud_timeout: float = 0.3,
    mode: Literal["rs232", "rs485", "rs422"] = "rs232",
) -> dict:
    """Open a serial port connection with optional auto-baud detection.

    If baudrate is not specified (None), automatically detects the baud rate
    by analyzing incoming data patterns. Works best when the device is actively
    sending data or responds to a probe string.

    Args:
        port: Device path (e.g., '/dev/ttyUSB0', 'COM3') or URL scheme:
              - socket://host:port (raw TCP socket)
              - rfc2217://host:port (Telnet COM Port Control)
              - loop:// (loopback for testing)
              - spy://device (debug wrapper, logs traffic)
              - cp2110:// (Silicon Labs HID-to-UART, requires `hidapi`)
        baudrate: Baud rate. If None, auto-detect (recommended for unknown devices)
        bytesize: Data bits (5, 6, 7, or 8)
        parity: Parity checking (N=None, E=Even, O=Odd, M=Mark, S=Space)
        stopbits: Stop bits (1, 1.5, or 2)
        timeout: Read timeout in seconds
        write_timeout: Write timeout in seconds (None = blocking)
        inter_byte_timeout: Timeout between bytes during read (None = disabled)
        xonxoff: Enable software flow control (XON/XOFF)
        rtscts: Enable hardware RTS/CTS flow control
        dsrdtr: Enable hardware DSR/DTR flow control
        exclusive: Request exclusive access (lock port from other processes)
        autobaud_probe: String to send during auto-detection (e.g., "UUUUU" for sync)
        autobaud_timeout: Timeout per rate during auto-detection (default 0.3s)
        mode: Serial mode to open in. "rs232" (default) for point-to-point with modem
              control lines, "rs422" for full-duplex differential, "rs485" for half-duplex bus.

    Returns:
        Connection status and details (includes auto-detection info if used)
    """
    if port in _connections:
        return {"error": f"Port {port} is already open", "success": False}

    if len(_connections) >= MAX_CONNECTIONS:
        return {"error": f"Maximum connections ({MAX_CONNECTIONS}) reached", "success": False}

    # Validate port path before any I/O
    if path_error := _validate_port_path(port):
        return path_error

    # Detect URL scheme vs local device path
    is_url = "://" in port
    _SUPPORTED_SCHEMES = ("socket", "rfc2217", "loop", "spy", "cp2110", "alt", "hwgrep")

    if is_url:
        scheme = port.split("://", 1)[0].lower()
        if scheme not in _SUPPORTED_SCHEMES:
            return {"error": f"Unsupported URL scheme: {scheme}://", "success": False}

        if scheme == "cp2110":
            try:
                import hid  # noqa: F401
            except ImportError:
                return {
                    "error": "cp2110:// requires the hidapi package. "
                    "Install with: pip install mcserial[cp2110]",
                    "success": False,
                }

    # Auto-detect baud rate if not specified (only for local devices)
    detected_info = None
    if baudrate is None and not is_url:
        detection_result = _detect_baud_rate_internal(
            port=port,
            probe=autobaud_probe,
            timeout_per_rate=autobaud_timeout,
        )
        if detection_result.get("detected_baudrate"):
            baudrate = detection_result["detected_baudrate"]
            detected_info = {
                "auto_detected": True,
                "detection_confidence": detection_result.get("confidence", 0),
                "detection_candidates": [
                    {"baudrate": r["baudrate"], "score": r["score"]}
                    for r in detection_result.get("results", [])[:3]
                ],
            }
        else:
            baudrate = DEFAULT_BAUDRATE
            detected_info = {
                "auto_detected": False,
                "fallback_reason": "No data received or low confidence",
                "using_default": DEFAULT_BAUDRATE,
            }
    elif baudrate is None:
        baudrate = DEFAULT_BAUDRATE

    try:
        if is_url:
            conn = serial.serial_for_url(
                port,
                baudrate=baudrate,
                bytesize=bytesize,
                parity=parity,
                stopbits=stopbits,
                timeout=timeout,
                write_timeout=write_timeout,
                xonxoff=xonxoff,
                rtscts=rtscts,
                dsrdtr=dsrdtr,
            )
        else:
            conn = serial.Serial(
                port=port,
                baudrate=baudrate,
                bytesize=bytesize,
                parity=parity,
                stopbits=stopbits,
                timeout=timeout,
                write_timeout=write_timeout,
                inter_byte_timeout=inter_byte_timeout,
                xonxoff=xonxoff,
                rtscts=rtscts,
                dsrdtr=dsrdtr,
                exclusive=exclusive,
            )
        # Create the connection object with requested mode
        sc = SerialConnection(port=port, connection=conn, mode=mode)

        # Auto-enable traffic logging for spy:// URLs
        if is_url and port.split("://", 1)[0].lower() == "spy":
            sc.traffic_log = deque(maxlen=1000)
            _log("INFO", "server", f"spy:// detected, auto-enabled traffic logging for {port}")

        _connections[port] = sc
        _log("INFO", "server", f"Opened {port} at {baudrate} baud (mode={mode})")

        _mode_hints = {
            "rs232": "Use set_port_mode() to switch to RS-422 or RS-485 mode if needed.",
            "rs422": "RS-422 full-duplex differential mode. Common tools (transact, read, write) are available. No modem or direction control tools.",
            "rs485": "RS-485 half-duplex bus mode. Use rs485_transact for bus transactions.",
        }

        result = {
            "success": True,
            "port": port,
            "mode": mode,
            "baudrate": baudrate,
            "bytesize": bytesize,
            "parity": parity,
            "stopbits": stopbits,
            "xonxoff": xonxoff,
            "rtscts": rtscts,
            "dsrdtr": dsrdtr,
            "resource_uri": f"serial://{port}/data",
        }
        if is_url:
            result["url_scheme"] = port.split("://", 1)[0].lower()
            result["hint"] = "Opened via URL handler. Some features (exclusive, auto-baud) are not available."
            if sc.traffic_log is not None:
                result["traffic_log_enabled"] = True
                result["traffic_log_resource"] = f"serial://{port}/log"
        else:
            result["exclusive"] = exclusive
            result["mode_hint"] = _mode_hints[mode]
        if detected_info:
            result["autobaud"] = detected_info
        return result
    except serial.SerialException as e:
        _log("ERROR", "server", f"Failed to open {port}: {e}")
        return {"error": str(e), "success": False}
    except OSError as e:
        _log("ERROR", "server", f"Connection error for {port}: {e}")
        return {"error": f"Connection error: {e}", "success": False}


@mcp.tool()
def close_serial_port(port: str) -> dict:
    """Close an open serial port connection.

    Args:
        port: Device path of the port to close

    Returns:
        Status of the close operation
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    close_error = None
    try:
        _connections[port].connection.close()
    except serial.SerialException as e:
        close_error = str(e)
        _log("WARNING", "server", f"Error closing {port}: {e}")
    finally:
        del _connections[port]
        _log("INFO", "server", f"Closed {port}")

    result = {"success": True, "port": port, "message": "Port closed"}
    if close_error:
        result["warning"] = f"Port removed but close reported: {close_error}"
    return result
