"""Read/write tools for serial port data."""

from __future__ import annotations

import time

import serial

from mcserial._state import (
    TrafficEntry,
    _connections,
    _log,
    mcp,
)


@mcp.tool()
def write_serial(port: str, data: str, encoding: str = "utf-8") -> dict:
    """Write data to an open serial port.

    Args:
        port: Device path of the port to write to
        data: String data to send
        encoding: Character encoding (default: utf-8)

    Returns:
        Number of bytes written
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        sc = _connections[port]
        # Auto-append default line ending if configured
        send_data = data
        if sc.default_line_ending:
            send_data = data + sc.default_line_ending
        try:
            encoded = send_data.encode(encoding)
        except (UnicodeEncodeError, LookupError) as e:
            return {"error": f"Encoding error: {e}", "success": False}
        bytes_written = sc.connection.write(encoded)
        sc.connection.flush()

        # Traffic capture
        if sc.traffic_log is not None:
            sc.traffic_log.append(TrafficEntry(
                timestamp=time.time(),
                direction="tx",
                data=encoded,
                encoding_used=encoding,
            ))
        _log("DEBUG", port, f"TX {bytes_written} bytes")

        return {"success": True, "bytes_written": bytes_written, "port": port}
    except serial.SerialException as e:
        _log("ERROR", port, f"Write error: {e}")
        return {"error": str(e), "success": False}


@mcp.tool()
def write_serial_bytes(port: str, data: list[int]) -> dict:
    """Write raw bytes to an open serial port.

    Args:
        port: Device path of the port to write to
        data: List of byte values (0-255)

    Returns:
        Number of bytes written
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    # Validate byte range before conversion - bytes() silently truncates values > 255
    invalid_values = [b for b in data if not (0 <= b <= 255)]
    if invalid_values:
        return {
            "error": f"Byte values must be 0-255, got invalid values: {invalid_values[:5]}{'...' if len(invalid_values) > 5 else ''}",
            "success": False,
        }

    try:
        sc = _connections[port]
        raw_bytes = bytes(data)
        bytes_written = sc.connection.write(raw_bytes)
        sc.connection.flush()

        # Traffic capture
        if sc.traffic_log is not None:
            sc.traffic_log.append(TrafficEntry(
                timestamp=time.time(),
                direction="tx",
                data=raw_bytes,
                encoding_used=None,
            ))
        _log("DEBUG", port, f"TX {bytes_written} bytes (raw)")

        return {"success": True, "bytes_written": bytes_written, "port": port}
    except (serial.SerialException, ValueError) as e:
        _log("ERROR", port, f"Write bytes error: {e}")
        return {"error": str(e), "success": False}


@mcp.tool()
def read_serial(
    port: str,
    size: int | None = None,
    encoding: str = "utf-8",
    timeout: float | None = None,
) -> dict:
    """Read data from an open serial port.

    Args:
        port: Device path of the port to read from
        size: Maximum bytes to read (None = read all available)
        encoding: Character encoding for decoding (default: utf-8)
        timeout: Override timeout for this read (None = use port default)

    Returns:
        Data read from the port
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        sc = _connections[port]
        conn = sc.connection

        # Temporarily override timeout if specified
        original_timeout = conn.timeout
        if timeout is not None:
            conn.timeout = timeout

        try:
            raw = conn.read(size) if size is not None else conn.read(conn.in_waiting or 1)
        finally:
            if timeout is not None:
                conn.timeout = original_timeout

        # Traffic capture
        if raw and sc.traffic_log is not None:
            sc.traffic_log.append(TrafficEntry(
                timestamp=time.time(),
                direction="rx",
                data=raw,
                encoding_used=encoding,
            ))
        if raw:
            _log("DEBUG", port, f"RX {len(raw)} bytes")

        return {
            "success": True,
            "data": raw.decode(encoding, errors="replace"),
            "bytes_read": len(raw),
            "raw_hex": raw.hex(),
            "port": port,
        }
    except serial.SerialException as e:
        _log("ERROR", port, f"Read error: {e}")
        return {"error": str(e), "success": False}


@mcp.tool()
def read_serial_line(port: str, encoding: str = "utf-8") -> dict:
    """Read a single line (until newline) from an open serial port.

    Args:
        port: Device path of the port to read from
        encoding: Character encoding for decoding (default: utf-8)

    Returns:
        Line of data read from the port
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        sc = _connections[port]
        raw = sc.connection.readline()

        # Traffic capture
        if raw and sc.traffic_log is not None:
            sc.traffic_log.append(TrafficEntry(
                timestamp=time.time(),
                direction="rx",
                data=raw,
                encoding_used=encoding,
            ))
        if raw:
            _log("DEBUG", port, f"RX line {len(raw)} bytes")

        return {
            "success": True,
            "line": raw.decode(encoding, errors="replace").rstrip("\r\n"),
            "bytes_read": len(raw),
            "port": port,
        }
    except serial.SerialException as e:
        _log("ERROR", port, f"Read line error: {e}")
        return {"error": str(e), "success": False}


@mcp.tool()
def read_serial_lines(
    port: str,
    max_lines: int = 10,
    encoding: str = "utf-8",
) -> dict:
    """Read multiple lines from an open serial port.

    Reads up to max_lines, stopping early if no more data is available
    (readline returns empty due to timeout). Useful for draining buffered
    output or reading multi-line responses.

    Args:
        port: Device path of the port to read from
        max_lines: Maximum number of lines to read (default: 10)
        encoding: Character encoding for decoding (default: utf-8)

    Returns:
        List of lines read from the port
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    if max_lines < 1 or max_lines > 1000:
        return {"error": "max_lines must be 1-1000", "success": False}

    try:
        sc = _connections[port]
        lines = []
        total_bytes = 0

        for _ in range(max_lines):
            raw = sc.connection.readline()
            if not raw:
                break
            total_bytes += len(raw)
            lines.append(raw.decode(encoding, errors="replace").rstrip("\r\n"))

            # Traffic capture per line
            if sc.traffic_log is not None:
                sc.traffic_log.append(TrafficEntry(
                    timestamp=time.time(),
                    direction="rx",
                    data=raw,
                    encoding_used=encoding,
                ))

        if total_bytes:
            _log("DEBUG", port, f"RX {len(lines)} lines, {total_bytes} bytes")

        return {
            "success": True,
            "lines": lines,
            "count": len(lines),
            "bytes_read": total_bytes,
            "port": port,
        }
    except serial.SerialException as e:
        _log("ERROR", port, f"Read lines error: {e}")
        return {"error": str(e), "success": False}


@mcp.tool()
def read_until(
    port: str,
    terminator: str = "\n",
    size: int | None = None,
    encoding: str = "utf-8",
    timeout: float | None = None,
) -> dict:
    """Read data until a specific terminator sequence is received.

    More flexible than read_serial_line - supports any terminator, not just newline.

    Args:
        port: Device path of the port to read from
        terminator: Byte sequence to stop at (default: newline)
        size: Maximum bytes to read (None = no limit, use timeout)
        encoding: Character encoding for terminator and result
        timeout: Override timeout for this read (None = use port default)

    Returns:
        Data read up to and including the terminator
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        sc = _connections[port]
        conn = sc.connection
        term_bytes = terminator.encode(encoding)

        # Temporarily override timeout if specified
        original_timeout = conn.timeout
        if timeout is not None:
            conn.timeout = timeout

        # Enforce a safety limit to prevent memory exhaustion from unterminated streams
        effective_size = size if size is not None else 1024 * 1024  # 1MB safety cap

        try:
            raw = conn.read_until(term_bytes, effective_size)
        finally:
            if timeout is not None:
                conn.timeout = original_timeout

        # Traffic capture
        if raw and sc.traffic_log is not None:
            sc.traffic_log.append(TrafficEntry(
                timestamp=time.time(),
                direction="rx",
                data=raw,
                encoding_used=encoding,
            ))
        if raw:
            _log("DEBUG", port, f"RX {len(raw)} bytes (read_until)")

        return {
            "success": True,
            "data": raw.decode(encoding, errors="replace"),
            "bytes_read": len(raw),
            "raw_hex": raw.hex(),
            "port": port,
            "terminator_found": raw.endswith(term_bytes),
        }
    except serial.SerialException as e:
        _log("ERROR", port, f"read_until error: {e}")
        return {"error": str(e), "success": False}
