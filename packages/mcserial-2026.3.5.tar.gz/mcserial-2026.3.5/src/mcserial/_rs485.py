"""RS-485 and RS-422 mode tools: setup, detection, transact, scan."""

from __future__ import annotations

import serial

from mcserial._helpers import _read_response, _require_mode, _validate_port_path
from mcserial._state import (
    TrafficEntry,
    _connections,
    _log,
    mcp,
)


@mcp.tool()
def set_rs485_mode(
    port: str,
    enabled: bool = True,
    delay_before_tx: float = 0.0,
    delay_before_rx: float = 0.0,
    rts_level_for_tx: bool = True,
    rts_level_for_rx: bool = False,
    loopback: bool = False,
) -> dict:
    """Configure RS-485 hardware mode for half-duplex communication.

    **Requires RS-485 mode.** Use set_port_mode(port, "rs485") first.

    RS-485 is commonly used in industrial applications (Modbus, etc.)
    where multiple devices share a bus. The driver must control the
    TX enable line (typically RTS) to switch between transmit and receive.

    Args:
        port: Device path of the port
        enabled: Enable or disable RS-485 mode
        delay_before_tx: Delay in seconds before enabling TX
        delay_before_rx: Delay in seconds before enabling RX after TX
        rts_level_for_tx: RTS level when transmitting (True=high)
        rts_level_for_rx: RTS level when receiving (True=high)
        loopback: Enable RS-485 loopback mode

    Returns:
        RS-485 configuration status
    """
    if mode_error := _require_mode(port, "rs485"):
        return mode_error

    try:
        conn = _connections[port].connection

        if enabled:
            # Create RS485Settings
            rs485_settings = serial.rs485.RS485Settings(
                rts_level_for_tx=rts_level_for_tx,
                rts_level_for_rx=rts_level_for_rx,
                loopback=loopback,
                delay_before_tx=delay_before_tx,
                delay_before_rx=delay_before_rx,
            )
            conn.rs485_mode = rs485_settings
        else:
            conn.rs485_mode = None

        return {
            "success": True,
            "port": port,
            "rs485_enabled": enabled,
            "rts_level_for_tx": rts_level_for_tx if enabled else None,
            "rts_level_for_rx": rts_level_for_rx if enabled else None,
            "delay_before_tx": delay_before_tx if enabled else None,
            "delay_before_rx": delay_before_rx if enabled else None,
            "loopback": loopback if enabled else None,
        }
    except (serial.SerialException, AttributeError) as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def check_rs485_support(port: str) -> dict:
    """Check RS-485 hardware support for a serial port.

    Detects whether the port/driver supports hardware RS-485 mode
    (automatic DE/RE control) or requires software emulation.

    Args:
        port: Device path to check (doesn't need to be open)

    Returns:
        RS-485 capability information
    """
    if path_error := _validate_port_path(port):
        return path_error
    import subprocess

    result = {
        "port": port,
        "driver": None,
        "chip": None,
        "hardware_rs485": False,
        "software_fallback": True,
        "notes": [],
    }

    # Try to get USB device info
    try:
        # Get the device's parent USB info via udevadm
        udev_output = subprocess.run(
            ["udevadm", "info", "-a", "-n", port],
            capture_output=True,
            text=True,
            timeout=5,
        )
        udev_info = udev_output.stdout.lower()

        # Detect driver
        if "ftdi" in udev_info:
            result["driver"] = "ftdi_sio"
            result["hardware_rs485"] = True
            result["notes"].append("FTDI chips have hardware RS-485 auto-direction")
        elif "cp210x" in udev_info or "silabs" in udev_info:
            result["driver"] = "cp210x"
            # Only some CP210x models support RS-485
            if "cp2102" in udev_info:
                result["chip"] = "CP2102"
                result["hardware_rs485"] = False
                result["notes"].append("CP2102 lacks hardware RS-485; use software RTS control")
            elif "cp2105" in udev_info or "cp2108" in udev_info:
                result["chip"] = "CP2105/CP2108"
                result["hardware_rs485"] = True
                result["notes"].append("CP2105/CP2108 have hardware RS-485 support")
            else:
                result["notes"].append("CP210x detected; RS-485 support varies by model")
        elif "ch341" in udev_info or "ch340" in udev_info:
            result["driver"] = "ch341"
            result["hardware_rs485"] = False
            result["notes"].append("CH340/CH341 lacks hardware RS-485; timing may be unreliable")
        elif "pl2303" in udev_info:
            result["driver"] = "pl2303"
            result["hardware_rs485"] = False
            result["notes"].append("PL2303 lacks hardware RS-485; use software RTS control")
        elif "ttyS" in port or "ttyAMA" in port:
            result["driver"] = "native"
            result["hardware_rs485"] = True
            result["notes"].append("Native UART; check if RS-485 transceiver is connected")

        # Try to detect chip from product string
        for line in udev_output.stdout.split('\n'):
            if 'ATTRS{product}' in line:
                result["chip"] = line.split('==')[1].strip(' "') if '==' in line else None
                break

    except (subprocess.TimeoutExpired, FileNotFoundError):
        result["notes"].append("Could not query udev; install udevadm for better detection")

    # Test if kernel RS-485 ioctl works
    try:
        import fcntl

        # TIOCSRS485 = 0x542F, TIOCGRS485 = 0x542E
        TIOCGRS485 = 0x542E

        with open(port) as f:
            try:
                # Try to get current RS-485 settings
                fcntl.ioctl(f.fileno(), TIOCGRS485, b'\x00' * 32)
                result["kernel_rs485_ioctl"] = True
                result["notes"].append("Kernel TIOCSRS485 ioctl supported")
            except OSError:
                result["kernel_rs485_ioctl"] = False
                result["notes"].append("Kernel RS-485 ioctl not supported on this port")
    except Exception as e:
        result["kernel_rs485_ioctl"] = False
        result["notes"].append(f"Could not test ioctl: {e}")

    # Recommendation
    if result["hardware_rs485"]:
        result["recommendation"] = "Use set_rs485_mode() for automatic DE/RE control"
    else:
        result["recommendation"] = "Use manual RTS control via set_modem_lines() around writes"

    result["success"] = True
    return result


@mcp.tool()
def check_rs422_support(port: str) -> dict:
    """Check RS-422 hardware capabilities for a serial port.

    Detects adapter type and reports RS-422-relevant information:
    differential TX/RX pairs, maximum cable length, receiver count.

    RS-422 uses two differential pairs (TX+/TX- and RX+/RX-) for full-duplex
    communication over long distances with high noise immunity. The same USB
    adapters that support RS-485 often support RS-422 as well.

    The port does not need to be open. Use this to scout hardware capabilities
    before committing to a mode.

    Args:
        port: Device path to check (doesn't need to be open)

    Returns:
        RS-422 capability information including adapter type and notes
    """
    if path_error := _validate_port_path(port):
        return path_error
    import platform
    import subprocess

    result = {
        "port": port,
        "driver": None,
        "chip": None,
        "full_duplex": True,
        "dual_differential": True,
        "max_receivers": 10,
        "max_cable_length_m": 1200,
        "notes": [],
    }

    if platform.system() != "Linux":
        result["notes"].append(
            f"Running on {platform.system()}. Hardware detection via udevadm "
            f"is Linux-only. Adapter information is not available."
        )
        result["platform_limited"] = True
        result["recommendation"] = (
            "RS-422 works with all common tools (transact, read_serial, write_serial). "
            "No direction control needed — just read and write."
        )
        result["success"] = True
        return result

    # Detect adapter via udevadm
    try:
        udev_output = subprocess.run(
            ["udevadm", "info", "-a", "-n", port],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if udev_output.returncode != 0:
            result["notes"].append(
                f"udevadm returned error (code {udev_output.returncode}). "
                f"Port may not exist or may require elevated permissions."
            )
            result["recommendation"] = (
                "RS-422 works with all common tools (transact, read_serial, write_serial). "
                "No direction control needed — just read and write."
            )
            result["success"] = True
            return result

        udev_info = udev_output.stdout.lower()

        if "ftdi" in udev_info:
            result["driver"] = "ftdi_sio"
            if "ft2232" in udev_info or "ft4232" in udev_info:
                result["notes"].append(
                    "FTDI FT2232/FT4232 dual/quad-channel chip — "
                    "supports RS-422 via separate TX/RX differential pairs"
                )
            else:
                result["notes"].append(
                    "FTDI chip detected. Single-channel FTDI adapters support RS-422 "
                    "when paired with an external RS-422 transceiver (e.g., MAX490)"
                )
        elif "cp210x" in udev_info or "silabs" in udev_info:
            result["driver"] = "cp210x"
            if "cp2105" in udev_info:
                result["chip"] = "CP2105"
                result["notes"].append(
                    "CP2105 dual-channel — each channel can drive RS-422 "
                    "with appropriate transceiver wiring"
                )
            elif "cp2108" in udev_info:
                result["chip"] = "CP2108"
                result["notes"].append(
                    "CP2108 quad-channel — supports RS-422 with external transceiver"
                )
            else:
                result["notes"].append(
                    "CP210x detected. RS-422 requires external differential transceiver"
                )
        elif "ch341" in udev_info or "ch340" in udev_info:
            result["driver"] = "ch341"
            result["notes"].append(
                "CH340/CH341 — RS-422 requires external transceiver. "
                "Timing may be less precise than FTDI for high-speed RS-422"
            )
        elif "pl2303" in udev_info:
            result["driver"] = "pl2303"
            result["notes"].append(
                "PL2303 — RS-422 requires external transceiver. "
                "Adequate for standard RS-422 speeds"
            )
        elif "ttyS" in port or "ttyAMA" in port:
            result["driver"] = "native"
            result["notes"].append(
                "Native UART — verify that an RS-422 transceiver "
                "(e.g., MAX490, SN75179) is connected to TX/RX lines"
            )

        # Extract chip/product string
        for line in udev_output.stdout.split('\n'):
            if 'ATTRS{product}' in line and result["chip"] is None:
                result["chip"] = line.split('==')[1].strip(' "') if '==' in line else None
                break

    except (subprocess.TimeoutExpired, FileNotFoundError):
        result["notes"].append("Could not query udev; install udevadm for better detection")

    if not result["notes"]:
        result["notes"].append(
            "RS-422 uses the same physical interface as RS-485 but with "
            "separate differential pairs for TX and RX (full-duplex)"
        )

    result["recommendation"] = (
        "RS-422 works with all common tools (transact, read_serial, write_serial). "
        "No direction control needed — just read and write."
    )
    result["success"] = True
    return result


@mcp.tool()
def rs485_transact(
    port: str,
    data: str,
    response_timeout: float = 1.0,
    response_terminator: str | None = None,
    response_length: int | None = None,
    encoding: str = "utf-8",
    turnaround_delay: float = 0.005,
) -> dict:
    """Send data and receive response on RS-485 bus (half-duplex transaction).

    **Requires RS-485 mode.** Use set_port_mode(port, "rs485") first.

    Handles the TX->RX turnaround timing automatically. For devices without
    hardware RS-485 support, manually controls RTS around the transaction.

    Useful for request/response protocols like Modbus RTU. For mode-agnostic
    write+read without RTS control, see transact().

    Args:
        port: Device path (must be open, preferably with RS-485 mode set)
        data: Data to send
        response_timeout: Max time to wait for response (seconds)
        response_terminator: Stop reading when this sequence is received
        response_length: Expected response length in bytes (alternative to terminator)
        encoding: Character encoding for data
        turnaround_delay: Delay after TX before reading (seconds)

    Returns:
        Transaction result with sent/received data
    """
    import time

    if mode_error := _require_mode(port, "rs485"):
        return mode_error

    try:
        sc = _connections[port]
        conn = sc.connection
        has_hw_rs485 = conn.rs485_mode is not None

        # Clear any pending data
        conn.reset_input_buffer()

        # TX phase — RTS must be released even on exception to avoid bus lockup
        try:
            if not has_hw_rs485:
                conn.rts = True  # Enable driver (TX mode)
                time.sleep(0.001)  # Small settling time

            # Send data
            try:
                encoded = data.encode(encoding)
            except (UnicodeEncodeError, LookupError) as e:
                return {"error": f"Encoding error: {e}", "success": False}
            bytes_written = conn.write(encoded)
            conn.flush()

            # Traffic capture TX
            if sc.traffic_log is not None:
                sc.traffic_log.append(TrafficEntry(
                    timestamp=time.time(),
                    direction="tx",
                    data=encoded,
                    encoding_used=encoding,
                ))
            _log("DEBUG", port, f"TX {bytes_written} bytes (rs485_transact)")

            # Wait for transmission to complete
            # At slowest common rate (9600), 1 byte = ~1ms
            tx_time = (bytes_written * 10) / conn.baudrate  # 10 bits per byte typical
            time.sleep(tx_time + turnaround_delay)
        finally:
            # Always release RTS to prevent bus lockup
            if not has_hw_rs485:
                try:
                    conn.rts = False  # Disable driver (RX mode)
                    time.sleep(0.001)
                except serial.SerialException:
                    _log("ERROR", port, "Failed to release RTS — bus may be stuck in TX mode")

        # Read response
        original_timeout = conn.timeout
        conn.timeout = response_timeout

        try:
            raw_response = _read_response(
                conn, response_timeout, response_terminator, response_length, encoding,
            )
        finally:
            conn.timeout = original_timeout

        # Traffic capture RX
        if raw_response and sc.traffic_log is not None:
            sc.traffic_log.append(TrafficEntry(
                timestamp=time.time(),
                direction="rx",
                data=raw_response,
                encoding_used=encoding,
            ))
        if raw_response:
            _log("DEBUG", port, f"RX {len(raw_response)} bytes (rs485_transact)")

        return {
            "success": True,
            "port": port,
            "bytes_sent": bytes_written,
            "data_sent": data,
            "response": raw_response.decode(encoding, errors="replace"),
            "response_bytes": len(raw_response),
            "response_hex": raw_response.hex(),
            "hardware_rs485": has_hw_rs485,
        }

    except serial.SerialException as e:
        _log("ERROR", port, f"rs485_transact error: {e}")
        return {"error": str(e), "success": False}


@mcp.tool()
def rs485_scan_addresses(
    port: str,
    start_address: int = 1,
    end_address: int = 247,
    probe_template: str = "{addr:02x}03000001",
    response_timeout: float = 0.1,
    encoding: str = "latin-1",
) -> dict:
    """Scan RS-485 bus for responding devices (address discovery).

    **Requires RS-485 mode.** Use set_port_mode(port, "rs485") first.

    Sends a probe message to each address and records which ones respond.
    Useful for discovering Modbus or similar addressed devices on the bus.

    Args:
        port: Device path (must be open with RS-485 mode)
        start_address: First address to scan (default 1)
        end_address: Last address to scan (default 247, Modbus max)
        probe_template: Message template with {addr} placeholder. Default is
                        a Modbus "read holding register" frame (customize for your protocol)
        response_timeout: Time to wait for response per address (seconds)
        encoding: Encoding for probe (use 'latin-1' for raw bytes)

    Returns:
        List of responding addresses
    """
    import time

    if mode_error := _require_mode(port, "rs485"):
        return mode_error

    try:
        conn = _connections[port].connection
        has_hw_rs485 = conn.rs485_mode is not None

        responding = []
        scanned = 0

        for addr in range(start_address, end_address + 1):
            # Format probe with address
            try:
                if "{addr" in probe_template:
                    probe = probe_template.format(addr=addr)
                else:
                    probe = chr(addr) + probe_template
            except (ValueError, KeyError):
                probe = chr(addr) + probe_template

            # Clear buffers
            conn.reset_input_buffer()

            # TX — RTS must be released even on exception
            try:
                if not has_hw_rs485:
                    conn.rts = True
                    time.sleep(0.001)

                conn.write(probe.encode(encoding))
                conn.flush()

                tx_time = (len(probe) * 10) / conn.baudrate
                time.sleep(tx_time + 0.002)
            finally:
                if not has_hw_rs485:
                    try:
                        conn.rts = False
                        time.sleep(0.001)
                    except serial.SerialException:
                        _log("ERROR", port, f"Failed to release RTS during scan at addr {addr}")

            # Wait for response
            time.sleep(response_timeout)

            if conn.in_waiting > 0:
                response = conn.read(conn.in_waiting)
                responding.append({
                    "address": addr,
                    "response_length": len(response),
                    "response_hex": response.hex()[:32],  # First 16 bytes
                })

            scanned += 1

        return {
            "success": True,
            "port": port,
            "addresses_scanned": scanned,
            "devices_found": len(responding),
            "responding_addresses": responding,
            "hardware_rs485": has_hw_rs485,
        }

    except serial.SerialException as e:
        return {"error": str(e), "success": False}
