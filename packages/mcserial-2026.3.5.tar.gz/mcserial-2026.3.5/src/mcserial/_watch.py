"""USB device watch tools: detect hot-plugged serial devices and capture boot data."""

import re
import time
from collections import deque
from contextlib import suppress
from threading import Event, Lock
from typing import Literal

import serial
import serial.tools.list_ports

from mcserial._state import (
    DEFAULT_TIMEOUT,
    MAX_CONNECTIONS,
    SerialConnection,
    TrafficEntry,
    _connections,
    _log,
    mcp,
)

# ============================================================================
# MODULE-LEVEL STATE
# ============================================================================

_watch_lock = Lock()
_active_watches: dict[str, Event] = {}
_watch_counter: int = 0

# Cap boot_data accumulation to prevent memory bloat at high baud rates
_MAX_BOOT_CAPTURE_BYTES = 262144  # 256 KB


# ============================================================================
# INTERNAL HELPERS
# ============================================================================


def _next_watch_id() -> str:
    """Generate a sequential watch ID. Thread-safe."""
    global _watch_counter
    with _watch_lock:
        _watch_counter += 1
        return f"watch-{_watch_counter}"


def _snapshot_ports() -> dict[str, "serial.tools.list_ports_common.ListPortInfo"]:
    """Return a dict of USB-only ports keyed by device path.

    Filters on hwid != "n/a" which excludes phantom/legacy ttyS ports on Linux.
    """
    return {
        p.device: p
        for p in serial.tools.list_ports.comports()
        if p.hwid != "n/a"
    }


def _match_device(
    port_info: "serial.tools.list_ports_common.ListPortInfo",
    grep_pattern: "re.Pattern | None",
    vid: int | None,
    pid: int | None,
    serial_number: str | None,
) -> bool:
    """Check if a port_info matches ALL specified filters."""
    if grep_pattern:
        searchable = " ".join(
            str(v)
            for v in [
                port_info.device,
                port_info.description,
                port_info.hwid,
                port_info.manufacturer,
                port_info.product,
                port_info.serial_number,
            ]
            if v
        )
        if not grep_pattern.search(searchable):
            return False

    if vid is not None and port_info.vid != vid:
        return False

    if pid is not None and port_info.pid != pid:
        return False

    return not (serial_number is not None and port_info.serial_number != serial_number)


def _find_matching_port(
    ports: dict[str, "serial.tools.list_ports_common.ListPortInfo"],
    grep_pattern: "re.Pattern | None",
    vid: int | None,
    pid: int | None,
    serial_number: str | None,
) -> "serial.tools.list_ports_common.ListPortInfo | None":
    """Find the first matching port in a snapshot."""
    for port_info in ports.values():
        if _match_device(port_info, grep_pattern, vid, pid, serial_number):
            return port_info
    return None


def _try_udev_watch(
    grep_pattern: "re.Pattern | None",
    vid: int | None,
    pid: int | None,
    serial_number: str | None,
    deadline: float,
    poll_interval: float,
    cancel_event: Event,
) -> "serial.tools.list_ports_common.ListPortInfo | None":
    """Watch for a device using pyudev (Linux-only). Returns matching port_info or None."""
    try:
        import pyudev
    except ImportError:
        return None

    context = pyudev.Context()
    monitor = pyudev.Monitor.from_netlink(context)
    monitor.filter_by(subsystem="tty")
    monitor.start()

    try:
        while time.monotonic() < deadline:
            if cancel_event.is_set():
                return None

            device = monitor.poll(timeout=poll_interval)
            if device is None:
                continue

            if device.action != "add":
                continue

            # udev fired — re-query comports to get full ListPortInfo for the new device
            time.sleep(0.05)  # brief settle for kernel to finish setup
            ports = _snapshot_ports()
            device_node = device.device_node
            if device_node and device_node in ports:
                port_info = ports[device_node]
                if _match_device(port_info, grep_pattern, vid, pid, serial_number):
                    return port_info

            # Device appeared but didn't match our filters — keep watching
            # Also check all ports in case the device_node differs from comports path
            match = _find_matching_port(ports, grep_pattern, vid, pid, serial_number)
            if match:
                return match

        return None
    finally:
        # Clean up the monitor's netlink socket fd
        try:
            import os
            fd = monitor.fileno()
            if fd >= 0:
                os.close(fd)
        except Exception:
            pass


def _poll_watch(
    grep_pattern: "re.Pattern | None",
    vid: int | None,
    pid: int | None,
    serial_number: str | None,
    baseline: set[str],
    deadline: float,
    poll_interval: float,
    cancel_event: Event,
) -> "serial.tools.list_ports_common.ListPortInfo | None":
    """Watch for a device by polling comports(). Cross-platform fallback."""
    while time.monotonic() < deadline:
        if cancel_event.is_set():
            return None

        time.sleep(poll_interval)
        current = _snapshot_ports()
        new_devices = set(current.keys()) - baseline

        # Check new devices first (most likely candidates)
        for dev in new_devices:
            if _match_device(current[dev], grep_pattern, vid, pid, serial_number):
                return current[dev]

        # Also check all ports — device may have replaced an existing path
        match = _find_matching_port(current, grep_pattern, vid, pid, serial_number)
        if match and match.device not in baseline:
            return match

        # Update baseline with new non-matching devices so we don't re-check them
        baseline.update(new_devices)

    return None


def _build_device_info(port_info: "serial.tools.list_ports_common.ListPortInfo") -> dict:
    """Extract device metadata from a ListPortInfo."""
    return {
        "device": port_info.device,
        "description": port_info.description,
        "hwid": port_info.hwid,
        "manufacturer": port_info.manufacturer,
        "product": port_info.product,
        "serial_number": port_info.serial_number,
        "vid": f"{port_info.vid:04X}" if port_info.vid else None,
        "pid": f"{port_info.pid:04X}" if port_info.pid else None,
    }


# ============================================================================
# MCP TOOLS
# ============================================================================


@mcp.tool()
def watch_usb_device(
    grep: str | None = None,
    vid: str | None = None,
    pid: str | None = None,
    serial_number: str | None = None,
    baudrate: int = 115200,
    timeout: float = 60.0,
    capture_seconds: float = 3.0,
    on_connect_send: str | None = None,
    poll_interval: float = 0.25,
    exclusive: bool = True,
    mode: Literal["rs232", "rs485", "rs422"] = "rs232",
    traffic_log_max: int = 1000,
) -> dict:
    """Watch for a USB serial device to appear and capture its boot output.

    Monitors for a hot-plugged device matching the given filters, opens the port
    the instant the kernel finishes enumeration, and captures early boot data
    before returning. The connection remains open for further use afterward.

    This solves the universal embedded-dev timing gap: ESP32 boot messages,
    Arduino bootloader output, JTAG adapter initialization, STM32 DFU
    transitions — any scenario where data appears in a narrow window after
    USB enumeration that you'd otherwise miss.

    If the device is already connected when called, it opens immediately.

    Args:
        grep: Regex pattern to match against device/description/hwid/manufacturer/
              product/serial_number. Same syntax as list_serial_ports(grep=...).
              Examples: "CP210", "FTDI", "1A86:55D4"
        vid: USB Vendor ID as hex string (e.g., "10C4" for Silicon Labs).
             Matched against the port's numeric VID.
        pid: USB Product ID as hex string (e.g., "EA60" for CP2102).
             Matched against the port's numeric PID.
        serial_number: Exact match against the device's USB serial number string.
        baudrate: Baud rate to open with (default 115200). No auto-detect — we
                  can't afford to waste the boot window probing rates.
        timeout: Max seconds to wait for the device (1-300, default 60).
        capture_seconds: Seconds to capture boot data after connecting (0-30,
                         default 3). Set to 0 to skip capture and just connect fast.
        on_connect_send: Optional string to transmit after reading initial buffer
                         (e.g., a newline to trigger a prompt). Sent AFTER capturing
                         any pre-existing kernel buffer data.
        poll_interval: Seconds between device polls (0.1-5, default 0.25).
                       On Linux with pyudev, this is the udev poll timeout.
        exclusive: Request exclusive port access (default True).
        mode: Serial mode — rs232, rs485, or rs422.
        traffic_log_max: Max traffic log entries (default 1000).

    Returns:
        On success: watch_id, port, device_info, boot_capture (text + hex + byte count),
                    connection details, and detection method.
        On timeout: error with elapsed time and detection method.

    At least one filter (grep, vid, pid, or serial_number) is required.
    """
    # --- Validate inputs ---
    if not any([grep, vid, pid, serial_number]):
        return {
            "error": "At least one filter required: grep, vid, pid, or serial_number",
            "success": False,
        }

    if not (1 <= timeout <= 300):
        return {"error": "timeout must be between 1 and 300 seconds", "success": False}

    if not (0 <= capture_seconds <= 30):
        return {"error": "capture_seconds must be between 0 and 30", "success": False}

    if not (0.1 <= poll_interval <= 5):
        return {"error": "poll_interval must be between 0.1 and 5 seconds", "success": False}

    if len(_connections) >= MAX_CONNECTIONS:
        return {"error": f"Maximum connections ({MAX_CONNECTIONS}) reached", "success": False}

    # Compile grep pattern
    grep_pattern = None
    if grep:
        try:
            grep_pattern = re.compile(grep, re.IGNORECASE)
        except re.error as e:
            return {"error": f"Invalid grep pattern: {e}", "success": False}

    # Parse VID/PID from hex strings to ints
    vid_int = None
    pid_int = None
    if vid:
        try:
            vid_int = int(vid, 16)
        except ValueError:
            return {"error": f"Invalid VID hex string: {vid!r}", "success": False}
    if pid:
        try:
            pid_int = int(pid, 16)
        except ValueError:
            return {"error": f"Invalid PID hex string: {pid!r}", "success": False}

    # --- Register watch (thread-safe) ---
    watch_id = _next_watch_id()
    cancel_event = Event()
    with _watch_lock:
        _active_watches[watch_id] = cancel_event
    _log("INFO", "server", f"[{watch_id}] Watching for device (grep={grep}, vid={vid}, pid={pid})")

    start_time = time.monotonic()
    deadline = start_time + timeout
    detection_method = "unknown"

    try:
        # --- Check if device is already present ---
        baseline = _snapshot_ports()
        match = _find_matching_port(baseline, grep_pattern, vid_int, pid_int, serial_number)

        if match:
            detection_method = "already_present"
            _log("INFO", "server", f"[{watch_id}] Device already present: {match.device}")
        else:
            # --- Watch for device arrival ---
            # Try udev first (Linux, fast event-driven) with a budget that
            # reserves time for the polling fallback if udev silently fails.
            udev_budget = min(timeout * 0.8, timeout - 5) if timeout > 10 else timeout
            udev_deadline = start_time + udev_budget

            match = _try_udev_watch(
                grep_pattern, vid_int, pid_int, serial_number,
                udev_deadline, poll_interval, cancel_event,
            )
            if match:
                detection_method = "udev"
            else:
                if cancel_event.is_set():
                    elapsed = time.monotonic() - start_time
                    return {
                        "success": False,
                        "error": "Watch cancelled",
                        "watch_id": watch_id,
                        "elapsed_seconds": round(elapsed, 2),
                    }

                # Fall back to polling with remaining time
                if time.monotonic() < deadline:
                    baseline_devices = set(baseline.keys())
                    match = _poll_watch(
                        grep_pattern, vid_int, pid_int, serial_number,
                        baseline_devices, deadline, poll_interval, cancel_event,
                    )
                    if match:
                        detection_method = "polling"

        # --- Check for cancellation or timeout ---
        if cancel_event.is_set():
            elapsed = time.monotonic() - start_time
            return {
                "success": False,
                "error": "Watch cancelled",
                "watch_id": watch_id,
                "elapsed_seconds": round(elapsed, 2),
            }

        if match is None:
            elapsed = time.monotonic() - start_time
            return {
                "success": False,
                "error": f"No matching device appeared within {timeout}s",
                "watch_id": watch_id,
                "elapsed_seconds": round(elapsed, 2),
                "detection_method": detection_method,
                "filters": {
                    "grep": grep,
                    "vid": vid,
                    "pid": pid,
                    "serial_number": serial_number,
                },
            }

        port = match.device
        device_info = _build_device_info(match)

        # --- Settle delay and open port ---
        if detection_method != "already_present":
            time.sleep(0.05)  # 50ms settle for kernel to finalize device node

        # Retry open up to 3 times — kernel may still be setting up the device
        conn = None
        last_error = None
        for attempt in range(3):
            try:
                conn = serial.Serial(
                    port=port,
                    baudrate=baudrate,
                    timeout=0.1,  # short timeout for capture phase
                    exclusive=exclusive,
                )
                break
            except (serial.SerialException, OSError) as e:
                last_error = e
                if attempt < 2:
                    time.sleep(0.1)

        if conn is None:
            err_msg = str(last_error)
            if "Permission" in err_msg or "EACCES" in err_msg:
                err_msg += (
                    ". Check udev rules or add your user to the 'dialout' group: "
                    "sudo usermod -aG dialout $USER"
                )
            return {
                "success": False,
                "error": f"Device found but failed to open {port}: {err_msg}",
                "watch_id": watch_id,
                "device_info": device_info,
                "detection_method": detection_method,
            }

        # --- Register connection atomically (with MAX_CONNECTIONS re-check) ---
        traffic_log: deque[TrafficEntry] = deque(maxlen=traffic_log_max)
        sc = SerialConnection(
            port=port,
            connection=conn,
            mode=mode,
            traffic_log=traffic_log,
            traffic_log_max=traffic_log_max,
        )

        if port in _connections:
            conn.close()
            return {
                "success": False,
                "error": f"Port {port} was opened by another connection while watching",
                "watch_id": watch_id,
                "device_info": device_info,
            }

        if len(_connections) >= MAX_CONNECTIONS:
            conn.close()
            return {
                "success": False,
                "error": f"Maximum connections ({MAX_CONNECTIONS}) reached during watch",
                "watch_id": watch_id,
                "device_info": device_info,
            }

        _connections[port] = sc

        wait_elapsed = round(time.monotonic() - start_time, 3)
        _log(
            "INFO", "server",
            f"[{watch_id}] Opened {port} at {baudrate} baud "
            f"(detected via {detection_method}, waited {wait_elapsed}s)",
        )

        # --- Capture boot data and finalize connection ---
        # Wrapped so any unexpected failure cleans up the registered connection.
        try:
            # Do NOT flush input buffer — kernel buffer may contain early boot data
            boot_data = bytearray()

            if capture_seconds > 0:
                capture_deadline = time.monotonic() + capture_seconds
                while time.monotonic() < capture_deadline:
                    try:
                        available = conn.in_waiting
                        if available:
                            chunk = conn.read(available)
                            if chunk:
                                if len(boot_data) < _MAX_BOOT_CAPTURE_BYTES:
                                    boot_data.extend(
                                        chunk[:_MAX_BOOT_CAPTURE_BYTES - len(boot_data)]
                                    )
                                traffic_log.append(TrafficEntry(
                                    timestamp=time.time(),
                                    direction="rx",
                                    data=chunk,
                                ))
                        else:
                            remaining = capture_deadline - time.monotonic()
                            if remaining > 0:
                                time.sleep(min(0.02, remaining))
                    except serial.SerialException:
                        break

            # Send on_connect_send if specified
            if on_connect_send:
                try:
                    encoded = on_connect_send.encode("utf-8")
                    conn.write(encoded)
                    conn.flush()
                    traffic_log.append(TrafficEntry(
                        timestamp=time.time(),
                        direction="tx",
                        data=encoded,
                        encoding_used="utf-8",
                    ))
                    _log("DEBUG", port, f"Sent on_connect: {on_connect_send!r}")
                except (serial.SerialException, UnicodeEncodeError) as e:
                    _log("WARNING", port, f"Failed to send on_connect_send: {e}")

            # Restore normal timeout for ongoing use
            conn.timeout = DEFAULT_TIMEOUT

        except Exception as e:
            # Post-connect failure — clean up the connection we just registered
            with suppress(Exception):
                conn.close()
            _connections.pop(port, None)
            _log("ERROR", "server", f"[{watch_id}] Post-connect failure on {port}: {e}")
            return {
                "success": False,
                "error": f"Connected to {port} but post-connect processing failed: {e}",
                "watch_id": watch_id,
                "device_info": device_info,
                "detection_method": detection_method,
            }

        # --- Build response ---
        boot_text = boot_data.decode("utf-8", errors="replace") if boot_data else ""
        boot_hex = " ".join(f"{b:02x}" for b in boot_data[:256])

        total_elapsed = round(time.monotonic() - start_time, 3)

        return {
            "success": True,
            "watch_id": watch_id,
            "port": port,
            "device_info": device_info,
            "detection_method": detection_method,
            "wait_seconds": wait_elapsed,
            "total_seconds": total_elapsed,
            "connection": {
                "baudrate": baudrate,
                "mode": mode,
                "exclusive": exclusive,
                "traffic_log_enabled": True,
                "traffic_log_max": traffic_log_max,
                "resource_uri": f"serial://{port}/data",
                "traffic_log_resource": f"serial://{port}/log",
            },
            "boot_capture": {
                "capture_seconds": capture_seconds,
                "bytes_captured": len(boot_data),
                "text": boot_text,
                "hex_preview": boot_hex if boot_data else None,
            },
        }

    finally:
        with _watch_lock:
            _active_watches.pop(watch_id, None)


@mcp.tool()
def cancel_watch(watch_id: str | None = None) -> dict:
    """Cancel an active device watch.

    If watch_id is specified, cancels that specific watch. If omitted,
    cancels ALL active watches.

    This works because FastMCP runs sync tools in worker threads — the
    event loop remains free to dispatch cancel_watch while watch_usb_device
    blocks in another thread.

    Args:
        watch_id: ID of the watch to cancel (from watch_usb_device response).
                  If None, cancels all active watches.

    Returns:
        List of cancelled watch IDs and count.
    """
    with _watch_lock:
        if not _active_watches:
            return {"success": True, "cancelled": [], "message": "No active watches"}

        if watch_id:
            event = _active_watches.get(watch_id)
            if event is None:
                return {
                    "success": False,
                    "error": f"Watch {watch_id!r} not found",
                    "active_watches": list(_active_watches.keys()),
                }
            event.set()
            cancelled = [watch_id]
            _log("INFO", "server", f"Cancelled watch: {watch_id}")
        else:
            # Snapshot keys to avoid mutation during iteration
            cancelled = list(_active_watches.keys())
            for wid in cancelled:
                _active_watches[wid].set()
            _log("INFO", "server", f"Cancelled all watches ({len(cancelled)})")

    return {
        "success": True,
        "cancelled": cancelled,
        "count": len(cancelled),
    }
