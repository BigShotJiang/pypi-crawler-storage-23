"""YMODEM file transfer protocol implementation.

YMODEM extends XMODEM-1K with:
- Batch transfers (multiple files in one session)
- File metadata in block 0 (filename, size, modification time)
- CRC-16 required (no checksum mode)

Protocol flow:
  Receiver sends 'C' to initiate
  Sender sends block 0: filename + size + mtime (null-terminated strings)
  Receiver ACKs, then sends 'C' again for data
  Sender transmits data blocks (1024 bytes, XMODEM-1K style)
  Sender sends EOT, receiver NAKs, sender sends EOT again, receiver ACKs
  For batch: repeat with next file, or send empty block 0 to end session
"""

from __future__ import annotations

import contextlib
import logging
import os
import time
from collections.abc import Callable
from pathlib import Path

from mcserial._utils import open_file_atomic, sanitize_filename
from mcserial.xmodem import (
    ACK,
    CAN,
    CRC_MODE,
    EOT,
    NAK,
    SOH,
    STX,
    XModemError,
    _calc_crc16,
)

logger = logging.getLogger(__name__)

# Transfer limits and defaults
DEFAULT_MAX_TRANSFER_SIZE = 100 * 1024 * 1024  # 100MB default limit per file
DEFAULT_TIMEOUT = 60.0  # Total transfer timeout in seconds
DEFAULT_RETRY_LIMIT = 16  # Max retries per block


class YModemError(XModemError):
    """YMODEM-specific error."""
    pass


class YModem:
    """YMODEM batch file transfer protocol handler.

    Args:
        read_func: Callable that reads n bytes from serial, returns bytes
        write_func: Callable that writes bytes to serial
    """

    def __init__(
        self,
        read_func: Callable[[int], bytes],
        write_func: Callable[[bytes], int],
    ):
        self.read = read_func
        self.write = write_func

    def _read_byte(self, timeout_retries: int = 10) -> int | None:
        """Read a single byte with retry."""
        for _ in range(timeout_retries):
            data = self.read(1)
            if data:
                return data[0]
        return None

    def _make_block(self, block_num: int, data: bytes, block_size: int = 1024) -> bytes:
        """Create a YMODEM block with CRC-16."""
        # Pad data to block size
        if len(data) < block_size:
            data = data + bytes(block_size - len(data))

        header = STX if block_size == 1024 else SOH
        block = bytes([header, block_num & 0xFF, (255 - block_num) & 0xFF]) + data

        crc = _calc_crc16(data)
        block += bytes([crc >> 8, crc & 0xFF])

        return block

    def _make_block0(self, filename: str, filesize: int, mtime: int | None = None) -> bytes:
        """Create YMODEM block 0 with file metadata.

        Block 0 format: filename\0size mtime\0 (space-separated, octal for time)
        """
        # Build metadata string
        if mtime is not None:
            meta = f"{filename}\x00{filesize} {mtime:o}"
        else:
            meta = f"{filename}\x00{filesize}"

        data = meta.encode("latin-1")
        return data

    def _parse_block0(self, data: bytes) -> tuple[dict | None, str]:
        """Parse YMODEM block 0 metadata.

        Returns:
            Tuple of (metadata_dict, status) where:
            - (dict, "ok"): Successfully parsed file metadata
            - (None, "end_of_batch"): Empty block 0, signals end of batch transfer
            - (None, "parse_error"): Failed to parse block 0 data
        """
        # Find null terminator after filename
        try:
            null_pos = data.index(0)
            filename = data[:null_pos].decode("latin-1").strip()

            if not filename:
                return None, "end_of_batch"

            # Parse size and optional mtime
            rest = data[null_pos + 1:].split(b" ")
            rest = [x for x in rest if x and x != b"\x00"]

            filesize = int(rest[0]) if rest else 0
            # Clamp filesize to reasonable bounds (prevent memory issues from malicious values)
            if filesize < 0:
                filesize = 0
            elif filesize > 10 * 1024 * 1024 * 1024:  # 10GB sanity limit
                logger.warning(f"Filesize {filesize} exceeds 10GB limit, clamping")
                filesize = 10 * 1024 * 1024 * 1024
            mtime = int(rest[1], 8) if len(rest) > 1 else None

            return {
                "filename": filename,
                "size": filesize,
                "mtime": mtime,
            }, "ok"
        except (ValueError, IndexError):
            return None, "parse_error"

    def send(
        self,
        files: list[str | Path],
        callback: Callable[[str, int, int], None] | None = None,
        retry_limit: int = DEFAULT_RETRY_LIMIT,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> dict:
        """Send files via YMODEM batch transfer.

        Args:
            files: List of file paths to send
            callback: Progress callback(filename, bytes_sent, total_bytes)
            retry_limit: Max retries per block
            timeout: Total timeout in seconds (enforced across entire transfer)

        Returns:
            Dict with transfer statistics
        """
        start_time = time.monotonic()
        results = []
        total_bytes = 0
        total_errors = 0

        for filepath in files:
            filepath = Path(filepath)
            if not filepath.exists():
                results.append({"file": str(filepath), "error": "File not found"})
                continue

            filesize = filepath.stat().st_size
            mtime = int(filepath.stat().st_mtime)

            # Wait for receiver 'C'
            logger.debug(f"Waiting for receiver to initiate {filepath.name}...")
            for _ in range(retry_limit * 10):
                if time.monotonic() - start_time > timeout:
                    return {"success": False, "error": f"Timeout ({timeout}s) waiting for receiver", "files": results}
                b = self._read_byte(timeout_retries=3)
                if b == CRC_MODE:
                    break
                elif b == CAN:
                    return {"success": False, "error": "Transfer cancelled", "files": results}
            else:
                return {"success": False, "error": "Timeout waiting for receiver", "files": results}

            # Send block 0 with metadata
            block0_data = self._make_block0(filepath.name, filesize, mtime)
            block0 = self._make_block(0, block0_data, block_size=128)

            retries = 0
            while retries < retry_limit:
                self.write(block0)
                response = self._read_byte(timeout_retries=30)
                if response == ACK:
                    break
                elif response == CAN:
                    return {"success": False, "error": "Transfer cancelled", "files": results}
                retries += 1
            else:
                results.append({"file": str(filepath), "error": "Block 0 not acknowledged"})
                continue

            # Wait for second 'C' to start data
            for _ in range(retry_limit * 5):
                b = self._read_byte(timeout_retries=3)
                if b == CRC_MODE:
                    break
            else:
                results.append({"file": str(filepath), "error": "No data initiation"})
                continue

            # Send file data
            bytes_sent = 0
            block_num = 1
            errors = 0

            with open(filepath, "rb") as f:
                while True:
                    data = f.read(1024)
                    if not data:
                        break

                    block = self._make_block(block_num, data)
                    retries = 0

                    while retries < retry_limit:
                        self.write(block)
                        response = self._read_byte(timeout_retries=30)

                        if response == ACK:
                            bytes_sent += len(data)
                            if callback:
                                callback(filepath.name, bytes_sent, filesize)
                            block_num = (block_num + 1) & 0xFF
                            break
                        elif response == CAN:
                            results.append({"file": str(filepath), "error": "Cancelled"})
                            break
                        else:
                            retries += 1
                            errors += 1
                    else:
                        results.append({"file": str(filepath), "error": f"Max retries at block {block_num}"})
                        break

            # Send EOT sequence (NAK then ACK expected)
            for _ in range(retry_limit):
                self.write(bytes([EOT]))
                response = self._read_byte(timeout_retries=10)
                if response == NAK:
                    self.write(bytes([EOT]))
                    response = self._read_byte(timeout_retries=10)
                    if response == ACK:
                        break
                elif response == ACK:
                    break

            results.append({
                "file": str(filepath),
                "bytes_sent": bytes_sent,
                "blocks": block_num - 1,
                "errors": errors,
                "success": True,
            })
            total_bytes += bytes_sent
            total_errors += errors

        # Send empty block 0 to end batch
        for _ in range(retry_limit * 5):
            b = self._read_byte(timeout_retries=3)
            if b == CRC_MODE:
                break

        empty_block0 = self._make_block(0, b"", block_size=128)
        self.write(empty_block0)
        self._read_byte(timeout_retries=10)  # ACK

        return {
            "success": all(r.get("success", False) for r in results),
            "files": results,
            "total_bytes": total_bytes,
            "total_errors": total_errors,
        }

    def receive(
        self,
        directory: str | Path,
        callback: Callable[[str, int, int], None] | None = None,
        retry_limit: int = DEFAULT_RETRY_LIMIT,
        overwrite: bool = False,
        max_transfer_size: int = DEFAULT_MAX_TRANSFER_SIZE,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> dict:
        """Receive files via YMODEM batch transfer.

        Args:
            directory: Directory to save received files
            callback: Progress callback(filename, bytes_received, total_bytes)
            retry_limit: Max retries per block
            overwrite: Overwrite existing files
            max_transfer_size: Maximum bytes to receive per file (default 100MB).
                               Set to 0 to disable limit. Prevents unbounded memory usage.
            timeout: Total timeout in seconds (enforced across entire transfer)

        Returns:
            Dict with transfer statistics
        """
        start_time = time.monotonic()
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)

        results = []
        total_bytes = 0
        total_errors = 0

        while True:
            # Check timeout
            if time.monotonic() - start_time > timeout:
                return {"success": False, "error": f"Timeout ({timeout}s)", "files": results}

            # Initiate with 'C' for CRC mode
            logger.debug("Initiating YMODEM receive...")
            for _attempt in range(retry_limit):
                if time.monotonic() - start_time > timeout:
                    return {"success": False, "error": f"Timeout ({timeout}s)", "files": results}
                self.write(bytes([CRC_MODE]))
                header = self._read_byte(timeout_retries=30)
                if header in (SOH, STX):
                    break
                elif header == CAN:
                    return {"success": False, "error": "Cancelled", "files": results}
            else:
                return {"success": False, "error": "Timeout", "files": results}

            # Receive block 0
            block_size = 1024 if header == STX else 128
            block_num = self._read_byte()
            block_num_comp = self._read_byte()

            if block_num != 0:
                self.write(bytes([NAK]))
                continue

            data = self.read(block_size)
            crc_bytes = self.read(2)

            # Verify CRC
            expected_crc = _calc_crc16(data)
            received_crc = (crc_bytes[0] << 8) | crc_bytes[1]
            if expected_crc != received_crc:
                self.write(bytes([NAK]))
                continue

            # Parse metadata
            meta, status = self._parse_block0(data)
            if status == "end_of_batch":
                self.write(bytes([ACK]))
                break
            elif status == "parse_error":
                logger.debug("Failed to parse block 0 metadata")
                self.write(bytes([NAK]))
                continue

            filename = meta["filename"]
            filesize = meta["size"]
            logger.debug(f"Receiving: {filename} ({filesize} bytes)")

            # Security: sanitize filename to prevent path traversal attacks
            safe_filename = sanitize_filename(filename)
            if safe_filename != filename:
                logger.warning(f"Sanitized filename: {filename!r} -> {safe_filename!r}")

            filepath = directory / safe_filename

            # Atomic file creation to prevent TOCTOU race conditions
            f, file_error, _ = open_file_atomic(filepath, overwrite)
            if file_error:
                results.append({"file": filename, "error": file_error})
                self.write(bytes([CAN, CAN]))
                continue

            self.write(bytes([ACK]))

            # Send 'C' to start data transfer
            self.write(bytes([CRC_MODE]))

            # Receive data blocks
            bytes_received = 0
            expected_block = 1
            errors = 0
            transfer_aborted = False

            try:
                while bytes_received < filesize and not transfer_aborted:
                    header = self._read_byte(timeout_retries=60)

                    if header == EOT:
                        self.write(bytes([NAK]))
                        header = self._read_byte(timeout_retries=10)
                        if header == EOT:
                            self.write(bytes([ACK]))
                            break
                        continue

                    if header not in (SOH, STX):
                        errors += 1
                        self.write(bytes([NAK]))
                        continue

                    block_size = 1024 if header == STX else 128
                    block_num = self._read_byte()
                    block_num_comp = self._read_byte()

                    if (block_num + block_num_comp) & 0xFF != 0xFF:
                        errors += 1
                        self.write(bytes([NAK]))
                        continue

                    data = self.read(block_size)
                    crc_bytes = self.read(2)

                    if len(data) != block_size or len(crc_bytes) != 2:
                        errors += 1
                        self.write(bytes([NAK]))
                        continue

                    expected_crc = _calc_crc16(data)
                    received_crc = (crc_bytes[0] << 8) | crc_bytes[1]
                    if expected_crc != received_crc:
                        errors += 1
                        self.write(bytes([NAK]))
                        continue

                    if block_num == expected_block:
                        # Trim last block to actual file size
                        remaining = filesize - bytes_received
                        if remaining < block_size:
                            data = data[:remaining]

                        f.write(data)
                        bytes_received += len(data)
                        expected_block = (expected_block + 1) & 0xFF

                        # Check transfer size limit to prevent unbounded memory usage
                        if max_transfer_size > 0 and bytes_received > max_transfer_size:
                            logger.warning(
                                f"Transfer aborted: {filename} exceeded {max_transfer_size} byte limit "
                                f"(received {bytes_received} bytes)"
                            )
                            self.write(bytes([CAN, CAN]))
                            transfer_aborted = True
                            break

                        if callback:
                            callback(filename, bytes_received, filesize)

                    self.write(bytes([ACK]))
            finally:
                f.close()

            if transfer_aborted:
                # Transfer was aborted due to size limit
                results.append({
                    "file": filename,
                    "path": str(filepath),
                    "error": f"Transfer size exceeded {max_transfer_size} byte limit",
                    "bytes_received": bytes_received,
                    "success": False,
                })
                # Try to clean up partial file
                with contextlib.suppress(OSError):
                    filepath.unlink()
                continue

            # Set modification time if provided
            if meta.get("mtime"):
                os.utime(filepath, (time.time(), meta["mtime"]))

            results.append({
                "file": filename,
                "path": str(filepath),
                "bytes_received": bytes_received,
                "errors": errors,
                "success": True,
            })
            total_bytes += bytes_received
            total_errors += errors

        return {
            "success": all(r.get("success", False) for r in results),
            "files": results,
            "total_bytes": total_bytes,
            "total_errors": total_errors,
        }


def send_ymodem(
    read_func: Callable[[int], bytes],
    write_func: Callable[[bytes], int],
    files: list[str | Path],
    callback: Callable[[str, int, int], None] | None = None,
) -> dict:
    """Convenience function to send files via YMODEM."""
    ym = YModem(read_func, write_func)
    return ym.send(files, callback)


def receive_ymodem(
    read_func: Callable[[int], bytes],
    write_func: Callable[[bytes], int],
    directory: str | Path,
    callback: Callable[[str, int, int], None] | None = None,
    overwrite: bool = False,
) -> dict:
    """Convenience function to receive files via YMODEM."""
    ym = YModem(read_func, write_func)
    return ym.receive(directory, callback, overwrite=overwrite)
