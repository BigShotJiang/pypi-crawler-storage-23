"""Configuration and logging tools for serial ports."""

from __future__ import annotations

from collections import deque
from typing import Literal

import serial

import mcserial._state as _state_mod
from mcserial._helpers import _resolve_line_ending
from mcserial._state import (
    _LOG_LEVELS,
    _connections,
    _log,
    mcp,
)


@mcp.tool()
def configure_serial(
    port: str,
    baudrate: int | None = None,
    timeout: float | None = None,
    write_timeout: float | None = None,
    inter_byte_timeout: float | None = None,
    xonxoff: bool | None = None,
    rtscts: bool | None = None,
    dsrdtr: bool | None = None,
    rts: bool | None = None,
    dtr: bool | None = None,
    line_ending: str | None = None,
) -> dict:
    """Configure settings on an open serial port.

    Args:
        port: Device path of the port to configure
        baudrate: New baud rate (None = no change)
        timeout: New read timeout in seconds (None = no change)
        write_timeout: New write timeout in seconds (None = no change)
        inter_byte_timeout: Timeout between bytes (None = no change)
        xonxoff: Software flow control XON/XOFF (None = no change)
        rtscts: Hardware RTS/CTS flow control (None = no change)
        dsrdtr: Hardware DSR/DTR flow control (None = no change)
        rts: Set RTS line state (None = no change)
        dtr: Set DTR line state (None = no change)
        line_ending: Default line ending for write_serial. Accepts "cr", "lf", "crlf",
                     "none" (to clear), or a literal string. When set, write_serial
                     auto-appends this to every string sent. Does not affect
                     write_serial_bytes. (None = no change)

    Returns:
        Updated port configuration
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        sc = _connections[port]
        conn = sc.connection

        if baudrate is not None:
            conn.baudrate = baudrate
        if timeout is not None:
            conn.timeout = timeout
        if write_timeout is not None:
            conn.write_timeout = write_timeout
        if inter_byte_timeout is not None:
            conn.inter_byte_timeout = inter_byte_timeout
        if xonxoff is not None:
            conn.xonxoff = xonxoff
        if rtscts is not None:
            conn.rtscts = rtscts
        if dsrdtr is not None:
            conn.dsrdtr = dsrdtr
        if (rts is not None or dtr is not None) and sc.mode != "rs232":
            return {
                "error": f"Setting RTS/DTR directly requires RS-232 mode (current: {sc.mode.upper()}). "
                         f"In {sc.mode.upper()} mode, these lines may have special meaning. "
                         f"Use set_port_mode(port='{port}', mode='rs232') to switch first.",
                "success": False,
            }
        if rts is not None:
            conn.rts = rts
        if dtr is not None:
            conn.dtr = dtr
        if line_ending is not None:
            resolved = _resolve_line_ending(line_ending)
            sc.default_line_ending = resolved if resolved else None

        return {
            "success": True,
            "port": port,
            "baudrate": conn.baudrate,
            "timeout": conn.timeout,
            "write_timeout": conn.write_timeout,
            "inter_byte_timeout": conn.inter_byte_timeout,
            "xonxoff": conn.xonxoff,
            "rtscts": conn.rtscts,
            "dsrdtr": conn.dsrdtr,
            "rts": conn.rts,
            "dtr": conn.dtr,
            "line_ending": sc.default_line_ending,
        }
    except serial.SerialException as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def get_connection_status() -> dict:
    """Get status of all open serial connections.

    Returns:
        Dictionary of open connections with their settings and current mode
    """
    status = {}
    for port, sc in _connections.items():
        conn = sc.connection
        try:
            status[port] = {
                "is_open": conn.is_open,
                "mode": sc.mode,
                "baudrate": conn.baudrate,
                "bytesize": conn.bytesize,
                "parity": conn.parity,
                "stopbits": conn.stopbits,
                "timeout": conn.timeout,
                "write_timeout": conn.write_timeout,
                "inter_byte_timeout": conn.inter_byte_timeout,
                "xonxoff": conn.xonxoff,
                "rtscts": conn.rtscts,
                "dsrdtr": conn.dsrdtr,
                "in_waiting": conn.in_waiting,
                "out_waiting": conn.out_waiting,
                **(
                    {
                        "cts": conn.cts,
                        "dsr": conn.dsr,
                        "ri": conn.ri,
                        "cd": conn.cd,
                        "rts": conn.rts,
                        "dtr": conn.dtr,
                    }
                    if sc.mode == "rs232"
                    else {"modem_lines": f"Not applicable in {sc.mode.upper()} mode"}
                ),
                "line_ending": sc.default_line_ending,
                "resource_uri": f"serial://{port}/data",
                "traffic_log_enabled": sc.traffic_log is not None,
                "traffic_log_entries": len(sc.traffic_log) if sc.traffic_log else 0,
            }
        except serial.SerialException:
            status[port] = {"is_open": False, "mode": sc.mode, "error": "Port disconnected"}
    return {"connections": status, "count": len(_connections)}


@mcp.tool()
def configure_logging(
    level: str = "INFO",
    max_entries: int = 1000,
    clear: bool = False,
) -> dict:
    """Configure server-wide logging behavior.

    Args:
        level: Minimum log level to capture (DEBUG, INFO, WARNING, ERROR)
        max_entries: Maximum entries in the server log buffer (default 1000)
        clear: Clear existing log entries if True

    Returns:
        Current logging configuration
    """
    level = level.upper()
    if level not in _LOG_LEVELS:
        return {
            "error": f"Invalid log level: {level}. Must be one of: {list(_LOG_LEVELS.keys())}",
            "success": False,
        }

    if max_entries < 10 or max_entries > 100000:
        return {"error": "max_entries must be between 10 and 100000", "success": False}

    old_level = _state_mod._log_level
    _state_mod._log_level = level

    if clear:
        _state_mod._log_buffer.clear()
        _log("INFO", "server", "Log buffer cleared")

    # Resize buffer if needed
    if _state_mod._log_buffer.maxlen != max_entries:
        old_entries = list(_state_mod._log_buffer)
        _state_mod._log_buffer = deque(old_entries, maxlen=max_entries)

    _log("INFO", "server", f"Logging configured: level={level}, max_entries={max_entries}")

    return {
        "success": True,
        "level": _state_mod._log_level,
        "previous_level": old_level,
        "max_entries": _state_mod._log_buffer.maxlen,
        "current_entries": len(_state_mod._log_buffer),
        "cleared": clear,
        "resource_uri": "serial://log",
    }


@mcp.tool()
def enable_traffic_log(
    port: str,
    enabled: bool = True,
    max_entries: int = 500,
    clear: bool = False,
) -> dict:
    """Enable or disable per-port traffic capture.

    When enabled, all TX/RX data on this port is captured to an in-memory buffer.
    The captured traffic can be read via the serial://{port}/log resource.

    Args:
        port: Device path of the port to configure
        enabled: Enable (True) or disable (False) traffic logging
        max_entries: Maximum traffic entries to keep (default 500)
        clear: Clear existing traffic log entries if True

    Returns:
        Traffic log configuration status
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    if max_entries < 10 or max_entries > 10000:
        return {"error": "max_entries must be between 10 and 10000", "success": False}

    sc = _connections[port]

    if enabled:
        if clear or sc.traffic_log is None:
            sc.traffic_log = deque(maxlen=max_entries)
            _log("INFO", port, f"Traffic logging enabled (max {max_entries} entries)")
        elif sc.traffic_log.maxlen != max_entries:
            # Resize buffer
            old_entries = list(sc.traffic_log)
            sc.traffic_log = deque(old_entries, maxlen=max_entries)
            _log("INFO", port, f"Traffic log resized to {max_entries} entries")
        sc.traffic_log_max = max_entries
    else:
        if sc.traffic_log is not None:
            sc.traffic_log = None
            _log("INFO", port, "Traffic logging disabled")

    return {
        "success": True,
        "port": port,
        "traffic_log_enabled": sc.traffic_log is not None,
        "max_entries": max_entries if enabled else None,
        "current_entries": len(sc.traffic_log) if sc.traffic_log else 0,
        "resource_uri": f"serial://{port}/log" if enabled else None,
    }


@mcp.tool()
def flush_serial(port: str, input_buffer: bool = True, output_buffer: bool = True) -> dict:
    """Flush serial port buffers.

    Args:
        port: Device path of the port to flush
        input_buffer: Clear input/receive buffer
        output_buffer: Clear output/transmit buffer

    Returns:
        Flush operation status
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        conn = _connections[port].connection
        if input_buffer:
            conn.reset_input_buffer()
        if output_buffer:
            conn.reset_output_buffer()
        return {"success": True, "port": port, "flushed_input": input_buffer, "flushed_output": output_buffer}
    except serial.SerialException as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def cancel_read(port: str) -> dict:
    """Cancel any pending read operation on a serial port.

    Interrupts a blocking read by calling cancel_read() on the underlying
    pyserial connection. Only effective on platforms that support it
    (POSIX with select-based reads).

    Args:
        port: Device path of the port

    Returns:
        Cancellation status
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        conn = _connections[port].connection
        conn.cancel_read()
        return {"success": True, "port": port, "cancelled": "read"}
    except (serial.SerialException, AttributeError) as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def cancel_write(port: str) -> dict:
    """Cancel any pending write operation on a serial port.

    Interrupts a blocking write by calling cancel_write() on the underlying
    pyserial connection. Only effective on platforms that support it
    (POSIX with select-based writes).

    Args:
        port: Device path of the port

    Returns:
        Cancellation status
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        conn = _connections[port].connection
        conn.cancel_write()
        return {"success": True, "port": port, "cancelled": "write"}
    except (serial.SerialException, AttributeError) as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def set_flow_control(
    port: str,
    input_flow: bool | None = None,
    output_flow: bool | None = None,
) -> dict:
    """Manually gate input/output flow control on a serial port.

    When software (XON/XOFF) or hardware (RTS/CTS) flow control is enabled,
    these calls manually send flow control signals:

    - input_flow=True: Send XON (allow remote to send)
    - input_flow=False: Send XOFF (tell remote to stop)
    - output_flow=True: Resume our outgoing data
    - output_flow=False: Pause our outgoing data

    Flow control must already be enabled via configure_serial (xonxoff=True
    or rtscts=True) for these to have effect.

    WARNING: Not portable across all platforms.

    Args:
        port: Device path of the port
        input_flow: Enable (XON) or disable (XOFF) incoming data (None = no change)
        output_flow: Enable or disable outgoing data (None = no change)

    Returns:
        Flow control gate status
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        conn = _connections[port].connection
        changes = {}

        if input_flow is not None:
            conn.set_input_flow_control(input_flow)
            changes["input_flow"] = input_flow
        if output_flow is not None:
            conn.set_output_flow_control(output_flow)
            changes["output_flow"] = output_flow

        return {
            "success": True,
            "port": port,
            "changes": changes,
            "flow_control_enabled": {
                "xonxoff": conn.xonxoff,
                "rtscts": conn.rtscts,
            },
        }
    except (serial.SerialException, AttributeError) as e:
        return {"error": str(e), "success": False}


@mcp.tool()
def set_port_mode(port: str, mode: Literal["rs232", "rs485", "rs422"]) -> dict:
    """Switch a serial port between RS-232, RS-422, and RS-485 modes.

    Mode determines which tools are available:

    RS-232 mode (default):
        - Standard point-to-point serial communication
        - Full modem control lines (RTS, DTR, CTS, DSR, RI, CD)
        - Tools: get_modem_lines, set_modem_lines, pulse_line, send_break

    RS-422 mode:
        - Full-duplex differential point-to-point (or 1-to-10 receivers)
        - Separate TX+/TX- and RX+/RX- differential pairs
        - No modem control lines, no direction control needed
        - Tools: check_rs422_support
        - All common tools (transact, read/write, configure) work normally

    RS-485 mode:
        - Half-duplex multi-drop bus communication
        - Automatic or manual TX/RX direction control
        - Tools: set_rs485_mode, rs485_transact, rs485_scan_addresses, check_rs485_support

    Common tools work in all modes:
        - open/close, read/write, configure, flush, detect_baud_rate

    Args:
        port: Device path of the port to configure
        mode: Target mode ("rs232", "rs422", or "rs485")

    Returns:
        Mode change status with available tools for the new mode
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    sc = _connections[port]
    old_mode = sc.mode

    # Clean up hardware state from previous mode
    if old_mode == "rs485" and mode != "rs485":
        try:
            if sc.connection.rs485_mode is not None:
                sc.connection.rs485_mode = None
                _log("INFO", port, f"Cleared RS-485 hardware settings for mode switch to {mode.upper()}")
        except (serial.SerialException, AttributeError):
            _log("WARNING", port, "Could not clear RS-485 hardware settings during mode switch")

    sc.mode = mode

    mode_tools = {
        "rs232": [
            "get_modem_lines",
            "set_modem_lines",
            "pulse_line",
            "send_break",
            "set_break_condition",
        ],
        "rs422": [
            "check_rs422_support",
        ],
        "rs485": [
            "set_rs485_mode",
            "rs485_transact",
            "rs485_scan_addresses",
            "check_rs485_support",
        ],
    }

    _mode_descriptions = {
        "rs232": "Point-to-point with modem control lines. Use get_modem_lines, set_modem_lines, pulse_line, send_break.",
        "rs422": "Full-duplex differential. All common tools (transact, read, write) work. No modem or direction control tools needed.",
        "rs485": "Half-duplex bus. Use rs485_transact for bus transactions, rs485_scan_addresses to discover devices.",
    }

    return {
        "success": True,
        "port": port,
        "previous_mode": old_mode,
        "current_mode": mode,
        "mode_tools": mode_tools[mode],
        "hint": f"Port is now in {mode.upper()} mode. {_mode_descriptions[mode]}",
    }


@mcp.tool()
def set_low_latency_mode(port: str, enabled: bool = True) -> dict:
    """Enable or disable low-latency mode (Linux only).

    Reduces latency by changing how the kernel buffers data.
    Useful for time-critical applications.

    Note: This is a Linux-specific feature and may not work on all systems.

    Args:
        port: Device path of the port
        enabled: Enable (True) or disable (False) low latency mode

    Returns:
        Operation status
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        conn = _connections[port].connection
        conn.set_low_latency_mode(enabled)
        return {"success": True, "port": port, "low_latency": enabled}
    except (serial.SerialException, AttributeError, OSError) as e:
        return {"error": f"Low latency mode not supported: {e}", "success": False}
