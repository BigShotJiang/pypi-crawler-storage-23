"""MCP Serial Port Server - FastMCP server for serial port access."""

from mcserial._state import mcp
from mcserial.server import main

__all__ = ["main", "mcp"]
