"""MCP resource handlers for serial port data access."""

from __future__ import annotations

import serial

from mcserial._ports import list_serial_ports
from mcserial._state import (
    DEFAULT_BAUDRATE,
    DEFAULT_TIMEOUT,
    MAX_CONNECTIONS,
    _connections,
    _log_buffer,
    mcp,
)


@mcp.resource("serial://server/info")
def resource_server_info() -> str:
    """Server version, links, and connection summary."""
    try:
        from importlib.metadata import version
        package_version = version("mcserial")
    except Exception:
        package_version = "dev"

    lines = [
        f"# mcserial v{package_version}",
        "",
        f"- Connections: {len(_connections)} open (max {MAX_CONNECTIONS})",
        f"- Default baudrate: {DEFAULT_BAUDRATE}",
        f"- Default timeout: {DEFAULT_TIMEOUT}s",
        "",
        "## Links",
        "- Documentation: https://mcserial.warehack.ing",
        "- PyPI: https://pypi.org/project/mcserial/",
        "- Repository: https://git.supported.systems/MCP/mcserial",
        "- Issues: https://git.supported.systems/MCP/mcserial/issues",
    ]
    return "\n".join(lines)


@mcp.resource("serial://ports")
def resource_list_ports() -> str:
    """List available serial ports as a resource."""
    ports = list_serial_ports.fn()
    lines = ["# Available Serial Ports\n"]
    for p in ports:
        status = "[OPEN]" if p["is_open"] else "[closed]"
        lines.append(f"- {p['device']} {status}: {p['description']}")
    return "\n".join(lines)


@mcp.resource("serial://{port}/data")
def resource_read_data(port: str) -> str:
    """Read available data from an open serial port.

    WARNING: Reading this resource CONSUMES data from the port buffer.
    Data read here will not be available to read_serial or transact.

    The {port} parameter should be URL-encoded if it contains special characters.
    For example: serial:///dev/ttyUSB0/data
    """
    # Handle URL-encoded port paths
    import urllib.parse
    port = urllib.parse.unquote(port)

    if port not in _connections:
        return f"Error: Port {port} is not open. Use open_serial_port tool first."

    try:
        conn = _connections[port].connection
        available = conn.in_waiting
        if available == 0:
            return f"[No data available on {port}]"

        raw = conn.read(available)
        text = raw.decode("utf-8", errors="replace")
        return f"[{len(raw)} bytes from {port}]\n{text}"
    except serial.SerialException as e:
        return f"Error reading from {port}: {e}"


@mcp.resource("serial://{port}/status")
def resource_port_status(port: str) -> str:
    """Get status information for a serial port."""
    import urllib.parse
    port = urllib.parse.unquote(port)

    if port not in _connections:
        return f"Port {port} is not open."

    try:
        sc = _connections[port]
        conn = sc.connection
        lines = [
            f"# Serial Port Status: {port}",
            f"- Mode: {sc.mode.upper()}",
            f"- Open: {conn.is_open}",
            f"- Baudrate: {conn.baudrate}",
            f"- Bytesize: {conn.bytesize}",
            f"- Parity: {conn.parity}",
            f"- Stopbits: {conn.stopbits}",
            f"- Timeout: {conn.timeout}s",
            f"- Line ending: {repr(sc.default_line_ending) if sc.default_line_ending else 'None'}",
            f"- Bytes waiting (in): {conn.in_waiting}",
            f"- Bytes waiting (out): {conn.out_waiting}",
        ]
        if sc.mode == "rs232":
            lines.extend([
                f"- CTS: {conn.cts}",
                f"- DSR: {conn.dsr}",
                f"- RI: {conn.ri}",
                f"- CD: {conn.cd}",
                f"- RTS: {conn.rts}",
                f"- DTR: {conn.dtr}",
            ])
        else:
            lines.append(f"- Modem lines: Not applicable in {sc.mode.upper()} mode")
        return "\n".join(lines)
    except serial.SerialException as e:
        return f"Error getting status for {port}: {e}"


@mcp.resource("serial://{port}/raw")
def resource_read_raw(port: str) -> str:
    """Read available data as hex dump from an open serial port.

    WARNING: Reading this resource CONSUMES data from the port buffer.
    Data read here will not be available to read_serial or transact.
    """
    import urllib.parse
    port = urllib.parse.unquote(port)

    if port not in _connections:
        return f"Error: Port {port} is not open."

    try:
        conn = _connections[port].connection
        available = conn.in_waiting
        if available == 0:
            return f"[No data available on {port}]"

        raw = conn.read(available)
        # Format as hex dump
        hex_str = " ".join(f"{b:02x}" for b in raw)
        return f"[{len(raw)} bytes from {port}]\n{hex_str}"
    except serial.SerialException as e:
        return f"Error reading from {port}: {e}"


@mcp.resource("serial://log")
def resource_server_log() -> str:
    """Server-wide log buffer. Returns recent log entries as formatted text.

    Use query parameter ?level=WARNING to filter by minimum level.
    """
    from datetime import datetime

    if not _log_buffer:
        return "# mcserial Server Log (0 entries)\n\n[No log entries yet]"

    lines = [f"# mcserial Server Log ({len(_log_buffer)} entries)\n"]
    for entry in _log_buffer:
        ts = datetime.fromtimestamp(entry.timestamp).strftime("%Y-%m-%dT%H:%M:%S")
        lines.append(f"[{ts}] {entry.level} {entry.source}: {entry.message}")

    return "\n".join(lines)


@mcp.resource("serial://{port}/log")
def resource_port_log(port: str) -> str:
    """Per-port traffic log (if enabled). Returns TX/RX history as hex + ASCII.

    Traffic logging must be enabled via enable_traffic_log() or by using spy://.
    """
    import urllib.parse
    from datetime import datetime

    port = urllib.parse.unquote(port)

    if port not in _connections:
        return f"Error: Port {port} is not open."

    sc = _connections[port]
    if sc.traffic_log is None:
        return (
            f"# Traffic Log: {port}\n\n"
            "Traffic logging is not enabled for this port.\n"
            "Use enable_traffic_log(port, enabled=True) to enable it."
        )

    if not sc.traffic_log:
        return f"# Traffic Log: {port} (0 entries)\n\n[No traffic captured yet]"

    def format_hex_ascii(data: bytes) -> str:
        """Format bytes as hex + ASCII representation."""
        hex_part = " ".join(f"{b:02x}" for b in data[:16])
        ascii_part = "".join(chr(b) if 32 <= b <= 126 else "." for b in data[:16])
        if len(data) > 16:
            hex_part += " ..."
            ascii_part += "..."
        return f"{hex_part}  |{ascii_part}|"

    lines = [f"# Traffic Log: {port} ({len(sc.traffic_log)} entries)\n"]
    for entry in sc.traffic_log:
        ts = datetime.fromtimestamp(entry.timestamp).strftime("%H:%M:%S.%f")[:-3]
        direction = "TX" if entry.direction == "tx" else "RX"
        formatted = format_hex_ascii(entry.data)
        lines.append(f"[{ts}] {direction} ({len(entry.data)} bytes): {formatted}")

    return "\n".join(lines)
