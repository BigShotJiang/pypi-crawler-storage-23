"""Shared state, data structures, and MCP instance for mcserial."""

from __future__ import annotations

import atexit
import os
import time
from collections import deque
from contextlib import asynccontextmanager, suppress
from dataclasses import dataclass, field
from typing import Literal

import serial
from fastmcp import FastMCP

# Configuration from environment
DEFAULT_BAUDRATE = int(os.getenv("MCSERIAL_DEFAULT_BAUDRATE", "9600"))
DEFAULT_TIMEOUT = float(os.getenv("MCSERIAL_DEFAULT_TIMEOUT", "1.0"))
MAX_CONNECTIONS = int(os.getenv("MCSERIAL_MAX_CONNECTIONS", "10"))

# Named line ending aliases -> actual characters
_LINE_ENDINGS = {"cr": "\r", "lf": "\n", "crlf": "\r\n", "none": ""}


# ============================================================================
# LOGGING DATA STRUCTURES
# ============================================================================


@dataclass
class LogEntry:
    """A single server log entry."""

    timestamp: float
    level: str  # DEBUG, INFO, WARNING, ERROR
    source: str  # "server", port name, "xmodem", etc.
    message: str


_TRAFFIC_ENTRY_MAX_DATA = 4096  # Cap per-entry data to prevent memory bloat


@dataclass
class TrafficEntry:
    """A single TX/RX traffic capture entry."""

    timestamp: float
    direction: Literal["tx", "rx"]
    data: bytes
    encoding_used: str | None = None
    truncated: bool = False

    def __post_init__(self):
        if len(self.data) > _TRAFFIC_ENTRY_MAX_DATA:
            object.__setattr__(self, "data", self.data[:_TRAFFIC_ENTRY_MAX_DATA])
            object.__setattr__(self, "truncated", True)


# Server-wide log buffer (circular)
_log_buffer: deque[LogEntry] = deque(maxlen=1000)
_log_level: str = "INFO"
_LOG_LEVELS = {"DEBUG": 0, "INFO": 1, "WARNING": 2, "ERROR": 3}


def _log(level: str, source: str, message: str) -> None:
    """Add an entry to the server log buffer if level meets threshold."""
    if _LOG_LEVELS.get(level, 0) >= _LOG_LEVELS.get(_log_level, 1):
        _log_buffer.append(LogEntry(
            timestamp=time.time(),
            level=level,
            source=source,
            message=message,
        ))


@dataclass
class SerialConnection:
    """Tracks an open serial port connection."""

    port: str
    connection: serial.Serial
    buffer: bytes = field(default_factory=bytes)
    mode: Literal["rs232", "rs485", "rs422"] = "rs232"
    # Default line ending appended by write_serial (None = no auto-append)
    default_line_ending: str | None = None
    # Traffic logging (None = disabled)
    traffic_log: deque | None = None
    traffic_log_max: int = 500


# Active connections registry
# NOTE: This dict is NOT thread-safe. The MCP server is designed for single-threaded
# async operation (FastMCP uses async/await). If you need thread-safe access,
# wrap operations with threading.Lock or use asyncio.Lock for async contexts.
_connections: dict[str, SerialConnection] = {}


def _cleanup_connections() -> int:
    """Close all open serial connections. Returns count of ports closed.

    Safe to call multiple times (idempotent) — closing an already-empty
    registry is a no-op returning 0.
    """
    closed = 0
    for _port, conn in list(_connections.items()):
        try:
            if conn.connection.is_open:
                conn.connection.close()
                closed += 1
        except Exception:
            pass  # Best effort - don't raise during shutdown
    _connections.clear()
    return closed


def _atexit_cleanup() -> None:
    """Best-effort cleanup during interpreter shutdown.

    During late interpreter teardown, module globals (like `time`) can
    already be None, so we suppress everything — the port close itself
    is the only thing that matters here.
    """
    with suppress(Exception):
        _cleanup_connections()


atexit.register(_atexit_cleanup)


@asynccontextmanager
async def _lifespan(server: FastMCP):
    """MCP server lifecycle — ensures serial ports are released on shutdown.

    The finally block runs when:
    - The MCP transport closes (client disconnect, graceful shutdown)
    - asyncio cancellation (SIGINT/SIGTERM handled by asyncio's event loop)
    - An unhandled exception crashes the server

    Outside an asyncio event loop, the atexit handler provides the fallback.
    """
    _log("INFO", "server", "MCP server started")
    try:
        yield {}
    finally:
        closed = _cleanup_connections()
        if closed:
            _log("INFO", "server", f"Lifespan shutdown — closed {closed} serial port(s)")
        _log("INFO", "server", "MCP server stopped")


mcp = FastMCP(
    name="mcserial",
    lifespan=_lifespan,
    instructions="""Serial port MCP server for RS-232/RS-422/RS-485 communication and file transfers.

## Quick Start
1. list_serial_ports() - Discover available ports
2. open_serial_port(port) - Open a connection (defaults to RS-232 mode)
3. transact(port, data) - Send a command and read the response in one call
4. For interactive sessions: configure_serial(port, line_ending="crlf") to auto-append line endings

## Modes
Ports open in RS-232 mode by default. Use set_port_mode() or the mode parameter on open_serial_port() to switch:

**RS-232 mode** (default): Point-to-point serial with modem control lines.
  - Tools: get_modem_lines, set_modem_lines, pulse_line, send_break

**RS-422 mode**: Full-duplex differential point-to-point (or 1-to-10 receivers).
  Uses separate TX+/TX- and RX+/RX- differential pairs for noise immunity over long cable runs (up to 1200m).
  No modem control lines, no direction control needed — just read and write.
  - Tools: check_rs422_support
  - All common tools (transact, read_serial, write_serial, etc.) work in RS-422 mode.

**RS-485 mode**: Half-duplex multi-drop bus communication.
  - Tools: set_rs485_mode, rs485_transact, rs485_scan_addresses

## File Transfers (X/Y/ZMODEM)
Transfer files using classic protocols. Works in all modes.
  - file_transfer_send(port, file, protocol="zmodem")
  - file_transfer_receive(port, save_path, protocol="zmodem")
  - file_transfer_send_batch(port, files) - YMODEM/ZMODEM only

Protocols: xmodem (128B blocks), xmodem1k, ymodem (batch), zmodem (streaming, recommended)

## Logging
In-memory logging for debugging and traffic capture:
  - configure_logging(level, max_entries) - Set server log level (DEBUG/INFO/WARNING/ERROR)
  - enable_traffic_log(port) - Capture TX/RX traffic on a port
  - spy:// URLs auto-enable traffic logging

## Device Watch
Watch for hot-plugged USB serial devices and capture boot output automatically.
- watch_usb_device(grep="CP210", baudrate=115200) - Watch for device, capture boot data
- watch_usb_device(vid="10C4", pid="EA60", capture_seconds=5) - Match by VID:PID
- cancel_watch() - Cancel an active watch (or all watches)

## Resources
- serial://server/info - Server version, repo links, connection count
- serial://ports - List available ports
- serial://{port}/data - Read data from open port
- serial://{port}/status - Port configuration and mode
- serial://{port}/raw - Read as hex dump
- serial://log - Server-wide log buffer
- serial://{port}/log - Per-port traffic log (if enabled)""",
)
