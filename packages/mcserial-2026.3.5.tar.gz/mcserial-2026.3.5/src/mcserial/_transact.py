"""The transact tool: send command + read response in one call."""

from __future__ import annotations

import time

import serial

from mcserial._helpers import _read_response, _resolve_line_ending
from mcserial._state import (
    TrafficEntry,
    _connections,
    _log,
    mcp,
)


@mcp.tool()
def transact(
    port: str,
    data: str,
    line_ending: str | None = None,
    response_timeout: float = 1.0,
    response_terminator: str | None = None,
    response_length: int | None = None,
    strip_echo: bool = False,
    encoding: str = "utf-8",
) -> dict:
    """Send a command and read its response in a single call (any mode).

    Combines write + read into one atomic operation, eliminating the need for
    separate write_serial, flush_serial, and read_serial calls. Works in all
    modes (RS-232, RS-422, and RS-485).

    For RS-485 with RTS direction control and turnaround delays, use
    rs485_transact() instead.

    Args:
        port: Device path of the port (must be open)
        data: Command string to send
        line_ending: Override line ending for this call. Accepts "cr", "lf", "crlf",
                     "none", or a literal string. If None, uses the port's default
                     line ending (set via configure_serial).
        response_timeout: Max time in seconds to wait for response (default 1.0)
        response_terminator: Stop reading when this sequence is received
        response_length: Expected response length in bytes (alternative to terminator)
        strip_echo: Remove the echoed command from the start of the response.
                    Useful for devices that echo back what you send.
        encoding: Character encoding (default: utf-8)

    Returns:
        Transaction result with sent/received data
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    try:
        sc = _connections[port]
        conn = sc.connection

        # Resolve line ending: explicit param > port default > none
        if line_ending is not None:
            resolved_ending = _resolve_line_ending(line_ending)
        else:
            resolved_ending = sc.default_line_ending

        send_data = data
        if resolved_ending:
            send_data = data + resolved_ending

        # Clear stale input data for a clean read
        conn.reset_input_buffer()

        # Send command
        try:
            encoded = send_data.encode(encoding)
        except (UnicodeEncodeError, LookupError) as e:
            return {"error": f"Encoding error: {e}", "success": False}
        bytes_written = conn.write(encoded)
        conn.flush()

        # Traffic capture TX
        if sc.traffic_log is not None:
            sc.traffic_log.append(TrafficEntry(
                timestamp=time.time(),
                direction="tx",
                data=encoded,
                encoding_used=encoding,
            ))
        _log("DEBUG", port, f"TX {bytes_written} bytes (transact)")

        # Read response with timeout
        original_timeout = conn.timeout
        conn.timeout = response_timeout

        try:
            raw_response = _read_response(
                conn, response_timeout, response_terminator, response_length, encoding,
            )
        finally:
            conn.timeout = original_timeout

        # Strip echoed command if requested
        if strip_echo and raw_response.startswith(encoded):
            raw_response = raw_response[len(encoded):]

        # Traffic capture RX
        if raw_response and sc.traffic_log is not None:
            sc.traffic_log.append(TrafficEntry(
                timestamp=time.time(),
                direction="rx",
                data=raw_response,
                encoding_used=encoding,
            ))
        if raw_response:
            _log("DEBUG", port, f"RX {len(raw_response)} bytes (transact)")

        return {
            "success": True,
            "port": port,
            "bytes_sent": bytes_written,
            "data_sent": data,
            "response": raw_response.decode(encoding, errors="replace"),
            "response_bytes": len(raw_response),
            "response_hex": raw_response.hex(),
        }

    except serial.SerialException as e:
        _log("ERROR", port, f"transact error: {e}")
        return {"error": str(e), "success": False}
