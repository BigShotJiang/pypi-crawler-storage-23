"""Validators, mode checks, and internal helper functions for mcserial."""

from __future__ import annotations

import time

import serial

from mcserial._state import (
    _LINE_ENDINGS,
    _connections,
)


def _resolve_line_ending(value: str | None) -> str | None:
    """Resolve a line ending value from a named alias or literal string.

    Accepts "cr", "lf", "crlf", "none", or a literal string like "\\r\\n".
    Returns None if value is None.
    """
    if value is None:
        return None
    return _LINE_ENDINGS.get(value.lower(), value)


def _detect_baud_rate_internal(
    port: str,
    probe: str | None = None,
    timeout_per_rate: float = 0.3,
    baudrates: list[int] | None = None,
) -> dict:
    """Internal baud rate detection (not exposed as MCP tool).

    Used by open_serial_port for auto-detection.
    """
    import math
    import time
    from collections import Counter

    # Common baud rates ordered by popularity
    default_rates = [
        115200, 9600, 57600, 38400, 19200,
        230400, 460800, 921600,
        4800, 2400, 1200,
    ]
    rates_to_try = baudrates or default_rates
    results = []

    def score_data(data: bytes) -> dict:
        """Score data readability with sync pattern analysis."""
        if not data:
            return {"score": 0, "bytes_received": 0}

        # Printable ASCII percentage
        printable = sum(1 for b in data if 32 <= b <= 126 or b in (9, 10, 13))
        printable_pct = (printable / len(data)) * 100

        # Line endings indicator
        has_newlines = b'\n' in data or b'\r' in data

        # Null byte penalty
        null_pct = (data.count(0x00) / len(data)) * 100

        # 0x55 sync pattern detection
        sync_count = sum(1 for b in data if b in (0x55, 0xAA))
        sync_pct = (sync_count / len(data)) * 100

        # Bit transitions (0x55 has 7 per byte)
        transitions = sum(
            sum(1 for i in range(7) if ((b >> i) & 1) != ((b >> (i + 1)) & 1))
            for b in data
        )
        avg_transitions = transitions / len(data)

        # Text clustering
        counter = Counter(data)
        text_cluster = sum(counter.get(b, 0) for b in range(0x20, 0x7F)) / len(data) * 100

        # Entropy calculation
        entropy = 0
        for count in counter.values():
            if count > 0:
                p = count / len(data)
                entropy -= p * math.log2(p)
        norm_entropy = (entropy / 8) * 100

        # Composite score
        score = printable_pct
        score += sync_pct * 0.5
        score += min(100, (avg_transitions / 7) * 100) * 0.2 if avg_transitions > 3 else 0
        score += text_cluster * 0.3
        if has_newlines:
            score += 15
        if null_pct > 30:
            score -= 40
        if norm_entropy > 70:
            score -= 20

        # UTF-8 bonus
        try:
            data.decode('utf-8')
            score += 10
        except UnicodeDecodeError:
            pass

        return {
            "score": round(max(0, min(100, score)), 1),
            "bytes_received": len(data),
        }

    for rate in rates_to_try:
        try:
            with serial.Serial(port=port, baudrate=rate, timeout=timeout_per_rate) as conn:
                if probe:
                    conn.write(probe.encode())
                    conn.flush()
                    time.sleep(0.05)

                time.sleep(timeout_per_rate)
                available = conn.in_waiting
                data = conn.read(available) if available else b""

                score_result = score_data(data)
                if score_result["bytes_received"] > 0:
                    results.append({"baudrate": rate, **score_result})

        except serial.SerialException:
            continue

    results.sort(key=lambda x: x["score"], reverse=True)
    best = results[0] if results else None

    return {
        "detected_baudrate": best["baudrate"] if best and best["score"] > 50 else None,
        "confidence": best["score"] if best else 0,
        "results": results[:5],
    }


def _validate_port_path(port: str) -> dict | None:
    """Validate that a port path looks like a serial device, not an arbitrary file.

    Returns error dict if invalid, None if OK.
    """
    import re
    # Reject path traversal attempts
    if ".." in port:
        return {
            "error": f"Invalid port path: {port}. Path traversal sequences are not allowed.",
            "success": False,
        }
    # Allow /dev/tty*, /dev/serial/*, COM ports, and pyserial URL schemes
    if re.match(r"^(/dev/(tty|serial)[A-Za-z0-9_/.-]+|COM\d+|[a-z]+://)", port):
        return None
    return {
        "error": f"Invalid port path: {port}. Expected a device path (/dev/ttyUSB0, COM3) or URL scheme (loop://).",
        "success": False,
    }


def _validate_file_path(file_path: str, operation: str = "read") -> dict | None:
    """Validate that a file path is safe for transfer operations.

    Rejects system directories to prevent accidental reads/writes to
    sensitive locations when an LLM caller is prompted to transfer files.

    Returns error dict if invalid, None if OK.
    """
    from pathlib import Path
    try:
        p = Path(file_path).resolve()
    except (OSError, ValueError) as e:
        return {"error": f"Invalid file path: {e}", "success": False}

    # Reject path traversal
    if ".." in str(Path(file_path)):
        return {
            "error": f"Path traversal not allowed: {file_path}",
            "success": False,
        }

    _FORBIDDEN_PREFIXES = ("/etc", "/usr", "/bin", "/sbin", "/boot", "/proc", "/sys", "/dev")
    resolved = str(p)
    for prefix in _FORBIDDEN_PREFIXES:
        if resolved == prefix or resolved.startswith(prefix + "/"):
            return {
                "error": f"Cannot {operation} files in system directory: {file_path}",
                "success": False,
            }
    return None


def _require_mode(port: str, required_mode: str | tuple[str, ...]) -> dict | None:
    """Check if port is in the required mode. Returns error dict if wrong mode.

    Args:
        port: Device path of the port to check.
        required_mode: A single mode string or tuple of acceptable modes.
    """
    if port not in _connections:
        return {"error": f"Port {port} is not open", "success": False}

    # Normalize to tuple for uniform handling
    allowed = (required_mode,) if isinstance(required_mode, str) else required_mode

    current_mode = _connections[port].mode
    if current_mode not in allowed:
        allowed_names = " or ".join(m.upper() for m in allowed)
        return {
            "error": f"Port {port} is in {current_mode.upper()} mode. "
                     f"This tool requires {allowed_names} mode. "
                     f"Use set_port_mode(port='{port}', mode='{allowed[0]}') to switch.",
            "success": False,
            "current_mode": current_mode,
            "required_mode": allowed[0] if len(allowed) == 1 else list(allowed),
            "hint": f"Switch to {allowed_names} mode to use this tool.",
        }
    return None  # Mode is correct


def _read_response(
    conn: serial.Serial,
    response_timeout: float,
    response_terminator: str | None,
    response_length: int | None,
    encoding: str,
) -> bytes:
    """Read a response from the serial port using terminator, length, or timeout fallback.

    Shared by transact() and rs485_transact() to avoid duplicating read logic.
    Caller is responsible for timeout save/restore.
    """
    if response_terminator:
        term_bytes = response_terminator.encode(encoding)
        return conn.read_until(term_bytes)
    elif response_length:
        return conn.read(response_length)
    else:
        # Poll until timeout expires, collecting all available data
        deadline = time.monotonic() + response_timeout
        collected = bytearray()
        while time.monotonic() < deadline:
            available = conn.in_waiting
            if available:
                collected.extend(conn.read(available))
                time.sleep(0.01)  # Brief pause to let more data arrive
            else:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                time.sleep(min(0.05, remaining))
        return bytes(collected)
