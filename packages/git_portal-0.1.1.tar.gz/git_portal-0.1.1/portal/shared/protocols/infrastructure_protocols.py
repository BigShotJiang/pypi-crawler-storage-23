"""Protocol definitions for infrastructure services."""

from __future__ import annotations

from pathlib import Path  # noqa: TCH003
from typing import Any, Protocol

from pydantic import BaseModel


class ShellResult(BaseModel):
    """Result from shell command execution."""

    success: bool
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0


class ShellExecutorProtocol(Protocol):
    """Protocol for executing shell commands."""

    async def execute(
        self,
        command: str,
        cwd: Path | None = None,
        env: dict[str, str] | None = None,
        capture_output: bool = True,
        timeout: int | None = None,
    ) -> ShellResult:
        """Execute a shell command.

        Args:
            command: Command to execute
            cwd: Working directory for command
            env: Environment variables
            capture_output: Whether to capture stdout/stderr
            timeout: Timeout in seconds

        Returns:
            ShellResult with execution details
        """
        ...


class FileSystemOperationsProtocol(Protocol):
    """Protocol for filesystem operations."""

    async def copy_file(self, source: Path, target: Path) -> bool:
        """Copy file from source to target.

        Args:
            source: Source file path
            target: Target file path

        Returns:
            True if successful
        """
        ...

    async def create_directory(self, path: Path) -> bool:
        """Create directory and any necessary parent directories.

        Args:
            path: Directory path to create

        Returns:
            True if successful
        """
        ...

    async def create_symlink(self, source: Path, target: Path) -> bool:
        """Create symbolic link from source to target.

        Args:
            source: Source path
            target: Symlink target path

        Returns:
            True if successful
        """
        ...

    async def update_env_file(self, file_path: Path, updates: dict[str, str]) -> bool:
        """Update environment file with new values.

        Args:
            file_path: Path to .env file
            updates: Dictionary of env var updates

        Returns:
            True if successful
        """
        ...

    async def make_executable(self, file_path: Path) -> bool:
        """Make file executable.

        Args:
            file_path: Path to file

        Returns:
            True if successful
        """
        ...


class TemplateEngineProtocol(Protocol):
    """Protocol for template processing."""

    async def render_to_file(
        self, template_path: Path, output_path: Path, context: dict[str, Any]
    ) -> bool:
        """Render template to file.

        Args:
            template_path: Path to template file
            output_path: Path for rendered output
            context: Template context variables

        Returns:
            True if successful
        """
        ...
