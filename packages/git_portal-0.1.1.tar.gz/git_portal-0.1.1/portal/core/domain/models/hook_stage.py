"""Hook stage definitions for the hook system."""

from enum import StrEnum


class HookStage(StrEnum):
    """Available hook stages for worktree operations."""

    PRE_CREATE = "pre_create"
    POST_CREATE = "post_create"
    PRE_DELETE = "pre_delete"
    POST_DELETE = "post_delete"
    PRE_SWITCH = "pre_switch"
    POST_SWITCH = "post_switch"
    PRE_LIST = "pre_list"
    POST_LIST = "post_list"
