"""Condition models for hook execution."""

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class ConditionType(StrEnum):
    """Types of conditions."""

    FILE_EXISTS = "file_exists"
    FILE_NOT_EXISTS = "file_not_exists"
    DIR_EXISTS = "dir_exists"
    ENV_VAR = "env"
    PLATFORM = "platform"
    COMMAND_SUCCESS = "command_success"


class Condition(BaseModel):
    """Condition for hook execution."""

    type: ConditionType
    value: Any
    negate: bool = Field(False, description="Negate the condition")

    @classmethod
    def parse(cls, condition_str: str) -> "Condition":
        """Parse condition string like 'file_exists:package.json'.

        Examples:
            - 'file_exists:package.json' -> Check if package.json exists
            - '!file_exists:package.json' -> Check if package.json does NOT exist
            - 'platform:darwin' -> Check if platform is macOS
            - 'env:CI=true' -> Check if CI env var equals 'true'
            - 'MY_VAR' -> Check if MY_VAR env var exists
        """
        if ":" in condition_str:
            type_str, value = condition_str.split(":", 1)
            negate = type_str.startswith("!")
            if negate:
                type_str = type_str[1:]

            return cls(type=ConditionType(type_str), value=value, negate=negate)
        else:
            # Simple boolean condition - assume it's an env var check
            return cls(type=ConditionType.ENV_VAR, value=condition_str, negate=False)
