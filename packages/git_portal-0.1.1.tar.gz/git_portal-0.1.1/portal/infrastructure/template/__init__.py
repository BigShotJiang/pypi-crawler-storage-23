"""Template processing infrastructure."""

from .template_engine import TemplateEngine

__all__ = ["TemplateEngine"]
