"""Integration event handling infrastructure."""

from .event_handlers import IntegrationEventHandler

__all__ = ["IntegrationEventHandler"]
