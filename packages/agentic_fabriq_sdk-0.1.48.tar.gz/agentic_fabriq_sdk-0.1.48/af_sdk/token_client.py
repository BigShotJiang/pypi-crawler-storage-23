"""
Token Client for Agentic Fabric SDK.

Provides a high-level client for interacting with the Agentic Fabric Token Broker
using JSON-RPC 2.0. Returns OAuth tokens + API metadata instead of executing calls.

The agent/developer receives the token and makes the actual HTTP call to the provider.

Usage:
    # Using CLI stored credentials (user ran 'afctl auth login')
    async with TokenClient(method="cli", app_id="myapp", app_secret="sk_xxx") as client:
        tools = await client.list_tools()
        token_info = await client.get_token("google_gmail_list_messages", {"maxResults": 5})
        
        # Make the actual API call yourself
        response = requests.get(
            token_info["api_call"]["full_url"],
            headers=token_info["api_call"]["headers"]
        )

    # Using Keycloak token directly (from agent's auth flow)
    async with TokenClient(
        method="keycloak",
        app_id="myapp",
        app_secret="sk_xxx",
        keycloak_token="eyJhbGc..."
    ) as client:
        token_info = await client.get_token("slack_send_message", {"channel": "#general", "text": "Hello"})
        
        # token_info contains everything you need to make the API call

    # Using external IdP token (e.g., Okta SSO)
    async with TokenClient(
        method="idp",
        app_id="myapp",
        app_secret="sk_xxx",
        external_token="eyJhbGc..."
    ) as client:
        token_info = await client.get_token("github_list_repos", {})
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional

import httpx

from .exceptions import (
    AuthenticationError,
    MCPConnectionError,
    MCPError,
)
from .auth.credentials import (
    load_stored_credentials,
    exchange_keycloak_for_af_token,
    AFTokenResponse,
)
from .auth.applications import exchange_okta_for_af_token

logger = logging.getLogger(__name__)

# Type alias for authentication method
AuthMethod = Literal["keycloak", "cli", "individual", "idp"]


@dataclass
class TokenInfo:
    """Token and API metadata returned by Token Broker."""
    
    access_token: str
    token_type: str
    expires_in: int
    expires_at: Optional[str]
    provider: str
    scopes: List[str]
    
    # API call specification
    method: str
    base_url: str
    endpoint: str
    full_url: str
    headers: Dict[str, str]
    query_params: Dict[str, Any]
    body_template: Optional[Dict[str, Any]]
    body_instructions: Optional[str]
    example_curl: str
    
    @classmethod
    def from_response(cls, data: Dict[str, Any]) -> "TokenInfo":
        """Create TokenInfo from Token Broker response."""
        token = data.get("token", data)
        api_call = token.get("api_call", {})
        
        return cls(
            access_token=token.get("access_token", ""),
            token_type=token.get("token_type", "Bearer"),
            expires_in=token.get("expires_in", 0),
            expires_at=token.get("expires_at"),
            provider=token.get("provider", ""),
            scopes=token.get("scopes", []),
            method=api_call.get("method", "GET"),
            base_url=api_call.get("base_url", ""),
            endpoint=api_call.get("endpoint", ""),
            full_url=api_call.get("full_url", ""),
            headers=api_call.get("headers", {}),
            query_params=api_call.get("query_params", {}),
            body_template=api_call.get("body_template"),
            body_instructions=api_call.get("body_instructions"),
            example_curl=token.get("example_curl", ""),
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "access_token": self.access_token,
            "token_type": self.token_type,
            "expires_in": self.expires_in,
            "expires_at": self.expires_at,
            "provider": self.provider,
            "scopes": self.scopes,
            "api_call": {
                "method": self.method,
                "base_url": self.base_url,
                "endpoint": self.endpoint,
                "full_url": self.full_url,
                "headers": self.headers,
                "query_params": self.query_params,
                "body_template": self.body_template,
                "body_instructions": self.body_instructions,
            },
            "example_curl": self.example_curl,
        }


class TokenClient:
    """
    Async/sync client for Agentic Fabric Token Broker.
    
    Returns OAuth tokens and API metadata instead of executing tool calls.
    The agent/developer makes the actual HTTP call to the provider.
    
    Authentication Methods:
        - "cli": Uses stored credentials from 'afctl auth login' (no token needed)
        - "keycloak": Pass a Keycloak token directly via keycloak_token parameter
        - "idp": Pass an external IdP token (e.g., Okta) via external_token parameter
    
    Args:
        method: Authentication method
        app_id: Application ID from afctl activation
        app_secret: Application secret from afctl activation
        keycloak_token: Keycloak JWT token (required when method="keycloak")
        external_token: External IdP token like Okta (required when method="idp")
        org_url: Organization URL for IdP auth
        broker_url: Token Broker URL (default: staging)
        gateway_url: Gateway URL for token exchange (default: staging)
        timeout: Request timeout in seconds (default: 60)
    
    Example:
        >>> async with TokenClient(
        ...     method="cli",
        ...     app_id="org-xxx_myapp",
        ...     app_secret="sk_xxx..."
        ... ) as client:
        ...     # List available tools
        ...     tools = await client.list_tools()
        ...     print(f"Available: {client.tool_names}")
        ...     
        ...     # Get token for a specific tool
        ...     token_info = await client.get_token(
        ...         "google_gmail_list_messages",
        ...         {"maxResults": 10}
        ...     )
        ...     
        ...     # Make the API call yourself
        ...     import requests
        ...     response = requests.get(
        ...         token_info.full_url,
        ...         headers=token_info.headers
        ...     )
        ...     print(response.json())
    """
    
    # Default URLs
    DEFAULT_BROKER_URL = "https://dashboard.agenticfabriq.com/tokens"
    DEFAULT_GATEWAY_URL = "https://dashboard.agenticfabriq.com"
    
    def __init__(
        self,
        *,
        method: AuthMethod,
        app_id: str,
        app_secret: str,
        keycloak_token: Optional[str] = None,
        external_token: Optional[str] = None,
        org_url: Optional[str] = None,
        broker_url: Optional[str] = None,
        gateway_url: Optional[str] = None,
        timeout: float = 60.0,
    ) -> None:
        # Validate method
        if method not in ("keycloak", "cli", "individual", "idp"):
            raise ValueError(
                f"Invalid method '{method}'. Must be 'cli', 'keycloak', or 'idp'"
            )
        
        # Validate token requirements based on method
        if method == "keycloak" and not keycloak_token:
            raise ValueError("keycloak_token is required when method='keycloak'")
        if method == "idp" and not external_token:
            raise ValueError("external_token is required when method='idp'")
        
        self._method = method
        self._app_id = app_id
        self._app_secret = app_secret
        self._keycloak_token = keycloak_token
        self._external_token = external_token
        self._org_url = org_url
        self._broker_url = (broker_url or self.DEFAULT_BROKER_URL).rstrip("/")
        self._gateway_url = (gateway_url or self.DEFAULT_GATEWAY_URL).rstrip("/")
        self._timeout = timeout
        
        # Internal state
        self._http_client: Optional[httpx.AsyncClient] = None
        self._af_token: Optional[str] = None
        self._af_token_response: Optional[AFTokenResponse] = None
        self._tools: List[Dict[str, Any]] = []
        self._request_id: int = 0
        
        # Event loop management for sync wrappers
        self._loop: Optional[asyncio.AbstractEventLoop] = None
    
    # -------------------------------------------------------------------------
    # Properties
    # -------------------------------------------------------------------------
    
    @property
    def is_connected(self) -> bool:
        """Check if the client is connected."""
        return self._http_client is not None
    
    @property
    def tool_names(self) -> List[str]:
        """Get list of available tool names."""
        return [t.get("name", "") for t in self._tools]
    
    @property
    def token_info(self) -> Optional[AFTokenResponse]:
        """Get the AF token response with metadata."""
        return self._af_token_response
    
    # -------------------------------------------------------------------------
    # Context Managers
    # -------------------------------------------------------------------------
    
    async def __aenter__(self) -> "TokenClient":
        """Async context manager entry."""
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.disconnect()
    
    def __enter__(self) -> "TokenClient":
        """Sync context manager entry."""
        self.connect_sync()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Sync context manager exit."""
        self.disconnect_sync()
    
    # -------------------------------------------------------------------------
    # Connection Management
    # -------------------------------------------------------------------------
    
    async def connect(self) -> None:
        """
        Connect to the Token Broker.
        
        Authenticates based on the configured method and verifies the connection
        by fetching the available tools.
        
        Raises:
            AuthenticationError: If authentication fails
            MCPConnectionError: If connection to Token Broker fails
        """
        # Get AF token via authentication
        self._af_token = await self._authenticate()
        
        if not self._af_token:
            raise AuthenticationError("Token exchange returned empty token")
        
        # Create HTTP client
        self._http_client = httpx.AsyncClient(
            timeout=self._timeout,
            follow_redirects=True,
        )
        
        # Verify connection by listing tools
        try:
            self._tools = await self.list_tools()
            logger.info(
                f"Connected to Token Broker. {len(self._tools)} tools available."
            )
        except Exception as e:
            await self.disconnect()
            raise MCPConnectionError(f"Failed to connect to Token Broker: {e}") from e
    
    async def disconnect(self) -> None:
        """Disconnect from the Token Broker."""
        if self._http_client is not None:
            await self._http_client.aclose()
            self._http_client = None
        
        self._af_token = None
        logger.info("Disconnected from Token Broker.")
    
    # -------------------------------------------------------------------------
    # Sync Wrappers
    # -------------------------------------------------------------------------
    
    def _get_or_create_loop(self) -> asyncio.AbstractEventLoop:
        """Get existing event loop or create a new one."""
        try:
            loop = asyncio.get_event_loop()
            if loop.is_closed():
                raise RuntimeError("Loop closed")
            return loop
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            self._loop = loop
            return loop
    
    def connect_sync(self) -> None:
        """Synchronous version of connect()."""
        loop = self._get_or_create_loop()
        loop.run_until_complete(self.connect())
    
    def disconnect_sync(self) -> None:
        """Synchronous version of disconnect()."""
        loop = self._get_or_create_loop()
        loop.run_until_complete(self.disconnect())
    
    def list_tools_sync(self) -> List[Dict[str, Any]]:
        """Synchronous version of list_tools()."""
        loop = self._get_or_create_loop()
        return loop.run_until_complete(self.list_tools())
    
    def get_token_sync(
        self,
        tool_name: str,
        arguments: Optional[Dict[str, Any]] = None,
    ) -> TokenInfo:
        """Synchronous version of get_token()."""
        loop = self._get_or_create_loop()
        return loop.run_until_complete(self.get_token(tool_name, arguments))
    
    # -------------------------------------------------------------------------
    # Token Broker Methods
    # -------------------------------------------------------------------------
    
    async def list_tools(self) -> List[Dict[str, Any]]:
        """
        List available tools from Token Broker.
        
        Returns:
            List of tool definitions with name, description, and inputSchema
            
        Raises:
            MCPError: If the Token Broker returns an error
            MCPConnectionError: If not connected
        """
        result = await self._jsonrpc_request("tools/list")
        
        tools = result.get("tools", []) if isinstance(result, dict) else result
        
        self._tools = [
            {
                "name": t.get("name"),
                "description": t.get("description"),
                "inputSchema": t.get("inputSchema"),
            }
            for t in tools
        ]
        
        return self._tools
    
    async def get_token(
        self,
        tool_name: str,
        arguments: Optional[Dict[str, Any]] = None,
    ) -> TokenInfo:
        """
        Get OAuth token and API metadata for a tool.
        
        Unlike MCP's call_tool which executes the API call, this returns
        the token and all the information needed to make the call yourself.
        
        Args:
            tool_name: Tool name (e.g., "google_gmail_list_messages")
            arguments: Tool arguments as a dictionary
            
        Returns:
            TokenInfo with access_token, headers, full_url, etc.
            
        Raises:
            MCPError: If the Token Broker returns an error
            MCPConnectionError: If not connected
            
        Example:
            >>> token_info = await client.get_token(
            ...     "google_gmail_list_messages",
            ...     {"maxResults": 10, "q": "is:unread"}
            ... )
            >>> # Now make the API call yourself
            >>> response = requests.get(
            ...     token_info.full_url,
            ...     headers=token_info.headers
            ... )
        """
        result = await self._jsonrpc_request(
            "tools/call",
            params={
                "name": tool_name,
                "arguments": arguments or {},
            },
        )
        
        # Extract content from result
        content = result.get("content", []) if isinstance(result, dict) else result
        
        if not content:
            raise MCPError("Empty response from Token Broker")
        
        # First content item should be the token
        token_data = content[0] if isinstance(content, list) else content
        
        # Check for error
        if token_data.get("type") == "error":
            raise MCPError(token_data.get("error", "Unknown error"))
        
        return TokenInfo.from_response(token_data)
    
    # -------------------------------------------------------------------------
    # Convenience Methods
    # -------------------------------------------------------------------------
    
    def get_tools(self) -> List[Dict[str, Any]]:
        """Get cached tools list without making a network call."""
        return self._tools
    
    def get_tool(self, name: str) -> Optional[Dict[str, Any]]:
        """Get a specific tool by name from the cache."""
        for tool in self._tools:
            if tool.get("name") == name:
                return tool
        return None
    
    def has_tool(self, name: str) -> bool:
        """Check if a tool exists in the cache."""
        return self.get_tool(name) is not None
    
    # -------------------------------------------------------------------------
    # Internal Methods
    # -------------------------------------------------------------------------
    
    async def _authenticate(self) -> str:
        """
        Authenticate and get AF token based on configured method.
        
        Returns:
            AF access token string
            
        Raises:
            AuthenticationError: If authentication fails
        """
        token_for_exchange: Optional[str] = None
        
        if self._method in ("cli", "individual"):
            creds = load_stored_credentials()
            if creds is None:
                raise AuthenticationError(
                    "Not logged in. Please run 'afctl auth login' first."
                )
            if creds.is_expired:
                raise AuthenticationError(
                    "Token expired. Please run 'afctl auth login' again."
                )
            token_for_exchange = creds.access_token
            logger.info("Using stored CLI credentials")
            
        elif self._method == "keycloak":
            token_for_exchange = self._keycloak_token
            logger.info("Using provided Keycloak token")
                
        elif self._method == "idp":
            token_for_exchange = self._external_token
            logger.info("Using provided external IdP token")
        
        if not token_for_exchange:
            raise AuthenticationError("Failed to obtain authentication token")
        
        # Exchange for AF token
        if self._method == "idp":
            af_token = await exchange_okta_for_af_token(
                okta_token=token_for_exchange,
                app_id=self._app_id,
                app_secret=self._app_secret,
                org_url=self._org_url,
                gateway_url=self._gateway_url,
            )
            self._af_token_response = AFTokenResponse(
                access_token=af_token,
                expires_in=3600,
                token_type="Bearer",
            )
            logger.info(f"Authenticated via IdP for app_id={self._app_id}")
        else:
            self._af_token_response = await exchange_keycloak_for_af_token(
                keycloak_token=token_for_exchange,
                app_id=self._app_id,
                secret_key=self._app_secret,
                gateway_url=self._gateway_url,
            )
            logger.info(
                f"Authenticated as user_id={self._af_token_response.user_id}, "
                f"app_id={self._af_token_response.app_id}"
            )
        
        return self._af_token_response.access_token
    
    async def _jsonrpc_request(
        self,
        method: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Send a JSON-RPC 2.0 request to the Token Broker."""
        if self._http_client is None:
            raise MCPConnectionError(
                "Not connected. Call connect() first or use context manager."
            )
        
        self._request_id += 1
        payload: Dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
            "id": self._request_id,
        }
        if params:
            payload["params"] = params
        
        logger.debug(f"Token Broker request: {method} (id={self._request_id})")
        
        try:
            request_headers = {
                "Authorization": f"Bearer {self._af_token}",
                "Content-Type": "application/json",
            }
            
            response = await self._http_client.post(
                self._broker_url,
                json=payload,
                headers=request_headers,
            )
            
            if response.status_code != 200:
                raise MCPConnectionError(
                    f"Token Broker returned HTTP {response.status_code}: {response.text}"
                )
            
            data = response.json()
            
            if "error" in data:
                error = data["error"]
                raise MCPError(
                    message=error.get("message", "Unknown error"),
                    code=error.get("code"),
                    data=error.get("data"),
                )
            
            return data.get("result", data)
                
        except httpx.RequestError as e:
            raise MCPConnectionError(f"Network error: {e}") from e
    
    def __repr__(self) -> str:
        status = "connected" if self.is_connected else "disconnected"
        return (
            f"TokenClient(method={self._method!r}, app_id={self._app_id!r}, "
            f"broker_url={self._broker_url!r}, status={status})"
        )
