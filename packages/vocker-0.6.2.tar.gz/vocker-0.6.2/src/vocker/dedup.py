from __future__ import annotations

import abc
import datetime
from collections import defaultdict
import contextlib
import filelock
import io
import json
import os
from pathlib import Path
import shutil
import stat
import threading
import time

import typing as ty
import attr
import structlog
import concurrent.futures as cf

import sqlalchemy as sa
from sqlalchemy import orm as sao, literal_column as _lit
from sqlalchemy_boltons import sqlite as sq
from sqlalchemy_boltons.orm import RelationshipComparator as Rel, IdKey
from sqlalchemy_boltons.core import bytes_startswith, count
from boltons.iterutils import chunked_iter
from cached_property import cached_property

from .integer_to_path import IntegerToPath, InvalidPathError
from .util import pathwalk, random_names, create_file_random, supports_executable
from . import dedup_models as mo
from . import multihash as mh


logger = structlog.get_logger(__name__)


@attr.s(eq=False, hash=False)
class Corrupted:
    path: Path | None = attr.ib()
    file_id: int = attr.ib()
    exception_name: str = attr.ib()
    exception_string: str = attr.ib()
    link_paths: tuple[Path, ...] = attr.ib()
    raw_link_paths: tuple[bytes, ...] = attr.ib()

    def to_json(self):
        d = attr.asdict(self)
        d["path"] = p if (p := d["path"]) is None else str(p)

        d["link_paths"] = [str(x) for x in d["link_paths"]]
        d["link_paths"].sort()

        # JSON cannot handle raw bytes
        d["raw_link_paths"] = [x.decode("iso-8859-1") for x in d["raw_link_paths"]]
        d["raw_link_paths"].sort()

        return d


@attr.s(eq=False, hash=False, kw_only=True)
class DedupFileMetadata:
    executable: bool = attr.ib(default=False)

    @classmethod
    def make_plain(cls):
        return cls(executable=False)


@attr.s(eq=False, hash=False, auto_exc=True)
class InvalidContentsError(Exception):
    message = attr.ib(default="file contents do not match hash")
    link_request: DedupLinkRequest | None = attr.ib(default=None)
    hashes_expected: dict[mh.HashFunction, mh.Digest] | None = attr.ib(default=None)
    hashes_observed: dict[mh.HashFunction, mh.Digest] | None = attr.ib(default=None)


@attr.s(eq=False, hash=False, auto_exc=True)
class BatchError(Exception):
    message = attr.ib(default="at least one of the DedupLinkRequests failed")
    requests: list[DedupRequest] | None = attr.ib(default=None)


class NotADedupLinkError(Exception):
    pass


class MissingContentError(Exception):
    pass


@attr.s(eq=False, hash=False, kw_only=True)
class DedupRequest:
    success: bool = attr.ib(init=False, default=False)
    exc: Exception | None = attr.ib(init=False, default=None)

    def result(self):
        if self.exc is not None:
            raise self.exc
        return self.success


@attr.s(eq=False, hash=False, kw_only=True)
class DedupLinkRequest(DedupRequest):
    """
    Represents a single request to link a deduped file at a filesystem location :attr:`link_path`.
    If the file is already in the dedup folder, then link it. Otherwise add it to the dedup folder
    by first getting its contents from :attr:`open_file_once`. These requests are batched and
    executed together.

    If a file already exists at :attr:`link_path`, then it will be removed before linking. If it is
    a directory, then an exception will be raised.

    The :attr:`open_file_once` function will be called *at most* once. If a deduplicated file
    already exists in the dedup folder with the same :attr:`file_contents_hash` and equal or
    equivalent :attr:`file_metadata`, then it will be reused and the :attr:`open_file_once` function
    will not be called at all.

    The :attr:`open_file_once` function should an open file handle from which the file contents can
    be read. If :attr:`open_file_once` is None, then the link request will be silently
    discarded.

    Each :attr:`open_file_once` function will be called in the order it appears in a batch of
    requests. This guarantee supports the use case of directly decompressing a
    [solid archive](https://en.wikipedia.org/wiki/Solid_archive), in which case file contents
    become available in a sequential manner as the archive is decompressed and it is impossible
    to efficiently access files in a random order.

    The file contents hash will be (over)written to :attr:`file_contents_hash`.

    The :attr:`tags` argument is used as a sort of label that can be used to refer to a deduplicated
    file. If there exists another deduplicated file that shares at least one tag with :attr:`tags`,
    then that deduplicated file will be used. That existing deduplicated file will be used
    regardless of the :attr:`file_contents_hash`.

    If :attr:`file_contents_hash` is None and no matching :attr:`tags` was found,
    then :attr:`open_file_once` will always be called. Without the content hash, we have no way
    of checking whether a deduplicated file with the same hash exists.
    """

    hash_function: mh.HashFunction = attr.ib()
    link_path: Path | None = attr.ib()
    file_metadata: DedupFileMetadata = attr.ib()
    file_contents_hash: mh.Digest | None = attr.ib()
    open_file_once: ty.Callable[[], ty.BinaryIO] | None = attr.ib()
    adopt_existing: bool = attr.ib(default=False)
    file_not_needed: ty.Callable[[], None] | None = attr.ib(default=None)
    tags: ty.Set[bytes] = attr.ib(factory=frozenset)

    @classmethod
    def from_content(cls, content: bytes, **kwargs):
        kwargs.setdefault("open_file_once", None)
        kwargs.setdefault("file_contents_hash", None)
        return cls(**kwargs).set_content(content)

    def set_content(self, content: bytes):
        self.file_contents_hash = self.hash_function().update(content).digest()
        self.open_file_once = lambda: io.BytesIO(content)
        return self


@attr.s(eq=False, hash=False, kw_only=True)
class _ImplDedupRequestCommon:
    index: int = attr.ib()
    failed: bool = attr.ib(default=False)

    @abc.abstractmethod
    def set_failed(self, exc): ...


@attr.s(eq=False, hash=False, kw_only=True)
class _ImplDedupLinkRequest(_ImplDedupRequestCommon):
    req: DedupLinkRequest = attr.ib(default=None)
    obj: _Obj | None = attr.ib(default=None)
    link_path_str: bytes | None = attr.ib(default=None)
    metadata_bytes: bytes | None = attr.ib(default=None)
    hashes_promised: dict[mh.HashFunction, mh.Digest] = attr.ib(default=None)
    hashes_computed: dict[mh.HashFunction, mh.Digest] | None = attr.ib(default=None)
    called_file: bool = attr.ib(default=False)

    def set_failed(self, exc):
        self.req.exc = exc
        self.failed = True
        self.call_file_not_needed()

    def call_file_not_needed(self) -> None:
        if not self.called_file:
            if (f := self.req.file_not_needed) is not None:
                try:
                    f()
                except Exception:
                    logger.warning("uncaught exception", exc_info=True)
            self.called_file = True

    def call_open_file_once(self):
        if self.called_file:
            raise AssertionError
        try:
            return self.req.open_file_once()
        finally:
            self.called_file = True


@attr.s(eq=False, hash=False)
class DedupCopyLinkRequest(DedupRequest):
    src: Path = attr.ib()
    dst: Path = attr.ib()


@attr.s(eq=False, hash=False, kw_only=True)
class _ImplDedupCopyLinkRequest(_ImplDedupRequestCommon):
    req: DedupCopyLinkRequest = attr.ib()
    src_str: str = attr.ib(default=None)
    dst_str: str = attr.ib(default=None)
    dedup_file_path: Path = attr.ib(default=None)

    def set_failed(self, exc):
        self.req.exc = exc
        self.failed = True


@attr.s(eq=False, hash=False)
class AdoptRequest:
    path: Path = attr.ib()
    tags: ty.Set[bytes] = attr.ib(factory=frozenset)


@attr.s(eq=False, slots=True)
class _Obj:
    id: int = attr.ib(factory=None)
    pending_file_ids = attr.ib(factory=list)
    completed_file_ids = attr.ib(factory=list)
    file_size: int | None = attr.ib(default=None)
    adopted_file_path: Path | None = attr.ib(default=None)


@attr.s(eq=False, slots=True)
class _Updates:
    obj_updates = attr.ib(factory=list)
    file_updates = attr.ib(factory=list)
    link_updates = attr.ib(factory=list)


"""
@attr.s(eq=False, hash=False)
class DedupUnlinkRequest(DedupRequest):
    link_path: Path = attr.ib()
"""


class DedupError:
    pass


@attr.s(frozen=True)
class DedupStats:
    dedup_count: int = attr.ib()
    orphaned_count: int = attr.ib()
    link_count: int = attr.ib()
    dedup_total_bytes: int = attr.ib()
    orphaned_total_bytes: int = attr.ib()
    link_total_bytes: int = attr.ib()

    def to_json(self):
        return attr.asdict(self)


@attr.s(frozen=True)
class DedupFile:
    pass


@attr.s(eq=False, hash=False)
class _PendingUpdater:
    sessionmaker_r: sao.sessionmaker = attr.ib()
    sessionmaker_w: sao.sessionmaker = attr.ib()
    pending: IdKey[mo.Pending] = attr.ib()
    seconds_in_the_future: int = attr.ib()
    update_interval: float = attr.ib(default=None)
    _should_exit = False
    update_on_exit: bool = attr.ib(default=False)

    def __attrs_post_init__(self):
        if self.update_interval is None:
            self.update_interval = (self.seconds_in_the_future - 3) / 2

        if (u := self.update_interval) < 1:
            raise ValueError(f"invalid update_interval={u!r}")

    def _update(self):
        with self.sessionmaker_w.begin() as s:
            pending: mo.Pending = self.pending.get_one(s)
            pending.expire_at = mo.now() + self.seconds_in_the_future

    def _thread_target(self):
        while not self._should_exit:
            t = self.update_interval
            try:
                self._update()
            except Exception:
                logger.warning("failed to update pending", exc_info=True)
                t = 1  # try again soon
            self._event.wait(t)
            self._event.clear()
        if self.update_on_exit:
            self._update()

    def start(self):
        self._should_exit = False
        self._event = threading.Event()
        self._thread = t = threading.Thread(target=self._thread_target)
        t.start()

    def stop(self):
        self._should_exit = True
        self._event.set()
        self._thread.join()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.stop()


class SkippedReqException(Exception):
    pass


def make_sqlite_options(synchronous):
    return sq.Options.new(
        timeout=60.0,
        begin="DEFERRED",
        foreign_keys="DEFERRED",
        recursive_triggers=True,
        trusted_schema=True,
        schemas={"main": sq.SchemaOptions.new(journal="WAL", synchronous=synchronous)},
    )


def _ns(stmt):
    return stmt.execution_options(synchronize_session=False)


@attr.s(eq=False, hash=False)
class Dedup(abc.ABC):
    base_path: Path = attr.ib()
    extra_hashes: ty.Set[mh.HashFunction] = attr.ib(
        factory=lambda: {mh.registry.name_to_hash["sha2-256"]}
    )
    _path_dedup: Path | None = attr.ib(default=None, kw_only=True)
    _path_db: Path | None = attr.ib(default=None, kw_only=True)
    path_temporary: Path | None = attr.ib(default=None, kw_only=True)
    path_deleted: Path | None = attr.ib(default=None, kw_only=True)
    _integer_to_path = attr.ib(factory=IntegerToPath, kw_only=True)
    _sqlite_synchronous = attr.ib(default="NORMAL", kw_only=True)
    _batch_size = 1000
    max_link_count: int = ...
    _clean_dedup_mtime = (
        round(datetime.datetime(2000, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc).timestamp()) & ~1
    )
    _corrupted_pending_id = -1  # reserved ID

    def __attrs_post_init__(self):
        if self._path_dedup is None:
            self._path_dedup = self.base_path / "f"

        if self._path_db is None:
            self._path_db = self.base_path / "dedup.db"

        if self.path_deleted is None:
            self.path_deleted = self.base_path / "deleted"

        if self.path_temporary is None:
            self.path_temporary = self.base_path / "tmp"

        self._beginw_lock = threading.RLock()
        self._path_dedup.mkdir(exist_ok=True, parents=True)
        self._path_db.parent.mkdir(exist_ok=True, parents=True)
        self.path_deleted.mkdir(exist_ok=True, parents=True)
        self._path_temporary_dirs.mkdir(exist_ok=True, parents=True)
        self._path_temporary_lock.mkdir(exist_ok=True, parents=True)
        self._path_temporary_simple_dir.mkdir(exist_ok=True, parents=True)
        engine = sq.create_engine_sqlite(self._path_db, create_engine_args=dict(echo=False))
        engine = make_sqlite_options(synchronous=self._sqlite_synchronous).apply(engine)
        self._engine_r = engine
        self._engine_w = sq.Options.apply_lambda(engine, lambda x: x.evolve(begin="IMMEDIATE"))

        self._SessionR = sao.sessionmaker(self._engine_r)
        self._SessionW = sao.sessionmaker(self._engine_w)

        self._initialize_db()

    def _initialize_db(self):
        """Initialize the database schema."""
        with self._engine_w.connect() as conn:
            mo.BaseDedup.metadata.create_all(conn)
            conn.commit()

        with self._beginw() as s:
            if s.get(mo.Pending, self._corrupted_pending_id) is None:
                s.add(mo.Pending(id=self._corrupted_pending_id, expire_at=1))

    @contextlib.contextmanager
    def _beginw(self):
        with self._beginw_lock, self._SessionW.begin() as s:
            s.connection()  # ensure the transaction is started
            yield s

    def apply_metadata_to_file(self, path: Path, metadata: DedupFileMetadata) -> None:
        if supports_executable():
            mode = path.lstat().st_mode
            if not stat.S_ISDIR(mode) and bool(stat.S_IXUSR & mode) != metadata.executable:
                mask = stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
                new_mode = mode & ~mask
                if metadata.executable:
                    new_mode |= mask
                os.chmod(str(path), new_mode, follow_symlinks=False)

    def _set_clean_file_mtime(self, path: Path) -> None:
        t = self._clean_dedup_mtime
        os.utime(path, (t, t))

    def get_metadata_from_file(self, path: Path) -> DedupFileMetadata:
        if supports_executable():
            mode = path.stat().st_mode
            if not stat.S_ISREG(mode):
                raise AssertionError
            return DedupFileMetadata(executable=bool(stat.S_IXUSR & mode))
        else:
            return DedupFileMetadata(executable=False)

    def convert_file_metadata_to_bytes(self, metadata: DedupFileMetadata) -> bytes:
        # TODO: make it platform-dependent whether we care about the executable bit
        return b"x=" + str(int(metadata.executable)).encode("ascii")

    def _link_path_to_string(self, p: Path) -> bytes:
        return str(p).encode("utf-8")

    def _link_path_from_string(self, data: bytes) -> Path:
        return Path(data.decode("utf-8"))

    @contextlib.contextmanager
    def _ignore_skip(self):
        try:
            yield
        except SkippedReqException:
            pass

    @contextlib.contextmanager
    def _catch_req_exc(self, r: _ImplDedupLinkRequest | _ImplDedupCopyLinkRequest):
        if r.failed:
            raise SkippedReqException from None
        try:
            yield
        except Exception as exc:
            r.set_failed(exc)
            raise SkippedReqException from None

    def _cfg_hash_functions_get(self, s: sao.Session):
        # TODO: not used yet
        if (cfg := s.get(mo.DedupConfig, "hashes")) is None:
            h = self._DEFAULT_HASHES
        else:
            h = json.loads(cfg.value)

        return [mh.registry.name_to_hash[name] for name in h]

    def _cfg_hash_functions_set(self, s: sao.Session, hashes: list[mh.HashFunction]):
        # TODO: not used yet
        if (cfg := s.get(mo.DedupConfig, "hashes")) is None:
            cfg = mo.DedupConfig(key="hashes", value="")
        cfg.value = json.dumps([h.name for h in hashes])

    def _make_dedup_file(self, link: _ImplDedupLinkRequest, pending=None):
        f = mo.Hash.from_digest
        return mo.DedupFile(
            file_metadata=link.metadata_bytes,
            size=0,
            mtime=0,
            orphaned_at=None,
            pending=pending,
            hashes=[f(h) for h in link.hashes_promised.values()],
        )

    def _tmp_sqlite(self, tmp):
        with self._SessionR() as s:
            return tmp.get(s, "").value

    @cached_property
    def _tmp_files(self):
        return self._tmp_sqlite(mo.tmp_new_files)

    @cached_property
    def _tmp_files2(self):
        return self._tmp_sqlite(mo.tmp_new_files2)

    @cached_property
    def _tmp_check_links(self):
        return self._tmp_sqlite(mo.tmp_check_links)

    @cached_property
    def _tmp_delete_extra(self):
        return self._tmp_sqlite(mo.tmp_delete_extra)

    @cached_property
    def _sql_prebatch_check_link(self):
        L = sao.aliased(mo.Link)
        return count(L).where(L.path == sa.bindparam("p_path"))

    @cached_property
    def _sql_prebatch_update_with_existing_dedup_files(self):
        tmp = self._tmp_files
        ONE = _lit("1")

        def _eq(x, y, attributes):
            return sa.and_(getattr(x, a) == getattr(y, a) for a in attributes)

        O = sao.aliased(mo.Obj, name="obj")
        tmp_f = sao.aliased(tmp.files, name="t_file")
        tmp_tag = sao.aliased(tmp.tags, name="t_tag")
        tmp_hash = sao.aliased(tmp.hashes, name="t_hash")
        Tag = sao.aliased(mo.Tag, name="tag")
        Hash = sao.aliased(mo.Hash, name="hash")
        cond_obj = O.q_is_complete() | (O.pending_id == sa.bindparam("p_pending_id"))
        cond_obj &= _eq(O, tmp_f.c, ["metadata_bytes"])
        sqt = (
            sa.select(O.id)
            .join(Tag, O.tags)
            .join(tmp_tag, _eq(tmp_tag.c, Tag, ["name"]))
            .where(cond_obj, tmp_tag.c.id == tmp_f.c.id)
            .limit(ONE)
        )
        q = sa.select(tmp_f.c.id, sqt.scalar_subquery().label("obj_id"))
        q = q.where(tmp_f.c.obj_id == None).subquery()

        sqh = (
            sa.select(O.id)
            .join(Hash, O.hashes)
            .join(tmp_hash, _eq(tmp_hash.c, Hash, ["hash_function", "hash"]))
            .where(cond_obj, tmp_hash.c.id == q.c.id)
            .limit(ONE)
        )
        q = sa.select(
            q.c.id,
            sa.case((q.c.obj_id == None, sqh.scalar_subquery()), else_=q.c.obj_id).label("obj_id"),
        )

        tmp_f_up = sao.aliased(tmp.files, name="t_file")

        # Finally, create the UPDATE statement that uses `qu` to update `tmp_files`.
        qu = q.cte(name="t_file_changes")
        stmt = sa.update(tmp_f_up)
        stmt = stmt.values(obj_id=qu.c.obj_id).where(tmp_f_up.c.id == qu.c.id)
        return _ns(stmt)

    @cached_property
    def _sql_prebatch_insert_missing_objs(self):
        """
        Create Obj records where missing.
        """
        tmp = self._tmp_files
        fake_created_at = sa.bindparam("p_fake_created_at")

        tmp_f = sa.alias(tmp.files, name="t_file")
        Obj = sao.aliased(mo.Obj, name="obj")
        q = sa.select(
            tmp_f.c.metadata_bytes.label("metadata"),
            tmp_f.c.id.label("size"),  # smuggle ID through this field
            fake_created_at.label("created_at"),
            sa.null().label("orphaned_at"),
            sa.bindparam("p_pending_id").label("pending_id"),
        )
        q = q.select_from(tmp_f).where(
            tmp_f.c.obj_id == None, tmp_f.c.insert_obj_if_missing == True
        )
        qi = sa.insert(mo.Obj)
        qi = qi.from_select(["metadata", "size", "created_at", "orphaned_at", "pending_id"], q)
        del q, Obj, tmp_f

        Obj = sao.aliased(mo.Obj, name="obj")
        q = sa.select(Obj.id.label("obj_id"), Obj.size.label("id")).where(
            Obj.created_at < _lit("0"), Obj.created_at == fake_created_at
        )
        q = q.cte(name="t_file_changes")

        tmp_f = sa.alias(tmp.files, name="t_file")
        qu = sa.update(tmp_f).add_cte(q)
        qu = qu.values(new_obj_id=q.c.obj_id).where(tmp_f.c.id == q.c.id)

        return _ns(qi), _ns(qu)

    @cached_property
    def _sql_prebatch_fix_and_delete_objs(self):
        tmp = self._tmp_files
        tmp_f = sao.aliased(tmp.files, name="t_files")
        pending_id = sa.bindparam("p_pending_id")
        created_at = sa.bindparam("p_created_at")
        Obj = sao.aliased(mo.Obj, name="obj")

        # Set a proper created_at for the new Objs that are actually in use.
        q = sa.select(tmp_f.c.obj_id).where(tmp_f.c.obj_id != None)
        r1 = sa.update(Obj).values(created_at=created_at)
        r1 = r1.where(Obj.id.in_(q), Obj.pending_id == pending_id)

        # Set updated_at to the current time.
        r2 = sa.update(Obj).values(updated_at=created_at)
        r2 = r2.where(Obj.id.in_(q))

        # Delete remaining Objs.
        r3 = sa.delete(Obj).where(
            Obj.id.in_(sa.select(tmp_f.c.new_obj_id)), Obj.created_at < _lit("0")
        )

        return tuple(_ns(x) for x in (r1, r2, r3))

    @cached_property
    def _sql_prebatch_insert_hashes(self):
        """
        Create Hash records.
        """
        tmp = self._tmp_files
        tmp_f = sao.aliased(tmp.files, name="t_files")
        tmp_h = sao.aliased(tmp.hashes, name="t_hash")
        Obj = sao.aliased(mo.Obj, name="obj")
        Hash = sao.aliased(mo.Hash, name="h")

        q = sa.select(tmp_f.c.new_obj_id, tmp_h.c.hash_function, tmp_h.c.hash)
        q = q.select_from(tmp_h).join(tmp_f, tmp_f.c.id == tmp_h.c.id)
        exists = sa.exists().select_from(Hash)
        exists = exists.where(
            Hash.hash_function == tmp_h.c.hash_function, Hash.obj_id == tmp_f.c.new_obj_id
        )
        q = q.where(~exists, tmp_f.c.new_obj_id != None)
        stmt = sa.insert(mo.Hash).from_select(["obj_id", "hash_function", "hash"], q)
        return _ns(stmt)

    @cached_property
    def _sql_prebatch_insert_tags(self):
        """
        Create Tag records.
        """
        # Sadly this has a lot in common with `_sql_insert_hashes`. The urge to refactor is intense.
        tmp = self._tmp_files
        tmp_f = sao.aliased(tmp.files, name="t_files")
        tmp_t = sao.aliased(tmp.tags, name="t_tag")
        Obj = sao.aliased(mo.Obj, name="obj")
        Tag = sao.aliased(mo.Tag, name="tag")

        q = sa.select(tmp_f.c.new_obj_id, tmp_t.c.name)
        q = q.select_from(tmp_t).join(tmp_f, tmp_f.c.id == tmp_t.c.id)
        exists = sa.exists().select_from(Tag)
        exists = exists.where(Tag.name == tmp_t.c.name, Tag.obj_id == tmp_f.c.new_obj_id)
        q = q.where(~exists, tmp_f.c.new_obj_id != None)
        stmt = sa.insert(mo.Tag).from_select(["obj_id", "name"], q)
        return _ns(stmt)

    @cached_property
    def _sql_prebatch_insert_files(self):
        tmp = self._tmp_files
        tmp_f = sao.aliased(tmp.files, name="t_files")
        q = sa.select(
            tmp_f.c.obj_id,
            sa.bindparam("p_pending_id").label("pending_id"),
            sa.bindparam("p_created_at").label("created_at"),
        )
        q = q.where(tmp_f.c.obj_id != None)
        stmt = sa.insert(mo.File).from_select(["obj_id", "pending_id", "created_at"], q)
        return _ns(stmt)

    @cached_property
    def _sql_prebatch_delete_and_insert_links(self):
        tmp = self._tmp_files
        F = sao.aliased(mo.File, name="file")
        L = sao.aliased(mo.Link, name="link")
        tmp_f = sao.aliased(tmp.files, name="t_file")
        null_id = sa.bindparam("p_null_file_id")

        cond_link = (tmp_f.c.obj_id != None) & (tmp_f.c.link_path != None)

        # Invalidate file link counts for the links we are about to delete.
        q = sa.select(L.file_id).where(L.path.in_(sa.select(tmp_f.c.link_path).where(cond_link)))
        r0 = sa.update(F).values(link_count=-1)
        r0 = r0.where(F.id.in_(q))

        # Delete the old links.
        r1 = sa.delete(L).where(L.path.in_(sa.select(tmp_f.c.link_path).where(cond_link)))

        # Insert the new links.
        q = sa.select(tmp_f.c.link_path.label("path"), null_id.label("file_id")).where(cond_link)
        r2 = sa.insert(mo.Link).from_select(["path", "file_id"], q)

        # Set in-use Objs as not orphaned as they now have links.
        O = sao.aliased(mo.Obj, name="obj")
        q = sa.select(tmp_f.c.obj_id).where(cond_link)
        r3 = sa.update(O).values(orphaned_at=None).where(O.id.in_(q))

        return tuple(_ns(r) for r in (r0, r1, r2, r3))

    @cached_property
    def _sql_postbatch_update_objs(self):
        t = sao.aliased(self._tmp_files2.objs, name="tu_obj")
        q = sa.select(t.c.obj_id, t.c.size).subquery()
        O = sao.aliased(mo.Obj, name="obj")
        stmt = sa.update(O).where(O.id == q.c.obj_id)
        stmt = stmt.values(size=q.c.size, pending_id=None)
        return _ns(stmt)

    @cached_property
    def _sql_postbatch_update_files(self):
        t = sao.aliased(self._tmp_files2.files, name="tu_files")
        q = sa.select(t.c.file_id, t.c.obj_id).subquery()
        F = sao.aliased(mo.File, name="file")
        stmt = sa.update(F).where(F.id == q.c.file_id)
        stmt = stmt.values(obj_id=q.c.obj_id, pending_id=None)
        return _ns(stmt)

    @cached_property
    def _sql_postbatch_update_links(self):
        t = sao.aliased(self._tmp_files2.links, name="tu_links")
        q = sa.select(t.c.link_path, t.c.file_id, t.c.link_count).subquery()
        F = sao.aliased(mo.File, name="file")
        L = sao.aliased(mo.Link, name="link")
        stmt1 = sa.update(F).where(F.id == q.c.file_id)
        stmt1 = stmt1.values(link_count=q.c.link_count)
        stmt2 = sa.update(L).where(L.path == q.c.link_path)
        stmt2 = stmt2.values(file_id=q.c.file_id)
        return _ns(stmt1), _ns(stmt2)

    @cached_property
    def _sql_prebatch_select_req_obj(self):
        tmp = self._tmp_files
        t_files = sao.aliased(tmp.files, name="t_files")
        q = sa.select(t_files.c.id, t_files.c.obj_id).where(t_files.c.obj_id != None)
        return _ns(q)

    @cached_property
    def _sql_prebatch_select_obj_file(self):
        tmp = self._tmp_files
        p_id = sa.bindparam("p_pending_id")
        O = sao.aliased(mo.Obj, name="obj")
        F = sao.aliased(mo.File, name="file")
        t_files = sao.aliased(tmp.files, name="t_files")
        qo = sa.select(t_files.c.obj_id).where(t_files.c.obj_id != None)
        q = sa.select(F.obj_id, F.id, F.pending_id)
        q = q.where(F.link_count < sa.bindparam("p_max_link_count"))
        q = q.where(F.obj_id.in_(qo), (F.pending_id == None) | (F.pending_id == p_id))
        return _ns(q)

    def run_batch(self, requests: ty.Iterable[DedupRequest]) -> None:
        """
        Link and/or delete many files using batching for efficiency. If the
        :attr:`DedupLinkRequest.file_hash` attribute is ``None``, then write the file hash to it.

        The requests will be addressed in the order that they appear in the iterable.

        BUG: If the same file (same hash or same tag) appears multiple times in the *requests* then
        multiple files will be created. You are welcome to fix this without breaking the tests and
        without incurring a significant performance penalty.

        We create more Objs and Files than we need, then clean them up later no biggie.
        They get automatically deleted when the Pending record is deleted.

        Pre-batch:

        1. Insert temporary files, hashes, tags
        2. Update tmp.files.obj_id by matching existing Objs by hash or tag.
        3. Insert a new Obj for each tmp_file where obj_id is NULL.
        4. Insert Objs and update t.files.obj_id to point to the right Obj.
        5. Insert Hash and Tag rows corresponding to stuff in t.files.
        6. Update tmp.files.obj_id by matching existing Objs by hash or tag.
        7. Insert a new File for each tmp_file. We might not need it.
        8. Insert a new Link for each tmp_file.
        9. Select (Obj.id, File.id) for each of tmp.files. These are all the possible usable files
           that we will attempt to create a link to.

        Batch:

        1. For each request:
            2. If no content is present, then use the existing pending File id to write the content.
            3. If content is already present:
                3. For each related file_id:
                    4. Check the link count and make a reminder to update the link count in the DB.
                    5. Attempt to create a link pointing to that file_id. If it succeeds, continue
                       to the next request.
                6. None of the file IDs succeeded. Make a copy of an existing file using the spare
                pending File id.

        Post-batch:

        1. Update the link counts.
        2. Match each

        """

        links = []
        copies = []
        # unlinks = []
        for i, req in enumerate(requests):
            if isinstance(req, DedupLinkRequest):
                links.append(_ImplDedupLinkRequest(req=req, index=i))
            elif isinstance(req, DedupCopyLinkRequest):
                copies.append(_ImplDedupCopyLinkRequest(req=req, index=i))
            else:
                raise TypeError(f"{type(req)!r}")

        if links and copies:
            # We don't do this yet because a copy request could be interfering with a link request
            # by having the same source or destination link.
            raise AssertionError(
                "doing both links and copies in the same batch is not supported for now"
            )

        # cases to consider:
        # adopt_existing==True, link_path is an existing dedup link: NOT IMPLEMENTED
        # adopt_existing==True, link_path is a regular file, hash matches content inside dedup db
        # adopt_existing==True, link_path is a regular file, content is novel

        # Preliminaries to do before we start writing to the database.
        tmp_files = []
        tmp_tags = []
        tmp_hashes = []
        with self._SessionR() as s:
            for link in links:
                req = link.req

                if req.link_path is not None:
                    link.link_path_str = ps = self._link_path_to_string(req.link_path)
                    # Remove existing file if present. This may raise if the path is actually a
                    # directory.
                    if req.adopt_existing:
                        pass  # Assertion is too expensive.
                        # assert not s.execute(
                        #     self._sql_prebatch_check_link, {"p_path": ps}
                        # ).scalar(), "adopting an existing link is not supported yet"
                    else:
                        self._delete_file(req.link_path, missing_ok=True)
                else:
                    # The user is requesting insert of content but doesn't want an actual link
                    # to be created.
                    link.link_path_str = ps = None
                    assert not req.adopt_existing

                if req.adopt_existing:
                    req.file_metadata = m = self.get_metadata_from_file(req.link_path)
                    with req.link_path.open("rb") as f:
                        r = self._compute_file_hash(req.hash_function, f)
                    link.file_size, req.file_contents_hash = r
                else:
                    m = req.file_metadata

                link.metadata_bytes = m = self.convert_file_metadata_to_bytes(m)

                tmp_files.append(
                    {
                        "id": link.index,
                        "link_path": ps,
                        "metadata_bytes": m,
                        "insert_obj_if_missing": req.open_file_once is not None
                        or req.adopt_existing,
                    }
                )

                tmp_tags += ({"id": link.index, "name": tag} for tag in req.tags)

                if (h := req.file_contents_hash) is not None:
                    d = {
                        "id": link.index,
                        "hash_function": h.function.function_code,
                        "hash": h.digest,
                    }
                    tmp_hashes.append(d)
                    link.hashes_promised = {h.function: h}
                else:
                    link.hashes_promised = {}

                if (req.file_contents_hash is None) and not req.tags:
                    raise AssertionError("must provide hash and/or tags")

        updates = _Updates()
        objs: dict[int, _Obj] = {}

        # Now we check the database and add file hash records where we can.
        with self._beginw() as s, mo.tmp_new_files(s, "") as t:
            c = s.connection()
            s.add(pending := mo.Pending(expire_at=mo.now() + 30.0))
            s.flush()
            pending_key = IdKey.from_instance(pending)
            pending_id = pending.id
            if tmp_files:
                c.execute(sa.insert(t.files), tmp_files).close()
            if tmp_hashes:
                c.execute(sa.insert(t.hashes), tmp_hashes).close()
            if tmp_tags:
                c.execute(sa.insert(t.tags), tmp_tags).close()

            s.add(temp_file := mo.File(pending_id=pending_id))
            s.flush()
            temp_file_id = temp_file.id

            # Set t.files.obj_id using existing Obj and File records.
            d = {
                "p_fake_created_at": -1,
                "p_created_at": mo.now(),
                "p_null_file_id": temp_file_id,
                "p_pending_id": pending_id,
                "p_max_link_count": self.max_link_count,
            }
            c.execute(self._sql_prebatch_update_with_existing_dedup_files, d).close()

            # We insert Obj records for the requests where t.files.obj_id is NULL.
            for stmt in self._sql_prebatch_insert_missing_objs:
                c.execute(stmt, d).close()

            # Now all requests have an Obj. We add tag or hash records where necessary.
            c.execute(self._sql_prebatch_insert_tags).close()
            c.execute(self._sql_prebatch_insert_hashes).close()

            # Coalesce overlapping new Objs.
            c.execute(self._sql_prebatch_update_with_existing_dedup_files, d).close()

            # Delete unused Objs. Set `Obj.created_at` for remaining ones.
            for stmt in self._sql_prebatch_fix_and_delete_objs:
                c.execute(stmt, d).close()

            # Speculatively insert as many files as there are members in the batch.
            c.execute(self._sql_prebatch_insert_files, d).close()

            for r in self._sql_prebatch_delete_and_insert_links:
                c.execute(r, d).close()

            if 0:
                tmp = self._tmp_files
                print("**************** files, hashes, tags")
                for tab in (tmp.files, tmp.hashes, tmp.tags):
                    print(s.execute(sa.select(tab)).all())

            for req_id, obj_id in c.execute(self._sql_prebatch_select_req_obj):
                if (obj := objs.get(obj_id)) is None:
                    objs[obj_id] = obj = _Obj(id=obj_id)
                (link := links[req_id]).obj = obj
                if link.req.adopt_existing:
                    obj.adopted_file_path = link.req.link_path

            for obj_id, file_id, pending_id in c.execute(self._sql_prebatch_select_obj_file, d):
                o = objs[obj_id]
                if pending_id is None:
                    o.completed_file_ids.append(file_id)
                else:
                    o.pending_file_ids.append(file_id)

            pending.expire_at = mo.now() + 30.0
            del pending

        failed_link_paths = []
        with self._PendingUpdater(
            pending=pending_key,
            sessionmaker_r=self._SessionR,
            sessionmaker_w=self._SessionW,
            seconds_in_the_future=20,
        ) as pu, self.temporary_directory(check_links=False) as tmp_path:
            for link in links:
                with self._ignore_skip(), self._catch_req_exc(link):
                    if (obj := link.obj) is None:
                        # nothing to be done here
                        link.call_file_not_needed()
                        link.set_failed(MissingContentError(f"no obj {link}"))
                        continue

                    self._write_dedup_file_contents(link, tmp_path, updates)

        with self._beginw() as s, mo.tmp_new_files2(s, "") as t:
            c = s.connection()

            if u := updates.link_updates:
                c.execute(sa.insert(self._tmp_files2.links), u).close()
                for stmt in self._sql_postbatch_update_links:
                    c.execute(stmt).close()

            if u := updates.file_updates:
                c.execute(sa.insert(self._tmp_files2.files), u).close()
                c.execute(self._sql_postbatch_update_files).close()

            if u := updates.obj_updates:
                c.execute(sa.insert(self._tmp_files2.objs), u).close()
                c.execute(self._sql_postbatch_update_objs).close()

            # Delete the pending object.
            s.delete(pending_key.get_one(s))
            s.flush()

        failed_requests = []
        for link in links:
            ok = link.req.success = not link.failed
            if not ok:
                failed_requests.append(link.req)

        if failed_requests:
            first_exc = failed_requests[0].exc
            raise BatchError(requests=failed_requests) from first_exc

    def _make_dedup_file_path(self, file_id: int) -> Path:
        return self._path_dedup / self._integer_to_path(file_id)

    def _write_file_computing_hashes(
        self, target: Path, open1, hashes: ty.Iterable[mh.HashFunction]
    ) -> tuple[int, dict[mh.HashFunction, mh.Digest]]:
        m = mh.MultiHasher({f: f() for f in hashes})
        with target.open("wb") as f_w, open1() as f_r:
            while block := f_r.read(65536):
                m.update(block)
                f_w.write(block)
        return m.size, m.digest()

    def _write_dedup_file_contents(
        self, link: _ImplDedupLinkRequest, tmp_path: Path, updates: _Updates
    ) -> None:
        obj = link.obj
        target = link.req.link_path
        skip_link_for_file_id = None
        adopting = obj.adopted_file_path
        adopted = False

        def _mkdirp(path):
            if not path.exists():
                path.mkdir(exist_ok=True, parents=True)

        # Do we have any completed File IDs at all?
        if obj.completed_file_ids:
            link.call_file_not_needed()
            if adopting is not None:
                # We don't need the file there.
                self._delete_file(target)
        else:
            # No completed IDs, we need to make one. Try to adopt if possible.
            tmp_p = tmp_path / "f.bin"
            self._delete_file(tmp_p, missing_ok=True)

            if adopting is not None:
                link.call_file_not_needed()
                self._adopt_file_and_link(adopting, tmp_p)
                adopted = True
                size = tmp_p.stat().st_size
                apply_metadata = False
            elif (open1 := link.call_open_file_once) is not None:
                (fs := set(link.hashes_promised)).update(self.extra_hashes)
                size, d = self._write_file_computing_hashes(tmp_p, open1, fs)
                link.hashes_computed = d

                # Check that the hashes match what was claimed inside the link request.
                computed = {k: d[k] for k in link.hashes_promised}
                if link.hashes_promised != computed:
                    raise InvalidContentsError(
                        link_request=link.req,
                        hashes_expected=link.hashes_promised,
                        hashes_observed=computed,
                    )
                apply_metadata = True
            else:
                link.set_failed(MissingContentError("content not provided"))
                return

            if apply_metadata:
                self.apply_metadata_to_file(tmp_p, link.req.file_metadata)
            self._set_clean_file_mtime(tmp_p)

            file_id = obj.pending_file_ids.pop()
            p = self._make_dedup_file_path(file_id)
            _mkdirp(p.parent)
            tmp_p.rename(p)
            obj.completed_file_ids.append(file_id)
            updates.file_updates.append({"file_id": file_id, "obj_id": obj.id})
            updates.obj_updates.append({"obj_id": obj.id, "size": size})
            # Now the file has the right contents. Let's also make a link now.

            if adopting is not None:
                skip_link_for_file_id = file_id

        exc = AssertionError
        endgame = False
        completed = obj.completed_file_ids
        while True:
            file_id = completed[-1]
            p = self._make_dedup_file_path(file_id)
            if adopted and adopting == target:
                ok = True
            else:
                ok = False
                try:
                    self._create_actual_link(p, target)
                    ok = True
                except Exception as exc_:
                    exc = exc_

                if not ok:
                    if not target.parent.exists():
                        retry = True
                        target.parent.mkdir(exist_ok=True, parents=True)
                    elif target.exists():
                        retry = True
                        self._delete_file(target)
                    else:
                        retry = False
                    if retry:
                        try:
                            self._create_actual_link(p, target)
                            ok = True
                        except Exception as exc_:
                            exc = exc_

            link_count = p.stat().st_nlink - 1
            updates.link_updates.append(
                {
                    "link_path": link.link_path_str if ok else None,
                    "file_id": file_id,
                    "link_count": link_count,
                }
            )
            if ok:
                # We're done! Bye!
                return

            if len(completed) > 1:
                completed.pop()
                continue

            if endgame:
                try:
                    raise exc
                finally:
                    exc = None  # eliminate GC cycle

            endgame = True

            # This is our last one file, we must make a copy.
            tmp_p = tmp_path / "f.bin"
            self._delete_file(tmp_p, missing_ok=True)
            shutil.copyfile(str(self._make_dedup_file_path(file_id)), str(tmp_p))

            file_id = obj.pending_file_ids.pop()
            p = self._make_dedup_file_path(file_id)
            _mkdirp(p.parent)
            tmp_p.rename(p)
            obj.completed_file_ids[0] = file_id
            updates.file_updates.append({"file_id": file_id, "obj_id": obj.id})
            # We made a copy. Hope it works now.

    @property
    def _PendingUpdater(self):
        return _PendingUpdater

    @abc.abstractmethod
    def _create_actual_link(self, existing: Path, new: Path): ...

    @abc.abstractmethod
    def _adopt_file_and_link(self, existing_path: Path, dedup_file_path: Path): ...

    @abc.abstractmethod
    def _verify_link(self, link: mo.Link) -> bool: ...

    def _pre_delete_links(self, path: Path):
        """
        Delete link records for all paths under *path*. Note that you must still delete the actual
        files, for example using rmtree.
        """
        self._check_links(path, True)

    def check_links(self, path: Path | None = None) -> None:
        """
        Detect links that were removed from the filesystem.

        If *path* is provided, then only traverse files under *path*. If the *path* does not exist,
        that means that everything under that *path* is gone.
        """
        self._check_links(path, False)

    @cached_property
    def _sql_checklinks(self):
        tmp = self._tmp_check_links
        t_links = sao.aliased(tmp.links)
        F = sao.aliased(mo.File)
        L = sao.aliased(mo.Link)

        # Invalidate link_count for affected dedup Files.
        q = sa.select(L.file_id).join(t_links, L.path == t_links.c.path)
        r0 = sa.update(F).values(link_count=-1).where(F.id.in_(q))

        # Delete Link records.
        r1 = sa.delete(L).where(L.path.in_(sa.select(t_links.c.path)))

        return tuple(_ns(x) for x in (r0, r1))

    def _check_links(self, path: Path | None, pre_delete: bool) -> None:
        F = sao.aliased(mo.File)
        L = sao.aliased(mo.Link)

        _verify_link = self._verify_link

        prefix = None
        if path is not None:
            exact_path = self._link_path_to_string(path)
            prefix = self._link_path_to_string(path / "x")[:-1]

            if pre_delete or not path.exists():
                # FAST PATH: Entire directory is gone, so all of its contents are gone. No need to
                # do any checking.
                _verify_link = lambda link: False

        q = sa.select(L).order_by(L.path).options(sao.joinedload(L.file))
        q = q.limit(self._batch_size)
        if prefix is not None:
            q = q.where((L.path == exact_path) | bytes_startswith(L.path, prefix))

        with self._SessionR() as s:
            last_link_path: str | None = None
            while True:
                if last_link_path is None:
                    q2 = q
                else:
                    q2 = q.where(L.path > last_link_path)

                results: list[mo.Link] = s.execute(q2).scalars().all()
                if not results:
                    break

                to_delete = []
                for link in results:
                    if not _verify_link(link):
                        # TODO: Instead of just deleting them from the DB, maybe we should keep
                        # track of invalid links or even repair them?
                        to_delete.append(link.path)

                if to_delete:
                    with self._beginw() as s2, mo.tmp_check_links(s2, "") as tmp:
                        # 1. Insert Link paths into a temporary table.
                        s2.connection().execute(
                            sa.insert(tmp.links), [{"path": x} for x in to_delete]
                        ).close()

                        # 2. Invalidate link_count inside parent Files.
                        # 3. Delete Links.
                        # 4. Recompute link_count for affected Files.
                        for stmt in self._sql_checklinks:
                            s2.execute(stmt).close()

                last_link_path = results[-1].path

    @cached_property
    def _sql_orph_update(self):
        now = sa.bindparam("p_now")
        updated_since = sa.bindparam("p_updated_since")
        Obj = sao.aliased(mo.Obj)
        return Obj.make_sql_update_orphaned(now).where(Obj.updated_at >= updated_since)

    def detect_orphaned(self):
        # Update link count for files where it was invalidated.
        self.integrity_check(skip_same_mtime=True, only_invalid_link_count=True)

        C = sao.aliased(mo.DedupConfig)
        KEY = "last_detect_orphaned"
        with self._beginw() as s:
            last_check = s.execute(sa.select(C).where(C.key == KEY)).scalar()
            if last_check is None:
                s.add(last_check := mo.DedupConfig(key=KEY, value="0"))
            since = int(last_check.value)
            now = mo.now()
            s.execute(self._sql_orph_update, {"p_now": now, "p_updated_since": since}).close()
            last_check.value = str(now)

    @cached_property
    def _sql_gc_orphaned_to_pending(self):
        O = sao.aliased(mo.Obj)
        F = sao.aliased(mo.File)
        F2 = sao.aliased(mo.File)
        q = sa.select(F.id).join(O, F.obj).where(O.orphaned_at < sa.bindparam("p_cutoff"))
        return _ns(
            sa.update(F2).values(pending_id=sa.bindparam("p_pending_id")).where(F2.id.in_(q))
        )

    @cached_property
    def _sql_gc_select_pending(self):
        F = sao.aliased(mo.File)
        P = sao.aliased(mo.Pending)
        L = sao.aliased(mo.Link)
        cond = P.expire_at < sa.bindparam("p_cutoff")
        cond &= P.id != _lit(str(self._corrupted_pending_id))
        q0 = sa.select(P.id).where(cond)
        q1 = sa.select(F.id).join(P).where(cond)
        q2 = sa.select(L.path).where(L.file_id.in_(q1))
        return q0, q1, q2

    def garbage_collect_dedup_files(
        self, min_age_orphan_seconds: int, min_age_pending_seconds: int = None
    ) -> None:
        """
        Remove dedup files that have no links to them as well as dedup files that were left behind
        by a failed batch of content insertion.
        """

        self.detect_orphaned()
        now = mo.now()
        orphan_cutoff = now - min_age_orphan_seconds
        pending_cutoff = now - (min_age_pending_seconds or 7200)

        self._garbage_collect_dedup_files(orphan_cutoff, pending_cutoff)

    def _garbage_collect_dedup_files(self, orphan_cutoff: int | None, pending_cutoff: int):
        if orphan_cutoff is not None:
            with self._beginw() as s:
                s.add(pending := mo.Pending(expire_at=1))  # expiration time far into the past
                s.flush()

                # Convert orphaned files to pending. We will collect the pending afterwards.
                params = {"p_pending_id": pending.id, "p_cutoff": orphan_cutoff}
                s.execute(self._sql_gc_orphaned_to_pending, params).close()

        with self._SessionR.begin() as s:
            # Iterate through the expired pending File IDs and delete the files and links. Gather the list
            # of pending objects that are finished.
            params = {"p_cutoff": pending_cutoff}
            q0, q1, q2 = self._sql_gc_select_pending
            pending_ids = s.execute(q0, params).scalars().all()

            for link_path in s.execute(q2, params).scalars():
                p = self._link_path_from_string(link_path)
                if p.exists():
                    self._delete_file(p)

            for file_id in s.execute(q1, params).scalars():
                p = self._make_dedup_file_path(file_id)
                if p.exists():
                    self._delete_file(p)

        # We only update the database after successfully deleting all the files and links.
        P = sao.aliased(mo.Pending)
        with self._beginw() as s:
            s.execute(sa.delete(P).where(P.id.in_(pending_ids))).close()

    def garbage_collect_deleted(self):
        """
        Delete unused temporary directories created with :meth:`.temporary_directory` as well as
        files that could not be deleted previously (due to locking on Windows, for example).
        """

        # We must ALWAYS lock self._path_temporary_master_lock before attempting to create or delete
        # an child lock file inside self._path_temporary_lock.
        for q in self._path_temporary_lock.iterdir():
            with contextlib.ExitStack() as ex:
                # Holding the master lock, we check the timestamp of the child lock and, if it's old
                # enough, we lock it.
                with self._filelock(self._path_temporary_master_lock, blocking=True):
                    if q.lstat().st_mtime >= mo.now() - 3600:
                        continue

                    try:
                        ex.enter_context(self._filelock(q, blocking=False))
                    except filelock.Timeout:
                        continue  # it's still locked, leave it alone

                    # We release the master lock as we don't need it anymore.

                # Still holding the child lock, delete the corresponding temporary dir.
                self.delete_tree(self._path_temporary_dirs / q.name)

            # Holding the master lock, finally delete the child lock.
            with self._filelock(self._path_temporary_master_lock, blocking=True):
                try:
                    with self._filelock(q, blocking=False):
                        pass
                except filelock.Timeout as exc_:
                    pass  # another thread chose the same name and locked it, leave it alone
                else:
                    self._remove_file_or_dir(q, ignore_errors=True)

        for p in self.path_deleted.iterdir():
            self._remove_file_or_dir(p, ignore_errors=True)

    def _remove_file_or_dir(self, p: Path, ignore_errors: bool):
        try:
            p.unlink()
        except Exception:
            if not p.exists():
                pass  # mission (already) accomplished
            elif stat.S_ISDIR(p.lstat().st_mode):
                shutil.rmtree(str(p), ignore_errors=ignore_errors)
            elif not ignore_errors:
                raise

    def garbage_collect_extra_files(self):
        """
        Look for files in the dedup directory that were left behind due to errors or unexpected
        shutdown. Delete such files.

        This recursively lists every file in the dedup store, so it takes a long time.
        """
        F = sao.aliased(mo.File)
        i2p = self._integer_to_path
        cutoff = mo.now() - 3600

        t_f = sao.aliased(self._tmp_delete_extra.files)
        q = sa.select(t_f.c.id).where(~sa.exists().select_from(F).where(F.id == t_f.c.id))

        base = self._path_dedup
        with self._SessionR.begin() as s, mo.tmp_delete_extra(s, "") as tmp:
            for chunk in chunked_iter(base.rglob("*"), self._batch_size):
                file_ids = {}
                for p in chunk:
                    if not p.is_file():
                        continue

                    try:
                        file_id = i2p.invert("/".join(p.relative_to(base).parts))
                    except InvalidPathError:
                        if p.stat().st_mtime < cutoff:
                            self._delete_file(p)
                        continue

                    file_ids[file_id] = p

                if file_ids:
                    s.execute(sa.insert(tmp.files), tuple({"id": x} for x in file_ids)).close()
                    bad_file_ids = s.execute(q).scalars().all()
                    s.execute(sa.delete(tmp.files)).close()

                    for file_id in bad_file_ids:
                        self._delete_file(file_ids[file_id])

    def corrupted_list(self) -> ty.Generator[Corrupted]:
        """
        Get the list of corrupted files found using :meth:`integrity_check`.
        """

        L = sao.aliased(mo.Link)

        with self._SessionR() as s:
            for fc in s.execute(sa.select(mo.FileCorruption)).scalars():
                fc.id
                links_bytes = s.execute(sa.select(L.path).where(L.file_id == fc.id)).scalars().all()
                links_paths = tuple((self._link_path_from_string(x)) for x in links_bytes)
                yield Corrupted(
                    path=self._make_dedup_file_path(fc.id),
                    file_id=fc.id,
                    exception_name=fc.exception_name,
                    exception_string=fc.exception_string,
                    link_paths=links_paths,
                    raw_link_paths=tuple(links_bytes),
                )

    def corrupted_clear(self):
        """
        Delete all corrupted files.
        """
        F = sao.aliased(mo.File)
        with self._beginw() as s:
            s.add(p := mo.Pending(expire_at=1))
            s.flush()
            s.execute(
                sa.update(F)
                .values(pending_id=p.id)
                .where(F.pending_id == self._corrupted_pending_id)
            ).close()
        self._garbage_collect_dedup_files(orphan_cutoff=None, pending_cutoff=2)

    @staticmethod
    def _copy_tree_default_fallback(src: Path, dst: Path):
        shutil.copy2(str(src), str(dst), follow_symlinks=False)

    def copy_tree(self, src: Path, dst: Path, fallback_copy=None) -> None:
        if fallback_copy is None:
            fallback_copy = self._copy_tree_default_fallback
        if dst.exists():
            raise AssertionError("dst must not exist")
        self.check_links(dst)

        def _run():
            self.run_batch(to_copy)
            for req in to_copy:
                try:
                    req.result()
                except NotADedupLinkError:
                    fallback_copy(req.src, req.dst)
            to_copy.clear()

        if src.is_dir():
            to_copy = []
            for root, dirs, files in pathwalk(src):
                root_dst = dst / root.relative_to(src)
                root_dst.mkdir(exist_ok=True, parents=True)
                for f in files:
                    to_copy.append(DedupCopyLinkRequest(src=root / f, dst=root_dst / f))
                    if len(to_copy) > 1000:
                        _run()
        else:
            # must be a file
            to_copy = [DedupCopyLinkRequest(src=src, dst=dst)]

        if to_copy:
            _run()

    def delete_tree(self, p: Path, check_links: bool = True) -> None:
        def f(func, path, exc_info):
            if (p := Path(path)).exists():
                self._move_to_deleted(p)

        shutil.rmtree(str(p.absolute()), onerror=f)
        if p.exists():
            self._move_to_deleted(p)
        if check_links:
            self.check_links(p)

    def delete_file(self, p: Path, missing_ok: bool = False) -> None:
        self._delete_file(p, missing_ok=missing_ok)
        self.check_links(p)

    def _delete_file(self, p: Path, missing_ok: bool = False) -> None:
        """
        On Windows, a locked file cannot be deleted. So instead we move it out of the way to a
        different directory in the hopes of deleting it later when it's not locked.
        """
        try:
            p.unlink(missing_ok=missing_ok)
        except OSError:
            if p.is_dir():
                raise
        else:
            return

        self._move_to_deleted(p)

    def _move_to_deleted(self, p: Path) -> None:
        base = self.path_deleted
        for name in random_names("", ".bin"):
            try:
                p.rename(base / name)
            except OSError as exc:
                exc_ = exc
            else:
                return

        raise exc_

    def _filelock(self, path: Path, blocking: bool):
        return filelock.FileLock(path, blocking=blocking)

    @cached_property
    def _path_temporary_simple_dir(self):
        return self.path_temporary / "simple"

    @cached_property
    def _path_temporary_dirs(self):
        return self.path_temporary / "dirs"

    @cached_property
    def _path_temporary_lock(self):
        return self.path_temporary / "lock"

    @cached_property
    def _path_temporary_master_lock(self):
        return self.path_temporary / "master.lock"

    @contextlib.contextmanager
    def temporary_directory(self, prefix="tmp_", suffix="", check_links: bool = True):
        exc = None
        for name in random_names(prefix=prefix, suffix=suffix):
            p = self._path_temporary_dirs / name
            q = self._path_temporary_lock / name

            # We must always acquire the master lock before acquiring a child lock. The order must
            # be consistent in order to prevent deadlocks.
            with contextlib.ExitStack() as ex:
                with self._filelock(self._path_temporary_master_lock, blocking=True):
                    try:
                        ex.enter_context(self._filelock(q, blocking=False))
                    except filelock.Timeout as exc_:
                        continue  # try a different name

                    # We now release the master lock because we don't need it any more.

                try:
                    p.mkdir(parents=True)
                except OSError as exc_:
                    exc = exc_
                    continue

                try:
                    yield p
                    break
                finally:
                    self.delete_tree(p, check_links=check_links)

                    # Release the lock file. We will attempt to delete it next.
                    ex.close()

                    # Attempt to delete the lock file.
                    with self._filelock(self._path_temporary_master_lock, blocking=True):
                        try:
                            with self._filelock(q, blocking=False):
                                pass
                        except filelock.Timeout as exc_:
                            pass  # another thread chose the same name and locked it, leave it alone
                        else:
                            self._remove_file_or_dir(q, ignore_errors=True)
        else:
            raise AssertionError("retry count exceeded, unknown cause") if exc is None else exc

    @cached_property
    def _sql_obht_select_file(self):
        F = sao.aliased(mo.File)
        O = sao.aliased(mo.Obj)
        T = sao.aliased(mo.Tag)
        H = sao.aliased(mo.Hash)
        b = sa.bindparam
        q = sa.select(
            F.id.label("file_id"),
            sa.case((O.orphaned_at != None, O.id), else_=None).label("obj_id"),
        ).join(O, F.obj)
        cond = F.pending_id == None
        lim1 = lambda q: q.limit(_lit("1"))
        q_h = q.join(H, O.hashes).where(cond, H.hash_function == b("p_hf"), H.hash == b("p_h"))
        q_t = q.join(T, O.tags).where(cond, T.name == b("p_tag"))
        return lim1(q_h), lim1(q_t)

    @cached_property
    def _sql_obht_update_obj(self):
        O = sao.aliased(mo.Obj)
        b = sa.bindparam
        return (
            sa.update(O)
            .values(orphaned_at=sa.case((O.orphaned_at != None, b("p_now")), else_=None))
            .where(O.id == b("p_obj_id"))
        )

    def _open_by_hash_or_tag(self, params: dict, q_index: int) -> ty.BinaryIO | None:
        with self._beginw() as s:
            c = s.connection()
            if (r := c.execute(self._sql_obht_select_file[q_index], params).one_or_none()) is None:
                return None
            file_id, obj_id = r

            if obj_id is not None:
                d = {"p_now": mo.now(), "p_obj_id": obj_id}
                c.execute(self._sql_obht_update_obj, d).close()

        return self._make_dedup_file_path(file_id).open("rb")

    def open_by_hash(self, digest: mh.Digest) -> ty.BinaryIO | None:
        d = {"p_hf": digest.function.function_code, "p_h": digest.digest}
        return self._open_by_hash_or_tag(d, 0)

    def open_by_tag(self, tag: bytes) -> ty.BinaryIO | None:
        return self._open_by_hash_or_tag({"p_tag": tag}, 1)

    @cached_property
    def _q_get_hash(self):
        L = sao.aliased(mo.Link)
        F = sao.aliased(mo.File)
        O = sao.aliased(mo.Obj)
        H = sao.aliased(mo.Hash)
        return (
            sa.select(L, H, O.size)
            .select_from(L)
            .join(F, L.file)
            .join(O, F.obj)
            .outerjoin(H, (Rel(H.obj) == O) & (H.hash_function == sa.bindparam("x_hf")))
            .options(sao.contains_eager(L.file.of_type(F)))
            .where(L.path == sa.bindparam("x_link_path"), F.pending == None)
        )

    def _query_by_link_path(
        self, s: sao.Session, link_path: bytes, hash_function: mh.HashFunction
    ) -> list[tuple[mo.Link, mo.Hash, int]]:
        return s.execute(
            self._q_get_hash,
            {"x_link_path": link_path, "x_hf": hash_function.function_code},
        ).all()

    def get_file_hash(
        self, hash_function: mh.HashFunction, path: Path, check_link: bool
    ) -> tuple[int, mh.Digest] | None:
        """
        Query the database to obtain the file contents hash of file at *path*. Return None if the
        file is not in the dedup database. If *check_link* is True, then check that the link is
        intact before returning the hash. If the link is damaged or removed, then call
        :meth:`check_links` to unregister the link then return None.
        """
        with self._SessionR() as s:
            link_path: bytes = self._link_path_to_string(path)
            links = self._query_by_link_path(s, link_path, hash_function)

            if not links:
                return None

            link, h, size = links[0]
            if h is None:
                return None

            if not (check_link and not self._verify_link(link)):
                return size, h.to_digest()

        self.check_links(path)
        return None

    def get_or_compute_file_hash(
        self, hash_function: mh.HashFunction, path: Path, **kw
    ) -> tuple[int, mh.Digest] | None:
        r = self.get_file_hash(hash_function, path, **kw)
        if r is None:
            with path.open("rb") as f:
                r = self._compute_file_hash(hash_function, f)
        return r

    def _compute_file_hash(self, hash_function, file):
        size = 0
        hasher = hash_function()
        while block := file.read(65536):
            size += len(block)
            hasher.update(block)
        return size, hasher.digest()

    def adopt_files(
        self, hash_function: mh.HashFunction, requests: ty.Iterable[AdoptRequest]
    ) -> None:
        """
        HACK: DO NOT RUN THIS ON EXISTING DEDUP LINKS

        Adopt each file given in *paths*. If the path is already a dedup link, then leave it
        alone. If the path is not a dedup link, then compute its hash and move the file to the
        dedup store and create a link to it. If the path is already a dedup link but does not
        have the right kind of hash digest, then compute the hash digest and store it in the
        database.

        This method is implemented in a somewhat inefficient way.
        """
        self.run_batch(
            DedupLinkRequest(
                hash_function=hash_function,
                link_path=req.path,
                tags=req.tags,
                file_metadata=self.get_metadata_from_file(req.path),
                open_file_once=None,
                adopt_existing=True,
                file_contents_hash=None,
            )
            for req in requests
        )

    def integrity_check(
        self,
        skip_same_mtime: bool,
        threads: int | None = None,
        *,
        only_invalid_link_count: bool = False,
    ):
        """
        Verify all deduplicated files match their stored hashes. Use modification time to skip
        unchanged files if *skip_same_mtime* is True. Move the corrupted files to
        :attr:`path_corrupted`.
        """

        F = sao.aliased(mo.File)
        O = sao.aliased(mo.Obj)
        batch_size = 1000
        q = sa.select(F).options(sao.selectinload(F.obj.of_type(O)).selectinload(O.hashes))
        if only_invalid_link_count:
            q = q.where(F.link_count < _lit("0"))
        q = q.where(F.pending_id == None).order_by(F.id).limit(batch_size)

        def _hash_check(file: mo.File) -> None:
            p = self._make_dedup_file_path(file.id)
            st = p.stat()

            # FIXME: specific to hardlink backend
            if (n := st.st_nlink - 1) != file.link_count:
                link_count_updates.append({"id": file.id, "link_count": n})
                changed_obj_ids.add(file.obj_id)

            if skip_same_mtime:
                if (st_mtime := int(st.st_mtime)) == self._clean_dedup_mtime:
                    return

            d = file.obj.hashes_dict
            m = mh.MultiHasher({hf: hf() for hf in d})
            with p.open("rb") as fh:
                while block := fh.read(65536):
                    m.update(block)
            if d != (observed := m.digest()):
                raise InvalidContentsError(hashes_expected=d, hashes_observed=observed)

            # TODO: also check file metadata matches, such as the executable bit

        id_min = None
        with cf.ThreadPoolExecutor(max_workers=threads) as exe:
            while True:
                changed_obj_ids = set()
                link_count_updates = []
                invalid_file_ids = []

                with self._SessionR() as s:
                    q2 = q if id_min is None else q.where(F.id > id_min)
                    dedup_files: list[mo.File] = s.execute(q2).scalars().all()

                    if not dedup_files:
                        break

                    s.expunge_all()
                    id_min = dedup_files[-1].id
                    futures = {exe.submit(_hash_check, f): f for f in dedup_files}
                    for future in cf.as_completed(futures):
                        if (exc := future.exception()) is not None:
                            if not isinstance(exc, Exception):
                                # Some other type of exception
                                raise exc

                            file = futures[future]
                            invalid_file_ids.append((file.id, exc))

                if link_count_updates:
                    with self._beginw() as s:
                        s.execute(sa.update(F), link_count_updates).close()
                        now = mo.now()
                        s.connection().execute(
                            sa.update(O)
                            .where(O.id == sa.bindparam("p_id"))
                            .values(updated_at=sa.bindparam("p_now")),
                            [{"p_id": x, "p_now": now} for x in changed_obj_ids],
                        ).close()

                if invalid_file_ids:
                    with self._beginw() as s:
                        s.execute(
                            sa.insert(mo.FileCorruption),
                            [
                                {
                                    "id": file_id,
                                    "exception_name": type(exc).__name__,
                                    "exception_string": str(exc),
                                }
                                for file_id, exc in invalid_file_ids
                            ],
                        ).close()
                        s.connection().execute(
                            sa.update(F)
                            .values(pending_id=self._corrupted_pending_id)
                            .where(F.id.in_(x[0] for x in invalid_file_ids))
                        ).close()

    class _compute_stats_ZeroRow:
        orphaned = None
        count = 0
        size = 0

    def compute_stats(self) -> DedupStats:
        self.detect_orphaned()

        with self._SessionR() as s:
            O = sao.aliased(mo.Obj)
            F = sao.aliased(mo.File)
            L = sao.aliased(mo.Link)
            orph = O.orphaned_at != None

            q = (
                sa.select(
                    orph.label("orphaned"),
                    sa.func.count().label("count"),
                    sa.func.sum(O.size).label("size"),
                )
                .select_from(F)
                .join(O, F.obj)
                .where(F.pending == None)
                .group_by(orph)
            )
            file_stats = {k: self._compute_stats_ZeroRow() for k in (False, True)}
            file_stats |= {row.orphaned: row for row in s.execute(q).all()}

            q = (
                sa.select(sa.func.count().label("count"), sa.func.sum(O.size).label("size"))
                .select_from(L)
                .join(F, L.file)
                .join(O, F.obj)
            ).where(F.pending == None)
            link_stats = s.execute(q).one()

        return DedupStats(
            dedup_count=file_stats[False].count,
            dedup_total_bytes=file_stats[False].size,
            orphaned_count=file_stats[True].count,
            orphaned_total_bytes=file_stats[True].size,
            link_count=link_stats.count,
            link_total_bytes=link_stats.size or 0,
        )


class DedupBackendHardlink(Dedup):
    max_link_count = 1000  # Windows limits it to 1023

    def _create_actual_link(self, existing: Path, new: Path):
        # Path.link_to was removed and replaced by Path.hardlink_to, but I want this to work across
        # Python 3.9 to 3.13
        os.link(str(existing), str(new))

    def _adopt_file_and_link(self, existing_path: Path, dedup_file_path: Path):
        # hard links are indistinguishable from each other
        self._create_actual_link(existing_path, dedup_file_path)

    def _verify_link(self, link: mo.Link) -> bool:
        p = self._link_path_from_string(link.path)
        try:
            a = p.lstat()
        except Exception:
            return False

        if int(a.st_mtime) != self._clean_dedup_mtime:
            return False

        # st_ino is 0 on unsupported filesystems on Windows.

        # TODO: should we even allow st_ino=0?
        if a.st_ino != 0:
            if (file_stat := getattr(link.file, "_cached_file_stat", None)) is None:
                try:
                    file_stat = self._make_dedup_file_path(link.file.id).stat()
                except Exception:
                    return False
                link.file._cached_file_stat = file_stat

            if a.st_ino != file_stat.st_ino:
                return False

        return True
