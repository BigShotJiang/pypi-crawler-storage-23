from __future__ import annotations

import abc
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
import contextlib
import enum
import functools
import io
import itertools
from math import log2
from pathlib import Path, PurePosixPath
from queue import Queue
import re
import shutil
import struct
import threading
import typing as ty

import attr
import cbor2
from sansio_tools import parser as sansio_parser
from sansio_tools.queue import BytesQueue, FileAdapterFromGeneratorBytes
import structlog

from ..exc import BadHashError, ImageNotFoundError, RepoFileNotFoundError
from ..integer_to_path import IntegerToPath
from ..util import assert_
from .. import image as im, multihash as mh, dedup as de, util as ut
from . import compression as cx

logger = structlog.get_logger(__name__)


CBOR_HEADER = b"\xd9\xd9\xf7"
STRUCT_ARCHIVE_SIZE = struct.Struct("!Q")
STRUCT_ESTIMATED_SIZE = struct.Struct("!H")


def cbor_dumps(obj) -> bytes:
    return cbor2.dumps(obj, datetime_as_timestamp=True, canonical=True)


def cbor_loads(data: bytes):
    return cbor2.loads(data)


def cbor_load(fp: ty.BinaryIO, max_size: int):
    left = max_size + 1
    q = BytesQueue()
    while buf := fp.read(left):
        left -= len(buf)
        q.append(buf)
        if not left:
            raise ValueError(f"input exceeded maximum size {max_size}")
    return cbor_loads(bytes(q))


def cbor_dump(obj, fp):
    fp.write(b"\xd9\xd9\xf7")
    cbor2.dump(obj, fp, datetime_as_timestamp=True, canonical=True)


@attr.s(eq=False, hash=False)
class ShardPathsWriter:
    file = attr.ib()

    def write_all(self, files: ty.Iterable[im.SingleFileImageMetadata]):
        cbor_dump([x.to_shard_entry() for x in files], self.file)


@attr.s(eq=False, hash=False)
class ArchiveDataWriter:
    file_archive: ty.BinaryIO = attr.ib()
    file_sizes: ty.BinaryIO = attr.ib()

    def begin_file(self, size: int, digest: mh.Digest):
        self.current_hasher = digest.function()
        self.current_size = 0
        self.expected_digest = digest
        self.expected_size = size

    def write_file_data(self, data: bytes):
        self.current_size += len(data)
        self.current_hasher.update(data)
        self.file_archive.write(data)

    def end_file(self):
        h = self.current_hasher.digest()
        h0 = self.expected_digest
        if (size := self.current_size) != (s0 := self.expected_size) or h != h0:
            raise AssertionError(
                f"written file did not match expected info ({size} != {s0}, {h} != {h0})"
            )
        self.file_sizes.write(STRUCT_ARCHIVE_SIZE.pack(size))


@attr.s(eq=False, hash=False)
class HashesWriter:
    file: ty.BinaryIO = attr.ib()

    def write_all(self, iterable: ty.Iterable[mh.Digest]):
        w = self.file.write
        for x in iterable:
            w(x.digest)


def estimated_archive_sizes_encode(sizes: ty.Iterable[int]):
    _s = STRUCT_ESTIMATED_SIZE
    result = []
    for size in sizes:
        if size <= 0:
            size = 1
        result.append(_s.pack(round(log2(size) * 1024)))
    return b"".join(result)


def estimated_archive_sizes_decode(data: bytes) -> list[int]:
    _s = STRUCT_ESTIMATED_SIZE
    data = memoryview(data)
    result = []
    for i in range(0, len(data), 2):
        [x] = _s.unpack(data[i : i + 2])
        result.append(round(2.0 ** (x / 1024)))
    return result


class MapXToYOperatorEnum(enum.Enum):
    OUT = 1
    AND = 2
    OR = 3


@attr.s(eq=False, hash=False)
class MapShardToArchiveWriterTrivial:
    file: ty.BinaryIO = attr.ib()

    def write_all(self, *, shard_id: int, archive_id: int, archive_size: int):
        data = [
            [archive_id],
            [[MapXToYOperatorEnum.OUT.value, 0, shard_id]],
            estimated_archive_sizes_encode([archive_size]),
        ]
        cbor_dump(data, self.file)


@attr.s(eq=False, hash=False)
class MapImageToShardWriterTrivial:
    file: ty.BinaryIO = attr.ib()

    def write_all(self, *, image_id: int, shard_ids: ty.Iterable[int]):
        shard_ids = list(shard_ids)
        data = [
            shard_ids,
            [[MapXToYOperatorEnum.OUT.value, 0] + list(range(len(shard_ids)))],
        ]
        cbor_dump(data, self.file)


def image_file_entries_for_hashing_iter(
    image_user_data_hash: mh.Digest, entries: ty.Iterable[im.SingleFileImageMetadata]
):
    yield image_user_data_hash.to_multihash_bytes()

    d = {}
    keys = []
    for e in entries:
        keys.append(k := e.to_image_hash_sort_key())
        d[k] = e

    keys.sort()

    for k in keys:
        yield cbor_dumps(d[k].to_data_for_image_hash())


@attr.s(eq=False, hash=False)
class RepoTransfer:
    """
    Implements upload and download functionality.

    Each manifest's hash is contained inside its parent's manifest.

    When consistency=True, we check the path in the Merkle tree of manifests all the way to the
    root. This is the correct thing to do when changing the contents of a repository, such as by
    adding a new image.

    When downloading content we prioritize speed over correctness (we can just retry if it fails),
    so we can set consistency=False.
    """

    path_local: Path = attr.ib()
    dedup: de.Dedup = attr.ib()
    accessor: RemoteRepoAccessor | None = attr.ib()
    consistency: bool = attr.ib(kw_only=True, default=True)
    manifest_cache_size: int = attr.ib(kw_only=True, default=1024)
    _download_locks = attr.ib(factory=dict, init=False)

    def __attrs_post_init__(self):
        self.reset_manifest_cache()

    def reset_manifest_cache(self):
        self.parse_manifest_cached = functools.lru_cache(self.manifest_cache_size)(
            self._parse_manifest
        )

    def _lock_download(self, k):
        if (v := (d := self._download_locks).get(k)) is None:
            return d.setdefault(k, threading.RLock())
        else:
            return v

    def _clear_download_locks(self):
        self._download_locks.clear()

    def _parse_manifest(self, p: PurePosixPath) -> tuple[mh.Digest, ManifestNode]:
        p = self.path_local / p
        reader = ManifestNodeReader.from_bytes(p.read_bytes())
        return reader.out_claimed_digest, reader.out_verified_data

    def _download_manifest(
        self, remote_path: PurePosixPath, destination: Path, required_digest: mh.Digest = None
    ) -> tuple[mh.Digest, ManifestNode]:
        if (accessor := self.accessor) is None:
            raise RepoFileNotFoundError(filename=remote_path, local_base_path=self.path_local)
        with self._lock_download(destination), accessor.download_open(remote_path) as file:
            _feed = (reader := ManifestNodeReader()).parser.feed
            q = BytesQueue()

            def feed(b):
                if b:
                    q.append(b)
                _feed(b)

            def _download_remaining_data():
                yield from q.data
                while block := file.read(65536):
                    feed(block)
                    yield block
                feed(None)

            # first we download the header to check the digest and maybe avoid downloading the rest
            block = True
            while block:
                block = file.read(256)
                feed(block if block else None)
                if (digest := reader.out_claimed_digest) is not None:
                    # OK, we have our digest
                    break
            else:
                raise AssertionError("no digest available but no error from parser?")

            if required_digest is not None and digest != required_digest:
                raise ValueError(
                    f"manifest hash at {str(remote_path)!r} does not match expected value"
                )

            _open = lambda: FileAdapterFromGeneratorBytes(_download_remaining_data())
            destination.parent.mkdir(exist_ok=True, parents=True)
            req = self.make_manifest_link_request(digest, destination, dict(open_file_once=_open))
            self.dedup.run_batch([req])

        if not reader.parser.eof:
            # We skipped the download because we found cached content, so we need to feed the
            # remaining cached content into the parser.
            with destination.open("rb") as file:
                file.seek(reader.input_position)
                while block := file.read(65536):
                    _feed(block)
            _feed(None)

        return digest, reader.out_verified_data

    @classmethod
    def make_manifest_link_request(cls, manifest_digest, destination, kwargs):
        return de.DedupLinkRequest(
            hash_function=manifest_digest.function,
            link_path=destination,
            file_metadata=de.DedupFileMetadata.make_plain(),
            file_contents_hash=None,
            tags={cls.make_manifest_digest_tag(manifest_digest)},
            **kwargs,
        )

    @staticmethod
    def make_manifest_digest_tag(manifest_digest):
        return b"vmf:" + manifest_digest.to_multihash_bytes()

    @staticmethod
    def make_hash_32_path(digest: mh.Digest):
        return PurePosixPath(digest.digest[:4].hex("/")) / "i.cbor"

    def _upload_file(self, local_path, remote_path):
        self.accessor.upload(local_path, remote_path)

    def _local(self, p: PurePosixPath) -> Path:
        return self.path_local / p

    @staticmethod
    def _wrap_exc_to_queue(q, func):
        def wrapped(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except BaseException as exc:
                q.put((exc,))
                raise

        return wrapped

    def upload_full(
        self,
        check_root_digest: ty.Callable[[mh.Digest], None],
        max_workers: int = None,
        full_overwrite: bool = False,
        source: RepoTransfer = None,
    ):
        if source is None:
            source = self

        q = Queue()

        def _notify_finished(p: PurePosixPath):
            q.put((None, "finish", p))

        _wrap_exc_to_queue = functools.partial(self._wrap_exc_to_queue, q)

        @_wrap_exc_to_queue
        def _handle_file(p: PurePosixPath):
            with source.open(p) as f:
                self._upload_file(f, p)
            _notify_finished(p)

        @_wrap_exc_to_queue
        def _handle_dir(p: PurePosixPath, is_root=False):
            source._ensure_manifests(p)
            new_digest, new_node = source.parse_manifest_cached(p / "manifest.bin")

            old_node = old_digest = None
            if not full_overwrite or is_root:
                try:
                    old_digest, old_node = self._download_manifest(
                        p / "manifest.bin",
                        tmp_dir_path / f"m{threading.get_ident()}.bin",
                    )
                except FileNotFoundError:
                    pass
                except Exception:
                    logger.warning(
                        "error downloading existing manifest",
                        exc_info=True,
                        data_path=str(p / "manifest.bin"),
                    )

                if is_root:
                    check_root_digest(old_digest)

            if not full_overwrite:
                if old_digest == new_digest:
                    _notify_finished(p)
                    return

            with source.open(p / "manifest.bin") as f:
                self._upload_file(f, "new" / p / "manifest.bin")

            if full_overwrite:
                # forcibly overwrite all content
                old_node = None

            remaining[p] = remaining_set = set()
            to_spawn = []
            for k, v in new_node.children.items():
                if old_node is None or old_node.children.get(k) != v:
                    # this file or directory is different, so we will need to recurse into it
                    child = p / k
                    is_dir, digest = v
                    remaining_set.add(child)
                    if is_dir:
                        to_spawn.append((None, "spawn", _handle_dir, child))
                    else:
                        to_spawn.append((None, "spawn", _handle_file, child))

            if to_spawn:
                for x in to_spawn:
                    q.put(x)
            else:
                # We are finished already, there was nothing to spawn.
                _notify_finished(p)

        @_wrap_exc_to_queue
        def _handle_dir_exit(p: PurePosixPath):
            with source.open(p / "manifest.bin") as f:
                self._upload_file(f, p / "manifest.bin")
            _notify_finished(p)

        root = PurePosixPath(".")
        remaining: dict[PurePosixPath, set[PurePosixPath]] = {}
        q.put((None, "spawn", _handle_dir, root, True))

        with self.dedup.temporary_directory() as tmp_dir_path, ThreadPoolExecutor(
            max_workers=max_workers
        ) as exe:
            try:
                while True:
                    msg = q.get()
                    if (exc := msg[0]) is not None:
                        raise exc
                    if msg[1] == "spawn":
                        exe.submit(msg[2], *msg[3:])
                    elif msg[1] == "finish":
                        p = msg[2]
                        if p == root:
                            break
                        (rem := remaining[parent := p.parent]).discard(p)
                        if not rem:  # that was the last child, we can finalize this dir
                            exe.submit(_handle_dir_exit, parent)
            finally:
                exe.shutdown(cancel_futures=True)
        self._clear_download_locks()

    def download_full(
        self, max_workers: int = None, archives: bool = True, manifest_only: bool = False
    ):
        def _should_download(path: PurePosixPath) -> bool:
            if manifest_only:
                return False
            return not (not archives and path.name.startswith("a."))

        q = Queue()
        _wrap_exc_to_queue = functools.partial(self._wrap_exc_to_queue, q)

        @_wrap_exc_to_queue
        def _download_file(p):
            if _should_download(p):
                with self.open(p):
                    pass

            q.put((None, "finish"))

        @_wrap_exc_to_queue
        def _download_dir(p):
            mf_path = p / "manifest.bin"
            try:
                _, node = self.parse_manifest_cached(mf_path)
            except FileNotFoundError:
                with self.open(mf_path) as f:
                    pass
                _, node = self.parse_manifest_cached(mf_path)

            for name, (is_dir, digest) in node.children.items():
                c = p / name
                if is_dir:
                    q.put((None, "spawn", _download_dir, c))
                else:
                    q.put((None, "spawn", _download_file, c))

            q.put((None, "finish"))

        self.reset_manifest_cache()
        with self.open(PurePosixPath("manifest.bin")) as f:
            pass  # ensure the root manifest is present

        q.put((None, "spawn", _download_dir, PurePosixPath(".")))
        with ThreadPoolExecutor(max_workers=max_workers) as exe:
            try:
                active = 0
                while not q.empty() or active > 0:
                    msg = q.get()
                    if (exc := msg[0]) is not None:
                        raise exc
                    if msg[1] == "spawn":
                        active += 1
                        exe.submit(msg[2], *msg[3:])
                    elif msg[1] == "finish":
                        active -= 1
            finally:
                exe.shutdown(cancel_futures=True)
        self._clear_download_locks()

    def _integer_to_path(self, i: int):
        return PurePosixPath(IntegerToPath(file_suffix="_d")(i))

    DEFAULT_CBOR_MAX_SIZE = 2**24

    def _ensure_manifests(self, path: PurePosixPath) -> ManifestNode:
        """
        Verify hash tree of manifests up to and including ``path / "manifest.bin"``. Download
        missing manifests.
        """
        base = self.path_local

        def _dl(x, manifest_digest):
            xm = x / "manifest.bin"
            dst = base / xm

            with self._lock_download(dst):
                if manifest_digest is not None:
                    if not (d := base / x).exists():
                        d.mkdir(exist_ok=True, parents=True)
                    req = self.make_manifest_link_request(
                        manifest_digest, dst, dict(open_file_once=None)
                    )
                    try:
                        self.dedup.run_batch([req])
                    except de.BatchError:
                        pass
                    else:
                        return self.parse_manifest_cached(xm)
                return self._download_manifest(xm, dst, required_digest=manifest_digest)

        p = path
        todo = []
        mf_node = mf_digest = None
        while True:
            if (mf_path := base / p / "manifest.bin").exists():
                # ok found one that exists, just use it
                mf_digest, mf_node = self.parse_manifest_cached(p / "manifest.bin")
                break

            if p.parts:
                todo.append(p)
                p = p.parent
            else:
                break

        if mf_node is None:
            # we need to download the root manifest
            mf_digest, mf_node = _dl(p, None)

        todo.reverse()
        for p in todo:
            parent_node: ManifestNode = mf_node
            try:
                is_dir, digest = parent_node.children[p.name]
            except KeyError:
                raise RepoFileNotFoundError(filename=p)
            mf_digest, mf_node = _dl(p, digest)
            if not is_dir:
                raise RepoFileNotFoundError(filename=p, message="not a directory")
            if mf_digest != digest:
                raise ValueError(
                    f"manifest {str(p)!r} digest {mf_digest!r} does not match parent node value {digest}"
                )

        return mf_node

    def open(self, path: PurePosixPath):
        loc = self.path_local
        acc = self.accessor
        mf_path = path.parent / "manifest.bin"
        if (loc_path := loc / path).exists():
            # don't even check the manifest for existing local files
            return loc_path.open("rb")

        def _not_found():
            raise RepoFileNotFoundError(
                filename=path, remote_accessor=self.accessor, local_base_path=self.path_local
            ) from None

        if self.consistency:
            node = self._ensure_manifests(path.parent)
        else:
            try:
                _, node = self.parse_manifest_cached(mf_path)
            except FileNotFoundError:
                if acc is None:
                    raise
                _, node = self._download_manifest(mf_path, loc / mf_path)

        if mf_path == path:
            # goofy - caller is trying to open the manifest itself
            return loc_path.open("rb")

        try:
            is_dir, digest = node.children[path.name]
        except KeyError:
            _not_found()
        if is_dir:
            _not_found()
        if (fp := self.dedup.open_by_hash(digest)) is not None:
            return fp

        if mf_path == path:
            # goofy - caller is trying to open the manifest itself
            return loc_path.open("rb")

        with self._lock_download(loc_path):
            _open = None if acc is None else (lambda: acc.download_open(path))

            req = de.DedupLinkRequest(
                hash_function=digest.function,
                link_path=loc_path,
                file_metadata=de.DedupFileMetadata.make_plain(),
                file_contents_hash=digest,
                open_file_once=_open,
            )
            # TODO: handle de.MissingContentError
            try:
                self.dedup.run_batch([req])
            except de.BatchError as exc:
                raise exc.requests[0].exc from None
            return loc_path.open("rb")

    @contextlib.contextmanager
    def open_compressed(self, path: PurePosixPath):
        # TODO: use gz if zstd not available
        p = path.parent / (path.name + ".xz")
        with self.open(p) as f1:
            with cx.open_decompressor(f1, "xz") as f:
                yield f

    def download_shard(self, shard_digest: mh.Digest) -> int | None:
        shard_hashes_path = "shard-by-hash-32" / self.make_hash_32_path(shard_digest)
        try:
            shard_hash_to_id = self._read_cbor(shard_hashes_path)
        except RepoFileNotFoundError:
            return None
        try:
            shard_id = shard_hash_to_id[shard_digest.digest]
        except KeyError:
            return None
        assert_(type(shard_id) is int)
        return shard_id

    def _read_cbor(self, path):
        max_size = self.DEFAULT_CBOR_MAX_SIZE
        with self.open(path) as f:
            return cbor_load(f, max_size=max_size)

    def _pre_download_paths(self, paths, max_workers):
        def _dl(x):
            try:
                path, is_compressed = x
                with (self.open_compressed if is_compressed else self.open)(path):
                    pass
            except Exception:
                logger.warning(
                    "error when pre-downloading path", data_path=str(path), exc_info=True
                )

        with ThreadPoolExecutor(max_workers=max_workers) as exe:
            for x in paths:
                exe.submit(_dl, x)

    def download_image(self, image_id: str, download_archives: bool = True, max_workers=None):
        # download image index to locate image ID by hash
        # download image metadata cbor and ID of latest image-to-shard mapping
        # download image-to-shard mapping
        # select shard set
        # for each shard, download metadata + ID of latest shard-to-archive mapping
        # download shard-to-archive mapping
        # select archive set
        digest = mh.registry.decode(image_id)
        hf = digest.function

        def _read_cbor_int(path) -> int:
            with self.open(path) as f:
                value: int = cbor_load(f, max_size=1024)
                assert_(type(value) is int)
            return value

        _read_cbor = self._read_cbor

        def _read_compressed_cbor(path, max_size=None):
            if max_size is None:
                max_size = self.DEFAULT_CBOR_MAX_SIZE
            with self.open_compressed(path) as f:
                return cbor_load(f, max_size=max_size)

        logger.info("download image information")

        try:
            image_hashes_path = "image-by-hash-32" / self.make_hash_32_path(digest)
            image_hash_to_id = _read_cbor(image_hashes_path)
            img_id = image_hash_to_id[digest.digest]
        except Exception as exc:
            raise ImageNotFoundError(image_id=image_id) from exc
        assert_(type(img_id) is int)

        image_path = "image" / self._integer_to_path(img_id)

        with self.open_compressed(image_path / "u") as f:
            image_meta_hash = hf().update(f.read()).digest()

        i2s_path = "is" / self._integer_to_path(_read_cbor_int(image_path / "is.cbor"))

        with self.open_compressed(i2s_path / "m") as f:
            # HACK: gathering all shards instead of being smart
            shard_ids: list[int] = cbor_loads(f.read())[0]
            assert_(type(shard_ids) is list)
            assert_(all(type(x) is int for x in shard_ids))

        logger.info("pre-download shard information")
        paths = []
        for shard_id in shard_ids:
            shard_path = "shard" / self._integer_to_path(shard_id)
            paths += (
                (shard_path / "p", True),
                (shard_path / "h.bin", False),
                (shard_path / "sa.cbor", False),
            )
        self._pre_download_paths(paths, max_workers=max_workers)
        self._clear_download_locks()

        digest_size = hf.digest_size
        shard_entries: dict[str, im.SingleFileImageMetadata] = {}
        for shard_id in shard_ids:
            shard_path = "shard" / self._integer_to_path(shard_id)

            shard_entry_data = _read_compressed_cbor(shard_path / "p")

            with self.open(shard_path / "h.bin") as f:
                for data in shard_entry_data:
                    entry = im.SingleFileImageMetadata.from_shard_entry(
                        data, hf.digest_from_bytes(f.read(digest_size))
                    )
                    shard_entries[entry.path] = entry

        computed_image_hash = (
            hf()
            .update_iter(
                image_file_entries_for_hashing_iter(image_meta_hash, shard_entries.values())
            )
            .digest()
        )

        if (s := computed_image_hash.to_multihash_base64url()) != image_id:
            raise ValueError(f"image hash does not match, expected {image_id}, calculated {s}")

        digest_to_shard_entries = defaultdict(list)
        for entry in shard_entries.values():
            digest_to_shard_entries[entry.digest.digest].append(entry)

        logger.info("finished shard metadata, now processing archives")
        _size_struct_size = STRUCT_ARCHIVE_SIZE.size

        def _process_shard(shard_id):
            logger.info("download shard archive", data_shard_id=shard_id)
            nonlocal digest_to_shard_entries

            shard_path = "shard" / self._integer_to_path(shard_id)
            s2a_path = "sa" / self._integer_to_path(_read_cbor_int(shard_path / "sa.cbor"))
            archive_ids = _read_compressed_cbor(s2a_path / "m")[0]
            assert_(type(archive_ids) is list)
            assert_(all(type(x) is int for x in archive_ids))

            with self.open_compressed(s2a_path / "m") as f:
                # HACK: gathering all archives instead of being smart
                archive_ids: list[int] = cbor_loads(f.read())[0]

            archive_infos = []
            for archive_id in archive_ids:
                export_inputs = []
                archive_path = "archive" / self._integer_to_path(archive_id)
                offset = 0
                with self.open(archive_path / "h.bin") as f_h, self.open_compressed(
                    archive_path / "s"
                ) as f_s:
                    while sz_bytes := f_s.read(_size_struct_size):
                        # archive file hashes and sizes
                        [size] = STRUCT_ARCHIVE_SIZE.unpack(sz_bytes)
                        digest = f_h.read(digest_size)
                        this_digest_shard_entries = digest_to_shard_entries.pop(digest, None)
                        if this_digest_shard_entries is not None:
                            export_inputs.append(
                                im.SolidArchiveFileInfo(
                                    files=this_digest_shard_entries, offset=offset, size=size
                                )
                            )
                        offset += size

                if download_archives:
                    with self.open_compressed(archive_path / "a") as f:
                        # ensure the contents are available
                        pass

                archive_infos.append(
                    ArchiveFilesExportInfo(archive_path=archive_path / "a", files=export_inputs)
                )
            return archive_infos

        with ThreadPoolExecutor(max_workers=max_workers) as exe, ut.cancel_futures_on_error(exe):
            for future in as_completed(
                exe.submit(_process_shard, shard_id) for shard_id in shard_ids
            ):
                yield from future.result()

        self._clear_download_locks()
        if digest_to_shard_entries:
            raise ValueError(f"failed to find data for items: {digest_to_shard_entries}")

    def export(
        self,
        exporter: im.VenvExporter,
        iterable: ty.Iterator[ArchiveFilesExportInfo],
        max_workers: int = None,
    ):
        def _process(archive_infos):
            with contextlib.ExitStack() as ex:
                files = []
                for archive_info in archive_infos:
                    archive_io = ex.enter_context(self.open_compressed(archive_info.archive_path))
                    files += (A(archive_io, info) for info in archive_info.files)
                if files and (fs := files[0].info.files):
                    logger.info("extracting files...", data_sample_path=str(fs[0].path))
                exporter.provide_files(files)

        def _group_archive_infos(iterable):
            n = 0
            lst = []
            for a in iterable:
                if ((n1 := len(a.files)) + n < 5000) and len(lst) < 50:
                    lst.append(a)
                    n += n1
                else:
                    yield lst
                    n = n1
                    lst = [a]
            if lst:
                yield lst

        exporter.begin_session()
        A = im.VenvExportInputFromSolidArchive
        with ThreadPoolExecutor(max_workers=max_workers) as exe, ut.cancel_futures_on_error(exe):
            ut.raise_as_completed(
                exe.submit(_process, a_info_group)
                for a_info_group in _group_archive_infos(iterable)
            )
        logger.info("done extracting, now finalizing...")
        exporter.end_session()


@attr.s(frozen=True)
class ArchiveFilesExportInfo:
    archive_path: PurePosixPath = attr.ib()
    files: tuple[im.SolidArchiveFileInfo] = attr.ib(converter=tuple)


def read_multihash(p: sansio_parser.BinaryParser, maximum_digest_size: int):
    function_code = yield from mh.multihash_varint_decode(p)
    digest_size = yield from mh.multihash_varint_decode(p)
    if digest_size > maximum_digest_size:
        raise ValueError("digest size exceeds maximum")
    digest_bytes = yield from p.read_bytes(digest_size)
    return mh.registry.decode_from_code_and_digest(function_code, digest_bytes)


@attr.s(eq=False, hash=False)
class ManifestNode:
    hash_function: mh.HashFunction = attr.ib()
    children: dict[str, tuple[bool, mh.Digest]] = attr.ib()
    _rx_child_name = re.compile(r"^[a-zA-Z0-9_-]+(?:\.[a-zA-Z0-9_-]+)*$")

    @classmethod
    def validate_child_name(cls, name: str) -> None:
        if name == "manifest.bin" or cls._rx_child_name.search(name) is None:
            raise ValueError(f"invalid child name: {name!r}")

    @classmethod
    def from_cbor_decoded(cls, hash_function: mh.HashFunction, data):
        is_dir_dict = {b"d": True, b"f": False}
        H = hash_function.digest_from_bytes
        for k in data:
            cls.validate_child_name(k)
        return cls(
            hash_function,
            {k: (is_dir_dict[v[:1]], H(v[1:])) for k, v in data.items()},
        )

    def to_bytes(self) -> tuple[bytes, mh.Digest]:
        hf = self.hash_function
        for name, (is_dir, digest) in self.children.items():
            self.validate_child_name(name)
            if digest.function != hf:
                raise AssertionError("child and parent must use the same hash function")
        d = {
            name: (b"d" if is_dir else b"f") + digest.digest
            for name, (is_dir, digest) in self.children.items()
        }
        b = cbor_dumps(d)
        h = hf().update(b).digest()
        return h.to_multihash_bytes() + b, h


@attr.s(eq=False, hash=False)
class ManifestNodeReader:
    maximum_digest_size: int = attr.ib(default=1024)
    parser = attr.ib(default=None, init=False)

    out_claimed_digest: mh.Digest = attr.ib(init=False, default=None)
    out_verified_data: ManifestNode = attr.ib(init=False, default=None)

    def __attrs_post_init__(self):
        self.parser = sansio_parser.BinaryParser(self._parse)

    def _parse(self, p: sansio_parser.BinaryParser):
        digest_top = yield from read_multihash(p, self.maximum_digest_size)
        self.out_claimed_digest = digest_top
        hf = digest_top.function
        hasher_top = hf()

        q2 = BytesQueue()
        while not p.eof:
            while p.queue:
                hasher_top.update(p.queue.popleft_any_to(q2))
            yield

        if digest_top != hasher_top.digest():
            raise ValueError("content does not match top-level hash")

        self.out_verified_data = ManifestNode.from_cbor_decoded(hf, cbor2.loads(bytes(q2)))

    @property
    def input_position(self) -> int:
        return self.parser.position + len(self.parser.queue)

    @classmethod
    def from_bytes(cls, data):
        (self := cls()).parser.feed(data).feed(None)
        return self

    @classmethod
    def parse_bytes(cls, data: bytes | memoryview):
        return cls.from_data(data).out_verified_data


class RemoteRepoAccessor(abc.ABC):
    def download(self, path: Path, remote_path: PurePosixPath):
        raise NotImplementedError
        if path.is_file():
            offset = path.stat().st_size
        with self.download_open_iter(remote_path=remote_path, offset=offset) as xs, path.open(
            "w+b"
        ) as fw:
            fw.seek(offset)
            for block in xs:
                fw.write(block)

    @abc.abstractmethod
    def download_open(
        self, remote_path: PurePosixPath, offset: int = 0
    ) -> ty.ContextManager[ty.BinaryIO]: ...

    @abc.abstractmethod
    def upload(self, path: Path, remote_path: PurePosixPath): ...


@attr.s(eq=False, hash=False)
class RemoteRepoAccessorFilesystem(RemoteRepoAccessor):
    base_path: Path = attr.ib()

    @contextlib.contextmanager
    def download_open(self, remote_path: PurePosixPath, offset: int = 0):
        with (self.base_path / remote_path).open("rb") as f:
            if offset:
                f.seek(offset)
            yield f

    def upload(self, path, remote_path):
        dst = self.base_path / remote_path
        if dst.exists():
            try:
                dst.unlink()
            except OSError:
                shutil.rmtree(dst)

        dst.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(path, Path):
            shutil.copyfile(str(path), str(dst), follow_symlinks=False)
        else:
            with dst.open("wb") as f:
                shutil.copyfileobj(path, f)
