from pathlib import Path, PurePosixPath

import attr

from . import multihash as mh


@attr.s(auto_exc=True, str=False)
class RepoFileNotFoundError(Exception):
    message = attr.ib(default="repository file not found")
    filename: PurePosixPath | None = attr.ib(default=None)
    remote_accessor = attr.ib(default=None)
    local_base_path: Path | None = attr.ib(default=None)


@attr.s(auto_exc=True, str=False)
class ImageNotFoundError(Exception):
    message = attr.ib(default="image not found")
    image_id = attr.ib(default=None)


@attr.s(auto_exc=True, str=False)
class BadHashError(Exception):
    message = attr.ib(
        default="""Manifest hash does not match parent. Either the repository is corrupt or in \
the middle of an upload, in which case you should retry the operation."""
    )
    path = attr.ib(default=None)
    digest_expected = attr.ib(default=None)
    digest_observed = attr.ib(default=None)


@attr.s(auto_exc=True, str=False)
class ForbiddenStringError(Exception):
    message = attr.ib(default="substring not allowed here")
    path = attr.ib(default=None)
    substring = attr.ib(default=None)


@attr.s(auto_exc=True, hash=False, str=True)
class LocalRepositoryExistsError(ValueError):
    message: str = attr.ib(default="local repository already exists")
    repo_path: Path = attr.ib(default=None)


@attr.s(auto_exc=True, hash=False, str=True)
class LocalRepositoryInvalidError(ValueError):
    message: str = attr.ib(default="local repository does not exist or is corrupted")
    repo_path: Path = attr.ib(default=None)


@attr.s(auto_exc=True, str=False)
class RepoTopLevelHashChanged(Exception):
    message = attr.ib(
        default="remote repository digest changed, not proceeding to prevent corruption"
    )
    expected: mh.Digest = attr.ib(default=None)
    observed: mh.Digest = attr.ib(default=None)
