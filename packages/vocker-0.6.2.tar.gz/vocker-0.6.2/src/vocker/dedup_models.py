from __future__ import annotations

import dataclasses
import typing as ty

import attr
import sqlalchemy as sa
from sqlalchemy import orm as sao
from sqlalchemy.orm import Mapped as M, mapped_column as mc, relationship, DeclarativeBase
from sqlalchemy_boltons.orm import RelationshipComparator as Rel
from sqlalchemy_boltons.temporary import CacheTemporaryMetaData as CacheTmp, MetaDataMaker

from . import multihash as mh
from .util_models import now, rel_kw_basic, rel_kw_cascade


class BaseDedup(DeclarativeBase):
    pass


_make_file_fk = lambda: sa.ForeignKey("dedup_file.id", ondelete="CASCADE")
_make_obj_fk = lambda: sa.ForeignKey("dedup_obj.id", ondelete="CASCADE")
_make_pending_fk = lambda: sa.ForeignKey("dedup_pending.id", ondelete="CASCADE")


@BaseDedup.registry.mapped_as_dataclass(init=False)
class DedupConfig:
    __tablename__ = "dedup_config"

    key: M[str] = mc(primary_key=True)
    value: M[str] = mc()


@BaseDedup.registry.mapped_as_dataclass(init=False)
class Obj:
    __tablename__ = "dedup_obj"
    """
    Represents an idealized deduplicated file. There may be multiple actual filesystem files
    associated to this idealized object.

    When an Obj has no more links, :attr:`orphaned_at` is set to the current time.

    When a File has no more links, and there are other Files with the same content, we should delete
    all but one of the Files. This is not implemented yet.

    Incomplete: Obj exists, has no File with pending_id != None.
    Complete: Obj exists, has at least one File with pending_id == None,

    Lifecycle:
    1. Incomplete + Used: Newly created object, data not written yet.
    2. Complete + Used: Data written, links created.
    3. Complete + Unused: Data written, no more links exist.
    4. Incomplete + Unused: Data maybe deleted, no more links exist.
    """

    id: M[int] = mc(primary_key=True)
    pending_id: M[int | None] = mc(_make_pending_fk())
    metadata_bytes: M[bytes] = mc("metadata")
    size: M[int] = mc()
    created_at: M[int] = mc()
    updated_at: M[int] = mc(server_default=sa.text("-1"), index=True)
    orphaned_at: M[int | None] = mc()

    files: M[list["File"]] = relationship(back_populates="obj", **rel_kw_cascade)
    tags: M[list["Tag"]] = relationship(back_populates="obj", **rel_kw_cascade)
    hashes: M[list["Hash"]] = relationship(back_populates="obj", **rel_kw_cascade)
    pending: M["Pending | None"] = relationship(back_populates="objs", **rel_kw_basic)

    @property
    def hashes_dict(self):
        return {(h := x.to_digest()).function: h for x in self.hashes}

    @classmethod
    def q_is_complete(cls):
        F = sao.aliased(File)
        return sa.exists().select_from(F).where(Rel(F.obj) == cls, F.pending_id == None)

    @classmethod
    def q_is_orphaned(cls):
        F = sao.aliased(File)
        return ~sa.exists().select_from(F).where(Rel(F.obj) == cls, F.link_count != 0)

    @classmethod
    def make_sql_update_orphaned(cls, orphaned_at_now):
        """
        Construct the SQL DML statement which sets :attr:`orphaned_at` according to whether any
        links are left that point to this dedup file.
        """
        return sa.update(cls).values(
            orphaned_at=sa.case(
                # If a Link exists, then it's NULL.
                (~cls.q_is_orphaned(), None),
                # If the orphaned_at file was set in the past, then keep that value.
                (cls.orphaned_at < orphaned_at_now, cls.orphaned_at),
                # Otherwise, set it to the current timestamp.
                else_=orphaned_at_now,
            )
        )


@BaseDedup.registry.mapped_as_dataclass(init=False)
class File:
    """
    Represents a single deduplicated file regardless of backend (hardlink, symlink, reflink).

    The file contents may not yet be available if :attr:`pending_id` is not NULL.

    If :attr:`obj_id` is NULL, then the File has been (probably) deleted and in a future transaction
    the row should also be deleted if the file is confirmed deleted.
    """

    __tablename__ = "dedup_file"

    # this is used as a speedup when verifying hardlinks
    _cached_file_stat = None

    id: M[int] = mc(primary_key=True)
    obj_id: M[int | None] = mc(_make_obj_fk(), index=True)
    link_count: M[int] = mc(server_default=sa.text("-1"))
    pending_id: M[int | None] = mc(sa.ForeignKey("dedup_pending.id", ondelete="CASCADE"))
    created_at: M[int | None] = mc()

    obj: M[list[Obj]] = relationship(back_populates="files", **rel_kw_cascade)
    links: M[list["Link"]] = relationship(back_populates="file", **rel_kw_cascade)
    pending: M["Pending | None"] = relationship(back_populates="files", **rel_kw_basic)


@BaseDedup.registry.mapped_as_dataclass(init=False)
class FileCorruption:
    """
    Represents information about a corrupted file.
    """

    __tablename__ = "dedup_file_corrupt"
    id: M[int] = mc(sa.ForeignKey("dedup_file.id", ondelete="CASCADE"), primary_key=True)
    exception_name: M[str] = mc()
    exception_string: M[str] = mc()


@BaseDedup.registry.mapped_as_dataclass(init=False)
class Pending:
    __tablename__ = "dedup_pending"

    id: M[int] = mc(primary_key=True)
    expire_at: M[int] = mc()

    files: M[list["File"]] = relationship(back_populates="pending", **rel_kw_cascade)
    objs: M[list["Obj"]] = relationship(back_populates="pending", **rel_kw_cascade)


@BaseDedup.registry.mapped_as_dataclass(init=False)
class Link:
    """A link (usage) of a deduplicated file."""

    __tablename__ = "dedup_link"

    path: M[bytes] = mc(primary_key=True)  # utf-8 encoded
    file_id: M[int] = mc(_make_file_fk(), index=True)
    mtime: M[int | None] = mc()  # whether this field means anything depends on the backend
    created_at: M[int | None] = mc()

    file: M["File"] = relationship(back_populates="links", **rel_kw_basic)


_tmp_meta = sa.MetaData()
tmp_bytes = sa.Table("bytes", _tmp_meta, sa.Column("id", sa.LargeBinary, primary_key=True))
tmp_ints = sa.Table("ints", _tmp_meta, sa.Column("id", sa.Integer, primary_key=True))


@attr.s(frozen=True)
class TmpNewFiles:
    files: sa.Table = attr.ib()
    tags: sa.Table = attr.ib()
    hashes: sa.Table = attr.ib()


@attr.s(frozen=True)
class TmpNewFiles2:
    files: sa.Table = attr.ib()
    links: sa.Table = attr.ib()
    objs: sa.Table = attr.ib()


@attr.s(frozen=True)
class TmpCheckLinks:
    links: sa.Table = attr.ib()


@attr.s(frozen=True)
class TmpDeleteExtra:
    files: sa.Table = attr.ib()


def _make_temp_new_files(maker: MetaDataMaker):
    # If an Obj has already-available contents in a File, then that File's id is written to
    # content_file_id. Otherwise it is NULL.
    files = maker.table(
        "files",
        sa.Column("id", sa.Integer, primary_key=True, nullable=False),
        sa.Column("link_path", sa.LargeBinary, nullable=True),
        sa.Column("metadata_bytes", sa.LargeBinary),
        sa.Column("insert_obj_if_missing", sa.Boolean),
        # sa.Column("adopt_existing", sa.Boolean, server_default=text("0")),
        sa.Column("obj_id", sa.Integer, nullable=True),  # ref: Obj.id
        sa.Column("new_obj_id", sa.Integer, nullable=True),  # ref: Obj.id
    )
    tags = maker.table(
        "files_by_tag",
        sa.Column("id", sa.Integer, primary_key=True, index=True),  # ref: temp.files.id
        sa.Column("name", sa.LargeBinary, primary_key=True),
    )
    hashes = maker.table(
        "files_by_hash",
        sa.Column("id", sa.Integer, primary_key=True),  # ref: temp.files.id
        sa.Column("hash_function", sa.Integer, primary_key=True),
        sa.Column("hash", sa.LargeBinary),
    )
    return TmpNewFiles(files=files, tags=tags, hashes=hashes)


def _make_temp_new_files2(maker: MetaDataMaker):
    files = maker.table(
        "files",
        sa.Column("file_id", sa.Integer, primary_key=True, nullable=False),
        sa.Column("obj_id", sa.Integer),
    )
    links = maker.table(
        "links",
        sa.Column("surrogate_id", sa.Integer, primary_key=True),
        sa.Column("link_path", sa.LargeBinary),
        sa.Column("file_id", sa.Integer),
        sa.Column("link_count", sa.Integer),
    )
    objs = maker.table(
        "objs",
        sa.Column("obj_id", sa.Integer, primary_key=True, nullable=False),
        sa.Column("size", sa.Integer),
    )
    return TmpNewFiles2(files=files, links=links, objs=objs)


def _make_temp_check_lx(maker: MetaDataMaker):
    links = maker.table(
        "links",
        sa.Column("path", sa.LargeBinary, primary_key=True, nullable=False),
    )
    return TmpCheckLinks(links)


def _make_temp_delete_extra(maker: MetaDataMaker):
    files = maker.table(
        "files",
        sa.Column("id", sa.Integer, primary_key=True, nullable=False),
    )
    return TmpDeleteExtra(files)


tmp_new_files: CacheTmp[TmpNewFiles] = CacheTmp(_make_temp_new_files)
tmp_new_files2: CacheTmp[TmpNewFiles2] = CacheTmp(_make_temp_new_files2)
tmp_check_links: CacheTmp[TmpCheckLinks] = CacheTmp(_make_temp_check_lx)
tmp_delete_extra: CacheTmp[TmpDeleteExtra] = CacheTmp(_make_temp_delete_extra)


@BaseDedup.registry.mapped_as_dataclass(init=False)
class Tag:
    __tablename__ = "dedup_tag"

    obj_id: M[int] = mc(_make_obj_fk(), primary_key=True)
    name: M[bytes] = mc(primary_key=True, index=True)

    obj: M["Obj"] = relationship(back_populates="tags", **rel_kw_basic)


@BaseDedup.registry.mapped_as_dataclass(init=False)
class Hash:
    __tablename__ = "dedup_hashes"

    obj_id: M[int] = mc(_make_obj_fk(), primary_key=True)
    hash_function: M[int] = mc(primary_key=True)
    hash: M[bytes] = mc(index=True)

    obj: M["Obj"] = relationship(back_populates="hashes", **rel_kw_basic)

    @classmethod
    def from_digest(cls, digest: mh.Digest, **kw):
        return cls(hash_function=digest.function.function_code, hash=digest.digest, **kw)

    def to_digest(self):
        return mh.registry.decode_from_code_and_digest(self.hash_function, self.hash)

    @classmethod
    def compare_digest(cls):
        return _HashCompareByDigest(cls)


@dataclasses.dataclass(eq=False)
class _HashCompareByDigest:
    alias: type[Hash]

    def in_(self, digests: ty.Iterable[mh.Digest]):
        a = self.alias
        return sa.tuple_(a.hash, a.hash_function).in_(
            (x.digest, x.function.function_code) for x in digests
        )

    def __eq__(self, other):
        if isinstance(other, mh.Digest):
            a = self.alias
            return sa.and_(a.hash == other.digest, a.hash_function == other.function.function_code)

        return NotImplemented

    def __ne__(self, other):
        return sa.not_(self == other)


sa.Index("ix_dedup_obj_pending_partial", Obj.pending_id, sqlite_where=Obj.pending_id != None)
sa.Index("ix_dedup_file_pending_partial", File.pending_id, sqlite_where=File.pending_id != None)
sa.Index("ix_dedup_obj_orphaned_at_partial", Obj.orphaned_at, sqlite_where=Obj.orphaned_at != None)
sa.Index("ix_dedup_file_link_count", File.obj_id, sa.desc(File.link_count))
sa.Index(
    "ix_dedup_file_link_count_invalid",
    File.id,
    sqlite_where=File.link_count < sa.literal_column("0"),
)
sa.Index(
    "ix_dedup_obj_created_at_partial",
    Obj.created_at,
    sqlite_where=Obj.created_at < sa.literal_column("0"),
)
