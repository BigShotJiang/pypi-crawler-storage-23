from __future__ import annotations

import argparse
from pathlib import Path
import re
import functools
import json
import sys
import typing as ty

import structlog

from .util import parse_pure_path, pprofile

logger = structlog.get_logger(__name__)


rx_probably_uri = re.compile(r"^[a-z-]+://")


def syst():
    from . import system as syst

    return syst


def _remote_repo_name(s):
    if not s.startswith("@"):
        raise ValueError("remote repository name must be start with a @")

    return s[1:]


def _local_repo_name(s):
    if s.startswith("@"):
        raise ValueError("local repository name cannot start with @")

    return s


def _abspath(s):
    return Path(s).absolute()


class Main:
    def __init__(self, argv, *, path_base=None):
        self.argument_parser = self.init_argparser()
        self.a = self.argument_parser.parse_args(argv)
        self.path_base = path_base

    def cmd_missing(self):
        self.argument_parser.error("missing command")

    @functools.cached_property
    def system(self):
        return syst().System(path_base=self.path_base)

    def cmd_repo_list(self):
        has_invalid = False
        d = {}
        for r in self.system.repo_list():
            if not (valid := r.check()):
                has_invalid = True
            d[r.name] = "ok" if valid else "damaged"
        comment = ""
        if has_invalid:
            comment = """There are damaged/invalid local repositories. This can happen if a local \
repository operation was interrupted (via a crash, an unexpected power loss, or Ctrl-C)."""
        return dict(repos=d, comment=comment)

    def cmd_repo_init(self):
        self.system.repo_init_new(self.a.local_name, self.a.hash_function)

    def cmd_repo_upload(self):
        a = self.a
        self.system.repo_upload(
            a.local_name, a.remote_uri, force=a.force, full_overwrite=a.full_overwrite
        )

    def cmd_repo_download(self):
        self.system.repo_download(
            self.a.remote_uri,
            self.a.local_name,
            shallow=self.a.shallow,
            archives=not self.a.no_archives,
        )

    def cmd_repo_rm(self):
        self.system.repo_get(self.a.local_name).delete()

    def cmd_image_import(self):
        if (t := self.a.type) == "auto":
            t = None
        return self.system.repo_add_image(
            repo_name=self.a.repository,
            image_path=self.a.input,
            image_type=t,
            mock_image_path=self.a.mock_image_path,
        )

    def cmd_image_export(self):
        audit = self.a.audit
        trusted = self.a.trusted
        use_sys_python = self.a.mock_use_system_python
        if (audit + trusted + use_sys_python) != 1:
            raise ValueError(
                "provide exactly one of --trusted or --audit or --mock-use-system-python"
            )

        if (repo_name := self.a.repo_name).startswith("local:"):
            kw = dict(repo_name=repo_name[6:])
        else:
            kw = dict(remote_uri=repo_name)
        return self.system.export_image(
            image_id=self.a.image_id,
            target=self.a.target,
            mock_target=self.a.mock_target,
            mock_use_system_python=use_sys_python,
            audit_mode=audit,
            **kw,
        )

    def cmd_gc(self):
        d = dict(main=self.system.dedup, repo=self.system.repo_dedup)
        dedups_keys = set()
        a = self.a
        max_age = a.max_age
        check_integrity = a.check_integrity
        check_links = a.check_links
        if a.main:
            dedups_keys.add("main")
        if a.repo:
            dedups_keys.add("repo")
        if a.full:
            dedups_keys.update(("main", "repo"))
            check_integrity = True
            check_links = True
            if max_age is None:
                max_age = 3600
        dedups = tuple(d[k] for k in dedups_keys)
        check_links_under: ty.Sequence[Path] = a.check_links_under or ()

        for k in dedups_keys:
            dedup = d[k]
            logger.info("Starting to gc.", data_dedup=k)
            if check_links:
                logger.info("Checking links.")
                dedup.check_links()
            elif check_links_under:
                for p in check_links_under:
                    logger.info(f"Checking links under user path.", data_path=str(p))
                    dedup.check_links(p)

            if check_integrity:
                logger.info("Checking integrity.")
                dedup.integrity_check(skip_same_mtime=True)
                dedup.garbage_collect_extra_files()

            if max_age is not None:
                logger.info("Deleting unused files.", data_max_age_seconds=max_age)
                dedup.garbage_collect_dedup_files(max_age)

        def _info(dedup):
            return {
                "corrupted": [c.to_json() for c in dedup.corrupted_list()],
                "#comments": [],
            }

        result = {"dedup": {k: _info(v) for k, v in d.items()}, "comments": []}

        if not dedups:
            result["comments"].append(
                """No actions taken. You must use --main and/or --repo to specify which \
files to act on, or use --full to perform all cleanup actions against all of the files."""
            )

        return result

    def cmd_stats(self):
        def f(dedup):
            stats = dedup.compute_stats()
            if stats.dedup_total_bytes:
                ratio = stats.link_total_bytes / stats.dedup_total_bytes
            else:
                ratio = 1.0
            return stats.to_json() | {"#space_savings_ratio": ratio}

        d = dict(main=self.system.dedup, repo=self.system.repo_dedup)
        return {k: f(v) for k, v in d.items()}

    def init_argparser(self):
        parser = argparse.ArgumentParser()
        parser.set_defaults(callback=self.cmd_missing)
        subparsers = parser.add_subparsers()
        sub_repo = subparsers.add_parser("repo").add_subparsers()
        sub_img = subparsers.add_parser("image").add_subparsers()

        p = {}

        def _add_parser(___parent, ___name):
            def f(*args, **kwargs):
                a = p[___name] = ___parent.add_parser(*args, **kwargs)
                a.set_defaults(callback=getattr(self, "cmd_" + ___name))
                return a

            return f

        def _Path(x):
            return Path(x).resolve()

        _add_parser(sub_repo, "repo_upload")(
            "upload",
            description="""\
Upload local repository copy to remote.""",
        )
        _add_parser(sub_repo, "repo_download")(
            "download",
            description="""\
Download remote repository to local.""",
        )

        def _arg_local(k):
            p[k].add_argument(
                "local_name", metavar="LOCAL-NAME", help="Name of the local repository."
            )

        p["repo_upload"].add_argument(
            "--to",
            dest="remote_uri",
            metavar="REMOTE-URI",
            help="""\
URI of the remote repository. This is optional, and by default this command will push to the same \
repository that was used to download.""",
        )
        p["repo_upload"].add_argument(
            "--full-overwrite",
            action="store_true",
            help="Forcibly overwrite all content in an attempt to fix a broken repository.",
        )
        p["repo_download"].add_argument(
            "remote_uri",
            metavar="REMOTE-URI",
            help="""\
URI of the remote repository. This URI will be saved and used for the `upload` command.""",
        )
        p["repo_download"].add_argument(
            "--shallow",
            action="store_true",
            help="Only download the root manifest. Other content is downloaded on demand.",
        )
        p["repo_download"].add_argument(
            "--no-archives",
            action="store_true",
            help="Do not download the actual archive files, only download metadata.",
        )
        _arg_local("repo_upload")
        _arg_local("repo_download")
        p["repo_upload"].add_argument(
            "--force",
            help="""\
Push the contents to the remote even if the contents have changed since the last upload or \
download command.""",
        )

        _add_parser(sub_repo, "repo_rm")("rm", description="Delete a local repository.")
        _arg_local("repo_rm")

        _add_parser(sub_repo, "repo_list")(
            "list", aliases=["ls"], description="List local repositories."
        )
        _add_parser(sub_repo, "repo_init")("init", description="Create new empty local repository.")
        _arg_local("repo_init")
        p["repo_init"].add_argument("--hash-function", default="sha3-512")

        _add_parser(sub_img, "image_import")("import", description="Add image to local repository.")
        p["image_import"].add_argument(
            "--repository",
            "-R",
            metavar="LOCAL-REPO",
            help="Name of the local repository.",
            required=True,
        )
        p["image_import"].add_argument("--type", "-t", help="Image type. Autodetected by default.")
        p["image_import"].add_argument(
            "--mock-image-path",
            help="(For testing only) Pretend that this is the original location of the image.",
            type=parse_pure_path,
        )
        p["image_import"].add_argument(
            "input", metavar="INPUT-DIRECTORY", help="Input directory path.", type=_abspath
        )

        _add_parser(sub_img, "image_export")(
            "export",
            description="Download an image (if needed) and unpack its contents into a directory.",
        )
        p["image_export"].add_argument(
            "repo_name",
            metavar="LOCAL-REPO-NAME|@REMOTE-REPO-NAME",
            help="Name of the local or remote repository.",
        )
        p["image_export"].add_argument(
            "image_id",
            metavar="IMAGE-ID",
            help="Image ID. Must be a multihash in base64url format.",
        )
        p["image_export"].add_argument(
            "target", metavar="TARGET-DIR", help="Target directory to export to.", type=_abspath
        )
        p["image_export"].add_argument(
            "--trusted",
            help="Allow the execution of arbitrary code inside the image. This is necessary, for "
            "example, to generate the pyc files. If you do not trust the image contents and you "
            "wish to analyze its contents instead, then use --audit instead.",
            action="store_true",
        )
        p["image_export"].add_argument(
            "--audit",
            help="Export the raw data inside the image as-is. Treat the image as potentially "
            "malicious, and NEVER run any code inside the image. "
            "This option exists so you can safely analyze the contents of an untrusted image. "
            "It will not produce a working environment directory.",
            action="store_true",
        )
        p["image_export"].add_argument(
            "--mock-target",
            help="(For testing only) Pretend that this is the output path.",
            type=parse_pure_path,
        )
        p["image_export"].add_argument(
            "--mock-use-system-python",
            help="(For testing only) Do not attempt to use the Python.",
            action="store_true",
        )
        _add_parser(subparsers, "gc")("gc", description="Clean old and unused files.")
        p["gc"].add_argument(
            "--full",
            help="""Do everything. Equivalent to `--main --repo --check-links --check-integrity \
--max-age=3600`.""",
            action="store_true",
        )
        p["gc"].add_argument(
            "--main",
            help="Act on the files inside exported image directories.",
            action="store_true",
        )
        p["gc"].add_argument("--repo", help="Act on local repository files.", action="store_true")
        p["gc"].add_argument(
            "--check-links",
            help="Check the links created by the file deduplication system.",
            action="store_true",
        )
        p["gc"].add_argument(
            "--max-age", help="Delete unused files older than MAX-AGE seconds.", type=int
        )
        p["gc"].add_argument(
            "--check-links-under",
            "-L",
            help="Check the links under the following (potentially non-existing) path.",
            type=_abspath,
            action="append",
        )
        p["gc"].add_argument(
            "--check-integrity",
            help="Read every file contents and check the hash.",
            action="store_true",
        )
        _add_parser(subparsers, "stats")("stats", description="Show storage statistics.")

        return parser

    def setup_logging(self):
        structlog.configure(logger_factory=structlog.PrintLoggerFactory(sys.stderr))

    def run(self):
        with pprofile():
            value = self.a.callback()
        if isinstance(value, dict):
            print(json.dumps(value, indent=2))

    def run_debug(self):
        return self.a.callback()

    @classmethod
    def main(cls, argv=None, setup_logging=True):
        self = cls(argv=argv)
        if setup_logging:
            self.setup_logging()
        self.run()
