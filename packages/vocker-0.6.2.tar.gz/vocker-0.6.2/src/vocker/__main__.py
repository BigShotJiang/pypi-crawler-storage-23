from .cli import Main

Main.main()
