from setuptools import setup

setup(name="vocker", version="0.0.0.1")
