# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Unreleased]

## [0.6.2] - 2026-02-19

### Fixed

- Properly substitute the environment path inside scripts. Also raise an exception if the
  environment name is found inside other files.

## [0.6.1] - 2026-02-16

### Fixed

- Use locking to remove race condition from `RepoTransfer`.
- Use `BaseDedup._delete_file` instead of `Path.unlink` everywhere to avoid file locking
  issues on Windows.

## [0.6.0] - 2026-02-15

### Changed

- Implement `image export` thread parallelism.

### Fixed

- Fix dedup bug where a failed link results in IntegrityError inside `run_batch`.
- Fix bug inside `repo.io` where parent directory creation was missing.

## [0.5.0] - 2026-02-14

### Added

- Implement shallow repository downloads. Also implement `image import` into a shallow
  repository.

## [0.4.0] - 2026-02-12

### Added

- Implement `image export --audit` option for examining the contents of an untrusted image.

### Changed

- Implement thread parallelism for repository upload and download.

## [0.3.2] - 2026-02-03

### Fixed

- Fix `ImageNotFoundError` due to incorrect manifest parsing when reusing cached content.

## [0.3.1] - 2026-02-02

### Changed

- Compress only to LZMA instead of both LZMA and zstandard. Decompression isn't even
  implemented yet for zstandard.

## [0.3.0] - 2026-01-27

### Changed

- Reimplement file deduplication bookkeeping to improve performance by moving most of the
  SQLAlchemy ORM-based logic to SQLAlchemy Core SQL statements. The performance increased by
  a factor of 3.

## [0.2.0] - 2025-12-18

### Changed

- Remove strictyaml dependency and replace with JSON.

## [0.1.0] - 2025-12-17

### Added

- Initial version.
