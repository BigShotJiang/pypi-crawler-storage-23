import os


RUN_SLOW_TESTS = bool(os.getenv("SLOW", ""))
