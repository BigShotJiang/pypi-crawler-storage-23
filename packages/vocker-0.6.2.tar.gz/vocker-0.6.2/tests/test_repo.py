from __future__ import annotations

import contextlib
import io
from pathlib import Path, PureWindowsPath
import sys
from unittest import mock
import zipfile

import attr
import pytest

from vocker.exc import ForbiddenStringError
from vocker.repo import io as rio
from vocker.util import PurePathBase
from vocker import cli, image as im


@attr.s
class FakeImageInfo:
    path: Path = attr.ib()
    mock_path_str: str = attr.ib()


def create_fake_pyenv_windows(path: Path, use_forbidden_string: bool = False):
    def d(rel_path):
        (p := path / rel_path).parent.mkdir(exist_ok=True, parents=True)
        return p

    venv_name = "vocker_example_xyzzy"
    mock_path = "C:\\" + venv_name
    py = mock_path + "\\python.exe"

    d("Lib/dist-packages/library.py").write_bytes(b"# this is a library\n")
    d("Lib/dist-packages/library2/__init__.py").write_bytes(b"# another library\n")
    d("Lib/dist-packages/library2/util.py").write_bytes(b"# a submodule\n")
    d("Lib/dist-packages/library2/util_copy.py").write_bytes(b"# a submodule\n")
    if use_forbidden_string:
        d("Lib/dist-packages/library2/forbidden.py").write_bytes(
            f"# a very bad submodule\n# that uses the forbidden string {venv_name}\n# oh no".encode(
                "utf-8"
            )
        )
    d("Scripts/activate").write_bytes(
        f'# activate shell script\n\nVIRTUAL_ENV="{mock_path}"\n'.encode("utf-8")
    )

    example_exe_py = f'# example exe script\nprint("hello")\n'
    example_io = io.BytesIO()
    with zipfile.ZipFile(example_io, mode="w", compression=zipfile.ZIP_STORED) as zf:
        zf.writestr(zipfile.ZipInfo("__main__.py"), example_exe_py)
    example_exe = [b"MZ" * 100, b"\0" * 100]
    example_exe += f'#!"{mock_path}"\n'.encode("utf-8"), example_io.getvalue()

    d("Scripts/script.py").write_bytes(
        f"#!{py}\n# This has a hardcoded interpreter".encode("utf-8")
    )
    d("Scripts/example.exe").write_bytes(b"".join(example_exe))
    d("python.exe").write_bytes(b"MZ_not_a_real_executable")
    return FakeImageInfo(path, mock_path_str=f"windows:{mock_path}")


def run_cli(path_base, argv):
    return cli.Main(argv, path_base=path_base).run_debug()


@pytest.mark.parametrize("forbidden_error", [False, True])
def test_repo_end_to_end(tmp_path, forbidden_error):
    # tmp_path = Path("/tmp/repo")
    b = tmp_path / "b"
    run_cli(b, ["repo", "init", "first"])
    assert run_cli(b, ["repo", "ls"])["repos"]["first"] == "ok"

    # create mock image
    import_path = tmp_path / "i"
    res = create_fake_pyenv_windows(import_path, use_forbidden_string=forbidden_error)

    # import image into repo
    cmd = ["image", "import", "-R", "first", "--type", "pyenv1", "--mock-image-path"]
    cmd += str(res.mock_path_str), str(res.path)
    with pytest.raises(ForbiddenStringError) if forbidden_error else contextlib.nullcontext():
        res = run_cli(b, cmd)

    if forbidden_error:
        return

    print("create image result:", res)
    image_id = res["image_id"]

    # res = run_cli(b, cmd)
    # print("RESULT 2", res)

    # upload image
    (remote_path := tmp_path / "remote").mkdir()
    remote_uri = remote_path.as_uri()
    run_cli(b, ["repo", "upload", "first", "--to", remote_uri])
    run_cli(b, ["repo", "rm", "first"])
    run_cli(b, ["repo", "rm", "nonexistent"])

    # setup another system instance and add the same remote
    b2 = tmp_path / "b2"

    _export_image(b2, remote_uri, image_id, import_path, tmp_path / "vex")
    _export_image(b2, remote_uri, image_id, import_path, tmp_path / "vex2")

    # setup yet another system instance and clone the full thing, then export
    b3 = tmp_path / "b3"
    run_cli(b3, ["repo", "download", "--shallow", remote_uri, "loc"])
    _export_image(b3, "local:loc", image_id, import_path, tmp_path / "vex3")
    run_cli(b3, ["repo", "download", remote_uri, "loc2"])

    # audit mode
    (va := tmp_path / "vex4").mkdir()
    run_cli(b3, ["image", "export", "--audit", "local:loc", image_id, str(va)])
    assert (va / "literal/Lib/dist-packages/library2/util.py").exists()
    assert (va / "template/Scripts/activate").exists()


def _export_image(b, source_repo: str, image_id: str, import_path: Path, export_path: Path):
    # download and export image
    run_cli(
        b, ["image", "export", "--mock-use-system-python", source_repo, image_id, str(export_path)]
    )

    vname = export_path.name.encode("utf-8")
    assert vname not in (import_path / "Scripts/script.py").read_bytes()
    assert vname in (export_path / "Scripts/script.py").read_bytes()
    assert vname not in (import_path / "Scripts/activate").read_bytes()
    assert vname in (export_path / "Scripts/activate").read_bytes()
    assert same_contents(import_path, export_path, "Lib/dist-packages/library.py")
    assert same_contents(import_path, export_path, "python.exe")
    assert list((export_path / "Lib/dist-packages/__pycache__").glob("*.pyc"))
    assert list((export_path / "Lib/dist-packages/library2/__pycache__").glob("*.pyc"))
    assert not list((export_path / "Lib").glob("*.pyc"))


def same_contents(a, b, suffix):
    return (a / suffix).read_bytes() == (b / suffix).read_bytes()


def test_estimated_archive_sizes():
    array = [0, 1, 2, 3, 4, 255, 256, 257, 1024, 65536, 2**32, 2**50]
    array2 = array.copy()
    array2[0] = 1

    data = rio.estimated_archive_sizes_encode(array)
    assert type(data) is bytes
    assert rio.estimated_archive_sizes_decode(data) == array2
