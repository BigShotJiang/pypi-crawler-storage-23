from pyptv import cli

cli()
