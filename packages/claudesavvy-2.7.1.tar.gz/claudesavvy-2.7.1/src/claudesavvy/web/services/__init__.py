"""Services for Claude Monitor web interface."""
