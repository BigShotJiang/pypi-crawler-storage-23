"""Chart routes for Claude Monitor."""
