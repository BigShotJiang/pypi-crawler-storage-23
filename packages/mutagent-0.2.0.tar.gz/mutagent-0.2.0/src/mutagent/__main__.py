"""python -m mutagent -- Interactive mutagent agent session."""

from mutagent.main import main

if __name__ == "__main__":
    main()
