"""mutagent.agent -- Agent declaration."""

from __future__ import annotations

from typing import TYPE_CHECKING, AsyncIterator, Callable

import mutagent

if TYPE_CHECKING:
    from mutagent.client import LLMClient
    from mutagent.messages import InputEvent, StreamEvent, ToolCall, ToolResult
    from mutagent.tools import ToolSet


class Agent(mutagent.Declaration):
    """Agent manages the conversation loop with an LLM.

    The agent sends messages to the LLM, handles tool calls by dispatching
    them through the ToolSet, and continues until the LLM signals
    end_turn.

    Attributes:
        client: The LLM client for sending messages.
        tool_set: The tool set for tool management and dispatch.
        system_prompt: System prompt for the LLM.
        messages: Conversation history.
        max_tool_rounds: Maximum number of tool call rounds per user
            message before forcing the agent to stop and summarize.
            Default 25.
    """

    client: LLMClient
    tool_set: ToolSet
    system_prompt: str
    messages: list
    max_tool_rounds: int

    async def run(
        self,
        input_stream: AsyncIterator[InputEvent],
        stream: bool = True,
        check_pending: Callable[[], bool] | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """Run the agent conversation loop, consuming input events and yielding output events.

        This is the main entry point. It consumes InputEvents from input_stream,
        processes each through the LLM (with tool call loops), and yields
        StreamEvents for each piece of incremental output.

        The async generator runs until input_stream is exhausted.

        Args:
            input_stream: AsyncIterator of user input events.
            stream: Whether to use SSE streaming for the HTTP request.
            check_pending: Optional callback that returns True if new input
                is available. Checked between tool rounds — if True, the
                current turn ends early so the outer loop can pick up the
                new message.

        Yields:
            StreamEvent instances for each piece of incremental output.
            A "turn_done" event is yielded after each user message is fully processed.
        """
        return agent_impl.run(self, input_stream, stream=stream, check_pending=check_pending)

    async def step(self, stream: bool = True) -> AsyncIterator[StreamEvent]:
        """Execute a single LLM call, yielding streaming events.

        Args:
            stream: Whether to use SSE streaming for the HTTP request.

        Yields:
            StreamEvent instances from the LLM client.
        """
        return agent_impl.step(self, stream=stream)

    async def handle_tool_calls(self, tool_calls: list[ToolCall]) -> list[ToolResult]:
        """Execute tool calls and return results.

        Args:
            tool_calls: List of tool calls from the LLM.

        Returns:
            List of tool results.
        """
        return await agent_impl.handle_tool_calls(self, tool_calls)


from .builtins import agent_impl
mutagent.register_module_impls(agent_impl)