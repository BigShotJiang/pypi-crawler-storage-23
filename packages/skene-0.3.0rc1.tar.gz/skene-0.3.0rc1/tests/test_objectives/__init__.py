"""Tests for objectives module."""
