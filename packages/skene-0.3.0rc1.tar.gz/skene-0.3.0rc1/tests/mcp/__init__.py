"""MCP tools tests."""
