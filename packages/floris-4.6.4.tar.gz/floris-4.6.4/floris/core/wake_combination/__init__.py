
from floris.core.wake_combination.fls import FLS
from floris.core.wake_combination.max import MAX
from floris.core.wake_combination.sosfs import SOSFS
