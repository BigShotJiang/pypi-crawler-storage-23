"""Coda MCP - Quantum computing tools via Model Context Protocol.

A lightweight MCP server for quantum computing:
- Circuit transpilation (Qiskit, Cirq, PennyLane, PyQuil, CUDA-Q)
- Circuit simulation (CPU and GPU)
- QPU access (IonQ, IQM, Rigetti, etc.)
- Research paper search

Installation:
    pip install coda-mcp

Usage:
    coda-mcp                    # Run server
    uvx coda-mcp                # Run without installing

Configuration:
    CODA_API_URL    API endpoint URL
    CODA_API_TOKEN  Authentication token
"""

__version__ = "0.1.0"
