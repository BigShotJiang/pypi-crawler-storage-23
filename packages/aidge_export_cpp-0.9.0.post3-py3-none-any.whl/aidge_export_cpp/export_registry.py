from aidge_core.export_utils import ExportLib
from aidge_export_cpp import CPP_ROOT


class ExportLibCpp(ExportLib):
    _name = "export_cpp"
    static_files = {
        str(CPP_ROOT / "static" / "Makefile"): "",
        str(CPP_ROOT / "static" / "typedefs.hpp"): "dnn/include/utils/cpp",
        str(CPP_ROOT / "static" / "utils.hpp"): "dnn/include/utils/cpp",
        str(CPP_ROOT / "static" / "rescaling_utils.hpp"): "dnn/include/utils/cpp",
        str(CPP_ROOT / "static" / "activation_utils.hpp"): "dnn/include/utils/cpp",
    }
