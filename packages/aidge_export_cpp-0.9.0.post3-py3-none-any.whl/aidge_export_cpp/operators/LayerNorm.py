import aidge_core
from aidge_core.export_utils import ExportNodeCpp
from aidge_export_cpp import CPP_ROOT, ExportLibCpp


class _LayerNorm(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Initialize kernel attributes
        operator = node.get_operator()
        self.attributes["activation"] = "Linear"
        self.attributes["rescaling"] = "NoScaling"
        self.attributes["epsilon"] = operator.attr.epsilon
        axis = operator.attr.axis
        if axis < 0 and len(operator.get_output(0)) > 0:
            axis = len(operator.get_output(0).dims) + axis
        self.attributes["axis"] = axis

        # Template for layer configuration file generation
        self.config_template = str(
            CPP_ROOT / "templates" / "configuration" / "layernorm_config.jinja"
        )

        # Template layer call function generation within the forward file
        self.forward_template = str(
            CPP_ROOT / "templates" / "kernel_forward" / "layernorm_forward.jinja"
        )

        # Files to include within the generated forward.cpp file
        self.include_list = []

        # Path to the kernel(s) files to copy
        self.add_kernel_to_copy(
            CPP_ROOT / "kernels" / "layernorm.hpp", "include/kernels/cpp"
        )
        self.add_kernel_to_copy(
            CPP_ROOT / "static" / "macs.hpp", "include/utils/cpp", fwd_include=False
        )

        # Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")


@ExportLibCpp.register(
    "LayerNorm",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.float32, aidge_core.dformat.nchw)
    ),
    aidge_core.ProdConso.in_place_model,
)
class LayerNorm(_LayerNorm):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)


@ExportLibCpp.register(
    "LayerNorm",
    aidge_core.ImplSpec(
        aidge_core.IOSpec(aidge_core.dtype.float32, aidge_core.dformat.ncw)
    ),
    aidge_core.ProdConso.in_place_model,
)
class LayerNorm(_LayerNorm):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
