import aidge_core
from aidge_core.export_utils import ExportNodeCpp, get_node_from_metaop
from aidge_export_cpp import CPP_ROOT, ExportLibCpp, set_scaling_attributes


@ExportLibCpp.register(
    "Cast", aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any))
)
class Cast(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Template for layer configuration file generation
        self.config_template = str(
            CPP_ROOT / "templates" / "configuration" / "cast_config.jinja"
        )

        # Template layer call function generation within the forward file
        self.forward_template = str(
            CPP_ROOT / "templates" / "kernel_forward" / "cast_forward.jinja"
        )

        # Path to the kernel(s) files to copy
        self.add_kernel_to_copy(
            CPP_ROOT / "kernels" / "cast.hpp", "include/kernels/cpp"
        )

        # Files to include within the generated forward.cpp file
        self.include_list = []

        # Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("utils/cpp/typedefs.hpp")
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")
