import aidge_core
from aidge_core.export_utils import ExportNodeCpp
from aidge_export_cpp import CPP_ROOT, ExportLibCpp


@ExportLibCpp.register(
    "DFT",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.complex32),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.complex32)],  # Output specifications
    ),
)
class DFT(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        tensor = self.operator.get_input(0)
        nbDims = len(tensor.dims)
        axis = (
            node.get_operator().attr.axis
            if node.get_operator().attr.axis >= 0
            else node.get_operator().attr.axis + nbDims
        )

        assert (
            axis < nbDims
        ), f"export dft: attribute axis == {node.get_operator().attr.axis} should be less than {nbDims}"

        postAxisElems = 1
        for i in range(axis + 1, nbDims):
            postAxisElems *= tensor.dims[i]

        preAxisElems = 1
        for i in range(axis):
            preAxisElems *= tensor.dims[i]

        # Set kernel attributes
        self.attributes["axis_size_post"] = postAxisElems
        self.attributes["axis_size_pre"] = preAxisElems
        self.attributes["dim_i"] = tensor.dims[axis]
        self.attributes["dim_o"] = self.operator.get_output(0).dims[axis]
        self.attributes["inverse"] = int(node.get_operator().attr.inverse)

        # Template for layer configuration file generation
        self.config_template = str(
            CPP_ROOT / "templates" / "configuration" / "dft_config.jinja"
        )

        # Template layer call function generation within the forward file
        self.forward_template = str(
            CPP_ROOT / "templates" / "kernel_forward" / "dft_forward.jinja"
        )

        # Files to include within the generated forward.cpp file
        self.include_list = []
        self.include_list.append("<complex>")

        # Path to the kernel(s) files to copy
        self.add_kernel_to_copy(CPP_ROOT / "kernels" / "dft.hpp", "include/kernels/cpp")

        # Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("utils/cpp/typedefs.hpp")
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")
