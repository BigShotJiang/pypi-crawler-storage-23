"""
Copyright (c) 2023 CEA-List

This program and the accompanying materials are made available under the
terms of the Eclipse Public License 2.0 which is available at
http://www.eclipse.org/legal/epl-2.0.

SPDX-License-Identifier: EPL-2.0
"""

import numpy as np

import aidge_core
from aidge_core.export_utils import ExportNodeCpp
from aidge_export_cpp import CPP_ROOT, ExportLibCpp


@ExportLibCpp.register(
    "Clip",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any)),
    aidge_core.ProdConso.in_place_model,
)
class CppClip(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Initialize kernel attributes
        self.attributes["min"] = node.get_operator().attr.min
        self.attributes["max"] = node.get_operator().attr.max

        # Template for layer configuration file generation
        self.config_template = str(
            CPP_ROOT / "templates" / "configuration" / "clip_config.jinja"
        )

        # Template layer call function generation within the forward file
        self.forward_template = str(
            CPP_ROOT / "templates" / "kernel_forward" / "clip_forward.jinja"
        )

        # Files to include within the generated forward.cpp file
        self.include_list = []

        # Path to the kernel(s) files to copy
        self.add_kernel_to_copy(
            CPP_ROOT / "kernels" / "clip.hpp", "include/kernels/cpp"
        )

        # Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("utils/cpp/typedefs.hpp")
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")
