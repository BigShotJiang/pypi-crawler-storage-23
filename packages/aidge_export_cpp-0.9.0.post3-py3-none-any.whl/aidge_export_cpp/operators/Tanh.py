import aidge_core
from aidge_core.export_utils import ExportNodeCpp
from aidge_export_cpp import CPP_ROOT, ExportLibCpp


@ExportLibCpp.register(
    "Tanh",
    aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any)),
    aidge_core.ProdConso.in_place_model,
)
class TanhCPP(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        self.attributes["activation"] = "Linear"
        self.attributes["rescaling"] = "NoScaling"

        # Template for layer configuration file generation
        self.config_template = str(
            CPP_ROOT / "templates" / "configuration" / "tanh_config.jinja"
        )

        # Template layer call function generation within the forward file
        self.forward_template = str(
            CPP_ROOT / "templates" / "kernel_forward" / "tanh_forward.jinja"
        )

        # Files to include within the generated forward.cpp file
        self.include_list = []

        # Path to the kernel(s) files to copy
        self.add_kernel_to_copy(
            CPP_ROOT / "kernels" / "tanh.hpp", "include/kernels/cpp"
        )

        # Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")
