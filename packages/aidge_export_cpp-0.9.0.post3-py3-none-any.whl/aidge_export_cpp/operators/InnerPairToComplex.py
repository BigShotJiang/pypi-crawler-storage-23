import aidge_core
from aidge_core.export_utils import ExportNodeCpp
from aidge_export_cpp import CPP_ROOT, ExportLibCpp


@ExportLibCpp.register(
    "InnerPairToComplex",
    aidge_core.ImplSpec(
        [  # Input specifications
            aidge_core.IOSpec(aidge_core.dtype.float32),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.complex32)],  # Output specifications
    ),
    aidge_core.ProdConso.in_place_model,
)
class InnerPairToComplexCPP(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        self.config_template = str(
            CPP_ROOT / "templates" / "configuration" / "innerpairtocomplex_config.jinja"
        )
        self.forward_template = str(
            CPP_ROOT
            / "templates"
            / "kernel_forward"
            / "innerpairtocomplex_forward.jinja"
        )
        self.include_list = []
        self.add_kernel_to_copy(
            CPP_ROOT / "kernels" / "innerpairtocomplex.hpp", "include/kernels/cpp"
        )

        # Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("utils/cpp/typedefs.hpp")
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")
