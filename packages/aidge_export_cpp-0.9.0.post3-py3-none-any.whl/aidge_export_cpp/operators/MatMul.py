import aidge_core
from aidge_core.export_utils import ExportNodeCpp
from aidge_export_cpp import CPP_ROOT, ExportLibCpp, set_scaling_attributes


@ExportLibCpp.register(
    "MatMul",
    aidge_core.ImplSpec(
        [
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default)],
    ),
)
@ExportLibCpp.register(
    "MatMul",
    aidge_core.ImplSpec(
        [
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.chw),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.chw),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.chw)],
    ),
)
@ExportLibCpp.register(
    "MatMul",
    aidge_core.ImplSpec(
        [
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nchw),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nchw),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nchw)],
    ),
)
@ExportLibCpp.register(
    "MatMul",
    aidge_core.ImplSpec(
        [
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.ncdhw),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.ncdhw),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.ncdhw)],
    ),
)
class MatMul(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
        self.attributes["activation"] = "Linear"
        self.attributes["rescaling"] = "NoScaling"

        self.attributes["accumulation_type"] = (
            "float"
            if aidge_core.is_floating_point(self.attributes["in_dtype"][0])
            else "int32_t"
        )

        # Initialize arrays storing broadcasted(or not) dims
        ndim_a = self.attributes["in_dims"][0]
        ndim_b = self.attributes["in_dims"][1]

        if len(ndim_a) == 1:
            ndim_a.insert(0, 1)

        if len(ndim_b) == 1:
            ndim_b.append(1)

        if len(ndim_a) > len(ndim_b):
            for _ in range(len(ndim_a) - len(ndim_b)):
                ndim_b.insert(0, 1)
        elif len(ndim_b) > len(ndim_a):
            for _ in range(len(ndim_b) - len(ndim_a)):
                ndim_a.insert(0, 1)

        nbdims_out = len(ndim_a)

        # Initialize strides for broadcasting
        stride_post0 = [0] * (nbdims_out - 2)
        stride_post1 = [0] * (nbdims_out - 2)
        stride_step0 = [0] * (nbdims_out - 2)
        stride_step1 = [0] * (nbdims_out - 2)

        if nbdims_out > 2:
            stride_post0[nbdims_out - 3] = 1
            stride_post1[nbdims_out - 3] = 1
            for i in range(nbdims_out - 4, -1, -1):
                stride_post0[i] = stride_post0[i + 1] * ndim_a[i + 1]
                stride_post1[i] = stride_post1[i + 1] * ndim_b[i + 1]

            for i in range(nbdims_out - 2):
                stride_step0[i] = 1 - stride_post0[i] if ndim_a[i] == 1 else 1
                stride_step1[i] = 1 - stride_post1[i] if ndim_b[i] == 1 else 1

        # if len(dims_b) == len(dims_a), then len(dims_a) == nbdims_out == len(dims_b);
        # else it will be broadcasted to the correct dims
        nbMatrices = 1
        for i in range(nbdims_out - 3, -1, -1):
            nbMatrices *= self.attributes["out_dims"][0][i]

        offsetIn0 = 0
        offsetIn1 = 0
        self.attributes["offset_in1"] = [0]
        self.attributes["offset_in2"] = [0]

        for stack in range(1, nbMatrices):
            dim = nbdims_out - 3
            tmp_stack = stack
            while tmp_stack % self.attributes["out_dims"][0][dim] == 0:
                tmp_stack //= self.attributes["out_dims"][0][dim]
                dim -= 1
            offsetIn0 += stride_step0[dim]
            offsetIn1 += stride_step1[dim]

            self.attributes["offset_in1"].append(offsetIn0)
            self.attributes["offset_in2"].append(offsetIn1)

        self.attributes["n"] = ndim_a[nbdims_out - 2]
        self.attributes["m"] = ndim_b[nbdims_out - 1]
        self.attributes["k"] = ndim_a[nbdims_out - 1]

        self.config_template = str(
            CPP_ROOT / "templates" / "configuration" / "matmul_config.jinja"
        )
        self.forward_template = str(
            CPP_ROOT / "templates" / "kernel_forward" / "matmul_forward.jinja"
        )
        self.include_list = []
        self.add_kernel_to_copy(
            CPP_ROOT / "kernels" / "matmul.hpp", "include/kernels/cpp"
        )

        # Include aidge outputs within the fwd file
        if self.attributes["aidge_cmp"]:
            self.include_list.append("utils/cpp/utils.hpp")  # aidge_cmp function
            self.include_list.append("utils/cpp/typedefs.hpp")
            self.include_list.append("data/aidge_outputs/" + node.name() + ".hpp")


@ExportLibCpp.register_metaop(
    "QMatMul",
    aidge_core.ImplSpec(
        [
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.default)],
    ),
)
@ExportLibCpp.register_metaop(
    "QMatMul",
    aidge_core.ImplSpec(
        [
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.chw),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.chw),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.chw)],
    ),
)
@ExportLibCpp.register_metaop(
    "QMatMul",
    aidge_core.ImplSpec(
        [
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nchw),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nchw),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.nchw)],
    ),
)
@ExportLibCpp.register_metaop(
    "QMatMul",
    aidge_core.ImplSpec(
        [
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.ncdhw),
            aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.ncdhw),
        ],
        [aidge_core.IOSpec(aidge_core.dtype.any, aidge_core.dformat.ncdhw)],
    ),
)
class QMatMul(MatMul):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)

        # Browse the metaop to update kernel attributes
        set_scaling_attributes(self, node)

        ## Set the scaling type
        if self.attributes["coef_value"] != 1:
            self.attributes["rescaling"] = "FixedPointScaling"
        elif self.attributes["shift_value"] != 0:
            self.attributes["rescaling"] = "SingleShiftScaling"

        # ## Accumulation type
        # self.attributes["accumulation_type"] = "int32_t"
