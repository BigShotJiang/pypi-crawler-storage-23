import os
from pathlib import Path

import numpy as np

import aidge_core
from aidge_core.export_utils import ExportNodeCpp, aidge2c, generate_file
from aidge_export_cpp import CPP_ROOT, ExportLibCpp


def export_params(
    name: str,
    output: aidge_core.Tensor,
    export_path: Path,
    header_path: Path,
    src_path: Path,
    filename: str,
):

    full_header_path: Path = export_path / header_path
    full_src_path: Path = export_path / src_path

    # # Get directory name of the file
    # dirname = os.path.dirname(filepath)

    # If directory doesn't exist, create it
    if not os.path.exists(full_header_path):
        os.makedirs(full_header_path)

    generate_file(
        str(full_header_path / filename) + ".hpp",
        str(CPP_ROOT / "templates" / "data" / "producer_header.jinja"),
        name=name,
        dims=output.dims,
        dtype=aidge2c(output.dtype),
        dtype_name=output.dtype,
    )

    if not os.path.exists(full_src_path):
        os.makedirs(full_src_path)

    generate_file(
        str(full_src_path / filename) + ".cpp",
        str(CPP_ROOT / "templates" / "data" / "producer_src.jinja"),
        name=name,
        declaration_path=str(Path(*header_path.parts[1:]) / filename) + ".hpp",
        dims=output.dims,
        dtype=aidge2c(output.dtype),
        dtype_name=output.dtype,
        values=np.array(output).tolist(),
    )


@ExportLibCpp.register(
    "Producer", aidge_core.ImplSpec(aidge_core.IOSpec(aidge_core.dtype.any))
)
class ProducerCPP(ExportNodeCpp):
    def __init__(self, node, mem_info):
        super().__init__(node, mem_info)
        self.output = self.operator.get_output(0)
        self.ignore = (
            node.attributes().ignore if node.attributes().has_attr("ignore") else False
        )

    def export(self, export_folder: Path):
        if self.ignore:
            return []

        path_to_definition = (
            f"{self.config_path}/{self.attributes['name']}.{self.config_extension}"
        )

        try:
            aidge_core.export_utils.code_generation.generate_file(
                str(export_folder / path_to_definition),
                str(CPP_ROOT / "templates" / "configuration" / "producer_config.jinja"),
                **self.attributes,
            )
        except Exception as e:
            raise RuntimeError(
                f"Error when creating config file for {self.node.name()}[{self.node.type()}]."
            ) from e

        filename = self.attributes["name"]
        header_path = Path("include/parameters/")
        source_path = Path("src/parameters/")
        export_params(
            self.attributes["out_name"][0],
            self.output,
            export_path=export_folder,
            header_path=header_path,
            src_path=source_path,
            filename=filename,
        )
        return [path_to_definition, str(header_path / filename) + ".hpp"]

    def forward(self):
        # A Producer does nothing during forward
        return []
