#ifndef __AIDGE_EXPORT_CPP_KERNELS_INNERPAIRTOCOMPLEX__
#define __AIDGE_EXPORT_CPP_KERNELS_INNERPAIRTOCOMPLEX__

#include "utils/cpp/typedefs.hpp"
#include <cstddef>
#include <cstring>

// Generic function for INNERPAIRTOCOMPLEX

namespace export_cpp {

template <size_t NB_ELTS_INPUT,
          size_t NB_ELTS_OUTPUT,
          typename Input_T,
          typename Output_T>
__attribute__((always_inline)) inline void
innerpairtocomplex_forward(const Input_T *__restrict inputs,
                           Output_T *__restrict outputs)
{

    if (NB_ELTS_OUTPUT == NB_ELTS_INPUT) {
        // real to complex
        for (size_t i = 0; i < NB_ELTS_INPUT; i++) {
            outputs[i] = std::complex<Input_T>(inputs[i], Input_T(0.0));
        }
    } else if (NB_ELTS_OUTPUT == NB_ELTS_INPUT / 2) {
        // Pair of real to complex
        // Direct raw data copy, as the memory layout is the same!
        std::memcpy(&outputs, &inputs, NB_ELTS_INPUT * sizeof(Input_T));
    }
}
} // namespace export_cpp
#endif // __AIDGE_EXPORT_CPP_KERNELS_INNERPAIRTOCOMPLEX__