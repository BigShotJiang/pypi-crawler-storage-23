#ifndef __AIDGE_EXPORT_CPP_KERNELS_LAYERNORM__
#define __AIDGE_EXPORT_CPP_KERNELS_LAYERNORM__

#include "utils/cpp/activation_utils.hpp"
#include "utils/cpp/typedefs.hpp"
#include <cstddef>
#include <math.h>

// WARNING: this kernel only works for 32-bits floating point values
// and for 4D input data (typically NCHW)
// Assumes also that data, gamma and beta strides are 1.

namespace export_cpp {

template <size_t NB_BATCHES,     // Batchsize
          size_t NB_OUTPUTS,     // Channels
          size_t OUTPUTS_HEIGHT, // 1 if NCW
          size_t OUTPUTS_WIDTH,  // Last dim
          ActivationFunction_T ACTIVATION,
          typename Input_T,
          typename Output_T,
          typename Param_T,
          typename Rescaling_T>
__attribute__((always_inline)) inline void
layernorm_forward(const Input_T *__restrict inputs,
                  Output_T *__restrict outputs,
                  const Param_T *__restrict scales, // Weights (gamma)
                  const Param_T *__restrict biases, // Bias (beta)
                  const double epsilon,
                  const int axis,
                  const Rescaling_T &__restrict rescaling)
{
    // Assume that there are always 4 dimensions (NCHW format)
    size_t dims = 4;
    size_t dformat[4] = {NB_BATCHES, NB_OUTPUTS, OUTPUTS_HEIGHT, OUTPUTS_WIDTH};

    // Check that the axis is positive, or mirror it else
    const size_t positiveAxis = (axis > 0 ? axis : dims + axis);

    // Retrieve the number of features from the axis
    size_t nbFeatures = 1;
    for (size_t i = positiveAxis; i < dims; ++i)
        nbFeatures *= dformat[i];

    // Input vector size and number of loops
    const size_t vecSize =
        NB_BATCHES * NB_OUTPUTS * OUTPUTS_HEIGHT * OUTPUTS_WIDTH;
    const size_t nbLoops = vecSize / nbFeatures;

    // Unary strides (left for consistency)
    const size_t strideFeatures = 1;
    const size_t strideGamma = 1;
    const size_t strideBeta = 1;

    for (size_t loop = 0; loop < nbLoops; ++loop) {
        Input_T mu = Input_T(0);
        Input_T delta = Input_T(0);
        Input_T delta2 = Input_T(0);
        Input_T m2 = Input_T(0);
        size_t n_feat = 0;
        size_t channel = loop % NB_OUTPUTS;

        // Welford's online algorithm
        // compute mean and biased variance
        for (size_t i = 0; i < nbFeatures; ++i) {
            n_feat++;
            delta = *inputs - mu;
            mu += delta / n_feat;
            delta2 = *inputs - mu;
            m2 += delta * delta2;
            inputs += strideFeatures;
        }

        const Input_T var = m2 / n_feat;
        const Input_T sigma = std::sqrt(var + epsilon);
        inputs -= strideFeatures * nbFeatures;

        for (size_t feat = 0; feat < nbFeatures; ++feat) {
            const Output_T sAs = (inputs[feat * strideFeatures] - mu) *
                                     scales[feat * strideGamma] / sigma +
                                 biases[feat * strideBeta];
            outputs[feat * strideFeatures] = activation_forward_value<Output_T>(
                sAs, channel, ACTIVATION, rescaling);
        }
        inputs += nbFeatures;
        outputs += nbFeatures;
    }
}

} // namespace export_cpp

#endif // __AIDGE_EXPORT_CPP_KERNELS_LAYERNORM__
