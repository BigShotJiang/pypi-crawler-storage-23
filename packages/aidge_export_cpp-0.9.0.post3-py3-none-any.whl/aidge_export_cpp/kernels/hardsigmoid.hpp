#ifndef __AIDGE_EXPORT_CPP_KERNELS_HARDSIGMOID__
#define __AIDGE_EXPORT_CPP_KERNELS_HARDSIGMOID__

#include "math.h"
#include "utils/cpp/typedefs.hpp"
#include <cstddef>

namespace export_cpp {

template <size_t NB_ELTS, typename Input_T, typename Output_T>
__attribute__((always_inline)) inline void
hardsigmoid_forward(const float ALPHA,
                    const float BETA,
                    const Input_T *__restrict inputs,
                    Output_T *__restrict outputs)
{
    for (size_t i = 0; i < NB_ELTS; i++) {
        const double result = ALPHA * inputs[i] + BETA;
        outputs[i] = static_cast<Output_T>((result < 0.0)   ? 0.0
                                           : (result > 1.0) ? 1.0
                                                            : result);
    }
}

} // namespace export_cpp

#endif // __AIDGE_EXPORT_CPP_KERNELS_HARDSIGMOID_