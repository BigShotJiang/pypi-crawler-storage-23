#ifndef __AIDGE_EXPORT_CPP_KERNELS_REDUCEMAX__
#define __AIDGE_EXPORT_CPP_KERNELS_REDUCEMAX__

#include "utils/cpp/typedefs.hpp"
#include "utils/cpp/utils.hpp"
#include <algorithm>
#include <cmath>
#include <cstddef>

namespace export_cpp {

template <Reduce_T ELEM_OP, typename T>
T stableReduce(const T *vec, std::size_t len, std::size_t stride)
{
    auto apply_op = [](auto a, auto b, int i) -> T {
        switch (ELEM_OP) {
        case Reduce_T::Min:
            return std::min(a, b);
        case Reduce_T::Max:
            return std::max(a, b);
        case Reduce_T::Mean:
            return std::fma(
                a - b, static_cast<T>(1) / static_cast<T>(i + 1), b);
        case Reduce_T::Sum:
            return a + b;
        default:
            return a;
        }
    };

    T reduced = vec[0];
    for (std::size_t i = 1; i < len; ++i) {
        reduced = apply_op(vec[i * stride], reduced, i);
    }
    return reduced;
}

template <Reduce_T ELEM_OP,
          std::size_t AXIS_SIZE,
          std::size_t AXIS_SIZE_PRE,
          std::size_t AXIS_SIZE_POST,
          typename Input_T,
          typename Output_T>
inline void computeOverAxis(const Input_T *__restrict in,
                            Output_T *__restrict out)
{
    for (std::size_t pre = 0; pre < AXIS_SIZE_PRE; ++pre) {
        const std::size_t in_base = pre * AXIS_SIZE * AXIS_SIZE_POST;
        const std::size_t out_base = pre * AXIS_SIZE_POST;

        for (std::size_t post = 0; post < AXIS_SIZE_POST; ++post) {
            out[out_base + post] = stableReduce<ELEM_OP>(
                in + in_base + post, AXIS_SIZE, AXIS_SIZE_POST);
        }
    }
}

template <Reduce_T ELEM_OP, typename T>
using Buffer_T =
    typename std::conditional_t<ELEM_OP == Reduce_T::Mean &&
                                    !std::is_floating_point<T>::value,
                                float,
                                T>;

template <std::size_t AXIS_IDX,
          std::size_t NB_AXES,
          std::size_t NB_ELTS,
          std::size_t IN_NB_ELTS,
          Reduce_T ELEM_OP,
          const std::size_t AXES[],
          const std::size_t IN_DIMS[],
          const std::size_t STRIDE_PRE[],
          const std::size_t STRIDE_POST[],
          typename Input_T,
          typename Output_T,
          bool OutputIsBuffer =
              std::is_same<Output_T, Buffer_T<ELEM_OP, Output_T>>::value>
struct ReduceAxisRecursive
{
    static void compute(const Input_T *__restrict in, Output_T *__restrict out)
    {
        Buffer_T<ELEM_OP, Output_T> buffer[NB_ELTS];
        computeOverAxis<ELEM_OP,
                        IN_DIMS[AXES[NB_AXES - 1 - AXIS_IDX]],
                        STRIDE_PRE[AXES[NB_AXES - 1 - AXIS_IDX]] /
                            (IN_NB_ELTS /
                             (IN_DIMS[AXES[NB_AXES - 1 - AXIS_IDX]] * NB_ELTS)),
                        STRIDE_POST[AXES[NB_AXES - 1 - AXIS_IDX]]>(in, buffer);

        ReduceAxisRecursive<AXIS_IDX - 1,
                            NB_AXES,
                            NB_ELTS /
                                IN_DIMS[AXES[NB_AXES - 1 - (AXIS_IDX - 1)]],
                            IN_NB_ELTS,
                            ELEM_OP,
                            AXES,
                            IN_DIMS,
                            STRIDE_PRE,
                            STRIDE_POST,
                            Input_T,
                            Output_T>::compute(buffer, out);
    }
};

template <std::size_t NB_AXES,
          std::size_t NB_ELTS,
          std::size_t IN_NB_ELTS,
          Reduce_T ELEM_OP,
          const std::size_t AXES[],
          const std::size_t IN_DIMS[],
          const std::size_t STRIDE_PRE[],
          const std::size_t STRIDE_POST[],
          typename Input_T,
          typename Output_T>
struct ReduceAxisRecursive<0,
                           NB_AXES,
                           NB_ELTS,
                           IN_NB_ELTS,
                           ELEM_OP,
                           AXES,
                           IN_DIMS,
                           STRIDE_PRE,
                           STRIDE_POST,
                           Input_T,
                           Output_T,
                           true>
{
    static void compute(const Input_T *__restrict in, Output_T *__restrict out)
    {
        // Last
        computeOverAxis<ELEM_OP,
                        IN_DIMS[AXES[NB_AXES - 1]],
                        STRIDE_PRE[AXES[NB_AXES - 1]] /
                            (IN_NB_ELTS /
                             (IN_DIMS[AXES[NB_AXES - 1]] * NB_ELTS)),
                        STRIDE_POST[AXES[NB_AXES - 1]]>(in, out);
    }
};

template <std::size_t NB_AXES,
          std::size_t NB_ELTS,
          std::size_t IN_NB_ELTS,
          Reduce_T ELEM_OP,
          const std::size_t AXES[],
          const std::size_t IN_DIMS[],
          const std::size_t STRIDE_PRE[],
          const std::size_t STRIDE_POST[],
          typename Input_T,
          typename Output_T>
struct ReduceAxisRecursive<0,
                           NB_AXES,
                           NB_ELTS,
                           IN_NB_ELTS,
                           ELEM_OP,
                           AXES,
                           IN_DIMS,
                           STRIDE_PRE,
                           STRIDE_POST,
                           Input_T,
                           Output_T,
                           false>
{
    static void compute(const Input_T *__restrict in, Output_T *__restrict out)
    {
        // Last
        Buffer_T<ELEM_OP, Output_T> buffer[NB_ELTS];
        computeOverAxis<ELEM_OP,
                        IN_DIMS[AXES[NB_AXES - 1]],
                        STRIDE_PRE[AXES[NB_AXES - 1]] /
                            (IN_NB_ELTS /
                             (IN_DIMS[AXES[NB_AXES - 1]] * NB_ELTS)),
                        STRIDE_POST[AXES[NB_AXES - 1]]>(in, buffer);

        // Rounding
        for (size_t i = 0; i < NB_ELTS; ++i) {
            out[i] = static_cast<Output_T>(std::nearbyint(buffer[i]));
        }
    }
};

template <bool Reduce> struct reduce_forward_impl;

template <> struct reduce_forward_impl<false>
{
    template <std::size_t NB_ELTS,
              std::size_t IN_NB_ELTS,
              std::size_t NB_AXES_TO_REDUCE,
              Reduce_T ELEM_OP,
              const std::size_t AXES[],
              const std::size_t IN_DIMS[],
              const std::size_t STRIDE_PRE[],
              const std::size_t STRIDE_POST[],
              typename Input_T,
              typename Output_T>
    static inline void run(const Input_T *__restrict input,
                           Output_T *__restrict output)
    {
        std::copy_n(input, IN_NB_ELTS, output);
    }
};

template <> struct reduce_forward_impl<true>
{
    template <std::size_t NB_ELTS,
              std::size_t IN_NB_ELTS,
              std::size_t NB_AXES_TO_REDUCE,
              Reduce_T ELEM_OP,
              const std::size_t AXES[],
              const std::size_t IN_DIMS[],
              const std::size_t STRIDE_PRE[],
              const std::size_t STRIDE_POST[],
              typename Input_T,
              typename Output_T>
    static inline void run(const Input_T *__restrict input,
                           Output_T *__restrict output)
    {
        ReduceAxisRecursive<NB_AXES_TO_REDUCE - 1,
                            NB_AXES_TO_REDUCE,
                            NB_ELTS / IN_DIMS[AXES[0]],
                            IN_NB_ELTS,
                            ELEM_OP,
                            AXES,
                            IN_DIMS,
                            STRIDE_PRE,
                            STRIDE_POST,
                            Input_T,
                            Output_T>::compute(input, output);
    }
};

template <std::size_t IN_NB_ELTS,
          std::size_t NB_AXES_TO_REDUCE,
          Reduce_T ELEM_OP,
          const std::size_t AXES[],
          const std::size_t IN_DIMS[],
          const std::size_t STRIDE_PRE[],
          const std::size_t STRIDE_POST[],
          typename Input_T,
          typename Output_T>
inline void reduce_forward(const Input_T *__restrict input,
                           Output_T *__restrict output)
{
    reduce_forward_impl<(NB_AXES_TO_REDUCE !=
                         0)>::template run<IN_NB_ELTS,
                                           IN_NB_ELTS,
                                           NB_AXES_TO_REDUCE,
                                           ELEM_OP,
                                           AXES,
                                           IN_DIMS,
                                           STRIDE_PRE,
                                           STRIDE_POST,
                                           Input_T,
                                           Output_T>(input, output);
}

} // namespace export_cpp

#endif // __AIDGE_EXPORT_CPP_KERNELS_REDUCEMAX__
