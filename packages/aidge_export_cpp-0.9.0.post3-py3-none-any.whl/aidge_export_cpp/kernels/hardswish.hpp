#ifndef __AIDGE_EXPORT_CPP_KERNELS_HARDSWISH__
#define __AIDGE_EXPORT_CPP_KERNELS_HARDSWISH__

#include "kernels/cpp/hardsigmoid.hpp"
#include "math.h"
#include "utils/cpp/typedefs.hpp"
#include <cstddef>

namespace export_cpp {

template <size_t NB_ELTS, typename Input_T, typename Output_T>
__attribute__((always_inline)) inline void
hardswish_forward(const Input_T *__restrict inputs,
                  Output_T *__restrict outputs)
{
    hardsigmoid_forward<NB_ELTS, Input_T, Output_T>(
        0.1666667, 0.5, inputs, outputs);

    for (size_t i = 0; i < NB_ELTS; ++i)
        outputs[i] = inputs[i] * outputs[i];
}

} // namespace export_cpp

#endif // __AIDGE_EXPORT_CPP_KERNELS_HARDSWISH_