#ifndef __AIDGE_EXPORT_CPP_KERNELS_MANYWISE__
#define __AIDGE_EXPORT_CPP_KERNELS_MANYWISE__

#include "utils/cpp/typedefs.hpp"
#include <algorithm>
#include <cstddef>

namespace export_cpp {

template <size_t NB_DIMS, typename InDim>
std::size_t get_flattened_index(size_t in_idx[NB_DIMS])
{
    std::size_t flattenedIdx = 0;
    std::size_t stride = 1;

    for (int i = NB_DIMS - 1; i >= 0; --i) {
        std::size_t idx = (InDim::values[i] > 1) ? in_idx[i] : 0;
        flattenedIdx += idx * stride;
        stride *= InDim::values[i];
    }

    return flattenedIdx;
}

template <size_t IN,
          size_t NB_DIMS,
          ManyWise_T ELEM_OP,
          size_t NB_INPUTS,
          typename InDims,
          typename T>
struct ApplyManywiseOp
{
    static T compute(const T *const *__restrict inputs, size_t out_idx[NB_DIMS])
    {
        auto apply_op = [](auto a, auto b) -> T {
            switch (ELEM_OP) {
            case ManyWise_T::Sum:
                return a + b;
            case ManyWise_T::Min:
                return std::min(a, b);
            case ManyWise_T::Max:
                return std::max(a, b);
            default:
                return a;
            }
        };

        using InDim = typename Nth<IN, InDims>::type;
        const auto in_idx = get_flattened_index<NB_DIMS, InDim>(out_idx);
        return apply_op(
            inputs[IN][in_idx],
            ApplyManywiseOp<IN - 1, NB_DIMS, ELEM_OP, NB_INPUTS, InDims, T>::
                compute(inputs, out_idx));
    }
};

template <size_t NB_DIMS,
          ManyWise_T ELEM_OP,
          size_t NB_INPUTS,
          typename InDims,
          typename T>
struct ApplyManywiseOp<0, NB_DIMS, ELEM_OP, NB_INPUTS, InDims, T>
{
    static T compute(const T *const *__restrict inputs, size_t out_idx[NB_DIMS])
    {
        using InDim = typename Nth<0, InDims>::type;
        const auto in_idx = get_flattened_index<NB_DIMS, InDim>(out_idx);
        return inputs[0][in_idx];
    }
};

template <size_t NB_ELTS,
          size_t NB_DIMS,
          ManyWise_T ELEM_OP,
          const size_t OUT_DIMS[],
          size_t NB_INPUTS,
          typename InDims,
          typename T>
__attribute__((always_inline)) inline static void
manywise_forward(const T *const *__restrict inputs, T *__restrict output)
{
    size_t out_idx[NB_DIMS] = {0};

    for (size_t i = 0; i < NB_ELTS; ++i) {
        output[i] = ApplyManywiseOp<NB_INPUTS - 1,
                                    NB_DIMS,
                                    ELEM_OP,
                                    NB_INPUTS,
                                    InDims,
                                    T>::compute(inputs, out_idx);

        // Increment out_idx as a multidimensional counter
        for (int i = NB_DIMS - 1; i >= 0; --i) {
            if (++out_idx[i] < OUT_DIMS[i]) {
                break;
            } else {
                out_idx[i] = 0;
            }
        }
    }
}

} // namespace export_cpp

#endif // __AIDGE_EXPORT_CPP_KERNELS_MANYWISE__