#ifndef __AIDGE_EXPORT_CPP_KERNELS_CLIP
#define __AIDGE_EXPORT_CPP_KERNELS_CLIP

#if __cplusplus >= 201703L
#include <algorithm> // clamp
#endif
#include <cstddef>

#include "utils/cpp/typedefs.hpp"

// Generic function for sqrt

using namespace export_cpp;

template <float MIN,
          float MAX,
          std::size_t NB_ELTS,
          // Memory mapping: inputs
          std::size_t INPUT_MEM_CONT_OFFSET,
          std::size_t INPUT_MEM_CONT_SIZE,
          std::size_t INPUT_MEM_WRAP_OFFSET,
          std::size_t INPUT_MEM_WRAP_SIZE,
          std::size_t INPUT_MEM_STRIDE,
          // Memory mapping: outputs
          std::size_t OUTPUT_MEM_CONT_OFFSET,
          std::size_t OUTPUT_MEM_CONT_SIZE,
          std::size_t OUTPUT_MEM_WRAP_OFFSET,
          std::size_t OUTPUT_MEM_WRAP_SIZE,
          std::size_t OUTPUT_MEM_STRIDE,
          typename Input_T,
          typename Output_T>
__attribute__((always_inline)) inline void
clip_forward(const Input_T *__restrict inputs, Output_T *__restrict outputs)
{
    std::size_t inOffset = 0;
    std::size_t outOffset = 0;

    for (std::size_t i = 0; i < NB_ELTS; ++i) {
        if (INPUT_MEM_WRAP_SIZE > 0 &&
            i == INPUT_MEM_CONT_SIZE / sizeof(Input_T))
        {
            inOffset = (INPUT_MEM_WRAP_OFFSET - INPUT_MEM_CONT_OFFSET -
                        INPUT_MEM_CONT_SIZE) /
                       static_cast<int>(sizeof(Input_T));
        }

        if (OUTPUT_MEM_WRAP_SIZE > 0 &&
            i == OUTPUT_MEM_CONT_SIZE / sizeof(Output_T))
        {
            outOffset = (OUTPUT_MEM_WRAP_OFFSET - OUTPUT_MEM_CONT_OFFSET -
                         OUTPUT_MEM_CONT_SIZE) /
                        static_cast<int>(sizeof(Output_T));
        }

#if __cplusplus >= 201703L
        outputs[outOffset + i] = std::clamp(inputs[inOffset + i], MIN, MAX);
#else
        outputs[outOffset + i] =
            (inputs[inOffset + i] > static_cast<Input_T>(MIN))
                ? ((inputs[inOffset + i] < static_cast<Input_T>(MAX))
                       ? static_cast<Output_T>(inputs[inOffset + i])
                       : static_cast<Output_T>(MAX))
                : static_cast<Output_T>(MIN);
#endif
    }
}

#endif // __AIDGE_EXPORT_CPP_KERNELS_CLIP