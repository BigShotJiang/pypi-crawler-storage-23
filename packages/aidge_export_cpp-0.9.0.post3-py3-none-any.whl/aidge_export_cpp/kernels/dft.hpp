#ifndef __AIDGE_EXPORT_CPP_KERNELS_DFT__
#define __AIDGE_EXPORT_CPP_KERNELS_DFT__

#include "utils/cpp/typedefs.hpp"
#include "utils/cpp/utils.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <type_traits>

namespace export_cpp {

namespace detail {
constexpr auto is_pow2(size_t n) { return (n & (n - 1)) == 0; }

inline std::size_t bitReverse(std::size_t x, std::size_t bits)
{
    std::size_t r = 0;
    for (std::size_t i = 0; i < bits; ++i) {
        r = (r << 1) | (x & 1);
        x >>= 1;
    }
    return r;
}

/**
 * Implement the Cooley–Tukey FFT algorithm.
 * See https://en.wikipedia.org/wiki/Cooley%E2%80%93Tukey_FFT_algorithm
 */
template <typename T, bool INV, size_t N>
void radix2_fft(std::array<std::complex<T>, N> &x)
{
    unsigned int bits = 0;
    while ((1u << bits) < N) {
        ++bits;
    }

    for (unsigned int k = 0; k < N; k++) {
        const unsigned int rev_k = bitReverse(k, bits);
        if (k < rev_k) {
            std::swap(x[k], x[rev_k]);
        }
    }

    for (unsigned int M = 2; M <= N; M <<= 1) {
        for (unsigned int k = 0; k < N; k += M) {
            for (unsigned int j = 0; j < M / 2; j++) {
                const auto evenIndex = k + j;
                const auto oddIndex = k + j + (M / 2);
                const auto even = x[evenIndex];
                const auto odd = x[oddIndex];
                const auto angle =
                    (INV ? 2 : -2) * M_PI * j / static_cast<T>(M);
                const auto twiddle = std::polar<T>(1.0, angle) * odd;
                x[evenIndex] = even + twiddle;
                x[oddIndex] = even - twiddle;
            }
        }
    }

    // scale inverse FFT
    if (INV) {
        for (auto &v : x) {
            v /= T(N);
        }
    }
}

constexpr size_t next_pow2(size_t x)
{
    size_t p = 1;
    while (p < x) {
        p <<= 1;
    }
    return p;
}

template <typename T, bool INV, size_t N>
void fft(std::array<std::complex<T>, N> &x)
{
    // The size is a power of two => one case uses radix2_fft() directly
    if (is_pow2(N)) {
        radix2_fft<T, INV>(x);
        return;
    }

    // Otherwise, use the Bluestein algorithm
    // https://en.wikipedia.org/wiki/Chirp_Z-transform
    constexpr auto M = next_pow2(2 * N - 1);
    std::array<std::complex<T>, M> a = {};
    std::array<std::complex<T>, M> b = {};

    // Precompute chirp
    a[0] = x[0];
    b[0] = 1;
    for (size_t n = 1; n < N; ++n) {
        const T angle =
            (INV ? M_PI : -M_PI) * (static_cast<uintmax_t>(n) * n) / N;
        a[n] = x[n] * std::polar<T>(1.0, angle);
        b[n] = b[M - n] = std::polar<T>(1.0, -angle);
    }

    // Convolution via power-of-two FFT
    radix2_fft<T, false>(a);
    radix2_fft<T, false>(b);
    for (size_t i = 0; i < M; i++) {
        a[i] *= b[i];
    }
    radix2_fft<T, true>(a);

    // Extract result
    for (size_t n = 0; n < N; ++n) {
        const T angle =
            (INV ? M_PI : -M_PI) * (static_cast<uintmax_t>(n) * n) / N;
        x[n] = a[n] * std::polar<T>(1.0, angle);
    }

    // scale inverse FFT
    if (INV) {
        for (auto &v : x) {
            v /= T(N);
        }
    }
}
} // namespace detail

template <typename T, size_t N> void fft(std::array<std::complex<T>, N> &x)
{
    detail::fft<T, false>(x);
}
template <typename T, size_t N> void ifft(std::array<std::complex<T>, N> &x)
{
    detail::fft<T, true>(x);
}

template <size_t AXIS_SIZE_PRE,
          size_t AXIS_SIZE_POST,
          size_t DIM_I,
          size_t DIM_O,
          bool INVERSE,
          typename Input_T,
          typename Output_T>
__attribute__((always_inline)) inline void
dft_forward(const Input_T *__restrict inputs, Output_T *__restrict outputs)
{
    // Iterate over the "pre-axis" and "post-axis" slices.
    // For each slice along the axis, compute the maximum value,
    // the sum of exponentials, and then write the normalized dft outputs.
    for (size_t i = 0; i < AXIS_SIZE_PRE; ++i) {
        for (size_t j = 0; j < AXIS_SIZE_POST; ++j) {
            std::array<Output_T, DIM_O> buffer{0};
            size_t idx_i = i * DIM_I * AXIS_SIZE_POST + j;
            size_t idx_o = i * DIM_O * AXIS_SIZE_POST + j;

            for (size_t k = 0; k < DIM_I && k < DIM_O; ++k) {
                buffer[k] = inputs[idx_i];
                idx_i += AXIS_SIZE_POST;
            }

            if (INVERSE) {
                ifft(buffer);
            } else {
                fft(buffer);
            }

            for (size_t k = 0; k < DIM_O; ++k) {
                outputs[idx_o] = buffer[k];
                idx_o += AXIS_SIZE_POST;
            }
        }
    }
}

} // namespace export_cpp

#endif // __AIDGE_EXPORT_CPP_KERNELS_DFT__
