import os
import sys
import logging
import json
import time
import math
import hashlib
import zlib
import re
import difflib
import threading
import argparse
import subprocess
import ast
import base64
import secrets
from datetime import datetime
# VERSION: E2EE_NEURAL_VAULT_V18
from threading import Timer
from collections import Counter, deque
from typing import Any, List, Dict, Optional

# Multi-Language AST Support
try:
    from tree_sitter_languages import get_language, get_parser
    TREE_SITTER_AVAILABLE = True
except ImportError:
    TREE_SITTER_AVAILABLE = False

# MCP & Web Imports
from mcp.server.fastmcp import FastMCP
from dotenv import load_dotenv
from supabase import create_client, Client
from groq import Groq
import uvicorn
from starlette.responses import JSONResponse
from starlette.requests import Request
import httpx

# Configure logging to strictly use stderr to prevent polluting the JSON-RPC stdout stream
logging.basicConfig(
    level=logging.WARNING,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr
)
logger = logging.getLogger("DalexorBridge")
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from fastapi.middleware.cors import CORSMiddleware

# Load local environment if it exists (Priority: Local .env > Shell Env)
load_dotenv(override=True)

# --- CONFIGURATION & AUTH (STATELESS) ---

def load_global_config():
    """Load configuration from global user config file."""
    import json
    config_file = os.path.join(os.path.expanduser("~/.dalexor"), "config.json")
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"[!] Warning: Failed to load global config: {e}")
    return {}



# Load Global Config
GLOBAL_CONFIG = load_global_config()

# Try to load API KEY from Env -> Global Config
DX_API_KEY = os.getenv("DX_API_KEY") or os.getenv("DALEXORMI_API_KEY") or GLOBAL_CONFIG.get("api_key")

CLOUD_URL = os.getenv("DALEXORMI_URL", "https://api.dalexor.com")
DX_SOVEREIGN = os.getenv("DX_SOVEREIGN", GLOBAL_CONFIG.get("sovereign", "false")).lower() == "true"
DX_TEAM_SECRET = (os.getenv("DX_TEAM_SECRET") or GLOBAL_CONFIG.get("team_secret") or "").strip()

# Set globals for project context if available
if not os.getenv("DX_PROJECT_ID") and GLOBAL_CONFIG.get("project_id"):
    os.environ["DX_PROJECT_ID"] = GLOBAL_CONFIG.get("project_id")
    
if not os.getenv("DX_PROJECT_NAME") and GLOBAL_CONFIG.get("project_name"):
    os.environ["DX_PROJECT_NAME"] = GLOBAL_CONFIG.get("project_name")


# --- NEURAL VAULT (E2EE) ---
class NeuralVault:
    @staticmethod
    def get_key(secret: str):
        import hashlib, base64
        hasher = hashlib.sha256()
        hasher.update(secret.encode())
        return base64.urlsafe_b64encode(hasher.digest())

# Removed NeuralVault.lock: Encryption is now handled by the Cloud Brain.

    @staticmethod
    def unlock(blob: str, secret: str) -> str:
        if not blob or not secret: return blob
        if not str(blob).startswith("vault_v1:"): return blob
        try:
            from cryptography.fernet import Fernet
            import base64
            cipher_text = blob.replace("vault_v1:", "").strip()
            
            # 🛡️ NOVEL BASE64 RECOVERY: Repair padding
            while len(cipher_text) % 4 != 0:
                cipher_text += "="
                
            f = Fernet(NeuralVault.get_key(secret))
            return f.decrypt(cipher_text.encode()).decode()
        except:
            return "[Neural Vault: Decryption Failed (Check DX_TEAM_SECRET)]"

# ... (Supabase/Groq init logic remains same) ...
# These are used by the CLOUD BRAIN (Railway) to talk to the DB/AI
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_SERVICE_ROLE = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_KEY")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# Detection: Are we running on Railway?
IS_CLOUD = os.getenv("RAILWAY_ENVIRONMENT") == "true" or os.getenv("RAILWAY_STATIC_URL") is not None or os.getenv("VPS_MODE") == "true"

# Shared Constants
IGNORE_LIST = {'.git', 'node_modules', '__pycache__', '.env', 'dist', 'build', '.next', '.dalexor', '.vscode', '.idea', 'venv', '.pyc', '.egg-info', '.pytest_cache', '.mypy_cache'}


# --- INITIALIZE DATABASE ONLY IF IN CLOUD ---
supabase_admin: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE) if (IS_CLOUD and SUPABASE_URL and SUPABASE_SERVICE_ROLE) else None
groq_client = Groq(api_key=GROQ_API_KEY) if (IS_CLOUD and GROQ_API_KEY) else None

# --- ENTROPY ENGINE ---
class SovereignEntropyEngine:
    @staticmethod
    def calculate(content, file_path=""):
        if not content or len(content) < 10: return 0.0
        
        # Layer 1: Token-based Shannon Entropy (Semantic Density)
        tokens = re.findall(r'[a-zA-Z_][a-zA-Z0-9_]*', content)
        if not tokens: return 0.5
        
        counts = Counter(tokens)
        total_tokens = len(tokens)
        shannon = -sum((count/total_tokens) * math.log2(count/total_tokens) for count in counts.values())
        
        # Layer 2: Autonomous Gravity (Structural Signature Analysis)
        gravity = 1.0
        
        # A. Identity Affinity: If tokens match the file name, the file is describing ITSELF (High Signal).
        if file_path:
            file_name = os.path.basename(file_path).split('.')[0].lower()
            if len(file_name) > 2:
                token_set = {t.lower() for t in tokens}
                if file_name in token_set:
                    gravity = max(gravity, 3.5)
        
        # B. Symbol Complexity Boost: Any token that looks like a Class, Function, or Constant.
        # PascalCase, camelCase, or UPPER_SNAKE
        complex_symbols = [t for t in tokens if re.search(r'[a-z][A-Z]', t) or re.match(r'^[A-Z][a-z]+[A-Z]', t) or (re.match(r'^[A-Z_]{4,}$', t))]
        symbol_density = len(complex_symbols) / total_tokens
        gravity += (symbol_density * 5.0)
        
        # Layer 3: Structural Multiplier (Logic density check)
        structure_multiplier = 1.0
        logic_patterns = [
            r'def\s+\w+', r'async\s+def', r'class\s+\w+',
            r'return\s+', r'if\s+.*:', r'import\s+', r'@\w+\(',
            r'\{[\s\S]*\}', r'supabase'
        ]
        
        for pattern in logic_patterns:
            matches = re.findall(pattern, content)
            if matches:
                structure_multiplier += (len(matches) * 0.20)
        
        # Layer 4: Noise Penalty (Repetitive boilerplate reduction)
        unique_tokens = len(counts)
        lexical_diversity = unique_tokens / total_tokens
        if lexical_diversity < 0.2 and total_tokens > 30:
            structure_multiplier *= 0.4
            
        # Final Sovereign Calculation
        score = (shannon * gravity * structure_multiplier) / 1.5
        return round(min(score, 10.0), 2)

# --- TRANSACTION MEMORY ---
class TransactionMemory:
    def __init__(self, cloud_callback):
        self.buffer = deque(maxlen=50)
        self.cloud_callback = cloud_callback
        self.lock = threading.Lock()
        self.flush_timer = None

    def add(self, file_path, diff, entropy, synapses, symbols, force_seal=False):
        with self.lock:
            # Check if this file already in buffer. If so, update it.
            # This is "Edge Coalescence"
            self.buffer.append({"file": file_path, "diff": diff, "entropy": entropy, "synapses": synapses, "symbols": symbols, "ts": time.time(), "seal": force_seal})
            
            if force_seal or len(self.buffer) >= 5:
                self._flush()
            else:
                if self.flush_timer: self.flush_timer.cancel()
                self.flush_timer = Timer(10.0, self._flush)
                self.flush_timer.start()

    def flush_all(self):
        """Force immediate flush of all pending items, marking them as seals."""
        with self.lock:
            if not self.buffer:
                print("[!] No pending evolution detected. (Use 'dx seal' for full project snapshot)")
                return
            
            # Mark all pending items as seals
            for item in self.buffer:
                item['seal'] = True
                
            print(f"[!] Sealing Milestone: Transmitting {len(self.buffer)} pending evolutionary atoms...")
        self._flush()

    def _flush(self):
        with self.lock:
            if not self.buffer: return
            batch = list(self.buffer)
            self.buffer.clear()
            
            for item in batch:
                content = item['diff']
                file_path = item['file']
                entropy = item['entropy']
                is_seal = item.get('seal', False)
                
                payload = {
                    "content": scrub_secrets(content[:10000]) if not content.startswith("vault_") else content,
                    "entropy_score": 10.0 if is_seal else round(entropy, 2),
                    "atom_type": "evolution_event", # Always use evolution_event for proper rendering
                    "source": "sentinel",
                    "synapses": item.get('synapses', []),
                    "symbols": item.get('symbols', []),
                    "is_sovereign": DX_SOVEREIGN,
                    "request_server_encryption": DX_SOVEREIGN,
                    "metadata": {
                        "file_path": file_path.replace("\\", "/"),
                        "file_name": os.path.basename(file_path),
                        "content_hash": hashlib.sha256(content.encode()).hexdigest(),
                        "summary": f"MILESTONE: {os.path.basename(file_path)} Sealed" if is_seal else f"Evolutionary Shift in {os.path.basename(file_path)}",
                        "synapses": item.get('synapses', []),
                        "symbols": item.get('symbols', []),
                        "dx_seal": is_seal
                    }
                }
                threading.Thread(target=self.cloud_callback, args=(payload,), daemon=True).start()

# --- UTILITY FUNCTIONS ---
def scrub_secrets(text):
    """Remove potential secrets from text before uploading."""
    patterns = [
        (r'(api[_-]?key|token|secret|password)\s*[=:]\s*[\'"]?([^\s\'"]+)', r'\1=***REDACTED***'),
        (r'Bearer\s+[A-Za-z0-9\-._~+/]+=*', 'Bearer ***REDACTED***'),
    ]
    for pattern, replacement in patterns:
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
    return text

def print_banner(email="Sovereign", plan="Identity Verified"):
    """Print welcome banner with user info."""
    display_plan = plan
    if plan.lower() == "free": display_plan = "Surgical Sandbox (Limited)"
    elif plan.lower() == "standard" or plan.lower() == "users": display_plan = f"{plan.capitalize()} (Scaling)"
    
    print("\n" + "="*60)
    print(" DALEXOR INTELLIGENCE SYSTEM")
    print("="*60)
    print(f" User: {email}")
    print(f" Plan: {display_plan}")
    print("="*60 + "\n")


def interactive_verification(force_prompt=False):
    """Verify identity with the Global Brain using environment or interactive prompt."""
    global DX_API_KEY, DX_TEAM_SECRET
    if not sys.stdin.isatty(): return (DX_API_KEY, "System", "Automated")
    
    current_key = DX_API_KEY
    if not current_key or force_prompt:
        print("\n" + "="*60)
        print(" DALEXOR INTELLIGENCE : SECURE HANDSHAKE")
        print("="*60)
        current_key = input("\n[*] Enter Sovereign API Key: ").strip()
        if not current_key: sys.exit(1)
        DX_API_KEY = current_key

    print("\n[*] Connecting to Global Brain...")
    try:
        import requests
        headers = {"X-DX-Key": current_key}
        response = requests.get(f"{CLOUD_URL}/validate", headers=headers, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            user_data = data.get("user", {})
            email = user_data.get('email', 'Sovereign')
            plan = data.get("subscription", {}).get("display", "Identity Verified")
            
            # 🌩️ Cloud Context Recovery: Adopt the session state from the server
           

            print(f"[+] Identity Confirmed: {email}")
            print(f"[*] Subscription: {plan}")

            # 🛡️ SOVEREIGN MODE ACTIVATION (For Pro/Enterprise/Sovereign plans ONLY - Standard/Users excluded)
            is_sovereign_plan = any(p in plan.lower() for p in ["sovereign", "enterprise", "professional", "unlimited", "pro"]) and not any(p in plan.lower() for p in ["standard", "users", "power", "sandbox"])
            
            global DX_SOVEREIGN
            if is_sovereign_plan:
                DX_SOVEREIGN = True
                print(f"[*] Sovereign Mode: ACTIVATED (End-to-End Encryption Enabled)")
                
                # 🔐 Prompt for Team Secret if not already set
                if not DX_TEAM_SECRET or force_prompt:
                    print("\n" + "="*60)
                    print(" NEURAL VAULT : E2EE TEAM SECRET")
                    print("="*60)
                    team_secret_input = input("\n[*] Enter Team Secret (E2EE Key): ").strip()
                    if team_secret_input:
                        DX_TEAM_SECRET = team_secret_input
                        print("[+] Team Secret configured for Neural Vault encryption.")
            else:
                DX_SOVEREIGN = False
            
            return (current_key, email, plan)
        else:
            print(f"[!] Verification Failed: {response.json().get('error', 'Invalid Key')}")
            sys.exit(1)
    except Exception as e:
        print(f"[!] Error: {e}")
        sys.exit(1)

def save_to_env(key, project_id=None, project_name=None, team_secret=None):
    """Save configuration to global config file."""
    import json
    
    # Use global config directory
    config_dir = os.path.expanduser("~/.dalexor")
    config_file = os.path.join(config_dir, "config.json")
    
    # Create directory if it doesn't exist
    os.makedirs(config_dir, exist_ok=True)
    
    # Read existing config
    config = {}
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
        except:
            pass
    
    # Update with new values
    config['api_key'] = key
    if project_id:
        config['project_id'] = project_id
        config['last_project_id'] = project_id
    if project_name:
        config['project_name'] = project_name
    if team_secret:
        config['team_secret'] = team_secret
    
    # Save Sovereign status
    config['sovereign'] = str(DX_SOVEREIGN).lower()
    
    config['cloud_url'] = CLOUD_URL
    
    # Save config
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)
    
    print(f"[+] Configuration saved to {config_file}")

def select_project(key, plan="free"):
    """Fetch and select a project, pinning it on the server for stateless sessions."""
    import requests
    
    # Update global API key to match the one used in dx init
    global DX_API_KEY
    DX_API_KEY = key
    
    headers = {"X-DX-Key": key}
    print("\n[*] Fetching project blueprints...")
    try:
        proj_res = requests.get(f"{CLOUD_URL}/projects", headers=headers, timeout=10)
        project_id = None
        project_name = "Default"
        
        if proj_res.status_code == 200:
            projects = proj_res.json().get("projects", [])
            if projects:
                print(f"\n[?] Found {len(projects)} existing project universes:")
                for idx, p in enumerate(projects):
                    print(f"   {idx + 1}. {p['name']} ({p.get('status', 'active')})")
                print(f"   {len(projects) + 1}. [Create New Project]")
                
                choice = input("\n[>] Select Project: ").strip()
                try:
                    c_idx = int(choice) - 1
                    if 0 <= c_idx < len(projects):
                        project_id = projects[c_idx]["id"]
                        project_name = projects[c_idx]["name"]
                    else:
                        project_name = input("[>] Enter New Project Name: ").strip()
                except:
                    project_id = None 
                    project_name = input("[>] Enter New Project Name: ").strip()
            else:
                project_name = input("[>] No projects found. Enter Project Name: ").strip()
        
        if not project_id:
            create_res = requests.post(f"{CLOUD_URL}/projects", json={"name": project_name}, headers=headers, timeout=10)
            if create_res.status_code == 200:
                project_id = create_res.json().get("project", {}).get("id")
                print(f"[+] Project '{project_name}' created and assigned.")
        
        # 🌩️ PIN PROJECT ON SERVER (No local files!)
        requests.post(f"{CLOUD_URL}/select-project", json={"project_id": project_id}, headers=headers, timeout=10)
        os.environ["DX_PROJECT_ID"] = project_id
        os.environ["DX_PROJECT_NAME"] = project_name
        print(f"[+] Context Pinned to Cloud: {project_name}")

        # --- E2EE NEURAL VAULT KEY MANAGEMENT ---
        print("\n" + "-"*60)
        print(" NEURAL VAULT : END-TO-END ENCRYPTION")
        print("-"*60)
        
        is_restricted_plan = any(p in plan.lower() for p in ["sandbox", "free", "limited", "standard", "users", "power"])
        if is_restricted_plan:
            print("[!] PLAN RESTRICTION: Neural Vault (E2EE) is a Professional/Sovereign feature.")
            print(f"[!] Your '{plan}' plan uses Standard Encryption (TLS/AES).")
        else:
            # Prioritize user-entered team secret, then fall back to server
            global DX_TEAM_SECRET
            if not DX_TEAM_SECRET:
                # Secrets come from server only if not manually entered
                all_proj_res = requests.get(f"{CLOUD_URL}/projects", headers=headers, timeout=10).json()
                selected_p = next((p for p in all_proj_res.get("projects", []) if p['id'] == project_id), {})
                team_secret = selected_p.get("team_secret")
                if team_secret:
                    DX_TEAM_SECRET = team_secret
                    os.environ["DX_TEAM_SECRET"] = team_secret
            else:
                # User manually entered the secret
                os.environ["DX_TEAM_SECRET"] = DX_TEAM_SECRET
            
            if DX_TEAM_SECRET:
                print(f"[*] Neural Vault Key active for this project (Cloud Sync).")
                
                # 🌩️ UPLOAD SECRET TO GLOBAL BRAIN (E2EE Handshake)
                try:
                    requests.post(f"{CLOUD_URL}/projects/{project_id}/secret", json={"secret": DX_TEAM_SECRET}, headers=headers, timeout=10)
                    print("[+] Neural Vault Handshake Complete: Cloud Sync Enabled.")
                except Exception as e:
                    print(f"[*] Warning: Key Sync delayed: {e}")
        
        print(f"[+] Project {project_name} Ready. CLI is operating in Stateless Cloud Mode.")
        
        # Save to .env file
        save_to_env(key, project_id, project_name, os.environ.get("DX_TEAM_SECRET"))

        return project_id, project_name
    except Exception as e:
        print(f"[!] Project Selection Error: {e}")
        return None, "Default"

# --- SENTINEL HANDLERS ---
class CodeChangeHandler(FileSystemEventHandler):
    def __init__(self, tx_memory):
        self.tx_memory = tx_memory
        self.last_hashes = self.load_hashes()
        self.content_cache = {}

    def load_hashes(self):
        """Load known file hashes to prevent redundant syncs."""
        path = os.path.join(".dalexor", "states.json")
        try:
            if os.path.exists(path):
                with open(path, 'r') as f:
                    return json.load(f).get("hashes", {})
        except: pass
        return {}

    def save_hashes(self):
        """Persist hashes to disk for future session continuity."""
        if not os.path.exists(".dalexor"):
            try: os.makedirs(".dalexor")
            except: pass
        path = os.path.join(".dalexor", "states.json")
        try:
            with open(path, 'w') as f:
                json.dump({"hashes": self.last_hashes, "ts": time.time()}, f)
        except: pass

    def on_modified(self, event): self._handle_event(event)
    def on_created(self, event): self._handle_event(event)

    def _handle_event(self, event):
        if event.is_directory or any(x in event.src_path for x in IGNORE_LIST): return
        
        # Normalize Windows paths to Forward Slashes for Lineage Parity
        src_path = event.src_path.replace('\\', '/')
        
        # Neural Pulse Feedback
        print(f"[*] Neural Pulse: {os.path.basename(src_path)} detected.")
        
        # Windows Grace Period: Let the IDE finish writing the file
        time.sleep(0.2)
        
        # Instant Presence report (Presence Parity)
        self.report_presence(src_path)
        # Debounce/Throttle at Sentinel level too
        self.process_change(src_path)

    def report_presence(self, file_path):
        import requests
        try:
            # Dynamically fetch key to ensure validity
            key = os.getenv("DX_API_KEY") or os.getenv("DALEXORMI_API_KEY") or DX_API_KEY
            if not key: return
            headers = {"X-DX-Key": key}
            # Silent fire-and-forget presence pulse
            requests.post(f"{CLOUD_URL}/presence", json={"file_path": file_path}, headers=headers, timeout=1.0)
        except Exception as e:
            # Presence pulse is non-critical, but we log the debug signal
            logger.debug(f"Presence pulse failed: {e}")
            pass

    def extract_synapses(self, content, current_file_name="", project_catalog=None):
        """Atomic Synapse Engine V7: Tree-Sitter & Greedy Dispatcher."""
        if not content: return []
        found = set()
        ext = os.path.splitext(current_file_name)[1].lower()

        # 0. NATIVE PYTHON AST (Built-in)
        if ext == '.py':
            try:
                tree = ast.parse(content)
                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        for alias in node.names: found.add(alias.name.split('.')[0])
                    elif isinstance(node, ast.ImportFrom):
                        if node.module: found.add(node.module.split('.')[0])
            except: pass

        # 1. TREE-SITTER RECOVERY (For other languages)
        elif TREE_SITTER_AVAILABLE:
            lang_map = {
                '.js': 'javascript', '.jsx': 'javascript',
                '.ts': 'typescript', '.tsx': 'tsx',
                '.go': 'go', '.rs': 'rust', '.rb': 'ruby',
                '.cpp': 'cpp', '.h': 'cpp', '.cs': 'c_sharp',
                '.java': 'java', '.php': 'php'
            }
            lang_name = lang_map.get(ext)
            if lang_name:
                try:
                    parser = get_parser(lang_name)
                    tree = parser.parse(bytes(content, "utf8"))
                    
                    # Custom Query for Imports/Requires
                    query_map = {
                        'javascript': '(import_statement source: (string) @src) (call_expression function: (identifier) @func arguments: (arguments (string) @src) (#eq? @func "require"))',
                        'typescript': '(import_statement source: (string) @src) (call_expression function: (identifier) @func arguments: (arguments (string) @src) (#eq? @func "require"))',
                        'tsx': '(import_statement source: (string) @src)',
                        'go': '(import_spec path: (string) @src)',
                        'rust': '(use_declaration argument: (use_path) @src)',
                        'php': '(include_expression path: (string) @src) (require_expression path: (string) @src)',
                    }
                    
                    query_str = query_map.get(lang_name)
                    if query_str:
                        language = get_language(lang_name)
                        query = language.query(query_str)
                        captures = query.captures(tree.root_node)
                        for node, tag in captures:
                            if tag == 'src':
                                name = node.text.decode('utf8').strip('\'"`').split('/')[-1]
                                if name: found.add(name)
                except Exception as e:
                    logger.debug(f"Tree-Sitter Parse Error for {current_file_name}: {e}")

        # 2. FALLBACK/REFINED REGEX (If Tree-Sitter failed or not available)
        if not found and ext in ['.js', '.ts', '.jsx', '.tsx', '.cs', '.cpp', '.h', '.java', '.go', '.rs', '.rb']:
            patterns = [
                r'import\s+.*?\s+from\s+[\'"](.*?)[\'"]',
                r'require\([\'"](.*?)[\'"]\)',
                r'export\s+.*?\s+from\s+[\'"](.*?)[\'"]',
                r'using\s+([\w\.]+);',
                r'#include\s+[<"](.*)[>"]',
                r'use\s+([\w:]+);'
            ]
            for p in patterns:
                for match in re.findall(p, content):
                    name = match.split('/')[-1].split('\\')[-1].split(':')[-1]
                    if name: found.add(name)

        # 3. HTML/WEB ANALYZER (New Sovereign Layer)
        elif ext == '.html':
            html_patterns = [
                r'src=["\'](.*?)["\']',
                r'href=["\'](.*?)["\']',
                r'action=["\'](.*?)["\']',
            ]
            for p in html_patterns:
                for match in re.findall(p, content):
                    # Robust path handling: Remove query params & hashes
                    clean_match = match.split('?')[0].split('#')[0]
                    # Get basename for catalog matching
                    name = clean_match.split('/')[-1].split('\\')[-1]
                    if name and '.' in name and len(name) > 2: 
                        found.add(name)

        # 4. UNIFIED CATALOG CROSS-CHECK (The Intelligence Layer)
        if project_catalog:
            # Strip comments before catalog matching to avoid "Comment Ghosts"
            clean_content = re.sub(r'//.*|/\*[\s\S]*?\*/|#.*|"""[\s\S]*?"""', '', content)
            tokens = set(re.findall(r'[A-Z][a-zA-Z0-9_]*|\b[a-zA-Z_]\w*\.[a-zA-Z0-9]+\b', clean_content))
            for t in tokens:
                if t in project_catalog and t != current_file_name:
                    found.add(t)

        system_exclude = {'os', 'sys', 'json', 'math', 'hashlib', 'time', 're', 'datetime', 'threading', 'logging', 'subprocess', 'ast', 'base64', 'secrets', 'react', 'vue', 'fs', 'path', 'http', 'https'}
        return [f for f in found if f.lower() not in system_exclude and f != current_file_name]

    def extract_symbols(self, content, file_path=""):
        """Sovereign Symbol Extraction: Multi-language semantic indexing."""
        if not content: return []
        symbols = set()
        ext = os.path.splitext(file_path)[1].lower()

        # 1. PYTHON NATIVE AST
        if ext == '.py':
            try:
                tree = ast.parse(content)
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)): symbols.add(node.name)
            except: pass

        # 2. TREE-SITTER SYBMOL MINING
        elif TREE_SITTER_AVAILABLE:
            lang_map = {
                '.js': 'javascript', '.ts': 'typescript', '.go': 'go', 
                '.rs': 'rust', '.cpp': 'cpp', '.cs': 'c_sharp'
            }
            lang_name = lang_map.get(ext)
            if lang_name:
                try:
                    parser = get_parser(lang_name)
                    tree = parser.parse(bytes(content, "utf8"))
                    query_map = {
                        'javascript': '(function_declaration name: (identifier) @name) (class_declaration name: (identifier) @name)',
                        'typescript': '(function_declaration name: (identifier) @name) (class_declaration name: (identifier) @name) (interface_declaration name: (type_identifier) @name)',
                        'go': '(function_declaration name: (identifier) @name) (type_spec name: (type_identifier) @name)',
                        'rust': '(function_item name: (identifier) @name) (struct_item name: (type_identifier) @name) (trait_item name: (identifier) @name)',
                    }
                    query_str = query_map.get(lang_name)
                    if query_str:
                        language = get_language(lang_name)
                        query = language.query(query_str)
                        captures = query.captures(tree.root_node)
                        for node, tag in captures:
                            symbols.add(node.text.decode('utf8'))
                except: pass

        # 3. FALLBACK REGEX SUITE (Includes language-specific patterns)
        if not symbols:
            patterns = {
                '.js': r'(?:function|class|const|let|var)\s+([a-zA-Z_]\w*)',
                '.ts': r'(?:function|class|interface|type|enum|const)\s+([a-zA-Z_]\w*)',
                '.go': r'(?:func|type|struct|interface)\s+(?:\([^\)]+\)\s+)?([a-zA-Z_]\w*)',
                '.rs': r'(?:fn|mod|struct|enum|trait|type)\s+([a-zA-Z_]\w*)',
                '.cpp': r'(?:class|struct|void|[\w<>]+)\s+([a-zA-Z_]\w*)(?:\s*\(|\s*\{)'
            }
            p = patterns.get(ext)
            if p: symbols.update(re.findall(p, content))
            else: symbols.update(re.findall(r'(?:def|class|function|func|fn)\s+([a-zA-Z_]\w*)', content))
            
        return list(symbols)

    def process_change(self, file_path):
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            curr_hash = hashlib.sha256(content.encode()).hexdigest()
            if self.last_hashes.get(file_path) == curr_hash: return
            
            prev_content = self.content_cache.get(file_path, "")
            diff_lines = []
            for line in difflib.unified_diff(prev_content.splitlines(), content.splitlines(), lineterm=''):
                if (line.startswith('+') or line.startswith('-')) and not (line.startswith('+++') or line.startswith('---')):
                    diff_lines.append(line)
            
            diff_text = "\n".join(diff_lines)
            analysis_target = diff_text if prev_content else content
            entropy = SovereignEntropyEngine.calculate(analysis_target, file_path)
            
            self.last_hashes[file_path] = curr_hash
            self.content_cache[file_path] = content 
            self.save_hashes()            
            if entropy >= 0.1:
                synapses = self.extract_synapses(content, os.path.basename(file_path))
                symbols = self.extract_symbols(content, file_path)
                print(f"[+] Significant evolution in {os.path.basename(file_path)} (Entropy: {entropy})")
                self.tx_memory.add(file_path, diff_text if prev_content else content[:10000], entropy, synapses, symbols)
            else:
                # Provide feedback even for low-value changes so user knows it's working
                print(f"[-] Filtered {os.path.basename(file_path)}: Significance {entropy} < 0.1 thresh.")
        except Exception as e:
            print(f"[!] Engine Error in {os.path.basename(file_path)}: {e}")

    def warm_up(self, root_dir):
        """Silently index all existing files to prevent 'Ghost Changes' on startup."""
        print("[*] Warming up Sentinel Cache...")
        count = 0
        for root, dirs, files in os.walk(root_dir):
            # Prune ignored directories
            dirs[:] = [d for d in dirs if d not in IGNORE_LIST and not d.startswith('.')]
            for file in files:
                if any(x in file for x in IGNORE_LIST) or file.startswith('.'): continue
                path = os.path.join(root, file).replace("\\", "/")
                try:
                    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    curr_hash = hashlib.sha256(content.encode()).hexdigest()
                    self.last_hashes[path] = curr_hash
                    self.content_cache[path] = content
                    count += 1
                except Exception as e:
                    print(f"[*] Warning: Skipping unreadable artifact {path}: {e}")
        print(f"[+] Indexed {count} existing artifacts.")

class DummyMCP:
    def tool(self): return lambda f: f
    def resource(self, path): return lambda f: f
    def prompt(self): return lambda f: f
    def run(self, transport): raise RuntimeError("FastMCP not initialized")

# --- MCP SERVER INITIALIZATION ---
try:
    from mcp.server.fastmcp import FastMCP
    mcp = FastMCP("DalexorGlobal")
except Exception as e:
    sys.stderr.write(f"[Dalexor MCP] FastMCP Init Failed: {e}\n")
    mcp = DummyMCP()

async def cloud_call(endpoint: str, payload: dict, timeout: int = 15):
    """Secure Async Handshake with Cloud Brain."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            headers = {"X-DX-Key": DX_API_KEY}
            payload["project_id"] = os.getenv("DX_PROJECT_ID")
            res = await client.post(f"{CLOUD_URL}/tools/{endpoint}", json=payload, headers=headers)
            if res.status_code == 200:
                data = res.json()
                result = data.get("result", "No result returned.")
                # Auto-Decrypt if E2EE is active
                if isinstance(result, str) and "vault_" in result:
                    result = NeuralVault.unlock(result, DX_TEAM_SECRET)
                return result
            return f"Brain Error ({res.status_code}): {res.text[:200]}"
    except Exception as e:
        return f"Neural Disconnect: {e}"

@mcp.tool()
async def mcp_health_check() -> str:
    """Returns local agent status and connectivity to Global Brain."""
    error_msg = ""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            res = await client.get(f"{CLOUD_URL}/", headers={"X-DX-Key": DX_API_KEY})
            cloud_status = "ONLINE" if res.status_code == 200 else f"ERROR ({res.status_code})"
            if res.status_code != 200:
                error_msg = f" | Error: {res.text[:100]}"
    except Exception as e:
        cloud_status = "OFFLINE"
        error_msg = f" | Exception: {str(e)}"
    
    return f"Dalexor Local Agent: ACTIVE\nGlobal Brain: {cloud_status}{error_msg}\nURL: {CLOUD_URL}\nAPI Key: {'Set' if DX_API_KEY else 'Missing'}\nProject: {os.getenv('DX_PROJECT_ID')}\nSovereign: {DX_SOVEREIGN}"

@mcp.tool()
async def get_logical_evolution() -> str:
    """Historical Replay: Summarize logical shifts in the project over the last hour."""
    return await cloud_call("logical_evolution", {"window_minutes": 60})

@mcp.tool()
async def trace_dependency(symbol: str) -> str:
    """Impact Analysis: Find all files that import or call a specific symbol (function, class, variable)."""
    # Prefer Local Search first for speed
    local_files = []
    try:
        cmd = ["rg", "-l", symbol, "."]
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        if proc.stdout:
            local_files = [f.strip() for f in proc.stdout.split('\n') if f.strip() and not any(x in f for x in IGNORE_LIST)]
    except Exception as e:
        print(f"[*] Local dependency trace restricted: {e}")

    cloud_data = await cloud_call("trace_dependency", {"symbol": symbol})
    if local_files:
        return f"**Local Workspace Mentions:**\n" + "\n".join(local_files) + f"\n\n**Cloud Synaptic Context:**\n{cloud_data}"
    return cloud_data

@mcp.tool()
async def get_surgical_context(file_path: str) -> str:
    """Neighborhood Retrieval: Get the full history of a file and all its physically linked neighbors."""
    return await cloud_call("surgical_context", {"file_path": file_path}, timeout=20)

@mcp.tool()
async def find_related_decisions(topic: str) -> str:
    """Cross-Reference: Find architectural decisions related to a specific topic."""
    return await cloud_call("related_decisions", {"topic": topic})


@mcp.tool()
async def find_definition(symbol: str) -> str:
    """Global Symbol Provenance: Find where a function, class, or variable is defined."""
    # Try local search first
    patterns = [rf"(async\s+)?def\s+{symbol}\b", rf"class\s+{symbol}\b", rf"function\s+{symbol}\b"]
    for p in patterns:
        try:
            cmd = ["rg", "-n", "--column", "-e", p, "."]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=3)
            if proc.stdout: return f"**Local Match:**\n{proc.stdout}"
        except Exception as e:
            logger.debug(f"Local ripgrep search failed for {symbol}: {e}")
            continue
    return await cloud_call("find_definition", {"symbol": symbol})

@mcp.tool()
async def get_atomic_diff(file_path: str) -> str:
    """Atomic Diffing: Replay exact code changes between last two versions of a file."""
    return await cloud_call("atomic_diff", {"file_path": file_path})

@mcp.tool()
async def get_dependency_topology(file_path: str) -> str:
    """Dependency Topology: Map structural relationships (imports/calls) for the target file."""
    return await cloud_call("dependency_topology", {"file_path": file_path})

@mcp.tool()
async def predict_conflicts(file_path: str) -> str:
    """Predictive Risk Analysis: Detect if a file was edited recently and analyze cross-team collision risks."""
    return await cloud_call("predict_conflicts", {"file_path": file_path})









# --- CLI COMMANDS ---

def dx_init():
    print("[*] Initializing Dalexor Project Memory...")
    # Stateless Init: Link to cloud project without writing local files
    key_tuple = interactive_verification(force_prompt=True)
    if key_tuple and key_tuple[0]:
        select_project(key_tuple[0], plan=key_tuple[2])
    
    print("[+] Project Initialized. CLI is linked to Cloud Session.")

def dx_sync(args=None, is_seal=False, message=None):
    """Deep Project Analysis: Ingest the current state of all files and map synapses."""
    global DX_API_KEY
    
    # Force fresh project lookup from server instead of stale env vars
    import requests
    headers = {"X-DX-Key": DX_API_KEY}
    project_id = None
    
    try:
        user_res = requests.get(f"{CLOUD_URL}/validate", headers=headers, timeout=10)
        if user_res.status_code == 200:
            last_project = user_res.json().get("user", {}).get("last_project_id")
            if last_project:
                project_id = last_project
                print(f"[+] Resumed Context: Project {project_id}")
            else:
                print("[!] No active project. Run 'dx init' first.")
                return
        else:
            print("[!] Authentication failed.")
            return
    except Exception as e:
        print(f"[!] Connection error: {e}")
        return

    print(f"[*] Analyzing files line-by-line for neural mapping into Project: {project_id}...")
    
    # Pre-calculate project catalog for greedy synapse matching
    PROJECT_CATALOG = set()
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if d not in IGNORE_LIST and not d.startswith('.')]
        for f in files:
            if not any(x in f for x in IGNORE_LIST) and not f.startswith('.'):
                PROJECT_CATALOG.add(f)
                # Also index base names for languages like Python or Rust
                if '.' in f:
                    PROJECT_CATALOG.add(f.split('.')[0])
    
    def cloud_callback(payload):
        import requests
        import time
        
        # Auto-enable encryption if plan allows (Double check global flag)
        if DX_SOVEREIGN:
            payload["is_sovereign"] = True
            payload["request_server_encryption"] = True

        retries = 3
        for attempt in range(retries):
            try:
                res = requests.post(f"{CLOUD_URL}/ingest", json=payload, headers={"X-DX-Key": DX_API_KEY, "Content-Type": "application/json"}, timeout=30)
                if res.status_code == 429:
                    print(f"\n[!] Rate Limit Exceeded: Sync paused. Wait an hour or upgrade for higher velocity.")
                    sys.exit(0) # Stop sync immediately
                if res.status_code == 402:
                    print(f"\n[!] Quota Full: Sync aborted. You have reached your atom limit. Manage atoms at dalexor.com")
                    sys.exit(0)
                if res.status_code != 200:
                    print(f"[!] Server returned {res.status_code}: {res.text[:200]}")
                    return None
                return res.json()
            except requests.exceptions.Timeout:
                print(f"[!] Upload timed out after 30s (skipping file, continuing sync...)")
                return None
            except requests.exceptions.RequestException as e:
                if attempt < retries - 1:
                    wait_time = 2 * (attempt + 1)
                    print(f"[!] Connection glitch. Retrying in {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    print(f"[!] Upload failed after {retries} attempts: {str(e)}")
                    return None
            except Exception as e:
                print(f"[!] Critical Error: {str(e)}")
                return None

    def generate_smart_summary(content, filename):
        """Extract meaningful summary from content header or docstrings."""
        # 1. Try Local AI if available (Rich Summary)
        groq_key = os.getenv("GROQ_API_KEY")
        if groq_key:
            try:
                from groq import Groq
                client = Groq(api_key=groq_key)
                completion = client.chat.completions.create(
                    model="llama-3.1-8b-instant",
                    messages=[
                        {"role": "system", "content": "You are Dalexor, a Sovereign Intelligence Detective. Analyze this evidence. Output a RICH, STRUCTURED summary using these tags: [LOGIC], [SYSTEM], [SECURITY]. Explain exactly WHAT THIS FILE IS FOR. Use sections 'NARRATIVE:' and 'SYMBOLS:'. Example: '[LOGIC] Core Logic NARRATIVE: This file provides the central authentication logic...'. Keep it precise but visually consistent with the dashboard."},
                        {"role": "user", "content": f"Explain what this file is for and analyze its purpose:\nFilename: {filename}\nContent:\n{content[:2500]}"}
                    ],
                    temperature=0.1
                )
                return completion.choices[0].message.content.strip()
            except Exception as e:
                # Log to stderr to avoid corrupting command output
                sys.stderr.write(f"[*] Intelligence Insight restricted: {e}\n")

        # 2. Heuristic Extraction (Fast & Private)
        ext = os.path.splitext(filename)[1].lower()
        
        # Python Docstrings
        if ext == '.py':
            match = re.search(r'^"""(.*?)"""', content, re.DOTALL)
            if match:
                return match.group(1).strip().split('\n')[0][:80]
            match = re.search(r"^'''(.*?)'''", content, re.DOTALL)
            if match:
                return match.group(1).strip().split('\n')[0][:80]
                
        # JS/TS Comments
        if ext in ['.js', '.ts', '.jsx', '.tsx']:
            match = re.search(r'/\*\*(.*?)\*/', content, re.DOTALL)
            if match:
                clean = re.sub(r'\s*\*\s*', ' ', match.group(1)).strip()
                return clean.split('.')[0][:80]
            # Single line comment at top
            match = re.search(r'^//\s*(.*)', content)
            if match:
                return match.group(1).strip()[:80]

        # HTML Title
        if ext == '.html':
            match = re.search(r'<title>(.*?)</title>', content, re.IGNORECASE)
            if match:
                return f"Page: {match.group(1).strip()}"

        # Markdown Header
        if ext == '.md':
            match = re.search(r'^#\s+(.*)', content)
            if match:
                return f"Doc: {match.group(1).strip()}"

        # 3. Fallback Heuristics for Config/Scripts
        try:
            if filename == 'requirements.txt':
                lines = [l.strip() for l in content.splitlines() if l.strip() and not l.startswith('#')]
                if len(lines) > 3:
                     return f"[SYSTEM] Neural Evidence NARRATIVE: 12 core dependencies detected including {', '.join(lines[:3])}..."
                return f"[SYSTEM] Dependency Manifest NARRATIVE: {', '.join(lines)}"
                
            if filename == 'package.json':
                import json
                try:
                    pkg = json.loads(content)
                    deps = list(pkg.get('dependencies', {}).keys())
                    if deps:
                        return f"[SYSTEM] Sovereign Manifest NARRATIVE: Node Configuration for {pkg.get('name', 'Project')}. Deps: {', '.join(deps[:3])}"
                    return f"[SYSTEM] Node Config NARRATIVE: {pkg.get('name', 'Project')}"
                except Exception as e:
                    sys.stderr.write(f"[*] Heuristic Parse restricted for {filename}: {e}\n")

            if ext in ['.bat', '.sh']:
                # Extract first non-comment echo that isn't just "off" or "on"
                # Find all echos
                echos = re.findall(r'echo\s+(.*)', content, re.IGNORECASE)
                for e in echos:
                    clean = e.strip().strip('"').strip("'")
                    if clean.lower() not in ['off', 'on', '']:
                        return f"[LOGIC] Tactical Script NARRATIVE: {clean}"

            if ext == '.json':
                # Generic JSON summary
                return f"[SYSTEM] Secure Artifact NARRATIVE: Configuration data."
        except Exception as e:
            logger.debug(f"Smart summary generation failed for {filename}: {e}")
            pass

        return f"[SYSTEM] Sovereign Sync NARRATIVE: {filename}"

    tx = TransactionMemory(cloud_callback)
    handler = CodeChangeHandler(tx)
    
    EXTENSION_MAP = {
        '.md': 'document',
        '.txt': 'document',
        '.json': 'artifact',
        '.yaml': 'artifact',
        '.yml': 'artifact',
        '.py': 'code',
        '.js': 'code',
        '.ts': 'code',
        '.html': 'code',
        '.css': 'code',
        '.sh': 'code',
        '.bat': 'code',
        '.ps1': 'code'
    }

    count = 0
    synapse_count = 0
    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if d not in IGNORE_LIST and not d.startswith('.')]
        for file in files:
            if any(x in file for x in IGNORE_LIST) or file.startswith('.'): continue
            path = os.path.relpath(os.path.join(root, file), ".").replace("\\", "/")
            ext = os.path.splitext(file)[1].lower()
            atom_type = EXTENSION_MAP.get(ext, 'code')

            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                # Zero-Trust Deduplication: Check if content changed since last sync
                # We blend the secret into the hash so if the key changes, we force a re-upload!
                content_hash_input = content + (DX_TEAM_SECRET or "")
                curr_hash = hashlib.sha256(content_hash_input.encode()).hexdigest()
                
                # Check for FORCE flag or changed content
                force_sync = (args and hasattr(args, 'extra') and args.extra == "force")
                
                if not force_sync and handler.last_hashes.get(path) == curr_hash:
                    continue

                entropy = SovereignEntropyEngine.calculate(content, path)
                synapses = handler.extract_synapses(content, os.path.basename(path), PROJECT_CATALOG)
                symbols = handler.extract_symbols(content, path)
                synapse_count += len(synapses)
                
                # Direct upload for sync mode
                smart_summary = generate_smart_summary(content, os.path.basename(path))
                
                # Generate stable UUID for source_id based on file path to avoid duplicates on re-sync
                import uuid
                source_id_seed = f"{os.getenv('DX_PROJECT_ID') or 'NONE'}:{path}"
                source_id = str(uuid.uuid5(uuid.NAMESPACE_URL, source_id_seed))

                payload = {
                    "content": content[:10000], 
                    "entropy_score": round(entropy, 2),
                    "atom_type": "evolution_event",
                    "source": "api",
                    "file_path": path, # Universal forward slashes
                    "file_name": os.path.basename(path),
                    "source_id": source_id,
                    "content_hash": curr_hash,
                    "synapses": synapses,
                    "symbols": symbols,
                    "is_sovereign": DX_SOVEREIGN,
                    "request_server_encryption": DX_SOVEREIGN, 
                    "is_encrypted": False, 
                    "project_id": os.getenv("DX_PROJECT_ID"), 
                    "project_name": os.getenv("DX_PROJECT_NAME") or "Default", 
                    "metadata": {
                        "file_path": path,
                        "file_name": os.path.basename(path),
                        "summary": smart_summary,
                        "synapses": synapses,
                        "content_hash": curr_hash,
                        "force": force_sync
                    }
                }
                
 
                api_res = cloud_callback(payload)
                if api_res:
                    handler.last_hashes[path] = curr_hash
                    handler.content_cache[path] = content
                    count += 1
                    
                    status = api_res.get("status")
                    if status == "skipped":
                        print(f"[-] Unchanged: {path}")
                    else:
                        print(f"[+] Indexed {atom_type}: {path} ({len(synapses)} synapses)")
                else:
                    print(f"[!] Failed: {path}")
                    
            except Exception as e:
                print(f"[!] Error syncing {path}: {e}")
                
    handler.save_hashes()
    if is_seal and count == 0:
        print("\n[!] No modifications detected since last sync. (Nothing to seal)")
    else:
        print(f"\n[+] Sync Complete! {count} artifacts analyzed. {synapse_count} synapses mapped.")

def dx_tail():
    global DX_API_KEY
    print("\033[95m[*] Dalexor Intelligence Stream Active...\033[0m")
    print("(Press Ctrl+C to disconnect)")
    
    import requests
    import json
    
    headers = {"X-DX-Key": DX_API_KEY}
    try:
        # Connect to the Global Brain's SSE Tail endpoint
        response = requests.get(f"{CLOUD_URL}/tail", headers=headers, stream=True, timeout=None)
        
        if response.status_code != 200:
            print(f"[!] Connection Refused: {response.status_code} - {response.text}")
            return

        for line in response.iter_lines():
            if line:
                decoded_line = line.decode('utf-8')
                if decoded_line.startswith('data: '):
                    try:
                        event = json.loads(decoded_line[6:])
                        e_type = event.get('type')
                        e_data = event.get('data', {})
                        # Format timestamp (e.g. 14:20:05)
                        ts = event.get('timestamp', '')[11:19] if event.get('timestamp') else "??:??:??"
                        
                        if e_type == 'presence':
                            print(f"[\033[90m{ts}\033[0m] ⚡ \033[94mPRESENCE\033[0m: {e_data.get('user')} is touching \033[1m{e_data.get('file')}\033[0m")
                        elif e_type == 'evolution':
                            print(f"[\033[90m{ts}\033[0m] 🧬 \033[92mEVOLUTION\033[0m: {e_data.get('user')} synced \033[1m{e_data.get('file')}\033[0m (Ω: {e_data.get('entropy')})")
                            print(f"    └─ \033[90m{e_data.get('insight')}\033[0m")
                        elif e_type == 'system':
                            print(f"[\033[90m{ts}\033[0m] 🛰️ \033[93mSYSTEM\033[0m: {event.get('message')}")
                    except Exception as parse_err:
                        pass # Ignore malformed stream chunks
    except KeyboardInterrupt:
        print("\n[*] Intelligence Stream Disconnected.")
    except Exception as e:
        print(f"[!] Stream Error: {e}")


def dx_chat():
    global DX_API_KEY
    print("Ask anything about your project's memory.")
    print("Type 'exit' to quit.")
    print("="*60 + "\n")

    import requests

    def read_local_file(rel_path, cwd, max_chars=5000):
        """Read a file from disk using a relative path (forward-slash safe on all OS)."""
        # Normalize slashes cross-platform
        safe_path = os.path.join(cwd, *rel_path.split('/'))
        try:
            with open(safe_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read(max_chars)
        except (FileNotFoundError, PermissionError, IsADirectoryError):
            return None

    while True:
        try:
            p = input("[>] You: ").strip()
            if not p:
                continue
            if p.lower() in ['exit', 'quit', 'bye']:
                break

            headers = {"X-DX-Key": DX_API_KEY}
            project_id = os.getenv("DX_PROJECT_ID")
            cwd = os.getcwd()

            # --- PHASE 1: Cloud retrieval — find which files are relevant ---
            try:
                res1 = requests.post(
                    f"{CLOUD_URL}/query",
                    json={"query": p, "project_id": project_id},
                    headers=headers,
                    timeout=60
                )
            except requests.exceptions.Timeout:
                print("[!] Query timed out. Try again.\n")
                continue

            if res1.status_code == 401:
                print("[!] Error (401): Unauthorized. Your API Key might be invalid.\n")
                DX_API_KEY, _, _ = interactive_verification()
                continue
            if res1.status_code != 200:
                print(f"[!] Brain Error ({res1.status_code}): {res1.text}\n")
                continue

            data1 = res1.json()
            intel = data1.get("intelligence", {})
            signals = intel.get("signals", [])
            neighbors = intel.get("synaptic_neighborhood", [])
            all_sources = signals + neighbors

            # --- PHASE 2: Read actual local file content for top signals ---
            file_contexts = []
            for src in all_sources[:6]:  # Top 6 sources to stay within cloud token limits
                path = src.get("path", "")
                if not path:
                    continue
                raw = read_local_file(path, cwd)
                if raw:
                    file_contexts.append(f"=== FILE: {path} ===\n{raw}")

            if file_contexts:
                # Re-query cloud with actual file content embedded.
                # The cloud LLM answers from this real content — no hallucination possible.
                embedded_content = "\n\n".join(file_contexts)
                grounded_query = (
                    f"[ACTUAL FILE CONTENTS FROM PROJECT — USE ONLY THIS, DO NOT GUESS]\n"
                    f"{embedded_content}\n\n"
                    f"[QUESTION] {p}\n\n"
                    f"Answer strictly and only from the file contents above. "
                    f"If the answer is not present, say so clearly."
                )
                try:
                    res2 = requests.post(
                        f"{CLOUD_URL}/query",
                        json={"query": grounded_query, "project_id": project_id},
                        headers=headers,
                        timeout=60
                    )
                    if res2.status_code == 200:
                        answer = res2.json().get("context", "")
                        if answer:
                            print(f"[*] Brain: {answer}\n")
                        else:
                            print(f"[*] Brain: {data1.get('context', '...')}\n")
                    else:
                        # Phase 2 failed — fall back to phase 1 answer
                        print(f"[*] Brain: {data1.get('context', '...')}\n")
                except requests.exceptions.Timeout:
                    print(f"[*] Brain: {data1.get('context', '...')}\n")
            else:
                # No local files found — show original cloud answer
                print(f"[*] Brain: {data1.get('context', '...')}\n")

            # Show sources (file paths only, no verbose summaries)
            if all_sources:
                print("-" * 60)
                print(f"[*] Sources ({len(signals)} signals, {len(neighbors)} neural neighbors):")
                for s in signals:
                    print(f"  [SIGNAL] {s['path']}")
                for n in neighbors:
                    print(f"  [NEURAL] {n['path']}")
                print("-" * 60 + "\n")

        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"[!] Connection Error: {e}\n")
            break


def run_agent():
    global DX_API_KEY
    import sys
    # Universal Case-Insensitivity fix
    if len(sys.argv) > 1:
        valid_cmds = ["init", "watch", "chat", "tail", "sync", "mcp"]
        if sys.argv[1].lower() in valid_cmds:
            sys.argv[1] = sys.argv[1].lower()

    parser = argparse.ArgumentParser(description="Dalexor MI Sovereign CLI")
    parser.add_argument("command", choices=["init", "watch", "chat", "tail", "sync", "mcp"], nargs="?", default="init")
    parser.add_argument("extra", nargs="?") # For file paths or messages
    args = parser.parse_args()

    # MCP MODE: Skip all interactive prompts and stdout printing
    # MCP uses stdio for JSON-RPC, so any print() will corrupt the protocol
    if args.command == "mcp":
        # Load local .env just in case we are running in a project dir
        try:
            from dotenv import load_dotenv
            load_dotenv()
        except Exception as e:
            sys.stderr.write(f"[Dalexor MCP] Warning: Failed to load local .env: {e}\n")
            pass

        # Get API key (Env > Global Config)
        DX_API_KEY = os.getenv("DX_API_KEY") or os.getenv("DALEXORMI_API_KEY") or GLOBAL_CONFIG.get("api_key")
        
        project_id = os.getenv("DX_PROJECT_ID") or GLOBAL_CONFIG.get("project_id")
        if project_id:
             sys.stderr.write(f"[Dalexor MCP] Active Project ID: {project_id}\n")
        else:
             sys.stderr.write(f"[Dalexor MCP] No Project ID found in environment or config. Defaulting to Organization Scope.\n")
        
        if not DX_API_KEY:
             sys.stderr.write(f"[Dalexor MCP] CRITICAL: No API Key found. Run 'dx init' or set DX_API_KEY.\n")
             sys.exit(1)
        
        import traceback
        try:
            if isinstance(mcp, DummyMCP):
                sys.stderr.write("[Dalexor MCP] CRITICAL: MCP server is in dummy state. Check dependencies.\n")
                sys.exit(1)
            
            sys.stderr.write(f"[Dalexor MCP] Handshake complete. Starting JSON-RPC server...\n")
            sys.stderr.flush()
            mcp.run(transport='stdio')
        except Exception as e:
            sys.stderr.write(f"[Dalexor MCP CRITICAL ERROR] {e}\n")
            sys.stderr.write(traceback.format_exc())
            sys.stderr.flush()
            sys.exit(1)
        return

    # Step 1: Handle Initialization separately (forces prompt)
    if args.command == "init": 
        dx_init()
        return

    # Step 2: Ensure Auth & Get Plan (for non-init commands)
    # Returns (key, email, plan_display_string)
    key_tuple = interactive_verification()
    
    # For other commands, we have the key now.
    if not key_tuple or not key_tuple[0]:
        print("[!] Error: Valid API Key required.")
        sys.exit(1)
        
    DX_API_KEY = key_tuple[0]
    
    # Print Banner for EVERY command (except MCP)
    print_banner(key_tuple[1], key_tuple[2]) # email, plan

    if args.command == "chat": dx_chat(); return
    if args.command == "tail": dx_tail(); return
    # Pass args to dx_sync implicitly by making it global or passing it (easier to use global args in this structure)
    if args.command == "sync": dx_sync(args); return

    # Watchdog & Sentinel
    def push_to_cloud(payload):
        import requests
        try:
            summary = payload.get('metadata', {}).get('summary', 'Evolution')
            
            # Inject Project Metadata
            project_id = os.getenv("DX_PROJECT_ID")
            if not project_id:
                print(f"[!] Critical Alert: Intelligence push aborted. No project context active. Run 'dx init'.")
                return

            payload["project_id"] = project_id
            payload["project_name"] = os.getenv("DX_PROJECT_NAME") or "Unnamed Project"
            payload["is_sovereign"] = DX_SOVEREIGN
            
            # 🔐 Preserve is_encrypted flag if already set (e.g., by dx seal)
            # Don't overwrite it - the content is already encrypted
            if "is_encrypted" not in payload:
                payload["is_encrypted"] = False
            
            print(f"[*] Uploading '{summary}' to Project '{payload['project_name']}'...")
            res = requests.post(f"{CLOUD_URL}/ingest", json=payload, headers={"X-DX-Key": DX_API_KEY}, timeout=60)
            if res.status_code == 200:
                print(f"[+] Synced: {res.json().get('ai_insight', 'Indexed')}")
            elif res.status_code == 429:
                print(f"[!] Rate Limit Exceeded: Your plan is currently throttled. Upgrade to Sovereign for near-unlimited velocity.")
            elif res.status_code == 402:
                print(f"[!] Quota Full: You have reached your Intelligence Atom limit. Please upgrade or manage your atoms at 'dalexor.com'")
            else:
                print(f"[!] Handshake Refused: {res.status_code} - {res.text}")
        except Exception as e: 
            print(f"[!] Transmission Error: {e}")

    tx = TransactionMemory(push_to_cloud)
    handler = CodeChangeHandler(tx)
    handler.warm_up(".")
    observer = Observer()
    observer.schedule(handler, ".", recursive=True)
    observer.start()

    if args.command == "watch":
        print(f"[*] Telescope Sentinel Active in {os.getcwd()}. Press Ctrl+C to stop.")
        print("\n" + "-"*60)
        print(" MANUAL TRIGGER: THE 'S' KEY")
        print("-"*60)
        print(" While dx watch is running, you have a 'tactical trigger':")
        print("\n [Press S] (or k): Immediately flush all pending changes and")
        print(" tag them with Maximum Entropy (10.0), signaling a milestone.")
        print("\n [Bypass Coalescence]: A manual seal bypasses the 20-minute")
        print(" window, forcing the creation of a fresh, stable version.")
        print("-"*60 + "\n")
        
        # Keyboard Listener for sealing milestones
        def kbd_loop():
            try:
                if os.name == 'nt':
                    import msvcrt
                    while True:
                        if msvcrt.kbhit():
                            ch = msvcrt.getch().decode('utf-8').lower()
                            if ch in ['s', 'k', '\x10']: # S, K, or Ctrl+P (approx)
                                tx.flush_all()
                        time.sleep(0.1)
                else:
                    import select
                    import termios
                    import tty
                    def getch():
                        fd = sys.stdin.fileno()
                        old_settings = termios.tcgetattr(fd)
                        try:
                            tty.setraw(sys.stdin.fileno())
                            ch = sys.stdin.read(1)
                        finally:
                            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                        return ch
                    while True:
                        if select.select([sys.stdin], [], [], 0.1)[0]:
                            ch = getch().lower()
                            if ch in ['s', 'k', '\x10']:
                                tx.flush_all()
                        time.sleep(0.1)
            except Exception as e:
                print(f"[!] Keyboard Sentinel Activation Error: {e}")

        if sys.stdin.isatty():
            threading.Thread(target=kbd_loop, daemon=True).start()

        try:
            while True: time.sleep(1)
        except Exception as e: 
            print(f"[*] Watcher Stopped: {e}")
            observer.stop()


if __name__ == "__main__":
    run_agent()

