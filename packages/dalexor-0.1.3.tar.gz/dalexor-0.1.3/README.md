# Dalexor CLI (Sovereign Agent) 🧠

Install the local agent to monitor your project and sync with the Global Brain. Dalexor provides zero-knowledge code intelligence and synaptic mapping for professional developers.

## 🚀 Installation

```bash
pip install dalexor
```

## 🛠️ Setup

```bash
dalexor init
```

## 📖 Available Commands

| Command | Description |
| :--- | :--- |
| **`dalexor init`** | Configure your API Key and select your project universe. |
| **`dx watch`** | Real-time monitoring of file changes with immediate neural sync. |
| **`dx sync`** | Deep analysis of all project files and global synaptic mapping. |
| **`dx chat`** | Interactive CLI chat with your project's neural memory. |
| **`dx tail`** | Live intelligence stream of incoming project signals (**Shannon Stream**). |
| **`dx mcp`** | Start the Model Context Protocol server for IDE integration (SSE). |

---

## ⚠️ PROPRIETARY SOFTWARE
This software is **Proprietary**. All rights are reserved by Dalexor MI. 
Unauthorized copying, modification, or redistribution of this package is strictly prohibited.

Visit [dalexor.com](https://dalexor.com) for more details.
