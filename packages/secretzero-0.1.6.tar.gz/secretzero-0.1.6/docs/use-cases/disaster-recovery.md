# Disaster Recovery

Plan for secret recovery and operational continuity.

## Guidance

- Store secrets in redundant targets
- Document recovery procedures
- Use rotation and audit logs during incidents
