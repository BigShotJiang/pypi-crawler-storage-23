# Drift Remediation

When drift is detected, remediate quickly and consistently.

## Recommended Actions

1. Investigate the source of change
2. Rotate affected secrets
3. Re-sync with `secretzero sync --force`
4. Update policies or access controls
