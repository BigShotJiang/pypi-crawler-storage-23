# Multi-Environment

SecretZero supports environment-specific configuration using profiles and
variables.

## Topics

- [Environment Setup](setup.md)
- [Variable Overrides](variables.md)
- [Best Practices](best-practices.md)
