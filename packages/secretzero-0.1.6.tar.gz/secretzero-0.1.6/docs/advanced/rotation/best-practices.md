# Rotation Best Practices

- Use short rotation periods for high-risk secrets
- Stage rotation to avoid downtime
- Keep a grace period for rolling credentials
- Audit rotation events in your lockfile
