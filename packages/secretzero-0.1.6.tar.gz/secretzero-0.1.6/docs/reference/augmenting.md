# Augmenting Secretfiles

Augmenting patterns help you extend Secretfiles with templates, variables, and
environment-specific overlays.

## Related

- [Use Case: Augmenting](../use-cases/augmenting.md)
- [Configuration Variables](../user-guide/configuration/variables.md)
