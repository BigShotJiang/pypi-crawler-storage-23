# Jenkins Credentials Example

This page highlights the Jenkins credentials example used in documentation.

## Source

The canonical example lives in the repository:

- https://github.com/zloeber/SecretZero/blob/main/examples/jenkins-credentials.yml

## Usage

```bash
curl -O https://raw.githubusercontent.com/zloeber/SecretZero/main/examples/jenkins-credentials.yml
mv jenkins-credentials.yml Secretfile.yml
secretzero sync
```
