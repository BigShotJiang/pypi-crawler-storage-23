export default {
  index: {
    display: "hidden",
  },
  introduction: "Introduction",
  "getting-started": "Getting Started",
  agent: "Agent",
  manager: "Manager",
  changelog: "Changelog",
  __: {
    type: "separator",
    title: "Resources",
  },
  llms: {
    title: "llms.txt",
    href: "/llms.txt",
  },
};
