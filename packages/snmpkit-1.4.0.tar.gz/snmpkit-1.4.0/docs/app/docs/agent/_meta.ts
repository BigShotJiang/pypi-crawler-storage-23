export default {
  index: "Overview",
  quickstart: "Quickstart",
  updater: "Updater",
  "set-handler": "SET Handler",
  traps: "Traps & Notifications",
  advanced: "Advanced",
  examples: "Examples",
  performance: "Performance",
};
