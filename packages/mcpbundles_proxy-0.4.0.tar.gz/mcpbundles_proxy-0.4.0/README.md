# mcpbundles-proxy (DEPRECATED)

> **This package is deprecated.** Use [`mcpbundles`](https://pypi.org/project/mcpbundles/) instead.

## Migration

```bash
pip uninstall mcpbundles-proxy
pip install mcpbundles
```

The new `mcpbundles` CLI includes everything from `mcpbundles-proxy` plus:

- **Full MCP Hub access** — discover and call 500+ tools from the command line
- **Interactive shell** — REPL with tab completion and live connection switching
- **Multi-connection proxy** — aggregate multiple MCP servers into one endpoint
- **AI agent integration** — generate tool manifests, serve local MCP endpoints
- **Streaming output** — progressive results for long-running operations

Proxy tunnel commands are available under `mcpbundles proxy start/stop/status`.

## Links

- **New package**: https://pypi.org/project/mcpbundles/
- **Documentation**: https://mcpbundles.com/docs/cli
- **Repository**: https://github.com/thinkchainai/mcpbundles-proxy
