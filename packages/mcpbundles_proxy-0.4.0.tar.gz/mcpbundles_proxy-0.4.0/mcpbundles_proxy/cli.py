"""Deprecated CLI shim — delegates to mcpbundles."""

import sys
import warnings

import click


@click.command(
    context_settings={"ignore_unknown_options": True, "allow_extra_args": True},
)
@click.pass_context
def cli(ctx: click.Context) -> None:
    """DEPRECATED — use 'mcpbundles' instead."""
    warnings.warn(
        "mcpbundles-proxy is deprecated. Use 'mcpbundles' instead: pip install mcpbundles",
        DeprecationWarning,
        stacklevel=2,
    )
    click.secho(
        "\n╔══════════════════════════════════════════════════════════════╗",
        fg="yellow",
    )
    click.secho(
        "║  mcpbundles-proxy is DEPRECATED                             ║",
        fg="yellow",
    )
    click.secho(
        "║                                                             ║",
        fg="yellow",
    )
    click.secho(
        "║  The new CLI is 'mcpbundles' — a full MCP client with      ║",
        fg="yellow",
    )
    click.secho(
        "║  Hub access, interactive shell, multi-connection proxy,     ║",
        fg="yellow",
    )
    click.secho(
        "║  and 500+ tool integrations.                               ║",
        fg="yellow",
    )
    click.secho(
        "║                                                             ║",
        fg="yellow",
    )
    click.secho(
        "║  Upgrade:  pip install mcpbundles                           ║",
        fg="yellow",
    )
    click.secho(
        "║  Run:      mcpbundles --help                                ║",
        fg="yellow",
    )
    click.secho(
        "╚══════════════════════════════════════════════════════════════╝\n",
        fg="yellow",
    )

    from mcpbundles.cli import cli as new_cli

    sys.argv[0] = "mcpbundles"
    ctx.invoke(new_cli)


if __name__ == "__main__":
    cli()
