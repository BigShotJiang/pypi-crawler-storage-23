"""DEPRECATED — use 'mcpbundles' instead. pip install mcpbundles"""

import warnings

warnings.warn(
    "mcpbundles-proxy is deprecated. Install 'mcpbundles' instead: pip install mcpbundles",
    DeprecationWarning,
    stacklevel=2,
)
