"""init command — interactive setup wizard for new teams.

Why an init wizard:
- Eliminates per-dev friction: runs once, writes .prlens.yml and optionally
  creates a GitHub Actions workflow so every subsequent dev just clones and runs.
- Creates the team Gist automatically so the reviewer doesn't need to know
  the GitHub API to set up shared history.
- Generates .github/workflows/prlens.yml so CI reviews are zero-config after
  `git push`.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import click
import yaml
from rich.console import Console

console = Console()

_WORKFLOW_TEMPLATE = """\
name: PR Lens Review

on:
  pull_request:
    types: [opened, synchronize, reopened]

jobs:
  review:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      pull-requests: write

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.12"

      - name: Install prlens
        run: pip install prlens[{provider}]

      - name: Run PR review
        env:
          GITHUB_TOKEN: ${{{{ secrets.GITHUB_TOKEN }}}}
          {api_key_env}: ${{{{ secrets.{api_key_env} }}}}
        run: |
          prlens review \\
            --repo ${{{{ github.repository }}}} \\
            --pr ${{{{ github.event.pull_request.number }}}} \\
            --yes
"""


@click.command("init")
@click.option("--repo", default=None, help="GitHub repository (owner/name). Auto-detected from git remote.")
def init_cmd(repo: str | None):
    """Set up prlens for your team.

    Creates .prlens.yml, optionally creates a shared GitHub Gist for team
    history, and generates a GitHub Actions workflow.
    """
    console.print("\n[bold cyan]prlens init[/bold cyan] — team setup wizard\n")

    # --- Detect repo from git remote ---
    if repo is None:
        repo = _detect_repo_from_git()
        if repo:
            console.print(f"[dim]Detected repository: {repo}[/dim]")
        else:
            repo = click.prompt("GitHub repository (owner/name)")

    # --- Choose provider ---
    provider = click.prompt(
        "AI provider",
        type=click.Choice(["anthropic", "openai"]),
        default="anthropic",
    )

    api_key_env = "ANTHROPIC_API_KEY" if provider == "anthropic" else "OPENAI_API_KEY"

    # --- Gist for team history ---
    gist_id = None
    setup_gist = click.confirm(
        "\nSet up a shared GitHub Gist for team review history? (recommended)",
        default=True,
    )
    if setup_gist:
        gist_id = _create_team_gist(repo)
        if gist_id:
            console.print(f"[green]Created team Gist: {gist_id}[/green]")
        else:
            console.print("[yellow]Gist creation skipped — add gist_id manually to .prlens.yml[/yellow]")

    # --- Write .prlens.yml ---
    config: dict = {"model": provider}
    if gist_id:
        config["store"] = "gist"
        config["gist_id"] = gist_id
    _write_config(config)
    console.print("[green]Created .prlens.yml[/green]")

    # --- GitHub Actions workflow ---
    setup_ci = click.confirm("\nGenerate .github/workflows/prlens.yml for GitHub Actions?", default=True)
    if setup_ci:
        _write_workflow(provider, api_key_env)
        console.print("[green]Created .github/workflows/prlens.yml[/green]")
        console.print(
            f"\n[yellow]Remember to add [bold]{api_key_env}[/bold] to your "
            "GitHub repository secrets (Settings → Secrets → Actions).[/yellow]"
        )

    console.print("\n[bold green]Setup complete![/bold green]")
    console.print("Run a review with: [bold]prlens review --repo {repo} --pr <number>[/bold]".format(repo=repo))


def _detect_repo_from_git() -> str | None:
    """Try to detect the GitHub repo slug from the git remote URL."""
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return None
        url = result.stdout.strip()
        # Handle both HTTPS and SSH remotes:
        # https://github.com/owner/repo.git  →  owner/repo
        # git@github.com:owner/repo.git      →  owner/repo
        if "github.com" not in url:
            return None
        slug = url.split("github.com")[-1].lstrip("/:").removesuffix(".git")
        return slug if "/" in slug else None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def _create_team_gist(repo: str) -> str | None:
    """Create a private Gist for team review history and return its ID."""
    try:
        result = subprocess.run(
            ["gh", "gist", "create", "--public=false", "--desc", f"prlens review history for {repo}"],
            capture_output=True,
            text=True,
            input='{"prlens_init": true}',
            timeout=15,
        )
        if result.returncode == 0:
            # gh gist create prints the Gist URL on stdout
            gist_url = result.stdout.strip()
            return gist_url.rstrip("/").split("/")[-1]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def _write_config(config: dict) -> None:
    """Write or update .prlens.yml, preserving any existing keys."""
    path = Path(".prlens.yml")
    existing: dict = {}
    if path.exists():
        import yaml as _yaml

        existing = _yaml.safe_load(path.read_text()) or {}
    existing.update(config)
    path.write_text(yaml.dump(existing, default_flow_style=False, sort_keys=False))


def _write_workflow(provider: str, api_key_env: str) -> None:
    """Write the GitHub Actions workflow file."""
    workflow_dir = Path(".github/workflows")
    workflow_dir.mkdir(parents=True, exist_ok=True)
    workflow_path = workflow_dir / "prlens.yml"
    workflow_path.write_text(_WORKFLOW_TEMPLATE.format(provider=provider, api_key_env=api_key_env))
