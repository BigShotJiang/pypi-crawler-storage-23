from dataclasses import dataclass, field
from typing import Optional, Tuple, List, Dict
import numpy as np

@dataclass
class Customer():
    id: int 
    x: float
    y: float
    demand: int
    @property
    def x_y(self):
        return np.array([self.x, self.y])


class CustomersList:
    def __init__(self, customers: Optional[List[Customer]] = None):
        self.customers = customers or []

    @classmethod
    def generate_random(
        cls,
        n: int,
        side: float = 100,
        demand_range: Tuple[int, int] = (1, 100),
        rng: Optional[np.random.Generator] = None,
    ):
        rng = rng or np.random.default_rng()
        xs = rng.uniform(0, side, n)
        ys = rng.uniform(0, side, n)
        demands = rng.integers(demand_range[0], demand_range[1] + 1, size=n)
        demands[0] = 0  # depot

        customers = [
            Customer(i, float(x), float(y), int(d))
            for i, (x, y, d) in enumerate(zip(xs, ys, demands))
        ]
        return cls(customers)
    def __iter__(self):
        return iter(self.customers)
    
    def __repr__(self) -> str:
        return "[" + ", ".join(str(customer) for customer in self) + "]"
    
    def get_positions(self):
        return np.array([[c.x, c.y] for c in self.customers])

    def get_demands(self):
        return np.array([c.demand for c in self.customers])

    def compute_distance_matrix(self):
        positions = self.get_positions()
        diffs = positions[:, np.newaxis, :] - positions[np.newaxis, :, :]
        self.distance_matrix = np.linalg.norm(diffs, axis=2)
        return self.distance_matrix
    

@dataclass
class VehicleRoute:
    vehicle: str                       # Vehicle identifier (e.g., "A", "B")
    customer_indices: List[int] = field(default_factory=list)  # Ordered list of customers
    cumulative_distances: Optional[np.ndarray] = field(default=None, init=False)

    def compute_cumulative_distance(self, distance_matrix: np.ndarray) -> np.ndarray:
        """
        Computes the cumulative distances along this vehicle's route
        using the provided NxN distance matrix.
        """
        if not self.customer_indices:
            self.cumulative_distances = np.array([])
            return self.cumulative_distances

        cum_dists = [0]  # start at first customer
        for prev, curr in zip(self.customer_indices[:-1], self.customer_indices[1:]):
            cum_dists.append(cum_dists[-1] + distance_matrix[prev, curr])
        
        self.cumulative_distances = np.array(cum_dists)
        return self.cumulative_distances
    
class OrderedTour:
    def __init__(self, vehicle_routes: Dict[str, VehicleRoute], distance_matrix: np.ndarray):
        self.vehicle_routes = vehicle_routes
        self.distance_matrix = distance_matrix

    def compute_ordered_visits(self) -> List[Tuple[str, int, float]]:
        """
        Returns a list of triplets:
        (vehicle_id, customer_index, cumulative_distance_global)
        Cumulative distance is summed over all vehicles progressively.
        """
        for route in self.vehicle_routes.values():
            route.compute_cumulative_distance(self.distance_matrix)

        all_visits = []
        for vehicle_id, route in self.vehicle_routes.items():
            assert route.cumulative_distances is not None
            for step_idx, (cust_idx, cum_dist) in enumerate(zip(route.customer_indices, route.cumulative_distances)):
                all_visits.append({
                    "vehicle": vehicle_id,
                    "step_idx": step_idx,
                    "customer": cust_idx,
                    "cum_vehicle": cum_dist
                })

        all_visits.sort(key=lambda x: (x["step_idx"], x["vehicle"]))

        cum_global = 0.0
        ordered_visits = []
        for visit in all_visits:
            route = self.vehicle_routes[visit["vehicle"]]
            if visit["step_idx"] == 0:
                increment = 0.0 
            else:
                prev_cust = route.customer_indices[visit["step_idx"]-1]
                curr_cust = route.customer_indices[visit["step_idx"]]
                increment = self.distance_matrix[prev_cust, curr_cust]

            cum_global += increment
            ordered_visits.append((visit["vehicle"], visit["customer"], cum_global))

        return ordered_visits

if __name__ == "__main__":
    rand_list = CustomersList.generate_random(20)
    print(rand_list)