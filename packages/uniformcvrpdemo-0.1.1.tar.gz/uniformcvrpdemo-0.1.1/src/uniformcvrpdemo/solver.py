import pulp
from data import CustomersList

def total_route_distance(routes, dist):
    """
    routes: iterable of routes, each route is a list of node indices
    dist: distance matrix
    """
    total = 0.0
    for route in routes:
        for i, j in zip(route[:-1], route[1:]):
            total += dist[i, j]
    return total

def extract_routes(x: dict, nodes: list[int], depot: int, n_vehicles: int) -> dict[int, list[int]]:
    """
    Extrait les routes de chaque véhicule depuis les variables x[i,j,k].
    Evite les boucles infinies et double-visites.
    """
    routes = {}
    visited_global = set([depot])

    for k in range(n_vehicles):
        route = [depot]
        current = depot

        # Maximum len(nodes) iterations pour éviter boucle infinie
        for _ in range(len(nodes)):
            # Cherche le prochain customer non-visité selon x[i,j,k] > 0.5
            next_nodes = [j for j in nodes if j not in visited_global and pulp.value(x.get((current,j,k), 0)) > 0.5]
            if not next_nodes:
                break
            next_node = next_nodes[0]
            route.append(next_node)
            visited_global.add(next_node)
            current = next_node

        # Retour au dépôt
        if route[-1] != depot:
            route.append(depot)

        routes[k] = route

    return routes


def solve_cvrp(customers_list, distance_matrix, vehicle_capacity, n_vehicles, time_limit):
    """
    Solve a Capacitated Vehicle Routing Problem (CVRP) as a MILP.

    Returns a dict of routes per vehicle: {vehicle_index: [customer indices in order]}.
    """
    n_customers = len(customers_list.customers)
    demands = customers_list.get_demands()
    
    # Set of nodes (0 is depot, assume depot = customer 0)
    nodes = list(range(n_customers))
    depot = 0
    
    # --- Decision variables ---
    # x[i,j,k] = 1 if vehicle k travels from i to j
    x = {}
    for i in nodes:
        for j in nodes:
            if i != j:
                for k in range(n_vehicles):
                    x[i,j,k] = pulp.LpVariable(f"x_{i}_{j}_{k}", cat='Binary')
    
    # u[i,k] = load of vehicle k after visiting i (for subtour elimination)
    u = {}
    for i in nodes:
        if i != depot:
            for k in range(n_vehicles):
                u[i,k] = pulp.LpVariable(f"u_{i}_{k}", lowBound=demands[i], upBound=vehicle_capacity, cat='Continuous')
    
    # --- Problem ---
    prob = pulp.LpProblem("CVRP", pulp.LpMinimize)
    
    # Objective: minimize total distance
    prob += pulp.lpSum(distance_matrix[i,j] * x[i,j,k] for i,j,k in x)
    
    # --- Constraints ---
    
    # 1. Each customer visited exactly once
    for j in nodes:
        if j != depot:
            prob += pulp.lpSum(x[i,j,k] for i in nodes if i != j for k in range(n_vehicles)) == 1
    
    # 2. Flow conservation for customers (in = out)
    for k in range(n_vehicles):
        for h in nodes:
            if h != depot:
                prob += (pulp.lpSum(x[i,h,k] for i in nodes if i != h) -
                         pulp.lpSum(x[h,j,k] for j in nodes if j != h)) == 0
    
    # 3. Each vehicle leaves depot at most once
    for k in range(n_vehicles):
        prob += pulp.lpSum(x[depot,j,k] for j in nodes if j != depot) <= 1
        prob += pulp.lpSum(x[i,depot,k] for i in nodes if i != depot) <= 1
    
    # 4. Subtour elimination (MTZ constraints)
    for k in range(n_vehicles):
        for i in nodes:
            for j in nodes:
                if i != j and i != depot and j != depot:
                    prob += u[i,k] - u[j,k] + vehicle_capacity * x[i,j,k] <= vehicle_capacity - demands[j]
    
    # --- Solve ---
    solver = pulp.PULP_CBC_CMD(msg=True, timeLimit=time_limit)  
    prob.solve(solver)
    
    routes = extract_routes(x, nodes, depot, n_vehicles)
    return routes

def clarke_wright(customers: CustomersList, Q: int):
    """
    Clarke & Wright savings heuristic adapted to customersList
    Depot is assumed to be customer with id = 0
    """

    dist = customers.distance_matrix
    depot = 0

    nodes = [c.id for c in customers if c.id != depot]
    demand = {c.id: c.demand for c in customers}

    # --- initial routes ---
    routes = {i: [depot, i, depot] for i in nodes}
    load = {i: demand[i] for i in nodes}

    # --- compute savings ---
    savings = []
    for i in nodes:
        for j in nodes:
            if i < j:
                s = dist[depot, i] + dist[depot, j] - dist[i, j]
                savings.append((s, i, j))

    savings.sort(reverse=True)

    # --- merge routes ---
    for _, i, j in savings:
        ri = rj = None

        for r in routes:
            if i in routes[r]:
                ri = r
            if j in routes[r]:
                rj = r

        if ri is None or rj is None or ri == rj:
            continue

        # i at end of ri, j at start of rj
        if routes[ri][-2] == i and routes[rj][1] == j:
            if load[ri] + load[rj] <= Q:
                routes[ri] = routes[ri][:-1] + routes[rj][1:]
                load[ri] += load[rj]
                del routes[rj]
                del load[rj]

    return list(routes.values())

def solve_cvrp_fixed(customers_list, distance_matrix, vehicle_capacity, n_vehicles, time_limit):
    """
    Solve a Capacitated Vehicle Routing Problem (CVRP) as a MILP.
    Forces each vehicle to start and end at depot.
    Returns a dict of routes per vehicle: {vehicle_index: [customer indices in order]}.
    """
    n_customers = len(customers_list.customers)
    demands = customers_list.get_demands()
    
    nodes = list(range(n_customers))
    depot = 0

    # --- Decision variables ---
    # x[i,j,k] = 1 if vehicle k travels from i to j
    x = {}
    for i in nodes:
        for j in nodes:
            if i != j:
                for k in range(n_vehicles):
                    x[i,j,k] = pulp.LpVariable(f"x_{i}_{j}_{k}", cat='Binary')
    
    # u[i,k] = load of vehicle k after visiting i (for MTZ subtour elimination)
    u = {}
    for i in nodes:
        for k in range(n_vehicles):
            low = demands[i]
            up = vehicle_capacity
            u[i,k] = pulp.LpVariable(f"u_{i}_{k}", lowBound=low, upBound=up, cat='Continuous')
    
    # --- Problem ---
    prob = pulp.LpProblem("CVRP_fixed", pulp.LpMinimize)
    
    # Objective: minimize total distance
    prob += pulp.lpSum(distance_matrix[i,j] * x[i,j,k] for i,j,k in x)
    
    # --- Constraints ---
    
    # 1. Each customer visited exactly once
    for j in nodes:
        if j != depot:
            prob += pulp.lpSum(x[i,j,k] for i in nodes if i != j for k in range(n_vehicles)) == 1
    
    # 2. Flow conservation for customers
    for k in range(n_vehicles):
        for h in nodes:
            if h != depot:
                prob += (pulp.lpSum(x[i,h,k] for i in nodes if i != h) -
                         pulp.lpSum(x[h,j,k] for j in nodes if j != h)) == 0
    
    # 3. Each vehicle leaves and returns to depot at most once
    for k in range(n_vehicles):
        prob += pulp.lpSum(x[depot,j,k] for j in nodes if j != depot) <= 1
        prob += pulp.lpSum(x[i,depot,k] for i in nodes if i != depot) <= 1
    
    # 4. Subtour elimination (MTZ)
    for k in range(n_vehicles):
        for i in nodes:
            for j in nodes:
                if i != j and i != depot and j != depot:
                    prob += u[i,k] - u[j,k] + vehicle_capacity * x[i,j,k] <= vehicle_capacity - demands[j]
    
    # --- Solve ---
    solver = pulp.PULP_CBC_CMD(msg=True, timeLimit=time_limit)  
    prob.solve(solver)
    
    routes = extract_routes(x, nodes, depot, n_vehicles)
    return routes


if __name__ == "__main__":
    customers = CustomersList.generate_random(10, side=20, demand_range=(1,10))
    customers.compute_distance_matrix()

    vehicle_capacity = 40
    n_vehicles = 7

    # --- MILP ---
    milp_routes = solve_cvrp(
        customers,
        customers.distance_matrix,
        vehicle_capacity,
        n_vehicles,
        time_limit = 3
    )

    # --- Clarke & Wright ---
    cw_routes = clarke_wright(customers, vehicle_capacity)

    print("MILP routes:")
    nb_milp_vehicles = 0
    for r in milp_routes.values():
        if max(r) > 0:
            nb_milp_vehicles = nb_milp_vehicles + 1
        print(r)
    milp_routes_list = list(milp_routes.values())
    milp_cost = total_route_distance(milp_routes_list, customers.distance_matrix)

    print(f"MILP total distance: {milp_cost:.2f}")
    print(f"Number of vehicles used: {nb_milp_vehicles}")

    print("\nClarke-Wright routes:")
    for r in cw_routes:
        print(r)
    cw_cost = total_route_distance(cw_routes, customers.distance_matrix)
    print(f"Clarke–Wright total distance: {cw_cost:.2f}")
    print(f"Number of vehicles used: {len(cw_routes)}")

