import matplotlib.pyplot as plt
import matplotlib.colors as colors
import matplotlib.cm as cm
from data import VehicleRoute, CustomersList
import numpy as np

SIDE = 100 

rng_customers = np.random.default_rng(42)

N_CLIENTS = 20

DEF_POINTS = rng_customers.uniform(0, SIDE, size=(N_CLIENTS, 2))

DEF_DEMANDS = rng_customers.integers(1, 101, size=N_CLIENTS)


def plot_customers_scatter(n_customers = N_CLIENTS, points = DEF_POINTS, demands = DEF_DEMANDS, vmin_demand = 1, vmax_demand = 100, side = SIDE, show= False):

    fig, ax = plt.subplots()
    norm = colors.Normalize(vmin=vmin_demand, vmax=vmax_demand)
    cmap = plt.get_cmap("RdYlGn_r")

    # Scatter plot
    sc = ax.scatter(
        points[:, 0],
        points[:, 1],
        c=demands,
        cmap=cmap,
        norm=norm
    )
    ax.grid(True)
    ax.set_xlim(0, side)
    ax.set_ylim(0, side)
    ax.set_aspect("equal")
    ax.set_title(f"{n_customers} customers in a {side}×{side} area")



    sm = cm.ScalarMappable(norm=norm, cmap=cmap)
    sm.set_array([])  # no actual data yet

    cbar = fig.colorbar(sm, ax=ax)
    cbar.set_label("Customer demand")
    if show:
        plt.show()

    return fig

def plot_vehicle_route(customers_list, vehicle_route: VehicleRoute, ax=None):
    """
    Plots a single vehicle route with points labeled as 'vehicle_letter + order'.
    """
    positions = customers_list.get_positions()
    route_indices = vehicle_route.customer_indices

    # Create axes if not provided
    if ax is None:
        fig, ax = plt.subplots()
    
    # Scatter all customers in gray for context
    ax.scatter(positions[:,0], positions[:,1], color='lightgray', zorder=1)
    
    # Positions of the customers in this route
    route_positions = positions[route_indices]

    # Plot lines connecting the route
    ax.plot(route_positions[:,0], route_positions[:,1], '-o', color='C0', zorder=2)

    # Label each point with vehicle + order
    for order, idx in enumerate(route_indices, start=1):
        x, y = positions[idx]
        label = f"{vehicle_route.vehicle}{order}"
        ax.text(x, y, label, fontsize=10, fontweight='bold',
                ha='center', va='center', color='black', zorder=3)
    
    ax.set_aspect('equal')
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_title(f"Route of vehicle {vehicle_route.vehicle}")
    plt.show()
    return 

def plot_vehicle_routes(customers_list, vehicle_routes: list[VehicleRoute], ax=None):
    """
    Plots all vehicle routes on the same figure.
    Each point is labeled as 'vehicle_letter + visit order'.
    """
    positions = customers_list.get_positions()
    
    # Create axes if not provided
    if ax is None:
        fig, ax = plt.subplots(figsize=(6,6))
    
    # Plot all customers in light gray for context
    ax.scatter(positions[:,0], positions[:,1], color='lightgray', zorder=1)
    
    # Color palette (cycle through)
    colors = plt.cm.get_cmap('tab10', len(vehicle_routes))
    
    for v_idx, route in enumerate(vehicle_routes):
        route_positions = positions[route.customer_indices]
        
        # Draw route line + markers
        ax.plot(route_positions[:,0], route_positions[:,1], '-o', color=colors(v_idx), zorder=2)
        
        # Label each customer on the route
        for order, idx in enumerate(route.customer_indices, start=1):
            x, y = positions[idx]
            label = f"{route.vehicle}{order}"
            ax.text(x, y, label, fontsize=9, fontweight='bold',
                    ha='center', va='center', color='black', zorder=3)
    
    ax.set_aspect('equal')
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_title(f"{len(vehicle_routes)} Vehicle Routes")
    ax.grid(True)
    return ax

def plot_routes_by_distance(customers_list, vehicle_routes, max_distance: float, ax=None):
    """
    Plots multiple vehicle routes progressively according to cumulative distance.
    Each vehicle progresses along its route until its cumulative distance <= max_distance.
    Points are labeled as 'vehicle_letter + visit order'.
    """
    positions = customers_list.get_positions()
    
    if ax is None:
        fig, ax = plt.subplots(figsize=(6,6))
    
    ax.clear()
    
    # Plot all customers in light gray
    ax.scatter(positions[:,0], positions[:,1], color='lightgray', zorder=1)
    
    colors = plt.cm.get_cmap('tab10', len(vehicle_routes))
    
    for v_idx, route in enumerate(vehicle_routes):
        if route.cumulative_distances is None:
            raise ValueError(f"Cumulative distances not computed for vehicle {route.vehicle}.")
        
        # Determine how many customers to show based on max_distance
        cum_dists = route.cumulative_distances
        indices_up_to_distance = np.where(cum_dists <= max_distance)[0]
        if len(indices_up_to_distance) == 0:
            continue
        
        # Select customers to plot
        last_idx = indices_up_to_distance[-1]
        route_positions = np.array([customers_list.customers[i].x_y for i in route.customer_indices[:last_idx+1]])
        
        # Plot lines and markers
        ax.plot(route_positions[:,0], route_positions[:,1], '-o', color=colors(v_idx), zorder=2)
        
        # Label only last visited customer
        last_customer_idx = route.customer_indices[last_idx]
        label = f"{route.vehicle}{last_idx+1}"
        x, y = positions[last_customer_idx]
        ax.text(x, y, label, fontsize=9, fontweight='bold',
                ha='center', va='center', color='black', zorder=3)
    
    ax.set_aspect('equal')
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_title(f"Vehicles up to cumulative distance {max_distance:.2f}")
    return ax


def plot_routes_up_to_step(customers_list, ordered_tour, T: int, ax=None):
    """
    Plots vehicle routes up to step T in an OrderedTour, counting step 0 once for all vehicles at depot.
    
    Parameters
    ----------
    customers_list : CustomersList
        Your list of Customer objects with positions.
    ordered_tour : list of tuples
        OrderedTour.compute_ordered_visits() output: [(vehicle, customer_idx, cumulative_distance), ...]
    T : int
        Step number up to which to plot the visits (0-based, step 0 = all at depot)
    ax : matplotlib.axes.Axes, optional
        Axis to plot on. Creates new if None.
    
    Returns
    -------
    fig, ax
    """
    if ax is None:
        fig, ax = plt.subplots(figsize=(6,6))
    else:
        fig = ax.figure
        ax.clear()

    positions = customers_list.get_positions()
    
    # Plot all customers in light gray
    ax.scatter(positions[:,0], positions[:,1], color='lightgray', zorder=1)

    # Step 0: all vehicles at depot
    depot = 0
    ax.scatter([positions[depot,0]], [positions[depot,1]], color='black', s=50, zorder=3)
    ax.text(positions[depot,0], positions[depot,1], "Depot", fontsize=9, fontweight='bold',
            ha='center', va='center', zorder=4)

    # Exclude depot-only steps in ordered_tour
    n_vehicles = len(set(v for v, _, _ in ordered_tour))
    if T > 0:
        visits_up_to_T = ordered_tour[n_vehicles:n_vehicles+T]
    else:
        visits_up_to_T = []

    # Track cumulative positions per vehicle
    vehicle_paths = {}
    for v, c_idx, cum_dist in visits_up_to_T:
        vehicle_paths.setdefault(v, []).append(c_idx)

    colors = plt.cm.get_cmap('tab10', len(vehicle_paths))

    for i, (v, customer_indices) in enumerate(vehicle_paths.items()):
        # include depot as starting point
        route_positions = np.array([customers_list.customers[depot].x_y] +
                                    [customers_list.customers[idx].x_y for idx in customer_indices])
        ax.plot(route_positions[:,0], route_positions[:,1], '-o', color=colors(i), zorder=2)

        # Label last visited customer
        last_idx = customer_indices[-1]
        label = f"{v}{len(customer_indices)}"
        x, y = positions[last_idx]
        ax.text(x, y, label, fontsize=9, fontweight='bold', ha='center', va='center', zorder=3)

    # Compute cumulative distance up to step T
    cum_distance_T = visits_up_to_T[-1][2] if visits_up_to_T else 0.0

    ax.set_aspect('equal')
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.grid(True)
    ax.set_title(f"Step {T} — Cumulative distance {cum_distance_T:.2f}")

    return fig, ax


if __name__ == "__main__":
    plot_customers_scatter()
    # Generate customers
    customers = CustomersList.generate_random(15, side=50)
    customers.compute_distance_matrix()

    # Define some vehicle routes
    routes = [
        VehicleRoute(vehicle="A", customer_indices=[0,3,7,1,9,0]),
        VehicleRoute(vehicle="B", customer_indices=[0,5,4,8,12,0]),
        VehicleRoute(vehicle="C", customer_indices=[0,10,11,13,14,0])
    ]

    # Precompute cumulative distances
    distances = [route.compute_cumulative_distance(customers.distance_matrix) for route in routes]
        # Animation loop
    fig, ax = plt.subplots(figsize=(6,6))

    # Maximum cumulative distance among all vehicles
    max_total_distance = max(distance[-1] for distance in distances)

    # Loop animation: gradually increase distance, then reset
    step_distance = 2.0  # distance increment per frame
    current_distance = 0.0

    while current_distance <= max_total_distance + step_distance:
        plot_routes_by_distance(customers, routes, current_distance, ax)
        plt.pause(0.5)
        current_distance += step_distance
