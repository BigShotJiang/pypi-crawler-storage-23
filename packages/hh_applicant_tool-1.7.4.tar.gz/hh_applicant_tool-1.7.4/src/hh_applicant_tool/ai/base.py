class AIError(Exception):
    pass
