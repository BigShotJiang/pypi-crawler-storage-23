"""
Business services for the core module.

This package contains pure business logic services that operate
on domain types without I/O concerns.
"""

# Services will be implemented here
