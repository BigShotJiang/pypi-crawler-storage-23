from .process import web_search
from .log import setup_logging

__all__ = [
    "web_search",
    "setup_logging",
]