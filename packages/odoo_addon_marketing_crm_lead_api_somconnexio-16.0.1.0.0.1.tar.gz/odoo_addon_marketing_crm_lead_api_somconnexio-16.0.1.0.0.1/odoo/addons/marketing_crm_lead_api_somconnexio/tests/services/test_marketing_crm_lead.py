from ...services.marketing_crm_lead import MarketingCRMLeadService

from odoo.addons.somconnexio.tests.sc_test_case import SCTestCase


class TestCRMLeadServiceRestCase(SCTestCase):
    def setUp(self):
        super().setUp()
        self.data = {
            "utm_campaign": "test campaign",
            "utm_source": "test source",
            "utm_medium": "test medium",
            "referred": "test referred",
        }
        self.marketing_web_tag = self.env.ref(
            "marketing_crm_lead_api_somconnexio.marketing_web"
        )

    def test_generate_new_marketing_info(self):
        result = MarketingCRMLeadService(self.env)._prepare_create(self.data)
        expected_campaign = (
            self.env["utm.campaign"]
            .sudo()
            .search([("name", "=", self.data["utm_campaign"])], limit=1)
        )
        expected_source_id = (
            self.env["utm.source"]
            .sudo()
            .search([("name", "=", self.data["utm_source"])], limit=1)
        ).id
        expected_medium_id = (
            self.env["utm.medium"]
            .sudo()
            .search([("name", "=", self.data["utm_medium"])], limit=1)
        ).id

        self.assertEqual(
            result,
            {
                "campaign_id": expected_campaign.id,
                "source_id": expected_source_id,
                "medium_id": expected_medium_id,
                "referred": self.data["referred"],
            },
        )
        self.assertTrue(self.marketing_web_tag in expected_campaign.tag_ids)

    def test_generate_existing_marketing_info(self):
        data_test = {
            k: f"{v}_exist" if k.startswith("utm_") else v for k, v in self.data.items()
        }
        expected_campaign_id = (
            self.env["utm.campaign"].sudo().create({"name": data_test["utm_campaign"]})
        ).id
        expected_source_id = (
            self.env["utm.source"].sudo().create({"name": data_test["utm_source"]})
        ).id
        expected_medium_id = (
            self.env["utm.medium"].sudo().create({"name": data_test["utm_medium"]})
        ).id
        result = MarketingCRMLeadService(self.env)._prepare_create(data_test)
        self.assertEqual(
            result,
            {
                "campaign_id": expected_campaign_id,
                "source_id": expected_source_id,
                "medium_id": expected_medium_id,
                "referred": data_test["referred"],
            },
        )
