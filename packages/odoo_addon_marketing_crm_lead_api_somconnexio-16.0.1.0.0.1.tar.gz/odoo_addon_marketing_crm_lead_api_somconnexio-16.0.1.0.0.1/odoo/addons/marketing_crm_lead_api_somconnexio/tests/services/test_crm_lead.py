import json
from mock import patch, Mock
from odoo.addons.base_rest_somconnexio.tests.common_service import BaseRestCaseAdmin


@patch(
    "odoo.addons.marketing_crm_lead_api_somconnexio.services.crm_lead.MarketingCRMLeadService",  # noqa
    return_value=Mock(spec=["_prepare_create"]),
)
class TestCRMLeadServiceRestCase(BaseRestCaseAdmin):
    def setUp(self):
        super().setUp()
        self.partner = self.env.ref("somconnexio.res_partner_1_demo")
        self.url = "/api/crm-lead"
        self.fiber_product = self.env.ref("somconnexio.Fibra600Mb")
        self.data = {
            "partner_id": self.partner.ref,
            "iban": "ES6621000418401234567891",
            "lead_line_ids": [
                {
                    "product_code": self.fiber_product.default_code,
                    "mobile_isp_info": {},
                    "broadband_isp_info": {
                        "type": "portability",
                        "delivery_address": {
                            "street": "123",
                            "zip_code": "08000",
                            "city": "Barcelona",
                            "country": "ES",
                            "state": "B",
                        },
                        "service_address": {
                            "street": "123",
                            "zip_code": "08000",
                            "city": "Barcelona",
                            "country": "ES",
                            "state": "B",
                        },
                        "previous_provider": 39,
                        "previous_service": "adsl",
                        "previous_owner_name": "Newus",
                        "previous_owner_first_name": "Borgo",
                        "previous_owner_vat_number": "29461336S",
                        "previous_contract_type": "contract",
                        "fiber_coverage": "fibraFTTH",
                    },
                },
            ],
            "marketing_info": {
                "utm_campaign": "test campaign",
                "utm_source": "test source",
                "utm_medium": "test medium",
                "referred": "test referred",
            },
        }

    def test_route_right_create_with_marketing_info(self, mock_marketing_crm_services):
        mock_marketing_crm_services.return_value._prepare_create.return_value = {
            "referred": "test marketing referred"
        }
        response = self.http_post(self.url, data=self.data)

        self.assertEqual(response.status_code, 200)

        mock_marketing_crm_services.return_value._prepare_create.assert_called_with(
            self.data["marketing_info"]
        )
        content = json.loads(response.content.decode("utf-8"))
        self.assertIn("id", content)

        crm_lead = self.env["crm.lead"].browse(content["id"])

        self.assertEqual(crm_lead.referred, "test marketing referred")
