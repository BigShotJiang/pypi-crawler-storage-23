S_MARKETING_INFO_CREATE = {
    "marketing_info": {
        "type": "dict",
        "schema": {
            "utm_campaign": {
                "type": "string",
            },
            "utm_source": {"type": "string"},
            "utm_medium": {"type": "string"},
            "referred": {"type": "string"},
        },
    },
}
