class MarketingCRMLeadService:
    def __init__(self, env):
        self.env = env

    def _prepare_create(self, params):
        marketing_info = {}

        # --- Handle campaign ---
        utm_campaign = params.get("utm_campaign")
        if utm_campaign:
            campaign = (
                self.env["utm.campaign"]
                .sudo()
                .search([("name", "=", utm_campaign)], limit=1)
            )
            if not campaign:
                tag_id = self.env.ref(
                    "marketing_crm_lead_api_somconnexio.marketing_web"
                ).id
                campaign = (
                    self.env["utm.campaign"]
                    .sudo()
                    .create({"name": utm_campaign, "tag_ids": [(6, 0, [tag_id])]})
                )
            marketing_info.update({"campaign_id": campaign.id})

        # --- Handle source ---
        utm_source = params.get("utm_source")
        if utm_source:
            source = (
                self.env["utm.source"]
                .sudo()
                .search([("name", "=", utm_source)], limit=1)
            )
            if not source:
                source = self.env["utm.source"].sudo().create({"name": utm_source})
            marketing_info.update({"source_id": source.id})

        # --- Handle medium ---
        utm_medium = params.get("utm_medium")
        if utm_medium:
            medium = (
                self.env["utm.medium"]
                .sudo()
                .search([("name", "=", utm_medium)], limit=1)
            )
            if not medium:
                medium = self.env["utm.medium"].sudo().create({"name": utm_medium})
            marketing_info.update({"medium_id": medium.id})

        # --- Handle medium ---
        referred = params.get("referred")
        if referred:
            marketing_info.update({"referred": referred})

        return marketing_info
