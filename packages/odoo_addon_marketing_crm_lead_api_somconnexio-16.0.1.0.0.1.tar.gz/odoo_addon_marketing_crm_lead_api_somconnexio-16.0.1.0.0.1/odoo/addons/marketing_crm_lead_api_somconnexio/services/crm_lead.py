from . import schemas
from odoo.addons.component.core import Component
from .marketing_crm_lead import MarketingCRMLeadService


class CRMLeadService(Component):
    _inherit = "crm.lead.services"

    def _prepare_create(self, params):
        parent_params = super()._prepare_create(params)
        marketing_info = params.get("marketing_info")
        marketing_params = {}

        if marketing_info:
            marketing_params = MarketingCRMLeadService(self.env)._prepare_create(
                marketing_info
            )

        return {**parent_params, **marketing_params}

    def _validator_create(self):
        create_schema = super()._validator_create()
        create_schema.update(schemas.S_MARKETING_INFO_CREATE)
        return create_schema
