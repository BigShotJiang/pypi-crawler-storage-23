{
    "name": "Marketing CRM Lead API - SomConnexio",
    "version": "16.0.1.0.0",
    "summary": """
        Create CRM Lead via API with marketing info
    """,
    "description": """
       This module provides utility to create CRM Lead via API
    with marketing info.
    """,
    "author": "Coopdevs Treball SCCL, " "Som Connexió SCCL",
    "website": "https://coopdevs.org",
    "license": "AGPL-3",
    "category": "Cooperative management",
    "depends": [
        "crm_lead_api_somconnexio",
    ],
    "data": ["data/utm_tag.xml"],
    "demo": [],
    "external_dependencies": {},
    "application": False,
    "installable": True,
}
