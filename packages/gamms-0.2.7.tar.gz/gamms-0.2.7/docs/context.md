# GAMMS Context
---

::: gamms.typing.IContext
    options:
        show_source: false
        heading_level: 4