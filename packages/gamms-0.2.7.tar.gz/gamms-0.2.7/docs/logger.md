# Logger

::: gamms.typing.ILogger
    options:
        members: true