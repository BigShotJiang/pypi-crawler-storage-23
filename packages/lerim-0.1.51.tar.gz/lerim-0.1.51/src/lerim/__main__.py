"""Allow running Lerim as ``python -m lerim``."""

from lerim.app.cli import main

main()
