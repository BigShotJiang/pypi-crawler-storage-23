from __future__ import annotations

import asyncio

import pytest

from corrode import Err, Ok
from corrode.async_iterator import (
    collect,
    filter_err,
    filter_err_unordered,
    filter_ok,
    filter_ok_unordered,
    map_collect,
    partition,
    try_reduce,
)


async def ok_after(value: int, delay: float = 0.0) -> Ok[int]:
    await asyncio.sleep(delay)
    return Ok(value)


async def err_after(value: str, delay: float = 0.0) -> Err[str]:
    await asyncio.sleep(delay)
    return Err(value)


# ---------------------------------------------------------------------------
# Basic correctness
# ---------------------------------------------------------------------------


class TestCollectBasic:
    async def test_empty(self) -> None:
        result = await collect([])
        assert result == Ok([])

    async def test_all_ok(self) -> None:
        result = await collect([ok_after(1), ok_after(2), ok_after(3)])
        assert result == Ok([1, 2, 3])

    async def test_single_ok(self) -> None:
        assert await collect([ok_after(42)]) == Ok([42])

    async def test_single_err(self) -> None:
        assert await collect([err_after("boom")]) == Err("boom")

    async def test_first_err_returned(self) -> None:
        # both fail, first to complete wins
        result = await collect([
            err_after("first", delay=0.0),
            err_after("second", delay=0.1),
        ])
        assert result == Err("first")

    async def test_err_among_oks(self) -> None:
        result = await collect([ok_after(1), err_after("bad"), ok_after(3)])
        assert result == Err("bad")


# ---------------------------------------------------------------------------
# concurrency=None (unlimited)
# ---------------------------------------------------------------------------


class TestConcurrencyUnlimited:
    async def test_all_scheduled_at_once(self) -> None:
        # all tasks have the same delay — if they run concurrently total time ~delay,
        # not N*delay
        started_at: list[float] = []

        async def tracked(v: int) -> Ok[int]:
            started_at.append(asyncio.get_event_loop().time())
            await asyncio.sleep(0.05)
            return Ok(v)

        result = await collect(
            [tracked(i) for i in range(5)],
            concurrency=None,
        )
        assert result == Ok([0, 1, 2, 3, 4])
        # all tasks started within a small window (< 0.02s)
        assert max(started_at) - min(started_at) < 0.02

    async def test_empty(self) -> None:
        assert await collect([], concurrency=None) == Ok([])

    async def test_err_cancels_pending(self) -> None:
        cancelled: list[int] = []

        async def slow_ok(v: int) -> Ok[int]:
            try:
                await asyncio.sleep(10)
                return Ok(v)
            except asyncio.CancelledError:
                cancelled.append(v)
                raise

        result = await collect(
            [err_after("boom", delay=0.0), slow_ok(1), slow_ok(2)],
            concurrency=None,
        )
        assert result == Err("boom")
        assert sorted(cancelled) == [1, 2]


# ---------------------------------------------------------------------------
# concurrency=1 (sequential)
# ---------------------------------------------------------------------------


class TestConcurrencyOne:
    async def test_all_ok(self) -> None:
        result = await collect(
            [ok_after(1), ok_after(2), ok_after(3)],
            concurrency=1,
        )
        assert result == Ok([1, 2, 3])

    async def test_runs_sequentially(self) -> None:
        order: list[int] = []

        async def tracked(v: int) -> Ok[int]:
            order.append(v)
            await asyncio.sleep(0)
            return Ok(v)

        await collect(
            [tracked(1), tracked(2), tracked(3)],
            concurrency=1,
        )
        # with concurrency=1 tasks are consumed one by one in input order
        assert order == [1, 2, 3]

    async def test_err_short_circuits(self) -> None:
        started: list[int] = []

        async def tracked_ok(v: int) -> Ok[int]:
            started.append(v)
            await asyncio.sleep(0)
            return Ok(v)

        result = await collect(
            [err_after("stop"), tracked_ok(1), tracked_ok(2)],
            concurrency=1,
        )
        assert result == Err("stop")
        # subsequent tasks were never started
        assert started == []

    async def test_empty(self) -> None:
        assert await collect([], concurrency=1) == Ok([])


# ---------------------------------------------------------------------------
# concurrency=N (sliding window)
# ---------------------------------------------------------------------------


class TestConcurrencyN:
    async def test_all_ok(self) -> None:
        result = await collect(
            [ok_after(i) for i in range(10)],
            concurrency=3,
        )
        assert result == Ok(list(range(10)))

    async def test_at_most_n_concurrent(self) -> None:
        in_flight: list[int] = []
        peak: list[int] = []

        async def tracked(v: int) -> Ok[int]:
            in_flight.append(v)
            peak.append(len(in_flight))
            await asyncio.sleep(0.02)
            in_flight.remove(v)
            return Ok(v)

        await collect(
            [tracked(i) for i in range(8)],
            concurrency=3,
        )
        assert max(peak) <= 3

    async def test_err_cancels_pending_window(self) -> None:
        cancelled: list[int] = []

        async def slow_ok(v: int) -> Ok[int]:
            try:
                await asyncio.sleep(10)
                return Ok(v)
            except asyncio.CancelledError:
                cancelled.append(v)
                raise

        result = await collect(
            [slow_ok(0), slow_ok(1), err_after("boom", delay=0.0), slow_ok(3)],
            concurrency=3,
        )
        assert result == Err("boom")
        # slow_ok(3) was never started (outside initial window of 3)
        assert 3 not in cancelled
        # slow_ok(0) and slow_ok(1) were cancelled
        assert sorted(cancelled) == [0, 1]

    async def test_concurrency_larger_than_input(self) -> None:
        result = await collect(
            [ok_after(i) for i in range(3)],
            concurrency=100,
        )
        assert result == Ok([0, 1, 2])

    async def test_empty(self) -> None:
        assert await collect([], concurrency=4) == Ok([])

    async def test_remaining_coros_not_started_after_err(self) -> None:
        # 6 coroutines, concurrency=3: first window is [0, 1, 2],
        # err fires immediately, coroutines [3, 4, 5] must never start
        started: list[int] = []

        async def slow(v: int) -> Ok[int]:
            started.append(v)
            await asyncio.sleep(10)
            return Ok(v)

        result = await collect(
            [err_after("stop"), slow(1), slow(2), slow(3), slow(4), slow(5)],
            concurrency=3,
        )
        assert result == Err("stop")
        assert all(v <= 2 for v in started)


# ---------------------------------------------------------------------------
# Order guarantee
# ---------------------------------------------------------------------------


class TestOrderGuarantee:
    async def test_order_preserved_with_different_delays(self) -> None:
        # tasks complete in reverse order but result must be in input order
        result = await collect([
            ok_after(1, delay=0.1),
            ok_after(2, delay=0.05),
            ok_after(3, delay=0.0),
        ])
        assert result == Ok([1, 2, 3])

    async def test_order_preserved_with_concurrency(self) -> None:
        result = await collect(
            [ok_after(i, delay=(9 - i) * 0.01) for i in range(10)],
            concurrency=3,
        )
        assert result == Ok(list(range(10)))

    async def test_partition_order_preserved(self) -> None:
        # interleaved ok/err with different delays
        oks, errs = await partition([
            ok_after(1, delay=0.1),
            err_after("a", delay=0.0),
            ok_after(2, delay=0.05),
            err_after("b", delay=0.08),
        ])
        assert oks == [1, 2]
        assert errs == ["a", "b"]


# ---------------------------------------------------------------------------
# Exception propagation
# ---------------------------------------------------------------------------


class TestExceptionPropagation:
    async def test_exception_escapes(self) -> None:
        async def boom() -> Ok[int]:
            raise ValueError("oops")

        with pytest.raises(ValueError, match="oops"):
            await collect([boom()])

    async def test_exception_cancels_pending(self) -> None:
        cancelled: list[int] = []

        async def slow(v: int) -> Ok[int]:
            try:
                await asyncio.sleep(10)
                return Ok(v)
            except asyncio.CancelledError:
                cancelled.append(v)
                raise

        async def boom() -> Ok[int]:
            raise RuntimeError("boom")

        with pytest.raises(RuntimeError):
            await collect([slow(1), slow(2), boom()])

        assert sorted(cancelled) == [1, 2]

    async def test_exception_closes_unconsumed_coros(self) -> None:
        started: list[int] = []

        async def boom() -> Ok[int]:
            raise RuntimeError

        async def never(v: int) -> Ok[int]:
            started.append(v)
            await asyncio.sleep(10)
            return Ok(v)

        with pytest.raises(RuntimeError):
            await collect([boom(), never(1), never(2)], concurrency=1)

        # with concurrency=1, never(1) and never(2) were never scheduled
        assert started == []

    async def test_exception_not_swallowed_when_err_also_present(self) -> None:
        # if one task raises and another returns Err, the exception wins
        async def boom() -> Ok[int]:
            raise RuntimeError("exception")

        with pytest.raises(RuntimeError, match="exception"):
            await collect([boom(), boom()], concurrency=None)


# ---------------------------------------------------------------------------
# create_task inputs
# ---------------------------------------------------------------------------


class TestCreateTaskInputs:
    async def test_all_ok_with_tasks(self) -> None:
        tasks = [asyncio.create_task(ok_after(i)) for i in range(4)]
        result = await collect(tasks)
        assert result == Ok([0, 1, 2, 3])

    async def test_err_cancels_out_of_window_tasks(self) -> None:
        # tasks are already running before collect is called
        cancelled = []

        async def slow(v: int) -> Ok[int]:
            try:
                await asyncio.sleep(10)
                return Ok(v)
            except asyncio.CancelledError:
                cancelled.append(v)
                raise

        tasks = [asyncio.create_task(slow(i)) for i in range(4)]
        await asyncio.sleep(0)  # let tasks start

        result = await collect(
            [err_after("stop"), *tasks],
            concurrency=2,
        )
        await asyncio.sleep(0)  # let cancellations propagate
        assert result == Err("stop")
        # all tasks are already-running Tasks (not plain coroutines),
        # so _cancel_all must call .cancel() on them, not .close()
        assert sorted(cancelled) == [0, 1, 2, 3]
        assert all(t.done() for t in tasks)

    async def test_mixed_coros_and_tasks(self) -> None:
        task = asyncio.create_task(ok_after(1))
        result = await collect([ok_after(0), task, ok_after(2)])
        assert result == Ok([0, 1, 2])


# ---------------------------------------------------------------------------
# partition
# ---------------------------------------------------------------------------


class TestPartition:
    async def test_empty(self) -> None:
        assert await partition([]) == ([], [])

    async def test_all_ok(self) -> None:
        oks, errs = await partition([ok_after(i) for i in range(3)])
        assert oks == [0, 1, 2]
        assert errs == []

    async def test_all_err(self) -> None:
        oks, errs = await partition([err_after(str(i)) for i in range(3)])
        assert oks == []
        assert errs == ["0", "1", "2"]

    async def test_mixed(self) -> None:
        oks, errs = await partition([
            ok_after(1), err_after("a"), ok_after(2), err_after("b"),
        ])
        assert oks == [1, 2]
        assert errs == ["a", "b"]

    async def test_consumes_all_no_short_circuit(self) -> None:
        completed = []

        async def tracked(v: int) -> Ok[int]:
            await asyncio.sleep(0)
            completed.append(v)
            return Ok(v)

        await partition(
            [err_after("e"), tracked(1), tracked(2), tracked(3)],
        )
        assert sorted(completed) == [1, 2, 3]

    async def test_concurrency_none(self) -> None:
        started_at: list[float] = []

        async def tracked(v: int) -> Ok[int]:
            started_at.append(asyncio.get_event_loop().time())
            await asyncio.sleep(0.05)
            return Ok(v)

        oks, errs = await partition(
            [tracked(i) for i in range(5)],
            concurrency=None,
        )
        assert oks == list(range(5))
        assert errs == []
        assert max(started_at) - min(started_at) < 0.02

    async def test_concurrency_one(self) -> None:
        order: list[int] = []

        async def tracked(v: int) -> Ok[int]:
            order.append(v)
            await asyncio.sleep(0)
            return Ok(v)

        await partition(
            [tracked(i) for i in range(4)],
            concurrency=1,
        )
        assert order == [0, 1, 2, 3]

    async def test_concurrency_n_at_most(self) -> None:
        in_flight: list[int] = []
        peak: list[int] = []

        async def tracked(v: int) -> Ok[int]:
            in_flight.append(v)
            peak.append(len(in_flight))
            await asyncio.sleep(0.02)
            in_flight.remove(v)
            return Ok(v)

        await partition(
            [tracked(i) for i in range(8)],
            concurrency=3,
        )
        assert max(peak) <= 3

    async def test_with_tasks(self) -> None:
        tasks = [asyncio.create_task(ok_after(i)) for i in range(3)]
        oks, errs = await partition(tasks)
        assert oks == [0, 1, 2]
        assert errs == []

    async def test_exception_propagates(self) -> None:
        async def boom() -> Ok[int]:
            raise RuntimeError("oops")

        with pytest.raises(RuntimeError, match="oops"):
            await partition([boom(), ok_after(1)])

    async def test_exception_cancels_pending(self) -> None:
        cancelled: list[int] = []

        async def slow(v: int) -> Ok[int]:
            try:
                await asyncio.sleep(10)
                return Ok(v)
            except asyncio.CancelledError:
                cancelled.append(v)
                raise

        async def boom() -> Ok[int]:
            raise RuntimeError("boom")

        with pytest.raises(RuntimeError):
            await partition([slow(1), slow(2), boom()])

        assert sorted(cancelled) == [1, 2]

    async def test_exception_drains_multiple_done(self) -> None:
        # two tasks finish simultaneously — if one raises, the other's
        # exception must be marked as retrieved to avoid warnings
        async def boom() -> Ok[int]:
            raise RuntimeError("boom")

        with pytest.raises(RuntimeError):
            await partition([boom(), boom()], concurrency=None)

    async def test_exception_closes_unconsumed_coros(self) -> None:
        started: list[int] = []

        async def boom() -> Ok[int]:
            raise RuntimeError

        async def never(v: int) -> Ok[int]:
            started.append(v)
            await asyncio.sleep(10)
            return Ok(v)

        with pytest.raises(RuntimeError):
            await partition([boom(), never(1), never(2)], concurrency=1)

        assert started == []


# ---------------------------------------------------------------------------
# map_collect
# ---------------------------------------------------------------------------


class TestMapCollect:
    async def test_all_ok(self) -> None:
        async def double(x: int) -> Ok[int]:
            await asyncio.sleep(0)
            return Ok(x * 2)

        result = await map_collect(range(4), double)
        assert result == Ok([0, 2, 4, 6])

    async def test_empty(self) -> None:
        async def double(x: int) -> Ok[int]:
            return Ok(x * 2)

        assert await map_collect([], double) == Ok([])

    async def test_first_err_short_circuits(self) -> None:
        called: list[int] = []

        async def maybe_fail(x: int) -> Ok[int] | Err[str]:
            called.append(x)
            await asyncio.sleep(0.01 * x)
            if x == 0:
                return Err("zero")
            return Ok(x)

        result = await map_collect(range(4), maybe_fail, concurrency=1)
        assert result == Err("zero")
        assert called == [0]

    async def test_concurrency_respected(self) -> None:
        in_flight: list[int] = []
        peak: list[int] = []

        async def tracked(x: int) -> Ok[int]:
            in_flight.append(x)
            peak.append(len(in_flight))
            await asyncio.sleep(0.02)
            in_flight.remove(x)
            return Ok(x)

        await map_collect(range(8), tracked, concurrency=3)
        assert max(peak) <= 3

    async def test_exception_propagates(self) -> None:
        async def boom(_x: int) -> Ok[int]:
            raise RuntimeError("oops")

        with pytest.raises(RuntimeError, match="oops"):
            await map_collect([1, 2, 3], boom)

    async def test_order_preserved(self) -> None:
        async def fetch(x: int) -> Ok[int]:
            await asyncio.sleep((10 - x) * 0.01)
            return Ok(x * 10)

        result = await map_collect(range(5), fetch)
        assert result == Ok([0, 10, 20, 30, 40])


# ---------------------------------------------------------------------------
# filter_ok_unordered
# ---------------------------------------------------------------------------


class TestFilterOkUnordered:
    async def test_yields_ok_values(self) -> None:
        results = [
            v async for v in filter_ok_unordered([ok_after(1), err_after("x"), ok_after(2)])
        ]
        assert sorted(results) == [1, 2]

    async def test_empty(self) -> None:
        assert [v async for v in filter_ok_unordered([])] == []

    async def test_all_err_yields_nothing(self) -> None:
        assert [v async for v in filter_ok_unordered([err_after("a"), err_after("b")])] == []

    async def test_yields_as_completed(self) -> None:
        # fast completes before slow even though slow comes first in input
        order: list[int] = []
        async for v in filter_ok_unordered([ok_after(1, delay=0.1), ok_after(2, delay=0.0)]):
            order.append(v)
        assert order == [2, 1]

    async def test_concurrency_respected(self) -> None:
        in_flight: list[int] = []
        peak: list[int] = []

        async def tracked(v: int) -> Ok[int]:
            in_flight.append(v)
            peak.append(len(in_flight))
            await asyncio.sleep(0.02)
            in_flight.remove(v)
            return Ok(v)

        async for _ in filter_ok_unordered([tracked(i) for i in range(8)], concurrency=3):
            pass
        assert max(peak) <= 3

    async def test_exception_propagates(self) -> None:
        async def boom() -> Ok[int]:
            raise RuntimeError("oops")

        with pytest.raises(RuntimeError, match="oops"):
            async for _ in filter_ok_unordered([boom(), ok_after(1)]):
                pass


# ---------------------------------------------------------------------------
# filter_err_unordered
# ---------------------------------------------------------------------------


class TestFilterErrUnordered:
    async def test_yields_err_values(self) -> None:
        results = [
            e async for e in filter_err_unordered([ok_after(1), err_after("x"), err_after("y")])
        ]
        assert sorted(results) == ["x", "y"]

    async def test_empty(self) -> None:
        assert [e async for e in filter_err_unordered([])] == []

    async def test_all_ok_yields_nothing(self) -> None:
        assert [e async for e in filter_err_unordered([ok_after(1), ok_after(2)])] == []

    async def test_yields_as_completed(self) -> None:
        order: list[str] = []
        async for e in filter_err_unordered(
            [err_after("slow", delay=0.1), err_after("fast", delay=0.0)],
        ):
            order.append(e)
        assert order == ["fast", "slow"]

    async def test_concurrency_respected(self) -> None:
        in_flight: list[int] = []
        peak: list[int] = []

        async def tracked(v: int) -> Err[int]:
            in_flight.append(v)
            peak.append(len(in_flight))
            await asyncio.sleep(0.02)
            in_flight.remove(v)
            return Err(v)

        async for _ in filter_err_unordered([tracked(i) for i in range(8)], concurrency=3):
            pass
        assert max(peak) <= 3

    async def test_exception_propagates(self) -> None:
        async def boom() -> Err[str]:
            raise RuntimeError("oops")

        with pytest.raises(RuntimeError, match="oops"):
            async for _ in filter_err_unordered([boom(), err_after("x")]):
                pass


# ---------------------------------------------------------------------------
# filter_ok (ordered)
# ---------------------------------------------------------------------------


class TestFilterOk:
    async def test_yields_ok_values(self) -> None:
        results = [v async for v in filter_ok(
            [ok_after(1), err_after("x"), ok_after(2)], concurrency=4,
        )]
        assert results == [1, 2]

    async def test_empty(self) -> None:
        assert [v async for v in filter_ok([], concurrency=4)] == []

    async def test_all_err_yields_nothing(self) -> None:
        assert [v async for v in filter_ok(
            [err_after("a"), err_after("b")], concurrency=4,
        )] == []

    async def test_order_preserved(self) -> None:
        # fast completes before slow, but output must follow input order
        order: list[int] = []
        async for v in filter_ok(
            [ok_after(1, delay=0.1), ok_after(2, delay=0.0)], concurrency=4,
        ):
            order.append(v)
        assert order == [1, 2]

    async def test_err_skipped_in_order(self) -> None:
        results = [v async for v in filter_ok(
            [ok_after(1), err_after("x"), ok_after(3)], concurrency=4,
        )]
        assert results == [1, 3]

    async def test_concurrency_respected(self) -> None:
        in_flight: list[int] = []
        peak: list[int] = []

        async def tracked(v: int) -> Ok[int]:
            in_flight.append(v)
            peak.append(len(in_flight))
            await asyncio.sleep(0.02)
            in_flight.remove(v)
            return Ok(v)

        async for _ in filter_ok([tracked(i) for i in range(8)], concurrency=3):
            pass
        assert max(peak) <= 3

    async def test_exception_propagates(self) -> None:
        async def boom() -> Ok[int]:
            raise RuntimeError("oops")

        with pytest.raises(RuntimeError, match="oops"):
            async for _ in filter_ok([boom(), ok_after(1)], concurrency=4):
                pass

    async def test_concurrency_one_sequential(self) -> None:
        order: list[int] = []

        async def tracked(v: int) -> Ok[int]:
            order.append(v)
            await asyncio.sleep(0)
            return Ok(v)

        async for _ in filter_ok([tracked(i) for i in range(4)], concurrency=1):
            pass
        assert order == [0, 1, 2, 3]


# ---------------------------------------------------------------------------
# filter_err (ordered)
# ---------------------------------------------------------------------------


class TestFilterErr:
    async def test_yields_err_values(self) -> None:
        results = [e async for e in filter_err(
            [ok_after(1), err_after("x"), err_after("y")], concurrency=4,
        )]
        assert results == ["x", "y"]

    async def test_empty(self) -> None:
        assert [e async for e in filter_err([], concurrency=4)] == []

    async def test_all_ok_yields_nothing(self) -> None:
        assert [e async for e in filter_err(
            [ok_after(1), ok_after(2)], concurrency=4,
        )] == []

    async def test_order_preserved(self) -> None:
        order: list[str] = []
        async for e in filter_err(
            [err_after("slow", delay=0.1), err_after("fast", delay=0.0)], concurrency=4,
        ):
            order.append(e)
        assert order == ["slow", "fast"]

    async def test_ok_skipped_in_order(self) -> None:
        results = [e async for e in filter_err(
            [err_after("a"), ok_after(1), err_after("b")], concurrency=4,
        )]
        assert results == ["a", "b"]

    async def test_concurrency_respected(self) -> None:
        in_flight: list[int] = []
        peak: list[int] = []

        async def tracked(v: int) -> Err[int]:
            in_flight.append(v)
            peak.append(len(in_flight))
            await asyncio.sleep(0.02)
            in_flight.remove(v)
            return Err(v)

        async for _ in filter_err([tracked(i) for i in range(8)], concurrency=3):
            pass
        assert max(peak) <= 3

    async def test_exception_propagates(self) -> None:
        async def boom() -> Err[str]:
            raise RuntimeError("oops")

        with pytest.raises(RuntimeError, match="oops"):
            async for _ in filter_err([boom(), err_after("x")], concurrency=4):
                pass


# ---------------------------------------------------------------------------
# try_reduce
# ---------------------------------------------------------------------------


async def int_after(value: int, delay: float = 0.0) -> int:
    await asyncio.sleep(delay)
    return value


class TestTryReduce:
    async def test_all_ok(self) -> None:
        def add(acc: int, x: int) -> Ok[int]:
            return Ok(acc + x)

        result = await try_reduce([int_after(1), int_after(2), int_after(3)], 0, add)
        assert result == Ok(6)

    async def test_empty(self) -> None:
        def add(acc: int, x: int) -> Ok[int]:
            return Ok(acc + x)

        result = await try_reduce([], 42, add)
        assert result == Ok(42)

    async def test_short_circuits_on_err(self) -> None:
        called: list[int] = []

        def maybe_fail(acc: int, x: int) -> Ok[int] | Err[str]:
            called.append(x)
            if x < 0:
                return Err(f"negative: {x}")
            return Ok(acc + x)

        result = await try_reduce(
            [int_after(1), int_after(-1), int_after(3)], 0, maybe_fail,
        )
        assert result == Err("negative: -1")
        assert called == [1, -1]

    async def test_accumulator_threads_through(self) -> None:
        def multiply(acc: int, x: int) -> Ok[int]:
            return Ok(acc * x)

        result = await try_reduce(
            [int_after(2), int_after(3), int_after(4)], 1, multiply,
        )
        assert result == Ok(24)

    async def test_exception_propagates(self) -> None:
        async def boom() -> int:
            raise RuntimeError("oops")

        def f(acc: int, x: int) -> Ok[int]:
            return Ok(acc + x)

        with pytest.raises(RuntimeError, match="oops"):
            await try_reduce([boom()], 0, f)

    async def test_sequential_execution(self) -> None:
        # try_reduce must be sequential: each item is awaited before calling f
        order: list[int] = []

        async def tracked(v: int) -> int:
            order.append(v)
            await asyncio.sleep(0)
            return v

        def f(acc: int, x: int) -> Ok[int]:
            return Ok(acc + x)

        await try_reduce([tracked(1), tracked(2), tracked(3)], 0, f)
        assert order == [1, 2, 3]
