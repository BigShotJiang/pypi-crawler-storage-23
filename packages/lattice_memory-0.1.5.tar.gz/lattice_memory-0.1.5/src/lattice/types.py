"""
Public types for Lattice SDK.

These types are re-exported via lattice.__init__ for public API stability.
"""

from dataclasses import dataclass

from lattice.core.types.enums import PatternType


@dataclass(frozen=True)
class SearchResult:
    """A search result from hybrid search.

    Attributes:
        session_id: Session ID of the matching log.
        role: Role of the message (user/assistant/tool).
        content: Content of the matching log.
        rrf_score: Reciprocal Rank Fusion score.
        timestamp: Timestamp of the log.

    >>> result = SearchResult(
    ...     session_id="ses_abc123",
    ...     role="user",
    ...     content="Fix the auth bug",
    ...     rrf_score=0.85,
    ...     timestamp="2026-01-01T00:00:00Z",
    ... )
    >>> result.session_id
    'ses_abc123'
    """

    session_id: str
    role: str
    content: str
    rrf_score: float
    timestamp: str


@dataclass(frozen=True)
class RuleProposal:
    """A rule proposal from an agent.

    Attributes:
        pattern: Pattern type (convention, bug-pattern, preference, architecture).
        observation: What was observed (max 200 chars).
        evidence: List of session IDs as evidence.
        suggested_action: Short action slug (max 100 chars).

    >>> proposal = RuleProposal(
    ...     pattern=PatternType.BUG_PATTERN,
    ...     observation="Expired JWT tokens caused auth failures",
    ...     evidence=["ses_abc123", "ses_def456"],
    ...     suggested_action="validate-jwt-expiry",
    ... )
    >>> proposal.pattern.value
    'bug-pattern'
    """

    pattern: PatternType
    observation: str
    evidence: list[str]
    suggested_action: str


__all__ = [
    "PatternType",
    "SearchResult",
    "RuleProposal",
]
