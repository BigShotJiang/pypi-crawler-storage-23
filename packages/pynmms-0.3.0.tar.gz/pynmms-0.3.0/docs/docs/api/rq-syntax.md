# RQ Syntax

::: pynmms.rq.syntax
    options:
      members:
        - RQSentence
        - parse_rq_sentence
        - is_rq_atomic
        - all_rq_atomic
        - make_concept_assertion
        - make_role_assertion
        - find_role_triggers
        - collect_individuals
        - fresh_individual
        - concept_label
        - find_blocking_individual
