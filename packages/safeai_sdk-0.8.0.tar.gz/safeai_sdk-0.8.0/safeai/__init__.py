"""SafeAI public package interface."""

from safeai.api import SafeAI

__all__ = ["SafeAI"]
