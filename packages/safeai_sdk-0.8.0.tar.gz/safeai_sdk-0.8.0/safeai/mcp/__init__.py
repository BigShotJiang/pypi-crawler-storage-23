"""SafeAI MCP server for agent-agnostic boundary enforcement."""

from __future__ import annotations
