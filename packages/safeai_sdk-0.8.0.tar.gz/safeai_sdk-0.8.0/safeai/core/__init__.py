"""Core enforcement components."""
