"""Typed containers for Gravity SDK responses."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class AdResponse:
    """A single ad returned by the Gravity API."""

    ad_text: str = ""
    title: str | None = None
    cta: str | None = None
    brand_name: str | None = None
    url: str | None = None
    favicon: str | None = None
    imp_url: str | None = None
    click_url: str | None = None
    placement: str | None = None
    placement_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AdResponse:
        return cls(
            ad_text=data.get("adText", ""),
            title=data.get("title"),
            cta=data.get("cta"),
            brand_name=data.get("brandName"),
            url=data.get("url"),
            favicon=data.get("favicon"),
            imp_url=data.get("impUrl"),
            click_url=data.get("clickUrl"),
            placement=data.get("placement"),
            placement_id=data.get("placement_id"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize back to the camelCase shape the JS SDK / renderers expect."""
        d: dict[str, Any] = {"adText": self.ad_text}
        if self.title is not None:
            d["title"] = self.title
        if self.cta is not None:
            d["cta"] = self.cta
        if self.brand_name is not None:
            d["brandName"] = self.brand_name
        if self.url is not None:
            d["url"] = self.url
        if self.favicon is not None:
            d["favicon"] = self.favicon
        if self.imp_url is not None:
            d["impUrl"] = self.imp_url
        if self.click_url is not None:
            d["clickUrl"] = self.click_url
        if self.placement is not None:
            d["placement"] = self.placement
        if self.placement_id is not None:
            d["placement_id"] = self.placement_id
        return d


@dataclass(frozen=True, slots=True)
class AdResult:
    """Result of a ``Gravity.get_ads()`` call."""

    ads: list[AdResponse] = field(default_factory=list)
    status: int = 0
    elapsed_ms: str = "0"
    request_body: dict[str, Any] | None = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "ads": [a.to_dict() for a in self.ads],
            "status": self.status,
            "elapsed": self.elapsed_ms,
            "request_body": self.request_body,
        }
        if self.error is not None:
            d["error"] = self.error
        return d
