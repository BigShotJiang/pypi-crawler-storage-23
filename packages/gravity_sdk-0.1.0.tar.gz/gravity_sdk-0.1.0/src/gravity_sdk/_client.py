"""Gravity SDK client."""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any

import httpx

from ._types import AdResponse, AdResult

logger = logging.getLogger("gravity_sdk")

DEFAULT_API_URL = "https://server.trygravity.ai/api/v1/ad"
DEFAULT_TIMEOUT_S = 3.0


def _resolve_forwarded_ip(request: Any) -> str | None:
    """Resolve the end-user's IP from forwarding headers and framework accessors."""

    headers = getattr(request, "headers", None)
    if headers is not None:
        forwarded = None
        if hasattr(headers, "get"):
            forwarded = headers.get("x-forwarded-for") or headers.get("x-real-ip")
        if forwarded:
            first = forwarded.split(",")[0].strip()
            if first:
                return first

    client = getattr(request, "client", None)
    if client and hasattr(client, "host"):
        return client.host  # type: ignore[return-value]

    meta: dict[str, str] | None = getattr(request, "META", None)
    if meta:
        forwarded = meta.get("HTTP_X_FORWARDED_FOR")
        if forwarded:
            return forwarded.split(",")[0].strip()
        remote = meta.get("REMOTE_ADDR")
        if remote:
            return remote

    remote_addr = getattr(request, "remote_addr", None)
    if remote_addr:
        return remote_addr  # type: ignore[return-value]

    return None


async def _get_request_body(request: Any) -> dict[str, Any]:
    """Extract the parsed JSON body from a framework request object."""

    json_method = getattr(request, "json", None)
    if json_method is not None and callable(json_method):
        try:
            body = json_method()
            if hasattr(body, "__await__"):
                body = await body
            return body if isinstance(body, dict) else {}
        except Exception:
            return {}

    raw_body = getattr(request, "body", None)
    if raw_body is not None:
        try:
            raw = raw_body() if callable(raw_body) else raw_body
            return json.loads(raw)
        except Exception:
            return {}

    return {}


_CONVERSATIONAL_ROLES = {"user", "assistant", "system", "developer", "model"}


def _normalize_messages(messages: list[dict[str, Any]], n: int = 2) -> list[dict[str, str]]:
    """Take the last *n* conversational messages and normalize to ``{"role", "content"}``."""
    if not messages:
        return []
    conversational = [m for m in messages if m.get("role", "user") in _CONVERSATIONAL_ROLES]
    result: list[dict[str, str]] = []
    for m in conversational[-n:]:
        role = str(m.get("role", "user"))
        content = m.get("content") or m.get("text") or m.get("message") or ""
        if isinstance(content, list):
            content = " ".join(
                part.get("text", "") for part in content if isinstance(part, dict)
            )
        result.append({"role": role, "content": str(content)})
    return result


class Gravity:
    """Async client for the Gravity API.

    Usage::

        gravity = Gravity(production=True)  # reads GRAVITY_API_KEY from env

        result = await gravity.get_ads(request, messages, placements)

    Or as an async context manager::

        async with Gravity(production=True) as gravity:
            result = await gravity.get_ads(request, messages, placements)

    Args:
        api_key:     Gravity API key. Defaults to the ``GRAVITY_API_KEY`` env var.
        api_url:     Gravity API endpoint URL.
        timeout:     Request timeout in seconds.
        production:  When ``True``, serves real ads. Defaults to ``False`` (test ads).
        relevancy:   Minimum relevancy threshold (0.0–1.0). Lower values return more
                     ads with weaker contextual matches; higher values are stricter.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_url: str = DEFAULT_API_URL,
        timeout: float = DEFAULT_TIMEOUT_S,
        production: bool = False,
        relevancy: float = 0.2,
    ) -> None:
        resolved = (api_key or os.environ.get("GRAVITY_API_KEY") or "").strip()
        if not resolved:
            logger.warning(
                "Gravity: no API key provided — set GRAVITY_API_KEY or pass api_key=. "
                "All requests will return empty results."
            )
        self._api_key = resolved
        self._api_url = api_url
        self._timeout = timeout
        self._production = production
        self._relevancy = relevancy
        self._http: httpx.AsyncClient | None = None

    @property
    def _client(self) -> httpx.AsyncClient:
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient(
                headers={
                    "Content-Type": "application/json",
                    **({"Authorization": f"Bearer {self._api_key}"} if self._api_key else {}),
                },
                timeout=self._timeout,
            )
        return self._http

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._http is not None and not self._http.is_closed:
            await self._http.aclose()
            self._http = None

    async def __aenter__(self) -> Gravity:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    async def get_ads(
        self,
        request: Any,
        messages: list[dict[str, Any]],
        placements: list[dict[str, str]],
        *,
        production: bool | None = None,
        relevancy: float | None = None,
    ) -> AdResult:
        """Request ads from the Gravity API.

        Reads the request body and headers to forward conversation context
        and resolve the end-user's IP. Runs the API call, parses the
        response, and returns typed results.

        Never raises — returns ``AdResult(ads=[])`` on any failure.

        Args:
            request:    The framework request object (FastAPI, Django, Flask, etc.).
            messages:   Conversation messages ``[{"role": ..., "content": ...}]``.
            placements: Ad placements, e.g.
                        ``[{"placement": "chat", "placement_id": "main"}]``.
            production: Override the constructor-level ``production`` flag for this call.
            relevancy:  Override the constructor-level ``relevancy`` threshold for this call.
        """
        if not self._api_key:
            return AdResult()

        use_production = production if production is not None else self._production
        use_relevancy = relevancy if relevancy is not None else self._relevancy

        body = await _get_request_body(request)
        ctx = body.get("gravity_context", {})
        client_user: dict[str, Any] = ctx.get("user", {})
        client_device: dict[str, Any] = ctx.get("device", {})
        client_ip = _resolve_forwarded_ip(request)

        user_id = client_user.get("id") or client_user.get("userId") or "anonymous"

        payload: dict[str, Any] = {
            "messages": _normalize_messages(messages),
            "sessionId": ctx.get("sessionId"),
            "placements": placements,
            "testAd": not use_production,
            "relevancy": use_relevancy,
            "user": {**client_user, "id": user_id},
            "device": {**client_device, **({"ip": client_ip} if client_ip else {})},
        }

        start = time.perf_counter()
        try:
            resp = await self._client.post(self._api_url, json=payload)
            elapsed = f"{(time.perf_counter() - start) * 1000:.0f}"

            if resp.status_code == 204:
                return AdResult(status=204, elapsed_ms=elapsed, request_body=payload)

            if resp.status_code != 200:
                error_text = resp.text
                self._log_error(resp.status_code, error_text)
                return AdResult(
                    status=resp.status_code,
                    elapsed_ms=elapsed,
                    error=error_text,
                    request_body=payload,
                )

            data = resp.json()
            raw_ads = data if isinstance(data, list) else [data]
            ads = [AdResponse.from_dict(a) for a in raw_ads]
            return AdResult(ads=ads, status=200, elapsed_ms=elapsed, request_body=payload)

        except httpx.TimeoutException:
            elapsed = f"{(time.perf_counter() - start) * 1000:.0f}"
            return AdResult(
                elapsed_ms=elapsed,
                error=f"Timeout ({self._timeout}s)",
                request_body=payload,
            )
        except Exception as exc:
            elapsed = f"{(time.perf_counter() - start) * 1000:.0f}"
            return AdResult(elapsed_ms=elapsed, error=str(exc), request_body=payload)

    @staticmethod
    def _log_error(status_code: int, error_text: str) -> None:
        if status_code in (401, 403):
            logger.warning(
                "Gravity: %d — API key is invalid, revoked, or missing. "
                "Verify your key at https://trygravity.ai",
                status_code,
            )
        elif status_code == 400:
            logger.warning("Gravity: 400 Bad Request — %s", error_text)
        elif status_code == 422:
            logger.warning(
                "Gravity: 422 Validation Error — request body is malformed. "
                "Details: %s",
                error_text,
            )
        else:
            logger.warning("Gravity: HTTP %d — %s", status_code, error_text)
