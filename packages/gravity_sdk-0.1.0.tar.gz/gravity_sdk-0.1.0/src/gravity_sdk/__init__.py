"""gravity-sdk — Python SDK for requesting ads from the Gravity API.

Usage::

    from gravity_sdk import Gravity

    gravity = Gravity()
    result = await gravity.get_ads(request, messages, placements)
"""

from ._client import Gravity
from ._types import AdResponse, AdResult
from ._version import __version__

__all__ = [
    "AdResponse",
    "AdResult",
    "Gravity",
    "__version__",
]
