"""Tests for the Gravity client."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any

import httpx
import pytest
import respx

from gravity_sdk import AdResponse, AdResult, Gravity
from gravity_sdk._client import DEFAULT_API_URL, _resolve_forwarded_ip

# ── Fake request objects ─────────────────────────────────────────


@dataclass
class FakeClient:
    host: str = "10.0.0.1"


class FakeStarletteRequest:
    def __init__(self, body: dict[str, Any], headers: dict[str, str] | None = None):
        self._body = body
        self.headers = headers or {}
        self.client = FakeClient()

    async def json(self) -> dict[str, Any]:
        return self._body


class FakeDjangoRequest:
    def __init__(self, body: dict[str, Any], meta: dict[str, str] | None = None):
        self.body = json.dumps(body).encode()
        self.META = meta or {"REMOTE_ADDR": "192.168.1.1"}


class FakeFlaskRequest:
    def __init__(self, body: dict[str, Any], remote_addr: str = "172.16.0.1"):
        self._body = body
        self.remote_addr = remote_addr

    def json(self) -> dict[str, Any]:
        return self._body


# ── Helpers ──────────────────────────────────────────────────────

PLACEMENTS = [{"placement": "chat", "placement_id": "main"}]
MESSAGES = [{"role": "user", "content": "Hello"}, {"role": "assistant", "content": "Hi!"}]
CTX_BODY = {"gravity_context": {"sessionId": "s", "user": {"id": "u"}}}

SAMPLE_AD = {
    "adText": "Try our product",
    "title": "Great Product",
    "cta": "Learn More",
    "brandName": "TestBrand",
    "url": "https://example.com",
    "impUrl": "https://example.com/imp",
    "clickUrl": "https://example.com/click",
}


# ── IP resolution ────────────────────────────────────────────────


class TestResolveForwardedIp:
    def test_x_forwarded_for(self):
        req = FakeStarletteRequest({}, headers={"x-forwarded-for": "1.2.3.4, 5.6.7.8"})
        assert _resolve_forwarded_ip(req) == "1.2.3.4"

    def test_x_real_ip(self):
        req = FakeStarletteRequest({}, headers={"x-real-ip": "9.8.7.6"})
        assert _resolve_forwarded_ip(req) == "9.8.7.6"

    def test_starlette_client_host(self):
        req = FakeStarletteRequest({})
        assert _resolve_forwarded_ip(req) == "10.0.0.1"

    def test_django_meta(self):
        req = FakeDjangoRequest({}, meta={"HTTP_X_FORWARDED_FOR": "3.3.3.3"})
        assert _resolve_forwarded_ip(req) == "3.3.3.3"

    def test_django_remote_addr(self):
        req = FakeDjangoRequest({})
        assert _resolve_forwarded_ip(req) == "192.168.1.1"

    def test_flask_remote_addr(self):
        req = FakeFlaskRequest({})
        assert _resolve_forwarded_ip(req) == "172.16.0.1"


# ── Gravity class ────────────────────────────────────────────────


class TestGravityInit:
    def test_reads_env_var(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("GRAVITY_API_KEY", "env-key-123")
        g = Gravity()
        assert g._api_key == "env-key-123"

    def test_explicit_key_overrides_env(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("GRAVITY_API_KEY", "env-key")
        g = Gravity(api_key="explicit-key")
        assert g._api_key == "explicit-key"

    def test_whitespace_key_treated_as_missing(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv("GRAVITY_API_KEY", raising=False)
        g = Gravity(api_key="   ")
        assert g._api_key == ""

    def test_custom_url_and_timeout(self):
        g = Gravity(api_key="k", api_url="https://custom.api/v1/ad", timeout=10.0)
        assert g._api_url == "https://custom.api/v1/ad"
        assert g._timeout == 10.0

    def test_defaults_to_test_mode(self):
        g = Gravity(api_key="k")
        assert g._production is False

    def test_production_flag(self):
        g = Gravity(api_key="k", production=True)
        assert g._production is True

    def test_default_relevancy(self):
        g = Gravity(api_key="k")
        assert g._relevancy == 0.2

    def test_custom_relevancy(self):
        g = Gravity(api_key="k", relevancy=0.6)
        assert g._relevancy == 0.6


class TestGravityContextManager:
    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        async with Gravity(api_key="test") as g:
            assert g._api_key == "test"
            assert g._http is None  # lazy — not created until first request

    @pytest.mark.asyncio
    async def test_close_is_idempotent(self):
        g = Gravity(api_key="test")
        await g.close()
        await g.close()  # should not raise


class TestGetAds:
    @pytest.mark.asyncio
    async def test_no_api_key_returns_empty(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv("GRAVITY_API_KEY", raising=False)
        async with Gravity() as g:
            result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert isinstance(result, AdResult)
        assert result.ads == []
        assert result.status == 0

    @respx.mock
    @pytest.mark.asyncio
    async def test_successful_ad_fetch(self):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        async with Gravity(api_key="test-key") as g:
            result = await g.get_ads(
                FakeStarletteRequest({
                    "gravity_context": {**CTX_BODY["gravity_context"], "device": {}},
                }),
                MESSAGES,
                PLACEMENTS,
            )
        assert result.status == 200
        assert len(result.ads) == 1
        assert isinstance(result.ads[0], AdResponse)
        assert result.ads[0].ad_text == "Try our product"
        assert result.ads[0].brand_name == "TestBrand"
        assert result.ads[0].click_url == "https://example.com/click"

    @respx.mock
    @pytest.mark.asyncio
    async def test_204_no_match(self):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(204))
        async with Gravity(api_key="test-key") as g:
            result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.status == 204
        assert result.ads == []

    @respx.mock
    @pytest.mark.asyncio
    async def test_api_error(self):
        respx.post(DEFAULT_API_URL).mock(
            return_value=httpx.Response(500, text="Internal Server Error")
        )
        async with Gravity(api_key="test-key") as g:
            result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.status == 500
        assert result.error == "Internal Server Error"

    @respx.mock
    @pytest.mark.asyncio
    async def test_timeout(self):
        respx.post(DEFAULT_API_URL).mock(side_effect=httpx.ReadTimeout("timed out"))
        async with Gravity(api_key="test-key") as g:
            result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.status == 0
        assert "Timeout" in (result.error or "")

    @respx.mock
    @pytest.mark.asyncio
    async def test_array_response(self):
        respx.post(DEFAULT_API_URL).mock(
            return_value=httpx.Response(200, json=[SAMPLE_AD, SAMPLE_AD])
        )
        async with Gravity(api_key="test-key") as g:
            result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert len(result.ads) == 2

    @respx.mock
    @pytest.mark.asyncio
    async def test_django_request_with_ip(self):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        async with Gravity(api_key="test-key") as g:
            result = await g.get_ads(
                FakeDjangoRequest(CTX_BODY, meta={"REMOTE_ADDR": "192.168.1.1"}),
                MESSAGES,
                PLACEMENTS,
            )
        assert result.status == 200
        assert result.request_body is not None
        assert result.request_body["device"]["ip"] == "192.168.1.1"

    @respx.mock
    @pytest.mark.asyncio
    async def test_messages_trimmed_to_last_2(self):
        long_messages = [
            {"role": "user", "content": "msg1"},
            {"role": "assistant", "content": "msg2"},
            {"role": "user", "content": "msg3"},
            {"role": "assistant", "content": "msg4"},
        ]
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        async with Gravity(api_key="test-key") as g:
            result = await g.get_ads(FakeStarletteRequest(CTX_BODY), long_messages, PLACEMENTS)
        assert result.request_body is not None
        assert len(result.request_body["messages"]) == 2
        assert result.request_body["messages"][0]["content"] == "msg3"

    @respx.mock
    @pytest.mark.asyncio
    async def test_default_sends_test_ad(self):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        async with Gravity(api_key="test-key") as g:
            result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.request_body is not None
        assert result.request_body["testAd"] is True

    @respx.mock
    @pytest.mark.asyncio
    async def test_production_sends_real_ads(self):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        async with Gravity(api_key="test-key", production=True) as g:
            result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.request_body is not None
        assert result.request_body["testAd"] is False

    @respx.mock
    @pytest.mark.asyncio
    async def test_production_override_per_call(self):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        async with Gravity(api_key="test-key") as g:
            result = await g.get_ads(
                FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS, production=True
            )
        assert result.request_body is not None
        assert result.request_body["testAd"] is False

    @respx.mock
    @pytest.mark.asyncio
    async def test_relevancy_default(self):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        async with Gravity(api_key="test-key") as g:
            result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.request_body is not None
        assert result.request_body["relevancy"] == 0.2

    @respx.mock
    @pytest.mark.asyncio
    async def test_relevancy_constructor(self):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        async with Gravity(api_key="test-key", relevancy=0.7) as g:
            result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.request_body is not None
        assert result.request_body["relevancy"] == 0.7

    @respx.mock
    @pytest.mark.asyncio
    async def test_relevancy_override_per_call(self):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        async with Gravity(api_key="test-key", relevancy=0.2) as g:
            result = await g.get_ads(
                FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS, relevancy=0.9
            )
        assert result.request_body is not None
        assert result.request_body["relevancy"] == 0.9

    @respx.mock
    @pytest.mark.asyncio
    async def test_client_reused_across_calls(self):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        async with Gravity(api_key="test-key") as g:
            await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
            first_client = g._http
            await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
            assert g._http is first_client


class TestLogging:
    @pytest.mark.asyncio
    async def test_no_api_key_warns_at_init(self, monkeypatch: pytest.MonkeyPatch, caplog):
        monkeypatch.delenv("GRAVITY_API_KEY", raising=False)
        with caplog.at_level(logging.WARNING, logger="gravity_sdk"):
            Gravity()
        assert "no API key" in caplog.text

    @respx.mock
    @pytest.mark.asyncio
    async def test_401_warns(self, caplog):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(401))
        with caplog.at_level(logging.WARNING, logger="gravity_sdk"):
            async with Gravity(api_key="bad") as g:
                result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.status == 401
        assert "401" in caplog.text

    @respx.mock
    @pytest.mark.asyncio
    async def test_403_warns(self, caplog):
        respx.post(DEFAULT_API_URL).mock(
            return_value=httpx.Response(403, json={"detail": "Not authenticated"})
        )
        with caplog.at_level(logging.WARNING, logger="gravity_sdk"):
            async with Gravity(api_key="bad") as g:
                result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.status == 403
        assert "403" in caplog.text

    @respx.mock
    @pytest.mark.asyncio
    async def test_400_warns(self, caplog):
        respx.post(DEFAULT_API_URL).mock(
            return_value=httpx.Response(400, json={"errors": ["Field 'messages' is required"]})
        )
        with caplog.at_level(logging.WARNING, logger="gravity_sdk"):
            async with Gravity(api_key="test-key") as g:
                result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.status == 400
        assert "400 Bad Request" in caplog.text

    @respx.mock
    @pytest.mark.asyncio
    async def test_422_warns(self, caplog):
        respx.post(DEFAULT_API_URL).mock(
            return_value=httpx.Response(
                422, json={"detail": [{"loc": ["body"], "msg": "field required"}]}
            )
        )
        with caplog.at_level(logging.WARNING, logger="gravity_sdk"):
            async with Gravity(api_key="test-key") as g:
                result = await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert result.status == 422
        assert "422 Validation Error" in caplog.text

    @respx.mock
    @pytest.mark.asyncio
    async def test_204_does_not_warn(self, caplog):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(204))
        with caplog.at_level(logging.WARNING, logger="gravity_sdk"):
            async with Gravity(api_key="test-key") as g:
                await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert caplog.text == ""

    @respx.mock
    @pytest.mark.asyncio
    async def test_200_does_not_warn(self, caplog):
        respx.post(DEFAULT_API_URL).mock(return_value=httpx.Response(200, json=SAMPLE_AD))
        with caplog.at_level(logging.WARNING, logger="gravity_sdk"):
            async with Gravity(api_key="test-key") as g:
                await g.get_ads(FakeStarletteRequest(CTX_BODY), MESSAGES, PLACEMENTS)
        assert caplog.text == ""


class TestSerialization:
    def test_ad_result_to_dict(self):
        ad = AdResponse.from_dict(SAMPLE_AD)
        result = AdResult(ads=[ad], status=200, elapsed_ms="142")
        d = result.to_dict()
        assert d["status"] == 200
        assert d["elapsed"] == "142"
        assert d["ads"][0]["adText"] == "Try our product"
        assert d["ads"][0]["brandName"] == "TestBrand"

    def test_ad_result_error_to_dict(self):
        result = AdResult(error="Timeout (3.0s)")
        d = result.to_dict()
        assert d["error"] == "Timeout (3.0s)"
        assert d["ads"] == []
