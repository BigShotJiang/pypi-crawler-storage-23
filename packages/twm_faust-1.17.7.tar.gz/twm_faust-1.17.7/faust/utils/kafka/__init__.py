"""Kafka utilities."""
