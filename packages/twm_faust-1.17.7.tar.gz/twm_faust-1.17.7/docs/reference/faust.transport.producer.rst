=====================================================
 ``faust.transport.producer``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.transport.producer

.. automodule:: faust.transport.producer
    :members:
    :undoc-members:
