=====================================================
 ``faust.sensors``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.sensors

.. automodule:: faust.sensors
    :members:
    :undoc-members:
