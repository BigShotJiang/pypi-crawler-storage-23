=====================================================
 ``faust.sensors.prometheus``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.sensors.prometheus

.. automodule:: faust.sensors.prometheus
    :members:
    :undoc-members:
