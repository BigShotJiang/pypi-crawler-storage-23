=====================================================
 ``faust.app.base``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.app.base

.. automodule:: faust.app.base
    :members:
    :undoc-members:
