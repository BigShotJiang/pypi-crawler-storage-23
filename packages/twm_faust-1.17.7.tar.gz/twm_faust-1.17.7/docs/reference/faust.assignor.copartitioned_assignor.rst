=====================================================
 ``faust.assignor.copartitioned_assignor``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.assignor.copartitioned_assignor

.. automodule:: faust.assignor.copartitioned_assignor
    :members:
    :undoc-members:
