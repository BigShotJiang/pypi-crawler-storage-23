"""Scheduler IR (Intermediate Representation) for sageLLM Control Plane.

The Scheduler IR provides a structured representation of scheduling decisions
and execution plans for inference tasks.

Key Components:
- SchedulerIR: Core IR structure representing a scheduling plan
- IRBuilder: Constructs IR from requests
- IROptimizer: Optimizes IR for better resource utilization
- IRExecutor: Interface for executing IR plans

Example:
    from sagellm_control.ir import DefaultIRExecutor, IRBuilder, IROptimizer
    from sagellm_protocol import Request

    # Build IR from request
    builder = IRBuilder()
    ir = builder.build_from_request(request)

    # Optimize IR
    optimizer = IROptimizer()
    optimized_ir = optimizer.optimize(ir)

    # Execute IR
    executor = DefaultIRExecutor(engine_client=engine)
    await executor.execute(optimized_ir)
"""

from __future__ import annotations

from sagellm_control.ir.builder import IRBuilder
from sagellm_control.ir.executor import DefaultIRExecutor, ExecutionCommand, IRExecutor
from sagellm_control.ir.optimizer import (
    ComputeCommOverlapPass,
    IROptimizer,
    KVReusePass,
    OptimizationPass,
    ResourceAllocationPass,
)
from sagellm_control.ir.types import (
    ComputationNode,
    DependencyEdge,
    IRNode,
    NodeType,
    ParallelismConfig,
    ParallelismStrategy,
    ResourceAllocation,
    SchedulerIR,
    TaskNode,
)

__all__ = [
    # Core IR types
    "SchedulerIR",
    "IRNode",
    "TaskNode",
    "ComputationNode",
    "DependencyEdge",
    "NodeType",
    "ResourceAllocation",
    "ParallelismConfig",
    "ParallelismStrategy",
    # Builder
    "IRBuilder",
    # Optimizer
    "OptimizationPass",
    "KVReusePass",
    "ComputeCommOverlapPass",
    "ResourceAllocationPass",
    "IROptimizer",
    # Executor
    "ExecutionCommand",
    "IRExecutor",
    "DefaultIRExecutor",
]
