# Kiwiscript
This is a programing language built on top of python.
It is a simple and homemade language.

# Instalation
Use the package manager [pip](https://pip.pypa.io/en/stable/) to install _Kiwiscript_.
```bash
pip install kiwiscript
```

# Usage
In order to use Kiwiscript, you will have to use python.
```bash
python -m kiwiscript
```
In order to find out what version you are using, you will also have to use python.
```bash
python -m kiwiscript --version
```
In order to execute a Kiwiscript file, you will have to use pyton
```bash
python -m kiwiscript your/path/to/file.ks
```