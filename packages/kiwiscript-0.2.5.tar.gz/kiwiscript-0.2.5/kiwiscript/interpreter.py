from __future__ import annotations
from typing import Any, Dict, Optional, List
from datetime import datetime
import time
import sys
from . import __version__

from .lexer import Token
from .parser import (
    Stmt, Let, Assign, Block, If, While, For, Func, ClassDef, Return, ExprStmt,
    Break, Continue, Pass,
    Expr, Number, String, Bool, Null, Var, This, ParentRef, ListExpr, DictExpr,
    Index, Get, Unary, Binary, Call, RangeExpr,
)

# -----------------------------
# Pretty Runtime Errors
# -----------------------------

class Colors:
    RED = "\033[91m"
    BOLD = "\033[1m"
    END = "\033[0m"

class RuntimeErrorLang(Exception):
    def __init__(self, message: str, token: Optional[Token] = None, source: Optional[str] = None):
        self.message = message
        self.token = token
        self.source = source or ""
        super().__init__(message)

    def __str__(self):
        if not self.token or not self.source:
            return f"{Colors.RED}{Colors.BOLD}RuntimeError:{Colors.END} {self.message}"
        lines = self.source.splitlines()
        line_text = lines[self.token.line - 1] if 0 <= self.token.line - 1 < len(lines) else ""
        caret = " " * max(0, self.token.col - 1) + "^"
        return (
            f"{Colors.RED}{Colors.BOLD}RuntimeError:{Colors.END} {self.message}\n"
            f"  --> line {self.token.line}, column {self.token.col}\n"
            f"{self.token.line:3} | {line_text}\n"
            f"    | {caret}\n"
        )

class ReturnSignal(Exception):
    def __init__(self, value: Any):
        self.value = value

class BreakSignal(Exception): pass
class ContinueSignal(Exception): pass


# -----------------------------
# Environment
# -----------------------------

class Env:
    def __init__(self, parent: Optional["Env"] = None):
        self.parent = parent
        self.values: Dict[str, Any] = {}

    def define(self, name: str, value: Any):
        self.values[name] = value

    def assign(self, name: str, value: Any):
        if name in self.values:
            self.values[name] = value
            return
        if self.parent:
            self.parent.assign(name, value)
            return
        raise KeyError(name)

    def get(self, name: str) -> Any:
        if name in self.values:
            return self.values[name]
        if self.parent:
            return self.parent.get(name)
        raise KeyError(name)


# -----------------------------
# Functions (closures)
# -----------------------------

class Function:
    def __init__(self, name: str, params: List[str], body: Block, closure: Env, source: str):
        self.name = name
        self.params = params
        self.body = body
        self.closure = closure
        self.source = source

    def call(self, args: List[Any], this_obj: Optional["InstanceObject"] = None, current_class: Optional["ClassObject"] = None):
        if len(args) != len(self.params):
            raise RuntimeErrorLang(
                f"{self.name}() expected {len(self.params)} arguments, got {len(args)}",
                source=self.source
            )

        env = Env(self.closure)
        for p, v in zip(self.params, args):
            env.define(p, v)

        try:
            Interpreter(
                env=env,
                source=self.source,
                current_this=this_obj,
                current_class=current_class
            ).exec_block(self.body)
        except ReturnSignal as r:
            return r.value
        return None

    def __call__(self, *args):
        # no implicit this
        return self.call(list(args), this_obj=None, current_class=None)


# -----------------------------
# Classes Runtime Objects
# -----------------------------

class ClassObject:
    def __init__(self, name: str, methods: Dict[str, Function], source: str, parent: Optional["ClassObject"] = None):
        self.name = name
        self.methods = methods
        self.source = source
        self.parent = parent

    def __call__(self, *args):
        inst = InstanceObject(self)

        # constructor selection:
        # - if class has mainF -> only that runs (Parent() must be explicit)
        # - if class has no mainF -> use parent's mainF automatically (if any)
        ctor = self.methods.get("mainF")
        if ctor:
            ctor.call(list(args), this_obj=inst, current_class=self)
            return inst

        # no ctor in this class: fall back to parent mainF
        if self.parent and "mainF" in self.parent.methods:
            self.parent.methods["mainF"].call(list(args), this_obj=inst, current_class=self.parent)
            return inst

        if len(args) != 0:
            raise RuntimeErrorLang(f"{self.name}() takes 0 arguments (no mainF defined)", source=self.source)
        return inst


class InstanceObject:
    def __init__(self, klass: ClassObject):
        self.klass = klass
        self.fields: Dict[str, Any] = {}

    def has_field(self, name: str) -> bool:
        return name in self.fields

    def get_field(self, name: str):
        return self.fields[name]

    def set_field(self, name: str, value: Any):
        self.fields[name] = value


class ParentProxy:
    """
    Inside a subclass method, 'Parent' means:
    - Parent(...) calls the parent's mainF on the *current instance*
    - Parent.method is accessible ONLY via explicit qualification: Parent.speak(this)
    """
    def __init__(self, parent_class: ClassObject, this_obj: InstanceObject, source: str):
        self.parent_class = parent_class
        self.this_obj = this_obj
        self.source = source

    def __call__(self, *args):
        ctor = self.parent_class.methods.get("mainF")
        if not ctor:
            raise RuntimeErrorLang(f"Parent class {self.parent_class.name} has no mainF()", source=self.source)
        return ctor.call(list(args), this_obj=self.this_obj, current_class=self.parent_class)


# -----------------------------
# Interpreter
# -----------------------------

class Interpreter:
    def __init__(
        self,
        env: Optional[Env] = None,
        source: Optional[str] = None,
        current_this: Optional[InstanceObject] = None,
        current_class: Optional[ClassObject] = None,
        args = None,
    ):
        self.env = env or Env()
        self.args = args or []
        self.source = source or ""
        self.loop_depth = 0
        self.current_this = current_this
        self.current_class = current_class
        self._define_builtins()
        self._install_kiwi_namespace()

    def _rt(self, msg: str, token: Optional[Token] = None):
        raise RuntimeErrorLang(msg, token=token, source=self.source)

    def _install_kiwi_namespace(self):

        def _write(*args):
            cooked = [self._stringify(a) if isinstance(a, InstanceObject) else a for a in args]
            with open(cooked[0], "w", encoding="utf-8") as f:
                f.write(cooked[1])

        def _read(*args):
            cooked = [self._stringify(a) if isinstance(a, InstanceObject) else a for a in args]
            try:
                with open(cooked[0], "r", encoding="utf-8") as f:
                    return f.read()
            except FileNotFoundError:
                return self._rt(f"The file of '{cooked[0]}' does not exist")

        kiwi_class = ClassObject("KiwiNamespace", methods={}, source=self.source, parent=None)
        kiwi = InstanceObject(kiwi_class)

        time_class = ClassObject("TimeNamespace", methods={}, source=self.source, parent=None)
        timeobj = InstanceObject(time_class)
        timeobj.set_field("date", datetime.now().date())
        timeobj.set_field("time", datetime.now().time())

        file_class = ClassObject("FileNamespace", methods={}, source=self.source, parent=None)
        fileobj = InstanceObject(file_class)
        fileobj.set_field("read", _read)
        fileobj.set_field("write", _write)

        io_class = ClassObject("IONamespace", methods={}, source=self.source, parent=None)
        ioobj = InstanceObject(io_class)
        ioobj.set_field("file", fileobj)

        basic_class = ClassObject("BasicNamespace", methods={}, source=self.source, parent=None)
        basicobj = InstanceObject(basic_class)
        basicobj.set_field("time", timeobj)
        basicobj.set_field("io", ioobj)

        sys_class = ClassObject("SysNamespace", methods={}, source=self.source, parent=None)
        sysobj = InstanceObject(sys_class)
        sysobj.set_field("argv", list(self.args))
        sysobj.set_field("version", __version__)
        sysobj.set_field("platform", sys.platform)

        kiwi.set_field("sys", sysobj)
        kiwi.set_field("basic", basicobj)

        self.env.define("Kiwi", kiwi)

    def _stringify(self, v: Any, token: Optional[Token] = None) -> str:
        if isinstance(v, InstanceObject):
            m = v.klass.methods.get("string")
            if m:
                out = m.call([], this_obj=v, current_class=v.klass)
                return str(out)
            return f"<{v.klass.name} instance>"
        return str(v)

    def _define_builtins(self):
        if "print" in self.env.values:
            return

        def _print(*args):
            cooked = [self._stringify(a) if isinstance(a, InstanceObject) else a for a in args]
            print(*cooked)


        self.env.define("print", _print)
        self.env.define("input", lambda p="": input(p))
        self.env.define("len", len)
        self.env.define("append", lambda lst, v: lst.append(v))
        self.env.define("delay", lambda ms: time.sleep(ms / 1000.0))
        self.env.define("exit", lambda code=0: sys.exit(code))

        def _range(*args):
            if len(args) == 1:
                start, end, step = 0, args[0], 1
            elif len(args) == 2:
                start, end = args
                step = 1
            elif len(args) == 3:
                start, end, step = args
            else:
                raise RuntimeErrorLang("range() expects 1, 2, or 3 arguments", source=self.source)

            if not all(isinstance(x, int) for x in (start, end, step)):
                raise RuntimeErrorLang("range() arguments must be integers", source=self.source)
            if step == 0:
                raise RuntimeErrorLang("range() step cannot be 0", source=self.source)
            if step < 0:
                raise RuntimeErrorLang("range() does not allow negative steps", source=self.source)
            return range(start, end, step)

        self.env.define("range", _range)

    # -------- execution --------

    def run(self, stmts: List[Stmt]):
        for stmt in stmts:
            self.exec_stmt(stmt)

    def exec_block(self, block: Block):
        old = self.env
        self.env = Env(old)
        try:
            for stmt in block.stmts:
                self.exec_stmt(stmt)
        finally:
            self.env = old

    def exec_stmt(self, stmt: Stmt):
        if isinstance(stmt, Let):
            value = self.eval(stmt.expr)

            # let variable
            if isinstance(stmt.target, Var):
                if stmt.target.name == "this":
                    self._rt("'this' is reserved", stmt.target.token)
                if stmt.target.name == "Parent":
                    self._rt("'Parent' is reserved", stmt.target.token)
                self.env.define(stmt.target.name, value)
                return

            # let obj.field = value  (field write rule)
            if isinstance(stmt.target, Get):
                obj = self.eval(stmt.target.obj)
                if not isinstance(obj, InstanceObject):
                    self._rt("Can only set fields on class instances", stmt.target.token)
                obj.set_field(stmt.target.name, value)
                return

            self._rt("Invalid let target", getattr(stmt.target, "token", None))

        if isinstance(stmt, Assign):
            value = self.eval(stmt.expr)

            if isinstance(stmt.target, Var):
                if stmt.target.name in ("this", "Parent"):
                    self._rt(f"'{stmt.target.name}' is reserved", stmt.target.token)
                try:
                    self.env.assign(stmt.target.name, value)
                except KeyError:
                    self._rt(f"Undefined variable '{stmt.target.name}'", stmt.target.token)
                return

            if isinstance(stmt.target, Index):
                obj = self.eval(stmt.target.obj)
                idx = self.eval(stmt.target.index)
                try:
                    obj[idx] = value
                except Exception:
                    self._rt("Invalid index assignment", stmt.target.token)
                return

            if isinstance(stmt.target, Get):
                self._rt("Illegal field assignment: use 'let obj.field = ...' to write fields", stmt.target.token)

            self._rt("Invalid assignment target", getattr(stmt.target, "token", None))

        if isinstance(stmt, Pass):
            return

        if isinstance(stmt, Break):
            if self.loop_depth <= 0:
                self._rt("'break' used outside of loop", stmt.token)
            raise BreakSignal()

        if isinstance(stmt, Continue):
            if self.loop_depth <= 0:
                self._rt("'continue' used outside of loop", stmt.token)
            raise ContinueSignal()

        if isinstance(stmt, ExprStmt):
            self.eval(stmt.expr)
            return

        if isinstance(stmt, Block):
            self.exec_block(stmt)
            return

        if isinstance(stmt, If):
            if self.is_truthy(self.eval(stmt.cond)):
                self.exec_block(stmt.then)
            else:
                if stmt.els is None:
                    return
                if isinstance(stmt.els, Block):
                    self.exec_block(stmt.els)
                elif isinstance(stmt.els, If):
                    self.exec_stmt(stmt.els)
                else:
                    self._rt("Invalid else branch", None)
            return

        if isinstance(stmt, While):
            self.loop_depth += 1
            try:
                while self.is_truthy(self.eval(stmt.cond)):
                    try:
                        self.exec_block(stmt.body)
                    except ContinueSignal:
                        continue
                    except BreakSignal:
                        break
            finally:
                self.loop_depth -= 1
            return

        if isinstance(stmt, For):
            iterable = self.eval(stmt.iterable)
            try:
                iterator = iter(iterable)
            except Exception:
                self._rt("Object is not iterable", stmt.iterable.token)

            self.loop_depth += 1
            try:
                for value in iterator:
                    loop_env = Env(self.env)
                    loop_env.define(stmt.name, value)
                    try:
                        Interpreter(
                            env=loop_env,
                            source=self.source,
                            current_this=self.current_this,
                            current_class=self.current_class
                        ).exec_block(stmt.body)
                    except ContinueSignal:
                        continue
                    except BreakSignal:
                        break
            finally:
                self.loop_depth -= 1
            return

        if isinstance(stmt, Func):
            fn = Function(stmt.name, stmt.params, stmt.body, self.env, self.source)
            self.env.define(stmt.name, fn)
            return

        if isinstance(stmt, ClassDef):
            # parent resolution: must already exist in env if used
            parent_obj: Optional[ClassObject] = None
            if stmt.parent:
                try:
                    maybe_parent = self.env.get(stmt.parent)
                except KeyError:
                    self._rt(f"Unknown parent class '{stmt.parent}'", None)
                if not isinstance(maybe_parent, ClassObject):
                    self._rt(f"'{stmt.parent}' is not a class", None)
                parent_obj = maybe_parent

            methods: Dict[str, Function] = {}
            for m in stmt.methods:
                methods[m.name] = Function(m.name, m.params, m.body, self.env, self.source)

            klass = ClassObject(stmt.name, methods, self.source, parent=parent_obj)
            self.env.define(stmt.name, klass)
            return

        if isinstance(stmt, Return):
            raise ReturnSignal(self.eval(stmt.expr) if stmt.expr else None)

        self._rt("Unknown statement", None)

    # -------- evaluation --------

    def eval(self, expr: Expr) -> Any:
        if isinstance(expr, Number): return expr.value
        if isinstance(expr, String): return expr.value
        if isinstance(expr, Bool): return expr.value
        if isinstance(expr, Null): return None

        if isinstance(expr, This):
            if self.current_this is None:
                self._rt("'this' used outside of class method", expr.token)
            return self.current_this

        if isinstance(expr, ParentRef):
            # Parent is only valid inside a subclass method with a parent and a current instance
            if self.current_this is None or self.current_class is None:
                self._rt("'Parent' used outside of class method", expr.token)
            if not self.current_class.parent:
                self._rt("'Parent' used but class has no parent", expr.token)
            return ParentProxy(self.current_class.parent, self.current_this, self.source)

        if isinstance(expr, Var):
            if expr.name == "this":
                self._rt("'this' is reserved", expr.token)
            if expr.name == "Parent":
                self._rt("'Parent' is reserved (use it as Parent(...), not a variable)", expr.token)
            try:
                return self.env.get(expr.name)
            except KeyError:
                self._rt(f"Undefined variable '{expr.name}'", expr.token)

        if isinstance(expr, ListExpr):
            return [self.eval(x) for x in expr.items]

        if isinstance(expr, DictExpr):
            out = {}
            for k, v in expr.pairs:
                out[self.eval(k)] = self.eval(v)
            return out

        if isinstance(expr, RangeExpr):
            start = self.eval(expr.start)
            end = self.eval(expr.end)
            if not isinstance(start, int) or not isinstance(end, int):
                self._rt("Range bounds must be integers", expr.token)
            if end < start:
                self._rt("Range end must be >= start (no negative ranges)", expr.token)
            return range(start, end)

        if isinstance(expr, Index):
            obj = self.eval(expr.obj)
            idx = self.eval(expr.index)
            try:
                return obj[idx]
            except Exception:
                self._rt("Invalid index operation", expr.token)

        if isinstance(expr, Get):
            obj = self.eval(expr.obj)

            # Instance: NO implicit parent method lookup.
            if isinstance(obj, InstanceObject):
                if obj.has_field(expr.name):
                    return obj.get_field(expr.name)

                # Only methods on *this class* are visible via obj.method
                m = obj.klass.methods.get(expr.name)
                if m:
                    # bind this + current_class so ParentRef works inside that method
                    def bound(*args):
                        return m.call(list(args), this_obj=obj, current_class=obj.klass)
                    return bound

                self._rt(f"Unknown field/method '{expr.name}' on {obj.klass.name}", expr.token)

            # Class object: explicit qualification Student.speak(this)
            if isinstance(obj, ClassObject):
                m = obj.methods.get(expr.name)
                if m:
                    # unbound; user must pass instance explicitly
                    return lambda *args: m.call(list(args), this_obj=None, current_class=obj)
                self._rt(f"Unknown method '{expr.name}' on class {obj.name}", expr.token)

            # Parent proxy: explicit qualification Parent.speak(this)
            if isinstance(obj, ParentProxy):
                m = obj.parent_class.methods.get(expr.name)
                if m:
                    return lambda *args: m.call(list(args), this_obj=None, current_class=obj.parent_class)
                self._rt(f"Unknown method '{expr.name}' on Parent class {obj.parent_class.name}", expr.token)

            self._rt("Invalid '.' access target", expr.token)

        if isinstance(expr, Unary):
            right = self.eval(expr.r)
            if expr.op == "MINUS":
                try:
                    return -right
                except Exception:
                    self._rt("Bad operand for unary '-'", expr.token)
            if expr.op == "BANG":
                return not self.is_truthy(right)
            self._rt(f"Unknown unary operator {expr.op}", expr.token)

        if isinstance(expr, Binary):
            if expr.op == "AND":
                left_truth = self.is_truthy(self.eval(expr.l))
                if not left_truth:
                    return False
                return self.is_truthy(self.eval(expr.r))

            if expr.op == "OR":
                left_truth = self.is_truthy(self.eval(expr.l))
                if left_truth:
                    return True
                return self.is_truthy(self.eval(expr.r))

            left = self.eval(expr.l)
            right = self.eval(expr.r)

            try:
                if expr.op == "PLUS":
                    if isinstance(left, str) or isinstance(right, str):
                        return str(left) + str(right)
                    return left + right
                if expr.op == "MINUS":
                    return left - right
                if expr.op == "STAR":
                    return left * right
                if expr.op == "SLASH":
                    if right == 0:
                        self._rt("Division by zero", expr.token)
                    return left / right
            except TypeError:
                self._rt("Invalid operands for arithmetic", expr.token)

            try:
                if expr.op == "EQEQ": return left == right
                if expr.op == "NEQ": return left != right
                if expr.op == "LT": return left < right
                if expr.op == "LTE": return left <= right
                if expr.op == "GT": return left > right
                if expr.op == "GTE": return left >= right
            except TypeError:
                self._rt("Invalid operands for comparison", expr.token)

            self._rt(f"Unknown binary operator {expr.op}", expr.token)

        if isinstance(expr, Call):
            fn = self.eval(expr.fn)
            args = [self.eval(a) for a in expr.args]

            # Parent(...) special call: runs parent mainF on current instance
            if isinstance(fn, ParentProxy):
                try:
                    return fn(*args)
                except RuntimeErrorLang:
                    raise
                except Exception as e:
                    self._rt(f"Error in Parent() call: {e}", expr.token)

            if not callable(fn):
                self._rt("Can only call functions/classes/Parent", expr.token)
            try:
                return fn(*args)
            except RuntimeErrorLang:
                raise
            except Exception as e:
                self._rt(f"Error in call: {e}", expr.token)

        self._rt("Unknown expression", getattr(expr, "token", None))

    def is_truthy(self, value: Any) -> bool:
        if value is None:
            return False
        if isinstance(value, bool):
            return value
        return bool(value)
#638