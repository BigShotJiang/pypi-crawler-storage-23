import argparse
import sys
from .lexer import lex
from .parser import Parser, KiwiSyntaxError
from .interpreter import Interpreter, RuntimeErrorLang as KiwiRuntimeError
from . import __version__

def run_source(src: str):
    sys.set_int_max_str_digits(0)
    tokens = lex(src)
    ast = Parser(tokens, src).parse()
    Interpreter(source=src, args=args.extras).run(ast)


def repl():
    print(f"KiwiScript v{__version__}. Type Control-C to exit.")
    interp = Interpreter(source="")
    while True:
        try:
            line = input(">> ")
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not line.strip():
            continue
        try:
            interp.source = line
            tokens = lex(line)
            ast = Parser(tokens, line).parse()
            interp.run(ast)
        except (KiwiSyntaxError, KiwiRuntimeError) as e:
            print(e)

def main():
    global args
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--version", action="version", version=f"v{__version__}")
    parser.add_argument("filename", nargs="?", default=None)
    parser.add_argument("extras", nargs="*")
    args = parser.parse_args()
    if args.filename:
        f = open(args.filename, "r")
        try:
            run_source(f.read())
        except (KiwiSyntaxError, KiwiRuntimeError) as e:
            print(e)
        except KeyboardInterrupt as e:
            print(e)
        except SyntaxError as e:
            print(e)
    else:
        repl()
