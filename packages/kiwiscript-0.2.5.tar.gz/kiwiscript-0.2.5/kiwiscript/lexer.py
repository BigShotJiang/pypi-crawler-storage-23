from dataclasses import dataclass
from typing import Any, List

@dataclass
class Token:
    kind: str
    value: Any
    line: int
    col: int

KEYWORDS = {
    "let", "if", "elif", "else", "while", "for", "in",
    "func", "return",
    "break", "continue", "pass",
    "and", "or",
    "class",
    "Parent",
    "this",
    "True", "False",
    "null",
}

SINGLE = {
    "+": "PLUS", "-": "MINUS", "*": "STAR", "/": "SLASH",
    "(": "LPAREN", ")": "RPAREN",
    "{": "LBRACE", "}": "RBRACE",
    "[": "LBRACKET", "]": "RBRACKET",
    ";": "SEMI", ",": "COMMA", ":": "COLON",
    ".": "DOT",
    "=": "EQ", "!": "BANG",
    "<": "LT", ">": "GT",
}

def lex(src: str) -> List[Token]:
    tokens: List[Token] = []
    i = 0
    line = 1
    col = 1

    def emit(kind, value=None, l=None, c=None):
        tokens.append(Token(kind, value, l or line, c or col))

    while i < len(src):
        c = src[i]

        if c == "\n":
            i += 1
            line += 1
            col = 1
            continue

        if c in " \t\r":
            i += 1
            col += 1
            continue

        # // comment
        if c == "/" and i + 1 < len(src) and src[i + 1] == "/":
            while i < len(src) and src[i] != "\n":
                i += 1
            continue

        # number
        if c.isdigit():
            start = i
            start_col = col
            while i < len(src) and src[i].isdigit():
                i += 1
                col += 1
            emit("NUMBER", int(src[start:i]), line, start_col)
            continue

        # string
        if c == '"':
            start_col = col
            i += 1
            col += 1
            s = ""
            while i < len(src) and src[i] != '"':
                s += src[i]
                i += 1
                col += 1
            if i >= len(src):
                raise SyntaxError("Unterminated string")
            i += 1
            col += 1
            emit("STRING", s, line, start_col)
            continue

        # identifier / keyword
        if c.isalpha() or c == "_":
            start = i
            start_col = col
            while i < len(src) and (src[i].isalnum() or src[i] == "_"):
                i += 1
                col += 1
            text = src[start:i]
            emit(text.upper() if text in KEYWORDS else "IDENT", text, line, start_col)
            continue

        # range operator ..
        if c == "." and i + 1 < len(src) and src[i + 1] == ".":
            emit("RANGE", "..")
            i += 2
            col += 2
            continue

        # two-char operators
        if c in ("=", "!", "<", ">") and i + 1 < len(src):
            two = src[i:i + 2]
            if two in ("==", "!=", "<=", ">="):
                emit({"==": "EQEQ", "!=": "NEQ", "<=": "LTE", ">=": "GTE"}[two], two)
                i += 2
                col += 2
                continue

        # single-char tokens
        if c in SINGLE:
            emit(SINGLE[c], c)
            i += 1
            col += 1
            continue

        raise SyntaxError(f"Unexpected character {c!r}")

    emit("EOF")
    return tokens
