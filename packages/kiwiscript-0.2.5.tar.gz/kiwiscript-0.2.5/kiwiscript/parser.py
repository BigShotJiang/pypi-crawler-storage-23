from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional, Tuple, Set
from .lexer import Token


class Colors:
    RED = "\033[91m"
    BOLD = "\033[1m"
    END = "\033[0m"


class KiwiSyntaxError(Exception):
    def __init__(self, message: str, token: Token, source: str):
        self.message = message
        self.token = token
        self.source = source
        super().__init__(message)

    def __str__(self):
        lines = self.source.splitlines()
        line = lines[self.token.line - 1] if self.token.line - 1 < len(lines) else ""
        caret = " " * max(0, self.token.col - 1) + "^"
        return (
            f"{Colors.RED}{Colors.BOLD}SyntaxError:{Colors.END} {self.message}\n"
            f"  --> line {self.token.line}, column {self.token.col}\n"
            f"{self.token.line:3} | {line}\n"
            f"    | {caret}\n"
        )


# -----------------------------
# AST: Expressions
# -----------------------------

@dataclass
class Expr:
    token: Token

@dataclass
class Number(Expr):
    value: int

@dataclass
class String(Expr):
    value: str

@dataclass
class Bool(Expr):
    value: bool

@dataclass
class Null(Expr):
    pass

@dataclass
class Var(Expr):
    name: str

@dataclass
class This(Expr):
    pass

@dataclass
class ParentRef(Expr):
    pass

@dataclass
class ListExpr(Expr):
    items: List[Expr]

@dataclass
class DictExpr(Expr):
    pairs: List[Tuple[Expr, Expr]]

@dataclass
class Index(Expr):
    obj: Expr
    index: Expr

@dataclass
class Get(Expr):
    obj: Expr
    name: str

@dataclass
class Unary(Expr):
    op: str
    r: Expr

@dataclass
class Binary(Expr):
    l: Expr
    op: str
    r: Expr

@dataclass
class Call(Expr):
    fn: Expr
    args: List[Expr]

@dataclass
class RangeExpr(Expr):
    start: Expr
    end: Expr


# -----------------------------
# AST: Statements
# -----------------------------

@dataclass
class Stmt: pass

@dataclass
class Let(Stmt):
    target: Expr
    expr: Expr

@dataclass
class Assign(Stmt):
    target: Expr
    expr: Expr

@dataclass
class Block(Stmt):
    stmts: List[Stmt]

@dataclass
class If(Stmt):
    cond: Expr
    then: Block
    els: Optional[Stmt]

@dataclass
class While(Stmt):
    cond: Expr
    body: Block

@dataclass
class For(Stmt):
    name: str
    iterable: Expr
    body: Block

@dataclass
class Func(Stmt):
    name: str
    params: List[str]
    body: Block

@dataclass
class ClassDef(Stmt):
    name: str
    parent: Optional[str]
    methods: List[Func]

@dataclass
class Return(Stmt):
    expr: Optional[Expr]

@dataclass
class Break(Stmt):
    token: Token

@dataclass
class Continue(Stmt):
    token: Token

@dataclass
class Pass(Stmt):
    token: Token

@dataclass
class ExprStmt(Stmt):
    expr: Expr


# -----------------------------
# Parser
# -----------------------------

class Parser:
    def __init__(self, tokens: List[Token], source: str):
        self.t = tokens
        self.i = 0
        self.source = source
        self.known_classes: Set[str] = set()

    def peek(self) -> Token:
        return self.t[self.i]

    def prev(self) -> Token:
        return self.t[self.i - 1]

    def at_end(self) -> bool:
        return self.peek().kind == "EOF"

    def _kind_at(self, offset: int) -> str:
        j = self.i + offset
        if j < 0 or j >= len(self.t):
            return "EOF"
        return self.t[j].kind

    def _tok_at(self, offset: int) -> Token:
        j = self.i + offset
        if j < 0 or j >= len(self.t):
            return self.t[-1]
        return self.t[j]

    def match(self, *kinds: str) -> bool:
        if self.peek().kind in kinds:
            self.i += 1
            return True
        return False

    def expect(self, kind: str, msg: Optional[str] = None) -> Token:
        if self.match(kind):
            return self.prev()
        raise KiwiSyntaxError(msg or f"expected {kind.lower()}", self.peek(), self.source)

    def expect_ident(self, msg="expected identifier") -> Token:
        if self.match("IDENT"):
            return self.prev()
        raise KiwiSyntaxError(msg, self.peek(), self.source)

    def parse(self) -> List[Stmt]:
        stmts: List[Stmt] = []
        while not self.at_end():
            stmts.append(self.statement())
        return stmts

    def statement(self) -> Stmt:
        # let ...
        if self.match("LET"):
            target = self.let_target()
            self.expect("EQ", "expected '=' after let target")
            expr = self.expr()
            self.match("SEMI")
            return Let(target, expr)

        # class Name(Parent)? { ... }
        if self.match("CLASS"):
            name_tok = self.expect_ident("expected class name")
            name = name_tok.value

            parent: Optional[str] = None
            if self.match("LPAREN"):
                p = self.expect_ident("expected parent class name inside (...)")
                parent = p.value
                self.expect("RPAREN", "expected ')' after parent class name")

            self.expect("LBRACE", "expected '{' after class header")

            methods: List[Func] = []
            while not self.match("RBRACE"):
                self.expect("FUNC", "only 'func' allowed inside class")
                methods.append(self.func_decl())

            self.known_classes.add(name)
            return ClassDef(name, parent, methods)

        # func ...
        if self.match("FUNC"):
            return self.func_decl()

        # if / elif / else
        if self.match("IF"):
            cond = self.expr()
            then = self.block()
            root = If(cond, then, None)
            cur = root
            while self.match("ELIF"):
                c = self.expr()
                b = self.block()
                nxt = If(c, b, None)
                cur.els = nxt
                cur = nxt
            if self.match("ELSE"):
                cur.els = self.block()
            return root

        # while
        if self.match("WHILE"):
            return While(self.expr(), self.block())

        # for
        if self.match("FOR"):
            name = self.expect_ident("expected loop variable after 'for'").value
            self.expect("IN", "expected 'in'")
            it = self.expr()
            return For(name, it, self.block())

        # return
        if self.match("RETURN"):
            if self.peek().kind in ("SEMI", "RBRACE"):
                self.match("SEMI")
                return Return(None)
            e = self.expr()
            self.match("SEMI")
            return Return(e)

        # break / continue / pass
        if self.match("BREAK"):
            t = self.prev()
            self.match("SEMI")
            return Break(t)

        if self.match("CONTINUE"):
            t = self.prev()
            self.match("SEMI")
            return Continue(t)

        if self.match("PASS"):
            t = self.prev()
            self.match("SEMI")
            return Pass(t)

        # Arduino-style instantiation: ClassName varName(...)
        # ONLY if ClassName is a known class.
        if (
            self.peek().kind == "IDENT"
            and self._kind_at(1) == "IDENT"
            and self._kind_at(2) == "LPAREN"
        ):
            class_name = self.peek().value
            if class_name in self.known_classes:
                class_tok = self.expect("IDENT")
                var_tok = self.expect("IDENT")
                self.expect("LPAREN")

                args: List[Expr] = []
                if not self.match("RPAREN"):
                    args.append(self.expr())
                    while self.match("COMMA"):
                        args.append(self.expr())
                    self.expect("RPAREN")

                self.match("SEMI")
                return Let(
                    Var(var_tok, var_tok.value),
                    Call(class_tok, Var(class_tok, class_tok.value), args),
                )

        # assignment or expression
        expr = self.expr()

        if self.match("EQ"):
            value = self.expr()

            # Ban: bob = Person(...)
            # Only banned when Person is a known class.
            if isinstance(value, Call) and isinstance(value.fn, Var):
                if value.fn.name in self.known_classes:
                    raise KiwiSyntaxError(
                        "class instances must be declared using 'let' or 'ClassName varName(...)' (assignment is not allowed)",
                        value.token,
                        self.source
                    )

            self.match("SEMI")
            return Assign(expr, value)

        self.match("SEMI")
        return ExprStmt(expr)

    def func_decl(self) -> Func:
        name = self.expect_ident("expected function name").value
        self.expect("LPAREN")
        params: List[str] = []
        if not self.match("RPAREN"):
            params.append(self.expect_ident("expected parameter name").value)
            while self.match("COMMA"):
                params.append(self.expect_ident("expected parameter name").value)
            self.expect("RPAREN")
        return Func(name, params, self.block())

    def let_target(self) -> Expr:
        if self.match("THIS"):
            base: Expr = This(self.prev())
        elif self.match("IDENT"):
            tok = self.prev()
            base = Var(tok, tok.value)
        else:
            raise KiwiSyntaxError("expected variable or object in let", self.peek(), self.source)

        if self.match("DOT"):
            field = self.expect("IDENT", "expected field name after '.'")
            return Get(field, base, field.value)

        return base

    def block(self) -> Block:
        self.expect("LBRACE", "expected '{'")
        stmts: List[Stmt] = []
        while not self.match("RBRACE"):
            if self.at_end():
                raise KiwiSyntaxError("unterminated block (missing '}')", self.peek(), self.source)
            stmts.append(self.statement())
        return Block(stmts)

    # -----------------------------
    # Expressions
    # -----------------------------

    def expr(self) -> Expr:
        return self.or_expr()

    def or_expr(self) -> Expr:
        e = self.and_expr()
        while self.match("OR"):
            t = self.prev()
            e = Binary(t, e, "OR", self.and_expr())
        return e

    def and_expr(self) -> Expr:
        e = self.equality()
        while self.match("AND"):
            t = self.prev()
            e = Binary(t, e, "AND", self.equality())
        return e

    def equality(self) -> Expr:
        e = self.comparison()
        while self.match("EQEQ", "NEQ"):
            t = self.prev()
            e = Binary(t, e, t.kind, self.comparison())
        return e

    def comparison(self) -> Expr:
        e = self.range_expr()
        while self.match("LT", "LTE", "GT", "GTE"):
            t = self.prev()
            e = Binary(t, e, t.kind, self.range_expr())
        return e

    def range_expr(self) -> Expr:
        e = self.term()
        if self.match("RANGE"):
            t = self.prev()
            return RangeExpr(t, e, self.term())
        return e

    def term(self) -> Expr:
        e = self.factor()
        while self.match("PLUS", "MINUS"):
            t = self.prev()
            e = Binary(t, e, t.kind, self.factor())
        return e

    def factor(self) -> Expr:
        e = self.unary()
        while self.match("STAR", "SLASH"):
            t = self.prev()
            e = Binary(t, e, t.kind, self.unary())
        return e

    def unary(self) -> Expr:
        if self.match("MINUS", "BANG"):
            t = self.prev()
            return Unary(t, t.kind, self.unary())
        return self.postfix()

    def postfix(self) -> Expr:
        e = self.primary()
        while True:
            if self.match("DOT"):
                t = self.prev()
                name = self.expect("IDENT", "expected name after '.'")
                e = Get(t, e, name.value)
                continue

            if self.match("LPAREN"):
                t = self.prev()
                args: List[Expr] = []
                if not self.match("RPAREN"):
                    args.append(self.expr())
                    while self.match("COMMA"):
                        args.append(self.expr())
                    self.expect("RPAREN")
                e = Call(t, e, args)
                continue

            if self.match("LBRACKET"):
                t = self.prev()
                idx = self.expr()
                self.expect("RBRACKET")
                e = Index(t, e, idx)
                continue

            break
        return e

    def primary(self) -> Expr:
        if self.match("NUMBER"):
            t = self.prev()
            return Number(t, t.value)

        if self.match("STRING"):
            t = self.prev()
            return String(t, t.value)

        if self.match("TRUE"):
            t = self.prev()
            return Bool(t, True)

        if self.match("FALSE"):
            t = self.prev()
            return Bool(t, False)

        if self.match("NULL"):
            t = self.prev()
            return Null(t)

        if self.match("THIS"):
            return This(self.prev())

        if self.match("PARENT"):
            return ParentRef(self.prev())

        if self.match("IDENT"):
            t = self.prev()
            return Var(t, t.value)

        if self.match("LPAREN"):
            e = self.expr()
            self.expect("RPAREN")
            return e

        if self.match("LBRACKET"):
            t = self.prev()
            items: List[Expr] = []
            if not self.match("RBRACKET"):
                items.append(self.expr())
                while self.match("COMMA"):
                    items.append(self.expr())
                self.expect("RBRACKET")
            return ListExpr(t, items)

        if self.match("LBRACE"):
            t = self.prev()
            pairs: List[Tuple[Expr, Expr]] = []
            if not self.match("RBRACE"):
                k = self.expr()
                self.expect("COLON")
                v = self.expr()
                pairs.append((k, v))
                while self.match("COMMA"):
                    k = self.expr()
                    self.expect("COLON")
                    v = self.expr()
                    pairs.append((k, v))
                self.expect("RBRACE")
            return DictExpr(t, pairs)

        raise KiwiSyntaxError("expected expression", self.peek(), self.source)
