"""CLI entry points for bsvae."""
