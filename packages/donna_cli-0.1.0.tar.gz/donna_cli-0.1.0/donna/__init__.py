"""Donna — Digital Operative for Non-Negotiable Automation."""

__version__ = "0.1.0"
