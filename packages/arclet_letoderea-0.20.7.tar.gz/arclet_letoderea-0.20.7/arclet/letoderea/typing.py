from __future__ import annotations

import inspect
from collections.abc import Awaitable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Generic, Protocol, TypeVar, Union, overload, cast
from collections.abc import Callable

from tarina import is_async
from typing_extensions import Self


T = TypeVar("T")
T1 = TypeVar("T1")


class CtxItem(Generic[T]):
    @classmethod
    def make(cls, name: str) -> CtxItem[T]:
        return cast(CtxItem[T], cast(object, name))


class Contexts(dict[str, Any]):
    if TYPE_CHECKING:

        def copy(self) -> Self: ...

        @overload
        def __getitem__(self, item: CtxItem[T1]) -> T1: ...

        @overload
        def __getitem__(self, item: str) -> Any: ...

        def __getitem__(self, item: str | CtxItem[T1]) -> Any: ...

        @overload
        def __setitem__(self, key: CtxItem[T1], value: T1, /) -> None: ...

        @overload
        def __setitem__(self, key: str, value: Any, /) -> None: ...

        def __setitem__(self, key: str | CtxItem[T1], value: Any, /): ...

        @overload
        def get(self, __key: CtxItem[T1]) -> T1 | None: ...

        @overload
        def get(self, __key: str) -> Any | None: ...

        @overload
        def get(self, __key: CtxItem[T1], __default: T1) -> T1: ...

        @overload
        def get(self, __key: str, __default: Any) -> Any: ...

        @overload
        def get(self, __key: CtxItem[T1], __default: T) -> T1 | T: ...

        def get(self, __key: str | CtxItem[T1], __default: Any = ...) -> Any: ...  # type: ignore

    ...


EVENT: CtxItem[Any] = CtxItem.make("$event")


async def generate_contexts(
    event: T, supplier:  Callable[[T, Contexts], Awaitable[Contexts | None]] | None = None, inherit_ctx: Contexts | None = None
) -> Contexts:
    contexts: Contexts = {EVENT: event, "$depend_cache": {}}  # type: ignore
    if supplier:
        await supplier(event, contexts)
    elif (_gather := getattr(event, "__context_gather__", getattr(event, "gather", None))) is not None:
        await _gather(contexts)
    if inherit_ctx:
        inherit_ctx.update(contexts)
        return inherit_ctx
    return contexts


TTarget = Union[Callable[..., Awaitable[T]], Callable[..., T]]  # noqa: UP007
TCallable = TypeVar("TCallable", bound=Callable[..., Any])
TDispose = Callable[[], None]


@dataclass
class Force:
    """用于转义在本框架中特殊部分的特殊值"""

    value: Any


class Result(Generic[T]):
    """用于标记一个事件响应器的处理结果，通常应用在某个事件响应器的处理结果需要被事件发布者使用的情况"""
    __slots__ = ("value",)

    def __init__(self, value: T):
        self.value = value


class Resultable(Protocol[T]):
    def check_result(self, value: Any) -> Result[T] | None: ...


async def run_always_await(target: Callable[..., Any] | Callable[..., Awaitable[Any]], *args, **kwargs) -> Any:
    obj = target(*args, **kwargs)
    if is_async(target) or inspect.isawaitable(obj):
        obj = await obj  # type: ignore
    return obj
