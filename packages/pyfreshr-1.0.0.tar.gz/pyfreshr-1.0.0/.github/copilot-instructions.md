# Project Overview

This project is a python library that does what a user does to retrieve data for the fresh-r air ventilation system. It will be used in a Home Assistant custom compontent to retrieve data and display it in the Home Assistant UI.

## Folder Structure
- `src/`: This folder contains the source code for the library.
- `tests/`: This folder contains unit tests for the library.
- `examples/`: This folder contains example scripts that demonstrate how to use the library.
- `README.md`: This file provides an overview of the project and instructions for installation and usage

## Libraries and Tools
- `aiohttp`: This library is used for making asynchronous HTTP requests to the API.
- `pytest`: This library is used for writing and running unit tests.

## Code Style
- Use the latest version of Python (3.10 or higher).
- Follow PEP 8 style guidelines for code formatting.
- Prefer async programming style when making API calls to improve performance.
- Use type hints to improve code readability and maintainability.