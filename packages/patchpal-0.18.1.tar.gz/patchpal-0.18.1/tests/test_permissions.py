"""Tests for permission pattern extraction (Claude Code compatibility)."""

from pathlib import Path

import pytest


@pytest.fixture
def mock_repo(tmp_path):
    """Create a mock repository directory."""
    repo_dir = tmp_path / "test_repo"
    repo_dir.mkdir()
    return repo_dir


def test_shell_command_pattern_simple():
    """Test simple shell command pattern extraction."""
    from patchpal.tools.shell_tools import _extract_shell_command_info

    # Simple command
    cmd, wd = _extract_shell_command_info("pytest tests/")
    assert cmd == "pytest"
    assert wd is None

    # Command with flags
    cmd, wd = _extract_shell_command_info("python -m pytest tests/")
    assert cmd == "python"
    assert wd is None


def test_shell_command_pattern_with_cd():
    """Test shell command pattern extraction with cd."""
    from patchpal.tools.shell_tools import _extract_shell_command_info

    # cd && command
    cmd, wd = _extract_shell_command_info("cd /tmp && python test.py")
    assert cmd == "python"
    assert wd == "/tmp"

    # cd && command with relative path
    cmd, wd = _extract_shell_command_info("cd src && python app.py")
    assert cmd == "python"
    assert wd == "src"

    # Multiple commands after cd
    cmd, wd = _extract_shell_command_info("cd /tmp && python setup.py && pytest")
    assert cmd == "python"  # First non-cd command
    assert wd == "/tmp"


def test_shell_command_pattern_with_pipes():
    """Test shell command pattern extraction with pipes."""
    from patchpal.tools.shell_tools import _extract_shell_command_info

    # Command with pipe
    cmd, wd = _extract_shell_command_info("ls -la | grep test")
    assert cmd == "ls"
    assert wd is None

    # cd && command | pipe
    cmd, wd = _extract_shell_command_info("cd /tmp && ls -la | grep test")
    assert cmd == "ls"
    assert wd == "/tmp"


def test_shell_command_pattern_cd_only():
    """Test shell command pattern extraction for cd-only command."""
    from patchpal.tools.shell_tools import _extract_shell_command_info

    # Just cd
    cmd, wd = _extract_shell_command_info("cd /tmp")
    assert cmd == "cd"
    assert wd == "/tmp"


def test_shell_command_pattern_or_operator():
    """Test shell command pattern extraction with || operator."""
    from patchpal.tools.shell_tools import _extract_shell_command_info

    # Command with ||
    cmd, wd = _extract_shell_command_info("python test.py || echo failed")
    assert cmd == "python"
    assert wd is None


def test_shell_command_pattern_powershell():
    """Test PowerShell command pattern extraction."""
    from patchpal.tools.shell_tools import _extract_shell_command_info

    # powershell -Command "cmdlet"
    cmd, wd = _extract_shell_command_info('powershell -Command "Get-ChildItem"')
    assert cmd == "get-childitem"  # Should extract the cmdlet, not "powershell"
    assert wd is None

    # powershell -c "cmdlet" (short form)
    cmd, wd = _extract_shell_command_info('powershell -c "Select-String test"')
    assert cmd == "select-string"
    assert wd is None

    # pwsh (PowerShell Core) -Command
    cmd, wd = _extract_shell_command_info('pwsh -Command "Get-Process"')
    assert cmd == "get-process"
    assert wd is None

    # pwsh -c (short form)
    cmd, wd = _extract_shell_command_info('pwsh -c "Get-Location"')
    assert cmd == "get-location"
    assert wd is None

    # Case insensitive - PowerShell commands with mixed case
    cmd, wd = _extract_shell_command_info('PowerShell -Command "Get-ChildItem"')
    assert cmd == "get-childitem"
    assert wd is None

    # Without quotes
    cmd, wd = _extract_shell_command_info("powershell -Command Get-ChildItem")
    assert cmd == "get-childitem"
    assert wd is None


def test_shell_command_composite_pattern():
    """Test that run_shell creates correct composite patterns."""
    # We can't easily test run_shell directly due to permission prompts,
    # but we can verify the pattern format logic

    # Pattern for simple command (no cd)
    command_name, working_dir = "pytest", None
    pattern = f"{command_name}@{working_dir}" if working_dir and command_name else command_name
    assert pattern == "pytest"

    # Pattern for command with cd - using @ separator for cross-platform compatibility
    command_name, working_dir = "python", "/tmp"
    pattern = f"{command_name}@{working_dir}" if working_dir and command_name else command_name
    assert pattern == "python@/tmp"

    # Pattern for different directory
    command_name, working_dir = "python", "/home"
    pattern = f"{command_name}@{working_dir}" if working_dir and command_name else command_name
    assert pattern == "python@/home"

    # These should be different patterns (different directories)
    assert "python@/tmp" != "python@/home"

    # Test Windows path compatibility
    command_name, working_dir = "python", "C:\\temp"
    pattern = f"{command_name}@{working_dir}" if working_dir and command_name else command_name
    assert pattern == "python@C:\\temp"  # No ambiguity with @ separator


def test_permission_pattern_inside_repo(mock_repo, monkeypatch):
    """Test that files inside repo use relative path as pattern."""
    # Mock REPO_ROOT
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", mock_repo)

    from patchpal.tools.common import _get_permission_pattern_for_path

    # Test file inside repo - use resolved path like the actual code does
    test_file = (mock_repo / "src" / "app.py").resolve()
    pattern = _get_permission_pattern_for_path("src/app.py", test_file)

    assert pattern == "src/app.py"
    assert not pattern.endswith("/")


def test_permission_pattern_outside_repo_tmp(mock_repo, monkeypatch):
    """Test that files outside repo use directory name as pattern."""
    # Mock REPO_ROOT
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", mock_repo)

    from patchpal.tools.common import _get_permission_pattern_for_path

    # Test file in /tmp/ - use absolute resolved path
    tmp_file = Path("/tmp/test.py").resolve()
    pattern = _get_permission_pattern_for_path("../../../../../tmp/test.py", tmp_file)

    assert pattern == "tmp/"
    assert pattern.endswith("/")


def test_permission_pattern_outside_repo_home(mock_repo, monkeypatch):
    """Test path traversal to other directories."""
    # Mock REPO_ROOT
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", mock_repo)

    from patchpal.tools.common import _get_permission_pattern_for_path

    # Test file in /home/user/other/ - use absolute resolved path
    other_file = Path("/home/user/other/file.py").resolve()
    pattern = _get_permission_pattern_for_path("/home/user/other/file.py", other_file)

    assert pattern == "other/"
    assert pattern.endswith("/")


def test_permission_pattern_multiple_traversals_same_dir(mock_repo, monkeypatch):
    """Test that different path traversals to same directory produce same pattern."""
    # Mock REPO_ROOT
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", mock_repo)

    from patchpal.tools.common import _get_permission_pattern_for_path

    # Use resolved path like the actual code does
    tmp_file = Path("/tmp/test.py").resolve()

    # Different path traversals to /tmp/
    pattern1 = _get_permission_pattern_for_path("../../../../../tmp/test.py", tmp_file)
    pattern2 = _get_permission_pattern_for_path("../../tmp/test.py", tmp_file)

    # Both should produce same pattern
    assert pattern1 == pattern2 == "tmp/"


def test_write_file_uses_correct_pattern(mock_repo, monkeypatch, tmp_path):
    """Test that write_file uses directory-based pattern for outside-repo files."""
    # Setup
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", mock_repo)
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "true")
    monkeypatch.setenv("PATCHPAL_READ_ONLY", "false")

    # Reload to pick up env vars
    import importlib

    import patchpal.permissions
    import patchpal.tools
    import patchpal.tools.common

    importlib.reload(patchpal.permissions)
    importlib.reload(patchpal.tools.common)
    importlib.reload(patchpal.tools)

    # Re-apply repo root after reload
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", mock_repo)
    # Reset permission manager so it gets recreated with new settings
    patchpal.tools.common._permission_manager = None

    # Track what pattern is passed to permission request
    captured_pattern = {}

    def mock_request_permission(self, tool_name, description, pattern=None, context=None):
        captured_pattern["pattern"] = pattern
        return False  # Deny to prevent actual file write

    monkeypatch.setattr(
        "patchpal.permissions.PermissionManager.request_permission", mock_request_permission
    )

    from patchpal.tools import write_file

    # Test writing to /tmp/ using path traversal
    tmp_file = tmp_path / "test_outside.txt"
    write_file(str(tmp_file), "test content")

    # Should use directory pattern (last component of parent)
    assert captured_pattern["pattern"].endswith("/")


def test_edit_file_uses_correct_pattern(mock_repo, monkeypatch, tmp_path):
    """Test that edit_file uses directory-based pattern for outside-repo files."""
    # Setup
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", mock_repo)
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "true")
    monkeypatch.setenv("PATCHPAL_READ_ONLY", "false")

    # Reload to pick up env vars
    import importlib

    import patchpal.permissions
    import patchpal.tools
    import patchpal.tools.common

    importlib.reload(patchpal.permissions)
    importlib.reload(patchpal.tools.common)
    importlib.reload(patchpal.tools)

    # Re-apply repo root after reload
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", mock_repo)
    # Reset permission manager so it gets recreated with new settings
    patchpal.tools.common._permission_manager = None

    # Create test file outside repo
    test_file = tmp_path / "test_edit.txt"
    test_file.write_text("original content")

    # Track what pattern is passed to permission request
    captured_pattern = {}

    def mock_request_permission(self, tool_name, description, pattern=None, context=None):
        captured_pattern["pattern"] = pattern
        return False  # Deny to prevent actual edit

    monkeypatch.setattr(
        "patchpal.permissions.PermissionManager.request_permission", mock_request_permission
    )

    from patchpal.tools import edit_file

    # Test editing file outside repo
    edit_file(str(test_file), "original", "modified")

    # Should use directory pattern
    assert captured_pattern["pattern"].endswith("/")


def test_permission_pattern_consistency_across_tools(mock_repo, monkeypatch, tmp_path):
    """Test that write_file and edit_file use same pattern for same file."""
    # Setup
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", mock_repo)
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "true")
    monkeypatch.setenv("PATCHPAL_READ_ONLY", "false")

    # Reload to pick up env vars
    import importlib

    import patchpal.permissions
    import patchpal.tools
    import patchpal.tools.common

    importlib.reload(patchpal.permissions)
    importlib.reload(patchpal.tools.common)
    importlib.reload(patchpal.tools)

    # Re-apply repo root after reload
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", mock_repo)
    # Reset permission manager so it gets recreated with new settings
    patchpal.tools.common._permission_manager = None

    test_file = tmp_path / "consistency_test.txt"
    test_file.write_text("original")

    captured_patterns = []

    def mock_request_permission(self, tool_name, description, pattern=None, context=None):
        captured_patterns.append(pattern)
        return False

    monkeypatch.setattr(
        "patchpal.permissions.PermissionManager.request_permission", mock_request_permission
    )

    from patchpal.tools import edit_file, write_file

    # Try both tools on same file
    write_file(str(test_file), "new content")
    edit_file(str(test_file), "original", "modified")

    # Both should use same pattern
    assert len(captured_patterns) == 2
    assert captured_patterns[0] == captured_patterns[1]
    assert captured_patterns[0].endswith("/")


def test_harmless_command_with_flags():
    """Test that harmless commands with flags are automatically granted."""
    import tempfile
    from pathlib import Path

    from patchpal.permissions import PermissionManager

    with tempfile.TemporaryDirectory() as tmpdir:
        manager = PermissionManager(Path(tmpdir))

        # Test grep with -l flag (extracted by find -exec)
        # The harmless list has "grep", pattern will be "grep -l"
        assert manager._check_existing_grant("run_shell", pattern="grep -l")

        # Test sed with -n flag
        assert manager._check_existing_grant("run_shell", pattern="sed -n")

        # Test exact matches still work
        assert manager._check_existing_grant("run_shell", pattern="grep")
        assert manager._check_existing_grant("run_shell", pattern="find")

        # Test multi-word patterns still work
        assert manager._check_existing_grant(
            "run_shell", pattern="git status", full_command="git status --short"
        )

        # Test non-harmless command requires permission
        assert not manager._check_existing_grant("run_shell", pattern="dangerous-command")


def test_find_exec_extraction_with_cd():
    """Test that find -exec extraction works when preceded by cd."""
    from patchpal.tools.shell_tools import _extract_shell_command_info

    # Original issue: cd && find -exec should extract inner command
    cmd = 'cd ~/projects/ghub/patchpal && find . -exec grep -l "pattern" {} \\;'
    command_name, working_dir = _extract_shell_command_info(cmd)
    assert command_name == "grep -l"  # Should extract grep, not find
    assert working_dir == "~/projects/ghub/patchpal"


def test_composite_pattern_matching():
    """Test that composite patterns (command@directory) match harmless commands."""
    import tempfile
    from pathlib import Path

    from patchpal.permissions import PermissionManager

    with tempfile.TemporaryDirectory() as tmpdir:
        manager = PermissionManager(Path(tmpdir))

        # Composite patterns should match base commands
        assert manager._check_existing_grant("run_shell", pattern="find@~/projects/ghub/patchpal")
        assert manager._check_existing_grant("run_shell", pattern="grep -l@/tmp")
        assert manager._check_existing_grant("run_shell", pattern="ls@/home")

        # Non-harmless commands should not match
        assert not manager._check_existing_grant("run_shell", pattern="rm@/tmp")
