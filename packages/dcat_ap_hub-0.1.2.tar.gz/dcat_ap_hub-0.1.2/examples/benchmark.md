


(- landingpage: https://www.kaggle.com/datasets/canozensoy/industrial-iot-dataset-synthetic
- single distirbution download url: https://www.kaggle.com/api/v1/datasets/download/canozensoy/industrial-iot-dataset-synthetic?datasetVersionNumber=1)

- landingpage: https://www.kaggle.com/datasets/ziya07/industrial-iot-fault-detection-dataset
- single distibution download url: https://www.kaggle.com/api/v1/datasets/download/ziya07/industrial-iot-fault-detection-dataset?datasetVersionNumber=1

- landinpage: https://www.kaggle.com/datasets/ziya07/intelligent-manufacturing-dataset
- single distirbution url: https://www.kaggle.com/api/v1/datasets/download/ziya07/intelligent-manufacturing-dataset?datasetVersionNumber=1

- landingpage: https://www.kaggle.com/datasets/ziya07/iot-integrated-predictive-maintenance-dataset
- single dsitribution url: https://www.kaggle.com/api/v1/datasets/download/ziya07/iot-integrated-predictive-maintenance-dataset?datasetVersionNumber=1