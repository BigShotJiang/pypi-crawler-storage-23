PROCESSOR_PROFILE_URI = "http://example.org/profiles/Processor"

HF_METADATA_PROFILE_URI = "http://example.org/profiles/HuggingFaceMetadata"
ONNX_METADATA_PROFILE_URI = "http://example.org/profiles/OnnxMetadata"
SKLEARN_METADATA_PROFILE_URI = "http://example.org/profiles/SklearnMetadata"


HF_FORMAT = "https://huggingface.co/formats/repository"
ONNX_FORMAT = "ONNX"
