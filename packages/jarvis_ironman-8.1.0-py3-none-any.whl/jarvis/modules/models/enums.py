# noinspection PyUnresolvedReferences
"""Space for all Enums.

>>> Enums

"""

import sys

if sys.version_info.minor > 10:
    from enum import StrEnum
else:
    from enum import Enum

    class StrEnum(str, Enum):
        """Override for python 3.10 due to lack of StrEnum."""


class ProcessNames(StrEnum):
    """Process names used by Jarvis."""

    jarvis = "JARVIS"
    pre_commit = "pre_commit"
    startup_script = "startup_script"
    crontab_executor = "crontab_executor"

    offline = "OFFLINE"
    plot_mic = "plot_mic"
    jarvis_api = "jarvis_api"
    ui_process = "ui_process"
    telegram_api = "telegram_api"
    listener_widget = "listener_widget"
    background_tasks = "background_tasks"


class SupportedPlatforms(StrEnum):
    """Supported operating systems."""

    windows = "Windows"
    macOS = "Darwin"
    linux = "Linux"


class ReminderOptions(StrEnum):
    """Supported reminder options."""

    phone = "phone"
    email = "email"
    telegram = "telegram"
    ntfy = "ntfy"
    all = "all"


class StartupOptions(StrEnum):
    """Background threads to startup."""

    all = "all"
    gpt = "gpt"
    none = "None"
    thermostat = "thermostat"


class TemperatureUnits(StrEnum):
    """Types of temperature units supported by Jarvis.

    >>> TemperatureUnits

    """

    METRIC = "metric"
    IMPERIAL = "imperial"


class DistanceUnits(StrEnum):
    """Types of distance units supported by Jarvis.

    >>> DistanceUnits

    """

    MILES = "miles"
    KILOMETERS = "kilometers"


class EventApp(StrEnum):
    """Types of event applications supported by Jarvis.

    >>> EventApp

    """

    CALENDAR = "calendar"
    OUTLOOK = "outlook"


class SSQuality(StrEnum):
    """Quality modes available for speech synthesis.

    >>> SSQuality

    """

    High = "high"
    Medium = "medium"
    Low = "low"
