---
name: gofastmcp-docs
description: Agent skill for GoFastMCP documentation.
categories: [Documentation, Knowledge Base]
tags: [docs, gofastmcp-docs, reference]
---

# Gofastmcp Docs Documentation

Agent skill for GoFastMCP documentation.

## Reference Files

- [Low-Level API](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/apps_low-level.md)
- [Apps](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/apps_overview.md)
- [Changelog](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/changelog.md)
- [The FastMCP Client](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/clients_client.md)
- [Client Transports](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/clients_transports.md)
- [Contributing](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/development_contributing.md)
- [Releases](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/development_releases.md)
- [Tests](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/development_tests.md)
- [Installation](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/getting-started_installation.md)
- [Quickstart](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/getting-started_quickstart.md)
- [Welcome to FastMCP](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/getting-started_welcome.md)
- [Welcome to FastMCP](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/index.md)
- [Low-Level API](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/llms-full.txt.md)
- [FastMCP](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/llms.txt.md)
- [Contrib Modules](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/patterns_contrib.md)
- [Authorization](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/servers_authorization.md)
- [The FastMCP Server](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/servers_server.md)
- [FastMCP Updates](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skills/gofastmcp-docs/reference/updates.md)
