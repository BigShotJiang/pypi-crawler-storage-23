[ Skip to content ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_aimodelsopenrouter)
**Join us at the inaugural PyAI Conf in San Francisco on March 10th![Learn More](https://pyai.events/?utm_source=pydantic-ai) **
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI")
Pydantic AI
pydantic_ai.models.openrouter
Type to start searching
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI") Pydantic AI
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
  * [ Pydantic AI  ](https://ai.pydantic.dev/)
  * [ Installation  ](https://ai.pydantic.dev/install/)
  * [ Getting Help  ](https://ai.pydantic.dev/help/)
  * [ Troubleshooting  ](https://ai.pydantic.dev/troubleshooting/)
  * [ Pydantic AI Gateway  ](https://ai.pydantic.dev/gateway/)
  * Documentation
    * Core Concepts
      * [ Agents  ](https://ai.pydantic.dev/agent/)
      * [ Dependencies  ](https://ai.pydantic.dev/dependencies/)
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Output  ](https://ai.pydantic.dev/output/)
      * [ Messages and chat history  ](https://ai.pydantic.dev/message-history/)
      * [ Direct Model Requests  ](https://ai.pydantic.dev/direct/)
    * Models & Providers
      * [ Overview  ](https://ai.pydantic.dev/models/overview/)
      * [ OpenAI  ](https://ai.pydantic.dev/models/openai/)
      * [ Anthropic  ](https://ai.pydantic.dev/models/anthropic/)
      * [ Google  ](https://ai.pydantic.dev/models/google/)
      * [ xAI  ](https://ai.pydantic.dev/models/xai/)
      * [ Bedrock  ](https://ai.pydantic.dev/models/bedrock/)
      * [ Cerebras  ](https://ai.pydantic.dev/models/cerebras/)
      * [ Cohere  ](https://ai.pydantic.dev/models/cohere/)
      * [ Groq  ](https://ai.pydantic.dev/models/groq/)
      * [ Hugging Face  ](https://ai.pydantic.dev/models/huggingface/)
      * [ Mistral  ](https://ai.pydantic.dev/models/mistral/)
      * [ OpenRouter  ](https://ai.pydantic.dev/models/openrouter/)
      * [ Outlines  ](https://ai.pydantic.dev/models/outlines/)
    * Tools & Toolsets
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Advanced Tool Features  ](https://ai.pydantic.dev/tools-advanced/)
      * [ Toolsets  ](https://ai.pydantic.dev/toolsets/)
      * [ Deferred Tools  ](https://ai.pydantic.dev/deferred-tools/)
      * [ Built-in Tools  ](https://ai.pydantic.dev/builtin-tools/)
      * [ Common Tools  ](https://ai.pydantic.dev/common-tools/)
      * [ Third-Party Tools  ](https://ai.pydantic.dev/third-party-tools/)
    * Advanced Features
      * [ Image, Audio, Video & Document Input  ](https://ai.pydantic.dev/input/)
      * [ Thinking  ](https://ai.pydantic.dev/thinking/)
      * [ HTTP Request Retries  ](https://ai.pydantic.dev/retries/)
    * MCP
      * [ Overview  ](https://ai.pydantic.dev/mcp/overview/)
      * [ Client  ](https://ai.pydantic.dev/mcp/client/)
      * [ FastMCP Client  ](https://ai.pydantic.dev/mcp/fastmcp-client/)
      * [ Server  ](https://ai.pydantic.dev/mcp/server/)
    * [ Multi-Agent Patterns  ](https://ai.pydantic.dev/multi-agent-applications/)
    * [ Web Chat UI  ](https://ai.pydantic.dev/web/)
    * [ Embeddings  ](https://ai.pydantic.dev/embeddings/)
    * [ Testing  ](https://ai.pydantic.dev/testing/)
  * Pydantic Evals
    * [ Overview  ](https://ai.pydantic.dev/evals/)
    * Getting Started
      * [ Quick Start  ](https://ai.pydantic.dev/evals/quick-start/)
      * [ Core Concepts  ](https://ai.pydantic.dev/evals/core-concepts/)
    * Evaluators
      * [ Overview  ](https://ai.pydantic.dev/evals/evaluators/overview/)
      * [ Built-in Evaluators  ](https://ai.pydantic.dev/evals/evaluators/built-in/)
      * [ LLM Judge  ](https://ai.pydantic.dev/evals/evaluators/llm-judge/)
      * [ Custom Evaluators  ](https://ai.pydantic.dev/evals/evaluators/custom/)
      * [ Report Evaluators  ](https://ai.pydantic.dev/evals/evaluators/report-evaluators/)
      * [ Span-Based  ](https://ai.pydantic.dev/evals/evaluators/span-based/)
    * How-To Guides
      * [ Logfire Integration  ](https://ai.pydantic.dev/evals/how-to/logfire-integration/)
      * [ Dataset Management  ](https://ai.pydantic.dev/evals/how-to/dataset-management/)
      * [ Dataset Serialization  ](https://ai.pydantic.dev/evals/how-to/dataset-serialization/)
      * [ Concurrency & Performance  ](https://ai.pydantic.dev/evals/how-to/concurrency/)
      * [ Multi-Run Evaluation  ](https://ai.pydantic.dev/evals/how-to/multi-run/)
      * [ Retry Strategies  ](https://ai.pydantic.dev/evals/how-to/retry-strategies/)
      * [ Metrics & Attributes  ](https://ai.pydantic.dev/evals/how-to/metrics-attributes/)
    * Examples
      * [ Simple Validation  ](https://ai.pydantic.dev/evals/examples/simple-validation/)
  * Pydantic Graph
    * [ Overview  ](https://ai.pydantic.dev/graph/)
    * [ Beta API  ](https://ai.pydantic.dev/graph/beta/)
      * [ Steps  ](https://ai.pydantic.dev/graph/beta/steps/)
      * [ Joins & Reducers  ](https://ai.pydantic.dev/graph/beta/joins/)
      * [ Decisions  ](https://ai.pydantic.dev/graph/beta/decisions/)
      * [ Parallel Execution  ](https://ai.pydantic.dev/graph/beta/parallel/)
  * Integrations
    * [ Debugging & Monitoring with Pydantic Logfire  ](https://ai.pydantic.dev/logfire/)
    * Durable Execution
      * [ Overview  ](https://ai.pydantic.dev/durable_execution/overview/)
      * [ Temporal  ](https://ai.pydantic.dev/durable_execution/temporal/)
      * [ DBOS  ](https://ai.pydantic.dev/durable_execution/dbos/)
      * [ Prefect  ](https://ai.pydantic.dev/durable_execution/prefect/)
    * UI Event Streams
      * [ Overview  ](https://ai.pydantic.dev/ui/overview/)
      * [ AG-UI  ](https://ai.pydantic.dev/ui/ag-ui/)
      * [ Vercel AI  ](https://ai.pydantic.dev/ui/vercel-ai/)
    * [ Agent2Agent (A2A)  ](https://ai.pydantic.dev/a2a/)
  * Related Packages
    * [ clai  ](https://ai.pydantic.dev/cli/)
  * Examples
    * [ Setup  ](https://ai.pydantic.dev/examples/setup/)
    * Getting Started
      * [ Pydantic Model  ](https://ai.pydantic.dev/examples/pydantic-model/)
      * [ Weather agent  ](https://ai.pydantic.dev/examples/weather-agent/)
    * Conversational Agents
      * [ Chat App with FastAPI  ](https://ai.pydantic.dev/examples/chat-app/)
      * [ Bank support  ](https://ai.pydantic.dev/examples/bank-support/)
    * Data & Analytics
      * [ SQL Generation  ](https://ai.pydantic.dev/examples/sql-gen/)
      * [ Data Analyst  ](https://ai.pydantic.dev/examples/data-analyst/)
      * [ RAG  ](https://ai.pydantic.dev/examples/rag/)
    * Streaming
      * [ Stream markdown  ](https://ai.pydantic.dev/examples/stream-markdown/)
      * [ Stream whales  ](https://ai.pydantic.dev/examples/stream-whales/)
    * Complex Workflows
      * [ Flight booking  ](https://ai.pydantic.dev/examples/flight-booking/)
      * [ Question Graph  ](https://ai.pydantic.dev/examples/question-graph/)
    * Business Applications
      * [ Slack Lead Qualifier with Modal  ](https://ai.pydantic.dev/examples/slack-lead-qualifier/)
    * UI Examples
      * [ Agent User Interaction (AG-UI)  ](https://ai.pydantic.dev/examples/ag-ui/)
  * API Reference
    * pydantic_ai
      * [ pydantic_ai.ag_ui  ](https://ai.pydantic.dev/api/ag_ui/)
      * [ pydantic_ai.agent  ](https://ai.pydantic.dev/api/agent/)
      * [ pydantic_ai.builtin_tools  ](https://ai.pydantic.dev/api/builtin_tools/)
      * [ pydantic_ai.common_tools  ](https://ai.pydantic.dev/api/common_tools/)
      * [ pydantic_ai — Concurrency  ](https://ai.pydantic.dev/api/concurrency/)
      * [ pydantic_ai.direct  ](https://ai.pydantic.dev/api/direct/)
      * [ pydantic_ai.durable_exec  ](https://ai.pydantic.dev/api/durable_exec/)
      * [ pydantic_ai.embeddings  ](https://ai.pydantic.dev/api/embeddings/)
      * [ pydantic_ai.exceptions  ](https://ai.pydantic.dev/api/exceptions/)
      * [ pydantic_ai.ext  ](https://ai.pydantic.dev/api/ext/)
      * [ pydantic_ai.format_prompt  ](https://ai.pydantic.dev/api/format_prompt/)
      * [ pydantic_ai.mcp  ](https://ai.pydantic.dev/api/mcp/)
      * [ pydantic_ai.messages  ](https://ai.pydantic.dev/api/messages/)
      * [ pydantic_ai.models.anthropic  ](https://ai.pydantic.dev/api/models/anthropic/)
      * [ pydantic_ai.models  ](https://ai.pydantic.dev/api/models/base/)
      * [ pydantic_ai.models.bedrock  ](https://ai.pydantic.dev/api/models/bedrock/)
      * [ pydantic_ai.models.cerebras  ](https://ai.pydantic.dev/api/models/cerebras/)
      * [ pydantic_ai.models.cohere  ](https://ai.pydantic.dev/api/models/cohere/)
      * [ pydantic_ai.models.fallback  ](https://ai.pydantic.dev/api/models/fallback/)
      * [ pydantic_ai.models.function  ](https://ai.pydantic.dev/api/models/function/)
      * [ pydantic_ai.models.google  ](https://ai.pydantic.dev/api/models/google/)
      * [ pydantic_ai.models.xai  ](https://ai.pydantic.dev/api/models/xai/)
      * [ pydantic_ai.models.groq  ](https://ai.pydantic.dev/api/models/groq/)
      * [ pydantic_ai.models.huggingface  ](https://ai.pydantic.dev/api/models/huggingface/)
      * [ pydantic_ai.models.instrumented  ](https://ai.pydantic.dev/api/models/instrumented/)
      * [ pydantic_ai.models.mcp_sampling  ](https://ai.pydantic.dev/api/models/mcp-sampling/)
      * [ pydantic_ai.models.mistral  ](https://ai.pydantic.dev/api/models/mistral/)
      * [ pydantic_ai.models.openai  ](https://ai.pydantic.dev/api/models/openai/)
      * pydantic_ai.models.openrouter  [ pydantic_ai.models.openrouter  ](https://ai.pydantic.dev/api/models/openrouter/)
        * [ Setup  ](https://ai.pydantic.dev/api/models/openrouter/#setup)
          * [ openrouter  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter)
          * [ KnownOpenRouterProviders  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.KnownOpenRouterProviders)
          * [ OpenRouterProviderName  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderName)
          * [ OpenRouterTransforms  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterTransforms)
          * [ OpenRouterProviderConfig  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig)
            * [ order  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.order)
            * [ allow_fallbacks  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.allow_fallbacks)
            * [ require_parameters  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.require_parameters)
            * [ data_collection  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.data_collection)
            * [ zdr  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.zdr)
            * [ only  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.only)
            * [ ignore  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.ignore)
            * [ quantizations  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.quantizations)
            * [ sort  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.sort)
            * [ max_price  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.max_price)
          * [ OpenRouterReasoning  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning)
            * [ effort  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning.effort)
            * [ max_tokens  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning.max_tokens)
            * [ exclude  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning.exclude)
            * [ enabled  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning.enabled)
          * [ OpenRouterUsageConfig  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterUsageConfig)
          * [ OpenRouterModelSettings  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings)
            * [ openrouter_models  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_models)
            * [ openrouter_provider  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_provider)
            * [ openrouter_preset  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_preset)
            * [ openrouter_transforms  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_transforms)
            * [ openrouter_reasoning  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_reasoning)
            * [ openrouter_usage  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_usage)
          * [ OpenRouterModel  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModel)
            * [ __init__  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModel.__init__)
          * [ OpenRouterStreamedResponse  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterStreamedResponse)
      * [ pydantic_ai.models.outlines  ](https://ai.pydantic.dev/api/models/outlines/)
      * [ pydantic_ai.models.test  ](https://ai.pydantic.dev/api/models/test/)
      * [ pydantic_ai.models.wrapper  ](https://ai.pydantic.dev/api/models/wrapper/)
      * [ pydantic_ai.output  ](https://ai.pydantic.dev/api/output/)
      * [ pydantic_ai.profiles  ](https://ai.pydantic.dev/api/profiles/)
      * [ pydantic_ai.providers  ](https://ai.pydantic.dev/api/providers/)
      * [ pydantic_ai.result  ](https://ai.pydantic.dev/api/result/)
      * [ pydantic_ai.retries  ](https://ai.pydantic.dev/api/retries/)
      * [ pydantic_ai.run  ](https://ai.pydantic.dev/api/run/)
      * [ pydantic_ai.settings  ](https://ai.pydantic.dev/api/settings/)
      * [ pydantic_ai.tools  ](https://ai.pydantic.dev/api/tools/)
      * [ pydantic_ai.toolsets  ](https://ai.pydantic.dev/api/toolsets/)
      * [ pydantic_ai.ui.ag_ui  ](https://ai.pydantic.dev/api/ui/ag_ui/)
      * [ pydantic_ai.ui  ](https://ai.pydantic.dev/api/ui/base/)
      * [ pydantic_ai.ui.vercel_ai  ](https://ai.pydantic.dev/api/ui/vercel_ai/)
      * [ pydantic_ai.usage  ](https://ai.pydantic.dev/api/usage/)
    * pydantic_evals
      * [ pydantic_evals.dataset  ](https://ai.pydantic.dev/api/pydantic_evals/dataset/)
      * [ pydantic_evals.evaluators  ](https://ai.pydantic.dev/api/pydantic_evals/evaluators/)
      * [ pydantic_evals.reporting  ](https://ai.pydantic.dev/api/pydantic_evals/reporting/)
      * [ pydantic_evals.otel  ](https://ai.pydantic.dev/api/pydantic_evals/otel/)
      * [ pydantic_evals.generation  ](https://ai.pydantic.dev/api/pydantic_evals/generation/)
    * pydantic_graph
      * [ pydantic_graph  ](https://ai.pydantic.dev/api/pydantic_graph/graph/)
      * [ pydantic_graph.nodes  ](https://ai.pydantic.dev/api/pydantic_graph/nodes/)
      * [ pydantic_graph.persistence  ](https://ai.pydantic.dev/api/pydantic_graph/persistence/)
      * [ pydantic_graph.mermaid  ](https://ai.pydantic.dev/api/pydantic_graph/mermaid/)
      * [ pydantic_graph.exceptions  ](https://ai.pydantic.dev/api/pydantic_graph/exceptions/)
      * Beta API
        * [ pydantic_graph.beta  ](https://ai.pydantic.dev/api/pydantic_graph/beta/)
        * [ pydantic_graph.beta.graph  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph/)
        * [ pydantic_graph.beta.graph_builder  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph_builder/)
        * [ pydantic_graph.beta.step  ](https://ai.pydantic.dev/api/pydantic_graph/beta_step/)
        * [ pydantic_graph.beta.join  ](https://ai.pydantic.dev/api/pydantic_graph/beta_join/)
        * [ pydantic_graph.beta.decision  ](https://ai.pydantic.dev/api/pydantic_graph/beta_decision/)
        * [ pydantic_graph.beta.node  ](https://ai.pydantic.dev/api/pydantic_graph/beta_node/)
    * fasta2a
      * [ fasta2a  ](https://ai.pydantic.dev/api/fasta2a/)
  * Project
    * [ Contributing  ](https://ai.pydantic.dev/contributing/)
    * [ Upgrade Guide  ](https://ai.pydantic.dev/changelog/)
    * [ Version policy  ](https://ai.pydantic.dev/version-policy/)


  * [ Setup  ](https://ai.pydantic.dev/api/models/openrouter/#setup)
    * [ openrouter  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter)
    * [ KnownOpenRouterProviders  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.KnownOpenRouterProviders)
    * [ OpenRouterProviderName  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderName)
    * [ OpenRouterTransforms  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterTransforms)
    * [ OpenRouterProviderConfig  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig)
      * [ order  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.order)
      * [ allow_fallbacks  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.allow_fallbacks)
      * [ require_parameters  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.require_parameters)
      * [ data_collection  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.data_collection)
      * [ zdr  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.zdr)
      * [ only  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.only)
      * [ ignore  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.ignore)
      * [ quantizations  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.quantizations)
      * [ sort  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.sort)
      * [ max_price  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig.max_price)
    * [ OpenRouterReasoning  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning)
      * [ effort  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning.effort)
      * [ max_tokens  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning.max_tokens)
      * [ exclude  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning.exclude)
      * [ enabled  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning.enabled)
    * [ OpenRouterUsageConfig  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterUsageConfig)
    * [ OpenRouterModelSettings  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings)
      * [ openrouter_models  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_models)
      * [ openrouter_provider  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_provider)
      * [ openrouter_preset  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_preset)
      * [ openrouter_transforms  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_transforms)
      * [ openrouter_reasoning  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_reasoning)
      * [ openrouter_usage  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModelSettings.openrouter_usage)
    * [ OpenRouterModel  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModel)
      * [ __init__  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterModel.__init__)
    * [ OpenRouterStreamedResponse  ](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterStreamedResponse)


  1. [ Pydantic AI  ](https://ai.pydantic.dev/)
  2. [ API Reference  ](https://ai.pydantic.dev/api/ag_ui/)
  3. [ pydantic_ai  ](https://ai.pydantic.dev/api/ag_ui/)


# `pydantic_ai.models.openrouter`
## Setup
For details on how to set up authentication with this model, see [model configuration for OpenRouter](https://ai.pydantic.dev/models/openrouter/).
###  KnownOpenRouterProviders `module-attribute`
```
KnownOpenRouterProviders = Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[
    "z-ai",
    "cerebras",
    "venice",
    "moonshotai",
    "morph",
    "stealth",
    "wandb",
    "klusterai",
    "openai",
    "sambanova",
    "amazon-bedrock",
    "mistral",
    "nextbit",
    "atoma",
    "ai21",
    "minimax",
    "baseten",
    "anthropic",
    "featherless",
    "groq",
    "lambda",
    "azure",
    "ncompass",
    "deepseek",
    "hyperbolic",
    "crusoe",
    "cohere",
    "mancer",
    "avian",
    "perplexity",
    "novita",
    "siliconflow",
    "switchpoint",
    "xai",
    "inflection",
    "fireworks",
    "deepinfra",
    "inference-net",
    "inception",
    "atlas-cloud",
    "nvidia",
    "alibaba",
    "friendli",
    "infermatic",
    "targon",
    "ubicloud",
    "aion-labs",
    "liquid",
    "nineteen",
    "cloudflare",
    "nebius",
    "chutes",
    "enfer",
    "crofai",
    "open-inference",
    "phala",
    "gmicloud",
    "meta",
    "relace",
    "parasail",
    "together",
    "google-ai-studio",
    "google-vertex",
]

```

Known providers in the OpenRouter marketplace
###  OpenRouterProviderName `module-attribute`
```
OpenRouterProviderName = str[](https://docs.python.org/3/library/stdtypes.html#str) | KnownOpenRouterProviders[](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.KnownOpenRouterProviders "KnownOpenRouterProviders



      module-attribute
   \(pydantic_ai.models.openrouter.KnownOpenRouterProviders\)")

```

Possible OpenRouter provider names.
Since OpenRouter is constantly updating their list of providers, we explicitly list some known providers but allow any name in the type hints. See [the OpenRouter API](https://openrouter.ai/docs/api-reference/list-available-providers) for a full list.
###  OpenRouterTransforms `module-attribute`
```
OpenRouterTransforms = Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['middle-out']

```

Available messages transforms for OpenRouter models with limited token windows.
Currently only supports 'middle-out', but is expected to grow in the future.
###  OpenRouterProviderConfig
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Represents the 'Provider' object from the OpenRouter API.
Source code in `pydantic_ai_slim/pydantic_ai/models/openrouter.py`
```
156
157
158
159
160
161
162
163
164
165
166
167
168
169
170
171
172
173
174
175
176
177
178
179
180
181
182
183
184
185
186
187
```
| ```
class OpenRouterProviderConfig(TypedDict, total=False):
    """Represents the 'Provider' object from the OpenRouter API."""

    order: list[OpenRouterProviderName]
    """List of provider slugs to try in order (e.g. ["anthropic", "openai"]). [See details](https://openrouter.ai/docs/features/provider-routing#ordering-specific-providers)"""

    allow_fallbacks: bool
    """Whether to allow backup providers when the primary is unavailable. [See details](https://openrouter.ai/docs/features/provider-routing#disabling-fallbacks)"""

    require_parameters: bool
    """Only use providers that support all parameters in your request."""

    data_collection: Literal['allow', 'deny']
    """Control whether to use providers that may store data. [See details](https://openrouter.ai/docs/features/provider-routing#requiring-providers-to-comply-with-data-policies)"""

    zdr: bool
    """Restrict routing to only ZDR (Zero Data Retention) endpoints. [See details](https://openrouter.ai/docs/features/provider-routing#zero-data-retention-enforcement)"""

    only: list[OpenRouterProviderName]
    """List of provider slugs to allow for this request. [See details](https://openrouter.ai/docs/features/provider-routing#allowing-only-specific-providers)"""

    ignore: list[str]
    """List of provider slugs to skip for this request. [See details](https://openrouter.ai/docs/features/provider-routing#ignoring-providers)"""

    quantizations: list[Literal['int4', 'int8', 'fp4', 'fp6', 'fp8', 'fp16', 'bf16', 'fp32', 'unknown']]
    """List of quantization levels to filter by (e.g. ["int4", "int8"]). [See details](https://openrouter.ai/docs/features/provider-routing#quantization)"""

    sort: Literal['price', 'throughput', 'latency']
    """Sort providers by price or throughput. (e.g. "price" or "throughput"). [See details](https://openrouter.ai/docs/features/provider-routing#provider-sorting)"""

    max_price: _OpenRouterMaxPrice
    """The maximum pricing you want to pay for this request. [See details](https://openrouter.ai/docs/features/provider-routing#max-price)"""

```

---|---
####  order `instance-attribute`
```
order: list[](https://docs.python.org/3/library/stdtypes.html#list)[OpenRouterProviderName[](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderName "OpenRouterProviderName



      module-attribute
   \(pydantic_ai.models.openrouter.OpenRouterProviderName\)")]

```

List of provider slugs to try in order (e.g. ["anthropic", "openai"]). [See details](https://openrouter.ai/docs/features/provider-routing#ordering-specific-providers)
####  allow_fallbacks `instance-attribute`
```
allow_fallbacks: bool[](https://docs.python.org/3/library/functions.html#bool)

```

Whether to allow backup providers when the primary is unavailable. [See details](https://openrouter.ai/docs/features/provider-routing#disabling-fallbacks)
####  require_parameters `instance-attribute`
```
require_parameters: bool[](https://docs.python.org/3/library/functions.html#bool)

```

Only use providers that support all parameters in your request.
####  data_collection `instance-attribute`
```
data_collection: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['allow', 'deny']

```

Control whether to use providers that may store data. [See details](https://openrouter.ai/docs/features/provider-routing#requiring-providers-to-comply-with-data-policies)
####  zdr `instance-attribute`
```
zdr: bool[](https://docs.python.org/3/library/functions.html#bool)

```

Restrict routing to only ZDR (Zero Data Retention) endpoints. [See details](https://openrouter.ai/docs/features/provider-routing#zero-data-retention-enforcement)
####  only `instance-attribute`
```
only: list[](https://docs.python.org/3/library/stdtypes.html#list)[OpenRouterProviderName[](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderName "OpenRouterProviderName



      module-attribute
   \(pydantic_ai.models.openrouter.OpenRouterProviderName\)")]

```

List of provider slugs to allow for this request. [See details](https://openrouter.ai/docs/features/provider-routing#allowing-only-specific-providers)
####  ignore `instance-attribute`
```
ignore: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

List of provider slugs to skip for this request. [See details](https://openrouter.ai/docs/features/provider-routing#ignoring-providers)
####  quantizations `instance-attribute`
```
quantizations: list[](https://docs.python.org/3/library/stdtypes.html#list)[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[
        "int4",
        "int8",
        "fp4",
        "fp6",
        "fp8",
        "fp16",
        "bf16",
        "fp32",
        "unknown",
    ]
]

```

List of quantization levels to filter by (e.g. ["int4", "int8"]). [See details](https://openrouter.ai/docs/features/provider-routing#quantization)
####  sort `instance-attribute`
```
sort: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['price', 'throughput', 'latency']

```

Sort providers by price or throughput. (e.g. "price" or "throughput"). [See details](https://openrouter.ai/docs/features/provider-routing#provider-sorting)
####  max_price `instance-attribute`
```
max_price: _OpenRouterMaxPrice

```

The maximum pricing you want to pay for this request. [See details](https://openrouter.ai/docs/features/provider-routing#max-price)
###  OpenRouterReasoning
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Configuration for reasoning tokens in OpenRouter requests.
Reasoning tokens allow models to show their step-by-step thinking process. You can configure this using either OpenAI-style effort levels or Anthropic-style token limits, but not both simultaneously.
Source code in `pydantic_ai_slim/pydantic_ai/models/openrouter.py`
```
190
191
192
193
194
195
196
197
198
199
200
201
202
203
204
205
206
207
208
```
| ```
class OpenRouterReasoning(TypedDict, total=False):
    """Configuration for reasoning tokens in OpenRouter requests.

    Reasoning tokens allow models to show their step-by-step thinking process.
    You can configure this using either OpenAI-style effort levels or Anthropic-style
    token limits, but not both simultaneously.
    """

    effort: Literal['high', 'medium', 'low']
    """OpenAI-style reasoning effort level. Cannot be used with max_tokens."""

    max_tokens: int
    """Anthropic-style specific token limit for reasoning. Cannot be used with effort."""

    exclude: bool
    """Whether to exclude reasoning tokens from the response. Default is False. All models support this."""

    enabled: bool
    """Whether to enable reasoning with default parameters. Default is inferred from effort or max_tokens."""

```

---|---
####  effort `instance-attribute`
```
effort: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['high', 'medium', 'low']

```

OpenAI-style reasoning effort level. Cannot be used with max_tokens.
####  max_tokens `instance-attribute`
```
max_tokens: int[](https://docs.python.org/3/library/functions.html#int)

```

Anthropic-style specific token limit for reasoning. Cannot be used with effort.
####  exclude `instance-attribute`
```
exclude: bool[](https://docs.python.org/3/library/functions.html#bool)

```

Whether to exclude reasoning tokens from the response. Default is False. All models support this.
####  enabled `instance-attribute`
```
enabled: bool[](https://docs.python.org/3/library/functions.html#bool)

```

Whether to enable reasoning with default parameters. Default is inferred from effort or max_tokens.
###  OpenRouterUsageConfig
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Configuration for OpenRouter usage.
Source code in `pydantic_ai_slim/pydantic_ai/models/openrouter.py`
```
211
212
213
214
```
| ```
class OpenRouterUsageConfig(TypedDict, total=False):
    """Configuration for OpenRouter usage."""

    include: bool

```

---|---
###  OpenRouterModelSettings
Bases: `ModelSettings[](https://ai.pydantic.dev/api/settings/#pydantic_ai.settings.ModelSettings "ModelSettings \(pydantic_ai.settings.ModelSettings\)")`
Settings used for an OpenRouter model request.
Source code in `pydantic_ai_slim/pydantic_ai/models/openrouter.py`
```
217
218
219
220
221
222
223
224
225
226
227
228
229
230
231
232
233
234
235
236
237
238
239
240
241
242
243
244
245
246
247
248
249
250
251
252
253
254
```
| ```
class OpenRouterModelSettings(ModelSettings, total=False):
    """Settings used for an OpenRouter model request."""

    # ALL FIELDS MUST BE `openrouter_` PREFIXED SO YOU CAN MERGE THEM WITH OTHER MODELS.

    openrouter_models: list[str]
    """A list of fallback models.

    These models will be tried, in order, if the main model returns an error. [See details](https://openrouter.ai/docs/features/model-routing#the-models-parameter)
    """

    openrouter_provider: OpenRouterProviderConfig
    """OpenRouter routes requests to the best available providers for your model. By default, requests are load balanced across the top providers to maximize uptime.

    You can customize how your requests are routed using the provider object. [See more](https://openrouter.ai/docs/features/provider-routing)"""

    openrouter_preset: str
    """Presets allow you to separate your LLM configuration from your code.

    Create and manage presets through the OpenRouter web application to control provider routing, model selection, system prompts, and other parameters, then reference them in OpenRouter API requests. [See more](https://openrouter.ai/docs/features/presets)"""

    openrouter_transforms: list[OpenRouterTransforms]
    """To help with prompts that exceed the maximum context size of a model.

    Transforms work by removing or truncating messages from the middle of the prompt, until the prompt fits within the model's context window. [See more](https://openrouter.ai/docs/features/message-transforms)
    """

    openrouter_reasoning: OpenRouterReasoning
    """To control the reasoning tokens in the request.

    The reasoning config object consolidates settings for controlling reasoning strength across different models. [See more](https://openrouter.ai/docs/use-cases/reasoning-tokens)
    """

    openrouter_usage: OpenRouterUsageConfig
    """To control the usage of the model.

    The usage config object consolidates settings for enabling detailed usage information. [See more](https://openrouter.ai/docs/use-cases/usage-accounting)
    """

```

---|---
####  openrouter_models `instance-attribute`
```
openrouter_models: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

A list of fallback models.
These models will be tried, in order, if the main model returns an error. [See details](https://openrouter.ai/docs/features/model-routing#the-models-parameter)
####  openrouter_provider `instance-attribute`
```
openrouter_provider: OpenRouterProviderConfig[](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterProviderConfig "OpenRouterProviderConfig \(pydantic_ai.models.openrouter.OpenRouterProviderConfig\)")

```

OpenRouter routes requests to the best available providers for your model. By default, requests are load balanced across the top providers to maximize uptime.
You can customize how your requests are routed using the provider object. [See more](https://openrouter.ai/docs/features/provider-routing)
####  openrouter_preset `instance-attribute`
```
openrouter_preset: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

Presets allow you to separate your LLM configuration from your code.
Create and manage presets through the OpenRouter web application to control provider routing, model selection, system prompts, and other parameters, then reference them in OpenRouter API requests. [See more](https://openrouter.ai/docs/features/presets)
####  openrouter_transforms `instance-attribute`
```
openrouter_transforms: list[](https://docs.python.org/3/library/stdtypes.html#list)[OpenRouterTransforms[](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterTransforms "OpenRouterTransforms



      module-attribute
   \(pydantic_ai.models.openrouter.OpenRouterTransforms\)")]

```

To help with prompts that exceed the maximum context size of a model.
Transforms work by removing or truncating messages from the middle of the prompt, until the prompt fits within the model's context window. [See more](https://openrouter.ai/docs/features/message-transforms)
####  openrouter_reasoning `instance-attribute`
```
openrouter_reasoning: OpenRouterReasoning[](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterReasoning "OpenRouterReasoning \(pydantic_ai.models.openrouter.OpenRouterReasoning\)")

```

To control the reasoning tokens in the request.
The reasoning config object consolidates settings for controlling reasoning strength across different models. [See more](https://openrouter.ai/docs/use-cases/reasoning-tokens)
####  openrouter_usage `instance-attribute`
```
openrouter_usage: OpenRouterUsageConfig[](https://ai.pydantic.dev/api/models/openrouter/#pydantic_ai.models.openrouter.OpenRouterUsageConfig "OpenRouterUsageConfig \(pydantic_ai.models.openrouter.OpenRouterUsageConfig\)")

```

To control the usage of the model.
The usage config object consolidates settings for enabling detailed usage information. [See more](https://openrouter.ai/docs/use-cases/usage-accounting)
###  OpenRouterModel
Bases: `OpenAIChatModel[](https://ai.pydantic.dev/api/models/openai/#pydantic_ai.models.openai.OpenAIChatModel "OpenAIChatModel



      dataclass
   \(pydantic_ai.models.openai.OpenAIChatModel\)")`
Extends OpenAIModel to capture extra metadata for Openrouter.
Source code in `pydantic_ai_slim/pydantic_ai/models/openrouter.py`
```
535
536
537
538
539
540
541
542
543
544
545
546
547
548
549
550
551
552
553
554
555
556
557
558
559
560
561
562
563
564
565
566
567
568
569
570
571
572
573
574
575
576
577
578
579
580
581
582
583
584
585
586
587
588
589
590
591
592
593
594
595
596
597
598
599
600
601
602
603
604
605
606
607
608
609
610
611
612
613
614
615
616
617
618
619
620
621
622
623
624
625
626
627
628
629
630
631
632
633
634
635
636
637
638
639
640
641
642
643
644
645
646
```
| ```
class OpenRouterModel(OpenAIChatModel):
    """Extends OpenAIModel to capture extra metadata for Openrouter."""

    def __init__(
        self,
        model_name: str,
        *,
        provider: Literal['openrouter'] | Provider[AsyncOpenAI] = 'openrouter',
        profile: ModelProfileSpec | None = None,
        settings: ModelSettings | None = None,
    ):
        """Initialize an OpenRouter model.

        Args:
            model_name: The name of the model to use.
            provider: The provider to use for authentication and API access. If not provided, a new provider will be created with the default settings.
            profile: The model profile to use. Defaults to a profile picked by the provider based on the model name.
            settings: Model-specific settings that will be used as defaults for this model.
        """
        super().__init__(model_name, provider=provider or OpenRouterProvider(), profile=profile, settings=settings)

    @override
    def prepare_request(
        self,
        model_settings: ModelSettings | None,
        model_request_parameters: ModelRequestParameters,
    ) -> tuple[ModelSettings | None, ModelRequestParameters]:
        merged_settings, customized_parameters = super().prepare_request(model_settings, model_request_parameters)
        new_settings = _openrouter_settings_to_openai_settings(cast(OpenRouterModelSettings, merged_settings or {}))
        return new_settings, customized_parameters

    @override
    def _validate_completion(self, response: chat.ChatCompletion) -> _OpenRouterChatCompletion:
        response = _OpenRouterChatCompletion.model_validate(response.model_dump())

        if error := response.error:
            raise ModelHTTPError(status_code=error.code, model_name=response.model, body=error.message)

        return response

    @override
    def _process_thinking(self, message: chat.ChatCompletionMessage) -> list[ThinkingPart] | None:
        assert isinstance(message, _OpenRouterCompletionMessage)

        if reasoning_details := message.reasoning_details:
            return [_from_reasoning_detail(detail) for detail in reasoning_details]
        else:
            return super()._process_thinking(message)

    @override
    def _process_provider_details(self, response: chat.ChatCompletion) -> dict[str, Any] | None:
        assert isinstance(response, _OpenRouterChatCompletion)

        provider_details = super()._process_provider_details(response) or {}
        provider_details.update(_map_openrouter_provider_details(response))
        return provider_details or None

    @dataclass
    class _MapModelResponseContext(OpenAIChatModel._MapModelResponseContext):  # type: ignore[reportPrivateUsage]
        reasoning_details: list[dict[str, Any]] = field(default_factory=list[dict[str, Any]])

        def _into_message_param(self) -> chat.ChatCompletionAssistantMessageParam:
            message_param = super()._into_message_param()
            if self.reasoning_details:
                message_param['reasoning_details'] = self.reasoning_details  # type: ignore[reportGeneralTypeIssues]
            return message_param

        @override
        def _map_response_thinking_part(self, item: ThinkingPart) -> None:
            assert isinstance(self._model, OpenRouterModel)
            if item.provider_name == self._model.system:
                if reasoning_detail := _into_reasoning_detail(item):  # pragma: lax no cover
                    self.reasoning_details.append(reasoning_detail.model_dump())
            else:  # pragma: lax no cover
                super()._map_response_thinking_part(item)

    @property
    @override
    def _streamed_response_cls(self):
        return OpenRouterStreamedResponse

    @override
    async def _map_binary_content_item(self, item: BinaryContent) -> ChatCompletionContentPartParam:
        """Map a BinaryContent item to a chat completion content part for OpenRouter."""
        if item.is_video:
            video_url: _VideoURL = {'url': item.data_uri}
            return cast(
                ChatCompletionContentPartParam,
                _ChatCompletionContentPartVideoUrlParam(video_url=video_url, type='video_url'),
            )

        return await super()._map_binary_content_item(item)

    @override
    async def _map_video_url_item(self, item: VideoUrl) -> ChatCompletionContentPartParam:
        """Map a VideoUrl to a chat completion content part for OpenRouter."""
        video_url: _VideoURL = {'url': item.url}
        if item.force_download:
            video_content = await download_item(item, data_format='base64_uri', type_format='extension')
            video_url['url'] = video_content['data']
        # OpenRouter extends OpenAI's API to support video_url, but it's not in the OpenAI client types.
        # At runtime, the OpenAI client accepts dicts that match the expected structure.
        return cast(
            ChatCompletionContentPartParam,
            _ChatCompletionContentPartVideoUrlParam(video_url=video_url, type='video_url'),
        )

    @override
    def _map_finish_reason(  # type: ignore[reportIncompatibleMethodOverride]
        self, key: Literal['stop', 'length', 'tool_calls', 'content_filter', 'error']
    ) -> FinishReason | None:
        return _CHAT_FINISH_REASON_MAP.get(key)

```

---|---
####  __init__
```
__init__(
    model_name: str[](https://docs.python.org/3/library/stdtypes.html#str),
    *,
    provider: (
        Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["openrouter"] | Provider[](https://ai.pydantic.dev/api/providers/#pydantic_ai.providers.Provider "pydantic_ai.providers.Provider")[AsyncOpenAI]
    ) = "openrouter",
    profile: ModelProfileSpec | None = None,
    settings: ModelSettings[](https://ai.pydantic.dev/api/settings/#pydantic_ai.settings.ModelSettings "ModelSettings \(pydantic_ai.settings.ModelSettings\)") | None = None
)

```

Initialize an OpenRouter model.
Parameters:
Name | Type | Description | Default
---|---|---|---
`model_name` |  `str[](https://docs.python.org/3/library/stdtypes.html#str)` |  The name of the model to use. |  _required_
`provider` |  `Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['openrouter'] | Provider[](https://ai.pydantic.dev/api/providers/#pydantic_ai.providers.Provider "pydantic_ai.providers.Provider")[AsyncOpenAI]` |  The provider to use for authentication and API access. If not provided, a new provider will be created with the default settings. |  `'openrouter'`
`profile` |  `ModelProfileSpec | None` |  The model profile to use. Defaults to a profile picked by the provider based on the model name. |  `None`
`settings` |  `ModelSettings[](https://ai.pydantic.dev/api/settings/#pydantic_ai.settings.ModelSettings "ModelSettings \(pydantic_ai.settings.ModelSettings\)") | None` |  Model-specific settings that will be used as defaults for this model. |  `None`
Source code in `pydantic_ai_slim/pydantic_ai/models/openrouter.py`
```
538
539
540
541
542
543
544
545
546
547
548
549
550
551
552
553
554
```
| ```
def __init__(
    self,
    model_name: str,
    *,
    provider: Literal['openrouter'] | Provider[AsyncOpenAI] = 'openrouter',
    profile: ModelProfileSpec | None = None,
    settings: ModelSettings | None = None,
):
    """Initialize an OpenRouter model.

    Args:
        model_name: The name of the model to use.
        provider: The provider to use for authentication and API access. If not provided, a new provider will be created with the default settings.
        profile: The model profile to use. Defaults to a profile picked by the provider based on the model name.
        settings: Model-specific settings that will be used as defaults for this model.
    """
    super().__init__(model_name, provider=provider or OpenRouterProvider(), profile=profile, settings=settings)

```

---|---
###  OpenRouterStreamedResponse `dataclass`
Bases: `OpenAIStreamedResponse[](https://ai.pydantic.dev/api/models/openai/#pydantic_ai.models.openai.OpenAIStreamedResponse "OpenAIStreamedResponse



      dataclass
   \(pydantic_ai.models.openai.OpenAIStreamedResponse\)")`
Implementation of `StreamedResponse` for OpenRouter models.
Source code in `pydantic_ai_slim/pydantic_ai/models/openrouter.py`
```
691
692
693
694
695
696
697
698
699
700
701
702
703
704
705
706
707
708
709
710
711
712
713
714
715
716
717
718
719
720
721
722
723
724
725
726
727
728
729
730
731
732
733
734
735
736
737
738
739
740
```
| ```
@dataclass
class OpenRouterStreamedResponse(OpenAIStreamedResponse):
    """Implementation of `StreamedResponse` for OpenRouter models."""

    @override
    async def _validate_response(self):
        try:
            async for chunk in self._response:
                yield _OpenRouterChatCompletionChunk.model_validate(chunk.model_dump())
        except APIError as e:
            error = _OpenRouterError.model_validate(e.body)
            raise ModelHTTPError(status_code=error.code, model_name=self._model_name, body=error.message)

    @override
    def _map_thinking_delta(self, choice: chat_completion_chunk.Choice) -> Iterable[ModelResponseStreamEvent]:
        assert isinstance(choice, _OpenRouterChunkChoice)

        if reasoning_details := choice.delta.reasoning_details:
            for i, detail in enumerate(reasoning_details):
                thinking_part = _from_reasoning_detail(detail)
                # Use unique vendor_part_id for each reasoning detail type to prevent
                # different detail types (e.g., reasoning.text, reasoning.encrypted)
                # from being incorrectly merged into a single ThinkingPart.
                # This is required for Gemini 3 Pro which returns multiple reasoning
                # detail types that must be preserved separately for thought_signature handling.
                vendor_id = f'reasoning_detail_{detail.type}_{i}'
                yield from self._parts_manager.handle_thinking_delta(
                    vendor_part_id=vendor_id,
                    id=thinking_part.id,
                    content=thinking_part.content,
                    signature=thinking_part.signature,
                    provider_name=self._provider_name,
                    provider_details=thinking_part.provider_details,
                )
        else:
            return super()._map_thinking_delta(choice)

    @override
    def _map_provider_details(self, chunk: chat.ChatCompletionChunk) -> dict[str, Any] | None:
        assert isinstance(chunk, _OpenRouterChatCompletionChunk)

        provider_details = super()._map_provider_details(chunk) or {}
        provider_details.update(_map_openrouter_provider_details(chunk))
        return provider_details or None

    @override
    def _map_finish_reason(  # type: ignore[reportIncompatibleMethodOverride]
        self, key: Literal['stop', 'length', 'tool_calls', 'content_filter', 'error']
    ) -> FinishReason | None:
        return _CHAT_FINISH_REASON_MAP.get(key)

```

---|---
© Pydantic Services Inc. 2024 to present
