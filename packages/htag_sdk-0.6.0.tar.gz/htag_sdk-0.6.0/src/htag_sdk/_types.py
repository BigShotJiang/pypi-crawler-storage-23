"""Common type aliases used across the HtAG SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

# Generic JSON-compatible types
JSONValue = Union[str, int, float, bool, None, List[Any], Dict[str, Any]]
JSONDict = Dict[str, Any]
JSONList = List[JSONDict]

# Header types
Headers = Dict[str, str]

# Query parameter types — values are serialised to strings before sending
QueryParamValue = Union[str, int, float, bool, None]
QueryParams = Dict[str, Union[QueryParamValue, List[QueryParamValue]]]

# Request body type
RequestBody = Optional[JSONDict]
