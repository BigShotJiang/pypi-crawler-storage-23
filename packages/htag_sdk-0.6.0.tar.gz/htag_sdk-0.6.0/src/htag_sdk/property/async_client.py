"""Asynchronous client for the Property API domain."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from htag_sdk.property.models import SoldPropertiesResponse

if TYPE_CHECKING:
    from htag_sdk._base import AsyncRequestMixin


class AsyncPropertyClient:
    """Asynchronous client for property data endpoints.

    This class is not instantiated directly. Access it via ``client.property``.
    """

    _client: "AsyncRequestMixin"

    def __init__(self, client: "AsyncRequestMixin") -> None:
        self._client = client

    async def sold_search(
        self,
        *,
        address: Optional[str] = None,
        address_key: Optional[str] = None,
        lat: Optional[float] = None,
        lon: Optional[float] = None,
        radius: int = 2000,
        proximity: Optional[str] = None,
        property_type: Optional[str] = None,
        sale_value_min: Optional[float] = None,
        sale_value_max: Optional[float] = None,
        include_sale_value_unknown: bool = True,
        bedrooms_min: Optional[int] = None,
        bedrooms_max: Optional[int] = None,
        bathrooms_min: Optional[int] = None,
        bathrooms_max: Optional[int] = None,
        car_spaces_min: Optional[int] = None,
        car_spaces_max: Optional[int] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        land_area_min: Optional[int] = None,
        land_area_max: Optional[int] = None,
    ) -> SoldPropertiesResponse:
        """Search for recently sold properties.

        Provide either ``address`` / ``address_key`` for an address-based
        search, or ``lat`` / ``lon`` for a coordinate-based search.

        Args:
            address: Free-text address to centre the search on.
            address_key: GNAF address key to centre the search on.
            lat: Latitude for coordinate-based search.
            lon: Longitude for coordinate-based search.
            radius: Search radius in metres (default 2000).
            proximity: Named proximity filter.
            property_type: Filter by property type (e.g. ``"house"``).
            sale_value_min: Minimum sale price.
            sale_value_max: Maximum sale price.
            include_sale_value_unknown: Include sales with unknown prices.
            bedrooms_min: Minimum number of bedrooms.
            bedrooms_max: Maximum number of bedrooms.
            bathrooms_min: Minimum number of bathrooms.
            bathrooms_max: Maximum number of bathrooms.
            car_spaces_min: Minimum number of car spaces.
            car_spaces_max: Maximum number of car spaces.
            start_date: Earliest sale date (ISO 8601 date string).
            end_date: Latest sale date (ISO 8601 date string).
            land_area_min: Minimum land area in square metres.
            land_area_max: Maximum land area in square metres.

        Returns:
            A :class:`SoldPropertiesResponse` with matching sold records.
        """
        params = {
            "address": address,
            "address_key": address_key,
            "lat": lat,
            "lon": lon,
            "radius": radius,
            "proximity": proximity,
            "property_type": property_type,
            "sale_value_min": sale_value_min,
            "sale_value_max": sale_value_max,
            "include_sale_value_unknown": include_sale_value_unknown,
            "bedrooms_min": bedrooms_min,
            "bedrooms_max": bedrooms_max,
            "bathrooms_min": bathrooms_min,
            "bathrooms_max": bathrooms_max,
            "car_spaces_min": car_spaces_min,
            "car_spaces_max": car_spaces_max,
            "start_date": start_date,
            "end_date": end_date,
            "land_area_min": land_area_min,
            "land_area_max": land_area_max,
        }
        data = await self._client._request("GET", "/property/sold/search", params=params)
        return SoldPropertiesResponse.model_validate(data)
