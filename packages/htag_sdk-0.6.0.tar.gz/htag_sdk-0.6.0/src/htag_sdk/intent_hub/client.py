"""Synchronous client for the Intent Hub API domain."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from htag_sdk.intent_hub.models import (
    ClassifiedEvent,
    EventCategory,
    EventType,
    Integration,
    PaginatedEvents,
    Subscription,
    TagInfo,
)

if TYPE_CHECKING:
    from htag_sdk._base import SyncRequestMixin


class IntentHubClient:
    """Synchronous client for events, integrations, subscriptions, and catalog.

    This class is not instantiated directly. Access it via ``client.intent_hub``.
    """

    _client: "SyncRequestMixin"

    def __init__(self, client: "SyncRequestMixin") -> None:
        self._client = client

    # ------------------------------------------------------------------
    # Events
    # ------------------------------------------------------------------

    def submit_event(
        self,
        *,
        source_type: str,
        source_id: str,
        text_content: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        suggested_category: Optional[str] = None,
        suggested_intent: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        event_type: Optional[str] = None,
    ) -> ClassifiedEvent:
        """Submit an event for classification.

        Args:
            source_type: Origin of the event (``"AGENT"``, ``"PLATFORM"``,
                ``"PARTNER"``, or ``"INTERNAL"``).
            source_id: Identifier of the source system or agent.
            text_content: Free-form text to classify.
            payload: Structured payload for rule-based classification.
            user_id: User who triggered the event.
            session_id: Session identifier for correlation.
            suggested_category: Hint for the classifier.
            suggested_intent: Hint for the classifier.
            idempotency_key: Deduplication key.
            event_type: Explicit event type slug — skips classification entirely.

        Returns:
            A :class:`ClassifiedEvent` with classification results.

        Raises:
            ValidationError: If required fields are missing.
            AuthenticationError: If the API key is invalid.
        """
        body: Dict[str, Any] = {
            "source_type": source_type,
            "source_id": source_id,
        }
        if text_content is not None:
            body["text_content"] = text_content
        if payload is not None:
            body["payload"] = payload
        if user_id is not None:
            body["user_id"] = user_id
        if session_id is not None:
            body["session_id"] = session_id
        if suggested_category is not None:
            body["suggested_category"] = suggested_category
        if suggested_intent is not None:
            body["suggested_intent"] = suggested_intent
        if idempotency_key is not None:
            body["idempotency_key"] = idempotency_key
        if event_type is not None:
            body["event_type"] = event_type

        data = self._client._request(
            "POST",
            "/events",
            json=body,
            base_url=self._client._intent_hub_base_url,
        )
        return ClassifiedEvent.model_validate(data)

    def get_event(self, event_id: str) -> ClassifiedEvent:
        """Retrieve a single classified event by ID.

        Args:
            event_id: The event identifier.

        Returns:
            A :class:`ClassifiedEvent`.

        Raises:
            NotFoundError: If the event does not exist.
        """
        data = self._client._request(
            "GET",
            f"/events/{event_id}",
            base_url=self._client._intent_hub_base_url,
        )
        return ClassifiedEvent.model_validate(data)

    def query_events(
        self,
        *,
        event_type: Optional[str] = None,
        intent: Optional[str] = None,
        tag: Optional[str] = None,
        user_id: Optional[str] = None,
        min_confidence: Optional[float] = None,
        limit: int = 20,
        cursor: Optional[str] = None,
    ) -> PaginatedEvents:
        """Query classified events with filters and cursor pagination.

        Args:
            event_type: Filter by event type slug.
            intent: Filter by primary intent.
            tag: Filter by tag.
            user_id: Filter by user ID.
            min_confidence: Minimum confidence threshold.
            limit: Maximum number of results (default 20).
            cursor: Pagination cursor from a previous response.

        Returns:
            A :class:`PaginatedEvents` with matching events.
        """
        params: Dict[str, Any] = {"limit": limit}
        if event_type is not None:
            params["event_type"] = event_type
        if intent is not None:
            params["intent"] = intent
        if tag is not None:
            params["tag"] = tag
        if user_id is not None:
            params["user_id"] = user_id
        if min_confidence is not None:
            params["min_confidence"] = min_confidence
        if cursor is not None:
            params["cursor"] = cursor

        data = self._client._request(
            "GET",
            "/events",
            params=params,
            base_url=self._client._intent_hub_base_url,
        )
        return PaginatedEvents.model_validate(data)

    # ------------------------------------------------------------------
    # Integrations
    # ------------------------------------------------------------------

    def create_integration(
        self,
        *,
        name: str,
        type: str = "WEBHOOK",
        url: Optional[str] = None,
        secret: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> Integration:
        """Register a new integration endpoint.

        Args:
            name: Human-readable name for the integration.
            type: Integration type (``"WEBHOOK"``, ``"SQS"``, or ``"SNS"``).
            url: Endpoint URL for webhook integrations.
            secret: Signing secret for webhook verification.
            headers: Custom headers to include in webhook requests.
            config: Additional configuration for the integration.

        Returns:
            The created :class:`Integration`.
        """
        body: Dict[str, Any] = {"name": name, "type": type}
        if url is not None:
            body["url"] = url
        if secret is not None:
            body["secret"] = secret
        if headers is not None:
            body["headers"] = headers
        if config is not None:
            body["config"] = config

        data = self._client._request(
            "POST",
            "/integrations",
            json=body,
            base_url=self._client._intent_hub_base_url,
        )
        return Integration.model_validate(data)

    def list_integrations(self) -> List[Integration]:
        """List all integrations for the authenticated organisation.

        Returns:
            A list of :class:`Integration` objects.
        """
        data = self._client._request(
            "GET",
            "/integrations",
            base_url=self._client._intent_hub_base_url,
        )
        return [Integration.model_validate(item) for item in data]

    def get_integration(self, integration_id: str) -> Integration:
        """Get a single integration by ID.

        Args:
            integration_id: The integration identifier.

        Returns:
            An :class:`Integration`.

        Raises:
            NotFoundError: If the integration does not exist.
        """
        data = self._client._request(
            "GET",
            f"/integrations/{integration_id}",
            base_url=self._client._intent_hub_base_url,
        )
        return Integration.model_validate(data)

    def update_integration(
        self,
        integration_id: str,
        *,
        name: Optional[str] = None,
        url: Optional[str] = None,
        secret: Optional[str] = None,
        status: Optional[str] = None,
    ) -> Integration:
        """Update an existing integration.

        Args:
            integration_id: The integration identifier.
            name: New name for the integration.
            url: New endpoint URL.
            secret: New signing secret.
            status: New status (``"ACTIVE"``, ``"DEGRADED"``, or ``"DISABLED"``).

        Returns:
            The updated :class:`Integration`.
        """
        body: Dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if url is not None:
            body["url"] = url
        if secret is not None:
            body["secret"] = secret
        if status is not None:
            body["status"] = status

        data = self._client._request(
            "PATCH",
            f"/integrations/{integration_id}",
            json=body,
            base_url=self._client._intent_hub_base_url,
        )
        return Integration.model_validate(data)

    def delete_integration(self, integration_id: str) -> None:
        """Delete an integration and its subscriptions.

        Args:
            integration_id: The integration identifier.
        """
        self._client._request(
            "DELETE",
            f"/integrations/{integration_id}",
            base_url=self._client._intent_hub_base_url,
        )

    def test_integration(self, integration_id: str) -> Dict[str, Any]:
        """Send a test webhook to the integration endpoint.

        Args:
            integration_id: The integration identifier.

        Returns:
            A dictionary with the test result.
        """
        data = self._client._request(
            "POST",
            f"/integrations/{integration_id}/test",
            base_url=self._client._intent_hub_base_url,
        )
        return data

    # ------------------------------------------------------------------
    # Subscriptions
    # ------------------------------------------------------------------

    def create_subscription(
        self,
        *,
        integration_id: str,
        event_type_slug: Optional[str] = None,
        tag: Optional[str] = None,
        intent_pattern: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Subscription:
        """Create a subscription linking an event pattern to an integration.

        Args:
            integration_id: Target integration to deliver matching events to.
            event_type_slug: Event type slug to match.
            tag: Tag to match.
            intent_pattern: Intent pattern (glob or regex) to match.
            filters: Additional filter criteria.

        Returns:
            The created :class:`Subscription`.
        """
        body: Dict[str, Any] = {"integration_id": integration_id}
        if event_type_slug is not None:
            body["event_type_slug"] = event_type_slug
        if tag is not None:
            body["tag"] = tag
        if intent_pattern is not None:
            body["intent_pattern"] = intent_pattern
        if filters is not None:
            body["filters"] = filters

        data = self._client._request(
            "POST",
            "/subscriptions",
            json=body,
            base_url=self._client._intent_hub_base_url,
        )
        return Subscription.model_validate(data)

    def list_subscriptions(self) -> List[Subscription]:
        """List all subscriptions for the authenticated organisation.

        Returns:
            A list of :class:`Subscription` objects.
        """
        data = self._client._request(
            "GET",
            "/subscriptions",
            base_url=self._client._intent_hub_base_url,
        )
        return [Subscription.model_validate(item) for item in data]

    def get_subscription(self, subscription_id: str) -> Subscription:
        """Get a single subscription by ID.

        Args:
            subscription_id: The subscription identifier.

        Returns:
            A :class:`Subscription`.

        Raises:
            NotFoundError: If the subscription does not exist.
        """
        data = self._client._request(
            "GET",
            f"/subscriptions/{subscription_id}",
            base_url=self._client._intent_hub_base_url,
        )
        return Subscription.model_validate(data)

    def update_subscription(
        self,
        subscription_id: str,
        *,
        event_type_slug: Optional[str] = None,
        tag: Optional[str] = None,
        intent_pattern: Optional[str] = None,
        integration_id: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> Subscription:
        """Update an existing subscription.

        Args:
            subscription_id: The subscription identifier.
            event_type_slug: New event type slug filter.
            tag: New tag filter.
            intent_pattern: New intent pattern filter.
            integration_id: New target integration.
            is_active: Enable or disable the subscription.

        Returns:
            The updated :class:`Subscription`.
        """
        body: Dict[str, Any] = {}
        if event_type_slug is not None:
            body["event_type_slug"] = event_type_slug
        if tag is not None:
            body["tag"] = tag
        if intent_pattern is not None:
            body["intent_pattern"] = intent_pattern
        if integration_id is not None:
            body["integration_id"] = integration_id
        if is_active is not None:
            body["is_active"] = is_active

        data = self._client._request(
            "PATCH",
            f"/subscriptions/{subscription_id}",
            json=body,
            base_url=self._client._intent_hub_base_url,
        )
        return Subscription.model_validate(data)

    def delete_subscription(self, subscription_id: str) -> None:
        """Delete a subscription.

        Args:
            subscription_id: The subscription identifier.
        """
        self._client._request(
            "DELETE",
            f"/subscriptions/{subscription_id}",
            base_url=self._client._intent_hub_base_url,
        )

    # ------------------------------------------------------------------
    # Catalog
    # ------------------------------------------------------------------

    def list_categories(self) -> List[EventCategory]:
        """List all event categories in the taxonomy.

        Returns:
            A list of :class:`EventCategory` objects.
        """
        data = self._client._request(
            "GET",
            "/catalog/categories",
            base_url=self._client._intent_hub_base_url,
        )
        return [EventCategory.model_validate(item) for item in data]

    def list_event_types(
        self,
        *,
        category: Optional[str] = None,
    ) -> List[EventType]:
        """List all event types, optionally filtered by category.

        Args:
            category: Filter by category slug.

        Returns:
            A list of :class:`EventType` objects.
        """
        params: Dict[str, Any] = {}
        if category is not None:
            params["category"] = category

        data = self._client._request(
            "GET",
            "/catalog/event-types",
            params=params if params else None,
            base_url=self._client._intent_hub_base_url,
        )
        return [EventType.model_validate(item) for item in data]

    def list_tags(self) -> List[TagInfo]:
        """List known tags with usage counts.

        Returns:
            A list of :class:`TagInfo` objects.
        """
        data = self._client._request(
            "GET",
            "/catalog/tags",
            base_url=self._client._intent_hub_base_url,
        )
        return [TagInfo.model_validate(item) for item in data]
