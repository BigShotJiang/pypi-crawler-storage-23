"""Pydantic models for the Intent Hub API domain."""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field  # Field used for event_id alias

# ---------------------------------------------------------------------------
# Literal type aliases (SDK is standalone -- no enum.Enum)
# ---------------------------------------------------------------------------

SourceType = Literal["AGENT", "PLATFORM", "PARTNER", "INTERNAL"]
IntegrationType = Literal["WEBHOOK", "SQS", "SNS"]
IntegrationStatus = Literal["ACTIVE", "DEGRADED", "DISABLED"]
Sentiment = Literal["POSITIVE", "NEUTRAL", "NEGATIVE", "MIXED"]
Urgency = Literal["IMMEDIATE", "STANDARD", "BATCHED"]

# ---------------------------------------------------------------------------
# Event models
# ---------------------------------------------------------------------------


class ClassifiedEvent(BaseModel):
    """A classified event returned by the Intent Hub."""

    model_config = ConfigDict(populate_by_name=True)

    id: str = Field(..., alias="event_id")
    raw_event_id: Optional[str] = None
    status: Optional[str] = None
    event_type: Optional[str] = None
    category: Optional[str] = None
    primary_intent: Optional[str] = None
    sub_intents: Optional[List[str]] = None
    confidence: Optional[float] = None
    sentiment: Optional[str] = None
    entities: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None
    urgency: Optional[str] = None
    classifier_model: Optional[str] = None
    classifier_version: Optional[str] = None
    classified_at: Optional[str] = None
    occurred_at: Optional[str] = None


class PaginatedEvents(BaseModel):
    """Paginated list of classified events."""

    model_config = ConfigDict(populate_by_name=True)

    events: List[ClassifiedEvent] = []
    total: int = 0
    cursor: Optional[str] = None


# ---------------------------------------------------------------------------
# Integration models
# ---------------------------------------------------------------------------


class Integration(BaseModel):
    """An integration endpoint (webhook, SQS, or SNS)."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    org_id: Optional[str] = None
    type: str
    name: str
    url: Optional[str] = None
    status: Optional[str] = None
    consecutive_failures: Optional[int] = None
    last_success_at: Optional[str] = None
    last_failure_at: Optional[str] = None
    created_at: Optional[str] = None


# ---------------------------------------------------------------------------
# Subscription models
# ---------------------------------------------------------------------------


class Subscription(BaseModel):
    """A subscription linking event patterns to an integration."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    org_id: Optional[str] = None
    integration_id: Optional[str] = None
    event_type_slug: Optional[str] = None
    tag: Optional[str] = None
    intent_pattern: Optional[str] = None
    is_active: Optional[bool] = None
    created_at: Optional[str] = None


# ---------------------------------------------------------------------------
# Catalog models
# ---------------------------------------------------------------------------


class EventCategory(BaseModel):
    """An event category in the taxonomy."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    slug: str
    name: str
    description: Optional[str] = None
    sort_order: Optional[int] = None


class EventType(BaseModel):
    """An event type in the taxonomy."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    slug: str
    name: str
    category_id: Optional[str] = None
    classification_hint: Optional[str] = None
    default_urgency: Optional[str] = None
    visibility: Optional[str] = None


class TagInfo(BaseModel):
    """A tag with its usage count."""

    model_config = ConfigDict(populate_by_name=True)

    tag: str
    count: int
