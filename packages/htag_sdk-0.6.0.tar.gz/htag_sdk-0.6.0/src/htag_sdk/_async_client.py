"""Asynchronous HtAG API client."""

from __future__ import annotations

from typing import Optional

import httpx

from htag_sdk._base import AsyncRequestMixin
from htag_sdk.address.async_client import AsyncAddressClient
from htag_sdk.intent_hub.async_client import AsyncIntentHubClient
from htag_sdk.markets.async_client import AsyncMarketsClient
from htag_sdk.property.async_client import AsyncPropertyClient


class AsyncHtAgApi(AsyncRequestMixin):
    """Asynchronous client for the HtAG AI API.

    Usage::

        import asyncio
        from htag_sdk import AsyncHtAgApi

        async def main():
            client = AsyncHtAgApi(api_key="sk-...", environment="prod")

            results = await client.address.search("100 George St Sydney")
            sold = await client.property.sold_search(address="100 George St Sydney")
            snapshots = await client.markets.snapshots(
                level="suburb", property_type=["house"]
            )

            await client.close()

        asyncio.run(main())

    As an async context manager::

        async with AsyncHtAgApi(api_key="sk-...", environment="prod") as client:
            results = await client.address.search("100 George St Sydney")

    Args:
        api_key: Your HtAG API key (required).
        environment: Target environment -- ``"prod"`` or ``"dev"``.
        base_url: Custom base URL (overrides ``environment``).
        timeout: Request timeout in seconds (default 60).
        max_retries: Maximum number of retry attempts for transient errors (default 3).
    """

    address: AsyncAddressClient
    property: AsyncPropertyClient
    markets: AsyncMarketsClient
    intent_hub: AsyncIntentHubClient

    def __init__(
        self,
        *,
        api_key: str,
        environment: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 60.0,
        max_retries: int = 3,
    ) -> None:
        super().__init__(
            api_key=api_key,
            environment=environment,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._http = httpx.AsyncClient()
        self.address = AsyncAddressClient(self)
        self.property = AsyncPropertyClient(self)
        self.markets = AsyncMarketsClient(self)
        self.intent_hub = AsyncIntentHubClient(self)

    async def close(self) -> None:
        """Release underlying HTTP connection pool resources."""
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncHtAgApi":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    def __repr__(self) -> str:
        return f"AsyncHtAgApi(base_url={self._base_url!r})"
