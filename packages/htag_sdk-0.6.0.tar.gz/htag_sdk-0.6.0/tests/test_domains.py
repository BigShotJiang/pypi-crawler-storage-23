"""Tests for domain sub-clients using mocked HTTP responses."""

from __future__ import annotations

from unittest.mock import patch, MagicMock

import httpx
import pytest

from htag_sdk import HtAgApi
from htag_sdk._exceptions import AuthenticationError, ServerError


def _mock_response(status_code: int = 200, json_data: dict | None = None) -> httpx.Response:
    """Build a mock httpx.Response."""
    response = MagicMock(spec=httpx.Response)
    response.status_code = status_code
    response.json.return_value = json_data or {}
    response.headers = {}
    response.text = ""
    return response


class TestAddressClient:
    def test_search_sends_correct_params(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {
            "results": [{"address_label": "100 George St", "score": 0.95}],
            "total": 1,
        })

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            result = client.address.search("100 George St", limit=5)

        call_kwargs = mock_req.call_args
        assert call_kwargs[0][0] == "GET"
        assert "/address/search" in call_kwargs[0][1]
        assert call_kwargs[1]["params"]["q"] == "100 George St"
        assert call_kwargs[1]["params"]["limit"] == 5
        assert result.results[0].address_label == "100 George St"
        client.close()

    def test_insights_with_address(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [{"flood": True, "address_label": "15 Miranda Ct"}], "total": 1})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            result = client.address.insights(address="15 Miranda Ct")

        call_kwargs = mock_req.call_args
        assert call_kwargs[1]["params"]["address"] == "15 Miranda Ct"
        assert result.results[0].flood is True
        client.close()

    def test_insights_with_address_keys(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.address.insights(address_keys=["KEY1", "KEY2"])

        call_kwargs = mock_req.call_args
        assert call_kwargs[1]["params"]["address_keys"] == ["KEY1", "KEY2"]
        client.close()

    def test_standardise_sends_post(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [{"input_address": "test", "address_key": "K1"}]})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.address.standardise(["100 George St Sydney"])

        call_kwargs = mock_req.call_args
        assert call_kwargs[0][0] == "POST"
        assert "/address/standardise" in call_kwargs[0][1]
        assert call_kwargs[1]["json"]["addresses"] == ["100 George St Sydney"]
        client.close()


class TestPropertyClient:
    def test_sold_search_sends_correct_params(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {
            "results": [{"sold_price": 1500000, "street_address": "100 George St"}],
            "total": 1,
        })

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            result = client.property.sold_search(
                address="100 George St Sydney",
                radius=2000,
                property_type="house",
                sale_value_min=500000,
            )

        call_kwargs = mock_req.call_args
        assert call_kwargs[0][0] == "GET"
        assert "/property/sold/search" in call_kwargs[0][1]
        params = call_kwargs[1]["params"]
        assert params["address"] == "100 George St Sydney"
        assert params["radius"] == 2000
        assert params["property_type"] == "house"
        assert params["sale_value_min"] == 500000
        assert result.results[0].sold_price == 1500000
        client.close()


class TestMarketsClient:
    def test_snapshots_sends_correct_params(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.markets.snapshots(level="suburb", property_type=["house"])

        call_kwargs = mock_req.call_args
        assert call_kwargs[0][0] == "GET"
        assert "/markets/snapshots" in call_kwargs[0][1]
        params = call_kwargs[1]["params"]
        assert params["level"] == "suburb"
        assert params["property_type"] == ["house"]
        client.close()

    def test_query_sends_post(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.markets.query({
                "level": "suburb",
                "mode": "search",
                "property_types": ["house"],
            })

        call_kwargs = mock_req.call_args
        assert call_kwargs[0][0] == "POST"
        assert "/markets/query" in call_kwargs[0][1]
        client.close()

    def test_trends_price(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.markets.trends.price(level="suburb", area_id=["SAL10001"])

        assert "/trends/price" in mock_req.call_args[0][1]
        client.close()

    def test_trends_rent(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp):
            client.markets.trends.rent(level="suburb", area_id=["SAL10001"])
        client.close()

    def test_trends_yield_history(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.markets.trends.yield_history(level="suburb", area_id=["SAL10001"])

        assert "/trends/yield_history" in mock_req.call_args[0][1]
        client.close()

    def test_trends_supply_demand(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.markets.trends.supply_demand(level="suburb", area_id=["SAL10001"])

        assert "/trends/supply_demand" in mock_req.call_args[0][1]
        client.close()

    def test_trends_search_index(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.markets.trends.search_index(level="suburb", area_id=["SAL10001"])

        assert "/trends/search_index" in mock_req.call_args[0][1]
        client.close()

    def test_trends_hold_period(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.markets.trends.hold_period(level="suburb", area_id=["SAL10001"])

        assert "/trends/hold_period" in mock_req.call_args[0][1]
        client.close()

    def test_trends_performance(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.markets.trends.performance(level="suburb", area_id=["SAL10001"])

        assert "/trends/performance" in mock_req.call_args[0][1]
        client.close()

    def test_trends_growth_rates(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.markets.trends.growth_rates(level="suburb", area_id=["SAL10001"])

        assert "/trends/growth_rates" in mock_req.call_args[0][1]
        client.close()

    def test_trends_demand_profile(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(200, {"results": [], "total": 0, "limit": 100, "offset": 0})

        with patch.object(client._http, "request", return_value=mock_resp) as mock_req:
            client.markets.trends.demand_profile(level="suburb", area_id=["SAL10001"])

        assert "/trends/demand_profile" in mock_req.call_args[0][1]
        client.close()


class TestErrorHandling:
    def test_401_raises_authentication_error(self):
        client = HtAgApi(api_key="sk-test", environment="prod")
        mock_resp = _mock_response(401, {"detail": "Unauthorized"})

        with patch.object(client._http, "request", return_value=mock_resp):
            with pytest.raises(AuthenticationError):
                client.address.search("test")
        client.close()

    def test_500_raises_server_error_after_retries(self):
        client = HtAgApi(api_key="sk-bad", environment="prod", max_retries=0)
        mock_resp = _mock_response(500, {"detail": "Internal Server Error"})

        with patch.object(client._http, "request", return_value=mock_resp):
            with pytest.raises(ServerError):
                client.address.search("test")
        client.close()
