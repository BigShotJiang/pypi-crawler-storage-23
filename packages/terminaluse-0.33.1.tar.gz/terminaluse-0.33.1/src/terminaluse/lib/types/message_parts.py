"""Message part types for agent message sending.

These types are used by ctx.messages.send() to send messages from agents.
They are simpler than the full UIMessagePart union - agents only need to
send text or data, not tool calls, reasoning, etc.

Example:
    from terminaluse.lib.types import TextPart, DataPart

    # Send text
    await ctx.messages.send(TextPart(text="Hello, world!"))

    # Send structured data
    await ctx.messages.send(DataPart(data={"status": "complete", "count": 42}))

    # Or just a string (auto-wrapped to TextPart)
    await ctx.messages.send("Hello, world!")
"""

from __future__ import annotations

from typing import Any, Literal, Union

from pydantic import BaseModel, ConfigDict


class TextPart(BaseModel):
    """Text content part for sending text messages."""

    type: Literal["text"] = "text"
    text: str

    model_config = ConfigDict(frozen=True)


class DataPart(BaseModel):
    """Data content part for sending structured data."""

    type: Literal["data"] = "data"
    data: Any

    model_config = ConfigDict(frozen=True)


# Union type for agent message parts
AgentMessagePart = Union[TextPart, DataPart]
