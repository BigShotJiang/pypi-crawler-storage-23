# Custom exports for terminaluse.lib
# These were previously exported from terminaluse.__init__.py but are now here
# to allow Fern to manage the main __init__.py

from terminaluse.lib import adk
from terminaluse.lib.client import AsyncTerminalUse, TerminalUse
from terminaluse.lib.sdk.agent_server import AgentServer
from terminaluse.lib.types.message_parts import AgentMessagePart, DataPart, TextPart
from terminaluse.lib.types.task_context import TaskContext
from terminaluse.lib.utils.logging import make_logger

# Re-export Event from types for convenience (commonly used with TaskContext)
from terminaluse.types import Event

__all__ = [
    "AsyncTerminalUse",
    "TerminalUse",
    "AgentServer",
    "TaskContext",
    "Event",
    "adk",
    "make_logger",
    # Message part types for ctx.messages.send()
    "TextPart",
    "DataPart",
    "AgentMessagePart",
]
