# test-prod-org/codex-hello-world - Codex SDK Hello World

This example uses OpenAI Agents `codex_tool` and forwards Codex stream events
into TerminalUse via `ctx.messages.send(...)`.

## What It Demonstrates

- `codex_tool` streaming (`thread.*`, `turn.*`, `item.*`)
- Thread continuation using Codex `thread.started` IDs
- Raw-event adapter path (`sdk_type=codex`) in Nucleus

## Requirements

- `OPENAI_API_KEY` (or `CODEX_API_KEY`) configured
- `openai-agents` installed in the agent environment
- Codex CLI installed in the runtime image (used internally by `codex_tool`)

## Local Run

```bash
cd sdks/python/examples/codex_hello_world
uv sync

export ENVIRONMENT=development
export OPENAI_API_KEY=sk-...

uv run terminaluse agents run --config config.yaml
```

## Build Image

```bash
cd sdks/python
terminaluse agents build --config examples/codex_hello_world/config.yaml
```

## Notes

- TerminalUse uses the installed `openai-agents` version as the canonical `sdk_version` for `sdk_type=codex`.
- The agent sends text user events to `codex_tool` and streams Codex events back to TerminalUse.
