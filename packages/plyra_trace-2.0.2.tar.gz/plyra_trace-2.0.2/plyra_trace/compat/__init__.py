"""Compatibility processors for third-party instrumentation."""

from plyra_trace.compat.openinference import OpenInferenceSpanProcessor
from plyra_trace.compat.openllmetry import OpenLLMetrySpanProcessor

__all__ = ["OpenInferenceSpanProcessor", "OpenLLMetrySpanProcessor"]
