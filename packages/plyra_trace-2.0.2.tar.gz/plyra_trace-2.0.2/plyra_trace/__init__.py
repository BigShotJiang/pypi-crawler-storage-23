"""plyra-trace: Behavioral tracing for agentic AI."""

from plyra_trace._client import PlyraClient, init
from plyra_trace.background import (
    PlyraBackgroundTask,
    capture_context,
    run_in_context,
    run_with_context,
)
from plyra_trace.context import metadata, session, tags, user
from plyra_trace.decorators import agent, guard, llm, tool, trace
from plyra_trace.models import GuardResult, SpanLink, TraceContext
from plyra_trace.propagation import (
    continue_trace,
    create_link,
    extract_context,
    inject_context,
)
from plyra_trace.semconv import SpanAttributes, SpanKind
from plyra_trace.spans import SpanBuilder

__version__ = "2.0.0"
__all__ = [
    "init",
    "PlyraClient",
    "trace",
    "agent",
    "tool",
    "guard",
    "llm",
    "session",
    "user",
    "metadata",
    "tags",
    "inject_context",
    "extract_context",
    "continue_trace",
    "create_link",
    "SpanBuilder",
    "SpanKind",
    "SpanAttributes",
    "GuardResult",
    "TraceContext",
    "SpanLink",
    "PlyraBackgroundTask",
    "capture_context",
    "run_in_context",
    "run_with_context",
]
