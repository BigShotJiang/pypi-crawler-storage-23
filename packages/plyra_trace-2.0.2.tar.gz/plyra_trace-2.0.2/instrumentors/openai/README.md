# plyra-instrument-openai

OpenAI SDK instrumentation for [plyra-trace](https://github.com/plyraAI/plyra-trace).

Automatically captures LLM spans (model, token counts, cost) for all
`openai.OpenAI` and `openai.AsyncOpenAI` calls with zero code changes.

## Install

```bash
pip install plyra-instrument-openai
```

## Usage

```python
import plyra_trace
plyra_trace.init(project="my-agent", endpoint="http://localhost:7700", auto_instrument=True)

import openai
client = openai.OpenAI()
# All calls are now traced automatically
```
