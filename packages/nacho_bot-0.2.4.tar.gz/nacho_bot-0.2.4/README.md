# Nacho

Context management and builder tools for AI assistants.

## Installation

```bash
pip install nacho-bot
```

This installs:
- **nacho-cli** — push, pull, and search context files on [nacho.bot](https://nacho.bot)
- **nacho-mcp** — MCP server for Nacho tools in your AI assistant

## Quick Start

```bash
nacho init
```

Sets up your AI assistant integration and launches the Nacho builder wizard.

## Links

- [nacho.bot](https://nacho.bot)
- [Documentation](https://nacho.bot/docs)
- [Repository](https://github.com/DevJoy-Studio-LLC/nacho)
