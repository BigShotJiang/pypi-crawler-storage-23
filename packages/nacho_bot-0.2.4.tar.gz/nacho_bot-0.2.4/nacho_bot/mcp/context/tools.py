import json
import os
from pathlib import Path

import httpx

DEFAULT_API_URL = "https://nacho.bot/api"
CREDENTIALS_FILE = Path.home() / ".nacho" / "credentials"
GLOBAL_CONFIG_FILE = Path.home() / ".nacho" / "config.json"


def _get_config() -> dict:
    """Project-level .nacho/config.json overrides global ~/.nacho/config.json."""
    config: dict = {}
    if GLOBAL_CONFIG_FILE.exists():
        try:
            config.update(json.loads(GLOBAL_CONFIG_FILE.read_text()))
        except (json.JSONDecodeError, OSError):
            pass
    project_cfg = Path(".nacho") / "config.json"
    if project_cfg.exists():
        try:
            config.update(json.loads(project_cfg.read_text()))
        except (json.JSONDecodeError, OSError):
            pass
    return config


def _get_provider() -> str:
    return _get_config().get("provider", "")


class NachoAPIError(Exception):
    pass


def _get_api_url() -> str:
    return os.environ.get("NACHO_API_URL", DEFAULT_API_URL)


def _get_headers() -> dict[str, str]:
    headers: dict[str, str] = {}
    if CREDENTIALS_FILE.exists():
        token = CREDENTIALS_FILE.read_text().strip()
        if token:
            headers["Authorization"] = f"Bearer {token}"
    return headers


def _api_get(path: str, params: dict | None = None) -> dict | list:
    url = f"{_get_api_url()}{path}"
    try:
        resp = httpx.get(url, params=params, headers=_get_headers(), timeout=30.0)
    except httpx.ConnectError:
        raise NachoAPIError(
            f"Could not connect to Nacho API at {_get_api_url()}. Is the server running?"
        )
    if resp.status_code == 401:
        raise NachoAPIError(
            "Authentication required. Run `nacho login` or `nacho token <token>` first."
        )
    if resp.status_code == 404:
        raise NachoAPIError("Not found.")
    resp.raise_for_status()
    return resp.json()


def _resolve_ref(ref: str) -> tuple[str, str]:
    parts = ref.strip().split("/", 1)
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise NachoAPIError("Invalid ref format. Use username/context-name.")
    return parts[0], parts[1]


def _pull_content(ref: str, version: int | None = None) -> str:
    username, name = _resolve_ref(ref)
    data = _api_get(f"/contexts/{username}/{name}")
    context_id = data.get("id")
    if not context_id:
        raise NachoAPIError("Could not resolve context ID.")

    params: dict = {}
    if version is not None:
        params["version"] = version

    url = f"{_get_api_url()}/contexts/{context_id}/download"
    try:
        resp = httpx.get(
            url, params=params, headers=_get_headers(), timeout=30.0, follow_redirects=True
        )
    except httpx.ConnectError:
        raise NachoAPIError(f"Could not connect to Nacho API at {_get_api_url()}.")
    if resp.status_code == 401:
        raise NachoAPIError("Authentication required.")
    if resp.status_code == 404:
        raise NachoAPIError("Context or version not found.")
    resp.raise_for_status()
    return resp.text


# --- Public tool functions (all return str for MCP) ---


def search(query: str = "", tags: str = "", sort: str = "relevance", page: int = 1) -> str:
    params: dict = {"page": page, "per_page": 10, "sort": sort}
    if query:
        params["q"] = query
    if tags:
        params["tags"] = tags

    try:
        data = _api_get("/contexts/search", params)
    except NachoAPIError as e:
        return f"Error: {e}"

    items = data.get("items", [])
    total = data.get("total", 0)

    if not items:
        return "No contexts found matching your query."

    lines = [f"Found {total} context(s) (page {data.get('page', 1)} of {data.get('pages', 1)}):\n"]
    for i, item in enumerate(items, 1):
        owner = item.get("owner_username", "unknown")
        name = item.get("name", "unknown")
        ref = f"{owner}/{name}"
        title = item.get("title", name)
        desc = item.get("short_description") or ""
        tags_list = item.get("tags", [])
        downloads = item.get("download_count", 0)
        upvotes = item.get("upvote_count", 0)

        lines.append(f"{i}. **{title}** (`{ref}`)")
        if desc:
            lines.append(f"   {desc}")
        if tags_list:
            lines.append(f"   Tags: {', '.join(tags_list)}")
        lines.append(f"   ↓{downloads} ▲{upvotes}")
        lines.append("")

    return "\n".join(lines)


def info(ref: str) -> str:
    try:
        username, name = _resolve_ref(ref)
    except NachoAPIError as e:
        return f"Error: {e}"

    try:
        data = _api_get(f"/contexts/{username}/{name}")
    except NachoAPIError as e:
        return f"Error: {e}"

    context_id = data.get("id")
    title = data.get("title", name)
    desc = data.get("short_description") or data.get("long_description") or "No description."
    long_desc = data.get("long_description") or ""
    tags_list = data.get("tags", [])
    downloads = data.get("download_count", 0)
    upvotes = data.get("upvote_count", 0)
    latest_version = data.get("latest_version", 1)
    license_val = data.get("license") or "Not specified"

    lines = [
        f"# {title}",
        f"**Ref:** `{ref}`",
        f"**Description:** {desc}",
    ]
    if long_desc and long_desc != desc:
        lines.append(f"\n{long_desc}")
    lines.append(f"**Tags:** {', '.join(tags_list) if tags_list else 'None'}")
    lines.append(f"**License:** {license_val}")
    lines.append(f"**Downloads:** {downloads} | **Upvotes:** {upvotes}")
    lines.append(f"**Latest version:** {latest_version}")

    if context_id:
        try:
            versions_data = _api_get(f"/contexts/{context_id}/versions")
        except NachoAPIError:
            versions_data = []
        if isinstance(versions_data, list) and versions_data:
            lines.append("\n**Versions:**")
            for v in versions_data[:5]:
                ver_num = v.get("version", "?")
                changelog = v.get("changelog") or "No changelog"
                created = v.get("created_at", "")[:10]
                lines.append(f"  - v{ver_num} ({created}): {changelog}")

    return "\n".join(lines)


def pull(ref: str, version: int | None = None) -> str:
    try:
        return _pull_content(ref, version)
    except NachoAPIError as e:
        return f"Error: {e}"


def install(ref: str, version: int | None = None) -> str:
    try:
        content = _pull_content(ref, version)
    except NachoAPIError as e:
        return f"Error: {e}"

    # Fetch tags for this context to embed in the marker
    tags_str = ""
    try:
        username, name = _resolve_ref(ref)
        data = _api_get(f"/contexts/{username}/{name}")
        tags_list = data.get("tags", [])
        if tags_list:
            tags_str = f" [{', '.join(tags_list)}]"
    except Exception:
        pass

    agents_md = Path("AGENTS.md")
    header = f"\n\n<!-- nacho: {ref}{tags_str} -->\n"

    if agents_md.exists():
        existing = agents_md.read_text()
        agents_md.write_text(existing + header + content)
        result_msg = f"Appended context `{ref}` to AGENTS.md."
    else:
        agents_md.write_text(header.lstrip() + content)
        result_msg = f"Created AGENTS.md with context `{ref}`."

    provider = _get_provider()
    if provider == "claude":
        claude_md = Path("CLAUDE.md")
        if not claude_md.exists():
            claude_md.write_text("@AGENTS.md\n")
            result_msg += " Created CLAUDE.md stub that imports AGENTS.md for Claude Code."

    return result_msg
