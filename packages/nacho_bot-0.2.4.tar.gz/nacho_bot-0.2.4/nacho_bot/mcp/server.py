from mcp.server.fastmcp import FastMCP

from nacho_bot.mcp.context.tools import info, install, pull, search
from nacho_bot.mcp.security.cli import clear_findings, scan_diff, scan_file, security_report

mcp = FastMCP(
    "nacho",
    instructions=(
        "Nacho provides context hub tools and security scanning tools. "
        "After writing or modifying code files, use nacho_scan_file to check them "
        "for security vulnerabilities, code quality issues, and secrets. "
        "Fix any CRITICAL or HIGH findings before moving on. "
        "Use nacho_scan_diff to scan all changed files at once. "
        "Use nacho_security_report at the end for a summary."
    ),
)

# ---------------------------------------------------------------------------
# Context Hub tools
# ---------------------------------------------------------------------------


@mcp.tool()
def nacho_search(query: str = "", tags: str = "", sort: str = "relevance", page: int = 1) -> str:
    """Search for contexts on Nacho by keyword or tags.

    Args:
        query: Search keywords (e.g. "fastapi react", "golang cli")
        tags: Comma-separated tag filter (e.g. "python,react")
        sort: Sort order — relevance, newest, downloads, upvotes, or updated
        page: Page number for pagination
    """
    return search(query=query, tags=tags, sort=sort, page=page)


@mcp.tool()
def nacho_info(ref: str) -> str:
    """Get detailed info about a Nacho context including description, tags, versions, and stats.

    Args:
        ref: Context reference in username/context-name format (e.g. "nacho/fastapi-react")
    """
    return info(ref=ref)


@mcp.tool()
def nacho_pull(ref: str, version: int | None = None) -> str:
    """Download the raw markdown content of a Nacho context.

    Args:
        ref: Context reference in username/context-name format
        version: Specific version number to download (latest if omitted)
    """
    return pull(ref=ref, version=version)


@mcp.tool()
def nacho_install(ref: str, version: int | None = None) -> str:
    """Install a Nacho context as project instructions. Downloads the context and writes it to AGENTS.md (the universal agent instructions file). If your provider is set to "claude" (via `nacho config set provider claude`), also creates a CLAUDE.md stub that imports AGENTS.md so Claude Code picks it up automatically.

    Args:
        ref: Context reference in username/context-name format
        version: Specific version number to install (latest if omitted)
    """
    return install(ref=ref, version=version)


# ---------------------------------------------------------------------------
# Security tools
# ---------------------------------------------------------------------------


@mcp.tool()
def nacho_scan_diff(repo_path: str, base_ref: str = "HEAD") -> str:
    """Scan files changed since base_ref (default: uncommitted changes vs HEAD).

    Runs security scanners appropriate for the project's stack against only the
    changed files. Returns findings formatted for remediation.

    Args:
        repo_path: Absolute path to the git repository
        base_ref: Git ref to diff against (default: HEAD)
    """
    return scan_diff(repo_path=repo_path, base_ref=base_ref)


@mcp.tool()
def nacho_scan_file(file_paths: list[str]) -> str:
    """Scan specific files with security tools appropriate for the project stack.

    Args:
        file_paths: List of absolute file paths to scan
    """
    return scan_file(file_paths=file_paths)


@mcp.tool()
def nacho_security_report() -> str:
    """Generate a summary security report of all findings from this session."""
    return security_report()


@mcp.tool()
def nacho_clear_findings() -> str:
    """Clear all accumulated security findings. Use between unrelated tasks."""
    return clear_findings()


def main():
    mcp.run(transport="stdio")
