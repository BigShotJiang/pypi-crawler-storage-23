"""Scan cache — skip scanning when files haven't changed since last scan."""

import hashlib
import json
from pathlib import Path


def _cache_file(repo_path: Path) -> Path:
    return repo_path / ".nacho" / ".last-scan"


def _compute_fingerprint(files: list[str]) -> str:
    """Hash of sorted (path, mtime) pairs."""
    entries = []
    for f in sorted(files):
        p = Path(f)
        if p.exists():
            entries.append(f"{f}:{p.stat().st_mtime_ns}")
    return hashlib.sha256("\n".join(entries).encode()).hexdigest()


def is_cached(repo_path: Path, files: list[str]) -> bool:
    """Return True if these files were already scanned and haven't changed."""
    cache = _cache_file(repo_path)
    if not cache.exists():
        return False
    try:
        data = json.loads(cache.read_text())
        return data.get("fingerprint") == _compute_fingerprint(files)
    except (json.JSONDecodeError, OSError):
        return False


def update_cache(repo_path: Path, files: list[str]) -> None:
    """Record that these files have been scanned."""
    cache = _cache_file(repo_path)
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_text(json.dumps({"fingerprint": _compute_fingerprint(files)}))
