"""Scanner implementations for nacho_mcp.sec.

Each scanner function takes a list of absolute file paths and returns findings.
Scanners gracefully return [] if their tool isn't installed.
"""

import json
import os
import platform
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Finding:
    tool: str
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW, INFO
    file: str
    line: int | None
    message: str
    rule_id: str | None = None


def _run(cmd: list[str], timeout: int = 60, cwd: str | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)


def _which(tool: str) -> bool:
    result = _run(["which", tool])
    return result.returncode == 0


# ---------------------------------------------------------------------------
# Auto-install core scanners on first use
# ---------------------------------------------------------------------------

_install_done_for: set[str] = set()


def ensure_tools_for_tags(tags: list[str]) -> None:
    """Install scanner tools needed for the detected stack. Skips already-installed."""
    # Always install universal tools (gitleaks) + semgrep fallback
    _ensure_universal()

    for tag in tags:
        tag_l = tag.lower()
        if tag_l in _install_done_for:
            continue
        _install_done_for.add(tag_l)

        if tag_l in ("python", "django", "flask", "fastapi"):
            _ensure_pip("bandit", "ruff", "pip-licenses")
        elif tag_l in ("javascript", "typescript", "react", "nextjs", "vue", "svelte", "angular", "node"):
            pass  # uses npx — comes with Node
        elif tag_l in ("go", "golang"):
            _ensure_go_tools()
        elif tag_l in ("ruby", "rails"):
            _ensure_ruby_tools()
        elif tag_l in ("elixir", "phoenix"):
            _ensure_elixir_tools()
        elif tag_l in ("rust",):
            _ensure_rust_tools()
        elif tag_l in ("c", "cpp", "c++"):
            _ensure_pip("flawfinder")
            _ensure_pkg("cppcheck")
        elif tag_l in ("csharp", "dotnet"):
            pass  # dotnet CLI comes with .NET SDK
        elif tag_l in ("swift",):
            if sys.platform == "darwin" and _which("brew") and not _which("swiftlint"):
                _run(["brew", "install", "swiftlint"], timeout=120)
        elif tag_l in ("java", "spring"):
            if not _which("pmd") and _which("brew"):
                _run(["brew", "install", "pmd"], timeout=120)
        elif tag_l in ("kotlin",):
            if not _which("detekt-cli") and _which("brew"):
                _run(["brew", "install", "detekt"], timeout=120)
        elif tag_l in ("php", "laravel"):
            if _which("composer") and not _which("phpstan"):
                _run(["composer", "global", "require", "phpstan/phpstan"], timeout=120)
        elif tag_l in ("dart", "flutter"):
            pass  # dart CLI comes with Dart/Flutter SDK


_universal_done = False


def _ensure_universal() -> None:
    """Install universal scanners (gitleaks, semgrep) once."""
    global _universal_done
    if _universal_done:
        return
    _universal_done = True

    _ensure_pip("semgrep")
    if not _which("gitleaks"):
        _install_gitleaks()


def _ensure_pip(*packages: str) -> None:
    """pip install any missing packages."""
    missing = [p for p in packages if not _which(p)]
    if missing:
        _run([sys.executable, "-m", "pip", "install", "--quiet"] + missing, timeout=120)


def _ensure_pkg(tool: str) -> None:
    """Install a system package via available package manager."""
    if _which(tool):
        return
    if _which("brew"):
        _run(["brew", "install", tool], timeout=120)
    elif _which("apt-get"):
        _run(["sudo", "apt-get", "install", "-y", tool], timeout=120)
    elif _which("choco"):
        _run(["choco", "install", tool, "-y"], timeout=120)


def _ensure_go_tools() -> None:
    if not _which("go"):
        return
    for tool, pkg in [
        ("gosec", "github.com/securego/gosec/v2/cmd/gosec@latest"),
        ("staticcheck", "honnef.co/go/tools/cmd/staticcheck@latest"),
        ("go-licenses", "github.com/google/go-licenses@latest"),
    ]:
        if not _which(tool):
            _run(["go", "install", pkg], timeout=120)


def _ensure_ruby_tools() -> None:
    if not _which("gem"):
        return
    for tool in ["brakeman", "rubocop", "bundle-audit"]:
        if not _which(tool):
            _run(["gem", "install", tool, "--no-document"], timeout=120)


def _ensure_elixir_tools() -> None:
    if not _which("mix"):
        return
    _run(["mix", "local.hex", "--force"], timeout=60)


def _ensure_rust_tools() -> None:
    if not _which("cargo"):
        return
    for tool, pkg in [("cargo-audit", "cargo-audit"), ("cargo-deny", "cargo-deny")]:
        if not _which(tool):
            _run(["cargo", "install", pkg], timeout=180)


def _install_gitleaks() -> None:
    """Install gitleaks binary. Tries package managers first, then GitHub release."""
    # Try platform package managers
    if _which("brew"):
        if _run(["brew", "install", "gitleaks"], timeout=120).returncode == 0:
            return
    if sys.platform == "win32":
        if _which("scoop") and _run(["scoop", "install", "gitleaks"], timeout=120).returncode == 0:
            return
        if _which("choco") and _run(["choco", "install", "gitleaks", "-y"], timeout=120).returncode == 0:
            return
    if _which("go"):
        if _run(["go", "install", "github.com/gitleaks/gitleaks/v8@latest"], timeout=120).returncode == 0:
            return

    # Fall back to downloading from GitHub releases
    _download_gitleaks_binary()


def _download_gitleaks_binary() -> None:
    """Download gitleaks binary from GitHub releases into ~/.local/bin."""
    system = platform.system().lower()  # linux, darwin, windows
    machine = platform.machine().lower()
    arch_map = {"x86_64": "x64", "amd64": "x64", "aarch64": "arm64", "arm64": "arm64"}
    arch = arch_map.get(machine)
    if not arch:
        return

    ext = "zip" if system == "windows" else "tar.gz"
    # gitleaks release naming: gitleaks_{version}_{os}_{arch}.{ext}
    # Use latest redirect to find current version
    version = "8.21.2"  # pinned known-good version
    name = f"gitleaks_{version}_{system}_{arch}.{ext}"
    url = f"https://github.com/gitleaks/gitleaks/releases/download/v{version}/{name}"

    # Install to ~/.local/bin (Linux/macOS) or ~/AppData/Local/Programs (Windows)
    if system == "windows":
        bin_dir = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "Programs" / "gitleaks"
    else:
        bin_dir = Path.home() / ".local" / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)

    try:
        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp) / name
            urllib.request.urlretrieve(url, archive)

            if ext == "zip":
                with zipfile.ZipFile(archive) as zf:
                    zf.extractall(tmp)
            else:
                import tarfile
                with tarfile.open(archive) as tf:
                    tf.extractall(tmp)

            binary_name = "gitleaks.exe" if system == "windows" else "gitleaks"
            src = Path(tmp) / binary_name
            dst = bin_dir / binary_name
            if src.exists():
                dst.write_bytes(src.read_bytes())
                dst.chmod(0o755)

                # Ensure bin_dir is on PATH for this process
                current_path = os.environ.get("PATH", "")
                if str(bin_dir) not in current_path:
                    os.environ["PATH"] = f"{bin_dir}{os.pathsep}{current_path}"
    except Exception:
        pass  # best-effort — scan proceeds without gitleaks


def _files_with_ext(files: list[str], *exts: str) -> list[str]:
    """Filter files by extension(s)."""
    ext_set = set(exts)
    return [f for f in files if Path(f).suffix in ext_set]


def _dirs_of(files: list[str]) -> list[str]:
    """Unique parent directories of existing files."""
    return list({str(Path(f).parent) for f in files if Path(f).exists()})


# ===========================================================================
# Python
# ===========================================================================

def run_bandit(files: list[str]) -> list[Finding]:
    """Python SAST — injection, eval, hardcoded creds, weak crypto."""
    py = _files_with_ext(files, ".py")
    if not py or not _which("bandit"):
        return []

    result = _run(["bandit", "-f", "json", "-q", "--"] + py, timeout=120)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for r in data.get("results", []):
            findings.append(Finding(
                tool="bandit",
                severity=r.get("issue_severity", "MEDIUM").upper(),
                file=r.get("filename", ""),
                line=r.get("line_number"),
                message=f"{r.get('issue_text', '')} (confidence: {r.get('issue_confidence', 'unknown')})",
                rule_id=r.get("test_id"),
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


def run_ruff(files: list[str]) -> list[Finding]:
    """Ruff default rules (includes security S-rules)."""
    py = _files_with_ext(files, ".py")
    if not py or not _which("ruff"):
        return []

    result = _run(["ruff", "check", "--output-format", "json", "--"] + py, timeout=60)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else []
        for r in data:
            code = r.get("code", "")
            sev = "MEDIUM" if code.startswith("S") else "LOW"
            findings.append(Finding(
                tool="ruff",
                severity=sev,
                file=r.get("filename", ""),
                line=r.get("location", {}).get("row"),
                message=r.get("message", ""),
                rule_id=code,
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


# Ruff quality rule sets:
# C90=McCabe complexity, SIM=simplify, PIE=misc smells, RET=return style,
# ARG=unused args, ERA=commented-out code, PL=pylint (complexity, refactor)
_QUALITY_RULES = "C90,SIM,PIE,RET,ARG,ERA,PLR,PLC,PLE,PLW"
_QUALITY_SEV: dict[str, str] = {
    "C90": "MEDIUM", "PLR": "MEDIUM", "PLE": "MEDIUM",
    "ERA": "LOW", "ARG": "LOW", "SIM": "LOW",
    "PIE": "LOW", "RET": "LOW", "PLC": "LOW", "PLW": "LOW",
}


def run_ruff_quality(files: list[str]) -> list[Finding]:
    """Ruff code quality: complexity, dead code, smells."""
    py = _files_with_ext(files, ".py")
    if not py or not _which("ruff"):
        return []

    result = _run(
        ["ruff", "check", "--select", _QUALITY_RULES,
         "--output-format", "json", "--"] + py,
        timeout=60,
    )
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else []
        for r in data:
            code = r.get("code", "")
            sev = "LOW"
            for prefix, s in _QUALITY_SEV.items():
                if code.startswith(prefix):
                    sev = s
                    break
            findings.append(Finding(
                tool="ruff-quality",
                severity=sev,
                file=r.get("filename", ""),
                line=r.get("location", {}).get("row"),
                message=r.get("message", ""),
                rule_id=code,
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


# ===========================================================================
# Multi-language (always available)
# ===========================================================================

def run_semgrep(files: list[str]) -> list[Finding]:
    """Semgrep OWASP Top 10 + security audit — works on most languages."""
    if not _which("semgrep"):
        return []

    cmd = [
        "semgrep", "--json", "--quiet",
        "--config", "p/owasp-top-ten",
        "--config", "p/security-audit",
    ] + files
    result = _run(cmd, timeout=120)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        sev_map = {"ERROR": "HIGH", "WARNING": "MEDIUM", "INFO": "LOW"}
        for r in data.get("results", []):
            findings.append(Finding(
                tool="semgrep",
                severity=sev_map.get(r.get("extra", {}).get("severity", ""), "MEDIUM"),
                file=r.get("path", ""),
                line=r.get("start", {}).get("line"),
                message=r.get("extra", {}).get("message", r.get("check_id", "")),
                rule_id=r.get("check_id"),
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


def run_gitleaks(files: list[str]) -> list[Finding]:
    """Secrets detection in source code (language-agnostic)."""
    if not _which("gitleaks"):
        return []

    existing = [f for f in files if Path(f).is_file()]
    if not existing:
        return []

    findings = []
    # Copy files into a temp dir so gitleaks only scans what we want.
    # Using --source on the project dir causes permission errors when
    # gitleaks walks into restricted directories.
    with tempfile.TemporaryDirectory() as scan_dir:
        # Map temp names back to originals
        temp_to_orig: dict[str, str] = {}
        for f in existing:
            dest = Path(scan_dir) / Path(f).name
            counter = 0
            while dest.exists():
                counter += 1
                dest = Path(scan_dir) / f"{Path(f).stem}_{counter}{Path(f).suffix}"
            try:
                dest.write_bytes(Path(f).read_bytes())
                temp_to_orig[dest.name] = f
            except (OSError, PermissionError):
                continue

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
            tmp_path = tmp.name

        _run([
            "gitleaks", "detect", "--no-git",
            f"--source={scan_dir}", "--report-format=json",
            f"--report-path={tmp_path}", "--no-banner",
        ], timeout=60)

        try:
            report = json.loads(Path(tmp_path).read_text())
            for r in report if isinstance(report, list) else []:
                reported_file = r.get("File", "")
                orig = temp_to_orig.get(Path(reported_file).name, reported_file)
                findings.append(Finding(
                    tool="gitleaks",
                    severity="CRITICAL",
                    file=orig,
                    line=r.get("StartLine"),
                    message=f"Secret detected: {r.get('Description', 'unknown')} (rule: {r.get('RuleID', '')})",
                    rule_id=r.get("RuleID"),
                ))
        except (json.JSONDecodeError, FileNotFoundError):
            pass
        finally:
            Path(tmp_path).unlink(missing_ok=True)
    return findings


# ===========================================================================
# JavaScript / TypeScript
# ===========================================================================

def _run_eslint(files: list[str], tool_name: str, rules: str) -> list[Finding]:
    js = _files_with_ext(files, ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs")
    if not js or not _which("npx"):
        return []

    result = _run(
        ["npx", "--yes", "eslint", "--format", "json", "--no-eslintrc",
         "--rule", rules, "--"] + js,
        timeout=120,
    )
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else []
        for file_result in data:
            for msg in file_result.get("messages", []):
                sev = "HIGH" if msg.get("severity", 1) == 2 else "MEDIUM"
                findings.append(Finding(
                    tool=tool_name,
                    severity=sev,
                    file=file_result.get("filePath", ""),
                    line=msg.get("line"),
                    message=msg.get("message", ""),
                    rule_id=msg.get("ruleId"),
                ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


def run_eslint_security(files: list[str]) -> list[Finding]:
    """ESLint security plugin — object injection, eval, CSRF, unsafe regex."""
    return _run_eslint(files, "eslint-security", (
        '{"security/detect-object-injection": "warn", '
        '"security/detect-non-literal-regexp": "warn", '
        '"security/detect-unsafe-regex": "warn", '
        '"security/detect-buffer-noassert": "warn", '
        '"security/detect-eval-with-expression": "error", '
        '"security/detect-no-csrf-before-method-override": "error", '
        '"security/detect-possible-timing-attacks": "warn"}'
    ))


def run_eslint_quality(files: list[str]) -> list[Finding]:
    """ESLint quality — complexity, unused vars, nesting, param count."""
    return _run_eslint(files, "eslint-quality", (
        '{"complexity": ["warn", 15], '
        '"max-depth": ["warn", 4], '
        '"max-nested-callbacks": ["warn", 3], '
        '"max-params": ["warn", 5], '
        '"no-unused-vars": "warn", '
        '"no-shadow": "warn", '
        '"consistent-return": "warn", '
        '"no-else-return": "warn", '
        '"no-lonely-if": "warn", '
        '"prefer-const": "warn"}'
    ))


# ===========================================================================
# Go
# ===========================================================================

def run_gosec(files: list[str]) -> list[Finding]:
    """Go security scanner."""
    go = _files_with_ext(files, ".go")
    if not go or not _which("gosec"):
        return []

    go_dirs = [d + "/..." for d in _dirs_of(go)]
    result = _run(["gosec", "-fmt=json", "-quiet"] + go_dirs, timeout=120)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for issue in data.get("Issues", []):
            findings.append(Finding(
                tool="gosec",
                severity=issue.get("severity", "MEDIUM").upper(),
                file=issue.get("file", ""),
                line=int(issue.get("line", 0)) or None,
                message=issue.get("details", ""),
                rule_id=issue.get("rule_id"),
            ))
    except (json.JSONDecodeError, KeyError, ValueError):
        pass
    return findings


def run_go_vet(files: list[str]) -> list[Finding]:
    """Go vet (built-in) + staticcheck for quality and common mistakes."""
    go = _files_with_ext(files, ".go")
    if not go:
        return []

    dirs = _dirs_of(go)
    findings = []

    if _which("go"):
        for d in dirs:
            result = _run(["go", "vet", "./..."], timeout=60, cwd=d)
            for line in result.stderr.strip().splitlines():
                if ".go:" in line:
                    parts = line.split(":", 3)
                    if len(parts) >= 4:
                        findings.append(Finding(
                            tool="go-vet",
                            severity="MEDIUM",
                            file=parts[0],
                            line=int(parts[1]) if parts[1].isdigit() else None,
                            message=parts[3].strip(),
                        ))

    if _which("staticcheck"):
        go_dirs = [d + "/..." for d in dirs]
        result = _run(["staticcheck", "-f", "json"] + go_dirs, timeout=120)
        for line in result.stdout.strip().splitlines():
            try:
                r = json.loads(line)
                findings.append(Finding(
                    tool="staticcheck",
                    severity="MEDIUM" if r.get("severity", "") == "error" else "LOW",
                    file=r.get("location", {}).get("file", ""),
                    line=r.get("location", {}).get("line"),
                    message=r.get("message", ""),
                    rule_id=r.get("code"),
                ))
            except (json.JSONDecodeError, KeyError):
                continue
    return findings


# ===========================================================================
# Java / Kotlin
# ===========================================================================

def run_pmd(files: list[str]) -> list[Finding]:
    """PMD — Java/Kotlin code quality + security (complexity, dead code, smells)."""
    jk = _files_with_ext(files, ".java", ".kt", ".kts")
    if not jk or not _which("pmd"):
        return []

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write("\n".join(jk))
        filelist_path = f.name

    result = _run([
        "pmd", "check",
        "--file-list", filelist_path,
        "--format", "json",
        "--rulesets", "rulesets/java/quickstart.xml",
        "--no-progress",
    ], timeout=120)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for violation in data.get("files", []):
            for v in violation.get("violations", []):
                prio = v.get("priority", 3)
                sev = "HIGH" if prio <= 1 else "MEDIUM" if prio <= 3 else "LOW"
                findings.append(Finding(
                    tool="pmd",
                    severity=sev,
                    file=violation.get("filename", ""),
                    line=v.get("beginLine"),
                    message=v.get("message", "").strip(),
                    rule_id=v.get("rule"),
                ))
    except (json.JSONDecodeError, KeyError):
        pass
    finally:
        Path(filelist_path).unlink(missing_ok=True)
    return findings


def run_detekt(files: list[str]) -> list[Finding]:
    """Detekt — Kotlin static analysis (complexity, smells, style)."""
    kt = _files_with_ext(files, ".kt", ".kts")
    if not kt or not _which("detekt-cli"):
        return []

    # detekt works on directories
    dirs = _dirs_of(kt)
    input_paths = ",".join(dirs)
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
        tmp_path = tmp.name

    _run([
        "detekt-cli",
        "--input", input_paths,
        "--report", f"json:{tmp_path}",
    ], timeout=120)
    findings = []
    try:
        data = json.loads(Path(tmp_path).read_text())
        for f_entry in data if isinstance(data, list) else []:
            for issue in f_entry.get("findings", []):
                sev_map = {"error": "HIGH", "warning": "MEDIUM", "info": "LOW"}
                findings.append(Finding(
                    tool="detekt",
                    severity=sev_map.get(issue.get("severity", ""), "MEDIUM"),
                    file=issue.get("location", {}).get("file", ""),
                    line=issue.get("location", {}).get("line"),
                    message=issue.get("message", ""),
                    rule_id=issue.get("id"),
                ))
    except (json.JSONDecodeError, FileNotFoundError, KeyError):
        pass
    finally:
        Path(tmp_path).unlink(missing_ok=True)
    return findings


# ===========================================================================
# C / C++
# ===========================================================================

def run_cppcheck(files: list[str]) -> list[Finding]:
    """Cppcheck — C/C++ static analysis (security, quality, undefined behavior)."""
    cc = _files_with_ext(files, ".c", ".h", ".cpp", ".cxx", ".cc", ".hpp", ".hxx")
    if not cc or not _which("cppcheck"):
        return []

    template = '{{"file":"{file}","line":{line},"severity":"{severity}","id":"{id}","message":"{message}"}}'
    result = _run([
        "cppcheck",
        "--enable=warning,style,performance,portability",
        f"--template={template}",
        "--quiet",
        "--force",
    ] + cc, timeout=120)

    findings = []
    # cppcheck writes to stderr
    for line in result.stderr.strip().splitlines():
        try:
            r = json.loads(line)
            sev_map = {"error": "HIGH", "warning": "MEDIUM", "style": "LOW",
                       "performance": "LOW", "portability": "LOW", "information": "INFO"}
            findings.append(Finding(
                tool="cppcheck",
                severity=sev_map.get(r.get("severity", ""), "MEDIUM"),
                file=r.get("file", ""),
                line=int(r.get("line", 0)) or None,
                message=r.get("message", ""),
                rule_id=r.get("id"),
            ))
        except (json.JSONDecodeError, KeyError, ValueError):
            continue
    return findings


def run_flawfinder(files: list[str]) -> list[Finding]:
    """Flawfinder — C/C++ security scanner (buffer overflows, format strings)."""
    cc = _files_with_ext(files, ".c", ".h", ".cpp", ".cxx", ".cc", ".hpp", ".hxx")
    if not cc or not _which("flawfinder"):
        return []

    result = _run([
        "flawfinder", "--csv", "--quiet", "--",
    ] + cc, timeout=120)

    findings = []
    for line in result.stdout.strip().splitlines():
        # CSV: file,line,column,context,warning,level,category,name
        parts = line.split(",")
        if len(parts) < 6 or parts[0] == "File":
            continue
        try:
            level = int(parts[5])
            sev = "HIGH" if level >= 4 else "MEDIUM" if level >= 2 else "LOW"
            findings.append(Finding(
                tool="flawfinder",
                severity=sev,
                file=parts[0],
                line=int(parts[1]) if parts[1].isdigit() else None,
                message=parts[4] if len(parts) > 4 else "",
                rule_id=parts[7] if len(parts) > 7 else None,
            ))
        except (ValueError, IndexError):
            continue
    return findings


# ===========================================================================
# C#
# ===========================================================================

def run_dotnet_analyzers(files: list[str]) -> list[Finding]:
    """dotnet build with analyzers — C# security + quality."""
    cs = _files_with_ext(files, ".cs")
    if not cs or not _which("dotnet"):
        return []

    # Find .csproj or .sln in parent directories
    dirs = _dirs_of(cs)
    project_file = None
    for d in dirs:
        p = Path(d)
        while p != p.parent:
            csproj = list(p.glob("*.csproj")) + list(p.glob("*.sln"))
            if csproj:
                project_file = str(csproj[0])
                break
            p = p.parent
        if project_file:
            break

    if not project_file:
        return []

    result = _run([
        "dotnet", "build", project_file,
        "--no-restore", "-warnaserror",
        "-p:TreatWarningsAsErrors=false",
        "/flp:v=quiet",
    ], timeout=180)

    findings = []
    # Parse MSBuild output: file(line,col): warning CODE: message
    for line in (result.stdout + result.stderr).splitlines():
        if ": warning " in line or ": error " in line:
            try:
                file_part, rest = line.split("): ", 1)
                file_loc = file_part.split("(")
                filepath = file_loc[0].strip()
                line_num = None
                if len(file_loc) > 1:
                    loc_parts = file_loc[1].split(",")
                    line_num = int(loc_parts[0]) if loc_parts[0].isdigit() else None

                is_error = ": error " in rest
                parts = rest.split(": ", 1)
                severity_code = parts[0].strip()  # "warning CS1234" or "error CS1234"
                code = severity_code.split()[-1] if severity_code else None
                message = parts[1].strip() if len(parts) > 1 else ""

                findings.append(Finding(
                    tool="dotnet-analyzers",
                    severity="HIGH" if is_error else "MEDIUM",
                    file=filepath,
                    line=line_num,
                    message=message,
                    rule_id=code,
                ))
            except (ValueError, IndexError):
                continue
    return findings


# ===========================================================================
# Rust
# ===========================================================================

def run_clippy(files: list[str]) -> list[Finding]:
    """Clippy — Rust linter (quality, complexity, correctness, style)."""
    rs = _files_with_ext(files, ".rs")
    if not rs or not _which("cargo"):
        return []

    # Find Cargo.toml
    cargo_dir = None
    for d in _dirs_of(rs):
        p = Path(d)
        while p != p.parent:
            if (p / "Cargo.toml").exists():
                cargo_dir = str(p)
                break
            p = p.parent
        if cargo_dir:
            break

    if not cargo_dir:
        return []

    result = _run([
        "cargo", "clippy", "--message-format=json", "--quiet", "--",
        "-W", "clippy::complexity",
        "-W", "clippy::perf",
        "-W", "clippy::style",
        "-W", "clippy::suspicious",
    ], timeout=180, cwd=cargo_dir)

    findings = []
    for line in result.stdout.strip().splitlines():
        try:
            msg = json.loads(line)
            if msg.get("reason") != "compiler-message":
                continue
            m = msg.get("message", {})
            level = m.get("level", "")
            if level not in ("warning", "error"):
                continue

            spans = m.get("spans", [])
            primary = next((s for s in spans if s.get("is_primary")), spans[0] if spans else {})

            sev = "HIGH" if level == "error" else "MEDIUM"
            code_obj = m.get("code") or {}
            findings.append(Finding(
                tool="clippy",
                severity=sev,
                file=primary.get("file_name", ""),
                line=primary.get("line_start"),
                message=m.get("message", ""),
                rule_id=code_obj.get("code"),
            ))
        except (json.JSONDecodeError, KeyError, StopIteration):
            continue
    return findings


def run_cargo_audit(files: list[str]) -> list[Finding]:
    """cargo-audit — Rust dependency vulnerability scanner."""
    rs = _files_with_ext(files, ".rs", ".toml")
    if not rs or not _which("cargo-audit"):
        return []

    cargo_dir = None
    for d in _dirs_of(rs):
        p = Path(d)
        while p != p.parent:
            if (p / "Cargo.lock").exists():
                cargo_dir = str(p)
                break
            p = p.parent
        if cargo_dir:
            break

    if not cargo_dir:
        return []

    result = _run(["cargo-audit", "audit", "--json"], timeout=120, cwd=cargo_dir)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for vuln in data.get("vulnerabilities", {}).get("list", []):
            advisory = vuln.get("advisory", {})
            findings.append(Finding(
                tool="cargo-audit",
                severity="HIGH",
                file="Cargo.lock",
                line=None,
                message=f"{advisory.get('title', 'Unknown')} in {vuln.get('package', {}).get('name', '?')}",
                rule_id=advisory.get("id"),
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


# ===========================================================================
# Elixir
# ===========================================================================

def run_credo(files: list[str]) -> list[Finding]:
    """Credo — Elixir code quality (complexity, readability, refactoring)."""
    ex = _files_with_ext(files, ".ex", ".exs")
    if not ex or not _which("mix"):
        return []

    mix_dir = None
    for d in _dirs_of(ex):
        p = Path(d)
        while p != p.parent:
            if (p / "mix.exs").exists():
                mix_dir = str(p)
                break
            p = p.parent
        if mix_dir:
            break

    if not mix_dir:
        return []

    result = _run(["mix", "credo", "--format", "json", "--strict"], timeout=120, cwd=mix_dir)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for issue in data.get("issues", []):
            prio_map = {"high": "MEDIUM", "higher": "MEDIUM", "low": "LOW",
                        "normal": "LOW", "ignore": "INFO"}
            findings.append(Finding(
                tool="credo",
                severity=prio_map.get(issue.get("priority", ""), "LOW"),
                file=issue.get("filename", ""),
                line=issue.get("line_no"),
                message=issue.get("message", ""),
                rule_id=issue.get("check"),
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


def run_sobelow(files: list[str]) -> list[Finding]:
    """Sobelow — Phoenix/Elixir security scanner (XSS, SQL injection, RCE)."""
    ex = _files_with_ext(files, ".ex", ".exs")
    if not ex or not _which("mix"):
        return []

    mix_dir = None
    for d in _dirs_of(ex):
        p = Path(d)
        while p != p.parent:
            if (p / "mix.exs").exists():
                mix_dir = str(p)
                break
            p = p.parent
        if mix_dir:
            break

    if not mix_dir:
        return []

    result = _run(["mix", "sobelow", "--format", "json", "--quiet"], timeout=120, cwd=mix_dir)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for vuln in data.get("findings", data) if isinstance(data, dict) else data:
            if isinstance(vuln, dict):
                sev_map = {"high": "HIGH", "medium": "MEDIUM", "low": "LOW"}
                findings.append(Finding(
                    tool="sobelow",
                    severity=sev_map.get(vuln.get("confidence", ""), "MEDIUM"),
                    file=vuln.get("file", ""),
                    line=vuln.get("line"),
                    message=vuln.get("type", ""),
                    rule_id=vuln.get("type"),
                ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


# ===========================================================================
# Ruby
# ===========================================================================

def run_brakeman(files: list[str]) -> list[Finding]:
    """Brakeman — Ruby on Rails security scanner."""
    rb = _files_with_ext(files, ".rb", ".erb")
    if not rb or not _which("brakeman"):
        return []

    # Find Rails root (Gemfile)
    rails_root = None
    for d in _dirs_of(rb):
        p = Path(d)
        while p != p.parent:
            if (p / "Gemfile").exists() and (p / "app").is_dir():
                rails_root = str(p)
                break
            p = p.parent
        if rails_root:
            break

    if not rails_root:
        return []

    result = _run(["brakeman", "-f", "json", "-q", "-p", rails_root], timeout=120)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for w in data.get("warnings", []):
            conf_map = {"High": "HIGH", "Medium": "MEDIUM", "Weak": "LOW"}
            findings.append(Finding(
                tool="brakeman",
                severity=conf_map.get(w.get("confidence", ""), "MEDIUM"),
                file=w.get("file", ""),
                line=w.get("line"),
                message=w.get("message", ""),
                rule_id=w.get("warning_type"),
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


def run_rubocop(files: list[str]) -> list[Finding]:
    """RuboCop — Ruby code quality (complexity, style, smells)."""
    rb = _files_with_ext(files, ".rb")
    if not rb or not _which("rubocop"):
        return []

    result = _run(["rubocop", "--format", "json", "--force-exclusion", "--"] + rb, timeout=120)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for f_entry in data.get("files", []):
            for offense in f_entry.get("offenses", []):
                sev_map = {"fatal": "HIGH", "error": "HIGH", "warning": "MEDIUM",
                           "convention": "LOW", "refactor": "LOW", "info": "INFO"}
                findings.append(Finding(
                    tool="rubocop",
                    severity=sev_map.get(offense.get("severity", ""), "LOW"),
                    file=f_entry.get("path", ""),
                    line=offense.get("location", {}).get("start_line"),
                    message=offense.get("message", ""),
                    rule_id=offense.get("cop_name"),
                ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


# ===========================================================================
# PHP
# ===========================================================================

def run_phpstan(files: list[str]) -> list[Finding]:
    """PHPStan — PHP static analysis (type errors, dead code, quality)."""
    php = _files_with_ext(files, ".php")
    if not php or not _which("phpstan"):
        return []

    result = _run(["phpstan", "analyse", "--error-format=json", "--no-progress", "--"] + php, timeout=120)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for f_entry in data.get("files", {}).values():
            for msg in f_entry.get("messages", []):
                findings.append(Finding(
                    tool="phpstan",
                    severity="MEDIUM",
                    file=msg.get("file", f_entry.get("file", "")),
                    line=msg.get("line"),
                    message=msg.get("message", ""),
                ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


# ===========================================================================
# Swift
# ===========================================================================

def run_swiftlint(files: list[str]) -> list[Finding]:
    """SwiftLint — Swift code quality and style."""
    swift = _files_with_ext(files, ".swift")
    if not swift or not _which("swiftlint"):
        return []

    result = _run(["swiftlint", "lint", "--reporter", "json", "--quiet", "--"] + swift, timeout=120)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else []
        for r in data:
            sev = "MEDIUM" if r.get("severity", "") == "error" else "LOW"
            findings.append(Finding(
                tool="swiftlint",
                severity=sev,
                file=r.get("file", ""),
                line=r.get("line"),
                message=r.get("reason", ""),
                rule_id=r.get("rule_id"),
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


# ===========================================================================
# Dart / Flutter
# ===========================================================================

def run_dart_analyze(files: list[str]) -> list[Finding]:
    """Dart analyzer — code quality, type errors, lints."""
    dart = _files_with_ext(files, ".dart")
    if not dart or not _which("dart"):
        return []

    # Find project root (pubspec.yaml)
    proj_dir = None
    for d in _dirs_of(dart):
        p = Path(d)
        while p != p.parent:
            if (p / "pubspec.yaml").exists():
                proj_dir = str(p)
                break
            p = p.parent
        if proj_dir:
            break

    if not proj_dir:
        return []

    result = _run(["dart", "analyze", "--format=json", proj_dir], timeout=120)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for d_entry in data.get("diagnostics", []):
            sev_map = {"ERROR": "HIGH", "WARNING": "MEDIUM", "INFO": "LOW"}
            loc = d_entry.get("location", {})
            findings.append(Finding(
                tool="dart-analyze",
                severity=sev_map.get(d_entry.get("severity", ""), "LOW"),
                file=loc.get("file", ""),
                line=loc.get("range", {}).get("start", {}).get("line"),
                message=d_entry.get("problemMessage", ""),
                rule_id=d_entry.get("code"),
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


# ===========================================================================
# Dependency License Compliance
# ===========================================================================

# Copyleft / restrictive licenses that can contaminate commercial projects
_COPYLEFT_CRITICAL = {
    "AGPL-3.0", "AGPL-3.0-only", "AGPL-3.0-or-later",
    "SSPL-1.0", "SSPL",
}
_COPYLEFT_HIGH = {
    "GPL-3.0", "GPL-3.0-only", "GPL-3.0-or-later",
    "GPL-2.0", "GPL-2.0-only", "GPL-2.0-or-later",
    "EUPL-1.1", "EUPL-1.2",
    "OSL-3.0", "CPAL-1.0",
}
_PERMISSIVE = {
    "MIT", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause", "ISC",
    "0BSD", "Unlicense", "CC0-1.0", "Zlib", "BSL-1.0",
    "MPL-2.0",  # weak copyleft, generally safe for SaaS
    "WTFPL", "Artistic-2.0", "PostgreSQL", "Python-2.0",
}


def _classify_license(license_str: str) -> str:
    """Classify a license string into a severity level."""
    if not license_str or license_str in ("UNKNOWN", "Unknown", ""):
        return "MEDIUM"
    normalized = license_str.strip()
    # Check exact matches first
    if normalized in _COPYLEFT_CRITICAL:
        return "CRITICAL"
    if normalized in _COPYLEFT_HIGH:
        return "HIGH"
    if normalized in _PERMISSIVE:
        return "INFO"
    # Substring checks for common variations
    upper = normalized.upper()
    if "AGPL" in upper or "SSPL" in upper:
        return "CRITICAL"
    if "GPL" in upper:
        return "HIGH"
    if any(p in upper for p in ("MIT", "APACHE", "BSD", "ISC")):
        return "INFO"
    return "MEDIUM"  # unknown license — flag for review


def _find_project_root(files: list[str], marker: str) -> str | None:
    """Walk up from file dirs to find a project root containing marker."""
    for d in _dirs_of(files):
        p = Path(d)
        while p != p.parent:
            if (p / marker).exists():
                return str(p)
            p = p.parent
    return None


def run_pip_licenses(files: list[str]) -> list[Finding]:
    """pip-licenses — Python dependency license checker."""
    py = _files_with_ext(files, ".py")
    if not py or not _which("pip-licenses"):
        return []

    # Look for a venv in the project
    proj = _find_project_root(py, "pyproject.toml") or _find_project_root(py, "requirements.txt")
    if not proj:
        return []

    # Check for a local venv to inspect
    venv_python = None
    for venv_dir in [".venv", "venv", "env"]:
        candidate = Path(proj) / venv_dir / "bin" / "python"
        if candidate.exists():
            venv_python = str(candidate)
            break

    cmd = ["pip-licenses", "--format=json", "--with-license-file", "--no-license-path"]
    if venv_python:
        cmd = [venv_python, "-m", "piplicenses", "--format=json", "--with-license-file", "--no-license-path"]

    result = _run(cmd, timeout=60, cwd=proj)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else []
        for pkg in data:
            license_name = pkg.get("License", "UNKNOWN")
            sev = _classify_license(license_name)
            if sev == "INFO":
                continue  # Don't report permissive licenses
            findings.append(Finding(
                tool="pip-licenses",
                severity=sev,
                file=pkg.get("Name", ""),
                line=None,
                message=f"{pkg.get('Name', '?')}=={pkg.get('Version', '?')} uses {license_name}",
                rule_id=license_name,
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


def run_license_checker(files: list[str]) -> list[Finding]:
    """license-checker — Node.js dependency license checker."""
    js = _files_with_ext(files, ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs")
    if not js:
        return []

    proj = _find_project_root(js, "package.json")
    if not proj or not (Path(proj) / "node_modules").is_dir():
        return []

    if not _which("npx"):
        return []

    result = _run(
        ["npx", "--yes", "license-checker", "--json", "--production"],
        timeout=120, cwd=proj,
    )
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for pkg_name, info in data.items():
            if pkg_name.startswith("├") or pkg_name.startswith("└"):
                continue
            license_name = info.get("licenses", "UNKNOWN")
            if isinstance(license_name, list):
                license_name = license_name[0] if license_name else "UNKNOWN"
            # Handle "(MIT OR Apache-2.0)" style
            license_name = license_name.strip("()")

            sev = _classify_license(license_name)
            if sev == "INFO":
                continue
            findings.append(Finding(
                tool="license-checker",
                severity=sev,
                file=pkg_name,
                line=None,
                message=f"{pkg_name} uses {license_name}",
                rule_id=license_name,
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


def run_cargo_deny_licenses(files: list[str]) -> list[Finding]:
    """cargo-deny — Rust dependency license checker."""
    rs = _files_with_ext(files, ".rs", ".toml")
    if not rs or not _which("cargo-deny"):
        return []

    cargo_dir = _find_project_root(rs, "Cargo.toml")
    if not cargo_dir:
        return []

    result = _run(
        ["cargo-deny", "check", "licenses", "--format", "json"],
        timeout=120, cwd=cargo_dir,
    )
    findings = []
    for line in result.stdout.strip().splitlines():
        try:
            msg = json.loads(line)
            if msg.get("type") != "diagnostic":
                continue
            fields = msg.get("fields", {})
            severity = fields.get("severity", "")
            sev = "HIGH" if severity == "error" else "MEDIUM" if severity == "warning" else "LOW"
            findings.append(Finding(
                tool="cargo-deny",
                severity=sev,
                file="Cargo.toml",
                line=None,
                message=fields.get("message", ""),
                rule_id="license-check",
            ))
        except (json.JSONDecodeError, KeyError):
            continue
    return findings


def run_go_licenses(files: list[str]) -> list[Finding]:
    """go-licenses — Go dependency license checker."""
    go = _files_with_ext(files, ".go")
    if not go or not _which("go-licenses"):
        return []

    go_dir = _find_project_root(go, "go.mod")
    if not go_dir:
        return []

    result = _run(["go-licenses", "csv", "./..."], timeout=120, cwd=go_dir)
    findings = []
    for line in result.stdout.strip().splitlines():
        # Format: module,url,license_type
        parts = line.split(",")
        if len(parts) < 3:
            continue
        module, _, license_name = parts[0], parts[1], parts[2]
        sev = _classify_license(license_name)
        if sev == "INFO":
            continue
        findings.append(Finding(
            tool="go-licenses",
            severity=sev,
            file=module,
            line=None,
            message=f"{module} uses {license_name}",
            rule_id=license_name,
        ))
    return findings


def run_composer_licenses(files: list[str]) -> list[Finding]:
    """composer licenses — PHP dependency license checker."""
    php = _files_with_ext(files, ".php")
    if not php or not _which("composer"):
        return []

    proj = _find_project_root(php, "composer.json")
    if not proj:
        return []

    result = _run(["composer", "licenses", "--format=json", "--no-interaction"], timeout=60, cwd=proj)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for pkg_name, info in data.get("dependencies", {}).items():
            license_list = info.get("license", [])
            license_name = license_list[0] if license_list else "UNKNOWN"
            sev = _classify_license(license_name)
            if sev == "INFO":
                continue
            findings.append(Finding(
                tool="composer-licenses",
                severity=sev,
                file=pkg_name,
                line=None,
                message=f"{pkg_name} ({info.get('version', '?')}) uses {license_name}",
                rule_id=license_name,
            ))
    except (json.JSONDecodeError, KeyError):
        pass
    return findings


def run_bundle_audit(files: list[str]) -> list[Finding]:
    """bundle-audit — Ruby gem license + vulnerability checker."""
    rb = _files_with_ext(files, ".rb", ".erb")
    if not rb or not _which("bundle-audit"):
        return []

    proj = _find_project_root(rb, "Gemfile.lock")
    if not proj:
        return []

    # bundle-audit doesn't have JSON output, but we can check licenses via bundler
    # For license checking, use `gem specification` approach or bundler plugin
    # For now, run bundle-audit for vulnerability advisories
    result = _run(["bundle-audit", "check", "--update"], timeout=120, cwd=proj)
    findings = []
    # Parse text output: "Name: gem_name\nVersion: x.y.z\nAdvisory: CVE-...\nCriticality: High\nTitle: ..."
    current: dict[str, str] = {}
    for line in result.stdout.splitlines():
        line = line.strip()
        if line.startswith("Name:"):
            current = {"name": line.split(":", 1)[1].strip()}
        elif line.startswith("Version:"):
            current["version"] = line.split(":", 1)[1].strip()
        elif line.startswith("Advisory:"):
            current["advisory"] = line.split(":", 1)[1].strip()
        elif line.startswith("Criticality:"):
            current["criticality"] = line.split(":", 1)[1].strip()
        elif line.startswith("Title:"):
            current["title"] = line.split(":", 1)[1].strip()
        elif not line and current.get("name"):
            crit = current.get("criticality", "").lower()
            sev = "CRITICAL" if crit == "critical" else "HIGH" if crit == "high" else "MEDIUM"
            findings.append(Finding(
                tool="bundle-audit",
                severity=sev,
                file=f"{current.get('name', '?')}-{current.get('version', '?')}",
                line=None,
                message=f"{current.get('title', 'Advisory')} ({current.get('advisory', '')})",
                rule_id=current.get("advisory"),
            ))
            current = {}
    return findings


def run_mix_audit(files: list[str]) -> list[Finding]:
    """mix_audit — Elixir dependency vulnerability + license checker."""
    ex = _files_with_ext(files, ".ex", ".exs")
    if not ex or not _which("mix"):
        return []

    mix_dir = _find_project_root(ex, "mix.exs")
    if not mix_dir:
        return []

    # mix_audit for vulnerabilities
    result = _run(["mix", "deps.audit", "--format", "json"], timeout=120, cwd=mix_dir)
    findings = []
    try:
        data = json.loads(result.stdout) if result.stdout.strip() else {}
        for vuln in data.get("vulnerabilities", []):
            findings.append(Finding(
                tool="mix-audit",
                severity="HIGH",
                file=vuln.get("package", ""),
                line=None,
                message=f"{vuln.get('title', 'Advisory')} in {vuln.get('package', '?')}",
                rule_id=vuln.get("cve"),
            ))
    except (json.JSONDecodeError, KeyError):
        pass

    # hex.licenses for license checking
    result = _run(["mix", "hex.licenses"], timeout=60, cwd=mix_dir)
    for line in result.stdout.strip().splitlines():
        # Format: "package_name - license"
        if " - " in line:
            parts = line.split(" - ", 1)
            pkg = parts[0].strip()
            license_name = parts[1].strip() if len(parts) > 1 else "UNKNOWN"
            sev = _classify_license(license_name)
            if sev == "INFO":
                continue
            findings.append(Finding(
                tool="mix-licenses",
                severity=sev,
                file=pkg,
                line=None,
                message=f"{pkg} uses {license_name}",
                rule_id=license_name,
            ))
    return findings


# ===========================================================================
# Registry
# ===========================================================================

# Maps tag keywords to scanner functions (security + quality + licenses)
SCANNER_REGISTRY: dict[str, list] = {
    # Python
    "python":     [run_bandit, run_ruff, run_ruff_quality, run_pip_licenses, run_semgrep],
    "fastapi":    [run_bandit, run_ruff, run_ruff_quality, run_pip_licenses, run_semgrep],
    "django":     [run_bandit, run_ruff, run_ruff_quality, run_pip_licenses, run_semgrep],
    "flask":      [run_bandit, run_ruff, run_ruff_quality, run_pip_licenses, run_semgrep],
    # JavaScript / TypeScript
    "javascript": [run_eslint_security, run_eslint_quality, run_license_checker, run_semgrep],
    "typescript": [run_eslint_security, run_eslint_quality, run_license_checker, run_semgrep],
    "react":      [run_eslint_security, run_eslint_quality, run_license_checker, run_semgrep],
    "nextjs":     [run_eslint_security, run_eslint_quality, run_license_checker, run_semgrep],
    "node":       [run_eslint_security, run_eslint_quality, run_license_checker, run_semgrep],
    "vue":        [run_eslint_security, run_eslint_quality, run_license_checker, run_semgrep],
    "angular":    [run_eslint_security, run_eslint_quality, run_license_checker, run_semgrep],
    "svelte":     [run_eslint_security, run_eslint_quality, run_license_checker, run_semgrep],
    # Go
    "go":         [run_gosec, run_go_vet, run_go_licenses, run_semgrep],
    "golang":     [run_gosec, run_go_vet, run_go_licenses, run_semgrep],
    # Java
    "java":       [run_pmd, run_semgrep],
    "spring":     [run_pmd, run_semgrep],
    # Kotlin
    "kotlin":     [run_pmd, run_detekt, run_semgrep],
    # C / C++
    "c":          [run_cppcheck, run_flawfinder, run_semgrep],
    "cpp":        [run_cppcheck, run_flawfinder, run_semgrep],
    "c++":        [run_cppcheck, run_flawfinder, run_semgrep],
    # C#
    "csharp":     [run_dotnet_analyzers, run_semgrep],
    "c#":         [run_dotnet_analyzers, run_semgrep],
    "dotnet":     [run_dotnet_analyzers, run_semgrep],
    ".net":       [run_dotnet_analyzers, run_semgrep],
    # Rust
    "rust":       [run_clippy, run_cargo_audit, run_cargo_deny_licenses, run_semgrep],
    # Elixir
    "elixir":     [run_credo, run_sobelow, run_mix_audit, run_semgrep],
    "phoenix":    [run_credo, run_sobelow, run_mix_audit, run_semgrep],
    # Ruby
    "ruby":       [run_brakeman, run_rubocop, run_bundle_audit, run_semgrep],
    "rails":      [run_brakeman, run_rubocop, run_bundle_audit, run_semgrep],
    # PHP
    "php":        [run_phpstan, run_composer_licenses, run_semgrep],
    "laravel":    [run_phpstan, run_composer_licenses, run_semgrep],
    # Swift
    "swift":      [run_swiftlint, run_semgrep],
    "ios":        [run_swiftlint, run_semgrep],
    # Dart / Flutter
    "dart":       [run_dart_analyze, run_semgrep],
    "flutter":    [run_dart_analyze, run_semgrep],
}

# Always run these regardless of stack
UNIVERSAL_SCANNERS = [run_gitleaks]


def get_scanners_for_tags(tags: list[str]) -> list:
    """Return deduplicated scanner list for the given tags."""
    scanners = list(UNIVERSAL_SCANNERS)
    seen = {id(s) for s in scanners}
    for tag in tags:
        for scanner in SCANNER_REGISTRY.get(tag.lower(), []):
            if id(scanner) not in seen:
                scanners.append(scanner)
                seen.add(id(scanner))
    # If no tag matched any language-specific scanner, run semgrep as a catch-all
    if len(scanners) == len(UNIVERSAL_SCANNERS):
        scanners.append(run_semgrep)
    return scanners
