"""Detect project stack from AGENTS.md nacho tags or file extensions."""

import re
from pathlib import Path

# Pattern: <!-- nacho: username/context-name [tag1, tag2, tag3] -->
_NACHO_TAG_RE = re.compile(r"<!--\s*nacho:\s*\S+\s*\[([^\]]+)\]\s*-->")

# File extension to tag mapping (fallback when no nacho markers exist)
_EXT_TO_TAG: dict[str, str] = {
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".go": "go",
    ".rb": "ruby",
    ".erb": "ruby",
    ".rs": "rust",
    ".java": "java",
    ".kt": "kotlin",
    ".kts": "kotlin",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".cxx": "cpp",
    ".cc": "cpp",
    ".hpp": "cpp",
    ".hxx": "cpp",
    ".cs": "csharp",
    ".swift": "swift",
    ".php": "php",
    ".ex": "elixir",
    ".exs": "elixir",
    ".dart": "dart",
    ".html": "javascript",
    ".htm": "javascript",
    ".vue": "javascript",
    ".svelte": "javascript",
}


def detect_tags_from_agents_md(repo_path: Path) -> list[str]:
    """Parse <!-- nacho: ref [tags] --> markers from AGENTS.md."""
    agents_md = repo_path / "AGENTS.md"
    if not agents_md.exists():
        return []

    tags: set[str] = set()
    for match in _NACHO_TAG_RE.finditer(agents_md.read_text()):
        raw_tags = match.group(1)
        for tag in raw_tags.split(","):
            tag = tag.strip().lower()
            if tag:
                tags.add(tag)
    return sorted(tags)


def detect_tags_from_files(repo_path: Path) -> list[str]:
    """Infer stack from file extensions in the project (shallow scan)."""
    tags: set[str] = set()
    # Walk top 3 levels to keep it fast
    for pattern in ["*", "*/*", "*/*/*"]:
        for f in repo_path.glob(pattern):
            try:
                if f.is_file() and f.suffix in _EXT_TO_TAG:
                    tags.add(_EXT_TO_TAG[f.suffix])
            except (PermissionError, OSError):
                continue
    return sorted(tags)


def detect_tags(repo_path: Path) -> list[str]:
    """Detect project stack tags. Prefers AGENTS.md markers, falls back to file scan."""
    tags = detect_tags_from_agents_md(repo_path)
    if tags:
        return tags
    return detect_tags_from_files(repo_path)
