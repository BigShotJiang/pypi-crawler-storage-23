"""Security scanning — tool functions + CLI entry point.

Tool functions (scan_diff, scan_file, etc.) are registered by nacho_bot.mcp.server.
The `nacho-sec check` CLI entry point is used by git pre-commit hooks.
"""

import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

from nacho_bot.mcp.security.cache import is_cached, update_cache
from nacho_bot.mcp.security.detect import detect_tags
from nacho_bot.mcp.security.scanners import Finding, ensure_tools_for_tags, get_scanners_for_tags

# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------


@dataclass
class SessionState:
    findings: list[Finding] = field(default_factory=list)
    scans_run: int = 0
    files_scanned: set[str] = field(default_factory=set)

    def add_findings(self, new: list[Finding]) -> None:
        self.findings.extend(new)
        self.scans_run += 1

    def clear(self) -> None:
        self.findings.clear()
        self.scans_run = 0
        self.files_scanned.clear()


_state = SessionState()

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

SEV_ICONS = {"CRITICAL": "\U0001f534", "HIGH": "\U0001f7e0", "MEDIUM": "\U0001f7e1", "LOW": "\U0001f535", "INFO": "\u2139\ufe0f"}
SEV_ORDER = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]


def _get_changed_files(repo: Path, base_ref: str = "HEAD") -> list[str]:
    """Get changed files (staged + unstaged + untracked) relative to base_ref."""

    def _git(*args: str) -> set[str]:
        result = subprocess.run(
            ["git", "-C", str(repo)] + list(args),
            capture_output=True, text=True, timeout=10,
        )
        return set(result.stdout.strip().splitlines()) if result.stdout.strip() else set()

    changed = set()
    changed |= _git("diff", "--name-only", base_ref, "--")
    changed |= _git("diff", "--name-only", "--cached")
    changed |= _git("ls-files", "--others", "--exclude-standard")

    return [str(repo / f) for f in changed if (repo / f).is_file()]


def _run_scanners(files: list[str], repo_path: Path) -> list[Finding]:
    """Run the appropriate scanners for this project's stack."""
    tags = detect_tags(repo_path)
    ensure_tools_for_tags(tags)
    scanners = get_scanners_for_tags(tags)

    all_findings: list[Finding] = []
    for scanner in scanners:
        all_findings.extend(scanner(files))
    return all_findings


def _format_findings(findings: list[Finding], file_count: int,
                     timings: dict[str, float] | None = None) -> str:
    if not findings:
        timing_str = ""
        if timings:
            timing_str = f" ({', '.join(f'{k}: {v:.1f}s' for k, v in timings.items())})"
        return f"No findings. Scanned {file_count} file(s).{timing_str}"

    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    findings.sort(key=lambda f: sev_rank.get(f.severity, 5))

    lines = [f"Found {len(findings)} issue(s) in {file_count} file(s):", ""]
    for f in findings:
        icon = SEV_ICONS.get(f.severity, "")
        loc = f.file
        if f.line:
            loc += f":{f.line}"
        rule = f" [{f.rule_id}]" if f.rule_id else ""
        lines.append(f"{icon} **{f.severity}** ({f.tool}{rule}): {f.message}")
        lines.append(f"   {loc}")
        lines.append("")

    if timings:
        lines.append(f"Timings: {', '.join(f'{k}: {v:.1f}s' for k, v in timings.items())}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tool functions (imported by nacho-mcp to register as MCP tools)
# ---------------------------------------------------------------------------


def scan_diff(repo_path: str, base_ref: str = "HEAD") -> str:
    """Scan files changed since base_ref (default: uncommitted changes vs HEAD).

    Runs security scanners appropriate for the project's stack against only the
    changed files. Returns findings formatted for remediation.
    """
    repo = Path(repo_path).expanduser().resolve()
    if not (repo / ".git").is_dir():
        return f"Error: {repo} is not a git repository"

    abs_files = _get_changed_files(repo, base_ref)
    if not abs_files:
        return "No changed files detected."

    _state.files_scanned.update(abs_files)
    t0 = time.monotonic()
    findings = _run_scanners(abs_files, repo)
    elapsed = time.monotonic() - t0

    _state.add_findings(findings)
    update_cache(repo, abs_files)
    return _format_findings(findings, len(abs_files), {"total": elapsed})


def scan_file(file_paths: list[str]) -> str:
    """Scan specific files with security tools appropriate for the project stack.

    Accepts a list of absolute file paths. Returns findings formatted for remediation.
    """
    resolved = [str(Path(f).expanduser().resolve()) for f in file_paths]
    existing = [f for f in resolved if Path(f).is_file()]
    if not existing:
        return "Error: none of the provided files exist."

    # Infer repo root from first file; fall back to file's parent dir
    repo_path = Path(existing[0]).parent
    search = repo_path
    while search != search.parent:
        if (search / ".git").is_dir():
            repo_path = search
            break
        search = search.parent

    _state.files_scanned.update(existing)
    t0 = time.monotonic()
    findings = _run_scanners(existing, repo_path)
    elapsed = time.monotonic() - t0

    _state.add_findings(findings)
    return _format_findings(findings, len(existing), {"total": elapsed})


def security_report() -> str:
    """Generate a summary security report of all findings from this session."""
    if not _state.findings:
        return (
            f"Clean — {_state.scans_run} scan(s) run, "
            f"{len(_state.files_scanned)} file(s) scanned, 0 findings."
        )

    by_sev: dict[str, list[Finding]] = {}
    for f in _state.findings:
        by_sev.setdefault(f.severity, []).append(f)

    lines = [
        "## Security Report",
        f"Scans run: {_state.scans_run} | Files scanned: {len(_state.files_scanned)} "
        f"| Total findings: {len(_state.findings)}",
        "",
    ]

    for sev in SEV_ORDER:
        group = by_sev.get(sev, [])
        if not group:
            continue
        lines.append(f"### {SEV_ICONS.get(sev, '')} {sev} ({len(group)})")
        lines.append("")
        for f in group:
            loc = f.file
            if f.line:
                loc += f":{f.line}"
            rule = f" [{f.rule_id}]" if f.rule_id else ""
            lines.append(f"- **{f.tool}**{rule}: {f.message}")
            lines.append(f"  `{loc}`")
        lines.append("")

    return "\n".join(lines)


def clear_findings() -> str:
    """Clear all accumulated findings. Use between unrelated tasks."""
    count = len(_state.findings)
    _state.clear()
    return f"Cleared {count} finding(s)."


# ---------------------------------------------------------------------------
# CLI mode (for git pre-commit hook)
# ---------------------------------------------------------------------------


def cli_check() -> int:
    """Run scan on changed files, print findings, return exit code."""
    import argparse

    parser = argparse.ArgumentParser(prog="nacho-sec check")
    parser.add_argument("--quiet", action="store_true", help="Only print if findings exist")
    parser.add_argument("--repo", default=".", help="Repository path")
    args = parser.parse_args(sys.argv[2:])

    repo = Path(args.repo).resolve()
    if not (repo / ".git").is_dir():
        if not args.quiet:
            print(f"Not a git repository: {repo}", file=sys.stderr)
        return 1

    abs_files = _get_changed_files(repo)
    if not abs_files:
        if not args.quiet:
            print("No changed files.")
        return 0

    # Check cache — skip if already scanned these exact files
    if is_cached(repo, abs_files):
        if not args.quiet:
            print("Files unchanged since last scan — skipping.")
        return 0

    findings = _run_scanners(abs_files, repo)
    update_cache(repo, abs_files)

    if not findings:
        if not args.quiet:
            print(f"Clean. Scanned {len(abs_files)} file(s).")
        return 0

    # Print findings (always, even in quiet mode — there are issues)
    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    findings.sort(key=lambda f: sev_rank.get(f.severity, 5))

    print(f"\nnacho-sec: {len(findings)} issue(s) found in {len(abs_files)} file(s)\n")
    for f in findings:
        loc = f.file
        if f.line:
            loc += f":{f.line}"
        rule = f" [{f.rule_id}]" if f.rule_id else ""
        print(f"  {f.severity} ({f.tool}{rule}): {f.message}")
        print(f"    {loc}")

    # Block commit on CRITICAL or HIGH
    blocking = [f for f in findings if f.severity in ("CRITICAL", "HIGH")]
    if blocking:
        print(f"\nBlocked: {len(blocking)} CRITICAL/HIGH finding(s) must be fixed before commit.")
        return 1

    print(f"\n{len(findings)} non-blocking finding(s) (MEDIUM/LOW). Commit allowed.")
    return 0


# ---------------------------------------------------------------------------
# Entry point (CLI only — MCP tools are registered by nacho-mcp)
# ---------------------------------------------------------------------------


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        sys.exit(cli_check())
    else:
        print("nacho-sec: security scanning library for Nacho")
        print()
        print("Usage:")
        print("  nacho-sec check [--quiet] [--repo PATH]   Run security scan (git pre-commit hook)")
        print()
        print("MCP tools (scan_diff, scan_file, security_report, clear_findings)")
        print("are registered by the unified nacho-mcp server.")
        sys.exit(0)
