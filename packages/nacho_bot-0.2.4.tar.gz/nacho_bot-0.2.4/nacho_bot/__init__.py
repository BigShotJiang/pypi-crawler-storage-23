"""nacho-bot — CLI, MCP server, and security scanning for Nacho."""
