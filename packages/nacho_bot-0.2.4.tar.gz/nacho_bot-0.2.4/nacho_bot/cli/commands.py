import argparse
import getpass
import json
import os
import shutil
import subprocess
import sys
from importlib import resources as importlib_resources
from pathlib import Path

from nacho_bot.cli.api_client import APIClient
from nacho_bot.cli.config import (
    clear_token,
    get_provider,
    load_config,
    load_tracked_contexts,
    save_config,
    save_token,
    save_tracked_context,
)


# ── Helpers ──────────────────────────────────────────────────────────


def _extract_title(content: str) -> str:
    """Return the first # H1 heading from markdown content, stripped."""
    import re
    match = re.search(r"^#\s+(.+)$", content, re.MULTILINE)
    return match.group(1).strip() if match else ""


def _extract_short_description(content: str) -> str:
    """Return the first prose paragraph (non-heading, non-code, non-table, non-list)."""
    in_code = False
    for line in content.splitlines():
        if line.startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            continue
        t = line.strip()
        if t and not t.startswith(("#", "|", "-", ">", "!")):
            return t[:500]
    return ""


def _slug_from_path(file_path: str) -> str:
    """Derive a URL-safe context name from a filename."""
    import re
    stem = Path(file_path).stem
    slug = re.sub(r"[^a-zA-Z0-9_-]+", "-", stem).strip("-").lower()
    return slug[:100] or "my-context"


# ── Context Hub commands ─────────────────────────────────────────────


def cmd_login(args):
    """Login and store API token."""
    client = APIClient()
    email = input("Email: ")
    password = getpass.getpass("Password: ")

    try:
        data = client.login(email, password)
        save_token(data["access_token"])
        print("Logged in successfully!")
        print("Tip: For long-lived access, create an API token at https://nacho.bot/settings")
    except Exception as e:
        print(f"Login failed: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_token(args):
    """Store an API token directly."""
    token = args.token or getpass.getpass("API Token: ")
    save_token(token)
    print("Token saved.")


def cmd_logout(args):
    """Clear stored credentials."""
    clear_token()
    print("Logged out.")


def _push_tracked(client, file_path, tracked_meta, changelog=None):
    """Push a new version for a tracked context. Returns True on success."""
    name = tracked_meta["name"]
    existing = client.get_my_context(name)
    if not existing:
        print(f"Error: remote context '{name}' not found for tracked file '{file_path}'", file=sys.stderr)
        return False
    result = client.push_version(existing["id"], file_path, changelog=changelog)
    print(f"Pushed {existing['owner_username']}/{existing['name']} v{result['version']}")
    return True


def cmd_push(args):
    """Push a context file."""
    client = APIClient()
    file_path = args.file
    tracked = load_tracked_contexts()

    # nacho push .  — push all tracked contexts
    if file_path == ".":
        if not tracked:
            print("Error: no tracked contexts in .nacho/contexts.yml", file=sys.stderr)
            sys.exit(1)
        failed = False
        for fpath, meta in tracked.items():
            try:
                if not _push_tracked(client, fpath, meta, changelog=args.changelog):
                    failed = True
            except Exception as e:
                print(f"Push failed for {fpath}: {e}", file=sys.stderr)
                failed = True
        if failed:
            sys.exit(1)
        return

    # nacho push <file>
    if file_path in tracked:
        try:
            _push_tracked(client, file_path, tracked[file_path], changelog=args.changelog)
        except Exception as e:
            print(f"Push failed: {e}", file=sys.stderr)
            sys.exit(1)
        return

    # Untracked file — first push
    try:
        content = Path(file_path).read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        print(f"Error: cannot read {file_path}: {e}", file=sys.stderr)
        sys.exit(1)

    name = args.name or _slug_from_path(file_path)
    title = args.title or _extract_title(content) or name
    description = args.description or _extract_short_description(content) or None

    try:
        result = client.push(
            file_path=file_path,
            name=name,
            title=title,
            short_description=description,
            tags=args.tags or "",
            license=args.license,
        )
        context = result["context"]
        version = result["version"]
        print(f"Pushed {context['owner_username']}/{context['name']} v{version['version']}")

        meta = {"name": name, "title": title}
        if description:
            meta["description"] = description
        if args.tags:
            meta["tags"] = args.tags
        if args.license:
            meta["license"] = args.license
        save_tracked_context(file_path, meta)
    except Exception as e:
        print(f"Push failed: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_pull(args):
    """Pull a context file."""
    client = APIClient()

    ref = args.ref
    if "/" not in ref:
        print("Error: ref must be in format 'username/context-name'", file=sys.stderr)
        sys.exit(1)

    username, context_name = ref.split("/", 1)

    try:
        content = client.pull(username, context_name, version=args.version)
        output = args.output or f"{context_name}.md"

        if os.path.exists(output) and not args.force:
            answer = input(f"File '{output}' already exists. Replace? [y/N] ").strip().lower()
            if answer not in ("y", "yes"):
                print("Cancelled.")
                return

        with open(output, "wb") as f:
            f.write(content)
        print(f"Downloaded to {output}")

        if client.token:
            try:
                owned = client.get_my_context(context_name)
                if owned:
                    save_tracked_context(output, {
                        "name": context_name,
                        "title": owned.get("title", context_name),
                    })
            except Exception:
                pass
    except Exception as e:
        print(f"Pull failed: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_upvote(args):
    """Toggle upvote on a context."""
    client = APIClient()

    ref = args.ref
    if "/" not in ref:
        print("Error: ref must be in format 'username/context-name'", file=sys.stderr)
        sys.exit(1)

    username, context_name = ref.split("/", 1)

    try:
        result = client.upvote(username, context_name)
        if result["upvoted"]:
            print(f"Upvoted {ref} ({result['upvote_count']} upvotes)")
        else:
            print(f"Removed upvote from {ref} ({result['upvote_count']} upvotes)")
    except Exception as e:
        print(f"Upvote failed: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_search(args):
    """Search for contexts."""
    client = APIClient()

    try:
        result = client.search(args.query)
        items = result.get("items", [])
        if not items:
            print("No results found.")
            return

        for context in items:
            tags = ", ".join(context.get("tags", []))
            print(f"  {context['owner_username']}/{context['name']} - {context['title']}")
            if context.get("short_description"):
                print(f"    {context['short_description']}")
            if tags:
                print(f"    Tags: {tags}")
            print()
    except Exception as e:
        print(f"Search failed: {e}", file=sys.stderr)
        sys.exit(1)


# ── Builder setup commands ───────────────────────────────────────────


def _ensure_nacho_packages():
    """Install/upgrade nacho packages from PyPI."""
    print("  Updating Nacho packages...")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "--quiet", "nacho-bot"],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode == 0:
            print("  Nacho packages up to date")
            return
        # Retry with --break-system-packages for externally-managed environments (PEP 668)
        if "externally-managed-environment" in result.stderr:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", "--quiet",
                 "--break-system-packages", "nacho-bot"],
                capture_output=True, text=True, timeout=120,
            )
            if result.returncode == 0:
                print("  Nacho packages up to date")
                return
        print("  Warning: Could not update packages (continuing anyway)", file=sys.stderr)
    except Exception as e:
        print(f"  Warning: Could not update packages: {e}", file=sys.stderr)


def _setup_mcp_server(project_dir: Path):
    """Write .mcp.json in the project directory for project-scoped MCP registration."""
    mcp_file = project_dir / ".mcp.json"

    config = {}
    if mcp_file.exists():
        try:
            config = json.loads(mcp_file.read_text())
        except (json.JSONDecodeError, OSError):
            config = {}

    servers = config.setdefault("mcpServers", {})
    if "nacho" in servers:
        print("  MCP server already registered")
        return

    servers["nacho"] = {"command": "nacho-mcp", "args": []}
    mcp_file.write_text(json.dumps(config, indent=2) + "\n")
    print("  MCP server registered")


def _setup_slash_command(project_dir: Path):
    """Copy NACHO_LARGE.md to <project>/.claude/commands/nachoinit.md.

    The destination filename determines the slash command name in Claude Code.
    NACHO_LARGE.md is the source; nachoinit.md is just the installed command name.
    """
    commands_dir = project_dir / ".claude" / "commands"
    commands_dir.mkdir(parents=True, exist_ok=True)
    source = importlib_resources.files("nacho_bot.cli").joinpath("data", "NACHO_LARGE.md")
    (commands_dir / "nachoinit.md").write_text(source.read_text())
    print("  /nachoinit command installed")


def _setup_permissions():
    """Add Nacho MCP permissions to global Claude Code settings."""
    settings_file = Path.home() / ".claude" / "settings.json"

    settings = {}
    if settings_file.exists():
        try:
            settings = json.loads(settings_file.read_text())
        except (json.JSONDecodeError, OSError):
            settings = {}

    permissions = settings.setdefault("permissions", {})
    allow = permissions.setdefault("allow", [])

    rules = ["mcp__nacho__*"]
    added = False
    for rule in rules:
        if rule not in allow:
            allow.append(rule)
            added = True

    if added:
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        settings_file.write_text(json.dumps(settings, indent=2) + "\n")
        print("  Nacho tool permissions configured")
    else:
        print("  Permissions already configured")


def _setup_project_permissions(project_dir: Path):
    """Create or update .claude/settings.json in the project with dev tool permissions."""
    settings_dir = project_dir / ".claude"
    settings_dir.mkdir(parents=True, exist_ok=True)
    settings_file = settings_dir / "settings.json"

    # Read existing settings to preserve hooks and other config
    settings = {}
    if settings_file.exists():
        try:
            settings = json.loads(settings_file.read_text())
        except (json.JSONDecodeError, OSError):
            settings = {}

    desired_rules = [
        "Bash(mkdir *)",
        "Bash(cp *)",
        "Bash(npm *)",
        "Bash(npx *)",
        "Bash(node *)",
        "Bash(pnpm *)",
        "Bash(yarn *)",
        "Bash(uv *)",
        "Bash(pip *)",
        "Bash(pip3 *)",
        "Bash(python *)",
        "Bash(python3 *)",
        "Bash(source *)",
        "Bash(go *)",
        "Bash(cargo *)",
        "Bash(curl *)",
        "Bash(git *)",
        "Bash(mix *)",
        "Bash(elixir *)",
        "mcp__nacho__*",
    ]

    permissions = settings.setdefault("permissions", {})
    permissions["defaultMode"] = "acceptEdits"
    allow = permissions.setdefault("allow", [])
    for rule in desired_rules:
        if rule not in allow:
            allow.append(rule)

    settings_file.write_text(json.dumps(settings, indent=2) + "\n")
    print("  Project permissions configured")


def _pick_ollama_model(base_url: str) -> str:
    """Interactive model picker shown on first Ollama run."""
    from nacho_bot.cli.ollama_runner import CURATED_MODELS, list_models

    pulled = set(list_models(base_url))

    print("\nChoose a model (will be downloaded if not already pulled):")
    for i, (name, size, desc) in enumerate(CURATED_MODELS, 1):
        marker = " [pulled]" if name in pulled else ""
        recommended = " (recommended)" if i == 1 else ""
        print(f"  {i}. {name:<25} ({size}) — {desc}{recommended}{marker}")
    print(f"  {len(CURATED_MODELS) + 1}. Custom model name")

    while True:
        try:
            raw = input(f"\nChoice [1]: ").strip()
            choice = int(raw) if raw else 1
        except (ValueError, EOFError):
            print("  Please enter a number.")
            continue

        if 1 <= choice <= len(CURATED_MODELS):
            return CURATED_MODELS[choice - 1][0]
        elif choice == len(CURATED_MODELS) + 1:
            model = input("  Model name: ").strip()
            if model:
                return model
            print("  Please enter a model name.")
        else:
            print(f"  Please enter a number between 1 and {len(CURATED_MODELS) + 1}.")


def _setup_git_hook(project_dir: Path):
    """Install a git pre-commit hook that runs nacho-sec check."""
    git_dir = project_dir / ".git"
    if not git_dir.is_dir():
        # Not a git repo yet; will be set up during build
        return

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    hook_file = hooks_dir / "pre-commit"

    nacho_sec_block = (
        '\n# --- nacho-sec ---\n'
        'if command -v nacho-sec >/dev/null 2>&1; then\n'
        '  nacho-sec check --quiet\n'
        'fi\n'
        '# --- /nacho-sec ---\n'
    )

    if hook_file.exists():
        existing = hook_file.read_text()
        if "nacho-sec" in existing:
            print("  Git pre-commit hook already configured")
            return
        hook_file.write_text(existing + nacho_sec_block)
    else:
        hook_file.write_text("#!/bin/sh\n" + nacho_sec_block)

    hook_file.chmod(0o755)
    print("  Git pre-commit hook installed")


_SECURITY_INSTRUCTIONS = """\

<!-- nacho:security -->
## Security Scanning

Before committing code, run `nacho_scan_diff` to check changed files for security vulnerabilities, code quality issues, and hardcoded secrets. Fix any CRITICAL or HIGH findings before committing. At the end of a task, run `nacho_security_report` for a summary.
<!-- /nacho:security -->
"""


def _setup_security_instructions(project_dir: Path, provider: str | None = None):
    """Add security scanning instructions to AGENTS.md, create CLAUDE.md stub if needed."""
    agents_md = project_dir / "AGENTS.md"

    if agents_md.exists():
        content = agents_md.read_text()
        if "nacho:security" in content:
            print("  Security instructions already in AGENTS.md")
        else:
            agents_md.write_text(content + _SECURITY_INSTRUCTIONS)
            print("  Security instructions added to AGENTS.md")
    else:
        agents_md.write_text(_SECURITY_INSTRUCTIONS.lstrip())
        print("  Created AGENTS.md with security instructions")

    # For Claude provider, ensure CLAUDE.md imports AGENTS.md
    if provider == "claude" or not provider:
        claude_md = project_dir / "CLAUDE.md"
        if not claude_md.exists():
            claude_md.write_text("@AGENTS.md\n")
            print("  Created CLAUDE.md (imports AGENTS.md)")
        else:
            content = claude_md.read_text()
            if "@AGENTS.md" not in content:
                claude_md.write_text(content.rstrip() + "\n\n@AGENTS.md\n")
                print("  Added @AGENTS.md to CLAUDE.md")


def _teardown_project_permissions(project_dir: Path):
    """Remove the broad dev tool permissions added during build."""
    settings_file = project_dir / ".claude" / "settings.json"
    if not settings_file.exists():
        return

    try:
        settings = json.loads(settings_file.read_text())
    except (json.JSONDecodeError, OSError):
        return

    allow = settings.get("permissions", {}).get("allow", [])
    build_rules = {r for r in allow if r.startswith("Bash(")}
    if not build_rules:
        return

    settings["permissions"]["allow"] = [r for r in allow if not r.startswith("Bash(")]
    # Remove defaultMode if we set it
    settings["permissions"].pop("defaultMode", None)
    settings_file.write_text(json.dumps(settings, indent=2) + "\n")


def _print_mcp_instructions(provider: str) -> None:
    """Print MCP server config instructions for non-Claude editors."""
    mcp_json = json.dumps(
        {
            "mcpServers": {
                "nacho": {
                    "command": "nacho-mcp",
                    "args": [],
                },
            }
        },
        indent=2,
    )
    print(
        f"Add the following to your {provider} MCP config "
        f"(check your editor's docs for the exact location):\n"
    )
    print(mcp_json)


def cmd_init(args):
    """Set up project for Nacho (MCP servers, security hooks, permissions). Idempotent."""
    provider = get_provider()
    project_dir = Path.cwd()

    print("Setting up Nacho...\n")
    _ensure_nacho_packages()

    if provider == "claude" or not provider:
        if not shutil.which("claude"):
            if not provider:
                print("No provider configured and Claude Code is not installed.")
                print("Set your AI provider: nacho config set provider <name>")
            else:
                print("Claude Code is not installed.")
                print("Install it at: https://claude.ai/download")
                print("Or switch providers: nacho config set provider <name>")
            sys.exit(1)

        if not provider:
            print("No provider configured. Defaulting to Claude Code.")
            print("Run `nacho config set provider claude` to make this permanent.\n")

        _setup_mcp_server(project_dir)
        _setup_slash_command(project_dir)
        _setup_permissions()
    else:
        print(f"Provider: {provider}")
        _print_mcp_instructions(provider)

    _setup_security_instructions(project_dir, provider)
    _setup_git_hook(project_dir)
    print("\nNacho setup complete.")


def cmd_build(args):
    """Set up project (via nacho init) and launch the /nachoinit scaffolding wizard."""
    provider = get_provider()
    project_dir = Path.cwd()

    # Run init first to ensure everything is configured
    cmd_init(args)

    # Apply broad dev tool permissions only for build (wizard needs them)
    _setup_project_permissions(project_dir)

    print()

    if provider == "claude" or not provider:
        print("Launching Claude Code...")
        print("(First launch may take a moment while the Nacho tools are downloaded)\n")
        sys.stdout.flush()
        try:
            exit_code = subprocess.call(["claude", "/nachoinit"])
        finally:
            _teardown_project_permissions(project_dir)
        sys.exit(exit_code)
    elif provider.lower() == "ollama":
        from nacho_bot.cli.ollama_runner import (
            DEFAULT_OLLAMA_URL,
            check_ollama,
            list_models,
            pull_model,
            run_ollama_wizard,
        )

        base_url = load_config().get("ollama_url", DEFAULT_OLLAMA_URL)
        if not check_ollama(base_url):
            print(f"\nOllama is not running at {base_url}.")
            print("Install Ollama: https://ollama.ai  |  then run: ollama serve")
            sys.exit(1)

        model = load_config().get("ollama_model")
        if not model:
            model = _pick_ollama_model(base_url)
            save_config({"ollama_model": model})
            print(f"  Saved model preference: {model}")

        available = list_models(base_url)
        if model not in available:
            pull_model(model, base_url)
        else:
            print(f"  Model {model} already available")

        print(f"\nStarting Nacho wizard with {model}...\n")
        try:
            run_ollama_wizard(model=model, project_dir=project_dir, base_url=base_url)
        finally:
            _teardown_project_permissions(project_dir)

    else:
        print("To start building, run /nachoinit in your AI editor.")


def cmd_config(args):
    """Show or set Nacho configuration."""
    if args.config_command == "set":
        save_config({args.key: args.value}, local=getattr(args, "local", False))
        scope = "project" if getattr(args, "local", False) else "global"
        print(f"Set {args.key}={args.value} ({scope})")
    elif args.config_command == "get":
        config = load_config()
        value = config.get(args.key)
        if value is None:
            print(f"{args.key} is not set")
        else:
            print(value)
    else:
        config = load_config()
        if config:
            print(json.dumps(config, indent=2))
        else:
            print("No configuration set.")
            print("Run `nacho config set provider claude` to configure your AI provider.")


# ── Entry point ──────────────────────────────────────────────────────


def main():
    import importlib.metadata

    try:
        version = importlib.metadata.version("nacho-bot")
    except importlib.metadata.PackageNotFoundError:
        version = "dev"

    parser = argparse.ArgumentParser(
        prog="nacho",
        description="Nacho CLI — build apps and manage context files.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {version}")
    subparsers = parser.add_subparsers(dest="command")

    # init
    subparsers.add_parser("init", help="Set up project (MCP servers, security hooks, permissions)")

    # build
    subparsers.add_parser("build", help="Set up project + launch /nachoinit scaffolding wizard")

    # config
    config_parser = subparsers.add_parser("config", help="Show or set Nacho configuration")
    config_sub = config_parser.add_subparsers(dest="config_command")

    config_set = config_sub.add_parser("set", help="Set a config value")
    config_set.add_argument("key", help="Config key (e.g. provider)")
    config_set.add_argument("value", help="Config value (e.g. claude, cursor)")
    config_set.add_argument("--local", action="store_true", help="Write to project .nacho/config.json")

    config_get = config_sub.add_parser("get", help="Get a config value")
    config_get.add_argument("key", help="Config key (e.g. provider)")

    # login
    subparsers.add_parser("login", help="Login with email/password")

    # token
    token_parser = subparsers.add_parser("token", help="Store an API token")
    token_parser.add_argument("token", nargs="?", help="The API token")

    # logout
    subparsers.add_parser("logout", help="Clear stored credentials")

    # push
    push_parser = subparsers.add_parser("push", help="Push a context file")
    push_parser.add_argument("file", help="Path to .md file, or '.' to push all tracked contexts")
    push_parser.add_argument("--name", help="Context name/slug (auto-derived from filename if omitted)")
    push_parser.add_argument("--title", help="Override title (auto-extracted from file content)")
    push_parser.add_argument("--description", help="Override short description (auto-extracted from file content)")
    push_parser.add_argument("--tags", help="Comma-separated tags")
    push_parser.add_argument("--license", help="License")
    push_parser.add_argument("--changelog", help="Changelog for this version")

    # pull
    pull_parser = subparsers.add_parser("pull", help="Pull a context file")
    pull_parser.add_argument("ref", help="username/context-name")
    pull_parser.add_argument("--version", type=int, help="Specific version")
    pull_parser.add_argument("-o", "--output", help="Output filename")
    pull_parser.add_argument("-f", "--force", action="store_true", help="Overwrite without prompting")

    # search
    search_parser = subparsers.add_parser("search", help="Search for contexts")
    search_parser.add_argument("query", help="Search query")

    # upvote
    upvote_parser = subparsers.add_parser("upvote", help="Toggle upvote on a context")
    upvote_parser.add_argument("ref", help="username/context-name")

    args = parser.parse_args()

    commands = {
        "init": cmd_init,
        "build": cmd_build,
        "config": cmd_config,
        "login": cmd_login,
        "token": cmd_token,
        "logout": cmd_logout,
        "push": cmd_push,
        "pull": cmd_pull,
        "search": cmd_search,
        "upvote": cmd_upvote,
    }

    if args.command == "init":
        cmd_init(args)
        print("Run `nacho` to launch your AI editor, or `nacho build` for the scaffolding wizard.")
    elif args.command in commands:
        commands[args.command](args)
    elif args.command is None:
        cmd_init(args)
        provider = get_provider()
        if (provider == "claude" or not provider) and shutil.which("claude"):
            print("\nLaunching Claude Code...")
            sys.stdout.flush()
            sys.exit(subprocess.call(["claude"]))
        else:
            print("\nOpen your AI editor to start building.")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
