import argparse
import json
import sys
from unittest.mock import MagicMock, patch

import pytest

from nacho_bot.cli.commands import (
    _setup_permissions,
    _setup_project_permissions,
    _setup_slash_command,
    cmd_init,
    cmd_login,
    cmd_logout,
    cmd_pull,
    cmd_push,
    cmd_search,
    cmd_token,
    cmd_upvote,
    main,
)


# ── cmd_login ───────────────────────────────────────────────────────


def test_cmd_login_success(credentials_file, monkeypatch, capsys):
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_DIR", credentials_file.parent)
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_FILE", credentials_file)

    mock_client = MagicMock()
    mock_client.login.return_value = {"access_token": "jwt123"}

    with (
        patch("nacho_bot.cli.commands.APIClient", return_value=mock_client),
        patch("builtins.input", return_value="user@example.com"),
        patch("getpass.getpass", return_value="password123"),
    ):
        cmd_login(argparse.Namespace())

    out = capsys.readouterr().out
    assert "Logged in successfully" in out
    assert credentials_file.read_text() == "jwt123"


def test_cmd_login_tip_shows_prod_url(credentials_file, monkeypatch, capsys):
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_DIR", credentials_file.parent)
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_FILE", credentials_file)

    mock_client = MagicMock()
    mock_client.login.return_value = {"access_token": "jwt123"}

    with (
        patch("nacho_bot.cli.commands.APIClient", return_value=mock_client),
        patch("builtins.input", return_value="user@example.com"),
        patch("getpass.getpass", return_value="pw"),
    ):
        cmd_login(argparse.Namespace())

    assert "nacho.bot/settings" in capsys.readouterr().out


def test_cmd_login_failure(capsys):
    mock_client = MagicMock()
    mock_client.login.side_effect = Exception("Invalid credentials")

    with (
        patch("nacho_bot.cli.commands.APIClient", return_value=mock_client),
        patch("builtins.input", return_value="user@example.com"),
        patch("getpass.getpass", return_value="wrong"),
        pytest.raises(SystemExit) as exc_info,
    ):
        cmd_login(argparse.Namespace())

    assert exc_info.value.code == 1


# ── cmd_token ───────────────────────────────────────────────────────


def test_cmd_token_saves_from_arg(credentials_file, monkeypatch, capsys):
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_DIR", credentials_file.parent)
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_FILE", credentials_file)

    cmd_token(argparse.Namespace(token="nacho_mytoken"))

    assert "Token saved" in capsys.readouterr().out
    assert credentials_file.read_text() == "nacho_mytoken"


def test_cmd_token_prompts_when_no_arg(credentials_file, monkeypatch):
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_DIR", credentials_file.parent)
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_FILE", credentials_file)

    with patch("getpass.getpass", return_value="nacho_prompted"):
        cmd_token(argparse.Namespace(token=None))

    assert credentials_file.read_text() == "nacho_prompted"


# ── cmd_logout ──────────────────────────────────────────────────────


def test_cmd_logout_clears(credentials_file, monkeypatch, capsys):
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_DIR", credentials_file.parent)
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_FILE", credentials_file)

    credentials_file.parent.mkdir(parents=True, exist_ok=True)
    credentials_file.write_text("old_token")

    cmd_logout(argparse.Namespace())

    assert "Logged out" in capsys.readouterr().out
    assert not credentials_file.exists()


# ── cmd_push ────────────────────────────────────────────────────────


def test_cmd_push_new_context(tmp_path, capsys):
    md_file = tmp_path / "contexts.md"
    md_file.write_text("# Hello")

    mock_client = MagicMock()
    mock_client.push.return_value = {
        "context": {"owner_username": "alice", "name": "my-ctx"},
        "version": {"version": 1},
    }

    with (
        patch("nacho_bot.cli.commands.APIClient", return_value=mock_client),
        patch("nacho_bot.cli.commands.load_tracked_contexts", return_value={}),
        patch("nacho_bot.cli.commands.save_tracked_context"),
    ):
        cmd_push(argparse.Namespace(
            file=str(md_file), name="my-ctx", title="My Context",
            description=None, tags=None, license=None, changelog=None,
        ))

    assert "alice/my-ctx v1" in capsys.readouterr().out


def test_cmd_push_tracked_context(tmp_path, capsys):
    md_file = tmp_path / "contexts.md"
    md_file.write_text("# Updated")

    mock_client = MagicMock()
    mock_client.get_my_context.return_value = {
        "id": "abc-123", "owner_username": "alice", "name": "my-ctx",
    }
    mock_client.push_version.return_value = {"version": 2}

    with (
        patch("nacho_bot.cli.commands.APIClient", return_value=mock_client),
        patch("nacho_bot.cli.commands.load_tracked_contexts", return_value={str(md_file): {"name": "my-ctx", "title": "My Context"}}),
    ):
        cmd_push(argparse.Namespace(
            file=str(md_file), name=None, title=None,
            description=None, tags=None, license=None, changelog=None,
        ))

    assert "alice/my-ctx v2" in capsys.readouterr().out
    mock_client.push_version.assert_called_once_with("abc-123", str(md_file), changelog=None)


def test_cmd_push_untracked_auto_name(tmp_path, capsys):
    """Name, title, and description are auto-derived from the file when not provided."""
    md_file = tmp_path / "my-context.md"
    md_file.write_text("# My Context Title\n\nThis is the auto-extracted description.")

    mock_client = MagicMock()
    mock_client.push.return_value = {
        "context": {"owner_username": "alice", "name": "my-context", "title": "My Context Title",
                    "short_description": None, "long_description": None, "license": None,
                    "latest_version": 1, "download_count": 0, "upvote_count": 0,
                    "is_published": True, "tags": [], "created_at": "2024-01-01T00:00:00",
                    "updated_at": "2024-01-01T00:00:00", "id": "abc", "owner_id": "x"},
        "version": {"version": 1},
    }

    with (
        patch("nacho_bot.cli.commands.APIClient", return_value=mock_client),
        patch("nacho_bot.cli.commands.load_tracked_contexts", return_value={}),
        patch("nacho_bot.cli.commands.save_tracked_context"),
    ):
        cmd_push(argparse.Namespace(
            file=str(md_file), name=None, title=None,
            description=None, tags=None, license=None, changelog=None,
        ))

    mock_client.push.assert_called_once()
    call_kwargs = mock_client.push.call_args.kwargs
    assert call_kwargs["name"] == "my-context"
    assert call_kwargs["title"] == "My Context Title"
    assert call_kwargs["short_description"] == "This is the auto-extracted description."
    assert "alice/my-context v1" in capsys.readouterr().out


def test_cmd_push_dot_no_tracked_errors(capsys):
    with (
        patch("nacho_bot.cli.commands.APIClient", return_value=MagicMock()),
        patch("nacho_bot.cli.commands.load_tracked_contexts", return_value={}),
        pytest.raises(SystemExit) as exc_info,
    ):
        cmd_push(argparse.Namespace(file=".", name=None, title=None,
                                    description=None, tags=None, license=None, changelog=None))

    assert exc_info.value.code == 1
    assert "no tracked contexts" in capsys.readouterr().err


# ── cmd_pull ────────────────────────────────────────────────────────


def test_cmd_pull_downloads_file(tmp_path, capsys):
    output_file = tmp_path / "my-ctx.md"

    mock_client = MagicMock()
    mock_client.token = None
    mock_client.pull.return_value = b"# Downloaded content"

    with patch("nacho_bot.cli.commands.APIClient", return_value=mock_client):
        cmd_pull(argparse.Namespace(
            ref="alice/my-ctx", version=None,
            output=str(output_file), force=True,
        ))

    assert output_file.read_bytes() == b"# Downloaded content"
    assert "Downloaded to" in capsys.readouterr().out


def test_cmd_pull_invalid_ref(capsys):
    with pytest.raises(SystemExit) as exc_info:
        cmd_pull(argparse.Namespace(ref="no-slash", version=None, output=None, force=False))

    assert exc_info.value.code == 1
    assert "username/context-name" in capsys.readouterr().err


# ── cmd_search ──────────────────────────────────────────────────────


def test_cmd_search_results(capsys):
    mock_client = MagicMock()
    mock_client.search.return_value = {
        "items": [{
            "owner_username": "alice", "name": "fastapi-ctx",
            "title": "FastAPI Context", "short_description": "A great context",
            "tags": ["python", "fastapi"],
        }]
    }

    with patch("nacho_bot.cli.commands.APIClient", return_value=mock_client):
        cmd_search(argparse.Namespace(query="fastapi"))

    out = capsys.readouterr().out
    assert "alice/fastapi-ctx" in out
    assert "python, fastapi" in out


def test_cmd_search_no_results(capsys):
    mock_client = MagicMock()
    mock_client.search.return_value = {"items": []}

    with patch("nacho_bot.cli.commands.APIClient", return_value=mock_client):
        cmd_search(argparse.Namespace(query="nonexistent"))

    assert "No results found" in capsys.readouterr().out


# ── cmd_upvote ──────────────────────────────────────────────────────


def test_cmd_upvote_adds_upvote(capsys):
    mock_client = MagicMock()
    mock_client.upvote.return_value = {"upvoted": True, "upvote_count": 5}

    with patch("nacho_bot.cli.commands.APIClient", return_value=mock_client):
        cmd_upvote(argparse.Namespace(ref="alice/my-ctx"))

    assert "Upvoted alice/my-ctx" in capsys.readouterr().out
    mock_client.upvote.assert_called_once_with("alice", "my-ctx")


def test_cmd_upvote_invalid_ref(capsys):
    with pytest.raises(SystemExit) as exc_info:
        cmd_upvote(argparse.Namespace(ref="no-slash"))

    assert exc_info.value.code == 1
    assert "username/context-name" in capsys.readouterr().err


# ── cmd_init ────────────────────────────────────────────────────────


def test_cmd_init_no_claude(capsys):
    with (
        patch("nacho_bot.cli.commands.get_provider", return_value="claude"),
        patch("nacho_bot.cli.commands._ensure_nacho_packages"),
        patch("shutil.which", return_value=None),
        pytest.raises(SystemExit) as exc_info,
    ):
        cmd_init(argparse.Namespace())

    assert exc_info.value.code == 1
    assert "Claude Code is not installed" in capsys.readouterr().out


def test_cmd_init_runs_setup(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    with (
        patch("nacho_bot.cli.commands.get_provider", return_value="claude"),
        patch("nacho_bot.cli.commands._ensure_nacho_packages"),
        patch("shutil.which", return_value="/usr/bin/claude"),
        patch("nacho_bot.cli.commands._setup_mcp_server") as mock_mcp,
        patch("nacho_bot.cli.commands._setup_slash_command"),
        patch("nacho_bot.cli.commands._setup_permissions"),
        patch("nacho_bot.cli.commands._setup_project_permissions") as mock_proj_perms,
    ):
        cmd_init(argparse.Namespace())
        mock_mcp.assert_called_once()
        # Project permissions are NOT set during init (only during build)
        mock_proj_perms.assert_not_called()


def test_setup_project_permissions(tmp_path):
    _setup_project_permissions(tmp_path)

    settings = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    assert settings["permissions"]["defaultMode"] == "acceptEdits"
    assert "mcp__nacho__*" in settings["permissions"]["allow"]
    assert "Bash(npm *)" in settings["permissions"]["allow"]


def test_setup_permissions_creates_settings(tmp_path, monkeypatch):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    monkeypatch.setattr("nacho_bot.cli.commands.Path.home", lambda: tmp_path)

    _setup_permissions()

    settings = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    assert "mcp__nacho__*" in settings["permissions"]["allow"]


def test_setup_permissions_idempotent(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    monkeypatch.setattr("nacho_bot.cli.commands.Path.home", lambda: tmp_path)

    _setup_permissions()
    _setup_permissions()

    settings = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    assert settings["permissions"]["allow"].count("mcp__nacho__*") == 1
    assert "already configured" in capsys.readouterr().out


def test_setup_slash_command(tmp_path):
    _setup_slash_command(tmp_path)

    dest = tmp_path / ".claude" / "commands" / "nachoinit.md"
    assert dest.exists()
    assert "interactive project scaffolding wizard" in dest.read_text()


# ── main dispatch ────────────────────────────────────────────────────


def test_main_no_command_launches_init():
    with (
        patch("sys.argv", ["nacho"]),
        patch("nacho_bot.cli.commands.cmd_init") as mock_init,
        patch("nacho_bot.cli.commands.get_provider", return_value="claude"),
        patch("shutil.which", return_value="/usr/bin/claude"),
        patch("subprocess.call", return_value=0) as mock_call,
    ):
        with pytest.raises(SystemExit) as exc_info:
            main()
        mock_init.assert_called_once()
        mock_call.assert_called_once_with(["claude"])
        assert exc_info.value.code == 0


def test_main_init_command(capsys):
    with (
        patch("sys.argv", ["nacho", "init"]),
        patch("nacho_bot.cli.commands.cmd_init") as mock_init,
    ):
        main()
        mock_init.assert_called_once()
        output = capsys.readouterr().out
        assert "nacho build" in output


def test_main_push():
    with (
        patch("sys.argv", ["nacho", "push", "file.md", "--name", "x"]),
        patch("nacho_bot.cli.commands.cmd_push") as mock_push,
    ):
        main()
        mock_push.assert_called_once()
        assert mock_push.call_args[0][0].file == "file.md"


def test_main_search():
    with (
        patch("sys.argv", ["nacho", "search", "fastapi"]),
        patch("nacho_bot.cli.commands.cmd_search") as mock_search,
    ):
        main()
        assert mock_search.call_args[0][0].query == "fastapi"


def test_main_login():
    with (
        patch("sys.argv", ["nacho", "login"]),
        patch("nacho_bot.cli.commands.cmd_login") as mock_login,
    ):
        main()
        mock_login.assert_called_once()


def test_main_version(capsys):
    with (
        patch("sys.argv", ["nacho", "--version"]),
        pytest.raises(SystemExit) as exc_info,
    ):
        main()

    assert exc_info.value.code == 0
    assert "nacho" in capsys.readouterr().out.lower()
