"""Tests for stack detection from AGENTS.md and file extensions."""

from pathlib import Path

from nacho_bot.mcp.security.detect import detect_tags, detect_tags_from_agents_md, detect_tags_from_files


def test_parse_nacho_tags(tmp_path):
    agents = tmp_path / "AGENTS.md"
    agents.write_text(
        "# My Project\n\n"
        "<!-- nacho: user/python-fastapi [python, fastapi, backend] -->\n"
        "Some content here.\n\n"
        "<!-- nacho: user/react-app [react, typescript] -->\n"
        "More content.\n"
    )
    tags = detect_tags_from_agents_md(tmp_path)
    assert tags == ["backend", "fastapi", "python", "react", "typescript"]


def test_parse_no_tags(tmp_path):
    agents = tmp_path / "AGENTS.md"
    agents.write_text("<!-- nacho: user/some-context -->\nNo tags here.\n")
    tags = detect_tags_from_agents_md(tmp_path)
    assert tags == []


def test_parse_no_agents_md(tmp_path):
    tags = detect_tags_from_agents_md(tmp_path)
    assert tags == []


def test_detect_from_files(tmp_path):
    (tmp_path / "app.py").write_text("print('hello')")
    (tmp_path / "utils.py").write_text("pass")
    tags = detect_tags_from_files(tmp_path)
    assert tags == ["python"]


def test_detect_from_files_mixed(tmp_path):
    (tmp_path / "app.py").write_text("")
    (tmp_path / "index.tsx").write_text("")
    tags = detect_tags_from_files(tmp_path)
    assert sorted(tags) == ["python", "typescript"]


def test_detect_prefers_agents_md(tmp_path):
    agents = tmp_path / "AGENTS.md"
    agents.write_text("<!-- nacho: user/go-api [go, backend] -->\n")
    (tmp_path / "main.py").write_text("")  # Python file exists but should be ignored
    tags = detect_tags(tmp_path)
    assert tags == ["backend", "go"]


def test_detect_falls_back_to_files(tmp_path):
    (tmp_path / "main.go").write_text("package main")
    tags = detect_tags(tmp_path)
    assert tags == ["go"]
