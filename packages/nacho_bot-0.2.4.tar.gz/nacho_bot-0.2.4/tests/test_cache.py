"""Tests for scan caching."""

import time
from pathlib import Path

from nacho_bot.mcp.security.cache import is_cached, update_cache


def test_no_cache_initially(tmp_path):
    f = tmp_path / "test.py"
    f.write_text("print('hi')")
    assert not is_cached(tmp_path, [str(f)])


def test_cached_after_update(tmp_path):
    f = tmp_path / "test.py"
    f.write_text("print('hi')")
    files = [str(f)]
    update_cache(tmp_path, files)
    assert is_cached(tmp_path, files)


def test_cache_invalidated_on_change(tmp_path):
    f = tmp_path / "test.py"
    f.write_text("print('hi')")
    files = [str(f)]
    update_cache(tmp_path, files)
    assert is_cached(tmp_path, files)

    # Modify the file — need a different mtime
    time.sleep(0.05)
    f.write_text("print('changed')")
    assert not is_cached(tmp_path, files)


def test_cache_invalidated_on_new_file(tmp_path):
    f1 = tmp_path / "a.py"
    f1.write_text("pass")
    update_cache(tmp_path, [str(f1)])

    f2 = tmp_path / "b.py"
    f2.write_text("pass")
    assert not is_cached(tmp_path, [str(f1), str(f2)])
