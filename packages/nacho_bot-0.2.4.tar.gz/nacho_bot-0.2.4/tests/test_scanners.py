"""Tests for scanner registry and selection."""

from nacho_bot.mcp.security.scanners import (
    UNIVERSAL_SCANNERS,
    _classify_license,
    get_scanners_for_tags,
    run_bandit,
    run_brakeman,
    run_bundle_audit,
    run_cargo_audit,
    run_cargo_deny_licenses,
    run_clippy,
    run_composer_licenses,
    run_cppcheck,
    run_credo,
    run_dart_analyze,
    run_detekt,
    run_dotnet_analyzers,
    run_eslint_quality,
    run_eslint_security,
    run_flawfinder,
    run_gitleaks,
    run_go_licenses,
    run_go_vet,
    run_gosec,
    run_license_checker,
    run_mix_audit,
    run_phpstan,
    run_pip_licenses,
    run_pmd,
    run_rubocop,
    run_ruff,
    run_ruff_quality,
    run_semgrep,
    run_sobelow,
    run_swiftlint,
)


# --- License classification ---

def test_classify_copyleft_critical():
    assert _classify_license("AGPL-3.0") == "CRITICAL"
    assert _classify_license("AGPL-3.0-only") == "CRITICAL"
    assert _classify_license("SSPL-1.0") == "CRITICAL"


def test_classify_copyleft_high():
    assert _classify_license("GPL-3.0") == "HIGH"
    assert _classify_license("GPL-2.0-only") == "HIGH"
    assert _classify_license("EUPL-1.2") == "HIGH"


def test_classify_permissive():
    assert _classify_license("MIT") == "INFO"
    assert _classify_license("Apache-2.0") == "INFO"
    assert _classify_license("BSD-3-Clause") == "INFO"
    assert _classify_license("ISC") == "INFO"
    assert _classify_license("MPL-2.0") == "INFO"


def test_classify_unknown():
    assert _classify_license("UNKNOWN") == "MEDIUM"
    assert _classify_license("") == "MEDIUM"
    assert _classify_license("CustomLicense-1.0") == "MEDIUM"


def test_classify_substring_match():
    assert _classify_license("GNU AGPL v3") == "CRITICAL"
    assert _classify_license("GNU GPL v2") == "HIGH"
    assert _classify_license("MIT License") == "INFO"


# --- Python ---

def test_python_tags():
    scanners = set(get_scanners_for_tags(["python"]))
    assert run_bandit in scanners
    assert run_ruff in scanners
    assert run_ruff_quality in scanners
    assert run_pip_licenses in scanners
    assert run_semgrep in scanners
    assert run_gitleaks in scanners


# --- JavaScript / TypeScript ---

def test_javascript_tags():
    scanners = set(get_scanners_for_tags(["javascript"]))
    assert run_eslint_security in scanners
    assert run_eslint_quality in scanners
    assert run_license_checker in scanners
    assert run_semgrep in scanners
    assert run_gitleaks in scanners


def test_typescript_tags():
    scanners = set(get_scanners_for_tags(["typescript"]))
    assert run_eslint_security in scanners
    assert run_eslint_quality in scanners
    assert run_license_checker in scanners


def test_framework_tags_map_to_js():
    for tag in ["react", "nextjs", "vue", "angular", "svelte", "node"]:
        scanners = set(get_scanners_for_tags([tag]))
        assert run_eslint_security in scanners, f"{tag} missing eslint-security"
        assert run_eslint_quality in scanners, f"{tag} missing eslint-quality"
        assert run_license_checker in scanners, f"{tag} missing license-checker"


# --- Go ---

def test_go_tags():
    scanners = set(get_scanners_for_tags(["go"]))
    assert run_gosec in scanners
    assert run_go_vet in scanners
    assert run_go_licenses in scanners
    assert run_semgrep in scanners
    assert run_gitleaks in scanners


# --- Java ---

def test_java_tags():
    scanners = set(get_scanners_for_tags(["java"]))
    assert run_pmd in scanners
    assert run_semgrep in scanners


def test_spring_maps_to_java():
    scanners = set(get_scanners_for_tags(["spring"]))
    assert run_pmd in scanners


# --- Kotlin ---

def test_kotlin_tags():
    scanners = set(get_scanners_for_tags(["kotlin"]))
    assert run_pmd in scanners
    assert run_detekt in scanners
    assert run_semgrep in scanners


# --- C / C++ ---

def test_c_tags():
    scanners = set(get_scanners_for_tags(["c"]))
    assert run_cppcheck in scanners
    assert run_flawfinder in scanners
    assert run_semgrep in scanners


def test_cpp_tags():
    scanners = set(get_scanners_for_tags(["cpp"]))
    assert run_cppcheck in scanners
    assert run_flawfinder in scanners


def test_cpp_plus_plus_tag():
    scanners = set(get_scanners_for_tags(["c++"]))
    assert run_cppcheck in scanners
    assert run_flawfinder in scanners


# --- C# ---

def test_csharp_tags():
    for tag in ["csharp", "c#", "dotnet", ".net"]:
        scanners = set(get_scanners_for_tags([tag]))
        assert run_dotnet_analyzers in scanners, f"{tag} missing dotnet-analyzers"
        assert run_semgrep in scanners, f"{tag} missing semgrep"


# --- Rust ---

def test_rust_tags():
    scanners = set(get_scanners_for_tags(["rust"]))
    assert run_clippy in scanners
    assert run_cargo_audit in scanners
    assert run_cargo_deny_licenses in scanners
    assert run_semgrep in scanners


# --- Elixir ---

def test_elixir_tags():
    scanners = set(get_scanners_for_tags(["elixir"]))
    assert run_credo in scanners
    assert run_sobelow in scanners
    assert run_mix_audit in scanners
    assert run_semgrep in scanners


def test_phoenix_maps_to_elixir():
    scanners = set(get_scanners_for_tags(["phoenix"]))
    assert run_credo in scanners
    assert run_sobelow in scanners
    assert run_mix_audit in scanners


# --- Ruby ---

def test_ruby_tags():
    scanners = set(get_scanners_for_tags(["ruby"]))
    assert run_brakeman in scanners
    assert run_rubocop in scanners
    assert run_bundle_audit in scanners
    assert run_semgrep in scanners


def test_rails_maps_to_ruby():
    scanners = set(get_scanners_for_tags(["rails"]))
    assert run_brakeman in scanners
    assert run_rubocop in scanners
    assert run_bundle_audit in scanners


# --- PHP ---

def test_php_tags():
    for tag in ["php", "laravel"]:
        scanners = set(get_scanners_for_tags([tag]))
        assert run_phpstan in scanners, f"{tag} missing phpstan"
        assert run_composer_licenses in scanners, f"{tag} missing composer-licenses"
        assert run_semgrep in scanners, f"{tag} missing semgrep"


# --- Swift ---

def test_swift_tags():
    for tag in ["swift", "ios"]:
        scanners = set(get_scanners_for_tags([tag]))
        assert run_swiftlint in scanners, f"{tag} missing swiftlint"
        assert run_semgrep in scanners, f"{tag} missing semgrep"


# --- Dart ---

def test_dart_tags():
    for tag in ["dart", "flutter"]:
        scanners = set(get_scanners_for_tags([tag]))
        assert run_dart_analyze in scanners, f"{tag} missing dart-analyze"
        assert run_semgrep in scanners, f"{tag} missing semgrep"


# --- General behavior ---

def test_unknown_tags_get_semgrep_fallback():
    scanners = set(get_scanners_for_tags(["unknown-stack"]))
    assert run_gitleaks in scanners
    assert run_semgrep in scanners
    assert len(get_scanners_for_tags(["unknown-stack"])) == len(UNIVERSAL_SCANNERS) + 1


def test_empty_tags_get_semgrep_fallback():
    scanners = get_scanners_for_tags([])
    assert run_semgrep in scanners
    assert run_gitleaks in scanners


def test_no_duplicate_scanners():
    scanners = get_scanners_for_tags(["python", "fastapi", "django"])
    scanner_ids = [id(s) for s in scanners]
    assert len(scanner_ids) == len(set(scanner_ids))


def test_mixed_stack_combines_scanners():
    scanners = set(get_scanners_for_tags(["python", "typescript", "rust"]))
    # Security
    assert run_bandit in scanners
    assert run_eslint_security in scanners
    assert run_clippy in scanners
    # Quality
    assert run_ruff_quality in scanners
    assert run_eslint_quality in scanners
    # Licenses
    assert run_pip_licenses in scanners
    assert run_license_checker in scanners
    assert run_cargo_deny_licenses in scanners
    # Universal
    assert run_gitleaks in scanners
    assert run_semgrep in scanners


def test_case_insensitive_tags():
    scanners = set(get_scanners_for_tags(["Python", "RUST", "Elixir"]))
    assert run_bandit in scanners
    assert run_clippy in scanners
    assert run_credo in scanners
