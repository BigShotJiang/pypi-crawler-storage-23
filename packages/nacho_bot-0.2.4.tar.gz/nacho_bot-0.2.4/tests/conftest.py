import pytest


@pytest.fixture()
def credentials_dir(tmp_path, monkeypatch):
    """Redirect credentials storage to a temp directory."""
    creds_dir = tmp_path / ".nacho"
    creds_file = creds_dir / "credentials"
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_DIR", creds_dir)
    monkeypatch.setattr("nacho_bot.cli.config.CREDENTIALS_FILE", creds_file)
    return creds_dir


@pytest.fixture()
def credentials_file(credentials_dir):
    """Return the credentials file path (inside the temp dir)."""
    return credentials_dir / "credentials"


@pytest.fixture
def no_credentials(tmp_path, monkeypatch):
    """Ensure no credentials file exists."""
    fake_creds = tmp_path / ".nacho" / "credentials"
    monkeypatch.setattr("nacho_bot.mcp.context.tools.CREDENTIALS_FILE", fake_creds)
    return fake_creds


@pytest.fixture
def fake_credentials(tmp_path, monkeypatch):
    """Create a fake credentials file with a test token."""
    creds_dir = tmp_path / ".nacho"
    creds_dir.mkdir()
    creds_file = creds_dir / "credentials"
    creds_file.write_text("nacho_test_token_123\n")
    monkeypatch.setattr("nacho_bot.mcp.context.tools.CREDENTIALS_FILE", creds_file)
    return creds_file
