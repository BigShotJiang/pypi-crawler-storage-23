## Python Utility Code

I keep writing the same stuff in different projects, so I finally decided
to throw stuff into a common boilerplate and stop the cut&paste jobs.

## Install

The library can be installed using *PyPi*:

```Shell
$ pip install python-misc-utils
```

Or directly from the *Github* repository:

```Shell
$ pip install git+https://github.com/davidel/py_misc_utils.git
```

