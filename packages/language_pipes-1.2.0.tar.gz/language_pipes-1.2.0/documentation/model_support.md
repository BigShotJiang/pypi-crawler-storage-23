### Supported Models
Below are the models that are tested and known to work. Any fine-tuned model based on a supported model should also work.

**Qwen3:**
- Qwen/Qwen3-1.7B
- Qwen/Qwen3-14B
- Qwen/Qwen3-30B-A3B-Thinking-2507

**Phi:**
- microsoft/Phi-4-mini-reasoning
- microsoft/Phi-4-reasoning-plus

**Z.ai:**
- zai-org/GLM-4.1V-9B-Thinking

**Meta:**
- meta-llama/Llama-3.1-8B-Instruct
- meta-llama/Llama-3.2-1B-Instruct

**Google**
- google/gemma-3-1b-it