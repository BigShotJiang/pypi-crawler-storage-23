import toml

def view_config(config_path: str):
    with open(config_path, 'r', encoding='utf-8') as f:
        config = toml.load(f)
    
    print("\n" + "=" * 60)
    print("  Configuration Details")
    print(f"  Path: {config_path}")
    print("=" * 60)
    
    # Property descriptions
    descriptions = {
        "node_id": "Unique identifier for this node on the network",
        "oai_port": "Port for OpenAI-compatible API server",
        "api_keys": "Authentication tokens used to connect to OpenAI-compatible API server",
        "peer_port": "Port for peer-to-peer network coordination",
        "network_ip": "IP address other nodes use to connect to this node",
        "bootstrap_address": "IP of existing node to join the network",
        "bootstrap_port": "Port of the bootstrap node",
        "network_key": "AES encryption key for secure communication",
        "whitelist_ips": "Only communicate with peers whose IP is in this list",
        "whitelist_node_ids": "Only communicate with peers whose node ID is in this list",
        "logging_level": "Verbosity level (DEBUG/INFO/WARNING/ERROR)",
        "max_pipes": "Max concurrent distributed model instances",
        "model_validation": "Verify model weight hashes match across nodes",
    }
    
    # Display simple properties
    print("\n--- Node Settings ---")
    _print_property("Node ID", config.get("node_id"), descriptions["node_id"])
    
    print("\n--- Network Settings ---")
    _print_property("Network IP", config.get("network_ip"), descriptions["network_ip"])
    _print_property("Peer Port", config.get("peer_port"), descriptions["peer_port"])
    
    bootstrap = config.get("bootstrap_address")
    if bootstrap:
        _print_property("Bootstrap Address", bootstrap, descriptions["bootstrap_address"])
        _print_property("Bootstrap Port", config.get("bootstrap_port"), descriptions["bootstrap_port"])
    else:
        print("  Bootstrap Node:     Not configured (this is a standalone/first node)")
    
    network_key = config.get("network_key")
    if network_key:
        # Show truncated key for security
        display_key = network_key[:8] + "..." + network_key[-8:] if len(network_key) > 20 else network_key
        _print_property("Network Key", display_key, descriptions["network_key"])
    else:
        print("  Network Encryption: Disabled")

    whitelist_ips = config.get("whitelist_ips", [])
    if whitelist_ips:
        _print_property("Whitelist IPs", ", ".join(whitelist_ips), descriptions["whitelist_ips"])
    else:
        print("  Whitelist IPs:      Disabled (all peers allowed)")

    whitelist_node_ids = config.get("whitelist_node_ids", [])
    if whitelist_node_ids:
        _print_property("Whitelist Node IDs", ", ".join(whitelist_node_ids), descriptions["whitelist_node_ids"])
    else:
        print("  Whitelist Node IDs: Disabled (all peers allowed)")
    
    print("\n--- API Settings ---")
    oai_port = config.get("oai_port")
    api_keys = config.get("api_keys", [])
    api_key_desc = "No API key required" if len(api_keys) == 0 else f"{len(api_keys)} keys set"
    if oai_port:
        _print_property("OpenAI API Port", oai_port, descriptions["oai_port"])
        _print_property("API keys", api_key_desc, "")
    else:
        print("  OpenAI API:         Disabled")
    
    print("\n--- Performance & Security ---")
    _print_property("Logging Level", config.get("logging_level", "INFO"), descriptions["logging_level"])
    _print_property("Max Pipes", config.get("max_pipes", 1), descriptions["max_pipes"])
    _print_property("Model Validation", "Enabled" if config.get("model_validation") else "Disabled", descriptions["model_validation"])
    
    # Display layer models
    models = config.get("layer_models", [])
    print(f"\n--- Layer Models ({len(models)}) ---")
    if models:
        for i, model in enumerate(models):
            print(f"\n  Model #{i+1}:")
            print(f"    ID:          {model.get('id', 'Unknown')}")
            # print(f"                 (HuggingFace model identifier)")
            print(f"    Device:      {model.get('device', 'cpu')}")
            # print(f"                 (Compute device: cpu, cuda:0, cuda:1, etc.)")
            print(f"    Max Memory:  {model.get('max_memory', 4)} GB")
            # print(f"                 (Maximum RAM/VRAM to use for model layers)")
    else:
        print("    No layer models configured")
    
    # Display end models
    end_models = config.get("end_models", [])
    print(f"\n--- End Models ({len(end_models)}) ---")
    if end_models:
        for i, model_id in enumerate(end_models):
            print(f"  {i+1}. {model_id}")
    else:
        print("  No end models configured.")
    
    print("\n" + "=" * 60)


def _print_property(label: str, value, description: str):
    """Helper to print a property with its description."""
    print(f"  {label + ':':<18} {value}")
