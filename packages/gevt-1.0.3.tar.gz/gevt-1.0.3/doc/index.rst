.. GeVT documentation master file, created by
   sphinx-quickstart on Tue Nov 27 20:23:48 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to GeVT's documentation!
================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   usage/about
   usage/installation
   usage/utilisation



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
