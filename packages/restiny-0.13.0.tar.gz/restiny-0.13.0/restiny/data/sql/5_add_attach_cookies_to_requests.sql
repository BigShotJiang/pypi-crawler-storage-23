ALTER TABLE requests
  ADD option_attach_cookies BOOLEAN NOT NULL DEFAULT TRUE
