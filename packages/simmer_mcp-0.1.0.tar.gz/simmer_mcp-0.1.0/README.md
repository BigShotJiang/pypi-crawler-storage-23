# simmer-mcp

MCP server that gives AI agents [Simmer's](https://simmer.markets) API documentation and error troubleshooting.

## Install

```bash
pip install simmer-mcp
```

## What it does

- **API docs as context** — serves `docs.md` and `skill.md` as MCP resources so your agent has the full Simmer API reference in working memory
- **Error lookup** — `troubleshoot_error()` tool matches common API errors to one-liner fixes

## Setup

Add to your MCP config (OpenClaw, Claude Desktop, Cursor, etc.):

```json
{
  "mcpServers": {
    "simmer": {
      "command": "python",
      "args": ["-m", "simmer_mcp"]
    }
  }
}
```

Your agent now has full Simmer API docs in context and can call `troubleshoot_error("not enough balance")` when something fails.

## Resources

| Resource | Description |
|----------|-------------|
| `simmer://docs/api-reference` | Full API reference (~2400 lines) |
| `simmer://docs/skill-reference` | Condensed agent reference (~600 lines) |

## Tools

| Tool | Description |
|------|-------------|
| `troubleshoot_error(error_text)` | Match an error against known patterns, get a fix |

## Docs

- Full API reference: https://simmer.markets/docs.md
- Python SDK: `pip install simmer-sdk`
- Website: https://simmer.markets
