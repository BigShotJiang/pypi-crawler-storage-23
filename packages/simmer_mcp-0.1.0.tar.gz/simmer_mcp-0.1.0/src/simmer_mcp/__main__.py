"""Entry point: python -m simmer_mcp"""

from simmer_mcp.server import mcp

mcp.run()
