from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error_response import ErrorResponse
from ...models.get_attributes_order import GetAttributesOrder
from ...models.get_attributes_sort import GetAttributesSort
from ...models.paginated_attributes_response import PaginatedAttributesResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    take: Union[Unset, int] = 20,
    skip: Union[Unset, int] = 0,
    name: Union[Unset, str] = UNSET,
    short_name: Union[Unset, str] = UNSET,
    sort: Union[Unset, GetAttributesSort] = UNSET,
    order: Union[Unset, GetAttributesOrder] = GetAttributesOrder.ASC,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["take"] = take

    params["skip"] = skip

    params["name"] = name

    params["shortName"] = short_name

    json_sort: Union[Unset, str] = UNSET
    if not isinstance(sort, Unset):
        json_sort = sort.value

    params["sort"] = json_sort

    json_order: Union[Unset, str] = UNSET
    if not isinstance(order, Unset):
        json_order = order.value

    params["order"] = json_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/catalog/attributes",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[ErrorResponse, PaginatedAttributesResponse]]:
    if response.status_code == 200:
        response_200 = PaginatedAttributesResponse.from_dict(response.json())

        return response_200

    if response.status_code == 201:
        response_201 = PaginatedAttributesResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())

        return response_404

    if response.status_code == 500:
        response_500 = ErrorResponse.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[ErrorResponse, PaginatedAttributesResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    take: Union[Unset, int] = 20,
    skip: Union[Unset, int] = 0,
    name: Union[Unset, str] = UNSET,
    short_name: Union[Unset, str] = UNSET,
    sort: Union[Unset, GetAttributesSort] = UNSET,
    order: Union[Unset, GetAttributesOrder] = GetAttributesOrder.ASC,
) -> Response[Union[ErrorResponse, PaginatedAttributesResponse]]:
    """Browse and search Attributes with card counts

     Browse and search Attributes with pagination and card count information

    Args:
        take (Union[Unset, int]):  Default: 20.
        skip (Union[Unset, int]):  Default: 0.
        name (Union[Unset, str]):
        short_name (Union[Unset, str]):
        sort (Union[Unset, GetAttributesSort]):
        order (Union[Unset, GetAttributesOrder]):  Default: GetAttributesOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ErrorResponse, PaginatedAttributesResponse]]
    """

    kwargs = _get_kwargs(
        take=take,
        skip=skip,
        name=name,
        short_name=short_name,
        sort=sort,
        order=order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    take: Union[Unset, int] = 20,
    skip: Union[Unset, int] = 0,
    name: Union[Unset, str] = UNSET,
    short_name: Union[Unset, str] = UNSET,
    sort: Union[Unset, GetAttributesSort] = UNSET,
    order: Union[Unset, GetAttributesOrder] = GetAttributesOrder.ASC,
) -> Optional[Union[ErrorResponse, PaginatedAttributesResponse]]:
    """Browse and search Attributes with card counts

     Browse and search Attributes with pagination and card count information

    Args:
        take (Union[Unset, int]):  Default: 20.
        skip (Union[Unset, int]):  Default: 0.
        name (Union[Unset, str]):
        short_name (Union[Unset, str]):
        sort (Union[Unset, GetAttributesSort]):
        order (Union[Unset, GetAttributesOrder]):  Default: GetAttributesOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ErrorResponse, PaginatedAttributesResponse]
    """

    return sync_detailed(
        client=client,
        take=take,
        skip=skip,
        name=name,
        short_name=short_name,
        sort=sort,
        order=order,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    take: Union[Unset, int] = 20,
    skip: Union[Unset, int] = 0,
    name: Union[Unset, str] = UNSET,
    short_name: Union[Unset, str] = UNSET,
    sort: Union[Unset, GetAttributesSort] = UNSET,
    order: Union[Unset, GetAttributesOrder] = GetAttributesOrder.ASC,
) -> Response[Union[ErrorResponse, PaginatedAttributesResponse]]:
    """Browse and search Attributes with card counts

     Browse and search Attributes with pagination and card count information

    Args:
        take (Union[Unset, int]):  Default: 20.
        skip (Union[Unset, int]):  Default: 0.
        name (Union[Unset, str]):
        short_name (Union[Unset, str]):
        sort (Union[Unset, GetAttributesSort]):
        order (Union[Unset, GetAttributesOrder]):  Default: GetAttributesOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[ErrorResponse, PaginatedAttributesResponse]]
    """

    kwargs = _get_kwargs(
        take=take,
        skip=skip,
        name=name,
        short_name=short_name,
        sort=sort,
        order=order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    take: Union[Unset, int] = 20,
    skip: Union[Unset, int] = 0,
    name: Union[Unset, str] = UNSET,
    short_name: Union[Unset, str] = UNSET,
    sort: Union[Unset, GetAttributesSort] = UNSET,
    order: Union[Unset, GetAttributesOrder] = GetAttributesOrder.ASC,
) -> Optional[Union[ErrorResponse, PaginatedAttributesResponse]]:
    """Browse and search Attributes with card counts

     Browse and search Attributes with pagination and card count information

    Args:
        take (Union[Unset, int]):  Default: 20.
        skip (Union[Unset, int]):  Default: 0.
        name (Union[Unset, str]):
        short_name (Union[Unset, str]):
        sort (Union[Unset, GetAttributesSort]):
        order (Union[Unset, GetAttributesOrder]):  Default: GetAttributesOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[ErrorResponse, PaginatedAttributesResponse]
    """

    return (
        await asyncio_detailed(
            client=client,
            take=take,
            skip=skip,
            name=name,
            short_name=short_name,
            sort=sort,
            order=order,
        )
    ).parsed
