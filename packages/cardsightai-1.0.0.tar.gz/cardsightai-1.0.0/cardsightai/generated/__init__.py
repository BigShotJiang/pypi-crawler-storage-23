"""Auto-generated CardSight AI API client code. Do not edit manually."""
