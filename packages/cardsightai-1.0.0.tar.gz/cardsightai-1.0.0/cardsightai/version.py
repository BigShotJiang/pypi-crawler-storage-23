"""Version information for the CardSight AI SDK"""

__version__ = "1.0.0"
