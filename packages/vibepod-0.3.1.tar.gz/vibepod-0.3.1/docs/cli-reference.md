# CLI Reference

Complete reference for all `vp` commands, auto-generated from the source.

::: mkdocs-typer
    :module: vibepod.cli
    :command: app
    :depth: 2
