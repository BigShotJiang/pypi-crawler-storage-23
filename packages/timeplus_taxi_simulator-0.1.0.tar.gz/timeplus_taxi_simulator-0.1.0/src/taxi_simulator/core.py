import json
import time
import math
import random
import os
import sys
from datetime import datetime, timezone

# Default path relative to this file
DEFAULT_ROUTES_PATH = os.path.join(os.path.dirname(__file__), "routes.json")

# ==========================================
# GEOMETRY HELPERS
# ==========================================
def haversine_distance(lon1, lat1, lon2, lat2):
    lon1, lat1, lon2, lat2 = map(math.radians, [lon1, lat1, lon2, lat2])
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    r = 6371 
    return c * r

def interpolate_position(lon1, lat1, lon2, lat2, fraction):
    new_lon = lon1 + (lon2 - lon1) * fraction
    new_lat = lat1 + (lat2 - lat1) * fraction
    return new_lon, new_lat

# ==========================================
# DATA PARSING HELPERS
# ==========================================
def _is_point(item):
    """Checks if an item looks like a [lon, lat] pair."""
    return (isinstance(item, (list, tuple)) and 
            len(item) >= 2 and 
            isinstance(item[0], (int, float)) and 
            isinstance(item[1], (int, float)))

def _find_route_coordinates(obj):
    """
    Recursively find the longest list of POINTS.
    A valid route must be [[x,y], [x,y], ...], not just [x,y].
    """
    # 1. Check if 'obj' itself is a valid route (List of Points)
    if isinstance(obj, list) and len(obj) >= 2:
        # To be a route, the first element must be a point, not a number
        if _is_point(obj[0]):
            return obj

    # 2. If not, search recursively inside
    candidates = []
    
    if isinstance(obj, list):
        for item in obj:
            # optimization: don't recurse if item is a number
            if not isinstance(item, (int, float)):
                res = _find_route_coordinates(item)
                if res: candidates.append(res)
                
    elif isinstance(obj, dict):
        # Priority search for known GeoJSON/Route keys
        priority_keys = ["path", "coordinates", "geometry", "points", "routes"]
        for key in priority_keys:
            if key in obj:
                res = _find_route_coordinates(obj[key])
                if res: return res # Return immediately if found in a specific key
        
        # Fallback: search all values
        for v in obj.values():
            if not isinstance(v, (int, float, str)):
                res = _find_route_coordinates(v)
                if res: candidates.append(res)
            
    if not candidates:
        return None
    
    # Return the longest candidate found (assumes longest list of points is the main route)
    return max(candidates, key=len)

# ==========================================
# CAR LOGIC
# ==========================================
class Car:
    def __init__(self, car_id, route, speed_kmh=60.0):
        self.car_id = car_id
        self.route = route
        
        # Validate route format before processing
        if not self.route or not _is_point(self.route[0]):
             raise ValueError(f"Invalid route format for {car_id}. Expected list of points.")

        self.speed_mps = (speed_kmh * 1000) / 3600 * random.uniform(0.8, 1.2)
        
        start_pt = self.route[0]
        self.lon, self.lat = start_pt[0], start_pt[1]
        
        self.current_idx = 0
        self.next_idx = 1
        self.dist_to_next = self._calc_dist_to_next()

    def _calc_dist_to_next(self):
        p1 = self.route[self.current_idx]
        p2 = self.route[self.next_idx]
        return haversine_distance(p1[0], p1[1], p2[0], p2[1]) * 1000.0

    def move(self, delta_time, realtime_factor=1.0):
        distance_to_travel = self.speed_mps * delta_time * realtime_factor

        while distance_to_travel > 0:
            if distance_to_travel >= self.dist_to_next:
                distance_to_travel -= self.dist_to_next
                self.current_idx = self.next_idx
                self.next_idx += 1
                if self.next_idx >= len(self.route):
                    self.current_idx = 0
                    self.next_idx = 1
                
                p_curr = self.route[self.current_idx]
                self.lon, self.lat = p_curr[0], p_curr[1]
                self.dist_to_next = self._calc_dist_to_next()
            else:
                fraction = distance_to_travel / self.dist_to_next
                p_curr = self.route[self.current_idx]
                p_next = self.route[self.next_idx]
                self.lon, self.lat = interpolate_position(
                    p_curr[0], p_curr[1], p_next[0], p_next[1], fraction
                )
                self.dist_to_next -= distance_to_travel
                distance_to_travel = 0

    def get_data(self):
        return {
            "car_id": self.car_id,
            "time": datetime.now(timezone.utc).isoformat(),
            "longitude": round(self.lon, 6),
            "latitude": round(self.lat, 6),
            "speed_kmh": round(self.speed_mps * 3.6, 1)
        }

# ==========================================
# PUBLIC API
# ==========================================
def stream_taxi_data(
    num_cars=10, 
    speed_kmh=60.0, 
    update_interval=0.5, 
    realtime_factor=5.0,
    custom_routes_file=None
):
    """
    Generator that yields a continuous stream of car data dictionaries.
    """
    
    # 1. Load Routes
    fpath = custom_routes_file or DEFAULT_ROUTES_PATH
    if not os.path.exists(fpath):
        raise FileNotFoundError(f"Routes file not found: {fpath}")

    with open(fpath, 'r') as f:
        data = json.load(f)

    # Handle standard wrapper keys if present (e.g. {"routes": [...]})
    raw_routes_list = []
    if isinstance(data, list):
        raw_routes_list = data
    elif isinstance(data, dict):
        # Look for common list containers
        for k in ['routes', 'features', 'paths']:
            if k in data and isinstance(data[k], list):
                raw_routes_list = data[k]
                break
        # If no list found, treat the dict itself as a single item source
        if not raw_routes_list:
            raw_routes_list = [data]

    # 2. Initialize Cars
    cars = []
    for i in range(num_cars):
        # Round-robin selection of routes
        raw_route_obj = raw_routes_list[i % len(raw_routes_list)]
        
        # Deep search for the actual coordinate list
        route = _find_route_coordinates(raw_route_obj)
        
        if route and len(route) > 1:
            try:
                cars.append(Car(f"car_{i+1:04d}", route, speed_kmh))
            except ValueError:
                continue # Skip bad routes

    if not cars:
        raise ValueError("Could not initialize any cars. The routes file structure might be unrecognized.")

    # 3. Stream Loop
    try:
        while True:
            start_time = time.time()
            
            for car in cars:
                car.move(update_interval, realtime_factor)
                yield car.get_data()
            
            elapsed = time.time() - start_time
            sleep_time = max(0, update_interval - elapsed)
            time.sleep(sleep_time)
            
    except KeyboardInterrupt:
        pass

def main_cli():
    """Entry point for command line usage."""
    # Run the generator and print JSON lines
    try:
        sys.stderr.write("Starting Taxi Simulator... (Ctrl+C to stop)\n")
        # Using default settings for CLI
        for event in stream_taxi_data(num_cars=50):
            print(json.dumps(event))
            sys.stdout.flush()
    except KeyboardInterrupt:
        sys.stderr.write("\nStopped.\n")