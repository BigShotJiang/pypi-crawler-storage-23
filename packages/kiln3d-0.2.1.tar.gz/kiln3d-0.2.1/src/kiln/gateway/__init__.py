"""Gateway integrations for distributed manufacturing networks."""
