"""Allow running ``python -m kiln`` to start the Kiln CLI."""

from kiln.cli.main import cli

cli()
