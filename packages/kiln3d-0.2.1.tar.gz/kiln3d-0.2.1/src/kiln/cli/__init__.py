"""Kiln CLI — agent-friendly command-line interface for 3D printers."""
