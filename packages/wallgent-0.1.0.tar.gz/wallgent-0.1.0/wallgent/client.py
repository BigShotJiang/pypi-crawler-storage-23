"""Main Wallgent client — entry point for all API operations."""

from __future__ import annotations

from typing import Optional

from wallgent.http import DEFAULT_BASE_URL, HttpClient
from wallgent.resources.cards import CardsResource
from wallgent.resources.customers import CustomersResource
from wallgent.resources.invoices import InvoicesResource
from wallgent.resources.network import NetworkResource
from wallgent.resources.payment_links import PaymentLinksResource
from wallgent.resources.payments import PaymentsResource
from wallgent.resources.policies import PoliciesResource
from wallgent.resources.transfers import TransfersResource
from wallgent.resources.wallets import WalletsResource
from wallgent.resources.webhooks import WebhooksResource


class Wallgent:
    """Wallgent API client.

    Usage::

        from wallgent import Wallgent

        client = Wallgent("wg_test_...")

        # Sync
        wallet = client.wallets.create(name="My Agent")

        # Async
        wallet = await client.wallets.acreate(name="My Agent")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        if not api_key:
            raise ValueError("API key is required")

        self._http = HttpClient(api_key, base_url=base_url, timeout=timeout)

        self._wallets: Optional[WalletsResource] = None
        self._payments: Optional[PaymentsResource] = None
        self._policies: Optional[PoliciesResource] = None
        self._webhooks: Optional[WebhooksResource] = None
        self._transfers: Optional[TransfersResource] = None
        self._cards: Optional[CardsResource] = None
        self._payment_links: Optional[PaymentLinksResource] = None
        self._customers: Optional[CustomersResource] = None
        self._invoices: Optional[InvoicesResource] = None
        self._network: Optional[NetworkResource] = None

    @property
    def wallets(self) -> WalletsResource:
        if self._wallets is None:
            self._wallets = WalletsResource(self._http)
        return self._wallets

    @property
    def payments(self) -> PaymentsResource:
        if self._payments is None:
            self._payments = PaymentsResource(self._http)
        return self._payments

    @property
    def policies(self) -> PoliciesResource:
        if self._policies is None:
            self._policies = PoliciesResource(self._http)
        return self._policies

    @property
    def webhooks(self) -> WebhooksResource:
        if self._webhooks is None:
            self._webhooks = WebhooksResource(self._http)
        return self._webhooks

    @property
    def transfers(self) -> TransfersResource:
        if self._transfers is None:
            self._transfers = TransfersResource(self._http)
        return self._transfers

    @property
    def cards(self) -> CardsResource:
        if self._cards is None:
            self._cards = CardsResource(self._http)
        return self._cards

    @property
    def payment_links(self) -> PaymentLinksResource:
        if self._payment_links is None:
            self._payment_links = PaymentLinksResource(self._http)
        return self._payment_links

    @property
    def customers(self) -> CustomersResource:
        if self._customers is None:
            self._customers = CustomersResource(self._http)
        return self._customers

    @property
    def invoices(self) -> InvoicesResource:
        if self._invoices is None:
            self._invoices = InvoicesResource(self._http)
        return self._invoices

    @property
    def network(self) -> NetworkResource:
        if self._network is None:
            self._network = NetworkResource(self._http)
        return self._network
