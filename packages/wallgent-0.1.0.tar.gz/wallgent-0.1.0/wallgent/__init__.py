"""Wallgent Python SDK — financial infrastructure for AI agents."""

from wallgent.client import Wallgent
from wallgent.errors import (
    EnvironmentMismatchError,
    InsufficientFundsError,
    InvalidAmountError,
    PolicyDeniedError,
    RateLimitExceededError,
    UnauthorizedError,
    ValidationError,
    WallgentError,
    WalletNotFoundError,
)

__all__ = [
    "Wallgent",
    "WallgentError",
    "InsufficientFundsError",
    "PolicyDeniedError",
    "WalletNotFoundError",
    "InvalidAmountError",
    "EnvironmentMismatchError",
    "RateLimitExceededError",
    "UnauthorizedError",
    "ValidationError",
]

__version__ = "0.1.0"
