"""Payment link resource — create, list, and cancel payment links."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from wallgent.http import HttpClient


class PaymentLinksResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, **params: Any) -> Dict[str, Any]:
        return self._http.request("POST", "/v1/payment-links", params)

    def list(
        self,
        *,
        wallet_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        parts = {}
        if wallet_id:
            parts["walletId"] = wallet_id
        if status:
            parts["status"] = status
        if limit is not None:
            parts["limit"] = str(limit)
        qs = "&".join(f"{k}={v}" for k, v in parts.items())
        resp = self._http.request("GET", f"/v1/payment-links{'?' + qs if qs else ''}")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    def cancel(self, link_id: str) -> Dict[str, Any]:
        return self._http.request("PATCH", f"/v1/payment-links/{link_id}")

    # ── Async variants ───────────────────────────────────────

    async def acreate(self, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("POST", "/v1/payment-links", params)

    async def alist(
        self,
        *,
        wallet_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        parts = {}
        if wallet_id:
            parts["walletId"] = wallet_id
        if status:
            parts["status"] = status
        if limit is not None:
            parts["limit"] = str(limit)
        qs = "&".join(f"{k}={v}" for k, v in parts.items())
        resp = await self._http.arequest("GET", f"/v1/payment-links{'?' + qs if qs else ''}")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    async def acancel(self, link_id: str) -> Dict[str, Any]:
        return await self._http.arequest("PATCH", f"/v1/payment-links/{link_id}")
