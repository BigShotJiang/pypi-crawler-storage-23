"""Customer resource — create, list, and manage customers for invoicing."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List

if TYPE_CHECKING:
    from wallgent.http import HttpClient


class CustomersResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, **params: Any) -> Dict[str, Any]:
        return self._http.request("POST", "/v1/customers", params)

    def list(self) -> List[Dict[str, Any]]:
        resp = self._http.request("GET", "/v1/customers")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    def get(self, customer_id: str) -> Dict[str, Any]:
        return self._http.request("GET", f"/v1/customers/{customer_id}")

    def update(self, customer_id: str, **params: Any) -> Dict[str, Any]:
        return self._http.request("PATCH", f"/v1/customers/{customer_id}", params)

    # ── Async variants ───────────────────────────────────────

    async def acreate(self, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("POST", "/v1/customers", params)

    async def alist(self) -> List[Dict[str, Any]]:
        resp = await self._http.arequest("GET", "/v1/customers")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    async def aget(self, customer_id: str) -> Dict[str, Any]:
        return await self._http.arequest("GET", f"/v1/customers/{customer_id}")

    async def aupdate(self, customer_id: str, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("PATCH", f"/v1/customers/{customer_id}", params)
