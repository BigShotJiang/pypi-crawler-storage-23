"""Invoice resource — create, finalize, void, refund, and charge invoices."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from wallgent.http import HttpClient


class InvoicesResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, **params: Any) -> Dict[str, Any]:
        return self._http.request("POST", "/v1/invoices", params)

    def list(
        self,
        *,
        wallet_id: Optional[str] = None,
        customer_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        parts = {}
        if wallet_id:
            parts["walletId"] = wallet_id
        if customer_id:
            parts["customerId"] = customer_id
        if status:
            parts["status"] = status
        qs = "&".join(f"{k}={v}" for k, v in parts.items())
        resp = self._http.request("GET", f"/v1/invoices{'?' + qs if qs else ''}")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    def get(self, invoice_id: str) -> Dict[str, Any]:
        return self._http.request("GET", f"/v1/invoices/{invoice_id}")

    def finalize(self, invoice_id: str) -> Dict[str, Any]:
        return self._http.request("POST", f"/v1/invoices/{invoice_id}/finalize")

    def void(self, invoice_id: str) -> Dict[str, Any]:
        return self._http.request("POST", f"/v1/invoices/{invoice_id}/void")

    def refund(self, invoice_id: str) -> Dict[str, Any]:
        return self._http.request("POST", f"/v1/invoices/{invoice_id}/refund")

    def charge(self, **params: Any) -> Dict[str, Any]:
        return self._http.request("POST", "/v1/invoices/charge", params)

    # ── Async variants ───────────────────────────────────────

    async def acreate(self, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("POST", "/v1/invoices", params)

    async def alist(
        self,
        *,
        wallet_id: Optional[str] = None,
        customer_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        parts = {}
        if wallet_id:
            parts["walletId"] = wallet_id
        if customer_id:
            parts["customerId"] = customer_id
        if status:
            parts["status"] = status
        qs = "&".join(f"{k}={v}" for k, v in parts.items())
        resp = await self._http.arequest("GET", f"/v1/invoices{'?' + qs if qs else ''}")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    async def aget(self, invoice_id: str) -> Dict[str, Any]:
        return await self._http.arequest("GET", f"/v1/invoices/{invoice_id}")

    async def afinalize(self, invoice_id: str) -> Dict[str, Any]:
        return await self._http.arequest("POST", f"/v1/invoices/{invoice_id}/finalize")

    async def avoid(self, invoice_id: str) -> Dict[str, Any]:
        return await self._http.arequest("POST", f"/v1/invoices/{invoice_id}/void")

    async def arefund(self, invoice_id: str) -> Dict[str, Any]:
        return await self._http.arequest("POST", f"/v1/invoices/{invoice_id}/refund")

    async def acharge(self, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("POST", "/v1/invoices/charge", params)
