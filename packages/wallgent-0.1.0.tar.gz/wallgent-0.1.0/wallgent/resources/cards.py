"""Card resource — create, list, and manage virtual cards."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from wallgent.http import HttpClient


class CardsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, **params: Any) -> Dict[str, Any]:
        return self._http.request("POST", "/v1/cards", params)

    def list(self, wallet_id: Optional[str] = None) -> List[Dict[str, Any]]:
        qs = f"?walletId={wallet_id}" if wallet_id else ""
        resp = self._http.request("GET", f"/v1/cards{qs}")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    def get(self, card_id: str) -> Dict[str, Any]:
        return self._http.request("GET", f"/v1/cards/{card_id}")

    def get_details(self, card_id: str) -> Dict[str, Any]:
        return self._http.request("GET", f"/v1/cards/{card_id}/details")

    def update(self, card_id: str, **params: Any) -> Dict[str, Any]:
        return self._http.request("PATCH", f"/v1/cards/{card_id}", params)

    def cancel(self, card_id: str) -> Dict[str, Any]:
        return self._http.request("DELETE", f"/v1/cards/{card_id}")

    # ── Async variants ───────────────────────────────────────

    async def acreate(self, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("POST", "/v1/cards", params)

    async def alist(self, wallet_id: Optional[str] = None) -> List[Dict[str, Any]]:
        qs = f"?walletId={wallet_id}" if wallet_id else ""
        resp = await self._http.arequest("GET", f"/v1/cards{qs}")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    async def aget(self, card_id: str) -> Dict[str, Any]:
        return await self._http.arequest("GET", f"/v1/cards/{card_id}")

    async def aget_details(self, card_id: str) -> Dict[str, Any]:
        return await self._http.arequest("GET", f"/v1/cards/{card_id}/details")

    async def aupdate(self, card_id: str, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("PATCH", f"/v1/cards/{card_id}", params)

    async def acancel(self, card_id: str) -> Dict[str, Any]:
        return await self._http.arequest("DELETE", f"/v1/cards/{card_id}")
