"""Transfer resource — deposits, withdrawals, and external rail transfers."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from wallgent.http import HttpClient


class TransfersResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def deposit(self, **params: Any) -> Dict[str, Any]:
        return self._http.request("POST", "/v1/transfers/deposit", params)

    def withdraw(self, **params: Any) -> Dict[str, Any]:
        return self._http.request("POST", "/v1/transfers/withdraw", params)

    def list(
        self,
        *,
        wallet_id: Optional[str] = None,
        direction: Optional[str] = None,
        status: Optional[str] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
    ) -> Dict[str, Any]:
        parts = {}
        if wallet_id:
            parts["walletId"] = wallet_id
        if direction:
            parts["direction"] = direction
        if status:
            parts["status"] = status
        if limit is not None:
            parts["limit"] = str(limit)
        if cursor:
            parts["cursor"] = cursor
        qs = "&".join(f"{k}={v}" for k, v in parts.items())
        return self._http.request("GET", f"/v1/transfers{'?' + qs if qs else ''}")

    def get(self, transfer_id: str) -> Dict[str, Any]:
        return self._http.request("GET", f"/v1/transfers/{transfer_id}")

    def cancel(self, transfer_id: str) -> Dict[str, Any]:
        return self._http.request("POST", f"/v1/transfers/{transfer_id}/cancel")

    # ── Async variants ───────────────────────────────────────

    async def adeposit(self, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("POST", "/v1/transfers/deposit", params)

    async def awithdraw(self, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("POST", "/v1/transfers/withdraw", params)

    async def alist(
        self,
        *,
        wallet_id: Optional[str] = None,
        direction: Optional[str] = None,
        status: Optional[str] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
    ) -> Dict[str, Any]:
        parts = {}
        if wallet_id:
            parts["walletId"] = wallet_id
        if direction:
            parts["direction"] = direction
        if status:
            parts["status"] = status
        if limit is not None:
            parts["limit"] = str(limit)
        if cursor:
            parts["cursor"] = cursor
        qs = "&".join(f"{k}={v}" for k, v in parts.items())
        return await self._http.arequest("GET", f"/v1/transfers{'?' + qs if qs else ''}")

    async def aget(self, transfer_id: str) -> Dict[str, Any]:
        return await self._http.arequest("GET", f"/v1/transfers/{transfer_id}")

    async def acancel(self, transfer_id: str) -> Dict[str, Any]:
        return await self._http.arequest("POST", f"/v1/transfers/{transfer_id}/cancel")
