"""Webhook resource — create, list, update, and delete webhook endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List

if TYPE_CHECKING:
    from wallgent.http import HttpClient


class WebhooksResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, **params: Any) -> Dict[str, Any]:
        return self._http.request("POST", "/v1/webhooks", params)

    def list(self) -> List[Dict[str, Any]]:
        resp = self._http.request("GET", "/v1/webhooks")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    def update(self, webhook_id: str, **params: Any) -> Dict[str, Any]:
        return self._http.request("PATCH", f"/v1/webhooks/{webhook_id}", params)

    def delete(self, webhook_id: str) -> None:
        self._http.request("DELETE", f"/v1/webhooks/{webhook_id}")

    # ── Async variants ───────────────────────────────────────

    async def acreate(self, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("POST", "/v1/webhooks", params)

    async def alist(self) -> List[Dict[str, Any]]:
        resp = await self._http.arequest("GET", "/v1/webhooks")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    async def aupdate(self, webhook_id: str, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("PATCH", f"/v1/webhooks/{webhook_id}", params)

    async def adelete(self, webhook_id: str) -> None:
        await self._http.arequest("DELETE", f"/v1/webhooks/{webhook_id}")
