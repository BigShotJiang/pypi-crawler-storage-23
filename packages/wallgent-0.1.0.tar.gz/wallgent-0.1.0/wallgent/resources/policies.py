"""Policy resource — create, list, update, and delete wallet spending policies."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from wallgent.http import HttpClient


class PoliciesResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, wallet_id: str, **params: Any) -> Dict[str, Any]:
        return self._http.request("POST", f"/v1/wallets/{wallet_id}/policies", params)

    def list(self, wallet_id: str) -> List[Dict[str, Any]]:
        resp = self._http.request("GET", f"/v1/wallets/{wallet_id}/policies")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    def update(self, wallet_id: str, policy_id: str, **params: Any) -> Dict[str, Any]:
        return self._http.request("PATCH", f"/v1/wallets/{wallet_id}/policies/{policy_id}", params)

    def delete(self, wallet_id: str, policy_id: str) -> None:
        self._http.request("DELETE", f"/v1/wallets/{wallet_id}/policies/{policy_id}")

    # ── Async variants ───────────────────────────────────────

    async def acreate(self, wallet_id: str, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest("POST", f"/v1/wallets/{wallet_id}/policies", params)

    async def alist(self, wallet_id: str) -> List[Dict[str, Any]]:
        resp = await self._http.arequest("GET", f"/v1/wallets/{wallet_id}/policies")
        return resp.get("data", []) if isinstance(resp, dict) else resp

    async def aupdate(self, wallet_id: str, policy_id: str, **params: Any) -> Dict[str, Any]:
        return await self._http.arequest(
            "PATCH", f"/v1/wallets/{wallet_id}/policies/{policy_id}", params
        )

    async def adelete(self, wallet_id: str, policy_id: str) -> None:
        await self._http.arequest("DELETE", f"/v1/wallets/{wallet_id}/policies/{policy_id}")
