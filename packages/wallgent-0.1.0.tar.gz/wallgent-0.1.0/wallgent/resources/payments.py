"""Payment resource — send payments between wallets."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from wallgent.http import HttpClient


class PaymentsResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def send(
        self,
        *,
        source_wallet_id: str,
        destination_wallet_id: str,
        amount: float,
        idempotency_key: str,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "from": source_wallet_id,
            "to": destination_wallet_id,
            "amount": amount,
            "idempotencyKey": idempotency_key,
        }
        if description is not None:
            body["description"] = description
        return self._http.request("POST", "/v1/payments", body)

    def retrieve(self, payment_id: str) -> Dict[str, Any]:
        return self._http.request("GET", f"/v1/payments/{payment_id}")

    # ── Async variants ───────────────────────────────────────

    async def asend(
        self,
        *,
        source_wallet_id: str,
        destination_wallet_id: str,
        amount: float,
        idempotency_key: str,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "from": source_wallet_id,
            "to": destination_wallet_id,
            "amount": amount,
            "idempotencyKey": idempotency_key,
        }
        if description is not None:
            body["description"] = description
        return await self._http.arequest("POST", "/v1/payments", body)

    async def aretrieve(self, payment_id: str) -> Dict[str, Any]:
        return await self._http.arequest("GET", f"/v1/payments/{payment_id}")
