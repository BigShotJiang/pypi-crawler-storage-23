"""Resource modules for the Wallgent API."""

from wallgent.resources.cards import CardsResource
from wallgent.resources.customers import CustomersResource
from wallgent.resources.invoices import InvoicesResource
from wallgent.resources.network import NetworkResource
from wallgent.resources.payment_links import PaymentLinksResource
from wallgent.resources.payments import PaymentsResource
from wallgent.resources.policies import PoliciesResource
from wallgent.resources.transfers import TransfersResource
from wallgent.resources.wallets import WalletsResource
from wallgent.resources.webhooks import WebhooksResource

__all__ = [
    "CardsResource",
    "CustomersResource",
    "InvoicesResource",
    "NetworkResource",
    "PaymentLinksResource",
    "PaymentsResource",
    "PoliciesResource",
    "TransfersResource",
    "WalletsResource",
    "WebhooksResource",
]
