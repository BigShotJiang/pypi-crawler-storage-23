# wallgent

Python SDK for the [Wallgent](https://wallgent.com) API — financial infrastructure for AI agents.

## Installation

```bash
pip install wallgent
```

With LangChain integration:
```bash
pip install "wallgent[langchain]"
```

With CrewAI integration:
```bash
pip install "wallgent[crewai]"
```

## Quick Start

```python
from wallgent import Wallgent

client = Wallgent("wg_live_...")

# Create a wallet
wallet = client.wallets.create(name="My Agent")

# Send a payment
payment = client.payments.create(
    from_wallet_id=wallet["id"],
    to_wallet_id="wal_...",
    amount="10.00",
    currency="USD",
)

# Async usage
import asyncio

async def main():
    wallet = await client.wallets.acreate(name="Async Agent")

asyncio.run(main())
```

## LangChain Integration

```python
from wallgent.langchain import WallgentToolkit
from langchain.agents import create_tool_calling_agent

toolkit = WallgentToolkit(api_key="wg_live_...")
tools = toolkit.get_tools()
```

## CrewAI Integration

```python
from wallgent.crewai import WallgentTool

tool = WallgentTool(api_key="wg_live_...")
```

## Documentation

Full docs at [docs.wallgent.com](https://docs.wallgent.com).

## License

MIT
