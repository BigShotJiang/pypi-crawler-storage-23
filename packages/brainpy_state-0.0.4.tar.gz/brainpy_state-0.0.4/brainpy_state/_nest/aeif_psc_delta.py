# Copyright 2026 BrainX Ecosystem Limited. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

# -*- coding: utf-8 -*-

import math
from typing import Callable

import brainstate
import braintools
import brainunit as u
import jax
import jax.numpy as jnp
import numpy as np
from brainstate.typing import ArrayLike, Size

from ._base import NESTNeuron

__all__ = [
    'aeif_psc_delta',
]


class aeif_psc_delta(NESTNeuron):
    r"""NEST-compatible ``aeif_psc_delta`` neuron model.

    Current-based adaptive exponential integrate-and-fire neuron with
    delta-shaped synaptic input. Implements NEST ``models/aeif_psc_delta.{h,cpp}``
    semantics with adaptive RKF45 integration, in-loop spike handling, and optional
    refractory input buffering.

    **1. Mathematical Formulation**

    The model combines exponential spike-initiation current (AdEx), spike-triggered
    and subthreshold adaptation current :math:`w`, and delta-function synaptic input
    that directly jumps the membrane voltage.

    Membrane dynamics:

    .. math::

       C_m \frac{dV}{dt}
       =
       -g_L (V - E_L)
       + g_L \Delta_T \exp\!\left(\frac{V - V_{th}}{\Delta_T}\right)
       - w + I_e + I_{\mathrm{stim}}.

    Adaptation dynamics:

    .. math::

       \tau_w \frac{dw}{dt} = a (V - E_L) - w.

    Incoming delta spikes are interpreted as instantaneous voltage jumps:

    .. math::

       V \leftarrow V + J \sum_k \delta(t - t_k).

    Here :math:`J` is the synaptic weight in millivolts.

    **2. Refractory and Spike Handling**

    During refractory integration (when ``refractory_step_count > 0``), NEST clamps
    the effective membrane voltage to ``V_reset`` and sets :math:`dV/dt = 0`. Outside
    refractory, the RHS uses :math:`\min(V, V_{\mathrm{peak}})` as the effective voltage
    to prevent unbounded exponential growth.

    Threshold detection uses:

    - ``V_peak`` if ``Delta_T > 0`` (exponential regime),
    - ``V_th`` if ``Delta_T == 0`` (IAF-like limit).

    On each detected spike:

    1. ``V`` is reset to ``V_reset``,
    2. adaptation jump ``w <- w + b`` is applied immediately,
    3. refractory counter is set to ``ceil(t_ref / dt) + 1`` if ``t_ref > 0``.

    Spike handling occurs *inside* the adaptive RKF45 substep loop. With ``t_ref = 0``,
    multiple spikes can occur within one simulation step, matching NEST behavior.

    **3. Refractory Input Buffering**

    If ``refractory_input=True`` (NEST ``refractory_input`` flag), delta spikes arriving
    during refractory are accumulated into ``refractory_spike_buffer`` with NEST's
    exponential discount factor:

    .. math::

       \mathrm{buffer} \leftarrow \mathrm{buffer} + J \cdot \exp(-r \cdot \Delta t / \tau_m),

    where :math:`r` is the current refractory step count. The buffered input is applied
    when the neuron exits refractory.

    **4. Update Order per Simulation Step**

    1. Integrate ODEs on interval :math:`(t, t+\Delta t]` via adaptive RKF45.
    2. **Inside integration loop**:
        a. Apply arriving delta jump to ``V`` (if not refractory).
        b. Apply refractory clamp (``V <- V_reset`` if refractory).
        c. Apply refractory buffering logic if ``refractory_input=True``.
        d. Threshold detection and spike/reset/adaptation handling.
    3. **After loop**: Decrement refractory counter once.
    4. Store external current input ``x`` into one-step delayed ``I_stim``.

    **5. Numerical Integration Details**

    The model uses adaptive Runge-Kutta-Fehlberg 4(5) (RKF45) with local error control.
    The step size ``integration_step`` is adjusted per neuron to satisfy the tolerance
    ``gsl_error_tol``, matching NEST's GSL solver behavior. Minimum step size is clamped
    to ``1e-8 ms`` to prevent infinite loops.

    The exponential term is computed using the effective voltage :math:`V_{\mathrm{eff}}`:

    .. math::

       V_{\mathrm{eff}} = \begin{cases}
           V_{\mathrm{reset}} & \text{if refractory}, \\
           \min(V, V_{\mathrm{peak}}) & \text{otherwise}.
       \end{cases}

    Overflow protection: the model validates that :math:`(V_{\mathrm{peak}} - V_{\mathrm{th}}) / \Delta_T`
    does not exceed ``log(DBL_MAX / 1e20)`` to prevent numerical overflow at spike time.

    **6. Differences from NEST**

    - **Spike output format**: NEST emits spike events; brainpy.state returns a binary
      array (0/1) per simulation step. Internal dynamics (adaptation increments, refractory
      handling) match NEST exactly.
    - **Surrogate gradients**: brainpy.state uses ``spk_fun`` (e.g., ``ReluGrad()``) for
      differentiable spike generation; NEST does not support gradient-based learning.
    - **Spike reset mode**: ``spk_reset='hard'`` (default) matches NEST; ``'soft'`` is
      available but non-canonical.

    Parameters
    ----------
    in_size : int, tuple of int
        Shape of the neuron population. Can be an integer (1D) or tuple (multi-dimensional).
    V_peak : ArrayLike, optional
        Spike detection threshold in millivolts. Used when ``Delta_T > 0``. Default: ``0.0 * u.mV``.
        Can be scalar or array matching ``in_size``.
    V_reset : ArrayLike, optional
        Reset potential in millivolts. Default: ``-60.0 * u.mV``. Must satisfy ``V_reset < V_peak``.
    t_ref : ArrayLike, optional
        Absolute refractory period in milliseconds. Default: ``0.0 * u.ms`` (no refractoriness).
        Must be non-negative.
    g_L : ArrayLike, optional
        Leak conductance in nanosiemens. Default: ``30.0 * u.nS``. Must be positive.
    C_m : ArrayLike, optional
        Membrane capacitance in picofarads. Default: ``281.0 * u.pF``. Must be positive.
    E_L : ArrayLike, optional
        Leak reversal potential in millivolts. Default: ``-70.6 * u.mV``.
    Delta_T : ArrayLike, optional
        Exponential slope factor in millivolts. Default: ``2.0 * u.mV``. Set to ``0.0`` for
        IAF-like limit. Must be non-negative.
    tau_w : ArrayLike, optional
        Adaptation time constant in milliseconds. Default: ``144.0 * u.ms``. Must be positive.
    a : ArrayLike, optional
        Subthreshold adaptation coupling in nanosiemens. Default: ``4.0 * u.nS``.
    b : ArrayLike, optional
        Spike-triggered adaptation increment in picoamperes. Default: ``80.5 * u.pA``.
    V_th : ArrayLike, optional
        Spike initiation threshold in millivolts (used in exponential term). Default: ``-50.4 * u.mV``.
        Must satisfy ``V_th <= V_peak``.
    I_e : ArrayLike, optional
        Constant external current in picoamperes. Default: ``0.0 * u.pA``.
    gsl_error_tol : ArrayLike, optional
        RKF45 local error tolerance (unitless). Default: ``1e-6``. Must be positive.
    refractory_input : bool, optional
        If True, accumulate delta spikes arriving during refractory with NEST's exponential
        discount factor and apply when refractory ends. Default: ``False``.
    V_initializer : Callable, optional
        Membrane potential initializer. Default: ``braintools.init.Constant(-70.6 * u.mV)``.
    w_initializer : Callable, optional
        Adaptation current initializer. Default: ``braintools.init.Constant(0.0 * u.pA)``.
    spk_fun : Callable, optional
        Surrogate gradient function for differentiable spike generation. Default: ``braintools.surrogate.ReluGrad()``.
    spk_reset : str, optional
        Spike reset mode. Options: ``'hard'`` (stop gradient), ``'soft'`` (V -= V_th). Default: ``'hard'``.
    ref_var : bool, optional
        If True, expose ``self.refractory`` as a boolean state variable. Default: ``False``.
    name : str, optional
        Name of the neuron group.

    Parameter Mapping
    -----------------

    ==================== ================== ========================================== =====================================================
    **Parameter**        **Default**        **Math equivalent**                        **Description**
    ==================== ================== ========================================== =====================================================
    ``in_size``          (required)         —                                          Population shape
    ``V_peak``           0 mV               :math:`V_{\mathrm{peak}}`                  Spike detection threshold (if :math:`\Delta_T > 0`)
    ``V_reset``          -60 mV             :math:`V_{\mathrm{reset}}`                 Reset potential
    ``t_ref``            0 ms               :math:`t_{\mathrm{ref}}`                   Absolute refractory duration
    ``g_L``              30 nS              :math:`g_{\mathrm{L}}`                     Leak conductance
    ``C_m``              281 pF             :math:`C_{\mathrm{m}}`                     Membrane capacitance
    ``E_L``              -70.6 mV           :math:`E_{\mathrm{L}}`                     Leak reversal potential
    ``Delta_T``          2 mV               :math:`\Delta_T`                           Exponential slope factor
    ``tau_w``            144 ms             :math:`\tau_w`                             Adaptation time constant
    ``a``                4 nS               :math:`a`                                  Subthreshold adaptation coupling
    ``b``                80.5 pA            :math:`b`                                  Spike-triggered adaptation increment
    ``V_th``             -50.4 mV           :math:`V_{\mathrm{th}}`                    Spike initiation threshold (in exponential term)
    ``I_e``              0 pA               :math:`I_{\mathrm{e}}`                     Constant external current
    ``gsl_error_tol``    1e-6               —                                          RKF45 local error tolerance
    ``refractory_input`` ``False``          —                                          If True, buffer spikes during refractory with NEST discounting
    ``V_initializer``    Constant(-70.6 mV) —                                          Membrane initializer
    ``w_initializer``    Constant(0 pA)     —                                          Adaptation current initializer
    ``spk_fun``          ReluGrad()         —                                          Surrogate spike function
    ``spk_reset``        ``'hard'``         —                                          Reset mode; hard reset matches NEST behavior
    ``ref_var``          ``False``          —                                          If True, expose boolean refractory indicator
    ==================== ================== ========================================== =====================================================

    State Variables
    ---------------

    V : brainstate.HiddenState
        Membrane potential :math:`V_m` in millivolts. Shape: ``(*in_size, *batch_shape)``.
    w : brainstate.HiddenState
        Adaptation current in picoamperes. Shape: ``(*in_size, *batch_shape)``.
    refractory_step_count : brainstate.ShortTermState
        Remaining refractory grid steps (int32). Shape: ``(*in_size, *batch_shape)``.
    refractory_spike_buffer : brainstate.ShortTermState
        Delayed refractory delta-jump accumulator in millivolts (float64). Shape: ``(*in_size, *batch_shape)``.
    integration_step : brainstate.ShortTermState
        Persistent RKF45 internal step size in milliseconds. Shape: ``(*in_size, *batch_shape)``.
    I_stim : brainstate.ShortTermState
        One-step delayed current buffer in picoamperes. Shape: ``(*in_size, *batch_shape)``.
    last_spike_time : brainstate.ShortTermState
        Last emitted spike time in milliseconds (:math:`t+\Delta t` on spike). Shape: ``(*in_size, *batch_shape)``.
    refractory : brainstate.ShortTermState, optional
        Boolean refractory indicator. Only present if ``ref_var=True``. Shape: ``(*in_size, *batch_shape)``.

    Raises
    ------
    ValueError
        If ``V_reset >= V_peak``.
    ValueError
        If ``Delta_T < 0``.
    ValueError
        If ``V_peak < V_th``.
    ValueError
        If ``C_m <= 0``.
    ValueError
        If ``t_ref < 0``.
    ValueError
        If ``tau_w <= 0``.
    ValueError
        If ``gsl_error_tol <= 0``.
    ValueError
        If ``(V_peak - V_th) / Delta_T`` exceeds ``log(DBL_MAX / 1e20)`` (overflow protection).
    ValueError
        During integration: if ``V < -1e3`` or ``|w| > 1e6`` (numerical instability).

    Examples
    --------
    **Basic usage with delta-function input:**

    .. code-block:: python

        >>> import brainpy.state as bst
        >>> import brainunit as u
        >>> import brainstate as bs
        >>> import jax.numpy as jnp
        >>>
        >>> # Create 100 AdEx neurons
        >>> neu = bst.aeif_psc_delta(100, V_peak=0.*u.mV, V_reset=-60.*u.mV, t_ref=2.*u.ms)
        >>>
        >>> # Initialize state
        >>> with bs.environ.context(dt=0.1*u.ms):
        ...     neu.init_all_states()
        ...
        ...     # Simulate with delta input
        ...     for i in range(100):
        ...         # Delta spike input (+1 mV jump)
        ...         neu.add_delta_input('external', lambda: jnp.ones(100) * 1.0 * u.mV)
        ...         spk = neu.step_run(i, 0.0*u.pA)
        ...         print(f"t={i*0.1:.1f}ms: {spk.sum():.0f} spikes")

    **With refractory input buffering:**

    .. code-block:: python

        >>> # Enable refractory buffering
        >>> neu = bst.aeif_psc_delta(
        ...     100,
        ...     V_peak=0.*u.mV,
        ...     V_reset=-60.*u.mV,
        ...     t_ref=5.*u.ms,
        ...     refractory_input=True
        ... )
        >>>
        >>> with bs.environ.context(dt=0.1*u.ms):
        ...     neu.init_all_states()
        ...
        ...     # Spikes arriving during refractory are buffered and discounted
        ...     for i in range(100):
        ...         neu.add_delta_input('external', lambda: jnp.ones(100) * 2.0 * u.mV)
        ...         spk = neu.step_run(i, 0.0*u.pA)

    **IAF-like limit (Delta_T = 0):**

    .. code-block:: python

        >>> # Delta_T=0 disables exponential term
        >>> neu = bst.aeif_psc_delta(
        ...     100,
        ...     Delta_T=0.0*u.mV,
        ...     V_th=-55.*u.mV,
        ...     V_peak=-55.*u.mV,  # Must equal V_th when Delta_T=0
        ...     a=0.0*u.nS,        # No subthreshold adaptation
        ...     b=0.0*u.pA         # No spike-triggered adaptation
        ... )

    See Also
    --------
    aeif_psc_alpha : AdEx with alpha-function synaptic currents
    aeif_psc_exp : AdEx with exponential synaptic currents
    aeif_cond_alpha : AdEx with conductance-based synapses

    Notes
    -----
    - The default ``t_ref=0`` matches NEST and allows multiple spikes per simulation step.
    - Returned spike tensor is binary per simulation step (spike/no-spike), while internal
      adaptation dynamics follow NEST in-loop spike/reset behavior.
    - With ``Delta_T > 0``, the exponential term can cause rapid voltage growth near spike
      threshold. The adaptive RKF45 integrator automatically reduces step size to maintain
      accuracy.
    - For gradient-based learning, use surrogate functions like ``ReluGrad()``, ``SigmoidGrad()``,
      or ``SuperSpike()`` via the ``spk_fun`` parameter.

    References
    ----------
    .. [1] Brette R, Gerstner W (2005). Adaptive exponential integrate-and-fire
           model as an effective description of neuronal activity.
           Journal of Neurophysiology, 94:3637-3642.
           DOI: https://doi.org/10.1152/jn.00686.2005
    .. [2] NEST source: ``models/aeif_psc_delta.h`` and ``models/aeif_psc_delta.cpp``.
           https://github.com/nest/nest-simulator
    """

    __module__ = 'brainpy.state'

    _MIN_H = 1e-8  # ms
    _MAX_ITERS = 100000

    def __init__(
        self,
        in_size: Size,
        V_peak: ArrayLike = 0.0 * u.mV,
        V_reset: ArrayLike = -60.0 * u.mV,
        t_ref: ArrayLike = 0.0 * u.ms,
        g_L: ArrayLike = 30.0 * u.nS,
        C_m: ArrayLike = 281.0 * u.pF,
        E_L: ArrayLike = -70.6 * u.mV,
        Delta_T: ArrayLike = 2.0 * u.mV,
        tau_w: ArrayLike = 144.0 * u.ms,
        a: ArrayLike = 4.0 * u.nS,
        b: ArrayLike = 80.5 * u.pA,
        V_th: ArrayLike = -50.4 * u.mV,
        I_e: ArrayLike = 0.0 * u.pA,
        gsl_error_tol: ArrayLike = 1e-6,
        refractory_input: bool = False,
        V_initializer: Callable = braintools.init.Constant(-70.6 * u.mV),
        w_initializer: Callable = braintools.init.Constant(0.0 * u.pA),
        spk_fun: Callable = braintools.surrogate.ReluGrad(),
        spk_reset: str = 'hard',
        ref_var: bool = False,
        name: str = None,
    ):
        super().__init__(in_size, name=name, spk_fun=spk_fun, spk_reset=spk_reset)

        self.V_peak = braintools.init.param(V_peak, self.varshape)
        self.V_reset = braintools.init.param(V_reset, self.varshape)
        self.t_ref = braintools.init.param(t_ref, self.varshape)
        self.g_L = braintools.init.param(g_L, self.varshape)
        self.C_m = braintools.init.param(C_m, self.varshape)
        self.E_L = braintools.init.param(E_L, self.varshape)
        self.Delta_T = braintools.init.param(Delta_T, self.varshape)
        self.tau_w = braintools.init.param(tau_w, self.varshape)
        self.a = braintools.init.param(a, self.varshape)
        self.b = braintools.init.param(b, self.varshape)
        self.V_th = braintools.init.param(V_th, self.varshape)
        self.I_e = braintools.init.param(I_e, self.varshape)
        self.gsl_error_tol = braintools.init.param(gsl_error_tol, self.varshape)

        self.refractory_input = refractory_input
        self.V_initializer = V_initializer
        self.w_initializer = w_initializer
        self.ref_var = ref_var

        self._validate_parameters()

    @staticmethod
    def _to_numpy(x, unit):
        dftype = brainstate.environ.dftype()
        return np.asarray(u.math.asarray(x / unit), dtype=dftype)

    @staticmethod
    def _to_numpy_unitless(x):
        dftype = brainstate.environ.dftype()
        return np.asarray(u.math.asarray(x), dtype=dftype)

    @staticmethod
    def _broadcast_to_state(x_np: np.ndarray, shape):
        return np.broadcast_to(x_np, shape)

    def _validate_parameters(self):
        v_reset = self._to_numpy(self.V_reset, u.mV)
        v_peak = self._to_numpy(self.V_peak, u.mV)
        v_th = self._to_numpy(self.V_th, u.mV)
        delta_t = self._to_numpy(self.Delta_T, u.mV)

        if np.any(v_reset >= v_peak):
            raise ValueError('Ensure that V_reset < V_peak .')
        if np.any(delta_t < 0.0):
            raise ValueError('Delta_T must be positive.')
        if np.any(v_peak < v_th):
            raise ValueError('V_peak >= V_th required.')
        if np.any(self._to_numpy(self.C_m, u.pF) <= 0.0):
            raise ValueError('Ensure that C_m > 0')
        if np.any(self._to_numpy(self.t_ref, u.ms) < 0.0):
            raise ValueError('Refractory time cannot be negative.')
        if np.any(self._to_numpy(self.tau_w, u.ms) <= 0.0):
            raise ValueError('tau_w must be strictly positive.')
        if np.any(self._to_numpy_unitless(self.gsl_error_tol) <= 0.0):
            raise ValueError('The gsl_error_tol must be strictly positive.')

        # Mirror NEST overflow guard for exponential term at spike time.
        positive_dt = delta_t > 0.0
        if np.any(positive_dt):
            max_exp_arg = np.log(np.finfo(np.float64).max / 1e20)
            ratio = (v_peak - v_th) / np.where(positive_dt, delta_t, 1.0)
            if np.any(ratio[positive_dt] >= max_exp_arg):
                raise ValueError(
                    'The current combination of V_peak, V_th and Delta_T will lead to numerical overflow at spike '
                    'time; try for instance to increase Delta_T or to reduce V_peak to avoid this problem.'
                )

    def init_state(self, batch_size: int = None, **kwargs):
        r"""Initialize all state variables for the neuron population.

        Creates and initializes state variables: membrane potential ``V``, adaptation
        current ``w``, refractory buffer, spike timing, refractory counter, integration
        step size, and delayed current buffer. Optionally creates boolean refractory
        indicator if ``ref_var=True``.

        Parameters
        ----------
        batch_size : int, optional
            Batch dimension for vectorized simulation. If None, no batch dimension is added.
            State shapes become ``(*in_size, batch_size)`` if provided, otherwise ``(*in_size,)``.
        **kwargs : dict
            Additional keyword arguments (ignored, for API compatibility).

        Notes
        -----
        - ``V`` and ``w`` are initialized using ``V_initializer`` and ``w_initializer``.
        - ``refractory_spike_buffer`` starts at zero (no buffered input).
        - ``last_spike_time`` starts at ``-1e7 ms`` (far past, indicating no recent spikes).
        - ``refractory_step_count`` starts at 0 (not refractory).
        - ``integration_step`` starts at the global simulation timestep ``dt``.
        - ``I_stim`` (delayed current buffer) starts at 0 pA.
        - If ``ref_var=True``, ``refractory`` boolean array starts at ``False``.
        """
        V = braintools.init.param(self.V_initializer, self.varshape, batch_size)
        w = braintools.init.param(self.w_initializer, self.varshape, batch_size)
        zeros = u.math.zeros_like(u.math.asarray(V / u.mV))

        self.V = brainstate.HiddenState(V)
        self.w = brainstate.HiddenState(w)
        dftype = brainstate.environ.dftype()
        self.refractory_spike_buffer = brainstate.ShortTermState(np.asarray(zeros, dtype=dftype))

        spk_time = braintools.init.param(braintools.init.Constant(-1e7 * u.ms), self.varshape, batch_size)
        self.last_spike_time = brainstate.ShortTermState(spk_time)
        ref_steps = braintools.init.param(braintools.init.Constant(0), self.varshape, batch_size)
        ditype = brainstate.environ.ditype()
        self.refractory_step_count = brainstate.ShortTermState(u.math.asarray(ref_steps, dtype=ditype))

        dt = brainstate.environ.get_dt()
        self.integration_step = brainstate.ShortTermState(
            braintools.init.param(braintools.init.Constant(dt), self.varshape, batch_size)
        )
        self.I_stim = brainstate.ShortTermState(
            braintools.init.param(braintools.init.Constant(0.0 * u.pA), self.varshape, batch_size)
        )

        if self.ref_var:
            refractory = braintools.init.param(braintools.init.Constant(False), self.varshape, batch_size)
            self.refractory = brainstate.ShortTermState(refractory)

    def reset_state(self, batch_size: int = None, **kwargs):
        r"""Reset all state variables to their initial values.

        Resets membrane potential, adaptation current, refractory buffer, spike timing,
        refractory counter, integration step size, and delayed current buffer to their
        default initialized values. Useful for re-initializing simulations without
        recreating the neuron object.

        Parameters
        ----------
        batch_size : int, optional
            Batch dimension for vectorized simulation. If None, preserves current batch shape.
        **kwargs : dict
            Additional keyword arguments (ignored, for API compatibility).

        Notes
        -----
        This method is semantically equivalent to ``init_state`` but operates on existing
        state variables rather than creating new ones.
        """
        self.V.value = braintools.init.param(self.V_initializer, self.varshape, batch_size)
        self.w.value = braintools.init.param(self.w_initializer, self.varshape, batch_size)
        zeros = u.math.zeros_like(u.math.asarray(self.V.value / u.mV))
        dftype = brainstate.environ.dftype()
        self.refractory_spike_buffer.value = np.asarray(zeros, dtype=dftype)
        self.last_spike_time.value = braintools.init.param(
            braintools.init.Constant(-1e7 * u.ms), self.varshape, batch_size
        )
        ref_steps = braintools.init.param(braintools.init.Constant(0), self.varshape, batch_size)
        ditype = brainstate.environ.ditype()
        self.refractory_step_count.value = u.math.asarray(ref_steps, dtype=ditype)

        dt = brainstate.environ.get_dt()
        self.integration_step.value = braintools.init.param(
            braintools.init.Constant(dt), self.varshape, batch_size
        )
        self.I_stim.value = braintools.init.param(
            braintools.init.Constant(0.0 * u.pA), self.varshape, batch_size
        )

        if self.ref_var:
            refractory = braintools.init.param(braintools.init.Constant(False), self.varshape, batch_size)
            self.refractory.value = refractory

    def get_spike(self, V: ArrayLike = None):
        r"""Generate differentiable spike output using surrogate gradient function.

        Computes spike probability via the surrogate function ``spk_fun`` applied to
        normalized membrane potential. Used for gradient-based learning.

        Parameters
        ----------
        V : ArrayLike, optional
            Membrane potential in millivolts. If None, uses ``self.V.value``.
            Shape: ``(*in_size, *batch_shape)``.

        Returns
        -------
        spike : ArrayLike
            Differentiable spike output in range [0, 1]. Shape matches ``V``.
            Forward pass: approximately binary (0 or 1).
            Backward pass: uses surrogate gradient from ``spk_fun``.

        Notes
        -----
        The membrane potential is normalized as:

        .. math::

            v_{\mathrm{scaled}} = \frac{V - V_{\mathrm{th}}}{V_{\mathrm{th}} - V_{\mathrm{reset}}}.

        The surrogate function is then applied: ``spk_fun(v_scaled)``.
        """
        V = self.V.value if V is None else V
        v_scaled = (V - self.V_th) / (self.V_th - self.V_reset)
        return self.spk_fun(v_scaled)

    def _refractory_counts(self):
        dt = brainstate.environ.get_dt()
        ditype = brainstate.environ.ditype()
        return u.math.asarray(u.math.ceil(self.t_ref / dt), dtype=ditype)

    def _sum_delta_inputs(self):
        delta_v = u.math.zeros_like(self.V.value)
        if self.delta_inputs is None:
            return delta_v

        for key in tuple(self.delta_inputs.keys()):
            out = self.delta_inputs[key]
            if callable(out):
                out = out()
            else:
                self.delta_inputs.pop(key)
            delta_v = delta_v + out

        return delta_v

    @staticmethod
    def _dynamics_scalar(v, w, is_refractory, i_stim, p):
        v_eff = p['V_reset'] if is_refractory else min(v, p['V_peak_rhs'])

        i_spike = 0.0 if p['Delta_T'] == 0.0 else (
            p['g_L'] * p['Delta_T'] * math.exp((v_eff - p['V_th']) / p['Delta_T'])
        )
        dv = 0.0 if is_refractory else (
                                           -p['g_L'] * (v_eff - p['E_L']) + i_spike - w + p['I_e'] + i_stim
                                       ) / p['C_m']

        dw = (p['a'] * (v_eff - p['E_L']) - w) / p['tau_w']
        return dv, dw

    def update(self, x=0.0 * u.pA):
        r"""Advance neuron state by one simulation timestep using adaptive RKF45 integration.

        Integrates membrane and adaptation dynamics over interval :math:`(t, t+\Delta t]`
        using adaptive Runge-Kutta-Fehlberg 4(5) with per-neuron step size control. Handles
        delta-function input, refractory clamping, spike detection, and reset within the
        integration loop to match NEST semantics.

        Parameters
        ----------
        x : ArrayLike, optional
            External current input in picoamperes. Shape: ``(*in_size, *batch_shape)`` or
            broadcastable. Default: ``0.0 * u.pA``.

        Returns
        -------
        spike : ArrayLike
            Binary spike indicator (0 or 1) for this timestep. Shape: ``(*in_size, *batch_shape)``.
            Value is 1 if any spike occurred during the integration interval, 0 otherwise.

        Raises
        ------
        ValueError
            If membrane potential drops below -1e3 mV (numerical instability).
        ValueError
            If adaptation current magnitude exceeds 1e6 pA (numerical instability).

        Notes
        -----
        **Integration algorithm:**

        1. For each neuron, iterate RKF45 substeps until ``t_local`` reaches ``dt``.
        2. At each substep:
            a. Compute RKF45 stages k1-k6 using ``_dynamics_scalar``.
            b. Compute 4th-order (y4) and 5th-order (y5) estimates.
            c. Compute local error: ``err = max(|y5 - y4|)``.
            d. If ``err <= gsl_error_tol`` or ``h <= 1e-8 ms``, accept step:
                - Update ``y <- y5``, ``t_local += h``.
                - Apply delta input if not refractory.
                - Apply refractory buffer if exiting refractory and ``refractory_input=True``.
                - Check spike threshold; if crossed, reset V, increment w by b, set refractory.
                - Adjust step size: ``h *= min(5, max(0.2, 0.9 * (tol / err)^0.2))``.
            e. Else reject step and reduce: ``h *= min(1, max(0.2, 0.9 * (tol / err)^0.25))``.
        3. After integration loop, decrement refractory counter once.
        4. Store current input ``x`` into ``I_stim`` for next timestep (one-step delay).

        **Delta input handling:**

        Delta inputs (accumulated via ``add_delta_input``) are applied as instantaneous
        voltage jumps during the first substep where the neuron is not refractory. If
        ``refractory_input=True``, delta inputs arriving during refractory are accumulated
        with exponential discount factor :math:`\exp(-r \cdot \Delta t / \tau_m)` where
        :math:`r` is the refractory step count.

        **Refractory clamping:**

        During refractory (``refractory_step_count > 0``), the effective voltage in the
        RHS is clamped to ``V_reset`` and :math:`dV/dt = 0`. The adaptation current ``w``
        continues to evolve normally.

        **Multiple spikes per step:**

        With ``t_ref = 0``, multiple spikes can occur within one simulation step. The
        returned binary spike indicator is 1 if *any* spike occurred, but internal state
        (adaptation increments, refractory handling) reflects all spikes that occurred
        during integration.

        **Performance:**

        The implementation uses scalar iteration over ``np.ndindex(v_shape)`` to allow
        per-neuron adaptive step sizes, matching NEST's GSL integrator. This is slower
        than vectorized integration but necessary for exact NEST compatibility and
        numerical accuracy with the exponential term.
        """
        t = brainstate.environ.get('t')
        dt_q = brainstate.environ.get_dt()
        dt = float(u.math.asarray(dt_q / u.ms))

        v_shape = self.V.value.shape

        V = self._broadcast_to_state(self._to_numpy(self.V.value, u.mV), v_shape)
        w = self._broadcast_to_state(self._to_numpy(self.w.value, u.pA), v_shape)
        ditype = brainstate.environ.ditype()
        r = self._broadcast_to_state(
            np.asarray(u.math.asarray(self.refractory_step_count.value), dtype=ditype),
            v_shape,
        )
        i_stim = self._broadcast_to_state(self._to_numpy(self.I_stim.value, u.pA), v_shape)
        h_int = self._broadcast_to_state(self._to_numpy(self.integration_step.value, u.ms), v_shape)
        dftype = brainstate.environ.dftype()
        refr_buf = self._broadcast_to_state(np.asarray(self.refractory_spike_buffer.value, dtype=dftype), v_shape)

        p = {
            'V_peak_rhs': self._broadcast_to_state(self._to_numpy(self.V_peak, u.mV), v_shape),
            'V_reset': self._broadcast_to_state(self._to_numpy(self.V_reset, u.mV), v_shape),
            'E_L': self._broadcast_to_state(self._to_numpy(self.E_L, u.mV), v_shape),
            'C_m': self._broadcast_to_state(self._to_numpy(self.C_m, u.pF), v_shape),
            'g_L': self._broadcast_to_state(self._to_numpy(self.g_L, u.nS), v_shape),
            'Delta_T': self._broadcast_to_state(self._to_numpy(self.Delta_T, u.mV), v_shape),
            'tau_w': self._broadcast_to_state(self._to_numpy(self.tau_w, u.ms), v_shape),
            'a': self._broadcast_to_state(self._to_numpy(self.a, u.nS), v_shape),
            'b': self._broadcast_to_state(self._to_numpy(self.b, u.pA), v_shape),
            'V_th': self._broadcast_to_state(self._to_numpy(self.V_th, u.mV), v_shape),
            'I_e': self._broadcast_to_state(self._to_numpy(self.I_e, u.pA), v_shape),
            'atol': self._broadcast_to_state(self._to_numpy_unitless(self.gsl_error_tol), v_shape),
        }
        p['tau_m'] = np.divide(
            p['C_m'],
            p['g_L'],
            out=np.full_like(p['C_m'], np.inf, dtype=dftype),
            where=p['g_L'] != 0.0,
        )

        v_peak_detect = np.where(
            p['Delta_T'] > 0.0,
            p['V_peak_rhs'],
            p['V_th'],
        )
        refr_counts = self._broadcast_to_state(
            np.asarray(u.math.asarray(self._refractory_counts()), dtype=ditype),
            v_shape,
        )
        refr_input = np.broadcast_to(np.asarray(bool(self.refractory_input), dtype=bool), v_shape)

        delta_v_q = self._sum_delta_inputs()
        delta_v = self._broadcast_to_state(self._to_numpy(delta_v_q, u.mV), v_shape)

        new_i_stim_q = self.sum_current_inputs(x, self.V.value)
        new_i_stim = self._broadcast_to_state(self._to_numpy(new_i_stim_q, u.pA), v_shape)

        spike_mask = np.zeros(v_shape, dtype=bool)
        V_next = np.empty_like(V)
        w_next = np.empty_like(w)
        r_next = np.empty_like(r)
        h_next = np.empty_like(h_int)
        refr_buf_next = np.empty_like(refr_buf)

        for idx in np.ndindex(v_shape):
            local_p = {k: p[k][idx] for k in p}
            y = np.asarray([V[idx], w[idx]], dtype=dftype)
            r_i = int(r[idx])
            h_i = float(max(h_int[idx], self._MIN_H))
            t_local = 0.0
            iters = 0
            local_spike = False

            pending_delta = float(delta_v[idx])
            refr_buf_i = float(refr_buf[idx])
            refr_input_i = bool(refr_input[idx])

            while t_local < dt and iters < self._MAX_ITERS:
                iters += 1
                h_i = max(self._MIN_H, min(h_i, dt - t_local))
                is_refractory = r_i > 0

                def f(y_):
                    dftype = brainstate.environ.dftype()
                    return np.asarray(
                        self._dynamics_scalar(
                            y_[0], y_[1], is_refractory, i_stim[idx], local_p
                        ),
                        dtype=dftype,
                    )

                k1 = f(y)
                k2 = f(y + h_i * (1.0 / 4.0) * k1)
                k3 = f(y + h_i * (3.0 * k1 / 32.0 + 9.0 * k2 / 32.0))
                k4 = f(y + h_i * (1932.0 * k1 / 2197.0 - 7200.0 * k2 / 2197.0 + 7296.0 * k3 / 2197.0))
                k5 = f(y + h_i * (439.0 * k1 / 216.0 - 8.0 * k2 + 3680.0 * k3 / 513.0 - 845.0 * k4 / 4104.0))
                k6 = f(
                    y
                    + h_i
                    * (
                        -8.0 * k1 / 27.0
                        + 2.0 * k2
                        - 3544.0 * k3 / 2565.0
                        + 1859.0 * k4 / 4104.0
                        - 11.0 * k5 / 40.0
                    )
                )

                y4 = y + h_i * (25.0 * k1 / 216.0 + 1408.0 * k3 / 2565.0 + 2197.0 * k4 / 4104.0 - k5 / 5.0)
                y5 = y + h_i * (
                    16.0 * k1 / 135.0
                    + 6656.0 * k3 / 12825.0
                    + 28561.0 * k4 / 56430.0
                    - 9.0 * k5 / 50.0
                    + 2.0 * k6 / 55.0
                )
                err = float(np.max(np.abs(y5 - y4)))
                atol = float(local_p['atol'])

                if err <= atol or h_i <= self._MIN_H:
                    y = y5
                    t_local += h_i
                    fac = 5.0 if err == 0.0 else min(5.0, max(0.2, 0.9 * (atol / err) ** 0.2))
                    h_i = max(self._MIN_H, h_i * fac)

                    if y[0] < -1e3 or y[1] < -1e6 or y[1] > 1e6:
                        raise ValueError('Numerical instability in aeif_psc_delta dynamics.')

                    if r_i == 0:
                        y[0] += pending_delta
                        pending_delta = 0.0
                        if refr_input_i and refr_buf_i != 0.0:
                            y[0] += refr_buf_i
                            refr_buf_i = 0.0
                    else:
                        y[0] = local_p['V_reset']
                        if refr_input_i:
                            tau_m_i = float(local_p['tau_m'])
                            decay = math.exp(-r_i * dt / tau_m_i) if np.isfinite(tau_m_i) else 1.0
                            refr_buf_i += pending_delta * decay
                        pending_delta = 0.0

                    if r_i == 0 and y[0] >= v_peak_detect[idx]:
                        local_spike = True
                        y[0] = local_p['V_reset']
                        y[1] += local_p['b']
                        r_i = int(refr_counts[idx]) + 1 if int(refr_counts[idx]) > 0 else 0
                else:
                    fac = min(1.0, max(0.2, 0.9 * (atol / err) ** 0.25))
                    h_i = max(self._MIN_H, h_i * fac)

            if r_i > 0:
                r_i -= 1

            spike_mask[idx] = local_spike
            V_next[idx] = y[0]
            w_next[idx] = y[1]
            r_next[idx] = r_i
            h_next[idx] = h_i
            refr_buf_next[idx] = refr_buf_i

        self.V.value = V_next * u.mV
        self.w.value = w_next * u.pA
        self.refractory_step_count.value = jnp.asarray(r_next, dtype=ditype)
        self.refractory_spike_buffer.value = refr_buf_next
        self.integration_step.value = h_next * u.ms
        self.I_stim.value = new_i_stim * u.pA
        self.last_spike_time.value = jax.lax.stop_gradient(
            u.math.where(spike_mask, t + dt_q, self.last_spike_time.value)
        )

        if self.ref_var:
            self.refractory.value = jax.lax.stop_gradient(self.refractory_step_count.value > 0)

        return u.math.asarray(spike_mask, dtype=dftype)
