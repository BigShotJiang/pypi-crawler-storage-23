# Shared utilities module
