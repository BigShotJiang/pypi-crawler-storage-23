# Antenna patterns module
