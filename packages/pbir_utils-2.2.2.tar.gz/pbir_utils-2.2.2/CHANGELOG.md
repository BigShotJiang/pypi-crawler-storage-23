## Fixed
- **Sanitizer**: Fixed a bug where `remove_unused_measures` would incorrectly remove measures that were referenced by other measures across different entities (tables).
