"""MCP Bouncer — health-check MCP servers, quarantine broken ones, auto-restore."""

__version__ = "1.0.0"
