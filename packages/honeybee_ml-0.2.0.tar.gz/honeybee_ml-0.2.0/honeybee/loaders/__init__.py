from .Reader.mindsDBreader import manifest_to_df
from .Reader.reader import PDF
from .Slide.slide import Slide
