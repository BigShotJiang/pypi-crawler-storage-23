"""Slide loader module for WSI processing"""

from .slide import Slide, WholeSlideImageDataset

__all__ = ["Slide", "WholeSlideImageDataset"]
