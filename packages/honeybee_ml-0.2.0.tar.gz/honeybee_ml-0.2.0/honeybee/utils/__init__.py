# Import compatibility fixes first
try:
    from . import pydantic_compat
except:
    pass
