"""Ontology resolution for clinical entities."""

from .resolver import OntologyResolver

__all__ = ["OntologyResolver"]
