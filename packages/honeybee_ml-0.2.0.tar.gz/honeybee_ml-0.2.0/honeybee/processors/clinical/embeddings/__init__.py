"""Embedding engine for clinical text."""

from .engine import EmbeddingEngine

__all__ = ["EmbeddingEngine"]
