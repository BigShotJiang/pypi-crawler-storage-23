"""Document ingestion for the clinical pipeline."""

from .document_ingester import DocumentIngester

__all__ = ["DocumentIngester"]
