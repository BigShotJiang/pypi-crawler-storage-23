#!/usr/bin/env python3

import sys
from os.path import abspath, dirname
from pathlib import Path

# Allow running directly (python adytum.py) without installing the package.
# When installed via pip, src/ is already on the path and this is a no-op.
sys.path.insert(0, str(Path(__file__).parent / "src"))

from adytum.main import run  # noqa: E402

if __name__ == "__main__":
    run(program_folder=dirname(abspath(__file__)))
