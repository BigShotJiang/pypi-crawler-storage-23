# adytum

![adytum](assets/banner.png)

A minimal, encrypted command-line password manager.

Credentials are stored in an in-memory SQLite database that is encrypted with **AES-256-GCM** and a key derived via **PBKDF2-SHA256 (600 000 iterations)** before being written to disk. Nothing leaves the encrypted file unprotected.

Originally developed in 2014 as one of my early personal projects during my teenage years :), this tool has now undergone a complete modernization. The refactor brings the architecture, security model, and tooling up to 2026 standards.

---

## Why adytum?

- **Minimal, offline-first, no plugins.** A single executable, no browser extension, no cloud account, no phone pairing. Your secrets stay where you put them.
- **Explicit threat model, no magic promises.** The README states what adytum protects against *and* what it does not. Cryptography does not make a tool trustworthy by itself; honesty does.
- **Simple, auditable file format.** Each vault is `salt (32 B) + nonce (12 B) + AES-256-GCM ciphertext`. You can verify or inspect the raw bytes with any hex editor without needing adytum itself.

---

## Requirements

- Python ≥ 3.10
- [`uv`](https://docs.astral.sh/uv/) (recommended) or `pip`

---

## Installation

### As a global tool with uv (recommended)

```bash
uv tool install adytum
```

The `adytum` command becomes available system-wide.

### From source with uv

```bash
uv tool install .
```

### With pip

```bash
pip install adytum
```

### For development

```bash
uv sync
```

The `adytum` command is then available inside the project's virtual environment.

### Run without installing

```bash
python adytum.py
```

---

## Running tests

```bash
pytest
```

---

## First run

On first launch adytum runs a setup wizard. It asks where to store the vault, where to keep backups, and then prompts you to choose a master key:

```
Vault folder path (e.g. ~/Dropbox/) or [quit]
>>> ~/vaults/

Backup folder path or [quit]
>>> ~/vaults/backup/

Create a new backup if last backup is older than N days or [quit]
>>> 1

Remove backups older than N days or [quit]
>>> 30

Choose a master key - do not forget it - or [quit]
>>> ********
Confirm the password or [quit]
>>> ********
Confirm master key: ENTER to seal, N to retry or [quit]
>>>
· Vault sealed.
```

> **Keep your master key safe.** There is no recovery mechanism - losing it means losing access to your data.

The encrypted vault is saved as `adytum.ec` inside the folder you chose.

---

## Subsequent launches

On every subsequent launch adytum decrypts the vault and drops you into the interactive prompt:

```
· Vault: /home/user/vaults/adytum.ec
ENTER to unseal, or type a new vault name or [quit]
>>>
adytum>
```

Pressing **Enter** opens the displayed vault. Typing a name creates (or opens) a vault with that name in the same folder - adytum appends `.ec` automatically if omitted and prints the full path before proceeding:

```
· Vault will be created at /home/user/vaults/work.ec
```

Type `h` or `help` at any point to see the full command reference.

---

## Command reference

Commands and their aliases are separated by spaces below. All input is case-sensitive for values but **commands are not** (they are matched literally, in lower-case).

### General

| Command | Aliases | Description |
|---------|---------|-------------|
| `h` | `help` | Show the command reference. |
| `q` | `exit` `quit` | Exit the program. |
| `cls` | `clear` `clearscreen` | Clear the screen. |
| `d` | `date` | Show the current date and time. |
| `ver` | `version` | Show the program version. |

---

### Listing entries - `ls`

```
ls
```
List all entries ordered by ID.

```
ls <id_start> <id_end>
```
List entries whose ID falls in the given range.

```
ls <id> [output_field]
```
List a single entry by ID. `output_field` is a column index (1-based) to highlight or copy.

#### Filter by field (SQLite LIKE syntax)

```
ls name     %gmail%
ls email    %@gmail.com%
ls usr      %admin%
ls pass     %hunter2%
ls project  %work%
ls web      %github%
ls comment  %todo%
```

Use `%` as a wildcard (standard SQLite `LIKE` operator).

#### Filter by date

```
ls date <dd/mm/yyyy>              # by creation date
ls date set <dd/mm/yyyy>          # by last-modification date
```

Dates can use `/`, `-`, `:`, or `.` as separators.

---

### Adding an entry - `mk`

Aliases: `make`, `create`

```
mk
```

Opens an interactive form that walks you through every field:

- **Name** - a human-readable label (e.g. `GitHub`)
- **Email** - the email address used for this entry
- **Username** - the login username
- **Password** - the account password
- **Project** - a group or project this entry belongs to
- **Web** - the URL or hostname of the service
- **Comments** - any extra notes

These fields cover the typical anatomy of a web credential: **Name** and **Web** identify *where* the entry lives; **Email** and **Username** cover the two most common login identifiers; **Password** is the secret itself; **Project** lets you group related entries (e.g. all credentials for a client or a side-project); and **Comments** is a catch-all for anything that doesn't fit the other fields.

At the end you are shown a summary and asked to confirm. Type `N` to re-enter the values or press **Enter** to seal the entry.

> To abort any form mid-way, type `exit_form`.

---

### Amending an entry - `set`

```
set <id>
```
Update all fields of entry `<id>` interactively.

Update a single field:

```
set <id> name
set <id> email
set <id> usr            # username
set <id> pass           # password
set <id> project
set <id> web
set <id> comment
set <id> date           # creation date
set <id> date set       # last-modification date
```

---

### Purging an entry - `rm`

Aliases: `remove`

```
rm <id>
```

Displays the entry and asks for confirmation before deleting it permanently.

---

### Password generator - `pass`

```
pass
```

Generates a cryptographically random password (default length 20). Guarantees at least one lowercase letter, uppercase letter, digit, and special character.

```
pass 32
```

Generate a password of the given length (minimum 4).

---

### Backup - `bk`

Aliases: `bkp`, `backup`

```
bk
```

Creates a timestamped copy of the current vault file inside the backup folder.

---

### Connect to a different vault - `conn`

Aliases: `connect`

```
conn
```

Prompts for a path to an `.ec` vault file and switches to it without restarting.

---

### Display toggles - `tgl`

Aliases: `toggle`

```
tgl hr      # toggle showing hours in date columns
tgl fy      # toggle showing full 4-digit year vs. 2-digit
tgl pv      # toggle password visibility in listings
```

---

## Forms - common input rules

| Input | Effect |
|-------|--------|
| `q`, `exit`, `quit` | Exit the program immediately. |
| `exit_form` | Leave the current form and return to the prompt. |
| **Enter** (empty) | Confirm / accept a value or proceed. |
| `N` | Reject / re-enter the current form values. |

---

## Vault files

Vaults are stored as `.ec` files (encrypted container) in the folder you chose during setup. The file format is:

```
[ 32-byte random salt ][ 12-byte nonce ][ AES-256-GCM ciphertext + 16-byte auth tag ]
```

The salt is not secret - it is stored in plain bytes at the start of the file. The actual data is only accessible with the correct master key.

Writes are **crash-safe**: the new file is first written to a temporary path (`<name>.ec.tmp`) and then renamed over the original via `os.replace()`. Because a rename on the same filesystem is atomic at the OS level, the vault file is never left in a partially-written state - a crash or interruption mid-write leaves the previous file intact.

---

## Configuration file

adytum stores its settings in a plain JSON file at:

```
~/.config/adytum/config.json
```

If the `XDG_CONFIG_HOME` environment variable is set, that directory is used instead of `~/.config`.

The file is created automatically on first run. It is updated when you switch to a different vault - either by typing a name at the startup prompt or via the `conn` command. It contains the following keys:

| Key | Description |
|-----|-------------|
| `last_vault` | Absolute path to the most recently used vault file. Loaded automatically on the next launch. |
| `backup_dir` | Absolute path to the backup folder. |
| `backup_frequency_days` | A backup is created automatically on startup if the most recent backup is older than this many days. |
| `backup_max_age_days` | Backup files older than this many days are deleted automatically on startup. |

Example:

```json
{
  "last_vault": "/home/user/vaults/adytum.ec",
  "backup_dir": "/home/user/vaults/backup",
  "backup_frequency_days": 1,
  "backup_max_age_days": 30
}
```

You can edit this file by hand if you need to point adytum at a different vault or change the backup thresholds without going through the setup wizard again.

---

## Security

| Property | Detail |
|----------|--------|
| Encryption | AES-256-GCM (authenticated encryption) |
| Key derivation | PBKDF2-SHA256, 600 000 iterations (OWASP 2024) |
| Salt | 32 random bytes, unique per vault, stored in plaintext |
| Nonce | 12 random bytes (96-bit), prepended to ciphertext |
| Serialization | JSON |
| Crash safety | Atomic write (temp file + `os.replace`) |

The master key is never stored anywhere. adytum derives the encryption key from the password + salt at startup and keeps the decrypted vault **only in memory** for the duration of the session.

### Threat model

**adytum protects against:**
- A stolen or lost device where an attacker has access to the filesystem.
- Exposure of backup files or cloud-synced storage.
- Offline brute-force attacks against the encrypted vault file.

**adytum does NOT protect against:**
- Malware or a compromised operating system on the host machine.
- Keyloggers capturing the master password at entry time.
- Memory-scraping attacks during an active session (the decrypted vault lives in RAM).
- Shoulder surfing.

### Limitations

adytum is a **personal and educational project**. It has not been audited by a third party and is not intended for enterprise, compliance, or high-assurance environments. Use it at your own risk. No warranty is provided.

### FIPS 140-2/3 compatibility

All algorithms used (AES-256-GCM, PBKDF2-SHA256) are NIST/FIPS-approved. However, formal FIPS 140-2/3 compliance also requires the underlying cryptographic **module** to be validated - the Python `cryptography` library and `hashlib` both delegate to OpenSSL. If you need FIPS compliance, run adytum on a system where OpenSSL is configured in FIPS mode (e.g. a FIPS-enabled RHEL/CentOS kernel). No code changes are required; the algorithm choices are already correct.

### Security FAQ

**Can I trust adytum with my passwords?**
adytum uses well-established cryptography (AES-256-GCM + PBKDF2-SHA256) and has a documented threat model. It has *not* been independently audited. Use it the way you would use any personal open-source tool: read the code, understand the limits, and decide for yourself.

**What happens if I forget my master key?**
There is no recovery mechanism - the key is never stored or transmitted anywhere. If you lose it, the data inside the vault is unrecoverable.

**Is my vault safe in Dropbox / Google Drive / iCloud?**
The vault file is fully encrypted before it touches the disk, so cloud storage only ever sees ciphertext. Keep in mind that metadata - file name, size, and modification timestamps - remains visible to the cloud provider.

**Why not just use Bitwarden / KeePassXC / 1Password?**
adytum is primarily a personal and educational project. For a production-grade password manager - especially in a team or compliance context - use an audited, maintained tool instead.
