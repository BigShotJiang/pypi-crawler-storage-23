#!/usr/bin/env python3


def index_is_in_list(ls: list | tuple, index: int) -> bool:
    return (0 <= index < len(ls)) or (-len(ls) <= index < 0)


def parse_range(token_list: list, arg_pos: int = 0):
    error_text = ("Syntax: [commands] + range + before + after. "
                  "i.e: ls r 0 1 / :2 / :2: / 2:")

    before = token_list[arg_pos] if index_is_in_list(
        token_list, arg_pos) else None
    after = token_list[arg_pos + 1] if index_is_in_list(
        token_list, arg_pos + 1) else None

    if before is None:
        print(error_text)
        return before, after

    if before.startswith(":") and before.endswith(":"):
        before = before[1:-1]
        after = before
        if not before:
            print(error_text)
        return before, after

    if before.endswith(":"):
        return before[:-1], after

    if before.startswith(":"):
        return None, before[1:]

    return before, after


def parse_quotations(text: str, token_list: list, arg_pos: int = 0):
    tokens = token_list[arg_pos:]

    if len(tokens) > 0:
        if tokens[0] and tokens[0][0] == '"':
            quotations_pos = [
                char_idx for char_idx, ch in enumerate(text) if ch == '"'
                ]
            if len(quotations_pos) >= 2:
                return text[quotations_pos[0] + 1: quotations_pos[-1]]
            return ""
        else:
            return tokens[0]
    return ""


def parse_output_field(token_list, idx: int = 3):
    output_field = None
    if len(token_list) > idx:
        try:
            idx_val = token_list[idx]

            if idx_val == ".":
                # "." is a shorthand for the Comment field (column index 9).
                idx_val = "9"

            output_field = int(idx_val)
        except (ValueError, IndexError):
            pass
    return output_field
