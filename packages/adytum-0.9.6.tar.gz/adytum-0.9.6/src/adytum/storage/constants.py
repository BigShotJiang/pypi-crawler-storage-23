#!/usr/bin/env python3

PBKDF2_ITERATIONS = 600_000  # OWASP 2024 recommendation
SALT_SIZE = 32
NONCE_SIZE = 12  # 96-bit nonce, standard for AES-GCM
