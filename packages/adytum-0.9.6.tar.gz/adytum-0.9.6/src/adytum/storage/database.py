#!/usr/bin/env python3

import json
import os
import sqlite3

from adytum.storage.constants import SALT_SIZE


class Database:
    """
    Encrypted database controller.

    File format: [ salt (32 bytes, plaintext) ][ nonce (12 bytes) ][ AESGCM ciphertext + tag ]

    The salt is not secret — it exists solely to make PBKDF2 brute-force
    attacks impractical. A fresh salt is generated on every write.
    """

    def set_encryption_motor(self, encryption_motor):
        self._encryption_motor = encryption_motor

    def read_file_to_imdb(self, encrypted_db_filepath):
        # 1 - Read file.
        with open(encrypted_db_filepath, "rb") as f:
            data = f.read()
        # 2 - Split salt and ciphertext.
        salt = data[:SALT_SIZE]
        ciphertext = data[SALT_SIZE:]
        # 3 - Derive key from password + salt, then decrypt.
        self._encryption_motor.set_salt(salt)
        serialized_db = self._encryption_motor.decrypt(ciphertext)
        # 4 - Deserialize (JSON list of SQL statements — no pickle).
        sql_dump = json.loads(serialized_db.decode("utf-8"))
        # 5 - Rebuild in-memory SQLite database.
        imdb_con = sqlite3.connect(":memory:")
        cur = imdb_con.cursor()
        for line in sql_dump:
            cur.execute(line)
        return imdb_con

    def write_file_from_imdb(self, imdb_con, encrypted_db_filepath):
        # 1 - SQL dump.
        sql_dump = list(imdb_con.iterdump())
        # 2 - Serialize as JSON (no pickle).
        serialized_db = json.dumps(sql_dump).encode("utf-8")
        # 3 - Generate a fresh salt and derive key.
        salt = os.urandom(SALT_SIZE)
        self._encryption_motor.set_salt(salt)
        # 4 - Encrypt.
        encrypted_db = self._encryption_motor.encrypt(serialized_db)
        # 5 - Write to a temp file, then atomically replace.
        #     This prevents database corruption if the process is interrupted.
        tmp_path = encrypted_db_filepath + ".tmp"
        try:
            with open(tmp_path, "wb") as f:
                f.write(salt + encrypted_db)
            os.replace(tmp_path, encrypted_db_filepath)
        except Exception:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise
