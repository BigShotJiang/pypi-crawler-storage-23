#!/usr/bin/env python3

import hashlib
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from adytum.storage.constants import PBKDF2_ITERATIONS, NONCE_SIZE


def str_to_bytes(data):
    if isinstance(data, str):
        return data.encode()
    return data


def derive_key(password: bytes, salt: bytes) -> bytes:
    """Derive a 32-byte AES-GCM key from password and salt using PBKDF2-SHA256."""
    return hashlib.pbkdf2_hmac("sha256", password, salt, PBKDF2_ITERATIONS)


class Cipher:
    """
    AES-256-GCM encryption with PBKDF2-SHA256 key derivation.

    Usage:
        cipher = Cipher(password)
        cipher.set_salt(salt)   # call before encrypt/decrypt
        ciphertext = cipher.encrypt(data)   # nonce prepended
        plaintext  = cipher.decrypt(ciphertext)

    The salt is stored alongside the ciphertext (not secret).
    Database handles generating/reading the salt from the file.
    """

    def __init__(self, password: str):
        self._password = str_to_bytes(password)
        self._aesgcm = None

    def set_salt(self, salt: bytes):
        """Derive the AES-GCM key from the stored password and the given salt."""
        key = derive_key(self._password, salt)
        self._aesgcm = AESGCM(key)

    def encrypt(self, raw) -> bytes:
        if self._aesgcm is None:
            raise RuntimeError("call set_salt() before encrypt()")
        nonce = os.urandom(NONCE_SIZE)
        return nonce + self._aesgcm.encrypt(nonce, str_to_bytes(raw), None)

    def decrypt(self, enc) -> bytes:
        if self._aesgcm is None:
            raise RuntimeError("call set_salt() before decrypt()")
        enc = str_to_bytes(enc)
        nonce, ciphertext = enc[:NONCE_SIZE], enc[NONCE_SIZE:]
        return self._aesgcm.decrypt(nonce, ciphertext, None)
