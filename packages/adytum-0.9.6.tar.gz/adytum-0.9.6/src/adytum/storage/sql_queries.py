#!/usr/bin/env python3

import os
import sqlite3
from os.path import exists
from shutil import copyfile

import structlog
from pendulum import now

from adytum.storage.cipher import Cipher
from adytum.storage.database import Database
from adytum.helpers import enter_password_or_quit
from adytum.style import green, dim, red

log = structlog.get_logger()

_ALLOWED_TABLES = frozenset({"Accounts"})
_ALLOWED_COLUMNS = frozenset({
    "Id", "Name", "Email", "Username", "Password",
    "Project", "Web", "Creation_timestamp",
    "Last_modification_timestamp", "Comments",
})


def _validate_identifiers(table: str, *columns: str) -> None:
    """Guard against unexpected table/column names in dynamic SQL."""
    if table not in _ALLOWED_TABLES:
        raise ValueError(f"Table '{table}' is not in the allowed list.")
    for col in columns:
        if col not in _ALLOWED_COLUMNS:
            raise ValueError(f"Column '{col}' is not in the allowed list.")


class QueriesManager:
    def __init__(self, encryption=True):
        self._encryption = encryption
        self.show_db_password = False
        if self._encryption:
            log.info("encryption_enabled")
            self._db_motor = Database()

    # --- Connection lifecycle:

    def set_database_path(self, path: str):
        """Set the full database file path."""
        self.database_url = os.path.expanduser(path)

    def set_backup_dir(self, path: str):
        """Set the directory where backups will be stored."""
        self.backup_dir = os.path.expanduser(path)

    def set_encryption_motor(self, key):
        """Creates the encryption motor."""
        self.classical_cipher = Cipher(key)
        self._db_motor.set_encryption_motor(self.classical_cipher)

    def valid_password(self):
        """Validates the database password."""
        try:
            self.connect()
            self.cur.execute("SELECT 1")
            self.close_connection()
        except Exception as e:
            log.warning("password_check_failed", error=str(e))
            return False
        return True

    def connect(self):
        """Decrypts the DB and connects to it."""
        if self._encryption:
            if exists(self.database_url):
                self.conn = self._db_motor.read_file_to_imdb(
                    encrypted_db_filepath=self.database_url
                    )
            else:
                self.conn = sqlite3.connect(":memory:")
        else:
            self.conn = sqlite3.connect(self.database_url)
        self.cur = self.conn.cursor()

    def close_connection(self):
        """Closes the connection with the database and encrypts it."""
        self.conn.commit()
        self.cur.close()
        if self._encryption:
            self._db_motor.write_file_from_imdb(
                imdb_con=self.conn,
                encrypted_db_filepath=self.database_url
                )

    def execute_query(self, query, parameters=None):
        """Decrypts the database, runs a query, and re-encrypts it."""
        try:
            self.connect()
        except Exception:
            log.error("db_connection_failed", exc_info=True)
            return []
        dataset = []
        try:
            if parameters is not None:
                self.cur.execute(query, parameters)
            else:
                self.cur.execute(query)
            dataset = self.cur.fetchall()
        finally:
            self.close_connection()
        return dataset

    def backup_database(self):
        """Copies the database file to the backup directory with a timestamp suffix."""
        time_string = (
            now().to_datetime_string()
            .replace(" ", "_")
            .replace(":", "-")
        )
        src = self.database_url
        backup_dir = getattr(self, "backup_dir", None) or os.path.dirname(src) or "."
        os.makedirs(backup_dir, exist_ok=True)
        name, ext = os.path.splitext(os.path.basename(src))
        dst = os.path.join(backup_dir, f"{name}-backup-{time_string}{ext}")
        print(dim("· Copying"))
        print(f"Source: {src}")
        print(f"Dest: {dst}")
        copyfile(src, dst)
        print(green("· Backup ready"))

    def connect_to_database(self, path, key: str | None = None):
        """Connects to the desired database."""
        path = os.path.expanduser(path)
        if exists(path):
            self.database_url = path
            if self._encryption:
                if key is None:
                    key = enter_password_or_quit(
                            "Input the key for this database "
                            "or [quit]\n>>> ",
                            show=self.show_db_password
                        )
                    self.set_encryption_motor(key)

                valid = self.valid_password()
                while not valid:
                    print(red("--- INVALID PASSWORD ---"))
                    key = enter_password_or_quit(
                            "Input the key for this database "
                            "or [quit]\n>>> ",
                            show=self.show_db_password
                        )
                    self.set_encryption_motor(key)
                    valid = self.valid_password()
            print(green("· Database connected."))
        else:
            print(red("--- The provided path doesn't exist. ---"))

    # ########## #
    #   CREATE   #
    # ########## #
    def create_database(self):
        """Creates the table structure of the database."""
        self.connect()
        self.cur.executescript(
            """
            CREATE TABLE Accounts(
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Name VARCHAR(250) NOT NULL,
                Email VARCHAR(250) NOT NULL,
                Username VARCHAR(250) NOT NULL,
                Password VARCHAR(1000) NOT NULL,
                Project VARCHAR(250) NOT NULL,
                Web VARCHAR(1000) NOT NULL,
                Creation_timestamp INT NOT NULL,
                Last_modification_timestamp INT NOT NULL,
                Comments TEXT);
            """
            )
        self.close_connection()

    def add_account(
            self,
            name,
            email,
            username,
            password,
            project,
            web,
            creation_timestamp,
            last_modification_timestamp,
            comments
                ):
        query = (
            "INSERT INTO Accounts(Name, Email, Username, "
            "Password, Project, Web, Creation_timestamp, "
            "Last_modification_timestamp, Comments) VALUES ("
            ":Name, :Email, :Username, :Password, :Project, "
            ":Web, :Creation_timestamp, "
            ":Last_modification_timestamp, :Comments)"
        )
        parameters = {
                "Name": name,
                "Email": email,
                "Username": username,
                "Password": password,
                "Project": project,
                "Web": web,
                "Creation_timestamp": creation_timestamp,
                "Last_modification_timestamp": last_modification_timestamp,
                "Comments": comments
            }
        self.execute_query(query, parameters)

    # ######## #
    #   READ   #
    # ######## #
    def list_element(self, table, column, before=None, after=None):
        """Lists elements supporting range queries with BETWEEN."""
        _validate_identifiers(table, column)
        if before is None and after is None:
            return self.execute_query(f"SELECT * FROM {table}")

        if before is None:
            before = 0

        # COALESCE lets SQLite resolve the upper bound inline when after=None,
        # avoiding a second decrypt+PBKDF2 round just to fetch MAX.
        query = (
            f"SELECT * FROM {table} WHERE {column} "
            f"BETWEEN ? AND COALESCE(?, (SELECT MAX({column}) FROM {table}))"
        )
        return self.execute_query(query, (before, after))

    def check_max_in_table(self, column, table):
        """Checks the max value of a column in the desired table."""
        _validate_identifiers(table, column)
        query = f"SELECT MAX({column}) FROM {table}"
        return self.execute_query(query)[0][0]

    def check_if_id_exists_in_table(self, table, the_id):
        """Checks if a holder Id exists."""
        _validate_identifiers(table)
        query = f"SELECT * FROM {table} WHERE Id=:the_id"
        parameters = {"the_id": the_id}
        dataset = self.execute_query(query, parameters)
        return bool(dataset)

    def list_element_like(self, table, column, text):
        """Lists elements using LIKE."""
        _validate_identifiers(table, column)
        query = f"SELECT * FROM {table} WHERE {column} LIKE ?"
        return self.execute_query(query, (text,))

    # ########## #
    #   UPDATE   #
    # ########## #
    def set_element(
        self,
        table,
        database_field,
        value,
        where_field,
        account_id
            ):
        _validate_identifiers(table, database_field, where_field)
        query = f"UPDATE {table} SET {database_field} = ? WHERE {where_field} = ?"
        self.execute_query(query, (value, account_id))

    def update_all(
        self,
        name,
        email,
        username,
        password,
        project,
        web,
        creation_timestamp,
        last_modification_timestamp,
        comments,
        account_id
            ):
        query = (
            "UPDATE Accounts SET Name=:Name, Email=:Email, "
            "Username=:Username, Password=:Password, Project=:Project, "
            "Web=:Web, Creation_timestamp=:Creation_timestamp, "
            "Last_modification_timestamp=:Last_modification_timestamp, "
            "Comments=:Comments WHERE Id=:Id"
        )
        parameters = {
            "Name": name,
            "Email": email,
            "Username": username,
            "Password": password,
            "Project": project,
            "Web": web,
            "Creation_timestamp": creation_timestamp,
            "Last_modification_timestamp": last_modification_timestamp,
            "Comments": comments,
            "Id": account_id,
        }
        self.execute_query(query, parameters)

    # ########## #
    #   DELETE   #
    # ########## #
    def remove_account(self, account_id):
        query = "DELETE FROM Accounts WHERE Id=:account_id"
        parameters = {"account_id": account_id}
        self.execute_query(query, parameters)
