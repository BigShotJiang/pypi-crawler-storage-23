#!/usr/bin/env python3

from adytum.storage.sql_queries import QueriesManager

__all__ = ["QueriesManager"]
