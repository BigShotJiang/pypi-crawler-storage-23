#!/usr/bin/env python3

from adytum.cli_parsing import parse_output_field
from adytum.cli_parsing import parse_quotations
from adytum.cli_parsing import parse_range

from adytum.cli_prompt import run_prompt
from adytum.helpers import generate_random_string
from adytum.splash import print_splash
from adytum.style import gold, red, dim
from adytum.version import __version__
from vtclear import clear_screen

import sys

import structlog
from pendulum import now

log = structlog.get_logger()


class Interpreter:
    def __init__(self, forms, program_name):
        self._define_commands()
        self.m_invalid_command = red("--- UNKNOWN COMMAND ---")
        self.forms = forms
        self.program_name = program_name
        self._dispatch = self._build_dispatch()
        self._list_dispatch = self._build_list_dispatch()
        self._set_dispatch = self._build_set_dispatch()

    def program_exit(self, previous_actions=None):
        if previous_actions:
            previous_actions()
        sys.exit()

    def cli_help(self):
        print(gold("--- CLI Section ---"))
        for cmd_list, desc in [
            (self.c_clear,   "Clear the screen."),
            (self.c_date,    "Date."),
            (self.c_help,    "Show this help."),
            (self.c_quit,    "Exit the program."),
            (self.c_version, "Show the program version and other details."),
        ]:
            print(f" {' '.join(cmd_list)} : {desc}")

    def standard_commands(
        self,
        text,
        token_list,
        program_name,
        program_version,
        previous_actions=None
            ):
        if text == "" or token_list == []:
            return True
        if token_list[0] in self.c_version:
            print(f"adytum v{program_version}")
            return True
        elif token_list[0] in self.c_help:
            self.cli_help()
            print(f"--- {program_name.capitalize()} Section ---")
            self.program_help()
            return True
        elif token_list[0] in self.c_quit:
            self.program_exit(previous_actions=previous_actions)
            return True
        elif token_list[0] in self.c_clear:
            clear_screen()
            return True
        elif token_list[0] in self.c_date:
            print(f"{now().tzinfo.name}: {now().to_datetime_string()}")
            return True
        else:
            return False

    def _define_commands(self):
        # --- CLI --- #
        self.c_clear = ["cls", "clear", "clearscreen"]
        self.c_date = ["d", "date"]
        self.c_help = ["h", "help"]
        self.c_quit = ["q", "exit", "quit"]
        self.c_version = ["ver", "version"]
        # --- COMMON --- #
        self.c_comment = ["c", "comment"]
        self.c_list = ["ls", "list"]
        self.c_make = ["mk", "make", "create"]
        self.c_remove = ["rm", "remove"]
        self.c_set = ["set"]
        # --- THIS PROGRAM --- #
        self.c_backup = ["bk", "bkp", "backup"]
        self.c_connect = ["conn", "connect"]
        self.c_email = ["mail", "email"]
        self.c_fullyear = ["fy", "fullyear"]
        self.c_hour = ["hr", "hour"]
        self.c_name = ["name"]
        self.c_pass = ["pass", "password"]
        self.c_project = ["p", "project"]
        self.c_pwvis = ["pv", "pwvis"]
        self.c_toggle = ["tgl", "toggle"]
        self.c_username = ["usr", "user", "username"]
        self.c_web = ["web"]
        self.command_list = [
            self.c_clear, self.c_date, self.c_help, self.c_quit,
            self.c_version, self.c_comment, self.c_list, self.c_make,
            self.c_remove, self.c_set, self.c_backup, self.c_connect,
            self.c_email, self.c_fullyear, self.c_hour, self.c_name,
            self.c_pass, self.c_project, self.c_pwvis, self.c_toggle,
            self.c_username, self.c_web,
        ]

    def _build_dispatch(self):
        dispatch = {}
        for cmd in self.c_pass:
            dispatch[cmd] = self._cmd_pass
        for cmd in self.c_list:
            dispatch[cmd] = self._cmd_list
        for cmd in self.c_remove:
            dispatch[cmd] = self._cmd_remove
        for cmd in self.c_make:
            dispatch[cmd] = self._cmd_make
        for cmd in self.c_set:
            dispatch[cmd] = self._cmd_set
        for cmd in self.c_toggle:
            dispatch[cmd] = self._cmd_toggle
        for cmd in self.c_backup:
            dispatch[cmd] = self._cmd_backup
        for cmd in self.c_connect:
            dispatch[cmd] = self._cmd_connect
        return dispatch

    def _build_list_dispatch(self):
        """Build the dispatch table for 'ls' sub-commands."""
        entries = [
            (self.c_name,     "name",     self.forms.list_accounts_by_name,     True),
            (self.c_email,    "email",    self.forms.list_accounts_by_email,    True),
            (self.c_username, "username", self.forms.list_accounts_by_username, True),
            (self.c_pass,     "pass",     self.forms.list_accounts_by_pass,     False),
            (self.c_project,  "project",  self.forms.list_accounts_by_project,  True),
            (self.c_web,      "web",      self.forms.list_accounts_by_web,      True),
            (self.c_comment,  "comment",  self.forms.list_accounts_by_comment,  False),
        ]
        lookup = {}
        for cmd_list, name, fn, has_output in entries:
            for cmd in cmd_list:
                lookup[cmd] = (name, fn, has_output)
        return lookup

    def _build_set_dispatch(self):
        """Build the dispatch table for 'set' sub-commands."""
        entries = [
            (self.c_name,     self.forms.set_name),
            (self.c_email,    self.forms.set_email),
            (self.c_username, self.forms.set_username),
            (self.c_pass,     self.forms.set_pass),
            (self.c_project,  self.forms.set_project),
            (self.c_web,      self.forms.set_web),
            (self.c_comment,  self.forms.set_comment),
        ]
        lookup = {}
        for cmd_list, fn in entries:
            for cmd in cmd_list:
                lookup[cmd] = fn
        return lookup

    def start(self):
        """It starts the program in CLI-mode."""
        clear_screen()
        print_splash()
        flat_commands = [cmd for group in self.command_list for cmd in group]
        run_prompt(
            command_processing_function=self.command_process,
            command_list=flat_commands,
        )

    # ################### #
    #   COMMAND PROCESS   #
    # ################### #
    def command_process(self, text):
        """It process the commands."""
        token_list = text.split()

        if not token_list:
            return

        if self.standard_commands(
            text=text,
            token_list=token_list,
            program_name=self.program_name,
            program_version=__version__,
                ):
            return

        handler = self._dispatch.get(token_list[0])
        if handler:
            try:
                handler(text, token_list)
            except Exception as e:
                log.error(
                    "command_error", command=token_list[0], exc_info=True)
                print(red(f"--- ERROR: {e} ---"))
        else:
            print(self.m_invalid_command)

    # ##################### #
    #   COMMAND HANDLERS    #
    # ##################### #
    def _cmd_pass(self, text, token_list):
        length = 20
        if len(token_list) > 1:
            try:
                length = int(token_list[1])
            except ValueError:
                print("Syntax: pass [length]  (default 20, minimum 4)")
                return
        try:
            print(generate_random_string(length))
        except ValueError as e:
            print(f"--- {e} ---")

    def _cmd_list(self, text, token_list):
        if len(token_list) == 1:
            self.forms.list_accounts_by_id()
            return

        sub = token_list[1]

        if sub in self.c_date:
            self._cmd_list_date(token_list)
            return

        if sub in self._list_dispatch:
            field_name, fn, has_output = self._list_dispatch[sub]
            if len(token_list) > 2:
                parsed_text = parse_quotations(text, token_list, 2)
                if has_output:
                    fn(
                        text=parsed_text,
                        output_field=parse_output_field(token_list)
                    )
                else:
                    fn(text=parsed_text)
            else:
                print(f"Syntax: ls {field_name} %{field_name}% (sqlite syntax).")
            return

        before, after = parse_range(token_list, 1)
        # Colon-style range ("5:", ":5", ":5:") is one token -> output_field at idx 2.
        # Two bare numbers ("2 10") are two tokens -> output_field at idx 3.
        first_range_token = token_list[1] if len(token_list) > 1 else ""
        output_idx = 2 if ":" in first_range_token else 3
        output_field = parse_output_field(
            token_list=token_list,
            idx=output_idx
        )
        self.forms.list_accounts_by_id(
            before=before,
            after=after,
            output_field=output_field
        )

    def _cmd_list_date(self, token_list):
        if len(token_list) > 2:
            if token_list[2] in self.c_set:
                before, after = parse_range(token_list, 3)
                self.forms.list_accounts_by_modification_date(
                    before=before,
                    after=after
                )
            else:
                before, after = parse_range(token_list, 2)
                self.forms.list_accounts_by_creation_date(
                    before=before,
                    after=after
                )
        else:
            print("Syntax: ls date + (set) + %date% (d/m/a).")

    def _cmd_remove(self, text, token_list):
        if len(token_list) > 1:
            number = token_list[1]
            if number.isdigit():
                self.forms.remove_account(number)
            else:
                print("The Id parameter must be a number.")
        else:
            print("rm + (Id).")

    def _cmd_make(self, text, token_list):
        self.forms.add_account()

    def _cmd_set(self, text, token_list):
        if len(token_list) < 2:
            print(
                "Syntax: set + (Id) + [ name, date + (set), "
                "email, username, pass, project, web, comment ]"
                )
            return

        account_id = token_list[1]
        if account_id.startswith(":") and account_id.endswith(":"):
            account_id = account_id[1:-1]

        if len(token_list) < 3 or not account_id.isdigit():
            self.forms.update_all(account_id)
            return

        sub = token_list[2]

        # date is special: "set id date" -> creation date,
        #                  "set id date set" -> modification date.
        if sub in self.c_date:
            if len(token_list) > 3 and token_list[3] in self.c_set:
                self.forms.set_modification_date(account_id)
            else:
                self.forms.set_creation_date(account_id)
            return

        fn = self._set_dispatch.get(sub)
        if fn:
            fn(account_id)
        else:
            print(
                "Syntax: set + (Id) + [ name, date + (set), "
                "email, username, pass, project, web, comment ]"
                )

    def _cmd_toggle(self, text, token_list):
        if len(token_list) > 1:
            if token_list[1] in self.c_hour:
                self.forms.toggle_show_hours()
            elif token_list[1] in self.c_fullyear:
                self.forms.toggle_show_full_year()
            elif token_list[1] in self.c_pwvis:
                self.forms.toggle_password_visibility()
        else:
            print("Syntax: tgl hr / fy / pv")

    def _cmd_backup(self, text, token_list):
        self.forms.backup_database()

    def _cmd_connect(self, text, token_list):
        self.forms.connect_to_database()

    def program_help(self):
        sections = [
            ("COMMON COMMANDS", [
                (self.c_comment,  "Comment object (i.e: ls c / mk c)"),
                (self.c_list,     "List function (i.e: ls / ls c + [LIKE])"),
                (self.c_make,     "Make function, to create things. (i.e: mk c)"),
                (self.c_remove,   "Remove function, to remove things. (i.e: rm c)"),
                (self.c_set,      "Set function, to set new values (i.e: set c + [Id])"),
            ]),
            ("THIS PROGRAM", [
                (self.c_backup,   "Backup the program database."),
                (self.c_email,    "Email object (i.e: ls email + [LIKE])"),
                (self.c_fullyear, "Fullyear parameter (i.e: tgl fy)"),
                (self.c_hour,     "Hour parameter (i.e: tgl hour)"),
                (self.c_pwvis,    "Password visibility (i.e: tgl pv)"),
                (self.c_name,     "Name parameter (i.e: ls name + [LIKE])"),
                (self.c_pass,     "Generate a random password (i.e: pass / pass 32)."),
                (self.c_project,  "Project object (i.e: ls project + [LIKE])"),
                (self.c_toggle,   "Toggle values (i.e: tgl fy / tgl hour)"),
                (self.c_username, "Username object (i.e: ls user + [LIKE])"),
                (self.c_web,      "Webpage object (i.e: ls web + [LIKE])"),
            ]),
        ]
        for section_name, cmds in sections:
            print(dim(f" · {section_name} ·"))
            for cmd_list, desc in cmds:
                print(f" {' '.join(cmd_list)} : {desc}")
