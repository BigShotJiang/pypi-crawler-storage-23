#!/usr/bin/env python3

from prompt_toolkit import PromptSession

from prompt_toolkit.completion import Completer
from prompt_toolkit.completion import Completion
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.completion import merge_completers

from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.history import InMemoryHistory


class _HistoryCompleter(Completer):
    def __init__(self, history):
        self._history = history

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor
        if not text:
            return
        seen = set()
        for entry in self._history.load_history_strings():
            if entry.startswith(text) and entry != text and entry not in seen:
                seen.add(entry)
                yield Completion(entry, start_position=-len(text))


def run_prompt(
    command_processing_function,
    command_list: list[str],
    prompt_string=HTML("<b><ansibrightblue>&gt; </ansibrightblue></b>"),
) -> None:
    history = InMemoryHistory()
    completer = merge_completers([
        WordCompleter(command_list, sentence=False),
        _HistoryCompleter(history),
    ])
    session = PromptSession(
        history=history,
        completer=completer,
    )
    while True:
        try:
            text = session.prompt(prompt_string)
        except (KeyboardInterrupt, EOFError):
            break
        command_processing_function(text)
