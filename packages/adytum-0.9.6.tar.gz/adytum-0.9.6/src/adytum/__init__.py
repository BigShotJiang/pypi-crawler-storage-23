#!/usr/bin/env python3

from adytum.version import __version__

__all__ = ["__version__"]
