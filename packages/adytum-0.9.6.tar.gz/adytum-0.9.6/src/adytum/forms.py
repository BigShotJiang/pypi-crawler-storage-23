#!/usr/bin/env python3

import os

from pendulum import now

from adytum.config import load_config, save_config
from adytum.helpers import (convert_date_range, enter_date_or_quit,
                            enter_password_with_confirm_or_quit,
                            enter_value_or_quit, ExitFormError)
from adytum.renderer import Renderer
from adytum.style import gold, crimson, red, green, dim


class Forms:
    def __init__(self, queries_manager):
        self.queries_manager = queries_manager
        self.renderer = Renderer()
        self.show_password = True

    def toggle_show_hours(self):
        self.renderer.toggle_show_hours()

    def toggle_show_full_year(self):
        self.renderer.toggle_show_full_year()

    def toggle_password_visibility(self):
        self.show_password = not self.show_password
        state = "visible" if self.show_password else "hidden"
        print(dim(f"· Password input is now {state}."))

    def _render_accounts(self, dataset, output_field=None):
        self.renderer.render_accounts(dataset, output_field)

    def backup_database(self):
        self.queries_manager.backup_database()

    def connect_to_database(self):
        try:
            path = enter_value_or_quit("- Vault path\n>>> ")
        except ExitFormError:
            print(dim("· Withdrawing."))
            return
        path = os.path.expanduser(path)
        self.queries_manager.connect_to_database(path)
        if os.path.exists(path):
            cfg = load_config()
            cfg["last_vault"] = os.path.abspath(path)
            # Reset backup_dir to the new DB's folder when switching databases.
            cfg["backup_dir"] = os.path.dirname(os.path.abspath(path))
            save_config(cfg)
            self.queries_manager.set_backup_dir(cfg["backup_dir"])

    # ########## #
    #   CREATE   #
    # ########## #
    def add_account(self):
        """It get the data and add an account to the system."""
        print(gold("--- INSCRIBE NEW ENTRY --- (exit_form to withdraw)"))
        status = "N"
        try:
            while status == "N":
                name = enter_value_or_quit(
                    "Enter the account name or [quit]\n>>> "
                )
                email = enter_value_or_quit(
                    "Enter the email for this account or [quit]\n>>> "
                )
                username = enter_value_or_quit(
                    "Enter the username for this account or [quit]\n>>> "
                )
                password = enter_password_with_confirm_or_quit(
                    show=self.show_password,
                    text="Enter the password for this account or [quit]\n>>> "
                )
                project = enter_value_or_quit(
                    "Enter the project name or [quit]\n>>> "
                )
                web = enter_value_or_quit(
                    "Enter the login website or [quit]\n>>> "
                )
                comments = enter_value_or_quit(
                    "Enter notes / comments or [quit]\n>>> "
                )
                status_text = (
                    "Review the entry. Press ENTER to seal it,\n"
                    "type N to revise it, or [quit]\n>>> "
                )
                status = enter_value_or_quit(status_text).upper()
        except ExitFormError:
            print(dim("· Withdrawing."))
            return

        creation_timestamp = last_modification_timestamp = now().timestamp()

        self.queries_manager.add_account(
                name=name,
                email=email,
                username=username,
                password=password,
                project=project,
                web=web,
                creation_timestamp=creation_timestamp,
                last_modification_timestamp=last_modification_timestamp,
                comments=comments
            )
        print(green("· Entry sealed."))

    ############
    #   READ   #
    ############
    def _list_by_field(self, column: str, text: str, output_field: int | None = None):
        """Generic LIKE search on any Accounts column."""
        dataset = self.queries_manager.list_element_like(
            table="Accounts", column=column, text=text
        )
        self._render_accounts(dataset, output_field)

    def list_accounts_by_id(self, before=None, after=None, output_field: int | None = None):
        """It list accounts by Id using BETWEEN for range."""
        dataset = self.queries_manager.list_element(
            table="Accounts", column="Id", before=before, after=after
        )
        self._render_accounts(dataset, output_field)

    def list_accounts_by_name(self, text, output_field: int | None = None):
        self._list_by_field("Name", text, output_field)

    def list_accounts_by_email(self, text, output_field: int | None = None):
        self._list_by_field("Email", text, output_field)

    def list_accounts_by_username(self, text, output_field: int | None = None):
        self._list_by_field("Username", text, output_field)

    def list_accounts_by_pass(self, text):
        self._list_by_field("Password", text)

    def list_accounts_by_project(self, text, output_field: int | None = None):
        self._list_by_field("Project", text, output_field)

    def list_accounts_by_web(self, text, output_field: int | None = None):
        self._list_by_field("Web", text, output_field)

    def list_accounts_by_comment(self, text):
        self._list_by_field("Comments", text)

    def list_accounts_by_creation_date(self, before=None, after=None):
        """It list accounts by date using BETWEEN for range."""
        before, after = convert_date_range(before=before, after=after)
        dataset = self.queries_manager.list_element(
            table="Accounts",
            column="Creation_timestamp",
            before=before,
            after=after
        )
        self._render_accounts(dataset)

    def list_accounts_by_modification_date(self, before=None, after=None):
        """It list accounts by date_modification using BETWEEN for range."""
        before, after = convert_date_range(before=before, after=after)
        dataset = self.queries_manager.list_element(
            table="Accounts", column="Last_modification_timestamp",
            before=before, after=after
        )
        self._render_accounts(dataset)

    # ########## #
    #   UPDATE   #
    # ########## #
    def set_element(
        self,
        account_id,
        table,
        where_field,
        string_new_element,
        database_field,
        date=False,
        password=False,
            ):
        """
        It is a wrapper of the UPDATE query,
        with a little form to manage the changes.
        """
        if not self.queries_manager.check_if_id_exists_in_table(
                table, account_id):
            print(red(f"--- NO ENTRY WITH ID {account_id} ---"))
            return
        self.list_accounts_by_id(
            before=account_id,
            after=account_id
            )

        status_text = (
            "Do you want to modify this account, if it is correct, "
            "press ENTER,\nif it is incorrect, input N and press ENTER or "
            "[quit], exit form with exit_form\n>>> "
        )

        try:
            status = enter_value_or_quit(status_text).upper()
            if status == "N":
                return

            status = "N"
            while status == "N":
                prompt = (
                    f"Input a new {string_new_element} for this account or [quit]\n>>> "
                )
                if date:
                    value = enter_date_or_quit(prompt)
                elif password:
                    value = enter_password_with_confirm_or_quit(
                        show=self.show_password, text=prompt)
                else:
                    value = enter_value_or_quit(prompt)

                status_text = (
                    "Verify the data, if it is correct, "
                    "press ENTER, \nif it is incorrect, input N and "
                    "press ENTER or [quit]\n>>> "
                )
                status = enter_value_or_quit(status_text).upper()
        except ExitFormError:
            print(dim("· Withdrawing."))
            return

        self.queries_manager.set_element(
                table=table,
                database_field=database_field,
                value=value,
                where_field=where_field,
                account_id=account_id
            )
        if database_field != "Last_modification_timestamp":
            self.queries_manager.set_element(
                table=table,
                database_field="Last_modification_timestamp",
                value=now().timestamp(),
                where_field=where_field,
                account_id=account_id
            )
        print(green("· Entry amended."))

    def _set_field(self, account_id, label: str, db_column: str,
                   date: bool = False, password: bool = False):
        """Thin wrapper that hardcodes table/where_field for the Accounts table."""
        self.set_element(
            account_id=account_id,
            table="Accounts",
            where_field="Id",
            string_new_element=label,
            database_field=db_column,
            date=date,
            password=password,
        )

    def set_name(self, account_id):
        self._set_field(account_id, "name", "Name")

    def set_creation_date(self, account_id):
        self._set_field(account_id, "creation date", "Creation_timestamp", date=True)

    def set_modification_date(self, account_id):
        self._set_field(account_id, "modification date", "Last_modification_timestamp", date=True)

    def set_email(self, account_id):
        self._set_field(account_id, "email", "Email")

    def set_username(self, account_id):
        self._set_field(account_id, "username", "Username")

    def set_pass(self, account_id):
        self._set_field(account_id, "password", "Password", password=True)

    def set_project(self, account_id):
        self._set_field(account_id, "project", "Project")

    def set_web(self, account_id):
        self._set_field(account_id, "web", "Web")

    def set_comment(self, account_id):
        self._set_field(account_id, "comment", "Comments")

    def update_all(self, account_id):
        """It update all the data of an account."""
        if not self.queries_manager.check_if_id_exists_in_table("Accounts", account_id):
            print(red(f"--- NO ENTRY WITH ID {account_id} ---"))
            return
        print(gold("--- AMEND ENTRY --- (exit_form to withdraw)"))
        self.list_accounts_by_id(before=account_id, after=account_id)

        try:
            status = enter_value_or_quit(
                "Do you want to modify this account, if it is correct, "
                "press ENTER,\nif it is incorrect, input N and press ENTER\n>>> "
                ).upper()
            if status == "N":
                return

            status = "N"
            while status == "N":
                name = enter_value_or_quit(
                    "Input the name of this account or [quit]\n>>> "
                    )
                email = enter_value_or_quit(
                    "Input the email you will use in this "
                    "account or [quit]\n>>> "
                    )
                username = enter_value_or_quit(
                    "Input the username you will use in this "
                    "account or [quit]\n>>> "
                    )
                password = enter_password_with_confirm_or_quit(
                    show=self.show_password,
                    text="Input the password you will use in this "
                    "account or [quit]\n>>> "
                    )
                project = enter_value_or_quit(
                    "Input the name of the project that this "
                    "account belongs to or [quit]\n>>> "
                    )
                web = enter_value_or_quit(
                    "Input the name of the web that will be used "
                    "to log in or [quit]\n>>> "
                    )

                creation_timestamp = enter_date_or_quit(
                    "Input a new creation date or [quit]\n>>> "
                )
                last_modification_timestamp = enter_date_or_quit(
                    "Input the modification date or [quit]\n>>> "
                )

                comments = enter_value_or_quit(
                    "Input your comments or [quit]\n>>> "
                    )

                status_text = (
                    "Verify the data, if it is correct, "
                    "press ENTER, \nif it is incorrect, input N "
                    "and press ENTER or [quit]\n>>> "
                )
                status = enter_value_or_quit(status_text).upper()
        except ExitFormError:
            print(dim("· Withdrawing."))
            return

        self.queries_manager.update_all(
            name=name,
            email=email,
            username=username,
            password=password,
            project=project,
            web=web,
            creation_timestamp=creation_timestamp,
            last_modification_timestamp=last_modification_timestamp,
            comments=comments,
            account_id=account_id
        )
        print(green("· Entry amended."))

    # ########## #
    #   DELETE   #
    # ########## #
    def remove_account(self, account_id):
        """It remove an account based on the account Id."""
        self.list_accounts_by_id(before=account_id, after=account_id)

        print(crimson("--- PRESS ENTER TO PURGE THIS ENTRY ---"))

        status_text = (
            "Verify the data, if it is correct, press ENTER,"
            "\nif it is incorrect, input N and press ENTER or [quit]\n>>> "
        )

        try:
            status = enter_value_or_quit(status_text).upper()
        except ExitFormError:
            print(dim("· Withdrawing."))
            return

        if status == "N":
            return

        self.queries_manager.remove_account(
            account_id=account_id
            )
        print(green("· Entry purged."))
