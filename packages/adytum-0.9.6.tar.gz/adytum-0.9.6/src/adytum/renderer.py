#!/usr/bin/env python3

from outfancy.table import Table
from pendulum import from_timestamp

from adytum.style import amber, dim

_COLUMNS_TO_CONVERT = {7, 8}
_ACCOUNTS_LABELS = [
    "Id", "Name", "Email", "Username", "Password",
    "Project", "Web", "Created", "Modified", "Comments",
]


def print_rows(dataset, output_field: int | None = None):
    try:
        rows = [row[output_field] for row in dataset]
    except (IndexError, TypeError):
        rows = []

    sep = "*" * 50
    print(sep)
    for row in rows:
        print(row)
        print(sep)


class Renderer:
    def __init__(self):
        self._table = Table()
        self._table.set_empty_string(amber("--- INNER CHAMBER EMPTY ---"))
        self.show_hours = False
        self.show_full_year = True
        self._fmt = self._build_fmt()

    def toggle_show_hours(self):
        self.show_hours = not self.show_hours
        self._fmt = self._build_fmt()
        state = "enabled" if self.show_hours else "disabled"
        print(dim(f"· Hours are now {state}."))

    def toggle_show_full_year(self):
        self.show_full_year = not self.show_full_year
        self._fmt = self._build_fmt()
        state = "enabled" if self.show_full_year else "disabled"
        print(dim(f"· Full year is now {state}."))

    def _build_fmt(self) -> str:
        fmt = "DD-MM-YYYY" if self.show_full_year else "DD-MM-YY"
        if self.show_hours:
            fmt += " HH:mm:ss"
        return fmt

    def _convert_timestamps(self, dataset):
        result = []
        for row in dataset:
            converted = []
            for i, value in enumerate(row):
                if i in _COLUMNS_TO_CONVERT:
                    converted.append(
                        from_timestamp(value, tz="local").format(self._fmt)
                    )
                else:
                    converted.append(value)
            result.append(converted)
        return result

    def render_accounts(self, dataset, output_field: int | None = None):
        if output_field is None:
            print(self._table.render(
                data=self._convert_timestamps(dataset),
                label_list=_ACCOUNTS_LABELS,
            ))
        else:
            print_rows(dataset=dataset, output_field=output_field)
