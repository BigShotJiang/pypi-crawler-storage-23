#!/usr/bin/env python3

from pendulum import now

GOLD = "\033[38;5;214m"
RESET = "\033[0m"
BOLD = "\033[1m"

_W = 73  # visual width of splash art

SPLASH = """\
               █████             █████
              ░░███             ░░███
  ██████    ███████  █████ ████ ███████   █████ ████ █████████████
 ░░░░░███  ███░░███ ░░███ ░███ ░░░███░   ░░███ ░███ ░░███░░███░░███
  ███████ ░███ ░███  ░███ ░███   ░███     ░███ ░███  ░███ ░███ ░███
 ███░░███ ░███ ░███  ░███ ░███   ░███ ███ ░███ ░███  ░███ ░███ ░███
░░████████░░████████ ░░███████   ░░█████  ░░████████ █████░███ █████
 ░░░░░░░░  ░░░░░░░░   ░░░░░███    ░░░░░    ░░░░░░░░ ░░░░░ ░░░ ░░░░░
                      ███ ░███
                     ░░██████
                      ░░░░░░                                        \
"""


def _date_string() -> str:
    return now(tz="local").to_rfc1036_string()


_SUBTITLE = "encrypted credential vault"


def print_splash():
    print()
    print(f"{GOLD}{SPLASH}{RESET}")

    subtitle_pad = " " * ((_W - len(_SUBTITLE)) // 2)
    print(f"{subtitle_pad}{_SUBTITLE}")

    date = _date_string()
    print()
    print(f"{BOLD}>>> {date}{RESET}\n")


if __name__ == "__main__":
    print_splash()
