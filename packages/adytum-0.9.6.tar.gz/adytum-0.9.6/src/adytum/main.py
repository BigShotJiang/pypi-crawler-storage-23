#!/usr/bin/env python3

import logging
import os
from pathlib import Path

import structlog

from adytum.command_interpreter import Interpreter
from adytum.forms import Forms
from adytum.session import start_session
from adytum.storage import QueriesManager


def _default_program_folder() -> str:
    xdg = os.environ.get("XDG_DATA_HOME", "")
    if xdg:
        return str(Path(xdg) / "adytum")
    return str(Path.home() / ".local" / "share" / "adytum")


def _configure_logging(program_folder: str) -> None:
    os.makedirs(program_folder, exist_ok=True)
    log_path = str(Path(program_folder) / "adytum.log")
    handler = logging.FileHandler(log_path)
    handler.setFormatter(logging.Formatter("%(message)s"))
    root_logger = logging.getLogger()
    root_logger.addHandler(handler)
    root_logger.setLevel(logging.WARNING)
    structlog.configure(
        processors=[
            structlog.stdlib.add_log_level,
            structlog.stdlib.add_logger_name,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.ExceptionRenderer(),
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def run(program_folder: str | None = None) -> None:
    if program_folder is None:
        program_folder = _default_program_folder()
    _configure_logging(program_folder)
    program_name = "adytum"
    queries_manager = QueriesManager()
    forms = Forms(queries_manager=queries_manager)
    interpreter = Interpreter(forms=forms, program_name=program_name)
    start_session(queries_manager)
    interpreter.start()
