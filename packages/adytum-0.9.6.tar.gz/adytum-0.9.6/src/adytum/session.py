#!/usr/bin/env python3

import os
import re
import sys

from pendulum import from_format as pendulum_from_format, now as pendulum_now

from adytum.config import load_config, save_config
from adytum.helpers import (
    enter_password_with_confirm_or_quit,
    enter_value_or_quit,
    enter_value_with_prefill_or_quit,
    ExitFormError,
)
from adytum.style import green, dim, red

_DEFAULT_VAULT_FILENAME = "adytum.ec"
_BACKUP_TS_RE = re.compile(r'-backup-(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})')


def _run_auto_backup(queries_manager, backup_dir: str) -> None:
    """Create a new backup if needed; prune backups older than threshold."""
    config = load_config()
    frequency_days = int(config.get("backup_frequency_days", 1))
    max_age_days = int(config.get("backup_max_age_days", 30))

    now = pendulum_now()
    cutoff_new = now.subtract(days=frequency_days)
    cutoff_remove = now.subtract(days=max_age_days)

    backup_files = []
    if os.path.isdir(backup_dir):
        for fname in os.listdir(backup_dir):
            m = _BACKUP_TS_RE.search(fname)
            if not m:
                continue
            try:
                dt = pendulum_from_format(m.group(1), "YYYY-MM-DD_HH-mm-ss")
            except Exception:
                continue
            backup_files.append((dt, os.path.join(backup_dir, fname)))

    # Remove old backups first
    survivors = []
    for dt, fpath in backup_files:
        if dt < cutoff_remove:
            os.remove(fpath)
            print(dim(f"· Purged old backup: {os.path.basename(fpath)}"))
        else:
            survivors.append((dt, fpath))

    # Create new backup if no survivors or newest is stale
    if not survivors or max(dt for dt, _ in survivors) < cutoff_new:
        queries_manager.backup_database()


def _create_database(queries_manager, path: str, backup_dir: str) -> None:
    """Ask for a key and create a new encrypted database at the given path."""
    try:
        status = "N"
        while status == "N":
            key = enter_password_with_confirm_or_quit(
                "Choose a master key — do not forget it — or [quit]\n>>> ",
                show=False,
            )
            status = enter_value_or_quit(
                "Press ENTER to seal the vault, or N to choose a different key or [quit]\n>>> "
            ).upper()
    except ExitFormError:
        sys.exit()

    os.makedirs(os.path.dirname(path), exist_ok=True)
    queries_manager.set_database_path(path)
    queries_manager.set_encryption_motor(key)
    queries_manager.create_database()
    queries_manager.set_backup_dir(backup_dir)
    print(green("· Vault sealed."))
    save_config({**load_config(),
                 "last_vault": os.path.abspath(path),
                 "backup_dir": os.path.abspath(backup_dir)})


def _open_database(
    queries_manager,
    path: str,
    backup_dir: str,
    config: dict
        ) -> None:
    """Connect to an existing database and persist updated config."""
    queries_manager.connect_to_database(path)
    queries_manager.set_backup_dir(backup_dir)
    save_config({**config, "last_vault": os.path.abspath(path)})
    _run_auto_backup(queries_manager, backup_dir)


def _setup_wizard(queries_manager) -> None:
    """First-run flow: ask for vaults folder and backup folder."""
    try:
        while True:
            raw_folder = enter_value_or_quit(
                "Vault folder path (e.g. ~/documents/vaults) or [quit]\n>>> "
            )
            if raw_folder.strip():
                break
            print(red("--- Folder cannot be empty. ---"))
        vaults_folder = os.path.abspath(os.path.expanduser(raw_folder.strip()))

        default_backup = os.path.join(vaults_folder, "backup")
        while True:
            raw_backup = enter_value_with_prefill_or_quit(
                "Backup folder path or [quit]\n>>> ",
                prefill=default_backup,
            )
            if raw_backup.strip():
                break
            print(red("--- Folder cannot be empty. ---"))
        backup_dir = os.path.expanduser(raw_backup.strip())

        while True:
            raw_freq = enter_value_with_prefill_or_quit(
                "Backup frequency in days (backup runs if last backup is older than this) or [quit]\n>>> ",
                prefill="1",
            )
            try:
                backup_frequency_days = int(raw_freq.strip())
                if backup_frequency_days > 0:
                    break
            except ValueError:
                pass
            print(red("--- Please enter a positive integer. ---"))

        while True:
            raw_max = enter_value_with_prefill_or_quit(
                "Maximum backup age in days (older backups are deleted) or [quit]\n>>> ",
                prefill="30",
            )
            try:
                backup_max_age_days = int(raw_max.strip())
                if backup_max_age_days > 0:
                    break
            except ValueError:
                pass
            print(red("--- Please enter a positive integer. ---"))
    except ExitFormError:
        sys.exit()

    save_config({
        "backup_dir": os.path.abspath(backup_dir),
        "backup_frequency_days": backup_frequency_days,
        "backup_max_age_days": backup_max_age_days,
    })

    path = os.path.join(vaults_folder, _DEFAULT_VAULT_FILENAME)

    if os.path.exists(path):
        _open_database(queries_manager, path, backup_dir, load_config())
    else:
        _create_database(queries_manager, path, backup_dir)


def _missing_vault_wizard(queries_manager, vaults_folder: str, config: dict) -> None:
    """Flow when configured vault file is missing: ask which vault to open or create."""
    backup_dir = config.get("backup_dir", os.path.join(vaults_folder, "backup"))
    try:
        print(dim(f"· Vaults folder: {vaults_folder}"))
        raw_folder = enter_value_or_quit(
            "ENTER to keep current folder, or enter a new path or [quit]\n>>> "
        )
        if raw_folder.strip():
            old_default_backup = os.path.join(vaults_folder, "backup")
            vaults_folder = os.path.abspath(os.path.expanduser(raw_folder.strip()))
            if backup_dir == old_default_backup:
                backup_dir = os.path.join(vaults_folder, "backup")
        while True:
            raw_name = enter_value_with_prefill_or_quit(
                "Vault name (without .ec) or [quit]\n>>> ",
                prefill="adytum",
            )
            if raw_name.strip():
                break
            print(red("--- Vault name cannot be empty. ---"))
    except ExitFormError:
        sys.exit()

    name = raw_name.strip()
    if not name.endswith(".ec"):
        name += ".ec"
    path = os.path.join(vaults_folder, name)

    if os.path.exists(path):
        _open_database(queries_manager, path, backup_dir, config)
    else:
        print(dim(f"· Vault will be created at {path}"))
        _create_database(queries_manager, path, backup_dir)


def start_session(queries_manager) -> None:
    """Initialize the database connection, creating a new vault if needed."""
    config = load_config()
    last_vault = config.get("last_vault") or config.get("last_db")

    if not last_vault:
        _setup_wizard(queries_manager)
        return

    if not os.path.exists(last_vault):
        print(red(f"--- Last vault not found: {last_vault} ---"))
        vaults_folder = os.path.dirname(os.path.abspath(last_vault))
        _missing_vault_wizard(queries_manager, vaults_folder, config)
        return

    # Known vault exists — offer to open it or create a new one in the same folder.
    vault_dir = os.path.dirname(os.path.abspath(last_vault))
    try:
        print(dim(f"· Vault: {last_vault}"))
        raw = enter_value_or_quit(
            "ENTER to unseal, or type a new vault name or [quit]\n>>> "
        )
    except ExitFormError:
        sys.exit()

    if raw == "":
        path = last_vault
        backup_dir = config.get(
            "backup_dir", vault_dir)
        _open_database(queries_manager, path, backup_dir, config)
    else:
        name = raw.strip()
        if not name.endswith(".ec"):
            name += ".ec"
        path = os.path.join(vault_dir, name)
        backup_dir = config.get("backup_dir", vault_dir)
        if os.path.exists(path):
            _open_database(queries_manager, path, backup_dir, config)
        else:
            print(dim(f"· Vault will be created at {path}"))
            _create_database(queries_manager, path, backup_dir)
