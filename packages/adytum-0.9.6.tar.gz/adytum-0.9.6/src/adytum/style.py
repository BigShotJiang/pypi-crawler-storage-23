#!/usr/bin/env python3

GOLD = "\033[38;5;214m"
AMBER = "\033[38;5;136m"
RED = "\033[38;5;167m"
CRIMSON = "\033[38;5;160m"
GREEN = "\033[38;5;71m"
DIM = "\033[38;5;244m"
BBLUE = "\033[1;94m"
RESET = "\033[0m"


def gold(s):
    return f"{GOLD}{s}{RESET}"


def amber(s):
    return f"{AMBER}{s}{RESET}"


def red(s):
    return f"{RED}{s}{RESET}"


def crimson(s):
    return f"{CRIMSON}{s}{RESET}"


def green(s):
    return f"{GREEN}{s}{RESET}"


def dim(s):
    return f"{DIM}{s}{RESET}"


def bblue(s):
    return f"{BBLUE}{s}{RESET}"
