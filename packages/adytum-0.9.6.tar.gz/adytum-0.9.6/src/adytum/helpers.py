#!/usr/bin/env python3

import string
import sys
from secrets import choice, randbelow

from pendulum import from_format

from prompt_toolkit import prompt as pt_prompt
from prompt_toolkit.formatted_text import FormattedText

from adytum.style import red, BBLUE, RESET


def _cp(text: str) -> str:
    """Color the >>> marker in a prompt string."""
    return text.replace(">>> ", f"{BBLUE}>>> {RESET}")


def _pt_cp(text: str) -> FormattedText:
    """Color the >>> marker for prompt_toolkit prompts."""
    parts = text.split(">>> ")
    result = []
    for i, part in enumerate(parts):
        if part:
            result.append(("", part))
        if i < len(parts) - 1:
            result.append(("bold ansibrightblue", ">>> "))
    return FormattedText(result)


#  Password generator:
_LOWER = string.ascii_lowercase
_UPPER = string.ascii_uppercase
_DIGITS = string.digits
# Shell metacharacters excluded: $ & * ( ) [ ] { } | ; < > ? ^ # ,
_SPECIAL = "!@%-_=+:."
_ALL = _LOWER + _UPPER + _DIGITS + _SPECIAL


def generate_random_string(length: int = 20) -> str:
    """Generate a cryptographically random password of the given length.

    Guarantees at least one lowercase, uppercase, digit, and special character.
    Minimum length is 4.
    """
    if length < 4:
        raise ValueError("length must be at least 4")
    chars = [
        choice(_LOWER),
        choice(_UPPER),
        choice(_DIGITS),
        choice(_SPECIAL),
    ] + [choice(_ALL) for _ in range(length - 4)]
    # Fisher-Yates shuffle via secrets.randbelow (cryptographic source)
    for i in range(len(chars) - 1, 0, -1):
        j = randbelow(i + 1)
        chars[i], chars[j] = chars[j], chars[i]
    return "".join(chars)


# Form exit:
class ExitFormError(Exception):
    """Raised when the user types 'exit_form' inside an input form."""


def date_to_unix_timestamp(text, exception=False):
    """It converts a valid date to timestamp format."""
    error_date = red("--- INVALID DATE — expected DD/MM/YYYY or DD/MM/YY ---")
    text = normalise_date(text)
    status, fmt = is_date(text)
    if status:
        date_input = from_format(text, fmt, tz="local")
        return date_input.timestamp()
    else:
        if exception:
            raise Exception(error_date)
        else:
            print(error_date)
            raise ExitFormError()


def convert_date_range(before, after):
    status_before = None
    status_after = None
    if before is not None:
        before = normalise_date(before)
        status_before, fmt_before = is_date(before)
    if after is not None:
        after = normalise_date(after)
        status_after, fmt_after = is_date(after)
    if status_before:
        before = from_format(before, fmt_before, tz="local").timestamp()
    else:
        before = None
    if status_after:
        after = from_format(after, fmt_after, tz="local").timestamp()
    else:
        after = None
    return before, after


def normalise_date(text: str) -> str:
    """
    Function to normalise dates.
    :param text: str: String of date to normalise.
    """
    return text.replace(
        "/", "-").replace(
        ":", "-").replace(
        ".", "-").replace(
        "@", "-")


def is_complete_hour(text: str, tz: str = "local") -> bool:
    """
    Check if text is a valid hour.
    :param text: str: Text to check.
    :param tz: str:  (Default value = "local")
    """
    for fmt in ["HH:mm:ss", "HH:mm"]:
        try:
            from_format(text, fmt, tz=tz)
            return True
        except Exception:
            continue
    return False


def is_date(text: str, tz: str = "local") -> tuple[bool, str]:
    """
    Check if text is a valid date. Format:
        format: "DD-MM-YYYY HH-mm-ss",
                "DD-MM-YYYY HH-mm",
                "DD-MM-YYYY HH",
                "DD-MM-YYYY"
    :param text: str: Text to
    :param tz: str:  (Default value = "local")
    """
    text = normalise_date(text)
    # YY variants come first: pendulum accepts "11" as YYYY=11 AD, so we must
    # match the 2-digit-year case before it falls through to the YYYY formats.
    time_format_list = ["DD-MM-YY HH-mm-ss",
                        "DD-MM-YYYY HH-mm-ss",
                        "DD-MM-YY HH-mm",
                        "DD-MM-YYYY HH-mm",
                        "DD-MM-YY HH",
                        "DD-MM-YYYY HH",
                        "DD-MM-YY",
                        "DD-MM-YYYY"]
    for fmt in time_format_list:
        try:
            from_format(text, fmt, tz=tz)
            return True, fmt
        except Exception:
            ...
    return False, ""


C_QUIT = ["q", "exit", "quit"]


def enter_value_or_quit(input_text):
    """Prompts for input; quits on quit words, raises ExitFormError on 'exit_form'."""
    while True:
        value = input(_cp(input_text))
        if value in C_QUIT:
            sys.exit()
        if value == "exit_form":
            raise ExitFormError()
        return value


def enter_value_with_prefill_or_quit(input_text, prefill=""):
    """Prompt with an editable pre-filled default using prompt_toolkit."""
    value = pt_prompt(input_text, default=prefill)
    if value in C_QUIT:
        sys.exit()
    if value == "exit_form":
        raise ExitFormError()
    return value


def enter_password_or_quit(text, show: bool = True):
    """It allows to receive a password input or to quit the program."""
    while True:
        value = input(_cp(text)) if show else pt_prompt(_pt_cp(text), is_password=True)
        if value in C_QUIT:
            sys.exit()
        if value == "exit_form":
            raise ExitFormError()
        return value


def enter_password_with_confirm_or_quit(text, show: bool = True):
    """Ask for a password twice; loop until both entries match."""
    while True:
        pw1 = enter_password_or_quit(text, show=show)
        pw2 = enter_password_or_quit("Confirm the password or [quit]\n>>> ", show=show)
        if pw1 == pw2:
            return pw1
        print(red("--- Passwords do not match. Please try again. ---"))


def enter_date_or_quit(prompt: str) -> float:
    """Ask for a date repeatedly until a valid one is entered; returns unix timestamp."""
    while True:
        value = enter_value_or_quit(prompt)
        valid, _ = is_date(value)
        if valid:
            return date_to_unix_timestamp(value)
        print(red("--- INVALID DATE ---"))
