#!/usr/bin/env python3

"""Tests for Interpreter.command_process — command dispatch flows."""

import pytest
from unittest.mock import MagicMock

from adytum.command_interpreter import Interpreter


@pytest.fixture
def interp():
    """Interpreter backed by a fully-mocked Forms object."""
    forms = MagicMock()
    return Interpreter(forms=forms, program_name="adytum"), forms


# ################# #
#   STANDARD CMDS   #
# ################# #

class TestStandardCommands:
    def test_empty_input_is_silent(self, interp, capsys):
        i, _ = interp
        i.command_process("")
        assert capsys.readouterr().out == ""

    def test_version(self, interp, capsys):
        i, _ = interp
        i.command_process("ver")
        assert "adytum" in capsys.readouterr().out.lower()

    def test_help(self, interp, capsys):
        i, _ = interp
        i.command_process("h")
        out = capsys.readouterr().out
        assert "CLI" in out

    def test_date(self, interp, capsys):
        i, _ = interp
        i.command_process("d")
        out = capsys.readouterr().out
        assert out.strip() != ""

    def test_unknown_command(self, interp, capsys):
        i, _ = interp
        i.command_process("foobar")
        assert "UNKNOWN" in capsys.readouterr().out

    def test_pass_prints_password(self, interp, capsys):
        i, _ = interp
        i.command_process("pass")
        out = capsys.readouterr().out.strip()
        assert len(out) == 20

    def test_pass_custom_length(self, interp, capsys):
        i, _ = interp
        i.command_process("pass 32")
        out = capsys.readouterr().out.strip()
        assert len(out) == 32

    def test_password_alias(self, interp, capsys):
        i, _ = interp
        i.command_process("password")
        out = capsys.readouterr().out.strip()
        assert len(out) == 20


# ############ #
#   LS / LIST  #
# ############ #

class TestListCommand:
    def test_ls_no_args_calls_list_by_id(self, interp):
        i, forms = interp
        i.command_process("ls")
        forms.list_accounts_by_id.assert_called_once()

    def test_list_alias(self, interp):
        i, forms = interp
        i.command_process("list")
        forms.list_accounts_by_id.assert_called_once()

    def test_ls_range(self, interp):
        i, forms = interp
        i.command_process("ls 1:5")
        forms.list_accounts_by_id.assert_called_once()
        call_kwargs = forms.list_accounts_by_id.call_args
        assert call_kwargs is not None

    def test_ls_name_with_text(self, interp):
        i, forms = interp
        i.command_process("ls name %foo%")
        forms.list_accounts_by_name.assert_called_once()

    def test_ls_name_no_text_prints_syntax(self, interp, capsys):
        i, forms = interp
        i.command_process("ls name")
        forms.list_accounts_by_name.assert_not_called()
        assert "Syntax" in capsys.readouterr().out

    def test_ls_email(self, interp):
        i, forms = interp
        i.command_process("ls email %x@x.com%")
        forms.list_accounts_by_email.assert_called_once()

    def test_ls_username(self, interp):
        i, forms = interp
        i.command_process("ls usr %admin%")
        forms.list_accounts_by_username.assert_called_once()

    def test_ls_pass(self, interp):
        i, forms = interp
        i.command_process("ls pass %secret%")
        forms.list_accounts_by_pass.assert_called_once()

    def test_ls_project(self, interp):
        i, forms = interp
        i.command_process("ls p %myproj%")
        forms.list_accounts_by_project.assert_called_once()

    def test_ls_web(self, interp):
        i, forms = interp
        i.command_process("ls web %example%")
        forms.list_accounts_by_web.assert_called_once()

    def test_ls_comment(self, interp):
        i, forms = interp
        i.command_process("ls c %note%")
        forms.list_accounts_by_comment.assert_called_once()

    def test_ls_date_no_sub_prints_syntax(self, interp, capsys):
        i, forms = interp
        i.command_process("ls date")
        forms.list_accounts_by_creation_date.assert_not_called()
        assert "Syntax" in capsys.readouterr().out

    def test_ls_date_creation(self, interp):
        i, forms = interp
        i.command_process("ls date 1/1/2024")
        forms.list_accounts_by_creation_date.assert_called_once()

    def test_ls_date_modification(self, interp):
        i, forms = interp
        i.command_process("ls date set 1/1/2024")
        forms.list_accounts_by_modification_date.assert_called_once()


# ########## #
#   MK/MAKE  #
# ########## #

class TestMakeCommand:
    def test_mk_calls_add_account(self, interp):
        i, forms = interp
        i.command_process("mk")
        forms.add_account.assert_called_once()

    def test_make_alias(self, interp):
        i, forms = interp
        i.command_process("make")
        forms.add_account.assert_called_once()

    def test_create_alias(self, interp):
        i, forms = interp
        i.command_process("create")
        forms.add_account.assert_called_once()


# ############ #
#   RM/REMOVE  #
# ############ #

class TestRemoveCommand:
    def test_rm_with_id(self, interp):
        i, forms = interp
        i.command_process("rm 5")
        forms.remove_account.assert_called_once_with("5")

    def test_rm_no_arg_prints_syntax(self, interp, capsys):
        i, forms = interp
        i.command_process("rm")
        forms.remove_account.assert_not_called()
        assert "rm" in capsys.readouterr().out

    def test_rm_non_digit_prints_error(self, interp, capsys):
        i, forms = interp
        i.command_process("rm foo")
        forms.remove_account.assert_not_called()
        assert "number" in capsys.readouterr().out.lower()

    def test_remove_alias(self, interp):
        i, forms = interp
        i.command_process("remove 3")
        forms.remove_account.assert_called_once_with("3")


# ########## #
#   SET      #
# ########## #

class TestSetCommand:
    def test_set_no_args_prints_syntax(self, interp, capsys):
        i, forms = interp
        i.command_process("set")
        assert "Syntax" in capsys.readouterr().out

    def test_set_id_only_calls_update_all(self, interp):
        i, forms = interp
        i.command_process("set 1")
        forms.update_all.assert_called_once_with("1")

    def test_set_colon_syntax_calls_update_all(self, interp):
        i, forms = interp
        i.command_process("set :1:")
        forms.update_all.assert_called_once_with("1")

    def test_set_name(self, interp):
        i, forms = interp
        i.command_process("set 2 name")
        forms.set_name.assert_called_once_with("2")

    def test_set_email(self, interp):
        i, forms = interp
        i.command_process("set 2 email")
        forms.set_email.assert_called_once_with("2")

    def test_set_username(self, interp):
        i, forms = interp
        i.command_process("set 2 usr")
        forms.set_username.assert_called_once_with("2")

    def test_set_pass(self, interp):
        i, forms = interp
        i.command_process("set 2 pass")
        forms.set_pass.assert_called_once_with("2")

    def test_set_project(self, interp):
        i, forms = interp
        i.command_process("set 2 p")
        forms.set_project.assert_called_once_with("2")

    def test_set_web(self, interp):
        i, forms = interp
        i.command_process("set 2 web")
        forms.set_web.assert_called_once_with("2")

    def test_set_comment(self, interp):
        i, forms = interp
        i.command_process("set 2 c")
        forms.set_comment.assert_called_once_with("2")

    def test_set_creation_date(self, interp):
        i, forms = interp
        i.command_process("set 2 date")
        forms.set_creation_date.assert_called_once_with("2")

    def test_set_modification_date(self, interp):
        i, forms = interp
        i.command_process("set 2 date set")
        forms.set_modification_date.assert_called_once_with("2")

    def test_set_unknown_sub_prints_syntax(self, interp, capsys):
        i, forms = interp
        i.command_process("set 2 foobar")
        assert "Syntax" in capsys.readouterr().out


# ########## #
#   TOGGLE   #
# ########## #

class TestToggleCommand:
    def test_tgl_hr_calls_toggle_hours(self, interp):
        i, forms = interp
        i.command_process("tgl hr")
        forms.toggle_show_hours.assert_called_once()

    def test_tgl_hour_alias(self, interp):
        i, forms = interp
        i.command_process("tgl hour")
        forms.toggle_show_hours.assert_called_once()

    def test_tgl_fy_calls_toggle_fullyear(self, interp):
        i, forms = interp
        i.command_process("tgl fy")
        forms.toggle_show_full_year.assert_called_once()

    def test_tgl_fullyear_alias(self, interp):
        i, forms = interp
        i.command_process("tgl fullyear")
        forms.toggle_show_full_year.assert_called_once()

    def test_tgl_no_args_prints_syntax(self, interp, capsys):
        i, forms = interp
        i.command_process("tgl")
        forms.toggle_show_hours.assert_not_called()
        forms.toggle_show_full_year.assert_not_called()
        assert "Syntax" in capsys.readouterr().out


# ########## #
#   BACKUP   #
# ########## #

class TestBackupCommand:
    def test_bk_calls_backup(self, interp):
        i, forms = interp
        i.command_process("bk")
        forms.backup_database.assert_called_once()

    def test_bkp_alias(self, interp):
        i, forms = interp
        i.command_process("bkp")
        forms.backup_database.assert_called_once()

    def test_backup_alias(self, interp):
        i, forms = interp
        i.command_process("backup")
        forms.backup_database.assert_called_once()


# ########### #
#   CONNECT   #
# ########### #

class TestConnectCommand:
    def test_conn_calls_connect(self, interp):
        i, forms = interp
        i.command_process("conn")
        forms.connect_to_database.assert_called_once()

    def test_connect_alias(self, interp):
        i, forms = interp
        i.command_process("connect")
        forms.connect_to_database.assert_called_once()
