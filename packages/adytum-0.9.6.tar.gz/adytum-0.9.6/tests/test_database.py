#!/usr/bin/env python3

import os
import sqlite3

import pytest

from adytum.storage.cipher import Cipher
from adytum.storage.database import Database, SALT_SIZE


def _make_db(password):
    db = Database()
    db.set_encryption_motor(Cipher(password))
    return db


class TestDatabaseRoundTrip:
    def test_write_read_round_trip(self, tmp_db_path):
        conn = sqlite3.connect(":memory:")
        conn.execute("CREATE TABLE t (x TEXT)")
        conn.execute("INSERT INTO t VALUES ('hello')")
        conn.commit()

        _make_db("password").write_file_from_imdb(conn, str(tmp_db_path))

        conn2 = _make_db("password").read_file_to_imdb(str(tmp_db_path))
        assert conn2.execute("SELECT * FROM t").fetchall() == [("hello",)]

    def test_file_starts_with_salt(self, tmp_db_path):
        conn = sqlite3.connect(":memory:")
        conn.commit()
        _make_db("password").write_file_from_imdb(conn, str(tmp_db_path))

        with open(tmp_db_path, "rb") as f:
            data = f.read()
        assert len(data) > SALT_SIZE

    def test_fresh_salt_per_write(self, tmp_db_path):
        conn = sqlite3.connect(":memory:")
        conn.commit()

        _make_db("password").write_file_from_imdb(conn, str(tmp_db_path))
        with open(tmp_db_path, "rb") as f:
            salt1 = f.read(SALT_SIZE)

        conn2 = sqlite3.connect(":memory:")
        conn2.commit()
        _make_db("password").write_file_from_imdb(conn2, str(tmp_db_path))
        with open(tmp_db_path, "rb") as f:
            salt2 = f.read(SALT_SIZE)

        assert salt1 != salt2

    def test_wrong_password_raises(self, tmp_db_path):
        conn = sqlite3.connect(":memory:")
        conn.commit()
        _make_db("correct").write_file_from_imdb(conn, str(tmp_db_path))

        with pytest.raises(Exception):
            _make_db("wrong").read_file_to_imdb(str(tmp_db_path))

    def test_no_tmp_file_after_write(self, tmp_db_path):
        conn = sqlite3.connect(":memory:")
        conn.commit()
        _make_db("password").write_file_from_imdb(conn, str(tmp_db_path))

        assert not os.path.exists(str(tmp_db_path) + ".tmp")
