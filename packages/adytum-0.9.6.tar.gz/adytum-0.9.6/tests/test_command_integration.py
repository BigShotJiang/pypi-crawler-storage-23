#!/usr/bin/env python3

"""Integration tests for command flows: Interpreter -> Forms -> QueriesManager -> SQLite."""

import pytest
from collections import deque
from contextlib import contextmanager
from unittest.mock import patch

from adytum.command_interpreter import Interpreter
from adytum.forms import Forms
from adytum.storage.sql_queries import QueriesManager


_TS = 1_000_000


# ############# #
#   FIXTURES    #
# ############# #

@pytest.fixture
def real_interp(tmp_path):
    """Full stack: real Interpreter -> Forms -> QueriesManager -> SQLite in tmp_path."""
    qm = QueriesManager(encryption=False)
    qm.set_database_path(str(tmp_path / "test.db"))
    qm.create_database()

    forms = Forms(qm)
    interp = Interpreter(forms=forms, program_name="adytum")
    return interp


def _seed(interp, **kwargs):
    """Insert a row directly, bypassing the interactive form."""
    defaults = dict(
        name="acme",
        email="acme@x.com",
        username="admin",
        password="s3cr3t",
        project="proj",
        web="http://acme.com",
        creation_timestamp=_TS,
        last_modification_timestamp=_TS + 1,
        comments="no comments",
    )
    defaults.update(kwargs)
    interp.forms.queries_manager.add_account(**defaults)


def _all_rows(interp):
    return interp.forms.queries_manager.list_element("Accounts", "Id")


@contextmanager
def _mock_inputs(*values):
    """Patch input() to feed *values one by one in order."""
    q = deque(values)
    getter = lambda _: q.popleft()
    with patch("builtins.input", side_effect=getter):
        yield


# ########## #
#   CREATE   #
# ########## #

class TestMakeIntegration:
    def test_mk_creates_account_in_db(self, real_interp):
        # add_account asks: name, email, username, password, confirm, project, web, comments, confirm
        with _mock_inputs("acme", "a@a.com", "user", "pass", "pass", "proj", "web.com", "ok", ""):
            real_interp.command_process("mk")
        rows = _all_rows(real_interp)
        assert len(rows) == 1
        assert rows[0][1] == "acme"

    def test_mk_with_retry_creates_account(self, real_interp):
        # First iteration the user types "N" to redo, second iteration confirms with ""
        inputs = (
            "name1", "e@e.com", "u", "p", "p", "proj", "web", "c", "N",  # first pass, reject
            "name2", "e@e.com", "u", "p", "p", "proj", "web", "c", "",  # second pass, confirm
        )
        with _mock_inputs(*inputs):
            real_interp.command_process("create")
        rows = _all_rows(real_interp)
        assert len(rows) == 1
        assert rows[0][1] == "name2"

    def test_mk_abort_via_exit_form_leaves_db_empty(self, real_interp):
        with _mock_inputs("exit_form"):
            real_interp.command_process("mk")
        assert _all_rows(real_interp) == []


# ########## #
#   LIST     #
# ########## #

class TestListIntegration:
    def test_ls_shows_seeded_account(self, real_interp, capsys):
        _seed(real_interp, name="acme")
        real_interp.command_process("ls")
        assert "acme" in capsys.readouterr().out

    def test_ls_range_filters_rows(self, real_interp, capsys):
        _seed(real_interp, name="one")
        _seed(real_interp, name="two")
        _seed(real_interp, name="nope")
        # ":2" -> after=2 -> WHERE Id <= 2 -> only first two rows
        real_interp.command_process("ls :2")
        out = capsys.readouterr().out
        assert "one" in out
        assert "two" in out
        assert "nope" not in out

    def test_ls_name_like_filter(self, real_interp, capsys):
        _seed(real_interp, name="github")
        _seed(real_interp, name="gitlab")
        _seed(real_interp, name="bitbucket")
        real_interp.command_process("ls name %git%")
        out = capsys.readouterr().out
        assert "github" in out
        assert "gitlab" in out
        assert "bitbucket" not in out

    def test_ls_email_like_filter(self, real_interp, capsys):
        _seed(real_interp, name="work", email="me@work.com")
        _seed(real_interp, name="personal", email="me@personal.com")
        real_interp.command_process("ls email %work%")
        out = capsys.readouterr().out
        assert "work" in out
        assert "personal" not in out

    def test_ls_empty_db_prints_nothing_harmful(self, real_interp, capsys):
        real_interp.command_process("ls")
        # Should not raise; output may be empty or a header
        capsys.readouterr()


# ########## #
#   REMOVE   #
# ########## #

class TestRemoveIntegration:
    def test_rm_deletes_account(self, real_interp):
        _seed(real_interp)
        with _mock_inputs(""):   # ENTER = confirm
            real_interp.command_process("rm 1")
        assert _all_rows(real_interp) == []

    def test_rm_abort_via_N_keeps_account(self, real_interp):
        _seed(real_interp)
        with _mock_inputs("N"):
            real_interp.command_process("rm 1")
        assert len(_all_rows(real_interp)) == 1

    def test_rm_abort_via_exit_form_keeps_account(self, real_interp):
        _seed(real_interp)
        with _mock_inputs("exit_form"):
            real_interp.command_process("rm 1")
        assert len(_all_rows(real_interp)) == 1

    def test_rm_nonexistent_id_still_calls_form(self, real_interp, capsys):
        # No rows seeded; remove_account will list nothing but not crash
        with _mock_inputs("N"):
            real_interp.command_process("rm 99")
        capsys.readouterr()


# ########## #
#   SET      #
# ########## #

class TestSetIntegration:
    # set_element flow: "" (confirm to edit), new_value, "" (verify)

    def test_set_name_updates_db(self, real_interp):
        _seed(real_interp, name="old_name")
        with _mock_inputs("", "new_name", ""):
            real_interp.command_process("set 1 name")
        assert _all_rows(real_interp)[0][1] == "new_name"

    def test_set_email_updates_db(self, real_interp):
        _seed(real_interp, email="old@x.com")
        with _mock_inputs("", "new@x.com", ""):
            real_interp.command_process("set 1 email")
        assert _all_rows(real_interp)[0][2] == "new@x.com"

    def test_set_username_updates_db(self, real_interp):
        _seed(real_interp, username="olduser")
        with _mock_inputs("", "newuser", ""):
            real_interp.command_process("set 1 usr")
        assert _all_rows(real_interp)[0][3] == "newuser"

    def test_set_pass_updates_db(self, real_interp):
        _seed(real_interp, password="oldpass")
        with _mock_inputs("", "newpass", "newpass", ""):
            real_interp.command_process("set 1 pass")
        assert _all_rows(real_interp)[0][4] == "newpass"

    def test_set_project_updates_db(self, real_interp):
        _seed(real_interp, project="oldproj")
        with _mock_inputs("", "newproj", ""):
            real_interp.command_process("set 1 p")
        assert _all_rows(real_interp)[0][5] == "newproj"

    def test_set_web_updates_db(self, real_interp):
        _seed(real_interp, web="http://old.com")
        with _mock_inputs("", "http://new.com", ""):
            real_interp.command_process("set 1 web")
        assert _all_rows(real_interp)[0][6] == "http://new.com"

    def test_set_abort_via_N_keeps_old_value(self, real_interp):
        _seed(real_interp, name="original")
        with _mock_inputs("N"):   # user declines at the first confirmation
            real_interp.command_process("set 1 name")
        assert _all_rows(real_interp)[0][1] == "original"

    def test_set_abort_via_exit_form_keeps_old_value(self, real_interp):
        _seed(real_interp, name="original")
        with _mock_inputs("exit_form"):
            real_interp.command_process("set 1 name")
        assert _all_rows(real_interp)[0][1] == "original"

    def test_set_nonexistent_id_prints_not_found(self, real_interp, capsys):
        real_interp.command_process("set 99 name")
        assert "NO ENTRY" in capsys.readouterr().out

    def test_set_id_only_update_all(self, real_interp):
        _seed(real_interp)
        # update_all flow: "" (confirm), then all 9 fields (password entered twice), then "" (verify)
        inputs = ("", "newname", "new@e.com", "newuser", "newpass", "newpass",
                  "newproj", "http://new.com", "01/01/2024", "02/01/2024",
                  "newcomment", "")
        with _mock_inputs(*inputs):
            real_interp.command_process("set 1")
        row = _all_rows(real_interp)[0]
        assert row[1] == "newname"
        assert row[2] == "new@e.com"
        assert row[3] == "newuser"


# ########## #
#   TOGGLE   #
# ########## #

class TestTogglePasswordVisibility:
    @pytest.fixture(autouse=True)
    def reset_pw_visibility(self):
        import adytum.helpers as helpers
        helpers._show_password = True
        yield
        helpers._show_password = True

    def test_tgl_pv_first_toggle_prints_hidden(self, real_interp, capsys):
        # Default is visible; one toggle -> hidden.
        real_interp.command_process("tgl pv")
        assert "hidden" in capsys.readouterr().out

    def test_tgl_pv_second_toggle_prints_visible(self, real_interp, capsys):
        # Two toggles from visible: visible -> hidden -> visible.
        real_interp.command_process("tgl pv")
        capsys.readouterr()  # discard first toggle output
        real_interp.command_process("tgl pv")
        assert "visible" in capsys.readouterr().out


# ###################### #
#   PASSWORD CONFIRM     #
# ###################### #

class TestPasswordConfirmation:
    def test_mk_mismatch_then_match_creates_account(self, real_interp):
        # First two passwords don't match -> retry; second pair matches
        inputs = (
            "acme", "a@a.com", "user",
            "pass1", "WRONG",        # mismatch -> retry
            "pass2", "pass2",        # match
            "proj", "web.com", "ok", ""
        )
        with _mock_inputs(*inputs):
            real_interp.command_process("mk")
        rows = _all_rows(real_interp)
        assert len(rows) == 1
        assert rows[0][4] == "pass2"
