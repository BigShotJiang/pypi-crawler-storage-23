#!/usr/bin/env python3

from adytum.renderer import Renderer
from adytum.renderer import print_rows


class TestRendererBuildFmt:
    def test_default(self):
        assert Renderer()._fmt == "DD-MM-YYYY"

    def test_short_year(self):
        r = Renderer()
        r.show_full_year = False
        assert r._build_fmt() == "DD-MM-YY"

    def test_with_hours(self):
        r = Renderer()
        r.show_hours = True
        assert r._build_fmt() == "DD-MM-YYYY HH:mm:ss"

    def test_short_year_with_hours(self):
        r = Renderer()
        r.show_full_year = False
        r.show_hours = True
        assert r._build_fmt() == "DD-MM-YY HH:mm:ss"


class TestRendererToggle:
    def test_toggle_show_hours(self, capsys):
        r = Renderer()
        assert r.show_hours is False
        r.toggle_show_hours()
        assert r.show_hours is True
        assert r._fmt == r._build_fmt()
        r.toggle_show_hours()
        assert r.show_hours is False

    def test_toggle_show_full_year(self, capsys):
        r = Renderer()
        assert r.show_full_year is True
        r.toggle_show_full_year()
        assert r.show_full_year is False
        assert r._fmt == r._build_fmt()
        r.toggle_show_full_year()
        assert r.show_full_year is True


class TestConvertTimestamps:
    _ROW = (1, "name", "email", "user", "pass", "proj", "web", 1_000_000, 1_000_001, "comment")

    def test_timestamp_columns_converted_to_str(self):
        r = Renderer()
        result = r._convert_timestamps([self._ROW])
        assert isinstance(result[0][7], str)
        assert isinstance(result[0][8], str)

    def test_other_columns_unchanged(self):
        r = Renderer()
        result = r._convert_timestamps([self._ROW])[0]
        assert result[0] == 1
        assert result[6] == "web"
        assert result[9] == "comment"

    def test_uses_current_fmt(self):
        r = Renderer()
        r.show_full_year = True
        r._fmt = r._build_fmt()
        result = r._convert_timestamps([self._ROW])[0]
        # Full year format includes 4-digit year
        assert len(result[7]) > len("DD-MM-YY")


class TestPrintRows:
    def test_prints_separator_and_rows(self, capsys):
        dataset = [(1, "a", "b"), (2, "c", "d")]
        print_rows(dataset, output_field=0)
        out = capsys.readouterr().out
        assert "*" * 50 in out
        assert "1" in out
        assert "2" in out

    def test_out_of_range_field_prints_only_separator(self, capsys):
        dataset = [(1, "a")]
        print_rows(dataset, output_field=99)
        out = capsys.readouterr().out
        assert "*" * 50 in out
        assert "1" not in out
