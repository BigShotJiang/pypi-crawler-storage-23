#!/usr/bin/env python3

import pytest

from adytum.storage.sql_queries import _validate_identifiers
from adytum.storage.sql_queries import _ALLOWED_COLUMNS


class TestValidateIdentifiers:
    def test_valid_table_and_columns(self):
        _validate_identifiers("Accounts", "Id", "Name")  # no exception

    def test_invalid_table(self):
        with pytest.raises(ValueError, match="Table"):
            _validate_identifiers("Users", "Id")

    def test_invalid_column(self):
        with pytest.raises(ValueError, match="Column"):
            _validate_identifiers("Accounts", "DROP")

    def test_all_allowed_columns(self):
        for col in _ALLOWED_COLUMNS:
            _validate_identifiers("Accounts", col)  # no exception


class TestDatabaseController:
    _TS = 1_000_000

    def _add(self, qm, name="acc", **kwargs):
        defaults = dict(
            name=name,
            email="e@e.com",
            username="user",
            password="pass",
            project="proj",
            web="http://x.com",
            creation_timestamp=self._TS,
            last_modification_timestamp=self._TS + 1,
            comments="comment",
        )
        defaults.update(kwargs)
        qm.add_account(**defaults)

    def test_create_database(self, qm):
        qm.create_database()
        rows = qm.execute_query(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='Accounts'"
        )
        assert rows[0][0] == "Accounts"

    def test_add_and_list(self, qm):
        qm.create_database()
        self._add(qm)
        rows = qm.list_element("Accounts", "Id")
        assert len(rows) == 1

    def test_list_element_with_range(self, qm):
        qm.create_database()
        self._add(qm)
        assert len(qm.list_element("Accounts", "Id", before=0, after=10)) == 1
        assert len(qm.list_element("Accounts", "Id", before=10, after=20)) == 0

    def test_list_element_no_args_returns_all(self, qm):
        qm.create_database()
        self._add(qm, name="a")
        self._add(qm, name="b")
        assert len(qm.list_element("Accounts", "Id")) == 2

    def test_list_element_like(self, qm):
        qm.create_database()
        self._add(qm, name="alpha")
        self._add(qm, name="beta")
        rows = qm.list_element_like("Accounts", "Name", "alp%")
        assert len(rows) == 1
        assert rows[0][1] == "alpha"

    def test_check_max_in_table(self, qm):
        qm.create_database()
        self._add(qm)
        self._add(qm)
        assert qm.check_max_in_table("Id", "Accounts") == 2

    def test_check_if_id_exists(self, qm):
        qm.create_database()
        self._add(qm)
        assert qm.check_if_id_exists_in_table("Accounts", 1) is True
        assert qm.check_if_id_exists_in_table("Accounts", 99) is False

    def test_set_element(self, qm):
        qm.create_database()
        self._add(qm)
        qm.set_element("Accounts", "Name", "new_name", "Id", 1)
        rows = qm.list_element("Accounts", "Id")
        assert rows[0][1] == "new_name"

    def test_update_all(self, qm):
        qm.create_database()
        self._add(qm)
        qm.update_all(
            name="updated",
            email="new@e.com",
            username="newuser",
            password="newpass",
            project="newproj",
            web="http://new.com",
            creation_timestamp=self._TS,
            last_modification_timestamp=self._TS + 100,
            comments="new comment",
            account_id=1,
        )
        rows = qm.list_element("Accounts", "Id")
        assert rows[0][1] == "updated"
        assert rows[0][2] == "new@e.com"

    def test_remove_account(self, qm):
        qm.create_database()
        self._add(qm)
        qm.remove_account(1)
        assert len(qm.list_element("Accounts", "Id")) == 0
