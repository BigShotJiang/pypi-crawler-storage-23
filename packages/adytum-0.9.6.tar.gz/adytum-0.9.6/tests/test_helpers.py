#!/usr/bin/env python3

import pytest

import string

from adytum.helpers import (
    ExitFormError,
    generate_random_string,
    normalise_date,
    is_date,
    is_complete_hour,
    date_to_unix_timestamp,
    convert_date_range,
)


class TestGenerateRandomString:
    def test_default_length(self):
        assert len(generate_random_string()) == 20

    def test_custom_length(self):
        assert len(generate_random_string(32)) == 32

    def test_minimum_length(self):
        assert len(generate_random_string(4)) == 4

    def test_below_minimum_raises(self):
        with pytest.raises(ValueError):
            generate_random_string(3)

    def test_contains_lowercase(self):
        pw = generate_random_string(20)
        assert any(c in string.ascii_lowercase for c in pw)

    def test_contains_uppercase(self):
        pw = generate_random_string(20)
        assert any(c in string.ascii_uppercase for c in pw)

    def test_contains_digit(self):
        pw = generate_random_string(20)
        assert any(c in string.digits for c in pw)

    def test_contains_special(self):
        special = "!@%-_=+:."
        pw = generate_random_string(20)
        assert any(c in special for c in pw)

    def test_randomness(self):
        passwords = {generate_random_string() for _ in range(20)}
        assert len(passwords) > 1


class TestNormaliseDate:
    def test_slash(self):
        assert normalise_date("01/05/2024") == "01-05-2024"

    def test_colon(self):
        assert normalise_date("01:05:2024") == "01-05-2024"

    def test_dot(self):
        assert normalise_date("01.05.2024") == "01-05-2024"

    def test_at(self):
        assert normalise_date("01@05@2024") == "01-05-2024"


class TestIsDate:
    def test_valid_date(self):
        ok, fmt = is_date("01-05-2024")
        assert ok is True
        assert fmt == "DD-MM-YYYY"

    def test_valid_datetime(self):
        ok, fmt = is_date("01-05-2024 10-30-00")
        assert ok is True
        assert fmt == "DD-MM-YYYY HH-mm-ss"

    def test_invalid(self):
        ok, fmt = is_date("not-a-date")
        assert ok is False
        assert fmt == ""

    def test_accepts_separator_variants(self):
        ok, _ = is_date("01/05/2024")
        assert ok is True


class TestIsCompleteHour:
    def test_full_hour(self):
        assert is_complete_hour("10:30:00") is True

    def test_short_hour(self):
        assert is_complete_hour("10:30") is True

    def test_invalid_hour(self):
        assert is_complete_hour("25:00") is False

    def test_non_hour(self):
        assert is_complete_hour("abc") is False


class TestDateToUnixTimestamp:
    def test_valid_date_returns_float(self):
        result = date_to_unix_timestamp("01-05-2024")
        assert isinstance(result, float)

    def test_invalid_no_exception(self, capsys):
        with pytest.raises(ExitFormError):
            date_to_unix_timestamp("invalid", exception=False)
        assert "INVALID DATE" in capsys.readouterr().out

    def test_invalid_with_exception(self):
        with pytest.raises(Exception, match="INVALID DATE"):
            date_to_unix_timestamp("invalid", exception=True)


class TestConvertDateRange:
    def test_both_valid(self):
        before, after = convert_date_range("01-01-2024", "31-12-2024")
        assert isinstance(before, float)
        assert isinstance(after, float)
        assert before < after

    def test_before_none(self):
        before, after = convert_date_range(None, "01-01-2024")
        assert before is None
        assert isinstance(after, float)

    def test_both_none(self):
        assert convert_date_range(None, None) == (None, None)
