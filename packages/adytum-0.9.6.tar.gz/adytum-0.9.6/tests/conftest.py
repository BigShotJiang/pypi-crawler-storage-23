#!/usr/bin/env python3

import pytest


@pytest.fixture(autouse=True)
def fast_cipher(monkeypatch):
    """Patch PBKDF2 iterations to 1 to keep the test suite fast."""
    import adytum.storage.cipher as cipher_mod

    monkeypatch.setattr(cipher_mod, "PBKDF2_ITERATIONS", 1)


@pytest.fixture
def tmp_db_path(tmp_path):
    """Temporary .ec file path."""
    return tmp_path / "test.ec"


@pytest.fixture
def qm(tmp_path):
    """QueriesManager with encryption disabled for fast tests."""
    from adytum.storage.sql_queries import QueriesManager

    instance = QueriesManager(encryption=False)
    instance.set_database_path(str(tmp_path / "test.db"))
    return instance
