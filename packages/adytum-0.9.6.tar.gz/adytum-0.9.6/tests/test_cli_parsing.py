#!/usr/bin/env python3

from adytum.cli_parsing import (
    index_is_in_list,
    parse_range,
    parse_quotations,
    parse_output_field,
)


class TestIndexIsInList:
    def test_valid_positive(self):
        assert index_is_in_list([1, 2, 3], 0) is True
        assert index_is_in_list([1, 2, 3], 2) is True

    def test_beyond_length(self):
        assert index_is_in_list([1, 2, 3], 3) is False
        assert index_is_in_list([1, 2, 3], 10) is False

    def test_valid_negative(self):
        assert index_is_in_list([1, 2, 3], -1) is True
        assert index_is_in_list([1, 2, 3], -3) is True

    def test_negative_out_of_range(self):
        assert index_is_in_list([1, 2, 3], -4) is False


class TestParseRange:
    def test_two_values(self):
        assert parse_range(["1", "5"]) == ("1", "5")

    def test_open_right(self):
        assert parse_range(["1:"]) == ("1", None)

    def test_open_left(self):
        assert parse_range([":5"]) == (None, "5")

    def test_enclosed(self):
        assert parse_range([":2:"]) == ("2", "2")

    def test_double_colon_prints_error(self, capsys):
        result = parse_range(["::"])
        assert "Syntax" in capsys.readouterr().out
        # "::" strips to "" on both sides
        assert result == ("", "")

    def test_empty_list_prints_error(self, capsys):
        result = parse_range([])
        assert "Syntax" in capsys.readouterr().out
        assert result == (None, None)

    def test_arg_pos_offset(self):
        assert parse_range(["x", "3", "7"], arg_pos=1) == ("3", "7")


class TestParseQuotations:
    def test_no_quotes(self):
        assert parse_quotations("hello", ["hello"]) == "hello"

    def test_with_quotes(self):
        result = parse_quotations('"hello world"', ['"hello world"'])
        assert result == "hello world"

    def test_empty_tokens(self):
        assert parse_quotations("", []) == ""


class TestParseOutputField:
    def test_valid_index(self):
        assert parse_output_field(["ls", "r", "name", "3"], idx=3) == 3

    def test_dot_shorthand(self):
        assert parse_output_field(["ls", "r", "name", "."], idx=3) == 9

    def test_list_too_short(self):
        assert parse_output_field(["ls", "r"], idx=3) is None

    def test_non_integer(self):
        assert parse_output_field(["ls", "r", "name", "x"], idx=3) is None
