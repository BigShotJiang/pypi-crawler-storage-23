#!/usr/bin/env python3

import os

import pytest

from adytum.storage.cipher import str_to_bytes, derive_key, Cipher


class TestStrToBytes:
    def test_str_input(self):
        assert str_to_bytes("hello") == b"hello"

    def test_bytes_input(self):
        assert str_to_bytes(b"hello") == b"hello"


class TestDeriveKey:
    def test_determinism(self):
        salt = b"a" * 32
        assert derive_key(b"password", salt) == derive_key(b"password", salt)

    def test_different_salt(self):
        k1 = derive_key(b"password", b"a" * 32)
        k2 = derive_key(b"password", b"b" * 32)
        assert k1 != k2

    def test_different_password(self):
        salt = b"a" * 32
        assert derive_key(b"password1", salt) != derive_key(b"password2", salt)

    def test_returns_32_bytes(self):
        key = derive_key(b"password", os.urandom(32))
        assert len(key) == 32


class TestCipher:
    def _make_cipher(self, password="password"):
        c = Cipher(password)
        c.set_salt(os.urandom(32))
        return c

    def test_round_trip_bytes(self):
        c = self._make_cipher()
        assert c.decrypt(c.encrypt(b"hello")) == b"hello"

    def test_round_trip_string(self):
        c = self._make_cipher()
        assert c.decrypt(c.encrypt("hello")) == b"hello"

    def test_wrong_salt_raises(self):
        c = Cipher("password")
        c.set_salt(os.urandom(32))
        ciphertext = c.encrypt(b"hello")

        c2 = Cipher("password")
        c2.set_salt(os.urandom(32))
        with pytest.raises(Exception):
            c2.decrypt(ciphertext)

    def test_wrong_password_raises(self):
        salt = os.urandom(32)
        c = Cipher("correct")
        c.set_salt(salt)
        ciphertext = c.encrypt(b"hello")

        c2 = Cipher("wrong")
        c2.set_salt(salt)
        with pytest.raises(Exception):
            c2.decrypt(ciphertext)

    def test_encrypt_before_set_salt_raises(self):
        c = Cipher("password")
        with pytest.raises(RuntimeError, match="set_salt"):
            c.encrypt("data")
