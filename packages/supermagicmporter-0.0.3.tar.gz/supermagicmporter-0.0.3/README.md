# 🚀 supermagicmporter

This module dynamically adds your project's root directory to `sys.path`. It allows you to perform clean imports from neighboring folders or subdirectories without struggling with relative import errors.

---

## 🛠 Installation

```bash
pip install supermagicmporter
```
📖 How to Use
To use this module, you need to call set_root_folder at the very beginning of your main script.
```python
from supermagicmporter import set_root_folder

# Initialize the root path
# Pass __file__ to automatically detect the current script's location
set_root_folder(__file__, 'yourRootFolder')

# Now you can import from your project folders easily
from my_subfolder import my_module
```

## Arguments
|Args|Description|
|----|-----------|
|file|Provides the current script's path. By passing the `__file__` magic variable, the location is automatically resolved.|
|root_folder_name|The exact name of your project's root directory as a string.|
----
⚠️ `Important Notes`
Memory Storage: The set_root_folder function stores the absolute path of the target folder in Python's memory for the duration of the session.

Import Order: From the line set_root_folder onwards, your project structure is prioritized. If you need to import standard Python libraries or other installed packages that might have name conflicts, perform those imports before calling this function.

Path Resolution: Ensure the root_folder_name matches your directory casing exactly.