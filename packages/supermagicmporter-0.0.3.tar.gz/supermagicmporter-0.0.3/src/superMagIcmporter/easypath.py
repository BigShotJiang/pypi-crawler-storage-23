import sys,os
def set_root_folder(file,root_folder_name:str):
    p = os.path.abspath(os.path.dirname(file))
    [p := os.path.dirname(p) for _ in range(10) if os.path.basename(p) != root_folder_name]
    sys.path.insert(0, p)