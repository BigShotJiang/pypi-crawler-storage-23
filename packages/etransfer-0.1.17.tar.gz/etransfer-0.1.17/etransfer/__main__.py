"""Main entry point for etransfer CLI."""

from etransfer.client.cli import app

if __name__ == "__main__":
    app()
