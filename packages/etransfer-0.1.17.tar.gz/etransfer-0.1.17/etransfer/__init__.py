"""EasyTransfer - TUS-based file transfer tool."""

__version__ = "0.1.17"
__author__ = "ETransfer Team"
