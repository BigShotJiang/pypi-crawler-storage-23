"""pytest-paia-blockly: pytest plugin for verifying get_solution() against test cases."""

__version__ = "0.1.0"
