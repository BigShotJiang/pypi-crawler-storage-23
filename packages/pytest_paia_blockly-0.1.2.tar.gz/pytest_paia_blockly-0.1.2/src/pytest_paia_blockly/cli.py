"""
Console script：直接執行套件內的 test_framework（test_verify_case），
讓使用者不需手動指定測試檔路徑。
"""

import subprocess
import sys
from pathlib import Path


def main() -> int:
    pkg_dir = Path(__file__).resolve().parent
    test_framework = pkg_dir / "test_framework.py"
    argv = [sys.executable, "-m", "pytest", str(test_framework)] + sys.argv[1:]
    return subprocess.run(argv).returncode


if __name__ == "__main__":
    sys.exit(main())
