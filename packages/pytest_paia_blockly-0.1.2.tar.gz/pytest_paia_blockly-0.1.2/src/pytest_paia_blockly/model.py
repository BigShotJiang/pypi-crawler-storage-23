import re
from typing import Any, Literal

from pydantic import BaseModel


ExpectedType = Literal["bool", "int", "float", "str", "list", "dict"]

EXPECTED_TYPE_PY_MAP: dict[str, type] = {
    "bool": bool,
    "int": int,
    "float": float,
    "str": str,
    "list": list,
    "dict": dict,
}

# spec.json 用：允許的型別字串 及 list<item> 語法
EXPECTED_TYPE_NAMES = frozenset(EXPECTED_TYPE_PY_MAP)


def is_valid_spec_type(type_str: ExpectedType) -> bool:
    """spec 用型別字串是否合法（primitive 或 list<...>）。"""
    return type_str in EXPECTED_TYPE_PY_MAP


class ExpectedAnswer(BaseModel):
    """預期答案：type 僅限六種型別，value 為對應型別的值。"""

    type: ExpectedType
    value: Any


class VerifyCase(BaseModel):
    """單筆測資：input 僅允許 JSON object，直接丟入 get_solution(input)。"""

    index: int = 0
    input: dict
    expected: ExpectedAnswer


class VerifyResult(VerifyCase):
    output: Any
    is_verified: bool
    execution_time: float = 0.0  # ms
    cpu_consumption: float = 0.0
    memory_usage: int = 0  # KiB
