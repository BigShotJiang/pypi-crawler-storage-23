"""支援 python -m pytest_paia_blockly 啟動（等同 paia-blockly-test）。"""
from pytest_paia_blockly.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
