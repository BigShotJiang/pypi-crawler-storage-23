"""
pytest-paia-blockly plugin
--------------------------
三個命令列選項：
  --paia-target-module  solution.py 的檔案路徑（必填）
  --paia-testcases      case.json 的路徑（必填）
  --paia-result         結果輸出路徑（預設 ./var/paia_result.json）

兩個必填參數任一未提供 → test_verify_case 參數化為 0 筆（no tests collected），不 fail。
"""

import importlib.util
import json
from pathlib import Path

import pytest

from pytest_paia_blockly.model import ExpectedAnswer, VerifyCase

_xdist_active: bool = False


class _PaiaState:
    """每個 pytest session 有獨立的 state 實例，避免跨 session（pytester）資料污染。"""

    def __init__(self):
        self.results: list = []
        self.xdist_active: bool = False


def pytest_configure(config) -> None:
    """初始化 session-level state。xdist 偵測延後到 pytest_sessionstart，
    以確保 -n 選項已被解析（pytest_configure 時 options 尚未完全初始化）。"""
    config._paia_state = _PaiaState()


def pytest_sessionstart(session) -> None:
    """偵測 xdist 是否真正被啟用（有 -n / --numprocesses > 0）。"""
    config = session.config
    state: _PaiaState = getattr(config, "_paia_state", None)
    if state is None:
        return
    try:
        numprocesses = config.getoption("numprocesses", default=0)
    except (ValueError, AttributeError):
        numprocesses = 0
    if numprocesses and numprocesses != "no":
        state.xdist_active = True
        import warnings
        warnings.warn(
            "pytest-paia-blockly: xdist 並行模式下 --paia-result 結果蒐集功能無法使用，"
            "請勿同時使用 -n / --numprocesses。",
            UserWarning,
            stacklevel=2,
        )


def pytest_addoption(parser) -> None:
    group = parser.getgroup("paia-blockly", "PAIA Blockly verification options")
    group.addoption(
        "--paia-target-module",
        default=None,
        metavar="PATH",
        help="solution.py 的檔案路徑（必填）。模組需提供 get_solution(input: dict) callable。",
    )
    group.addoption(
        "--paia-testcases",
        default=None,
        metavar="PATH",
        help="case.json 的路徑（必填）。格式：[{index, input, expected: {type, value}}, ...]",
    )
    group.addoption(
        "--paia-result",
        default="./var/paia_result.json",
        metavar="PATH",
        help="結果 JSON 輸出路徑（預設 ./var/paia_result.json）。",
    )


def _resolve(config, option: str) -> Path | None:
    raw = config.getoption(option, default=None)
    if not raw:
        return None
    p = Path(raw)
    return p if p.is_absolute() else Path(config.rootdir) / p


def _load_solution(path: Path):
    """從 .py 檔案路徑載入 get_solution callable。"""
    spec = importlib.util.spec_from_file_location("_paia_target_solution", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "get_solution") or not callable(getattr(mod, "get_solution")):
        pytest.fail(f"solution 模組 {path} 需提供 callable 的 get_solution")
    return getattr(mod, "get_solution")


def _load_cases(path: Path) -> list[VerifyCase]:
    """從 case.json 載入 VerifyCase 列表。"""
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        pytest.fail(f"--paia-testcases 非合法 JSON：{path}。錯誤：{e}")
    if not isinstance(data, list):
        pytest.fail(f"--paia-testcases 必須為 JSON array：{path}")
    cases: list[VerifyCase] = []
    for i, c in enumerate(data):
        if not isinstance(c.get("input"), dict):
            pytest.fail(f"Case 的 input 必須為 JSON object，第 {i + 1} 筆：{c}")
        exp = c.get("expected", {})
        if not isinstance(exp, dict) or "type" not in exp or "value" not in exp:
            pytest.fail(f"Case 的 expected 必須為 {{type, value}}，第 {i + 1} 筆：{c}")
        cases.append(
            VerifyCase(
                index=c.get("index", i + 1),
                input=c["input"],
                expected=ExpectedAnswer(**exp),
            )
        )
    return cases


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def paia_target_func(request):
    """載入 --paia-target-module 的 get_solution。未提供時回傳 None（test_verify_case 會 skip）。"""
    path = _resolve(request.config, "--paia-target-module")
    if path is None:
        return None
    if not path.exists():
        pytest.fail(f"--paia-target-module 檔案不存在：{path}")
    return _load_solution(path)


@pytest.fixture(scope="session")
def paia_result_file(request) -> str:
    raw = request.config.getoption("--paia-result", default="./var/paia_result.json")
    p = Path(raw)
    if not p.is_absolute():
        p = Path(request.config.rootdir) / p
    return str(p)


@pytest.fixture(scope="session")
def paia_results_collector(request) -> list:
    """收集每筆 case 的驗證結果，session 結束時寫入 --paia-result。"""
    return request.config._paia_state.results


# ── parametrize ───────────────────────────────────────────────────────────────

def _cases_for_parametrize(config) -> list[VerifyCase] | None:
    """讀取 case 列表；任一必填選項缺少或檔案不存在時回傳 None。"""
    target = config.getoption("--paia-target-module", default=None)
    testcases = config.getoption("--paia-testcases", default=None)
    if not target or not testcases:
        return None
    path = _resolve(config, "--paia-testcases")
    if path is None or not path.exists():
        return None
    return _load_cases(path)


def pytest_generate_tests(metafunc) -> None:
    """僅對 test_verify_case（需使用 paia_case fixture）做 case 參數化。"""
    if "paia_case" not in metafunc.fixturenames:
        return
    # 允許 pytest_paia_blockly.test_framework 與 pytester 子 session 中的 test_framework 模組
    mod_name: str = metafunc.definition.module.__name__
    if not (mod_name == "pytest_paia_blockly.test_framework" or mod_name.endswith("test_framework")):
        return
    cases = _cases_for_parametrize(metafunc.config)
    if not cases:
        metafunc.parametrize("paia_case", [], ids=[])
        return
    ids = [f"case{c.index}" for c in cases]
    metafunc.parametrize("paia_case", cases, ids=ids)


# ── report metadata ───────────────────────────────────────────────────────────

@pytest.hookimpl(optionalhook=True)
def pytest_json_runtest_metadata(item, call) -> dict:
    """將 paia_case 的 input / expected 寫入 pytest-json-report 的 metadata。"""
    if call.when != "call":
        return {}
    case = item.funcargs.get("paia_case", None)
    if case is None or not hasattr(case, "input"):
        return {}
    return {
        "input": case.input,
        "expected": case.expected.model_dump(mode="json"),
    }


# ── session finish ─────────────────────────────────────────────────────────────

def pytest_sessionfinish(session, exitstatus) -> None:
    """Session 結束時將蒐集到的結果寫入 --paia-result。"""
    config = session.config
    state: _PaiaState = getattr(config, "_paia_state", None)
    if state is None or state.xdist_active or not state.results:
        return
    raw = config.getoption("--paia-result", default="./var/paia_result.json")
    p = Path(raw)
    if not p.is_absolute():
        p = Path(config.rootdir) / p
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(state.results, f, ensure_ascii=False, indent=2)
    reporter = config.pluginmanager.get_plugin("terminalreporter")
    if reporter:
        reporter.write_line(f"[paia-blockly] 結果已寫入：{p}")
