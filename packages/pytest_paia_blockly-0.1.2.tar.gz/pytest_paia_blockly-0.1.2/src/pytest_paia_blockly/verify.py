import time
from typing import Any, Callable

from pytest_paia_blockly.model import (
    ExpectedAnswer,
    ExpectedType,
    EXPECTED_TYPE_PY_MAP,
    VerifyCase,
    VerifyResult,
)


def _type_name(obj: Any) -> str:
    if obj is None:
        return "None"
    t = type(obj)
    for name, py_type in EXPECTED_TYPE_PY_MAP.items():
        if t is py_type:
            return name
    return t.__name__


def _values_equal(output: Any, expected_value: Any, expected_type: ExpectedType) -> bool:
    """比對輸出與預期值；int/float 會先統一再比對，其餘用 ==。"""
    if output == expected_value:
        return True
    if expected_type == "float" and isinstance(output, (int, float)) and isinstance(expected_value, (int, float)):
        return float(output) == float(expected_value)
    if expected_type == "int" and isinstance(output, float) and output == int(output):
        return int(output) == expected_value
    return False


def get_verify_result(
    input_case: VerifyCase,
    expected: ExpectedAnswer | dict,
    get_solution: Callable[[dict], Any],
) -> VerifyResult:
    """單筆驗證：將 input（JSON object）傳入 get_solution(input)，與 expected（type+value）比對。"""
    if isinstance(expected, dict):
        expected = ExpectedAnswer(**expected)
    start = time.time()
    output = get_solution(input_case.input)
    execution_time_ms = (time.time() - start) * 1000
    type_ok = _type_name(output) == expected.type
    value_ok = _values_equal(output, expected.value, expected.type)
    return VerifyResult(
        index=input_case.index,
        input=input_case.input,
        expected=expected,
        output=output,
        is_verified=type_ok and value_ok,
        execution_time=execution_time_ms,
        cpu_consumption=0.0,
        memory_usage=0,
    )
