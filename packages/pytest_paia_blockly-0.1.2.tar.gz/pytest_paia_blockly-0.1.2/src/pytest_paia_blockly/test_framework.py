"""
唯一測試入口：test_verify_case
每筆 case 由 pytest_generate_tests（plugin.py）注入為獨立的參數化測試項目。
兩個必填選項未設定時，参數化為 0 筆，此測試不會被收集。
"""

from loguru import logger

from pytest_paia_blockly.model import VerifyCase
from pytest_paia_blockly.verify import get_verify_result


def test_verify_case(paia_case: VerifyCase, paia_target_func, paia_results_collector):
    """每筆 case 參數化執行：跑 get_solution(input)，結果收集後於 session 結束寫入 --paia-result。"""
    try:
        result = get_verify_result(paia_case, paia_case.expected, paia_target_func)
        paia_results_collector.append(result.model_dump(mode="json"))
        assert result.is_verified, (
            f"Case {paia_case.index}: expected {paia_case.expected.value!r}, got {result.output!r}"
        )
    except AssertionError:
        raise
    except Exception as e:
        logger.error(f"Case {paia_case.index} 執行錯誤：{e}")
        paia_results_collector.append({
            "index": paia_case.index,
            "input": paia_case.input,
            "expected": paia_case.expected.model_dump(mode="json"),
            "output": None,
            "is_verified": False,
            "execution_time": 0.0,
            "error": str(e),
        })
        raise
