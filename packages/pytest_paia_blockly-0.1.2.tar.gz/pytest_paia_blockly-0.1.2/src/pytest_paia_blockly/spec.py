"""PAIA Blockly 題目規格 spec.json 的 schema 與驗證。"""

from pydantic import BaseModel, Field, model_validator

from pytest_paia_blockly.model import ExpectedType


class SpecStatement(BaseModel):
    """題目摘要；完整說明請見同目錄 readme.md。"""

    title: str = Field(min_length=1)
    summary: str = Field(min_length=1)


class SpecInputField(BaseModel):
    """輸入參數欄位（供 Electron 渲染表單）。"""

    key: str = Field(min_length=1)
    type: ExpectedType
    description: str = Field(min_length=1)
    label: str | None = None


class SpecOutput(BaseModel):
    """輸出格式（供 Electron 顯示期望結果型別）。"""

    type: ExpectedType
    description: str = Field(min_length=1)


class PaiaProblemSpec(BaseModel):
    """
    精簡版題目規格：
    - statement：僅 title + summary（完整說明在 readme.md）
    - input_params：輸入欄位 key/type/description（供 Electron 渲染）
    - output：輸出型別與說明
    函式固定為 get_solution(params: dict)，不在 spec 中重複宣告。
    """

    spec_version: int = Field(ge=1)
    id: str = Field(min_length=1)
    statement: SpecStatement
    input_params: list[SpecInputField] = Field(min_length=1)
    output: SpecOutput

    @model_validator(mode="after")
    def _validate_unique_input_keys(self):
        keys = [f.key for f in self.input_params]
        dup = {k for k in keys if keys.count(k) > 1}
        if dup:
            raise ValueError(f"duplicate input_params keys: {sorted(dup)}")
        return self

