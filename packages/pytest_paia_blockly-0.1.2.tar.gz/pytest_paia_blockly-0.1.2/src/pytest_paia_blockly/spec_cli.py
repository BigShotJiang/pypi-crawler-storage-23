
import argparse
import json
import sys
from pathlib import Path

from pydantic import ValidationError

from pytest_paia_blockly.spec import PaiaProblemSpec


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="paia-blockly-validate-spec",
        description="Validate a PAIA Blockly problem spec.json file.",
    )
    parser.add_argument("spec_json", help="Path to spec.json")
    args = parser.parse_args(argv)

    path = Path(args.spec_json)
    if not path.exists():
        print(f"spec.json not found: {path}", file=sys.stderr)
        return 2

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"invalid JSON: {path}\n{e}", file=sys.stderr)
        return 2

    try:
        spec = PaiaProblemSpec.model_validate(data)
    except ValidationError as e:
        print(f"spec validation failed: {path}", file=sys.stderr)
        print(e, file=sys.stderr)
        return 1
    except ValueError as e:
        print(f"spec validation failed: {path}", file=sys.stderr)
        print(str(e), file=sys.stderr)
        return 1

    print(f"OK: {spec.id} (spec_version={spec.spec_version})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

