"""
pytest-paia-blockly plugin 整合測試（使用 pytester）

每個測試在隔離的暫存目錄啟動子 pytest session，對 plugin 做黑箱驗證。
子 session 需指定 pytest_paia_blockly/test_framework.py 的完整路徑，
因為該檔案安裝在套件目錄中，不在 pytester 的暫存 testpaths 裡。
"""

import json
from pathlib import Path

import pytest
import pytest_paia_blockly

EXAMPLES_ROOT = Path(__file__).resolve().parent.parent / "examples"
PLUGIN_TEST_FRAMEWORK = Path(pytest_paia_blockly.__file__).parent / "test_framework.py"


def _solution_py(topic: str) -> Path:
    return EXAMPLES_ROOT / topic / "solution.py"


def _cases_json(topic: str) -> Path:
    return EXAMPLES_ROOT / topic / "case.json"


# ── 正常通過 ──────────────────────────────────────────────────────────────────

def test_normal_pass(pytester):
    """正確 solution + 正確 cases → 全部 passed，result.json 寫入且 is_verified 全為 True。"""
    solution = _solution_py("sum_the_list")
    cases = _cases_json("sum_the_list")
    result_path = pytester.path / "result.json"
    result = pytester.runpytest(
        str(PLUGIN_TEST_FRAMEWORK),
        "--paia-target-module", str(solution),
        "--paia-testcases", str(cases),
        "--paia-result", str(result_path),
        "-v",
    )
    result.assert_outcomes(passed=10)
    data = json.loads(result_path.read_text())
    assert len(data) == 10
    assert all(r["is_verified"] for r in data)


# ── 缺必填參數 ────────────────────────────────────────────────────────────────

def test_no_target_module(pytester):
    """未提供 --paia-target-module → 收集到 0 個測試，不噴 error。"""
    cases = _cases_json("sum_the_list")
    result = pytester.runpytest(
        "--paia-testcases", str(cases),
        "-v",
    )
    # exit code 5 = no tests collected；exit code 0 也可接受
    assert result.ret in (0, 5)
    result.stdout.no_fnmatch_line("*ERROR*")


def test_no_testcases(pytester):
    """未提供 --paia-testcases → 收集到 0 個測試，不噴 error。"""
    solution = _solution_py("sum_the_list")
    result = pytester.runpytest(
        "--paia-target-module", str(solution),
        "-v",
    )
    assert result.ret in (0, 5)
    result.stdout.no_fnmatch_line("*ERROR*")


# ── 答案錯誤 ──────────────────────────────────────────────────────────────────

def test_wrong_answer(pytester):
    """solution 回傳錯誤值 → case 顯示 FAILED，result.json is_verified=False。"""
    wrong_solution = pytester.path / "wrong_solution.py"
    wrong_solution.write_text(
        "def get_solution(params):\n    return -1\n",
        encoding="utf-8",
    )
    result_path = pytester.path / "result.json"
    cases = _cases_json("sum_the_list")
    result = pytester.runpytest(
        str(PLUGIN_TEST_FRAMEWORK),
        "--paia-target-module", str(wrong_solution),
        "--paia-testcases", str(cases),
        "--paia-result", str(result_path),
        "-v",
    )
    result.assert_outcomes(failed=10)
    data = json.loads(result_path.read_text())
    assert all(not r["is_verified"] for r in data)


# ── solution 拋出例外 ─────────────────────────────────────────────────────────

def test_solution_exception(pytester):
    """solution 拋出例外 → case 顯示 ERROR，result.json 有 error 欄位且 is_verified=False。"""
    bad_solution = pytester.path / "bad_solution.py"
    bad_solution.write_text(
        "def get_solution(params):\n    raise ValueError('intentional error')\n",
        encoding="utf-8",
    )
    result_path = pytester.path / "result.json"
    cases = _cases_json("sum_the_list")
    result = pytester.runpytest(
        str(PLUGIN_TEST_FRAMEWORK),
        "--paia-target-module", str(bad_solution),
        "--paia-testcases", str(cases),
        "--paia-result", str(result_path),
        "-v",
    )
    # 例外在 test_verify_case 內被捕捉後 re-raise → pytest 計為 FAILED（非 ERROR）
    result.assert_outcomes(failed=10)
    data = json.loads(result_path.read_text())
    assert all(not r["is_verified"] for r in data)
    assert all("error" in r for r in data)


# ── 非法 case.json ────────────────────────────────────────────────────────────

def test_invalid_case_json(pytester):
    """case.json 格式非法 → 收集階段 ERROR，exit code 非 0。"""
    bad_cases = pytester.path / "bad_cases.json"
    bad_cases.write_text("this is not json", encoding="utf-8")
    solution = _solution_py("sum_the_list")
    result = pytester.runpytest(
        str(PLUGIN_TEST_FRAMEWORK),
        "--paia-target-module", str(solution),
        "--paia-testcases", str(bad_cases),
        "-v",
    )
    assert result.ret != 0


# ── result 父目錄自動建立 ─────────────────────────────────────────────────────

def test_result_file_parent_created(pytester):
    """--paia-result 指向不存在的子目錄 → 目錄自動建立，result.json 正確寫入。"""
    solution = _solution_py("sum_the_list")
    cases = _cases_json("sum_the_list")
    result_path = pytester.path / "deep" / "nested" / "result.json"
    result = pytester.runpytest(
        str(PLUGIN_TEST_FRAMEWORK),
        "--paia-target-module", str(solution),
        "--paia-testcases", str(cases),
        "--paia-result", str(result_path),
        "-v",
    )
    result.assert_outcomes(passed=10)
    assert result_path.exists(), "result.json 應被自動建立在不存在的子目錄中"
    data = json.loads(result_path.read_text())
    assert len(data) == 10


# ── xdist 警告 ────────────────────────────────────────────────────────────────

@pytest.mark.skipif(
    not pytest.importorskip("xdist", reason="pytest-xdist 未安裝，跳過"),
    reason="pytest-xdist 未安裝",
)
def test_xdist_warning(pytester):
    """啟用 xdist 時，plugin 應發出 UserWarning 並且不寫入 result.json。"""
    solution = _solution_py("sum_the_list")
    cases = _cases_json("sum_the_list")
    result = pytester.runpytest(
        str(PLUGIN_TEST_FRAMEWORK),
        "--paia-target-module", str(solution),
        "--paia-testcases", str(cases),
        "--paia-result", "result.json",
        "-n=2",
        "-v",
    )
    # warning 以 UserWarning 形式發出，會出現在 warnings summary 或 stderr
    output = result.stdout.str() + result.stderr.str()
    assert "xdist" in output or "paia-result" in output or "paia-blockly" in output
    assert not (pytester.path / "result.json").exists()
