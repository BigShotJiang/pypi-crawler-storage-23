"""
預設題目：每題依 case 參數化，每筆 case 為一則 pytest 項目。
不需命令列，在 Cursor 可對單一 case 按 Run（如 test_verify_sum_the_list[case_1]）或整題 Run。
"""

import importlib
import json
from pathlib import Path

import pytest

from pytest_paia_blockly.model import VerifyCase
from pytest_paia_blockly.verify import get_verify_result

_PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _load_cases(cases_path: str) -> list[VerifyCase]:
    """從 case 檔載入 VerifyCase 列表。"""
    path = _PROJECT_ROOT / cases_path
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return [
        VerifyCase(**c)
        for c in data
    ]


def _get_solution_fn(module_path: str):
    """從模組路徑取得 get_solution callable。"""
    mod = importlib.import_module(module_path)
    return getattr(mod, "get_solution")


# 每題的 cases 與 get_solution（模組載入時讀取一次）
_CASES_ADD_A_AND_B = _load_cases("examples/add_a_and_b/case.json")
_GET_SOLUTION_ADD_A_AND_B = _get_solution_fn("examples.add_a_and_b.solution")

@pytest.mark.parametrize("case", _CASES_ADD_A_AND_B, ids=lambda c: f"case_{c.index}")
def test_verify_add_a_and_b(case: VerifyCase):
    """預設題目：兩數相加。每筆 case 一則測試，可對單一 case 按 Run。"""
    result = get_verify_result(case, case.expected, _GET_SOLUTION_ADD_A_AND_B)
    assert result.is_verified, f"expected {case.expected.value!r}, got {result.output!r}"


_CASES_SUM_THE_LIST = _load_cases("examples/sum_the_list/case.json")
_GET_SOLUTION_SUM_THE_LIST = _get_solution_fn("examples.sum_the_list.solution")

@pytest.mark.parametrize("case", _CASES_SUM_THE_LIST, ids=lambda c: f"case_{c.index}")
def test_verify_sum_the_list(case: VerifyCase):
    """預設題目：列表求和。每筆 case 一則測試，可對單一 case 按 Run。"""
    result = get_verify_result(case, case.expected, _GET_SOLUTION_SUM_THE_LIST)
    assert result.is_verified, f"expected {case.expected.value!r}, got {result.output!r}"


_CASES_CONCAT_STR = _load_cases("examples/concat_str/case.json")
_GET_SOLUTION_CONCAT_STR = _get_solution_fn("examples.concat_str.solution")

@pytest.mark.parametrize("case", _CASES_CONCAT_STR, ids=lambda c: f"case_{c.index}")
def test_verify_concat_str(case: VerifyCase):
    """預設題目：字串相接。每筆 case 一則測試，可對單一 case 按 Run。"""
    result = get_verify_result(case, case.expected, _GET_SOLUTION_CONCAT_STR)
    assert result.is_verified, f"expected {case.expected.value!r}, got {result.output!r}"



_CASES_HELLO_USER_WITH_DICT = _load_cases("examples/hello_user_with_dict/case.json")
_GET_SOLUTION_HELLO_USER_WITH_DICT = _get_solution_fn("examples.hello_user_with_dict.solution")

@pytest.mark.parametrize("case", _CASES_HELLO_USER_WITH_DICT, ids=lambda c: f"case_{c.index}")
def test_verify_hello_user_with_dict(case: VerifyCase):
    """預設題目：Hello user。每筆 case 一則測試，可對單一 case 按 Run。"""
    result = get_verify_result(case, case.expected, _GET_SOLUTION_HELLO_USER_WITH_DICT)
    assert result.is_verified, f"expected {case.expected.value!r}, got {result.output!r}"