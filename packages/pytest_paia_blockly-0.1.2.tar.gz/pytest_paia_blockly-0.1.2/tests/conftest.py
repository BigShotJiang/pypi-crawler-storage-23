# tests/conftest.py — 本地開發用設定
# plugin 邏輯（addoption、fixtures、hooks）已移至 pytest_paia_blockly/plugin.py

# 啟用 pytester fixture（供 tests/test_plugin.py 的整合測試使用）
pytest_plugins = ["pytester"]
