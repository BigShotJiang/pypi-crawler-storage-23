# 如何出題（題目目錄說明）

本目錄下每一題為一個**獨立資料夾**，資料夾名稱即題目 id（建議用英文、底線，例如 `add_a_and_b`、`sum_the_list`）。出題時需提供以下檔案，並建議加上邊界與極端測資。

---

## 必備檔案

| 檔案 | 說明 |
|------|------|
| **README.md** | 題意、輸入/輸出說明、範例表格（欄位含各輸入參數與「期望結果」）、實作約定。完整題目說明以此為主。 |
| **spec.json** | 題目規格，供 Electron 等工具讀取以渲染表單與型別。需通過 `paia-blockly-validate-spec` 驗證。 |
| **case.json** | 測資列表，每筆含 `input` 與 `expected`，供 pytest-paia-blockly 執行驗證。 |
| **solution.py** | 參考解法，必須實作 `get_solution(params: dict)`，回傳值型別與 spec 的 `output.type` 一致。 |

可選：`__init__.py`（空檔即可，方便以模組路徑載入）、`result.json`（執行後產生的結果檔，可不納版控）。

---

## README.md 結構建議

- **題意**：一兩句話說明要做什麼。
- **輸入**：列出每個參數的 key、型別、意義；可寫「輸入為一個 JSON object，例如：`{...}`」。
- **輸出**：回傳型別與意義。
- **範例**：用表格列出「各輸入欄位 + 期望結果」，例如：

  | a   | b   | 期望結果 |
  |-----|-----|----------|
  | 1   | 2   | 3        |

- **實作說明**：註明在 `solution.py` 實作 `get_solution(params: dict)`，`params` 內容與回傳約定。

---

## spec.json 格式

- **spec_version**：整數，目前為 `1`。
- **id**：字串，與題目資料夾名稱一致。
- **statement**：`title`（題目標題）、`summary`（一句摘要）；完整說明放在 README。
- **input_params**：陣列，每個元素為 `key`、`type`、`description`；
  **type** 限：`bool`、`int`、`float`、`str`、`list`、`dict`。
- **output**：`type`、`description`，描述回傳型別與意義。

範例：

```json
{
  "spec_version": 1,
  "id": "add_a_and_b",
  "statement": {
    "title": "兩數相加（a + b）",
    "summary": "給定兩個整數 a、b，請回傳 a + b。"
  },
  "input_params": [
    { "key": "a", "type": "int", "description": "第一個加數" },
    { "key": "b", "type": "int", "description": "第二個加數" }
  ],
  "output": {
    "type": "int",
    "description": "回傳 a + b 的結果"
  }
}
```

驗證指令（需先安裝 pytest-paia-blockly）：

```bash
paia-blockly-validate-spec examples/<題目 id>/spec.json
```

---

## case.json 格式

為 JSON 陣列，每筆測資包含：

- **index**：整數，測資編號（可從 1 開始）。
- **input**：JSON object，key 與 spec 的 `input_params` 對應，直接傳入 `get_solution(input)`。
- **expected**：`{ "type": "int|float|str|bool|list|dict", "value": ... }`，與 `get_solution` 回傳值比對。

範例：

```json
[
  {"index": 1, "input": {"a": 1, "b": 2}, "expected": {"type": "int", "value": 3}},
  {"index": 2, "input": {"a": 0, "b": 0}, "expected": {"type": "int", "value": 0}}
]
```

建議除一般範例外，加入**邊界與極端測資**（例如：0、空字串/空列表、負數、單一元素、較大數值等），以涵蓋邊界情況。

---

## solution.py 約定

- 必須定義 **`get_solution(params: dict)`**，參數為單一字典（即 case 的 `input`）。
- 回傳值型別須與 spec 的 `output.type` 及 case 的 `expected.type` 一致。
- 實作時僅依賴 `params` 的 key，可寫 docstring 說明輸入與回傳。

---

## 出題流程簡述

1. 在 `examples/` 下新增資料夾，名稱即題目 id。
2. 撰寫 **README.md**（題意、輸入、輸出、範例表格、實作說明）。
3. 撰寫 **spec.json**（statement、input_params、output），並執行 `paia-blockly-validate-spec` 通過。
4. 撰寫 **case.json**（含一般與邊界測資）。
5. 撰寫 **solution.py**（`get_solution(params: dict)`），確保所有 case 通過驗證（可用專案內 `scripts/cli/`、`scripts/pytest/` 等腳本或 `pytest` 指令執行該題）。

若專案有腳本或 CI 依題目 id 清單執行，記得將新題目 id 加入對應設定。
