def get_solution(params: dict):
    """輸入 JSON object 含 list（數字列表），回傳總和。"""
    return sum(params["list"])
