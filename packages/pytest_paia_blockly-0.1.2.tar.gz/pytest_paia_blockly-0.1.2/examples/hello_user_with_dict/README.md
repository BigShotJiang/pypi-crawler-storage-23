# Hello, 使用者！（hello user with dict）

## 題意

給定輸入中的 `name`（與可選的 `age`），請回傳字串 `"Hello, {name}!"`（僅使用 `name`，age 本題可不使用）。

## 輸入

- `name`：字串，使用者名稱
- `age`：整數（選填），本題可忽略

輸入為一個 JSON object，例如：`{"name": "John", "age": 20}`。

## 輸出

回傳一個字串，格式為 `Hello, {name}!`，其中 `{name}` 為輸入的 `name` 值。

## 範例

| name | 期望結果       |
|------|----------------|
| John | Hello, John!   |
| （空）  | Hello, !        |
| A    | Hello, A!      |

## 實作說明

在 `solution.py` 中實作 `get_solution(params: dict)`，`params` 至少包含 `name`（字串），回傳 `"Hello, " + name + "!"`。
