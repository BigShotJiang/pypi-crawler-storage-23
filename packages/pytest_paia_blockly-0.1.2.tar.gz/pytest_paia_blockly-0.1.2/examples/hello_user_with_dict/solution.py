def get_solution(params: dict):
    """輸入 JSON object 含 name（與可選 age），回傳 Hello, {name}!。"""
    return f"Hello, {params['name']}!"
