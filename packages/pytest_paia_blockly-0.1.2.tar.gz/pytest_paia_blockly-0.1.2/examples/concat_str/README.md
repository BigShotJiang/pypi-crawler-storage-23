# 字串相接（concat str）

## 題意

給定兩個字串 `a`、`b`，請回傳將兩者依序相接後的結果（a 在前，b 在後）。

## 輸入

- `a`：字串
- `b`：字串

輸入為一個 JSON object，例如：`{"a": "Hello", "b": "World"}`。

## 輸出

回傳一個字串，即 `a + b`（Python 字串相接）。

## 範例

| a   | b   | 期望結果 |
|-----|-----|----------|
| haha   | hoho   | hahahoho       |
| （空） | x   | x        |
| x   | （空） | x        |

## 實作說明

在 `solution.py` 中實作 `get_solution(params: dict)`，`params` 為包含 `a`、`b`（字串）的字典，回傳相接後的字串。
