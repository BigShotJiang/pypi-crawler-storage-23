def get_solution(params: dict):
    """輸入 JSON object 含 a, b，回傳 a + b。"""
    return params["a"] + params["b"]
