#!/usr/bin/env bash
# 打包並上傳至 PyPI
# 前置：uv pip install build twine（或 pip install build twine）
# 上傳前請設定 PyPI token：export TWINE_USERNAME=__token__ 與 TWINE_PASSWORD=pypi-xxx
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

echo "Removing old builds..."
rm -r ./dist/*

echo "Building..."
uv run python -m build

echo "Uploading to PyPI..."
uv run twine upload dist/*
