# use uv to create a virtual environment and install the dependencies
uv venv
uv pip install -r requirements.txt
uv pip install -r requirements-dev.txt
uv pip install -e .

source .venv/bin/activate
