#!/usr/bin/env bash
# 僅執行 hello_user_with_dict 的 solution 驗證（CLI，從 repo 根目錄執行）
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

uv run paia-blockly-test \
  --paia-target-module "$REPO_ROOT/examples/hello_user_with_dict/solution.py" \
  --paia-testcases "$REPO_ROOT/examples/hello_user_with_dict/case.json" \
  --paia-result "$REPO_ROOT/var/hello_user_with_dict_result.json" \
  -v "$@"
