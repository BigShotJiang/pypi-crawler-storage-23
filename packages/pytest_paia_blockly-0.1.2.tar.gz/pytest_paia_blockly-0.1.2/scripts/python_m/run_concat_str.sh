#!/usr/bin/env bash
# python -m 方式：僅執行 concat_str 的 solution 驗證
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_ROOT"

python -m pytest_paia_blockly \
  --paia-target-module "$REPO_ROOT/examples/concat_str/solution.py" \
  --paia-testcases "$REPO_ROOT/examples/concat_str/case.json" \
  --paia-result "$REPO_ROOT/var/concat_str_result.json" \
  -v "$@"
