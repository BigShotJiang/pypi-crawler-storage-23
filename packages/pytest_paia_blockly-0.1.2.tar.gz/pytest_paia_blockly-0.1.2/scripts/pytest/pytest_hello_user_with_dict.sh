#!/usr/bin/env bash
# 透過 tests/test_framework.py 的 test_verify_case 驗證 hello_user_with_dict
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_ROOT"

pytest tests/test_framework.py \
  --paia-target-module "$REPO_ROOT/examples/hello_user_with_dict/solution.py" \
  --paia-testcases "$REPO_ROOT/examples/hello_user_with_dict/case.json" \
  --paia-result "$REPO_ROOT/var/hello_user_with_dict_result.json" \
  -v "$@"
