#!/usr/bin/env bash
# 透過 tests/test_framework.py 的 test_verify_case 驗證 add_a_and_b
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_ROOT"

pytest tests/test_framework.py \
  --paia-target-module "$REPO_ROOT/examples/add_a_and_b/solution.py" \
  --paia-testcases "$REPO_ROOT/examples/add_a_and_b/case.json" \
  --paia-result "$REPO_ROOT/var/add_a_and_b_result.json" \
  -v "$@"
