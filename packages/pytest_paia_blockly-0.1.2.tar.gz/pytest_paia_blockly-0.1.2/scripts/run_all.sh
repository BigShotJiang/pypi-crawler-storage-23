#!/usr/bin/env bash
# 依序執行所有範例題目
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== add_a_and_b ==="
bash "$SCRIPT_DIR/run_add_a_and_b.sh" "$@"

echo "=== sum_the_list ==="
bash "$SCRIPT_DIR/run_sum_the_list.sh" "$@"

echo "=== concat_str ==="
bash "$SCRIPT_DIR/run_concat_str.sh" "$@"

echo "=== hello_user_with_dict ==="
bash "$SCRIPT_DIR/run_hello_user_with_dict.sh" "$@"

echo ""
echo "全部題目執行完成。"
