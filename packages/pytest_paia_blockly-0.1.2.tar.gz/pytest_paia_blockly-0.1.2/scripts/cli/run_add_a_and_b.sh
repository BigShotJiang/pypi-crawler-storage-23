#!/usr/bin/env bash
# CLI 方式：paia-blockly-test — 僅執行 add_a_and_b 的 solution 驗證
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$REPO_ROOT"

paia-blockly-test \
  --paia-target-module "$REPO_ROOT/examples/add_a_and_b/solution.py" \
  --paia-testcases "$REPO_ROOT/examples/add_a_and_b/case.json" \
  --paia-result "$REPO_ROOT/var/add_a_and_b_result.json" \
  -v "$@"
