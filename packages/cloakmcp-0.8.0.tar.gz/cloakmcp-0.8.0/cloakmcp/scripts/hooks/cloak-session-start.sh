#!/bin/bash
exec cloak hook session-start
