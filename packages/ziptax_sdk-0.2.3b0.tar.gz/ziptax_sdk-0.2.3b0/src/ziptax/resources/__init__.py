"""Resources module for ZipTax SDK."""

from .functions import Functions

__all__ = ["Functions"]
