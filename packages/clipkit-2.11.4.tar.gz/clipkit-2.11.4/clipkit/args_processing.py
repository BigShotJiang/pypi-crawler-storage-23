import logging
import os.path
import sys

from .helpers import SeqType
from .modes import TrimmingMode
from .settings import DEFAULT_AA_GAP_CHARS

logger = logging.getLogger(__name__)


def process_args(args) -> dict:
    """
    Process args from argparser and set defaults
    """
    input_file = args.input
    output_file = args.output or f"{input_file}.clipkit"

    if not os.path.isfile(input_file):
        logger.warning("Input file does not exist")
        sys.exit()

    if input_file == output_file:
        logger.warning("Input and output files can't have the same name.")
        sys.exit()

    # assign optional arguments
    complement = args.complementary or False
    codon = args.codon or False
    mode = TrimmingMode(args.mode) if args.mode else TrimmingMode.smart_gap
    if args.gaps is not None:
        gaps = float(args.gaps)
    elif mode in {
        TrimmingMode.entropy,
        TrimmingMode.composition_bias,
        TrimmingMode.heterotachy,
    }:
        # Entropy thresholds are normalized to [0, 1], where larger values
        # indicate stronger per-site signal (diversity or compositional skew).
        gaps = 0.8
    else:
        gaps = 0.9
    gap_characters = (
        [c for c in args.gap_characters] if args.gap_characters is not None else None
    )
    auxiliary_file = args.auxiliary_file
    use_log = args.log or False
    quiet = args.quiet or False
    sequence_type = SeqType(args.sequence_type.lower()) if args.sequence_type else None

    if codon and mode == TrimmingMode.c3:
        logger.warning(
            "C3 and codon-based trimming are incompatible.\nCodon-based trimming removes whole codons while C3 removes every third codon position."
        )
        sys.exit()

    ends_only = args.ends_only or False
    dry_run = getattr(args, "dry_run", False) or False
    validate_only = getattr(args, "validate_only", False) or False
    report_json = getattr(args, "report_json", None)
    if report_json == "":
        report_json = f"{output_file}.report.json"
    plot_trim_report = getattr(args, "plot_trim_report", None)
    if plot_trim_report == "":
        plot_trim_report = f"{output_file}.trim_report.html"

    threads = args.threads if hasattr(args, "threads") else 1
    if threads < 1:
        logger.warning("Threads must be an integer greater than or equal to 1.")
        sys.exit()

    if mode == TrimmingMode.cst:
        if not auxiliary_file:
            logger.warning("CST mode requires an auxiliary file via -a/--auxiliary_file.")
            sys.exit()
        if not os.path.isfile(auxiliary_file):
            logger.warning("Auxiliary file does not exist.")
            sys.exit()

    return dict(
        input_file=input_file,
        output_file=output_file,
        input_file_format=args.input_file_format,
        output_file_format=args.output_file_format,
        auxiliary_file=auxiliary_file,
        codon=codon,
        sequence_type=sequence_type,
        complement=complement,
        gaps=gaps,
        gap_characters=gap_characters,
        mode=mode,
        use_log=use_log,
        quiet=quiet,
        ends_only=ends_only,
        dry_run=dry_run,
        validate_only=validate_only,
        report_json=report_json,
        plot_trim_report=plot_trim_report,
        threads=threads,
    )
