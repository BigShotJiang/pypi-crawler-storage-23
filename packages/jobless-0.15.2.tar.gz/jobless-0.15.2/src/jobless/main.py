from jobless.app import JoblessApp


def main() -> None:
    app = JoblessApp()
    app.run()
