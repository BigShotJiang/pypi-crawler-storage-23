import tkinter as tk
from tkinter import ttk


class CardArea(tk.Frame):
    def __init__(self, parent, card_width=None, align="center", columns=1, **kwargs):
        super().__init__(parent, **kwargs)

        self.card_width = card_width
        self.align = align
        self.columns = max(1, columns)

        self.canvas = tk.Canvas(self, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas)

        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )

        anchor_map = {"left": "nw", "center": "n", "right": "ne"}
        self.anchor = anchor_map.get(self.align, "n")

        self.canvas_window = self.canvas.create_window(
            (0, 0),
            window=self.scrollable_frame,
            anchor=self.anchor
        )

        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _on_canvas_configure(self, event):
        if self.card_width:
            self.canvas.itemconfig(self.canvas_window, width=self.card_width)
            if self.align == "center":
                self.canvas.coords(self.canvas_window, event.width / 2, 0)
            elif self.align == "right":
                self.canvas.coords(self.canvas_window, event.width, 0)
            else:
                self.canvas.coords(self.canvas_window, 0, 0)
        else:
            self.canvas.itemconfig(self.canvas_window, width=event.width)
            self.canvas.coords(self.canvas_window, 0, 0)

    def _on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def render(self, data_list, template_class):
        for child in self.scrollable_frame.winfo_children():
            child.destroy()

        for col in range(self.columns):
            self.scrollable_frame.columnconfigure(col, weight=1)

        for index, item in enumerate(data_list):
            row = index // self.columns
            column = index % self.columns

            card = template_class(self.scrollable_frame, item)
            card.grid(row=row, column=column, padx=10, pady=5, sticky="nsew")
