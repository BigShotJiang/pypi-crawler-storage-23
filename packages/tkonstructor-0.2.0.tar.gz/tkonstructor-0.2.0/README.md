A library for creating evolving regions with cards in Tkinter.

1.First of all, create a card class, example:

class ProductCard(Frame):
    def __init__(self, parent, row, command=None):
        super().__init__(parent, bd=1, relief=SOLID, pady=10)

        self.photo_canvas = Canvas(self, width=100, height=100)
        self.photo_canvas.grid(row=0, column=0, rowspan=2)

        photo_path = "PhotoName.png"
    
        img = PhotoImage(file = photo_path)
        self.img = img.subsample(3, 3)
        self.photo_canvas.create_image(0, 0, image=self.img, anchor=NW)

        Label(self, text=row[1]).grid(row=0, column=1)
        Label(self, text=row[2]).grid(row=1, column=1)
        Label(self, text=row[3]).grid(row=2, column=1)
        Label(self, text=row[4]).grid(row=3, column=1)
        Label(self, text=row[5]).grid(row=4, column=1)
        Label(self, text=row[6]).grid(row=5, column=1)        

        self.columnconfigure(2, weight=1)

        if command:
            self.bind("<Button-1>", lambda e: command(row))
            for child in self.winfo_children():
                child.bind("<Button-1>", lambda e: command(row))

2.Create function for your card creation with variable (list or etc.)

def create_product_card(info_list):
    card_area.render(info_list, ProductCard, on_card_click=open_edit_window)

3.Create function which will be called on click

def open_edit_window(data):
    edit_window = Toplevel()
    edit_window.title(text="Redacting")
    edit_window.geometry("350x250")
    edit_window.resizable(False, False)

    content = Frame(edit_window, padx=20, pady=20)
    content.pack(expand=True, fill=BOTH)

    Label(content, text="Matertial name:").pack(anchor=W)
    name_entry = Entry(content, width=40)
    name_entry.insert(0, data[1])
    name_entry.pack(pady=(0, 10))


4.Create a card area where cards will be shown

card_area = CardArea(main_window, columns=2, card_width=800, align="left")
card_area.pack(expand=True, fill=BOTH, side=RIGHT)

5.Now you can call your function and it will create a card in your Tkinter application

create_product_card(get_materials_list())