"""Allow running ConvoYield as: python -m convoyield"""
from convoyield.cli import main
main()
