"""
ConvoCoin P2P Network — Decentralized node communication.

Nodes discover each other, share blocks and transactions,
and reach consensus on the longest valid chain.
"""
