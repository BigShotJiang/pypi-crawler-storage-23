"""
idmtools Configuration tools/Manager.

Copyright 2021, Bill & Melinda Gates Foundation. All rights reserved.
"""
# flake8: noqa F821
from idmtools.config.idm_config_parser import IdmConfigParser
