"""
Defines all the platform operation interfaces.

Copyright 2021, Bill & Melinda Gates Foundation. All rights reserved.
"""
