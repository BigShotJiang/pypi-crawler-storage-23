"""
idmtools List of core abstract interfaces that other core objects derive from.

Copyright 2021, Bill & Melinda Gates Foundation. All rights reserved.
"""
