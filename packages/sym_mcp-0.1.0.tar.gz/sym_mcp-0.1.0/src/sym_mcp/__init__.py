"""sym_mcp package."""

