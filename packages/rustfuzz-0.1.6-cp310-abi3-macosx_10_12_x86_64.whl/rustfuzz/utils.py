"""
rustfuzz.utils — string preprocessing utilities.
"""

from __future__ import annotations

from ._rustfuzz import default_process

__all__ = ["default_process"]
