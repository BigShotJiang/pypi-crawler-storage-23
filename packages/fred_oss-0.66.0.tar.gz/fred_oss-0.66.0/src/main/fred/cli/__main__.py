from fred.cli.main import CLI


if __name__ == "__main__":
    CLI.cli_exec()
