"""
Neural Doctor - Intelligent Error Handling & Diagnostics System
A comprehensive error detection, diagnosis, and healing system for NeuralNode
"""
import asyncio
import json
import time
import logging
import traceback
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any, Union
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
import sys
import os
import subprocess
import platform


# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class ErrorCategory(Enum):
    """Error classification categories"""
    NETWORK = "network"
    API = "api"
    TOOL = "tool"
    LOGIC = "logic"
    RESOURCE = "resource"
    HARDWARE = "hardware"
    CUDA = "cuda"
    UNKNOWN = "unknown"


class ErrorSeverity(Enum):
    """Error severity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class ErrorRecord:
    """Complete error record for storage and analysis"""
    id: str
    timestamp: datetime
    category: ErrorCategory
    severity: ErrorSeverity
    error_type: str
    message: str
    stack_trace: str
    context: Dict[str, Any]
    root_cause: Optional[str] = None
    fix_suggestions: List[str] = field(default_factory=list)
    healed: bool = False
    healing_attempts: int = 0
    resolved: bool = False
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization"""
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat(),
            "category": self.category.value,
            "severity": self.severity.value,
            "error_type": self.error_type,
            "message": self.message,
            "stack_trace": self.stack_trace,
            "context": self.context,
            "root_cause": self.root_cause,
            "fix_suggestions": self.fix_suggestions,
            "healed": self.healed,
            "healing_attempts": self.healing_attempts,
            "resolved": self.resolved
        }


@dataclass
class HealthStatus:
    """System health status report"""
    timestamp: datetime
    overall_status: str  # "healthy", "degraded", "unhealthy"
    components: Dict[str, Dict[str, Any]]
    
    def to_dict(self) -> Dict:
        return {
            "timestamp": self.timestamp.isoformat(),
            "overall_status": self.overall_status,
            "components": self.components
        }


class HardwareChecker:
    """Hardware verification and CUDA checking"""
    
    @staticmethod
    def check_system_info() -> Dict[str, Any]:
        """Get basic system information"""
        return {
            "platform": platform.system(),
            "platform_version": platform.version(),
            "architecture": platform.architecture()[0],
            "processor": platform.processor(),
            "python_version": sys.version,
            "cpu_count": os.cpu_count(),
            "ram_gb": HardwareChecker._get_ram_gb()
        }
    
    @staticmethod
    def _get_ram_gb() -> float:
        """Get RAM size in GB"""
        try:
            import psutil
            return round(psutil.virtual_memory().total / (1024**3), 2)
        except ImportError:
            return -1
    
    @staticmethod
    def check_cuda() -> Dict[str, Any]:
        """Check CUDA availability and GPU info"""
        result = {
            "cuda_available": False,
            "cuda_version": None,
            "gpu_count": 0,
            "gpu_names": [],
            "gpu_memory_gb": []
        }
        
        try:
            import torch
            result["cuda_available"] = torch.cuda.is_available()
            
            if torch.cuda.is_available():
                result["cuda_version"] = torch.version.cuda
                result["gpu_count"] = torch.cuda.device_count()
                
                for i in range(torch.cuda.device_count()):
                    props = torch.cuda.get_device_properties(i)
                    result["gpu_names"].append(props.name)
                    result["gpu_memory_gb"].append(round(props.total_memory / (1024**3), 2))
        except ImportError:
            result["error"] = "PyTorch not installed"
        
        return result
    
    @staticmethod
    def check_ollama() -> Dict[str, Any]:
        """Check Ollama installation and status"""
        result = {
            "installed": False,
            "running": False,
            "version": None,
            "models": []
        }
        
        try:
            # Check if ollama command exists
            import subprocess
            version_result = subprocess.run(
                ["ollama", "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if version_result.returncode == 0:
                result["installed"] = True
                result["version"] = version_result.stdout.strip()
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            pass
        
        # Check if Ollama server is running
        try:
            import socket
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                if s.connect_ex(('localhost', 11434)) == 0:
                    result["running"] = True
        except:
            pass
        
        return result
    
    @staticmethod
    def full_hardware_report() -> Dict[str, Any]:
        """Generate complete hardware and environment report"""
        return {
            "system": HardwareChecker.check_system_info(),
            "cuda": HardwareChecker.check_cuda(),
            "ollama": HardwareChecker.check_ollama(),
            "timestamp": datetime.now().isoformat()
        }


class ErrorClassifier:
    """Intelligent error classification system"""
    
    @staticmethod
    def classify(error: Exception, context: Dict[str, Any] = None) -> ErrorCategory:
        """Classify error into category"""
        error_msg = str(error).lower()
        error_type = type(error).__name__.lower()
        
        # Network errors
        if any(keyword in error_msg for keyword in [
            "connection", "timeout", "network", "socket", "dns", 
            "unreachable", "refused", "reset", "abort"
        ]):
            return ErrorCategory.NETWORK
        
        # API errors
        if any(keyword in error_msg for keyword in [
            "api", "http", "request", "response", "status", 
            "unauthorized", "forbidden", "rate limit"
        ]):
            return ErrorCategory.API
        
        # Resource errors
        if any(keyword in error_msg for keyword in [
            "memory", "disk", "space", "resource", "quota", 
            "limit exceeded", "out of", "no space"
        ]):
            return ErrorCategory.RESOURCE
        
        # CUDA/Hardware errors
        if any(keyword in error_msg for keyword in [
            "cuda", "gpu", "nvidia", "out of memory", "cudnn",
            "device", "hardware"
        ]):
            return ErrorCategory.CUDA
        
        # Tool execution errors
        if context and "tool" in context:
            return ErrorCategory.TOOL
        
        # Logic errors
        if any(keyword in error_type for keyword in [
            "valueerror", "typeerror", "attributeerror", "keyerror",
            "indexerror", "runtimeerror"
        ]):
            return ErrorCategory.LOGIC
        
        return ErrorCategory.UNKNOWN
    
    @staticmethod
    def assess_severity(error: Exception, category: ErrorCategory) -> ErrorSeverity:
        """Assess error severity"""
        error_msg = str(error).lower()
        
        # Critical errors
        if category == ErrorCategory.CUDA and "out of memory" in error_msg:
            return ErrorSeverity.CRITICAL
        
        if any(keyword in error_msg for keyword in [
            "critical", "fatal", "crash", "panic", "emergency"
        ]):
            return ErrorSeverity.CRITICAL
        
        # High severity
        if category in [ErrorCategory.NETWORK, ErrorCategory.API]:
            return ErrorSeverity.HIGH
        
        # Medium severity
        if category in [ErrorCategory.RESOURCE, ErrorCategory.TOOL]:
            return ErrorSeverity.MEDIUM
        
        return ErrorSeverity.LOW


class RootCauseAnalyzer:
    """LLM-powered root cause analysis"""
    
    def __init__(self, llm=None):
        self.llm = llm
    
    async def analyze(self, error: Exception, context: Dict[str, Any]) -> str:
        """Analyze root cause using LLM or heuristics"""
        if self.llm:
            return await self._analyze_with_llm(error, context)
        return self._analyze_with_heuristics(error, context)
    
    async def _analyze_with_llm(self, error: Exception, context: Dict[str, Any]) -> str:
        """Use LLM to analyze root cause"""
        prompt = f"""Analyze the root cause of this error:

Error: {type(error).__name__}: {str(error)}
Stack Trace: {traceback.format_exc()}
Context: {json.dumps(context, indent=2)}

Provide a concise root cause analysis (2-3 sentences max)."""
        
        try:
            from neuralnode import Message
            messages = [Message.user(prompt)]
            response = await self.llm.achat(messages)
            return response.content.strip()
        except:
            return self._analyze_with_heuristics(error, context)
    
    def _analyze_with_heuristics(self, error: Exception, context: Dict[str, Any]) -> str:
        """Heuristic-based root cause analysis"""
        error_msg = str(error).lower()
        category = ErrorClassifier.classify(error, context)
        
        analysis_map = {
            ErrorCategory.NETWORK: "Network connectivity issue or service unavailable",
            ErrorCategory.API: "External API failure or invalid request format",
            ErrorCategory.CUDA: "GPU memory exhausted or CUDA configuration issue",
            ErrorCategory.RESOURCE: "System resources (RAM/Disk) insufficient",
            ErrorCategory.TOOL: "Tool execution failed due to invalid parameters or state",
            ErrorCategory.LOGIC: "Code logic error or invalid data format",
            ErrorCategory.UNKNOWN: "Unknown cause - requires investigation"
        }
        
        return analysis_map.get(category, "Unknown cause")
    
    def suggest_fixes(self, error: Exception, category: ErrorCategory, root_cause: str) -> List[str]:
        """Generate fix suggestions based on error type"""
        suggestions = []
        
        if category == ErrorCategory.NETWORK:
            suggestions = [
                "Check internet connection",
                "Verify service is running",
                "Retry with exponential backoff",
                "Check firewall settings"
            ]
        
        elif category == ErrorCategory.API:
            suggestions = [
                "Verify API credentials",
                "Check API rate limits",
                "Validate request format",
                "Update API client version"
            ]
        
        elif category == ErrorCategory.CUDA:
            suggestions = [
                "Reduce batch size or model size",
                "Clear GPU memory cache",
                "Switch to CPU mode temporarily",
                "Update CUDA drivers"
            ]
        
        elif category == ErrorCategory.RESOURCE:
            suggestions = [
                "Free up system memory",
                "Clear temporary files",
                "Close unnecessary applications",
                "Increase resource limits"
            ]
        
        elif category == ErrorCategory.TOOL:
            suggestions = [
                "Check tool parameters",
                "Verify tool dependencies",
                "Restart the tool service",
                "Update tool configuration"
            ]
        
        elif category == ErrorCategory.LOGIC:
            suggestions = [
                "Review input data format",
                "Add input validation",
                "Check for null/None values",
                "Add error handling"
            ]
        
        else:
            suggestions = [
                "Review error logs for details",
                "Check system health",
                "Restart the service",
                "Contact support if issue persists"
            ]
        
        return suggestions


class SelfHealingEngine:
    """Automatic error recovery and healing"""
    
    def __init__(self):
        self.healing_strategies: Dict[ErrorCategory, List[Callable]] = {
            ErrorCategory.NETWORK: [
                self._retry_with_backoff,
                self._check_service_health
            ],
            ErrorCategory.CUDA: [
                self._clear_gpu_cache,
                self._reduce_batch_size,
                self._switch_to_cpu
            ],
            ErrorCategory.RESOURCE: [
                self._free_memory,
                self._clear_temp_files
            ],
            ErrorCategory.TOOL: [
                self._restart_tool,
                self._reset_tool_state
            ]
        }
    
    async def attempt_heal(self, error_record: ErrorRecord) -> bool:
        """Attempt to heal the error automatically"""
        category = error_record.category
        
        if category not in self.healing_strategies:
            logger.info(f"No healing strategies for category: {category}")
            return False
        
        for strategy in self.healing_strategies[category]:
            try:
                logger.info(f"Attempting healing strategy: {strategy.__name__}")
                success = await strategy(error_record)
                error_record.healing_attempts += 1
                
                if success:
                    error_record.healed = True
                    logger.info(f"Healing successful with: {strategy.__name__}")
                    return True
                    
            except Exception as e:
                logger.warning(f"Healing strategy failed: {e}")
                continue
        
        logger.info("All healing strategies exhausted")
        return False
    
    async def _retry_with_backoff(self, error_record: ErrorRecord) -> bool:
        """Retry operation with exponential backoff"""
        # Implemented in RetryManager
        return False
    
    async def _check_service_health(self, error_record: ErrorRecord) -> bool:
        """Check if service is healthy before retrying"""
        # Basic implementation
        await asyncio.sleep(1)
        return True
    
    async def _clear_gpu_cache(self, error_record: ErrorRecord) -> bool:
        """Clear GPU memory cache"""
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                return True
        except:
            pass
        return False
    
    async def _reduce_batch_size(self, error_record: ErrorRecord) -> bool:
        """Reduce batch size in context"""
        # Would need context access to modify batch size
        return False
    
    async def _switch_to_cpu(self, error_record: ErrorRecord) -> bool:
        """Switch to CPU mode"""
        # Would need to modify global settings
        return False
    
    async def _free_memory(self, error_record: ErrorRecord) -> bool:
        """Attempt to free system memory"""
        try:
            import gc
            gc.collect()
            return True
        except:
            return False
    
    async def _clear_temp_files(self, error_record: ErrorRecord) -> bool:
        """Clear temporary files"""
        # Implementation would clear temp directories
        return False
    
    async def _restart_tool(self, error_record: ErrorRecord) -> bool:
        """Restart the failing tool"""
        # Would need tool registry
        return False
    
    async def _reset_tool_state(self, error_record: ErrorRecord) -> bool:
        """Reset tool to initial state"""
        return False


class RetryManager:
    """Intelligent retry mechanism with exponential backoff"""
    
    @staticmethod
    async def execute_with_retry(
        func: Callable,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        exponential_base: float = 2.0,
        retryable_exceptions: tuple = (Exception,)
    ) -> Any:
        """Execute function with exponential backoff retry"""
        last_exception = None
        
        for attempt in range(max_retries + 1):
            try:
                if asyncio.iscoroutinefunction(func):
                    return await func()
                else:
                    return func()
                    
            except retryable_exceptions as e:
                last_exception = e
                
                if attempt < max_retries:
                    # Calculate delay with exponential backoff
                    delay = min(base_delay * (exponential_base ** attempt), max_delay)
                    
                    logger.warning(
                        f"Attempt {attempt + 1}/{max_retries + 1} failed: {e}. "
                        f"Retrying in {delay:.1f}s..."
                    )
                    
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"All {max_retries + 1} attempts failed")
                    raise last_exception
        
        raise last_exception


class CircuitBreaker:
    """Circuit breaker pattern to prevent cascade failures"""
    
    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        half_open_max_calls: int = 3
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls
        
        self.failures: Dict[str, int] = {}
        self.last_failure_time: Dict[str, float] = {}
        self.state: Dict[str, str] = {}  # "closed", "open", "half-open"
        self.half_open_calls: Dict[str, int] = {}
    
    def can_execute(self, service: str) -> bool:
        """Check if service can execute"""
        current_state = self.state.get(service, "closed")
        
        if current_state == "closed":
            return True
        
        if current_state == "open":
            last_fail = self.last_failure_time.get(service, 0)
            if time.time() - last_fail >= self.recovery_timeout:
                self.state[service] = "half-open"
                self.half_open_calls[service] = 0
                logger.info(f"Circuit breaker for {service} entering half-open state")
                return True
            return False
        
        if current_state == "half-open":
            if self.half_open_calls.get(service, 0) < self.half_open_max_calls:
                self.half_open_calls[service] = self.half_open_calls.get(service, 0) + 1
                return True
            return False
        
        return True
    
    def record_success(self, service: str):
        """Record successful execution"""
        if self.state.get(service) == "half-open":
            self.state[service] = "closed"
            self.failures[service] = 0
            self.half_open_calls[service] = 0
            logger.info(f"Circuit breaker for {service} closed")
    
    def record_failure(self, service: str):
        """Record failed execution"""
        self.failures[service] = self.failures.get(service, 0) + 1
        self.last_failure_time[service] = time.time()
        
        if self.failures[service] >= self.failure_threshold:
            if self.state.get(service) != "open":
                self.state[service] = "open"
                logger.warning(f"Circuit breaker for {service} opened after {self.failures[service]} failures")


class ErrorLogger:
    """Centralized error logging system"""
    
    def __init__(self, log_dir: str = "./neural_doctor_logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        self.errors: List[ErrorRecord] = []
    
    def log_error(self, error_record: ErrorRecord):
        """Log error to file and memory"""
        self.errors.append(error_record)
        
        # Save to file
        log_file = self.log_dir / f"errors_{datetime.now().strftime('%Y%m%d')}.jsonl"
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(error_record.to_dict(), ensure_ascii=False) + "\n")
        
        # Also log to standard logger
        logger.error(f"[{error_record.category.value}] {error_record.message}")
    
    def get_recent_errors(self, n: int = 10) -> List[ErrorRecord]:
        """Get recent errors"""
        return sorted(self.errors, key=lambda x: x.timestamp, reverse=True)[:n]
    
    def get_errors_by_category(self, category: ErrorCategory) -> List[ErrorRecord]:
        """Get errors by category"""
        return [e for e in self.errors if e.category == category]
    
    def get_error_stats(self) -> Dict[str, Any]:
        """Get error statistics"""
        if not self.errors:
            return {"total": 0, "by_category": {}, "by_severity": {}}
        
        stats = {
            "total": len(self.errors),
            "by_category": {},
            "by_severity": {},
            "healed": sum(1 for e in self.errors if e.healed),
            "resolved": sum(1 for e in self.errors if e.resolved)
        }
        
        for error in self.errors:
            cat = error.category.value
            sev = error.severity.value
            stats["by_category"][cat] = stats["by_category"].get(cat, 0) + 1
            stats["by_severity"][sev] = stats["by_severity"].get(sev, 0) + 1
        
        return stats


class HealthMonitor:
    """System health monitoring"""
    
    def __init__(self, check_interval: float = 60.0):
        self.check_interval = check_interval
        self.last_check: Optional[datetime] = None
        self.health_history: List[HealthStatus] = []
        self._running = False
    
    async def start_monitoring(self):
        """Start continuous health monitoring"""
        self._running = True
        while self._running:
            status = await self.check_health()
            self.health_history.append(status)
            await asyncio.sleep(self.check_interval)
    
    def stop_monitoring(self):
        """Stop health monitoring"""
        self._running = False
    
    async def check_health(self) -> HealthStatus:
        """Perform comprehensive health check"""
        components = {
            "system": self._check_system_health(),
            "hardware": HardwareChecker.full_hardware_report(),
            "memory": self._check_memory()
        }
        
        # Determine overall status
        if all(c.get("status") == "healthy" for c in components.values() if isinstance(c, dict)):
            overall = "healthy"
        elif any(c.get("status") == "unhealthy" for c in components.values() if isinstance(c, dict)):
            overall = "unhealthy"
        else:
            overall = "degraded"
        
        self.last_check = datetime.now()
        
        return HealthStatus(
            timestamp=self.last_check,
            overall_status=overall,
            components=components
        )
    
    def _check_system_health(self) -> Dict[str, Any]:
        """Check system health"""
        return {"status": "healthy", "checks": {}}
    
    def _check_memory(self) -> Dict[str, Any]:
        """Check memory health"""
        try:
            import psutil
            mem = psutil.virtual_memory()
            
            status = "healthy"
            if mem.percent > 90:
                status = "unhealthy"
            elif mem.percent > 75:
                status = "degraded"
            
            return {
                "status": status,
                "total_gb": round(mem.total / (1024**3), 2),
                "used_gb": round(mem.used / (1024**3), 2),
                "percent": mem.percent
            }
        except ImportError:
            return {"status": "unknown", "error": "psutil not installed"}
    
    def get_health_report(self) -> Dict[str, Any]:
        """Get comprehensive health report"""
        if not self.health_history:
            return {"error": "No health data available"}
        
        latest = self.health_history[-1]
        return {
            "current_status": latest.to_dict(),
            "history_count": len(self.health_history),
            "uptime_checks": len([h for h in self.health_history if h.overall_status == "healthy"])
        }


class NeuralDoctor:
    """
    Main Neural Doctor class - Intelligent error handling system
    
    Simple usage:
        from neural_doctor import NeuralDoctor
        
        doctor = NeuralDoctor()
        
        # Check hardware
        report = doctor.check_hardware()
        print(report)
        
        # Monitor health
        await doctor.start_monitoring()
    """
    
    def __init__(self, llm=None, enable_monitoring: bool = False):
        self.classifier = ErrorClassifier()
        self.analyzer = RootCauseAnalyzer(llm)
        self.healing_engine = SelfHealingEngine()
        self.retry_manager = RetryManager()
        self.circuit_breaker = CircuitBreaker()
        self.error_logger = ErrorLogger()
        self.health_monitor = HealthMonitor()
        self.llm = llm
        
        if enable_monitoring:
            asyncio.create_task(self.health_monitor.start_monitoring())
    
    async def diagnose(self, error: Exception, context: Dict[str, Any] = None) -> ErrorRecord:
        """Complete error diagnosis"""
        context = context or {}
        
        # Classify error
        category = self.classifier.classify(error, context)
        severity = self.classifier.assess_severity(error, category)
        
        # Create error record
        error_id = f"err_{int(time.time() * 1000)}"
        record = ErrorRecord(
            id=error_id,
            timestamp=datetime.now(),
            category=category,
            severity=severity,
            error_type=type(error).__name__,
            message=str(error),
            stack_trace=traceback.format_exc(),
            context=context
        )
        
        # Analyze root cause
        record.root_cause = await self.analyzer.analyze(error, context)
        
        # Generate fix suggestions
        record.fix_suggestions = self.analyzer.suggest_fixes(error, category, record.root_cause)
        
        # Log error
        self.error_logger.log_error(record)
        
        return record
    
    async def heal(self, error_record: ErrorRecord) -> bool:
        """Attempt to heal error"""
        return await self.healing_engine.attempt_heal(error_record)
    
    async def execute_with_protection(
        self,
        func: Callable,
        context: Dict[str, Any] = None,
        max_retries: int = 3,
        service_name: str = "default"
    ) -> Any:
        """
        Execute function with full Neural Doctor protection
        
        Args:
            func: Function to execute
            context: Execution context for error diagnosis
            max_retries: Maximum retry attempts
            service_name: Service identifier for circuit breaker
        
        Returns:
            Function result
        
        Raises:
            Exception: If all healing and retry attempts fail
        """
        context = context or {}
        
        # Check circuit breaker
        if not self.circuit_breaker.can_execute(service_name):
            raise Exception(f"Circuit breaker is open for service: {service_name}")
        
        last_error = None
        
        for attempt in range(max_retries):
            try:
                result = await func() if asyncio.iscoroutinefunction(func) else func()
                self.circuit_breaker.record_success(service_name)
                return result
                
            except Exception as e:
                last_error = e
                
                # Diagnose error
                error_record = await self.diagnose(e, context)
                
                # Try healing
                healed = await self.heal(error_record)
                
                if healed:
                    # Retry after healing
                    continue
                else:
                    # Record failure for circuit breaker
                    self.circuit_breaker.record_failure(service_name)
                    
                    # Wait before retry
                    if attempt < max_retries - 1:
                        delay = min(2 ** attempt, 30)
                        logger.info(f"Waiting {delay}s before retry...")
                        await asyncio.sleep(delay)
        
        # All retries exhausted
        raise last_error
    
    def check_hardware(self) -> Dict[str, Any]:
        """Quick hardware check"""
        return HardwareChecker.full_hardware_report()
    
    async def start_monitoring(self):
        """Start health monitoring"""
        await self.health_monitor.start_monitoring()
    
    def stop_monitoring(self):
        """Stop health monitoring"""
        self.health_monitor.stop_monitoring()
    
    def get_health_report(self) -> Dict[str, Any]:
        """Get current health report"""
        return self.health_monitor.get_health_report()
    
    def get_error_stats(self) -> Dict[str, Any]:
        """Get error statistics"""
        return self.error_logger.get_error_stats()
    
    def get_recent_errors(self, n: int = 10) -> List[ErrorRecord]:
        """Get recent errors"""
        return self.error_logger.get_recent_errors(n)


# Simple wrapper functions for easy usage
doctor = None


def init_neural_doctor(llm=None, enable_monitoring: bool = False):
    """Initialize Neural Doctor globally"""
    global doctor
    doctor = NeuralDoctor(llm, enable_monitoring)
    return doctor


def get_doctor() -> NeuralDoctor:
    """Get global Neural Doctor instance"""
    global doctor
    if doctor is None:
        doctor = NeuralDoctor()
    return doctor


async def protected_execute(func: Callable, context: Dict = None, max_retries: int = 3):
    """Simple wrapper for protected execution"""
    doc = get_doctor()
    return await doc.execute_with_protection(func, context, max_retries)


def quick_health_check() -> Dict[str, Any]:
    """Quick hardware and system health check"""
    return HardwareChecker.full_hardware_report()


# Example usage
if __name__ == "__main__":
    async def demo():
        # Initialize
        doc = init_neural_doctor()
        
        # Check hardware
        print("=" * 50)
        print("HARDWARE CHECK")
        print("=" * 50)
        report = doc.check_hardware()
        print(json.dumps(report, indent=2))
        
        # Test error handling
        print("\n" + "=" * 50)
        print("ERROR HANDLING DEMO")
        print("=" * 50)
        
        try:
            def failing_func():
                raise ConnectionError("Network timeout")
            
            await doc.execute_with_protection(
                failing_func,
                context={"operation": "test_connection"},
                max_retries=1
            )
        except Exception as e:
            print(f"Final error: {e}")
            
        # Show error stats
        stats = doc.get_error_stats()
        print("\nError Stats:")
        print(json.dumps(stats, indent=2))
    
    asyncio.run(demo())
