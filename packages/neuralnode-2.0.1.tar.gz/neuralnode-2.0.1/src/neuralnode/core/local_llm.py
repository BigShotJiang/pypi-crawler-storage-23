"""
NeuralNode Core - Local LLM Interface
Ollama integration with advanced features
"""
import aiohttp
import asyncio
from typing import List, Dict, Optional, Any, AsyncGenerator
from .message import Message


class LocalLLM:
    """Local LLM interface via Ollama"""
    
    def __init__(self, model: str = "qwen3.5:4b", base_url: str = "http://localhost:11434"):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession()
        return self.session
    
    def chat(self, messages: List[Message], **options) -> Message:
        """Synchronous chat (for tool use)"""
        return asyncio.run(self.achat(messages, **options))
    
    async def achat(self, messages: List[Message], stream: bool = False, 
                    ollama_options: Optional[Dict] = None) -> Message:
        """Async chat with Ollama"""
        session = await self._get_session()
        
        # Convert messages to Ollama format
        ollama_messages = [msg.to_ollama_format() for msg in messages]
        
        payload = {
            "model": self.model,
            "messages": ollama_messages,
            "stream": stream,
        }
        
        if ollama_options:
            payload["options"] = ollama_options
        
        try:
            async with session.post(
                f"{self.base_url}/api/chat",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=120)
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return Message.assistant(data.get("message", {}).get("content", ""))
                else:
                    error_text = await response.text()
                    return Message.assistant(f"Error: HTTP {response.status} - {error_text}")
        except asyncio.TimeoutError:
            return Message.assistant("Error: Request timeout")
        except Exception as e:
            return Message.assistant(f"Error: {str(e)}")
    
    async def generate(self, prompt: str, images: Optional[List[str]] = None,
                       **options) -> str:
        """Generate text with optional images (vision)"""
        session = await self._get_session()
        
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
        }
        
        if images:
            payload["images"] = images
        
        if options:
            payload["options"] = options
        
        try:
            async with session.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=120)
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("response", "")
                else:
                    return f"Error: HTTP {response.status}"
        except Exception as e:
            return f"Error: {str(e)}"
    
    async def stream_chat(self, messages: List[Message], 
                          **options) -> AsyncGenerator[str, None]:
        """Stream chat response token by token"""
        session = await self._get_session()
        
        ollama_messages = [msg.to_ollama_format() for msg in messages]
        
        payload = {
            "model": self.model,
            "messages": ollama_messages,
            "stream": True,
        }
        
        if options:
            payload["options"] = options
        
        try:
            async with session.post(
                f"{self.base_url}/api/chat",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=120)
            ) as response:
                async for line in response.content:
                    if line:
                        try:
                            data = eval(line.decode())
                            if "message" in data and "content" in data["message"]:
                                yield data["message"]["content"]
                        except:
                            pass
        except Exception as e:
            yield f"Error: {str(e)}"
    
    async def list_models(self) -> List[str]:
        """List available models from Ollama"""
        session = await self._get_session()
        
        try:
            async with session.get(f"{self.base_url}/api/tags") as response:
                if response.status == 200:
                    data = await response.json()
                    return [m["name"] for m in data.get("models", [])]
                return []
        except:
            return []
    
    async def close(self):
        """Close HTTP session"""
        if self.session and not self.session.closed:
            await self.session.close()
