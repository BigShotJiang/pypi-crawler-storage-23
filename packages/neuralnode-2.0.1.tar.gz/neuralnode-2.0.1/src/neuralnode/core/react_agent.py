"""
NeuralNode Core - ReAct Agent
Advanced reasoning and acting agent with tool integration
"""
import re
import asyncio
from typing import List, Dict, Optional, Any
from dataclasses import dataclass
from .local_llm import LocalLLM
from .message import Message
from .base_tool import BaseTool, ToolResult


@dataclass
class AgentStep:
    """Single step in agent execution"""
    step_number: int
    thought: str
    action: Optional[str]
    action_input: Optional[Dict]
    observation: Optional[str]
    final_answer: Optional[str]


class ReActAgent:
    """
    ReAct (Reasoning + Acting) Agent
    Implements the ReAct pattern: Thought -> Action -> Observation
    """
    
    def __init__(self, llm: LocalLLM, tools: List[BaseTool], 
                 system_prompt: str, max_iterations: int = 15):
        self.llm = llm
        self.tools = {tool.name: tool for tool in tools}
        self.system_prompt = system_prompt
        self.max_iterations = max_iterations
        self.execution_history: List[AgentStep] = []
    
    async def arun(self, query: str, context: str = "") -> str:
        """
        Run the agent on a query
        
        Args:
            query: The user query
            context: Additional context
            
        Returns:
            Final answer from the agent
        """
        # Build initial prompt
        tools_desc = self._build_tools_description()
        
        prompt = f"""{self.system_prompt}

Available Tools:
{tools_desc}

{context}

User Query: {query}

Think step by step. Use the format:
Thought: [your reasoning]
Action: tool_name Input: {{"param": "value"}}
Observation: [tool result]
...
Final Answer: [your response to the user]

Begin:
"""
        
        messages = [
            Message.system(self.system_prompt),
            Message.user(prompt)
        ]
        
        iteration = 0
        self.execution_history = []
        
        while iteration < self.max_iterations:
            iteration += 1
            
            # Get LLM response
            response = await self.llm.achat(messages)
            response_text = response.content
            
            # Check for final answer
            if "Final Answer:" in response_text:
                final_answer = self._extract_final_answer(response_text)
                self.execution_history.append(AgentStep(
                    step_number=iteration,
                    thought=response_text,
                    action=None,
                    action_input=None,
                    observation=None,
                    final_answer=final_answer
                ))
                return final_answer
            
            # Extract thought and action
            thought = self._extract_thought(response_text)
            action_name, action_input = self._extract_action(response_text)
            
            if not action_name or action_name not in self.tools:
                # No valid action found, treat as final answer
                return response_text.strip()
            
            # Execute tool
            tool = self.tools[action_name]
            try:
                result = tool.execute(**action_input)
                observation = result.content if result.success else f"Error: {result.error}"
            except Exception as e:
                observation = f"Error executing {action_name}: {str(e)}"
            
            # Record step
            self.execution_history.append(AgentStep(
                step_number=iteration,
                thought=thought,
                action=action_name,
                action_input=action_input,
                observation=observation,
                final_answer=None
            ))
            
            # Add to conversation
            messages.append(Message.assistant(response_text))
            messages.append(Message.user(f"Observation: {observation}\n\nContinue:"))
        
        return "Maximum iterations reached. Here's what I found:\n" + \
               "\n".join([f"Step {s.step_number}: {s.thought[:100]}..." for s in self.execution_history])
    
    def run(self, query: str, context: str = "") -> str:
        """Synchronous version"""
        return asyncio.run(self.arun(query, context))
    
    def _build_tools_description(self) -> str:
        """Build description of all available tools"""
        descriptions = []
        for name, tool in self.tools.items():
            params = ", ".join([f"{p}: {s.type}" for p, s in tool.parameters.items()])
            descriptions.append(f"- {name}: {tool.description} (Params: {params})")
        return "\n".join(descriptions)
    
    def _extract_thought(self, text: str) -> str:
        """Extract thought from response"""
        match = re.search(r"Thought:\s*(.+?)(?=Action:|Final Answer:|$)", text, re.DOTALL)
        return match.group(1).strip() if match else text.strip()
    
    def _extract_action(self, text: str) -> tuple[Optional[str], Optional[Dict]]:
        """Extract action name and input from response"""
        # Match Action: tool_name Input: {...}
        match = re.search(r"Action:\s*(\w+)\s*Input:\s*(\{.*?\})", text, re.DOTALL)
        if match:
            action_name = match.group(1).strip()
            try:
                import json
                action_input = json.loads(match.group(2))
                return action_name, action_input
            except:
                return action_name, {}
        
        # Fallback: just action name
        match = re.search(r"Action:\s*(\w+)", text)
        if match:
            return match.group(1).strip(), {}
        
        return None, None
    
    def _extract_final_answer(self, text: str) -> str:
        """Extract final answer from response"""
        match = re.search(r"Final Answer:\s*(.+)$", text, re.DOTALL)
        return match.group(1).strip() if match else text.strip()
    
    def get_execution_trace(self) -> List[AgentStep]:
        """Get full execution history"""
        return self.execution_history
