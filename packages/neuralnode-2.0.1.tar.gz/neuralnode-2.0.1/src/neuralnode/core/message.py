"""
NeuralNode Core - Message Class
Standardized message format for LLM conversations
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime
from enum import Enum


class MessageRole(Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass
class Message:
    """Standard message format"""
    role: MessageRole
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    tool_calls: Optional[List[Dict]] = None
    tool_results: Optional[List[Dict]] = None
    
    @classmethod
    def system(cls, content: str, **metadata) -> "Message":
        """Create system message"""
        return cls(role=MessageRole.SYSTEM, content=content, metadata=metadata)
    
    @classmethod
    def user(cls, content: str, **metadata) -> "Message":
        """Create user message"""
        return cls(role=MessageRole.USER, content=content, metadata=metadata)
    
    @classmethod
    def assistant(cls, content: str, **metadata) -> "Message":
        """Create assistant message"""
        return cls(role=MessageRole.ASSISTANT, content=content, metadata=metadata)
    
    @classmethod
    def tool(cls, content: str, tool_name: str, **metadata) -> "Message":
        """Create tool result message"""
        metadata["tool_name"] = tool_name
        return cls(role=MessageRole.TOOL, content=content, metadata=metadata)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format"""
        return {
            "role": self.role.value,
            "content": self.content,
            **self.metadata,
        }
    
    def to_ollama_format(self) -> Dict[str, Any]:
        """Convert to Ollama API format"""
        result = {
            "role": self.role.value,
            "content": self.content,
        }
        if "images" in self.metadata:
            result["images"] = self.metadata["images"]
        return result
    
    def to_openai_format(self) -> Dict[str, Any]:
        """Convert to OpenAI API format"""
        result = {
            "role": self.role.value,
            "content": self.content,
        }
        if self.tool_calls:
            result["tool_calls"] = self.tool_calls
        return result
