"""
NeuralNode Core - Utils
Utility functions for the framework
"""
import re
import time
import socket
import subprocess
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def clean_agent_response(text: str) -> str:
    """Removes Thought/Action/Final Answer markers for a cleaner Telegram experience."""
    if not text:
        return text

    original = text

    # Remove "Thought: ...", "Action: ...", "PARAMETERS: ...", "Input: ..."
    text = re.sub(r'(?i)Thought:.*?(?=Action:|Final Answer:|$)', '', text, flags=re.DOTALL)
    text = re.sub(r'(?i)Action:.*?\n', '', text)
    text = re.sub(r'(?i)(PARAMETERS|Input):.*?\n', '', text, flags=re.DOTALL)

    # Remove "Final Answer:" label itself
    text = re.sub(r'(?i)Final Answer:\s*', '', text)

    # If cleaning removed EVERYTHING, return the original text
    cleaned = text.strip()
    if "Maximum iterations reached" in cleaned:
        return "I tried to process that, but the loop took too long. Please try again or be more specific!"
    return cleaned if cleaned else original.strip()


async def generate_voice_file(text: str, output_path: str):
    """Generates an MP3 file using edge_tts."""
    try:
        import edge_tts
        communicate = edge_tts.Communicate(text, "en-US-EmmaNeural")
        await communicate.save(output_path)
        return True
    except Exception as e:
        logger.error(f"TTS Generation failed: {e}")
        return False


def ensure_ollama_running(ollama_path: str = r"C:\Users\Assem\AppData\Local\Programs\Ollama\ollama.exe"):
    """Starts Ollama server if not already running."""

    # Check if Ollama is already listening on default port
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if s.connect_ex(('localhost', 11434)) == 0:
            logger.info("Ollama server is already running.")
            return True

    # Try to start it
    if not Path(ollama_path).exists():
        logger.warning(f"Ollama executable not found at {ollama_path}. Please check the path.")
        return False

    logger.info("Starting Ollama server...")
    try:
        # 0x00000010 is CREATE_NEW_CONSOLE on Windows
        creationflags = 0x00000010 if __import__('os').name == 'nt' else 0
        subprocess.Popen([ollama_path, "serve"],
                        creationflags=creationflags,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL)

        # Wait for it to wake up
        for _ in range(15):
            time.sleep(1)
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                if s.connect_ex(('localhost', 11434)) == 0:
                    logger.info("Ollama server started successfully.")
                    return True
        logger.error("Ollama server failed to start within 15 seconds.")
        return False
    except Exception as e:
        logger.error(f"Failed to launch Ollama: {e}")
        return False
