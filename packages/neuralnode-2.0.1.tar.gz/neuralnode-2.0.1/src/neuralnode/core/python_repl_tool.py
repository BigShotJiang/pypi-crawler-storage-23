"""
NeuralNode Core - Python REPL Tool
Execute Python code dynamically
"""
import io
import sys
import traceback
from typing import Dict, Any
from .base_tool import BaseTool, ToolResult, ParameterSpec


class PythonREPLTool(BaseTool):
    """Execute Python code and return the result"""
    
    name = "python_repl"
    description = "Execute Python code and return the output. Use for calculations, data processing, or any Python task."
    parameters = {
        "code": ParameterSpec(
            type="string",
            description="Python code to execute",
            required=True
        )
    }
    
    def __init__(self):
        self.globals = {
            "__name__": "__repl__",
            "__builtins__": __builtins__,
        }
        self.locals = {}
    
    def execute(self, code: str = "", **kwargs) -> ToolResult:
        """Execute Python code safely"""
        code = code or kwargs.get("code", "")
        if not code:
            return ToolResult.error("No code provided")
        
        # Capture stdout
        old_stdout = sys.stdout
        stdout_capture = io.StringIO()
        sys.stdout = stdout_capture
        
        try:
            # Execute code
            exec(code, self.globals, self.locals)
            
            # Get output
            output = stdout_capture.getvalue()
            
            # Reset stdout
            sys.stdout = old_stdout
            
            # Return result
            if output.strip():
                return ToolResult.ok(content=output.strip())
            else:
                return ToolResult.ok(content="Code executed successfully (no output)")
                
        except Exception as e:
            sys.stdout = old_stdout
            error_msg = f"Error: {str(e)}\n{traceback.format_exc()}"
            return ToolResult.error(error_msg[:500])  # Limit error length
    
    def reset(self):
        """Reset the REPL environment"""
        self.globals = {
            "__name__": "__repl__",
            "__builtins__": __builtins__,
        }
        self.locals = {}
