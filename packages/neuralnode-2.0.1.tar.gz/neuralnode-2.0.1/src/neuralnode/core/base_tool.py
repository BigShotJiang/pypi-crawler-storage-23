"""
NeuralNode Core - Base Tool Classes
Foundation for all agent tools
"""
from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from abc import ABC, abstractmethod


@dataclass
class ParameterSpec:
    """Specification for a tool parameter"""
    type: str
    description: str
    required: bool = True
    default: Any = None
    enum: Optional[list] = None


@dataclass
class ToolResult:
    """Result from tool execution"""
    success: bool
    content: str
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def ok(cls, content: str, **metadata) -> "ToolResult":
        """Create successful result"""
        return cls(success=True, content=content, metadata=metadata)
    
    @classmethod
    def error(cls, error: str, **metadata) -> "ToolResult":
        """Create error result"""
        return cls(success=False, content="", error=error, metadata=metadata)


class BaseTool(ABC):
    """Abstract base class for all agent tools"""
    
    name: str = ""
    description: str = ""
    parameters: Dict[str, ParameterSpec] = {}
    
    def __init__(self):
        pass
    
    @abstractmethod
    def execute(self, **kwargs) -> ToolResult:
        """Execute the tool with given parameters"""
        pass
    
    def get_schema(self) -> Dict[str, Any]:
        """Get JSON schema for tool"""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": {
                name: {
                    "type": spec.type,
                    "description": spec.description,
                    "required": spec.required,
                    **({"default": spec.default} if spec.default is not None else {}),
                    **({"enum": spec.enum} if spec.enum else {}),
                }
                for name, spec in self.parameters.items()
            },
        }
    
    def validate_params(self, params: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """Validate parameters against spec"""
        for name, spec in self.parameters.items():
            if spec.required and name not in params:
                return False, f"Required parameter '{name}' missing"
            
            if name in params and spec.enum and params[name] not in spec.enum:
                return False, f"Parameter '{name}' must be one of: {spec.enum}"
        
        return True, None
