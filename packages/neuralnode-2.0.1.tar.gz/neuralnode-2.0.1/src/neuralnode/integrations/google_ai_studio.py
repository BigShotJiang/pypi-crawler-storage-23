"""
Google AI Studio Integration for NeuralNode
Provides access to Gemini and Gemma models via Google AI Studio API
"""
import aiohttp
import asyncio
from typing import List, Dict, Optional, Any, AsyncGenerator
import json
from dataclasses import dataclass


@dataclass
class GoogleAIConfig:
    """Configuration for Google AI Studio"""
    api_key: str
    model: str = "gemini-1.5-flash"  # Lightweight, cost-effective model
    base_url: str = "https://generativelanguage.googleapis.com/v1beta"
    temperature: float = 0.7
    max_tokens: int = 2048


class GoogleAILLM:
    """
    Google AI Studio LLM Interface
    Supports Gemini Flash, Gemini Pro, and Gemma models
    """
    
    # Available lightweight models
    LIGHTWEIGHT_MODELS = {
        "gemini-1.5-flash": "Gemini 1.5 Flash - Fast & cost-effective",
        "gemini-1.5-flash-8b": "Gemini 1.5 Flash 8B - Ultra lightweight",
        "gemma-2-2b": "Gemma 2 2B - Open lightweight model",
        "gemma-2-4b": "Gemma 2 4B - Balanced lightweight",
    }
    
    def __init__(self, api_key: str, model: str = "gemini-1.5-flash"):
        """
        Initialize Google AI Studio LLM
        
        Args:
            api_key: Google AI Studio API key
            model: Model name (gemini-1.5-flash, gemma-2-2b, etc.)
        """
        self.config = GoogleAIConfig(api_key=api_key, model=model)
        self.session: Optional[aiohttp.ClientSession] = None
        
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession()
        return self.session
    
    def _build_url(self) -> str:
        """Build API URL for the model"""
        return f"{self.config.base_url}/models/{self.config.model}:generateContent?key={self.config.api_key}"
    
    def _build_stream_url(self) -> str:
        """Build streaming API URL"""
        return f"{self.config.base_url}/models/{self.config.model}:streamGenerateContent?key={self.config.api_key}"
    
    def _convert_messages(self, messages: List[Any]) -> List[Dict]:
        """Convert NeuralNode messages to Gemini format"""
        gemini_messages = []
        
        for msg in messages:
            role = "user" if msg.role.value in ["user", "system"] else "model"
            gemini_messages.append({
                "role": role,
                "parts": [{"text": msg.content}]
            })
        
        return gemini_messages
    
    async def achat(self, messages: List[Any], **kwargs) -> Any:
        """
        Async chat with Google AI
        
        Args:
            messages: List of Message objects
            **kwargs: Additional parameters (temperature, max_tokens)
        
        Returns:
            Message object with response
        """
        from neuralnode import Message
        
        session = await self._get_session()
        
        # Build request
        contents = self._convert_messages(messages)
        
        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": kwargs.get("temperature", self.config.temperature),
                "maxOutputTokens": kwargs.get("max_tokens", self.config.max_tokens),
                "topP": kwargs.get("top_p", 0.9),
                "topK": kwargs.get("top_k", 40),
            }
        }
        
        try:
            async with session.post(
                self._build_url(),
                json=payload,
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    # Extract response text
                    if "candidates" in data and len(data["candidates"]) > 0:
                        candidate = data["candidates"][0]
                        if "content" in candidate and "parts" in candidate["content"]:
                            text = candidate["content"]["parts"][0].get("text", "")
                            return Message.assistant(text)
                    
                    return Message.assistant("No response from model")
                else:
                    error_text = await response.text()
                    return Message.assistant(f"Error: HTTP {response.status} - {error_text}")
                    
        except Exception as e:
            return Message.assistant(f"Error: {str(e)}")
    
    async def stream_chat(self, messages: List[Any], **kwargs) -> AsyncGenerator[str, None]:
        """
        Stream chat response from Google AI
        """
        session = await self._get_session()
        
        contents = self._convert_messages(messages)
        
        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": kwargs.get("temperature", self.config.temperature),
                "maxOutputTokens": kwargs.get("max_tokens", self.config.max_tokens),
            }
        }
        
        try:
            async with session.post(
                self._build_stream_url(),
                json=payload,
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status == 200:
                    # Process streaming response
                    async for line in response.content:
                        if line:
                            try:
                                data = json.loads(line)
                                if "candidates" in data:
                                    candidate = data["candidates"][0]
                                    if "content" in candidate:
                                        text = candidate["content"]["parts"][0].get("text", "")
                                        yield text
                            except:
                                pass
                else:
                    yield f"Error: HTTP {response.status}"
                    
        except Exception as e:
            yield f"Error: {str(e)}"
    
    def chat(self, messages: List[Any], **kwargs) -> Any:
        """Synchronous version"""
        return asyncio.run(self.achat(messages, **kwargs))
    
    async def generate(self, prompt: str, **kwargs) -> str:
        """Generate text from a single prompt"""
        from neuralnode import Message
        messages = [Message.user(prompt)]
        response = await self.achat(messages, **kwargs)
        return response.content
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """List available models"""
        session = await self._get_session()
        
        url = f"{self.config.base_url}/models?key={self.config.api_key}"
        
        try:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("models", [])
                return []
        except:
            return []
    
    async def close(self):
        """Close HTTP session"""
        if self.session and not self.session.closed:
            await self.session.close()


class GoogleAIManager:
    """
    Manager for switching between Ollama, LM Studio, and Google AI
    """
    
    def __init__(self):
        self.ollama = None
        self.lm_studio = None
        self.google_ai = None
        self.active_backend = "ollama"  # default
    
    async def initialize_google_ai(self, api_key: str, model: str = "gemini-1.5-flash"):
        """Initialize Google AI Studio backend"""
        self.google_ai = GoogleAILLM(api_key=api_key, model=model)
        self.active_backend = "google_ai"
    
    def get_active_llm(self):
        """Get currently active LLM"""
        if self.active_backend == "google_ai" and self.google_ai:
            return self.google_ai
        elif self.active_backend == "lm_studio" and self.lm_studio:
            return self.lm_studio
        return self.ollama
    
    def switch_backend(self, backend: str):
        """Switch between backends"""
        if backend in ["ollama", "lm_studio", "google_ai"]:
            self.active_backend = backend


# Quick test
async def test_google_ai():
    """Test Google AI Studio integration"""
    import os
    
    api_key = os.getenv("GOOGLE_API_KEY", "")
    if not api_key:
        print("❌ GOOGLE_API_KEY not set")
        return
    
    print("Testing Google AI Studio integration...")
    
    llm = GoogleAILLM(api_key=api_key, model="gemini-1.5-flash")
    
    # Test simple generation
    from neuralnode import Message
    messages = [
        Message.system("You are a helpful assistant."),
        Message.user("Say 'Hello from Gemini!' and nothing else.")
    ]
    
    response = await llm.achat(messages)
    print(f"Response: {response.content}")
    
    # List available models
    print("\nAvailable models:")
    models = await llm.list_models()
    for model in models[:5]:  # Show first 5
        print(f"  - {model.get('name', 'unknown')}")
    
    await llm.close()


if __name__ == "__main__":
    asyncio.run(test_google_ai())
