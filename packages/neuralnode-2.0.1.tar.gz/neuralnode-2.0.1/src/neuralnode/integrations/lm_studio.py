"""
LM Studio Integration for NeuralNode
Direct integration with LM Studio local inference server
"""
import aiohttp
import asyncio
from typing import List, Dict, Optional, Any, AsyncGenerator
from ..core.message import Message


class LMStudioLLM:
    """
    LM Studio LLM Interface
    Connects to LM Studio's local inference server
    Default: http://localhost:1234 (LM Studio's default port)
    """
    
    def __init__(self, 
                 base_url: str = "http://localhost:1234",
                 model: Optional[str] = None,
                 timeout: int = 120):
        self.base_url = base_url.rstrip("/")
        self.model = model  # LM Studio auto-loads the model
        self.timeout = timeout
        self.session: Optional[aiohttp.ClientSession] = None
        self.api_endpoint = f"{self.base_url}/v1/chat/completions"
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession()
        return self.session
    
    async def check_connection(self) -> Dict[str, Any]:
        """Check if LM Studio is running and accessible"""
        try:
            session = await self._get_session()
            async with session.get(
                f"{self.base_url}/v1/models",
                timeout=aiohttp.ClientTimeout(total=10)
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "connected": True,
                        "models": data.get("data", []),
                        "error": None
                    }
                else:
                    return {
                        "connected": False,
                        "models": [],
                        "error": f"HTTP {response.status}"
                    }
        except Exception as e:
            return {
                "connected": False,
                "models": [],
                "error": str(e)
            }
    
    async def achat(self, 
                    messages: List[Message], 
                    temperature: float = 0.7,
                    max_tokens: int = 2000,
                    stream: bool = False) -> Message:
        """
        Async chat with LM Studio
        Uses OpenAI-compatible API
        """
        session = await self._get_session()
        
        # Convert messages to OpenAI format
        openai_messages = [msg.to_openai_format() for msg in messages]
        
        payload = {
            "messages": openai_messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
        }
        
        # Add model if specified
        if self.model:
            payload["model"] = self.model
        
        try:
            async with session.post(
                self.api_endpoint,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    # Extract response
                    if "choices" in data and len(data["choices"]) > 0:
                        choice = data["choices"][0]
                        if "message" in choice:
                            content = choice["message"].get("content", "")
                            return Message.assistant(content)
                    
                    return Message.assistant("No response from model")
                else:
                    error_text = await response.text()
                    return Message.assistant(f"Error: HTTP {response.status} - {error_text}")
                    
        except asyncio.TimeoutError:
            return Message.assistant("Error: Request timeout")
        except Exception as e:
            return Message.assistant(f"Error: {str(e)}")
    
    def chat(self, messages: List[Message], **kwargs) -> Message:
        """Synchronous version"""
        return asyncio.run(self.achat(messages, **kwargs))
    
    async def generate(self, 
                       prompt: str, 
                       temperature: float = 0.7,
                       max_tokens: int = 2000) -> str:
        """Generate text from a single prompt"""
        messages = [Message.user(prompt)]
        response = await self.achat(messages, temperature=temperature, max_tokens=max_tokens)
        return response.content
    
    async def stream_chat(self, 
                          messages: List[Message],
                          temperature: float = 0.7,
                          max_tokens: int = 2000) -> AsyncGenerator[str, None]:
        """
        Stream chat response from LM Studio
        """
        session = await self._get_session()
        
        openai_messages = [msg.to_openai_format() for msg in messages]
        
        payload = {
            "messages": openai_messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
        }
        
        if self.model:
            payload["model"] = self.model
        
        try:
            async with session.post(
                self.api_endpoint,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            ) as response:
                if response.status == 200:
                    # Read streaming response
                    async for line in response.content:
                        if line:
                            line_text = line.decode('utf-8').strip()
                            
                            # SSE format: data: {...}
                            if line_text.startswith("data: "):
                                json_str = line_text[6:]  # Remove "data: "
                                
                                if json_str == "[DONE]":
                                    break
                                
                                try:
                                    import json
                                    data = json.loads(json_str)
                                    
                                    if "choices" in data and len(data["choices"]) > 0:
                                        delta = data["choices"][0].get("delta", {})
                                        if "content" in delta:
                                            yield delta["content"]
                                except:
                                    pass
                else:
                    yield f"Error: HTTP {response.status}"
                    
        except Exception as e:
            yield f"Error: {str(e)}"
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """List available models in LM Studio"""
        session = await self._get_session()
        
        try:
            async with session.get(
                f"{self.base_url}/v1/models",
                timeout=aiohttp.ClientTimeout(total=10)
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("data", [])
                return []
        except:
            return []
    
    async def unload_model(self) -> bool:
        """Unload current model to free VRAM"""
        try:
            session = await self._get_session()
            async with session.post(
                f"{self.base_url}/v1/internal/model/unload",
                timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                return response.status == 200
        except:
            return False
    
    async def close(self):
        """Close HTTP session"""
        if self.session and not self.session.closed:
            await self.session.close()


class LMStudioManager:
    """
    Manager for switching between Ollama and LM Studio
    """
    
    def __init__(self):
        self.ollama = None
        self.lm_studio = None
        self.active_backend = "ollama"  # default
    
    async def initialize_ollama(self, model: str = "qwen3.5:4b"):
        """Initialize Ollama backend"""
        from ..core.local_llm import LocalLLM
        self.ollama = LocalLLM(model=model)
        self.active_backend = "ollama"
    
    async def initialize_lm_studio(self, base_url: str = "http://localhost:1234"):
        """Initialize LM Studio backend"""
        self.lm_studio = LMStudioLLM(base_url=base_url)
        self.active_backend = "lm_studio"
    
    async def check_lm_studio_available(self) -> bool:
        """Check if LM Studio is running"""
        if self.lm_studio is None:
            self.lm_studio = LMStudioLLM()
        
        status = await self.lm_studio.check_connection()
        return status["connected"]
    
    def get_active_llm(self):
        """Get currently active LLM"""
        if self.active_backend == "lm_studio" and self.lm_studio:
            return self.lm_studio
        return self.ollama
    
    def switch_backend(self, backend: str):
        """Switch between backends"""
        if backend in ["ollama", "lm_studio"]:
            self.active_backend = backend


# Quick test
async def test_lm_studio():
    """Test LM Studio connection"""
    print("Testing LM Studio integration...")
    
    llm = LMStudioLLM()
    
    # Check connection
    status = await llm.check_connection()
    print(f"Connection: {status}")
    
    if status["connected"]:
        # Test chat
        print("\nTesting chat...")
        messages = [
            Message.system("You are a helpful assistant."),
            Message.user("Say 'Hello from LM Studio!' and nothing else.")
        ]
        
        response = await llm.achat(messages)
        print(f"Response: {response.content}")
        
        # Test streaming
        print("\nTesting streaming...")
        async for token in llm.stream_chat(messages):
            print(token, end="", flush=True)
        print()
    else:
        print("LM Studio not running. Start it and try again.")
    
    await llm.close()


if __name__ == "__main__":
    asyncio.run(test_lm_studio())
