"""
WhatsApp Integration for NeuralNode
Multiple integration methods for WhatsApp messaging
"""
import asyncio
import aiohttp
import json
import base64
from typing import Optional, List, Dict, Callable
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


@dataclass
class WhatsAppMessage:
    """WhatsApp message structure"""
    message_id: str
    from_number: str
    to_number: str
    text: Optional[str]
    media_url: Optional[str]
    media_type: Optional[str]  # 'image', 'video', 'audio', 'document'
    timestamp: datetime
    is_from_user: bool


class WhatsAppBusinessAPI:
    """
    WhatsApp Business API Integration
    For production use with Meta's official API
    Requires: WhatsApp Business Account, access token
    """
    
    API_VERSION = "v17.0"
    BASE_URL = "https://graph.facebook.com"
    
    def __init__(self, 
                 phone_number_id: str,
                 access_token: str,
                 business_account_id: Optional[str] = None):
        self.phone_number_id = phone_number_id
        self.access_token = access_token
        self.business_account_id = business_account_id
        self.base_url = f"{self.BASE_URL}/{self.API_VERSION}"
    
    async def send_text_message(self, 
                                to_number: str, 
                                text: str,
                                preview_url: bool = True) -> Dict:
        """Send text message via WhatsApp Business API"""
        url = f"{self.base_url}/{self.phone_number_id}/messages"
        
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to_number,
            "type": "text",
            "text": {
                "preview_url": preview_url,
                "body": text
            }
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=payload) as response:
                    data = await response.json()
                    return {
                        "success": response.status == 200,
                        "response": data,
                        "status_code": response.status
                    }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def send_image(self, 
                         to_number: str, 
                         image_url: str,
                         caption: Optional[str] = None) -> Dict:
        """Send image message"""
        url = f"{self.base_url}/{self.phone_number_id}/messages"
        
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to_number,
            "type": "image",
            "image": {
                "link": image_url,
                **({"caption": caption} if caption else {})
            }
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=payload) as response:
                    data = await response.json()
                    return {
                        "success": response.status == 200,
                        "response": data
                    }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def send_audio(self, to_number: str, audio_url: str) -> Dict:
        """Send audio/voice message"""
        url = f"{self.base_url}/{self.phone_number_id}/messages"
        
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to_number,
            "type": "audio",
            "audio": {
                "link": audio_url
            }
        }
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=payload) as response:
                    data = await response.json()
                    return {
                        "success": response.status == 200,
                        "response": data
                    }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def verify_webhook(self, 
                             mode: str, 
                             token: str, 
                             challenge: str,
                             verify_token: str) -> Optional[str]:
        """Verify webhook subscription"""
        if mode == "subscribe" and token == verify_token:
            return challenge
        return None
    
    async def process_webhook(self, data: Dict) -> List[WhatsAppMessage]:
        """Process incoming webhook data"""
        messages = []
        
        entries = data.get("entry", [])
        for entry in entries:
            changes = entry.get("changes", [])
            for change in changes:
                value = change.get("value", {})
                
                # Check for messages
                if "messages" in value:
                    for msg in value["messages"]:
                        wa_msg = WhatsAppMessage(
                            message_id=msg.get("id", ""),
                            from_number=msg.get("from", ""),
                            to_number=value.get("metadata", {}).get("phone_number_id", ""),
                            text=msg.get("text", {}).get("body") if msg.get("type") == "text" else None,
                            media_url=None,  # Would need to download media
                            media_type=msg.get("type") if msg.get("type") != "text" else None,
                            timestamp=datetime.now(),
                            is_from_user=True
                        )
                        messages.append(wa_msg)
        
        return messages


class WhatsAppWebIntegration:
    """
    WhatsApp Web Integration (Unofficial)
    Uses whatsapp-web.js via Python bridge or pywhatkit
    For development/testing only - not for production
    """
    
    def __init__(self):
        self.session_active = False
        self.qr_callback: Optional[Callable] = None
        self.message_callbacks: List[Callable] = []
    
    async def start_session(self, 
                           headless: bool = False,
                           qr_callback: Optional[Callable] = None) -> bool:
        """
        Start WhatsApp Web session
        Shows QR code for authentication
        """
        try:
            # Try to use pywhatsApp (if available)
            import pywhatkit
            self.session_active = True
            return True
        except ImportError:
            print("⚠️ pywhatkit not installed. Run: pip install pywhatkit")
            return False
    
    async def send_message(self, 
                          phone_number: str, 
                          message: str,
                          wait_time: int = 15) -> bool:
        """
        Send message via WhatsApp Web
        Note: This opens browser window
        """
        try:
            import pywhatkit
            
            # Format phone number
            if not phone_number.startswith("+"):
                phone_number = "+" + phone_number
            
            # Send instantly
            pywhatkit.sendwhatmsg_to_instantly(
                phone_number, 
                message,
                wait_time=wait_time
            )
            
            return True
            
        except Exception as e:
            print(f"Error sending WhatsApp message: {e}")
            return False
    
    async def send_image(self,
                        phone_number: str,
                        image_path: str,
                        caption: str = "") -> bool:
        """Send image via WhatsApp Web"""
        try:
            # pywhatkit doesn't support images directly
            # Would need to use selenium or playwright directly
            print("⚠️ Image sending requires additional setup with Selenium")
            return False
        except Exception as e:
            print(f"Error: {e}")
            return False
    
    def close_session(self):
        """Close WhatsApp Web session"""
        self.session_active = False


class WhatsAppAgentBot:
    """
    Complete WhatsApp bot with AI agent integration
    """
    
    def __init__(self,
                 method: str = "business_api",
                 phone_number_id: Optional[str] = None,
                 access_token: Optional[str] = None):
        """
        Initialize WhatsApp bot
        
        Args:
            method: 'business_api' (production) or 'web' (development)
            phone_number_id: Required for business_api
            access_token: Required for business_api
        """
        self.method = method
        self.agent = None  # Will be set later
        
        if method == "business_api":
            if not phone_number_id or not access_token:
                raise ValueError("phone_number_id and access_token required for Business API")
            self.whatsapp = WhatsAppBusinessAPI(phone_number_id, access_token)
        else:
            self.whatsapp = WhatsAppWebIntegration()
        
        self.authorized_numbers: List[str] = []
    
    def set_agent(self, agent):
        """Set AI agent for responding to messages"""
        self.agent = agent
    
    def authorize_number(self, phone_number: str):
        """Add authorized phone number"""
        # Normalize
        if not phone_number.startswith("+"):
            phone_number = "+" + phone_number
        self.authorized_numbers.append(phone_number)
    
    async def handle_incoming_message(self, message: WhatsAppMessage):
        """Process incoming message and respond"""
        # Check authorization
        from_number = message.from_number
        if from_number not in self.authorized_numbers:
            print(f"Unauthorized number: {from_number}")
            return
        
        if not self.agent:
            print("No agent set")
            return
        
        # Process with agent
        try:
            if asyncio.iscoroutinefunction(self.agent.arun):
                response = await self.agent.arun(message.text or "")
            else:
                response = self.agent.run(message.text or "")
            
            # Send response
            if self.method == "business_api":
                await self.whatsapp.send_text_message(from_number, response)
            else:
                await self.whatsapp.send_message(from_number, response)
                
        except Exception as e:
            print(f"Error handling message: {e}")
    
    async def send_ai_response(self, 
                               to_number: str, 
                               user_message: str) -> bool:
        """
        Get AI response and send to WhatsApp
        """
        if not self.agent:
            return False
        
        try:
            # Get AI response
            if asyncio.iscoroutinefunction(self.agent.arun):
                response = await self.agent.arun(user_message)
            else:
                response = self.agent.run(user_message)
            
            # Send via WhatsApp
            if self.method == "business_api":
                result = await self.whatsapp.send_text_message(to_number, response)
                return result["success"]
            else:
                return await self.whatsapp.send_message(to_number, response)
                
        except Exception as e:
            print(f"Error: {e}")
            return False


# Setup guide for users
WHATSAPP_SETUP_GUIDE = """
🔧 WhatsApp Integration Setup Guide

📱 Method 1: WhatsApp Business API (Recommended for Production)

1. Create Meta Business Account
   - Go to https://business.facebook.com
   - Create a business account

2. Set up WhatsApp Business Platform
   - Go to https://developers.facebook.com/apps
   - Create new app → Select "Business"
   - Add WhatsApp product

3. Get Credentials
   - Phone Number ID: From WhatsApp → API Setup
   - Access Token: Generate temporary token
   - Business Account ID: From business settings

4. Add to .env file:
   ```
   WHATSAPP_PHONE_NUMBER_ID=your_phone_number_id
   WHATSAPP_ACCESS_TOKEN=your_access_token
   WHATSAPP_BUSINESS_ACCOUNT_ID=your_business_account_id
   ```

5. Verify Phone Number
   - Add and verify your phone number in Meta dashboard

6. Webhook Setup (Optional, for receiving messages)
   - Set webhook URL: https://your-server.com/webhook/whatsapp
   - Verify token: your_verify_token
   - Subscribe to: messages

📱 Method 2: WhatsApp Web (Development Only)

1. Install pywhatkit:
   ```bash
   pip install pywhatkit
   ```

2. Usage:
   ```python
   from neuralnode.integrations.whatsapp import WhatsAppWebIntegration
   
   wa = WhatsAppWebIntegration()
   await wa.start_session()
   await wa.send_message("+201234567890", "Hello!")
   ```

⚠️ Limitations of WhatsApp Web:
- Opens browser window
- Requires phone to be connected
- Not suitable for production
- Rate limited

📱 Method 3: Third-Party Services (Easiest)

Using services like:
- Twilio WhatsApp API
- MessageBird
- 360dialog
- WATI

Example with Twilio:
```python
from twilio.rest import Client

client = Client(account_sid, auth_token)
message = client.messages.create(
    from_='whatsapp:+14155238886',
    body='Hello!',
    to='whatsapp:+201234567890'
)
```

🚀 Quick Start Example:

```python
import asyncio
from neuralnode.integrations.whatsapp import WhatsAppAgentBot

async def main():
    # Initialize bot
    bot = WhatsAppAgentBot(
        method="business_api",
        phone_number_id="123456789",
        access_token="your_token"
    )
    
    # Set your AI agent
    bot.set_agent(your_agent)
    
    # Authorize users
    bot.authorize_number("+201234567890")
    
    # Send message
    await bot.send_ai_response("+201234567890", "What's the weather?")

asyncio.run(main())
```
"""


# Export setup guide
__doc__ = WHATSAPP_SETUP_GUIDE
