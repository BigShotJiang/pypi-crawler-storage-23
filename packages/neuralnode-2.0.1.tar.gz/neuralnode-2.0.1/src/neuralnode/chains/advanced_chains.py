"""
NeuralNode Advanced Chains System
Powerful composable chains superior to LangChain
"""
import asyncio
from typing import List, Dict, Optional, Any, Callable, Union
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
from enum import Enum
import json
import re

from ..core.local_llm import LocalLLM
from ..core.message import Message


class ChainType(Enum):
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    CONDITIONAL = "conditional"
    LOOP = "loop"
    MAP_REDUCE = "map_reduce"
    FALLBACK = "fallback"


@dataclass
class ChainOutput:
    """Output from a chain step"""
    output: Any
    metadata: Dict[str, Any] = field(default_factory=dict)
    success: bool = True
    error: Optional[str] = None
    execution_time: float = 0.0


class Chain(ABC):
    """Abstract base class for all chains"""
    
    name: str = ""
    description: str = ""
    
    @abstractmethod
    async def arun(self, input_data: Any, **kwargs) -> ChainOutput:
        """Async execution"""
        pass
    
    def run(self, input_data: Any, **kwargs) -> ChainOutput:
        """Sync execution"""
        return asyncio.run(self.arun(input_data, **kwargs))
    
    def __or__(self, other: 'Chain') -> 'SequentialChain':
        """Chain composition using | operator"""
        return SequentialChain([self, other])


class LLMChain(Chain):
    """
    Basic LLM chain - prompts LLM with formatted input
    """
    
    name = "llm_chain"
    description = "Process input through LLM with a template"
    
    def __init__(self, 
                 llm: LocalLLM,
                 template: str,
                 output_parser: Optional[Callable] = None):
        self.llm = llm
        self.template = template
        self.output_parser = output_parser
    
    async def arun(self, input_data: Any, **kwargs) -> ChainOutput:
        import time
        start = time.time()
        
        try:
            # Format prompt
            if isinstance(input_data, dict):
                prompt = self.template.format(**input_data)
            else:
                prompt = self.template.format(input=input_data)
            
            # Call LLM
            messages = [Message.user(prompt)]
            response = await self.llm.achat(messages, **kwargs)
            output = response.content
            
            # Parse if parser provided
            if self.output_parser:
                output = self.output_parser(output)
            
            return ChainOutput(
                output=output,
                execution_time=time.time() - start,
                metadata={"prompt": prompt[:100]}
            )
            
        except Exception as e:
            return ChainOutput(
                output=None,
                error=str(e),
                success=False,
                execution_time=time.time() - start
            )


class TransformChain(Chain):
    """
    Transform chain - applies function to input
    """
    
    name = "transform_chain"
    description = "Transform input using a function"
    
    def __init__(self, transform_func: Callable[[Any], Any]):
        self.transform_func = transform_func
    
    async def arun(self, input_data: Any, **kwargs) -> ChainOutput:
        try:
            if asyncio.iscoroutinefunction(self.transform_func):
                output = await self.transform_func(input_data)
            else:
                output = self.transform_func(input_data)
            
            return ChainOutput(output=output)
        except Exception as e:
            return ChainOutput(output=None, error=str(e), success=False)


class SequentialChain(Chain):
    """
    Sequential chain - runs chains in sequence
    Output of one is input to next
    """
    
    name = "sequential_chain"
    description = "Execute multiple chains in sequence"
    
    def __init__(self, chains: List[Chain], name: str = "sequential"):
        self.chains = chains
        self.name = name
    
    async def arun(self, input_data: Any, **kwargs) -> ChainOutput:
        current_output = input_data
        metadata = {"steps": []}
        
        for i, chain in enumerate(self.chains):
            result = await chain.arun(current_output, **kwargs)
            
            if not result.success:
                return ChainOutput(
                    output=None,
                    error=f"Chain {i} ({chain.name}) failed: {result.error}",
                    success=False,
                    metadata=metadata
                )
            
            current_output = result.output
            metadata["steps"].append({
                "chain": chain.name,
                "output_preview": str(current_output)[:100]
            })
        
        return ChainOutput(output=current_output, metadata=metadata)
    
    def __or__(self, other: Chain) -> 'SequentialChain':
        """Add another chain to sequence"""
        return SequentialChain(self.chains + [other])


class ParallelChain(Chain):
    """
    Parallel chain - runs multiple chains in parallel
    Returns list of all outputs
    """
    
    name = "parallel_chain"
    description = "Execute multiple chains in parallel"
    
    def __init__(self, chains: List[Chain], name: str = "parallel"):
        self.chains = chains
        self.name = name
    
    async def arun(self, input_data: Any, **kwargs) -> ChainOutput:
        # Run all chains concurrently
        tasks = [chain.arun(input_data, **kwargs) for chain in self.chains]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        outputs = []
        errors = []
        
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                errors.append(f"Chain {i}: {str(result)}")
            elif result.success:
                outputs.append(result.output)
            else:
                errors.append(f"Chain {i}: {result.error}")
        
        return ChainOutput(
            output=outputs,
            metadata={"results": len(outputs), "errors": errors},
            success=len(errors) == 0,
            error="; ".join(errors) if errors else None
        )


class ConditionalChain(Chain):
    """
    Conditional chain - routes to different chains based on condition
    """
    
    name = "conditional_chain"
    description = "Route to different chains based on condition"
    
    def __init__(self, 
                 condition_func: Callable[[Any], str],
                 chains_map: Dict[str, Chain],
                 default_chain: Optional[Chain] = None):
        self.condition_func = condition_func
        self.chains_map = chains_map
        self.default_chain = default_chain
    
    async def arun(self, input_data: Any, **kwargs) -> ChainOutput:
        # Evaluate condition
        route_key = self.condition_func(input_data)
        
        # Select chain
        chain = self.chains_map.get(route_key, self.default_chain)
        
        if chain is None:
            return ChainOutput(
                output=None,
                error=f"No chain found for route: {route_key}",
                success=False
            )
        
        # Execute selected chain
        result = await chain.arun(input_data, **kwargs)
        result.metadata["route"] = route_key
        
        return result


class MapReduceChain(Chain):
    """
    Map-Reduce chain - map over inputs, then reduce results
    Superior for processing large datasets
    """
    
    name = "map_reduce_chain"
    description = "Map over inputs then reduce results"
    
    def __init__(self,
                 map_chain: Chain,
                 reduce_chain: Chain,
                 batch_size: int = 5):
        self.map_chain = map_chain
        self.reduce_chain = reduce_chain
        self.batch_size = batch_size
    
    async def arun(self, input_data: List[Any], **kwargs) -> ChainOutput:
        # Map phase - process each item
        map_results = []
        
        for i in range(0, len(input_data), self.batch_size):
            batch = input_data[i:i + self.batch_size]
            
            # Process batch in parallel
            tasks = [self.map_chain.arun(item, **kwargs) for item in batch]
            batch_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for result in batch_results:
                if isinstance(result, Exception):
                    map_results.append(f"Error: {str(result)}")
                elif result.success:
                    map_results.append(result.output)
                else:
                    map_results.append(f"Error: {result.error}")
        
        # Reduce phase - combine all results
        reduce_input = {
            "inputs": input_data,
            "mapped_results": map_results,
            "count": len(map_results)
        }
        
        reduce_result = await self.reduce_chain.arun(reduce_input, **kwargs)
        
        return ChainOutput(
            output=reduce_result.output,
            metadata={
                "mapped_count": len(map_results),
                "reduce_success": reduce_result.success
            }
        )


class FallbackChain(Chain):
    """
    Fallback chain - tries chains in order until one succeeds
    """
    
    name = "fallback_chain"
    description = "Try chains in order with fallback"
    
    def __init__(self, chains: List[Chain]):
        self.chains = chains
    
    async def arun(self, input_data: Any, **kwargs) -> ChainOutput:
        last_error = None
        
        for i, chain in enumerate(self.chains):
            result = await chain.arun(input_data, **kwargs)
            
            if result.success:
                result.metadata["fallback_used"] = i > 0
                result.metadata["fallback_index"] = i
                return result
            
            last_error = result.error
        
        return ChainOutput(
            output=None,
            error=f"All chains failed. Last error: {last_error}",
            success=False
        )


class ConversationChain(Chain):
    """
    Conversation chain - maintains conversation history
    """
    
    name = "conversation_chain"
    description = "Stateful conversation with memory"
    
    def __init__(self, 
                 llm: LocalLLM,
                 system_prompt: str = "",
                 max_history: int = 10):
        self.llm = llm
        self.system_prompt = system_prompt
        self.max_history = max_history
        self.history: List[Message] = []
    
    async def arun(self, input_data: str, **kwargs) -> ChainOutput:
        # Build messages
        messages = []
        
        if self.system_prompt:
            messages.append(Message.system(self.system_prompt))
        
        # Add history
        messages.extend(self.history[-self.max_history:])
        
        # Add current input
        messages.append(Message.user(input_data))
        
        # Call LLM
        response = await self.llm.achat(messages, **kwargs)
        
        # Update history
        self.history.append(Message.user(input_data))
        self.history.append(Message.assistant(response.content))
        
        # Trim history
        if len(self.history) > self.max_history * 2:
            self.history = self.history[-self.max_history * 2:]
        
        return ChainOutput(
            output=response.content,
            metadata={"history_length": len(self.history)}
        )
    
    def clear_history(self):
        """Clear conversation history"""
        self.history = []


class ExtractionChain(Chain):
    """
    Extraction chain - extracts structured data from text
    """
    
    name = "extraction_chain"
    description = "Extract structured data from text"
    
    def __init__(self, 
                 llm: LocalLLM,
                 schema: Dict[str, str],
                 examples: Optional[List[Dict]] = None):
        self.llm = llm
        self.schema = schema
        self.examples = examples or []
    
    async def arun(self, input_text: str, **kwargs) -> ChainOutput:
        # Build extraction prompt
        schema_desc = "\n".join([f"- {k}: {v}" for k, v in self.schema.items()])
        
        examples_text = ""
        if self.examples:
            examples_text = "\n\nExamples:\n" + json.dumps(self.examples, indent=2)
        
        prompt = f"""Extract the following information from the text.

Schema:
{schema_desc}{examples_text}

Text to extract from:
{input_text}

Return ONLY a JSON object with the extracted information."""
        
        messages = [Message.user(prompt)]
        response = await self.llm.achat(messages, **kwargs)
        
        # Try to parse JSON
        try:
            # Find JSON in response
            json_match = re.search(r'\{.*\}', response.content, re.DOTALL)
            if json_match:
                extracted = json.loads(json_match.group())
            else:
                extracted = json.loads(response.content)
            
            return ChainOutput(output=extracted)
        except Exception as e:
            return ChainOutput(
                output=response.content,
                error=f"JSON parsing failed: {str(e)}",
                success=False
            )


# Pre-built chain templates
def create_qa_chain(llm: LocalLLM, context: str) -> LLMChain:
    """Create a Q&A chain with context"""
    template = f"""Context: {context}

Question: {{input}}

Answer the question based on the context above."""
    
    return LLMChain(llm=llm, template=template)


def create_summary_chain(llm: LocalLLM, max_words: int = 100) -> LLMChain:
    """Create a summarization chain"""
    template = f"""Summarize the following text in {max_words} words or less:

{{input}}

Summary:"""
    
    return LLMChain(llm=llm, template=template)


def create_classification_chain(llm: LocalLLM, categories: List[str]) -> LLMChain:
    """Create a classification chain"""
    categories_str = ", ".join(categories)
    
    template = f"""Classify the following into one of these categories: {categories_str}

Text: {{input}}

Category:"""
    
    return LLMChain(llm=llm, template=template)


# Chain builder DSL
class ChainBuilder:
    """
    Fluent API for building chains
    """
    
    def __init__(self):
        self.chains: List[Chain] = []
    
    def add(self, chain: Chain) -> 'ChainBuilder':
        """Add a chain to the sequence"""
        self.chains.append(chain)
        return self
    
    def llm(self, llm: LocalLLM, template: str) -> 'ChainBuilder':
        """Add an LLM chain"""
        self.chains.append(LLMChain(llm, template))
        return self
    
    def transform(self, func: Callable) -> 'ChainBuilder':
        """Add a transform chain"""
        self.chains.append(TransformChain(func))
        return self
    
    def parallel(self, *chains: Chain) -> 'ChainBuilder':
        """Add a parallel chain"""
        self.chains.append(ParallelChain(list(chains)))
        return self
    
    def conditional(self, condition: Callable, **chains: Chain) -> 'ChainBuilder':
        """Add a conditional chain"""
        self.chains.append(ConditionalChain(condition, chains))
        return self
    
    def fallback(self, *chains: Chain) -> 'ChainBuilder':
        """Add a fallback chain"""
        self.chains.append(FallbackChain(list(chains)))
        return self
    
    def build(self) -> SequentialChain:
        """Build the final sequential chain"""
        return SequentialChain(self.chains)


# Example usage
async def example():
    """Example of using advanced chains"""
    llm = LocalLLM()
    
    # Simple chain
    chain = LLMChain(llm, "Translate to French: {input}")
    result = await chain.arun("Hello world")
    print(f"Translation: {result.output}")
    
    # Sequential chain using pipe operator
    translate_chain = LLMChain(llm, "Translate to French: {input}")
    uppercase_chain = TransformChain(lambda x: x.upper())
    
    combined = translate_chain | uppercase_chain
    result = await combined.arun("hello")
    print(f"Combined: {result.output}")
    
    # Parallel chain
    sentiment_chain = LLMChain(llm, "Classify sentiment (positive/negative): {input}")
    topic_chain = LLMChain(llm, "Extract main topic: {input}")
    
    parallel = ParallelChain([sentiment_chain, topic_chain])
    result = await parallel.arun("I love this product!")
    print(f"Parallel results: {result.output}")
