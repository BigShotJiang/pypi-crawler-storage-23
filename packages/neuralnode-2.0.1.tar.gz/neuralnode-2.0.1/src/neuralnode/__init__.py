"""
NeuralNode Core Package
Advanced AI Agent Framework Core
"""

__version__ = "2.0.0"

# Core classes
from .core.base_tool import BaseTool, ToolResult, ParameterSpec
from .core.message import Message
from .core.local_llm import LocalLLM
from .core.react_agent import ReActAgent
from .core.python_repl_tool import PythonREPLTool

# Utils
from .core.utils import generate_voice_file, ensure_ollama_running

# Integrations - Official Providers
from .integrations.google_ai_studio import GoogleAILLM, GoogleAIManager

# Neural Doctor - Intelligent Error Handling
from .neural_doctor import (
    NeuralDoctor,
    ErrorClassifier,
    RootCauseAnalyzer,
    SelfHealingEngine,
    RetryManager,
    CircuitBreaker,
    ErrorLogger,
    HealthMonitor,
    HardwareChecker,
    ErrorCategory,
    ErrorSeverity,
    ErrorRecord,
    HealthStatus,
    init_neural_doctor,
    get_doctor,
    protected_execute,
    quick_health_check,
)

__all__ = [
    # Core
    "BaseTool",
    "ToolResult",
    "ParameterSpec",
    "Message",
    "LocalLLM",
    "ReActAgent",
    "PythonREPLTool",
    "generate_voice_file",
    "ensure_ollama_running",
    # Integrations
    "GoogleAILLM",
    "GoogleAIManager",
    # Neural Doctor
    "NeuralDoctor",
    "ErrorClassifier",
    "RootCauseAnalyzer",
    "SelfHealingEngine",
    "RetryManager",
    "CircuitBreaker",
    "ErrorLogger",
    "HealthMonitor",
    "HardwareChecker",
    "ErrorCategory",
    "ErrorSeverity",
    "ErrorRecord",
    "HealthStatus",
    "init_neural_doctor",
    "get_doctor",
    "protected_execute",
    "quick_health_check",
]
