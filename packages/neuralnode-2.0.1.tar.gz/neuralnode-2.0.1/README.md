# NeuralNode 2.0

Advanced AI Agent Framework with Neural Doctor error handling system.

## Features

- ReAct Agent with reasoning capabilities
- BaseTool and ToolResult for custom tools
- Message system for agent communication
- Neural Doctor - Advanced error handling with self-healing
- Google AI Studio integration
- RAG (Retrieval-Augmented Generation)
- Advanced Chains
- Voice capabilities (TTS/STT)
- Memory management

## Installation

```bash
pip install neuralnode
```

## Quick Start

```python
from neuralnode import ReActAgent, Message, BaseTool
from neuralnode.integrations.google_ai_studio import GoogleAILLM

# Create agent
agent = ReActAgent(
    llm=GoogleAILLM(api_key="your-api-key"),
    system_prompt="You are a helpful assistant"
)

# Send message
response = agent.run(Message.user("Hello!"))
print(response.content)
```

## API Keys

Create `.env` file:
```
GOOGLE_API_KEY=your_key_here
TELEGRAM_BOT_TOKEN=your_token_here
```

## License

MIT
