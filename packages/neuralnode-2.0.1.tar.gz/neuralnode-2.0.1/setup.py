from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="neuralnode",
    version="2.0.1",
    author="NeuralNode Team",
    author_email="contact@neuralnode.ai",
    description="Advanced AI Agent Framework with Neural Doctor error handling",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/neuralnode/neuralnode",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
        "aiohttp>=3.8.0",
        "numpy>=1.21.0",
        "chromadb>=0.4.0",
        "sentence-transformers>=2.2.0",
        "python-dotenv>=0.19.0",
        "websockets>=10.0",
        "ollama>=0.1.0",
    ],
    extras_require={
        "voice": [
            "pyttsx3>=2.90",
            "SpeechRecognition>=3.10.0",
            "pyaudio>=0.2.11",
        ],
        "full": [
            "pyttsx3>=2.90",
            "SpeechRecognition>=3.10.0",
            "pyaudio>=0.2.11",
            "requests>=2.25.0",
            "aiohttp>=3.8.0",
            "numpy>=1.21.0",
            "chromadb>=0.4.0",
            "sentence-transformers>=2.2.0",
            "python-dotenv>=0.19.0",
            "websockets>=10.0",
            "ollama>=0.1.0",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
