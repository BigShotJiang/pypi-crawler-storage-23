# -*- coding: utf-8 -*-
"""
NextPCG MCP Python Package API
Author: NextPCG

本模块为外部开发者提供 MCP 工具开发的公共 API。

主要导出：
- 类型定义：MCPToolParam, MCPToolDefinition, MCPToolResult, MCPToolCategory
- 基类：MCPToolBase, MCPToolMixin
- 装饰器：expose_as_mcp, mcp_param, MCPToolConfig
- 类型映射：DSON_TYPE_TO_JSON_SCHEMA, PYTHON_TYPE_TO_JSON_SCHEMA

示例用法：

    # 方式 1：使用 @nextpcgmethod 装饰器（推荐）
    from nextpcg.pypapi.dson import DsonBase, nextpcgmethod
    from nextpcg.pypapi.dson_field import String, Int
    
    class MyMCPTools(DsonBase):
        if_in_server = False  # 外部进程执行
        
        @nextpcgmethod(expose_as_mcp=True, mcp_timeout=60, mcp_category="custom")
        def my_tool(param: String) -> dict:
            '''我的自定义工具'''
            return {"result": param.get_input()}
    
    # 方式 2：使用 @expose_as_mcp 装饰器
    from nextpcg.pypapi.mcp import expose_as_mcp
    
    @expose_as_mcp(timeout=60, category="custom")
    def my_standalone_tool(param: str) -> dict:
        '''独立的 MCP 工具'''
        return {"result": param}
    
    # 方式 3：继承 MCPToolBase（高级用法）
    from nextpcg.pypapi.mcp import MCPToolBase
    
    class MyAdvancedTool(MCPToolBase):
        name = "my_advanced_tool"
        description = "高级自定义工具"
        timeout = 60
        
        def execute(self, **kwargs) -> dict:
            return {"result": "success"}
"""

# 类型定义
from .types import (
    MCPToolCategory,
    MCPToolParam,
    MCPToolDefinition,
    MCPToolResult,
    DSON_TYPE_TO_JSON_SCHEMA,
    PYTHON_TYPE_TO_JSON_SCHEMA,
)

# 基类
from .tool_base import (
    MCPToolBase,
    MCPToolMixin,
)

# 装饰器
from .decorators import (
    expose_as_mcp,
    mcp_param,
    MCPToolConfig,
)


# 公共 API 列表
__all__ = [
    # 类型定义
    'MCPToolCategory',
    'MCPToolParam',
    'MCPToolDefinition',
    'MCPToolResult',
    'DSON_TYPE_TO_JSON_SCHEMA',
    'PYTHON_TYPE_TO_JSON_SCHEMA',
    # 基类
    'MCPToolBase',
    'MCPToolMixin',
    # 装饰器
    'expose_as_mcp',
    'mcp_param',
    'MCPToolConfig',
]


# 版本信息
__version__ = '2.0.0'