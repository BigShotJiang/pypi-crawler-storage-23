# -*- coding: utf-8 -*-
"""
NextPCG MCP 类型定义
Author: NextPCG

本模块提供 MCP 相关的类型定义，供外部开发者使用。
"""

from typing import Dict, List, Any, Optional, Callable, TypeVar, Generic
from dataclasses import dataclass, field
from enum import Enum


class MCPToolCategory(Enum):
    """MCP 工具分类"""
    GENERAL = "general"           # 通用工具
    ASSET = "asset"               # 资产管理
    BLUEPRINT = "blueprint"       # 蓝图编辑
    SCENE = "scene"               # 场景操作
    MATERIAL = "material"         # 材质编辑
    ANIMATION = "animation"       # 动画工具
    EDITOR = "editor"             # 编辑器工具
    UTILITY = "utility"           # 实用工具
    CUSTOM = "custom"             # 自定义工具


@dataclass
class MCPToolParam:
    """MCP 工具参数定义"""
    name: str
    type: str
    description: str = ""
    required: bool = True
    default: Any = None
    
    def to_json_schema(self) -> dict:
        """转换为 JSON Schema 格式"""
        schema = {
            'type': self._type_to_json_type(),
            'description': self.description or f'Parameter {self.name}'
        }
        if self.default is not None:
            schema['default'] = self.default
        return schema
    
    def _type_to_json_type(self) -> str:
        """将类型字符串转换为 JSON Schema 类型"""
        type_mapping = {
            'int': 'integer',
            'integer': 'integer',
            'float': 'number',
            'number': 'number',
            'bool': 'boolean',
            'boolean': 'boolean',
            'str': 'string',
            'string': 'string',
            'list': 'array',
            'array': 'array',
            'dict': 'object',
            'object': 'object',
        }
        return type_mapping.get(self.type.lower(), 'string')


@dataclass
class MCPToolDefinition:
    """MCP 工具定义"""
    name: str
    description: str
    parameters: List[MCPToolParam] = field(default_factory=list)
    category: str = "general"
    timeout: int = 30
    
    def to_json_schema(self) -> dict:
        """转换为 MCP 标准的 JSON Schema 格式"""
        properties = {}
        required = []
        
        for param in self.parameters:
            properties[param.name] = param.to_json_schema()
            if param.required:
                required.append(param.name)
        
        return {
            'type': 'function',
            'function': {
                'name': self.name,
                'description': self.description,
                'parameters': {
                    'type': 'object',
                    'properties': properties,
                    'required': required
                },
                'timeout': self.timeout
            }
        }


@dataclass
class MCPToolResult:
    """MCP 工具执行结果"""
    success: bool
    result: Any = None
    error: Optional[str] = None
    error_type: Optional[str] = None
    executed_on: str = "server"
    duration_ms: float = 0
    
    def to_dict(self) -> dict:
        """转换为字典"""
        data = {
            'success': self.success,
            'executed_on': self.executed_on,
            'duration_ms': self.duration_ms
        }
        if self.success:
            data['result'] = self.result
        else:
            data['error'] = self.error
            if self.error_type:
                data['error_type'] = self.error_type
        return data


# DSON 类型到 JSON Schema 的映射表（供外部开发者参考）
DSON_TYPE_TO_JSON_SCHEMA = {
    # 基础类型
    'paramType.Bool': {'type': 'boolean', 'description': 'BoolField: 布尔值'},
    'paramType.Int': {'type': 'integer', 'description': 'IntField: 整数'},
    'paramType.Int2': {'type': 'array', 'items': {'type': 'integer'}, 'minItems': 2, 'maxItems': 2, 'description': 'Int2Field: 2个整数 [x, y]'},
    'paramType.Int3': {'type': 'array', 'items': {'type': 'integer'}, 'minItems': 3, 'maxItems': 3, 'description': 'Int3Field: 3个整数 [x, y, z]'},
    'paramType.Int4': {'type': 'array', 'items': {'type': 'integer'}, 'minItems': 4, 'maxItems': 4, 'description': 'Int4Field: 4个整数'},
    'paramType.Float': {'type': 'number', 'description': 'FloatField: 浮点数'},
    'paramType.Float2': {'type': 'array', 'items': {'type': 'number'}, 'minItems': 2, 'maxItems': 2, 'description': 'Float2Field: 2个浮点数 [x, y]'},
    'paramType.Float3': {'type': 'array', 'items': {'type': 'number'}, 'minItems': 3, 'maxItems': 3, 'description': 'Float3Field: 3个浮点数 [x, y, z]'},
    'paramType.Float4': {'type': 'array', 'items': {'type': 'number'}, 'minItems': 4, 'maxItems': 4, 'description': 'Float4Field: 4个浮点数'},
    'paramType.String': {'type': 'string', 'description': 'StringField: 字符串'},
    'paramType.Json': {'type': 'object', 'description': 'JsonField: JSON对象'},
    'paramType.File': {'type': 'string', 'description': 'FileField: 文件路径'},
    'paramType.List': {'type': 'array', 'description': 'ListField: 列表'},
    # 复杂几何类型
    'paramType.HeightField': {'type': 'string', 'description': 'HeightFieldField: 高度场数据文件路径'},
    'paramType.InstancedStaticMesh': {'type': 'string', 'description': 'InstancedStaticMeshField: 实例化静态网格数据'},
    'paramType.StaticMesh': {'type': 'string', 'description': 'StaticMeshField: 静态网格数据'},
    'paramType.Texture': {'type': 'string', 'description': 'TextureField: 纹理数据'},
    'paramType.Curve': {'type': 'array', 'items': {'type': 'string'}, 'description': 'CurveField: 曲线数据文件路径列表'},
    'paramType.Transform': {'type': 'array', 'items': {'type': 'number'}, 'minItems': 10, 'maxItems': 10, 'description': 'TransformField: 变换数据 [LocX,LocY,LocZ,RotX,RotY,RotZ,RotW,ScaleX,ScaleY,ScaleZ]'},
    'paramType.Color': {'type': 'array', 'items': {'type': 'number'}, 'minItems': 4, 'maxItems': 4, 'description': 'ColorField: 颜色 [R, G, B, A]'},
}


# Python 类型到 JSON Schema 的映射
PYTHON_TYPE_TO_JSON_SCHEMA = {
    int: {'type': 'integer'},
    float: {'type': 'number'},
    bool: {'type': 'boolean'},
    str: {'type': 'string'},
    list: {'type': 'array'},
    dict: {'type': 'object'},
}
