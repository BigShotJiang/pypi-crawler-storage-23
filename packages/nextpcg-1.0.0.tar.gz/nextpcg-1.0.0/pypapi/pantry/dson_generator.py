# -*- coding: utf-8 -*-
"""
DSON 文件生成器
Author  : NextPCG

使用方法：
    python dson_generator.py

此脚本会根据 dson_config.yaml 中的配置：
1. 生成 .dson 文件
2. 生成对应的测试文件
3. 生成启动脚本 (.nextpcg/dson_init.bat 或 dson_init.sh)
4. 生成 dson_main.py 入口文件
"""

import os
import sys

# 添加当前目录到 Python 路径
current_path = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(current_path)

import yaml
from nextpcg.pypapi.dson_create import generate


def main():
    """主函数：读取配置并生成所有必要文件"""
    config_path = os.path.join(current_path, 'dson_config.yaml')
    
    if not os.path.exists(config_path):
        print("错误：找不到 dson_config.yaml 配置文件")
        print("请先运行 'nextpcg init' 初始化项目，或手动创建配置文件")
        sys.exit(1)
    
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            dson_config = yaml.full_load(f)
    except Exception as e:
        print(f"错误：无法解析配置文件 - {e}")
        sys.exit(1)
    
    # 验证必需字段
    if 'name' not in dson_config:
        print("错误：配置文件缺少 'name' 字段")
        sys.exit(1)
    
    if 'modules' not in dson_config:
        print("错误：配置文件缺少 'modules' 字段")
        sys.exit(1)
    
    print(f"正在为插件 '{dson_config['name']}' 生成 DSON 文件...")
    
    try:
        generate(current_path, dson_config)
        print("生成完成！")
        print(f"  - DSON 文件位于: {os.path.join(current_path, 'dson')}")
        print(f"  - 启动脚本位于: {os.path.join(current_path, '.nextpcg')}")
        print(f"  - 入口文件: {os.path.join(current_path, 'dson_main.py')}")
    except Exception as e:
        print(f"错误：生成失败 - {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
