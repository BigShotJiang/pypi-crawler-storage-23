# Upstream adds methods to the Transform class prototype in this file, instead
# see transform.py for add_mark, remove_mark, and clear_incompatible.
