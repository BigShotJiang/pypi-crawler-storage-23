---
name: email-sender
description: >
  Send and read emails via Gmail SMTP/IMAP. Supports plain text, HTML, search, and folder listing.
  Credentials stored in email_config.json (gitignored).
---

# Email Sender & Reader Skill

## Overview

Send and read emails via Gmail using Python scripts. Uses SMTP for sending and IMAP for reading.

## Paths

All paths are relative to **this skill's directory** (the directory containing this SKILL.md file):

- **Send script**: `send_email.py` (in this directory)
- **Read script**: `read_email.py` (in this directory)
- **Config**: `email_config.json` (in this directory, gitignored)

## Configuration

`email_config.json` must contain:
```json
{
    "gmail_address": "sender@gmail.com",
    "app_password": "xxxx xxxx xxxx xxxx"
}
```

Generate an app password at https://myaccount.google.com/apppasswords

## Sending emails

Replace `<SKILL_DIR>` with this skill's absolute directory path.

### Basic plain text email
```bash
python "<SKILL_DIR>/send_email.py" --to "recipient@example.com" --subject "Subject here" --body "Body text here"
```

### With HTML body
```bash
python "<SKILL_DIR>/send_email.py" --to "recipient@example.com" --subject "Subject" --body "Plain text fallback" --html "<h1>Rich HTML content</h1>"
```

### Body from file
```bash
python "<SKILL_DIR>/send_email.py" --to "recipient@example.com" --subject "Subject" --body-file /path/to/body.txt
```

## Reading emails

### List latest emails from inbox
```bash
python "<SKILL_DIR>/read_email.py" inbox
python "<SKILL_DIR>/read_email.py" inbox --count 20
python "<SKILL_DIR>/read_email.py" inbox --folder "[Gmail]/Sent Mail"
```

### Read a specific email by UID
```bash
python "<SKILL_DIR>/read_email.py" read <uid>
```

### Search emails
```bash
python "<SKILL_DIR>/read_email.py" search "from:someone@example.com"
python "<SKILL_DIR>/read_email.py" search "subject:invoice"
python "<SKILL_DIR>/read_email.py" search "to:recipient@example.com"
python "<SKILL_DIR>/read_email.py" search "since:01-Jan-2026"
python "<SKILL_DIR>/read_email.py" search "keyword"    # free text search
```

### List folders/labels
```bash
python "<SKILL_DIR>/read_email.py" folders
```

## Notes

- Send uses Gmail SMTP SSL on port 465
- Read uses Gmail IMAP SSL on port 993
- Same app password works for both SMTP and IMAP
- Config file is gitignored to keep credentials out of version control
