---
name: kanban-autonomous
description: Autonomous task management system for infinite AI-driven development. Manages projects, milestones, and tasks via a Kanban API with an autonomous pipeline that creates and assigns work.
---

# Kanban Autonomous Development Skill

You are an autonomous AI developer working with a Kanban task management system. This system tracks projects, milestones, and tasks, and provides an autonomous pipeline that creates work items for you. Your job is to fetch tasks, implement them, test your changes, log your progress, and move on to the next task.

**Base URL**: `http://kanbanboard.local:3000`

All endpoints below are relative to this base URL. All request/response bodies are JSON. Use `Content-Type: application/json` for POST/PATCH requests.

---

## Quick Start: "Do the next Kanban task"

When the user says something like "do the next kanban task" or "work on the next ticket", follow this workflow:

1. **Check if a project exists** — `GET /api/projects` to list projects
2. **Fetch the next task** — `GET /api/ai/projects/{projectId}/next-task`
3. If a task is returned (`selected` is not null), **work on it** (see Task Execution Workflow below). Read `context.agent_instructions` from the response to understand the full task context.
4. **Only if no task is available** (`selected` is null), run the autonomous pipeline to generate new work (see Autonomous Pipeline below). Do NOT run the pipeline if there are already tasks to work on.
5. After the pipeline completes, fetch the next task again
6. After completing a task, **ask the user** if they want to continue with the next task

---

## Project Setup

### For a NEW project (you have a PRD or requirements)

1. **Create the project** with scope text containing the PRD/requirements:

   ```
   POST /api/projects
   { "name": "My Project", "scope_text": "Full PRD text here...", "guidelines_text": "Optional planning rules, priorities, constraints", "repo_path": "C:\\path\\to\\repo" }
   ```

2. **Sync status from the repository** (required):

   ```
   POST /api/ai/projects/{projectId}/sync-status/start
   ```

   Returns `{ "job_id": "abc123", "status": "running" }` (HTTP 202). **This can take 30-120 seconds** as it performs deep codebase exploration. **Always run this step** — even for new/empty repos, it sets the project status which is needed for good task generation and context in agent instructions.

   **Poll for completion** — use `GET /api/ai/jobs/{jobId}` every 15-30 seconds:

   ```json
   {
     "job_id": "abc123",
     "status": "running",
     "progress": [
       {
         "type": "cli_thinking",
         "detail": "Let me investigate the codebase...",
         "ts": 1707590400000
       },
       {
         "type": "cli_activity",
         "tool": "Read",
         "detail": "src/index.ts",
         "ts": 1707590405000
       },
       {
         "type": "cli_activity",
         "tool": "Grep",
         "detail": "TODO|FIXME in src",
         "ts": 1707590410000
       }
     ],
     "started_at": 1707590390000
   }
   ```

   When `status` becomes `"completed"`, `result` contains the sync outcome:

   ```json
   {
     "job_id": "abc123",
     "status": "completed",
     "progress": [...],
     "started_at": 1707590390000,
     "completed_at": 1707590420000,
     "result": {
       "status_text": "The project has X built, Y in progress... Recommended next steps: ...",
       "cli_meta": { "duration_ms": 30000 },
       "synced": true
     }
   }
   ```

   If `status` is `"failed"`, check the `error` field. If you get `409 Conflict`, a job is already running — use the returned `job_id` to poll the existing one.

3. **Run the autonomous pipeline** to generate initial milestones and tasks (see Autonomous Pipeline section below).

### For an EXISTING project (repository already exists, no PRD)

1. **Create the project** with just a name (no scope text):

   ```
   POST /api/projects
   { "name": "My Project", "repo_path": "C:\\path\\to\\repo" }
   ```

2. **Initialize from repository** — this analyzes the codebase and generates both scope and status:

   ```
   POST /api/ai/projects/{projectId}/init
   { "path": "C:\\path\\to\\repo", "apply": true, "create_seed_tasks": true, "max_depth": 3 }
   ```

   **WARNING: This can take 60-180+ seconds** as it scans the repository, reads files, and uses LLM analysis to generate a comprehensive project scope, status summary, and optional seed tasks. You MUST wait patiently for this to complete.

3. Optionally **run the autonomous pipeline** to generate additional milestones and tasks.

---

## Autonomous Pipeline

The autonomous pipeline analyzes the project state, creates milestones and tasks, selects the next task to work on, and optionally evolves milestones when all their tasks are complete. **Only run the pipeline when `GET /api/ai/projects/{id}/next-task` returns `selected: null`** (no tasks available). If tasks already exist, just fetch and work on them directly — do not run the pipeline unnecessarily.

### Starting the Pipeline (Async — Recommended)

Use the async endpoint to avoid timeouts:

```
POST /api/ai/projects/{projectId}/autonomous-next/start
{
  "sync_status": true,
  "evolve_methods": ["unified"],
  "include_project_evolve": false,
  "max_depth": 3,
  "max_new_tasks": 15,
  "max_milestone_tasks": 50,
  "ground_hierarchy_evolve": true,
  "codebase_evolve_goal": "",
  "milestone_creation_llm": false,
  "milestone_creation_cli": true,
  "exclude_status": ["done", "ideas", "review", "testing"],
  "prefer_status": ["in_progress", "todo"],
  "max_candidates": 40
}
```

**Response** (202 Accepted):

```json
{ "job_id": "abc123", "status": "running" }
```

All fields in the request body are optional. The defaults shown above use the **unified** evolve method and **CLI-based** milestone creation — these produce the best quality results because they investigate the actual codebase before proposing work items.

**Key config options:**

- `sync_status`: Whether to sync project status from the repo before running. **Always set to `true`** — the status text is critical context for task generation and agent instructions. Only set to `false` if you already synced status moments ago in the same session
- `evolve_methods`: **Use `["unified"]`** — this is the recommended default. It combines full PM context with codebase investigation in a single Claude Code call, producing the best quality tasks. Alternatives: `["hierarchy"]` for LLM-only (fast but not codebase-aware), `["codebase"]` for CLI-based without PM context, `["hierarchy", "codebase"]` for both legacy methods. Methods are additive
- `ground_hierarchy_evolve`: **Always set to `true`** — ensures proposed tasks are validated against the actual codebase so already-implemented work is not re-created. Default `true`
- `codebase_evolve_goal`: Optional focus goal for codebase evolution (e.g., "improve error handling")
- `milestone_creation_llm`: When `true`, uses LLM to create milestones when none exist (fast, ~5 sec). Default `false`. Can be used alongside CLI for faster initial milestone while CLI provides a second codebase-grounded one
- `milestone_creation_cli`: **Use `true`** — this is the recommended default for projects with a `repo_path`. Uses Claude Code CLI to investigate the codebase before proposing milestones, producing better grounded results. Both LLM and CLI can be enabled simultaneously — LLM runs first, CLI second

### Polling for Pipeline Completion

The pipeline can take **2-20 minutes** depending on configuration (especially with codebase evolution enabled). Poll every 30 seconds:

```
GET /api/ai/jobs/{jobId}
```

**Response while running:**

```json
{
  "job_id": "abc123",
  "status": "running",
  "progress": [
    { "type": "sync_status", "ts": 1707590400000 },
    { "type": "select_task", "ts": 1707590430000 },
    { "type": "create_milestone", "ts": 1707590460000 }
  ],
  "started_at": 1707590390000
}
```

**Response when completed:**

```json
{
  "job_id": "abc123",
  "status": "completed",
  "progress": [...],
  "started_at": 1707590390000,
  "completed_at": 1707590500000,
  "result": {
    "actions": [...],
    "selected": { "id": "taskId", "title": "...", "status": "todo", ... },
    "rationale": "Why this task was selected...",
    "candidate_count": 8,
    "context": {
      "project": { "id": "...", "name": "...", "repo_path": "..." },
      "path": [ { "id": "parentId", "title": "Parent Epic", "status": "todo", "depth": 1 }, ... ],
      "task": { "id": "taskId", "title": "...", "status": "todo", "parent_id": "...", "milestone_id": "..." },
      "children": [],
      "agent_instructions": "=== AGENT TASK ASSIGNMENT ===\n\nYou are assigned to work on the LEAF TICKET..."
    }
  }
}
```

The completed pipeline result includes the same `context.agent_instructions` field as the `next-task` endpoint. **Read `result.context.agent_instructions` to get the full task brief** (project scope, parent ticket hierarchy, and your specific task details). You do NOT need to make a separate `next-task` call after the pipeline completes — the context is already included.

**Note:** The `context` object provides lightweight metadata (IDs, titles, statuses) for programmatic use. Heavy text fields (`scope_text`, `status_text`, `guidelines_text`, `description`, `detail_text`) are omitted since they are already included in `agent_instructions`.

**Response on failure:**

```json
{
  "job_id": "abc123",
  "status": "failed",
  "error": "Error message...",
  "completed_at": 1707590500000
}
```

**Important:** If you get a `409 Conflict`, a pipeline is already running for this project. Use the returned `job_id` to poll the existing job instead.

**Polling strategy:** Sleep 30 seconds between polls. Set a maximum timeout of 20 minutes. If the job has not completed after 20 minutes, inform the user.

### After Pipeline Completes

The result includes a `selected` task if one was found. If present, read `result.context.agent_instructions` for the full task brief and proceed to work on it. If `selected` is null, all existing tasks may be done — inform the user.

---

## Fetching the Next Task

**Always call this FIRST before considering running the autonomous pipeline.** Only run the pipeline if this endpoint returns `selected: null` (no tasks available).

```
GET /api/ai/projects/{projectId}/next-task
```

Optional query parameters: `exclude_status`, `prefer_status`, `max_candidates`

**Response:**

```json
{
  "selected": {
    "id": "taskId",
    "title": "Implement Tokenizer",
    "description": "Create a function to split an expression string into meaningful tokens.",
    "status": "todo",
    "detail_text": "In src/calc.js, implement a helper function tokenize(expression)...",
    "project_id": "projId",
    "milestone_id": "msId",
    "parent_id": "parentId"
  },
  "rationale": "This task is the foundational step for the milestone...",
  "candidate_count": 8,
  "context": {
    "project": { "id": "...", "name": "...", "repo_path": "..." },
    "path": [
      {
        "id": "parentId",
        "title": "Parent Epic",
        "status": "todo",
        "depth": 1
      },
      { "id": "taskId", "title": "...", "status": "todo", "depth": 0 }
    ],
    "task": {
      "id": "taskId",
      "title": "...",
      "status": "todo",
      "parent_id": "parentId",
      "milestone_id": "msId"
    },
    "children": [],
    "agent_instructions": "=== AGENT TASK ASSIGNMENT ===\n\nYou are assigned to work on the LEAF TICKET shown at the bottom.\n..."
  }
}
```

**The `context.agent_instructions` field is your primary source of information for understanding the task.** It is a pre-formatted document that includes:

- The full **project scope** and **current project status**
- The **complete ancestor ticket hierarchy** (parent, grandparent, etc.) so you understand what broader goal this sub-ticket belongs to
- The **leaf ticket details** (your actual task) clearly marked as "YOUR TASK"

Read `agent_instructions` carefully — it gives you everything you need to understand the task in context. You do NOT need to make separate API calls to get the project scope or parent ticket details. The other fields in `context` (`project`, `path`, `task`, `children`) provide lightweight metadata (IDs, titles, statuses) for programmatic use — heavy text fields are omitted since they are already in `agent_instructions`.

If `selected` is `null`, no eligible tasks exist — only then should you run the autonomous pipeline to generate new ones.

---

## Task Execution Workflow

When you have a task to work on, follow this workflow:

### 1. Read the task context

The `next-task` response already includes a `context.agent_instructions` field — **this is your primary task brief**. It contains the full project scope, current project status, the complete parent ticket hierarchy for context, and your specific leaf ticket details. Read it carefully before starting work.

If you need the task's comment history or previous progress updates (e.g., if the task was partially worked on before):

```
GET /api/tasks/{taskId}
```

This returns the task object plus its `comments` and `updates` arrays.

### 2. Update status to in_progress

```
PATCH /api/tasks/{taskId}
{ "status": "in_progress" }
```

### 3. Implement the changes

Do the actual development work. Write code, modify files, etc.

### 4. Test your changes

**Testing is critical.** Since this is an autonomous development system with minimal human intervention, you MUST verify your changes work before moving on. Testing strategies:

- **Unit tests**: Run the project's test suite (e.g., `npm test`, `pytest`, etc.)
- **API testing**: If you implemented an API endpoint, make HTTP requests to verify it works
- **Script-based testing**: Write and run a quick script (Python, Node.js, bash) to test the functionality
- **Build verification**: Ensure the project builds without errors

If tests fail, fix the issues before proceeding.

### 5. Log your progress

Append a progress update describing what you did:

```
POST /api/tasks/{taskId}/updates
{ "text": "Implemented JWT authentication middleware. Added token generation on login and validation middleware for protected routes. All 12 unit tests passing.", "author": "Claude" }
```

Write clear, specific updates that document:

- What was implemented/changed
- What files were modified
- Test results
- Any issues encountered and how they were resolved

### 6. Update task status

After implementing and verifying your changes, move the task to the appropriate status:

- **If the task involves front-end changes** (UI, HTML, CSS, Vue components, client-side JS, etc.), move it to `testing` so the QA engineer can verify it:

  ```
  PATCH /api/tasks/{taskId}
  { "status": "testing" }
  ```

- **If the task is backend-only** (API endpoints, database, server logic, scripts, config, etc.) with no front-end impact, move it to `done`:
  ```
  PATCH /api/tasks/{taskId}
  { "status": "done" }
  ```

**Valid task statuses:** `ideas`, `todo`, `in_progress`, `review`, `testing`, `done`

### 7. Ask the user

After completing a task, inform the user what was done and ask if they want to continue with the next task. Do NOT automatically proceed without user confirmation.

---

## Project Manager Chat

Each project has a built-in **AI Project Manager** you can talk to via a simple chat API. It has full context about the project (scope, status, all tasks, all milestones) and can both **answer questions** and **make changes** to tasks and milestones.

### When to use the Project Manager

- **Clarifying ticket requirements** — If a task's description or detail*text is unclear, ask the project manager: *"What exactly should task #abc123 implement? The description doesn't mention which API format to use."\_
- **Getting project context** — _"What is this project about?"_, _"What milestones are in progress?"_, _"Which tasks are blocked?"_
- **Creating tasks/milestones** — _"Create a task called 'Add input validation' in todo"_, _"Create a milestone for the v2 release"_
- **Updating tasks** — _"Move task #abc123 to done"_, _"Change the title of task #abc123 to 'Fix auth bug'"_
- **Surgical text edits** — _"In task #abc123, replace 'bcrypt' with 'argon2' in the detail_text"_ — this does a precise find-and-replace without rewriting the whole field
- **Bulk text replacements** — _"Replace all occurrences of 'Login' with 'Sign-in' in the description of task #abc123"_ (uses `replace_all`)
- **Deleting tasks/milestones** — _"Delete task #abc123"_, _"Delete the 'Legacy API' milestone"_
- **Asking for guidance** — _"What should I work on next?"_, _"Is there a task that covers database migrations?"_

### Chat API

**Send a message:**

```
POST /api/projects/{projectId}/chat
{ "message": "Your question or instruction here" }
```

**Response:**

```json
{
  "message": {
    "id": "msg123",
    "role": "assistant",
    "content": "The project manager's reply text...",
    "created_at": "2026-02-11T20:00:00.000Z"
  },
  "actions_performed": [
    {
      "tool": "create_task",
      "args": { "title": "Add validation", "status": "todo" },
      "result": { "ok": true, "task_id": "xyz789" }
    }
  ]
}
```

- `message.content` — The project manager's natural language reply
- `actions_performed` — Array of any changes it made (empty if it just answered a question). Check this to know if tasks/milestones were created, updated, or deleted
- If `actions_performed` is non-empty, the Kanban board has been modified — you may want to re-fetch tasks

**Get conversation history:**

```
GET /api/projects/{projectId}/chat?limit=50
```

Returns the last N messages (user + assistant, oldest first). Useful if you want to review what was discussed previously.

**Clear conversation:**

```
DELETE /api/projects/{projectId}/chat
```

### Available tools the Project Manager can use

The project manager uses OpenAI-compatible tool calls internally. You don't need to specify tools — just describe what you want in plain language. It has access to:

| Tool                   | What it does                                                                                                                    |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| `create_task`          | Create a new task (title, description, detail_text, status, parent_id, milestone_id)                                            |
| `update_task`          | Update any task fields (title, description, detail_text, status, parent_id, milestone_id)                                       |
| `edit_task_field`      | Surgical find-and-replace on a task's title, description, or detail_text. Supports `replace_all` for replacing every occurrence |
| `delete_task`          | Soft-delete a task and all its subtasks                                                                                         |
| `create_milestone`     | Create a new milestone                                                                                                          |
| `update_milestone`     | Update milestone fields                                                                                                         |
| `edit_milestone_field` | Surgical find-and-replace on a milestone's title or description. Supports `replace_all`                                         |
| `delete_milestone`     | Delete a milestone (unlinks tasks, doesn't delete them)                                                                         |

### Example: Asking for clarification while working on a task

```
POST /api/projects/{projectId}/chat
{ "message": "I'm working on task #abc123 which says 'Add user authentication'. Should I use JWT or session-based auth? The ticket doesn't specify." }
```

The project manager will check the project scope and other tickets for context and give you a recommendation based on the overall project architecture.

---

## Complete API Reference

### Projects

| Method | Endpoint             | Description                                                                                |
| ------ | -------------------- | ------------------------------------------------------------------------------------------ |
| GET    | `/api/projects`      | List all projects                                                                          |
| POST   | `/api/projects`      | Create project. Body: `{ name, scope_text?, status_text?, guidelines_text?, repo_path? }`  |
| GET    | `/api/projects/{id}` | Get project details                                                                        |
| PATCH  | `/api/projects/{id}` | Update project. Body: `{ name?, scope_text?, status_text?, guidelines_text?, repo_path? }` |
| DELETE | `/api/projects/{id}` | Delete project                                                                             |

### Tasks

| Method | Endpoint                                   | Description                                                                                                  |
| ------ | ------------------------------------------ | ------------------------------------------------------------------------------------------------------------ |
| GET    | `/api/tasks?project_id={id}`               | List tasks for a project                                                                                     |
| POST   | `/api/tasks`                               | Create task. Body: `{ title, description?, status?, detail_text?, project_id, parent_id?, milestone_id? }`   |
| GET    | `/api/tasks/{id}`                          | Get task with comments and progress updates                                                                  |
| PATCH  | `/api/tasks/{id}`                          | Update task. Body: `{ title?, description?, status?, detail_text?, project_id?, parent_id?, milestone_id? }` |
| DELETE | `/api/tasks/{id}`                          | Soft-delete task and descendants                                                                             |
| GET    | `/api/tasks/{id}/ancestors?include_self=1` | Get ancestor path                                                                                            |
| GET    | `/api/tasks/{id}/descendants`              | Get descendant tasks                                                                                         |
| GET    | `/api/tasks/{id}/context`                  | Get rich context (project, path, children, rendered text)                                                    |
| PATCH  | `/api/tasks/{id}/cascade-status`           | Set status on task and all descendants. Body: `{ status }`                                                   |
| POST   | `/api/tasks/{id}/comments`                 | Add comment. Body: `{ text, author? }`                                                                       |
| POST   | `/api/tasks/{id}/updates`                  | Add progress update. Body: `{ text, author? }`                                                               |

### Milestones

| Method | Endpoint                        | Description                                                                          |
| ------ | ------------------------------- | ------------------------------------------------------------------------------------ |
| GET    | `/api/projects/{id}/milestones` | List milestones for project (with task counts)                                       |
| GET    | `/api/milestones/{id}`          | Get milestone with tasks, comments, updates                                          |
| POST   | `/api/milestones`               | Create milestone. Body: `{ title, project_id, description?, status?, target_date? }` |
| PATCH  | `/api/milestones/{id}`          | Update milestone                                                                     |
| DELETE | `/api/milestones/{id}`          | Delete milestone                                                                     |
| POST   | `/api/milestones/{id}/comments` | Add comment to milestone                                                             |
| POST   | `/api/milestones/{id}/updates`  | Add progress update to milestone                                                     |

### Project Manager Chat

| Method | Endpoint                           | Description                                                                                       |
| ------ | ---------------------------------- | ------------------------------------------------------------------------------------------------- |
| POST   | `/api/projects/{id}/chat`          | Send a message to the project manager. Body: `{ message }`. Returns reply + any actions performed |
| GET    | `/api/projects/{id}/chat?limit=50` | Get conversation history (user + assistant messages, oldest first)                                |
| DELETE | `/api/projects/{id}/chat`          | Clear all chat messages for the project                                                           |

### AI / Autonomous Endpoints

| Method | Endpoint                                      | Description                                                                                                                                          |
| ------ | --------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| GET    | `/api/ai/health`                              | Check if AI/LLM is enabled and configured                                                                                                            |
| POST   | `/api/ai/projects/{id}/init`                  | Initialize project from repository (slow: 60-180s)                                                                                                   |
| POST   | `/api/ai/projects/{id}/sync-status/start`     | Start async status sync (returns job_id, poll via /api/ai/jobs/{jobId})                                                                              |
| POST   | `/api/ai/projects/{id}/sync-status`           | Sync status synchronously (legacy, can timeout on large repos)                                                                                       |
| POST   | `/api/ai/projects/{id}/refresh-status`        | Refresh status (repo-aware or LLM fallback)                                                                                                          |
| POST   | `/api/ai/projects/{id}/evolve`                | LLM-based task creation                                                                                                                              |
| POST   | `/api/ai/projects/{id}/codebase-evolve`       | CLI-based task creation (repo-aware)                                                                                                                 |
| POST   | `/api/ai/projects/{id}/unified-evolve`        | Unified evolve: PM context + repo access in single CLI call (experimental). Body: `{ goal?, milestone_id?, max_depth?, max_new_tasks?, apply? }`     |
| POST   | `/api/ai/projects/{id}/cli-create-milestones` | CLI-based milestone creation (repo-aware). Body: `{ max_milestones?, apply? }`. Uses Claude Code to investigate codebase before proposing milestones |
| GET    | `/api/ai/projects/{id}/next-task`             | Pick next task (lightweight, fast)                                                                                                                   |
| POST   | `/api/ai/projects/{id}/autonomous-next/start` | Start autonomous pipeline (async, returns job_id)                                                                                                    |
| GET    | `/api/ai/jobs/{jobId}`                        | Poll pipeline job status                                                                                                                             |
| POST   | `/api/ai/projects/{id}/autonomous-next`       | Run autonomous pipeline synchronously (blocks, can timeout)                                                                                          |

### Agents

| Method | Endpoint                         | Description                                                                                                                                              |
| ------ | -------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| GET    | `/api/projects/{id}/agents`      | List agents for a project (includes last_run info)                                                                                                       |
| GET    | `/api/agents/{id}`               | Get single agent with last 20 runs                                                                                                                       |
| POST   | `/api/agents`                    | Create agent. Body: `{ project_id, name, description?, system_prompt?, repo_path?, allowed_tools?, max_turns?, status?, dangerously_skip_permissions? }` |
| PATCH  | `/api/agents/{id}`               | Update agent (partial). Same fields as create (except project_id)                                                                                        |
| DELETE | `/api/agents/{id}`               | Delete agent and all run history                                                                                                                         |
| POST   | `/api/agents/{id}/clear-session` | Reset the agent's Claude session (starts fresh on next run)                                                                                              |
| GET    | `/api/agents/{id}/runs?limit=20` | Get run history for an agent                                                                                                                             |
| POST   | `/api/agents/{id}/run/start`     | Start an async agent run. Body: `{ prompt }`. Returns `{ job_id, run_id, status }` (202). Poll via `/api/ai/jobs/{job_id}`                               |

### Next Task Selection (Non-AI)

| Method | Endpoint                       | Description                                                                          |
| ------ | ------------------------------ | ------------------------------------------------------------------------------------ |
| POST   | `/api/projects/{id}/next-task` | Pick next task via LLM. Body: `{ exclude_status?, prefer_status?, max_candidates? }` |

---

## Full Autonomous Development Loop

Here is the complete loop for autonomous infinite development:

```
1. GET /api/projects → pick or create the project
2. If new project with PRD:
     POST /api/projects { name, scope_text, repo_path }
     POST /api/ai/projects/{id}/sync-status/start → poll GET /api/ai/jobs/{jobId} every 15s until done ← ALWAYS run this, even for empty repos
   If existing repo (no PRD):
     POST /api/projects { name, repo_path }
     POST /api/ai/projects/{id}/init { path, apply: true, create_seed_tasks: true } (wait 60-180s)

3. LOOP:
   a. GET /api/ai/projects/{id}/next-task
   b. If task found (selected is not null):
        → Read context.agent_instructions for full task brief (project scope, parent hierarchy, task details)
        → Proceed to step (c)
      If NO task found (selected is null):
        → POST /api/ai/projects/{id}/autonomous-next/start
        → Poll GET /api/ai/jobs/{jobId} every 30s (max 20 min)
        → If pipeline completed with result.selected → use it (read result.context.agent_instructions)
        → If pipeline completed with no selected task or pipeline failed → inform user, stop
   c. PATCH /api/tasks/{taskId} { status: "in_progress" }
   d. Implement the changes (using agent_instructions as your task brief)
   e. TEST the changes thoroughly
   f. POST /api/tasks/{taskId}/updates { text: "Description of work done...", author: "Claude" }
   g. If task involved front-end changes:
        PATCH /api/tasks/{taskId} { status: "testing" }
      Else (backend-only):
        PATCH /api/tasks/{taskId} { status: "done" }
   h. Ask user: "Task complete. Continue with next task?"
   i. If user confirms → go to step (a)
      If user declines → stop
```

---

## Important Notes

- **Long-running calls**: The `init`, `sync-status/start`, and `autonomous-next/start` endpoints involve LLM calls and/or codebase exploration. They can take minutes. Always use the async endpoints (`sync-status/start`, `autonomous-next/start`) and poll `GET /api/ai/jobs/{jobId}` for results rather than the synchronous variants which may timeout.
- **Testing is mandatory**: Since this system operates with minimal human oversight, always test your changes before marking a task as done. Use unit tests, API calls, scripts, or build verification as appropriate for the project.
- **Progress updates are your work log**: Always append a progress update to each task you complete. This is the audit trail of what was done.
- **One task at a time**: Work on one task, complete it fully (including testing), log your progress, then move on.
- **Respect the hierarchy**: Tasks can have parent-child relationships. The next-task selection algorithm considers this. Trust it to pick the right task.
- **Status flow**: `ideas` → `todo` → `in_progress` → `testing` → `done` (or `review` → `done`). Tasks with front-end changes should go to `testing` for QA review; backend-only tasks can go directly to `done`.
