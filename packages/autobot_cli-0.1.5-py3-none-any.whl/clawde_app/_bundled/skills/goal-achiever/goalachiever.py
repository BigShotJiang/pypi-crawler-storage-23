#!/usr/bin/env python3
"""
goalachiever.py

Create/manage long-horizon, file-based "goal workspace" instances from a template.

Design constraints:
  - Standard library only (no external dependencies)
  - Safe by default (no destructive actions unless explicitly requested)
  - Workspace state lives in files, enabling repeated CLI-agent iterations.
"""

from __future__ import annotations

import argparse
import json
import re
import secrets
import shutil
import subprocess
import sys
import textwrap
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Constants / defaults
# ----------------------------

DEFAULT_WORKSPACES_DIRNAME = "goal-workspaces"
DEFAULT_TEMPLATE_REL = Path("template")
WORKSPACE_META_FILENAME = ".goalachiever.json"
REGISTRY_FILENAME = "REGISTRY.json"

REQUIRED_TEMPLATE_PATHS = [
    Path("CLAUDE.md"),
    Path("GOAL.md"),
    Path("status") / "STATUS.md",
    Path("status") / "METRICS.md",
    Path("tasks") / "BOARD.md",
    Path("memory") / "MEMORY.md",
]


# ----------------------------
# Small helpers
# ----------------------------

def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _eprint(*args: Any) -> None:
    print(*args, file=sys.stderr)


def _die(msg: str, code: int = 1) -> None:
    _eprint(f"error: {msg}")
    sys.exit(code)


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(_read_text(path))


def _save_json(path: Path, data: Dict[str, Any]) -> None:
    _write_text(path, json.dumps(data, indent=2, sort_keys=True) + "\n")


def _slugify(text: str, max_len: int = 64) -> str:
    """
    Convert arbitrary text into a filesystem-friendly slug.
    """
    s = text.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-{2,}", "-", s).strip("-")
    if not s:
        s = "goal-" + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return s[:max_len].rstrip("-")


def _is_git_available() -> bool:
    return shutil.which("git") is not None


def _run_git_init(dest: Path) -> None:
    if not _is_git_available():
        _die("git is not available on PATH; cannot --git-init")
    subprocess.run(["git", "init"], cwd=str(dest), check=True)


def _resolve_root(root_arg: Optional[str]) -> Path:
    """
    Base directory for creating/listing workspaces.
    Defaults to current working directory.
    """
    if root_arg:
        return Path(root_arg).expanduser().resolve()
    return Path.cwd().resolve()


def _default_template_dir() -> Path:
    """
    Default template directory is next to this script:
      <script_dir>/template/goal-workspace
    """
    return Path(__file__).resolve().parent / DEFAULT_TEMPLATE_REL


def _validate_template_dir(template_dir: Path) -> Tuple[bool, List[Path]]:
    missing: List[Path] = []
    for rel in REQUIRED_TEMPLATE_PATHS:
        if not (template_dir / rel).exists():
            missing.append(rel)
    return (len(missing) == 0, missing)


def _insert_or_replace_block(
    text: str,
    start_marker: str,
    end_marker: str,
    block_lines: List[str],
) -> str:
    """
    Insert a marked block or replace it if already present.
    The block will include the markers.
    """
    block = "\n".join([start_marker, *block_lines, end_marker]) + "\n"

    start_idx = text.find(start_marker)
    end_idx = text.find(end_marker)
    if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
        end_idx = end_idx + len(end_marker)
        before = text[:start_idx].rstrip("\n")
        after = text[end_idx:].lstrip("\n")
        combined = (before + "\n\n" + block.strip("\n") + "\n\n" + after).strip("\n") + "\n"
        return combined

    # If no existing block, insert near top (after first header if present).
    lines = text.splitlines()
    insert_at = 0
    if lines and lines[0].startswith("#"):
        insert_at = 1
    new_lines = lines[:insert_at] + ["", block.strip("\n"), ""] + lines[insert_at:]
    return "\n".join(new_lines).strip("\n") + "\n"


def _upsert_workspace_markers(workspace_dir: Path, goal_text: str, slug: str) -> None:
    """
    Inject idempotent metadata blocks into key workspace docs.
    This keeps the workspace self-describing even if created automatically.
    """
    created_at = _now_utc_iso()

    # GOAL.md
    goal_md = workspace_dir / "GOAL.md"
    if goal_md.exists():
        text = _read_text(goal_md)
    else:
        text = "# Goal\n"
    text = _insert_or_replace_block(
        text,
        "<!-- goalachiever:objective:start -->",
        "<!-- goalachiever:objective:end -->",
        [
            f"**Objective (from init):** {goal_text}",
            "",
            f"- Workspace slug: `{slug}`",
            f"- Created (UTC): `{created_at}`",
        ],
    )
    _write_text(goal_md, text)

    # memory/MEMORY.md
    mem_md = workspace_dir / "memory" / "MEMORY.md"
    if mem_md.exists():
        text = _read_text(mem_md)
    else:
        text = "# Memory\n"
    text = _insert_or_replace_block(
        text,
        "<!-- goalachiever:workspace-meta:start -->",
        "<!-- goalachiever:workspace-meta:end -->",
        [
            f"- Workspace: `{slug}`",
            f"- Objective: {goal_text}",
            f"- Created (UTC): `{created_at}`",
            "",
            "_Keep this file compact. Move details into topic files or logs._",
        ],
    )
    _write_text(mem_md, text)

    # status/STATUS.md (light touch)
    status_md = workspace_dir / "status" / "STATUS.md"
    if status_md.exists():
        text = _read_text(status_md)
        text = _insert_or_replace_block(
            text,
            "<!-- goalachiever:status-meta:start -->",
            "<!-- goalachiever:status-meta:end -->",
            [
                f"- Objective: {goal_text}",
                f"- Workspace: `{slug}`",
            ],
        )
        _write_text(status_md, text)


def _normalize_external_paths(paths: List[str]) -> List[str]:
    norm: List[str] = []
    for p in paths:
        pp = str(Path(p).expanduser().resolve())
        if pp not in norm:
            norm.append(pp)
    return norm


def _update_external_md(workspace_dir: Path, external_paths: List[str]) -> None:
    """
    Ensure external/EXTERNAL.md contains an idempotent block with linked repos.
    """
    ext_md = workspace_dir / "external" / "EXTERNAL.md"
    if ext_md.exists():
        text = _read_text(ext_md)
    else:
        text = "# External repositories\n\nThis workspace tracks work done in other repositories.\n"

    if external_paths:
        block_lines = ["## Linked repositories"] + [f"- `{p}`" for p in external_paths] + [
            "",
            "### Operating rules",
            "- Plan in this workspace; execute in the external repo; always write back evidence here.",
            "- Prefer recording commit hashes/PR links and test results.",
            "- Do not copy large chunks of the external repo into this workspace.",
        ]
    else:
        block_lines = [
            "## Linked repositories",
            "_None linked yet. Use the CLI to link:_",
            "",
            "```bash",
            f"python3 {Path(__file__).name} link <workspace-path> --external /path/to/repo",
            "```",
        ]

    text = _insert_or_replace_block(
        text,
        "<!-- goalachiever:linked-repos:start -->",
        "<!-- goalachiever:linked-repos:end -->",
        block_lines,
    )
    _write_text(ext_md, text)


def _workspace_meta_path(workspace_dir: Path) -> Path:
    return workspace_dir / WORKSPACE_META_FILENAME


def _is_workspace_dir(path: Path) -> bool:
    return _workspace_meta_path(path).exists()


def _resolve_workspace_arg(root: Path, workspaces_dir: str, workspace_arg: str) -> Path:
    """
    Workspace arg can be:
      - an existing path to a workspace dir
      - a slug (directory name) under <root>/<workspaces_dir>/
    """
    p = Path(workspace_arg).expanduser()
    if p.exists():
        return p.resolve()
    # treat as slug
    candidate = (root / workspaces_dir / workspace_arg).resolve()
    return candidate


def _registry_path(root: Path, workspaces_dir: str) -> Path:
    return root / workspaces_dir / REGISTRY_FILENAME


def _update_registry(root: Path, workspaces_dir: str, workspace_dir: Path, meta: Dict[str, Any]) -> None:
    """
    Maintain a simple registry for convenience. Safe: only writes under <root>/<workspaces_dir>/REGISTRY.json.
    """
    reg_path = _registry_path(root, workspaces_dir)
    reg_path.parent.mkdir(parents=True, exist_ok=True)

    rel_path: str
    try:
        rel_path = workspace_dir.resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        rel_path = workspace_dir.resolve().as_posix()

    entry = {
        "id": meta.get("id"),
        "slug": meta.get("slug"),
        "goal": meta.get("goal"),
        "created_at": meta.get("created_at"),
        "path": rel_path,
    }

    if reg_path.exists():
        try:
            reg = _load_json(reg_path)
        except Exception:
            reg = {}
    else:
        reg = {}

    workspaces = reg.get("workspaces", [])
    if not isinstance(workspaces, list):
        workspaces = []

    # Replace any existing entry with same id or same path
    new_workspaces: List[Dict[str, Any]] = []
    for w in workspaces:
        if not isinstance(w, dict):
            continue
        if w.get("id") == entry["id"]:
            continue
        if w.get("path") == entry["path"]:
            continue
        new_workspaces.append(w)
    new_workspaces.append(entry)

    reg_out = {
        "version": 1,
        "updated_at": _now_utc_iso(),
        "workspaces": sorted(new_workspaces, key=lambda x: (x.get("created_at") or "", x.get("slug") or "")),
    }
    _save_json(reg_path, reg_out)


# ----------------------------
# Commands
# ----------------------------

def cmd_doctor(args: argparse.Namespace) -> None:
    template_dir = Path(args.template).expanduser().resolve() if args.template else _default_template_dir()
    ok, missing = _validate_template_dir(template_dir)
    print(f"Template dir: {template_dir}")
    if ok:
        print("OK: template contains required files.")
        return
    print("MISSING required template files:")
    for rel in missing:
        print(f"  - {rel.as_posix()}")
    sys.exit(2)


def cmd_init(args: argparse.Namespace) -> None:
    root = _resolve_root(args.root)
    template_dir = Path(args.template).expanduser().resolve() if args.template else _default_template_dir()

    ok, missing = _validate_template_dir(template_dir)
    if not ok:
        _die(
            "template is missing required files:\n"
            + "\n".join([f"  - {p.as_posix()}" for p in missing])
            + f"\nTemplate dir: {template_dir}\n"
            + "Run `python3 goalachiever.py doctor` after installing the template."
        )

    goal_text = args.goal.strip()
    if not goal_text:
        _die("--goal must be non-empty")

    slug_base = args.slug or _slugify(args.name or goal_text)

    if args.dest:
        dest = Path(args.dest).expanduser().resolve()
    else:
        dest = (root / args.workspaces_dir / slug_base).resolve()

    if dest.exists():
        if _is_workspace_dir(dest):
            _die(
                f"workspace already exists at {dest}\n"
                "Use `info` to inspect it, or choose a different --slug/--dest."
            )
        _die(f"destination already exists at {dest} (not a workspace). Choose a different --dest or remove it.")

    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(str(template_dir), str(dest))

    meta = {
        "id": "GA-" + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%SZ") + "-" + secrets.token_hex(3),
        "slug": dest.name,
        "goal": goal_text,
        "created_at": _now_utc_iso(),
        "created_from": {
            "root": str(root),
            "template_dir": str(template_dir),
        },
        "external_repositories": [],
    }

    external_paths = _normalize_external_paths(args.external or [])
    for p in external_paths:
        meta["external_repositories"].append({"path": p, "added_at": _now_utc_iso()})

    _save_json(_workspace_meta_path(dest), meta)
    _upsert_workspace_markers(dest, goal_text=goal_text, slug=meta["slug"])
    _update_external_md(dest, external_paths)

    if args.git_init:
        try:
            _run_git_init(dest)
        except subprocess.CalledProcessError as e:
            _die(f"git init failed: {e}")

    # Update registry only if workspace is under root/workspaces_dir (default structure).
    try:
        _ = dest.relative_to((root / args.workspaces_dir).resolve())
        _update_registry(root, args.workspaces_dir, dest, meta)
    except Exception:
        # Not under the standard location; do not maintain registry.
        pass

    print(str(dest))
    if args.print_next:
        print("\nNext steps:")
        print(f"  1) cd {dest}")
        print("  2) Open Claude Code in this directory")
        print('  3) Run: p "iterate the project"')


def cmd_list(args: argparse.Namespace) -> None:
    root = _resolve_root(args.root)
    base = (root / args.workspaces_dir).resolve()
    if not base.exists():
        print(f"No workspaces directory found at: {base}")
        return

    reg_path = _registry_path(root, args.workspaces_dir)
    if reg_path.exists():
        try:
            reg = _load_json(reg_path)
            workspaces = reg.get("workspaces", [])
            if isinstance(workspaces, list) and workspaces:
                print(f"Workspaces (from {reg_path}):")
                for w in workspaces:
                    if not isinstance(w, dict):
                        continue
                    print(f"- {w.get('slug')}: {w.get('path')}")
                    goal = w.get("goal")
                    if goal:
                        print(f"  goal: {goal}")
                return
        except Exception:
            # Fall through to scan
            pass

    # Scan for .goalachiever.json
    found: List[Tuple[str, Path, str]] = []
    for d in sorted(base.iterdir()):
        if not d.is_dir():
            continue
        meta_path = _workspace_meta_path(d)
        if meta_path.exists():
            try:
                meta = _load_json(meta_path)
                goal = str(meta.get("goal") or "")
                found.append((d.name, d, goal))
            except Exception:
                found.append((d.name, d, ""))

    if not found:
        print(f"No workspaces found under: {base}")
        return

    print(f"Workspaces (scanned under {base}):")
    for slug, path, goal in found:
        print(f"- {slug}: {path}")
        if goal:
            print(f"  goal: {goal}")


def cmd_info(args: argparse.Namespace) -> None:
    root = _resolve_root(args.root)
    ws = _resolve_workspace_arg(root, args.workspaces_dir, args.workspace)
    meta_path = _workspace_meta_path(ws)
    if not meta_path.exists():
        _die(f"not a workspace (missing {WORKSPACE_META_FILENAME}): {ws}")
    meta = _load_json(meta_path)

    print(f"Workspace: {ws}")
    print(f"  id: {meta.get('id')}")
    print(f"  slug: {meta.get('slug')}")
    print(f"  created_at: {meta.get('created_at')}")
    print(f"  goal: {meta.get('goal')}")

    exts = meta.get("external_repositories", [])
    if isinstance(exts, list) and exts:
        print("  external_repositories:")
        for e in exts:
            if isinstance(e, dict):
                print(f"    - {e.get('path')} (added_at: {e.get('added_at')})")
            else:
                print(f"    - {e}")
    else:
        print("  external_repositories: (none)")

    print("\nKey files:")
    print(f"  - {ws / 'CLAUDE.md'}")
    print(f"  - {ws / 'GOAL.md'}")
    print(f"  - {ws / 'status' / 'STATUS.md'}")
    print(f"  - {ws / 'status' / 'METRICS.md'}")
    print(f"  - {ws / 'status' / 'NEXT_ACTIONS.md'}")
    print(f"  - {ws / 'tasks' / 'BOARD.md'}")
    print(f"  - {ws / 'logs' / 'ITERATIONS.md'}")


def cmd_link(args: argparse.Namespace) -> None:
    root = _resolve_root(args.root)
    ws = _resolve_workspace_arg(root, args.workspaces_dir, args.workspace)
    meta_path = _workspace_meta_path(ws)
    if not meta_path.exists():
        _die(f"not a workspace (missing {WORKSPACE_META_FILENAME}): {ws}")

    meta = _load_json(meta_path)
    current_exts: List[Dict[str, Any]] = []
    if isinstance(meta.get("external_repositories"), list):
        for e in meta["external_repositories"]:
            if isinstance(e, dict) and "path" in e:
                current_exts.append(e)

    new_paths = _normalize_external_paths(args.external or [])
    if not new_paths:
        _die("--external must be provided at least once")

    existing_paths = {e["path"] for e in current_exts}
    for p in new_paths:
        if p in existing_paths:
            continue
        current_exts.append({"path": p, "added_at": _now_utc_iso()})
        existing_paths.add(p)

    meta["external_repositories"] = current_exts
    _save_json(meta_path, meta)

    _update_external_md(ws, [e["path"] for e in current_exts])
    print(f"Linked {len(new_paths)} external repo(s) to: {ws}")


def cmd_set_goal(args: argparse.Namespace) -> None:
    root = _resolve_root(args.root)
    ws = _resolve_workspace_arg(root, args.workspaces_dir, args.workspace)
    meta_path = _workspace_meta_path(ws)
    if not meta_path.exists():
        _die(f"not a workspace (missing {WORKSPACE_META_FILENAME}): {ws}")

    goal_text = args.goal.strip()
    if not goal_text:
        _die("--goal must be non-empty")

    meta = _load_json(meta_path)
    meta["goal"] = goal_text
    _save_json(meta_path, meta)

    external_paths: List[str] = []
    exts = meta.get("external_repositories", [])
    if isinstance(exts, list):
        for e in exts:
            if isinstance(e, dict) and "path" in e:
                external_paths.append(str(e["path"]))

    _upsert_workspace_markers(ws, goal_text=goal_text, slug=str(meta.get("slug") or ws.name))
    _update_external_md(ws, external_paths)
    print(f"Updated goal for: {ws}")


# ----------------------------
# CLI
# ----------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="goalachiever.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent(
            """
            Goal Achiever CLI

            Creates and manages "goal workspace" instances from a template directory.
            """
        ).strip(),
    )

    parser.add_argument(
        "--root",
        default=None,
        help="Base directory for goal-workspaces/ (default: current directory).",
    )
    parser.add_argument(
        "--workspaces-dir",
        default=DEFAULT_WORKSPACES_DIRNAME,
        help=f"Directory name under --root to store workspaces (default: {DEFAULT_WORKSPACES_DIRNAME}).",
    )

    sub = parser.add_subparsers(dest="cmd", required=True)

    p_doctor = sub.add_parser("doctor", help="Validate the template directory.")
    p_doctor.add_argument(
        "--template",
        default=None,
        help="Path to template directory. Default: <script_dir>/template/goal-workspace",
    )
    p_doctor.set_defaults(func=cmd_doctor)

    p_init = sub.add_parser("init", help="Create a new goal workspace from the template.")
    p_init.add_argument("--goal", required=True, help="Goal text (objective).")
    p_init.add_argument("--name", default=None, help="Optional human-friendly name (used for slug if provided).")
    p_init.add_argument("--slug", default=None, help="Optional explicit slug (directory name).")
    p_init.add_argument("--dest", default=None, help="Optional explicit destination directory for the workspace.")
    p_init.add_argument(
        "--template",
        default=None,
        help="Path to template directory. Default: <script_dir>/template/goal-workspace",
    )
    p_init.add_argument(
        "--external",
        action="append",
        default=[],
        help="Path to an external repo to link (repeatable).",
    )
    p_init.add_argument("--git-init", action="store_true", help="Run `git init` inside the workspace.")
    p_init.add_argument(
        "--print-next",
        action="store_true",
        help="Print suggested next steps after creating the workspace.",
    )
    p_init.set_defaults(func=cmd_init)

    p_list = sub.add_parser("list", help="List goal workspaces.")
    p_list.set_defaults(func=cmd_list)

    p_info = sub.add_parser("info", help="Show info about a workspace.")
    p_info.add_argument("workspace", help="Workspace path or slug (under goal-workspaces/).")
    p_info.set_defaults(func=cmd_info)

    p_link = sub.add_parser("link", help="Link external repository paths to an existing workspace.")
    p_link.add_argument("workspace", help="Workspace path or slug (under goal-workspaces/).")
    p_link.add_argument(
        "--external",
        action="append",
        default=[],
        help="Path to an external repo to link (repeatable).",
    )
    p_link.set_defaults(func=cmd_link)

    p_set_goal = sub.add_parser("set-goal", help="Update a workspace goal text.")
    p_set_goal.add_argument("workspace", help="Workspace path or slug (under goal-workspaces/).")
    p_set_goal.add_argument("--goal", required=True, help="New goal text.")
    p_set_goal.set_defaults(func=cmd_set_goal)

    return parser


def main(argv: Optional[List[str]] = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
