
# Experiment runbook (how to run it)

Write exact commands / steps so it can be repeated.

## Steps
1. …
2. …

## Notes
- …
