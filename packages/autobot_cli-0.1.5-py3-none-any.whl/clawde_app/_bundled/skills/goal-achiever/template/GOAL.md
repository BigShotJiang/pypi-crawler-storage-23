
# Goal

## Objective
(Write a single sentence objective.)

Example:
Increase sales by **20%** for **Company X**.

## Timebox
- Start: YYYY-MM-DD
- End: YYYY-MM-DD

## Key results (definition of done)
List measurable outcomes. Avoid vague goals.

| KR ID | Metric | Baseline | Target | Measurement source | Update cadence |
|------|--------|----------|--------|--------------------|----------------|
| KR1  |        |          |        |                    |                |
| KR2  |        |          |        |                    |                |

## Scope
### In scope
- …

### Out of scope
- …

## Constraints
- …

## Stakeholders
See `STAKEHOLDERS.md`.

## Assumptions
- …

## Risks
See `status/RISKS.md`.

## Notes
- If this goal requires external access (dashboards, repos, accounts), document exactly what is needed.
