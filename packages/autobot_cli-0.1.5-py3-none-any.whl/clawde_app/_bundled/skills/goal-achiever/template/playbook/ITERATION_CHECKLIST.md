
# Playbook: Iteration checklist

Use this as a checklist during each run.

## Start of iteration
- [ ] Read: GOAL.md, status/STATUS.md, status/METRICS.md, status/NEXT_ACTIONS.md, tasks/BOARD.md, memory/MEMORY.md
- [ ] Compact working docs if too long
- [ ] Restate goal + “definition of done” briefly

## Planning
- [ ] Update baseline metrics if missing
- [ ] Choose 1–3 actions max (measurement / experiment / execution)
- [ ] Ensure tasks exist for chosen actions
- [ ] Ensure hypotheses/experiments exist for exploration actions

## Execution
- [ ] Do the work (run commands, edit code, write docs)
- [ ] Capture evidence (logs, metrics, links)

## Evaluation
- [ ] Update experiment results
- [ ] Update hypothesis status (validated/rejected/active/parked)
- [ ] Update metrics snapshot if possible

## Write-back (required)
- [ ] Update status/STATUS.md (current truth)
- [ ] Update status/NEXT_ACTIONS.md (concrete next steps)
- [ ] Update tasks/BOARD.md (task movement)
- [ ] Append to logs/ITERATIONS.md (what happened)
- [ ] Update memory/MEMORY.md only if needed (keep it compact)

## End
- [ ] Stop cleanly after state is updated
- [ ] If blocked, list exact needs from user
