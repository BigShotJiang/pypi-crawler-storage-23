
---
id: H-YYYYMMDD-###
status: proposed  # proposed | active | validated | rejected | parked
confidence: low   # low | medium | high
expected_impact: medium  # low | medium | high
created: YYYY-MM-DD
tags: []
links:
  # All paths are repo-root relative (e.g., "status/STATUS.md")
  goal: GOAL.md
  related_tasks: []  # e.g., ["tasks/T-YYYYMMDD-001.md"]
  experiments: []    # e.g., ["experiments/E-YYYYMMDD-001/plan.md"]
---

# Hypothesis: <short statement>

## Claim
(If we do X, then Y will improve because Z.)

## Rationale (concise)
- …

## Predicted impact
- Metric(s):
- Expected change:
- Time to impact:

## How to test (minimum viable experiment)
- Experiment ID: E-YYYYMMDD-###
- Success criteria:
- Failure criteria:
- Data required:
- Risks:

## Current status
- Next step:
- Blockers:

## Evidence log
- YYYY-MM-DD: (link to experiment results / data)
