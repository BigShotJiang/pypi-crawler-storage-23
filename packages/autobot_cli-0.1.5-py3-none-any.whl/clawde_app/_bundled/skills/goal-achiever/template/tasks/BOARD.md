
# Task board

This is a lightweight Kanban view.
Each task should also have a dedicated file in `tasks/` when it needs detail.

## Backlog
- (create tasks as needed)

## Next
- (top 1–3 tasks for next iteration)

## In progress
- 

## Blocked
- 

## Done
-
