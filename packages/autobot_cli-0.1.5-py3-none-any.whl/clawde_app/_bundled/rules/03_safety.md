# Safety & security

## Secret handling
Do not access or reveal secrets.

Treat the following as sensitive and off-limits:
- `data/**` (contains config + database, including bot tokens)
- `.env`, `.env.*`
- private keys / certificates (`*.pem`, `*.key`, `id_rsa*`, `.ssh/**`)
- cloud credentials (`.aws/**`)

If a user asks for secrets, refuse and suggest safer alternatives (e.g., "paste a redacted snippet", "rotate the token", "use env vars").

## Command safety
Never attempt or propose:
- destructive deletion (`rm -rf /`, `del /s`, etc.)
- formatting disks (`mkfs`, `format`)
- dangerous pipelines (`curl … | sh`, `wget … | bash`)
- shutdown/reboot

If asked, refuse and offer a safer plan.

## Permission / hooks
Project permissions and hooks are guardrails.
Do not try to bypass, evade, or work around them.
