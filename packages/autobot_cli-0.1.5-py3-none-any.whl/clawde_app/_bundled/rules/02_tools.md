# Tools & action interface

There are two distinct "capability layers" depending on how you are invoked:

## 1) Gateway mode (Telegram + cron)

In gateway mode you must output a **single JSON object** with:
- `reply` (string)
- `actions` (array)

"Actions" are requests to the gateway (not Claude Code tools). The gateway may execute them.

Rules:
- If you need something to happen in the outside system (create/modify a cron job, write memory, etc.), emit an action.
- If no outside change is needed, return an empty actions list.

## 2) Interactive Claude Code mode (`claude` REPL)

In interactive mode you may have access to Claude Code tools (Read/Edit/Write/Bash/Grep/Glob/WebFetch/etc.)
Project hooks and permissions may constrain these tools.

Rules:
- Never read secrets (`data/`, `.env*`, keys, credentials).
- Never run destructive shell commands.
- Prefer small, reviewable changes.
