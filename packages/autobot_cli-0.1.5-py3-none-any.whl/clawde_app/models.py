from __future__ import annotations

import json
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union

try:
    import orjson  # type: ignore
except Exception:  # pragma: no cover
    orjson = None  # type: ignore

# Pydantic (v1/v2 compatible-ish usage)
try:
    from pydantic import BaseModel, Field  # type: ignore
except Exception as e:  # pragma: no cover
    raise RuntimeError(
        "pydantic is required. Install dependencies from requirements/pyproject."
    ) from e


class ChatStatus(str, Enum):
    paired = "paired"
    unpaired = "unpaired"


class TelegramMode(str, Enum):
    polling = "polling"
    webhook = "webhook"


class RunMode(str, Enum):
    telegram = "telegram"
    cron = "cron"
    ingest = "ingest"


class JobScheduleType(str, Enum):
    cron = "cron"
    interval = "interval"
    once = "once"
    gapped = "gapped"


class EventRole(str, Enum):
    user = "user"
    assistant = "assistant"
    system = "system"


class EventSource(str, Enum):
    telegram_in = "telegram_in"
    telegram_out = "telegram_out"
    cron = "cron"
    gateway = "gateway"


class ActionType(str, Enum):
    schedule_job = "schedule_job"
    enable_job = "enable_job"
    disable_job = "disable_job"
    delete_job = "delete_job"
    trigger_job = "trigger_job"
    write_memory = "write_memory"
    append_daily_log = "append_daily_log"
    set_tool_profile = "set_tool_profile"
    set_project_dir = "set_project_dir"
    set_backend = "set_backend"
    modify_job = "modify_job"
    write_skill = "write_skill"
    enable_skill = "enable_skill"
    disable_skill = "disable_skill"
    create_goal = "create_goal"
    register_mcp_server = "register_mcp_server"
    remove_mcp_server = "remove_mcp_server"
    setup_autonomous_dev = "setup_autonomous_dev"


# ----------------------------
# Action payloads
# ----------------------------
class ScheduleJobPayload(BaseModel):
    name: str = Field(..., description="Human-readable unique-ish job name")
    schedule_type: JobScheduleType
    schedule_value: str = Field(
        ...,
        description=(
            "For cron: 'min hour dom mon dow'. For interval: JSON string "
            "like '{\"minutes\":30}'. For once: ISO timestamp."
        ),
    )
    timezone: str = Field("Europe/London", description="IANA timezone, default Europe/London")
    prompt: str = Field(..., description="Prompt instruction for the scheduled run")
    target_chat_id: Optional[int] = Field(
        None, description="If provided, post the job's reply into this Telegram chat"
    )
    tool_profile: str = Field(
        "read_only",
        description="Name of tool profile to use for this job, e.g. read_only/dev",
    )
    active_start: Optional[str] = Field(
        None,
        description="Active window start HH:MM (24h). Both start and end required if set.",
    )
    active_end: Optional[str] = Field(
        None,
        description="Active window end HH:MM (24h). Overnight ranges like 23:00-09:00 supported.",
    )
    backend: Optional[str] = Field(
        None,
        description="Backend to use: 'claude', 'codex', or 'gemini'. Defaults to chat/global default.",
    )
    agent_profile: Optional[str] = Field(
        None,
        description="Agent profile to use (e.g. 'clawde', 'jarvis'). Defaults to the bot's own agent.",
    )
    sessionful: bool = Field(
        False,
        description=(
            "If true, the job resumes the same CLI session across runs, "
            "enabling multi-step autonomous tasks with continuity. Default false (stateless)."
        ),
    )
    use_chat_session: bool = Field(
        False,
        description=(
            "If true, the cron job shares the Telegram chat's Claude session "
            "instead of its own. Requires target_chat_id. "
            "The chat session is updated after each successful run."
        ),
    )
    project_dir: Optional[str] = Field(
        None,
        description=(
            "Absolute path to working directory for this job. "
            "If omitted, inherits from the chat's project_dir at creation time."
        ),
    )


class ModifyJobPayload(BaseModel):
    job_id: int = Field(..., description="ID of the job to modify")
    tool_profile: Optional[str] = Field(None, description="New tool profile, e.g. 'dev', 'read_only'")
    backend: Optional[str] = Field(None, description="New backend: 'claude', 'codex', or 'gemini'")
    prompt: Optional[str] = Field(None, description="New prompt text")
    enabled: Optional[bool] = Field(None, description="Enable or disable the job")
    schedule_value: Optional[str] = Field(None, description="New schedule value")
    sessionful: Optional[bool] = Field(None, description="Enable or disable session persistence across runs")
    use_chat_session: Optional[bool] = Field(
        None, description="Enable or disable shared-chat-session mode for this job",
    )
    project_dir: Optional[str] = Field(None, description="New working directory, or empty string to reset to default.")
    autodev_config: Optional[Dict[str, Any]] = Field(None, description="Updated autodev pipeline config (only for autodev jobs). Prompt is rebuilt from this.")


class EnableDisableDeleteJobPayload(BaseModel):
    job_id: int


class WriteMemoryPayload(BaseModel):
    topic: str = Field(..., description="Topic file name in memory/topics (without .md)")
    content_md: str = Field(..., description="Markdown content to write/append")
    mode: Literal["append", "replace"] = "append"


class AppendDailyLogPayload(BaseModel):
    date: str = Field(..., description="YYYY-MM-DD")
    content_md: str = Field(..., description="Markdown to append to that day's log")


class SetToolProfilePayload(BaseModel):
    chat_id: int
    tool_profile: str


class SetProjectDirPayload(BaseModel):
    chat_id: int
    project_dir: Optional[str] = Field(
        None, description="Absolute path to project directory. null resets to default."
    )


class SetBackendPayload(BaseModel):
    chat_id: int
    backend: str = Field(..., description="'claude', 'codex', or 'gemini'")


class WriteSkillPayload(BaseModel):
    name: str = Field(..., description="Skill name (alphanumeric, dashes, underscores)")
    content_md: str = Field(..., description="Full SKILL.md content (markdown with optional YAML frontmatter)")
    scope: str = Field("agent", description="'agent' (per-agent, default) or 'global' (shared across all agents)")


class ToggleSkillPayload(BaseModel):
    name: str = Field(..., description="Skill name to enable or disable")


class CreateGoalPayload(BaseModel):
    goal: str = Field(..., description="Goal objective text")
    slug: Optional[str] = Field(None, description="Optional workspace slug (directory name)")
    external: Optional[List[str]] = Field(None, description="External repo paths to link")


class PreLaunchPayload(BaseModel):
    command: str = Field(..., description="Command to run")
    args: Optional[List[str]] = Field(None, description="Command arguments (use <runtime> for runtime dir)")
    port: Optional[int] = Field(None, description="Port to wait for readiness")
    find_executable: Optional[str] = Field(None, description="Executable hint (e.g. 'chrome') for auto-discovery")
    env: Optional[Dict[str, str]] = Field(None, description="Environment variables")


class RegisterMCPServerPayload(BaseModel):
    name: str = Field(..., description="Server name (alphanumeric, dashes, underscores)")
    description: str = Field("", description="What this MCP server does")
    type: str = Field(..., description="'stdio', 'http', or 'sse'")
    command: Optional[str] = Field(None, description="Command to run (stdio or managed http servers)")
    args: Optional[List[str]] = Field(None, description="Command arguments")
    env: Optional[Dict[str, str]] = Field(None, description="Environment variables")
    url: Optional[str] = Field(None, description="Server URL (remote http/sse servers)")
    headers: Optional[Dict[str, str]] = Field(None, description="HTTP headers (http/sse servers)")
    enabled: bool = Field(True, description="Whether the server is enabled")
    port: Optional[int] = Field(None, description="Port for gateway-managed HTTP servers (requires command)")
    pre_launch: Optional[PreLaunchPayload] = Field(None, description="Background process dependency managed by the gateway")


class RemoveMCPServerPayload(BaseModel):
    name: str = Field(..., description="Server name to remove")


class SetupAutonomousDevPayload(BaseModel):
    project_id: str = Field(..., description="Kanban project ID")
    project_dir: str = Field(..., description="Absolute path to the project repository")
    schedule_type: JobScheduleType = Field(
        JobScheduleType.gapped,
        description="Schedule type: 'gapped' (recommended) or 'interval'",
    )
    schedule_value: str = Field(
        '{"minutes":30}',
        description='Gap/interval duration as JSON, e.g. {"minutes":30}',
    )
    job_name: Optional[str] = Field(
        None,
        description="Job name. Defaults to 'kanban_autodev_{project_id[:8]}'",
    )
    backend: Optional[str] = Field(
        None,
        description="Backend: 'claude', 'codex', or 'gemini'. Inherits from chat if not set.",
    )
    active_start: Optional[str] = Field(None, description="Active window start HH:MM")
    active_end: Optional[str] = Field(None, description="Active window end HH:MM")
    kanban_base_url: str = Field(
        "http://kanbanboard.local:3000",
        description="Kanban API base URL",
    )
    # Pipeline configuration
    evolve_methods: List[str] = Field(
        default_factory=lambda: ["unified"],
        description='Evolve methods, e.g. ["unified"] or ["hierarchy","codebase"]',
    )
    sync_status: bool = Field(True, description="Sync project status before pipeline run")
    include_project_evolve: bool = Field(False, description="Include project-level evolve")
    max_depth: int = Field(3, description="Max codebase exploration depth")
    max_new_tasks: int = Field(15, description="Max new tasks per pipeline run")
    max_milestone_tasks: int = Field(50, description="Max tasks per milestone")
    ground_hierarchy_evolve: bool = Field(True, description="Validate tasks against codebase")
    codebase_evolve_goal: str = Field("", description="Optional focus goal for codebase evolve")
    milestone_creation_llm: bool = Field(False, description="Use LLM for milestone creation")
    milestone_creation_cli: bool = Field(True, description="Use CLI for repo-aware milestones")
    exclude_status: List[str] = Field(
        default_factory=lambda: ["done", "ideas", "review", "testing"],
        description="Task statuses to exclude",
    )
    prefer_status: List[str] = Field(
        default_factory=lambda: ["in_progress", "todo"],
        description="Task statuses to prioritize",
    )
    max_candidates: int = Field(40, description="Max candidate tasks to consider")
    use_project_manager: bool = Field(False, description="Include Project Manager chat instructions in the prompt")
    include_pipeline_run: bool = Field(
        True,
        description="Include the autonomous pipeline step that generates new tasks when none are available. When false, just reports no tasks and stops.",
    )
    custom_instructions: Optional[str] = Field(None, description="Extra text appended to the generated prompt")


class Action(BaseModel):
    type: ActionType
    payload: Dict[str, Any]


class ResponseMeta(BaseModel):
    confidence: Optional[float] = Field(
        None, description="Optional confidence, 0..1"
    )
    notes: Optional[str] = Field(None, description="Internal notes, not shown unless debug")


class StructuredResponse(BaseModel):
    reply: str = Field(..., description="User-facing message (sent to Telegram unless mode=ingest)")
    actions: List[Action] = Field(default_factory=list, description="Actions for gateway to execute")
    meta: Optional[ResponseMeta] = None


def _model_json_schema(model_cls: type[BaseModel]) -> Dict[str, Any]:
    """
    Return a JSON Schema for a Pydantic model, supporting both Pydantic v1 and v2.
    """
    # Pydantic v2
    if hasattr(model_cls, "model_json_schema"):
        return model_cls.model_json_schema()  # type: ignore[attr-defined]
    # Pydantic v1
    if hasattr(model_cls, "schema"):
        return model_cls.schema()  # type: ignore[attr-defined]
    raise RuntimeError("Unsupported pydantic version; cannot generate JSON schema")


def structured_response_json_schema_dict() -> Dict[str, Any]:
    """
    A strict JSON schema suitable for Claude Code `--json-schema`.
    We rely on Pydantic's schema generation for correctness.
    """
    return _model_json_schema(StructuredResponse)


def structured_response_json_schema_str(minified: bool = True) -> str:
    """
    Returns JSON schema string for `--json-schema`.

    Minified is recommended because passing multi-line JSON through shells is painful.
    """
    schema = structured_response_json_schema_dict()
    if orjson is not None:
        opt = 0
        if minified:
            return orjson.dumps(schema, option=opt).decode("utf-8")
        return json.dumps(schema, ensure_ascii=False, indent=2)
    if minified:
        return json.dumps(schema, ensure_ascii=False, separators=(",", ":"))
    return json.dumps(schema, ensure_ascii=False, indent=2)


def parse_structured_response(obj: Any) -> StructuredResponse:
    """
    Parse structured output returned by Claude Code.
    Claude Code may return:
      - {"structured_output": {...}} (when --json-schema used)
      - or a raw dict that matches our schema
    """
    if isinstance(obj, dict) and "structured_output" in obj and isinstance(obj["structured_output"], dict):
        payload = obj["structured_output"]
    else:
        payload = obj
    # Pydantic v2 uses model_validate; v1 uses parse_obj
    if hasattr(StructuredResponse, "model_validate"):
        return StructuredResponse.model_validate(payload)  # type: ignore[attr-defined]
    return StructuredResponse.parse_obj(payload)  # type: ignore[attr-defined]
