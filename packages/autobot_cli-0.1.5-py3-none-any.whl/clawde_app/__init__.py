"""
clawde_app

OpenClaw-like agent gateway that uses Claude Code (`claude` CLI) as the runtime.
Telegram is sessionful (per chat) and cron jobs are stateless.

See `clawde_app/cli.py` for the entrypoint.
"""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.1.5"
