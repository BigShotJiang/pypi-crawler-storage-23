from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

from . import __version__
from .config import build_paths, discover_data_home
from .main import (
    doctor,
    init_repo,
    is_process_alive,
    read_pid,
    remove_pid,
    run_blocking,
    start_background,
    stop_process,
)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="autobot",
        description="AutoBot gateway — Claude Code CLI + Telegram + Cron",
    )
    p.add_argument(
        "--config",
        default=None,
        help="Path to config YAML (auto-detected if omitted)",
    )
    p.add_argument(
        "--data-dir",
        default=None,
        help="Data directory (overrides AUTOBOT_DATA_DIR env var)",
    )
    p.add_argument(
        "--log-level",
        default="INFO",
        help="Logging level: DEBUG, INFO, WARNING, ERROR (default: INFO)",
    )
    p.add_argument(
        "--version",
        action="store_true",
        help="Print version and exit",
    )

    sub = p.add_subparsers(dest="command")

    sub.add_parser("run", help="Run the gateway in the foreground")

    sub.add_parser("start", help="Start the gateway as a background process")

    stop_p = sub.add_parser("stop", help="Stop the running gateway")
    stop_p.add_argument(
        "--timeout",
        type=int,
        default=10,
        help="Seconds to wait for graceful shutdown before force-killing (default: 10)",
    )

    restart_p = sub.add_parser("restart", help="Restart the gateway (stop + start)")
    restart_p.add_argument(
        "--timeout",
        type=int,
        default=10,
        help="Seconds to wait for graceful shutdown before force-killing (default: 10)",
    )

    sub.add_parser("status", help="Show whether the gateway is running")

    mgr_p = sub.add_parser("manager", help="Run the process manager API (foreground)")
    mgr_p.add_argument(
        "--port",
        type=int,
        default=8421,
        help="Port for the manager API (default: 8421)",
    )

    sub.add_parser("doctor", help="Run environment checks (does not start the bot)")

    init_p = sub.add_parser("init", help="Interactive setup wizard")
    init_p.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing template files if they already exist.",
    )
    init_p.add_argument(
        "--non-interactive",
        action="store_true",
        help="Skip interactive prompts, create scaffolding with defaults only.",
    )

    return p


# ---------------------------------------------------------------------------
# Config path resolution
# ---------------------------------------------------------------------------

def _resolve_config_path(args: argparse.Namespace) -> Path:
    """Determine the config file path from CLI args / env / defaults."""
    data_dir = getattr(args, "data_dir", None)

    # 1. Explicit --config
    if args.config:
        return Path(args.config).expanduser()

    # 2. Derive from --data-dir
    if data_dir:
        d = Path(data_dir).expanduser()
        # Legacy layout: data/ subdir
        legacy = d / "data" / "config.yaml"
        if legacy.exists():
            return legacy
        return d / "config.yaml"

    # 3. Derive from AUTOBOT_DATA_DIR
    env_dir = os.environ.get("AUTOBOT_DATA_DIR")
    if env_dir:
        d = Path(env_dir).expanduser()
        legacy = d / "data" / "config.yaml"
        if legacy.exists():
            return legacy
        return d / "config.yaml"

    # 4. Legacy: cwd has data/config.yaml (dev repo)
    legacy_cwd = Path("data/config.yaml")
    if legacy_cwd.exists():
        return legacy_cwd

    # 5. Default data home
    default_home = Path.home() / ".autobot"
    return default_home / "config.yaml"


def _get_data_dir_override(args: argparse.Namespace) -> Path | None:
    """Extract the data-dir override from CLI args (or None)."""
    val = getattr(args, "data_dir", None)
    if val:
        return Path(val).expanduser()
    return None


def _get_paths(config_path: Path, data_dir_override: Path | None = None):
    """Build AppPaths from config path (without loading full config)."""
    return build_paths(config_path, data_dir_override=data_dir_override)


def _cmd_start(config_path: Path, log_level: str, data_dir_override: Path | None = None) -> int:
    paths = _get_paths(config_path, data_dir_override)

    # Check if already running
    pid = read_pid(paths)
    if pid is not None and is_process_alive(pid):
        print(f"autobot is already running (PID {pid}).")
        return 1

    # Clean up stale PID file
    if pid is not None:
        remove_pid(paths)

    pid = start_background(config_path, log_level)
    print(f"autobot started (PID {pid}).")

    # Wait briefly and verify it's still alive
    time.sleep(2)
    if is_process_alive(pid):
        print("Process is running.")
        return 0
    else:
        print("WARNING: Process exited immediately. Check runtime/logs/clawde.log for errors.")
        return 1


def _cmd_stop(config_path: Path, timeout: int, data_dir_override: Path | None = None) -> int:
    paths = _get_paths(config_path, data_dir_override)
    pid = read_pid(paths)

    if pid is None:
        print("autobot is not running (no PID file).")
        return 0

    if not is_process_alive(pid):
        print(f"autobot is not running (stale PID {pid}). Cleaning up.")
        remove_pid(paths)
        return 0

    print(f"Stopping autobot (PID {pid})…")
    stopped = stop_process(paths, timeout=timeout)
    if stopped:
        print("autobot stopped.")
        return 0
    else:
        print("Failed to stop autobot.")
        return 1


def _cmd_restart(config_path: Path, log_level: str, timeout: int, data_dir_override: Path | None = None) -> int:
    paths = _get_paths(config_path, data_dir_override)
    pid = read_pid(paths)

    if pid is not None and is_process_alive(pid):
        print(f"Stopping autobot (PID {pid})…")
        stop_process(paths, timeout=timeout)
        # Give Telegram polling a moment to release
        time.sleep(2)

    return _cmd_start(config_path, log_level, data_dir_override)


def _cmd_status(config_path: Path, data_dir_override: Path | None = None) -> int:
    paths = _get_paths(config_path, data_dir_override)
    pid = read_pid(paths)

    if pid is None:
        print("autobot is not running (no PID file).")
        return 1

    if is_process_alive(pid):
        print(f"autobot is running (PID {pid}).")
        return 0
    else:
        print(f"autobot is not running (stale PID {pid}).")
        remove_pid(paths)
        return 1


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.version:
        print(__version__)
        return 0

    config_path = _resolve_config_path(args)
    data_dir_override = _get_data_dir_override(args)

    # Load .env from data home (or fallback to cwd)
    try:
        from dotenv import load_dotenv
        data_home = discover_data_home(config_path, data_dir_override)
        env_file = data_home / ".env"
        if env_file.exists():
            load_dotenv(env_file)
        else:
            load_dotenv()  # cwd fallback (dev mode)
    except ImportError:
        pass

    # Default command
    cmd = args.command or "run"

    if cmd == "init":
        init_repo(
            config_path=config_path,
            force=bool(getattr(args, "force", False)),
            data_dir_override=data_dir_override,
            interactive=not bool(getattr(args, "non_interactive", False)),
        )
        return 0

    if cmd == "doctor":
        return doctor(
            config_path=config_path,
            log_level=str(args.log_level),
            data_dir_override=data_dir_override,
        )

    if cmd == "run":
        run_blocking(
            config_path=config_path,
            log_level=str(args.log_level),
            data_dir_override=data_dir_override,
        )
        return 0

    if cmd == "start":
        return _cmd_start(config_path, str(args.log_level), data_dir_override)

    if cmd == "stop":
        return _cmd_stop(config_path, timeout=int(getattr(args, "timeout", 10)), data_dir_override=data_dir_override)

    if cmd == "restart":
        return _cmd_restart(config_path, str(args.log_level), timeout=int(getattr(args, "timeout", 10)), data_dir_override=data_dir_override)

    if cmd == "status":
        return _cmd_status(config_path, data_dir_override)

    if cmd == "manager":
        from .manager import run_manager
        run_manager(config_path, str(args.log_level), port=int(getattr(args, "port", 8421)))
        return 0

    parser.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
