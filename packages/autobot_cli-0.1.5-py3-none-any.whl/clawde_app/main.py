from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import signal
import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

from .actions import ActionExecutor
from .agent_profile import resolve_agent, ensure_agent_scaffold
from .claude_runner import ClaudeRunner
from .codex_runner import CodexRunner
from .gemini_runner import GeminiRunner
from .config import AppConfig, AppPaths, ToolProfile, build_paths, load_config
from .context_builder import ContextBuilder
from .db import Database
from .memory_index import MemoryIndex
from .memory_retrieval import ensure_memory_scaffold
from .skills import ensure_skills_scaffold
from .scheduler_service import SchedulerService
from .telegram_service import TelegramService
from .utils import ensure_runtime_scaffold, get_logger, setup_logging, write_text_if_missing


# ---------------------------------------------------------------------------
# PID file helpers
# ---------------------------------------------------------------------------

def _pid_path(paths: AppPaths) -> Path:
    return paths.runtime_dir / "clawde.pid"


def write_pid(paths: AppPaths) -> None:
    """Write current process PID to runtime/clawde.pid."""
    pid_file = _pid_path(paths)
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(str(os.getpid()), encoding="utf-8")


def remove_pid(paths: AppPaths) -> None:
    """Remove PID file on shutdown."""
    try:
        _pid_path(paths).unlink(missing_ok=True)
    except Exception:
        pass


def read_pid(paths: AppPaths) -> Optional[int]:
    """Read PID from file. Returns None if missing or invalid."""
    pid_file = _pid_path(paths)
    if not pid_file.exists():
        return None
    try:
        return int(pid_file.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return None


def is_process_alive(pid: int) -> bool:
    """Check if a process with the given PID is running."""
    if sys.platform == "win32":
        # On Windows, use tasklist to check
        try:
            r = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/NH", "/FO", "CSV"],
                capture_output=True, text=True, timeout=5,
            )
            # tasklist returns the process line if found
            return str(pid) in r.stdout
        except Exception:
            return False
    else:
        # On Unix, send signal 0 (no-op, just checks existence)
        try:
            os.kill(pid, 0)
            return True
        except (ProcessLookupError, PermissionError):
            return False


def stop_process(paths: AppPaths, timeout: int = 10) -> bool:
    """
    Stop the running clawde process.
    Returns True if process was stopped, False if not running.
    """
    pid = read_pid(paths)
    if pid is None:
        return False

    if not is_process_alive(pid):
        remove_pid(paths)
        return False

    # Stop managed MCP servers first (the gateway process may not run
    # its async shutdown handler, especially on Windows where signal
    # handlers are not supported in asyncio).
    try:
        from .mcp_manager import stop_mcp_servers
        stopped = stop_mcp_servers(paths)
        if stopped:
            _log = logging.getLogger("clawde")
            _log.info("Stopped managed MCP servers: %s", list(stopped.keys()))
    except Exception:
        pass

    if sys.platform == "win32":
        # On Windows, force-kill the entire process tree.
        # Graceful taskkill (WM_CLOSE) doesn't work for Python processes
        # since asyncio signal handlers aren't supported on Windows.
        try:
            subprocess.run(
                ["taskkill", "/T", "/F", "/PID", str(pid)],
                capture_output=True, timeout=5,
            )
        except Exception:
            pass
        import time
        for _ in range(timeout):
            if not is_process_alive(pid):
                break
            time.sleep(1)
    else:
        # Unix: SIGTERM then SIGKILL
        try:
            # Kill the full process group on Unix so spawned workers
            # (e.g. node/subprocess trees) are reaped with the parent.
            try:
                os.killpg(os.getpgid(pid), signal.SIGTERM)
            except Exception:
                os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            remove_pid(paths)
            return False

        import time
        for _ in range(timeout):
            if not is_process_alive(pid):
                remove_pid(paths)
                return True
            time.sleep(1)
        # Force kill
        try:
            try:
                os.killpg(os.getpgid(pid), signal.SIGKILL)
            except Exception:
                os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        time.sleep(1)

    remove_pid(paths)
    return True


def start_background(config_path: Path, log_level: str = "INFO") -> int:
    """
    Launch clawde as a detached background process.
    Returns the PID of the new process.
    """
    cmd = [
        sys.executable, "-m", "clawde_app.cli",
        "--config", str(config_path),
        "--log-level", log_level,
        "run",
    ]

    kwargs: dict = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "stdin": subprocess.DEVNULL,
    }

    if sys.platform == "win32":
        # Windows: CREATE_NEW_PROCESS_GROUP + DETACHED_PROCESS
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        DETACHED_PROCESS = 0x00000008
        kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    else:
        # Unix: start_new_session detaches from parent
        kwargs["start_new_session"] = True

    proc = subprocess.Popen(cmd, **kwargs)
    return proc.pid


def _parse_log_level(level: str) -> int:
    s = (level or "INFO").strip().upper()
    return getattr(logging, s, logging.INFO)


def _ensure_default_tool_profiles(cfg: AppConfig) -> None:
    """
    Provide sane defaults if tool_profiles are missing.
    This makes a minimal config usable immediately.
    """
    if cfg.claude.tool_profiles is None:
        cfg.claude.tool_profiles = {}

    # safe_chat: no tools at all
    cfg.claude.tool_profiles.setdefault("safe_chat", ToolProfile(tools="", allowed_tools=""))

    # read_only
    cfg.claude.tool_profiles.setdefault(
        "read_only",
        ToolProfile(
            tools="Read,Grep,Glob",
            allowed_tools="Read,Grep,Glob",
        ),
    )

    # dev (admin only)
    cfg.claude.tool_profiles.setdefault(
        "dev",
        ToolProfile(
            tools="Read,Edit,Bash,Grep,Glob",
            allowed_tools="Read,Edit,Grep,Glob,"
            "Bash(git status *),Bash(git diff *),Bash(pytest *),Bash(python *),Bash(pip *),Bash(uv *)",
        ),
    )


def _install_signal_handlers(stop_event: asyncio.Event) -> None:
    """
    Best-effort graceful shutdown handlers.
    On Windows, loop.add_signal_handler is not supported so we fall back
    to signal.signal() which schedules the stop via call_soon_threadsafe.
    """
    loop = asyncio.get_running_loop()

    def _request_stop() -> None:
        if not stop_event.is_set():
            stop_event.set()

    installed = False
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _request_stop)
            installed = True
        except NotImplementedError:
            pass
        except Exception:
            pass

    if not installed:
        # Windows fallback: signal.signal runs in the main thread,
        # so we use call_soon_threadsafe to set the event on the loop.
        def _win_handler(signum, frame):
            loop.call_soon_threadsafe(_request_stop)

        signal.signal(signal.SIGINT, _win_handler)
        try:
            signal.signal(signal.SIGTERM, _win_handler)
        except (OSError, ValueError):
            pass


async def _shutdown(
    *,
    log: logging.Logger,
    paths: Optional[AppPaths] = None,
    telegram_services: Optional[dict] = None,
    scheduler: Optional[SchedulerService] = None,
    db: Optional[Database] = None,
    memory_index: Optional[MemoryIndex] = None,
    watcher_task: Optional[asyncio.Task] = None,
) -> None:
    """
    Graceful shutdown sequence.
    """
    try:
        if scheduler is not None:
            log.info("Stopping scheduler…")
            await scheduler.shutdown()
    except Exception as e:
        log.warning("Scheduler shutdown error: %s", e)

    if telegram_services:
        for agent_name, ts in telegram_services.items():
            try:
                log.info("Stopping Telegram for agent '%s'…", agent_name)
                await ts.stop()
            except Exception as e:
                log.warning("Telegram shutdown error (agent=%s): %s", agent_name, e)

    # Stop memory file watcher and close index
    if watcher_task is not None:
        watcher_task.cancel()
        try:
            await watcher_task
        except (asyncio.CancelledError, Exception):
            pass
    if memory_index is not None:
        try:
            await memory_index.close()
        except Exception:
            pass

    # Stop managed MCP servers
    if paths is not None:
        try:
            from .mcp_manager import stop_mcp_servers
            stopped = stop_mcp_servers(paths)
            if stopped:
                log.info("Stopped managed MCP servers: %s", list(stopped.keys()))
        except Exception as e:
            log.warning("MCP server shutdown error: %s", e)

    try:
        if db is not None:
            log.info("Closing database…")
            await db.close()
    except Exception as e:
        log.warning("Database close error: %s", e)


async def run_async(
    config_path: Path,
    log_level: str = "INFO",
    data_dir_override: Path | None = None,
) -> None:
    """
    Main async runner: loads config, starts Telegram + Scheduler, waits until signalled to stop.
    """
    cfg, paths = load_config(config_path, data_dir_override=data_dir_override)
    _ensure_default_tool_profiles(cfg)

    ensure_runtime_scaffold(paths)
    ensure_memory_scaffold(paths)
    ensure_skills_scaffold(paths.skills_dir)
    setup_logging(paths, level=_parse_log_level(log_level))
    log = get_logger("clawde")

    # Write PID file so CLI can manage this process
    write_pid(paths)
    log.info("Starting clawde… (PID %d)", os.getpid())
    log.info("Repo root: %s", paths.repo_root)
    log.info("DB path: %s", paths.db_path)
    log.info("Agents: %s", list(cfg.agents.keys()))

    # Start managed MCP servers (before Telegram/scheduler so they are ready)
    from .mcp_sync import ensure_mcp_scaffold
    from .mcp_manager import start_mcp_servers

    ensure_mcp_scaffold(paths.mcp_servers_dir)
    mcp_results = await start_mcp_servers(paths)
    if mcp_results:
        started = [n for n, ok in mcp_results.items() if ok]
        failed = [n for n, ok in mcp_results.items() if not ok]
        if started:
            log.info("Managed MCP servers started: %s", started)
        if failed:
            log.warning("Managed MCP servers failed to start: %s", failed)

    db = Database(paths.db_path)
    await db.connect()

    claude = ClaudeRunner(cfg, paths)
    codex = CodexRunner(cfg, paths)
    gemini = GeminiRunner(cfg, paths)

    # Memory index for hybrid search (Phase 2)
    memory_index: Optional[MemoryIndex] = None
    watcher_task: Optional[asyncio.Task] = None
    if cfg.memory.retrieval.strategy == "hybrid":
        memory_index = MemoryIndex(paths.db_path, cfg)
        log.info("Hybrid memory search enabled (strategy=%s)", cfg.memory.retrieval.strategy)

    context_builder = ContextBuilder(cfg, paths, db, memory_index=memory_index)
    actions = ActionExecutor(cfg, paths, db, memory_index=memory_index)

    # Ensure agent directories exist
    for agent_name in cfg.agents:
        agent = resolve_agent(paths.agents_dir, agent_name)
        if agent:
            ensure_agent_scaffold(agent)

    # Background reindex + file watcher for hybrid memory search
    if memory_index is not None:
        async def _initial_reindex():
            try:
                # Index global memory
                n = await memory_index.reindex_agent("", paths.memory_dir)
                log.info("Memory index: %d chunks from global memory", n)
                # Index per-agent memory
                for agent_name in cfg.agents:
                    agent = resolve_agent(paths.agents_dir, agent_name)
                    if agent and agent.memory_dir.is_dir():
                        n = await memory_index.reindex_agent(agent_name, agent.memory_dir)
                        log.info("Memory index: %d chunks from agent '%s'", n, agent_name)
            except Exception:
                log.error("Initial memory reindex failed", exc_info=True)

        asyncio.create_task(_initial_reindex())

        # File watcher for memory dirs
        watch_dirs: list[tuple[str, Path]] = [("", paths.memory_dir)]
        for agent_name in cfg.agents:
            agent = resolve_agent(paths.agents_dir, agent_name)
            if agent:
                watch_dirs.append((agent_name, agent.memory_dir))
        watcher_task = asyncio.create_task(memory_index.start_watcher(watch_dirs))

    # Create a TelegramService for each agent
    telegram_services: dict[str, TelegramService] = {}
    for agent_name, agent_cfg in cfg.agents.items():
        ts = TelegramService(
            cfg, paths, db, claude, codex, gemini,
            context_builder, actions,
            agent_name=agent_name,
            agent_cfg=agent_cfg,
        )
        telegram_services[agent_name] = ts

    # Single scheduler shared across all agents
    scheduler = SchedulerService(
        cfg, paths, db, claude, codex, gemini,
        context_builder, actions,
        telegram_services=telegram_services,
    )

    # Wire back-references so each TelegramService can reload jobs
    for ts in telegram_services.values():
        ts.scheduler_service = scheduler

    stop_event = asyncio.Event()
    _install_signal_handlers(stop_event)

    try:
        await scheduler.start()
        for agent_name, ts in telegram_services.items():
            await ts.start()
            log.info("Agent '%s' started (polling Telegram).", agent_name)

        # Start web dashboard
        if cfg.web.enabled:
            import uvicorn
            from .web.app import create_app

            web_app = create_app(
                cfg, paths, db, scheduler,
                telegram_services, context_builder, actions,
            )
            web_config = uvicorn.Config(
                web_app,
                host=cfg.web.host,
                port=cfg.web.port,
                log_level="warning",
            )
            web_server = uvicorn.Server(web_config)
            asyncio.create_task(web_server.serve())
            log.info("Web dashboard: http://%s:%d", cfg.web.host, cfg.web.port)

        log.info(
            "clawde is running (%d agent(s), scheduler active). Press Ctrl+C to stop.",
            len(telegram_services),
        )
        await stop_event.wait()

    finally:
        await _shutdown(
            log=log,
            paths=paths,
            telegram_services=telegram_services,
            scheduler=scheduler,
            db=db,
            memory_index=memory_index,
            watcher_task=watcher_task,
        )
        remove_pid(paths)
        log.info("clawde stopped.")


def run_blocking(
    config_path: Path,
    log_level: str = "INFO",
    data_dir_override: Path | None = None,
) -> None:
    """
    Blocking entrypoint for CLI. Handles KeyboardInterrupt cleanly.
    """
    try:
        asyncio.run(run_async(
            config_path=config_path,
            log_level=log_level,
            data_dir_override=data_dir_override,
        ))
    except KeyboardInterrupt:
        # asyncio.run already tries to cancel tasks, but on Windows the
        # KeyboardInterrupt can abort _shutdown() before MCP cleanup finishes.
        # Do a synchronous fallback cleanup for pre-launch processes (e.g. Chrome).
        try:
            from .mcp_manager import stop_pre_launch_processes
            _, paths = load_config(config_path, data_dir_override=data_dir_override)
            stop_pre_launch_processes(paths)
        except Exception:
            pass


# ----------------------------
# init + doctor helpers
# ----------------------------
def init_repo(
    config_path: Path,
    force: bool = False,
    data_dir_override: Path | None = None,
    interactive: bool = True,
) -> None:
    """
    Create directories and sample files to get started quickly.

    When *interactive* is True and stdout is a tty, runs the setup wizard
    (prompts for bot token + chat ID).  Otherwise falls back to writing a
    sample config that the user can edit by hand.
    """
    # We can derive paths even if config doesn't exist.
    paths = build_paths(config_path, data_dir_override=data_dir_override)

    if interactive and sys.stdin.isatty() and not config_path.exists():
        # Run the interactive wizard
        from .wizard import run_wizard
        run_wizard(data_home=paths.data_home, config_path=config_path, paths=paths, force=force)
        return

    # Non-interactive fallback: scaffold + sample config
    _init_scaffold(config_path, paths, force)


def _init_scaffold(config_path: Path, paths, force: bool = False) -> None:
    """Non-interactive scaffolding (sample config + directory structure)."""
    ensure_runtime_scaffold(paths)
    ensure_memory_scaffold(paths)
    ensure_skills_scaffold(paths.skills_dir)

    # Create data dir
    paths.data_dir.mkdir(parents=True, exist_ok=True)

    # Sample config
    sample_cfg = """# autobot config (sample)

# Each agent is a separate Telegram bot. Get a token from @BotFather.
agents:
  clawde:
    bot_token: "PASTE_YOUR_TELEGRAM_BOT_TOKEN_HERE"
    default_backend: "claude"
    allowed_chat_ids: []
    admin_chat_ids: []
    respond_in_groups: false
    require_mention_in_groups: true
    max_reply_chars: 3500
    send_long_as_file: true

claude:
  executable: "claude"
  model: null
  max_turns_telegram: null
  max_turns_cron: null
  max_turns_ingest: 1
  output_format: "stream-json"
  tool_profiles:
    safe_chat:
      tools: ""
      allowed_tools: ""
    read_only:
      tools: "Read,Grep,Glob"
      allowed_tools: "Read,Grep,Glob"
    dev:
      tools: "Read,Edit,Bash,Grep,Glob"
      allowed_tools: "Read,Edit,Grep,Glob,Bash(git status *),Bash(git diff *),Bash(pytest *),Bash(python *),Bash(pip *),Bash(uv *)"

memory:
  daily_include_days: 2
  retrieval:
    strategy: "keyword"
    max_snippets: 6
    max_chars_per_snippet: 1500
    keyword_min_hits: 1

scheduler:
  timezone: "Europe/London"
  misfire_grace_seconds: 120
  coalesce: true
  max_concurrent_jobs: 2

security:
  secrets_path_globs:
    - "data/*"
    - ".env"
    - "**/*.key"
    - "**/id_rsa*"
    - "**/*token*"
  deny_bash_patterns:
    - "rm -rf"
    - "del /s"
    - "format "
    - "shutdown"
"""
    if force or not config_path.exists():
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(sample_cfg, encoding="utf-8")
        print(f"[OK] Wrote sample config to: {config_path}")
    else:
        print(f"[INFO] Config already exists: {config_path} (use --force to overwrite)")

    # Copy bundled assets (rules, hooks, CLAUDE.md, settings.json)
    from .wizard import copy_bundled_assets
    copy_bundled_assets(paths.data_home, force=force)

    # Sentinel
    sentinel = paths.data_home / ".autobot-root"
    if not sentinel.exists():
        sentinel.write_text("", encoding="utf-8")

    print("[OK] Initialized.")
    print("Next steps:")
    print(f"1) Edit {config_path} — paste your Telegram bot token (get one from @BotFather)")
    print("2) Add your Telegram chat ID to admin_chat_ids (send /start to @userinfobot to find it)")
    print("3) Run: autobot run")


def doctor(
    config_path: Path,
    log_level: str = "INFO",
    data_dir_override: Path | None = None,
) -> int:
    """
    Environment checks. Returns shell-style exit code.
    """
    ok = True
    print("autobot doctor\n==============")

    # Python
    print(f"- Python: {sys.version.split()[0]}")
    if sys.version_info < (3, 11):
        print("  [WARN] Recommended: Python 3.11+")
        ok = False

    # Config
    try:
        cfg, paths = load_config(config_path, data_dir_override=data_dir_override)
        _ensure_default_tool_profiles(cfg)
        ensure_runtime_scaffold(paths)
        ensure_memory_scaffold(paths)
        ensure_skills_scaffold(paths.skills_dir)
        print(f"- Config: OK ({config_path})")
        print(f"- Data home: {paths.data_home}")
        print(f"- DB path: {paths.db_path}")
    except Exception as e:
        print(f"- Config: FAIL - {e}")
        return 2

    # Claude CLI
    exe = cfg.claude.executable
    try:
        r = subprocess.run(
            [exe, "--version"],
            capture_output=True,
            text=True,
            timeout=5,
            cwd=str(paths.data_home),
        )
        if r.returncode != 0:
            print(f"- Claude CLI: FAIL - exit={r.returncode} stderr={r.stderr.strip()[:200]}")
            ok = False
        else:
            out = (r.stdout or r.stderr or "").strip()
            print(f"- Claude CLI: OK ({out[:120]})")
    except FileNotFoundError:
        print(f"- Claude CLI: FAIL - executable not found: {exe}")
        ok = False
    except Exception as e:
        print(f"- Claude CLI: FAIL - {e}")
        ok = False

    # Node / npx (needed for managed MCP servers via supergateway)
    if shutil.which("npx"):
        print("- npx: OK")
    else:
        print("- npx: [WARN] not found (needed for managed MCP servers)")

    # Kanban Dashboard (optional — only check if MCP config is enabled)
    kanban_cfg_path = paths.mcp_servers_dir / "kanban.json"
    if kanban_cfg_path.exists():
        try:
            kanban_raw = json.loads(kanban_cfg_path.read_text(encoding="utf-8"))
        except Exception:
            kanban_raw = {}
        if kanban_raw.get("enabled", True):
            kanban_url = (kanban_raw.get("env") or {}).get(
                "KANBAN_BASE_URL", "http://kanbanboard.local:3000"
            )
            try:
                import urllib.request
                req = urllib.request.Request(f"{kanban_url}/api/health", method="GET")
                with urllib.request.urlopen(req, timeout=5) as resp:
                    print(f"- Kanban Dashboard: OK ({kanban_url})")
            except Exception:
                print(f"- Kanban Dashboard: [WARN] not reachable at {kanban_url}")

    # Agent tokens
    if not cfg.agents:
        print("- Agents: [WARN] no agents configured")
        ok = False
    for agent_name, agent_cfg in cfg.agents.items():
        token = agent_cfg.bot_token.get_secret_value()
        if token and "PASTE" not in token.upper():
            print(f"- Agent '{agent_name}' token: OK")
        else:
            print(f"- Agent '{agent_name}' token: [WARN] not set")
            ok = False

    return 0 if ok else 1
