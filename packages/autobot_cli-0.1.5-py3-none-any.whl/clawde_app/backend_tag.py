"""Inline backend override tag detection and stripping.

Supports ``@backend-claude``, ``@backend-codex``, ``@backend-gemini``
anywhere in message text.  First match determines the backend; all
occurrences are stripped and whitespace is normalised.
"""
from __future__ import annotations

import re
from typing import Optional, Tuple

_BACKEND_TAG_RE = re.compile(r"@backend-(claude|codex|gemini)", re.IGNORECASE)

VALID_BACKENDS = ("claude", "codex", "gemini")


def extract_backend_tag(text: str) -> Tuple[Optional[str], str]:
    """Extract backend override and return ``(backend, cleaned_text)``.

    Returns ``(None, original_text)`` if no tag is found.
    First match determines backend; **all** occurrences are stripped.
    """
    m = _BACKEND_TAG_RE.search(text)
    if not m:
        return None, text
    backend = m.group(1).lower()
    cleaned = _BACKEND_TAG_RE.sub("", text)
    cleaned = re.sub(r"  +", " ", cleaned).strip()
    return backend, cleaned


def strip_backend_tags(text: str) -> str:
    """Strip all ``@backend-X`` tags from *text* (for storage/memory)."""
    cleaned = _BACKEND_TAG_RE.sub("", text)
    return re.sub(r"  +", " ", cleaned).strip()
