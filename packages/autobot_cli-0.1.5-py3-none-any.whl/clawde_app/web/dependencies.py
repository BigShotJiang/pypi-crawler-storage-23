"""FastAPI dependency injection — pulls shared singletons from app.state."""
from __future__ import annotations

from fastapi import Request

from ..config import AppConfig, AppPaths
from ..db import Database


def get_db(request: Request) -> Database:
    return request.app.state.db


def get_cfg(request: Request) -> AppConfig:
    return request.app.state.cfg


def get_paths(request: Request) -> AppPaths:
    return request.app.state.paths


def get_scheduler(request: Request):
    return request.app.state.scheduler


def get_telegram_services(request: Request) -> dict:
    return request.app.state.telegram_services
