"""Run history and detail endpoints."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from ..dependencies import get_db, get_paths, get_telegram_services

router = APIRouter()


@router.get("")
async def list_runs(
    agent_name: Optional[str] = Query(None),
    mode: Optional[str] = Query(None),
    date_from: Optional[str] = Query(None),
    date_to: Optional[str] = Query(None),
    chat_id: Optional[int] = Query(None),
    job_id: Optional[int] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db=Depends(get_db),
):
    rows, total = await db.get_runs_filtered(
        agent_name=agent_name,
        mode=mode,
        date_from=date_from,
        date_to=date_to,
        chat_id=chat_id,
        job_id=job_id,
        limit=limit,
        offset=offset,
    )
    return {"items": rows, "total": total, "limit": limit, "offset": offset}


@router.get("/active")
async def active_runs(telegram_services=Depends(get_telegram_services)):
    result = []
    for agent_name, ts in telegram_services.items():
        for chat_id, active in getattr(ts, "_active_runs", {}).items():
            result.append({
                "agent_name": agent_name,
                "chat_id": chat_id,
                "run_id": getattr(active, "run_id", None),
                "backend": getattr(active, "backend", None),
                "cancelled": getattr(active, "cancelled", False),
            })
    return result


@router.get("/{run_id}")
async def get_run(run_id: str, db=Depends(get_db)):
    run = await db.get_run(run_id)
    if not run:
        raise HTTPException(404, "Run not found")
    return run


@router.get("/{run_id}/log")
async def get_run_log(run_id: str, db=Depends(get_db), paths=Depends(get_paths)):
    """Read and return parsed log lines for a run."""
    run = await db.get_run(run_id)
    if not run:
        raise HTTPException(404, "Run not found")

    log_file = run.get("log_file")
    if not log_file:
        raise HTTPException(404, "No log file recorded for this run")

    log_path = Path(log_file)
    if not log_path.exists():
        raise HTTPException(404, f"Log file not found: {log_file}")

    lines = []
    try:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                lines.append(line.rstrip("\n"))
    except Exception as e:
        raise HTTPException(500, f"Error reading log: {e}")

    return {"run_id": run_id, "log_file": log_file, "lines": lines, "line_count": len(lines)}
