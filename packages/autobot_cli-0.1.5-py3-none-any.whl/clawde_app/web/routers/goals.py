"""Goals dashboard endpoints."""
from __future__ import annotations

import json
import re
import shutil
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from ..dependencies import get_paths, get_cfg

router = APIRouter()


def _validate_slug(slug: str) -> str | None:
    if not slug or not re.match(r'^[a-z0-9][a-z0-9_-]*$', slug):
        return "Slug must be lowercase alphanumeric with hyphens/underscores, starting with alphanumeric"
    if len(slug) > 64:
        return "Slug too long (max 64 chars)"
    return None


def _load_registry(registry_path) -> dict:
    if not registry_path.exists():
        return {"workspaces": {}}
    try:
        return json.loads(registry_path.read_text(encoding="utf-8"))
    except Exception:
        return {"workspaces": {}}


def _save_registry(registry_path, reg: dict):
    registry_path.parent.mkdir(parents=True, exist_ok=True)
    registry_path.write_text(json.dumps(reg, indent=2), encoding="utf-8")


@router.get("/{agent_name}")
async def list_goals(agent_name: str, paths=Depends(get_paths), cfg=Depends(get_cfg)):
    if agent_name not in cfg.agents:
        raise HTTPException(404, "Agent not found")

    registry_path = paths.agents_dir / agent_name / "goals" / "REGISTRY.json"
    reg = _load_registry(registry_path)

    goals = []
    for slug, info in reg.get("workspaces", {}).items():
        goals.append({
            "slug": slug,
            "goal": info.get("goal", ""),
            "created_at": info.get("created_at", ""),
            "workspace_dir": info.get("workspace_dir", ""),
        })
    return {"agent": agent_name, "goals": goals}


@router.get("/{agent_name}/{slug}/files")
async def get_goal_files(agent_name: str, slug: str, paths=Depends(get_paths), cfg=Depends(get_cfg)):
    if agent_name not in cfg.agents:
        raise HTTPException(404, "Agent not found")

    workspace_dir = paths.agents_dir / agent_name / "goals" / slug
    if not workspace_dir.is_dir():
        raise HTTPException(404, "Goal workspace not found")

    files = {}
    for fname in ("STATUS.md", "NEXT_ACTIONS.md", "METRICS.md", "GOAL.md"):
        fpath = workspace_dir / "status" / fname
        if not fpath.exists():
            fpath = workspace_dir / fname
        if fpath.exists():
            files[fname] = fpath.read_text(encoding="utf-8", errors="replace")

    return {"agent": agent_name, "slug": slug, "files": files}


class GoalCreate(BaseModel):
    slug: str
    goal: str


@router.post("/{agent_name}")
async def create_goal(agent_name: str, body: GoalCreate, paths=Depends(get_paths), cfg=Depends(get_cfg)):
    if agent_name not in cfg.agents:
        raise HTTPException(404, "Agent not found")

    err = _validate_slug(body.slug)
    if err:
        raise HTTPException(400, err)

    goals_dir = paths.agents_dir / agent_name / "goals"
    registry_path = goals_dir / "REGISTRY.json"
    workspace_dir = goals_dir / body.slug

    if workspace_dir.exists():
        raise HTTPException(409, f"Goal '{body.slug}' already exists")

    # Create workspace directory with standard files
    status_dir = workspace_dir / "status"
    status_dir.mkdir(parents=True, exist_ok=True)

    now = datetime.now(timezone.utc).isoformat()

    (status_dir / "GOAL.md").write_text(f"# {body.slug}\n\n{body.goal}\n", encoding="utf-8")
    (status_dir / "STATUS.md").write_text("# Status\n\nJust created.\n", encoding="utf-8")
    (status_dir / "NEXT_ACTIONS.md").write_text("# Next Actions\n\n- Define next steps\n", encoding="utf-8")
    (status_dir / "METRICS.md").write_text("# Metrics\n\nNo metrics yet.\n", encoding="utf-8")

    # Update REGISTRY.json
    reg = _load_registry(registry_path)
    reg.setdefault("workspaces", {})[body.slug] = {
        "goal": body.goal,
        "created_at": now,
        "workspace_dir": str(workspace_dir),
    }
    _save_registry(registry_path, reg)

    return {"ok": True, "slug": body.slug}


@router.put("/{agent_name}/{slug}/files/{filename}")
async def update_goal_file(
    agent_name: str, slug: str, filename: str,
    body: dict,
    paths=Depends(get_paths), cfg=Depends(get_cfg),
):
    if agent_name not in cfg.agents:
        raise HTTPException(404, "Agent not found")

    allowed_files = {"GOAL.md", "STATUS.md", "NEXT_ACTIONS.md", "METRICS.md"}
    if filename not in allowed_files:
        raise HTTPException(400, f"Invalid filename. Allowed: {', '.join(sorted(allowed_files))}")

    workspace_dir = paths.agents_dir / agent_name / "goals" / slug
    if not workspace_dir.is_dir():
        raise HTTPException(404, "Goal workspace not found")

    content = body.get("content", "")

    # Try status/ subdir first (where files are created), fall back to root
    fpath = workspace_dir / "status" / filename
    if not fpath.exists():
        fpath_root = workspace_dir / filename
        if fpath_root.exists():
            fpath = fpath_root
        # else write to status/ (default location)

    fpath.write_text(content, encoding="utf-8")

    # If updating GOAL.md, also update the goal text in REGISTRY
    if filename == "GOAL.md":
        goals_dir = paths.agents_dir / agent_name / "goals"
        registry_path = goals_dir / "REGISTRY.json"
        reg = _load_registry(registry_path)
        if slug in reg.get("workspaces", {}):
            # Extract first non-heading paragraph as goal summary
            lines = content.strip().split("\n")
            goal_text = ""
            for line in lines:
                stripped = line.strip()
                if stripped and not stripped.startswith("#"):
                    goal_text = stripped
                    break
            reg["workspaces"][slug]["goal"] = goal_text
            _save_registry(registry_path, reg)

    return {"ok": True}


@router.delete("/{agent_name}/{slug}")
async def delete_goal(agent_name: str, slug: str, paths=Depends(get_paths), cfg=Depends(get_cfg)):
    if agent_name not in cfg.agents:
        raise HTTPException(404, "Agent not found")

    goals_dir = paths.agents_dir / agent_name / "goals"
    workspace_dir = goals_dir / slug

    if not workspace_dir.is_dir():
        raise HTTPException(404, "Goal workspace not found")

    # Remove workspace directory
    shutil.rmtree(workspace_dir)

    # Remove from REGISTRY.json
    registry_path = goals_dir / "REGISTRY.json"
    reg = _load_registry(registry_path)
    reg.get("workspaces", {}).pop(slug, None)
    _save_registry(registry_path, reg)

    return {"ok": True}
