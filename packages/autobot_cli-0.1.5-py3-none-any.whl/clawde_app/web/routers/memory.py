"""Memory file explorer endpoints."""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from ..dependencies import get_paths, get_cfg

router = APIRouter()


def _build_tree(base_path: Path, prefix: str = "") -> list:
    """Recursively build a file tree."""
    items = []
    if not base_path.is_dir():
        return items
    for entry in sorted(base_path.iterdir()):
        rel = f"{prefix}/{entry.name}" if prefix else entry.name
        if entry.name.startswith("__"):
            continue
        if entry.is_dir():
            items.append({
                "name": entry.name,
                "path": rel,
                "type": "directory",
                "children": _build_tree(entry, rel),
            })
        elif entry.suffix in (".md", ".txt", ".json", ".yaml", ".yml"):
            items.append({
                "name": entry.name,
                "path": rel,
                "type": "file",
            })
    return items


def _validate_memory_path(paths, rel_path: str) -> Path:
    """Resolve and validate that a path is within allowed memory directories."""
    repo = paths.repo_root
    resolved = (repo / rel_path).resolve()

    # Must be under memory/ or agents/*/memory/
    memory_root = paths.memory_dir.resolve()
    agents_root = paths.agents_dir.resolve()

    if str(resolved).startswith(str(memory_root)):
        return resolved
    if str(resolved).startswith(str(agents_root)):
        # Check it's under a memory subdirectory
        rel_to_agents = resolved.relative_to(agents_root)
        parts = rel_to_agents.parts
        if len(parts) >= 2 and parts[1] == "memory":
            return resolved
    raise HTTPException(403, "Path not allowed — must be under memory/ or agents/*/memory/")


@router.get("/tree")
async def memory_tree(paths=Depends(get_paths), cfg=Depends(get_cfg)):
    tree = []
    # Global memory
    tree.append({
        "name": "memory",
        "path": "memory",
        "type": "directory",
        "children": _build_tree(paths.memory_dir, "memory"),
    })
    # Per-agent memory
    for agent_name in cfg.agents:
        agent_mem = paths.agents_dir / agent_name / "memory"
        if agent_mem.is_dir():
            prefix = f"agents/{agent_name}/memory"
            tree.append({
                "name": f"{agent_name} memory",
                "path": prefix,
                "type": "directory",
                "children": _build_tree(agent_mem, prefix),
            })
    return tree


@router.get("/file")
async def read_memory_file(path: str = Query(...), paths=Depends(get_paths)):
    resolved = _validate_memory_path(paths, path)
    if not resolved.exists():
        raise HTTPException(404, "File not found")
    content = resolved.read_text(encoding="utf-8", errors="replace")
    return {"path": path, "content": content}


class MemoryFileUpdate(BaseModel):
    path: str
    content: str


@router.put("/file")
async def write_memory_file(body: MemoryFileUpdate, paths=Depends(get_paths)):
    resolved = _validate_memory_path(paths, body.path)
    resolved.parent.mkdir(parents=True, exist_ok=True)
    resolved.write_text(body.content, encoding="utf-8")
    return {"ok": True, "path": body.path}


@router.delete("/file")
async def delete_memory_file(path: str = Query(...), paths=Depends(get_paths)):
    resolved = _validate_memory_path(paths, path)
    if not resolved.exists():
        raise HTTPException(404, "File not found")
    resolved.unlink()
    return {"ok": True}
