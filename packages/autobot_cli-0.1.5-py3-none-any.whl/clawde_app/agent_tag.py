"""Inline agent override tag detection and stripping.

Supports ``@agent-<name>`` anywhere in message text (case-insensitive).
First match determines the agent; all occurrences are stripped and
whitespace is normalised.
"""
from __future__ import annotations

import re
from typing import Optional, Tuple

_AGENT_TAG_RE = re.compile(r"@agent-(\w+)", re.IGNORECASE)


def extract_agent_tag(text: str) -> Tuple[Optional[str], str]:
    """Extract agent override and return ``(agent_name, cleaned_text)``.

    Returns ``(None, original_text)`` if no tag is found.
    First match determines agent; **all** occurrences are stripped.
    """
    m = _AGENT_TAG_RE.search(text)
    if not m:
        return None, text
    agent = m.group(1).lower()
    cleaned = _AGENT_TAG_RE.sub("", text)
    cleaned = re.sub(r"  +", " ", cleaned).strip()
    return agent, cleaned


def strip_agent_tags(text: str) -> str:
    """Strip all ``@agent-X`` tags from *text*."""
    cleaned = _AGENT_TAG_RE.sub("", text)
    return re.sub(r"  +", " ", cleaned).strip()
