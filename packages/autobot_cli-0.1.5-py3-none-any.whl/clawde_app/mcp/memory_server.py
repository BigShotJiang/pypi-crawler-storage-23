"""
MCP server exposing memory_search and memory_get tools.

Spawned by Claude CLI as a stdio MCP server. Agent env vars
(CLAWDE_REPO_ROOT, CLAWDE_AGENT_NAME) are injected by the gateway
via mcp_sync before each run.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Optional

# Load .env before reading env vars (this process is spawned by Claude CLI)
try:
    from dotenv import load_dotenv
    # Walk up to find repo root .env
    _this_dir = Path(__file__).resolve().parent
    for _p in [_this_dir.parents[1], _this_dir.parents[0], Path.cwd()]:
        if (_p / ".env").exists():
            load_dotenv(_p / ".env")
            break
except ImportError:
    pass

from mcp.server.fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Bootstrap paths from environment
# ---------------------------------------------------------------------------

_REPO_ROOT = Path(os.environ.get("CLAWDE_REPO_ROOT", "")).resolve()
_AGENT_NAME = os.environ.get("CLAWDE_AGENT_NAME", "")

if not _REPO_ROOT.is_dir():
    # Fallback: discover repo root from this file's location
    _REPO_ROOT = Path(__file__).resolve().parents[2]


def _memory_dirs() -> tuple[Path, Path, Path]:
    """Return (memory_dir, topics_dir, daily_dir) for the current agent."""
    if _AGENT_NAME:
        base = _REPO_ROOT / "agents" / _AGENT_NAME / "memory"
    else:
        base = _REPO_ROOT / "memory"
    return base, base / "topics", base / "daily"


def _global_memory_dirs() -> tuple[Path, Path, Path]:
    """Return global (non-agent) memory dirs."""
    base = _REPO_ROOT / "memory"
    return base, base / "topics", base / "daily"


def _validate_memory_path(rel_path: str) -> Optional[Path]:
    """
    Resolve a relative path and ensure it's under memory/ or agents/*/memory/.
    Returns the absolute path, or None if invalid.
    """
    # Prevent absolute paths and traversal
    if os.path.isabs(rel_path) or ".." in rel_path.split("/"):
        return None

    resolved = (_REPO_ROOT / rel_path).resolve()

    # Must be under memory/ or agents/*/memory/
    memory_root = (_REPO_ROOT / "memory").resolve()
    agents_root = (_REPO_ROOT / "agents").resolve()

    if str(resolved).startswith(str(memory_root)):
        return resolved

    if str(resolved).startswith(str(agents_root)):
        try:
            rel_to_agents = resolved.relative_to(agents_root)
            parts = rel_to_agents.parts
            if len(parts) >= 2 and parts[1] == "memory":
                return resolved
        except ValueError:
            pass

    return None


# ---------------------------------------------------------------------------
# Search backend (keyword retriever — upgraded to hybrid in Phase 2)
# ---------------------------------------------------------------------------

def _load_config():
    """Load real config if available, else return defaults."""
    from clawde_app.config import AppConfig, AppPaths, MemoryConfig

    global_mem, global_topics, global_daily = _global_memory_dirs()

    # Try loading real config for strategy/settings
    try:
        from clawde_app.config import load_config
        cfg_path = _REPO_ROOT / "data" / "config.yaml"
        if cfg_path.exists():
            return load_config(cfg_path)
    except Exception:
        pass

    cfg = AppConfig(agents={}, memory=MemoryConfig())
    from clawde_app.config import _package_dir
    paths = AppPaths(
        data_home=_REPO_ROOT,
        package_dir=_package_dir(),
        config_path=_REPO_ROOT / "data" / "config.yaml",
        data_dir=_REPO_ROOT / "data",
        db_path=_REPO_ROOT / "data" / "clawde.db",
        runtime_dir=_REPO_ROOT / "runtime",
        runtime_context_file=_REPO_ROOT / "runtime" / "context" / "current.md",
        memory_dir=global_mem,
        memory_topics_dir=global_topics,
        memory_daily_dir=global_daily,
        claude_rules_dir=_REPO_ROOT / ".claude" / "rules",
        stderr_log_dir=_REPO_ROOT / "runtime" / "logs",
        agents_dir=_REPO_ROOT / "agents",
        skills_dir=_REPO_ROOT / "skills",
        mcp_dir=_REPO_ROOT / "mcp",
        mcp_servers_dir=_REPO_ROOT / "mcp" / "servers",
    )
    return cfg, paths


async def _search_memory_async(query: str, max_results: int = 6) -> list[dict]:
    """Run search over memory files. Uses hybrid if configured, else keyword."""
    cfg, paths = _load_config()

    mem_dir, topics_dir, daily_dir = _memory_dirs()
    agent_name = _AGENT_NAME

    snippets = []

    # Try hybrid search if configured
    if cfg.memory.retrieval.strategy == "hybrid":
        try:
            from clawde_app.memory_index import MemoryIndex
            index = MemoryIndex(paths.db_path, cfg)
            snippets = await index.search(
                agent_name, query,
                top_k=max_results,
                max_chars=cfg.memory.retrieval.max_chars_per_snippet,
            )
            await index.close()
        except Exception:
            snippets = []

    # Fall back to keyword search
    if not snippets:
        from clawde_app.memory_retrieval import KeywordMemoryRetriever
        retriever = KeywordMemoryRetriever(cfg, paths)
        snippets = retriever.retrieve(
            query, topics_dir=topics_dir, daily_dir=daily_dir,
        )

        # Merge global memory if agent-specific
        global_mem, global_topics, global_daily = _global_memory_dirs()
        if _AGENT_NAME and global_mem.resolve() != mem_dir.resolve():
            global_snippets = retriever.retrieve(
                query, topics_dir=global_topics, daily_dir=global_daily,
            )
            seen = {s.source_path.resolve() for s in snippets}
            for gs in global_snippets:
                if gs.source_path.resolve() not in seen:
                    snippets.append(gs)
                    seen.add(gs.source_path.resolve())
            snippets.sort(key=lambda s: s.score, reverse=True)
            snippets = snippets[:max_results]

    results = []
    for s in snippets:
        try:
            rel = s.source_path.relative_to(_REPO_ROOT).as_posix()
        except ValueError:
            rel = s.source_path.as_posix()
        results.append({
            "source": rel,
            "kind": s.kind,
            "title": s.title or "",
            "score": round(s.score, 2),
            "excerpt": s.excerpt,
        })
    return results


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

mcp = FastMCP("memory")


@mcp.tool()
async def memory_search(query: str, max_results: int = 6) -> str:
    """Search your long-term memory (MEMORY.md, topics/*.md, daily/*.md).

    Use this BEFORE answering questions about prior work, decisions, dates,
    people, preferences, or project history. Returns ranked excerpts from
    your memory files.

    Args:
        query: What to search for (natural language or keywords)
        max_results: Maximum number of results to return (default 6)
    """
    results = await _search_memory_async(query, max_results=max_results)
    if not results:
        return "No memory matches found for this query."

    parts = []
    for i, r in enumerate(results, 1):
        parts.append(
            f"### Result {i} (score: {r['score']}, {r['kind']})\n"
            f"**Source**: `{r['source']}`\n"
            f"**Title**: {r['title']}\n\n"
            f"{r['excerpt']}"
        )
    return "\n\n---\n\n".join(parts)


@mcp.tool()
def memory_get(file_path: str, from_line: int = 1, num_lines: int = 0) -> str:
    """Read a specific memory file (or a slice of it).

    Use after memory_search to read the full context around a matched snippet.

    Args:
        file_path: Relative path to the memory file (e.g. "memory/topics/projects.md"
                   or "agents/clawde/memory/daily/2026-02-14.md")
        from_line: Line number to start reading from (1-based, default 1)
        num_lines: Number of lines to read (0 = entire file, default 0)
    """
    resolved = _validate_memory_path(file_path)
    if resolved is None:
        return f"Error: Path '{file_path}' is not allowed. Must be under memory/ or agents/*/memory/."

    if not resolved.exists():
        return f"Error: File '{file_path}' not found."

    if not resolved.is_file():
        return f"Error: '{file_path}' is not a file."

    try:
        text = resolved.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return f"Error reading file: {e}"

    lines = text.splitlines(keepends=True)

    if from_line > 1 or num_lines > 0:
        start = max(0, from_line - 1)
        if num_lines > 0:
            lines = lines[start:start + num_lines]
        else:
            lines = lines[start:]

    content = "".join(lines)

    # Cap output to avoid overwhelming the context
    if len(content) > 15000:
        content = content[:15000] + "\n\n... (truncated, use from_line/num_lines to read specific sections)"

    return content


if __name__ == "__main__":
    mcp.run()
