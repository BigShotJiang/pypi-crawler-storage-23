from yreflow.main import main

main()
