"""
Model responsável pela geração dos blocos Range.

Implementa ancoragem de sessão baseada em session_open.
"""

from dataclasses import dataclass
from typing import List
import MetaTrader5 as mt5
from datetime import datetime, time
from mtcli.logger import setup_logger

log = setup_logger("mtcli.range.model")


@dataclass
class RangeBlock:
    open: float
    close: float
    direction: str  # "UP" ou "DOWN"


class RangeModel:
    """
    Responsável por:
    - Buscar dados no MT5
    - Calcular blocos de Range
    - Aplicar ancoragem por abertura de sessão
    """

    def __init__(
        self,
        symbol: str,
        timeframe_const: int,
        bars: int,
        range_size: float,
        ancorar_abertura: bool = False,
        session_open: str | None = None,
    ):
        self.symbol = symbol
        self.timeframe_const = timeframe_const
        self.bars = bars
        self.range_size = range_size
        self.ancorar_abertura = ancorar_abertura
        self.session_open = session_open

    def obter_candles(self):
        log.info(f"Buscando {self.bars} candles de {self.symbol}")
        rates = mt5.copy_rates_from_pos(
            self.symbol,
            self.timeframe_const,
            0,
            self.bars
        )

        if rates is None:
            raise RuntimeError("Erro ao obter dados do MT5.")

        return rates

    def _obter_preco_ancora(self, rates):
        """
        Retorna preço âncora baseado na abertura da sessão.
        """

        if not self.session_open:
            log.warning("session_open não configurado. Usando primeiro close.")
            return rates[0]["close"]

        hora_sessao = datetime.strptime(self.session_open, "%H:%M").time()

        for candle in rates:
            dt = datetime.fromtimestamp(candle["time"])
            if dt.time() >= hora_sessao:
                log.info(
                    f"Âncora encontrada na sessão: "
                    f"{dt.strftime('%Y-%m-%d %H:%M')} "
                    f"preço abertura {candle['open']}"
                )
                return candle["open"]

        log.warning("Sessão não encontrada nos candles carregados.")
        return rates[0]["close"]

    def gerar_range(self) -> List[RangeBlock]:

        rates = self.obter_candles()

        if len(rates) == 0:
            return []

        blocos: List[RangeBlock] = []

        # 🔹 Âncora
        if self.ancorar_abertura:
            ultimo_preco_base = self._obter_preco_ancora(rates)
        else:
            ultimo_preco_base = rates[0]["close"]
            log.info("Range iniciado pelo primeiro fechamento.")

        for candle in rates:
            preco = candle["close"]

            while abs(preco - ultimo_preco_base) >= self.range_size:

                if preco > ultimo_preco_base:
                    novo_close = ultimo_preco_base + self.range_size
                    direcao = "UP"
                else:
                    novo_close = ultimo_preco_base - self.range_size
                    direcao = "DOWN"

                blocos.append(
                    RangeBlock(
                        open=ultimo_preco_base,
                        close=novo_close,
                        direction=direcao
                    )
                )

                ultimo_preco_base = novo_close

        log.info(f"{len(blocos)} blocos de range gerados.")
        return blocos
