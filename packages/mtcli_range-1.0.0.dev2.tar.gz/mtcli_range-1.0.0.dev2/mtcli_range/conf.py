"""
Configuração do plugin mtcli-range.

Lê parâmetros do arquivo mtcli.ini na seção [range].
Também lê session_open da seção [renko] ou [range].
"""

import configparser
import os


CONFIG_PATH = os.path.join(os.getcwd(), "mtcli.ini")

config = configparser.ConfigParser()
config.read(CONFIG_PATH)

SECTION = "range"


def get_default_symbol() -> str:
    return config.get(SECTION, "symbol", fallback="WIN$")


def get_default_range() -> float:
    return config.getfloat(SECTION, "range_size", fallback=50.0)


def get_default_timeframe() -> str:
    return config.get(SECTION, "timeframe", fallback="m5")


def get_default_bars() -> int:
    return config.getint(SECTION, "bars", fallback=500)


def get_session_open() -> str | None:
    """
    Retorna horário de abertura da sessão no formato HH:MM.
    Busca:
        1. [range]
        2. [renko]
    """
    if config.has_option("range", "session_open"):
        return config.get("range", "session_open")

    if config.has_option("renko", "session_open"):
        return config.get("renko", "session_open")

    return None
