"""
View responsável pela saída no terminal.

Layout linear, amigável para leitores de tela.
Sem uso de gráficos ASCII complexos.
"""

from typing import List
from mtcli.logger import setup_logger
from .range_model import RangeBlock

log = setup_logger("mtcli.range.view")


class RangeView:
    """
    Responsável por exibir os blocos de forma textual estruturada.
    """

    @staticmethod
    def exibir_header(symbol: str, range_size: float, ancorado: bool):
        """Exibe cabeçalho descritivo."""
        print("\n========================================")
        print("GRÁFICO RANGE")
        print("----------------------------------------")
        print(f"Ativo: {symbol}")
        print(f"Tamanho do Range: {range_size}")
        print(f"Ancorado na abertura: {'SIM' if ancorado else 'NÃO'}")
        print("========================================\n")

    @staticmethod
    def exibir_blocos(blocos: List[RangeBlock], numerar: bool):
        """
        Exibe blocos linha a linha.

        numerar:
            - True  -> exibe número da linha
            - False -> não exibe numeração
        """

        if not blocos:
            print("Nenhum bloco gerado.")
            return

        if numerar:
            print("Número Direção Abertura Fechamento")
            print("-----------------------------------")
        else:
            print("Direção Abertura Fechamento")
            print("----------------------------")

        for i, bloco in enumerate(blocos, start=1):

            if numerar:
                print(
                    f"{i:>6} "
                    f"{bloco.direction:<5} "
                    f"{bloco.open:>8.0f} "
                    f"{bloco.close:>10.0f}"
                )
            else:
                print(
                    f"{bloco.direction:<5} "
                    f"{bloco.open:>8.0f} "
                    f"{bloco.close:>10.0f}"
                )
