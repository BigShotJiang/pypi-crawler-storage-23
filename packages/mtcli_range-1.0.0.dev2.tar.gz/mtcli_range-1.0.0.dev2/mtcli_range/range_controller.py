"""
Controller do plugin mtcli-range.

Responsável por orquestrar:

- Leitura de parâmetros da CLI
- Conversão de timeframe via Enum central
- Leitura de session_open do mtcli.ini
- Conexão segura com MT5
- Execução do Model
- Renderização da View

Mantém separação clara entre:
    Model  -> cálculo dos blocos
    View   -> exibição no terminal
    Controller -> coordenação do fluxo
"""

from mtcli.mt5_context import mt5_conexao
from mtcli.logger import setup_logger
from mtcli.domain.timeframe import Timeframe

from .range_model import RangeModel
from .range_view import RangeView
from .conf import get_session_open


log = setup_logger("mtcli.range.controller")


class RangeController:
    """
    Controlador principal do gráfico Range.

    Parâmetros:
        symbol (str): ativo
        timeframe (str): timeframe textual (ex: m5, h1)
        bars (int): quantidade de candles base
        range_size (float): tamanho fixo do range
        ancorar_abertura (bool): se True, ancora na abertura da sessão
        numerar (bool): se True, numera as linhas exibidas
    """

    def __init__(
        self,
        symbol: str,
        timeframe: str,
        bars: int,
        range_size: float,
        ancorar_abertura: bool,
        numerar: bool,
    ):
        self.symbol = symbol
        self.timeframe = Timeframe.from_string(timeframe)
        self.bars = bars
        self.range_size = range_size
        self.ancorar_abertura = ancorar_abertura
        self.numerar = numerar

    def executar(self):
        """
        Executa o fluxo completo:

        1. Lê session_open do mtcli.ini
        2. Abre conexão MT5
        3. Instancia o Model
        4. Gera blocos Range
        5. Exibe resultado via View
        """

        log.info("Iniciando execução do mtcli-range.")

        # 🔹 Lê horário de abertura de sessão do mtcli.ini
        session_open = get_session_open()

        if self.ancorar_abertura:
            if session_open:
                log.info(f"Ancoragem habilitada. session_open = {session_open}")
            else:
                log.warning(
                    "Ancoragem solicitada, mas session_open não encontrado no mtcli.ini. "
                    "Será usado o primeiro fechamento disponível."
                )

        try:
            with mt5_conexao():

                model = RangeModel(
                    symbol=self.symbol,
                    timeframe_const=self.timeframe.mt5_const,
                    bars=self.bars,
                    range_size=self.range_size,
                    ancorar_abertura=self.ancorar_abertura,
                    session_open=session_open,
                )

                blocos = model.gerar_range()

        except Exception as e:
            log.error(f"Erro durante execução do RangeController: {e}")
            raise

        # 🔹 Exibição fora do contexto MT5
        RangeView.exibir_header(
            symbol=self.symbol,
            range_size=self.range_size,
            ancorado=self.ancorar_abertura,
        )

        RangeView.exibir_blocos(
            blocos=blocos,
            numerar=self.numerar,
        )

        log.info("Execução do mtcli-range finalizada com sucesso.")
