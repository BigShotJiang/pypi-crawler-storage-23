from .cli import range_command


def register(cli):
    cli.add_command(range_command, name="range")
    cli.add_command(range_command, name="r")
