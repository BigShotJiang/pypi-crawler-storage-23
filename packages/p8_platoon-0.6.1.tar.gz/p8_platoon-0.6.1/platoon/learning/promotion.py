"""Promotion simulator — lift, cannibalization, and post-promo dip modeling.

TODO: Implement promotion impact analysis:
    - Pre/during/post-promo demand decomposition
    - Cannibalization estimation (cross-product substitution)
    - Net incremental units after accounting for pull-forward
    - ROI calculation: incremental margin vs. discount cost

Planned backends:
    - builtin: Heuristic lift model (before/during/after comparison)
    - causalml: Causal inference for true incremental lift (T-learner, X-learner)

Usage (planned):
    from platoon.learning.providers import get_provider
    promo = get_provider("promotion")
    result = promo.simulate(baseline_demand=20, discount_pct=0.25, duration_days=7)
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List

from platoon.learning.providers import ModelProvider, register_provider


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass
class PromotionResult:
    """Output of a promotion simulation."""

    periods: List[Dict[str, Any]]  # [{period, demand, baseline, lift}]
    total_incremental_units: float  # gross lift during promo
    net_incremental_units: float  # after subtracting pull-forward / post-promo dip
    roi: float  # incremental_margin / discount_cost


# ---------------------------------------------------------------------------
# Provider stubs
# ---------------------------------------------------------------------------


@register_provider
class BuiltinPromotionProvider(ModelProvider):
    """Heuristic promotion simulator — before/during/after comparison.

    TODO: Implement simulate() with configurable lift curves and post-promo dip.
    """

    name = "builtin_promotion"
    domain = "promotion"
    backend = "builtin"

    def simulate(self, baseline_demand: float, discount_pct: float, duration_days: int = 7, **kwargs) -> PromotionResult:
        """Simulate promotion impact on demand."""
        raise NotImplementedError("builtin promotion provider not yet implemented")


@register_provider
class CausalMLPromotionProvider(ModelProvider):
    """Causal inference promotion analysis via causalml.

    TODO: Implement simulate() using T-learner or X-learner for true incremental lift.
    Requires: causalml
    """

    name = "causalml_promotion"
    domain = "promotion"
    backend = "causalml"

    @classmethod
    def is_available(cls) -> bool:
        try:
            import causalml  # noqa: F401
            return True
        except ImportError:
            return False

    def simulate(self, baseline_demand: float, discount_pct: float, duration_days: int = 7, **kwargs) -> PromotionResult:
        """Simulate promotion impact using causal inference."""
        raise NotImplementedError("causalml promotion provider not yet implemented")
