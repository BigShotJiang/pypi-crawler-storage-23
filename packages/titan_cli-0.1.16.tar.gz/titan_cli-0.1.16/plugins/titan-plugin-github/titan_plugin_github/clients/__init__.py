# plugins/titan-plugin-github/titan_plugin_github/clients/__init__.py
"""
GitHub API clients
"""

from .github_client import GitHubClient

__all__ = ["GitHubClient"]
