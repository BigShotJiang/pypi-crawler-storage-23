from __future__ import annotations

from typing import TYPE_CHECKING

from blends.models import Language
from blends.stack.policies.default import DefaultExportPolicy
from blends.stack.policies.go import GoExportPolicy
from blends.stack.policies.java import JavaExportPolicy
from blends.stack.policies.javascript import JavaScriptExportPolicy
from blends.stack.policies.kotlin import KotlinExportPolicy
from blends.stack.policies.python import PythonExportPolicy

if TYPE_CHECKING:
    from blends.stack.policies.base import ExportPolicy

_POLICY_REGISTRY: dict[Language, ExportPolicy] = {
    Language.PYTHON: PythonExportPolicy(),
    Language.JAVA: JavaExportPolicy(),
    Language.GO: GoExportPolicy(),
    Language.JAVASCRIPT: JavaScriptExportPolicy(),
    Language.TYPESCRIPT: JavaScriptExportPolicy(),
    Language.KOTLIN: KotlinExportPolicy(),
    Language.SCALA: KotlinExportPolicy(),
    Language.CSHARP: JavaExportPolicy(),
}

_DEFAULT_POLICY = DefaultExportPolicy()


def get_export_policy(language: Language) -> ExportPolicy:
    return _POLICY_REGISTRY.get(language, _DEFAULT_POLICY)
