from .fractionals import Fraction

# optionally, you can expose it in __all__ to make it explicit
__all__ = ["Fraction"]
__version__ = "1.0.6"

