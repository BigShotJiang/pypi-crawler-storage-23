"""jq-like JSON processor for termish."""

from .eval import JqError, JqTypeError, evaluate
from .parser import ParseError, parse_filter

__all__ = ["parse_filter", "evaluate", "ParseError", "JqError", "JqTypeError"]
