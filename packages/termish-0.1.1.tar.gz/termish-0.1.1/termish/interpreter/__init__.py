from .core import execute_script

__all__ = ["execute_script"]
