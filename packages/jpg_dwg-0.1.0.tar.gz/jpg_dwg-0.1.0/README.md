# jpg-dwg

Convert scanned P&ID (Piping and Instrumentation) drawing images to DXF (lines only), and optionally to DWG via an external converter.

## Install

**From PyPI (recommended):**

```bash
pip install jpg-dwg
```

**From source:**

```bash
git clone https://github.com/yourusername/jpg-dwg.git
cd jpg-dwg
pip install -e .
```

Or install dependencies only and run as module:

```bash
pip install -r requirements.txt
python -m jpg_dwg input.png -o output.dxf
```

## Usage

```bash
# Basic: image → DXF (after pip install jpg-dwg)
jpg-dwg scan.png -o drawing.dxf

# Or as module
python -m jpg_dwg scan.png -o drawing.dxf

# With options (invert is on by default for black-on-white P&ID; use --no-invert if needed)
python -m jpg_dwg scan.png -o drawing.dxf --preview preprocessed.png --scale 0.1

# Enable P&ID symbol detection (contour-based heuristics)
python -m jpg_dwg scan.png -o drawing.dxf --symbols

# Also produce DWG (requires ODA File Converter)
python -m jpg_dwg scan.png -o drawing.dxf --dwg drawing.dwg
```

### Options

| Option | Description |
|--------|-------------|
| `input` | Input image path (PNG, JPG, etc.) |
| `-o`, `--output` | Output DXF path |
| `--scale` | Drawing units per pixel (default 1.0) |
| `--dpi` | DPI hint (default 300) |
| `--no-deskew` | Disable automatic deskew |
| `--invert` | Invert binary (default: on for black lines on white) |
| `--no-invert` | Do not invert (for white lines on dark scan) |
| `--adaptive` | Use adaptive threshold instead of Otsu |
| `--no-denoise` | Disable morphology denoise |
| `--thin` | Thinning/skeletonization (requires opencv-contrib) |
| `--preview PATH` | Save preprocessed binary image |
| `--symbols` | Run P&ID symbol detection and insert blocks |
| `--dwg PATH` | Also convert DXF to DWG (see below) |
| `-v`, `--verbose` | Verbose logging |

## DWG output

This tool writes **DXF** only. To get **DWG**:

1. Install [ODA File Converter](https://www.opendesign.com/guestfiles/oda_file_converter).
2. Set `ODA_FILE_CONVERTER` to the converter executable path, or ensure it is on `PATH`.
3. Use `--dwg output.dwg`. The CLI will run the converter after writing the DXF.

## Limitations

- Quality depends on scan resolution and contrast. Preprocess with `--invert` or `--preview` to tune.
- Vectorization extracts lines only (OpenCV Hough).
- P&ID symbol detection is heuristic (contour-based). For production, consider a trained model (e.g. YOLO on P&ID symbols).

## Publishing to PyPI (maintainers)

1. Create an account and API token at [pypi.org](https://pypi.org) (use [test.pypi.org](https://test.pypi.org) for testing).
2. From the repo root:
   ```bash
   pip install build twine
   python -m build
   twine upload dist/*
   ```
3. When prompted: username `__token__`, password = your PyPI API token.
4. To test first: `twine upload --repository testpypi dist/*`, then `pip install -i https://test.pypi.org/simple/ jpg-dwg`.

Update `version` in `pyproject.toml` and the `[project.urls]` Homepage/Source to your repo before publishing.

## Project layout

```
jpg-dwg/
├── pyproject.toml
├── requirements.txt
├── README.md
├── src/jpg_dwg/
│   ├── cli.py
│   ├── preprocess.py
│   ├── vectorize.py
│   ├── export_dxf.py
│   ├── symbols.py
│   └── config.py
└── tests/
```
