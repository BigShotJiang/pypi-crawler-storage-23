"""Allow running as python -m jpg_dwg."""

from .cli import main

if __name__ == "__main__":
    main()
