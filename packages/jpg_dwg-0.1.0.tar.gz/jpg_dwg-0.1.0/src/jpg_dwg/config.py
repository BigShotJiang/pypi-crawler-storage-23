"""Default layers, block names, and scale."""

# Layers for Phase 1 (generic) and Phase 2 (P&ID)
LAYER_LINE = "LINE"
LAYER_CIRCLE = "CIRCLE"
LAYER_ARC = "ARC"
LAYER_POLYLINE = "POLYLINE"
LAYER_TEXT = "TEXT"

# P&ID-specific layers
LAYER_PIPE = "PIPE"
LAYER_INSTRUMENT = "INSTRUMENT"
LAYER_VALVE = "VALVE"
LAYER_EQUIPMENT = "EQUIPMENT"

# Block names for P&ID symbols (Phase 2)
BLOCK_VALVE = "VALVE"
BLOCK_PUMP = "PUMP"
BLOCK_INSTRUMENT = "INSTRUMENT"
BLOCK_EQUIPMENT = "EQUIPMENT"

# Default scale: pixels per drawing unit (e.g. 1 mm)
DEFAULT_DPI = 300
DEFAULT_SCALE = 1.0  # 1 pixel = 1 drawing unit; override with --scale
