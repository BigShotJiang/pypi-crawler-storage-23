"""Build ezdxf document from LINE primitives (and optional symbol refs); save DXF."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, List

import ezdxf
from ezdxf.layouts import Modelspace

from . import config

logger = logging.getLogger(__name__)


def _add_line(
    msp: Modelspace,
    p: dict[str, Any],
    scale: float,
    height: int,
    layer: str,
) -> None:
    """Add one line; image coords (y down) -> drawing (y up) and scale."""
    msp.add_line(
        (p["x1"] * scale, (height - 1 - p["y1"]) * scale),
        (p["x2"] * scale, (height - 1 - p["y2"]) * scale),
        dxfattribs={"layer": layer},
    )


def _add_line_drawing_coords(
    msp: Modelspace,
    p: dict[str, Any],
    scale: float,
    layer: str,
) -> None:
    """Add one line already in drawing coords (y up); only scale."""
    msp.add_line(
        (p["x1"] * scale, p["y1"] * scale),
        (p["x2"] * scale, p["y2"] * scale),
        dxfattribs={"layer": layer},
    )


def export_dxf(
    primitives: List[dict[str, Any]],
    output_path: str | Path,
    height: int,
    scale_factor: float = 1.0,
    use_drawing_coords: bool = False,
    symbol_refs: List[dict[str, Any]] | None = None,
    default_layer: str | None = None,
) -> None:
    """
    Write LINE primitives (and optional symbol_refs) to DXF.
    Only primitives with type "line" are exported.
    """
    layer = default_layer or config.LAYER_LINE
    doc = ezdxf.new("R2010")
    msp = doc.modelspace()

    if symbol_refs:
        from .symbols import add_pid_blocks
        add_pid_blocks(doc)

    for p in primitives:
        if p.get("type") != "line":
            continue
        if use_drawing_coords:
            _add_line_drawing_coords(msp, p, scale_factor, layer)
        else:
            _add_line(msp, p, scale_factor, height, layer)

    if symbol_refs:
        for ref in symbol_refs:
            name = ref.get("block_name") or ref.get("block")
            if not name:
                continue
            x = ref.get("x", 0) * scale_factor
            y = (height - 1 - ref.get("y", 0)) * scale_factor if not use_drawing_coords else ref.get("y", 0) * scale_factor
            scale = ref.get("scale", 1.0)
            rot = ref.get("rotation", 0)
            try:
                msp.add_blockref(name, (x, y), dxfattribs={"xscale": scale, "yscale": scale, "rotation": rot})
            except ezdxf.DXFKeyError:
                logger.warning("Block '%s' not defined, skipping insert", name)

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc.saveas(str(output_path))
    logger.info("Saved DXF to %s", output_path)
