"""Optional P&ID symbol detection (contour-based placeholder). Returns block refs for export."""

from __future__ import annotations

import logging
from typing import Any, List

import cv2
import numpy as np

from . import config

logger = logging.getLogger(__name__)


def detect_symbols(binary: np.ndarray) -> List[dict[str, Any]]:
    """
    Contour-based heuristic detection: circles -> INSTRUMENT, elongated -> VALVE, etc.
    Returns list of {block_name, x, y, scale?, rotation?} in image coords (y down).
    """
    refs: List[dict[str, Any]] = []
    contours, _ = cv2.findContours(
        binary, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE
    )
    for cnt in contours:
        if len(cnt) < 5:
            continue
        area = cv2.contourArea(cnt)
        if area < 50 or area > 0.3 * binary.size:
            continue
        M = cv2.moments(cnt)
        if M["m00"] == 0:
            continue
        cx = M["m10"] / M["m00"]
        cy = M["m01"] / M["m00"]
        (_, _), (ma, MA), angle = cv2.fitEllipse(cnt)
        aspect = MA / ma if ma > 0 else 1
        # Heuristics: near-circle -> instrument bubble; elongated -> valve
        if 0.8 <= aspect <= 1.2 and area < 2000:
            refs.append({"block_name": config.BLOCK_INSTRUMENT, "x": cx, "y": cy, "scale": 1.0, "rotation": 0})
        elif aspect > 2 or aspect < 0.5:
            refs.append({"block_name": config.BLOCK_VALVE, "x": cx, "y": cy, "scale": 1.0, "rotation": angle})
        else:
            refs.append({"block_name": config.BLOCK_EQUIPMENT, "x": cx, "y": cy, "scale": 1.0, "rotation": 0})
    return refs


def add_pid_blocks(doc) -> None:
    """Add default P&ID block definitions to doc.blocks so add_blockref works."""
    from . import config
    # Instrument: circle
    blk = doc.blocks.new(config.BLOCK_INSTRUMENT)
    blk.add_circle((0, 0), 1.0)
    # Valve: triangle/diamond
    blk = doc.blocks.new(config.BLOCK_VALVE)
    blk.add_lwpolyline([(0, 1), (-0.6, -0.5), (0, 0), (0.6, -0.5), (0, 1)])
    # Pump: circle with arrow
    blk = doc.blocks.new(config.BLOCK_PUMP)
    blk.add_circle((0, 0), 1.0)
    blk.add_line((-0.5, 0), (0.5, 0))
    # Equipment: rectangle
    blk = doc.blocks.new(config.BLOCK_EQUIPMENT)
    blk.add_lwpolyline([(-1, -0.5), (1, -0.5), (1, 0.5), (-1, 0.5), (-1, -0.5)])
