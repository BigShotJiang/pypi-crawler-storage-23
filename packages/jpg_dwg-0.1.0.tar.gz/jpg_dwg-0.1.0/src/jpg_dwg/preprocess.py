"""Load image, deskew, binarize, optional denoise/thin."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Tuple

import cv2
import numpy as np

logger = logging.getLogger(__name__)


def load_image(path: str | Path) -> np.ndarray:
    """Load image; raise if missing or invalid format."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Image not found: {path}")
    img = cv2.imread(str(path))
    if img is None:
        raise ValueError(f"Cannot read image (unsupported format?): {path}")
    return img


def to_grayscale(img: np.ndarray) -> np.ndarray:
    """Convert to grayscale if needed."""
    if len(img.shape) == 2:
        return img
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def deskew(img: np.ndarray) -> np.ndarray:
    """Deskew using moments of binary image (white = foreground)."""
    gray = to_grayscale(img) if len(img.shape) == 3 else img
    if gray.dtype != np.uint8:
        gray = (gray * 255).astype(np.uint8) if gray.max() <= 1 else gray.astype(np.uint8)
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    coords = np.column_stack(np.where(binary > 0))
    if len(coords) < 100:
        return img
    angle = cv2.minAreaRect(coords)[-1]
    if angle < -45:
        angle = 90 + angle
    elif angle > 45:
        angle = angle - 90
    if abs(angle) < 0.5:
        return img
    h, w = img.shape[:2]
    M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    if len(img.shape) == 3:
        return cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REPLICATE)
    return cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REPLICATE)


def binarize(
    img: np.ndarray,
    *,
    invert: bool = False,
    use_adaptive: bool = False,
) -> np.ndarray:
    """Otsu or adaptive threshold; optional invert (for white lines on dark)."""
    gray = to_grayscale(img) if len(img.shape) == 3 else img
    if gray.dtype != np.uint8:
        gray = (np.clip(gray, 0, 1) * 255).astype(np.uint8)
    if use_adaptive:
        binary = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 21, 10
        )
    else:
        _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    if invert:
        binary = 255 - binary
    return binary


def denoise(binary: np.ndarray) -> np.ndarray:
    """Morphology: remove small speckles, close gaps."""
    kernel = np.ones((2, 2), np.uint8)
    out = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)
    out = cv2.morphologyEx(out, cv2.MORPH_CLOSE, kernel)
    return out


def thin(binary: np.ndarray) -> np.ndarray:
    """Thinning (skeleton) for line-like drawings."""
    # Zhang-Suen style via OpenCV ximgproc if available; else skip
    try:
        thin = cv2.ximgproc.thinning(binary, thinningType=cv2.ximgproc.THINNING_ZHANGSUEN)
        return thin
    except AttributeError:
        return binary


def preprocess(
    path: str | Path,
    *,
    deskew_img: bool = True,
    invert: bool = False,
    use_adaptive: bool = False,
    denoise_img: bool = True,
    thin_img: bool = False,
    scale: float | None = None,
    dpi: float = 300,
) -> Tuple[np.ndarray, float]:
    """
    Load, optionally deskew, binarize, denoise, thin.
    Returns (binary image, scale_factor).
    scale_factor = pixels per drawing unit; if scale is set, use it; else derive from dpi.
    """
    img = load_image(path)
    if deskew_img:
        img = deskew(img)
    binary = binarize(img, invert=invert, use_adaptive=use_adaptive)
    if denoise_img:
        binary = denoise(binary)
    if thin_img:
        binary = thin(binary)

    # Scale: drawing units per pixel. If user passes scale = "units per pixel" we use it.
    # Plan says "scale factor (pixel → drawing units)" so scale_factor = 1 means 1 pixel = 1 unit.
    # Common: 1 pixel at 300 dpi = 1/300 inch; so scale_factor could be 1/300 for inch units.
    # We treat scale as "drawing units per pixel" so scale=1.0 means 1 pixel = 1 unit.
    if scale is not None:
        scale_factor = scale
    else:
        # Default: 1 pixel = 1 unit (user can override with --scale)
        scale_factor = 1.0
    logger.info("Preprocessed image shape %s, scale_factor=%s", binary.shape, scale_factor)
    return binary, scale_factor
