"""CLI: input image, output DXF; optional --scale, --dpi, --deskew, --invert, --preview, --symbols, --dwg."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from . import __version__
from .export_dxf import export_dxf
from .preprocess import preprocess
from .vectorize import vectorize

logger = logging.getLogger(__name__)


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Convert scanned P&ID image to DXF (and optionally DWG).",
    )
    p.add_argument("input", type=str, help="Input image path (e.g. PNG, JPG)")
    p.add_argument("-o", "--output", type=str, required=True, help="Output DXF path")
    p.add_argument("--scale", type=float, default=None, help="Drawing units per pixel (default 1.0)")
    p.add_argument("--dpi", type=float, default=300, help="DPI hint for scale (default 300)")
    p.add_argument("--no-deskew", action="store_true", help="Disable deskew")
    p.add_argument("--invert", action="store_true", help="Invert binary (default: on for black lines on white, typical P&ID)")
    p.add_argument("--no-invert", action="store_true", help="Do not invert (use if scan is white lines on dark)")
    p.add_argument("--adaptive", action="store_true", help="Use adaptive threshold")
    p.add_argument("--no-denoise", action="store_true", help="Disable denoise")
    p.add_argument("--thin", action="store_true", help="Thin/skeletonize lines")
    p.add_argument("--layer", type=str, default=None, help="Single layer for all (overrides defaults)")
    p.add_argument("--preview", type=str, default=None, metavar="PATH", help="Save preprocessed image")
    p.add_argument("--symbols", action="store_true", help="Enable P&ID symbol detection (Phase 2)")
    p.add_argument("--vectorize", type=str, choices=("primitives",), default="primitives", help="Vectorization method")
    p.add_argument("--dwg", type=str, default=None, metavar="PATH", help="Also convert to DWG (requires ODA converter)")
    p.add_argument("-v", "--verbose", action="store_true", help="Verbose logging")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p.parse_args()


def run() -> None:
    args = _parse_args()
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)s: %(message)s",
    )

    input_path = Path(args.input)
    output_path = Path(args.output)
    if output_path.suffix.lower() != ".dxf":
        logger.warning("Output path has no .dxf extension; some viewers may not recognize it.")

    try:
        binary, scale_factor = preprocess(
            input_path,
            deskew_img=not args.no_deskew,
            invert=args.invert or (not args.no_invert),
            use_adaptive=args.adaptive,
            denoise_img=not args.no_denoise,
            thin_img=args.thin,
            scale=args.scale,
            dpi=args.dpi,
        )
    except FileNotFoundError as e:
        logger.error("%s", e)
        sys.exit(1)
    except ValueError as e:
        logger.error("%s", e)
        sys.exit(1)

    if args.preview:
        import cv2
        cv2.imwrite(str(args.preview), binary)
        logger.info("Wrote preview to %s", args.preview)

    height, width = binary.shape
    primitives = vectorize(binary, method=args.vectorize)

    symbol_refs = None
    if args.symbols:
        try:
            from .symbols import detect_symbols
            symbol_refs = detect_symbols(binary)
            if symbol_refs:
                logger.info("Detected %d symbols", len(symbol_refs))
        except Exception as e:
            logger.warning("Symbol detection failed: %s", e)

    export_dxf(
        primitives,
        output_path,
        height=height,
        scale_factor=scale_factor,
        use_drawing_coords=False,
        symbol_refs=symbol_refs,
        default_layer=args.layer,
    )

    logger.info("Exported %d lines", len(primitives))

    if args.dwg:
        _convert_to_dwg(output_path, Path(args.dwg))


def _convert_to_dwg(dxf_path: Path, dwg_path: Path) -> None:
    """Run ODA File Converter (if configured) to produce DWG from DXF."""
    import os
    import subprocess
    # Common env var for ODA converter path
    converter = os.environ.get("ODA_FILE_CONVERTER") or "ODAFileConverter"
    try:
        # ODA CLI: ODAFileConverter input_dir output_dir ACAD2018 DXF 0 0 "*.dxf"
        # Output dir must exist; it writes DWG there with same base name
        out_dir = dwg_path.parent
        out_dir.mkdir(parents=True, exist_ok=True)
        in_dir = dxf_path.parent
        cmd = [
            converter,
            str(in_dir),
            str(out_dir),
            "ACAD2018",
            "DXF",
            "0",
            "0",
            dxf_path.name,
        ]
        subprocess.run(cmd, check=True)
        # Converter writes to output dir with same name but .dwg
        result = out_dir / dxf_path.with_suffix(".dwg").name
        if result != dwg_path and dwg_path.suffix.lower() == ".dwg":
            import shutil
            shutil.move(str(result), str(dwg_path))
        logger.info("Converted to DWG: %s", dwg_path)
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        logger.warning("DWG conversion failed (install ODA File Converter?): %s", e)


def main() -> None:
    run()


if __name__ == "__main__":
    main()
