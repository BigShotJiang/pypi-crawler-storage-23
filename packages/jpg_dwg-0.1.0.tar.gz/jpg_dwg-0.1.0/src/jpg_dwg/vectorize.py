"""Extract only LINE primitives from raster via OpenCV Hough."""

from __future__ import annotations

import logging
from typing import Any, List

import cv2
import numpy as np

logger = logging.getLogger(__name__)

_MIN_LINE_LENGTH_RATIO = 0.02
_HOUGH_LINE_THRESHOLD = 50
_HOUGH_MAX_LINE_GAP = 8
_DEDUPE_LINE_DIST = 3


def _image_to_drawing_coords(x: float, y: float, height: int) -> tuple[float, float]:
    """Image (x, y) with y down -> drawing (x, y) with y up."""
    return (float(x), float(height - 1 - y))


def _lines_mergeable(a: dict[str, Any], b: dict[str, Any], dist_tol: float) -> bool:
    if a["type"] != "line" or b["type"] != "line":
        return False
    ax1, ay1, ax2, ay2 = a["x1"], a["y1"], a["x2"], a["y2"]
    bx1, by1, bx2, by2 = b["x1"], b["y1"], b["x2"], b["y2"]
    va = (ax2 - ax1, ay2 - ay1)
    vb = (bx2 - bx1, by2 - by1)
    la, lb = np.hypot(*va), np.hypot(*vb)
    if la < 1e-6 or lb < 1e-6:
        return False
    cos = (va[0] * vb[0] + va[1] * vb[1]) / (la * lb)
    if cos < 0.99:
        return False

    def dist_pt_to_seg(px, py, x1, y1, x2, y2):
        dx, dy = x2 - x1, y2 - y1
        t = max(0, min(1, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy + 1e-12)))
        return np.hypot(px - (x1 + t * dx), py - (y1 + t * dy))

    return (
        dist_pt_to_seg(bx1, by1, ax1, ay1, ax2, ay2) <= dist_tol
        and dist_pt_to_seg(bx2, by2, ax1, ay1, ax2, ay2) <= dist_tol
    )


def _dedupe_lines(lines: List[dict[str, Any]], dist_tol: float) -> List[dict[str, Any]]:
    if not lines:
        return []
    kept: List[dict[str, Any]] = []
    for p in lines:
        if any(_lines_mergeable(p, k, dist_tol) for k in kept):
            continue
        kept.append(p)
    return kept


def vectorize(binary: np.ndarray, method: str = "primitives") -> List[dict[str, Any]]:
    """
    Extract only LINE primitives (HoughLinesP on edges).
    Returns list of {"type": "line", "x1", "y1", "x2", "y2"} in image coords (y down).
    """
    if method != "primitives":
        raise ValueError(f"Unknown vectorize method: {method}")
    height, width = binary.shape
    dim = min(width, height)
    edges = cv2.Canny(binary, 50, 150)
    min_line_len = max(25, int(dim * _MIN_LINE_LENGTH_RATIO))
    lines = cv2.HoughLinesP(
        edges,
        rho=1,
        theta=np.pi / 180,
        threshold=_HOUGH_LINE_THRESHOLD,
        minLineLength=min_line_len,
        maxLineGap=_HOUGH_MAX_LINE_GAP,
    )
    line_list: List[dict[str, Any]] = []
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            line_list.append({"type": "line", "x1": x1, "y1": y1, "x2": x2, "y2": y2})
    line_list = _dedupe_lines(line_list, _DEDUPE_LINE_DIST)
    logger.info("Vectorized: %d lines", len(line_list))
    return line_list


def primitives_to_drawing_coords(
    primitives: List[dict[str, Any]],
    height: int,
) -> List[dict[str, Any]]:
    """Convert line coords from image (y down) to drawing (y up)."""
    out = []
    for p in primitives:
        p = dict(p)
        if p["type"] == "line":
            x1, y1 = _image_to_drawing_coords(p["x1"], p["y1"], height)
            x2, y2 = _image_to_drawing_coords(p["x2"], p["y2"], height)
            p["x1"], p["y1"], p["x2"], p["y2"] = x1, y1, x2, y2
        out.append(p)
    return out
