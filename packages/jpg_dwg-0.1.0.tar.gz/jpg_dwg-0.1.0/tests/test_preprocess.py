"""Tests for preprocess module."""

import tempfile
from pathlib import Path

import numpy as np
import pytest

from jpg_dwg.preprocess import load_image, to_grayscale, binarize, preprocess


def test_to_grayscale():
    rgb = np.random.randint(0, 255, (10, 10, 3), dtype=np.uint8)
    gray = to_grayscale(rgb)
    assert gray.shape == (10, 10)
    assert gray.dtype in (np.uint8, np.float64)


def test_binarize():
    gray = np.random.randint(0, 255, (20, 20), dtype=np.uint8)
    out = binarize(gray, invert=False)
    assert out.shape == gray.shape
    assert set(np.unique(out)).issubset({0, 255})


def test_load_image_missing():
    with pytest.raises(FileNotFoundError):
        load_image("/nonexistent/path.png")


def test_preprocess_requires_valid_file():
    with pytest.raises(FileNotFoundError):
        preprocess("/nonexistent.png")


def test_preprocess_with_real_image():
    # Create a minimal valid PNG in temp file
    import cv2
    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        path = f.name
    try:
        img = np.ones((50, 50), dtype=np.uint8) * 255
        img[20:30, 20:30] = 0
        cv2.imwrite(path, img)
        binary, scale = preprocess(path, deskew_img=False, denoise_img=False)
        assert binary.shape == (50, 50)
        assert scale == 1.0
    finally:
        Path(path).unlink(missing_ok=True)
