"""BaseModel for all SDK response types."""

from __future__ import annotations

import pydantic


class BaseModel(pydantic.BaseModel):
    """Base class for all Rulebook API response models.

    All response types inherit from this. It uses Pydantic v2 for
    validation and serialization with strict typing.
    """

    model_config = pydantic.ConfigDict(
        populate_by_name=True,
        frozen=True,
    )
