"""Fee schedule result model."""

from __future__ import annotations

from typing import Optional

from rulebook._models import BaseModel

__all__ = ["FeeScheduleResult"]


class FeeScheduleResult(BaseModel):
    id: str
    """Unique identifier for the fee schedule result."""

    exchange_name: str
    """Exchange identifier (e.g., ``"fee_cboe_us_options"``, ``"Nasdaq"``)."""

    fee_type: str
    """Fee type — ``"Option"`` or ``"Equity"``."""

    fee_category: str
    """Fee category (e.g., ``"Fee And Rebates"``)."""

    fee_charge_type: Optional[str] = None
    """Charge type classification."""

    fee_amount: Optional[str] = None
    """Fee or rebate amount (may include currency, ranges, or tier descriptions)."""

    fee_action: Optional[str] = None
    """Trading action type — ``"Make"``, ``"Take"``, ``"Open"``, ``"Routed"``, or ``"Other"``."""

    fee_action_details: Optional[str] = None
    """Additional details about the trading action."""

    fee_basis: Optional[str] = None
    """Basis on which the fee is calculated."""

    fee_notes: Optional[str] = None
    """Additional notes about the fee."""

    fee_reference: Optional[str] = None
    """Reference information for the fee."""

    fee_participant: Optional[str] = None
    """Market participant type (e.g., ``"Market Maker"``, ``"Customer"``)."""

    fee_participant_details: Optional[str] = None
    """Additional details about the participant."""

    fee_monthly_volume: Optional[str] = None
    """Monthly volume threshold or tier."""

    fee_monthly_volume_criteria: Optional[str] = None
    """Criteria used for monthly volume calculations."""

    fee_symbol_classification: Optional[str] = None
    """Symbol classification (e.g., ``"ETF"``, ``"Equity"``)."""

    fee_symbol_type: Optional[str] = None
    """Symbol type (e.g., ``"Penny"``, ``"Non Penny"``)."""

    fee_trade_type: Optional[str] = None
    """Trade type (e.g., ``"Simple Order"``, ``"Complex Order"``)."""

    fee_symbol: Optional[str] = None
    """Specific symbol this fee applies to."""

    fee_excluded_symbols: Optional[str] = None
    """Symbols excluded from this fee."""

    fee_conditions: Optional[str] = None
    """Conditions under which this fee applies."""

    fee_exclusions: Optional[str] = None
    """Exclusions from this fee."""

    fee_extra_info: Optional[str] = None
    """Additional information about the fee."""

    version_id: Optional[str] = None
    """Extraction version identifier."""

    scraped_time: Optional[str] = None
    """Timestamp when the data was scraped."""

    created_on: Optional[str] = None
    """Timestamp when the record was created."""
