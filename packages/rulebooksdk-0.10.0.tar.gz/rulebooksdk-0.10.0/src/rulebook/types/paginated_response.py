"""Paginated response model."""

from __future__ import annotations

from typing import Generic, List, Optional, TypeVar

from rulebook._models import BaseModel

__all__ = ["PaginatedResponse"]

_T = TypeVar("_T")


class PaginatedResponse(BaseModel, Generic[_T]):
    """Paginated list response with metadata.

    The ``data`` field contains the list of results for the current page.
    """

    data: List[_T]
    """List of results for the current page."""

    total_records: int
    """Total number of records matching the query."""

    page_size: int
    """Number of records per page."""

    total_pages: int
    """Total number of pages."""

    current_page: int
    """Current page number (zero-based)."""

    query_time: Optional[float] = None
    """Server-side query execution time in seconds."""
