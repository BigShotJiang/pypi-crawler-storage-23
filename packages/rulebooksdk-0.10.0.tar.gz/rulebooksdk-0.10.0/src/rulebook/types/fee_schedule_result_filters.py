"""Fee schedule result filter values model."""

from __future__ import annotations

from typing import List

from rulebook._models import BaseModel

__all__ = ["FeeScheduleResultFilters"]


class FeeScheduleResultFilters(BaseModel):
    exchange_names: List[str]
    """Available exchange names."""

    fee_types: List[str]
    """Available fee types (e.g., ``["Equity", "Option"]``)."""

    fee_categories: List[str]
    """Available fee categories."""

    fee_actions: List[str]
    """Available trading action types."""

    fee_participants: List[str]
    """Available participant types."""

    fee_symbol_classifications: List[str]
    """Available symbol classifications."""

    fee_symbol_types: List[str]
    """Available symbol types."""

    fee_trade_types: List[str]
    """Available trade types."""
