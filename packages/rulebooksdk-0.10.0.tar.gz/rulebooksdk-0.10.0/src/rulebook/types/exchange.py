"""Exchange summary model."""

from __future__ import annotations

from typing import List

from rulebook._models import BaseModel

__all__ = ["Exchange"]


class Exchange(BaseModel):
    name: str
    """Exchange identifier used in API queries (e.g., ``"NYSE"``, ``"CBOE"``)."""

    display_name: str
    """Human-readable exchange name (e.g., ``"New York Stock Exchange"``)."""

    fee_types: List[str]
    """Fee types available for this exchange (e.g., ``["Equity", "Option"]``)."""

    record_count: int
    """Total fee schedule records available for this exchange."""
