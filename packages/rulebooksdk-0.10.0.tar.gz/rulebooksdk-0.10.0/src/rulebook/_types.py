"""SDK-internal type aliases."""

from __future__ import annotations

from typing import Any, Mapping, TypeVar, Union

import httpx
from typing_extensions import Literal, TypedDict, override

Headers = Mapping[str, str]
Query = Mapping[str, object]
Body = object


class RequestOptions(TypedDict, total=False):
    headers: Headers
    max_retries: int
    timeout: float | httpx.Timeout | None
    params: Query


class NotGiven:
    """Sentinel to distinguish omitted keyword arguments from None.

    Example::

        def get(timeout: float | NotGiven | None = NOT_GIVEN) -> Response: ...

        get(timeout=1)     # 1s timeout
        get(timeout=None)  # No timeout
        get()              # Default timeout behavior
    """

    def __bool__(self) -> Literal[False]:
        return False

    @override
    def __repr__(self) -> str:
        return "NOT_GIVEN"


NOT_GIVEN = NotGiven()


def is_given(value: object) -> bool:
    """Return True if the value was explicitly provided (not NOT_GIVEN)."""
    return not isinstance(value, NotGiven)


def make_request_options(
    *,
    extra_headers: Headers | None = None,
    extra_query: Query | None = None,
    timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
) -> RequestOptions:
    """Build a RequestOptions dict from per-request overrides."""
    options: RequestOptions = {}

    if extra_headers is not None:
        options["headers"] = extra_headers

    if extra_query is not None:
        options["params"] = extra_query

    if is_given(timeout):
        options["timeout"] = timeout  # type: ignore[assignment]

    return options
