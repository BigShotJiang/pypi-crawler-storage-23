"""API resource classes."""

from __future__ import annotations

from rulebook.resources.exchanges import (
    AsyncExchanges as AsyncExchanges,
    AsyncExchangesWithRawResponse as AsyncExchangesWithRawResponse,
    Exchanges as Exchanges,
    ExchangesWithRawResponse as ExchangesWithRawResponse,
)
from rulebook.resources.fee_schedule_results import (
    AsyncFeeScheduleResults as AsyncFeeScheduleResults,
    AsyncFeeScheduleResultsWithRawResponse as AsyncFeeScheduleResultsWithRawResponse,
    FeeScheduleResults as FeeScheduleResults,
    FeeScheduleResultsWithRawResponse as FeeScheduleResultsWithRawResponse,
)

__all__ = [
    "Exchanges",
    "AsyncExchanges",
    "ExchangesWithRawResponse",
    "AsyncExchangesWithRawResponse",
    "FeeScheduleResults",
    "AsyncFeeScheduleResults",
    "FeeScheduleResultsWithRawResponse",
    "AsyncFeeScheduleResultsWithRawResponse",
]
