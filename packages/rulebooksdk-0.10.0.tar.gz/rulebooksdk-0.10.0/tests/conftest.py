"""Shared fixtures for Rulebook SDK tests."""

from __future__ import annotations

import os
from pathlib import Path

import httpx
import pytest

from rulebook import AsyncRulebook, Rulebook

BASE_URL = "https://api.rulebook.company/api/v1"

# ---------------------------------------------------------------------------
# Unit-test fixtures (httpx mock transport)
# ---------------------------------------------------------------------------


@pytest.fixture
def client(httpx_mock) -> Rulebook:
    """Sync Rulebook client wired to the httpx mock transport."""
    return Rulebook(api_key="test-key", base_url=BASE_URL, max_retries=0)


@pytest.fixture
def async_client(httpx_mock) -> AsyncRulebook:
    """Async Rulebook client wired to the httpx mock transport."""
    return AsyncRulebook(api_key="test-key", base_url=BASE_URL, max_retries=0)

