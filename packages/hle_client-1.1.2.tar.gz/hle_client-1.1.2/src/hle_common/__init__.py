"""HLE Common — Shared types and utilities between client and server."""

__version__ = "0.1.2"
