import turtle as tu

def draw(coords_with_color):
    screen = tu.Screen()
    screen.colormode(255) 
    t = tu.Turtle()
    screen.title("Painter")
    t.shape('turtle') 
    t.speed(0)
    screen.tracer(10) 

    for pos, color in coords_with_color:
        x, y = pos
        t.penup()
        t.goto(x - 200, 200 - y)
        t.pendown()
        
        
        t.pencolor(color)
        t.dot(3) 

    screen.update()
    tu.done()