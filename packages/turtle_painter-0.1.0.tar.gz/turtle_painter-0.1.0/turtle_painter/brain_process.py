import cv2
import numpy as np

def drawing_path(image_path):
   
    img_color = cv2.imread(image_path)

 
    img_color = cv2.resize(img_color, (400, 400))
    

    img_gray = cv2.cvtColor(img_color, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(img_gray, 100, 200)
    

    indices = np.where(edges == 255)
    
    coords_with_color = []

    for y, x in zip(indices[0], indices[1]):
        
        b, g, r = img_color[y, x]
        color = (int(r), int(g), int(b)) 
        
        coords_with_color.append(((x, y), color))
        
    return coords_with_color