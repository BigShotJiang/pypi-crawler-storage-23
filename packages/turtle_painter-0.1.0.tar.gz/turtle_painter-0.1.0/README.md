# Turtle Painter 

A Python package that uses computer vision to detect edges in images and draws them in real-time using Turtle graphics!!

## Installation
```bash
pip install turtle_painter