"""Semantic API MCP Server."""

import json
import os

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Semantic API")

BASE_URL = os.environ.get("SEMANTIC_API_URL", "https://semanticapi.dev")


def _get_api_key() -> str:
    key = os.environ.get("SEMANTIC_API_KEY", "")
    if not key:
        raise ValueError(
            "SEMANTIC_API_KEY environment variable is required. "
            "Get your API key at https://semanticapi.dev"
        )
    return key


def _headers() -> dict[str, str]:
    return {
        "X-API-Key": _get_api_key(),
        "Content-Type": "application/json",
    }


async def _post(path: str, payload: dict) -> str:
    """Make a POST request and return formatted JSON response."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(f"{BASE_URL}{path}", json=payload, headers=_headers())
        resp.raise_for_status()
        return json.dumps(resp.json(), indent=2)


async def _get(path: str, params: dict | None = None) -> dict:
    """Make a GET request and return parsed JSON response."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(f"{BASE_URL}{path}", params=params)
        resp.raise_for_status()
        return resp.json()


def _format_provider_list(data: dict) -> str:
    """Format catalog listing for human + agent readability."""
    lines = []
    providers = data.get("providers") or data.get("results") or []
    for p in providers:
        pid = p.get("id") or p.get("provider_id", "")
        name = p.get("name", pid)
        desc = p.get("description", "")
        auth = p.get("auth_type", "unknown")
        free = "yes" if p.get("free_tier") else "no"
        caps = p.get("capability_count", 0) or len(p.get("capabilities", []))
        signup = p.get("signup_url", "")
        lines.append(f"📦 {name} ({pid})")
        if desc:
            lines.append(f"   {desc}")
        lines.append(f"   Auth: {auth} | Free tier: {free} | Capabilities: {caps}")
        if signup:
            lines.append(f"   Signup: {signup}")
        lines.append("")

    total = data.get("total", len(providers))
    page = data.get("page", 1)
    total_pages = data.get("total_pages", 1)
    lines.append(f"Page {page}/{total_pages} ({total} total providers)")
    return "\n".join(lines)


def _format_provider_detail(p: dict) -> str:
    """Format full provider detail."""
    lines = []
    pid = p.get("id") or p.get("provider_id", "")
    name = p.get("name", pid)
    desc = p.get("description", "")
    lines.append(f"📦 {name} ({pid})")
    if desc:
        lines.append(f"   {desc}")
    if p.get("base_url"):
        lines.append(f"   Base URL: {p['base_url']}")
    if p.get("auth_type"):
        lines.append(f"   Auth: {p['auth_type']}")
    if p.get("signup_url"):
        lines.append(f"   Signup: {p['signup_url']}")
    if p.get("setup_steps"):
        steps = p["setup_steps"]
        if isinstance(steps, list):
            steps_str = " ".join(f"{i+1}. {s}" for i, s in enumerate(steps))
        else:
            steps_str = str(steps)
        lines.append(f"   Steps: {steps_str}")
    free = p.get("free_tier")
    if free is not None:
        free_detail = p.get("free_tier_details", "")
        free_str = "yes" if free else "no"
        if free_detail:
            free_str += f" ({free_detail})"
        lines.append(f"   Free tier: {free_str}")

    capabilities = p.get("capabilities", [])
    if capabilities:
        lines.append("")
        lines.append("   Capabilities:")
        for i, cap in enumerate(capabilities):
            is_last = i == len(capabilities) - 1
            prefix = "└─" if is_last else "├─"
            cont = "   " if is_last else "│  "
            cap_id = cap.get("id") or cap.get("capability_id", "")
            cap_desc = cap.get("description", "")
            method = cap.get("method", "").upper()
            path = cap.get("path", "")
            lines.append(f"   {prefix} {cap_id}: {cap_desc}")
            if method and path:
                lines.append(f"   {cont} {method} {path}")

    return "\n".join(lines)


@mcp.tool()
async def semantic_query(query: str, auto_discover: bool = True) -> str:
    """Search for an API capability using natural language.

    Returns endpoint details, parameters, auth info, and code snippets.

    Args:
        query: Natural language description of what you want to do (e.g. "send an email with Gmail")
        auto_discover: Whether to automatically discover new APIs if no cached result exists
    """
    try:
        return await _post("/api/query", {"query": query, "auto_discover": auto_discover})
    except ValueError as e:
        return str(e)
    except httpx.HTTPStatusError as e:
        return f"API error {e.response.status_code}: {e.response.text}"
    except Exception as e:
        return f"Error: {e}"


@mcp.tool()
async def semantic_discover(provider_name: str, user_intent: str | None = None) -> str:
    """Deep discovery of a specific provider/API by name and intent.

    Args:
        provider_name: Name of the API provider (e.g. "stripe", "twilio", "github")
        user_intent: Optional description of what you want to do with this API
    """
    try:
        payload: dict = {"provider_name": provider_name}
        if user_intent:
            payload["user_intent"] = user_intent
        return await _post("/api/discover/search", payload)
    except ValueError as e:
        return str(e)
    except httpx.HTTPStatusError as e:
        return f"API error {e.response.status_code}: {e.response.text}"
    except Exception as e:
        return f"Error: {e}"


@mcp.tool()
async def semantic_discover_url(url: str, user_intent: str | None = None) -> str:
    """Analyze any API from its documentation URL. Generates a full provider config.

    Args:
        url: URL of the API documentation to analyze
        user_intent: Optional description of what you want to do with this API
    """
    try:
        payload: dict = {"url": url}
        if user_intent:
            payload["user_intent"] = user_intent
        return await _post("/api/discover/from-url", payload)
    except ValueError as e:
        return str(e)
    except httpx.HTTPStatusError as e:
        return f"API error {e.response.status_code}: {e.response.text}"
    except Exception as e:
        return f"Error: {e}"


@mcp.tool()
async def semantic_catalog(
    page: int = 1,
    auth_type: str | None = None,
    category: str | None = None,
    search: str | None = None,
    free_only: bool = False,
) -> str:
    """Browse the Semantic API provider catalog. No API key required.

    Args:
        page: Page number (starts at 1)
        auth_type: Filter by auth type (e.g. "bearer", "apikey", "oauth2", "none")
        category: Filter by category (e.g. "payments", "ai", "communication")
        search: Search providers by name or description
        free_only: Only show providers with a free tier
    """
    try:
        params: dict = {"page": page}
        if auth_type:
            params["auth_type"] = auth_type
        if category:
            params["category"] = category
        if search:
            params["search"] = search
        if free_only:
            params["free_only"] = "true"
        data = await _get("/api/catalog", params)
        return _format_provider_list(data)
    except httpx.HTTPStatusError as e:
        return f"API error {e.response.status_code}: {e.response.text}"
    except Exception as e:
        return f"Error: {e}"


@mcp.tool()
async def semantic_provider_detail(provider_id: str) -> str:
    """Get full details for a specific API provider, including all capabilities. No API key required.

    Args:
        provider_id: The provider identifier (e.g. "stripe", "open-meteo", "github")
    """
    try:
        data = await _get(f"/api/catalog/{provider_id}")
        return _format_provider_detail(data)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return f"Provider '{provider_id}' not found."
        return f"API error {e.response.status_code}: {e.response.text}"
    except Exception as e:
        return f"Error: {e}"


@mcp.tool()
async def semantic_catalog_stats() -> str:
    """Get public statistics about the Semantic API catalog. No API key required.

    Returns total providers, capabilities, categories, and other stats.
    """
    try:
        data = await _get("/api/catalog/stats")
        lines = ["📊 Semantic API Catalog Stats"]
        for key, value in data.items():
            label = key.replace("_", " ").title()
            lines.append(f"   {label}: {value}")
        return "\n".join(lines)
    except httpx.HTTPStatusError as e:
        return f"API error {e.response.status_code}: {e.response.text}"
    except Exception as e:
        return f"Error: {e}"


@mcp.tool()
async def semantic_categories() -> str:
    """List all available provider categories in the Semantic API catalog. No API key required."""
    try:
        data = await _get("/api/catalog/categories")
        categories = data if isinstance(data, list) else data.get("categories", [])
        if not categories:
            return "No categories found."
        lines = ["📂 Provider Categories", ""]
        for cat in categories:
            if isinstance(cat, dict):
                name = cat.get("name", cat.get("id", ""))
                count = cat.get("count", "")
                lines.append(f"   • {name}" + (f" ({count} providers)" if count else ""))
            else:
                lines.append(f"   • {cat}")
        return "\n".join(lines)
    except httpx.HTTPStatusError as e:
        return f"API error {e.response.status_code}: {e.response.text}"
    except Exception as e:
        return f"Error: {e}"


def main():
    """Run the MCP server with stdio transport."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
