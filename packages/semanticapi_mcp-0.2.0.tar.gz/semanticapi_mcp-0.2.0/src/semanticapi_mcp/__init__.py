"""Semantic API MCP Server - Use Semantic API as a tool in Claude, ChatGPT, and other LLM agents."""

__version__ = "0.1.0"
