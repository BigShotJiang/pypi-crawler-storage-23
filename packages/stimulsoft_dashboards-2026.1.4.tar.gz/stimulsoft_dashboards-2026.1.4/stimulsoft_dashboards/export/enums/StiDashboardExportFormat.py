from enum import Enum


class StiDashboardExportFormat(Enum):

    PDF = 1
    EXCEL = 2
    DATA = 3
    IMAGE = 4
    HTML = 6
