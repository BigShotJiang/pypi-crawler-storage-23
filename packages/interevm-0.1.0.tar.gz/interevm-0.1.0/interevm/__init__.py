"""interevm — async EVM/Web3 library for Python."""

from .contract import (
    ABIEvent,
    ABIFunction,
    Contract,
    MulticallHelper,
)
from .rpc_client import (
    CallRequest,
    RPCClient,
    RPCConfig,
    RPCError,
    compute_event_topic,
    compute_function_selector,
    ensure_hex_prefix,
    format_tx_dict,
    mkdata,
    rpc_retry,
    topic_from_address,
    topic_from_uint,
)

__version__ = "0.1.0"

__all__ = [
    # RPC client
    "RPCClient",
    "RPCConfig",
    "RPCError",
    "CallRequest",
    "rpc_retry",
    "mkdata",
    "format_tx_dict",
    "compute_function_selector",
    "compute_event_topic",
    "topic_from_address",
    "topic_from_uint",
    "ensure_hex_prefix",
    # Contract / ABI
    "Contract",
    "ABIFunction",
    "ABIEvent",
    "MulticallHelper",
]
