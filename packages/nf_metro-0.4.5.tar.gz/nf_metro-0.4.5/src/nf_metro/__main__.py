"""Allow running as: python -m nf_metro"""

from nf_metro.cli import cli

if __name__ == "__main__":
    cli()
