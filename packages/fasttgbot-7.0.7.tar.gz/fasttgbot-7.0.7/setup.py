from setuptools import setup

setup(
    name="fasttgbot",
    version="7.0.7",
    description="🤖 Простой Telegram бот с AI генерацией",
    long_description="Создай бота в 3 строки! AI автоматически генерирует функции!",
    author="Your Name",
    author_email="your@email.com",
    py_modules=["fasttgbot"],
    install_requires=["pytelegrambotapi", "mistralai"],
)