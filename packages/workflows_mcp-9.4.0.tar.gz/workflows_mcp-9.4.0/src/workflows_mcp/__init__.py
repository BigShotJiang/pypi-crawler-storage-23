"""Workflows MCP Server - DAG-based workflow execution for Claude Code."""

__version__ = "9.4.0"

__all__ = ["__version__"]
