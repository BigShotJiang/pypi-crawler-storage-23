"""_____________________________________________________________________

:PROJECT: ChemDataReader

* Main module formal interface. *

:details: In larger projects, formal interfaces are helping to define a trustable contract.
          Currently there are two commonly used approaches: 
          [ABCMetadata](https://docs.python.org/3/library/abc.html) or [Python Protocols](https://peps.python.org/pep-0544/)

       see also:
       ABC metaclass
         - https://realpython.com/python-interface/
         - https://dev.to/meseta/factories-abstract-base-classes-and-python-s-new-protocols-structural-subtyping-20bm

.. note:: -
.. todo:: - 
________________________________________________________________________
"""


from abc import ABCMeta, abstractmethod
import asyncio


class ChemDatReaderInterface(metaclass=ABCMeta):
    """ChemDatReader formal Interface
    TODO: test, if ABC baseclass is wor
    """

    @classmethod
    def __subclasshook__(cls, subclass):
        return hasattr(subclass, "read_csv") and callable(subclass.read_csv) or NotImplemented
        return NotImplemented

    @classmethod
    @abstractmethod
    async def read_substance_names_csv(self, csv_filename: str = None) -> str:
        """csv reader module

        :param name: person to greet
        :type name: str
        """
        raise NotImplementedError

    @classmethod
    @abstractmethod
    async def get_compounds_by_name(self, name_list: list[str] = [], operation: str = None, output_format: str = None, as_dict: bool = False):
        """
        get all compounds of a list of names or CAS numbers
        """
        raise NotImplementedError
