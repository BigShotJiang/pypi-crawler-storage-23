# pubchem data models

from pydantic import BaseModel
from typing import List, Optional, Dict

class Id(BaseModel):
    cid: int

class IdWrapper(BaseModel):
    id: Id

class Atoms(BaseModel):
    aid: List[int]
    element: List[int]

class Bonds(BaseModel):
    aid1: List[int]
    aid2: List[int]
    order: List[int]

class Style(BaseModel):
    annotation: List[int]
    aid1: List[int]
    aid2: List[int]

class Conformers(BaseModel):
    x: List[float]
    y: List[float]
    style: Style

class Coords(BaseModel):
    type: List[int]
    aid: List[int]
    conformers: List[Conformers]

class Urn(BaseModel):
    label: Optional[str] = None
    name: Optional[str] = None
    datatype: Optional[int]
    release: Optional[str]
    implementation: Optional[str] = None
    version: Optional[str] = None
    software: Optional[str] = None
    source: Optional[str] = None
    parameters: Optional[str] = None

class Value(BaseModel):
    sval: Optional[str] = None
    ival: Optional[int] = None
    fval: Optional[float] = None
    binary: Optional[str] = None

class Prop(BaseModel):
    urn: Urn
    value: Value

class Count(BaseModel):
    heavy_atom: int
    atom_chiral: int
    atom_chiral_def: int
    atom_chiral_undef: int
    bond_chiral: int
    bond_chiral_def: int
    bond_chiral_undef: int
    isotope_atom: int
    covalent_unit: int
    tautomers: int

class PCCompound(BaseModel):
    id: IdWrapper
    atoms: Atoms
    bonds: Bonds
    coords: List[Coords]
    charge: int
    props: List[Prop]
    count: Count

class PubChemRecord(BaseModel):
    PC_Compounds: List[PCCompound]