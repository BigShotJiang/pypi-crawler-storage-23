"""_____________________________________________________________________

:PROJECT: ChemDataReader

* Main module formal interface. *

:details: In larger projects, formal interfaces are helping to define a trustable contract.
          Currently there are two commonly used approaches: 
          [ABCMetadata](https://docs.python.org/3/library/abc.html) or [Python Protocols](https://peps.python.org/pep-0544/)

       see also:
       ABC metaclass
         - https://realpython.com/python-interface/
         - https://dev.to/meseta/factories-abstract-base-classes-and-python-s-new-protocols-structural-subtyping-20bm

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

from typing import Any
import asyncio
import chemdatareader.object_factory as object_factory

# here is a
from abc import ABCMeta, abstractmethod


class ChemDatCollectorBuilderInterface(metaclass=ABCMeta):
    """ChemDatReader formal Interface
    TODO: test, if ABC baseclass is wor
    """

    @classmethod
    def __subclasshook__(cls, subclass):
        # return (hasattr(subclass, 'test_connection') and
        #         callable(subclass.test_connection) or
        #         NotImplemented)
        return NotImplemented


class ChemDataCollectorInterface(metaclass=ABCMeta):
    """ChemDatReader formal Interface
    TODO: test, if ABC baseclass is wor
    """

    @classmethod
    def __subclasshook__(cls, subclass):
        return hasattr(subclass, "test_connection") and callable(subclass.test_connection) or NotImplemented

    def test_connection(self) -> str:
        """csv reader module

        :param name: person to greet
        :type name: str
        """
        raise NotImplementedError
    
    async def get_compounds_by_name(
        self, name_list: list[str] = [], operation: str = None, output_format: str = None,
        as_dict: bool = False
    ):
        """
        get all compounds of a list of names or CAS numbers
        """
        raise NotImplementedError
    
    def properties_to_dict(self, record: Any):
        """
        convert properties to dict
        """
        raise NotImplementedError


class ChemDataService(object_factory.ObjectFactory):
    """ChemDataService is a factory for ChemDatReaderBuilderInterface"""

    def get(self, service_id, **kwargs):
        return self.create(service_id.strip().lower(), **kwargs)


services = ChemDataService()
