"""fixos – AI-powered Linux/Windows diagnostics and repair."""
__version__ = "2.1.16"
