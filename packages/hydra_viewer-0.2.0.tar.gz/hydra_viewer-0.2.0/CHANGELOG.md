## v0.2.0 (2026-02-25)

### BREAKING CHANGE

- first implementation of the whole app

### Feat

- **app**: implement hydra_viewer TUI application
