#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from __future__ import annotations

from dataclasses import dataclass, field

import pytest
from fastapi.testclient import TestClient

from pyedc_dataplane import create_signaling_api
from pyedc_dataplane.crud.transfers import InMemoryTransferRepository
from pyedc_dataplane.schemas.json_ld_model import DataAddress, ns
from pyedc_dataplane.services.signaling import TransferInstructionConsumer

NS = "https://w3id.org/edc/v0.0.1/ns/"


@dataclass
class RecordingInstructionConsumer(TransferInstructionConsumer):
    """Test consumer that records messages and returns deterministic addresses."""

    started: list = field(default_factory=list)
    suspended: list = field(default_factory=list)
    terminated: list = field(default_factory=list)

    def on_start(self, message):
        self.started.append(message)
        return DataAddress(
            properties={ns("from"): "consumer"},  # usually better as plain key
            **{
                ns("endpoint"): f"https://consumer.local/{message.processId}",
                ns("authorization"): f"token-{message.processId}",
            },
        )

    def on_suspend(self, message):
        self.suspended.append(message)

    def on_terminate(self, message):
        self.terminated.append(message)


@pytest.fixture
def client_with_consumer():
    consumer = RecordingInstructionConsumer()
    repository = InMemoryTransferRepository()
    app = create_signaling_api(
        instruction_consumer=consumer,
        transfer_repository=repository,
    )
    client = TestClient(app)
    try:
        yield client, consumer, repository
    finally:
        client.close()


def build_start_payload():
    return {
        "@context": {"@vocab": NS},
        "@id": "transfer-id",
        "@type": "DataFlowStartMessage",
        "processId": "process-id",
        "datasetId": "dataset-id",
        "participantId": "participant-id",
        "agreementId": "agreement-id",
        "transferType": "HttpData-PULL",
        "sourceDataAddress": {
            "type": "HttpData",
            "baseUrl": "https://jsonplaceholder.typicode.com/todos",
        },
        "destinationDataAddress": {
            "type": "HttpData",
            "baseUrl": "https://jsonplaceholder.typicode.com/todos",
        },
        "callbackAddress": "http://control-plane",
        "properties": {"key": "value"},
    }


def test_signaling_flow_invokes_consumer(client_with_consumer):
    client, consumer, repository = client_with_consumer
    payload = build_start_payload()

    response = client.post("/signaling/v1/dataflows", json=payload)
    assert response.status_code == 200
    body = response.json()
    data_address = body["dataAddress"]
    assert data_address["endpoint"] == f"https://consumer.local/{payload['processId']}"
    assert data_address["authorization"] == f"token-{payload['processId']}"
    assert len(consumer.started) == 1
    record = repository.get(payload["processId"])
    assert record is not None and record.state == "STARTED"

    suspend = {
        "@context": {"@vocab": NS},
        "@type": "DataFlowSuspendMessage",
        "processId": payload["processId"],
        "reason": "maintenance",
    }
    suspend_response = client.post("/signaling/v1/dataflows", json=suspend)
    assert suspend_response.status_code == 200
    assert len(consumer.suspended) == 1
    record = repository.get(payload["processId"])
    assert record.state == "SUSPENDED"

    terminate = {
        "@context": {"@vocab": NS},
        "@type": "DataFlowTerminateMessage",
        "processId": payload["processId"],
        "reason": "complete",
    }
    terminate_response = client.post("/signaling/v1/dataflows", json=terminate)
    assert terminate_response.status_code == 200
    assert terminate_response.json()["status"] == "acknowledged"
    assert len(consumer.terminated) == 1
    record = repository.get(payload["processId"])
    assert record.state == "TERMINATED"
