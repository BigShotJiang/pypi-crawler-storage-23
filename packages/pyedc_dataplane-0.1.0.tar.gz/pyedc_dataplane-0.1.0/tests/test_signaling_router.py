#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from unittest.mock import create_autospec

import pytest
from fastapi.testclient import TestClient

from pyedc_dataplane import create_signaling_api
from pyedc_dataplane.dependencies import get_signaling_service
from pyedc_dataplane.schemas.json_ld_model import DataAddress, ns
from pyedc_dataplane.services.signaling import (
    SignalingService,
    TransferInstructionError,
)

NS = "https://w3id.org/edc/v0.0.1/ns/"


@pytest.fixture
def client_with_service():
    api_app = create_signaling_api()
    mock_service = create_autospec(SignalingService)
    api_app.dependency_overrides[get_signaling_service] = lambda: mock_service
    client = TestClient(api_app)
    try:
        yield client, mock_service
    finally:
        api_app.dependency_overrides.pop(get_signaling_service, None)
        client.close()


def build_start_payload():
    return {
        "@context": {"@vocab": NS},
        "@id": "transfer-id",
        "@type": "DataFlowStartMessage",
        "processId": "process-id",
        "datasetId": "dataset-id",
        "participantId": "participant-id",
        "agreementId": "agreement-id",
        "transferType": "HttpData-PULL",
        "sourceDataAddress": {
            "type": "HttpData",
            "baseUrl": "https://jsonplaceholder.typicode.com/todos",
        },
        "destinationDataAddress": {
            "type": "HttpData",
            "baseUrl": "https://jsonplaceholder.typicode.com/todos",
        },
        "callbackAddress": "http://control-plane",
        "properties": {"key": "value"},
    }


def test_start_message_returns_data_address(client_with_service):
    client, service = client_with_service
    mocked_address = DataAddress(
        **{
            ns("endpoint"): "https://dataplane.local/public/process-id",
            ns("authorization"): "token-123",
            ns("endpointType"): "https://w3id.org/idsa/v4.1/HTTP"
        },
        properties={ns("transferType"): "HttpData-PULL"},
    )
    service.handle_start.return_value = mocked_address
    payload = build_start_payload()
    response = client.post("/signaling/v1/dataflows", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["@type"] == "DataFlowResponseMessage"
    data_address = data["dataAddress"]
    assert data_address["authorization"] == "token-123"
    assert data_address["endpointType"] == "https://w3id.org/idsa/v4.1/HTTP"
    assert data["provisioning"] is False
    service.handle_start.assert_called_once()


def test_suspend_and_terminate_acknowledgements(client_with_service):
    client, service = client_with_service
    payload = build_start_payload()
    mocked_address = DataAddress(
        endpoint="https://dataplane.local/public/process-id",
        authorization="token",
        properties={},
    )
    service.handle_start.return_value = mocked_address
    client.post("/signaling/v1/dataflows", json=payload)
    service.handle_start.assert_called_once()
    service.handle_start.reset_mock()
    suspend = {
        "@context": {"@vocab": NS},
        "@type": "DataFlowSuspendMessage",
        "processId": payload["processId"],
        "reason": "maintenance",
    }
    suspend_response = client.post("/signaling/v1/dataflows", json=suspend)
    assert suspend_response.status_code == 200
    suspend_body = suspend_response.json()
    assert suspend_body["detail"].startswith("Transfer process-id suspended")
    service.handle_suspend.assert_called_once()
    suspend_message = service.handle_suspend.call_args[0][0]
    assert suspend_message.processId == payload["processId"]

    terminate = {
        "@context": {"@vocab": NS},
        "@type": "DataFlowTerminateMessage",
        "processId": payload["processId"],
        "reason": "complete",
    }
    terminate_response = client.post("/signaling/v1/dataflows", json=terminate)
    assert terminate_response.status_code == 200
    body = terminate_response.json()
    assert body["status"] == "acknowledged"
    assert "terminated" in body["detail"]
    service.handle_terminate.assert_called_once()
    terminate_message = service.handle_terminate.call_args[0][0]
    assert terminate_message.processId == payload["processId"]


def test_start_message_returns_consumer_error(client_with_service):
    client, service = client_with_service
    service.handle_start.side_effect = TransferInstructionError(
        "consumer refused", status_code=409
    )
    response = client.post("/signaling/v1/dataflows", json=build_start_payload())

    assert response.status_code == 409
    assert response.json()["detail"] == "consumer refused"
