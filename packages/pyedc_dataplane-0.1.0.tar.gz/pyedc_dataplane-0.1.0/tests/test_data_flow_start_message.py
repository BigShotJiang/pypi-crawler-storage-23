#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from pyedc_core.utils.json_ld_transformer import JsonLdTransformer
from pyedc_dataplane.schemas.json_ld_model import DataFlowStartMessage, ns

sample_payload = {
    "@context": {"@vocab": "https://w3id.org/edc/v0.0.1/ns/"},
    "@id": "transfer-id",
    "@type": "DataFlowStartMessage",
    "processId": "process-id",
    "datasetId": "dataset-id",
    "participantId": "participant-id",
    "agreementId": "agreement-id",
    "transferType": "HttpData-PULL",
    "sourceDataAddress": {
        "type": "HttpData",
        "baseUrl": "https://jsonplaceholder.typicode.com/todos",
    },
    "destinationDataAddress": {
        "type": "HttpData",
        "baseUrl": "https://jsonplaceholder.typicode.com/todos",
    },
    "callbackAddress": "http://control-plane",
    "properties": {"key": "value"},
}


def test_data_flow_start_message_model():
    transformer = JsonLdTransformer()
    expanded = transformer.expand(sample_payload)
    msg = DataFlowStartMessage(**expanded)
    assert msg.id == "transfer-id"
    assert "https://w3id.org/edc/v0.0.1/ns/DataFlowStartMessage" in msg.type
    sourceBaseUrl = msg.sourceDataAddress.model_extra[ns("baseUrl")]
    assert sourceBaseUrl
    assert sourceBaseUrl.endswith("/todos")
    assert msg.properties["https://w3id.org/edc/v0.0.1/ns/key"] == "value"
