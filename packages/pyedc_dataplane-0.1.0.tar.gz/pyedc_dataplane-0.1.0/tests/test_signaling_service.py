#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import Mock, create_autospec, patch

import pytest
from pyedc_core.utils.json_ld_transformer import JsonLdTransformer
from pyedc_dataplane.crud.transfers import TransferRecord, TransferRepository
from pyedc_dataplane.schemas.json_ld_model import (
    DataAddress,
    DataFlowStartMessage,
    DataFlowSuspendMessage,
    DataFlowTerminateMessage,
)
from pyedc_dataplane.services.signaling import (
    SignalingService,
    TransferInstructionConsumer,
    TransferInstructionError,
)

NS = "https://w3id.org/edc/v0.0.1/ns/"


def build_start_message() -> DataFlowStartMessage:
    return _build_message(
        {
            "@type": "DataFlowStartMessage",
            "processId": "process-id",
            "datasetId": "dataset-id",
            "participantId": "participant-id",
            "agreementId": "agreement-id",
            "transferType": "HttpData-PULL",
            "sourceDataAddress": {"type": "HttpData", "baseUrl": "https://example.com/src"},
            "destinationDataAddress": {"type": "HttpData", "baseUrl": "https://example.com/dst"},
            "callbackAddress": "http://control-plane",
            "properties": {"key": "value"},
        },
        DataFlowStartMessage,
    )


def build_suspend_message(process_id: str = "process-id") -> DataFlowSuspendMessage:
    return _build_message(
        {"@type": "DataFlowSuspendMessage", "processId": process_id, "reason": "maintenance"},
        DataFlowSuspendMessage,
    )


def build_terminate_message(process_id: str = "process-id") -> DataFlowTerminateMessage:
    return _build_message(
        {"@type": "DataFlowTerminateMessage", "processId": process_id, "reason": "complete"},
        DataFlowTerminateMessage,
    )


def _build_message(payload: dict, model_cls):
    body = {
        "@context": {"@vocab": NS},
        "@id": "transfer-id",
    }
    body.update(payload)
    transformer = JsonLdTransformer()
    expanded = transformer.expand(body)
    return model_cls(**expanded)


def test_handle_start_creates_record():
    repo = create_autospec(TransferRepository)
    repo.get.return_value = None
    message = build_start_message()
    stub_uuid = SimpleNamespace(hex="tok-1")
    with patch("pyedc_dataplane.services.signaling.uuid4", return_value=stub_uuid):
        service = SignalingService(
            repository=repo,
            endpoint_resolver=lambda msg: f"https://api.local/{msg.processId}",
        )
        result = service.handle_start(message)

    assert result.authorization == "tok-1"
    repo.save.assert_called_once()
    saved_record = repo.save.call_args[0][0]
    assert saved_record.process_id == "process-id"
    assert saved_record.state == "STARTED"


def test_handle_start_returns_existing_address():
    repo = create_autospec(TransferRepository)
    stored_address = DataAddress(
        endpoint="https://api.local/process-id",
        authorization="existing-token",
        properties={},
    )
    record = TransferRecord(
        process_id="process-id",
        agreement_id="agreement-id",
        participant_id="participant-id",
        dataset_id="dataset-id",
        transfer_type="HttpData-PULL",
        source_address={},
        destination_address={},
        callback_address="http://callback",
        properties={},
        state="STARTED",
        data_address=stored_address.model_dump(by_alias=True, exclude_none=True),
    )
    repo.get.return_value = record
    service = SignalingService(repository=repo)

    result = service.handle_start(build_start_message())

    assert result.authorization == "existing-token"
    repo.save.assert_not_called()


def test_handle_start_waits_for_consumer_data_address():
    repo = create_autospec(TransferRepository)
    repo.get.return_value = None
    provided_address = DataAddress(
        endpoint="https://consumer.local/process-id",
        authorization="consumer-token",
        properties={"from": "consumer"},
    )
    consumer = Mock(spec=TransferInstructionConsumer)
    consumer.on_start.return_value = provided_address
    service = SignalingService(repository=repo, instruction_consumer=consumer)
    message = build_start_message()

    result = service.handle_start(message)

    assert result is provided_address
    consumer.on_start.assert_called_once_with(message)
    repo.save.assert_called_once()


def test_handle_suspend_updates_state_and_notifies_consumer():
    repo = create_autospec(TransferRepository)
    record = TransferRecord(
        process_id="process-id",
        agreement_id="agreement-id",
        participant_id="participant-id",
        dataset_id="dataset-id",
        transfer_type="HttpData-PULL",
        source_address={},
        destination_address={},
        callback_address="http://callback",
        properties={},
        state="STARTED",
    )
    repo.get.return_value = record
    consumer = Mock(spec=TransferInstructionConsumer)
    service = SignalingService(repository=repo, instruction_consumer=consumer)
    message = build_suspend_message()

    returned = service.handle_suspend(message)

    assert returned is record
    assert record.state == "SUSPENDED"
    consumer.on_suspend.assert_called_once_with(message)
    repo.save.assert_called_once_with(record)


def test_handle_terminate_updates_state_and_notifies_consumer():
    repo = create_autospec(TransferRepository)
    record = TransferRecord(
        process_id="process-id",
        agreement_id="agreement-id",
        participant_id="participant-id",
        dataset_id="dataset-id",
        transfer_type="HttpData-PULL",
        source_address={},
        destination_address={},
        callback_address="http://callback",
        properties={},
        state="STARTED",
    )
    repo.get.return_value = record
    consumer = Mock(spec=TransferInstructionConsumer)
    service = SignalingService(repository=repo, instruction_consumer=consumer)
    message = build_terminate_message()

    returned = service.handle_terminate(message)

    assert returned is record
    assert record.state == "TERMINATED"
    consumer.on_terminate.assert_called_once_with(message)
    repo.save.assert_called_once_with(record)


def test_handle_start_propagates_transfer_instruction_error():
    repo = create_autospec(TransferRepository)
    repo.get.return_value = None
    consumer = Mock(spec=TransferInstructionConsumer)
    expected = TransferInstructionError("invalid request", status_code=422)
    consumer.on_start.side_effect = expected
    service = SignalingService(repository=repo, instruction_consumer=consumer)

    with pytest.raises(TransferInstructionError) as exc_info:
        service.handle_start(build_start_message())

    assert exc_info.value is expected


def test_handle_start_wraps_unexpected_consumer_exception():
    repo = create_autospec(TransferRepository)
    repo.get.return_value = None
    consumer = Mock(spec=TransferInstructionConsumer)
    consumer.on_start.side_effect = RuntimeError("boom")
    service = SignalingService(repository=repo, instruction_consumer=consumer)

    with pytest.raises(TransferInstructionError) as exc_info:
        service.handle_start(build_start_message())

    assert exc_info.value.status_code == 500
    assert "failed to produce a DataAddress" in exc_info.value.detail
