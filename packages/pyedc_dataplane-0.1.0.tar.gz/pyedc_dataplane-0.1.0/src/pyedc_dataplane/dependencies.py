#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from functools import lru_cache

from fastapi import Depends

from pyedc_dataplane.crud.transfers import InMemoryTransferRepository, TransferRepository
from pyedc_dataplane.services.signaling import SignalingService, TransferInstructionConsumer


@lru_cache
def get_transfer_repository() -> TransferRepository:
    return InMemoryTransferRepository()


def get_instruction_consumer() -> TransferInstructionConsumer | None:
    """Dependency hook to allow overriding the instruction consumer."""
    return None


def get_signaling_service(
    repository: TransferRepository = Depends(get_transfer_repository),
    consumer: TransferInstructionConsumer | None = Depends(get_instruction_consumer),
) -> SignalingService:
    return SignalingService(repository=repository, instruction_consumer=consumer)
