#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from __future__ import annotations

from datetime import datetime, timezone
from typing import Callable, Optional, Protocol
from uuid import uuid4

from pyedc_dataplane.crud.transfers import TransferRecord, TransferRepository
from pyedc_dataplane.schemas.json_ld_model import (
    DataAddress,
    DataFlowStartMessage,
    DataFlowSuspendMessage,
    DataFlowTerminateMessage,
)


class TransferInstructionError(RuntimeError):
    """Raised when an instruction consumer rejects or cannot satisfy a request."""

    def __init__(self, detail: str, *, status_code: int = 400):
        super().__init__(detail)
        self.detail = detail
        self.status_code = status_code


class TransferInstructionConsumer(Protocol):
    """Protocol for components that react to START/SUSPEND/TERMINATE instructions."""

    def on_start(self, message: DataFlowStartMessage) -> DataAddress:
        """Return a DataAddress or raise TransferInstructionError for recoverable failures."""
        ...

    def on_suspend(self, message: DataFlowSuspendMessage) -> None:
        ...

    def on_terminate(self, message: DataFlowTerminateMessage) -> None:
        ...


class SignalingService:
    """Encapsulates START/SUSPEND/TERMINATE workflows for the signaling API."""

    def __init__(
        self,
        repository: TransferRepository,
        endpoint_resolver: Optional[Callable[[DataFlowStartMessage], str]] = None,
        instruction_consumer: Optional[TransferInstructionConsumer] = None,
    ):
        self._repository = repository
        self._endpoint_resolver = endpoint_resolver or self._default_endpoint
        self._instruction_consumer = instruction_consumer or DefaultInstructionConsumer(
            endpoint_resolver=self._endpoint_resolver,
            builder=self._build_data_address,
        )

    def handle_start(self, message: DataFlowStartMessage) -> DataAddress:
        record = self._repository.get(message.processId)
        if record and record.state == "STARTED" and record.data_address:
            return DataAddress.model_validate(record.data_address)

        try:
            data_address = self._instruction_consumer.on_start(message)
        except TransferInstructionError:
            raise
        except Exception as exc:  # pragma: no cover - unexpected control flow
            raise TransferInstructionError(
                "Instruction consumer failed to produce a DataAddress.",
                status_code=500,
            ) from exc

        if record is None:
            record = self._build_record(message, data_address)
        else:
            self._update_record_from_start(record, message, data_address)

        record.mark_state("STARTED")
        record.data_address = data_address.model_dump(by_alias=True, exclude_none=True)
        self._repository.save(record)
        return data_address

    def handle_suspend(self, message: DataFlowSuspendMessage) -> Optional[TransferRecord]:
        process_id = message.processId
        if not process_id:
            return None
        record = self._repository.get(process_id)
        if record is None:
            return None
        self._instruction_consumer.on_suspend(message)
        record.mark_state("SUSPENDED")
        self._repository.save(record)
        return record

    def handle_terminate(self, message: DataFlowTerminateMessage) -> Optional[TransferRecord]:
        process_id = message.processId
        if not process_id:
            return None
        record = self._repository.get(process_id)
        if record is None:
            return None
        self._instruction_consumer.on_terminate(message)
        record.mark_state("TERMINATED")
        self._repository.save(record)
        return record

    def _build_record(
        self,
        message: DataFlowStartMessage,
        data_address: DataAddress,
    ) -> TransferRecord:
        return TransferRecord(
            process_id=message.processId,
            agreement_id=message.agreementId,
            participant_id=message.participantId,
            dataset_id=message.datasetId,
            transfer_type=message.transferType,
            source_address=message.sourceDataAddress.model_dump(by_alias=True, exclude_none=True),
            destination_address=message.destinationDataAddress.model_dump(by_alias=True, exclude_none=True),
            callback_address=message.callbackAddress,
            properties=message.properties,
            state="STARTED",
            data_address=data_address.model_dump(by_alias=True, exclude_none=True),
        )

    def _update_record_from_start(
        self,
        record: TransferRecord,
        message: DataFlowStartMessage,
        data_address: DataAddress,
    ) -> None:
        record.agreement_id = message.agreementId
        record.participant_id = message.participantId
        record.dataset_id = message.datasetId
        record.transfer_type = message.transferType
        record.source_address = message.sourceDataAddress.model_dump(by_alias=True, exclude_none=True)
        record.destination_address = message.destinationDataAddress.model_dump(by_alias=True, exclude_none=True)
        record.callback_address = message.callbackAddress
        record.properties = message.properties
        record.data_address = data_address.model_dump(by_alias=True, exclude_none=True)
        record.updated_at = datetime.now(timezone.utc)

    def _build_data_address(
        self,
        endpoint: str,
        token: str,
        message: DataFlowStartMessage,
    ) -> DataAddress:
        return DataAddress(
            endpoint=endpoint,
            authorization=token,
            properties={
                "transferType": message.transferType,
                "participantId": message.participantId,
                "agreementId": message.agreementId,
                "generatedAt": datetime.now(timezone.utc).isoformat(),
            },
        )

    @staticmethod
    def _default_endpoint(message: DataFlowStartMessage) -> str:
        return f"https://dataplane.local/public/{message.processId}"


class DefaultInstructionConsumer(TransferInstructionConsumer):
    """Fallback consumer that mimics the previous in-service DataAddress creation."""

    def __init__(
        self,
        endpoint_resolver: Callable[[DataFlowStartMessage], str],
        builder: Callable[[str, str, DataFlowStartMessage], DataAddress],
    ):
        self._endpoint_resolver = endpoint_resolver
        self._builder = builder

    def on_start(self, message: DataFlowStartMessage) -> DataAddress:
        token = uuid4().hex
        endpoint = self._endpoint_resolver(message)
        return self._builder(endpoint, token, message)

    def on_suspend(self, message: DataFlowSuspendMessage) -> None:  # noqa: D401
        """Default implementation is a no-op."""
        return None

    def on_terminate(self, message: DataFlowTerminateMessage) -> None:  # noqa: D401
        """Default implementation is a no-op."""
        return None
