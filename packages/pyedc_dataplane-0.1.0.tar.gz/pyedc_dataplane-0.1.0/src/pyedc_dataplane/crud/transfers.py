#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Optional, Protocol


@dataclass
class TransferRecord:
    process_id: str
    agreement_id: str
    participant_id: str
    dataset_id: str
    transfer_type: str
    source_address: dict
    destination_address: dict
    callback_address: str
    properties: dict
    state: str = "READY"
    data_address: Optional[dict] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def mark_state(self, new_state: str) -> None:
        self.state = new_state
        self.updated_at = datetime.now(timezone.utc)


class TransferRepository(Protocol):
    """Abstraction for persisting transfer state and issued data addresses."""

    def get(self, process_id: str) -> Optional[TransferRecord]:
        ...

    def save(self, record: TransferRecord) -> TransferRecord:
        ...

    def delete(self, process_id: str) -> None:
        ...


class InMemoryTransferRepository(TransferRepository):
    """Simple in-memory persistence for development/testing."""

    def __init__(self):
        self._store: Dict[str, TransferRecord] = {}

    def get(self, process_id: str) -> Optional[TransferRecord]:
        return self._store.get(process_id)

    def save(self, record: TransferRecord) -> TransferRecord:
        record.updated_at = datetime.now(timezone.utc)
        self._store[record.process_id] = record
        return record

    def delete(self, process_id: str) -> None:
        self._store.pop(process_id, None)
