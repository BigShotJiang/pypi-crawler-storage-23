#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from pydantic import BaseModel, Field, ConfigDict, model_validator
from typing import Optional, Union, List, Dict, Any
from pyld import jsonld

EDC_NAMESPACE = "https://w3id.org/edc/v0.0.1/ns/"


def ns(term: str, namespace: str = EDC_NAMESPACE) -> str:
    return f"{namespace}{term}"


class JSONLDModel(BaseModel):
    """Base class for JSON-LD documents."""
    id: Optional[str] = Field(default=None, alias='@id')
    type: Optional[Union[str, List[str]]] = Field(default=None, alias='@type')

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    @model_validator(mode="before")
    @classmethod
    def _flatten_jsonld(cls, data):
        if isinstance(data, dict):
            return {k: _flatten_value(v) for k, v in data.items()}
        return data

    def _get_context(self) -> Optional[Dict[str, Any]]:
        extra = getattr(self, "__pydantic_extra__", None)
        if extra:
            return extra.get("@context")
        return None

    def to_jsonld(self):
        """Return compact JSON-LD representation."""
        context = self._get_context()
        return jsonld.compact(self.dict(by_alias=True, exclude_none=True), context)



class HttpDataAddress(BaseModel):
    """Represents a simple HTTP data address."""
    model_config = ConfigDict(populate_by_name=True, extra="allow")
    type: str = Field(alias=ns("type"))
    baseUrl: str = Field(alias=ns("baseUrl"))


class DataAddress(BaseModel):
    """Address returned to the consumer describing how to reach the data plane."""
    model_config = ConfigDict(populate_by_name=True, extra="allow")
    # endpoint: str = Field(alias=ns("endpoint"))
    # endpointType: str = Field(default="https://w3id.org/idsa/v4.1/HTTP", alias=ns("endpointType"))
    properties: Dict[str, Any] = Field(default_factory=dict, alias=ns("properties"))


class DataFlowStartMessage(JSONLDModel):
    """Schema for DataFlowStartMessage JSON-LD documents."""
    processId: str = Field(alias=ns("processId"))
    datasetId: str = Field(alias=ns("datasetId"))
    participantId: str = Field(alias=ns("participantId"))
    agreementId: str = Field(alias=ns("agreementId"))
    transferType: str = Field(alias=ns("transferType"))
    sourceDataAddress: DataAddress = Field(alias=ns("sourceDataAddress"))
    destinationDataAddress: DataAddress = Field(alias=ns("destinationDataAddress"))
    callbackAddress: str = Field(alias=ns("callbackAddress"))
    properties: Dict[str, Any] = Field(default_factory=dict, alias=ns("properties"))


class DataFlowSuspendMessage(JSONLDModel):
    """Schema for DataFlowSuspendMessage JSON-LD documents."""
    processId: Optional[str] = Field(default=None, alias=ns("processId"))
    reason: Optional[str] = Field(default=None, alias=ns("reason"))


class DataFlowTerminateMessage(JSONLDModel):
    """Schema for DataFlowTerminateMessage JSON-LD documents."""
    processId: Optional[str] = Field(default=None, alias=ns("processId"))
    reason: Optional[str] = Field(default=None, alias=ns("reason"))


class DataFlowResponseMessage(JSONLDModel):
    """Response sent back to the control plane with endpoint details."""
    dataAddress: DataAddress = Field(alias=ns("dataAddress"))
    provisioning: bool = Field(default=False, alias=ns("provisioning"))


class DataFlowAckMessage(JSONLDModel):
    """Generic acknowledgement message for suspend/terminate requests."""
    status: str = Field(default="acknowledged",alias=ns("status"))
    detail: Optional[str] = Field(default=None,alias=ns("detail"))


def _flatten_value(value):
    if isinstance(value, list):
        if not value:
            return value
        if all(not isinstance(item, dict) for item in value):
            return value
        return _flatten_value(value[0])
    if isinstance(value, dict):
        if "@value" in value:
            return value["@value"]
        if "@id" in value:
            return value["@id"]
        return {k: _flatten_value(v) for k, v in value.items()}
    return value
