#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from __future__ import annotations

from typing import Sequence

from fastapi import APIRouter, FastAPI

from pyedc_core.app_factory import create_namespaced_app
from pyedc_core.utils.constants import CoreConstants
from pyedc_dataplane.crud.transfers import TransferRepository
from pyedc_dataplane.dependencies import (
    get_instruction_consumer,
    get_transfer_repository,
)
from pyedc_dataplane.routers import signaling_router
from pyedc_dataplane.services.signaling import TransferInstructionConsumer

DEFAULT_NAMESPACES = {
    "edc": CoreConstants.EDC_NAMESPACE,
    "@vocab": CoreConstants.EDC_NAMESPACE,
}


def create_signaling_api(
    *,
    title: str = "EDC Data Plane Control API",
    extra_routers: Sequence[APIRouter] | None = None,
    instruction_consumer: TransferInstructionConsumer | None = None,
    transfer_repository: TransferRepository | None = None,
) -> FastAPI:
    """Build a FastAPI app exposing the signaling API."""
    routers = [signaling_router, *(extra_routers or ())]
    app = create_namespaced_app(
        title=title,
        scope="control",
        routers=routers,
        namespaces=DEFAULT_NAMESPACES,
    )
    if instruction_consumer is not None:
        app.dependency_overrides[get_instruction_consumer] = lambda: instruction_consumer
    if transfer_repository is not None:
        app.dependency_overrides[get_transfer_repository] = lambda: transfer_repository
    return app


__all__ = ["create_signaling_api"]
