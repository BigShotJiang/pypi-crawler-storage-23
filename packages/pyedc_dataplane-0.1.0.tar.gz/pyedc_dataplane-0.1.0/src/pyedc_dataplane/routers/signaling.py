#  Copyright (c) 2026 Nederlandse Organisatie voor toegepast-natuurwetenschappelijk onderzoek TNO
#
#  This program and the accompanying materials are made available under the
#  terms of the Apache License, Version 2.0 which is available at
#  https://www.apache.org/licenses/LICENSE-2.0
#
#    SPDX-License-Identifier: Apache-2.0
#

from __future__ import annotations

from datetime import datetime, timezone
from typing import List, Union

from fastapi import APIRouter, Depends, HTTPException, status

from pyedc_core.utils.constants import CoreConstants
from pyedc_dataplane.dependencies import get_signaling_service
from pyedc_dataplane.schemas.json_ld_model import (
    DataFlowAckMessage,
    DataFlowResponseMessage,
    DataFlowStartMessage,
    DataFlowSuspendMessage,
    DataFlowTerminateMessage,
)
from pyedc_dataplane.services.signaling import (
    SignalingService,
    TransferInstructionError,
)

router = APIRouter(prefix="/signaling/v1/dataflows", tags=["signaling"])

SignalMessage = Union[
    DataFlowStartMessage,
    DataFlowSuspendMessage,
    DataFlowTerminateMessage,
]


@router.post(
    "",
    response_model=Union[DataFlowResponseMessage, DataFlowAckMessage],
    summary="Handle data plane signaling messages.",
)
def handle_signaling(
    message: SignalMessage,
    service: SignalingService = Depends(get_signaling_service),
):
    """Route START/SUSPEND/TERMINATE messages to the appropriate handler."""
    msg_types = _message_types(message)

    if _has_type(msg_types, "DataFlowStartMessage"):
        return _handle_start(message, service)
    if _has_type(msg_types, "DataFlowSuspendMessage"):
        _ensure_process_id(message.processId)
        service.handle_suspend(message)  # type: ignore[arg-type]
        return _acknowledge(message, message.processId, "suspended")
    if _has_type(msg_types, "DataFlowTerminateMessage"):
        _ensure_process_id(message.processId)
        service.handle_terminate(message)  # type: ignore[arg-type]
        return _acknowledge(message, message.processId, "terminated")
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail="Unsupported signaling message type",
    )


def _handle_start(
    message: DataFlowStartMessage,
    service: SignalingService,
) -> DataFlowResponseMessage:
    """Return the consumer-provided endpoint description for the transfer."""
    try:
        data_address = service.handle_start(message)
    except TransferInstructionError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.detail) from exc
    return DataFlowResponseMessage(
        id=message.id or message.processId,
        type="DataFlowResponseMessage",
        dataAddress=data_address,
        provisioning=False,
    )


def _acknowledge(
    message: Union[DataFlowSuspendMessage, DataFlowTerminateMessage],
    process_id: str | None,
    state: str,
) -> DataFlowAckMessage:
    """Return an acknowledgement for suspend/terminate requests."""
    return DataFlowAckMessage(
        id=message.id or process_id,
        type=f"DataFlow{state.capitalize()}Ack",
        status="acknowledged",
        detail=f"Transfer {process_id} {state} at {datetime.now(timezone.utc).isoformat()}",
    )


def _message_types(message: SignalMessage) -> List[str]:
    raw = message.type
    if raw is None:
        return []
    if isinstance(raw, list):
        return raw
    return [raw]


def _has_type(types: List[str], simple_name: str) -> bool:
    target = f"{CoreConstants.EDC_NAMESPACE}{simple_name}"
    return any(t in (simple_name, target) for t in types)


def _ensure_process_id(process_id: str | None) -> None:
    if not process_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="processId is required for signaling acknowledgements",
        )
