# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2023 Istituto Nazionale di Fisica Nucleare
# SPDX-FileCopyrightText: 2023 Ian Postuma

from typing import Dict, List, Optional, Sequence, Tuple


class Materials:
    """
    Material container
    """

    def __init__(self) -> None:
        self.id: List[int] = []
        self.names: Dict[str, int] = {}
        self.composition: Dict[str, List[Tuple[str, float]]] = {}
        self.density: Dict[str, float] = {}

    def __repr__(self):
        return self.display()
    def __str__(self):
        return self.display()

    def display(self) -> str:
        s_display = 'Materials\n'
        for n in self.names.keys():
            s_display += '    Mat. {}: {}\n    '.format(self.names[n],n)
            s_display += 'density: {}\n    '.format(self.density[n])
            s_display += ', '.join(['{}={}'.format(c[0], c[1]) for c in self.composition[n]]) + '\n\n'
        return s_display

    def add_material(
        self,
        m_name: str,
        zzaid_comp: Optional[Sequence[Sequence[object]]] = None,
        rho: float = 0,
    ) -> None:
        """
        Method which defines the material:

        * m_name: unique material name
        * zzaid_comp: [[ZZAID, Atom_Number],...]
        * rho: material density g*cm-3
        """
        if m_name in self.names.keys():
            raise ValueError(f"Material name {m_name} already defined")
        try:
            density = float(rho)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"rho must be a number, got {rho!r}") from exc

        comp: List[Tuple[str, float]] = []
        if zzaid_comp is not None:
            for i, row in enumerate(zzaid_comp):
                if len(row) != 2:
                    raise ValueError(f"zzaid_comp[{i}] must contain exactly two values: [ZZAID, atom_number]")
                zzaid = str(row[0])
                try:
                    atom_number = float(row[1])
                except (TypeError, ValueError) as exc:
                    raise ValueError(f"zzaid_comp[{i}][1] must be numeric, got {row[1]!r}") from exc
                comp.append((zzaid, atom_number))

        c_id = 1
        if len(self.id) > 0:
            c_id += self.id[-1]
        self.id.append(c_id)

        self.names[m_name] = c_id
        self.composition[m_name] = comp
        self.density[m_name] = density
