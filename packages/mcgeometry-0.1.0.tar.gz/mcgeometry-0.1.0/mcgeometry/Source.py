# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2023 Istituto Nazionale di Fisica Nucleare
# SPDX-FileCopyrightText: 2023 Ian Postuma
import numpy as np
from glob import glob
from os.path import join, dirname
import re
from . import Traslation as t

def atoi(text):
    return int(text) if text.isdigit() else text

def natural_keys(text):
    '''
    alist.sort(key=natural_keys) sorts in human order
    http://nedbatchelder.com/blog/200712/human_sorting.html
    (See Toothy's implementation in the comments)
    '''
    return [ atoi(c) for c in re.split(r'(\d+)', text) ]

class Source:
    """.
    Source Definition.

    You may define different sources with distribution of:
        * Angle
        * Energy
        * Position
        * Particle type
    """
    def __init__(self):
        self.aspectra   = 0
        self.espectra   = 0
        self.position   = 0
        self.particle   = 0
        self.traslation = 0

    def LoadDDSource(self, source_csv, particle, plot=True):
        self.particle = particle
        
        data = np.genfromtxt(source_csv,delimiter=',')

        source = Source()
        angles = data[:,1]

        print(angles)

        spectras = {}

        for i in range(data.shape[0]):
            spectras[data[i,1]] = np.loadtxt(join(dirname(source_csv),data[i,-1]))

        print(spectras)
        
        return source
