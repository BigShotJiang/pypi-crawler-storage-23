# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2023 Istituto Nazionale di Fisica Nucleare
# SPDX-FileCopyrightText: 2023 Ian Postuma

from typing import Dict, List, Sequence


def _as_float(value: float, name: str) -> float:
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a number, got {value!r}") from exc


class Traslation:
    """
    Class used as container for traslation and/or rotation of surfaces.
    This class defines the traslation vector and rotarion matrix for a surface.
    """

    def __init__(self) -> None:
        self.id: List[int] = []
        self.traslations: Dict[str, List[List[float]]] = {}
        self.names: Dict[str, int] = {}

    def __repr__(self):
        return self.display()
    def __str__(self):
        return self.display()

    def display(self) -> str:
        s_display = 'Traslations\n'
        for n in self.names.keys():
            s_display += '    Surf. {}: {}\n    '.format(self.names[n],n)
            t,r = self.traslations[n]
            s_display += "trc : [{}, {}, {}]\n    ".format(*t)
            s_display += "rot : [{}, {}, {}]".format(*r)
            s_display += '\n\n'
        return s_display
    
    def add_traslations(
        self,
        t_name: str,
        dx: float = 0,
        dy: float = 0,
        dz: float = 0,
        alpha: float = 0,
        beta: float = 0,
        gamma: float = 0,
    ) -> None:
        """
        method that adds a traslation to the list of traslations
            * r_name defines the name of the rotation
            * dx, dy, dz the displacement in space
            * alpha: rotation arounz Z axiz
            * beta:  rotation around Y axiz
            * gamma: rotation around X axis
            * kwargs are the argument of the specific type
        """
        if t_name in self.names.keys():
            raise ValueError(f"Traslation name {t_name} already defined")

        t_id = 1
        if len(self.id) > 0:
            t_id += self.id[-1]
        self.id.append(t_id)

        self.names[t_name] = t_id
        self.traslations[t_name] = [
            [_as_float(dx, "dx"), _as_float(dy, "dy"), _as_float(dz, "dz")],
            [
                _as_float(alpha, "alpha"),
                _as_float(beta, "beta"),
                _as_float(gamma, "gamma"),
            ],
        ]

    def add_translation(
        self,
        t_name: str,
        dx: float = 0,
        dy: float = 0,
        dz: float = 0,
        alpha: float = 0,
        beta: float = 0,
        gamma: float = 0,
    ) -> None:
        """Snake-case alias for add_traslations."""
        self.add_traslations(t_name, dx=dx, dy=dy, dz=dz, alpha=alpha, beta=beta, gamma=gamma)

    def add_translations(
        self,
        t_name: str,
        dx: float = 0,
        dy: float = 0,
        dz: float = 0,
        alpha: float = 0,
        beta: float = 0,
        gamma: float = 0,
    ) -> None:
        """Correct-spelling alias for add_traslations."""
        self.add_traslations(t_name, dx=dx, dy=dy, dz=dz, alpha=alpha, beta=beta, gamma=gamma)


class Translation(Traslation):
    """Preferred class name alias for Traslation."""
