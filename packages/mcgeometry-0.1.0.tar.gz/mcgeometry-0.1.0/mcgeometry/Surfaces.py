# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2023 Istituto Nazionale di Fisica Nucleare
# SPDX-FileCopyrightText: 2023 Ian Postuma
from typing import Dict, List, Optional, Sequence, Tuple

from . import Traslation as t


def _as_float(value: float, name: str) -> float:
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a number, got {value!r}") from exc


def _validate_vec3(values: Sequence[float], name: str) -> List[float]:
    if len(values) != 3:
        raise ValueError(f"{name} must have exactly 3 numeric values")
    return [_as_float(values[0], f"{name}[0]"), _as_float(values[1], f"{name}[1]"), _as_float(values[2], f"{name}[2]")]


class Surfaces:
    """
    Class to define the surfaces of a geometry.
    This class creates a surface container which can then be used to construct a geometry.
    """
    def __init__(self) -> None:
        self.id: List[int] = []
        self.surfaces: Dict[str, List[object]] = {}
        self.names: Dict[str, int] = {}
        self.traslations = t.Translation()
        self.s_traslation: Dict[str, str] = {}

    def __repr__(self):
        return self.display()
    def __str__(self):
        return self.display()

    def display(self) -> str:
        s_display = 'Surfaces\n'
        for n in self.names.keys():
            s_display += '    Surf. {}: {}\n    Type {}\n    '.format(self.names[n],n,self.surfaces[n][0])
            s_display += ', '.join(['{}={!r}'.format(k, v) for k, v in self.surfaces[n][1].items()]) + '\n\n'
        return s_display
    
    def add_surface(self, s_name: str, s_type: str, **kwargs: object) -> None:
        """
        method that adds a surface to the list of surfaces
            * s_name defines the name of a surface
            * kwargs are the argument of the specific type
        """
        if s_name in self.names.keys():
            raise ValueError(f"Surface name {s_name} already defined")

        s_id = 1
        if len(self.id) > 0:
            s_id += self.id[-1]
        self.id.append(s_id)

        self.names[s_name] = s_id
        self.surfaces[s_name] = [s_type,kwargs]
    
    def set_traslation(self, s_name: str, t_name: str) -> None:
        """
        Surface traslation to its position:
            s_name -> the name of the surface to traslate
            t_name -> a name for the traslation
            dx,dy,dz -> 3D displacement 
            alpha -> rotation around z axis
            beta  -> rotation around y axis
            gamma -> rotation around x axis
        """
        if s_name not in self.names:
            raise KeyError(f"Surface {s_name} is not defined")
        if t_name not in self.traslations.names.keys():
            raise KeyError(f"Traslation name {t_name} is not defined")
        if s_name in self.s_traslation.keys():
            raise ValueError(f"Traslation for surface {s_name} already defined")
        self.s_traslation[s_name] = t_name

    def set_translation(self, s_name: str, t_name: str) -> None:
        """Snake-case alias for set_traslation."""
        self.set_traslation(s_name, t_name)

    def add_traslation(
        self,
        t_name: str,
        dx: float = 0,
        dy: float = 0,
        dz: float = 0,
        alpha: float = 0,
        beta: float = 0,
        gamma: float = 0,
    ) -> None:
        self.traslations.add_traslations(t_name, dx=dx, dy=dy, dz=dz, alpha=alpha, beta=beta, gamma=gamma)

    def add_translation(
        self,
        t_name: str,
        dx: float = 0,
        dy: float = 0,
        dz: float = 0,
        alpha: float = 0,
        beta: float = 0,
        gamma: float = 0,
    ) -> None:
        """Snake-case alias for add_traslation."""
        self.add_traslation(t_name, dx=dx, dy=dy, dz=dz, alpha=alpha, beta=beta, gamma=gamma)

    def add_translations(
        self,
        t_name: str,
        dx: float = 0,
        dy: float = 0,
        dz: float = 0,
        alpha: float = 0,
        beta: float = 0,
        gamma: float = 0,
    ) -> None:
        """Correct-spelling alias for add_traslation."""
        self.add_traslation(t_name, dx=dx, dy=dy, dz=dz, alpha=alpha, beta=beta, gamma=gamma)
        

    def get_traslations(self) -> t.Traslation:
        return self.traslations
    
    def get_translations(self) -> t.Traslation:
        """Snake-case alias for get_traslations."""
        return self.get_traslations()

    def rpp(self, s_name: str, p_min: Sequence[float], p_max: Sequence[float]) -> None:
        s_type = "rpp"
        kwargs = {"p_min": _validate_vec3(p_min, "p_min"), "p_max": _validate_vec3(p_max, "p_max")}
        self.add_surface(s_name, s_type, **kwargs)

    def sph(self, s_name: str, c: Sequence[float], r: float) -> None:
        s_type = "sph"
        radius = _as_float(r, "r")
        if radius <= 0:
            raise ValueError("r must be > 0")
        kwargs = {"c": _validate_vec3(c, "c"), "r": radius}
        self.add_surface(s_name, s_type, **kwargs)

    def rcc(self, s_name: str, c: Sequence[float], h: Sequence[float], r: float) -> None:
        s_type = "rcc"
        radius = _as_float(r, "r")
        if radius <= 0:
            raise ValueError("r must be > 0")
        kwargs = {"c": _validate_vec3(c, "c"), "h": _validate_vec3(h, "h"), "r": radius}
        self.add_surface(s_name, s_type, **kwargs)

    def trc(self, s_name: str, c: Sequence[float], h: Sequence[float], r1: float, r2: float) -> None:
        s_type = "trc"
        radius_1 = _as_float(r1, "r1")
        radius_2 = _as_float(r2, "r2")
        if radius_1 <= 0 or radius_2 <= 0:
            raise ValueError("r1 and r2 must both be > 0")
        kwargs = {"c": _validate_vec3(c, "c"), "h": _validate_vec3(h, "h"), "r1": radius_1, "r2": radius_2}
        self.add_surface(s_name, s_type, **kwargs)

    def hex(
        self,
        s_name: str,
        v: Sequence[float],
        h: Sequence[float],
        r: Sequence[float],
        s: Optional[Sequence[float]] = None,
        t: Optional[Sequence[float]] = None,
    ) -> None:
        s_type = "hex"
        kwargs = {
            "v": _validate_vec3(v, "v"),
            "h": _validate_vec3(h, "h"),
            "r": _validate_vec3(r, "r"),
            "s": _validate_vec3([0, 0, 0] if s is None else s, "s"),
            "t": _validate_vec3([0, 0, 0] if t is None else t, "t"),
        }
        self.add_surface(s_name, s_type, **kwargs)
