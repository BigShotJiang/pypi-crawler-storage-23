# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2023 Istituto Nazionale di Fisica Nucleare
# SPDX-FileCopyrightText: 2023 Ian Postuma

from textwrap import fill
from typing import Dict, Sequence, Tuple

class MCNP:
    """
    Class that manages the MCNP implementation
    """
    def __init__(self, cells, surfaces, materials) -> None:
        self.cells = cells
        self.surfaces = surfaces
        self.materials = materials
        self.traslations = surfaces.get_traslations()

        self.input = "MCNP input written with MCGeometry"


    def write_cells(self) -> str:
        """
        Method that output the MCNP cell structure as a string
        """
        s_cell = "{}\nc\n".format(self.input)
        if self.cells.OWS not in self.surfaces.names:
            raise KeyError(f"Outer world surface {self.cells.OWS} is not defined")
        cn = len(self.cells.names.items()) + 1
        surf = "{}".format(self.surfaces.names[self.cells.OWS])
        s_cell += "c {}\n{} {} {}\n".format("Outer World", cn, 0, surf)
        for k, v in self.cells.names.items():
            cn = v
            mat, m_name = self.get_cell_material(k)
            surf = self.get_surface_algebra(k)
            s_cell += "c {} {}\n".format(k, m_name)
            dump = "{} {} {}".format(cn, mat, surf)
            s_cell += fill(dump, width=80, initial_indent='', subsequent_indent='     ')
            s_cell += "\nc\n"
        return s_cell

    def Write_Cells(self) -> str:
        """Backward-compatible alias for write_cells."""
        return self.write_cells()

    def write_surfaces(self) -> str:
        """
        Method that output the MCNP surface structure as a string
        """
        s_surf = ""
        for k, v in self.surfaces.names.items():
            sf = self.surfaces.surfaces[k][0]
            trc = " "
            if k in self.surfaces.s_traslation.keys():
                t_name = self.surfaces.s_traslation[k]
                trc = self.surfaces.traslations.names[t_name]
            args = self.surfaces.surfaces[k][1]
            if sf not in surf_func:
                raise ValueError(f"Unsupported surface type {sf!r}")
            s_surf += "c {}\n".format(k)
            dump = "{} {} {} {}".format(v, trc, sf, surf_func[sf](**args))
            s_surf += fill(dump, width=80, initial_indent='', subsequent_indent='     ')
            s_surf += "\n"
        return s_surf

    def Write_Surfaces(self) -> str:
        """Backward-compatible alias for write_surfaces."""
        return self.write_surfaces()

    def write_materials(self) -> str:
        """
        Method that output the MCNP material information as a string
        """
        s_mat = ""
        for k, v in self.materials.names.items():
            if float(self.materials.density[k]) != 0.0:
                s_mat += "c {:>15s} {:<5d}\n".format("Material", v)
                s_mat += self.get_material_composition(k, v)
        return s_mat

    def Write_Materials(self) -> str:
        """Backward-compatible alias for write_materials."""
        return self.write_materials()

    def write_importances(self) -> str:
        """
        Method to define the importances in the card section

        CAREFULL this method sets imp:n=1 for now
        """
        s_imp = "imp:n 0"
        for k in self.cells.names.keys():
            if "imp_n" not in self.cells.operations[k]:
                raise KeyError(f"Cell {k} has no 'imp_n' operation")
            s_imp += " {}".format(self.cells.operations[k]["imp_n"])
        s_imp = fill(s_imp, width=80, initial_indent='', subsequent_indent='     ')
        s_imp += "\n"
        return s_imp

    def Write_Importances(self) -> str:
        """Backward-compatible alias for write_importances."""
        return self.write_importances()

    def write_traslations(self) -> str:
        trc = ""
        for k in self.traslations.names.keys():
            trc += "c {}\n".format(k)
            t, r = self.traslations.traslations[k]
            trc += fill("tr{} {}".format(self.traslations.names[k], traslation(t, r)),
                        width=80, initial_indent='', subsequent_indent='     ')
            trc += "\n"
        return trc

    def Write_Traslations(self) -> str:
        """Backward-compatible alias for write_traslations."""
        return self.write_traslations()

    def write(self) -> str:
        c = self.write_cells()
        s = self.write_surfaces()
        m = self.write_materials()
        i = self.write_importances()
        t = self.write_traslations()

        return "{}\n{}\n{}{}{}".format(c, s, m, i, t)

    def Write(self) -> str:
        """Backward-compatible alias for write."""
        return self.write()

    def get_cell_material(self, c_name: str) -> Tuple[str, str]:
        """
        Define the material from the cell name and material object
        """
        mat = "0"
        if c_name not in self.cells.material:
            raise KeyError(f"Cell {c_name} has no material")
        if float(self.materials.density[self.cells.material[c_name]]) != 0.0:
            mat = "{} -{}".format(self.materials.names[self.cells.material[c_name]],
                                self.materials.density[self.cells.material[c_name]])
        return mat, self.cells.material[c_name]
    
    def get_outer_intersection(self, c_name: str) -> str:
        dump = ""
        if c_name not in self.cells.subcell:
            return dump
        for s in self.cells.subcell[c_name]:
            if s not in self.surfaces.names:
                raise KeyError(f"Subcell surface {s} is not defined")
            dump += " {}".format(self.surfaces.names[s])
        return dump
    
    def get_surface_algebra(self, c_name: str) -> str:
        """
        Define the surface boolean operations for the main cell and all its subcells
        """
        if c_name not in self.cells.surface:
            raise KeyError(f"Cell {c_name} has no associated surface")
        surf = "-{}".format(self.surfaces.names[self.cells.surface[c_name]])
        if c_name in self.cells.subcell.keys():
            surf += self.get_outer_intersection(c_name)
        return surf
    
    def get_material_composition(self, m_name: str, m_id: int) -> str:
        s_comp = "m{:<5d}$ {:>10s} [rho= {} g/cm3]\n".format(m_id, m_name, self.materials.density[m_name])
        for m in self.materials.composition[m_name]:
            s_comp += "     {} {}\n".format(m[0], m[1])
        return s_comp

def traslation(trc: Sequence[float], rot: Sequence[float]) -> str:
    from math import cos,sin,radians

    alpha = radians(rot[0])
    beta  = radians(rot[1])
    gamma = radians(rot[2])

    a=cos(alpha)*cos(beta)
    b=cos(alpha)*sin(beta)*sin(gamma)-sin(alpha)*cos(gamma)
    c=cos(alpha)*sin(beta)*cos(gamma)+sin(alpha)*sin(gamma)
    d=sin(alpha)*cos(beta)
    e=sin(alpha)*sin(beta)*sin(gamma)+cos(alpha)*cos(gamma)
    f=sin(alpha)*sin(beta)*cos(gamma)-cos(alpha)*sin(gamma)
    g=-sin(beta)
    h=cos(beta)*sin(gamma)
    i=cos(beta)*cos(gamma)

    return "{:1.6f} {:1.6f} {:1.6f}  {:1.6f} {:1.6f} {:1.6f}  {:1.6f} {:1.6f} {:1.6f}  {:1.6f} {:1.6f} {:1.6f}".format(trc[0],trc[1],trc[2],
                                                           a, b, c,
                                                           d, e, f,
                                                           g, h, i)

def rpp(p_min: Sequence[float], p_max: Sequence[float]) -> str:
    """
    Function that outputs the rpp format from BB point
    """
    return "{} {} {} {} {} {}".format(p_min[0],p_max[0],
                                      p_min[1],p_max[1],
                                      p_min[2],p_max[2])

def sph(c: Sequence[float], r: float) -> str:
    """
    Function that outputs the sph format from c (3D point) and r (radius)
    """
    return "{} {} {} {}".format(c[0],c[1],c[2],r)

def rcc(c: Sequence[float], h: Sequence[float], r: float) -> str:
    """
    Function that outputs the rcc format from: 
        c -> 3D point of the ceter of the base
        h -> 3D vector of the height of the cylinder 
        r -> radius
    """
    return "{} {} {} {} {} {} {}".format(c[0],c[1],c[2],
                                         h[0],h[1],h[2],
                                         r)

def trc(c: Sequence[float], h: Sequence[float], r1: float, r2: float) -> str:
    """
    Function that outputs the rcc format from: 
        c  -> 3D point of the ceter of the base
        h  -> 3D vector of the height of the cylinder
        r1 -> radius of bottom face
        r2 -> radius of top face
    """
    return "{} {} {} {} {} {} {} {}".format(c[0],c[1],c[2],
                                         h[0],h[1],h[2],
                                         r1,r2)

def hex(v: Sequence[float], h: Sequence[float], r: Sequence[float], s: Sequence[float], t: Sequence[float]) -> str:
    """
    Input Parameter and Description:
        (v1 v2 v3) The x,y,z coordinates of the bottom of the hexagonal prism.
        (h1 h2 h3) Vector from the bottom to the top of the hexagonal prism. For a z-hex with heighth,h1,h2, andh3= 0 0 h .
        (r1 r2 r3) Vector from the axis to the center of the 1st facet. For a pitch 2p facet normaltoy-axis,r1,r2,and r3= 0 p 0 .
        (s1 s2 s3) Vector to center of the 2nd facet. 
        (t1 t2 t3) Vector to center of the 3rd facet.

        WARNING s and t have to be trated separately
    """
    dump = ""
    for vec in [v,h,r]:
        for val in vec:
            dump = dump+" {:1.4f}".format(val)
    return dump

# surface function dictionary
surf_func = {"rpp":rpp,
             "rcc":rcc,
             "sph":sph,
             "trc":trc,
             "hex":hex}
