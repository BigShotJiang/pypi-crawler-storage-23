# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2023 Istituto Nazionale di Fisica Nucleare
# SPDX-FileCopyrightText: 2023 Ian Postuma

class Tally:
    """
    Container of tallies.

    You may define regions of the simulated world where to extract information about:
         1 Flux
         2 Current
         3 Dose
    """
    def __init__(self,cell_definitio):
        self.id = []
        self.tallies = {}
        self.names = {}
        self.cells = cell_definitio

    def __repr__(self):
        return self.display()
    def __str__(self):
        return self.display()

    def display(self):
        s_display = 'Tallies\n'
        for n in self.names.keys():
            s_display += '    Tally. {}: {}\n'.format(self.names[n],n)
            #s_display += 'operations: {}\n    '.format(self.operations[n][0])
            s_display += ', '.join(['{}={!r}'.format(k, v) for k, v in self.tallies[n].items()]) + '\n\n'
        return s_display

    def surface(self,c_name,t_type,facet=1,ebin=[0,20],angle=[-1,1],particle="neutron",comment=""):
        """
        This method defines a surface tally on a cell, it needs:
            * c_name: cell name
            * t_type:
                1 Flux
                2 Current
                3 Dose
            * facet: which surface of the body to use for the tally
                . eg, for an rpp this is:
                    1 max X 
                    2 min X
                    3 max Y
                    4 min Y
                    5 max Z
                    6 max Z
                . eg, for an rcc and trc this is:
                    1 surf perpendicular to r
                    2 surface perpendicular to top
                    3 surface perpendicular to bottom
                . eg, for sph:
                    1 furface of the sphere
        """

        t_id = 1
        if len(self.id) > 0:
            t_id += self.id[-1]
        self.id.append(t_id)

        self.names[t_id] = {}
        self.names[t_id][c_name]
        self.names[t_id][t_type]
        self.names[t_id][facet]
        self.names[t_id][ebin]
        self.names[t_id][angle]
        self.names[t_id][particle]
        self.names[t_id][comment]
