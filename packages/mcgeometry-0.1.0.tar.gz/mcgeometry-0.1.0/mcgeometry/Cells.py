# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileCopyrightText: 2023 Istituto Nazionale di Fisica Nucleare
# SPDX-FileCopyrightText: 2023 Ian Postuma

from typing import Dict, List


class Cells:
    """
    Container of cells.

    One cell is a geometrical object defined by a closed surface. 
    It has to be defined by at least a Surface and a Material object.

    A cell may contain other cells (i.e. subcells), these subcells
    will be subtracted from the cell and each subcell has to be defined 
    by at lest one Surface and one Material object
    """
    def __init__(self, surfaces, Outer_World_Surface: str) -> None:
        self.id: List[int] = []
        self.operations: Dict[str, Dict[str, object]] = {}
        self.material: Dict[str, str] = {}
        self.names: Dict[str, int] = {}
        self.subcell: Dict[str, List[str]] = {}
        self.surface: Dict[str, str] = {}
        self.OWS = Outer_World_Surface
        self.surfaces = surfaces

    def __repr__(self):
        return self.display()
    def __str__(self):
        return self.display()

    def display(self) -> str:
        s_display = 'Cells\n'
        for n in self.names.keys():
            s_display += '    Cell. {}: {}\n    Material {}\n    '.format(self.names[n],n,self.material[n])
            #s_display += 'operations: {}\n    '.format(self.operations[n][0])
            s_display += ', '.join(['{}={!r}'.format(k, v) for k, v in self.operations[n].items()]) + '\n\n'
        return s_display
    
    def add_cell(self, c_name: str, material: str, surface_name: str, **kwargs: object) -> None:
        """
        method that adds a cell to the list of cells
            * c_name defines the name of a cell
            * kwargs are the argument of the specific type
            * surface_name name of the cooresponding surface
        """
        if c_name in self.names.keys():
            raise ValueError(f"Cell name {c_name} already defined")
        if surface_name not in self.surfaces.names:
            raise KeyError(f"Surface {surface_name} is not defined")

        c_id = 1
        if len(self.id) > 0:
            c_id += self.id[-1]
        self.id.append(c_id)

        self.names[c_name] = c_id
        self.material[c_name] = material
        self.operations[c_name] = dict(kwargs)
        self.surface[c_name] = surface_name

    def add_subcell(
        self,
        c_name: str,
        s_c_name: str,
        material: str,
        s_surface_name: str,
        **kwargs: object,
    ) -> None:
        """
        method that adds a subcell to the list of cells
            * c_name name of the parent cell
            * s_c_name defines the name of a sub cell
            * kwargs are the argument of the specific type
        """
        if c_name not in self.names.keys():
            raise KeyError(f"Parent cell {c_name} is not defined")
        self.add_cell(s_c_name,material,s_surface_name,**kwargs)
        if c_name in self.subcell.keys():
            self.subcell[c_name].append(s_c_name)
        else:
            self.subcell[c_name] = [s_c_name]

    def subtract_cell(self, c_name: str, s_c_name: str) -> None:
        """
        add s_c_name as a subcell of c_name
        """
        if c_name not in self.names.keys():
            raise KeyError(f"Cell {c_name} is not defined")
        if s_c_name not in self.names.keys():
            raise KeyError(f"Subcell {s_c_name} is not defined")
        if c_name in self.subcell.keys():
            self.subcell[c_name].append(s_c_name)
        else:
            self.subcell[c_name] = [s_c_name]
