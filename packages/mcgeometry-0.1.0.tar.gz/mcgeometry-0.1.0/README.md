# MCgeometry

`MCgeometry` is a lightweight Python module for building MCNP geometry inputs from
Python objects.

It provides containers for:
- surfaces (`Surfaces`)
- cells (`Cells`)
- materials (`Materials`)
- geometry/input writing (`MCNP`)

## Repository layout

```text
mcgeometry/
  __init__.py
  Surfaces.py
  Cells.py
  Materials.py
  MCNP.py
  Source.py
  Tally.py
  Traslation.py
```

## Requirements

- Python 3.8+ (recommended)
- `numpy` is used by `Source.py`

## Installation

From PyPI (after publication):

```bash
pip install mcgeometry
```

From source (repository root):

```bash
pip install -e .
```

This enables imports without manually setting `PYTHONPATH`.

## Quick start

Example: create a simple world box containing one spherical cell and generate the
MCNP input text.

```python
from mcgeometry import Surfaces, Cells, Materials, MCNP

# 1) Define surfaces
surfaces = Surfaces()
surfaces.rpp("world", p_min=[-100, -100, -100], p_max=[100, 100, 100])
surfaces.sph("sphere", c=[0, 0, 0], r=10)

# 2) Define materials
materials = Materials()
materials.add_material("vacuum", rho=0.0)
materials.add_material("water", zzaid_comp=[["1001.80c", 2], ["8016.80c", 1]], rho=1.0)

# 3) Define cells
cells = Cells(surfaces, Outer_World_Surface="world")
cells.add_cell("sphere_cell", material="water", surface_name="sphere", imp_n=1)

# 4) Build MCNP input string
mcnp = MCNP(cells, surfaces, materials)
input_text = mcnp.Write()
print(input_text)
```

## Examples

The `examples/` folder contains runnable scripts:

- `examples/basic_geometry.py`: minimal geometry/material/cell setup and MCNP
  input generation.

Run:

```bash
python examples/basic_geometry.py
```

## How to add this module to the Python path

If you are developing from this repository (without packaging/installing), Python
must be able to find the project root (the folder that contains `mcgeometry/`).

### Option 1: Temporary (current shell session)

From the repository root:

```bash
export PYTHONPATH="$PWD:$PYTHONPATH"
```

Then import normally:

```python
from mcgeometry import Surfaces, Cells, Materials, MCNP
```

### Option 2: Permanent (your shell profile)

Add this line to `~/.zshrc` (zsh) or `~/.bashrc` (bash):

```bash
export PYTHONPATH="/absolute/path/to/mcgeometry/repo:$PYTHONPATH"
```

Reload your shell:

```bash
source ~/.zshrc
```

### Option 3: In code (single script/notebook)

```python
import sys
sys.path.append("/absolute/path/to/mcgeometry/repo")

from mcgeometry import Surfaces, Cells, Materials, MCNP
```

## Notes

- The package exports most core classes through `mcgeometry/__init__.py`, so
  importing from `mcgeometry` is the simplest entry point.
- The project currently uses the `Traslation` naming used in source files.
- The API now also includes standardized aliases:
  - class alias: `Translation` (keeps `Traslation` for compatibility)
  - `MCNP.write*` methods (keeps `MCNP.Write*` for compatibility)
- `Source` and `Tally` modules are currently under development and still need
  full validation before production use.
