import logging

logging.warn("I'm coming, world !")  # [deprecated-method]
