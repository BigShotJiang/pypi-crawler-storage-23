def foo():  # [disallowed-name]
    print("apples")
