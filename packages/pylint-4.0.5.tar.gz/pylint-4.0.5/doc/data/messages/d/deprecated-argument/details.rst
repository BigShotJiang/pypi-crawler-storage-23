The actual replacement needs to be studied on a case by case basis
by reading the deprecation warning or the release notes.
