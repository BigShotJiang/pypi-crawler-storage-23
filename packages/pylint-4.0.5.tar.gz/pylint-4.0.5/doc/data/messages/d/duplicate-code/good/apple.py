from fruit import Fruit


class Apple(Fruit): ...
