def get_fruits(apple, banana, orange):
    pass
