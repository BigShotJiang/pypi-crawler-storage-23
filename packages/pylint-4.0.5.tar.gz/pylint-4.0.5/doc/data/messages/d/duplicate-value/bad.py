incorrect_set = {"value1", 23, 5, "value1"}  # [duplicate-value]
