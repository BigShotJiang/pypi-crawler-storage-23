class Animal:
    pass


class Bird(Animal):
    pass


class Cat(Animal):
    pass
