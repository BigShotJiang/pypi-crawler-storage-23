fruit_prices = {"apple": 1, "banana": 10}
