from collections import Iterable  # [deprecated-class]
