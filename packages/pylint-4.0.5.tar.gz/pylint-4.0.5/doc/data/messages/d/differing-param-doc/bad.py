def add(x, y):  # [differing-param-doc]
    """Add two numbers.

    :param int x: x value.
    :param int z: z value.
    """

    return x + y
