def add(x, y):
    """Add two numbers.

    :param int x: x value.
    :param int y: y value.
    """

    return x + y
