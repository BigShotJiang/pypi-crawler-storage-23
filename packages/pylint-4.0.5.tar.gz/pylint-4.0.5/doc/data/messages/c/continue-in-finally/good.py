while True:
    try:
        pass
    except ValueError:
        pass
    else:
        continue
