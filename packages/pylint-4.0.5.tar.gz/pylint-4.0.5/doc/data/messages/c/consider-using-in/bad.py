def fruit_is_round(fruit):
    # +1: [consider-using-in]
    return fruit == "apple" or fruit == "orange" or fruit == "melon"
