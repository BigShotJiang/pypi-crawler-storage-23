FRUITS = {"apple": 1, "pear": 5, "peach": 10}


for fruit in FRUITS.keys():  # [consider-iterating-dictionary]
    print(fruit)
