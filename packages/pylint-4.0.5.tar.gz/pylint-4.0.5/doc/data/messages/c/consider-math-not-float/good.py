import math

swag = math.inf
