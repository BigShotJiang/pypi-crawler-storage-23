swag = float("inf")  # [consider-math-not-float]
