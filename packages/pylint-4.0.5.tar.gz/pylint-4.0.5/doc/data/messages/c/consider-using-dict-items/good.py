ORCHESTRA = {
    "violin": "strings",
    "oboe": "woodwind",
    "tuba": "brass",
    "gong": "percussion",
}


for instrument, section in ORCHESTRA.items():
    print(f"{instrument}: {section}")
