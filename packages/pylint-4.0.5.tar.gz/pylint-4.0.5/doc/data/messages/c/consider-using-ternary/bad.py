x, y = 1, 2
maximum = x >= y and x or y  # [consider-using-ternary]
