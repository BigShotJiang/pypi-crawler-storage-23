x, y = 1, 2
maximum = x if x >= y else y
