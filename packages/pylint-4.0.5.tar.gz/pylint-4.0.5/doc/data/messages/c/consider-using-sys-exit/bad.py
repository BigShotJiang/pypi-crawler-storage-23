if __name__ == "__main__":
    user = input("Enter user name: ")
    print(f"Hello, {user}")
    exit(0)  # [consider-using-sys-exit]
