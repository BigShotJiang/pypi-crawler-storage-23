contents = open("apple.txt", "r", encoding="utf8").read()  # [consider-using-with]
