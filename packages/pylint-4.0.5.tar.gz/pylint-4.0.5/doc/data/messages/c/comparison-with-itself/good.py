def is_an_orange(fruit):
    an_orange = "orange"
    return an_orange == fruit
