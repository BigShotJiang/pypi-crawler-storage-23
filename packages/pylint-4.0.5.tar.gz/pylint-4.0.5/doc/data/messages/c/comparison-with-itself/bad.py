def is_an_orange(fruit):
    an_orange = "orange"
    return fruit == fruit  # [comparison-with-itself]
