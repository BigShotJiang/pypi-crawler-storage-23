a = 1
b = 2

temp = a  # [consider-swap-variables]
a = b
b = temp
