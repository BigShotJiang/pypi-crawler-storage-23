x, y = input(), input()
if x >= y:  # [consider-ternary-expression]
    maximum = x
else:
    maximum = y
