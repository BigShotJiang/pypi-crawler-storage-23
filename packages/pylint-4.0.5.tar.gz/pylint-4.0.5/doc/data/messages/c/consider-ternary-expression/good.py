x, y = input(), input()
maximum = x if x >= y else y
