``c-extension-no-member`` is an informational variant of ``no-member`` to encourage
allowing introspection of C extensions as described in the
`page <https://pylint.readthedocs.io/en/latest/user_guide/messages/error/no-member.html>`_
for ``no-member``.
