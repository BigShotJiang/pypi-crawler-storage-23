STRING = "Valid carriage return: \r"
