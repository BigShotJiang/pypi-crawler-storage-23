class Person:
    __slots__ = ("name", "age")
