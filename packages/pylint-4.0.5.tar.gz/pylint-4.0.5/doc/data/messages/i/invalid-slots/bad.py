class Person:  # [invalid-slots]
    __slots__ = 42
