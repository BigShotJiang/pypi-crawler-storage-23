class FruitBasket:
    def __init__(self, fruits):
        self.fruits = ["Apple", "Banana", "Orange"]

    def __len__(self):
        return len(self.fruits)
