x = ["a" "b"]  # [implicit-str-concat]
