STRING = "Invalid character backspace "  # [invalid-character-backspace]
