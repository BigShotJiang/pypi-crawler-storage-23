STRING = "Valid character backspace \b"
