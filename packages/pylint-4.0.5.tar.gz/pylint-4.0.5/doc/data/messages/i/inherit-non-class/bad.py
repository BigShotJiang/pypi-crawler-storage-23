class Fruit(bool):  # [inherit-non-class]
    pass
