STRING = "Valid character zero-width-space u200B"
