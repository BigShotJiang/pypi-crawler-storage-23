__all__ = (
    None,  # [invalid-all-object]
    Fruit,
    Worm,
)


class Fruit:
    pass


class Worm:
    pass
