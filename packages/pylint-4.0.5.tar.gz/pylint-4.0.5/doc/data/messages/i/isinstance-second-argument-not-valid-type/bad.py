isinstance("apples and oranges", hex)  # [isinstance-second-argument-not-valid-type]
