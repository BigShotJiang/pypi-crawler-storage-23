import sys


def print_python_version():
    print(sys.version_info)
