def print_python_version():
    import sys  # [import-outside-toplevel]

    print(sys.version_info)
