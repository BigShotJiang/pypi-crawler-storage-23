LETTERS = ["a", "b", "c", "d"]

FIRST_THREE = LETTERS[:3]
