class Apple:
    pass


Apple.__class__ = 1  # [invalid-class-object]
