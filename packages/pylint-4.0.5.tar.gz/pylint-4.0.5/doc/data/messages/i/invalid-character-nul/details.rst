There's no need to use end-of-string characters. String objects maintain their
own length.
