LETTERS = ["a", "b", "c", "d"]

LETTERS[::0]  # [invalid-slice-step]
