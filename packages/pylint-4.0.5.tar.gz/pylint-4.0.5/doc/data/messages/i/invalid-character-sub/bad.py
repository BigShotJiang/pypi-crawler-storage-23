STRING = "Invalid character sub "  # [invalid-character-sub]
