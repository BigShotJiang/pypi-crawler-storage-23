class CustomHash:
    """__hash__ returns `int`"""

    def __hash__(self):
        return 19
