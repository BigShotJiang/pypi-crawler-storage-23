fruits = ["apple", "banana", "orange"]
print(fruits["apple"])  # [invalid-sequence-index]
