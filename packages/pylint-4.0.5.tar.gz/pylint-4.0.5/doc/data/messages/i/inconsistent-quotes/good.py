import datetime

print("Current year: ", datetime.date.today().strftime("%Y"))
