class CustomStr:
    """__str__ returns <type 'str'>"""

    def __str__(self):
        return "oranges"
