import os

os.getenv(1)  # [invalid-envvar-value]
