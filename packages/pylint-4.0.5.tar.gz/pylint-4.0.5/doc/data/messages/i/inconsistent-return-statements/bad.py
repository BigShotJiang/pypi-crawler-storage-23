def get_the_answer(value: str) -> str | None:  # [inconsistent-return-statements]
    if value:
        return value
