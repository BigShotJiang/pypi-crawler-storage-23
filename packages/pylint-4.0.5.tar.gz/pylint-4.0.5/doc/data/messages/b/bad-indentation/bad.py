if input():
   print('yes')  # [bad-indentation]
