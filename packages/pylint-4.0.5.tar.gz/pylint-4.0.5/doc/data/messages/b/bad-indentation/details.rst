The option ``--indent-string`` can be used to set the indentation unit for this check.
