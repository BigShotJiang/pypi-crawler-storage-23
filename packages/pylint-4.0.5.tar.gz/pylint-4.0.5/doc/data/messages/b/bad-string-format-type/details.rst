This check is currently only active for "old-style" string formatting as seen in the examples.
See `Issue #6085 <https://github.com/pylint-dev/pylint/issues/6163>`_ for more information.
