print("%s %s" % ("hello", "world"))
