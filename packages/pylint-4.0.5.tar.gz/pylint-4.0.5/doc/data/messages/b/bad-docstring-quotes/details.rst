From `PEP 257`:
    "For consistency, always use ``"""triple double quotes"""`` around docstrings."
