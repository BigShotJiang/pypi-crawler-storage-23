print("{a[0] + a[1]}".format(a=[0, 1]))  # [bad-format-string]
