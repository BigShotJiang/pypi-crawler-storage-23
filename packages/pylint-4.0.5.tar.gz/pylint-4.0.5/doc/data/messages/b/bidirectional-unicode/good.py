example = "x[U+2194]" * 100
