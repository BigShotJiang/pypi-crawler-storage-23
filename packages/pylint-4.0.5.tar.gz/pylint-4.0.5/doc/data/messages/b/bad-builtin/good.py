numbers = [2 * x for x in [1, 2, 3]]
print(numbers)
