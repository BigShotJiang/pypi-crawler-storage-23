while True:
    try:
        pass
    finally:
        break  # [break-in-finally]
