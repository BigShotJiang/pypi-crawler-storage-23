while True:
    try:
        pass
    except ValueError:
        pass
    else:
        break
