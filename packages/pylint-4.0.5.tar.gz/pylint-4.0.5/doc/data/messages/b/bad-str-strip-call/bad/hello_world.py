"Hello World".strip("Hello")  # [bad-str-strip-call]
# >>> ' World'
