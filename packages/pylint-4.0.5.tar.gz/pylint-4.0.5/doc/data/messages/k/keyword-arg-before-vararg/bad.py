def func(x=None, *args):  # [keyword-arg-before-vararg]
    return [x, *args]
