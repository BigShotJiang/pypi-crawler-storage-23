import logging
import sys

logging.warning("Python version: %s", sys.version)
