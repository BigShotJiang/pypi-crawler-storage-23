FRUIT = [
    "apricot",
    "blackcurrant",
    "cantaloupe",
    "dragon fruit",
    "elderberry",
    "fig",
    "grapefruit",
]
