This message permits to allow f-string in logging and still be warned of
``logging-format-interpolation``.
