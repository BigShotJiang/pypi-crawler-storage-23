def is_an_orange(fruit):
    return fruit == "orange"
