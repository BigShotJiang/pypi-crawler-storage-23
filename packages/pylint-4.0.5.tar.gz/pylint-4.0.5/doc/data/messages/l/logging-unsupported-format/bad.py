import logging

logging.info("%s %y !", "Hello", "World")  # [logging-unsupported-format]
