import logging

logging.info("%s %s !", "Hello", "World")
