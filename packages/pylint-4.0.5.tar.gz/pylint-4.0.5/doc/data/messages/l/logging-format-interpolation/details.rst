Another reasonable option is to use f-string. If you want to do that, you need to enable
``logging-format-interpolation`` and disable ``logging-fstring-interpolation``.
