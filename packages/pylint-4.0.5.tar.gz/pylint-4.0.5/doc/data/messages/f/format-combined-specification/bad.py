print("{} {1}".format("hello", "world"))  # [format-combined-specification]
