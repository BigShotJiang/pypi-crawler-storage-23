print("{0} {1}".format("hello", "world"))
