print("number: {}".format(1))
