def test_division():
    a = 9 / 3
    assert a == 3
