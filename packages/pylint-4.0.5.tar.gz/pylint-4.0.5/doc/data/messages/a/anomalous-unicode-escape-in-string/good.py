print(b"\\u%b" % b"0394")
