class Student:
    def register(self):
        self.is_registered = True  # [attribute-defined-outside-init]
