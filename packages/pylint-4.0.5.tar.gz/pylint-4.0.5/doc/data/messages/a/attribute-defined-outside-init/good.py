class Student:
    def __init__(self):
        self.is_registered = False

    def register(self):
        self.is_registered = True
