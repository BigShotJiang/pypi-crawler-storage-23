x, y = (1, None)
assert x
assert y
