assert (1, None)  # [assert-on-tuple]
