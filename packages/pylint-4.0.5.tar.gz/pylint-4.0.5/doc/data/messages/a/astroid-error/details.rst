This is a message linked to an internal problem in pylint. There's nothing to change in your code,
but maybe in pylint's configuration or installation.
