import asyncio


async def main():
    await asyncio.sleep(1)
