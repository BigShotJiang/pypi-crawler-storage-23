def add(x, y):
    print(x + y)


value = add(10, 10)  # [assignment-from-no-return]
