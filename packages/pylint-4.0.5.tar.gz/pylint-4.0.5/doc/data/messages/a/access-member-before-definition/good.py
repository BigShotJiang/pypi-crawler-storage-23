class Unicorn:
    def __init__(self, fluffiness_level):
        self.fluffiness_level = fluffiness_level
        if self.fluffiness_level > 9000:
            print("It's OVER-FLUFFYYYY ! *crush glasses*")
