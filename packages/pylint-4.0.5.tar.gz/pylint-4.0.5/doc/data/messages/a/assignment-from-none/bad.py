def function():
    return None


f = function()  # [assignment-from-none]
