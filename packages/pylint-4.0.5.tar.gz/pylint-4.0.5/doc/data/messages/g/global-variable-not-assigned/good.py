TOMATO = "black cherry"


def update_tomato():
    global TOMATO
    TOMATO = "moneymaker"
