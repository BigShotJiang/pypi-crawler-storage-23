price = 25
global price  # [global-at-module-level]
