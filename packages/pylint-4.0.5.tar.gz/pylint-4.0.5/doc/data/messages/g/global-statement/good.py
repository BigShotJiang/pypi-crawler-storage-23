var = 1


def foo():
    print(var)
    return 10


var = foo()
print(var)
