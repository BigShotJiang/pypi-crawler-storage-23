str(42) == "42"  # [expression-not-assigned]
