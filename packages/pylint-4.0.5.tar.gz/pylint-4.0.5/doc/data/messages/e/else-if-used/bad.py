if input():
    pass
else:
    if len(input()) >= 10:  # [else-if-used]
        pass
    else:
        pass
