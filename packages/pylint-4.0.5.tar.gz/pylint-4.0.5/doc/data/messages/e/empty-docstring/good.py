def foo():
    """A dummy description."""
