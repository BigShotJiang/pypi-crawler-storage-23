eval("[1, 2, 3]")  # [eval-used]
