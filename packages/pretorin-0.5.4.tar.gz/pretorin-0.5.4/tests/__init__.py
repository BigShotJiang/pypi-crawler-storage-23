"""Tests for Pretorin CLI."""
