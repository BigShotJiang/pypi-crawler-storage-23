"""Enable running as: python -m mcp_server_unipile"""

from . import main

main()
