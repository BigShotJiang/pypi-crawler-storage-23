from django.apps import AppConfig


class FilevaultConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mojo.apps.filevault'
    verbose_name = 'FileVault'
