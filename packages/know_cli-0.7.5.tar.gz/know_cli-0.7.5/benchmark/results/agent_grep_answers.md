# Farfield Codebase Investigation Results

## Question 1: How does the billing/subscription system work?

### Subscription Model

The subscription is represented by the `WorkspaceSubscription` SQLAlchemy model in `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/models.py`. It maps to the `workspace_subscriptions` table and tracks:

- `workspace_id` (FK to workspaces, unique per workspace)
- `stripe_customer_id`, `stripe_subscription_id`
- `status` (enum: trialing, active, past_due, canceled, unpaid) via `SubscriptionStatus`
- `plan_name` (default: "pro")
- `billing_interval` (month or year)
- `seat_count` (default: 1)
- `max_concurrent_sandboxes` (default: 2)
- `trial_ends_at`, `current_period_end`, `cancel_at_period_end`

### Billing Plan Tiers and Limits

The system currently has a single plan tier called **"pro"** (the default `plan_name`). There is no evidence of multiple plan tiers (free, team, enterprise) in the codebase. Pricing is managed entirely through Stripe via two price IDs configured in `/Users/sushil/Code/Github/farfield/apps/api/src/core/config.py`:

- `stripe_price_id_monthly`
- `stripe_price_id_yearly`

Seat-based pricing: the checkout line item `quantity` equals the workspace member count. The `BillingService.sync_seat_count()` method keeps Stripe subscription quantities in sync with workspace membership changes.

New subscriptions get a **14-day trial** (`trial_period_days=14` in `create_checkout_session`).

### Sandbox Limit Enforcement

Sandbox limits are enforced through `BillingService.check_cloud_access()` in `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/service.py` (line 180). This method:

1. Checks if the workspace has a subscription at all (raises `CloudReadinessError` with code `no_subscription` if not)
2. Checks if a trial has expired (code `trial_expired`)
3. Checks if subscription is canceled or unpaid (code `subscription_inactive`)
4. Counts active cloud sessions via `SubscriptionRepository.count_active_cloud_sessions()` and compares against `max_concurrent_sandboxes` (code `concurrent_limit`)

The `count_active_cloud_sessions()` method in `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/repository.py` (line 104) counts active sandboxes by joining `CloudSession -> CodingAgentSession -> CodingAgent` and checking either:
- GKE pods: `AgentPod.status == "assigned"`
- E2B sessions: `CloudSession.cloud_status` in ("pending", "provisioning", "cloning", "running")

`check_cloud_access()` is called from `CloudSessionService` (in `/Users/sushil/Code/Github/farfield/apps/api/src/features/cloud_sessions/service.py`) at lines 223, 605, and 1485 before provisioning cloud sessions.

### Key Files

- **Model**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/models.py` - `WorkspaceSubscription`, `SubscriptionStatus`
- **Service**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/service.py` - `BillingService` with methods: `get_subscription_status()`, `create_checkout_session()`, `create_portal_session()`, `handle_webhook_event()`, `check_cloud_access()`, `sync_seat_count()`
- **Repository**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/repository.py` - `SubscriptionRepository` with `count_active_cloud_sessions()`
- **Router**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/router.py` - endpoints: `GET /status`, `POST /checkout`, `POST /portal`, `POST /webhooks`
- **Schemas**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/schemas.py` - `SubscriptionStatusResponse`, `CheckoutSessionRequest/Response`, `PortalSessionResponse`
- **Dependencies**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/billing/dependencies.py` - `BillingServiceDep`
- **Enforcement caller**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/cloud_sessions/service.py` - `CloudReadinessError`, calls `check_cloud_access()`

---

## Question 2: How does the LLM provider system work?

### Provider Configuration and Selection

LLM providers are configured through a static `SUPPORTED_MODELS` dictionary in `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/models.py`. Each model is defined as a `ModelInfo` object with: name, display_name, provider (from `ApiKeyProvider` enum), supports_tools flag, and context_window size.

Supported providers and models:
- **Anthropic**: claude-sonnet-4-5, claude-opus-4-5, claude-opus-4-6 (200K context)
- **OpenAI**: gpt-5.1, gpt-5.1-codex (128K context)
- **Gemini**: gemini-3-pro-preview, gemini-3-flash-preview (1M context), gemini-2.5-flash (1M context)
- **OpenRouter**: x-ai/grok-code-fast-1 (131K context)
- **Cursor**: acts as a proxy for all providers

The default model is `"gemini-3-flash-preview"`.

Model selection happens at the API layer: the user specifies a model name, `get_provider_for_model()` maps it to a provider, and the appropriate API key is fetched from workspace settings.

The `LLMService` class in `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/service.py` creates LangChain chat model instances via `get_chat_model()`, which dispatches to:
- `ChatAnthropic` for Anthropic
- `ChatOpenAI` for OpenAI (and OpenRouter via custom `base_url`)
- `ChatGoogleGenerativeAI` for Gemini
- `ChatVertexAI` for Vertex AI (Gemini models via Google Cloud service accounts)

Extended thinking is supported for Anthropic (via `thinking` config) and Gemini 2.5+/3+ (via `thinking_budget` or `thinking_level`).

### The `provider_discovery` Module

`/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/provider_discovery.py` provides **live model discovery** from provider APIs. The main function is `discover_models(workspace_id, db, tool_type)`.

How it works:
1. For each provider (Anthropic, OpenAI, Gemini, Cursor), it calls the respective API's model listing endpoint (e.g., `GET https://api.anthropic.com/v1/models`)
2. Results are cached in-memory for 10 minutes (`CACHE_TTL_SECONDS = 600`)
3. If no API key is configured or the API call fails, it falls back to the hardcoded `SUPPORTED_MODELS`
4. Provider-specific fetch functions: `_fetch_anthropic_models()`, `_fetch_openai_models()`, `_fetch_gemini_models()`, `_fetch_cursor_models()`
5. The `TOOL_TYPE_PROVIDERS` dict maps each `AgentToolType` to compatible providers for filtering

### Workspace-Level Model Settings

The `WorkspaceModel` SQLAlchemy model in `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/workspace_models.py` stores per-workspace model configuration in the `workspace_models` table. Fields: workspace_id, model_id, display_name, provider, is_enabled, sort_order.

The `WorkspaceModelRepository` provides CRUD operations and a `seed_defaults()` method that bulk-inserts all `SUPPORTED_MODELS` for a new workspace.

The workspace model list endpoint (`list_workspace_models` in the LLM router) merges two sources:
1. **Live-discovered models** (primary) from `discover_models()`
2. **Registry models** (admin-managed) from `WorkspaceModelRepository`

Admin overrides: admins can disable discovered models via `is_enabled=false`, or add custom models not returned by provider APIs. The `PROVIDER_TOOL_TYPES` mapping controls which providers are compatible with each agent tool type (e.g., claude_code only uses anthropic).

### Key Files

- **Models definition**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/models.py` - `ModelInfo`, `SUPPORTED_MODELS`, `DEFAULT_MODEL`, `get_provider_for_model()`
- **LLM service**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/service.py` - `LLMService.get_chat_model()`, `stream_response()`
- **Provider discovery**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/provider_discovery.py` - `discover_models()`, `_fetch_*_models()`, `DiscoveredModel`
- **Workspace models**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/workspace_models.py` - `WorkspaceModel`, `WorkspaceModelRepository`, `_providers_for_tool_type()`
- **Router**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/llm/router.py` - `list_models()`, `list_workspace_models()`, CRUD endpoints for admin model management

---

## Question 3: How does the agent execution pipeline work?

### Flow from User Message to Agent Response

There are two main execution paths:

**Path 1: CLI/GitHub Planning Agent** (via `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/router.py`)

1. User sends POST to `/sessions` with `initial_message`, `model`, `source` (github or cli), and optionally `repo_id` or `codebase_context`
2. `create_session()` endpoint:
   - Resolves the model's provider via `get_provider_for_model()`, fetches the API key
   - Creates a context provider: `LocalFSProvider` (for GitHub repos, cloned locally) or `PassthroughProvider` (for CLI-sent context)
   - Creates tools via `create_tools(provider)` + `create_research_tools()`
   - Instantiates the LLM via `LLMService.get_chat_model()`
   - Creates the LangGraph agent via `create_planning_agent(model, tools)`
   - Returns a `StreamingResponse` wrapping `stream_agent_response()`
3. For follow-up messages: POST to `/sessions/{session_id}/messages` reconstructs the provider and agent, loads existing messages via `deserialize_messages()`, and streams again

**Path 2: Web Plan Threads** (via `/Users/sushil/Code/Github/farfield/apps/api/src/features/plans/router.py`)

1. User sends POST to `/{plan_slug}/threads/{thread_id}/ai-response`
2. `generate_ai_response()` endpoint:
   - Gets the plan and thread with message history
   - Creates plan tools (`read_plan`, `edit_plan`) + codebase tools (if plan has linked repos) + research tools
   - Builds clarification context (expertise analysis, domain questions)
   - Returns a `StreamingResponse` wrapping `stream_thread_agent_response()`

### Role of LangGraph

LangGraph is the core orchestration framework. The agent graph is built in `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/graph.py` via `create_planning_agent()`:

1. Creates a `StateGraph` with `PlanningState` as the state type
2. Two nodes: `"agent"` (LLM decision-maker) and `"tools"` (LangGraph's built-in `ToolNode`)
3. Entry point is `"agent"`
4. Conditional edge from `"agent"`: if last message has `tool_calls` -> go to `"tools"`, otherwise -> `END`
5. Edge from `"tools"` -> back to `"agent"` (creates the agent loop)
6. Compiled with optional `AsyncPostgresSaver` checkpointer for session persistence

The `PlanningState` (in `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/state.py`) uses LangGraph's `add_messages` annotation for automatic message accumulation. Fields: messages, context_source, repo_path, session_id, clarification_context.

The `agent_node` function builds a system prompt from `system.md` + optional clarification context + domain questions + command instructions, then invokes the model with tools bound via `model.bind_tools(tools)`.

### Tools and MCP Integration

**Built-in Agent Tools** (in `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/tools.py`):

`create_tools(provider)` creates LangChain `@tool`-decorated functions backed by a `ContextProvider`:
- `read_file(path)` - read file content
- `list_directory(path)` - list directory entries
- `search_code(pattern)` - regex search across codebase
- `get_file_tree()` - project structure tree
- `get_dependencies()` - project dependencies
- `find_relevant_files(query)` - semantic file discovery
- `get_file_overview(path)` - structural overview (classes, functions)

`create_plan_tools(plan_context)` creates plan-specific tools:
- `read_plan()` - read current plan content
- `edit_plan(old_text, new_text)` - surgical find/replace on plan (emits `PlanEdit` via contextvars callback)

`create_research_tools(tavily_api_key, exa_api_key)` creates web search tools:
- `research_web(query)` - uses Exa (preferred) or Tavily for web search

**Agent Daemon** (local process management in `/Users/sushil/Code/Github/farfield/packages/agent-daemon/`):

The agent daemon is a Node.js WebSocket server that manages local coding agent processes:
- `ProcessManager` (in `process-manager.ts`) spawns CLI tools as child processes: `claude` (Claude Code), `codex` (Codex CLI), `cursor-agent` (Cursor Agent)
- Server (in `server.ts`) accepts WebSocket connections, handles auth, spawn, kill, list_sessions, check_tool messages
- Discovery (in `discovery.ts`) uses a beacon file at `~/.farfield/daemon.json` for client discovery on ports 19542-19544

**MCP Server** (in `/Users/sushil/Code/Github/farfield/packages/tauri-mcp-server/`):

The `tauri-mcp-server` is an MCP server (using `@modelcontextprotocol/sdk`) for testing the Farfield Tauri desktop app. It provides tools for screenshots, DOM inspection, clicking, form filling, JavaScript execution, and window management via IPC socket to the Tauri app.

**Cloud Execution** uses E2B sandboxes or GKE pods managed by `CloudSessionService` in `/Users/sushil/Code/Github/farfield/apps/api/src/features/cloud_sessions/service.py`, with billing enforcement via `check_cloud_access()`.

### Streaming

The streaming layer in `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/streaming.py` handles:
- `stream_agent_response()` - for CLI/GitHub sessions
- `stream_thread_agent_response()` - for web plan threads

Both use LangGraph's `agent.astream()` with `stream_mode=["messages", "updates"]` and emit SSE events:
- `thinking` - extended thinking content
- `token` - text response tokens
- `tool_call` - tool invocation with name and args
- `tool_result` - tool execution results
- `plan_edit` - plan modifications
- `done` - completion signal
- `error` - error messages

Key helper functions: `extract_text_content()` (skips thinking blocks), `extract_thinking_content()`, `strip_role_prefix()`.

### Key Files

- **Agent graph**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/graph.py` - `create_planning_agent()`
- **Agent state**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/state.py` - `PlanningState`
- **Agent tools**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/tools.py` - `create_tools()`, `create_plan_tools()`, `create_research_tools()`
- **Agent streaming**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/streaming.py` - `stream_agent_response()`, `stream_thread_agent_response()`
- **Agent router (CLI)**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/agent/router.py` - `create_session()`, `send_message()`
- **Plans router (web)**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/plans/router.py` - `generate_ai_response()`
- **Agent daemon**: `/Users/sushil/Code/Github/farfield/packages/agent-daemon/src/process-manager.ts` - `ProcessManager.spawnAgent()`
- **Daemon server**: `/Users/sushil/Code/Github/farfield/packages/agent-daemon/src/server.ts` - WebSocket server
- **MCP server**: `/Users/sushil/Code/Github/farfield/packages/tauri-mcp-server/src/index.ts` - Tauri testing MCP server
- **Coding agent models**: `/Users/sushil/Code/Github/farfield/apps/api/src/features/coding_agents/models.py` - `AgentToolType`, `CodingAgent`, `CodingAgentSession`, `CloudSession`, `AgentPod`
