"""Decorator components for routing, DI, and configuration"""
