"""Configuration management components"""
