"""Core framework components"""
