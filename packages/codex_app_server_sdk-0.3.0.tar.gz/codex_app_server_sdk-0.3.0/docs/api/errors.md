# `codex_app_server_sdk.errors`

::: codex_app_server_sdk.errors
