SELECT 1 AS value, 'hello' AS greeting;
