# dagster-ge

The docs for `dagster-ge` can be found
[here](https://docs.dagster.io/integrations/libraries/great-expectations/dagster-ge).
