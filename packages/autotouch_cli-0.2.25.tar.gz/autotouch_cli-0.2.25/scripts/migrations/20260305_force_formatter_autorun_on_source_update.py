#!/usr/bin/env python3
"""
Normalize formatter columns to auto-run on source updates.

Why:
- Formatter columns should be reactive transforms.
- Legacy records may still have auto_run=never/onInsert or a conflicting legacy autoRun field.

What this migration does:
1) Finds formatter columns with missing/legacy auto-run values.
2) Sets `auto_run` to `onSourceUpdate`.
3) Removes legacy `autoRun` to avoid precedence conflicts in payload serialization.

Usage:
  python scripts/migrations/20260305_force_formatter_autorun_on_source_update.py

Environment variables:
  MONGODB_URI      (default: mongodb://localhost:27017)
  MONGODB_DB_NAME  (default: autotouch)
  DRY_RUN          (default: false)
"""

import asyncio
import os
from datetime import datetime
from typing import Any, Dict

from motor.motor_asyncio import AsyncIOMotorClient


MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "autotouch")
DRY_RUN = os.getenv("DRY_RUN", "false").strip().lower() == "true"


def _formatter_query() -> Dict[str, Any]:
    return {
        "kind": "formatter",
        "$or": [
            {"auto_run": {"$exists": False}},
            {"auto_run": {"$in": [None, "", "never", "onInsert"]}},
            {"autoRun": {"$exists": True}},
        ],
    }


async def run() -> None:
    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]

    try:
        print(f"Starting formatter auto-run migration on db={MONGODB_DB_NAME}")
        print(f"Timestamp: {datetime.utcnow().isoformat()}Z")
        print(f"DRY_RUN={DRY_RUN}")

        query = _formatter_query()
        candidates = await db.columns.count_documents(query)
        print(f"Formatter columns to normalize: {candidates}")

        if candidates == 0:
            print("No formatter columns require migration.")
            return

        sample = await db.columns.find(
            query,
            {"_id": 1, "key": 1, "auto_run": 1, "autoRun": 1},
        ).limit(5).to_list(length=5)
        print("Sample candidates:")
        for col in sample:
            print(
                f"- id={col.get('_id')} key={col.get('key')} "
                f"auto_run={col.get('auto_run')} autoRun={col.get('autoRun')}"
            )

        if DRY_RUN:
            print("DRY_RUN enabled; no updates applied.")
            return

        now = datetime.utcnow()
        result = await db.columns.update_many(
            query,
            {
                "$set": {
                    "auto_run": "onSourceUpdate",
                    "updated_at": now,
                },
                "$unset": {"autoRun": ""},
            },
        )
        print(f"Matched: {result.matched_count}")
        print(f"Modified: {result.modified_count}")
        print("Migration complete.")
    finally:
        client.close()


if __name__ == "__main__":
    asyncio.run(run())
