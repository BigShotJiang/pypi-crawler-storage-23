# primelog/core/constants.py
"""PrimeLog 内部关系类型素数映射表 - 按调用频率分配素数（频率越高素数越小）

版本：2.0（开发版）
注意：此版本与之前版本不兼容，所有素数已重新分配。
素数分配严格遵循：频率越高，素数越小。
所有键名均与 _RELATION_RULES 中的返回值保持一致。
"""

RELATION_PRIME_MAP = {
    # ============================================================
    # 🔥 超高频（每秒上万次） - 使用最小的素数
    # ============================================================
    "io": 2,               # I/O操作（read/write/open/close等）
    "import": 3,           # 动态导入（import_module/require等）
    "serialize": 5,        # 序列化（to_json/from_json/pickle等）
    "log": 7,              # 日志记录（debug/info/warn/error等）
    "iterate": 11,         # 迭代操作（for_each/map/filter等）

    # ============================================================
    # 🔥 高频（每分钟上千次）
    # ============================================================
    "http_request": 13,    # HTTP请求（get/post/put/delete等）
    "db_query": 17,        # 数据库查询（query/fetch/select等）
    "cache_get": 19,       # 缓存读取（get_cache/read_cache等）
    "config_read": 23,     # 配置读取（get_config/read_config）
    "rpc": 29,             # RPC调用（rpc_call/invoke）

    # ============================================================
    # 中频（每小时几十到几百次）
    # ============================================================
    "file_io": 31,         # 文件读写（read_file/write_file等）
    "validation": 37,      # 数据校验（validate/check/verify）
    "metrics": 41,         # 指标采集（metric/record/count）
    "pipeline": 43,        # 流水线/流处理（pipe/stream/process）
    "lock_acquire": 47,    # 锁获取（lock_acquire/acquire_lock）

    # ============================================================
    # 低频（每天几次到几十次）
    # ============================================================
    "init": 53,            # 初始化（init/setup/bootstrap）
    "config_write": 59,    # 配置写入（set_config/write_config）
    "cache_set": 61,       # 缓存写入（set_cache/write_cache）
    "transaction": 67,     # 事务（begin/commit/rollback）
    "notification": 71,    # 通知（send/notify/alert）

    # ============================================================
    # 极低频（程序生命周期一次或更低）
    # ============================================================
    "internal.sync": 73,   # 同步内部调用（由 get_/set_ 等通用规则返回）
    "internal.async": 79,  # 异步内部调用（由 async 上下文推断）
    "internal.event": 83,  # 内部事件（emit/fire_event等，暂未使用）
    "internal.config": 89, # 内部配置操作（暂未使用）
    "internal.registry": 97, # 注册中心操作（register/lookup等）
    "runtime": 101,        # 运行时依赖（默认素数）
    "destroy": 103,        # 销毁（close/destroy/cleanup）
    "health_check": 107,   # 健康检查（health/ping/status）
    "lock": 109,           # 通用锁操作（lock/unlock）
    "cache": 113,          # 通用缓存操作（cache_delete等）

    # 预留空间（如需添加新类型，请从下一个素数 127 开始）
    # 注意：新类型若频率较高，请慎重考虑是否应调整分组，但已有类型的素数严禁修改！
}

# 下一个可用素数：127（用于未来扩展）