import json
import time
from pathlib import Path
import jwt
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import os

class TokenManager:
    def __init__(self):
        self.cache_dir = Path.home() / '.postlocker'
        self.tokens_file = self.cache_dir / 'tokens.json'
        self.key_file = self.cache_dir / '.key'
        self._ensure_cache_dir()
        self._ensure_encryption_key()

    def _ensure_cache_dir(self):
        """Ensure the cache directory exists"""
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _ensure_encryption_key(self):
        """Create or load the encryption key"""
        if not self.key_file.exists():
            # Generate a random salt
            salt = os.urandom(16)
            # Use machine-specific info as password
            machine_info = self._get_machine_specific_info()
            
            # Generate key using PBKDF2
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=100000,
            )
            key = base64.urlsafe_b64encode(kdf.derive(machine_info.encode()))
            
            # Save salt and key
            with open(self.key_file, 'wb') as f:
                f.write(salt + key)
        
        # Load the existing key
        with open(self.key_file, 'rb') as f:
            data = f.read()
            salt = data[:16]
            self.key = data[16:]
        
        self.fernet = Fernet(self.key)

    def _get_machine_specific_info(self) -> str:
        """Get machine-specific information to derive encryption key"""
        # This could be enhanced with more machine-specific identifiers
        return os.path.expanduser('~')

    def _encrypt_token(self, token: str) -> str:
        """Encrypt a token"""
        return self.fernet.encrypt(token.encode()).decode()

    def _decrypt_token(self, encrypted_token: str) -> str:
        """Decrypt a token"""
        return self.fernet.decrypt(encrypted_token.encode()).decode()

    def _get_host_key(self, host: str) -> str:
        """Generate a safe key from host URL"""
        host = host.lower().replace('https://', '').replace('http://', '')
        return base64.urlsafe_b64encode(host.encode()).decode()

    def save_token(self, token: str, host: str = "https://api.postlocker.app"):
        """Save encrypted token with its metadata for a specific host"""
        try:
            tokens_data = {}
            if self.tokens_file.exists():
                with open(self.tokens_file, 'r') as f:
                    tokens_data = json.load(f)

            decoded = jwt.decode(token, options={"verify_signature": False})
            host_key = self._get_host_key(host)
            
            encrypted_token = self._encrypt_token(token)
            tokens_data[host_key] = {
                'token': encrypted_token,
                'expires_at': decoded.get('exp', 0),
                'host': host
            }

            with open(self.tokens_file, 'w') as f:
                json.dump(tokens_data, f)
        except Exception as e:
            print(f"Warning: Could not cache token: {e}")

    def get_valid_token(self, host: str = "https://api.postlocker.app"):
        """Get cached token for specific host if it exists and is valid"""
        try:
            if not self.tokens_file.exists():
                return None

            with open(self.tokens_file, 'r') as f:
                tokens_data = json.load(f)

            host_key = self._get_host_key(host)
            token_data = tokens_data.get(host_key)

            if not token_data:
                return None

            if token_data['expires_at'] > time.time() + 60:
                return self._decrypt_token(token_data['token'])

            return None
        except Exception as e:
            print(f"Warning: Could not retrieve cached token: {e}")
            return None

    def clear_token(self, host: str = "https://api.postlocker.app"):
        """Clear cached token for specific host"""
        if not self.tokens_file.exists():
            return

        try:
            with open(self.tokens_file, 'r') as f:
                tokens_data = json.load(f)

            host_key = self._get_host_key(host)
            if host_key in tokens_data:
                del tokens_data[host_key]

            with open(self.tokens_file, 'w') as f:
                json.dump(tokens_data, f)
        except Exception:
            pass

    def clear_all_tokens(self):
        """Clear all cached tokens"""
        if self.tokens_file.exists():
            self.tokens_file.unlink()