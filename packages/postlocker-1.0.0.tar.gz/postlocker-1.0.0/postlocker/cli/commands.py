"""CLI commands for PostLocker."""

import click
import sys
from getpass import getpass
from typing import Optional, List
import json
import time
from datetime import datetime
from datetime import timezone

from postlocker.postlocker import generate_password

@click.group()
def cli():
    """PostLocker CLI - Manage your saved content"""
    pass

@cli.group()
def tokens():
    """Manage cached tokens"""
    pass

@tokens.command(name='clear')
def tokens_clear():
    """Clear all cached tokens"""
    from postlocker.token_manager import TokenManager
    
    token_manager = TokenManager()
    token_manager.clear_all_tokens()
    click.echo("All cached tokens have been cleared.")

@tokens.command(name='list')
def tokens_list():
    """List all cached tokens"""
    from postlocker.token_manager import TokenManager
    import json
    from datetime import datetime
    
    token_manager = TokenManager()
    
    if not token_manager.tokens_file.exists():
        click.echo("No cached tokens found.")
        return
        
    try:
        with open(token_manager.tokens_file, 'r') as f:
            tokens_data = json.load(f)
            
        if not tokens_data:
            click.echo("No cached tokens found.")
            return
            
        click.echo(f"\nFound {len(tokens_data)} cached tokens:")
        click.echo("---")
        for host_key, data in tokens_data.items():
            expires_at = datetime.fromtimestamp(data['expires_at'])
            is_expired = data['expires_at'] <= time.time()
            
            click.echo(f"\nHost: {data['host']}")
            click.echo(f"Status: {'Expired' if is_expired else 'Valid'}")
            click.echo(f"Expires: {expires_at}")
            
    except Exception as e:
        click.echo(f"Error reading tokens: {str(e)}")
        sys.exit(1)

def get_credentials(email: Optional[str], host: Optional[str]) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """Get credentials, prompting only if necessary"""
    from postlocker.postlocker import PostLocker
    
    pl = PostLocker(base_url=host) if host else PostLocker()
    # Check if we have a valid cached token
    token = pl.token_manager.get_valid_token(host) if host else pl.token_manager.get_valid_token()
    
    # If no valid token, we need credentials
    if not token:
        email = email or click.prompt('Email', type=str)
        password = getpass('Password: ')
        return email, password, None
    
    return None, None, token

@cli.command()
@click.argument('content')
@click.option('--tags', '-T', multiple=True, help='Tags for the content (can be specified multiple times)')
@click.option('--groups', '-G', multiple=True, help='Group ids to add the content to (can be specified multiple times)')
@click.option('--note', '-n', help='Add a note to the save')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def save(content, tags, groups, note, host):
    """Save content to PostLocker"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        # Save the content first
        result = pl.save(content)
        save_id = result['id']
        
        # Add to groups if specified
        for group in groups or []:
            try:
                pl.add_to_group(save_id, group)
            except PostLockerException as e:
                click.echo(f"Warning: Failed to add to group '{group}': {str(e)}")

        # Add tags if specified
        for tag in tags or []:
            try:
                pl.add_tag(save_id, tag)
            except PostLockerException as e:
                click.echo(f"Warning: Failed to add tag '{tag}': {str(e)}")

        # Add note if specified
        if note:
            try:
                pl.add_note_to_save(save_id, note)
            except PostLockerException as e:
                click.echo(f"Warning: Failed to add note: {str(e)}")

        click.echo(f"Content saved successfully! ID: {save_id}")
        
        # Show summary of what was added
        if groups:
            click.echo(f"Added to groups: {', '.join(groups)}")
        if tags:
            click.echo(f"Added tags: {', '.join(tags)}")
        if note:
            click.echo("Added note to save")
            
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@cli.command()
@click.argument('id', required=False)
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def delete(id, host):
    """Delete content from PostLocker by ID"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        # Handle piped input
        ids = get_piped_ids() if not id else [id]
        if not ids:
            click.echo("Error: No save ID provided")
            sys.exit(1)
            
        for save_id in ids:
            try:
                pl.delete(save_id)
                click.echo(f"Content with ID {save_id} deleted successfully!")
            except PostLockerException as e:
                click.echo(f"Error deleting {save_id}: {str(e)}")
                
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

def _get_title_from_meta(save):
    """Helper function to get title from save metadata"""
    return next((meta['value'] for meta in save['meta'] if meta['key'] == 'title'), None)

@cli.command()
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data (if there is --since, only the updated saves are displayed, not the deleted or groups)')
@click.option('--summary', is_flag=True, help='Show AI summary for each save')
@click.option('--limit', '-l', type=int, help='Limit the number of saves to display')
@click.option('--offset', '-s', type=int, default=0, help='Number of saves to skip')
@click.option('--pipe', is_flag=True, help='Output only save IDs for piping')
@click.option('--since', '-t', type=str, help="only list the saves and groups updated and deleted since this timestamp (ISO format)")
@click.option('--content-type', '-c', help='Filter by content type')
def list(host, raw, summary, limit, offset, pipe, since, content_type):
    """List all saved content"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        try:
            since_date = datetime.fromisoformat(since) if since else None
        except ValueError:
            click.echo(f"Error: Invalid timestamp format: {since}")
            sys.exit(1)
            
            
        response = pl.get_all(since=since_date, content_type=content_type)
        if since:
            since_response = response['updated_since']
            saves = response['saves']
            deleted = response['deleted']
            groups = response['groups']
        else:
            saves = response
        
        # Apply offset and limit if specified
        saves = saves[offset:]
        if limit is not None:
            saves = saves[:limit]
            
        if pipe:
            # Just output IDs for piping
            for save in saves:
                click.echo(save['id'])
        else:
            if raw:
                click.echo(json.dumps(saves, indent=2, default=str))
            else:
                if since:
                    click.echo(f"========== SAVES updated since {since} ==========")
                    click.echo(f"Found {len(saves)} saves updated since {since}:")
                else:
                    click.echo(f"\nFound {len(saves)} saves:")
                click.echo("---")
                for save in saves:
                    format_save_for_display(save, raw=False, summary=summary)
                if since:
                    click.echo(f"========== GROUPS updated since {since} ==========")
                    click.echo(f"Found {len(groups)} groups.")
                    for group in groups:
                        click.echo(f"{group['name']}")
                    
                    click.echo(f"\n========== DELETED objects since {since} ==========")
                    click.echo(f"Found {len(deleted)} deleted objects.")
                    for deleted_object in deleted:
                        click.echo(f"{deleted_object['object_id']} : {deleted_object['object_type']}")
                        
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@cli.command()
@click.argument('id')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def get(id, host):
    """Get content by ID"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        save = pl.get_by_id(id)
        
        click.echo(json.dumps(save, indent=2, default=str))
        
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@cli.command()
@click.argument('query')
@click.option('--limit', '-l', help='Maximum number of results')
@click.option('--semantic/--no-semantic', default=True, help='Use semantic search')
@click.option('--distance', '-d', type=float, help='Semantic search distance threshold')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
@click.option('--summary', is_flag=True, help='Show AI summary for each save')
@click.option('--group', '-g', help='Filter by group name')
@click.option('--pipe', is_flag=True, help='Output only save IDs for piping')
@click.option('--content-type', '-c', help='Filter by content type')
def search(query, limit, semantic, distance, host, raw, summary, group, pipe, content_type):
    """Search saved content"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        results = pl.search(query, limit=limit, semantic=semantic, distance=distance, group=group, content_type=content_type)
        
        if pipe:
            # Just output IDs for piping
            for save in results:
                click.echo(save['id'])
        else:
            if raw:
                click.echo(json.dumps(results, indent=2, default=str))
            else:
                click.echo(f"\nFound {len(results)} results:")
                click.echo("---")
                for save in results:
                    format_save_for_display(save, raw=False, summary=summary)
                    
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@cli.command()
@click.option('--output', '-o', help='Output file (if not provided, prints to stdout)')
@click.option('--format', '-f', type=click.Choice(['json', 'csv']), default='json',
              help='Export format (json or csv)')
@click.option('--pretty', '-p', is_flag=True, help='Pretty print JSON output')
@click.option('--limit', '-l', type=int, help='Limit the number of saves to export')
@click.option('--offset', '-s', type=int, default=0, help='Number of saves to skip before starting export')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def export(output, format, pretty, limit, offset, host):
    """Export saved content to JSON or CSV format"""
    from postlocker.postlocker import PostLocker, PostLockerException
    from postlocker.exporters import JSONExporter, CSVExporter
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        # Check for piped input
        piped_ids = get_piped_ids()
        
        if piped_ids:
            # If we have piped input, get those specific saves
            saves = []
            for save_id in piped_ids:
                try:
                    save = pl.get_by_id(save_id)
                    saves.append(save)
                except PostLockerException as e:
                    click.echo(f"Warning: Could not get save {save_id}: {str(e)}", err=True)
        else:
            # Otherwise get all saves as before
            saves = pl.get_all()
            
            # Apply offset and limit if specified
            saves = saves[offset:]
            if limit is not None:
                saves = saves[:limit]
        
        if format == 'json':
            exporter = JSONExporter()
            result = exporter.export(saves)
            if output:
                exporter.save_to_file(output, saves, pretty=pretty)
                click.echo(f"Saved {len(saves)} items to {output}")
            else:
                click.echo(result)
        else:  # CSV format
            if not output:
                click.echo("Error: CSV export requires an output file")
                sys.exit(1)
            exporter = CSVExporter(output)
            exporter.export(saves)
            click.echo(f"Saved {len(saves)} items to {output}")
            
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@cli.command(name='import')
@click.argument('filename')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--delay', '-d', default=0.5, type=float, help='Delay in seconds between importing each save')
@click.option('--limit', '-l', type=int, help='Limit the number of saves to import')
@click.option('--offset', '-s', type=int, default=0, help='Number of saves to skip before starting import')
@click.option('--pipe', is_flag=True, help='Output save IDs for piping')
def import_saves(filename, host, delay, limit, offset, pipe):
    """Import content from a CSV file"""
    from postlocker.postlocker import PostLocker, PostLockerException
    from postlocker.exporters import CSVExporter
    import time
    
    if not filename.endswith('.csv'):
        click.echo("Error: Only CSV import is currently supported")
        sys.exit(1)
        
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        # Import from CSV
        exporter = CSVExporter(filename)
        saves = exporter.import_from_csv(filename)
        
        # Apply offset and limit if specified
        saves = saves[offset:]
        if limit is not None:
            saves = saves[:limit]
        
        imported_ids = []
        with click.progressbar(saves, label='Importing saves') as saves_bar:
            for save in saves_bar:
                try:
                    result = pl.save(save["content"])
                    imported_ids.append(result['id'])
                    time.sleep(delay)
                except PostLockerException as e:
                    click.echo(f"Error importing save: {str(e)}", err=True)
                
        if pipe:
            # Output just the IDs for piping
            for save_id in imported_ids:
                click.echo(save_id)
        else:
            click.echo(f"Successfully imported {len(imported_ids)} items from {filename}")
            
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error reading file: {str(e)}")
        sys.exit(1)

@cli.group()
def groups():
    """Manage content groups"""
    pass

@groups.command(name='list')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
def groups_list(host, raw):
    """List all content groups"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        groups = pl.list_groups()
        if raw:
            click.echo(json.dumps(groups, indent=2, default=str))
        else:
            click.echo(f"\nFound {len(groups)} groups:")
            click.echo("---")
            for group in groups:
                click.echo(f"Name: {group['name']}")
                if 'description' in group and group['description']:
                    click.echo(f"Description: {group['description']}")
                click.echo("---")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@groups.command(name='search')
@click.argument('query')
@click.option('--limit', '-l', type=int, default=10, help='Maximum number of results')
@click.option('--offset', '-o', type=int, default=0, help='Number of results to skip')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
def search_groups(query, host, raw, limit, offset):
    """Search for groups by name"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        groups = pl.search_groups(query, limit=limit, offset=offset)
        if raw:
            click.echo(json.dumps(groups, indent=2, default=str))
        else:
            for group in groups:
                click.echo(f"Name: {group['name']}")    
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@groups.command(name='get')
@click.argument('id')
@click.argument('save_ids', required=False, nargs=-1)
@click.option('--add', '-a', is_flag=True, help='Add a save ID to this group')
@click.option('--delete', '-d', is_flag=True, help='Remove a save ID from this group')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
@click.option('--pipe', is_flag=True, help='Output only save IDs for piping')
@click.option('--limit', '-l', type=int, help='Limit the number of saves to display')
@click.option('--offset', '-s', type=int, default=0, help='Number of saves to skip')
@click.option('--summary', is_flag=True, help='Show AI summary for each save')
def get_group(id, save_ids, add, delete, host, raw, pipe, limit, offset, summary):
    """Get content from a specific group or modify group contents with the add/delete options (add/delete cannot be used together and if neither are used, the group content is displayed)"""
    from postlocker.postlocker import PostLocker, PostLockerException
    if add and delete:
        click.echo("Error: Cannot use add and delete options together")
        sys.exit(1)
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        if add or delete:
            if not save_ids:
                piped_ids = get_piped_ids()
                if piped_ids:
                    save_ids = piped_ids
                else:
                    click.echo("Error: No save IDs provided")
                    sys.exit(1)
            successful_saves = []
            for save_id in save_ids:
                if add:
                    try:
                        result = pl.add_to_group(save_id, id)
                        successful_saves.append(save_id)
                        if not pipe:
                            click.echo(f"Successfully added save {save_id} to group '{id}'")
                            format_save_for_display(result, raw=raw, summary=summary)
                    except PostLockerException as e:
                        click.echo(f"Error adding {save_id}: {str(e)}")
                elif delete:
                    try:
                        result = pl.remove_from_group(save_id, id)
                        successful_saves.append(save_id)
                        if not pipe:
                            click.echo(f"Successfully removed save {save_id} from group '{id}'")
                            format_save_for_display(result, raw=raw, summary=summary)
                    except PostLockerException as e:
                        click.echo(f"Error removing {save_id}: {str(e)}")
        else:
            # If no add/delete option, get group content
            group_content = pl.get_group_by_id(id)
            
            # Apply offset and limit if specified
            group_content = group_content[offset:]
            if limit is not None:
                group_content = group_content[:limit]
        
        if pipe:
            # Just output IDs for piping
            if add or delete:
                for save_id in successful_saves:
                    click.echo(save_id)
            else:
                for save in group_content:
                    click.echo(save['id'])
        else:
            if not raw: 
                click.echo(f"\nGroup: {id}")
                click.echo(f"\nFound {len(group_content)} saves in group:")
                click.echo("---")
            for save in group_content:
                format_save_for_display(save, raw=raw, summary=summary)
                
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@groups.command(name='create')
@click.argument('name')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def create_group(name, host):
    """Create a new group"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        result = pl.create_group(name)
        click.echo(f"Successfully created group '{name}'")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@groups.command(name='rm')
@click.argument('id')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def delete_group(id, host):
    """Delete a group"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        result = pl.delete_group(id)
        click.echo(f"Successfully deleted group '{id}'")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)
        
@cli.command()
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def clear(host):
    """Delete ALL saves and groups from your account (WARNING: DESTRUCTIVE ACTION)"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    click.echo(f"WARNING: This will DELETE ALL saves and groups from your PostLocker account on host {host}!")
    click.echo("This action cannot be undone!")
    click.echo("\nTo confirm, please type 'Yes' (case-sensitive):")
    
    confirmation = input()
    if confirmation != "Yes":
        click.echo("Operation cancelled.")
        return
        
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        # First delete all groups
        groups = pl.list_groups()
        with click.progressbar(groups, label='Deleting groups') as groups_bar:
            for group in groups_bar:
                pl.delete_group(group['id'])

        # Then delete all saves
        saves = pl.get_all()
        with click.progressbar(saves, label='Deleting saves') as saves_bar:
            for save in saves_bar:
                pl.delete(save['id'])
                
        click.echo(f"\nSuccessfully deleted {len(saves)} saves and {len(groups)} groups.")
            
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@cli.group()
def users():
    """Manage user information"""
    pass

@users.command(name='me')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
def user_me(host, raw):
    """Get current user information"""
    from postlocker.postlocker import PostLocker, PostLockerException
    from datetime import datetime
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        user_info = pl.get_user()
        if raw:
            click.echo(json.dumps(user_info, indent=2, default=str))
        else:
            click.echo("\nUser Information:")
            click.echo(f"Email: {user_info.get('email')}")
            click.echo(f"Status: {'Active' if user_info.get('is_active') else 'Inactive'}")
            click.echo(f"Verified: {'Yes' if user_info.get('is_verified') else 'No'}")
            click.echo(f"Admin: {'Yes' if user_info.get('is_superuser') else 'No'}")
            
            # Format dates nicely in local timezone
            if user_info.get('last_login'):
                utc_time = datetime.fromisoformat(user_info['last_login'].replace('Z', '+00:00'))
                local_time = utc_time.astimezone()
                tz_name = datetime.now().astimezone().tzinfo
                click.echo(f"Last Token Refresh: {local_time.strftime('%Y-%m-%d %H:%M:%S')} ({tz_name})")
            
            if user_info.get('created_at'):
                utc_time = datetime.fromisoformat(user_info['created_at'].replace('Z', '+00:00'))
                local_time = utc_time.astimezone()
                tz_name = datetime.now().astimezone().tzinfo
                click.echo(f"Account Created: {local_time.strftime('%Y-%m-%d %H:%M:%S')} ({tz_name})\n")
            
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)


@users.command(name='get')
@click.argument('email')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
def get_user(email, host, raw):
    """Get user information"""
    from postlocker.postlocker import PostLocker, PostLockerException 

    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1) 

        user_info = pl.get_user(email)
        if raw:
            click.echo(json.dumps(user_info, indent=2, default=str))   
        else:
            click.echo(f"Email: {user_info.get('email')}")
            click.echo(f"Status: {'Active' if user_info.get('is_active') else 'Inactive'}")
            click.echo(f"Verified: {'Yes' if user_info.get('is_verified') else 'No'}")
            click.echo(f"Admin: {'Yes' if user_info.get('is_superuser') else 'No'}")
            
            # Format dates nicely in local timezone
            if user_info.get('last_login'):
                utc_time = datetime.fromisoformat(user_info['last_login'].replace('Z', '+00:00'))
                local_time = utc_time.astimezone()
                tz_name = datetime.now().astimezone().tzinfo
                click.echo(f"Last Token Refresh: {local_time.strftime('%Y-%m-%d %H:%M:%S')} ({tz_name})")
            
            if user_info.get('created_at'):
                utc_time = datetime.fromisoformat(user_info['created_at'].replace('Z', '+00:00'))
                local_time = utc_time.astimezone()
                tz_name = datetime.now().astimezone().tzinfo
                click.echo(f"Account Created: {local_time.strftime('%Y-%m-%d %H:%M:%S')} ({tz_name})\n")
            
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@cli.group()
def tags():
    """Manage tags"""
    pass

@tags.command(name='list')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
def list_tags(host, raw):
    """List all tags"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        tags = pl.get_all_tags()
        if raw:
            click.echo(json.dumps(tags, indent=2, default=str))
        else:
            click.echo(f"\nFound {len(tags)} tags:")
            click.echo("---")
            for tag in tags:
                click.echo(f"{tag['name']}")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@tags.command(name='get')
@click.argument('tag')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
def get_saves_by_tag(tag, host, raw):
    """Get saves by tag"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        saves = pl.get_saves_by_tag(tag)
        if raw:
            click.echo(json.dumps(saves, indent=2, default=str))
        else:
            click.echo(f"\nFound {len(saves)} saves with tag '{tag}':")
            click.echo("---")
            for save in saves:
                click.echo(f"ID: {save['id']}")
                title = _get_title_from_meta(save)
                if title:
                    click.echo(f"Title: {title}")
                click.echo(f"Content: {save['content']}")
                click.echo("---")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@tags.command(name='add')
@click.argument('save_id')
@click.argument('tag')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def add_tag(save_id, tag, host):
    """Add a tag to a save"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        result = pl.add_tag(save_id, tag)
        click.echo(f"Successfully added tag '{tag}' to save {save_id}")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@tags.command(name='remove')
@click.argument('save_id')
@click.argument('tag')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def remove_tag(save_id, tag, host):
    """Remove a tag from a save"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        result = pl.remove_tag(save_id, tag)
        click.echo(f"Successfully removed tag '{tag}' from save {save_id}")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@cli.command(name='related')
@click.argument('save_id')
@click.option('--limit', '-l', help='Maximum number of results')
@click.option('--distance', '-d', help='Semantic search distance threshold')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
def get_related_saves(save_id, limit, distance, host, raw):
    """Get related saves"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        related_saves = pl.get_related_saves(save_id, limit=limit, distance=distance)
        if raw:
            click.echo(json.dumps(related_saves, indent=2, default=str))
        else:
            click.echo(f"\nFound {len(related_saves)} related saves:")
            click.echo("---")
            for save in related_saves:
                click.echo(f"ID: {save['id']}")
                title = _get_title_from_meta(save)
                if title:
                    click.echo(f"Title: {title}")
                click.echo(f"Content: {save['content']}")
                click.echo("---")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@users.command(name='list')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
@click.option('--limit', '-l', type=int, help='Limit the number of users to display')
@click.option('--offset', '-o', type=int, default=0, help='Number of users to skip')
@click.option('--include-length', is_flag=True, help='Include the number of saves for each user in the output')
def list_users(host, raw, limit, offset, include_length):
    """List all users (admin only)"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        users = pl.admin_get_all_users(limit=limit, offset=offset)
        if raw:
            click.echo(json.dumps(users, indent=2, default=str))
        else:
            click.echo(f"\nFound {len(users)} users:")
            click.echo("---")
            for user in users:
                click.echo(f"Email: {user['email']}")
                click.echo(f"Active: {'Yes' if user['is_active'] else 'No'}")
                click.echo(f"Admin: {'Yes' if user['is_superuser'] else 'No'}")
                if include_length:
                    response = pl.get_number_of_saves(user['email'])
                    click.echo(f"Number of Saves: {response['saves_length']}")
                click.echo("---")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@users.command(name='create')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--pipe', is_flag=True, help='Read email addresses from standard input')
@click.option('-y', '--yes', is_flag=True, help='Automatically generate passwords without prompting')
@click.option('--delay', type=float, default=0.5, help='Delay in seconds between creating users in batch')
def create_user(host, pipe, yes, delay):
    """Create a new user or multiple users from piped input"""
    from postlocker.postlocker import PostLocker, PostLockerException
    import sys
    import time
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)
        
        email_addresses = []
        if pipe:
            email_addresses = [line.strip() for line in sys.stdin if line.strip()]
        else:
            email_addresses.append(click.prompt('Email Address'))
        
        for email_address in email_addresses:
            if yes:
                password = generate_password()
                click.echo(f"Generated password for {email_address}: {password}")
            else:
                # Securely prompt for password
                password = click.prompt(f'Password for {email_address} (leave blank for random)', hide_input=True, confirmation_prompt=True)
                if not password or password == '':
                    password = generate_password()
                    click.echo(f"Generated password for {email_address}: {password}")

            result = pl.user_create(email_address, password)
            click.echo(f"Successfully created user '{email_address}'")
            time.sleep(delay)
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@users.command(name='set-admin')
@click.argument('email')
@click.argument('is_admin', type=bool)
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def set_user_admin(email, is_admin, host):
    """Set user as admin"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        result = pl.user_set_admin(email, is_admin)
        click.echo(f"Successfully set admin status for user '{email}' to {is_admin}")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@users.command(name='set-active')
@click.argument('email')
@click.argument('is_active', type=bool)
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def set_user_active(email, is_active, host):
    """Set user as active"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        result = pl.user_set_active(email, is_active)
        click.echo(f"Successfully set active status for user '{email}' to {is_active}")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@users.command(name='set-verified')
@click.argument('email')
@click.argument('is_verified', type=bool)
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def set_user_verified(email, is_verified, host):
    """Set user as verified"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        logged_in_email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(logged_in_email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        result = pl.user_set_verified(email, is_verified)
        click.echo(f"Successfully set verified status for user '{email}' to {is_verified}")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@users.command(name='reset-password')
@click.argument('email')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def reset_user_password(email, host):
    """Reset user password"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        # Securely prompt for new password
        password = click.prompt('New Password', hide_input=True, confirmation_prompt=True)
        
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        result = pl.user_reset_password(email, password)
        click.echo(f"Successfully reset password for user '{email}'")
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@cli.group()
def ai():
    """Re-analyse saves to update AI metadata"""
    pass

@ai.command(name='all')
@click.option('--delay', '-d', default=0.5, type=float, help='Delay in seconds between analysing each save')
@click.option('--limit', '-l', type=int, help='Limit the number of saves to analyse')
@click.option('--offset', '-s', type=int, default=0, help='Number of saves to skip before starting')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
def analyse_all(delay, limit, offset, host):
    """Re-analyse all saves to update AI metadata"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        # Get all saves
        saves = pl.get_all()
        
        # Apply offset and limit if specified
        saves = saves[offset:]
        if limit is not None:
            saves = saves[:limit]
            
        errors: List[tuple[str, str]] = []  # List to store (save_id, error_message) tuples
        processed = 0
        
        with click.progressbar(saves, label='Re-analysing saves') as saves_bar:
            for save in saves_bar:
                try:
                    pl.reanalyse_save(save['id'])
                    processed += 1
                    time.sleep(delay)
                except PostLockerException as e:
                    errors.append((save['id'], str(e)))
                    
        # Output results
        click.echo(f"\nSuccessfully re-analysed {processed} saves")
        
        if errors:
            click.echo("\nErrors occurred while processing the following saves:")
            for save_id, error in errors:
                click.echo(f"Save {save_id}: {error}")
            
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@ai.command()
@click.argument('save_id', required=False)
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
@click.option('--summary', is_flag=True, help='Show AI summary for the save')
def analyse(save_id, host, raw, summary):
    """Re-analyse a specific save to update AI metadata"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        # Handle piped input
        ids = get_piped_ids() if not save_id else [save_id]
        if not ids:
            click.echo("Error: No save ID provided")
            sys.exit(1)
            
        for current_id in ids:
            try:
                result = pl.reanalyse_save(current_id)
                if raw:
                    click.echo(json.dumps(result, indent=2, default=str))
                else:
                    format_save_for_display(result, raw=False, summary=summary)
            except PostLockerException as e:
                click.echo(f"Error analysing {current_id}: {str(e)}")
            
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@cli.group()
def notes():
    """Manage notes on saves"""
    pass

@notes.command(name='get')
@click.argument('save_id')
@click.option('--limit', '-l', type=int, help='Limit the number of notes to display')
@click.option('--offset', '-s', type=int, default=0, help='Number of notes to skip')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
def get_notes(save_id, limit, offset, host, raw):
    """Get notes for a save"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        save = pl.get_by_id(save_id)
        
        # Filter metadata for notes
        notes = [meta for meta in save.get('meta', []) if meta['key'] == 'user:note']
        # Apply offset and limit
        notes = notes[offset:]
        if limit is not None:
            notes = notes[:limit]
            
        if raw:
            click.echo(json.dumps(notes, indent=2, default=str))
        else:
            if not notes:
                click.echo("No notes found.")
                return
                
            click.echo(f"\nFound {len(notes)} notes:")
            click.echo("---")
            for note in notes:
                created_at = datetime.fromisoformat(note['created_at'].replace('Z', '+00:00'))
                local_time = created_at.astimezone()
                tz_name = datetime.now().astimezone().tzinfo
                
                click.echo(f"\nNote ID: {note['id']}")
                click.echo(f"Created: {local_time.strftime('%Y-%m-%d %H:%M:%S')} ({tz_name})")
                click.echo(f"Content: {note['value']}")
                
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@notes.command(name='add')
@click.argument('save_id')
@click.argument('note')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
def add_note(save_id, note, host, raw):
    """Add a note to a save"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        result = pl.add_note_to_save(save_id, note)
        
        if raw:
            click.echo(json.dumps(result, indent=2, default=str))
        else:
            click.echo(f"Successfully added note to save {save_id}")
            
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

@notes.command(name='delete')
@click.argument('save_id')
@click.argument('note_id')
@click.option('--host', '-h', envvar='POSTLOCKER_BASE_URL', help='PostLocker host URL')
@click.option('--raw', is_flag=True, help='Display full JSON data')
def delete_note(save_id, note_id, host, raw):
    """Delete a note from a save"""
    from postlocker.postlocker import PostLocker, PostLockerException
    
    try:
        email, password, token = get_credentials(None, host)
        
        pl = PostLocker(base_url=host) if host else PostLocker()
        if token:
            pl._token = token
        elif not pl.login(email, password):
            click.echo("Error: Login failed")
            sys.exit(1)

        result = pl.delete_note_from_save(save_id, note_id)
        
        if raw:
            click.echo(json.dumps(result, indent=2, default=str))
        else:
            click.echo(f"Successfully deleted note {note_id} from save {save_id}")
            
    except PostLockerException as e:
        click.echo(f"Error: {str(e)}")
        sys.exit(1)

def get_piped_ids():
    """Get save IDs from stdin if they were piped in"""
    if not sys.stdin.isatty():
        return [line.strip() for line in sys.stdin.readlines() if line.strip()]
    return []

def format_save_for_display(save, raw=False, summary=False):
    """Helper function to format and display a save"""
    if raw:
        click.echo(json.dumps(save, indent=2, default=str))
    else:
        click.echo(f"ID: {save['id']}")
        title = _get_title_from_meta(save)
        if title:
            click.echo(f"Title: {title}")
        click.echo(f"Content: {save['content']}")
        if summary:
            summary_text = next((meta['value'] for meta in save['meta'] if meta['key'] == 'ai:summary'), 'No summary available')
            click.echo(f"Summary: {summary_text}")
        click.echo("---")



