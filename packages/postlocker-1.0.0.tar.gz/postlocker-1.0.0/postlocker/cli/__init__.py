"""CLI module for PostLocker."""
