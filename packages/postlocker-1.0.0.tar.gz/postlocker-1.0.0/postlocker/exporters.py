import csv
import json

class CSVExporter:
    def __init__(self, filename: str):
        print(f"Notice: CSV Exporter only imports/exports content (URLs or text), not metadata, groups, or tags.")
        self.filename = filename
        
    def export(self, saves: list[any]):
        with open(self.filename, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["content"])
            for save in saves:
                writer.writerow([save["content"]])

    def import_from_csv(self, filename: str) -> list[any]:
        saves = []
        with open(filename, "r") as file:
            reader = csv.reader(file)
            next(reader)  # Skip the header
            for row in reader:
                saves.append({"content": row[0]})
        return saves

class JSONExporter:
    def __init__(self):
        pass
        
    def export(self, saves, pretty: bool = False):
        if pretty:
            return json.dumps(saves, default=str, indent=4)
        else:
            return json.dumps(saves, default=str)
    
    def import_from_json(self, json_str: str):
        data = json.loads(json_str)
        return data
    
    def save_to_file(self, filename: str, saves, pretty: bool = False):
        with open(filename, "w") as file:
            if pretty:
                file.write(self.export(saves, pretty=True))
            else:
                file.write(self.export(saves))    
    
    def load_from_file(self, filename: str):
        with open(filename, "r") as file:
            return self.import_from_json(file.read())