from datetime import datetime
import json
import random
import string
import requests
from .exporters import JSONExporter
from .token_manager import TokenManager

# Postlocker exceptions
class PostLockerException(Exception):
    pass

class PostLockerLoginException(PostLockerException):
    pass

class PostLockerSaveException(PostLockerException):
    pass

class PostLockerDeleteException(PostLockerException):
    pass

def generate_password(length: int = 8) -> str:
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))
#Main class
class PostLocker:
    def __init__(self, base_url: str = "https://api.postlocker.app"):
        self.base_url = base_url
        self.token_manager = TokenManager()
        self._token = None
        self.json_exporter = JSONExporter()

    @property
    def token(self):
        if not self._token:
            self._token = self.token_manager.get_valid_token(self.base_url)
        return self._token

    def login(self, email: str, pwd: str):
        # Try to get cached token first
        cached_token = self.token_manager.get_valid_token(self.base_url)
        if cached_token:
            self._token = cached_token
            return True

        # If no valid cached token, perform login
        response = requests.post(f"{self.base_url}/auth/token", json={"email": email, "password": pwd})
        if response.status_code == 200:
            response.encoding = 'utf-8'
            self._token = response.text.strip("\"")
            self.token_manager.save_token(self._token, self.base_url)
            return True
        elif response.status_code == 500:
            raise PostLockerLoginException(f"Failed to log in: {response.status_code} - {response.text}")
        else:
            raise PostLockerLoginException(f"Failed to log in: {response.status_code} - {response.json().get('detail')}")

    def get_user(self, email: str | None = None) -> any:
        if not self.token:
            raise PostLockerException("Not logged in")
        if email:
            response = requests.get(f"{self.base_url}/auth/users/{email}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        else:
            response = requests.get(f"{self.base_url}/auth/me", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to get user: {response.status_code} - {response.text}")
    
    def user_change_password(self, old_password: str, new_password: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/auth/change-password", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, data=json.dumps({"old_password": old_password, "new_password": new_password}))
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to change password: {response.status_code} - {response.text}")
 
    def save(self, content: str):
        if not self.token:
            raise PostLockerException("Not logged in")
            
        data = {
            "content": content,
        }
        
        response = requests.post(
            f"{self.base_url}/saves",
            json=data,
            headers={"X-Auth-Token": self.token, "Accept": "application/json"}
        )
        
        if response.status_code == 200:
            save_out = self.json_exporter.import_from_json(response.text)
            return save_out
        elif response.status_code == 500:
            raise PostLockerSaveException(f"Failed to save to PostLocker: {response.status_code} - {response.text}")
        else:
            raise PostLockerSaveException(f"Failed to save to PostLocker: {response.status_code} - {response.json().get('detail')}")

    def get_url(self, id: str) -> str:
        return f"{self.base_url}/saves/{id}"

    def delete(self, id: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.delete(f"{self.base_url}/saves/{id}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return True 
        elif response.status_code == 500:
            raise PostLockerDeleteException(f"Failed to delete from PostLocker: {response.status_code} - {response.text}")
        else:
            raise PostLockerDeleteException(f"Failed to delete from PostLocker: {response.status_code} - {response.json().get('detail')}")
        
    def get_all(self, since: datetime | None = None, content_type: str | None = None) -> list[any]:
        if not self.token:
            raise PostLockerException("Not logged in")
        if since:
            # Ensure timezone info is included
            iso_time = since.isoformat()
            if not since.tzinfo:
                # Append 'Z' to indicate UTC if no timezone is present
                iso_time += 'Z'
            params = {"since": iso_time}
            if content_type:
                params['content_type'] = content_type
            response = requests.get(f"{self.base_url}/saves/updated", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, params=params)
        else:
            params = {}
            if content_type:
                params['content_type'] = content_type
            response = requests.get(f"{self.base_url}/saves", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, params=params)
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to get all saves: {response.status_code} - {response.text}")
        
    def get_by_id(self, id: str) -> any:
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.get(f"{self.base_url}/saves/{id}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to get save by ID: {response.status_code} - {response.text}")

    def search(self, query: str, limit: int | None = None, semantic: bool = True, distance: float | None = None, group: str | None = None, content_type: str | None = None) -> list[any]:
        if not self.token:
            raise PostLockerException("Not logged in")
        
        # Build query parameters
        params = {
            'query': query,
            'semantic': semantic
        }
        if limit:
            params['limit'] = limit
        if distance is not None:
            params['distance'] = distance
        if group:
            params['group'] = group
        if content_type:
            params['content_type'] = content_type
            
        response = requests.get(
            f"{self.base_url}/saves/search",
            params=params,
            headers={"X-Auth-Token": self.token, "Accept": "application/json"}
        )
        
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to search: {response.status_code} - {response.text}")
    
    def list_groups(self) -> list[any]:
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.get(f"{self.base_url}/saves/groups", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to list groups: {response.status_code} - {response.text}")
    
    def search_groups(self, query: str, limit: int | None = None, offset: int | None = None) -> list[any]:
        if not self.token:
            raise PostLockerException("Not logged in")
        params = {
            'query': query,
        }
        if limit:
            params['limit'] = limit
        if offset:
            params['offset'] = offset
        response = requests.get(f"{self.base_url}/saves/groups/search", params=params, headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to search groups: {response.status_code} - {response.text}")
    
    def get_group_by_id(self, id: str) -> any:
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.get(f"{self.base_url}/saves/group/{id}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to get group by name: {response.status_code} - {response.text}")
    
    def add_to_group(self, id: str, group_id: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/saves/{id}/group/{group_id}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to add to group: {response.status_code} - {response.text}")
    
    def remove_from_group(self, id: str, group_id: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.delete(f"{self.base_url}/saves/{id}/group/{group_id}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to remove from group: {response.status_code} - {response.text}")
    
    def create_group(self, name: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/saves/groups", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, data=json.dumps({"name": name}))
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to create group: {response.status_code} - {response.text}")
    
    def delete_group(self, id: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.delete(f"{self.base_url}/saves/group/{id}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to delete group: {response.status_code} - {response.text}")

    def get_all_tags(self) -> list[any]:
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.get(f"{self.base_url}/saves/tags", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to get all tags: {response.status_code} - {response.text}")
    
    def get_saves_by_tag(self, tag: str) -> list[any]:
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.get(f"{self.base_url}/saves/tag/{tag}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to get saves by tag: {response.status_code} - {response.text}")
    
    def add_tag(self, id: str, tag: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/saves/{id}/tag?tag_name={tag}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to add tag: {response.status_code} - {response.text}")
    
    def remove_tag(self, id: str, tag: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.delete(f"{self.base_url}/saves/{id}/tag/{tag}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to remove tag: {response.status_code} - {response.text}")
    
    # def delete_tag(self, tag: str):
    #     if not self.token:
    #         raise PostLockerException("Not logged in")
    #     response = requests.delete(f"{self.base_url}/saves/tag/{tag}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
    #     return self.json_exporter.import_from_json(response.text)

    def get_related_saves(self, id: str, limit: int | None = None, distance: float | None = None) -> list[any]:
        if not self.token:
            raise PostLockerException("Not logged in")
        limit_query: str | None = "limit=" + str(limit) if limit else None
        distance_query: str | None = "distance=" + str(distance) if distance else None
        query: str = "&".join([limit_query, distance_query]) if limit_query and distance_query else limit_query or distance_query
        response = requests.get(f"{self.base_url}/saves/{id}/related?{query}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to get related saves: {response.status_code} - {response.text}")

    def reanalyse_save(self, id: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/saves/{id}/re-analyse", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to re-analyze save: {response.status_code} - {response.text}")

    def add_note_to_save(self, id: str, note: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/saves/{id}/metadata", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, data=json.dumps({"key": "user:note", "value": note}))
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to add note to save: {response.status_code} - {response.text}")
        
    def get_notes_from_save(self, id: str) -> str:
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.get(f"{self.base_url}/saves/{id}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            save = self.json_exporter.import_from_json(response.text)
            metadata = save.get("metadata", [])
            notes = []
            for item in metadata:
                if item.get("key") == "user:note":
                    notes.append(item)
            return notes
        else:
            raise PostLockerException(f"Failed to get notes from save: {response.status_code} - {response.text}")

    def delete_note_from_save(self, id: str, note_id: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.delete(f"{self.base_url}/saves/{id}/metadata/{note_id}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to delete note from save: {response.status_code} - {response.text}")
    
    # Admin functions
    def admin_get_all_users(self, limit: int | None = None, offset: int | None = None) -> list[any]:
        if not self.token:
            raise PostLockerException("Not logged in")
        params = {}
        if limit:
            params['limit'] = limit
        if offset:
            params['offset'] = offset   
        response = requests.get(f"{self.base_url}/auth/users", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, params=params)
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to get all users: {response.status_code} - {response.text}")

    # def admin_get_user(self, email: str) -> any:
    #     if not self.token:
    #         raise PostLockerException("Not logged in")
    #     response = requests.get(f"{self.base_url}/auth/users/{email}", headers={"X-Auth-Token": self.token, "Accept": "application/json"})
    #     return self.json_exporter.import_from_json(response.text)
    
    def user_create(self, email: str, password: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/auth/users", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, data=json.dumps({"email": email, "password": password}))
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to create user: {response.status_code} - {response.text}")
    
    def user_set_admin(self, email: str, is_admin: bool):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/auth/users/set-admin", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, data=json.dumps({"user": {"email": email}, "admin": is_admin}))
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to set user admin status: {response.status_code} - {response.text}")
    
    def user_set_active(self, email: str, is_active: bool):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/auth/users/set-active", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, data=json.dumps({"user": {"email": email}, "active": is_active}))
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to set user active status: {response.status_code} - {response.text}")
    
    def user_set_verified(self, email: str, is_verified: bool):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/auth/users/set-verified", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, data=json.dumps({"user": {"email": email}, "verified": is_verified}))
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to set user verified status: {response.status_code} - {response.text}")  
    
    def user_reset_password(self, email: str, password: str):
        if not self.token:
            raise PostLockerException("Not logged in")
        response = requests.post(f"{self.base_url}/auth/users/reset-password", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, data=json.dumps({"user": {"email": email}, "password": password}))
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to reset user password: {response.status_code} - {response.text}")
        
    def get_number_of_saves(self, email: str) -> int:
        if not self.token:
            raise PostLockerException("Not logged in")
        params = {  
            'email': email
        }
        response = requests.get(f"{self.base_url}/saves/length", headers={"X-Auth-Token": self.token, "Accept": "application/json"}, params=params)
        if response.status_code == 200:
            return self.json_exporter.import_from_json(response.text)
        else:
            raise PostLockerException(f"Failed to get number of saves: {response.status_code} - {response.text}")
    
    