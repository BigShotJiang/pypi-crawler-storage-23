"""Package-backed MCP adapter for GraphRAG tools."""

from src.graphrag.mcp_impl import register_graphrag_tools

__all__ = ["register_graphrag_tools"]
