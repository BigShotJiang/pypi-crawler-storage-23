# kokao/inverse.py
import torch
from typing import Optional, Tuple


class InverseProblem:
    """
    Решает S(x) = S_target, где S(x) = S⁺(x)/S⁻(x), с фиксированными весами.
    Используется для генерации входа по целевому сигналу (S → x).
    """
    _EPSILON = 1e-6

    def __init__(self, w_plus: torch.Tensor, w_minus: torch.Tensor):
        # Принимаем эффективные веса (уже положительные)
        self.w_plus = w_plus.clone().detach()
        self.w_minus = w_minus.clone().detach()
        self.device = w_plus.device
        self.dtype = w_plus.dtype
        self.input_dim = w_plus.shape[0]

    def _compute_S(self, x: torch.Tensor) -> torch.Tensor:
        """Вычисляет S(x) с сохранением знака S⁻."""
        s_plus = torch.dot(x, self.w_plus)
        s_minus = torch.dot(x, self.w_minus)
        s_abs = s_minus.abs().clamp(min=self._EPSILON)
        return s_plus / s_abs * torch.sign(s_minus)

    def solve(
        self,
        S_target: float,
        x_init: Optional[torch.Tensor] = None,
        lr: float = 0.1,
        max_steps: int = 100,
        clamp_range: Tuple[float, float] = (-1.0, 1.0),
        verbose: bool = False,
    ) -> torch.Tensor:
        """Находит x, минимизирующий (S(x) - S_target)²."""
        if x_init is None:
            x = torch.randn(self.input_dim, device=self.device, dtype=self.dtype)
        else:
            x = x_init.clone().detach().to(self.device, self.dtype)

        x.requires_grad_(True)
        optimizer = torch.optim.Adam([x], lr=lr)

        for step in range(max_steps):
            optimizer.zero_grad()
            s = self._compute_S(x)
            loss = (s - S_target) ** 2
            loss.backward()
            optimizer.step()
            x.data.clamp_(*clamp_range)

            if verbose and step % 10 == 0:
                print(f"Step {step}: loss = {loss.item():.6f}")

        return x.detach()