"""
Интуитивно-эталонная система (Глава 2).

Реализация простейшей интуитивно-эталонной системы с поддержкой:
- Размытых эталонов (сумма образов, общие черты усиливаются)
- Нижнего порога проводимости (не может упасть ниже EPSILON)
- Активации эталонов (как во сне или фантазировании)
"""
import torch
from typing import Optional, Dict, Any
from .core import KokaoCore
from .core_base import CoreConfig


class IntuitiveEtalonSystem:
    """
    Простейшая интуитивно-эталонная система (Глава 2).
    
    Добавлено:
    - Размытые эталоны (сумма образов, общие черты усиливаются)
    - Нижний порог проводимости (не может упасть ниже EPSILON)
    """
    _LOW_THRESHOLD = 0.1  # Нижний порог проводимости (п.2.3.1)

    def __init__(self, config: CoreConfig):
        """
        Инициализация системы.

        Args:
            config: Конфигурация ядра
        """
        self.config = config
        self.intuitive_core = KokaoCore(config)
        self.etalon_storage: Dict[str, Dict[str, Any]] = {}

    def learn_etalon(self, etalon_id: str, x: torch.Tensor, blurry: bool = False) -> None:
        """
        Обучение эталону.

        Args:
            etalon_id: Идентификатор эталона
            x: Вектор образа
            blurry: Если True, сохраняем как "размытый эталон" (обобщенный образ)
        """
        self.etalon_storage[etalon_id] = {
            "vec": x.clone().detach(),
            "activated": False,
            "blurry": blurry
        }

    def add_to_blurred_etalon(self, etalon_id: str, x: torch.Tensor) -> None:
        """
        Уточнение размытого эталона (п.2.2).
        Добавляет новую ситуацию к уже существующему размытому эталону.

        Args:
            etalon_id: Идентификатор эталона
            x: Новый вектор для добавления
        """
        if etalon_id not in self.etalon_storage:
            raise ValueError(f"Etalon {etalon_id} not found")
        if not self.etalon_storage[etalon_id]["blurry"]:
            raise ValueError(f"Etalon {etalon_id} is not blurry")

        existing_vec = self.etalon_storage[etalon_id]["vec"]
        # Усреднение: (старый + новый)/2
        self.etalon_storage[etalon_id]["vec"] = (existing_vec + x) / 2.0

    def recognize(self, x: torch.Tensor, threshold: float = 0.1) -> Optional[str]:
        """
        Распознавание.
        Активирует ближайший эталон, если косинусное сходство > threshold.

        Args:
            x: Входной вектор для распознавания
            threshold: Порог сходства

        Returns:
            ID ближайшего эталона или None
        """
        best_match = None
        best_similarity = -1

        for etalon_id, data in self.etalon_storage.items():
            vec = data["vec"]
            similarity = torch.dot(x, vec) / (x.norm() * vec.norm() + 1e-8)
            sim_val = similarity.item()
            if sim_val > best_similarity:
                best_similarity = sim_val
                best_match = etalon_id

        if best_match and best_similarity > threshold:
            self.etalon_storage[best_match]["activated"] = True
            return best_match
        return None

    def activate_etalon(self, etalon_id: str) -> Optional[torch.Tensor]:
        """
        Активация эталона внутренне (как во сне или фантазировании).

        Args:
            etalon_id: Идентификатор эталона

        Returns:
            Вектор эталона или None
        """
        if etalon_id in self.etalon_storage:
            self.etalon_storage[etalon_id]["activated"] = True
            return self.etalon_storage[etalon_id]["vec"]
        return None

    def get_active_etalon(self) -> Optional[torch.Tensor]:
        """
        Получить активированный эталон (или None, если нет активных).

        Returns:
            Вектор активного эталона или None
        """
        for data in self.etalon_storage.values():
            if data["activated"]:
                return data["vec"]
        return None

    def forget_etalon(self, etalon_id: str, decay_rate: float = 0.01) -> None:
        """
        Забывание эталона (п.2.2).
        Снижает вес эталона, но не ниже нижнего порога.

        Args:
            etalon_id: Идентификатор эталона
            decay_rate: Скорость забывания
        """
        if etalon_id in self.etalon_storage:
            vec = self.etalon_storage[etalon_id]["vec"]
            # умножение на (1 - decay_rate) и обрезка по нижнему порогу
            vec = vec * (1.0 - decay_rate)
            vec = torch.max(vec, torch.full_like(vec, self._LOW_THRESHOLD))
            self.etalon_storage[etalon_id]["vec"] = vec

    def reset_activation(self) -> None:
        """Сбросить активацию всех эталонов."""
        for data in self.etalon_storage.values():
            data["activated"] = False

    def get_etalon_count(self) -> int:
        """Получить количество эталонов."""
        return len(self.etalon_storage)

    def get_all_etalons(self) -> Dict[str, torch.Tensor]:
        """Получить все эталоны."""
        return {eid: data["vec"] for eid, data in self.etalon_storage.items()}
