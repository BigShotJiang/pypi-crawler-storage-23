# kokao/decoder.py
import torch
from .inverse import InverseProblem


class Decoder:
    def __init__(self, core, lr: float = 0.1, max_steps: int = 100):
        self.core = core
        self.lr = lr
        self.max_steps = max_steps

    def generate(self, S_target: float) -> torch.Tensor:
        inverse = self.core.to_inverse_problem()
        return inverse.solve(S_target, lr=self.lr, max_steps=self.max_steps)