# Kokao Engine v2.0

**Интуитивная система по методу Косякова. Двухканальное ядро (S⁺/S⁻), когнитивные модули, обратная задача.**

[![PyPI version](https://badge.fury.io/py/kokao-engine.svg)](https://badge.fury.io/py/kokao-engine)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-132%20passed-green)](tests/)

Kokao Engine — это фреймворк для создания и исследования интуитивных систем, основанный на теории функционально-независимых структур Ю.Б. Косякова. В версии 2.0 реализовано двухканальное ядро, инвариантное к масштабу входа, и набор когнитивных модулей, соответствующих уровням 2–4 из книги "Мой мозг".

## ✨ Ключевые особенности v2.0

*   **Двухканальное ядро (`KokaoCore`)** – сигнал вычисляется как отношение `S = S⁺ / S⁻`, что обеспечивает инвариантность к "яркости" входного сигнала.
*   **Обратная задача (`InverseProblem`)** – генерация входного вектора `x` для достижения целевого сигнала `S_target`.
*   **Когнитивные модули** (строго по книге):
    *   Размытые эталоны и система "Таламус-Кора".
    *   Разделение на левое (образы) и правое (действия) полушария.
    *   Система целей, удовольствия, депривации и утомляемости.
*   **Производительность**: пакетное обучение (`train_batch`) даёт ускорение до **800x** на GPU.
*   **Безопасность**: встроенная валидация входных данных (`SecureKokao`).
*   **Модульность и расширения**: лёгкая интеграция с современным ML-стеком (RAG, XAI, LangChain, HuggingFace, ONNX, квантовые вычисления и др.).

## ⚙️ Установка

```bash
pip install kokao-engine

# Для установки с опциональными расширениями:
pip install 'kokao-engine[all]'  # или выборочно, например [rag,xai,langchain]
```

## 🚀 Быстрый старт (v2.0)

```python
import torch
from kokao import KokaoCore, CoreConfig, Decoder

# 1. Создание двухканального ядра
config = CoreConfig(input_dim=10)
core = KokaoCore(config)

# 2. Обучение на одном примере
x = torch.randn(10)
loss = core.train(x, target=0.8, mode="gradient")
print(f"Loss: {loss:.4f}")

# 3. Пакетное обучение (быстро!)
X_batch = torch.randn(32, 10)
y_batch = torch.full((32,), 0.8)
batch_loss = core.train_batch(X_batch, y_batch)
print(f"Batch loss: {batch_loss:.4f}")

# 4. Генерация вектора для целевого сигнала
decoder = Decoder(core)
x_gen = decoder.generate(S_target=0.5)
print(f"Generated signal: {core.signal(x_gen):.4f} (target: 0.5)")
```

## 📚 Модули

### Базовое ядро
- `KokaoCore` - двухканальное ядро (S⁺/S⁻)
- `InverseProblem` - обратная задача (генерация x по S)
- `Decoder` - обёртка для генерации

### Когнитивные системы (Главы 2-4)
- `IntuitiveEtalonSystem` - простейшая эталонная система
- `NormalIntuitiveEtalonSystem` - нормальная система с полушариями
- `SelfPlanningSystem` - система с целями и планированием

### AI/ML модули
- `TimeSeriesPredictor` - прогнозирование временных рядов
- `KokaoAgent` - автономные агенты
- `FederatedLearning` - федеративное обучение
- `KokaoGAN`, `KokaoVAE` - генеративные модели

### Продвинутые сети
- `KokaoQuantumNetwork` - квантовые нейронные сети
- `KokaoGNN` - графовые нейронные сети
- `KokaoSNN` - спайковые нейронные сети

### Безопасность
- `DPSGD` - дифференциальная приватность
- `HomomorphicKokao` - гомоморфное шифрование
- `VulnerabilityAuditor` - аудит уязвимостей
- `PenetrationTester` - тестирование на проникновение

### Интеграции
- `RAGModule` - поиск с FAISS
- `XAIAnalyzer` - объяснимый AI (SHAP/LIME)
- `LangChainKokaoAdapter` - инструменты для LangChain
- `HFModelManager` - публикация на HuggingFace Hub

## 📖 Документация

Полная документация доступна в файлах:
- [ARCHITECTURE.md](ARCHITECTURE.md) - архитектура проекта
- [README.md](README.md) - основное описание

Примеры использования находятся в папке [examples/](examples/).

## 🧪 Тесты

```bash
# Запуск всех тестов
python run_all_tests.py

# Или через pytest
pytest tests/ -v
```

## 🤝 Участие в разработке

Мы приветствуем вклад сообщества! Пожалуйста:
1. Fork репозиторий
2. Создайте ветку (`git checkout -b feature/AmazingFeature`)
3. Commit изменения (`git commit -m 'Add AmazingFeature'`)
4. Push в ветку (`git push origin feature/AmazingFeature`)
5. Откройте Pull Request

## 📄 Лицензия и авторство

Проект распространяется под лицензией Apache 2.0.

**Автор**: Виталий Калиновский  
**Организация**: newmathphys

Данная реализация является независимой разработкой на основе идей, изложенных в книге Ю.Б. Косякова "Мой мозг" (1999). Патент РФ №2109332 утратил силу, математический метод находится в общественном достоянии.

## 📈 Статистика

- **132 теста** покрывают все модули
- **32+ модуля** реализовано
- **800x ускорение** на GPU с батчевым обучением
- **INT8/INT4 квантование** для edge-устройств
