"""Тесты для интуитивно-эталонной системы."""
import pytest
import torch
from kokao.etalon import IntuitiveEtalonSystem
from kokao.core_base import CoreConfig


@pytest.fixture
def system():
    """Фикстура для тестов."""
    config = CoreConfig(input_dim=5)
    return IntuitiveEtalonSystem(config)


def test_learn_etalon(system):
    """Тест обучения эталону."""
    x = torch.randn(5)
    system.learn_etalon("obj1", x)
    assert "obj1" in system.etalon_storage
    assert torch.allclose(system.etalon_storage["obj1"]["vec"], x)


def test_learn_blurry_etalon(system):
    """Тест обучения размытому эталону."""
    x1 = torch.randn(5)
    x2 = torch.randn(5)
    system.learn_etalon("obj1", x1, blurry=True)
    system.add_to_blurred_etalon("obj1", x2)
    expected = (x1 + x2) / 2
    assert torch.allclose(system.etalon_storage["obj1"]["vec"], expected)


def test_recognize(system):
    """Тест распознавания."""
    x = torch.randn(5)
    system.learn_etalon("obj1", x)
    best = system.recognize(x)
    assert best == "obj1"
    # Проверим, что активировался
    assert system.etalon_storage["obj1"]["activated"] is True


def test_recognize_threshold(system):
    """Тест порога распознавания."""
    x1 = torch.randn(5)
    x2 = torch.randn(5)  # другой
    system.learn_etalon("obj1", x1)
    best = system.recognize(x2, threshold=0.9)  # высокий порог
    assert best is None


def test_activate_etalon(system):
    """Тест активации эталона."""
    x = torch.randn(5)
    system.learn_etalon("obj1", x)
    vec = system.activate_etalon("obj1")
    assert vec is not None
    assert system.etalon_storage["obj1"]["activated"] is True


def test_get_active_etalon(system):
    """Тест получения активного эталона."""
    x = torch.randn(5)
    system.learn_etalon("obj1", x)
    system.activate_etalon("obj1")
    active = system.get_active_etalon()
    assert active is not None
    assert torch.allclose(active, x)


def test_forget_etalon(system):
    """Тест забывания эталона."""
    x = torch.ones(5) * 0.5
    system.learn_etalon("obj1", x)
    system.forget_etalon("obj1", decay_rate=0.5)
    new_vec = system.etalon_storage["obj1"]["vec"]
    # должно уменьшиться, но не ниже порога
    assert torch.all(new_vec <= x * 0.5)
    assert torch.all(new_vec >= system._LOW_THRESHOLD)


def test_reset_activation(system):
    """Тест сброса активации."""
    x = torch.randn(5)
    system.learn_etalon("obj1", x)
    system.activate_etalon("obj1")
    system.reset_activation()
    assert system.etalon_storage["obj1"]["activated"] is False


def test_get_etalon_count(system):
    """Тест подсчета эталонов."""
    assert system.get_etalon_count() == 0
    system.learn_etalon("obj1", torch.randn(5))
    system.learn_etalon("obj2", torch.randn(5))
    assert system.get_etalon_count() == 2


def test_get_all_etalons(system):
    """Тест получения всех эталонов."""
    x1 = torch.randn(5)
    x2 = torch.randn(5)
    system.learn_etalon("obj1", x1)
    system.learn_etalon("obj2", x2)
    etalons = system.get_all_etalons()
    assert len(etalons) == 2
    assert "obj1" in etalons
    assert "obj2" in etalons
    assert torch.allclose(etalons["obj1"], x1)
    assert torch.allclose(etalons["obj2"], x2)


def test_recognize_multiple_etalons(system):
    """Тест распознавания среди нескольких эталонов."""
    x1 = torch.randn(5)
    x2 = torch.randn(5)
    x3 = torch.randn(5)
    system.learn_etalon("obj1", x1)
    system.learn_etalon("obj2", x2)
    system.learn_etalon("obj3", x3)

    # Распознаем x1 - должен найти obj1
    best = system.recognize(x1, threshold=0.5)
    assert best == "obj1"


def test_nonexistent_etalon_activation(system):
    """Тест активации несуществующего эталона."""
    vec = system.activate_etalon("nonexistent")
    assert vec is None


def test_forget_nonexistent_etalon(system):
    """Тест забывания несуществующего эталона (должно игнорироваться)."""
    # Не должно вызывать ошибку
    system.forget_etalon("nonexistent")
    assert True
