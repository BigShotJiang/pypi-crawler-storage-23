"""Claude Code compile pipeline — live capture to chunk-atom cell."""
