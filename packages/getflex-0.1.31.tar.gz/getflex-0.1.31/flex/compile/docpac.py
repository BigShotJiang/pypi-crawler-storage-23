"""Re-export from canonical location: flex.modules.docpac.compile.docpac"""
from flex.modules.docpac.compile.docpac import (  # noqa: F401
    DocPacEntry,
    parse_docpac,
    parse_docpac_file,
    FOLDER_MAP,
    SKIP_FOLDERS,
    DOCPAC_INDICATORS,
)
