# SOMA identity module — stable UUIDs for files, repos, content, and URLs.
