"""Claude Code module — enrichment config for claude-code session cells."""
