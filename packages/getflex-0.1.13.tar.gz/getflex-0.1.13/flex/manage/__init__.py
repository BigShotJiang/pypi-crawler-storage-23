"""Manage: offline graph intelligence. Produces columns SQL reads for free."""
