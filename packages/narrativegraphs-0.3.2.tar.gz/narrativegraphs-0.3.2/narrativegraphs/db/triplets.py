from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, relationship

from narrativegraphs.db.documents import AnnotationMixin, DocumentOrm
from narrativegraphs.db.engine import Base


class TripletOrm(Base, AnnotationMixin):
    __tablename__ = "triplets"

    subject_id = Column(Integer, ForeignKey("entities.id"), nullable=True, index=True)
    predicate_id = Column(
        Integer, ForeignKey("predicates.id"), nullable=True, index=True
    )
    object_id = Column(Integer, ForeignKey("entities.id"), nullable=True, index=True)
    relation_id = Column(Integer, ForeignKey("relations.id"), nullable=True, index=True)
    cooccurrence_id = Column(
        Integer, ForeignKey("cooccurrences.id"), nullable=True, index=True
    )

    subject_occurrence_id = Column(
        Integer, ForeignKey("entity_occurrences.id"), nullable=False, index=True
    )
    object_occurrence_id = Column(
        Integer, ForeignKey("entity_occurrences.id"), nullable=False, index=True
    )

    pred_span_start = Column(Integer, nullable=False)
    pred_span_end = Column(Integer, nullable=False)
    pred_span_text = Column(String, nullable=False)

    # Relationships
    subject = relationship(
        "EntityOrm",
        foreign_keys="TripletOrm.subject_id",
    )
    predicate = relationship(
        "PredicateOrm",
        foreign_keys="TripletOrm.predicate_id",
    )
    object = relationship(
        "EntityOrm",
        foreign_keys="TripletOrm.object_id",
    )
    relation = relationship(
        "RelationOrm",
        foreign_keys="TripletOrm.relation_id",
    )
    cooccurrence = relationship(
        "CooccurrenceOrm",
        foreign_keys="TripletOrm.cooccurrence_id",
    )
    document: Mapped["DocumentOrm"] = relationship(
        "DocumentOrm",
        foreign_keys="TripletOrm.doc_id",
        back_populates="triplets",
    )
    subject_occurrence = relationship(
        "EntityOccurrenceOrm",
        foreign_keys="TripletOrm.subject_occurrence_id",
    )
    object_occurrence = relationship(
        "EntityOccurrenceOrm",
        foreign_keys="TripletOrm.object_occurrence_id",
    )
