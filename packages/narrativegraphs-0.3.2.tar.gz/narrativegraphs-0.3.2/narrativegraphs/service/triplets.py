from typing import Optional

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import aliased

from narrativegraphs.db.entities import EntityOrm
from narrativegraphs.db.entityoccurrences import EntityOccurrenceOrm
from narrativegraphs.db.predicates import PredicateOrm
from narrativegraphs.db.triplets import TripletOrm
from narrativegraphs.dto.common import TextContext
from narrativegraphs.dto.triplets import Triplet, TripletGroup
from narrativegraphs.service.common import OrmAssociatedService


class TripletService(OrmAssociatedService):
    _orm = TripletOrm

    def as_df(self) -> pd.DataFrame:
        with self._get_session_context() as session:
            engine = session.get_bind()

            # Create aliases for the two entity joins
            subject_entity = aliased(EntityOrm)
            object_entity = aliased(EntityOrm)
            # Create aliases for the two occurrence joins
            subject_occurrence = aliased(EntityOccurrenceOrm)
            object_occurrence = aliased(EntityOccurrenceOrm)

            df = pd.read_sql(
                select(
                    TripletOrm.id.label("id"),
                    subject_entity.id.label("subject_entity_id"),
                    subject_entity.label.label("subject_label"),
                    subject_occurrence.span_text.label("subject_span_text"),
                    subject_occurrence.span_start.label("subject_span_start"),
                    subject_occurrence.span_end.label("subject_span_end"),
                    PredicateOrm.id.label("predicate_id"),
                    PredicateOrm.label.label("predicate_label"),
                    TripletOrm.pred_span_text.label("pred_span_text"),
                    object_entity.id.label("object_entity_id"),
                    object_entity.label.label("object_label"),
                    object_occurrence.span_text.label("object_span_text"),
                    object_occurrence.span_start.label("object_span_start"),
                    object_occurrence.span_end.label("object_span_end"),
                )
                .join(PredicateOrm)
                .join(
                    subject_occurrence,
                    TripletOrm.subject_occurrence_id == subject_occurrence.id,
                )
                .join(
                    object_occurrence,
                    TripletOrm.object_occurrence_id == object_occurrence.id,
                )
                .join(
                    subject_entity,
                    TripletOrm.subject_id == subject_entity.id,
                )
                .join(
                    object_entity,
                    TripletOrm.object_id == object_entity.id,
                ),
                engine,
            )

        cleaned = df.dropna(axis=1, how="all")

        return cleaned

    def get_single(self, id_: int) -> dict:
        return self._get_by_id_and_transform(id_, lambda x: x.__dict__)

    def get_multiple(
        self, ids: list[int] = None, limit: Optional[int] = None
    ) -> list[dict]:
        return self._get_multiple_by_ids_and_transform(
            lambda x: x.__dict__, ids=ids, limit=limit
        )

    def get_by_entity_ids(self, entity_ids: list[int]) -> list[Triplet]:
        with self._get_session_context() as session:
            triplets = (
                session.query(TripletOrm)
                .filter(
                    TripletOrm.subject_id.in_(entity_ids)
                    & TripletOrm.object_id.in_(entity_ids)
                )
                .all()
            )
            return [Triplet.from_orm(triplet) for triplet in triplets]

    def get_contexts_by_entity_ids(self, entity_ids: list[int]) -> list[TripletGroup]:
        triplets = self.get_by_entity_ids(entity_ids)
        triplets_groups = [TripletGroup.from_triplet(triplet) for triplet in triplets]
        return TextContext.combine_many(triplets_groups)
