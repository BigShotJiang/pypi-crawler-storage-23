import React, {
  createContext,
  PropsWithChildren,
  useContext,
  useMemo,
} from 'react';
import { GraphService, GraphServiceImpl } from '../services/GraphService';
import { DocService, DocServiceImpl } from '../services/DocService';
import { EntityService, EntityServiceImpl } from '../services/EntityService';
import {
  RelationService,
  RelationServiceImpl,
} from '../services/RelationService';
import {
  CooccurrenceService,
  CooccurrenceServiceImpl,
} from '../services/CooccurrenceService';

const getApiUrl = (): string => {
  // 1. Check for explicit override (highest priority)
  const envApiUrl = import.meta.env.VITE_API_URL;
  if (envApiUrl) {
    return envApiUrl;
  }

  // 2. Localhost development - point to known backend port
  if (
    window.location.hostname === 'localhost' ||
    window.location.hostname === '127.0.0.1'
  ) {
    return 'http://localhost:8001';
  }

  // 3. Production - strip /vis from current URL
  const currentUrl = window.location.href;
  return currentUrl.split('/vis')[0];
};

interface Services {
  graphService: GraphService;
  docService: DocService;
  entityService: EntityService;
  cooccurrenceService: CooccurrenceService;
  relationService: RelationService;
}

const ServiceContext = createContext<Services | undefined>(undefined);

export const ServiceContextProvider: React.FC<PropsWithChildren> = ({
  children,
}) => {
  // We find the API url dynamically; we know that it will be served
  const apiUrl = getApiUrl();

  const value: Services = useMemo(
    () => ({
      graphService: new GraphServiceImpl(apiUrl),
      docService: new DocServiceImpl(apiUrl),
      entityService: new EntityServiceImpl(apiUrl),
      cooccurrenceService: new CooccurrenceServiceImpl(apiUrl),
      relationService: new RelationServiceImpl(apiUrl),
    }),
    [apiUrl],
  );

  return (
    <ServiceContext.Provider value={value}>{children}</ServiceContext.Provider>
  );
};

export const useServiceContext = (): Services => {
  const context = useContext(ServiceContext);
  if (!context) {
    throw new Error('useServiceContext must be used within a ServiceProvider');
  }
  return context;
};
