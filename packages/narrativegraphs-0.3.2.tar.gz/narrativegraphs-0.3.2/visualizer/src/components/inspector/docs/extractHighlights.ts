import { Doc, Span } from '../../../types/doc';
import { HighlightContext, HighlightedSpan } from './types';
import { ConnectionType } from '../../../hooks/useGraphQuery';

function toHighlightedSpan(
  span: Span,
  role: 'subject' | 'predicate' | 'object',
  isPrimary: boolean,
  isEntityHighlight?: boolean,
): HighlightedSpan {
  return {
    ...span,
    role,
    isPrimary,
    isEntityHighlight,
  };
}

/**
 * For entity context: highlight all occurrences of the entity using entityMentions.
 */
function extractEntityHighlights(
  doc: Doc,
  entityId: string | number,
): HighlightedSpan[] {
  const highlights: HighlightedSpan[] = [];

  if (doc.entityMentions) {
    for (const mention of doc.entityMentions) {
      if (String(mention.id) === String(entityId)) {
        highlights.push(toHighlightedSpan(mention, 'subject', true, true));
      }
    }
  }

  return highlights;
}

/**
 * For relation context: highlight triplets where all three IDs match.
 */
function extractRelationHighlights(
  doc: Doc,
  subjectId: string | number,
  predicateId: string | number,
  objectId: string | number,
): HighlightedSpan[] {
  const highlights: HighlightedSpan[] = [];

  if (!doc.triplets) return highlights;

  for (const triplet of doc.triplets) {
    const matches =
      triplet.subject.id === subjectId &&
      triplet.predicate.id === predicateId &&
      triplet.object.id === objectId;

    if (matches) {
      highlights.push(toHighlightedSpan(triplet.subject, 'subject', true));
      highlights.push(toHighlightedSpan(triplet.predicate, 'predicate', true));
      highlights.push(toHighlightedSpan(triplet.object, 'object', true));
    }
  }

  return highlights;
}

/**
 * For cooccurrence context: highlight tuplets where both IDs match.
 */
function extractCooccurrenceHighlights(
  doc: Doc,
  subjectId: string | number,
  objectId: string | number,
): HighlightedSpan[] {
  const highlights: HighlightedSpan[] = [];

  if (!doc.tuplets) return highlights;

  for (const tuplet of doc.tuplets) {
    // Check both orderings since cooccurrence is symmetric
    const matchesForward =
      tuplet.entityOne.id === subjectId && tuplet.entityTwo.id === objectId;
    const matchesReverse =
      tuplet.entityOne.id === objectId && tuplet.entityTwo.id === subjectId;

    if (matchesForward) {
      highlights.push(toHighlightedSpan(tuplet.entityOne, 'subject', true));
      highlights.push(toHighlightedSpan(tuplet.entityTwo, 'object', true));
    } else if (matchesReverse) {
      highlights.push(toHighlightedSpan(tuplet.entityTwo, 'subject', true));
      highlights.push(toHighlightedSpan(tuplet.entityOne, 'object', true));
    }
  }

  return highlights;
}

/**
 * For multi-entity context: highlight all occurrences of any focus entity as primary.
 * Focus entities get isEntityHighlight=true for unique coloring.
 */
function extractEntitiesHighlights(
  doc: Doc,
  entityIds: (string | number)[],
  connectionType: ConnectionType,
): HighlightedSpan[] {
  const highlights: HighlightedSpan[] = [];
  const entityIdSet = new Set(entityIds.map((id) => id.toString()));

  if (connectionType === 'relation') {
    for (const triplet of doc.triplets ?? []) {
      const subjectIsFocus = entityIdSet.has(triplet.subject.id.toString());
      const objectIsFocus = entityIdSet.has(triplet.object.id.toString());

      if (subjectIsFocus || objectIsFocus) {
        highlights.push(
          toHighlightedSpan(
            triplet.subject,
            'subject',
            subjectIsFocus,
            subjectIsFocus,
          ),
        );
        highlights.push(
          toHighlightedSpan(triplet.predicate, 'predicate', false),
        );
        highlights.push(
          toHighlightedSpan(
            triplet.object,
            'object',
            objectIsFocus,
            objectIsFocus,
          ),
        );
      }
    }
  } else {
    // cooccurrence mode
    for (const tuplet of doc.tuplets ?? []) {
      const entityOneIsFocus = entityIdSet.has(tuplet.entityOne.id.toString());
      const entityTwoIsFocus = entityIdSet.has(tuplet.entityTwo.id.toString());

      if (entityOneIsFocus || entityTwoIsFocus) {
        highlights.push(
          toHighlightedSpan(
            tuplet.entityOne,
            'subject',
            entityOneIsFocus,
            entityOneIsFocus,
          ),
        );
        highlights.push(
          toHighlightedSpan(
            tuplet.entityTwo,
            'object',
            entityTwoIsFocus,
            entityTwoIsFocus,
          ),
        );
      }
    }
  }

  return highlights;
}

/**
 * Extracts highlighted spans from a document based on the highlight context.
 */
export function extractHighlights(
  doc: Doc,
  context: HighlightContext,
  connectionType: ConnectionType,
): HighlightedSpan[] {
  switch (context.type) {
    case 'entity':
      return extractEntityHighlights(doc, context.entityId);
    case 'relation':
      return extractRelationHighlights(
        doc,
        context.subjectId,
        context.predicateId,
        context.objectId,
      );
    case 'cooccurrence':
      return extractCooccurrenceHighlights(
        doc,
        context.entityOneId,
        context.entityTwoId,
      );
    case 'entities':
      return extractEntitiesHighlights(doc, context.entityIds, connectionType);
  }
}
