# Exokit — Your Databricks Development Power Suit

Generate production-grade Databricks demo projects in minutes. Answer 8 questions, get a fully deployed hello-world with lakehouse pipelines, ML models, dashboards, Genie spaces, an AI agent, and a full-stack app — then let Claude Code build the real content.

## Install

```bash
pip install exokit
```

## Quick Start

```bash
# Check prerequisites (auto-installs missing tools)
exokit validate --fix

# Scaffold + deploy a new demo
exokit init my-demo-project
```

The CLI walks you through setup: company, industry, Databricks profile, warehouse. Then it scaffolds and deploys everything end-to-end.

## What You Get

| Layer | What Gets Built |
|-------|-----------------|
| Raw Data | Structured tables (Spark + Faker) + unstructured PDFs for RAG |
| Pipelines | Bronze (Auto Loader) → Silver (constraints) → Gold (metrics) |
| ML Models | AutoML + MLflow tracking + Unity Catalog model registration |
| Dashboards | AI/BI Lakeview dashboards + Genie Spaces |
| AI Agent | RAG agent with UC function tools |
| App | Full-stack React + FastAPI on Databricks Apps |
| Governance | CLAUDE.md, 4 specialist agents, wave-based execution |

## Commands

```bash
exokit init [OUTPUT_DIR]              # Scaffold + deploy
exokit validate [--profile P] [--fix] # Check (and install) prerequisites
exokit update-skills [PROJECT_DIR]    # Refresh bundled Databricks skills
```

## How It Works

```
You answer questions  →  exokit scaffolds  →  Claude builds the content
     (8 questions)       (deterministic)      (industry-specific)
```

## Links

- [Documentation](https://github.com/fouad-alsayadi/exokit)
- [Issues](https://github.com/fouad-alsayadi/exokit/issues)
