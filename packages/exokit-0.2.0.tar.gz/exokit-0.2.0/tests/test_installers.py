"""Tests for auto-installation logic."""

from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, patch

from exokit.core.installers import (
    attempt_install,
    check_and_install_all,
    setup_databricks_auth,
    verify_install,
)
from exokit.core.models import (
    AuthSetupRequest,
    InstallOption,
    InstallResult,
    PrereqResult,
)


def _make_option(
    tool_name: str = "test-tool",
    display_name: str = "Test Tool",
    commands: list[list[str]] | None = None,
    platform_hint: str = "Install manually",
) -> InstallOption:
    """Helper to build an InstallOption for testing."""
    return InstallOption(
        tool_name=tool_name,
        display_name=display_name,
        commands=commands or [["fake-install", "test-tool"]],
        platform_hint=platform_hint,
    )


class TestAttemptInstall:
    """Tests for attempt_install function."""

    @patch("exokit.core.installers.subprocess.run")
    def test_successful_install(self, mock_run: MagicMock) -> None:
        mock_run.return_value = subprocess.CompletedProcess(
            args=[], returncode=0, stdout="installed", stderr=""
        )
        option = _make_option()
        result = attempt_install(option)
        assert result.success is True
        assert result.tool_name == "test-tool"
        assert "fake-install test-tool" in result.command_used

    @patch("exokit.core.installers.subprocess.run")
    def test_install_fails_all_commands(self, mock_run: MagicMock) -> None:
        mock_run.return_value = subprocess.CompletedProcess(
            args=[], returncode=1, stdout="", stderr="error"
        )
        option = _make_option(
            commands=[["cmd1"], ["cmd2"]],
            platform_hint="Try manual install",
        )
        result = attempt_install(option)
        assert result.success is False
        assert "Try manual install" in result.message
        assert mock_run.call_count == 2

    @patch("exokit.core.installers.subprocess.run")
    def test_second_command_succeeds(self, mock_run: MagicMock) -> None:
        """First command fails, second succeeds."""
        mock_run.side_effect = [
            subprocess.CompletedProcess(args=[], returncode=1, stdout="", stderr="err"),
            subprocess.CompletedProcess(args=[], returncode=0, stdout="ok", stderr=""),
        ]
        option = _make_option(commands=[["cmd1"], ["cmd2", "arg"]])
        result = attempt_install(option)
        assert result.success is True
        assert result.command_used == "cmd2 arg"

    @patch("exokit.core.installers.subprocess.run")
    def test_install_timeout(self, mock_run: MagicMock) -> None:
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="brew", timeout=300)
        option = _make_option()
        result = attempt_install(option)
        assert result.success is False

    @patch("exokit.core.installers.subprocess.run")
    def test_install_command_not_found(self, mock_run: MagicMock) -> None:
        mock_run.side_effect = FileNotFoundError()
        option = _make_option()
        result = attempt_install(option)
        assert result.success is False


class TestVerifyInstall:
    """Tests for verify_install function."""

    def test_verify_known_tool(self) -> None:
        mock_check = MagicMock(
            return_value=PrereqResult(name="uv", passed=True, message="uv found", version="0.5.0")
        )
        with patch.dict("exokit.core.installers._CHECK_FUNCTIONS", {"uv": mock_check}):
            result = verify_install("uv")
        assert result.passed is True
        assert result.version == "0.5.0"
        mock_check.assert_called_once()

    def test_verify_unknown_tool(self) -> None:
        result = verify_install("unknown-tool")
        assert result.passed is False
        assert "No verification check" in result.message

    def test_verify_fails_after_install(self) -> None:
        """Tool installed but not on PATH yet."""
        mock_check = MagicMock(
            return_value=PrereqResult(name="node", passed=False, message="Node.js not found")
        )
        with patch.dict("exokit.core.installers._CHECK_FUNCTIONS", {"node": mock_check}):
            result = verify_install("node")
        assert result.passed is False


class TestSetupDatabricksAuth:
    """Tests for setup_databricks_auth function."""

    @patch("exokit.core.installers.subprocess.run")
    def test_auth_success(self, mock_run: MagicMock) -> None:
        mock_run.return_value = subprocess.CompletedProcess(
            args=[], returncode=0, stdout="", stderr=""
        )
        request = AuthSetupRequest(workspace_url="https://adb-123.net", profile_name="test")
        result = setup_databricks_auth(request)
        assert result.success is True
        assert result.profile_name == "test"
        assert "adb-123.net" in result.message

    @patch("exokit.core.installers.subprocess.run")
    def test_auth_failure(self, mock_run: MagicMock) -> None:
        mock_run.return_value = subprocess.CompletedProcess(
            args=[], returncode=1, stdout="", stderr="error"
        )
        request = AuthSetupRequest(workspace_url="https://adb-123.net", profile_name="test")
        result = setup_databricks_auth(request)
        assert result.success is False

    @patch("exokit.core.installers.subprocess.run")
    def test_auth_timeout(self, mock_run: MagicMock) -> None:
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="databricks", timeout=120)
        request = AuthSetupRequest(workspace_url="https://adb-123.net", profile_name="test")
        result = setup_databricks_auth(request)
        assert result.success is False
        assert "timed out" in result.message.lower()

    @patch("exokit.core.installers.subprocess.run")
    def test_auth_cli_not_found(self, mock_run: MagicMock) -> None:
        mock_run.side_effect = FileNotFoundError()
        request = AuthSetupRequest(workspace_url="https://adb-123.net", profile_name="test")
        result = setup_databricks_auth(request)
        assert result.success is False
        assert "not found" in result.message.lower()

    @patch("exokit.core.installers.subprocess.run")
    def test_auth_command_args(self, mock_run: MagicMock) -> None:
        """Verify the correct command is constructed."""
        mock_run.return_value = subprocess.CompletedProcess(
            args=[], returncode=0, stdout="", stderr=""
        )
        request = AuthSetupRequest(
            workspace_url="https://my-workspace.cloud.databricks.com",
            profile_name="my-profile",
        )
        setup_databricks_auth(request)
        call_args = mock_run.call_args[0][0]
        assert call_args == [
            "databricks",
            "auth",
            "login",
            "--host",
            "https://my-workspace.cloud.databricks.com",
            "--profile",
            "my-profile",
        ]


class TestCheckAndInstallAll:
    """Tests for the orchestrating check_and_install_all function."""

    def _make_prompter(
        self,
        confirm: bool = True,
    ) -> MagicMock:
        """Create a mock prompter."""
        prompter = MagicMock()
        prompter.confirm_install.return_value = confirm
        return prompter

    @patch("exokit.core.installers.check_all")
    def test_all_pass_no_prompts(self, mock_check_all: MagicMock) -> None:
        """When all checks pass, prompter is never called."""
        mock_check_all.return_value = [
            PrereqResult(name="uv", passed=True, message="ok", version="1.0"),
            PrereqResult(name="node", passed=True, message="ok", version="20.0"),
        ]
        prompter = self._make_prompter()
        results = check_and_install_all(prompter)
        assert all(r.passed for r in results)
        prompter.confirm_install.assert_not_called()

    @patch("exokit.core.installers.check_all")
    def test_user_declines_install(self, mock_check_all: MagicMock) -> None:
        """When user declines, original failure is preserved."""
        mock_check_all.return_value = [
            PrereqResult(name="uv", passed=False, message="not found"),
        ]
        prompter = self._make_prompter(confirm=False)
        results = check_and_install_all(prompter)
        assert results[0].passed is False
        prompter.on_install_start.assert_not_called()

    @patch("exokit.core.installers.verify_install")
    @patch("exokit.core.installers.attempt_install")
    @patch("exokit.core.installers.check_all")
    def test_user_accepts_install_success(
        self,
        mock_check_all: MagicMock,
        mock_attempt: MagicMock,
        mock_verify: MagicMock,
    ) -> None:
        """When user accepts and install succeeds, re-verify passes."""
        mock_check_all.return_value = [
            PrereqResult(name="uv", passed=False, message="not found"),
        ]
        mock_attempt.return_value = InstallResult(tool_name="uv", success=True, message="ok")
        mock_verify.return_value = PrereqResult(
            name="uv", passed=True, message="uv found", version="0.5.0"
        )
        prompter = self._make_prompter(confirm=True)
        results = check_and_install_all(prompter)
        assert results[0].passed is True
        assert results[0].version == "0.5.0"
        prompter.on_install_start.assert_called_once()
        prompter.on_install_complete.assert_called_once()

    @patch("exokit.core.installers.attempt_install")
    @patch("exokit.core.installers.check_all")
    def test_install_fails(
        self,
        mock_check_all: MagicMock,
        mock_attempt: MagicMock,
    ) -> None:
        """When install fails, original failure is preserved."""
        mock_check_all.return_value = [
            PrereqResult(name="uv", passed=False, message="not found"),
        ]
        mock_attempt.return_value = InstallResult(tool_name="uv", success=False, message="failed")
        prompter = self._make_prompter(confirm=True)
        results = check_and_install_all(prompter)
        assert results[0].passed is False

    @patch("exokit.core.installers.check_all")
    def test_auth_checks_skipped(self, mock_check_all: MagicMock) -> None:
        """Auth failures are passed through, not auto-installed."""
        mock_check_all.return_value = [
            PrereqResult(name="databricks-auth-DEFAULT", passed=False, message="no auth"),
            PrereqResult(name="databricks-profiles", passed=False, message="no profiles"),
        ]
        prompter = self._make_prompter()
        results = check_and_install_all(prompter)
        assert all(not r.passed for r in results)
        prompter.confirm_install.assert_not_called()

    @patch("exokit.core.installers.check_all")
    def test_no_install_option_available(self, mock_check_all: MagicMock) -> None:
        """Tool with no install option is passed through unchanged."""
        mock_check_all.return_value = [
            PrereqResult(name="nonexistent-tool", passed=False, message="missing"),
        ]
        prompter = self._make_prompter()
        results = check_and_install_all(prompter)
        assert results[0].passed is False
        prompter.confirm_install.assert_not_called()

    @patch("exokit.core.installers.verify_install")
    @patch("exokit.core.installers.attempt_install")
    @patch("exokit.core.installers.check_all")
    def test_mixed_pass_and_fail(
        self,
        mock_check_all: MagicMock,
        mock_attempt: MagicMock,
        mock_verify: MagicMock,
    ) -> None:
        """Mix of passing, failing, and installable tools."""
        mock_check_all.return_value = [
            PrereqResult(name="uv", passed=True, message="ok", version="1.0"),
            PrereqResult(name="node", passed=False, message="not found"),
            PrereqResult(name="databricks-auth-DEFAULT", passed=False, message="no auth"),
        ]
        mock_attempt.return_value = InstallResult(tool_name="node", success=True, message="ok")
        mock_verify.return_value = PrereqResult(
            name="node", passed=True, message="found", version="20.0"
        )
        prompter = self._make_prompter(confirm=True)
        results = check_and_install_all(prompter)
        assert results[0].passed is True  # uv (already passing)
        assert results[1].passed is True  # node (installed)
        assert results[2].passed is False  # auth (skipped)
