#!/usr/bin/env bash
# Test exokit prereqs auto-install in a clean Docker container.
#
# Usage: ./scripts/test_prereqs_docker.sh
#
# Builds a minimal Python 3.11 container, installs exokit from source,
# and runs a test script that calls check_and_install_all with an
# auto-accepting prompter to verify the full install flow.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/.."

echo "=== Building Docker test image ==="
docker build -t exokit-prereqs-test -f scripts/Dockerfile.test-prereqs .

echo ""
echo "=== Running prereqs check (before auto-install) ==="
docker run --rm exokit-prereqs-test python3 -c "
from exokit.core.prereqs import check_all

results = check_all()
for r in results:
    status = 'PASS' if r.passed else 'FAIL'
    print(f'  [{status}] {r.name}: {r.message}')

passed = sum(1 for r in results if r.passed)
print(f'\n{passed}/{len(results)} checks passed')
"

echo ""
echo "=== Running auto-install (yes to everything) ==="
docker run --rm exokit-prereqs-test python3 -c "
from exokit.core.installers import check_and_install_all
from exokit.core.models import AuthSetupRequest, InstallOption, InstallResult

class AutoAcceptPrompter:
    def confirm_install(self, option: InstallOption) -> bool:
        print(f'  > {option.display_name} is missing. Auto-accepting install...')
        return True

    def on_install_start(self, tool_name: str, command: str) -> None:
        print(f'  > Installing {tool_name}: {command}')

    def on_install_complete(self, result: InstallResult) -> None:
        status = 'OK' if result.success else 'FAIL'
        print(f'  > [{status}] {result.tool_name}: {result.message}')

    def prompt_auth_setup(self) -> AuthSetupRequest | None:
        return None

    def on_auth_progress(self, message: str) -> None:
        print(f'  > {message}')

prompter = AutoAcceptPrompter()
results = check_and_install_all(prompter)

print()
print('=== Final results ===')
for r in results:
    status = 'PASS' if r.passed else 'FAIL'
    version = f' v{r.version}' if r.version else ''
    print(f'  [{status}] {r.name}{version}: {r.message}')

passed = sum(1 for r in results if r.passed)
print(f'\n{passed}/{len(results)} checks passed after auto-install')
"

echo ""
echo "=== Cleanup ==="
docker rmi exokit-prereqs-test -f 2>/dev/null || true
echo "Done."
