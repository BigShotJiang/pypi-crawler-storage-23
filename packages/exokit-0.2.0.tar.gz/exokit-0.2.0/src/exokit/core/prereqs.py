"""Prerequisite checks for demo scaffolding.

Each check uses subprocess.run to detect tool version.
No UI code — returns structured PrereqResult objects.
"""

from __future__ import annotations

import platform
import re
import subprocess

from exokit.core.models import InstallOption, PrereqResult


def _run_version_command(command: list[str]) -> tuple[bool, str]:
    """Run a version command and return (success, output).

    Returns (False, error_message) if the command fails or is not found.
    """
    try:
        result = subprocess.run(  # noqa: S603
            command,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return True, result.stdout.strip()
        return False, result.stderr.strip()
    except FileNotFoundError:
        return False, f"Command not found: {command[0]}"
    except subprocess.TimeoutExpired:
        return False, f"Command timed out: {' '.join(command)}"


def _extract_version(output: str) -> str | None:
    """Extract a version string (e.g. 1.2.3) from command output."""
    match = re.search(r"\d+\.\d+(?:\.\d+)?", output)
    if match:
        return match.group(0)
    return None


def check_databricks_cli() -> PrereqResult:
    """Check if the Databricks CLI is installed and accessible."""
    success, output = _run_version_command(["databricks", "--version"])
    if success:
        version = _extract_version(output)
        return PrereqResult(
            name="databricks-cli",
            passed=True,
            message=f"Databricks CLI found: {output}",
            version=version,
        )
    return PrereqResult(
        name="databricks-cli",
        passed=False,
        message=f"Databricks CLI not found: {output}",
    )


def check_uv() -> PrereqResult:
    """Check if uv package manager is installed."""
    success, output = _run_version_command(["uv", "--version"])
    if success:
        version = _extract_version(output)
        return PrereqResult(
            name="uv",
            passed=True,
            message=f"uv found: {output}",
            version=version,
        )
    return PrereqResult(
        name="uv",
        passed=False,
        message=f"uv not found: {output}",
    )


def check_node() -> PrereqResult:
    """Check if Node.js is installed."""
    success, output = _run_version_command(["node", "--version"])
    if success:
        version = _extract_version(output)
        return PrereqResult(
            name="node",
            passed=True,
            message=f"Node.js found: {output}",
            version=version,
        )
    return PrereqResult(
        name="node",
        passed=False,
        message=f"Node.js not found: {output}",
    )


def check_apx() -> PrereqResult:
    """Check if APX CLI is installed."""
    success, output = _run_version_command(["apx", "--version"])
    if success:
        version = _extract_version(output)
        return PrereqResult(
            name="apx",
            passed=True,
            message=f"APX found: {output}",
            version=version,
        )
    return PrereqResult(
        name="apx",
        passed=False,
        message=f"APX not found: {output}",
    )


def check_databricks_auth(profile: str = "DEFAULT") -> PrereqResult:
    """Check if Databricks authentication is configured for the given profile."""
    success, output = _run_version_command(["databricks", "auth", "describe", "--profile", profile])
    if success:
        return PrereqResult(
            name=f"databricks-auth-{profile}",
            passed=True,
            message=f"Databricks auth configured for profile '{profile}'",
        )
    return PrereqResult(
        name=f"databricks-auth-{profile}",
        passed=False,
        message=f"Databricks auth not configured for profile '{profile}': {output}",
    )


def check_databricks_profiles() -> PrereqResult:
    """Check that at least one Databricks CLI profile exists in ~/.databrickscfg."""
    import configparser
    from pathlib import Path

    cfg_path = Path.home() / ".databrickscfg"
    if not cfg_path.exists():
        return PrereqResult(
            name="databricks-profiles",
            passed=False,
            message=("No ~/.databrickscfg found. Run: databricks configure --profile <name>"),
        )

    cfg = configparser.ConfigParser()
    cfg.read(cfg_path)
    profiles = list(cfg.sections())
    if cfg.defaults():
        profiles.insert(0, "DEFAULT")

    if not profiles:
        return PrereqResult(
            name="databricks-profiles",
            passed=False,
            message=(
                "~/.databrickscfg exists but has no profiles. "
                "Run: databricks configure --profile <name>"
            ),
        )

    return PrereqResult(
        name="databricks-profiles",
        passed=True,
        message=f"Found {len(profiles)} profile(s): {', '.join(profiles[:5])}",
        version=str(len(profiles)),
    )


def check_ai_dev_kit() -> PrereqResult:
    """Check if the Databricks AI Dev Kit MCP server is installed."""
    from pathlib import Path

    kit_path = Path.home() / ".ai-dev-kit"
    venv_python = kit_path / ".venv" / "bin" / "python"
    server_script = kit_path / "repo" / "databricks-mcp-server" / "run_server.py"

    if venv_python.exists() and server_script.exists():
        return PrereqResult(
            name="ai-dev-kit",
            passed=True,
            message=f"MCP server found at {kit_path}",
        )

    return PrereqResult(
        name="ai-dev-kit",
        passed=False,
        message=(
            "Databricks MCP server not installed. Install with:\n"
            "  bash <(curl -sL https://raw.githubusercontent.com/"
            "databricks-solutions/ai-dev-kit/main/install.sh)"
        ),
    )


def check_all(databricks_profile: str = "DEFAULT") -> list[PrereqResult]:
    """Run all prerequisite checks and return results.

    Order matters for auto-install: uv must be installed before APX
    and AI Dev Kit (they depend on it), Node.js before APX.

    Args:
        databricks_profile: The Databricks CLI profile to check auth for.

    Returns:
        List of PrereqResult for each check.
    """
    return [
        check_databricks_cli(),
        check_uv(),
        check_node(),
        check_apx(),
        check_ai_dev_kit(),
        check_databricks_profiles(),
        check_databricks_auth(profile=databricks_profile),
    ]


# ---------------------------------------------------------------------------
# Install registry — platform-aware install commands per tool
# ---------------------------------------------------------------------------


def _detect_platform() -> str:
    """Detect the current platform for install command selection."""
    system = platform.system().lower()
    if system == "darwin":
        return "macos"
    return system  # "linux", "windows", etc.


_WSL_HINT = "Windows is not supported. Please use WSL (Windows Subsystem for Linux)."


def _build_install_options() -> dict[str, InstallOption]:
    """Build platform-aware install options for each prerequisite tool."""
    plat = _detect_platform()

    # Windows: no auto-install — point users to WSL
    if plat == "windows":
        tool_names = [
            ("databricks-cli", "Databricks CLI"),
            ("uv", "uv package manager"),
            ("node", "Node.js"),
            ("apx", "APX CLI"),
            ("ai-dev-kit", "Databricks AI Dev Kit (MCP Server)"),
        ]
        return {
            name: InstallOption(
                tool_name=name,
                display_name=display,
                commands=[],
                platform_hint=_WSL_HINT,
            )
            for name, display in tool_names
        }

    options: dict[str, InstallOption] = {}

    # Databricks CLI
    if plat == "macos":
        options["databricks-cli"] = InstallOption(
            tool_name="databricks-cli",
            display_name="Databricks CLI",
            commands=[["brew", "install", "databricks/tap/databricks"]],
            platform_hint="Install via Homebrew: brew install databricks/tap/databricks",
        )
    else:
        options["databricks-cli"] = InstallOption(
            tool_name="databricks-cli",
            display_name="Databricks CLI",
            commands=[
                [
                    "bash",
                    "-c",
                    "curl -fsSL https://raw.githubusercontent.com/"
                    "databricks/setup-cli/main/install.sh | sh",
                ],
            ],
            platform_hint=(
                "Install with: curl -fsSL "
                "https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sh"
            ),
        )

    # uv (same command on macOS and Linux)
    options["uv"] = InstallOption(
        tool_name="uv",
        display_name="uv package manager",
        commands=[["bash", "-c", "curl -LsSf https://astral.sh/uv/install.sh | sh"]],
        platform_hint="Install with: curl -LsSf https://astral.sh/uv/install.sh | sh",
    )

    # Node.js
    if plat == "macos":
        options["node"] = InstallOption(
            tool_name="node",
            display_name="Node.js",
            commands=[["brew", "install", "node"]],
            platform_hint="Install via Homebrew (brew install node) or nvm (https://nvm.sh)",
        )
    else:
        options["node"] = InstallOption(
            tool_name="node",
            display_name="Node.js",
            commands=[],  # too many Linux variants — manual install
            platform_hint="Install via nvm (https://nvm.sh) or your system package manager",
        )

    # APX (binary installer, not a Python package)
    options["apx"] = InstallOption(
        tool_name="apx",
        display_name="APX CLI",
        commands=[
            [
                "bash",
                "-c",
                "curl -fsSL https://databricks-solutions.github.io/apx/install.sh | sh",
            ],
        ],
        platform_hint=(
            "Install with: curl -fsSL https://databricks-solutions.github.io/apx/install.sh | sh"
        ),
    )

    # AI Dev Kit
    options["ai-dev-kit"] = InstallOption(
        tool_name="ai-dev-kit",
        display_name="Databricks AI Dev Kit (MCP Server)",
        commands=[
            [
                "bash",
                "-c",
                "curl -sL https://raw.githubusercontent.com/"
                "databricks-solutions/ai-dev-kit/main/install.sh | bash",
            ],
        ],
        platform_hint=(
            "Install with: bash <(curl -sL https://raw.githubusercontent.com/"
            "databricks-solutions/ai-dev-kit/main/install.sh)"
        ),
    )

    return options


INSTALL_OPTIONS: dict[str, InstallOption] = _build_install_options()
