"""Auto-installation logic for missing prerequisites.

Provides install commands and execution — no UI code.
Uses the InstallPrompter protocol for user interaction callbacks.
"""

from __future__ import annotations

import os
import subprocess
from collections.abc import Callable
from pathlib import Path

from exokit.core.models import (
    AuthSetupRequest,
    AuthSetupResult,
    InstallOption,
    InstallPrompter,
    InstallResult,
    PrereqResult,
)
from exokit.core.prereqs import (
    INSTALL_OPTIONS,
    check_ai_dev_kit,
    check_all,
    check_apx,
    check_databricks_cli,
    check_node,
    check_uv,
)

# Map tool names to their re-verification check functions
_CHECK_FUNCTIONS: dict[str, Callable[[], PrereqResult]] = {
    "databricks-cli": check_databricks_cli,
    "uv": check_uv,
    "node": check_node,
    "apx": check_apx,
    "ai-dev-kit": check_ai_dev_kit,
}


def _run_install_command(command: list[str]) -> tuple[bool, str]:
    """Execute an install command and return (success, output)."""
    try:
        result = subprocess.run(  # noqa: S603
            command,
            capture_output=True,
            text=True,
            timeout=300,  # 5 minutes for installs
        )
        if result.returncode == 0:
            return True, result.stdout.strip()
        return False, result.stderr.strip()
    except FileNotFoundError:
        return False, f"Command not found: {command[0]}"
    except subprocess.TimeoutExpired:
        return False, "Installation timed out (5 minutes)"


def attempt_install(option: InstallOption) -> InstallResult:
    """Try to install a tool using its defined commands.

    Tries each command in order, stops at the first success.
    """
    for cmd in option.commands:
        success, output = _run_install_command(cmd)
        if success:
            return InstallResult(
                tool_name=option.tool_name,
                success=True,
                message="Installed successfully",
                command_used=" ".join(cmd),
            )

    return InstallResult(
        tool_name=option.tool_name,
        success=False,
        message=f"Installation failed. {option.platform_hint}",
    )


def _refresh_path() -> None:
    """Add common install directories to PATH for the current process.

    Installers like ``curl | sh`` (uv, APX) write binaries to
    ``~/.local/bin`` or ``~/.cargo/bin`` and update shell config, but
    the current process won't see them until PATH is refreshed.
    """
    home = Path.home()
    extra_dirs = [
        str(home / ".local" / "bin"),  # uv, APX
        str(home / ".cargo" / "bin"),  # uv (alternative)
        "/opt/homebrew/bin",  # brew on Apple Silicon
        "/usr/local/bin",  # brew on Intel Mac
    ]
    current_path = os.environ.get("PATH", "")
    path_parts = current_path.split(os.pathsep)
    for d in extra_dirs:
        if d not in path_parts and Path(d).is_dir():
            path_parts.insert(0, d)
    os.environ["PATH"] = os.pathsep.join(path_parts)


def verify_install(tool_name: str) -> PrereqResult:
    """Re-run the check for a tool after installation.

    If the first check fails, refreshes PATH (to pick up newly
    installed binaries) and tries once more.
    """
    check_fn = _CHECK_FUNCTIONS.get(tool_name)
    if check_fn is None:
        return PrereqResult(
            name=tool_name,
            passed=False,
            message=f"No verification check available for {tool_name}",
        )
    result = check_fn()
    if result.passed:
        return result

    # Binary may not be on PATH yet — refresh and retry
    _refresh_path()
    return check_fn()


def setup_databricks_auth(request: AuthSetupRequest) -> AuthSetupResult:
    """Run ``databricks auth login`` for the given workspace and profile.

    Opens a browser for OAuth. The subprocess blocks until the user
    completes the OAuth flow or the timeout expires.
    """
    cmd = [
        "databricks",
        "auth",
        "login",
        "--host",
        request.workspace_url,
        "--profile",
        request.profile_name,
    ]
    try:
        result = subprocess.run(  # noqa: S603
            cmd,
            capture_output=False,  # let browser auth flow through to terminal
            timeout=120,
        )
        if result.returncode == 0:
            return AuthSetupResult(
                success=True,
                profile_name=request.profile_name,
                message=f"Authenticated to {request.workspace_url}",
            )
        return AuthSetupResult(
            success=False,
            profile_name=request.profile_name,
            message="Authentication failed",
        )
    except subprocess.TimeoutExpired:
        return AuthSetupResult(
            success=False,
            profile_name=request.profile_name,
            message="Authentication timed out (2 minutes)",
        )
    except FileNotFoundError:
        return AuthSetupResult(
            success=False,
            profile_name=request.profile_name,
            message="Databricks CLI not found — install it first",
        )


def check_and_install_all(
    prompter: InstallPrompter,
    databricks_profile: str = "DEFAULT",
) -> list[PrereqResult]:
    """Run all prereq checks, offering to install missing tools.

    For each failed check:
    1. Look up the install option
    2. Ask the user via prompter.confirm_install()
    3. If yes, run the install command and re-verify
    4. Collect final results

    Auth and profile checks are passed through unchanged — they are
    handled separately via the wizard's "Add new profile" flow.
    """
    results = check_all(databricks_profile=databricks_profile)
    final_results: list[PrereqResult] = []

    for result in results:
        if result.passed:
            final_results.append(result)
            continue

        # Auth and profile checks are handled by the wizard, not here
        if result.name.startswith("databricks-auth") or result.name == "databricks-profiles":
            final_results.append(result)
            continue

        option = INSTALL_OPTIONS.get(result.name)
        if option is None or not option.commands:
            # No auto-install available — show platform hint
            final_results.append(result)
            continue

        if not prompter.confirm_install(option):
            final_results.append(result)
            continue

        # Attempt install
        prompter.on_install_start(option.tool_name, " ".join(option.commands[0]))
        install_result = attempt_install(option)
        prompter.on_install_complete(install_result)

        if install_result.success:
            verified = verify_install(result.name)
            final_results.append(verified)
        else:
            final_results.append(result)

    return final_results
