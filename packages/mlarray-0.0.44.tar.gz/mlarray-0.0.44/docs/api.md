# API Reference

## MLArray Module

::: mlarray.mlarray.MLArray

## Metadata Module

::: mlarray.meta.BaseMeta

::: mlarray.meta.SingleKeyBaseMeta

::: mlarray.meta.Meta

::: mlarray.meta.MetaSource

::: mlarray.meta.MetaExtra

::: mlarray.meta.MetaSpatial

::: mlarray.meta.AxisLabelEnum

::: mlarray.meta.MetaStatistics

::: mlarray.meta.MetaBbox

::: mlarray.meta.MetaIsSeg

::: mlarray.meta.MetaBlosc2

::: mlarray.meta.MetaHasArray

::: mlarray.meta.MetaImageFormat

::: mlarray.meta.MetaVersion
