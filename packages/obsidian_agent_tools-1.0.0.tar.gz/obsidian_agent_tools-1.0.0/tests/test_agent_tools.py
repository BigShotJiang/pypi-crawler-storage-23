import pytest
import os
import sys
import json
import tempfile
from unittest.mock import patch, MagicMock


try:
    from agent_tools.core import load_config, save_config, list_tools, run_tool, format_output, build_cli, main
except ImportError:
    import importlib
    agent_tools_core = importlib.import_module("agent-tools.core")
    load_config = agent_tools_core.load_config
    save_config = agent_tools_core.save_config
    list_tools = agent_tools_core.list_tools
    run_tool = agent_tools_core.run_tool
    format_output = agent_tools_core.format_output
    build_cli = agent_tools_core.build_cli
    main = agent_tools_core.main


class TestLoadConfig:
    def test_load_config_valid_file(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_data = {"tools": ["tool1", "tool2"], "verbose": True}
        config_file.write_text(json.dumps(config_data))
        result = load_config(str(config_file))
        assert isinstance(result, dict)
        assert "tools" in result or result is not None

    def test_load_config_missing_file(self):
        with pytest.raises((FileNotFoundError, OSError, Exception)):
            load_config("/nonexistent/path/config.json")

    def test_load_config_empty_file(self, tmp_path):
        config_file = tmp_path / "empty_config.json"
        config_file.write_text("")
        try:
            result = load_config(str(config_file))
            assert result is not None or result is None
        except (json.JSONDecodeError, ValueError, Exception):
            pass

    def test_load_config_default_path(self):
        try:
            result = load_config()
            assert result is not None or result is None
        except (TypeError, FileNotFoundError, Exception):
            pass


class TestSaveConfig:
    def test_save_config_valid(self, tmp_path):
        config_file = tmp_path / "output_config.json"
        config_data = {"tools": ["tool1"], "verbose": False}
        try:
            result = save_config(config_data, str(config_file))
            assert config_file.exists() or result is not None or result is None
        except TypeError:
            save_config(str(config_file), config_data)
            assert config_file.exists()

    def test_save_config_invalid_path(self):
        config_data = {"key": "value"}
        with pytest.raises((OSError, PermissionError, Exception)):
            save_config(config_data, "/nonexistent/deep/path/config.json")

    def test_save_config_empty_dict(self, tmp_path):
        config_file = tmp_path / "empty_config.json"
        try:
            save_config({}, str(config_file))
            assert config_file.exists()
        except Exception:
            pass


class TestListTools:
    def test_list_tools_returns_iterable(self):
        result = list_tools({})
        assert hasattr(result, '__iter__')

    def test_list_tools_returns_list_or_dict(self):
        result = list_tools({})
        assert isinstance(result, (list, dict, tuple, set))

    def test_list_tools_elements_are_strings_or_dicts(self):
        result = list_tools({})
        if isinstance(result, (list, tuple)):
            for item in result:
                assert isinstance(item, (str, dict))


class TestRunTool:
    def test_run_tool_invalid_tool_name(self):
        with pytest.raises((ValueError, KeyError, RuntimeError, Exception)):
            run_tool("nonexistent_tool_xyz_12345")

    def test_run_tool_with_none(self):
        with pytest.raises((TypeError, ValueError, KeyError, Exception)):
            run_tool(None)

    def test_run_tool_valid_if_tools_exist(self):
        tools = list_tools({})
        if tools:
            tool_name = tools[0] if isinstance(tools[0], str) else list(tools[0].keys())[0] if isinstance(tools[0], dict) else str(tools[0])
            try:
                result = run_tool(tool_name)
                assert result is not None or result is None
            except Exception:
                pass


class TestFormatOutput:
    def test_format_output_string(self):
        result = format_output("hello world")
        assert isinstance(result, str)

    def test_format_output_dict(self):
        data = {"key": "value", "number": 42}
        result = format_output(data)
        assert isinstance(result, str)
        assert len(result) > 0

    def test_format_output_empty(self):
        try:
            result = format_output("")
            assert isinstance(result, str)
        except (ValueError, TypeError):
            pass

    def test_format_output_none(self):
        try:
            result = format_output(None)
            assert isinstance(result, str) or result is None
        except (TypeError, ValueError):
            pass

    def test_format_output_list(self):
        data = [1, 2, 3, "test"]
        result = format_output(data)
        assert isinstance(result, str)

    def test_format_output_nested_dict(self):
        data = {"outer": {"inner": "value"}, "list": [1, 2, 3]}
        result = format_output(data)
        assert isinstance(result, str)
        assert len(result) > 0


class TestBuildCli:
    def test_build_cli_returns_parser(self):
        result = build_cli()
        assert result is not None
        assert hasattr(result, 'parse_args') or callable(result)

    def test_build_cli_parse_help(self):
        cli = build_cli()
        if hasattr(cli, 'parse_args'):
            with pytest.raises(SystemExit):
                cli.parse_args(["--help"])


class TestMain:
    def test_main_no_args(self):
        with patch('sys.argv', ['agent-tools']):
            try:
                result = main()
                assert result is None or isinstance(result, int) or result is not None
            except SystemExit as e:
                assert e.code is None or isinstance(e.code, int)
            except Exception:
                pass

    def test_main_help_flag(self):
        with patch('sys.argv', ['agent-tools', '--help']):
            with pytest.raises(SystemExit) as exc_info:
                main()
            assert exc_info.value.code == 0 or exc_info.value.code is None

    def test_main_invalid_args(self):
        with patch('sys.argv', ['agent-tools', '--invalid-flag-xyz']):
            try:
                result = main()
            except (SystemExit, Exception):
                pass