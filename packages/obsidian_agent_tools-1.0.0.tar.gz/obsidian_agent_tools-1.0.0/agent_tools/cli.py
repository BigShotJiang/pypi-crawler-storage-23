import argparse
import json
import sys

from .core import load_config, save_config, list_tools, run_tool, format_output, build_cli, main as core_main


def cmd_config_load(args):
    config = load_config(args.path if hasattr(args, 'path') and args.path else None)
    if args.json:
        print(json.dumps(config, indent=2, default=str))
    else:
        output = format_output(config)
        print(output)
    if args.verbose:
        print(f"[DEBUG] Config loaded from: {getattr(args, 'path', 'default')}", file=sys.stderr)


def cmd_config_save(args):
    config = load_config(args.input if hasattr(args, 'input') and args.input else None)
    save_config(config, args.output if hasattr(args, 'output') and args.output else None)
    if args.verbose:
        print(f"[DEBUG] Config saved to: {getattr(args, 'output', 'default')}", file=sys.stderr)
    if args.json:
        print(json.dumps({"status": "saved"}, indent=2))
    else:
        print("Configuration saved successfully.")


def cmd_list_tools(args):
    tools = list_tools()
    if args.json:
        print(json.dumps(tools, indent=2, default=str))
    else:
        output = format_output(tools)
        print(output)
    if args.verbose:
        print(f"[DEBUG] Found {len(tools) if isinstance(tools, (list, dict)) else 'unknown'} tools", file=sys.stderr)


def cmd_run_tool(args):
    if args.verbose:
        print(f"[DEBUG] Running tool: {args.tool_name} with args: {args.tool_args}", file=sys.stderr)
    result = run_tool(args.tool_name, *args.tool_args)
    if args.json:
        print(json.dumps(result, indent=2, default=str))
    else:
        output = format_output(result)
        print(output)


def cmd_format(args):
    import sys as _sys
    if args.input_file:
        with open(args.input_file, 'r') as f:
            data = f.read()
    else:
        data = _sys.stdin.read()
    try:
        parsed = json.loads(data)
    except json.JSONDecodeError:
        parsed = data
    result = format_output(parsed)
    if args.json:
        print(json.dumps({"formatted": result}, indent=2, default=str))
    else:
        print(result)
    if args.verbose:
        print(f"[DEBUG] Formatted output from: {args.input_file or 'stdin'}", file=sys.stderr)


def cmd_build(args):
    if args.verbose:
        print("[DEBUG] Building CLI configuration...", file=sys.stderr)
    result = build_cli()
    if args.json:
        print(json.dumps(result, indent=2, default=str))
    else:
        output = format_output(result)
        print(output)


def main():
    parser = argparse.ArgumentParser(
        prog="agent-tools",
        description="CLI for agent-tools package",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 1.0.0",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Output results in JSON format",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        default=False,
        help="Enable debug/verbose output",
    )

    subparsers = parser.add_subparsers(
        title="subcommands",
        dest="subcommand",
        help="Available subcommands",
    )

    # config-load subcommand
    parser_config_load = subparsers.add_parser(
        "config-load",
        help="Load configuration",
    )
    parser_config_load.add_argument(
        "--path",
        type=str,
        default=None,
        help="Path to configuration file",
    )
    parser_config_load.set_defaults(func=cmd_config_load)

    # config-save subcommand
    parser_config_save = subparsers.add_parser(
        "config-save",
        help="Save configuration",
    )
    parser_config_save.add_argument(
        "--input",
        type=str,
        default=None,
        help="Path to input configuration file",
    )
    parser_config_save.add_argument(
        "--output",
        type=str,
        default=None,
        help="Path to output configuration file",
    )
    parser_config_save.set_defaults(func=cmd_config_save)

    # list subcommand
    parser_list = subparsers.add_parser(
        "list",
        help="List available tools",
    )
    parser_list.set_defaults(func=cmd_list_tools)

    # run subcommand
    parser_run = subparsers.add_parser(
        "run",
        help="Run a specific tool",
    )
    parser_run.add_argument(
        "tool_name",
        type=str,
        help="Name of the tool to run",
    )
    parser_run.add_argument(
        "tool_args",
        nargs="*",
        default=[],
        help="Arguments to pass to the tool",
    )
    parser_run.set_defaults(func=cmd_run_tool)

    # format subcommand
    parser_format = subparsers.add_parser(
        "format",
        help="Format output data",
    )
    parser_format.add_argument(
        "--input-file",
        type=str,
        default=None,
        help="Input file to format (reads from stdin if not provided)",
    )
    parser_format.set_defaults(func=cmd_format)

    # build subcommand
    parser_build = subparsers.add_parser(
        "build",
        help="Build CLI configuration",
    )
    parser_build.set_defaults(func=cmd_build)

    args = parser.parse_args()

    if args.verbose:
        print(f"[DEBUG] Parsed arguments: {args}", file=sys.stderr)

    if args.subcommand is None:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()