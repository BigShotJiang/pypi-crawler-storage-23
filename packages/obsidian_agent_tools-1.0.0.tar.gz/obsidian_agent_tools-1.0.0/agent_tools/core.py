import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Optional


DEFAULT_CONFIG_PATHS = [
    Path.home() / ".agent-tools" / "config.json",
    Path("agent-tools.config.json"),
]


def load_config(config_path: Optional[str] = None) -> dict[str, Any]:
    """Load configuration from a JSON file.

    Args:
        config_path: Optional explicit path to a config file.
            If None, searches default locations.

    Returns:
        Dictionary of configuration values.

    Raises:
        FileNotFoundError: If an explicit config_path is given but does not exist.
        json.JSONDecodeError: If the config file contains invalid JSON.
    """
    if config_path is not None:
        p = Path(config_path)
        if not p.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)

    for candidate in DEFAULT_CONFIG_PATHS:
        if candidate.exists():
            with open(candidate, "r", encoding="utf-8") as f:
                return json.load(f)

    return {}


def save_config(config: dict[str, Any], config_path: Optional[str] = None) -> Path:
    """Save configuration to a JSON file.

    Args:
        config: Dictionary of configuration values to persist.
        config_path: Optional explicit path. Defaults to ~/.agent-tools/config.json.

    Returns:
        The Path where the configuration was written.
    """
    p = Path(config_path) if config_path else DEFAULT_CONFIG_PATHS[0]
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, default=str)
    return p


def list_tools(config: dict[str, Any]) -> list[dict[str, str]]:
    """List all registered AI agent tools.

    Args:
        config: Current configuration dictionary.

    Returns:
        A list of tool descriptor dictionaries.
    """
    builtin_tools = [
        {"name": "summarize", "description": "Summarize input text", "type": "text"},
        {"name": "extract", "description": "Extract structured data from text", "type": "text"},
        {"name": "classify", "description": "Classify input into categories", "type": "text"},
        {"name": "transform", "description": "Transform data between formats", "type": "data"},
        {"name": "validate", "description": "Validate data against a schema", "type": "data"},
    ]
    custom_tools = config.get("custom_tools", [])
    return builtin_tools + custom_tools


def run_tool(tool_name: str, input_data: str, config: dict[str, Any]) -> dict[str, Any]:
    """Execute a named AI agent tool against the provided input.

    Args:
        tool_name: The name of the tool to run.
        input_data: The input string or data to process.
        config: Current configuration dictionary.

    Returns:
        A result dictionary with status, tool name, and output.

    Raises:
        ValueError: If the tool_name is not found among registered tools.
    """
    available = {t["name"]: t for t in list_tools(config)}
    if tool_name not in available:
        raise ValueError(
            f"Unknown tool '{tool_name}'. Available tools: {', '.join(available.keys())}"
        )

    tool_info = available[tool_name]
    options = config.get("tool_options", {}).get(tool_name, {})

    output = _execute(tool_name, input_data, options)

    return {
        "status": "success",
        "tool": tool_name,
        "tool_type": tool_info["type"],
        "input_length": len(input_data),
        "output": output,
    }


def _execute(tool_name: str, input_data: str, options: dict[str, Any]) -> Any:
    """Internal dispatcher for tool execution."""
    max_len = options.get("max_length", 500)
    if tool_name == "summarize":
        sentences = [s.strip() for s in input_data.split(".") if s.strip()]
        limit = options.get("sentences", 3)
        summary = ". ".join(sentences[:limit])
        return summary[:max_len] if summary else input_data[:max_len]
    elif tool_name == "extract":
        words = input_data.split()
        return {"word_count": len(words), "char_count": len(input_data), "preview": input_data[:200]}
    elif tool_name == "classify":
        length = len(input_data)
        category = "short" if length < 100 else "medium" if length < 1000 else "long"
        return {"category": category, "length": length}
    elif tool_name == "transform":
        fmt = options.get("format", "upper")
        if fmt == "upper":
            return input_data.upper()
        elif fmt == "lower":
            return input_data.lower()
        elif fmt == "title":
            return input_data.title()
        return input_data
    elif tool_name == "validate":
        schema_type = options.get("schema", "non_empty")
        if schema_type == "non_empty":
            valid = len(input_data.strip()) > 0
        elif schema_type == "json":
            try:
                json.loads(input_data)
                valid = True
            except json.JSONDecodeError:
                valid = False
        else:
            valid = True
        return {"valid": valid, "schema": schema_type}
    else:
        return {"raw": input_data[:max_len]}


def format_output(result: Any, output_format: str = "json") -> str:
    """Format a result for display.

    Args:
        result: The data to format.
        output_format: One of 'json', 'text'. Defaults to 'json'.

    Returns:
        Formatted string representation.
    """
    if output_format == "json":
        return json.dumps(result, indent=2, default=str)
    elif output_format == "text":
        if isinstance(result, dict):
            lines = [f"{k}: {v}" for k, v in result.items()]
            return "\n".join(lines)
        elif isinstance(result, list):
            return "\n".join(str(item) for item in result)
        return str(result)
    return json.dumps(result, indent=2, default=str)


def build_cli() -> argparse.ArgumentParser:
    """Build and return the CLI argument parser.

    Returns:
        Configured ArgumentParser instance.
    """
    parser = argparse.ArgumentParser(
        prog="agent-tools",
        description="AI Agent Tools - auto-generated tool suite for ai_agent_tools",
    )
    parser.add_argument("--config", type=str, default=None, help="Path to config JSON file")
    parser.add_argument("--format", choices=["json", "text"], default="json", help="Output format")

    sub = parser.add_subparsers(dest="command", help="Available commands")

    sub.add_parser("list", help="List all available tools")

    run_p = sub.add_parser("run", help="Run a specific tool")
    run_p.add_argument("tool", type=str, help="Tool name to execute")
    run_p.add_argument("--input", type=str, default=None, help="Input string (or use stdin)")
    run_p.add_argument("--input-file", type=str, default=None, help="Read input from file")

    cfg_p = sub.add_parser("config", help="Manage configuration")
    cfg_p.add_argument("action", choices=["show", "set", "init"], help="Config action")
    cfg_p.add_argument("--key", type=str, default=None, help="Config key for set")
    cfg_p.add_argument("--value", type=str, default=None, help="Config value for set")

    return parser


def main() -> int:
    """Main entry point for the CLI.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    parser = build_cli()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    try:
        config = load_config(args.config)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Error loading config: {e}", file=sys.stderr)
        return 1

    try:
        if args.command == "list":
            tools = list_tools(config)
            print(format_output(tools, args.format))

        elif args.command == "run":
            input_data = args.input
            if args.input_file:
                p = Path(args.input_file)
                if not p.exists():
                    print(f"Error: Input file not found: {args.input_file}", file=sys.stderr)
                    return 1
                input_data = p.read_text(encoding="utf-8")
            elif input_data is None:
                if not sys.stdin.isatty():
                    input_data = sys.stdin.read()
                else:
                    print("Error: No input provided. Use --input, --input-file, or pipe via stdin.", file=sys.stderr)
                    return 1
            result = run_tool(args.tool, input_data, config)
            print(format_output(result, args.format))

        elif args.command == "config":
            if args.action == "show":
                print(format_output(config, args.format))
            elif args.action == "init":
                path = save_config({"custom_tools": [], "tool_options": {}}, args.config)
                print(f"Configuration initialized at {path}")
            elif args.action == "set":
                if not args.key:
                    print("Error: --key is required for config set", file=sys.stderr)
                    return 1
                try:
                    value: Any = json.loads(args.value) if args.value else None
                except json.JSONDecodeError:
                    value = args.value
                config[args.key] = value
                path = save_config(config, args.config)
                print(f"Configuration updated at {path}")

    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())