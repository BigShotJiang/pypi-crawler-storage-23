"""Utils for CTC models."""

from asr_eval.ctc.base import ctc_mapping


__all__ = [
    'ctc_mapping',
]