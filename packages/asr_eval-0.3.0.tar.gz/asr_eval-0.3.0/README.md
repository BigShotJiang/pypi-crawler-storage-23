# asr_eval ⚗️

Evaluation and building components for Automatic Speech Recognition in Python.

- [Preprint paper](https://arxiv.org/abs/2601.20992) (pdf)
- Full documentation (web)
- Full documentation (pdf)

## Features

**🧪 Evaluation features** (see overview, guide and reference)

- Extended annotation syntax via multi-reference and wildcard blocks
- Aligned multiple model comparision with error highlighting

**⚙️ Benchmarking features** (see overview, guide and reference)

- A set of baseline pipelines and datasets (in progress)
- Model benchmarking in scale with a web dashboard
- Components to build custom pipelines

**➰ Streaming features** (see overview, guide and reference)

- A base class and buffers for streaming models
- Streaming evaluation diagrams

## Installation

Please refer to the installation guide.

## Contributing

This project is in active development stage. Feel free to contrubite:

- Open an Issue on Github
- Open a Pull request (see Contributing guide)
- Write in Telegram chat and tag @olegs9
