
# Change Log
All notable changes to this project will be documented in this file.
 
## [0.3.0] - 2026-feb-14
  
First publicly released version.