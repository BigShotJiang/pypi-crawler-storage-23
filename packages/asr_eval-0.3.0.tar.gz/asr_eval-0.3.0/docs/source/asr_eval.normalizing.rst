asr_eval.normalizing
--------------------

.. automodule:: asr_eval.normalizing
   :members:
   :show-inheritance:

.. automodule:: asr_eval.normalizing.filler_words
   :members:
   :show-inheritance:

.. automodule:: asr_eval.normalizing.silero
   :members:
   :show-inheritance:

.. automodule:: asr_eval.normalizing.translit
   :members:
   :show-inheritance: