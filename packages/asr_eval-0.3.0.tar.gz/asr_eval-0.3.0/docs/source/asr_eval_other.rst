Miscellaneous
----------------

.. automodule:: asr_eval
   :members:
   :show-inheritance:

asr_eval.segments
===================

.. automodule:: asr_eval.segments
   :members:
   :show-inheritance:

.. automodule:: asr_eval.segments.chunking
   :members:
   :show-inheritance:

asr_eval.tts
===================

.. automodule:: asr_eval.tts
   :members:
   :show-inheritance:

.. automodule:: asr_eval.tts.yandex_speechkit
   :members:
   :show-inheritance:

asr_eval.utils
===================

.. automodule:: asr_eval.utils
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.storage
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.audio_ops
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.cacheable
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.dataframe
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.deduplicate
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.formatting
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.misc
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.plots
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.serializing
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.server
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.shelves
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.srt_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.table
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.timer
   :members:
   :show-inheritance:

.. automodule:: asr_eval.utils.types
   :members:
   :show-inheritance: