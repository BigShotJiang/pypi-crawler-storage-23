# sudo apt install snapd
# sudo snap install drawio
# sudo apt install xvfb
xvfb-run -a drawio -x -f svg -o framework.svg framework.drawio