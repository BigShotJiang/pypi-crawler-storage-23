asr_eval.streaming
--------------------

.. automodule:: asr_eval.streaming
   :members:
   :show-inheritance:

.. automodule:: asr_eval.streaming.buffer
   :members:
   :show-inheritance:

.. automodule:: asr_eval.streaming.caller
   :members:
   :show-inheritance:

.. automodule:: asr_eval.streaming.evaluation
   :members:
   :show-inheritance:

.. automodule:: asr_eval.streaming.model
   :members:
   :show-inheritance:

.. automodule:: asr_eval.streaming.plots
   :members:
   :show-inheritance:

.. automodule:: asr_eval.streaming.sender
   :members:
   :show-inheritance:

.. automodule:: asr_eval.streaming.wrappers
   :members:
   :show-inheritance: