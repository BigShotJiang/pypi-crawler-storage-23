asr_eval.align
--------------------

.. automodule:: asr_eval.align
   :members:
   :show-inheritance:

.. automodule:: asr_eval.align.alignment
   :members:
   :show-inheritance:

.. automodule:: asr_eval.align.parsing
   :members:
   :show-inheritance:

.. automodule:: asr_eval.align.transcription
   :members:
   :show-inheritance:

.. automodule:: asr_eval.align.matching
   :members:
   :show-inheritance:

.. automodule:: asr_eval.align.char_aligner
   :members:
   :show-inheritance:

.. automodule:: asr_eval.align.metrics
   :members:
   :show-inheritance:

.. automodule:: asr_eval.align.plots
   :members:
   :show-inheritance:

.. automodule:: asr_eval.align.timings
   :members:
   :show-inheritance:

asr_eval.align.solvers
========================

.. automodule:: asr_eval.align.solvers
   :members:
   :show-inheritance:

.. automodule:: asr_eval.align.solvers.dynprog
   :members:
   :show-inheritance:

.. automodule:: asr_eval.align.solvers.recursive
   :members:
   :show-inheritance: