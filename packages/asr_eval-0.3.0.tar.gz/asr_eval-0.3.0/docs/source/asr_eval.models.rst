asr_eval.models
--------------------

.. automodule:: asr_eval.models
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.base.interfaces
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.base.longform
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.base.openai_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.ast_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.flamingo_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.gemma_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.gigaam_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.legacy_pisets_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.nemo_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.pyannote_diarization
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.pyannote_vad
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.qwen2_audio_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.qwen_audio_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.salute_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.speechbrain_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.t_one_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.vikhr_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.vosk54_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.vosk_streaming_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.voxtral_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.wav2vec2_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.whisper_faster_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.whisper_wrapper
   :members:
   :show-inheritance:

.. automodule:: asr_eval.models.yandex_speechkit_wrapper
   :members:
   :show-inheritance: