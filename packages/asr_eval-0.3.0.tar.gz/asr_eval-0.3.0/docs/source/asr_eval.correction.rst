asr_eval.correction
--------------------

.. automodule:: asr_eval.correction
   :members:
   :show-inheritance:

.. automodule:: asr_eval.correction.interfaces
   :members:
   :show-inheritance:

.. automodule:: asr_eval.correction.bow_corpus
   :members:
   :show-inheritance:

.. automodule:: asr_eval.correction.comparator_wordfreq
   :members:
   :show-inheritance:

.. automodule:: asr_eval.correction.corrector_langchain
   :members:
   :show-inheritance:

.. automodule:: asr_eval.correction.corrector_levenshtein
   :members:
   :show-inheritance:

.. automodule:: asr_eval.correction.corrector_wikirag
   :members:
   :show-inheritance: