asr_eval.bench
--------------------

.. automodule:: asr_eval.bench
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.check
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.run
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.evaluator
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.loader
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.dashboard.run
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.augmentors
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.parsers
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.datasets
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.pipelines
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.streaming.make_plots
   :members:
   :show-inheritance:

.. automodule:: asr_eval.bench.streaming.show_plots
   :members:
   :show-inheritance: