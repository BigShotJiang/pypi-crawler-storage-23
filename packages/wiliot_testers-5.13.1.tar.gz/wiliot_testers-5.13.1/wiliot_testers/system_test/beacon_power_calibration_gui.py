import json
from pathlib import Path
from wiliot_testers.system_test.beacon_power_calibration import BeaconCalibration
from wiliot_tools.utils.wiliot_gui.wiliot_gui import WiliotGui, popup_message


def run_gui():
        json_params_path = Path(__file__).parent / 'beacon_power_calibration_params.json'

        def load_params_from_json(json_params_path):
            if json_params_path.is_file():
                try:
                    with open(json_params_path, 'r') as json_file:
                        return json.load(json_file)
                except json.JSONDecodeError:
                    print("Error decoding JSON from file")
            return {}

        used_values = load_params_from_json(json_params_path)

        # Backward compatibility: migrate old 'lora_value' to lora_sweep_start/end
        if 'lora_value' in used_values and 'lora_sweep_start' not in used_values:
            used_values['lora_sweep_start'] = used_values['lora_value']
            used_values['lora_sweep_end'] = used_values['lora_value']
        # Migrate old lora_static_value
        if 'lora_static_value' in used_values and 'lora_sweep_start' not in used_values:
            used_values['lora_sweep_start'] = used_values['lora_static_value']
            used_values['lora_sweep_end'] = used_values['lora_static_value']
        # Migrate old ble_static_value
        if 'ble_static_value' in used_values and 'ble_sweep_start' not in used_values:
            used_values['ble_sweep_start'] = used_values['ble_static_value']
            used_values['ble_sweep_end'] = used_values['ble_static_value']

        params_dict = {
            'sweep_mode': {
                'text': 'Sweep Mode (helper)',
                'value': used_values.get('sweep_mode', 'sweep_ble'),
                'widget_type': 'combobox',
                'options': ['sweep_ble', 'sweep_lora'],
                'group': 'Sweep Configuration'
            },
            'time_profile_on': {
                'text': 'On',
                'value': used_values.get('time_profile_on', '5'),
                'widget_type': 'entry',
                'group': 'Time profile'
            },
            'time_profile_period': {
                'text': 'Period',
                'value': used_values.get('time_profile_period', '15'),
                'widget_type': 'entry',
                'group': 'Time profile'
            },
            'lora_sweep_row': [
                {'lora_sweep_start': {
                    'text': 'LoRa Attenuation',
                    'value': used_values.get('lora_sweep_start', '20'),
                    'widget_type': 'spinbox',
                    'options': list(range(0, 31)),
                    'group': 'Sweep Configuration'
                }},
                {'lora_sweep_end': {
                    'text': 'to',
                    'value': used_values.get('lora_sweep_end', '20'),
                    'widget_type': 'spinbox',
                    'options': list(range(0, 31)),
                    'group': 'Sweep Configuration'
                }}
            ],
            'iter_length': {
                'text': 'Iteration length (in seconds)',
                'value': used_values.get('iter_length', '90'),
                'widget_type': 'entry',
                'options': {'font': ('Helvetica', 10, 'bold')},
            },
            'energy_pattern_value': {
                'text': 'Energy pattern',
                'value': used_values.get('energy_pattern_value', '50'),
                'widget_type': 'entry',
                'options': {'font': ('Helvetica', 10, 'bold')},
            },
            'ble_sweep_row': [
                {'ble_sweep_start': {
                    'text': 'BLE Attenuation',
                    'value': used_values.get('ble_sweep_start', '0'),
                    'widget_type': 'spinbox',
                    'options': list(range(0, 31)),
                    'group': 'Sweep Configuration'
                }},
                {'ble_sweep_end': {
                    'text': 'to',
                    'value': used_values.get('ble_sweep_end', '30'),
                    'widget_type': 'spinbox',
                    'options': list(range(0, 31)),
                    'group': 'Sweep Configuration'
                }}
            ],

            'lora_attn_com': {
                'text': 'LoRa COM Port',
                'value': used_values.get('lora_attn_com', 'COM3'),
                'widget_type': 'entry',
                'options': {'font': ('Helvetica', 10, 'bold')},
                'group': 'COM Port Configuration'
            },
            'ble_attn_com': {
                'text': 'BLE COM Port',
                'value': used_values.get('ble_attn_com', 'COM6'),
                'widget_type': 'entry',
                'options': {'font': ('Helvetica', 10, 'bold')},
                'group': 'COM Port Configuration'
            },
        }

        beacon_power_calib_gui = WiliotGui(params_dict=params_dict, title='Beacon Power Calibration')
        values = beacon_power_calib_gui.run()
        print(values)
        try:
            form_values = {
                'sweep_mode': values['sweep_mode'],
                'iter_duration': int(values['iter_length']),
                'lora_sweep_start': int(values['lora_sweep_row_lora_sweep_start']),
                'lora_sweep_end': int(values['lora_sweep_row_lora_sweep_end']),
                'ble_sweep_start': int(values['ble_sweep_row_ble_sweep_start']),
                'ble_sweep_end': int(values['ble_sweep_row_ble_sweep_end']),
                'energy_pattern_value': int(values['energy_pattern_value']),
                'time_profile_on': int(values['time_profile_on']),
                'time_profile_period': int(values['time_profile_period']),
                'lora_attn_com': values['lora_attn_com'],
                'ble_attn_com': values['ble_attn_com'],
            }

            # Apply configuration and persist
            with open(json_params_path, 'w') as json_file:
                json.dump(form_values, json_file, indent=4)
            return form_values

        except ValueError:
            popup_message('Value must be an integer.')

if __name__ == "__main__":
    params_dict = run_gui()
    inst = BeaconCalibration(**params_dict)
