"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""

import json
from pathlib import Path
import time
from datetime import datetime
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from wiliot_core import WiliotGateway, set_logger, PacketList, DataType, ActionType
from wiliot_tools.utils.wiliot_gui.wiliot_gui import WiliotGui, popup_message
from wiliot_tools.test_equipment.test_equipment import EquipmentError, Attenuator
from wiliot_testers.wiliot_tester_log import WiliotTesterLog
from wiliot_core.local_gateway.utils.gw_commands import CommandDetails
from wiliot_core.utils.utils import WiliotDir

STABILIZATION_RANGE_MODIFIER = 1 # Max differance between points that fit the criteria
MIN_CONSECUTIVE_POINTS_MODIFIER = 5 # How many points in a row should be in order to recommend a value
OPTIMAL_ATTENUATION_MODIFIER = 2 # By how much attenuation to increase after finding stabilisation point

now = datetime.now()
run_start_time = now.strftime("%m-%d-%Y_%H-%M-%S")

class BeaconCalibration:

    def __init__(self, sweep_mode='sweep_ble', iter_duration=90,
                 lora_sweep_start=20, lora_sweep_end=20,
                 ble_sweep_start=0, ble_sweep_end=30,
                 energy_pattern_value=50, time_profile_on=5,
                 time_profile_period=15, lora_attn_com='', ble_attn_com='',
                 non_interactive_plots=False):
        # Set matplotlib backend for non-interactive mode (e.g., when running from dashboard)
        if non_interactive_plots:
            matplotlib.use('Agg')  # Non-interactive backend - no GUI window, thread-safe
        
        # Initialises logger and GUI
        self.init_name_path()
        self.non_interactive_plots = non_interactive_plots
        # Takes the values from the params_dict on main if provided
        self.sweep_mode = sweep_mode
        self.iter_duration = iter_duration
        self.lora_sweep_start = lora_sweep_start
        self.lora_sweep_end = lora_sweep_end
        self.ble_sweep_start = ble_sweep_start
        self.ble_sweep_end = ble_sweep_end
        self.energy_pattern_val = energy_pattern_value
        self.time_profile_on_val = time_profile_on
        self.time_profile_period_val = time_profile_period
        self.lora_attn_com = lora_attn_com
        self.ble_attn_com = ble_attn_com

        self.gw_logger = WiliotTesterLog(run_name="beacon_calibration_testing")
        self.gw_logger.set_logger(self.gw_log_path, tester_name="Wiliot tester")

        # Initialises the hardware
        self.gw_obj = None
        self.attn_obj_lora = None
        self.attn_obj_ble = None
        self.recommended_stabilization = None
        self.init_hw()
        self.all_results = pd.DataFrame({'Adva': [], 'Frequency': [], 'TBP': [], 'Atten': []})
        self.gw_config()
        self.run_sweep()
        self.process_result()
        self.optimal_value_calculation()
        self.analysis_plot()


    def init_name_path(self):
        wiliot_dir = WiliotDir()
        app_root = Path(wiliot_dir.get_wiliot_root_app_dir())

        runs_root = app_root / 'Beacon_calibration_runs'
        runs_root.mkdir(parents=True, exist_ok=True)

        self.results_path = runs_root / f'Beacon_calibration_run_{run_start_time}'
        self.results_path.mkdir(parents=True, exist_ok=True)

        self.gw_log_path = app_root / 'Beacon_calibration_logs'
        self.gw_log_path.mkdir(parents=True, exist_ok=True)

        logger_path, self.logger = set_logger(app_name='BeaconCalibration', dir_name=self.gw_log_path,
                                              file_name='Beacon_calibration_test_log')

    def init_hw(self):

        self.gw_obj = WiliotGateway(auto_connect=True, logger_name=self.gw_logger.gw_logger.name, verbose=False)
        try:
            if self.gw_obj.is_connected():
                self.gw_obj.reset_gw()
                if not self.gw_obj.is_gw_alive():
                    raise EquipmentError('Gateway Error - Verify WiliotGateway connection')

                self.gw_logger.gw_logger.info('GW connected successfully')
            else:
                raise EquipmentError('Gateway Error - Verify WiliotGateway connection')
        except Exception as e:
            self.gw_logger.gw_logger.warning(e)
            self.gw_obj.close_port()
            raise EquipmentError('Gateway Error - Verify WiliotGateway connection')

        # Initializes both attenuators
        self.attn_obj_lora = Attenuator(ATTN_type='API', comport=self.lora_attn_com).GetActiveTE()
        self.attn_obj_ble = Attenuator(ATTN_type='API', comport=self.ble_attn_com).GetActiveTE()

        # Determine which radio to sweep (will be validated in run_sweep)
        lora_sweeping = (self.lora_sweep_start != self.lora_sweep_end)
        ble_sweeping = (self.ble_sweep_start != self.ble_sweep_end)

        # Set static attenuator (the one NOT being swept)
        if ble_sweeping and not lora_sweeping:
            self._set_static_attn(self.attn_obj_lora, self.lora_sweep_start, 'LoRa')
        elif lora_sweeping and not ble_sweeping:
            self._set_static_attn(self.attn_obj_ble, self.ble_sweep_start, 'BLE')

    def gw_config(self):
        cmds = {
            CommandDetails.time_profile: [self.time_profile_period_val, self.time_profile_on_val],
            CommandDetails.set_energizing_pattern: [self.energy_pattern_val],
        }
        self.gw_obj.set_configuration(cmds=cmds, start_gw_app=False)

    def _set_static_attn(self, attn_obj, attn_value, radio_name):
        actual = attn_obj.Setattn(attn=attn_value)
        if actual != attn_value:
            raise Exception(f'Error setting {radio_name} static attenuation: target={attn_value}, actual={actual}')
        self.logger.info(f'{radio_name} attenuator set to static value: {attn_value}')

    def run_sweep(self):
        # Auto-detect sweep mode based on ranges
        lora_sweeping = (self.lora_sweep_start != self.lora_sweep_end)
        ble_sweeping = (self.ble_sweep_start != self.ble_sweep_end)

        # Validate sweep configuration
        if lora_sweeping and ble_sweeping:
            raise ValueError(
                f"Cannot sweep both LoRa and BLE simultaneously. "
                f"LoRa range: {self.lora_sweep_start}-{self.lora_sweep_end}, "
                f"BLE range: {self.ble_sweep_start}-{self.ble_sweep_end}. "
                f"Set one range to a static value (start == end)."
            )
        if not lora_sweeping and not ble_sweeping:
            raise ValueError(
                f"Must sweep at least one radio. "
                f"Both LoRa ({self.lora_sweep_start}-{self.lora_sweep_end}) and "
                f"BLE ({self.ble_sweep_start}-{self.ble_sweep_end}) are static. "
                f"Ensure start != end for either LoRa or BLE."
            )

        # Determine sweep parameters
        sweep_obj, sweep_start, sweep_end, sweep_label, static_attn = (
            (self.attn_obj_ble, self.ble_sweep_start, self.ble_sweep_end, 'BLE', self.lora_sweep_start)
            if ble_sweeping
            else (self.attn_obj_lora, self.lora_sweep_start, self.lora_sweep_end, 'LoRa', self.ble_sweep_start)
        )
        self.logger.info(f'Sweep mode: {sweep_label} (range {sweep_start}-{sweep_end}), static radio at {static_attn}')

        sweep_attns = range(int(sweep_start), int(sweep_end), 1)
        self.attenuation_list = []
        self.all_results = PacketList()

        for attn in sweep_attns:
            # set atten
            self.attn_val = int(sweep_obj.Setattn(attn=attn))
            self.attenuation_list.append(attn)
            self.logger.info(f'{sweep_label} attenuation: new: {attn}, actual: {self.attn_val}')

            self.gw_obj.reset_listener()
            self.gw_obj.set_configuration(start_gw_app=True)
            self.daq()
            is_stopped = self.gw_obj.stop_gw_app()
            if not is_stopped:
                raise Exception('could not send stop to GW')

    def daq(self):
        start_time = time.time()  # Records starting time
        max_duration = self.iter_duration
        while True:
            if self.gw_obj.is_data_available():
                cur_packet_list = self.gw_obj.get_packets(action_type=ActionType.ALL_SAMPLE,
                                                          data_type=DataType.PACKET_LIST)

                if len(cur_packet_list) > 0:
                    for p in cur_packet_list:
                        p.add_custom_data({'attenuation': self.attn_val})
                        self.logger.info('got packet {}'.format(p.packet_data['raw_packet']))
                        self.all_results.append(p)
            else:
                time.sleep(0.1)

            if time.time() - start_time > max_duration:
                break
        self.logger.info('Iteration ended!')

    def process_result(self):
        self.tbp_df = pd.DataFrame()  # creates an empty dataframe
        df = self.all_results.get_df(add_sprinkler_info=True)  # makes a dataframe from the data so far
        df_packet = df.drop_duplicates(subset=['raw_packet'])  # drops duplicates of packets
        df_packet = df_packet[df_packet['tbp'] > 0]
        self.group_tbp = df_packet.groupby(by=['attenuation', 'adv_address']).agg(
            tbp_mean=('tbp', lambda x: np.ceil(np.mean(x)) if len(x) > 0 else None),
            tbp_min=('tbp', lambda x: np.ceil(np.min(x)) if len(x) > 0 else None),
            tbp_median=('tbp', lambda x: np.ceil(np.median(x)) if len(x) > 0 else None)
        ).reset_index()
        self.group_tbp = self.group_tbp.sort_values(by=['adv_address', 'attenuation'])
        self.group_tbp['difference'] = self.group_tbp.groupby('adv_address')['tbp_mean'].diff().fillna(0)
        # Various calculations on the TBP packets
        self.group_tbp.to_csv(self.results_path / f"tbp_calculated_{run_start_time}.csv")
        # Saves packets with TBP only
        df_packet.to_csv(self.results_path / f"filtered_tbp_packets_{run_start_time}.csv")
        # Saves all the results
        df.to_csv(self.results_path / f"full_Test_results_{run_start_time}.csv")

    def analysis_plot(self, show_plot=False):
        # Expected behavior: starting at lowest attenuation (highest Tx power), TBP should rise as attenuation
        # decreases until it plateaus when BLE alone cannot charge and only Sub-1G harvesting contributes.
        self.optimal_value_calculation()
        
        # Create figure and plot
        fig, ax = plt.subplots(figsize=(10, 6))
        for adva in self.group_tbp['adv_address'].unique():
            group_data = self.group_tbp[self.group_tbp['adv_address'] == adva]
            y1 = group_data['tbp_mean']
            # Unused for now but kept for future debugging:
            # y2 = group_data['tbp_min']
            # y3 = group_data['tbp_median']
            ax.plot(group_data['attenuation'], y1, marker='o', label="tbp_mean")

            # Used for debugging and comparing results
            # ax.plot(group_data['attenuation'], y2, marker='o', label="tbp_min")
            # ax.plot(group_data['attenuation'], y3, marker='o', label="tbp_median")
        
        ax.set_xlabel("Attenuation")
        ax.set_ylabel('TBP')
        if self.recommended_stabilization:
            ax.set_title(f"Recommended attenuation: {int(self.recommended_stabilization)} sweep: {getattr(self, 'sweep_mode', None)}")
        else:
            ax.set_title("No recommended attenuation based on criteria")
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # Save the figure
        plot_path = self.results_path / f"beacon_calibration_plot_{run_start_time}.png"
        fig.savefig(plot_path, dpi=150, bbox_inches='tight')
        self.logger.info(f"Plot saved to: {plot_path}")
        
        # Show plot only in interactive mode and if requested
        if show_plot and not self.non_interactive_plots:
            plt.show()
        else:
            plt.close(fig)  # Clean up to avoid memory leaks

    def optimal_value_calculation(self):
        self.group_tbp['incremental_difference'] = self.group_tbp['tbp_mean'].diff()

        stabilization_range = STABILIZATION_RANGE_MODIFIER
        min_consecutive_points = MIN_CONSECUTIVE_POINTS_MODIFIER

        streak_count = 0  # Tracks the longest streak of values within the stabilization range
        stabilization_start_index = None
        try:
            for index, row in self.group_tbp.iterrows():
                if abs(row['incremental_difference']) <= stabilization_range:
                    streak_count += 1
                    if streak_count == min_consecutive_points:
                        stabilization_start_index = index - min_consecutive_points + 1
                        stabilization_start_value = self.group_tbp.loc[stabilization_start_index, 'attenuation']
                        break
                else:
                    streak_count = 0  # Resets said counter if conditions are not met

        except KeyError:
            pass

        if stabilization_start_index is not None:
            self.logger.critical(
                f"Stabilization starts at Attenuation: {stabilization_start_index}, tbp_mean: {int(self.group_tbp.loc[stabilization_start_index, 'tbp_mean'])}")
            self.recommended_stabilization = stabilization_start_value + OPTIMAL_ATTENUATION_MODIFIER
            self.logger.info(f"Recommended Attenuation: {int(self.recommended_stabilization)}")
        else:
            self.logger.info("No stabilization detected based on the criteria")
        # decide key based on sweep mode
        key_name = ('beacons_calibration_2_4' if getattr(self, 'sweep_mode',
                                                         None) == 'sweep_ble' else 'beacons_calibration_lora')
        if self.recommended_stabilization is not None:
            # save to JSON (merge with existing file if present)
            params_path = self.results_path / "setup_calibration_params.json"
            value = int(self.recommended_stabilization)
            with open(params_path, 'w') as f:
                json.dump({key_name: value}, f, indent=4)


if __name__ == '__main__':
    json_params_path = Path(__file__).parent / 'beacon_power_calibration_params.json'
    with open(json_params_path, 'r') as json_file:
        params_dict = json.load(json_file)

    inst = BeaconCalibration(**params_dict)
