"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
from wiliot_testers.post_process.utils.post_process_tools import *
from wiliot_core import IS_PRIVATE_INSTALLATION
from wiliot_testers.post_process.utils.process_table_schema_partners import table_config
from wiliot_testers.post_process.utils.column_name_map import column_name_map
from wiliot_testers.utils.get_version import get_version
from abc import ABC, abstractmethod

if IS_PRIVATE_INSTALLATION:
    from wiliot_testers.post_process.utils.extended.process_table_schema_main import table_config as extended_table_config
    table_config.update(extended_table_config)
    from wiliot_core import DecryptedTagCollection as TagCollection
else:
    from wiliot_core import TagCollection

class PostProcess(ABC):
    def __init__(self, run_data=None, packet_data=None, decoded_packet_list=None,
                 process_type=None, manufacturing_ver=None, tester_run_id=None, wafer_sort_data=None):

        if process_type not in ["sample_test", "offline_test", "yield_test", "association_and_verification_test", "conversion_yield_test"]:
            raise Exception('the selected process type ({}) is not supported! '
                            'please select one of the following '
                            '["sample_test", "offline_test", "yield_test", "association_and_verification_test", "conversion_yield_test"]'.format(process_type))

        self.wafer_sort_data = convert_to_pandas_df(wafer_sort_data)
        self.run_data = run_data
        self.packet_data = packet_data
        self.decoded_packet_list = decoded_packet_list
        self.process_type = process_type
        self.manufacturing_ver = manufacturing_ver
        self.tester_run_id = tester_run_id

        self.decoded_multi_tag = None
        self.serialization_list = None
        self.force_serialization = False
        self.change_status_list = None
        self.sensors_scylla_df = None
        self.common_run_name = None
        self.printing_run = None
        self.processed_dict = None
        self.partner_results = None
        self.packet_df = None

        self.results = {}

    @calculate_run_time
    def process_decoded_data(self):
        if self.decoded_packet_list is None or len(self.decoded_packet_list) == 0:
            return
        # add custom data and generate the multi tag class
        self.decoded_multi_tag = TagCollection()
        inlay = extract_unique_data(self.run_data, 'inlay_type')
        for ind, decoded_packet in enumerate(self.decoded_packet_list):
            if 'tag_id' in decoded_packet.decoded_data.keys():
                decoded_packet.decoded_data['tag_id'] = decoded_packet.decoded_data['tag_id'].lower()
            else:
                # corrupted packet
                self.decoded_packet_list.pop(ind)
                continue
            decoded_packet.set_inlay_type(inlay)
            self.check_external_id(decoded_packet)
            for k in decoded_packet.custom_data.keys():
                decoded_packet.custom_data[k] = string_to_number(decoded_packet.custom_data[k], k)
            encrypted_payload_list = get_payload(decoded_packet.custom_data['original_encrypted_packet'])
            decoded_packet.add_custom_data({'encrypted_payload': encrypted_payload_list})

            self.decoded_multi_tag.append(decoded_packet)

        # init main variables
        self.packet_df = self.decoded_packet_list.get_df(add_sprinkler_info=True, is_overwrite=True)
        self.packet_df['tag_id'] = self.packet_df['tag_id'].str.lower()
        self.common_run_name = extract_unique_data(self.packet_df, 'common_run_name')

    # subclasses can override this method
    def check_external_id(self, decoded_packet):
        pass

    def add_common_fields(self):
        self.packet_df.insert(loc=len(self.packet_df.columns), column='tester_run_id', value=self.tester_run_id)
        decrypted_packet = []
        for p in self.packet_df['decrypted_packet']:
            if pd.isnull(p) or p == '':
                decrypted_packet.append('')
            else:
                decrypted_packet.append(
                    self.decoded_packet_list[0].get_packet_content(raw_packet=p, get_gw_data=True))
        self.packet_df['group_id'] = get_group_id_reversed(self.packet_df['group_id'].values)
        self.packet_df['flow_ver'] = get_converted_flow_version(self.packet_df['flow_ver'].values)
        self.packet_df.drop('decrypted_packet', axis=1, inplace=True)
        self.packet_df.insert(loc=len(self.packet_df.columns), column='decrypted_packet', value=decrypted_packet)
        if 'time_from_start' in self.packet_df.keys():
            self.packet_df.insert(loc=len(self.packet_df.columns), column='packet_time',
                                  value=self.packet_df['time_from_start'])

    def prepare_and_merge_wafer_sort_data(self):
        if self.wafer_sort_data is not None:
            self.wafer_sort_data.columns = ['wafer_sort_'+col.lower() for col in self.wafer_sort_data.columns]
            self.wafer_sort_data['wafer_sort_status'] = self.wafer_sort_data['wafer_sort_soft_bin'].apply(lambda x: 1 if x == 1 else 0)
            validate_wafer_sort_data(self.wafer_sort_data, wafer_sort_fields)
            self.packet_df = pd.merge(self.packet_df, self.wafer_sort_data,
                                      left_on='tag_id', right_on='wafer_sort_tag_id', how='left')
            self.wafer_sort_data = self.wafer_sort_data.set_index('wafer_sort_tag_id')

    @calculate_run_time
    def create_packet_data_tables(self):
        if self.decoded_packet_list is None or self.decoded_multi_tag is None:
            print_pp('packet data and/or decoded data are empty')
            return
        self.create_packet_data_process()

    @abstractmethod
    def create_packet_data_process(self):
        pass

    def is_printing_run(self):
        try:
            printing_run = str(self.run_data['to_print'][0]).lower() == 'yes' \
                           or str(self.run_data['to_print'][0]).lower() == 'true'
        except Exception:
            printing_run = False

        return printing_run

    @calculate_run_time
    def create_group_data_tables(self):
        self.printing_run = self.is_printing_run()
        if self.decoded_packet_list is None:
            print_pp('decoded_packet_list is empty')

        self.create_group_data_process()

    @abstractmethod
    def create_group_data_process(self):
        pass

    def import_run_data(self):
        run_table = {}
        for k, v in self.run_data.items():
            if isinstance(v, list) and len(v) == 1:
                run_table[k] = [str(v[0])]
            else:
                run_table[k] = [str(v)]
        # add run_id and cloud ver:
        if self.manufacturing_ver:
            run_table['manufacturing_version'] = [str(self.manufacturing_ver)]
        if self.tester_run_id:
            run_table['tester_run_id'] = [int(self.tester_run_id)]
        run_table['post_process_version'] = [get_version()]
        run_table['upload_date'] = [datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')]

        return run_table

    def update_reel_run_end_time(self, run_table):
        if 'reel_run_end_time' not in run_table.keys() or run_table['reel_run_end_time'][0]\
                or 'test_start_time' not in self.packet_data or 'test_end_time' not in self.packet_data \
                or 'trigger_time' not in self.packet_data or len(self.packet_data['trigger_time']) == 0:
            return
        optional_end_time = [self.packet_data['test_end_time'][-1], self.packet_data['test_start_time'][-1],
                             self.packet_data['trigger_time'][-1]]
        for t in optional_end_time:
            if t:
                run_table['reel_run_end_time'] = [t]
                return

    @calculate_run_time
    def create_run_data_table(self):
        if self.run_data is None or len(self.run_data) == 0:
            return

        self.create_run_data_process()

    @abstractmethod
    def create_run_data_process(self):
        pass

    def extract_partners_table(self):
        if f'{self.process_type}_partner' not in table_config:
            return None
        partner_tables = table_config[self.process_type + '_partner']
        self.partner_results = {k: {} for k in partner_tables.keys()}
        for k, v in partner_tables.items():
            if k in self.results.keys():
                col_ind = {col_name: i for i, col_name in enumerate(self.results[k]['table_scheme'].keys())
                           if col_name in v.keys()}
                self.partner_results[k]['rows'] = []
                for row in self.results[k]['rows']:
                    cur_row = []
                    for col_name in v.keys():
                        cur_row.append(row[col_ind[col_name]])
                    self.partner_results[k]['rows'].append(cur_row)
                self.partner_results[k]['table_scheme'] = partner_tables[k]
            else:
                del self.partner_results[k]
        return self.partner_results

    def generate_testers_database(self):
        if self.decoded_packet_list is None or len(self.decoded_packet_list) == 0 or self.packet_data is None:
            return None, None, None, None, None
        self.process_decoded_data()
        self.create_packet_data_tables()
        self.create_group_data_tables()
        self.create_run_data_table()
        self.extract_partners_table()
        return self.results, self.serialization_list, self.change_status_list, self.partner_results, self.force_serialization, self.sensors_scylla_df
