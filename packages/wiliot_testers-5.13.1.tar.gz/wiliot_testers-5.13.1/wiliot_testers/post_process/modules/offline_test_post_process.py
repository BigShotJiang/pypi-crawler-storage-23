"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
from wiliot_testers.post_process.modules.post_process import *
from wiliot_testers.post_process.utils.mandatory_fields import *
from wiliot_testers.wiliot_tester_tag_result import FailureCodes
from wiliot_core import valid_output_power_vals, IS_PRIVATE_INSTALLATION
if IS_PRIVATE_INSTALLATION:
    from wiliot_core import DecryptedPacketList as PacketList
else:
    from wiliot_core import PacketList

# from wiliot_core import get_expected_power_mode


class OfflineTestPostProcess(PostProcess):
    def __init__(self, run_data=None, packet_data=None, decoded_packet_list=None,
                 process_type=None, manufacturing_ver=None, tester_run_id=None, wafer_sort_data=None,
                 is_test_mode=False):

        super().__init__(run_data, packet_data, decoded_packet_list, process_type, manufacturing_ver, tester_run_id,
                         wafer_sort_data)
        self.crc_dict = {}
        self.run_table = None
        self.packet_df = None
        self.run_test_table = None
        self.test_param = None
        self.table_run_test_name = None
        self.table_run_test_dict = None
        self.table_run_dict = None
        self.table_run_name = None
        self.location_with_duplication = None
        self.table_test_dict = None
        self.table_test_name = None
        self.table_loc_dict = None
        self.table_loc_name = None
        self.tag_location_df = None
        self.tag_location_test_df = None
        self.all_locations = None
        self.tag_data_fields = ['group_id', 'packet_version', 'flow_version']
        self.add_missing_mandatory_fields(data_type='run_data')
        self.add_missing_mandatory_fields(data_type='packet_data')
        self.packet_raw_df = pd.DataFrame(self.packet_data).set_index("tag_run_location")
        self.table_config = table_config
        if is_test_mode:
            self.table_config['offline_test']['tag_test_packets']['n_exit_test_mode'] = 'int'
            self.table_config['offline_test']['tag_test_packets']['timer_reset_counter'] = 'int'
            self.table_config['offline_test']['tag_test_packets']['before_last_est_freq'] = 'int'

    def process_decoded_data(self):
        super().process_decoded_data()
        self.test_param = parse_test_param(self.run_data['test_suite_dict'][0])
        self.add_common_fields()
        self.add_missing_mandatory_fields(data_type='packet_df')
        self.packet_df = add_calculated_data_per_packet(df_to_agg=self.packet_df,
                                                        groups=['tag_run_location', 'test_num', 'tag_id'])

    def add_missing_mandatory_fields(self, data_type):
        if data_type == 'run_data':
            for col, default_value in offline_non_mandatory_fields['run_data'].items():
                if col not in self.run_data:
                    self.run_data[col] = [default_value]
        elif data_type == 'packet_data':
            for col, default_value in offline_non_mandatory_fields['packet_data'].items():
                if col not in self.packet_data:
                    self.packet_data[col] = [default_value] * len(self.packet_data[list(self.packet_data.keys())[0]])
        elif data_type == 'packet_df':
            for col, default_value in offline_non_mandatory_fields['packet_data'].items():
                if col not in self.packet_df:
                    self.packet_df.insert(loc=len(self.packet_df.columns), column=col, value=default_value)

    def add_sensors_data(self):
        if 'rc_sensor_freq_khz' in self.packet_df:
            if 'rc_sensor_cap_or_res_str' not in self.packet_df and 'rc_sensor_ext_or_int_cap_str' not in self.packet_df:
                self.packet_df['rc_sensor_ext_or_int_cap_str'] = 'ExtCap'
            
            k = 'rc_sensor_ext_or_int_cap_str' if 'rc_sensor_ext_or_int_cap_str' in self.packet_df else 'rc_sensor_cap_or_res_str'
            self.packet_df.insert(loc=len(self.packet_df.columns), column='external_cap_sensor_freq', \
                                value=self.packet_df[self.packet_df[k].isin(['ExtCap', 'capacitor'])]['rc_sensor_freq_khz'])
            self.packet_df.insert(loc=len(self.packet_df.columns), column='external_res_sensor_freq', \
                                value=self.packet_df[self.packet_df[k].isin(['ExtRes', 'resistor'])]['rc_sensor_freq_khz'])
            self.packet_df.insert(loc=len(self.packet_df.columns), column='internal_cap_sensor_freq', \
                                value=self.packet_df[self.packet_df[k] == 'IntCap']['rc_sensor_freq_khz'])
            self.packet_df.insert(loc=len(self.packet_df.columns), column='internal_res_sensor_freq', \
                                value=self.packet_df[self.packet_df[k] == 'IntRes']['rc_sensor_freq_khz'])
        self.packet_df.insert(loc=len(self.packet_df.columns), column='invalid_sensor_measurement', \
                                value=self.packet_df.get('rc_sensor_timeout_ind', 0) == 1)
            
    def create_packet_data_process(self):
        table_name = list(self.table_config[self.process_type].keys())[4]
        table_type = self.table_config[self.process_type][table_name]
        self.prepare_and_merge_wafer_sort_data()
        if 'lo_max_freq' in list(self.packet_df.columns):
            self.packet_df['max_tx'] = self.packet_df['lo_max_freq'].apply(lambda x: x if x != 2402 else None)
        self.add_sensors_data()
        dict_in = self.packet_df.to_dict('series')
        packet_result = build_table_for_cloud(dict_in=dict_in, table_type=table_type)

        self.results[table_name] = packet_result

    def check_external_id(self, decoded_packet):
        if isinstance(decoded_packet.custom_data['external_id'], np.ndarray):
            for ind, s in enumerate(decoded_packet.custom_data['status_offline']):
                if s == '' or s is None or int(s) == 0:
                    decoded_packet.custom_data['external_id'][ind] = ''
        else:
            if decoded_packet.custom_data['status_offline'] == '' or \
                    decoded_packet.custom_data['status_offline'] is None or \
                    int(decoded_packet.custom_data['status_offline']) == 0:
                decoded_packet.custom_data['external_id'] = ''

    def initialize_dataframes(self):
        self.tag_location_df = {k: [] for k in self.table_loc_dict.keys()}
        self.tag_location_test_df = {k: [] for k in
                                     set(list(self.table_loc_dict.keys()) + list(self.table_test_dict.keys()))}
        self.processed_dict = {'status_post_process': [], 'tag_id': [], 'external_id': []}

    def copy_loc_data_from_packet_data_file(self, cur_tag_location_df, loc_df):
        for col_name in self.table_loc_dict.keys():
            if col_name in self.tag_data_fields:
                continue
            val = extract_unique_data(dict_in=loc_df, name=col_name)
            if val is not None:
                cur_tag_location_df[col_name] = val

    def copy_test_data_from_packet_data_file(self, cur_tag_location_df, test_stat, test_df_selected):
        for col_name in self.table_test_dict.keys():
            if col_name not in self.table_loc_dict.keys():
                val = extract_unique_data(dict_in=test_stat, name=col_name)
                if val is None:
                    val = extract_unique_data(dict_in=test_df_selected, name=col_name)
                if val is None and col_name in offline_mandatory_fields_per_location:
                    raise Exception(f'pp: copy_test_data_from_packet_data_file: on location: {cur_tag_location_df.get("tag_run_location")} missing mandatory field {col_name} or mandatory field does not contain unique data per location')
                cur_tag_location_df[col_name] = val

    def add_sensors_info_for_scylla(self, cur_tag_location_df, loc_df):
        cur_tag_location_df['tag_sensor_type'] = self.run_data.get('tag_sensor_type', ['Default'])[0].upper()
        if 'external_cap_sensor_freq' in loc_df.columns:
            valid_sens_data = loc_df['external_cap_sensor_freq'][loc_df['invalid_sensor_measurement'] == False]
            cur_tag_location_df['sensor_tag_measurement'] = valid_sens_data.iloc[-1] if valid_sens_data.size > 0 else float('nan')
        else:
            cur_tag_location_df['sensor_tag_measurement'] = float('nan')

        name_data_map = {
                          'temperature_tag_measurement': 'temperature',
                          'humidity_external_measurement': 'humidity_sensor',
                          'temperature_external_measurement': 'temperature_sensor',
                          'light_external_measurement': 'light_intensity_sensor'}
        for k, v in name_data_map.items():
            if v in loc_df.columns:
                last_valid_index = loc_df[v].last_valid_index()
                if last_valid_index is not None:
                    cur_tag_location_df[k] = loc_df[v].loc[last_valid_index]
                else:
                    cur_tag_location_df[k] = float('nan')
            else:
                cur_tag_location_df[k] = float('nan')

    def calculate_post_process_status(self, cur_tag_location_df, loc_df, loc):
        try:
            cur_tag_location_df['status_post_process'] = cur_tag_location_df['status_offline']
            # extract tag id list of the selected tag:
            all_tag_id_per_loc = loc_df['tag_id'][loc_df['packet_status'] == 'good']
            # check alternating adva:
            if cur_tag_location_df['fail_bin'] == FailureCodes.SEVERAL_TAGS_UNDER_TEST.value:
                good_tag_id = all_tag_id_per_loc.dropna().unique()
                good_tag_id = good_tag_id[good_tag_id != '']
                if len(good_tag_id) == 1:
                    cur_tag_location_df['fail_bin'] = FailureCodes.ALTERING_ADVA_POST_PROCESS.value

            tag_id_selected = all_tag_id_per_loc[loc_df['selected_tag'] == loc_df['adv_address']]
            unique_tag_id = tag_id_selected.dropna().unique()
            unique_tag_id = unique_tag_id[unique_tag_id != '']

            self.add_wafer_sort_data(unique_tag_id, cur_tag_location_df)

            # add data of the selected tag:
            if len(unique_tag_id) == 1:  # only one tag selected
                cur_tag_id = unique_tag_id[0]
                cur_tag_location_df['tag_id'] = cur_tag_id
                for data_name in self.tag_data_fields:
                    cur_tag_location_df[data_name] = \
                        extract_unique_data(dict_in=loc_df[loc_df['tag_id'] == cur_tag_id], name=data_name)
            else:
                cur_tag_location_df['tag_id'] = ''

            if cur_tag_location_df['status_offline'] == 1:
                tag_is_passed = cur_tag_location_df['fail_bin'] == FailureCodes.PASS.value
                if loc in self.location_with_duplication.keys():
                    cur_tag_location_df['status_post_process'] = 0
                    if tag_is_passed:
                        cur_tag_location_df['fail_bin'] = FailureCodes.DUPLICATION_POST_PROCESS.value if self.location_with_duplication[loc] == 'tag_id' else FailureCodes.DUPLICATION_EXTERNAL_ID.value
                    else:
                        raise Exception('pp: create_group_data_table:at loc {} offline status is pass '
                                        'while the failure code is not PASS'.format(loc))
                elif len(unique_tag_id) == 1:
                    if cur_tag_location_df['tag_id'].startswith('000d0') and tag_is_passed:
                        cur_tag_location_df['fail_bin'] = FailureCodes.CORRUPTED_PACKET_POST_PROCESS.value
                    elif self.printing_run and cur_tag_location_df['external_id'] == '' and tag_is_passed:
                        cur_tag_location_df['fail_bin'] = FailureCodes.INVALID_EXTERNAL_ID_POST_PROCESS.value
                    elif self.wafer_sort_data is not None and tag_is_passed:
                        if cur_tag_location_df['wafer_sort_soft_bin'] is not None and cur_tag_location_df['wafer_sort_soft_bin'] != 1:
                            cur_tag_location_df['fail_bin'] = FailureCodes.WAFER_SORT_FAIL_POST_PROCESS.value
                        elif cur_tag_location_df['wafer_sort_flow_version'] is not None and str(cur_tag_location_df['flow_version']) != str(cur_tag_location_df['wafer_sort_flow_version']):
                            cur_tag_location_df['fail_bin'] = FailureCodes.CORRUPTED_PACKET_POST_PROCESS.value
                    # elif self.check_power_mode(loc_df) and tag_is_passed:
                    #     cur_tag_location_df['fail_bin'] = FailureCodes.WRONG_POWER_MODE_POST_PROCESS.value

                else:
                    if tag_is_passed:
                        cur_tag_location_df['fail_bin'] = FailureCodes.DIFF_TAG_ID_WITH_SAME_ADVA_POST_PROCESS.value
                    else:
                        raise Exception('pp: create_group_data_table:at loc {} offline status is pass '
                                        'while the failure code is not PASS and tag id is'
                                        'different for the same selected tag '
                                        '(by adv_address): {}'.format(loc, unique_tag_id))

            cur_tag_location_df['num_responding_tags'] = len(unique_tag_id)
            cur_tag_location_df['fail_bin_str'] = FailureCodes(cur_tag_location_df['fail_bin']).name
            cur_tag_location_df['status_post_process'] = \
                FailureCodes(cur_tag_location_df['fail_bin']).value == FailureCodes.PASS.value
            cur_tag_location_df['last_executed_test'] = np.nanmax(self.packet_raw_df.loc[[str(loc)]]['test_num'])
            cur_tag_location_df['crc_environment'] = self.crc_dict.get(loc)
        except Exception as e:
            print_pp(f'pp: calculate_post_process_status: error calculating post process status at location {loc}: {e}')
            raise e

    def calculate_location_duration(self, cur_tag_location_df, loc):
        loc_start_time = extract_unique_data(self.packet_df.loc[self.packet_df['tag_run_location'] == loc],
                                             'trigger_time')
        loc_end_time = extract_unique_data(self.packet_df.loc[self.packet_df['tag_run_location'] == loc + 1],
                                           'trigger_time')
        try:
            if loc_start_time is None:
                loc_start_time = self.packet_data['trigger_time'][
                    self.packet_data['tag_run_location'].index(str(loc))]
            if loc_end_time is None:
                loc_end_time = self.packet_data['trigger_time'][
                    self.packet_data['tag_run_location'].index(str(loc + 1))]
        except Exception as e:
            loc_start_time, loc_end_time = [None, None]
        cur_tag_location_df['total_location_duration'] = time_diff_between_two_strings(loc_end_time,
                                                                                       loc_start_time)
        # cur_tag_location_df['group_id'] = get_group_id_reversed([cur_tag_location_df['group_id']])[0]

    def update_process_dict(self, cur_tag_location_df):
        self.processed_dict['status_post_process'].append(cur_tag_location_df['status_post_process'])
        self.processed_dict['tag_id'].append(cur_tag_location_df['tag_id'])
        self.processed_dict['external_id'].append(cur_tag_location_df['external_id'])

    def add_sensors_data_per_loc_test(self, packet_df, dict_in):
        for cap_t in ('external', 'internal'):
            if f'{cap_t}_cap_sensor_freq' in packet_df.keys():
                dict_in[f'{cap_t}_cap_sensor_freq_avg'] = packet_df[f'{cap_t}_cap_sensor_freq'].mean()
                dict_in[f'{cap_t}_cap_sensor_freq_min'] = packet_df[f'{cap_t}_cap_sensor_freq'].min()
                dict_in[f'{cap_t}_cap_sensor_freq_max'] = packet_df[f'{cap_t}_cap_sensor_freq'].max()
        return dict_in

    def build_table_per_test(self, loc_df, cur_tag_location_df):
        tests_df = loc_df.groupby('test_num')
        for test, test_df in tests_df:
            test_df_clean = test_df[test_df['packet_status'] == 'good']
            test_df_selected = test_df_clean[test_df_clean['selected_tag'] == test_df_clean['adv_address']]
            unique_tag_id = test_df_clean['tag_id'].unique()
            if test_df_selected.empty and len(unique_tag_id) == 1:
                test_df_selected = test_df_clean[test_df_clean['tag_id'] == unique_tag_id[0]]
            elif test_df_selected['tag_id'].nunique() > 1:
                test_df_selected = pd.DataFrame()
            test_stat = self.decoded_packet_list.get_df_statistics(packet_df=test_df_selected)
            test_stat = self.add_sensors_data_per_loc_test(packet_df=test_df_selected, dict_in=test_stat)
            self.copy_test_data_from_packet_data_file(cur_tag_location_df, test_stat, test_df_selected)
            cur_tag_location_df['test_num'] = extract_unique_data(dict_in=test_df, name='test_num')
            cur_tag_location_df['test_status_offline'] = extract_unique_data(dict_in=test_df,
                                                                             name='test_status_offline')
            cur_tag_location_df['test_name'] = self.test_param['name'][int(test) % len(self.test_param['name'])]
            test_end_time = extract_unique_data(dict_in=test_df, name='test_end_time')
            test_start_time = extract_unique_data(dict_in=test_df, name='test_start_time')
            cur_tag_location_df['test_duration'] = time_diff_between_two_strings(test_end_time,
                                                                                 test_start_time)
            add_row_to_dict(cur_tag_location_df, self.tag_location_test_df)

    def process_location_data(self, loc, locations_df):
        cur_tag_location_df = {k: None for k in self.table_loc_dict.keys()}
        if loc not in locations_df.groups.keys():
            self.process_empty_location(loc, cur_tag_location_df)
            return

        loc_df = locations_df.get_group(loc)
        try:
            self.copy_loc_data_from_packet_data_file(cur_tag_location_df, loc_df)
            self.calculate_post_process_status(cur_tag_location_df, loc_df, loc)
            self.calculate_location_duration(cur_tag_location_df, loc)
            self.add_sensors_info_for_scylla(cur_tag_location_df, loc_df)
            add_row_to_dict(cur_tag_location_df, self.tag_location_df)
            self.update_process_dict(cur_tag_location_df)
            self.build_table_per_test(loc_df, cur_tag_location_df)
        except Exception as e:
            print_pp(f'pp: create_group_data_table: error processing location {loc}: {e}')
            raise e

    def add_wafer_sort_data(self, unique_tag_id, cur_tag_location_df):
        wafer_sort_columns_to_add = wafer_sort_fields[1:]
        if self.wafer_sort_data is not None and len(unique_tag_id) == 1 and \
                unique_tag_id[0] in self.wafer_sort_data.index:
            wafer_sort_tag_data = self.wafer_sort_data.loc[unique_tag_id[0]]
            for col in wafer_sort_columns_to_add:
                cur_tag_location_df[col] = wafer_sort_tag_data[col]
        else:
            for col in wafer_sort_columns_to_add:
                cur_tag_location_df[col] = None

    def process_empty_location(self, loc, cur_tag_location_df):
        try:
            location_index = self.packet_data['tag_run_location'].index(str(loc))
        except Exception as e:
            raise Exception(f'pp: process_empty_location: location {loc} is missing in packet_data: {e}')
        try:
            fail_bin = int(self.packet_data['fail_bin'][location_index])
        except Exception as e:
            fail_bin = FailureCodes.MISSING_LABEL.value

        cur_tag_location_df['status_post_process'] = False
        if fail_bin == FailureCodes.NO_RESPONSE.value or fail_bin == FailureCodes.BAD_PRINTING.value:
            self.processed_dict['status_post_process'].append(False)
        elif fail_bin == FailureCodes.MISSING_LABEL.value or fail_bin == FailureCodes.END_OF_TEST.value:
            self.processed_dict['status_post_process'].append(None)
        elif fail_bin == FailureCodes.PASS.value:
            self.processed_dict['status_post_process'].append(False)
            fail_bin = FailureCodes.CORRUPTED_PACKET_POST_PROCESS.value
        else:
            print_pp('pp: create_group_data_table: empty line {} with failure code {} different from '
                     'NO_RESPONSE or MISSING_LABEL or PASS (i.e. corrupted packets)'.format(loc, fail_bin))
            self.processed_dict['status_post_process'].append(False)
        cur_tag_location_df['tag_run_location'] = loc
        if 'tag_reel_location' in self.packet_data.keys():
            cur_tag_location_df['tag_reel_location'] = \
                self.packet_data['tag_reel_location'][location_index]
        cur_tag_location_df['fail_bin'] = fail_bin
        cur_tag_location_df['fail_bin_str'] = FailureCodes(fail_bin).name
        cur_tag_location_df['common_run_name'] = self.common_run_name
        cur_tag_location_df['tester_run_id'] = self.tester_run_id
        cur_tag_location_df['external_id'] = self.packet_data['external_id'][location_index]
        cur_tag_location_df['num_responding_tags'] = 0
        cur_tag_location_df['status_offline'] = False
        cur_tag_location_df['last_executed_test'] = np.nanmax(self.packet_raw_df.loc[[str(loc)]]['test_num']) if fail_bin not in (FailureCodes.MISSING_LABEL.value, FailureCodes.END_OF_TEST.value) else None
        cur_tag_location_df['crc_environment'] = self.crc_dict.get(loc)
        if 'label_validated' in self.packet_data.keys():
            cur_tag_location_df['label_validated'] = self.packet_data['label_validated'][location_index]

        try:
            cur_tag_location_df['total_test_duration'] = \
                float(
                    self.packet_data['total_test_duration'][location_index])
        except Exception as e:
            pass

        if loc < max(self.all_locations) and 'trigger_time' in self.packet_data:
            loc_start_time = self.packet_data['trigger_time'][location_index]
            loc_end_time = self.packet_data['trigger_time'][
                self.packet_data['tag_run_location'].index(str(loc + 1))]
            cur_tag_location_df['total_location_duration'] = time_diff_between_two_strings(loc_end_time,
                                                                                           loc_start_time)
        else:
            cur_tag_location_df['total_location_duration'] = None  # we reach to the end of the run

        # append to tables
        add_row_to_dict(cur_tag_location_df, self.tag_location_df)

        cur_tag_location_df['test_num'] = self.packet_data['test_num'][location_index]
        cur_tag_location_df['test_status_offline'] = 0
        cur_tag_location_df['test_status'] = 0
        cur_tag_location_df['test_duration'] = cur_tag_location_df['total_test_duration']
        cur_tag_location_df['received_packet_count'] = 0

        for k in self.table_test_dict.keys():
            if k not in cur_tag_location_df.keys():
                cur_tag_location_df[k] = None

        add_row_to_dict(cur_tag_location_df, self.tag_location_test_df)

        # update process dict:
        self.processed_dict['tag_id'].append('')
        self.processed_dict['external_id'].append('')
        return cur_tag_location_df

    def create_crc_env_dict(self):

        if "crc_environment_previous" not in list(self.packet_raw_df.columns):
            return
        loc_df = self.packet_raw_df.reset_index()
        loc_df["tag_run_location"] = loc_df["tag_run_location"].astype(int)
        loc_df = loc_df.groupby("tag_run_location").agg(
            crc_environment_previous=('crc_environment_previous', 'first')).reset_index()
        loc_df['crc_environment'] = loc_df['crc_environment_previous'].shift(-1).fillna('')
        loc_df['crc_environment'] = loc_df.apply(lambda x: x['crc_environment']
                                                if x['crc_environment_previous'] != ''
                                                else '', axis=1)
        self.crc_dict = dict(zip(loc_df['tag_run_location'], loc_df['crc_environment']))

    def create_group_data_process(self):

        self.table_loc_name = list(self.table_config[self.process_type].keys())[2]
        self.table_loc_dict = self.table_config[self.process_type][self.table_loc_name]
        self.table_test_name = list(self.table_config[self.process_type].keys())[3]
        self.table_test_dict = self.table_config[self.process_type][self.table_test_name]

        self.printing_run = self.is_printing_run()
        self.common_run_name = extract_unique_data(self.packet_df, 'common_run_name')
        if self.common_run_name is None:
            raise Exception('pp: create_group_data_process: common_run_name is missing or does not contain unique data')
        try:
            self.all_locations = [int(loc) for loc in set(self.packet_data['tag_run_location'].copy())]
        except Exception as e:
            raise Exception(f'pp: create_group_data_process: tag_run_location contains non-integer values: {e}')
        self.initialize_dataframes()

        if self.decoded_packet_list is None:
            print_pp('decoded_packet_list is empty')
            return

        self.create_crc_env_dict()
        self.location_with_duplication = check_duplication(self.packet_df)
        locations_df = self.packet_df.groupby('tag_run_location')
        for loc in range(min(self.all_locations), max(self.all_locations) + 1):
            self.process_location_data(loc, locations_df)
        self.checking_pixels_asset_group()
        self.results[self.table_loc_name] = build_table_for_cloud(self.tag_location_df, self.table_loc_dict)
        self.results[self.table_test_name] = build_table_for_cloud(self.tag_location_test_df, self.table_test_dict)

    def checking_pixels_asset_group(self):
        if self.run_data.get('product_config', [''])[0] != 'DurableShapes':
            return
        
        n_pixels_per_asset = int(self.run_data.get('num_pixels_per_asset', [0])[0])
        df = pd.DataFrame(self.tag_location_df)
        res = df.groupby(by=['printed_shape', 'pixels_group_num']).agg(
            n_passed_pixels_per_asset=('status_post_process', 'sum'), 
            tag_loc=('tag_run_location', 'first'),
            )
        if any(res['n_passed_pixels_per_asset'] > n_pixels_per_asset):
            bad_groups = res[res['n_passed_pixels_per_asset'] > n_pixels_per_asset].index.tolist()
            raise Exception (f'pp: checking_pixels_asset_group: on DurableShapes {bad_groups} asset groups have more pixels than written on run_data {n_pixels_per_asset}')
        
        if any(res['n_passed_pixels_per_asset'] < n_pixels_per_asset):
            bad_groups = res[res['n_passed_pixels_per_asset'] < n_pixels_per_asset].index.tolist()
            print (f'pp: checking_pixels_asset_group: on DurableShapes {bad_groups} asset groups have less pixels than written on run_data {n_pixels_per_asset}, update fail bin')
            bad_group_num = [n[1] for n in bad_groups]
            for loc_ind, pixels_group_num in enumerate(self.tag_location_df['pixels_group_num']):
                if pixels_group_num in bad_group_num and self.tag_location_df['status_post_process'][loc_ind] > 0:
                    self.tag_location_df['fail_bin'][loc_ind] = FailureCodes.INSUFFICIENT_NUMBER_OF_PIXELS.value
                    self.tag_location_df['fail_bin_str'][loc_ind] = FailureCodes.INSUFFICIENT_NUMBER_OF_PIXELS.name
                    self.processed_dict['status_post_process'][loc_ind] = False
                    print (f'pp: checking_pixels_asset_group: update location {self.tag_location_df["tag_run_location"][loc_ind]} to fail bin {FailureCodes.INSUFFICIENT_NUMBER_OF_PIXELS.value}')
                    
        return

    def create_run_test_table(self):

        self.run_test_table = {k: [] for k in self.table_run_test_dict.keys()}
        all_tests = self.get_all_tests()
        packet_data_df = self.packet_raw_df.reset_index()

        test_group = packet_data_df.groupby('test_num')
        for i, test in enumerate(all_tests):
            cur_run_test_table = self.create_test_table(test, test_group)
            add_row_to_dict(cur_run_test_table, self.run_test_table)

        self.update_run_summary(packet_data_df)

    def update_run_summary(self, packet_data_df):
        # add run dict pp processed:
        fail_bin_per_loc = packet_data_df.drop_duplicates(subset=['tag_run_location'])['fail_bin']
        self.run_table['total_run_tested'] = [sum([1 for p in self.processed_dict['status_post_process']
                                                   if p is not None])]
        self.run_table['total_run_bad_printing'] = [sum(fail_bin_per_loc == str(FailureCodes.BAD_PRINTING.value))]
        # check files uploading:
        if (int(self.run_table['total_run_tested'][0]) != int(self.run_data['total_run_tested'][0])
           and int(self.run_table['total_run_tested'][0]) != int(self.run_data['total_run_tested'][0])+self.run_table['total_run_bad_printing'][0]):

            raise Exception('pp: post-process number of tested is {} and run_data number of tested is {},'
                            ' please check your upload!'.format(self.run_table['total_run_tested'][0],
                                                                self.run_data['total_run_tested'][0]))
        
        if 'reel_run_start_time' not in self.run_data or pd.isna(self.run_data['reel_run_start_time'][0]):
            raise Exception('pp: post-process reel_run_start_time is missing in run_data')
        else:
            try:
                convert_date(self.run_data['reel_run_start_time'][0])
            except Exception as e:
                raise Exception('pp: post-process reel_run_start_time format is incorrect in run_data (expected format: YYYY-MM-DD HH:MM:SS)')

        self.run_table['sensors_enable'] = [self.run_data.get('sensors_enable', [''])[0].lower() == 'yes']
        self.run_table['total_run_responding_tags'] = [len(self.packet_df['tag_id'].unique())
                                                       if 'tag_id' in self.packet_df.keys() else 0]
        self.run_table['total_run_passed_offline'] = [sum(fail_bin_per_loc == str(FailureCodes.PASS.value))]
        if self.processed_dict is not None:
            self.run_table['total_run_passed_post_process'] = [sum([
                p == 1 for p in self.processed_dict['status_post_process']])]
        else:
            self.run_table['total_run_passed_post_process'] = [0]

        if int(self.run_table['total_run_tested'][0]) > 0:
            self.run_table['run_responsive_tags_yield'] = \
                [100 * (int(self.run_table['total_run_responding_tags'][0]) / int(
                    self.run_table['total_run_tested'][0]))]
            self.run_table['run_offline_yield'] = \
                [100 * (int(self.run_table['total_run_passed_offline'][0]) / int(
                    self.run_table['total_run_tested'][0]))]
            self.run_table['run_post_process_yield'] = \
                [100 * (int(self.run_table['total_run_passed_post_process'][0]) / int(
                    self.run_table['total_run_tested'][0]))]
        else:
            self.run_table['run_responsive_tags_yield'] = [0]
            self.run_table['run_offline_yield'] = [0]
            self.run_table['run_post_process_yield'] = [0]

    def get_all_tests(self):
        all_tests = list(set(self.packet_data['test_num'].copy()))
        all_tests = [int(t) for t in all_tests if t != '']
        all_tests.sort()
        return all_tests

    def create_test_table(self, test, test_group):
        cur_run_test_table = {}
        test_param_per_test = {k: v[test % len(v)] for k, v in self.test_param.items()}
        test_df = self.packet_df.loc[self.packet_df['test_num'] == test]
        test_df_selected = test_df[test_df['selected_tag'].values == test_df['adv_address'].values]
        try:
            test_loc_df = test_group.get_group(str(test)).drop_duplicates(subset=['tag_run_location'])
        except KeyError:
            test_loc_df = test_group.get_group(int(test)).drop_duplicates(subset=['tag_run_location'])

        for col_name in self.table_run_test_dict.keys():
            cur_run_test_table[col_name] = extract_unique_data(test_param_per_test, col_name)

        cur_run_test_table['tester_run_id'] = int(self.tester_run_id)
        cur_run_test_table['common_run_name'] = extract_unique_data(test_loc_df, 'common_run_name')
        cur_run_test_table['test_num'] = test
        cur_run_test_table['test_tested'] = len(test_loc_df) - sum(
            test_loc_df['fail_bin'] == str(FailureCodes.MISSING_LABEL.value))
        cur_run_test_table['test_passed_offline'] = sum(
            [str(s).lower() == 'true' or s is True or s == 1 for s in test_loc_df['is_test_pass'].values])
        if 'absGwTxPowerIndex' in test_param_per_test and test_param_per_test['absGwTxPowerIndex'] is not None:
            cur_run_test_table['test_tx_power_ble_dbm'] = \
                float(valid_output_power_vals[test_param_per_test['absGwTxPowerIndex']]['abs_power'])
        elif 'absGwTxPower' in test_param_per_test and test_param_per_test['absGwTxPower'] is not None:
            cur_run_test_table['test_tx_power_ble_dbm'] = test_param_per_test['absGwTxPower']
        if 'sub1gGwTxPower' in test_param_per_test and test_param_per_test['sub1gGwTxPower'] is not None:
            cur_run_test_table['test_tx_power_lora_dbm'] = test_param_per_test['sub1gGwTxPower']

        if cur_run_test_table['test_post_delay'] is None:
            cur_run_test_table['test_post_delay'] = 0
        # adding stat
        if len(test_df_selected):
            test_packet_list = PacketList()
            test_stat = test_packet_list.get_df_statistics(packet_df=test_df_selected)
            if 'stop_criteria_num_packets_l' in test_param_per_test:
                cur_run_test_table['test_min_packets'] = test_param_per_test['stop_criteria_num_packets_l']
            cur_run_test_table['test_res_rssi_avg'] = test_stat['rssi_mean']
            cur_run_test_table['test_res_tbp_avg'] = test_stat['tbp_mean']
            all_selected_tags = [tag for tag in set(test_df_selected['selected_tag']) if str(tag) != 'nan']
            tag_test_df = test_df_selected.groupby('selected_tag')
            all_min_tx = []
            for tag in all_selected_tags:
                stat_cur = test_packet_list.get_df_statistics(packet_df=tag_test_df.get_group(tag))
                if 'min_tx_last' in stat_cur:
                    all_min_tx.append(stat_cur['min_tx_last'])
            if len(all_min_tx):
                cur_run_test_table['test_res_min_tx_frequency_last_avg'] = np.mean(all_min_tx)
        return cur_run_test_table

    def add_sensors_summary(self):
        for sens_t in ['temperature_sensor', 'humidity_sensor', 'light_intensity_sensor', 'external_cap_sensor_freq']:
            self.run_table[f'{sens_t}_avg'] = [self.packet_df.get(sens_t, pd.Series(dtype='float64')).mean()]

    def create_run_data_process(self):

        self.table_run_name = list(self.table_config[self.process_type].keys())[0]
        self.table_run_dict = self.table_config[self.process_type][self.table_run_name]

        self.run_table = self.import_run_data()
        self.update_reel_run_end_time(self.run_table)
        self.add_sensors_summary()

        self.table_run_test_name = list(self.table_config[self.process_type].keys())[1]
        self.table_run_test_dict = self.table_config[self.process_type][self.table_run_test_name]

        self.create_run_test_table()
        self.results[self.table_run_name] = build_table_for_cloud(self.run_table, self.table_run_dict)
        self.results[self.table_run_test_name] = build_table_for_cloud(self.run_test_table, self.table_run_test_dict)

    @calculate_run_time
    def create_serialization_and_status_change_table(self):

        owner_id = self.run_data['owner_id'][0]
        if not self.printing_run or self.processed_dict is None or owner_id is None or self.decoded_multi_tag is None:
            return

        serialization_data = []
        self.change_status_list = []
        empty_ex_id = 0
        all_serialized_tag_id = []
        for ind in range(len(self.processed_dict['tag_id'])):
            # ind per location
            tag_id = self.processed_dict['tag_id'][ind]
            if tag_id and self.processed_dict['status_post_process'][ind]:
                # location has selected tag id and passed:
                external_id = self.processed_dict['external_id'][ind]
                if isinstance(external_id, str) and len(external_id) >= min_external_id_characters:
                    raw_payload = self.decoded_multi_tag.tags[tag_id][0].custom_data['encrypted_payload'][0]
                    serialization_data.append({'tagId': external_id, 'payload': raw_payload})
                    all_serialized_tag_id.append(tag_id)
                else:
                    empty_ex_id += 1
            elif tag_id:
                # tag was detected but failed:
                group_id = self.decoded_multi_tag.tags[tag_id][0].packet_data['group_id']
                if group_id == '000000':
                    group_id = self.decoded_multi_tag.tags[tag_id][0].custom_data['original_encrypted_packet'][0][20:26]
                group_id = get_group_id_reversed([group_id])[0]
                self.change_status_list.append({'tagId': tag_id.lower(), 'groupId': group_id,
                                                'ownerId': owner_id, 'status': 'failed'})

        # check unique tags id per ex id:
        if len(all_serialized_tag_id) != len(list(set(all_serialized_tag_id))):
            raise Exception(
                'pp: serialization: same tag id has more then one external id: {}'.format(serialization_data))

        self.serialization_list = {'owner_id': owner_id, 'data': serialization_data}
        if empty_ex_id:
            print_pp(' {} tags with empty external id were dropped from the serialization list'.format(empty_ex_id))
            if empty_ex_id == len(self.processed_dict['status_post_process']):
                self.serialization_list = None
                self.change_status_list = None
        if len(self.serialization_list['data']) == 0:
            self.serialization_list = None
        if len(self.change_status_list) == 0:
            self.change_status_list = None

        if self.serialization_list is not None and 'label' in self.run_data.get('product_config', ['pixels'])[0].lower():
            self.force_serialization = True

    @calculate_run_time
    def create_temperature_calibration_table(self):
        if not self.printing_run or self.packet_df.empty:
            return
        df_selected = self.packet_df[self.packet_df['selected_tag'].values == self.packet_df['adv_address'].values]
        df_selected = df_selected[df_selected['fail_bin_str'] == 'PASS']
        
        temp_calib_str_col = ['common_run_name', 'external_id', 'tag_id', 'raw_packet', 'gw_packet']  #TODO need to support encrypted_packet instead of raw_packet + gw_packet
        temp_calib_num_col = ['timestamp', 'time_from_start', 'temperature_sensor', 'temperature', 'packet_cntr', 'packet_cntr_8_msb']
        temp_calib_columns = temp_calib_str_col + temp_calib_num_col
        col_to_copy = []
        constant_col = {'temp_type': 'C', 'temp_expected': round(df_selected['temperature_sensor'].mean()),'temp_range': 5}
        for col in temp_calib_columns:
            if col in df_selected.keys():
                col_to_copy.append(col)
            else:
                constant_col[col] = '' if col in temp_calib_str_col else float('nan')
        
        temp_calib_df = df_selected[col_to_copy]
        
        for col, val in constant_col.items():
            temp_calib_df.insert(loc=len(temp_calib_df.columns), column=col, value=val)
        
        temp_calib_df.insert(loc=len(temp_calib_df.columns), column='group_id', 
                             value=df_selected['group_id'].apply(lambda x: f'"{get_group_id_reversed([x])[0]}"'))
        
        self.temperature_calibration_df = temp_calib_df.dropna(subset=['temperature', 'temperature_sensor', 'external_id'])

    @calculate_run_time
    def create_sensors_scylla_table(self):
        if not self.printing_run or self.packet_df.empty:
            return
        df = pd.DataFrame(self.tag_location_df)
        self.sensors_scylla_df = df[[
            'tag_id', 'group_id',
            'tag_sensor_type', 'sensor_tag_measurement', 'temperature_tag_measurement',
            'humidity_external_measurement', 'temperature_external_measurement', 'light_external_measurement']][(pd.notnull(df['tag_id']))&(df['tag_id']!='')]
        self.sensors_scylla_df.rename(columns={c : snake_to_camel_case(c) for c in self.sensors_scylla_df.columns}, inplace=True)


    def generate_testers_database(self):
        super().generate_testers_database()
        self.create_serialization_and_status_change_table()
        self.create_sensors_scylla_table()
        # self.create_temperature_calibration_table()
        return self.results, self.serialization_list, self.change_status_list, self.partner_results, self.force_serialization, self.sensors_scylla_df

    # @staticmethod
    # def check_power_mode(loc_df):
    #     power_mode_packets_df = loc_df[(loc_df['packet_ver'].astype(str) >= '2.4') & (loc_df['decrypted_packet_type'] == 1)]
    #     if len(power_mode_packets_df) == 0:
    #         return False
    #     if power_mode_packets_df['tx_lpm_hpm_str'].nunique() != 1:
    #         return True
    #     power_mode = list(power_mode_packets_df['tx_lpm_hpm_str'])[0]
    #     inlay = list(power_mode_packets_df['inlay_type'])[0]
    #     expected_power_mode = get_expected_power_mode(inlay)
    #     if expected_power_mode == '':
    #         return False
    #     return expected_power_mode != power_mode
