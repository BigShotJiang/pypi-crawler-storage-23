"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
import pandas as pd

from wiliot_testers.post_process.modules.post_process import *


class AssociationAndVerificationPostProcess(PostProcess):
    def __init__(self, run_data=None, packet_data=None, decoded_packet_list=None,
                 process_type=None, manufacturing_ver=None, tester_run_id=None, wafer_sort_data=None,
                 is_test_mode=False):

        super().__init__(run_data, packet_data, decoded_packet_list, process_type, manufacturing_ver, tester_run_id,
                         wafer_sort_data)

    @staticmethod
    def remove_end_rows(df):
        index = None
        if len(df) == 0:
            return df
        for index, row in df[::-1].iterrows():
            if row['wiliot_code'] != '' or row['asset_code'] != '':
                break
        df = df.iloc[:index + 1]
        return df

    @staticmethod
    def remove_duplicates(df):
        # same location dupes removal
        df = (df.sort_values(by='n_packets', ascending=False)
              .drop_duplicates(subset=['wiliot_code', 'asset_code', 'location'], keep='first')
              .sort_index())
        # successive rows dupes removal
        df = df[(df['wiliot_code'] != df['wiliot_code'].shift(1)) | (df['asset_code'] != df['asset_code'].shift(1)) | ((df['asset_code'] == '') & (df['wiliot_code'] == ''))]
        return df

    @staticmethod
    def check_for_exception(df):
        for col in ['asset_code', 'tag_id', 'wiliot_code']:
            df = df[df[col] != '']
            check_df = df.groupby(col).agg(unique_locations=('location', 'nunique'))
            check_df = check_df[check_df['unique_locations'] > 1]
            if len(check_df) > 0:
                raise Exception(
                    f"pp: there are duplicate {col} on different location in {col} {list(check_df.reset_index()[col])}")

    def create_packet_data_process(self):
        table_name = list(table_config[self.process_type].keys())[1]
        raw_df = pd.DataFrame(self.packet_data)
        df = pd.DataFrame(self.packet_df)
        raw_df['location'] = raw_df['location'].astype(float)
        empty_locations_df = raw_df[~raw_df['location'].isin(set(df['location']))]
        df = self.remove_duplicates(df)
        if not all(pd.isna(empty_locations_df)):
            df = pd.concat([df, empty_locations_df]).sort_values("location").reset_index(drop=True)
        df = self.remove_end_rows(df)
        self.check_for_exception(df)
        df = df.reset_index(drop=True)
        are_equal = (df.index + df['location'].min() == df['location']).all()
        if not are_equal:
            print_pp("row number and location are not equal, changing locations")
            df['location'] = df.index + df['location'].min()

        self.packet_df = df
        self.packet_df['tester_run_id'] = self.tester_run_id
        packet_result = build_table_for_cloud(dict_in=self.packet_df.to_dict('series'),
                                              table_type=table_config[self.process_type][table_name])
        self.results[table_name] = packet_result

    def create_group_data_process(self):
        pass

    def create_run_data_process(self):
        table_name = list(table_config[self.process_type].keys())[0]
        run_table = self.import_run_data()
        self.update_reel_run_end_time(run_table)
        """
        n_locations: number of locations
        n_tags_outside_test: copy paste from run_data (number of heared tags outside the reel
        scan_success: scan_status == True / n_locations
        association_success: is_associated == True / n_scan_success ?
        responding_rate: num locaion where n_packets >  0/ (num of wiliot_code != null) ?
        n_successive_bad_scan: copy paste from run_data, is it config param
        n_success: is_success == True 
        success_rate: n_sucess / n_location
        """
        n_scan_success = len(self.packet_df[self.packet_df['scan_status'] == 'True'])
        n_locations = len(self.packet_df)
        n_success = len(self.packet_df[self.packet_df['is_success'] == 'True'])
        run_table['n_locations'] = [n_locations]
        run_table['scan_success'] = [100*n_scan_success/n_locations]
        run_table['association_success'] = [100*len(self.packet_df[self.packet_df['is_associated'] == 'True'])/n_scan_success]
        run_table['responding_rate'] = [100*len(self.packet_df[self.packet_df['n_packets'].replace('', 0).astype(float).astype(int) > 0])/len(self.packet_df[self.packet_df['wiliot_code'] != ''])]
        run_table['n_success'] = [n_success]
        run_table['success_rate'] = [100*n_success/n_locations]
        run_result = build_table_for_cloud(dict_in=run_table, table_type=table_config[self.process_type][table_name])
        self.results[table_name] = run_result
