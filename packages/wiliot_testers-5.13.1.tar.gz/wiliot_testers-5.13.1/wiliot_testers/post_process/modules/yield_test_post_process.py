"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
from wiliot_testers.post_process.modules.post_process import *


class YieldTestPostProcess(PostProcess):
    def __init__(self, run_data=None, packet_data=None, decoded_packet_list=None,
                 process_type=None, manufacturing_ver=None, tester_run_id=None, wafer_sort_data=None,
                 is_test_mode=False):

        super().__init__(run_data, packet_data, decoded_packet_list, process_type, manufacturing_ver, tester_run_id,
                         wafer_sort_data)
        self.matrix_df = None

    def create_packet_data_process(self):
        self.add_common_fields()
        table_name = list(table_config[self.process_type].keys())[2]
        if 'packet_ver' in self.packet_df.keys():
            self.packet_df['packet_ver'] = self.packet_df['packet_ver'].astype(str)
        self.prepare_and_merge_wafer_sort_data()
        # filter out tags from different wafers:
        packet_df_no_dupes = self.packet_df.drop_duplicates(subset=['tag_id'], keep='first')
        packet_df_filtered = self.filter_out_wafers_outside_test(packet_df_no_dupes)
        self.packet_df['is_valid_wafer'] = False
        self.packet_df.loc[packet_df_filtered.index, 'is_valid_wafer'] = True

        packet_result = build_table_for_cloud(dict_in=self.packet_df.to_dict('series'),
                                              table_type=table_config[self.process_type][table_name])
        self.results[table_name] = packet_result

    def filter_out_wafers_outside_test(self, df):
        def get_lot_wafer():
            lot_wafer_run = self.common_run_name.split('.')
            if len(lot_wafer_run) != 2:
                print_pp('pp: Could not extract lot and wafer from common run name')
                return None
            run_lot = lot_wafer_run[0].upper()
            if len(run_lot) != 9 or not run_lot.isalnum():
                print_pp(f'pp: Invalid LOT was found based on the common run name {run_lot}')
                return None
            run_wafer = lot_wafer_run[1].split('_')[0]
            if len(run_wafer) > 2 or not run_wafer.isdigit():
                print_pp(f'pp: Invalid WAFER was found based on the common run name {run_wafer}')
            run_wafer = int(run_wafer)
            return {'lot': run_lot, 'wafer': run_wafer}
        
        valid_lot_wafer = get_lot_wafer()
        if valid_lot_wafer is None:
            return df  # no filtering is done
        if 'wafer_sort_lot_id' not in df or all(pd.isna(df['wafer_sort_lot_id'])) or \
            'wafer_sort_wafer' not in df or all(pd.isna(df['wafer_sort_wafer'])):
            print_pp('pp: no wafer sort data - no filtering was executed')
            return df
        try:
            df_out = df[(df['wafer_sort_wafer'].notna()) & (df['wafer_sort_lot_id'].notna())]
            wafer_sort_wafer_str = df_out['wafer_sort_wafer'].astype('int').astype('string').str.zfill(2)
            df_out = df_out[(df_out['wafer_sort_lot_id'] == valid_lot_wafer['lot'])&(wafer_sort_wafer_str == str(int(valid_lot_wafer['wafer'])).zfill(2))]
            del df_out['wafer_sort_wafer']  # removing original column sue to pandas warning
            df_out.insert(0, 'wafer_sort_wafer', wafer_sort_wafer_str) # inserting back the padded column
            print_pp(f'pp: Filter out {len(df) - len(df_out)} packets since wafer and lot were different than common run name: {valid_lot_wafer}')
        except Exception as e:
            print_pp(f'pp: Could not filter out packets from different wafers due to error: {e}')
            return df
        return df_out
        
    def create_group_data_process(self):
        table_name = list(table_config[self.process_type].keys())[1]
        cast_columns(self.packet_df, ['rssi', 'min_tx', 'tag_matrix_ttfp'], float)
        packet_df_no_dupes = self.packet_df.drop_duplicates(subset=['tag_id'], keep='first')
        # filter out tags from different wafers:
        packet_df_filtered = packet_df_no_dupes[packet_df_no_dupes['is_valid_wafer'] == True]
        self.matrix_df = packet_df_filtered.groupby('matrix_tags_location').agg(
            # new column name = (column to group, function)
            matrix_timestamp=('matrix_timestamp', 'min'),
            number_of_advas=('adv_address', 'nunique'),
            number_of_tags=('tag_id', 'nunique'),
            matrix_yield=('tag_id', lambda x: 100*x.nunique()/int(self.run_data['matrix_tags'][0])),
            matrix_ttfp=('tag_matrix_ttfp', 'min'),
            rssi_mean=('rssi', 'mean'),
            rssi_std=('rssi', 'std'),
            min_tx_mean=('min_tx', 'mean'),
            min_tx_std=('min_tx', 'std'),
            matrix_environment_light_intensity_avg=('environment_light_intensity', 'mean'),
            matrix_environment_temperature_avg=('environment_temperature', 'mean'),
            matrix_environment_humidity_avg=('environment_humidity', 'mean'),
        ).reset_index().rename(columns={'matrix_tags_location': 'matrix_location'})
        # adding raw_data to matrix_df to include also corrupted packets data:
        raw_df = pd.DataFrame(self.packet_data).drop_duplicates('matrix_tags_location')
        raw_df.insert(0, 'matrix_location', raw_df['matrix_tags_location'].astype(int))
        raw_df = raw_df[['matrix_location', 'matrix_timestamp']]
        self.matrix_df = pd.merge(self.matrix_df, raw_df, on='matrix_location', how='outer')
        self.matrix_df.insert(0, 'matrix_timestamp', self.matrix_df['matrix_timestamp_y'])
        all_locations = pd.DataFrame({'matrix_location': range(int(raw_df['matrix_location'].min()),
                                                               int(raw_df['matrix_location'].max()) + 1)})
        self.matrix_df = all_locations.merge(self.matrix_df, on='matrix_location', how='left')
        columns_to_replace_with_0 = ['number_of_advas', 'number_of_tags', 'matrix_yield']
        self.matrix_df[columns_to_replace_with_0] = (self.matrix_df[columns_to_replace_with_0].apply(pd.to_numeric, errors='coerce').fillna(0))
        try:
            m_timestamp = self.matrix_df['matrix_timestamp'].astype(float)
            self.matrix_df['matrix_time'] = m_timestamp.shift(-1) - m_timestamp
        except:
            self.matrix_df['matrix_timestamp'] = pd.to_datetime(self.matrix_df['matrix_timestamp'])
            self.matrix_df['matrix_time'] = (self.matrix_df['matrix_timestamp'].shift(-1) - self.matrix_df[
                'matrix_timestamp']).dt.total_seconds()
        self.matrix_df['tester_run_id'] = self.tester_run_id
        self.matrix_df['common_run_name'] = self.common_run_name

        packet_result = build_table_for_cloud(dict_in=self.matrix_df,
                                              table_type=table_config[self.process_type][table_name])
        self.results[table_name] = packet_result

    def create_run_data_process(self):
        table_name = list(table_config[self.process_type].keys())[0]

        run_table = self.import_run_data()
        self.update_reel_run_end_time(run_table)

        run_table['batch_name'] = [run_table['wafer_lot'][0] + '.' + run_table['wafer_number'][0]]
        run_table['total_run_passed'] = [
            int(int(run_table['total_run_tested'][0]) * int(float(run_table['yield'][0])) / 100)]
        run_table['total_run_tags'] = [self.matrix_df['number_of_tags'].sum()]
        run_table['run_post_process_yield'] = [100 * int(run_table['total_run_tags'][0]) / int(run_table['total_run_tested'][0])]
        run_table['run_environment_light_intensity_avg'] = [self.packet_df['environment_light_intensity'].mean()]
        run_table['run_environment_temperature_avg'] = [self.packet_df['environment_temperature'].mean()]
        run_table['run_environment_humidity_avg'] = [self.packet_df['environment_humidity'].mean()]
        run_table['matrix_time_avg'] = [self.matrix_df['matrix_time'].mean()]
        run_table['matrix_time_std'] = [self.matrix_df['matrix_time'].std()]
        try:
            time_profile_on_time, time_profile_period = ast.literal_eval(run_table['gw_time_profile'][0])
            run_table['time_profile_period'] = [time_profile_period]
            run_table['time_profile_on_time'] = [time_profile_on_time]
        except:
            print_pp("Could not extract time_profile values!")

        run_result = build_table_for_cloud(dict_in=run_table, table_type=table_config[self.process_type][table_name])
        self.results[table_name] = run_result
