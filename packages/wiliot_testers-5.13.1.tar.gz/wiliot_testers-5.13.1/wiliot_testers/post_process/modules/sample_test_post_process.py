"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
import numpy as np
import pandas as pd

from wiliot_testers.post_process.modules.post_process import *
from wiliot_testers.wiliot_tester_tag_result import FailBinSample

ANALYSIS_COLUMNS_NAMES = {  # name in stat: name in analysis table
    'ttfp': 'TTFP',
    'tbp_min': 'timeBetweenSuccessivePacketMs',
    'tbp_mean': 'timeBetweenSuccessivePacketMsAvg',
    'packet_counter_first': 'firstPacketCounterValue',
    'min_tx_last': 'minTXLast',
    'tbc_mean': 'TimeBetweenCyclesAvg',
    'rssi_mean': 'rssiAvg',
    'total_cer': 'cer',
    'per_mean': 'perAvg'}


class SampleTestPostProcess(PostProcess):
    NO_RESPONSE_FAIL_BINS = [FailBinSample.NO_TTFP.value, FailBinSample.NO_SERIALIZATION.value,
                             FailBinSample.UNDETERMINED_ERROR.value]

    def __init__(self, run_data=None, packet_data=None, decoded_packet_list=None,
                 process_type=None, manufacturing_ver=None, tester_run_id=None, wafer_sort_data=None,
                 is_test_mode=False):

        super().__init__(run_data, packet_data, decoded_packet_list, process_type, manufacturing_ver, tester_run_id,
                         wafer_sort_data)

    def results_table(self):
        self.packet_df = add_calculated_data_per_packet(df_to_agg=self.packet_df, groups=['tag_id'])

        results_dict = self.packet_df.to_dict('list')
        results_dict_camel = snake_to_camel_dict_keys(results_dict)
        # fix according to sample test convention where encryptedPacket is a flag if the packet id
        if 'decryptedPacket' in results_dict_camel.keys():
            results_dict_camel['encryptedPacket'] = []
            for decrypted_packet in results_dict_camel['decryptedPacket']:
                results_dict_camel['encryptedPacket'].append(int(decrypted_packet is not None or
                                                                 not decrypted_packet == ''))

        # fix according to sample test convention tagId -> tagID
        if 'tagId' in results_dict_camel.keys():
            results_dict_camel['tagID'] = results_dict_camel.pop('tagId')
        # fix according to sample test convention time from start -> time
        if 'timeFromStart' in results_dict_camel.keys():
            results_dict_camel['time'] = results_dict_camel.pop('timeFromStart')
        # fix according to sample test convention packetVer -> packetVersion
        if 'packetVer' in results_dict_camel.keys():
            results_dict_camel['packetVersion'] = results_dict_camel.pop('packetVer')
        # fix according to sample test convention packetCntr -> packetCntrVal
        if 'packetCntr' in results_dict_camel.keys():
            results_dict_camel['packetCtrVal'] = results_dict_camel.pop('packetCntr')
        # fix according to sample test convention flow version
        if 'flowVer' in results_dict_camel.keys():
            results_dict_camel['vFlow'] = [int(s[2:4] if '0x' in s else s.split('.')[0], 16) for s in
                                           results_dict_camel['flowVer']]
            results_dict_camel['vMinor'] = [int(s[4::] if '0x' in s else s.split('.')[1], 16) for s in
                                            results_dict_camel['flowVer']]
        if 'groupId' in results_dict_camel.keys():
            results_dict_camel['groupId'] = get_group_id_reversed(group_id_list=results_dict_camel['groupId'])
        if 'currentCer' in results_dict_camel.keys():
            results_dict_camel['currentCer'] = [int(x * 100) if not np.isnan(x) else None for x in results_dict_camel['currentCer']]
        if 'movingMeanCer' in results_dict_camel.keys():
            results_dict_camel['currentCer'] = [int(x * 100) if not np.isnan(x) else None for x in results_dict_camel['movingMeanCer']]
        if 'avgNumPackets' in results_dict_camel.keys():
            results_dict_camel['avgNumPackets'] = [round(x) for x in results_dict_camel['avgNumPackets']]
        if 'loMaxFreq' in results_dict_camel.keys():
            results_dict_camel['maxTx'] = [x if x != 2402 else None for x in results_dict_camel['loMaxFreq']]

        return results_dict_camel

    def insert_no_response_tags(self, analysis_dict):
        raw_packets_df = pd.DataFrame(self.packet_data)
        raw_packets_df = raw_packets_df.rename(
            columns={'state(tbp_exists:0,no_tbp:-1,no_ttfp:-2,dup_adv_address:-3)': 'state'})
        if 'state' not in raw_packets_df.keys():
            return
        no_response_df = raw_packets_df[
            (raw_packets_df['state'].astype(int).isin(SampleTestPostProcess.NO_RESPONSE_FAIL_BINS)) &
            ((raw_packets_df['encrypted_packet'] == '') | (raw_packets_df['encrypted_packet'].isna()))]
        for i, row in no_response_df.iterrows():
            for key in analysis_dict:
                if key == 'externalId':
                    value_to_add = row['external_id']
                elif key == 'commonRunName':
                    value_to_add = row['common_run_name']
                elif key in ('TTFP', 'timeBetweenSuccessivePacketMs', 'firstPacketCounterValue'):
                    value_to_add = -1
                elif key == 'state':
                    value_to_add = row['state']
                elif key == 'failBin':
                    value_to_add = get_failbin_sample(int(row['state']))
                else:
                    value_to_add = None
                analysis_dict[key].append(value_to_add)

    def analysis_table(self):
        tags_stat = pd.DataFrame()
        tags_df = self.packet_df.groupby('tag_id')
        for tag_id, tag_df in tags_df:
            tag_stat = self.decoded_packet_list.get_df_statistics(tag_df)
            tag_stat['tagID'] = tag_id
            tag_stat['externalId'] = extract_unique_data(tag_df, 'external_id')
            tag_stat['chamber'] = extract_unique_data(tag_df, 'chamber')
            tag_stat['state'] = extract_unique_data(tag_df, 'state')
            tag_stat['failBin'] = get_failbin_sample(tag_stat['state'])
            tag_stat['flowVer'] = extract_unique_data(tag_df, 'flow_ver')

            internal_temp = tag_stat['temperature_mean'] if is_number(tag_stat.get('temperature_mean')) else float('nan')
            sensor_temp = extract_unique_data(tag_df, 'temperature_from_sensor')
            sensor_temp = sensor_temp if is_number(sensor_temp) else float('nan')
            tag_stat['DiffBetweenTagAndChamberTemp'] = internal_temp - sensor_temp

            tags_stat = pd.concat([tags_stat, pd.DataFrame(tag_stat, index=[0])], axis=0)
        # change columns names and change to dict:
        analysis_df = tags_stat.rename(columns=ANALYSIS_COLUMNS_NAMES)
        analysis_df.insert(loc=0, column='commonRunName', value=self.common_run_name)
        analysis_dict = analysis_df.reset_index().to_dict(orient='list')
        # add no response data
        self.insert_no_response_tags(analysis_dict)
        return analysis_dict

    def create_packet_data_process(self):
        results_table_dict = self.results_table()
        packet_table_name = list(table_config[self.process_type].keys())[1]
        packet_result = build_table_for_cloud(dict_in=results_table_dict,
                                              table_type=table_config[self.process_type][packet_table_name])
        self.results[packet_table_name] = packet_result

        # analysis table:
        analysis_packet_list = self.analysis_table()
        packet_analysis_table_name = list(table_config[self.process_type].keys())[2]
        packet_analysis_results = \
            build_table_for_cloud(dict_in=analysis_packet_list,
                                  table_type=table_config[self.process_type][packet_analysis_table_name])
        self.results[packet_analysis_table_name] = packet_analysis_results

    def create_group_data_process(self):
        pass

    def create_run_data_process(self):
        table_name = list(table_config[self.process_type].keys())[0]
        self.run_data = snake_to_camel_dict_keys(self.run_data)
        run_table = self.import_run_data()
        if 'testStatus' not in run_table.keys():
            run_table['testStatus'] = [True]  # to support previous version with no pass validation
        run_results = build_table_for_cloud(dict_in=run_table, table_type=table_config[self.process_type][table_name])
        self.results[table_name] = run_results
