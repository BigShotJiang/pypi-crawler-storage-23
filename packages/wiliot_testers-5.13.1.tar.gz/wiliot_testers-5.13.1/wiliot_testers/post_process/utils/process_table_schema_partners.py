"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""

table_config = \
    {
        'sample_test':
            {
                'run_data':
                    {
                        'testerStationName': 'str',
                        'commonRunName': 'str',
                        'batchName': 'str',
                        'testerType': 'str',
                        'comments': 'str',
                        'timeProfile': 'str', 'txPower': 'str', 'energizingPattern': 'str',
                        'tested': 'str', 'passed': 'str', 'inlay': 'str',
                        'testTime': 'str', 'maxTtfp': 'str', 'gwVersion': 'str',
                        'bleAttenuation': 'str', 'loraAttenuation': 'str', 'antennaType': 'str',
                        'operator': 'str',
                        'runStartTime': 'str', 'runEndTime': 'str',
                        'surface': 'str', 'numChambers': 'str', 'pyWiliotVersion': 'str',
                        'testTimeProfilePeriod': 'str',
                        'ttfpAvg': 'str', 'tbpAvg': 'str', 'rssiAvg': 'str',
                        'tester_run_id': 'long', 'manufacturing_version': 'str',
                        'responded': 'str', 'responding[%]': 'str', 'passed[%]': 'str',
                        'testStatus': 'bool', 'controlLimits': 'str', 'hwVersion': 'str',
                        'sub1gFrequency': 'str', 'tbpStd': 'str', 'failBin': 'str', 'failBinStr': 'str',
                        'validTbp[%]': 'str'
                    },
                'results':
                    {
                        'commonRunName': 'str', 'time': 'float', 'decryptedPacket': 'str', 'tagID': 'str',
                        'groupId': 'str',
                        'encryptedPacket': 'int',
                        'packetCtrVal': 'int', 'chargeTime': 'int',
                        'vMinor': 'int', 'vFlow': 'int',
                        'packetVersion': 'str',
                        'totalDco': 'float', 'dcoCoarse': 'int', 'dcoFine': 'int', 'dcoEfine': 'int',
                        'symdcoGapInd': 'int',
                        'wkupPos': 'int', 'eawkupSilent': 'int', 'eawkupEnergy': 'int', 'wkupNeg': 'int',
                        'auxMeasStr': 'float', 'auxFreqStr': 'float', 'auxFreqInt': 'float', 'auxMeasInt': 'float',
                        'auxMeasExceptionTimeoutCtr': 'int', 'succAuxMeasInd': 'int', 'goodAuxMeasCtr': 'int',
                        'auxMeasStatusPrevPrevPrev': 'int', 'auxMeasCh': 'int', 'auxMeasChPrevPrevPrev': 'int',
                        'auxMeasStatusPrevPrev': 'int', 'auxMeasStatus': 'int', 'auxMeasStatusPrev': 'int',
                        'badAuxMeasCtr': 'int', 'auxMeasChPrevPrev': 'int', 'auxMeasChPrev': 'int', 'auxMeasCtr': 'int',
                        'temperature': 'float', 'temperatureRange': 'int',
                        'idac': 'int', 'idacX2': 'int',
                        'txLpmHpm': 'int',
                        'packetTime': 'float', 'timeDiff': 'float',
                        'gpio4Sense': 'int',
                        'proximity': 'int',
                        'loVrefVbpCalibFailInd': 'int', 'loVrefTx': 'int', 'loVbpTx': 'int',
                        'modIdx': 'int',
                        'maxTimeSprinklerCtr': 'int', 'maxFreqSprinklerCtr': 'int',
                        'avgNumPackets': 'int', 'cyclesLost': 'int',
                        'compAndTuneToggle': 'int', 'loBufCtl': 'int',
                        'currentCer': 'int',
                        'calibCycle': 'int',
                        'tunerIdx': 'int',
                        'testModePacketInd': 'int',
                        'statParam': 'int',
                        'externalId': 'str',
                        'chamber': 'str', 'originalEncryptedPacket': 'str', 'encryptedPayload': 'str',
                        'rssi': 'int', 'temperatureFromSensor': 'float', 'perPerCycleCh': 'float', 'gearTypeStr': 'str', 'harvTypeStr': 'str', 'packetCntrNormalized': 'int',
                        'maxTx': 'float'
                    },
                'analysis':
                    {
                        'commonRunName': 'str',
                        'tagID': 'str',
                        'externalId': 'str',
                        'TTFP': 'float',
                        'timeBetweenSuccessivePacketMs': 'int',
                        'timeBetweenSuccessivePacketMsAvg': 'float',
                        'firstPacketCounterValue': 'int',
                        'minTXLast': 'float',
                        'TimeBetweenCyclesAvg': 'float',
                        'chamber': 'str', 'rssiAvg': 'float',
                        'state': 'int', 'failBin': 'str', 'flowVer': 'str',
                        'DiffBetweenTagAndChamberTemp': 'float',
                        'cer': 'float',
                        'perAvg': 'float'
                    }
            },
        'offline_test':
            {
                'runs':
                    {
                        'tester_run_id': 'long', 'common_run_name': 'str', 'tester_station_name': 'str',
                        'operator': 'str', 'reel_run_start_time': 'timestamp', 'reel_run_end_time': 'timestamp',
                        'batch_name': 'str', 'tester_type': 'str', 'comments': 'str',
                        'total_run_tested': 'int', 'total_run_responding_tags': 'int',
                        'total_run_passed_offline': 'int', 'total_run_passed_post_process': 'int',
                        'total_missing_labels': 'int', 'run_responsive_tags_yield': 'float',
                        'run_offline_yield': 'float', 'run_post_process_yield': 'float',
                        'ttfp_avg': 'float', 'conversion_type': 'str', 'inlay': 'str', 'test_suite': 'str',
                        'surface': 'str', 'to_print': 'bool', 'qr_validation': 'bool',
                        'print_pass_job_name': 'str', 'printing_format': 'str', 'external_id_prefix': 'str',
                        'external_id_suffix_init_value': 'int',
                        'coupler_partnumber': 'str',
                        'gw_version': 'str', 'py_wiliot_version': 'str', 'post_process_version': 'str',
                        'manufacturing_version': 'str', 'upload_date': 'timestamp', 'total_run_bad_printing': 'int',
                        'conversion_label': 'str', 'sensors_enable': 'bool', 'product_config': 'str', 
                        'tag_sensor_type': 'str',
                        'temperature_sensor_avg': 'float', 'humidity_sensor_avg': 'float', 'light_intensity_sensor_avg': 'float',
                        'external_cap_sensor_freq_avg': 'float', 'num_pixels_per_asset': 'int'
                    },
                'run_tests':
                    {
                        'tester_run_id': 'long', 'common_run_name': 'str', 'test_num': 'int', 'test_name': 'str',
                        'test_tested': 'int', 'test_passed_offline': 'int',
                        'test_time_profile_period': 'int', 'test_time_profile_on_time': 'int',
                        'test_tx_power_ble_dbm': 'float', 'test_tx_power_lora_dbm': 'float',
                        'test_energizing_pattern': 'int', 'test_receive_ch': 'int',
                        'test_pl_delay': 'int', 'test_rssi_hw_threshold': 'int',
                        'test_rssi_acceptable_threshold': 'int',
                        'test_min_packets': 'int', 'test_max_time': 'float', 'test_post_delay': 'float',
                        'test_ttfp_lsl': 'float', 'test_ttfp_usl': 'float', 'test_tbp_min_lsl': 'float',
                        'test_tbp_min_usl': 'float', 'test_tbp_max_lsl': 'float', 'test_tbp_max_usl': 'float',
                        'test_tbp_avg_lsl': 'float', 'test_tbp_avg_usl': 'float',
                        'test_sprinkler_counter_max_lsl': 'int', 'test_sprinkler_counter_max_usl': 'int',
                        'test_time_between_cycles_lsl': 'float', 'test_time_between_cycles_usl': 'float',
                        'test_res_rssi_avg': 'float', 'test_res_tbp_avg': 'float',
                        'test_res_min_tx_frequency_last_avg': 'float'
                    },
                'tag_locations':
                    {
                        'tester_run_id': 'long', 'common_run_name': 'str', 'tag_run_location': 'int',
                        'tag_reel_location': 'int', 'total_test_duration': 'float', 'total_location_duration': 'float',
                        'status_offline': 'int', 'status_post_process': 'int', 'fail_bin': 'int', 'fail_bin_str': 'str',
                        'last_executed_test': 'int', 'tag_id': 'str',
                        'external_id': 'str', 'qr_validated': 'bool', 'group_id': 'str',
                        'packet_version': 'str', 'flow_version': 'str', 'num_responding_tags': 'int',
                        'label_validated': 'str', 'wafer_sort_lot_id': 'str', 'wafer_sort_wafer': 'str',
                        'wafer_sort_soft_bin': 'int', 'wafer_sort_flow_version': 'str',
                        'wafer_sort_packet_version': 'str',
                        'wafer_sort_x_location': 'int', 'wafer_sort_y_location': 'int', 'wafer_sort_status': 'int', 'crc_environment': 'int',
                        'tag_sensor_type': 'str', 'sensor_tag_measurement': 'float', 'temperature_tag_measurement': 'float',
                        'humidity_external_measurement': 'float', 'light_external_measurement': 'float',
                        'temperature_external_measurement': 'float','pixels_group_num': 'int', 'printed_shape': 'str'
                    },
                'tag_location_tests':
                    {
                        'tester_run_id': 'long', 'common_run_name': 'str', 'tag_run_location': 'int', 'test_num': 'int',
                        'test_status_offline': 'int', 'test_duration': 'float',
                        'received_packet_count': 'int', 'ttfp': 'float',
                        'charge_time_max': 'int',
                        'charge_time_min': 'int', 'tbp_avg': 'float', 'tbp_min': 'float', 'tbp_max': 'float',
                        'rssi_avg': 'float', 'rssi_std': 'float', 'first_packet_counter': 'int',
                        'last_packet_counter': 'int', 'dco_coarse_last': 'int', 'dco_fine_last': 'int',
                        'dco_efine_last': 'int', 'min_tx_frequency_last': 'float', 'packets_per_cycle_avg': 'float',
                        'packets_per_cycle_std': 'float', 'time_between_cycles_avg': 'float', 'aux_meas_avg': 'float',
                        'temperature_from_sensor': 'float', 'internal_temperature_avg': 'float',
                        'tag_id': 'str', 'test_status': 'int', 'total_cer': 'float', 'received_cycle_count': 'int',
                        'vref_mean': 'float', 'vref_std': 'float', 'vref_min': 'int', 'vref_max': 'int',
                        'vbp_mean': 'float', 'vbp_std': 'float', 'vbp_min': 'int', 'vbp_max': 'int', 'test_name': 'str',
                        'external_cap_sensor_freq_avg': 'float', 'external_cap_sensor_freq_min': 'float', 'external_cap_sensor_freq_max': 'float',
                        'internal_cap_sensor_freq_avg': 'float', 'internal_cap_sensor_freq_min': 'float', 'internal_cap_sensor_freq_max': 'float',
                        'total_aux_meas_rate': 'float', 'num_packets': 'int', 'num_cycles': 'int'
                    },
                'tag_test_packets':
                    {
                        'tester_run_id': 'long', 'common_run_name': 'str', 'tag_run_location': 'int', 'test_num': 'int',
                        'packet_time': 'float', 'original_encrypted_packet': 'str', 'packet_status': 'str',
                        'encrypted_payload': 'str', 'adv_address': 'str', 'group_id': 'str',
                        'decrypted_packet': 'str', 'gw_packet': 'str',
                        'decrypted_packet_type': 'int', 'tag_id': 'str',
                        'flow_ver': 'str', 'test_mode': 'int',
                        'rssi': 'int', 'stat_param': 'int', 'time_from_start': 'float',
                        'packet_ver': 'str', 'packet_cntr': 'int', 'temperature_range': 'int',
                        'temperature': 'float', 'temperature_sensor': 'float',
                        'dco_coarse': 'int', 'dco_fine': 'int', 'dco_efine': 'int',
                        'total_dco': 'float', 'min_tx': 'float', 'gpio4_sense': 'int', 'remainder4': 'int',
                        'lo_vref_tx': 'int', 'lo_vref_vbp_calib_fail_ind': 'int',
                        'comp_and_tune_toggle': 'int', 'lo_buf_ctl': 'int', 'idac_x2': 'int',
                        'idac': 'int', 'symdco_gap_ind': 'int', 'wkup_pos': 'int', 'wkup_neg': 'int', 'mod_idx': 'int',
                        'aux_meas_val': 'float', 'proximity': 'int',
                        'eawkup_silent': 'int', 'eawkup_energy': 'int', 'reserved': 'int', 'charge_time': 'int',
                        'good_aux_meas_ctr': 'int', 'bad_aux_meas_ctr': 'int', 'max_time_sprinkler_ctr': 'int',
                        'max_freq_sprinkler_ctr': 'int', 'succ_aux_meas_ind': 'int',
                        'aux_meas_exception_timeout_ctr': 'int', 'aux_meas_ch_str': 'str', 'aux_meas_channel_n': 'int',
                        'aux_meas_status_n': 'int', 'aux_meas_channel_n_1': 'int', 'aux_meas_status_n_1': 'int',
                        'aux_meas_channel_n_2': 'int', 'aux_meas_status_n_2': 'int', 'aux_meas_channel_n_3': 'int',
                        'aux_meas_status_n_3': 'int', 'selected_tag': 'str', 'tx_lpm_hpm': 'int',
                        'tx_lpm_hpm_str': 'str', 'lo_vbp_tx': 'int', 'external_sensor': 'float',
                        'packet_cntr_16bits': 'int', 'per_per_cycle_ch': 'float', 'gear_type_str': 'str',
                        'harv_type_str': 'str', 'packet_cntr_normalized': 'int',
                        'max_tx': 'float', 'current_cer': 'float', 'humidity_sensor': 'float',
                        'light_intensity_sensor': 'float', 'rc_sensor_freq_khz': 'float',
                        'external_id': 'str', 'tbc': 'float', 'tbp': 'int', 'first_packet_ind': 'bool',
                        'external_cap_sensor_freq': 'float', 'internal_cap_sensor_freq': 'float', 'external_res_sensor_freq': 'float', 'internal_res_sensor_freq': 'float',
                        'invalid_sensor_measurement': 'bool'
                    }

            },
        'yield_test': {
            'runs':
                {
                    'tester_run_id': 'long', 'common_run_name': 'str', 'tester_station_name': 'str',
                    'operator': 'str', 'run_start_time': 'timestamp', 'run_end_time': 'timestamp',
                    'wafer_lot': 'str', 'wafer_number': 'int', 'tester_type': 'str', 'comments': 'str',

                    'total_run_tested': 'int', 'total_run_advas': 'int', 'run_yield': 'float',
                    'total_run_tags': 'int', 'run_post_process_yield': 'float',

                    'inlay': 'str', 'conversion_type': 'str', 'surface': 'str',

                    'run_environment_light_intensity_avg': 'float', 'run_environment_temperature_avg': 'float',
                    'run_environment_humidity_avg': 'float',

                    'matrix_time_avg': 'float', 'matrix_time_std': 'float',

                    'matrix_tags': 'str', 'thermodes_col': 'str', 'rows_number': 'str',

                    'energizing_pattern': 'int', 'time_profile_period': 'int',
                    'time_profile_on_time': 'int', 'received_channel': 'int',

                    'gw_version': 'str', 'py_wiliot_version': 'str', 'post_process_version': 'str',
                    'manufacturing_version': 'str', 'upload_date': 'timestamp', 'number_of_columns': 'int', 'number_of_lanes': 'int',
                },
            'matrix':
                {
                    'tester_run_id': 'long', 'common_run_name': 'str',
                    'matrix_location': 'int', 'matrix_time': 'float', 'matrix_yield': 'float',

                    'number_of_tags': 'int', 'number_of_advas': 'int', 'matrix_ttfp': 'float',

                    'rssi_mean': 'float', 'rssi_std': 'float', 'min_tx_mean': 'float', 'min_tx_std': 'float',

                    'matrix_environment_light_intensity_avg': 'float', 'matrix_environment_temperature_avg': 'float',
                    'matrix_environment_humidity_avg': 'float',

                },
            'packets':
                {
                    'tester_run_id': 'long', 'common_run_name': 'str', 'uid': 'str', 'transmitted_adva': 'str',
                    'matrix_tags_location': 'int',
                    'packet_time': 'float', 'tag_matrix_ttfp': 'float', 'decrypted_packet': 'str', 'rssi': 'int', 'dco_fine': 'int',
                    'dco_efine': 'int', 'dco_coarse': 'int',
                    'internal_temperature': 'float', 'packet_counter': 'int', 'charge_time': 'int',
                    'packet_version': 'str', 'flow_version': 'str', 'group_id': 'str',
                    'environment_light_intensity': 'float', 'environment_humidity': 'float', 'environment_temperature': 'float',
                    'min_tx_frequency': 'float', 'aux_meas_val': 'float', 'external_sensor': 'float',
                    'wafer_sort_lot_id': 'str', 'wafer_sort_wafer': 'str', 'wafer_sort_soft_bin': 'int', 'wafer_sort_flow_version': 'str',
                    'wafer_sort_packet_version': 'str', 'wafer_sort_x_location': 'int', 'wafer_sort_y_location': 'int', 'wafer_sort_status': 'int',
                    'per_per_cycle_ch': 'float', 'gear_type_str': 'str', 'harv_type_str': 'str', 'packet_cntr_normalized': 'int', 'current_cer': 'float', 'lo_max_freq':'float',
                    'is_valid_wafer': 'bool'
                }
            },
        'association_and_verification_test': {
            'runs':
                {
                    'tester_run_id': 'long', 'common_run_name': 'str', 'station_name': 'str', 'run_start_time': 'str', 'end_run_time': 'str',
                    'n_locations': 'int', 'n_tags_outside_test': 'int', 'scan_success': 'float',
                    'association_success': 'float',
                    'responding_rate': 'str', 'n_successive_bad_scan': 'int', 'is_duplicated': 'bool',
                    'n_success': 'int',
                    'success_rate': 'str', 'min_test_time': 'int', 'max_test_time': 'int', 'time_to_move': 'int',
                    'need_to_associate': 'bool', 'is_step_machine': 'bool', 'asset_location': 'str', 'owner_id': 'str',
                    'category_id': 'str', 'energy_pattern': 'int', 'time_profile': 'str', 'ble_power': 'int',
                    'sub1g_power': 'int', 'sub1g_freq': 'int', 'scan_ch': 'int', 'is_listen_bridge': 'bool',
                    'env': 'str', 'scanner_type': 'str', 'sc_min_location': 'int', 'sc_association': 'int',
                    'sc_scanning': 'int', 'sc_responding': 'int', 'sc_n_no_scan': 'int', 'run_name': 'str',
                    'first_location': 'int', 'tester_type': 'str', 'inlay_type': "str"
                },
            'locations':
                {
                    'tester_run_id': 'long', 'common_run_name': 'str', 'location': 'float', 'wiliot_code': 'str',
                    'asset_code': 'str', 'timestamp': 'float', 'scan_status': 'bool', 'is_associated': 'bool',
                    'associate_status_code': 'float',
                    'adv_address': 'str', 'n_packets': 'float', 'external_id': 'str', 'encrypted_packet': 'str',
                    'rssi': 'float', 'packet_type': 'float', 'is_success': 'bool', 'min_tx': 'float', 'tag_id': 'str',
                    'dco_fine': 'int', 'dco_coarse': 'int',
                }

        },

        'sample_test_partner':
            {
                'run_data':
                {
                    'testerStationName': 'str', 'commonRunName': 'str', 'batchName': 'str',
                    'testerType': 'str', 'comments': 'str',
                    'timeProfile': 'str', 'txPower': 'str', 'energizingPattern': 'str',
                    'tested': 'str', 'passed': 'str',
                    'inlay': 'str', 'testTime': 'str', 'maxTtfp': 'str', 'gwVersion': 'str',
                    'bleAttenuation': 'str', 'loraAttenuation': 'str', 'antennaType': 'str',
                    'operator': 'str',
                    'runStartTime': 'str', 'runEndTime': 'str',
                    'surface': 'str', 'numChambers': 'str', 'pyWiliotVersion': 'str',
                    'testTimeProfilePeriod': 'str',
                    'ttfpAvg': 'str', 'tbpAvg': 'str', 'rssiAvg': 'str',
                    'tester_run_id': 'long', 'manufacturing_version': 'str',
                    'responded': 'str', 'responding[%]': 'str', 'passed[%]': 'str',
                    'testStatus': 'bool', 'failBin': 'str', 'failBinStr': 'str'
                },
                'analysis':
                {
                    'commonRunName': 'str', 'externalId': 'str',
                    'TTFP': 'float', 'timeBetweenSuccessivePacketMs': 'int',
                    'firstPacketCounterValue': 'int', 'minTXLast': 'float',
                    'TimeBetweenCyclesAvg': 'float', 'chamber': 'str',
                    'rssiAvg': 'float', 'state': 'int', 'failBin': 'str', 'DiffBetweenTagAndChamberTemp': 'float',
                    'cer': 'float', 'perAvg': 'float'
                }
            },
        'offline_test_partner':
            {
                'runs':
                {
                    'tester_run_id': 'long', 'common_run_name': 'str', 'tester_station_name': 'str',
                    'operator': 'str', 'reel_run_start_time': 'timestamp', 'reel_run_end_time': 'timestamp',
                    'batch_name': 'str', 'tester_type': 'str', 'comments': 'str',
                    'total_run_tested': 'int', 'total_run_responding_tags': 'int',
                    'total_run_passed_offline': 'int', 'total_run_passed_post_process': 'int',
                    'total_missing_labels': 'int', 'run_responsive_tags_yield': 'float',
                    'run_offline_yield': 'float', 'run_post_process_yield': 'float',
                    'ttfp_avg': 'float', 'conversion_type': 'str', 'inlay': 'str', 'test_suite': 'str',
                    'surface': 'str', 'to_print': 'bool', 'qr_validation': 'bool',
                    'print_pass_job_name': 'str', 'printing_format': 'str', 'external_id_prefix': 'str',
                    'external_id_suffix_init_value': 'int',
                    'coupler_partnumber': 'str',
                    'gw_version': 'str', 'py_wiliot_version': 'str', 'post_process_version': 'str',
                    'manufacturing_version': 'str', 'upload_date': 'timestamp', 'total_run_bad_printing': 'int',
                    'sensors_enable': 'bool', 'product_config': 'str',
                    'tag_sensor_type': 'str',
                    'temperature_sensor_avg': 'float', 'humidity_sensor_avg': 'float', 'light_intensity_sensor_avg': 'float',
                    'external_cap_sensor_freq_avg': 'float', 'num_pixels_per_asset': 'int'
                },
                'run_tests':
                {
                    'tester_run_id': 'long', 'common_run_name': 'str', 'test_num': 'int', 'test_name': 'str',
                    'test_tested': 'int', 'test_passed_offline': 'int',
                    'test_time_profile_period': 'int', 'test_time_profile_on_time': 'int',
                    'test_tx_power_ble_dbm': 'float', 'test_tx_power_lora_dbm': 'float',
                    'test_energizing_pattern': 'int', 'test_receive_ch': 'int',
                    'test_pl_delay': 'int', 'test_rssi_hw_threshold': 'int',
                    'test_rssi_acceptable_threshold': 'int',
                    'test_min_packets': 'int', 'test_max_time': 'float', 'test_post_delay': 'float',
                    'test_ttfp_lsl': 'float', 'test_ttfp_usl': 'float', 'test_tbp_min_lsl': 'float',
                    'test_tbp_min_usl': 'float', 'test_tbp_max_lsl': 'float', 'test_tbp_max_usl': 'float',
                    'test_tbp_avg_lsl': 'float', 'test_tbp_avg_usl': 'float',
                    'test_sprinkler_counter_max_lsl': 'int', 'test_sprinkler_counter_max_usl': 'int',
                    'test_time_between_cycles_lsl': 'float', 'test_time_between_cycles_usl': 'float',
                    'test_res_rssi_avg': 'float', 'test_res_tbp_avg': 'float',
                    'test_res_min_tx_frequency_last_avg': 'float'
                },
                'tag_locations':
                {
                    'tester_run_id': 'long', 'common_run_name': 'str', 'tag_run_location': 'int',
                    'tag_reel_location': 'int', 'total_test_duration': 'float', 'total_location_duration': 'float',
                    'status_offline': 'int', 'status_post_process': 'int', 'fail_bin': 'int', 'fail_bin_str': 'str',
                    'last_executed_test': 'int', 'external_id': 'str', 'qr_validated': 'bool',
                    'num_responding_tags': 'int', 'label_validated': 'str',  'wafer_sort_lot_id': 'str',
                    'wafer_sort_wafer': 'str', 'pixels_group_num': 'int', 'printed_shape': 'str', 
                    'wafer_sort_x_location': 'int', 'wafer_sort_y_location': 'int', 'wafer_sort_status': 'int'
                },
                'tag_location_tests':
                {
                    'tester_run_id': 'long', 'common_run_name': 'str', 'tag_run_location': 'int', 'test_num': 'int',
                    'test_status_offline': 'int', 'test_duration': 'float',
                    'received_packet_count': 'int', 'ttfp': 'float', 'tbp_avg': 'float', 'tbp_min': 'float',
                    'tbp_max': 'float', 'rssi_avg': 'float', 'rssi_std': 'float', 'min_tx_frequency_last': 'float',
                    'external_cap_sensor_freq_avg': 'float', 'external_cap_sensor_freq_min': 'float', 'external_cap_sensor_freq_max': 'float',
                    'internal_cap_sensor_freq_avg': 'float', 'internal_cap_sensor_freq_min': 'float', 'internal_cap_sensor_freq_max': 'float',
                    'total_cer': 'float', 'total_aux_meas_rate': 'float', 'num_packets': 'int', 'num_cycles': 'int'
                },
                'tag_test_packets':
                {
                    'tester_run_id': 'long', 'common_run_name': 'str', 'tag_run_location': 'int', 'test_num': 'int',
                    'packet_time': 'float', 'original_encrypted_packet': 'str', 'packet_status': 'str',
                    'test_mode': 'int', 'rssi': 'int', 'time_from_start': 'float', 'min_tx': 'float',
                    'packet_cntr': 'int', 'gpio4_sense': 'int', 'max_tx': 'float', 'current_cer': 'float',
                    'aux_meas_val': 'float', 'tbc': 'float', 'tbp': 'int', 'external_id': 'str',
                    'external_cap_sensor_freq': 'float', 'internal_cap_sensor_freq': 'float', 'external_res_sensor_freq': 'float', 'internal_res_sensor_freq': 'float',
                    'invalid_sensor_measurement': 'bool', 'adv_address': 'str', 'selected_tag': 'str'

                }
            }
    }
table_config['conversion_yield_test'] = table_config['yield_test']
table_config['conversion_yield_test']['runs']['lane_ids'] = 'str'