"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
import time
import sys
import numpy as np
import pandas as pd
from pandas.core.series import Series
import datetime
import re
import ast

from wiliot_testers.wiliot_tester_tag_result import FailBinSample
from wiliot_testers.post_process.utils.column_name_map import column_name_map
from wiliot_core import Packet, set_logger, IS_PRIVATE_INSTALLATION
if IS_PRIVATE_INSTALLATION:
    from wiliot_core import DecryptedTagCollection as TagCollection
else:
    from wiliot_core import TagCollection

LOGGER = None
try:
    if  sys.platform != 'linux':
        _, LOGGER = set_logger('LocalPP', 'local_pp_logs')
except:
    pass


alpha_packet_fields = ['common_run_name', 'external_id', 'selected_tag', 'fail_bin_str',
                       'test_start_time', 'trigger_time', 'test_end_time', 'adi_per_packet', 'tag_id']
wafer_sort_fields = ['wafer_sort_tag_id', 'wafer_sort_lot_id', 'wafer_sort_wafer', 'wafer_sort_soft_bin',
                     'wafer_sort_flow_version', 'wafer_sort_packet_version', 'wafer_sort_x_location',
                     'wafer_sort_y_location', 'wafer_sort_status']
min_external_id_characters = 8
TEST_TX_POWER_BLE_DBM = 22
TEST_TX_POWER_LORA_DBM = 29


def print_pp(msg):
    print(msg)
    try:
        if LOGGER is not None:
            LOGGER.info(msg)
    except:
        pass

def extract_unique_data(dict_in, name):
    """
    check if name exists in the dict_in according to the column_name_map,
    if it does, it check all values are the same and return the unique value
    :param dict_in:
    :type dict_in: dict or pd.DataFrame
    :param name:
    :type name: str
    :return:
    :rtype:
    """

    if name in column_name_map.keys():
        optional_names = column_name_map[name]
    else:
        optional_names = [name]

    name_str = None
    for name in optional_names:
        if name in dict_in.keys():
            name_str = name
            break

    if name_str is None:
        return None

    if isinstance(dict_in[name_str], list) or \
            (isinstance(dict_in[name_str], np.ndarray) and dict_in[name_str].size > 1) or \
            isinstance(dict_in[name_str], Series):
        unique_data = set(dict_in[name_str].copy())
        if len(unique_data) == 1:
            return unique_data.pop()
        else:
            # packets from the specified dict have different data
            return None
    elif isinstance(dict_in[name_str], np.ndarray):
        return dict_in[name_str].item()
    else:
        return dict_in[name_str]


def string_to_number(list_in, name):
    """

    :param list_in:
    :type list_in:
    :param name:
    :type name:str
    :return:
    :rtype: list
    """
    if isinstance(list_in, list):
        pass
    elif isinstance(list_in, np.ndarray):
        list_in = list_in.tolist()
    elif isinstance(list_in, str) or isinstance(list_in, np.str_):
        list_in = [str(list_in)]
    elif isinstance(list_in, int) or isinstance(list_in, float) or list_in is None:
        return [list_in]
    else:
        raise Exception('pp: string_to_number: unsupported list_in type: {} for list:{}'.format(type(list_in), list_in))

    if name in alpha_packet_fields:
        return list_in

    converted_list = []
    for element in list_in:
        if element == '':
            converted_list.append(None)
        elif (isinstance(element, str) or isinstance(list_in, np.str_)) and element.lower() != element.upper():
            # element contains letters
            converted_list.append(element)
        else:
            try:
                num_element = float(element)
                if num_element == float('nan') or num_element == float('inf'):
                    converted_list.append(element)
                else:
                    converted_list.append(num_element)
            except ValueError:
                converted_list.append(element)

    return converted_list


def get_group_id_reversed(group_id_list=None):
    """

    :param group_id_list: list of group ids
    :type group_id_list: list
    :return:
    :rtype:
    """
    if group_id_list is None:
        return None
    group_id_list = [g.lower() for g in group_id_list]
    return [group_id[-2:] + group_id[-4:-2] + group_id[-6:-4] for group_id in group_id_list]


def get_converted_flow_version(flow_ver_list=None):
    if flow_ver_list is None:
        return None
    converted_flow_ver = []
    for fv in flow_ver_list:
        fv = fv[2::]  # removing the '0x'
        converted_flow_ver.append((fv[:-2] + "." + fv[-2:]).upper())
    return converted_flow_ver


def build_table_for_cloud(dict_in=None, table_type=None):
    if dict_in is None or table_type is None:
        return None

    try_to_correct_names(dict_in, table_type)
    # rearrange dictionary to fit table config:
    sorted_data = arrange_table_col(dict_in=dict_in, table_col=list(table_type.keys()))
    # check col type
    col_type = check_table_type(sorted_data, table_type=table_type)
    # reformat to cloud structure:
    results_out = reformat_columns_to_row(sorted_data)
    if results_out is None or col_type is None:
        print_pp('problem occurred during build_table_for_cloud function')
        return None
    results_out['col_type'] = col_type
    results_out['table_scheme'] = {k: v for k, v in zip(results_out['col_name'], results_out['col_type'])}
    del results_out['col_name'], results_out['col_type']

    return results_out


def arrange_table_col(dict_in, table_col):
    """
    This function order the input dictionary according to the config file and makes sure all columns exist
    :param dict_in: dictionary contains all the data. each key is the column name and each key's value is a list
                    with all the elements
    :type dict_in: dict or pd.Series
    :param table_col: list with all the columns names with the correct order
    :type table_col: list
    :return: ordered dictionary with all the data
    :rtype: dict
    """
    ordered_dict = {}
    if isinstance(dict_in, pd.DataFrame):
        n_rows = max([1, len(dict_in)])
    elif isinstance(dict_in, dict):
        n_rows = max([1] + [len(v) for v in dict_in.values() if isinstance(v, (list, pd.Series))])
    else:
        n_rows = max([1] + [len(v) for k, v in dict_in.iteritems() if isinstance(v, pd.Series)])

    for k in table_col:
        if k in dict_in.keys():
            ordered_dict[k] = list(dict_in[k])
        else:
            ordered_dict[k] = [''] * n_rows

    return ordered_dict


def check_table_type(dict_in, table_type):
    """
    This function check if all element in each column has the desired data type. If not it fixes it
    :param dict_in: dictionary contains all the table columns, each key is a different column
    :type dict_in: dict
    :param table_type: dictionary so each key is the column name and each key's value is the column data type
    :type table_type: dict
    :return: list of the columns type (fixed the dict_in as a mutable variable)
    :rtype: list
    """
    col_type = []
    # check if a value is numpy:
    for key, col in dict_in.items():
        # check if column name exists in the process_table_config.py
        if key not in table_type.keys():
            print_pp('the following parameter will not be inserted to the table: {}'.format(key))
            continue
        for j, element in enumerate(col):
            error_msg = 'pp: check_table_type: we expected to get {} type for {} key, but got: {} (type {})'. \
                format(table_type[key], key, col[j], type(col[j]).__name__)
            # clean numpy types
            if type(element).__module__ == np.__name__:
                if 'str' in type(element).__name__:
                    col[j] = ''.join([char for char in element])
                elif 'float' in type(element).__name__:
                    col[j] = float(element)
                elif 'int' in type(element).__name__:
                    col[j] = int(element)
                elif 'ndarray' in type(element).__name__ and element.size == 1:
                    if 'float' in element.dtype.name:
                        col[j] = float(element)
                    elif 'int' in element.dtype.name:
                        col[j] = int(element)
                    else:
                        col[j] = str(element)
                else:
                    raise Exception("pp: check_table_type: element contains numpy type "
                                    "we didn't handle: " + type(element).__name__)
            # check the type:
            if type(col[j]).__name__ != table_type[key]:  # fix the dict if data type is not according to the config
                if table_type[key] == 'str':
                    if pd.isnull(col[j]):
                        col[j] = ''
                    else:
                        col[j] = str(col[j])
                else:
                    if table_type[key] == 'int' and type(col[j]).__name__ == 'float':
                        if np.isnan(element):
                            col[j] = None
                        elif col[j] is not None and col[j] % 1 == 0:
                            col[j] = int(col[j])  # fix pandas issue when empty cells exist, col is converted to float
                        else:
                            raise Exception(error_msg)

                    elif table_type[key] == 'float' and type(col[j]).__name__ == 'int':
                        col[j] = float(col[j])
                    elif table_type[key] == 'int' and type(col[j]).__name__ == 'NoneType':
                        pass  # None type is considered as int
                    elif table_type[key] == 'int' and type(col[j]).__name__ == 'bool':
                        col[j] = int(col[j])
                    elif table_type[key] == 'float' and type(col[j]).__name__ == 'NoneType':
                        col[j] = float('nan')
                    elif table_type[key] == 'long' and type(col[j]).__name__ == 'int':
                        pass
                    elif table_type[key] == 'bool' and type(col[j]).__name__ == 'NoneType':
                        pass
                    elif table_type[key] == 'timestamp' and type(col[j]).__name__ == 'NoneType':
                        pass
                    elif table_type[key] == 'timestamp' and type(col[j]).__name__ == 'str' and col[j] == '':
                        col[j] = None
                    elif type(col[j]).__name__ == 'str':
                        try:
                            if table_type[key] == 'int' or table_type[key] == 'long':
                                if col[j]:
                                    col[j] = int(float(col[j]))
                                else:
                                    col[j] = None
                            elif table_type[key] == 'float':
                                if col[j]:
                                    col[j] = float(col[j])
                                else:
                                    col[j] = float('nan')
                            elif table_type[key] == 'bool':
                                if col[j].lower() == 'no' or col[j].lower() == 'false':
                                    col[j] = False
                                elif col[j].lower() == 'yes' or col[j].lower() == 'true':
                                    col[j] = True
                                else:
                                    raise Exception(error_msg)
                            elif table_type[key] == 'timestamp':
                                try:
                                    col[j] = convert_date(col[j])
                                except ValueError:
                                    raise Exception(error_msg + '(expected format: %Y-%m-%d %H:%M:%S.%f)')

                        except Exception as e:
                            raise Exception(error_msg + f'due to {e}')
                    else:
                        raise Exception(error_msg)
            if table_type[key] == 'float':
                col[j] = round(col[j], 2)

        col_type.append(table_type[key])

    return col_type


def reformat_columns_to_row(dict_in):
    """
    This function reformat dict of columns to rows
    :param dict_in: each key of the dict_in is the column name and all the keys contains the same number of elements
    :type dict_in: dict
    :return: dict with key of the column name ('col_name') and key with a list of all the rows ('rows'),
             so each list's element is a row
    :rtype: dict
    """
    all_values = []
    # calculate the number of rows
    rows_length = [len(x) for x in dict_in.values() if isinstance(x, list)]
    if rows_length:
        n_rows = max(rows_length)
    else:
        n_rows = 1
    for k, val in dict_in.items():
        # check if all the columns has the same number of elements:
        if not (isinstance(val, list) or isinstance(val, tuple)):
            val = [val] * n_rows
        elif not len(val):
            val = [None] * n_rows
        else:
            if len(val) != n_rows:
                print_pp('col {}: expect for {} rows, but val contain {} rows\nval:{}'.format(k, n_rows, len(val), val))
                return None

        all_values.append(val)

    dict_out = {'col_name': list(dict_in.keys()),
                'rows': list(map(list, zip(*all_values)))}

    return dict_out


def convert_date(col_j):
    try:
        # Attempt to parse string with microseconds
        return datetime.datetime.strptime(col_j, "%Y-%m-%d %H:%M:%S.%f")
    except ValueError:
        # If that fails, try to parse without microseconds
        return datetime.datetime.strptime(col_j, "%Y-%m-%d %H:%M:%S")


def get_payload(original_encrypted_packet):
    encrypted_payload_list = []
    for sprinkler in original_encrypted_packet:
        p = Packet(sprinkler)
        encrypted_payload_list.append(p.get_payload())
    return encrypted_payload_list

def snake_to_camel_case(word: str):
    """
    Convert a snake_case string to camelCase.
    :param word: The snake_case string to convert.
    :return: The converted camelCase string.
    """
    return ''.join(x.capitalize() if i else x for i, x in enumerate(word.split('_')))

def snake_to_camel_dict_keys(dict_in):
    """
    this function copied the input dictionary and replace the keys to camel case
    :param dict_in: input dictionary
    :type dict_in: dict
    :return: same dictionary with camel case keys
    :rtype: dict
    """
    dict_out = {}
    for key, val in dict_in.items():  # copy the raw data
        key = snake_to_camel_case(key)
        dict_out[key] = val
    return dict_out


def camel_case_to_snake_case(word: str):
    return re.sub(r'(?<!^)(?=[A-Z])', '_', word).lower()


def check_duplication(packet_df):
    packet_df_selected = packet_df[packet_df['selected_tag'] ==
                                   packet_df['adv_address']].drop_duplicates(subset=['tag_run_location'])

    duplicated_tag_id = packet_df_selected['tag_id'][packet_df_selected['tag_id'].duplicated(keep=False)].dropna()
    duplicated_tag_id = duplicated_tag_id[duplicated_tag_id != '']
    duplicated_ex_id = packet_df_selected['external_id'][
        packet_df_selected['external_id'].duplicated(keep=False)].dropna()
    duplicated_ex_id = duplicated_ex_id.loc[(duplicated_ex_id != 'None') & (duplicated_ex_id != '') &
                                            (duplicated_ex_id != 'N')]
    location_with_duplication = {}
    if len(duplicated_tag_id):
        tag_id_dup_loc = list(packet_df_selected['tag_run_location'][duplicated_tag_id.index])
        print_pp(f'The same tag id was selected in different location: {tag_id_dup_loc}')
        location_with_duplication = {dup_loc: 'tag_id' for dup_loc in tag_id_dup_loc}
    if len(duplicated_ex_id):
        ex_id_dup_loc = list(packet_df_selected['tag_run_location'][duplicated_ex_id.index])
        print_pp(f'The same external id was found in different locations: {ex_id_dup_loc}')
        location_with_duplication = {**location_with_duplication, **{dup_loc: 'external_id' for dup_loc in ex_id_dup_loc}}
    
    return location_with_duplication


def time_diff_between_two_strings(late=None, early=None):
    time_to_covert = [late, early]
    t_conv_arr = []
    for t_str in time_to_covert:
        if t_str is None or t_str == '':
            return None
        try:
            t_conv = datetime.datetime.strptime(t_str, "%Y-%m-%d %H:%M:%S.%f")
        except ValueError:
            try:
                t_conv = datetime.datetime.strptime(t_str, "%Y-%m-%d %H:%M:%S")
            except Exception as e:
                print_pp('could not convert time string:{}, due to {}'.format(t_str, e))
                return None
        except Exception as e:
            print_pp('could not convert time string:{}, due to {}'.format(t_str, e))
            return None
        t_conv_arr.append(t_conv)
    time_diff = t_conv_arr[0] - t_conv_arr[1]
    return time_diff.total_seconds()


def parse_test_param(test_param_str):
    """

    :param test_param_str:
    :type test_param_str: str
    :return:
    :rtype: dict
    """

    def convert_to_numeric(str):
        """
        convert string to array, int or float
        :param str:
        :type str: str
        :return:
        :rtype:
        """
        p_str = None
        try:
            p_str = int(str)
        except Exception as e:
            pass
        if p_str is None:
            try:
                p_str = float(str)
            except Exception as e:
                pass
        if p_str is None:
            p_str = str.strip("'")
        return p_str

    def add_value_to_dict(dict_in, field_name, val_in):
        if isinstance(val_in, list) and len(val_in) == 2 \
                and not isinstance(convert_to_numeric(val_in[0]), str) \
                and not isinstance(convert_to_numeric(val_in[1]), str):
            if field_name + '_l' in dict_in:
                dict_in[field_name + '_l'].append(val_in[0])
                dict_in[field_name + '_u'].append(val_in[1])
            else:
                dict_in[field_name + '_l'] = [val_in[0]]
                dict_in[field_name + '_u'] = [val_in[1]]
                if field_name in dict_in.keys():
                    del dict_in[field_name]
        elif field_name not in dict_in.keys():
            dict_in[field_name] = [val_in]
        else:
            dict_in[field_name].append(val_in)

    test_param = ''
    try:
        test_param_str = test_param_str.replace(':true', ':"true"').replace(':false', ':"false"')
        test_param = ast.literal_eval(test_param_str)
        n_tests = len(test_param['tests'])
        test_param_dict = {k: [v] * n_tests for k, v in test_param.items() if k != 'tests'}
        all_keys = []
        all_sub_keys = []
        for test in test_param['tests']:
            all_keys += list(test.keys())
            for k, v in test.items():
                if isinstance(v, dict):
                    for k2, v2 in v.items():
                        if isinstance(v2, list):
                            all_sub_keys += ['{}_{}_l'.format(k, k2), '{}_{}_u'.format(k, k2)]
                        else:
                            all_sub_keys += ['{}_{}'.format(k, k2)]
        all_keys = list(set(all_keys))
        all_sub_keys = list(set(all_sub_keys))
        all_keys += all_sub_keys  # adding the sub keys at the end

        for k in all_keys:
            if k not in test_param_dict.keys():
                test_param_dict[k] = []
            for test_num, test in enumerate(test_param['tests']):
                if k in test.keys():
                    if isinstance(test[k], dict):
                        for k2, v2 in test[k].items():
                            add_value_to_dict(test_param_dict, k + '_' + k2, v2)
                    else:
                        add_value_to_dict(test_param_dict, k, test[k])
                else:
                    found_field = False
                    for field_name in test_param_dict.keys():
                        if k == field_name and len(test_param_dict[field_name]) >= test_num + 1:
                            found_field = True
                            break
                    if not found_field:
                        test_param_dict[k].append(None)
            if k in test_param_dict.keys() and len(test_param_dict[k]) == 0:
                del test_param_dict[k]
    except Exception as e:
        raise Exception('pp: parse_test_param: from the follow string: {}, '
                        'we got the following exception:{}'.format(test_param, e))

    return test_param_dict


def calculate_run_time(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        run_time = end_time - start_time
        print_pp(f"{func.__name__} took {round(run_time, 2)} seconds to run.")
        return result

    return wrapper


def add_row_to_dict(row, dic):
    for k, v in row.items():
        dic[k].append(v)


def convert_to_pandas_df(df):
    if hasattr(df, 'sparkSession') and hasattr(df, 'toPandas'):  # check if spark df
        df = df.toPandas()
    return df


def validate_wafer_sort_data(df, wafer_sort_cols):
    if df is not None and not all(col in df.columns for col in wafer_sort_cols):
        raise Exception(f"not all columns {wafer_sort_cols} exist in the given dataframe")


def try_to_correct_names(dict_in, table_type):
    for col in table_type:
        if col in column_name_map:
            optional_names = column_name_map[col]
            for name in optional_names:
                if name in dict_in:
                    dict_in[col] = dict_in[name]
                    break


def cast_columns(df, cols, to_cast):
    for col in cols:
        if col in df.columns:
            df[col] = df[col].astype(to_cast)
        else:
            if to_cast == float:
                df[col] = float('nan')
            elif to_cast == str:
                df[col] = ''
            else:
                df[col] = None



def is_number(num):
    return num is not None and str(num).lower() != 'nan'


def get_failbin_sample(value):
    for member in FailBinSample:
        if member.value == value:
            return member.name
    return None


def _do_analysis(df_to_calc):
    tc = TagCollection()
    new_df = tc.df_analysis(packet_df=df_to_calc, assume_brownout=True)
    return new_df


def add_calculated_data_per_packet(df_to_agg, groups):
    analyzed_attr = ['moving_mean_cer', 'current_cer',
                     'moving_mean_per_per_cycle', 'current_per_per_cycle',
                     'moving_mean_n_packet_per_cycle', 'current_n_packet_per_cycle',
                     'tbc', 'packet_cntr_normalized', 'aux_meas_counter']
    df_group = df_to_agg.groupby(groups)
    analyzed_df = pd.DataFrame()
    for _, df_to_calc in df_group:
        if df_to_calc.empty:
            continue

        try:
            new_df = _do_analysis(df_to_calc)
            new_df.set_index(df_to_calc.index, inplace=True)
            if not set(analyzed_attr).issubset(new_df.keys()):
                for att in analyzed_attr:
                    if att not in new_df.keys():
                        new_df.insert(loc=len(new_df.columns), column=att, value=float('nan'))
        except Exception as e:
            print_pp(f'error during add_calculated_data_per_packet: {e}\nfor df:{df_to_calc}')
            continue
        analyzed_df = pd.concat([analyzed_df, new_df[analyzed_attr]], axis=0)
    df_to_agg = pd.concat([df_to_agg, analyzed_df], axis=1)

    return df_to_agg
