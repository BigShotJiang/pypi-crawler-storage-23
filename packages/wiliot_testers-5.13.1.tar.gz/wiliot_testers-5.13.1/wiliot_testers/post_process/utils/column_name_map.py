"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""

column_name_map = {
    'inlay_type': ['inlay', 'inlay_type', 'antennaType', 'antenna_type', 'inlayType'],
    'uid': ['uid', 'tag_id'],
    'common_run_name': ['common_run_name', 'commonRunName'],
    'tag_run_location': ['tag_run_location', 'tag_location', 'tagLocation'],
    'status_offline': ['status_offline', 'chosenTagStatus'],
    'fail_bin': ['fail_bin', 'chosenTagStatus'],
    'external_id': ['external_id', 'externalId'],
    'selected_tag': ['selected_tag', 'chosenTagInLocation'],
    'internal_temperature': ['internal_temperature', 'temperature'],
    'temperature_from_sensor': ['temperature_from_sensor', 'temperature_from_sensor_last', 'sensor_temperature'],
    'packet_version': ['packet_ver', 'packet_version'],
    'flow_version': ['flow_ver', 'flow_version'],
    'transmitted_adva': ['transmitted_adva', 'adv_address'],
    'test_name': ['name'],
    'test_status_offline': ['test_status'],
    'received_packet_count': ['num_packets'],
    'received_cycle_count': ['num_cycles'],
    'test_time_profile_period': ['timeProfile_u'],
    'test_time_profile_on_time': ['timeProfile_l'],
    'test_energizing_pattern': ['energizingPattern'],
    'test_receive_ch': ['rxChannel'],
    'test_pl_delay': ['plDelay'],
    'test_min_packets': ['minPackets'],
    'test_max_time': ['maxTime'],
    'test_post_delay': ['delayBeforeNextTest'],
    'test_ttfp_lsl': ['ttfp_l', 'quality_param_ttfp_l'],
    'test_ttfp_usl': ['ttfp_u', 'quality_param_ttfp_u'],
    'test_tbp_min_lsl': ['tbp_min_l', 'quality_param_tbp_min_l'],
    'test_tbp_min_usl': ['tbp_min_u', 'quality_param_tbp_min_u'],
    'test_tbp_max_lsl': ['tbp_max_l', 'quality_param_tbp_max_l'],
    'test_tbp_max_usl': ['tbp_max_u', 'quality_param_tbp_max_u'],
    'test_tbp_avg_lsl': ['tbp_mean_l', 'quality_param_tbp_mean_l'],
    'test_tbp_avg_usl': ['tbp_mean_u', 'quality_param_tbp_mean_u'],
    'test_sprinkler_counter_max_lsl': ['sprinkler_counter_max_l', 'quality_param_sprinkler_counter_max_l'],
    'test_sprinkler_counter_max_usl': ['sprinkler_counter_max_u', 'quality_param_sprinkler_counter_max_u'],
    'test_res_rssi_avg': ['rssi_mean'],
    'test_res_tbp_avg': ['tbp_mean'],
    'rssi_avg': ['rssi_mean'],
    'tbp_avg': ['tbp_mean'],
    'first_packet_counter': ['packet_counter_first'],
    'last_packet_counter': ['packet_counter_last'],
    'packet_counter': ['packet_counter', 'packet_cntr'],
    'min_tx_frequency_last': ['min_tx_last'],
    'packets_per_cycle_avg': ['sprinkler_counter_mean'],
    'packets_per_cycle_std': ['sprinkler_counter_std'],
    'internal_temperature_avg': ['temperature_mean'],
    'aux_meas_avg': ['axu_meas_mean', 'aux_meas_val_mean'],
    'total_location_duration': ['total_location_duration', 'total_run_duration'],
    'test_rssi_hw_threshold': ['rssiThresholdHW'], 'test_rssi_acceptable_threshold': ['rssiThresholdSW'],
    'time_between_cycles_avg': ['tbc_mean'],
    'state': ['state(tbp_exists:0,no_tbp:-1,no_ttfp:-2,dup_adv_address:-3)'],
    'external_sensor': ['external_sensor_val', 'external_sensor'],
    'total_run_advas': ['total_run_responding_tags'],
    'run_yield': ['run_yield', 'yield'],
    'energizing_pattern': ['energizing_pattern', 'energy_pattern_val', 'gw_energy_pattern'],
    'min_tx_frequency': ['min_tx_frequency', 'min_tx'],
    'temperature_sensor': ['temperature_from_sensor'],
    'current_cer': ['current_cer', 'moving_mean_cer'],
    'n_exit_test_mode': ['rc_sensor_acc'],  # relevant only for test mode
    'total_aux_meas_rate': ['total_aux_meas_rate', 'aux_meas_rate_total'],
    'need_to_associate': ['need_to_associate', 'do_association'],

}
