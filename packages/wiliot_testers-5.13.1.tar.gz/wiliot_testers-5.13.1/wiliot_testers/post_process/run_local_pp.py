"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
import os
from smart_open import smart_open
import datetime
import re
import csv

from wiliot_core import IS_PRIVATE_INSTALLATION, GW_PACKET_LEN, PacketList, WiliotDir
from wiliot_testers.utils.get_version import get_version
from wiliot_testers.post_process.utils.post_process_tools import print_pp
if IS_PRIVATE_INSTALLATION:
    from wiliot_core import DecryptedPacketList

MAX_PATH_CHARS = 260


class LocalPostProcess(object):
    def __init__(self):
        pass

    @staticmethod
    def camel_case_to_snake_case(word: str):
        return re.sub(r'(?<!^)(?=[A-Z])', '_', word).lower()

    def csv_to_dict(self, file_path=None):
        if file_path:
            with smart_open(file_path, 'r') as f:
                reader = csv.DictReader(f, delimiter=',')
                col_names = [{col_name.split('\ufeff')[-1]: col_name} for col_name in reader.fieldnames]
                data_out = {self.camel_case_to_snake_case(list(col.keys())[0]): [] for col in col_names}
                for row in reader:
                    for col in col_names:
                        data_out[self.camel_case_to_snake_case(list(col.keys())[0])].append(
                            row[list(col.values())[0]])
            return data_out
        else:
            raise Exception('No path supplied to read csv file')

    @staticmethod
    def get_decrypt_packet(de_packet):
        if IS_PRIVATE_INSTALLATION:
            packet_str = de_packet.decoded_data['decrypted_packet']
        else: 
            packet_str = de_packet.get_packet_string()
        match = re.findall(r'"([^"]+)"', packet_str)
        return match[0][:-GW_PACKET_LEN] if match else ''

    def do_decryption(self, raw_data):
        de_p = DecryptedPacketList() if IS_PRIVATE_INSTALLATION else PacketList()
        packet_df_in = pd.DataFrame(raw_data)
        if 'raw_packet' in packet_df_in.columns and 'gw_packet' not in packet_df_in.columns:
            packet_df_in['gw_packet'] = ''
        de_p = de_p.import_packet_df(packet_df=packet_df_in, import_all=True, verbose=False, ignore_crc=True)
        
        cols_to_rename = {'commonRunName': 'common_run_name', 'encryptedPacket': 'encrypted_packet', 'externalId': 'external_id'}
        for p in de_p:
            p.add_custom_data(custom_data={'original_encrypted_packet': self.get_decrypt_packet(p)})
            for c_orig, c_new in cols_to_rename.items():
                if c_orig in p.custom_data:
                    p.custom_data[c_new] = p.custom_data.pop(c_orig)
            if not IS_PRIVATE_INSTALLATION:
                p.decoded_data['tag_id'] = p.get_adva()
                p.add_custom_data({'decrypted_packet': p.get_packet_string(),
                                   'tag_id': str(p.get_adva()).lower()})
        return de_p

class GenerateLocalResults(object):
    def __init__(self, path_in):
        self.common_run_name = self.get_common_run_name(path_in)
        self.results_path, self.partner_results_path = self.get_result_path(path_in)

    @staticmethod
    def get_common_run_name(path_in):
        return os.path.basename(path_in).split('@')[0]

    @staticmethod
    def get_result_path(path_in):
        dir_name = os.path.dirname(path_in)
        folder_name = f'pp_results_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}'
        d = WiliotDir()
        pp_tester_folder = os.path.join(d.get_wiliot_root_app_dir(),
                                        'local_pp_results', 
                                        os.path.basename(os.path.dirname(dir_name)),
                                        os.path.basename(dir_name),
                                        get_version(),
                                        )
        pp_tester_path = os.path.join(pp_tester_folder, folder_name)
        ppfp_tester_path = os.path.join(pp_tester_folder, folder_name.replace('pp', 'ppfp'))
        os.makedirs(pp_tester_path, exist_ok=True)
        os.makedirs(ppfp_tester_path, exist_ok=True)

        return pp_tester_path, ppfp_tester_path

    @staticmethod
    def get_valid_path_length(path_in):
        if len(path_in) >= MAX_PATH_CHARS:
            file_name = os.path.basename(path_in)
            file_name = file_name[(len(path_in) - MAX_PATH_CHARS + 1):]
            path_in = os.path.join(os.path.dirname(path_in), file_name)
        return path_in

    def generate_tables(self, res_in):
        for key in res_in.keys():
            file_path = self.get_valid_path_length(os.path.join(self.results_path, f'{self.common_run_name}@{key}.csv'))
            with open(file_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(list(res_in[key]['table_scheme'].keys()))
                writer.writerow(list(res_in[key]['table_scheme'].values()))
                writer.writerows(res_in[key]['rows'])
                f.close()
            print_pp(f'generated table for {key} at {file_path}')

    def generate_serialization_table(self, res_in):
        if res_in is not None:
            file_path = self.get_valid_path_length(
                os.path.join(self.results_path, f'{self.common_run_name}@serialization_table.csv'))
            with open(file_path, 'w', newline='') as f:
                csv_writer = csv.DictWriter(f, res_in['data'][0].keys())
                csv_writer.writeheader()
                for serialization_dict in res_in['data']:
                    csv_writer.writerow({k: v for k, v in serialization_dict.items()})
                f.close()
            print_pp(f'generated serialization table at {file_path}')

    def generate_change_status_table(self, res_in):
        if res_in is not None:
            file_path = self.get_valid_path_length(
                os.path.join(self.results_path, f'{self.common_run_name}@status_change_table.csv'))
            with open(file_path, 'w',
                      newline='') as f:
                csv_writer = csv.DictWriter(f, res_in[0].keys())
                csv_writer.writeheader()
                for change_status_dict in res_in:
                    csv_writer.writerow({k: v for k, v in change_status_dict.items()})
                f.close()
            print_pp(f'generated status change table at {file_path}')

    def generate_partners_tables(self, res_in):
        if res_in is not None:
            for key in res_in.keys():
                file_path = self.get_valid_path_length(
                    os.path.join(self.partner_results_path, f'{self.common_run_name}@{key}_partners.csv'))
                with open(file_path, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(list(res_in[key]['table_scheme'].keys()))
                    writer.writerow(list(res_in[key]['table_scheme'].values()))
                    writer.writerows(res_in[key]['rows'])
                    f.close()
            print_pp(f'generated partners tables for {key} at {file_path}')

    def generate_temperature_calib_table(self, res_in):
        if res_in is not None:
            file_path = self.get_valid_path_length(
                os.path.join(self.results_path, f'{self.common_run_name}@temperature_calibration.csv'))
            res_in.to_csv(file_path, index=False)
            print_pp(f'generated temperature calibration table at {file_path}')

    def generate_sensors_results_table(self, res_in):
        if res_in is not None:
            file_path = self.get_valid_path_length(
                os.path.join(self.results_path, f'{self.common_run_name}@sensors_results.csv'))
            res_in.to_csv(file_path, index=False)
            print_pp(f'generated sensors results table at {file_path}')

if __name__ == '__main__':
    import pandas as pd
    import sys
    import pathlib
    import argparse
    import traceback

    from wiliot_testers.utils.get_version import get_version
    from wiliot_tools.utils.wiliot_gui.wiliot_gui import WiliotGui
    from wiliot_testers.post_process.generate_testers_database import generate_testers_database, process_type_mapping


    def get_files_path():
        """
        opens GUI for selecting a file and returns it
        """
        # Define the window's contents
        layout_dict = {
            'run_data_file': {'text': 'run_data file for post-process:', 'value': '', 'widget_type': 'file_input'},
            'packets_data_file': {'text': 'packets_data file for post-process:', 'value': '',
                                  'widget_type': 'file_input'},
            'data_folder': {'text': '[OPTIONAL] folder for post-process:', 'value': '', 'widget_type': 'file_input', 'options': 'folder'},
            'tester_type': {'text': 'Tester type?', 'value': "offline_test", 'widget_type': 'combobox', 'options': tuple(process_type_mapping.keys())},
            'is_test_mode': {'value': False}
        }
        gui = WiliotGui(params_dict=layout_dict, title='Run Local PP')
        values_out = gui.run()
        return values_out

    local_pp = LocalPostProcess()

    parser = argparse.ArgumentParser(description='Run Local Post-Process')
    parser.add_argument('-r', '--run_data_file', default=None, help='run data file path')
    parser.add_argument('-p', '--packets_data_file', default=None, help='packets data file path')
    parser.add_argument('-f', '--data_folder', default=None, help='data folder with all relevant files')
    parser.add_argument('-t', '--tester_type', default='offline_test', help=f'tester_type options; {tuple(process_type_mapping.keys())}')
    parser.add_argument('-tm', '--is_test_mode', default=False, help=f'is data with test mode packet (different parsing)')

    args = parser.parse_args()
    values = None
    if args.data_folder is not None or args.packets_data_file is not None:
        values = {'run_data_file': args.run_data_file, 'packets_data_file': args.packets_data_file, 'data_folder': args.data_folder,
                  'tester_type': args.tester_type, 'is_test_mode': args.is_test_mode}
    else:
        values = get_files_path()
    if values is None:
        print_pp('user exited the program')
        sys.exit(0)

    if os.path.isdir(values['data_folder']):
        folder_base = pathlib.Path(values['data_folder'])
        packets_data_list = list(folder_base.rglob("*@packets_data.csv"))
        run_data_list = list(folder_base.rglob("*@run_data.csv"))
    else:
        packets_data_list = [pathlib.Path(values['packets_data_file'])]
        run_data_list = [pathlib.Path(values['run_data_file'])]

    for current_run in run_data_list:
        print_pp(f'processing: {current_run}')
        try:
            common_run_name = current_run.name.split('@')[0]
            run_path = current_run.__str__()
            current_packets = [p for p in packets_data_list if common_run_name in p.name]
            if len(current_packets) != 1:
                raise Exception(f'did not found unique packets file per run data: {current_packets}')
            packet_path = current_packets[0].__str__()

            process_type = values['tester_type']

            print_pp('pywiliot version: {}'.format(get_version()))
            # de_packet_list = DecryptedPacketList()
            # de_packet_list = de_packet_list.import_packet_df(path=packet_path, import_all=True)
            print_pp('apply post process on: {}'.format(packet_path))
            packet_data = local_pp.csv_to_dict(file_path=packet_path)
            run_data = local_pp.csv_to_dict(file_path=run_path)

            # # # #### example for cloud ####
            de_packet_list = local_pp.do_decryption(packet_data)  # offline=True, offline_path='export (56).csv'
            print_pp("Decryption done")
            # # ### end of example #####
            # wafer_sort_test_file = pd.read_csv('wafer sort data for PP.csv')
            wafer_sort_test_file = None
            res, serialization_table, change_status_table, partner_results, force_serialization, sensors_results = \
                generate_testers_database(run_data=run_data, packet_data=packet_data,
                                          decoded_data=de_packet_list, process_type=process_type,
                                          tester_run_id=5100210002, manufacturing_ver="0.0.0",
                                          wafer_sort_data=wafer_sort_test_file,
                                          is_test_mode=values['is_test_mode'])
            print_pp(f'force serialization: {force_serialization}')
            if res is None:
                print_pp('no results generated')
                continue
            # generate the csv files:
            local_res = GenerateLocalResults(path_in=packet_path)
            if IS_PRIVATE_INSTALLATION:
                local_res.generate_tables(res)

            # print serialization and status_change tables:
            local_res.generate_serialization_table(serialization_table)
            local_res.generate_change_status_table(change_status_table)

            # generate the csv files for partners:
            local_res.generate_partners_tables(partner_results)

            # generate the csv file for sensors scylla:
            if IS_PRIVATE_INSTALLATION:
                local_res.generate_sensors_results_table(sensors_results)

            # generate the csv file for temperature calibration:
            # local_res.generate_temperature_calib_table(temperature_calibration_df)
            # if temperature_calibration_df is not None:
            #     t = TemperatureCalibration(df_in=temperature_calibration_df)
            #     res = t.get_results()
            #     print_pp(f'temperature calibration results:\n{res.keys() if res is not None else res}')

        except Exception as e:
            print_pp(f'got exception during processing {current_run.name}: {e}, {traceback.format_exc()}')

    print_pp('done')
