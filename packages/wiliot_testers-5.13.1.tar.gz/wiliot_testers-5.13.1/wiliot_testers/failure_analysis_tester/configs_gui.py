"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""

import datetime
import json
from pathlib import Path

from wiliot_core import WiliotDir
from wiliot_testers.utils.get_version import get_version
from wiliot_tools.utils.wiliot_gui.wiliot_gui import WiliotGui

TESTER_NAME = 'failure_analysis'
VER = get_version()
wiliot_dir = WiliotDir()
wiliot_dir.create_tester_dir(TESTER_NAME)
FA_TEST_DIR = Path(wiliot_dir.get_tester_dir(TESTER_NAME))
TIME_NOW = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
CONFIGS_DIR = FA_TEST_DIR / 'configs'
CONFIGS_DIR.mkdir(exist_ok=True)
CONFIG_FILE = Path(__file__).parent / 'configs' / 'config.json'
HW_CONFIG_FILE = CONFIGS_DIR / 'hw_config.json'
RELAY_CONFIG = {
    'LORA': '0000',
    'BLE': '0100',
    'TX': '1100',
    'VDD_CAP': '1110',
    # 'LC': '1111',
}
MANDATORY_PP_FIELDS = ['common_run_name', 'tag_alias',
                       'LORA_percent_pass', 'BLE_percent_pass', 'TX_percent_pass', 'VDD_CAP_percent_pass',
                       'capacitance_nF', 'hardware_vstart_mid', 'software_vstart_mid', 'hardware_vstart_high', 'software_vstart_high', 'avg_drop']


def get_visa_address(force_gui=False):
    if not force_gui and HW_CONFIG_FILE.is_file():
        with open(HW_CONFIG_FILE, 'r') as jsonFile:
            hw_config = json.load(jsonFile)
            if 'visa_addr' in hw_config:
                return hw_config['visa_addr']
    visa_addr = get_new_visa_address()
    with open(HW_CONFIG_FILE, 'w') as jsonFile:
        json.dump({'visa_addr': visa_addr}, jsonFile, indent=4)
    return visa_addr

def get_new_visa_address():
    get_visa_address_layout = {
        'title': {
            'value': f'Could not connect to SMU,\n'
                        f'Please input SMU address\n'
                        f'USB connection is in format: USB0::2391::52760::MY51143992::0::INSTR\n'
                        f'TCP connection is in format: TCPIP0::192.168.48.83::inst0::INSTR\n',
            'text': '',
            'widget_type': 'label',
        },
        'visa_addr': {
            'value': '',
            'text': '',
            'widget_type': 'entry',
        },
    }
    get_visa_address_gui = WiliotGui(params_dict=get_visa_address_layout, do_button_config=True, title='Valid Setup Association and Verification')
    vals = get_visa_address_gui.run()
    return vals['visa_addr']
