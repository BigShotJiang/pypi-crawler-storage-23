import numpy as np


def find_pairs_refined(times, volts, smooth_window=5, refine_radius=2, min_sep=2):
    n = len(volts)
    vraw = np.asarray(volts, dtype=float)

    # centered rolling mean (guide only; preserve edges with raw values)
    if smooth_window and smooth_window > 1 and (smooth_window % 2 == 1):
        from pandas import Series
        vguide = Series(vraw).rolling(window=smooth_window, center=True).mean().to_numpy()
        vguide = np.array(vguide, copy=True)
        nanm = np.isnan(vguide)
        vguide[nanm] = vraw[nanm]
    else:
        vguide = vraw.copy()

    # candidate peaks on guide
    cand_peaks = [i for i in range(1, n - 1)
                    if vguide[i] >= vguide[i - 1] and vguide[i] > vguide[i + 1]]

    def refine_peak(idx):
        lo = max(0, idx - refine_radius)
        hi = min(n, idx + refine_radius + 1)
        return lo + int(np.argmax(vraw[lo:hi]))

    # refine all peaks, remove dupes, enforce minimal separation
    rpeaks = []
    last = -10 ** 9
    for p in cand_peaks:
        rp = refine_peak(p)
        if rp - last >= min_sep:
            rpeaks.append(rp)
            last = rp
    rpeaks = sorted(set(rpeaks))

    # default pairs: global-min between consecutive peaks
    pairs = []
    for i in range(len(rpeaks) - 1):
        a, b = rpeaks[i], rpeaks[i + 1]
        if b <= a + 1:
            continue
        seg = vraw[a + 1:b]
        if seg.size == 0:
            continue
        valley = a + 1 + int(np.argmin(seg))
        pairs.append((a, valley))
    return pairs, rpeaks

def calc_system_test_params(t, v, pairs_def, refined_peaks, early_window_s, early_drop_min, drop_threshold, drop_start, drop_end):
    # ---- prefer the first local-min ("early notch") after each peak ----
    sig_pairs = []
    for i, (pk, fallback_valley) in enumerate(pairs_def):
        # search region: from pk+1 forward until next refined peak (exclusive)
        next_pk = refined_peaks[i + 1] if (i + 1) < len(refined_peaks) else None
        end_idx = next_pk if next_pk is not None else len(v)

        # find local minima in that region (strict)
        local_mins = []
        for j in range(pk + 1, end_idx - 1):
            if v[j] < v[j - 1] and v[j] <= v[j + 1]:
                local_mins.append(j)

        chosen_valley = fallback_valley
        # Try to grab the *first* notch that is within early_window_s and big enough
        if local_mins:
            for vm in local_mins:
                dt = t[vm] - t[pk]
                dv = v[pk] - v[vm]
                if dt <= early_window_s and dv >= early_drop_min:
                    chosen_valley = vm
                    break  # prefer the first qualifying notch

        # apply normal (larger) threshold so we don't keep noise later on
        if (v[pk] - v[chosen_valley]) >= drop_threshold:
            sig_pairs.append((pk, chosen_valley))

    if len(sig_pairs) < 2:
        print("[WARNING] Not enough significant drops after notch preference/thresholding.")
        return

    # ---- split MID/HIGH by peak voltage gap (robust across datasets) ----
    peak_voltages = np.array([v[pk] for pk, _ in sig_pairs], dtype=float)
    u = np.unique(peak_voltages)
    if len(u) == 1:
        thr = u[0] + 1e-9
    else:
        u.sort();
        gaps = np.diff(u);
        j = int(np.argmax(gaps));
        thr = 0.5 * (u[j] + u[j + 1])

    labels = ["MID" if v[pk] < thr else "HIGH" for pk, _ in sig_pairs]

    # ---- Vstarts: first two per gear ----
    mid_pairs = [(pk, va) for (pk, va), lab in zip(sig_pairs, labels) if lab == "MID"][:2]
    high_pairs = [(pk, va) for (pk, va), lab in zip(sig_pairs, labels) if lab == "HIGH"][:2]

    ret_dict = {}

    ret_dict['hardware_vstart_mid'] = float(v[mid_pairs[0][0]]) if len(mid_pairs) > 0 else None
    ret_dict['software_vstart_mid'] = float(v[mid_pairs[1][0]]) if len(mid_pairs) > 1 else None
    ret_dict['hardware_vstart_high'] = float(v[high_pairs[0][0]]) if len(high_pairs) > 0 else None
    ret_dict['software_vstart_high'] = float(v[high_pairs[1][0]]) if len(high_pairs) > 1 else None

    # ---- Average TX drop over requested window (in overall order) ----
    rng_pairs = sig_pairs[max(0, drop_start - 1):min(len(sig_pairs), drop_end)]
    drops = [float(v[pk] - v[va]) for pk, va in rng_pairs]
    ret_dict['avg_drop'] = float(np.mean(drops)) if drops else None

    return ret_dict

def create_capacitance_chart(cap_nF:float, control_limits_nF:list) -> tuple[str, str]:
    if cap_nF is None or np.isnan(cap_nF):
        return "N/A", "N/A"
    half_range = (control_limits_nF[1] - control_limits_nF[0]) / 4
    verdict = 'Pass' if control_limits_nF[0] <= cap_nF <= control_limits_nF[1] else 'Fail'
    chart_str = "(-----)"
    if verdict == 'Pass':
        idx = np.floor(5 * (cap_nF - control_limits_nF[0]) / (control_limits_nF[1] - control_limits_nF[0])) + 1
        if idx > 5:
            idx = 5
        chart_str = chart_str[:int(idx)] + '*' + chart_str[int(idx)+1:]
    else:
        if cap_nF < control_limits_nF[0]:
            if cap_nF < control_limits_nF[0] - half_range:
                chart_str = "*-" + chart_str
            else:
                chart_str = "*" + chart_str
        else:
            if cap_nF > control_limits_nF[1] + half_range:
                chart_str = chart_str + "-*"
            else:
                chart_str = chart_str + "*"
    return chart_str, verdict
