from datetime import datetime
import pandas as pd
import plotly.graph_objects as go
import traceback

from wiliot_testers.failure_analysis_ota_tester.modules.fa_ota_gui_inlay import load_json, save_json, GOLDENS_DIR


def get_golden_data_from_file(test_suite_name, tag_inlay, ble_calib, lora_calib):
    golden_data = {}
    golden_files = sorted(GOLDENS_DIR.glob(f"{test_suite_name}_{tag_inlay}_{ble_calib}_{lora_calib}*.json"))
    if golden_files:
        latest_golden = golden_files[-1]
        golden_data = load_json(latest_golden, {})
    return golden_data

def save_golden_data_to_file(results):
    test_suite_name = results['test_suite_name']
    tag_inlay = results['tag_inlay']
    ble_calib = results['ble_calib']
    lora_calib = results['lora_calib']
    date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{test_suite_name}_{tag_inlay}_{ble_calib}_{lora_calib}_{date_str}.json"
    filepath = GOLDENS_DIR / filename

    save_json(filepath, results)


def try_float(num):
    try:
        return float(num)
    except:
        return None

def get_results_plot(st):
    fig = go.Figure()
    is_plot = False
    try:
        result_test = st.get('analysis')
        results_test_suite = st.get('test_suite_name')
        if result_test is not None and 'results_per_tag' in result_test:
            is_plot = True
            for tag, data in result_test['results_per_tag'].items():
                x_values = data['x_values'] if 'x_values' in data else data['x_names']
                fig.add_trace(go.Scatter(
                    x=x_values,
                    y=data['y_value'],
                    mode="lines+markers",
                    name=f"Tag {tag}",
                    ))
            if results_test_suite == 'LoRa Attenuation Sweep':
                fig.add_hline(y=450, annotation_text="450")
            fig.update_yaxes(title_text=st.get('y_label',''))
            fig.update_xaxes(title_text=st.get('x_label',''))

        # Plot golden data if available (use test suite from results, not UI)
        if results_test_suite and is_plot:
            tag_inlay = st.get('tag_inlay')
            ble_calib = st.get('ble_calib')
            lora_calib = st.get('lora_calib')
            golden_data = get_golden_data_from_file(results_test_suite, tag_inlay, ble_calib, lora_calib)
            if golden_data:
                golden_analysis = golden_data.get('analysis')
                if golden_analysis and 'results_per_tag' in golden_analysis:
                    for tag, data in golden_analysis['results_per_tag'].items():
                        x_values = data['x_values'] if 'x_values' in data else data['x_names']
                        fig.add_trace(go.Scatter(
                            x=x_values,
                            y=data['y_value'],
                            mode="lines+markers",
                            name=f"Golden - Tag {tag}",
                            line=dict(dash='dash'),
                            opacity=0.6
                        ))

        # Add selected value indication
        selected_value_type = st.get('analysis', {}).get('best_value_type')
        if selected_value_type == 'x':
            is_plot = True
            x_value = st.get('analysis', {}).get('best_value')
            if x_value is not None:
                width = (max(st["plot_x"]) - min(st["plot_x"])) / 20 if len(st["plot_x"]) and any(pd.notnull(st["plot_x"])) else 5  # 5% of the x-axis range
                fig.add_vrect(
                    x0=x_value - width / 2,
                    x1=x_value + width / 2,
                    fillcolor="#FF5733",
                    opacity=0.2,
                    layer="below",
                    line_width=0,
                    annotation_text="Selected test",
                    annotation_position="top left",
                    annotation=dict(yshift=10)
                )
        elif selected_value_type == 'y':
            is_plot = True
            y_value = st.get('analysis', {}).get('best_value')
            if y_value is not None:
                height = (max(st["plot_y"]) - min(st["plot_y"])) / 20 if len(st["plot_y"]) and any(pd.notnull(st["plot_y"])) else 5  # 5% of the y-axis range
                fig.add_hrect(
                    y0=y_value - height / 2,
                    y1=y_value + height / 2,
                    fillcolor="#FF5733",
                    opacity=0.2,
                    layer="below",
                    line_width=0,
                    annotation_text="Selected Value",
                    annotation_position="top left",
                    annotation=dict(yshift=10)
                )
    except Exception as e:
        print(f'Plot got exception {e}, {traceback.format_exc()}')
        is_plot = False
    return is_plot, fig
