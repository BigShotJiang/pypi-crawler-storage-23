"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
from typing import Dict, Any, Optional
from copy import deepcopy,copy
import json
import numpy as np
from pathlib import Path
import logging

class TestSuiteBuilder:
    """Builds the test suite as name may suggest, handles json loading, parsing and sweep logic."""
    def __init__(self):
        self.json_defs = self._load_suites_from_json()
    
    def _load_suites_from_json(self) -> Dict[str, Dict[str, Any]]:
        """Load test suites from JSON files in the `test_suites/` directory.

        Each JSON may include a top-level `suite_name` field (preferred). If not
        present the filename stem will be used as the suite key.
        """
        suites_dir = Path(__file__).parent.parent / "test_suites"


        if not suites_dir.exists() or not suites_dir.is_dir():
            raise FileNotFoundError(
                f"Test suites directory not found: {suites_dir}.\n"
                "Create a `test_suites/` directory next to `configs/` and add JSON files."
            )

        out: Dict[str, Dict[str, Any]] = {}

        base_path = suites_dir / "base_suite.json"
        if not base_path.exists():
            raise FileNotFoundError(
                f"Required file missing: {base_path}.\n"
                "`base_suite.json` not found, please create it or reinstall wiliot_testers."
            )


        with open(base_path, "r", encoding="utf8") as f:
            base = json.load(f)
            base.pop("suite_name", None)
        # load each suite file (all .json files except base)
        for p in sorted(suites_dir.glob("*.json")):
            if p.name == "base_suite.json":
                continue
            try:
                with open(p, "r", encoding="utf8") as f:
                    data = json.load(f)
                suite_key = data.get("suite_name") or p.stem
                data.pop("suite_name", None)
                out[suite_key] = data
            except Exception:
                logging.exception(f"Failed loading suite JSON: {p}")

        if not out:
            raise RuntimeError(f"No suite JSON files found in {suites_dir} (excluding base_suite.json)")

        self.base_suite = base
        return out

    def build_all_suites(self) -> Dict[str, Dict[str, Any]]:
        """Build all test suites by merging with base and expanding sweeps.

        This function operates in JSON-only mode: it requires `test_suites/`
        to contain `base_suite.json` and at least one other suite JSON file.
        """
        return {name: self._resolve_suite(diff) for name, diff in self.json_defs.items()}

    def _resolve_suite(self, diff: Dict[str, Any]) -> Dict[str, Any]:
        """Merge suite diff with base suite and expand sweep parameters."""
        merged = {**self.base_suite, **diff}
        
        # create all sub tests based on the base_suite:
        original_tests = diff.get('tests')
        if original_tests is not None:
            tests = []
            for test in diff.get('tests', []):
                tests.append({**self.base_suite['tests'][0], **test})
            merged['tests'] = tests
        return self._expand_sweeps(merged)
    
    @staticmethod
    def _expand_sweeps(suite: Dict[str, Any]) -> Dict[str, Any]:
        sweep_params = suite.get('sweep_params')
        if sweep_params is None:
            return suite
        
        # convert dict sweep into list of values:
        new_params_values_list = {}
        new_values_list = {}
        for param_name, values in sweep_params.items():
            if isinstance(values, dict):
                new_values_list[param_name] = np.arange(values['value_min'], values['value_max'] + values['value_step'], values['value_step'])
                type_val_func = eval(values['value_type'])
                type_param_func = eval(values['param_type'])
                if type_param_func == list:
                    values = [[values['prefix'] + type_val_func(val)] for val in new_values_list[param_name]]
                else:
                    values = [type_param_func(values['prefix'] + type_val_func(val)) for val in new_values_list[param_name]]
                new_params_values_list[param_name] = values
        for param_name, values in new_params_values_list.items():
            sweep_params[param_name] = values

        # check sweep params validity for more than one sweep values
        sweep_length = None
        for param_name, values in sweep_params.items():
            if sweep_length is None:
                sweep_length = len(values)
            elif len(values) != sweep_length:
                raise ValueError(
                    "All sweep parameter lists must have the same length; "
                    f"'{param_name}' has {len(values)} vs expected {sweep_length}."
                )
        

        # duplicate the last test based on the sweep params:
        expanded_tests = suite.get('tests')
        if expanded_tests is None or len(expanded_tests) == 0:
            raise ValueError(f"test suite MUST contains tests field: {suite}")
        main_test = expanded_tests[-1]
        expanded_tests.pop()  # remove the main test
        for idx in range(sweep_length):
            variant = deepcopy(main_test)
            name_suffix = [main_test.get('name', 'test')]

            for param_name, values in sweep_params.items():
                value = values[idx]
                if 'HwUpdate' in param_name:
                    variant['HwUpdate']['function_inputs'][param_name.replace('HwUpdate_', '')] = value
                else:
                    variant[param_name] = value

                value_name = value if new_values_list.get(param_name) is None else new_values_list[param_name][idx]
                if param_name == 'absGwTxPower':
                    name_suffix.append(f"p{int(value_name)}dBm")
                elif param_name == 'rxChannel':
                    name_suffix.append(f"ch{value_name}")
                elif param_name == 'gw_commands':
                    name_suffix.append(f"{value_name}")
                else:
                    name_suffix.append(f"{param_name}_{value_name}")

            if name_suffix:
                variant['name'] = '_'.join(name_suffix)

            expanded_tests.append(variant)

        suite['tests'] = expanded_tests
        return suite

def make_test_suite() -> Dict[str, Dict[str, Any]]:
    builder = TestSuiteBuilder()
    return builder.build_all_suites()


if __name__ == '__main__':
    test_suite = make_test_suite()
    print(json.dumps(test_suite, indent=4))