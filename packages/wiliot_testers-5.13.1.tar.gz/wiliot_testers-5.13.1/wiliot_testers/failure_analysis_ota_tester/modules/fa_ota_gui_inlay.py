"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
import json
from pathlib import Path
from datetime import datetime
from dash import html, dcc
import dash_bootstrap_components as dbc
from wiliot_core import UsableInlayTypesTuple
from wiliot_core.utils.utils import WiliotDir

# ----------------------------
# JSON HELPERS
# ----------------------------
TESTER_DIR = Path(WiliotDir().get_wiliot_root_app_dir()) / 'fa_ota_tester'
USER_SETTINGS_PATH = Path(__file__).parent.parent / "configs" / "fa_ota_user_input.json"
CALIB_PATH = TESTER_DIR / "fa_ota_setup_calibration_params.json"
CALIB_ARCHIVE_DIR = TESTER_DIR / "calibration_backups"
CALIB_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
GOLDENS_DIR = TESTER_DIR / "goldens"
GOLDENS_DIR.mkdir(parents=True, exist_ok=True)
CALIB_CONTAINER_SHOW_STYLE = {"display": "flex", "flexDirection": "column", "alignItems": "flex-start", "border": "1px solid black", "padding": "10px",}

def load_json(path: Path, default=None):
    if path.exists():
        try:
            with open(path, "r") as f:
                return json.load(f)
        except Exception:
            return default or {}
    return default or {}


def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=4)


# ----------------------------
# BUILD UI
# ----------------------------
def field_row(label_text, component):
    """Small left-aligned row for tight vertical spacing."""
    return dbc.Row([
        dbc.Col(html.Div(label_text), width="auto",
                style={"font-weight": "bold", "padding-top": "6px", "width": "160px"}),
        dbc.Col(component, width="auto"),
    ], className="mb-2", align="center")


def title_section():
    return dbc.Row([
        # title
        dbc.Col(
            html.H2("Failure Analysis Over The Air",
                    style={"font-weight": "bold", "margin": "0", "padding-left": "15px"}),
            width=True
        ),
        # Logo
        dbc.Col(
            html.Img(
                id="app-logo",
                src="https://www.wiliot.com/src/uploads/Wiliotlogo.png",
                style={
                    "height": "30px",
                    "margin-left": "10px"
                }
            ),
            width="auto",
            align="center",
            style={"text-align": "right"}
        )
    ], className="mt-3 mb-3", align="center")


def config_section(saved, suite_options):
    run_name = saved.get("run_name", "")
    external_id = saved.get("external_id", "")
    tag_inlay = saved.get("tag_inlay", "")
    suite = saved.get("test_suite_name", "")
    owner_id = saved.get("owner_id", "")

    return dbc.Card([
        dbc.CardHeader("Configuration", className="section-header"),
        dbc.CardBody([

            dbc.Row([
                dbc.Col(html.Div("Run Name:"), width="auto",
                        style={"font-weight": "bold", "padding-top": "6px", "width": "120px"}),
                dbc.Col(
                    dcc.Input(id="run-name", type="text", value=run_name, style={"width": "100%"}),
                    width=4
                ),
            ], className="mb-2", align="center"),

            dbc.Row([
                dbc.Col(html.Div("Test Type:"), width="auto",
                        style={"font-weight": "bold", "padding-top": "6px", "width": "120px"}),
                dbc.Col(
                    dcc.Dropdown(
                        id="test-suite-name",
                        options=suite_options,
                        value=suite,
                        placeholder="Choose suite",
                        style={"width": "100%"}
                    ),
                    width=4
                ),
                dbc.Col(
                    dbc.Button("Info", id="suite-info-btn", color="info", size="sm"),
                    width="auto",
                    style={"padding-left": "10px"}
                )
            ], className="mb-2", align="center"),

            dbc.Row([
                dbc.Col(html.Div("Tag Inlay:"), width="auto",
                        style={"font-weight": "bold", "padding-top": "6px", "width": "120px"}),
                dbc.Col(
                    dcc.Dropdown(
                        id="tag-inlay",
                        options=UsableInlayTypesTuple,
                        value=tag_inlay,
                        placeholder="Select Inlay"
                    ),
                    width=4
                ),
            ], className="mb-2", align="center"),

            dbc.Row([
                dbc.Col(html.Div("External ID:"), width="auto",
                        style={"font-weight": "bold", "padding-top": "6px", "width": "120px"}),
                dbc.Col(
                    dcc.Input(id="external-id", type="text", value=external_id, style={"width": "100%"}),
                    width=4
                ),
                dbc.Col(
                    dbc.Button("Scan", id="run-scan", color="warning", size="sm", style={"display": "none"}),
                    width="auto",
                    style={"padding-left": "10px"}
                ),
                dbc.Col(
                    dbc.Button("Open Chamber", id="toggle-chamber", color="secondary", size="sm", style={"display": "none"}),
                    width="auto",
                    style={"padding-left": "10px"}
                ),
            ], className="mb-2", align="center"),

            dbc.Row([
                dbc.Col(html.Div("Owner Id:"), width="auto",
                        style={"font-weight": "bold", "padding-top": "6px", "width": "120px"}),
                dbc.Col(
                    dcc.Input(id="owner-id", type="text", value=owner_id, style={"width": "100%"}),
                    width=4
                ),
            ], className="mb-2", align="center"),

            # Modal
            dbc.Modal([
                dbc.ModalHeader("Test Type Information"),
                dbc.ModalBody(id="suite-info-text",style={"whiteSpace": "pre-line"}),
                dbc.ModalFooter(dbc.Button("Close", id="suite-info-close", className="ms-auto")),
            ], id="suite-info-modal", is_open=False),

        ])
    ], className="mb-3")


def test_section():
    return dbc.Card([
        dbc.CardHeader("Test Execution", className="section-header"),
        dbc.CardBody([
            dbc.Row(dbc.Col([
            dbc.Button("Start Test", id="start-test", color="success", className="me-2", style={"width": "160px"}),
            dbc.Button("Stop Test", id="stop-test", color="danger", className="me-2", disabled=True, style={"width": "160px"}),
            dbc.Button("Save Golden Data", id="save-golden-data", color="warning", disabled=True, className="me-2", style={"width": "160px"}),
            html.Div([
                dcc.Input(id="set-calib-input", type="text", placeholder="Calibration value", style={"width": "160px", "marginBottom": "8px"}),
                dbc.Button("Set Calibration", id="set-calib-btn", color="info", style={"width": "160px"}),
            ], id="calib-container", style={"display": "none"},
                            className="ms-2",
            ),], width="auto", style={"display": "flex", "flexDirection": "row", "alignItems": "center", "flexWrap": "wrap", "gap": "8px"}),
            className="mb-2",align="center",),

            html.Hr(),
            html.Div(id="test-monitor"),

            dcc.Interval(id="monitor-interval", interval=3000, n_intervals=0),
        ])
    ], className="mb-3")


def conclusion_section():
    return dbc.Card([
        dbc.CardHeader("Conclusion", className="section-header"),
        dbc.CardBody([
            html.Div(id="conclusion-text", children="No results yet." ,style={"whiteSpace": "pre-line"})
        ])
    ])


# ----------------------------
# MAIN UI ENTRY POINT
# ----------------------------

def get_inlay(test_suite_options):
    saved = load_json(USER_SETTINGS_PATH, {})
    calib = load_json(CALIB_PATH, {})
    suite_options = [{"label": opt, "value": opt} for opt in test_suite_options]

    return html.Div([
        # html.H2("Failure Analysis Over The Air", className="mt-3"),
        title_section(),
        config_section(saved, suite_options),
        test_section(),
        conclusion_section(),
        html.Div(id="background-status", style={"display": "none"}),
        # modals
        dbc.Modal([
            dbc.ModalHeader("Run Parameters"),
            dbc.ModalBody(
                html.Div([
                html.Div(dbc.Row([
                dbc.Col(html.Div("Ble Attenuation:"), width="auto", style={"font-weight": "bold", "padding-top": "6px", "width": "170px"}),
                dbc.Col(dcc.Input(id="pre-run-modal-ble", type="text", placeholder='4', style={"width": "100%"}), width=4),], className="mb-2", align="center"), id="pre-run-ble-row"),
                html.Div(dbc.Row([
                dbc.Col(html.Div("Lora Attenuation:"), width="auto", style={"font-weight": "bold", "padding-top": "6px", "width": "170px"}),
                dbc.Col(dcc.Input(id="pre-run-modal-lora", type="text", placeholder='4', style={"width": "100%"}), width=4),], className="mb-2", align="center"), id="pre-run-lora-row"),
                dbc.Row([
                dbc.Col(html.Div("RSSI Threshold:"), width="auto", style={"font-weight": "bold", "padding-top": "6px", "width": "170px"}),
                dbc.Col(dcc.Input(id="pre-run-modal-rssi", type="text", placeholder='4', style={"width": "100%"}), width=4),], className="mb-2", align="center"),
                dbc.Row([
                dbc.Col(html.Div("Max Test Time (s):"), width="auto", style={"font-weight": "bold", "padding-top": "6px", "width": "170px"}),
                dbc.Col(dcc.Input(id="pre-run-modal-max-time", type="text", placeholder='4', style={"width": "100%"}), width=4),], className="mb-2", align="center"),
                ])
            ),
            dbc.ModalFooter(dbc.Button("Run Test", id="pre-run-modal-run-btn", color="success", style={"width": "160px"}),className="d-flex justify-content-center")
            ], id="pre-run-modal-dialog", is_open=False)
    ])
