"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
from __future__ import annotations
import logging
import threading
import os
import csv
import datetime
from pathlib import Path
import json
import pandas as pd
import numpy as np
from queue import Queue
import traceback

from wiliot_api import ManufacturingClient
from wiliot_core.utils.utils import set_logger, GetApiKey
from wiliot_core import TagCollection
from wiliot_testers.failure_analysis_ota_tester.modules.fa_ota_utils import get_golden_data_from_file, try_float
from wiliot_tools.utils.wiliot_gui.wiliot_gui import WiliotGui
from wiliot_tools.resolver_tool.resolve_packets import ResolvePackets
from wiliot_testers.wiliot_tester_tag_result import FailureCodes
from wiliot_testers.sample.modules.wiliot_sample_tag_test import WiliotSampleTagTest
from wiliot_testers.failure_analysis_ota_tester.modules.fa_test_suites import make_test_suite
from wiliot_testers.failure_analysis_ota_tester.modules.fa_ota_hardware import FailureAnalysisOtaHardware
from wiliot_testers.failure_analysis_ota_tester.modules.fa_ota_gui_inlay import CALIB_PATH, load_json

class FailureAnalysisOtaRunner:
    """Orchestrates failure analysis OTA test execution with GUI selection and result export."""

    def __init__(self):
        self.test_suite = make_test_suite()
        self.run_root = None
        self.logger = None
        self.selected_suite_name = None
        self.run_output = {}
        self.stop_event = threading.Event()
        self.stat_check_event = threading.Event()
        self.tester = None
        self.last_test_status = None
        self.selected_suite = None
        self.client = None
        self.current_run_status = 'Not Started'
        self.hw_obj = FailureAnalysisOtaHardware()
    
    def get_tests_suites(self):
        """Returns available test suites."""
        return self.test_suite

    def run(self, test_suite_name='', run_name='', tag_inlay='', external_id='', ble_atten=None, lora_atten=None, rssi_threshold=None, max_test_time=None):
        """Main entry point: show GUI, get user selection, and execute tests."""
        self.current_run_status = 'Running'
        try:
            last_gui_input_path = Path(__file__).parents[1] / "configs" / "fa_ota_user_input.json"
            selection = load_json(last_gui_input_path)
            self.tag_inlay = tag_inlay
            self.external_id = external_id
            self._setup_run_environment(run_name)
            self.hw_obj.set_logger(self.logger)
            self.hw_obj.connect_all()
            self.selected_suite = self._prepare_suite(test_suite_name, rssi_threshold, max_test_time)
            self._set_calibration(ble_atten, lora_atten)
            # running the test
            self._execute_tests(selection)
            self.logger.info(f"All tests completed. Results saved in: {self.run_root}")
            is_success = self.hw_obj.disconnect_all()
            if not is_success:
                raise Exception('could not disconnect from all devices')
        except Exception as e:
            self.current_run_status = f"Error: {e}"
            if self.logger:
                self.logger.error(f"Error during test run: {e}, trace: {traceback.format_exc()}")
            else:
                print(f"Error during test run: {e}, trace: {traceback.format_exc()}")

    def get_current_run_status(self):
        """Returns the current exception message, if any."""
        return self.current_run_status

    def get_run_output(self):
        """Returns the output of the last run, with the following keys: 'results', 'analysis', 'packets_df', 'tags_df'"""
        return self.run_output

    def stop(self):
        """Signal to stop the ongoing test run."""
        self.stop_event.set()
    
    def get_run_results(self):
        """Returns the test run status."""
        stat = {
                    "running_test_num": None,
                    "running_test_name": None,
                    "completed": [],
                    "plot_x": [],
                    "plot_y": [],
                    "x_label": "X",
                    "y_label": "Y",
                    "tag_inlay": "",
                    "ble_calib": None,
                    "lora_calib": None,
                    "test_suite_name": self.selected_suite_name
                }
        if self.tester is None:
            return stat
        
        if self.stat_check_event.is_set():
            self.stat_check_event.clear()
            current_res = self.tester.get_current_test_results()
            if self.last_test_status is None:
                self.last_test_status = stat

            is_last_test = self.stop_event.is_set() or not self.tester.is_test_running()
            self.last_test_status["running_test_num"] = len(current_res) - is_last_test
            self.last_test_status["running_test_name"] = self.selected_suite['tests'][self.last_test_status["running_test_num"]]['name']
            self.last_test_status["x_label"] = self.selected_suite["tests"][-1]["name"]
            self.last_test_status["y_label"] = self.selected_suite.get('analysis_param', {}).get('value')
            self.last_test_status["tag_inlay"] = self.tag_inlay
            self.last_test_status["ble_calib"] = self.ble_atten
            self.last_test_status["lora_calib"] = self.lora_atten
            x_values = self.selected_suite.get('analysis_param', {}).get('x_values', {})
            for i, sub_test_res in enumerate(current_res):
                if i < len(self.last_test_status["completed"]):
                    continue  # already recorded
                
                self.last_test_status["completed"].append({"name": f"Test {i}: {self.selected_suite['tests'][i]['name']}", 
                                                           "status": "pass" if sub_test_res.is_test_passed else f"fail {sub_test_res.test_status.name}"})
                if self.selected_suite.get('analysis_param') is None:
                    continue
                tests_to_ignore = self.selected_suite['analysis_param'].get('tests_to_ignore', [])
                if self.selected_suite["tests"][i]["name"] in tests_to_ignore:
                    continue
                ind_x_value = i - len(tests_to_ignore)
                self.last_test_status["plot_x"].append(x_values['start'] + ind_x_value * x_values['step'] if x_values else ind_x_value)
                self.last_test_status["plot_y"].append(sub_test_res.selected_tag_statistics.get(self.last_test_status["y_label"]))

        elif self.last_test_status is None:
            # first test is running
            stat["running_test_num"] = 0
            stat["running_test_name"] = self.selected_suite['tests'][0]['name']
            self.last_test_status = stat

        return self.last_test_status
    
    def get_user_selection(self):
        """Display GUI and return user selection."""
        default_user_params = {
            'test_suite_name': list(self.test_suite.keys())[0],
            'rssi_threshold': 70,
            'max_test_time': 60,
            'run_name': 'test'
            }
        last_gui_input_path = Path(__file__).parents[1] / "configs" / "fa_ota_user_input.json"
        user_params = load_json(last_gui_input_path, default_user_params)
        
        params = {
            'test_suite_name': {
                'value': user_params['test_suite_name'],
                'text': 'Select a test',
                'options': list(self.test_suite.keys()),
                'widget_type': 'combobox'
            },
            'rssi_threshold': {'value': '', 'text': 'RSSI Threshold'},
            'max_test_time': {'value': '', 'text': 'Max Time'},
            'run_name': {'value': user_params['run_name'], 'text': 'Run name'}
            }

        gui = WiliotGui(params_dict=params, full_screen=False, title='Select tests to run', do_gui_init=True)
        return gui.run(save_path=last_gui_input_path)

    def _prepare_suite(self, test_suite_name, rssi_threshold, max_test_time):
        """Validate and configure the selected test suite."""
        self.selected_suite_name = test_suite_name
        if self.selected_suite_name not in self.test_suite:
            raise ValueError(f"Suite '{self.selected_suite_name}' not found.")

        suite = self.test_suite[self.selected_suite_name]
        suite['rssiThresholdSW'] = float(rssi_threshold)
        if max_test_time:
            suite['maxTtfp'] = float(max_test_time)
            for test in suite.get('tests', []):
                test['maxTime'] = float(max_test_time)

        # try:
        #     self.logger.info(f'The selected suite is:\n{json.dumps(suite, indent=4)}')
        # except Exception as e:
        #     self.logger.error(f"Could not log selected suite: {e}")
        return suite

    def _setup_run_environment(self, run_name):
        """Create run directory and logger."""
        run_name_raw = run_name.strip()
        if not run_name_raw:
            raise ValueError("Run name cannot be empty.")

        run_start_time = datetime.datetime.now()
        run_name = f"{self._safe_name(run_name_raw)}_{run_start_time.strftime('%Y%m%d_%H%M%S')}"

        logger_path, self.logger = set_logger('fa_ota', dir_name='fa_ota_tester', folder_name='logs', common_run_name=run_name)
        self.logger.setLevel(logging.DEBUG)
        self.run_root = os.path.dirname(logger_path)

    def _set_calibration(self, ble_atten, lora_atten):
        self.ble_atten = try_float(ble_atten)
        self.lora_atten = try_float(lora_atten)
        needed_calib = self.selected_suite.get("calibration")
        if not needed_calib:
            self.hw_obj.set_attenuation(ble_atten=0, lora_atten=0)  # reset attenuator if connected
            self.logger.info('Both attenuators were set to 0')
            return
        self.hw_obj.set_attenuation(ble_atten=self.ble_atten, lora_atten=self.lora_atten)  # reset attenuator if connected

    def _execute_tests(self, config):
        """Execute all tests in the suite as subtests."""
        res, all_packets_df, all_tags_df = self._run_single_test(config)
        analysis_out = {}
        if res is not None:
            analysis_out = self._analyze_results(res, all_packets_df, all_tags_df)
        self.run_output = {'results': res, 'analysis': analysis_out, 'packets_df': all_packets_df, 'tags_df': all_tags_df}
        if self.last_test_status is None:
            self.last_test_status = self.get_run_results()
        self.last_test_status['analysis'] = analysis_out
    
    def _analyze_results(self, res, all_packets_df, all_tags_df):
        """Perform analysis on the test results."""
        analysis_out = {}
        self.current_run_status = "Test was completed"
        analysis_param = self.selected_suite.get('analysis_param')
        if analysis_param is None or res is None:
            return analysis_out
        
        self.logger.info(f"Analyzing results for suite {self.selected_suite_name}")
        try:
            if analysis_param['input_data'] == 'tags':
                data_df = all_tags_df
            elif analysis_param['input_data'] == 'packets':
                data_df = all_packets_df
            else:
                self.logger.error(f"Unknown input_data for analysis: {analysis_param['input_data']}")
                return analysis_out
            
            if len(data_df) == 0:
                return analysis_out
            
            # filter out tests to ignore
            tests_to_ignore = analysis_param.get('tests_to_ignore', [])
            if tests_to_ignore:
                data_df = data_df[~data_df['test_name'].isin(tests_to_ignore)]
            
            # apply analysis function
            func = getattr(np, analysis_param['func']) if 'func' in analysis_param else eval(analysis_param['lambda'])
            value_col = analysis_param['value']

            # filter valid value range if specified
            valid_range = analysis_param.get('valid_value_range')
            if valid_range and value_col in data_df.columns:
                data_df = data_df[(data_df[value_col] >= valid_range[0]) & (data_df[value_col] <= valid_range[-1])]
            
            best_tests = []
            result_value = None
            group_val = 'external_id' if (data_df['external_id'].str.len() > 0).any() else 'adv_address'
            for tag, group_df in data_df.groupby(group_val):
                if value_col not in group_df.columns:
                    self.logger.warning(f"Value column '{value_col}' not found in data for tag {tag}. Skipping.")
                    continue
                # result Y-axis:
                result_value = func(group_df[value_col])

                # result X-axis:
                tests_name = group_df['test_name'].loc[group_df[value_col]==result_value].values
                best_tests += tests_name.tolist()
                
                # Summary
                self.logger.info(f"best test for tag {tag}: {tests_name} with {value_col} = {result_value}")
                # Get results Per Tag
                analysis_out['results_per_tag'] = analysis_out.get('results_per_tag', {})
                analysis_out['results_per_tag'][tag] = {
                    'y_value': group_df[value_col].tolist(),  # all tag values from all tests
                    'x_names': group_df['test_name'].to_list(),
                }
                analysis_out['results_per_tag'][tag]['x_values'] = [self._get_value_from_test_name(analysis_param, t) 
                                                                    for t in analysis_out['results_per_tag'][tag]['x_names']]
                # Get Analysis Per Tag
                analysis_out['analysis_per_tag'] = analysis_out.get('analysis_per_tag', {})
                analysis_out['analysis_per_tag'][tag] = result_value

            # Get the BEST x value:
            analysis_out['best_test'] = max(best_tests, key=best_tests.count) if len(best_tests) > 0 else 'N/A'
            # Get the BEST y value:
            analysis_out['best_result'] = func([out for out in analysis_out['analysis_per_tag'].values()]) if isinstance(analysis_out.get('analysis_per_tag'), dict) else None

            best_result = analysis_out['best_result'].item() if isinstance(analysis_out['best_result'], np.generic) else analysis_out['best_result']
            try:
                analysis_str = self._get_analysis_str(best_result, analysis_out['results_per_tag'])
            except Exception as e:
                self.logger.error(f"Error during generating analysis string: {e}, trace: {traceback.format_exc()}")
                analysis_str = f"Analysis result: {analysis_param['desc']} of {value_col} = {best_result} found in test {analysis_out['best_test']}\nCould not generate detailed analysis string: {e}"
            self.logger.info(analysis_str)
            self.current_run_status = analysis_str
            
            # get the one number for the whole run
            analysis_out['best_value'] = None
            analysis_out['best_value_type'] = None
            if analysis_param.get('result_axis') == 'x':
                if analysis_out['best_test'] != 'N/A':
                    analysis_out['best_value'] = self._get_value_from_test_name(analysis_param, analysis_out['best_test'])
                    analysis_out['best_value_type'] = 'x'
            elif analysis_param.get('result_axis') == 'y':
                if analysis_out['best_result'] is not None:
                    analysis_out['best_value'] = eval(analysis_param.get('result_format', 'str'))(analysis_out['best_result'])
                    analysis_out['best_value_type'] = 'y'
            return analysis_out

        except Exception as e:
            self.logger.error(f"Error during analysis data preparation: {e} {traceback.format_exc()}")
            return analysis_out
    
    def _get_analysis_str(self, best_result, results_per_tag):
        analysis_str = ''
        golden_data = get_golden_data_from_file(self.selected_suite_name, self.tag_inlay, self.ble_atten, self.lora_atten)
        if self.selected_suite_name == "LoRa Frequency Sweep":
            result_tags = list(results_per_tag.keys())
            result_tag = results_per_tag[result_tags[0]]
            if len(results_per_tag) > 1:
                analysis_str += f"more than one tag result, conclusion is for {result_tags[0]}\n"
            result_harvester_data = dict(zip(result_tag['x_values'], result_tag['y_value']))
            result_avg = []
            golden_avg = []
            golden_harvester_data = {}
            if not golden_data:
                is_golden = False
                analysis_str += "no golden data saved\n"
            else:
                golden_tags = list(golden_data['analysis']['results_per_tag'].keys())
                if len(golden_tags) > 1:
                    is_golden = False
                    analysis_str += "more than one golden tag saved\n"
                else:
                    is_golden = True
                    golden_tag = golden_data['analysis']['results_per_tag'][golden_tags[0]]
                    golden_harvester_data = dict(zip(golden_tag['x_values'], golden_tag['y_value']))
            for freq in [905000, 910000, 915000, 920000]:
                result_avg.append(result_harvester_data[freq])
                analysis_str += f"TBP @ {int(freq/1000)}MHz "
                analysis_str += f"Measured is {result_harvester_data[freq]:.2f}[ms], "
                if is_golden:
                    golden_avg.append(golden_harvester_data[freq])
                    analysis_str += f"Golden is {golden_harvester_data[freq]:.2f}[ms], "
                    analysis_str += f"Difference is {result_harvester_data[freq] - golden_harvester_data[freq]:.2f}[ms]\n"
            result_avg = np.mean(result_avg)
            analysis_str += f"Measured avg TBP is {result_avg:.2f}[ms], "
            if is_golden:
                golden_avg = np.mean(golden_avg)
                analysis_str += f"Golden avg TBP is {golden_avg:.2f}[ms], "
                analysis_str += f"Difference avg TBP is {result_avg - golden_avg:.2f}[ms]\n"
        elif self.selected_suite_name in ["Max TX Test", "Min TX Test"]:
            analysis_str += f"Measured value is {best_result:.2f}[MHz]\n"
            if not golden_data:
                analysis_str += "no golden data saved\n"
            else:
                analysis_str += f"Golden value is {golden_data['analysis']['best_value']:.2f}[MHz]\n"
                analysis_str += f"Difference is {best_result - golden_data['analysis']['best_value']:.2f}[MHz]\n"
        else:
            raise NotImplementedError

        return analysis_str
    
    @staticmethod
    def _get_value_from_test_name(analysis_param, test_name):
        if analysis_param.get('result_axis') == 'y':
            return str(test_name)
        return eval(analysis_param.get('result_format', 'str'))(test_name.split('_')[-1])

    @staticmethod
    def _get_tags_in_test(tags_in):
        if tags_in == '' or tags_in is None:
            return None 
        if not isinstance(tags_in, list):
            tags_in_list = tags_in.split(',')
        tags_out = []
        for t in tags_in_list:
            if t == '':
                continue
            tags_out.append(t.replace(' ',''))
        return tags_out or None

    def _run_single_test(self, config=None):
        """Execute a full suite with all subtests and export results."""
        res = None
        resolver_handler = None
        config = config if config is not None else {}
        all_packets_df = pd.DataFrame()
        all_tags_df = pd.DataFrame()
        self.stop_event.clear()
        self.last_test_status = None
        try:
            tags_in_test = self._get_tags_in_test(self.external_id)
            resolve_q = Queue(maxsize=100) if tags_in_test is not None else None
            test_suite = {'test': {self.selected_suite_name: self.selected_suite}}
            test_suite['test'][self.selected_suite_name]['isTestSuite'] = True
            self.tester = WiliotSampleTagTest(
                tags_in_test= tags_in_test,
                dir_for_gw_log=self.run_root,
                selected_test=self.selected_suite_name,
                test_suite=test_suite,
                stop_event_trig=self.stop_event,
                logger_name=self.logger.name,
                logger_result_name=self.logger.name,
                logger_gw_name=self.logger.name,
                inlay=config.get('tag_inlay'),
                resolve_q=resolve_q,
                hw_functions=self.hw_obj.get_hw_functions()
            )
            if resolve_q is not None:
                self.resolver = ResolvePackets(tags_in_test=tags_in_test,
                                               owner_id=config.get('owner_id', 'wiliot-ops'),
                                               env=config.get('env', 'prod'),
                                               resolve_q=resolve_q,
                                               set_tags_status_df=self.tester.set_tags_status,
                                               stop_event_trig=self.stop_event,
                                               logger_name=self.logger.name,
                                               )
                resolver_handler = threading.Thread(target=self.resolver.run, args=())
                resolver_handler.start()
                self.client = self.resolver.client
            self._connect_to_cloud(cloud_config=config)
            res = self.tester.run(sub_test_ended_event=self.stat_check_event)
            self.logger.info(' ***** Test was Completed ***** ')
            self.stop_event.set()
            if resolver_handler is not None:
                resolver_handler.join(10)
                if resolver_handler.is_alive():
                    raise Exception('fa ota: could not stop the resolve thread, please re-run app')
                self.logger.info('running resolver thread was done')

            if res.is_all_tests_passed():  #TODO need to define pass/fail based on analysis results?
                self.logger.info(f"'{self.selected_suite_name}' PASSED")
            else:
                self.logger.info(f"'{self.selected_suite_name}' FAILED")

            all_packets_df, all_tags_df = self._export_results(res, self.selected_suite['tests'], tags_in_test)
        except Exception as e:
            e_msg = f"Error running '{self.selected_suite_name}': {e}"
            self.current_run_status = e_msg
            self.logger.warning(f"{e_msg}: {(traceback.format_exc())}")
        
        if self.tester:
            self.tester.exit_tag_test()
        
        return res, all_packets_df, all_tags_df

    def _connect_to_cloud(self, cloud_config):
        if self.client is not None:
            return
        try:
            owner_id = cloud_config.get('owner_id', 'wiliot-ops')
            owner_id = owner_id if owner_id != '' else 'wiliot-ops'
            env = cloud_config.get('env', 'prod')
            # check if user need to type api key:
            auth_gui_is_needed, _, _, _ = GetApiKey.check_file(owner_id, env)
            if auth_gui_is_needed:
                self.current_run_status = 'Error: Please Check the Terminal, You need to manually add API key'
            k = GetApiKey(env=env, owner_id=owner_id, gui_type='cli')
            api_key = k.get_api_key()
            if api_key == '':
                raise Exception(f'Could not found an api key for owner id {owner_id} and env {env}')
            self.client = ManufacturingClient(api_key=api_key, env=env, logger_=self.logger.name, owner_id=owner_id)
            self.logger.info('Connection to the cloud was established')

        except Exception as e:
            raise Exception(f'Problem connecting to cloud {e}')

    def _export_results(self, res_obj, suite_tests, tags_in_test):
        """Export test results to CSV files."""
        all_packets_df = pd.DataFrame()
        all_tags_df = pd.DataFrame()

        if not res_obj:
            return all_packets_df, all_tags_df

        run_name = os.path.basename(self.run_root)
        run_data_csv = os.path.join(self.run_root, f"{run_name}@run_data.csv")

        for i, stage in enumerate(res_obj):
            test_name = suite_tests[i]['name'] if i < len(suite_tests) else 'unknown'
            self._export_run_data(run_data_csv, i, stage, test_name)
            packets_df = self._process_packets(stage, test_name)
            tags_df = self._process_tags(stage, test_name)
            all_packets_df = pd.concat([all_packets_df, packets_df], ignore_index=True)
            all_tags_df = pd.concat([all_tags_df, tags_df], ignore_index=True)
        # save packets and tags results:
        packets_csv = os.path.join(self.run_root, f"{run_name}@packets_data.csv")
        all_packets_df = self._merge_resolve_to_data(all_packets_df, tags_in_test)
        all_packets_df.to_csv(packets_csv, index=False)

        tags_csv = os.path.join(self.run_root, f"{run_name}@tags_data.csv")
        all_tags_df = self._merge_resolve_to_data(all_tags_df, tags_in_test)
        all_tags_df.to_csv(tags_csv, index=False)
        return all_packets_df, all_tags_df

    def _export_run_data(self, csv_path, test_num, stage, test_name):
        """Exports run data summary to CSV."""
        try:
            summary = stage.get_summary() if hasattr(stage, 'get_summary') else {}
            try:
                summary['failure_code_name'] = FailureCodes(summary.get('test_status')).name
            except Exception:
                summary['failure_code_name'] = 'UNKNOWN'
            
            row = {'suite': self.selected_suite_name, 'test_num': test_num, 'test_name': test_name, **summary}
            with open(csv_path, 'a', newline='', encoding='utf8') as f:
                writer = csv.DictWriter(f, fieldnames=row.keys())
                if not os.path.isfile(csv_path) or f.tell() == 0:
                    writer.writeheader()
                writer.writerow(row)
        except Exception as e:
            self.logger.error(f"Failed writing run_data: {e}")

    def _process_packets(self, stage, test_name):
        """Process packet data to DF."""
        df = pd.DataFrame()
        try:
            if stage.all_packets.size():
                # add parsed data if needed
                if self.selected_suite.get('analysis_param', {}).get('do_parse', False):
                    self.tester.enrich_packet_list(packet_list=stage.all_packets, client=self.client)
                    all_tags = TagCollection()
                    stage.all_tags = stage.add_packets_to_multi_tags(packets_in=stage.all_packets, multi_tag_out=all_tags)
                df = stage.all_packets.get_df()
                df['suite'] = self.selected_suite_name
                df['test_name'] = test_name
                df['external_id'] = ''
        except Exception as e:
            self.logger.error(f"Failed process packets: {e} [{traceback.format_exc()}]")
        return df

    def _process_tags(self, stage, test_name):
        """Process tag statistics to DF."""
        tags_df = pd.DataFrame()
        try:
            if stage.all_tags.tags:
                tags_df = stage.all_tags.get_statistics()
                tags_df['suite'] = self.selected_suite_name
                tags_df['test_name'] = test_name
                if self.selected_suite.get('analysis_param', {}).get('do_parse', False) and stage.selected_tag.size():
                    selected_tag = stage.selected_tag[0].packet_data['adv_address']
                    if selected_tag in stage.all_tags.keys():
                        new_stat = tags_df[tags_df['adv_address'] == selected_tag]
                        stage.selected_tag_statistics = new_stat.iloc[0].to_dict() if new_stat.size > 0 else {}
        except Exception as e:
            self.logger.error(f"Failed process tags: {e}")
        return tags_df

    @staticmethod
    def _safe_name(name: str) -> str:
        """Sanitizes name for filesystem use."""
        return name.replace(' ', '_').replace('/', '-').replace('@', '')
    
    def _merge_resolve_to_data(self, df_in, tags_in_test):
        if len(df_in) == 0 or len(self.tester.tags_status_df) == 0:
            return df_in
        df_out = pd.merge(df_in, self.tester.tags_status_df[['adv_address', 'external_id', 'resolve_status']], how='outer', on='adv_address')
        if 'external_id_y' in df_out.columns:
            df_out = df_out.rename(columns={'external_id_y': 'external_id'})
        if 'external_id_x' in df_out.columns:
            del df_out['external_id_x']
        if tags_in_test:
            df_out = df_out[df_out["external_id"].isin(tags_in_test)]
        return df_out



if __name__ == '__main__':
    runner = FailureAnalysisOtaRunner()
    selection = runner.get_user_selection()
    runner.run(**selection)
    print("Failure Analysis OTA test run completed with the following output:")
    out = runner.get_run_output()
    print(f"Failure Analysis OTA Test Analysis Results: {out.get('analysis')}")