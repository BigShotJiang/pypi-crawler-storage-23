"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""

from wiliot_tools.test_equipment.test_equipment import Attenuator
from wiliot_testers.failure_analysis_ota_tester.modules.fa_ota_gui_inlay import TESTER_DIR, save_json, load_json, USER_SETTINGS_PATH
from wiliot_tools.utils.wiliot_gui.wiliot_gui import WiliotGui
from wiliot_tools.test_equipment.test_equipment import available_serial_ports

HW_CONFIG_PATH = TESTER_DIR / "fa_ota_hardware_config.json"
HW_DEVICES = ['ble_attenuator', 'lora_attenuator', 'barcode_scanner', 'chamber']

class FailureAnalysisOtaHardware(object):
    def __init__(self, logger=None):
        self.attenuators = []
        self.ble_attenuator = None
        self.lora_attenuator = None
        self.params = load_json(HW_CONFIG_PATH, default={})
        self.logger = logger

    def set_logger(self, logger):
        self.logger = logger

    def get_hw_functions(self):
        return {'attenuation': self.set_attenuation}
    
    def connect_all(self):
        while self.ble_attenuator is None or self.lora_attenuator is None:
            if self.connect_attenuators():
                break
            save_hw_serial()
            self.params = load_json(HW_CONFIG_PATH, default={})
        self.attenuators = [self.ble_attenuator, self.lora_attenuator]

    def disconnect_all(self):
        success = self.disconnect_attenuators()
        return success

    def connect_attenuators(self) -> bool:
        if 'ble_attenuator_serial' in self.params:
            atten = Attenuator('API', serial_number=self.params.get('ble_attenuator_serial'))
            if atten.GetActiveTE().is_open():
                self.ble_attenuator = atten

        if 'lora_attenuator_serial' in self.params:
            atten = Attenuator('API', serial_number=self.params.get('lora_attenuator_serial'))
            if atten.GetActiveTE().is_open():
                self.lora_attenuator = atten

        return self.ble_attenuator is not None and self.lora_attenuator is not None
    
    def set_attenuation(self, ble_atten=None, lora_atten=None):
        if self.ble_attenuator and ble_atten is not None:
            value_out = self.ble_attenuator.GetActiveTE().Setattn(float(ble_atten))
            if self.logger is not None:
                self.logger.info(f'Attenuator: Setting BLE Attenuator to {ble_atten} dB')
            if float(ble_atten) != float(value_out):
                raise Exception(f'Attenuator BLE was set to {ble_atten} but actual value is {value_out}')

        if self.lora_attenuator and lora_atten is not None:
            value_out = self.lora_attenuator.GetActiveTE().Setattn(float(lora_atten))
            if self.logger is not None:
                self.logger.info(f'Attenuator: Setting LORA Attenuator to {lora_atten} dB')
            if float(lora_atten) != float(value_out):
                raise Exception(f'Attenuator LORA was set to {lora_atten} but actual value is {value_out}')
    
    def disconnect_attenuators(self):
        success = True
        for atten in self.attenuators:
            atten.GetActiveTE().close_port()
            if atten.GetActiveTE().is_open():
                success = False
        return success

def save_hw_serial():
    params = get_new_hw_serial()
    save_json(HW_CONFIG_PATH, params)

def get_new_hw_serial():
    params = {}
    atten_comport_options = get_comport_per_device("API Weinschel Attenuator")
    scanner_comport_options = get_comport_per_device("Scanner")
    chamber_comport_options = get_comport_per_device("Tescom")
    get_atten_serial_layout = {
        'title': {
            'value': f'Please choose attenuators for BLE and LoRa',
            'text': '',
            'widget_type': 'label',
        },
        'ble_attenuator': {
            'text': 'BLE Attenuator',
            'value': '',
            'options': list(atten_comport_options.keys()),
            'widget_type': 'combobox'},
        'lora_attenuator': {
            'text': 'LORA Attenuator',
            'value': '',
            'options': list(atten_comport_options.keys()),
            'widget_type': 'combobox'},
        'barcode_scanner': {
            'text': 'Barcode Scanner (optional)',
            'value': '',
            'options': list(scanner_comport_options.keys()),
            'widget_type': 'combobox'},
        'chamber': {
            'text': 'Pneumatic Chamber (optional)',
            'value': '',
            'options': list(chamber_comport_options.keys()),
            'widget_type': 'combobox'},

    }
    get_atten_serial_gui = WiliotGui(params_dict=get_atten_serial_layout, do_button_config=True, title='Get Hardware By Serial Number')
    vals = get_atten_serial_gui.run()
    if isinstance(vals, dict):
        for device in HW_DEVICES:
            if device in vals.keys() and vals[device]:
                if 'attenuator' in device:
                    params[f'{device}_serial'] = atten_comport_options[vals[device]]
                elif device == 'barcode_scanner':
                    params[f'{device}_serial'] = scanner_comport_options[vals[device]]
                elif device == 'chamber':
                    params[f'{device}_serial'] = chamber_comport_options[vals[device]]
    return params

def get_comport_per_device(device_name):
    comports = available_serial_ports(device_params={"name": device_name})
    return {f"{port['port']} ({port['serial_number']})": port["serial_number"] for port in comports}

if __name__ == "__main__":
    fa_hw = FailureAnalysisOtaHardware()
    fa_hw.connect_all()
    fa_hw.set_attenuation(ble_atten=0, lora_atten=0)
    fa_hw.disconnect_attenuators()
