"""
Copyright (c) 2016- 2025, Wiliot Ltd. All rights reserved.

Redistribution and use of the Software in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.

  2. Redistributions in binary form, except as used in conjunction with
  Wiliot's Pixel in a product or a Software update for such product, must reproduce
  the above copyright notice, this list of conditions and the following disclaimer in
  the documentation and/or other materials provided with the distribution.

  3. Neither the name nor logo of Wiliot, nor the names of the Software's contributors,
  may be used to endorse or promote products or services derived from this Software,
  without specific prior written permission.

  4. This Software, with or without modification, must only be used in conjunction
  with Wiliot's Pixel or with Wiliot's cloud service.

  5. If any Software is provided in binary form under this license, you must not
  do any of the following:
  (a) modify, adapt, translate, or create a derivative work of the Software; or
  (b) reverse engineer, decompile, disassemble, decrypt, or otherwise attempt to
  discover the source code or non-literal aspects (such as the underlying structure,
  sequence, organization, ideas, or algorithms) of the Software.

  6. If you create a derivative work and/or improvement of any Software, you hereby
  irrevocably grant each of Wiliot and its corporate affiliates a worldwide, non-exclusive,
  royalty-free, fully paid-up, perpetual, irrevocable, assignable, sublicensable
  right and license to reproduce, use, make, have made, import, distribute, sell,
  offer for sale, create derivative works of, modify, translate, publicly perform
  and display, and otherwise commercially exploit such derivative works and improvements
  (as applicable) in conjunction with Wiliot's products and services.

  7. You represent and warrant that you are not a resident of (and will not use the
  Software in) a country that the U.S. government has embargoed for use of the Software,
  nor are you named on the U.S. Treasury Department’s list of Specially Designated
  Nationals or any other applicable trade sanctioning regulations of any jurisdiction.
  You must not transfer, export, re-export, import, re-import or divert the Software
  in violation of any export or re-export control laws and regulations (such as the
  United States' ITAR, EAR, and OFAC regulations), as well as any applicable import
  and use restrictions, all as then in effect

THIS SOFTWARE IS PROVIDED BY WILIOT "AS IS" AND "AS AVAILABLE", AND ANY EXPRESS
OR IMPLIED WARRANTIES OR CONDITIONS, INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED
WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, NONINFRINGEMENT,
QUIET POSSESSION, FITNESS FOR A PARTICULAR PURPOSE, AND TITLE, ARE DISCLAIMED.
IN NO EVENT SHALL WILIOT, ANY OF ITS CORPORATE AFFILIATES OR LICENSORS, AND/OR
ANY CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES, FOR THE COST OF PROCURING SUBSTITUTE GOODS OR SERVICES,
FOR ANY LOSS OF USE OR DATA OR BUSINESS INTERRUPTION, AND/OR FOR ANY ECONOMIC LOSS
(SUCH AS LOST PROFITS, REVENUE, ANTICIPATED SAVINGS). THE FOREGOING SHALL APPLY:
(A) HOWEVER CAUSED AND REGARDLESS OF THE THEORY OR BASIS LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE);
(B) EVEN IF ANYONE IS ADVISED OF THE POSSIBILITY OF ANY DAMAGES, LOSSES, OR COSTS; AND
(C) EVEN IF ANY REMEDY FAILS OF ITS ESSENTIAL PURPOSE.
"""
import logging
from datetime import datetime
import dash_bootstrap_components as dbc
import threading
import pandas as pd
from dash import Dash, Input, Output, State, callback_context, html, dcc, no_update
import webbrowser

from wiliot_testers.failure_analysis_ota_tester.modules.fa_ota_gui_inlay import get_inlay, save_json, load_json, USER_SETTINGS_PATH, CALIB_PATH, CALIB_ARCHIVE_DIR, GOLDENS_DIR, CALIB_CONTAINER_SHOW_STYLE
from wiliot_testers.failure_analysis_ota_tester.modules.fa_ota_tag_test import FailureAnalysisOtaRunner
from wiliot_testers.failure_analysis_ota_tester.modules.fa_ota_utils import get_results_plot, save_golden_data_to_file
from wiliot_tools.test_equipment.test_equipment import available_serial_ports, BarcodeScanner, Tescom
logging.getLogger('werkzeug').setLevel(logging.WARNING)

class OTAApp:
    def __init__(self):
        self.tester = FailureAnalysisOtaRunner()
        self.app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
        self.app.layout = get_inlay(test_suite_options=self.tester.get_tests_suites().keys())
        self.is_test_running = False
        self.run_instance = None
        self.calib_container_shown = False
        self.calib_type = None
        self.scanner = None
        self.chamber = None
        self.register_callbacks()

    def register_callbacks(self):
        app = self.app
        # -------------------------------------------------
        # Test-Suite Info Pop-Up
        # -------------------------------------------------
        @app.callback(
            Output("suite-info-modal", "is_open"),
            Output("suite-info-text", "children"),
            Input("suite-info-btn", "n_clicks"),
            Input("suite-info-close", "n_clicks"),
            State("suite-info-modal", "is_open"),
            State("test-suite-name", "value")
        )
        def toggle_suite_info(btn_open, btn_close, is_open, suite_name):
            triggered = callback_context.triggered_id
            if suite_name:
                suite_description = self.tester.get_tests_suites().get(suite_name, {}).get("desc", "No description available.")
            else:
                suite_description = "No suite selected."

            if triggered == "suite-info-btn":
                return True, suite_description
            elif triggered == "suite-info-close":
                return False, suite_description

            return is_open, suite_description

        # ----------------------------
        # Scan barcode
        # ----------------------------
        # @app.callback(
        #     Output("tag-inlay", "value"),
        #     Input("run-scan", "n_clicks"),
        #     State("hw-scanner-com", "value"),
        #     State("tag-inlay", "value"),
        #     prevent_initial_call=True
        # )
        # def scan_barcode(_, com_port, current_value):
        #     if not com_port:
        #         return no_update

        #     try:
        #         # Connect to scanner if not connected or COM port changed
        #         if self.scanner is None or self.scanner.com_port != com_port:
        #             self.scanner = BarcodeScanner(com_port=com_port, config=False)

        #         # Scan and get the tag ID
        #         scanned_data = self.scanner.scan_and_flush()
        #         scanned_data = scanned_data[0]
        #         if scanned_data:  # Check for non-empty string
        #             return scanned_data
        #     except Exception:
        #         pass

        #     return no_update

        # ----------------------------
        # Show/hide scan button based on scanner COM port
        # ----------------------------
        # @app.callback(
        #     Output("run-scan", "style"),
        #     Input("hw-scanner-com", "value"),
        # )
        # def toggle_scan_button(com_port):
        #     if com_port:
        #         return {"display": "inline-block"}
        #     return {"display": "none"}

        # ----------------------------
        # Show/hide and update chamber button based on COM port
        # ----------------------------
        # @app.callback(
        #     Output("toggle-chamber", "style"),
        #     Output("toggle-chamber", "children"),
        #     Input("hw-chamber-com", "value"),
        #     prevent_initial_call=True
        # )
        # def toggle_chamber_button(com_port):
        #     if not com_port:
        #         return {"display": "none"}, "Open Chamber"

        #     # Try to get chamber state
        #     try:
        #         if self.chamber is None or self.chamber.port != com_port:
        #             self.chamber = Tescom(port=com_port)
        #         if self.chamber.is_door_open():
        #             return {"display": "inline-block"}, "Close Chamber"
        #         else:
        #             return {"display": "inline-block"}, "Open Chamber"
        #     except Exception:
        #         pass

        #     return {"display": "inline-block"}, "Open Chamber"

        # ----------------------------
        # Toggle chamber open/close
        # ----------------------------
        # @app.callback(
        #     Output("toggle-chamber", "children", allow_duplicate=True),
        #     Input("toggle-chamber", "n_clicks"),
        #     State("hw-chamber-com", "value"),
        #     State("toggle-chamber", "children"),
        #     prevent_initial_call=True
        # )
        # def toggle_chamber(_, com_port, current_label):
        #     if not com_port:
        #         return current_label

        #     try:
        #         # Connect to chamber if not connected or COM port changed
        #         if self.chamber is None or self.chamber.port != com_port:
        #             self.chamber = Tescom(port=com_port)

        #         # Toggle based on current state
        #         if current_label == "Open Chamber":
        #             self.chamber.open_chamber()
        #             return "Close Chamber"
        #         else:
        #             self.chamber.close_chamber()
        #             return "Open Chamber"
        #     except Exception as e:
        #         pass

        #     return current_label

        # ----------------------------
        # Save config on change
        # ----------------------------
        @app.callback(
            Output("background-status", "children"),
            [
                Input("run-name", "value"),
                Input("test-suite-name", "value"),
                Input("tag-inlay", "value"),
                Input("external-id", "value"),
                Input("owner-id", "value"),
            ],
        )
        def store_settings(*vals):
            (
                run_name, suite, tag_inlay, external_id, owner_id
            ) = vals

            data = {
                "run_name": run_name,
                "test_suite_name": suite,
                "tag_inlay": tag_inlay,
                "external_id": external_id,
                "owner_id": owner_id,
            }
            save_json(USER_SETTINGS_PATH, data)
            return ""

        # -------------------------------------------------
        # Start Test — with hardware validation pop-up and pre-run modal
        # -------------------------------------------------
        @app.callback(
            Output("pre-run-modal-dialog", "is_open"),
            Output("pre-run-modal-ble", "placeholder"),
            Output("pre-run-modal-lora", "placeholder"),
            Output("pre-run-modal-rssi", "placeholder"),
            Output("pre-run-modal-max-time", "placeholder"),
            Output("pre-run-modal-ble", "value"),
            Output("pre-run-modal-lora", "value"),
            Output("pre-run-modal-rssi", "value"),
            Output("pre-run-modal-max-time", "value"),
            Output("pre-run-ble-row", "style"),
            Output("pre-run-lora-row", "style"),
            Output("conclusion-text", "children", allow_duplicate=True),
            Output("save-golden-data", "children", allow_duplicate=True),
            Input("start-test", "n_clicks"),
            State("test-suite-name", "value"),
            State("tag-inlay", "value"),
            State("run-name", "value"),
            prevent_initial_call=True
        )
        def open_pre_run_modal(n, suite, tag_inlay, run_name):
            test_suite = self.tester.get_tests_suites().get(suite, {})

            # check if run_name is selected
            if not run_name:
                return  False, "", "", "", "", "", "", "", "", {}, {}, "Please choose run name", "Save Golden Data"
            
            # check if tag_inlay is selected
            if not tag_inlay:
                return  False, "", "", "", "", "", "", "", "", {}, {}, "Please choose tag inlay", "Save Golden Data"
            
            # check if test suite name is selected
            if not suite:
                return  False, "", "", "", "", "", "", "", "", {}, {}, "Please choose test type", "Save Golden Data"

            if self.is_test_running:
                return  False, "", "", "", "", "", "", "", "", {}, {}, "", "Save Golden Data"  # do nothing if already running

            calib_data = load_json(CALIB_PATH, {})
            ble_calib = calib_data.get("output_power_ble_calib", "")
            lora_calib = calib_data.get("output_power_lora_calib", "")
            ble_row_style = {}
            lora_row_style = {}
            rssi = test_suite['rssiThresholdSW']
            max_time = test_suite['tests'][0]['maxTime']

            # Hide BLE/LoRa attenuation rows for their respective sweep tests
            if suite == "BLE Beacons Attenuation Sweep":
                ble_row_style = {"display": "none"}
            elif suite == "LoRa Attenuation Sweep":
                lora_row_style = {"display": "none"} 

            # all good → open pre-run modal with placeholders, clear values
            return  True, ble_calib, lora_calib, rssi, max_time, "", "", "", "", ble_row_style, lora_row_style, "", "Save Golden Data"

        # -------------------------------------------------
        # Run Test from pre-run modal
        # -------------------------------------------------
        @app.callback(
            Output("pre-run-modal-dialog", "is_open", allow_duplicate=True),
            Output("start-test", "disabled", allow_duplicate=True),
            Output("stop-test", "disabled", allow_duplicate=True),
            Output("calib-container", "style", allow_duplicate=True),
            Input("pre-run-modal-run-btn", "n_clicks"),
            State("test-suite-name", "value"),
            State("tag-inlay", "value"),
            State("external-id", "value"),
            State("run-name", "value"),
            State("pre-run-modal-ble", "value"),
            State("pre-run-modal-lora", "value"),
            State("pre-run-modal-rssi", "value"),
            State("pre-run-modal-max-time", "value"),
            prevent_initial_call=True
        )
        def run_test_from_modal(n, suite, tag_inlay, external_id, run_name, ble_atten, lora_atten, rssi_threshold, max_test_time):
            # Use test suite defaults if modal values are empty
            test_suite = self.tester.get_tests_suites().get(suite, {})
            calib_data = load_json(CALIB_PATH, {})
            if not ble_atten:
                ble_atten = None if suite == "BLE Beacons Attenuation Sweep" else calib_data.get("output_power_ble_calib","")
            if not lora_atten:
                lora_atten = None if suite == "LoRa Attenuation Sweep" else calib_data.get("output_power_lora_calib","")
            if not rssi_threshold:
                rssi_threshold = test_suite.get("rssiThresholdSW")
            if not max_test_time:
                max_test_time = test_suite.get("maxTtfp")

            if ble_atten == "" or lora_atten == "":
                return  True, False, True, {"display": "none"}  # keep modal open, enable start, disable stop, hide calib

            # Start test with modal arguments
            self.start_test(test_suite_name=suite, run_name=run_name, tag_inlay=tag_inlay, external_id=external_id,
                            ble_atten=ble_atten, lora_atten=lora_atten, rssi_threshold=rssi_threshold, max_test_time=max_test_time)
            self.is_test_running = True
            self.calib_container_shown = False
            self.calib_type = None
            return False, True, False, {"display": "none"}  # close modal, disable start, enable stop, hide calib
        
        # ----------------------------
        # Stop test suite
        # ----------------------------
        @app.callback(
            Output("start-test", "disabled", allow_duplicate=True),
            Output("stop-test", "disabled", allow_duplicate=True),
            Input("stop-test", "n_clicks"),
            prevent_initial_call=True
        )
        def stop_test(_):
            self.tester.stop()
            return False, True

        # ----------------------------
        # Save Calibration
        # ----------------------------
        @app.callback(
            Output("calib-container", "style", allow_duplicate=True),
            Input("set-calib-btn", "n_clicks"),
            State("set-calib-input", "value"),
            prevent_initial_call=True
        )
        def save_calib(_, value):
            if value and self.calib_type:
                try:
                    calib_data = load_json(CALIB_PATH, {})
                    # save backup calibration file
                    save_json(CALIB_ARCHIVE_DIR / f"fa_ota_setup_calibration_params{datetime.now().strftime('%Y%m%d_%H%M%S')}.json", calib_data)
                    if self.calib_type == "ble":
                        calib_data["output_power_ble_calib"] = float(value)
                    elif self.calib_type == "lora":
                        calib_data["output_power_lora_calib"] = float(value)
                    save_json(CALIB_PATH, calib_data)
                    self.calib_type = None
                    return {"display": "none"}
                except ValueError:
                    return CALIB_CONTAINER_SHOW_STYLE
            return CALIB_CONTAINER_SHOW_STYLE

        # ----------------------------
        # Save Golden Data
        # ----------------------------
        @app.callback(
            Output("save-golden-data", "children", allow_duplicate=True),
            Input("save-golden-data", "n_clicks"),
            State("test-suite-name", "value"),
            State("tag-inlay", "value"),
            prevent_initial_call=True
        )
        def save_golden_data(n, test_suite_name, tag_inlay):
            if not test_suite_name or not tag_inlay:
                return "Save Golden Data"

            results = self.tester.get_run_results()
            if not results:
                return "Save Golden Data"
            save_golden_data_to_file(results)

            return "Saved!"

        # ----------------------------
        # Monitor callback
        # ----------------------------
        @app.callback(
            Output("test-monitor", "children"),
            Output("conclusion-text", "children"),
            Output("start-test", "disabled", allow_duplicate=True),
            Output("stop-test", "disabled", allow_duplicate=True),
            Output("save-golden-data", "disabled"),
            Output("calib-container", "style"),
            Output("set-calib-btn", "children"),
            Input("monitor-interval", "n_intervals"),
            State("calib-container", "style"),
            State("set-calib-btn", "children"),
            prevent_initial_call=True
        )
        def update_monitor(_, calib_style, calib_btn_label):
            if self.run_instance and not self.run_instance.is_alive():
                self.is_test_running = False

            st = self.tester.get_run_results()

            # build test results view
            children = []

            # current test run
            if st["running_test_num"]:
                children.append(html.Div(f"Running Test #{st['running_test_num']}: "
                                         f"{st['running_test_name']}"))

            # Monitor graph
            is_plot, fig = get_results_plot(st)
            
            if is_plot:
                children.append(dbc.Card(dcc.Graph(figure=fig)))

            else:
                # completed test run
                if st["completed"]:
                    for c in st["completed"]:
                        color = "green" if c["status"] == "pass" else "red"
                        children.append(
                            html.Div([
                                html.Span(c["name"]),
                                html.Span(f" - {c['status']}",
                                        style={"color": color, "marginLeft": "10px"})
                            ])
                        )

            # conclusion text
            conc_str = self.tester.get_current_run_status()
            conc_color = 'green' if 'Analysis result:' in conc_str else ('red' if 'Error' in conc_str else 'blue')
            conclusion_text = html.Div(self.tester.get_current_run_status(), style={"color": conc_color, "fontWeight": "bold"})

            disable_start_button = self.is_test_running
            disable_stop_button = not self.is_test_running
            # Enable save golden only when test is done and results are available
            has_results = st.get("completed") or st.get("analysis")
            disable_save_golden = self.is_test_running or not has_results

            # Check if we should show calib input after test completion
            calib_container_style = calib_style or {"display": "none"}
            test_just_completed = not self.is_test_running and has_results and not self.calib_container_shown
            results_test_suite = st.get('test_suite_name')
            if test_just_completed:
                if results_test_suite == "BLE Beacons Attenuation Sweep":
                    calib_container_style = CALIB_CONTAINER_SHOW_STYLE
                    calib_btn_label = "Set BLE Calibration"
                    self.calib_container_shown = True
                    self.calib_type = "ble"
                elif results_test_suite == "LoRa Attenuation Sweep":
                    calib_container_style = CALIB_CONTAINER_SHOW_STYLE
                    calib_btn_label = "Set LoRa Calibration"
                    self.calib_container_shown = True
                    self.calib_type = "lora"

            return children, conclusion_text, disable_start_button, disable_stop_button, disable_save_golden, calib_container_style, calib_btn_label

    def start_test(self, test_suite_name='', run_name='', tag_inlay='', external_id='', ble_atten=None, lora_atten=None, rssi_threshold=None, max_test_time=None):
        self.run_instance = threading.Thread(
            target=self.tester.run,
            kwargs={
                "test_suite_name": test_suite_name,
                "run_name": run_name,
                "tag_inlay": tag_inlay,
                "external_id": external_id,
                "ble_atten": ble_atten,
                "lora_atten": lora_atten,
                "rssi_threshold": rssi_threshold,
                "max_test_time": max_test_time
            }
        )
        self.run_instance.start()

    # ----------------------------------
    def run(self):
        webbrowser.open("http://127.0.0.1:8050/")
        self.app.run(debug=False)


if __name__ == "__main__":
    # ----------------------------
    # Verify Attenuators Connection
    # ----------------------------
    from wiliot_testers.failure_analysis_ota_tester.modules.fa_ota_hardware import FailureAnalysisOtaHardware
    fa_hw = FailureAnalysisOtaHardware()
    fa_hw.connect_all()
    fa_hw.disconnect_attenuators()
    # ----------------------------
    # Main Application
    # ----------------------------
    OTAApp().run()