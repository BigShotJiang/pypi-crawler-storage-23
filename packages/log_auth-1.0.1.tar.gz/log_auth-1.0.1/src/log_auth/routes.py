from flask import request, jsonify
from flask_login import login_user, logout_user, login_required
from . import auth_bp
from .services import create_user, authenticate_user

@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.json

    user, error = create_user(
        username=data.get("username"),
        password=data.get("password"),
    )

    if error:
        return jsonify({"error": error}), 400

    return jsonify({"message": "User created"}), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.json

    user = authenticate_user(
        username=data.get("username"),
        password=data.get("password"),
    )

    if not user:
        return jsonify({"error": "Invalid credentials"}), 401

    login_user(user)
    return jsonify({"message": "Logged in"})


@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    return jsonify({"message": "Logged out"})
