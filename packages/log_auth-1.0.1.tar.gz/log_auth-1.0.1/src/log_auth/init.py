from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from flask import Blueprint

db = SQLAlchemy()
login_manager = LoginManager()
auth_bp = Blueprint("auth", __name__)

def init_auth(app):
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    from .models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    app.register_blueprint(auth_bp)
