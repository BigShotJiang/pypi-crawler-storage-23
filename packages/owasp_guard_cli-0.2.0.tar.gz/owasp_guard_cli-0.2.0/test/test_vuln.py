import os
import sqlite3
from flask import Flask, request
import hashlib

app = Flask(__name__)
app.config["SECRET_KEY"] = "hardcoded-dev-secret"  # A02: hardcoded secret


@app.get("/user")
def get_user():
    username = request.args.get("username", "")
    conn = sqlite3.connect("app.db")
    q = f"SELECT * FROM users WHERE username = '{username}'"  # A03: SQL injection
    row = conn.execute(q).fetchone()
    return {"row": str(row)}


@app.post("/run")
def run_cmd():
    cmd = request.json.get("cmd", "")
    return os.popen(cmd).read()  # A03: command injection


@app.post("/hash")
def weak_hash():
    pwd = request.json.get("password", "")
    return hashlib.md5(pwd.encode()).hexdigest()  # A02: weak crypto
