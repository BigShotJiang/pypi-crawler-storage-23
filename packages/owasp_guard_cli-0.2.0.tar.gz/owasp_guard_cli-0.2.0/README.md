# OWASP Guard CLI

OWASP Guard is a prompt-engineered secure code inspection CLI for identifying OWASP Top 10 (2021) issues in source code.

It scans a repository or single file, performs chunked LLM analysis with a verification pass, then generates:
- `report.json` for pipelines and automation
- `report.md` for human review and audit

## Key Features
- OWASP-focused findings with confidence scoring
- Chunk-based analysis with route/function-aware heuristics
- Verification pass to reduce false positives
- Deduplication of repeated findings
- Progress-rich terminal UI
- Broad multi-language and config/IaC file support

## Requirements
- Python `3.11+`
- Groq API key

## Installation
From PyPI:
```bash
pip install owasp-guard-cli
```

From source:
```bash
pip install -r requirements.txt
pip install -e .
```

## Quick Start
1. Configure API key:
```bash
owasp-guard init
```

2. Run scan:
```bash
owasp-guard scan ./project --output-dir outputs
```

3. Review outputs:
- `outputs/report.json`
- `outputs/report.md`

## CLI Usage
Main help:
```bash
owasp-guard --help
owasp-guard help
```

Topic help:
```bash
owasp-guard help init
owasp-guard help scan
owasp-guard help reports
owasp-guard help errors
```

Alias entrypoint:
```bash
owasp help
owasp help scan
```

## Common Commands
Initialize with provided key:
```bash
owasp-guard init --api-key gsk_xxx
```

Scan repo:
```bash
owasp-guard scan "D:\path\to\repo" --output-dir outputs
```

Scan single file:
```bash
owasp-guard scan "D:\path\to\file.py" --output-dir outputs
```

Fixed-scope evaluation:
```bash
owasp-guard scan "D:\path\to\repo" --max-files 10 --output-dir outputs
```

Custom model:
```bash
owasp-guard scan ./project --model llama-3.1-8b-instant
```

## Report Schema Summary
`report.json` includes:
- tool metadata and report version
- methodology metadata
- scope metrics (`total_files`, `total_chunks`, `total_findings`)
- summary metrics (`risk_score_10`, severity and OWASP distributions)
- full findings list

`report.md` includes:
- executive summary and risk score
- OWASP and file impact distribution
- findings index and detailed evidence/fix sections
- priority action plan and remediation roadmap

## Exit Codes
- `0`: scan completed with no findings
- `1`: scan completed with findings
- `2`: invalid CLI usage
- `3`: runtime error

## Error Types
- `Configuration Error`: missing/invalid API key or unreadable config
- `Input Error`: bad path, unsupported file type, invalid `--max-files`, empty scope
- `API Error`: model/provider failures
- `Report Error`: output write/serialization failures
- `Scan Error`: chunking or scan pipeline failures

## Repository Docs
- Project prompt evolution: `PROMPT_LOG.md`
- Tool benchmark worksheet: `comparison.md`
- Sample outputs: `report.md`, `testotpt/report.md`, `juiceotpt/report.md`
