import json
from datetime import datetime, timezone
from pathlib import Path
from collections import Counter

from .models import ScanReport
from .errors import ReportError


def _severity_from_confidence(confidence: float) -> str:
    if confidence >= 0.9:
        return "HIGH"
    if confidence >= 0.75:
        return "MEDIUM"
    return "LOW"


def _priority_from_severity(severity: str) -> str:
    return {"HIGH": "P1", "MEDIUM": "P2", "LOW": "P3"}[severity]


def _risk_score(summary: dict) -> float:
    high = summary["severity_breakdown"]["high"]
    medium = summary["severity_breakdown"]["medium"]
    low = summary["severity_breakdown"]["low"]
    raw = (high * 9.0) + (medium * 5.0) + (low * 2.0)
    return round(min(10.0, raw / 5.0), 1)


def _build_summary(report: ScanReport) -> dict:
    severities = [_severity_from_confidence(f.confidence) for f in report.findings]
    severity_counts = Counter(severities)
    owasp_counts = Counter(f.owasp_category for f in report.findings)
    file_counts = Counter(f.file for f in report.findings)
    top_files = [{"file": path, "findings": count} for path, count in file_counts.most_common(10)]
    risk_level = "LOW"
    if severity_counts.get("HIGH", 0) > 0:
        risk_level = "HIGH"
    elif severity_counts.get("MEDIUM", 0) > 0:
        risk_level = "MEDIUM"
    return {
        "overall_risk_level": risk_level,
        "risk_score_10": _risk_score({
            "severity_breakdown": {
                "high": severity_counts.get("HIGH", 0),
                "medium": severity_counts.get("MEDIUM", 0),
                "low": severity_counts.get("LOW", 0),
            }
        }),
        "severity_breakdown": {
            "high": severity_counts.get("HIGH", 0),
            "medium": severity_counts.get("MEDIUM", 0),
            "low": severity_counts.get("LOW", 0),
        },
        "owasp_distribution": dict(sorted(owasp_counts.items(), key=lambda kv: kv[1], reverse=True)),
        "top_affected_files": top_files,
    }


def _json_payload(report: ScanReport) -> dict:
    summary = _build_summary(report)
    return {
        "tool": "owasp-guard",
        "report_version": "1.2",
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "methodology": {
            "analysis_mode": "chunk-based static LLM review",
            "verification_pass": True,
            "deduplication": "root-cause + location + evidence",
            "taxonomy": "OWASP Top 10 (2021)",
        },
        "scanned_path": report.scanned_path,
        "total_files": report.total_files,
        "total_chunks": report.total_chunks,
        "total_findings": report.total_findings,
        "summary": summary,
        "findings": [f.model_dump() for f in report.findings],
    }


def _markdown_payload(report: ScanReport) -> str:
    summary = _build_summary(report)
    lines = [
        "# OWASP Guard Security Assessment Report",
        "",
        f"**Generated:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%SZ')}  ",
        f"**Target:** `{report.scanned_path}`  ",
        f"**Overall risk level:** **{summary['overall_risk_level']}**  ",
        f"**Risk score (0-10):** **{summary['risk_score_10']:.1f}**  ",
        "",
        "## Executive Summary",
        "",
        "| Metric | Value |",
        "|---|---|",
        f"| Files scanned | {report.total_files} |",
        f"| Chunks analyzed | {report.total_chunks} |",
        f"| Total findings | {report.total_findings} |",
        f"| Risk score (0-10) | {summary['risk_score_10']:.1f} |",
        f"| High severity | {summary['severity_breakdown']['high']} |",
        f"| Medium severity | {summary['severity_breakdown']['medium']} |",
        f"| Low severity | {summary['severity_breakdown']['low']} |",
        "",
    ]
    if not report.findings:
        lines.append("No vulnerabilities were detected in the selected scope.")
        return "\n".join(lines)

    lines.extend(
        [
            "## OWASP Distribution",
            "",
            "| OWASP Category | Findings |",
            "|---|---|",
        ]
    )
    for category, count in summary["owasp_distribution"].items():
        lines.append(f"| {category} | {count} |")

    lines.extend(
        [
            "",
            "## Most Affected Files",
            "",
            "| File | Findings |",
            "|---|---|",
        ]
    )
    for entry in summary["top_affected_files"]:
        lines.append(f"| `{entry['file']}` | {entry['findings']} |")

    lines.extend(
        [
            "",
            "## Findings Index",
            "",
            "| # | Severity | File | Lines | OWASP | Title | Confidence | Priority |",
            "|---|---|---|---|---|---|---|---|",
        ]
    )
    for i, f in enumerate(report.findings, start=1):
        sev = _severity_from_confidence(f.confidence)
        pri = _priority_from_severity(sev)
        lines.append(
            f"| {i} | {sev} | `{f.file}` | {f.line_start}-{f.line_end} | {f.owasp_category} | {f.title} | {f.confidence:.2f} | {pri} |"
        )

    lines.extend(
        [
            "",
            "## Priority Action Plan",
            "",
            "| Priority | SLA Target | Governance Action |",
            "|---|---|---|",
            "| P1 | 24-72 hours | Immediate patch + hotfix review + security sign-off |",
            "| P2 | 7-14 days | Sprint remediation + mandatory code review checklist |",
            "| P3 | 30-60 days | Backlog hardening + periodic verification scan |",
        ]
    )

    lines.append("")
    lines.append("## Detailed Findings")

    for i, f in enumerate(report.findings, start=1):
        sev = _severity_from_confidence(f.confidence)
        pri = _priority_from_severity(sev)
        lines.extend(
            [
                "",
                f"### [{i}] {f.title}",
                f"- Severity: **{sev}**",
                f"- Priority: **{pri}**",
                f"- File: `{f.file}`",
                f"- Line range: {f.line_start}-{f.line_end}",
                f"- OWASP: {f.owasp_category}",
                f"- Confidence: {f.confidence:.2f}",
                f"- Risk summary: {f.risk_summary}",
                f"- Fix recommendation: {f.fix_recommendation}",
                "",
                "**Evidence**",
                "```text",
                f.evidence,
                "```",
            ]
        )

    lines.extend(
        [
            "",
            "## Remediation Roadmap",
            "",
            "| Priority | Action |",
            "|---|---|",
            "| P1 | Resolve all HIGH-severity findings first and patch before release. |",
            "| P2 | Address MEDIUM-severity findings in the next sprint with code review checks. |",
            "| P3 | Track LOW-severity findings in backlog and resolve during maintenance windows. |",
            "",
            "## Methodology",
            "",
            "This report was generated by OWASP Guard using prompt-engineered LLM analysis with chunking, OWASP taxonomy mapping, verification pass, and deduplication.",
            "",
            "## Report Notes",
            "",
            "- Line ranges are best effort and based on chunk-level analysis.",
            "- Findings are confidence-scored and post-processed by a verification pass.",
            "- Re-run the scan after remediation to confirm closure and risk reduction.",
        ]
    )
    return "\n".join(lines)


def write_reports(report: ScanReport, output_dir: str) -> tuple[Path, Path]:
    output = Path(output_dir).expanduser().resolve()
    try:
        output.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise ReportError(f"Unable to create output directory: {output} ({exc})") from exc
    json_path = output / "report.json"
    md_path = output / "report.md"

    try:
        json_path.write_text(json.dumps(_json_payload(report), indent=2), encoding="utf-8")
        md_path.write_text(_markdown_payload(report), encoding="utf-8")
    except OSError as exc:
        raise ReportError(f"Unable to write reports in {output} ({exc})") from exc
    return json_path, md_path
