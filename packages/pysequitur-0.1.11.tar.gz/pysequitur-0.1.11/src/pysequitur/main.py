class test:

    def __init_(self):
        print("test")
    def thing1(self):
        print("test")

    print("poo")


    def thing2(self):
        print("test")





