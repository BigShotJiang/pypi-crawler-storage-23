The codes included in StarCounts.StarCounts are required for use with the field star count metrics (CountMassMetric and CountMetric)
