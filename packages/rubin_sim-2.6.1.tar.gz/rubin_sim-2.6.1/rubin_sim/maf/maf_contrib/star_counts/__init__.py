__all__ = (
    "abs_mag",
    "coords",
    "spec_type",
    "starcount",
    "starcount_bymass",
    "stellardensity",
)
