.. py:currentmodule:: rubin_sim.moving_objects

.. _moving-objects-api:

==================
Moving Objects API
==================

.. automodule:: rubin_sim.moving_objects
    :imported-members:
    :members:
    :show-inheritance: