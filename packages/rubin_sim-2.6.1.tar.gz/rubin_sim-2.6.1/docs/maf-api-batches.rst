.. py:currentmodule:: rubin_sim.maf

.. _maf-api-batches:

=======
Batches
=======

.. automodule:: rubin_sim.maf.batches
    :imported-members:
    :members:
    :show-inheritance:
