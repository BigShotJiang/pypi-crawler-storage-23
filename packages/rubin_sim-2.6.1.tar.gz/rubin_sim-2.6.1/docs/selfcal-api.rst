.. py:currentmodule:: rubin_sim.selfcal

.. _selfcal-api:

====================
Self Calibration API
====================

.. automodule:: rubin_sim.selfcal
    :imported-members:
    :members:
    :show-inheritance: