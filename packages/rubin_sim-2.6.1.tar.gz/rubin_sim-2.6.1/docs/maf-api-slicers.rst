.. py:currentmodule:: rubin_sim.maf

.. _maf-api-slicers:

=======
Slicers
=======

.. automodule:: rubin_sim.maf.slicers
    :imported-members:
    :members:
    :show-inheritance:
