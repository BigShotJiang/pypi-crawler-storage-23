.. py:currentmodule:: rubin_sim.satellite_constellations

.. _satellite-constellations-api:

============================
Satellite Constellations API
============================

.. automodule:: rubin_sim.satellite_constellations
    :imported-members:
    :members:
    :show-inheritance: