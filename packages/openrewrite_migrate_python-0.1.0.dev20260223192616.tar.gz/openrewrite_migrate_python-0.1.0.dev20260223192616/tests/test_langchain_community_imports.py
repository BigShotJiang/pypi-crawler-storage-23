"""Tests for LangChain community import migration recipe."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.langchain_community_imports import (
    ReplaceLangchainCommunityImports,
)


class TestReplaceLangchainCommunityImports:
    """Tests for the ReplaceLangchainCommunityImports recipe."""

    def test_replaces_chat_models_import(self):
        """Test that from langchain.chat_models is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.chat_models import ChatOpenAI
                """,
                """
                from langchain_community.chat_models import ChatOpenAI
                """,
            )
        )

    def test_replaces_llms_import(self):
        """Test that from langchain.llms is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.llms import OpenAI
                """,
                """
                from langchain_community.llms import OpenAI
                """,
            )
        )

    def test_replaces_embeddings_import(self):
        """Test that from langchain.embeddings is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.embeddings import OpenAIEmbeddings
                """,
                """
                from langchain_community.embeddings import OpenAIEmbeddings
                """,
            )
        )

    def test_replaces_vectorstores_import(self):
        """Test that from langchain.vectorstores is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.vectorstores import FAISS
                """,
                """
                from langchain_community.vectorstores import FAISS
                """,
            )
        )

    def test_replaces_document_loaders_import(self):
        """Test that from langchain.document_loaders is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.document_loaders import TextLoader
                """,
                """
                from langchain_community.document_loaders import TextLoader
                """,
            )
        )

    def test_replaces_tools_import(self):
        """Test that from langchain.tools is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.tools import Tool
                """,
                """
                from langchain_community.tools import Tool
                """,
            )
        )

    def test_replaces_utilities_import(self):
        """Test that from langchain.utilities is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.utilities import SerpAPIWrapper
                """,
                """
                from langchain_community.utilities import SerpAPIWrapper
                """,
            )
        )

    def test_replaces_retrievers_import(self):
        """Test that from langchain.retrievers is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.retrievers import WikipediaRetriever
                """,
                """
                from langchain_community.retrievers import WikipediaRetriever
                """,
            )
        )

    def test_replaces_multiple_imports(self):
        """Test that multiple imports from the same module are migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.chat_models import ChatOpenAI, ChatAnthropic
                """,
                """
                from langchain_community.chat_models import ChatOpenAI, ChatAnthropic
                """,
            )
        )

    def test_replaces_agent_toolkits_import(self):
        """Test that from langchain.agent_toolkits is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.agent_toolkits import create_sql_agent
                """,
                """
                from langchain_community.agent_toolkits import create_sql_agent
                """,
            )
        )

    def test_replaces_cache_import(self):
        """Test that from langchain.cache is migrated."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.cache import InMemoryCache
                """,
                """
                from langchain_community.cache import InMemoryCache
                """,
            )
        )

    def test_no_change_for_langchain_core(self):
        """Test that langchain_core imports are not modified."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain_core.messages import HumanMessage
                """
            )
        )

    def test_no_change_for_langchain_schema(self):
        """Test that langchain.schema imports are not modified (not a community module)."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.schema import Document
                """
            )
        )

    def test_no_change_for_langchain_prompts(self):
        """Test that langchain.prompts imports are not modified (stayed in core)."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.prompts import PromptTemplate
                """
            )
        )

    def test_no_change_for_already_community(self):
        """Test that langchain_community imports are not modified."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain_community.chat_models import ChatOpenAI
                """
            )
        )

    def test_no_change_for_unrelated_import(self):
        """Test that unrelated imports are not modified."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from os.path import join
                """
            )
        )

    def test_no_change_for_plain_langchain_import(self):
        """Test that 'import langchain' is not modified."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                import langchain
                """
            )
        )

    def test_no_change_for_langchain_agents(self):
        """Test that langchain.agents imports are not modified (not a community module)."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.agents import AgentType
                """
            )
        )

    def test_no_change_for_langchain_chains(self):
        """Test that langchain.chains imports are not modified (not a community module)."""
        spec = RecipeSpec(recipe=ReplaceLangchainCommunityImports())
        spec.rewrite_run(
            python(
                """
                from langchain.chains import LLMChain
                """
            )
        )
