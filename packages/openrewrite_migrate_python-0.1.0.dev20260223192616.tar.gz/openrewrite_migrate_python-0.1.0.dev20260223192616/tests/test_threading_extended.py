"""Tests for additional threading deprecation migration recipes."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.threading_deprecations import (
    ReplaceEventIsSet,
    ReplaceThreadGetName,
    ReplaceThreadSetName,
    ReplaceThreadIsDaemon,
    ReplaceThreadSetDaemon,
)


class TestReplaceEventIsSet:
    """Tests for ReplaceEventIsSet recipe."""

    def test_replaces_event_isset(self):
        spec = RecipeSpec(recipe=ReplaceEventIsSet())
        spec.rewrite_run(
            python(
                "result = event.isSet()",
                "result = event.is_set()",
            )
        )

    def test_no_change_when_already_snake_case(self):
        spec = RecipeSpec(recipe=ReplaceEventIsSet())
        spec.rewrite_run(
            python("result = event.is_set()")
        )


class TestReplaceThreadGetName:
    """Tests for ReplaceThreadGetName recipe."""

    def test_replaces_getname(self):
        spec = RecipeSpec(recipe=ReplaceThreadGetName())
        spec.rewrite_run(
            python(
                "name = thread.getName()",
                "name = thread.name",
            )
        )

    def test_no_change_when_using_property(self):
        spec = RecipeSpec(recipe=ReplaceThreadGetName())
        spec.rewrite_run(
            python("name = thread.name")
        )


class TestReplaceThreadSetName:
    """Tests for ReplaceThreadSetName recipe."""

    def test_replaces_setname(self):
        spec = RecipeSpec(recipe=ReplaceThreadSetName())
        spec.rewrite_run(
            python(
                'thread.setName("worker")',
                'thread.name = "worker"',
            )
        )


class TestReplaceThreadIsDaemon:
    """Tests for ReplaceThreadIsDaemon recipe."""

    def test_replaces_isdaemon(self):
        spec = RecipeSpec(recipe=ReplaceThreadIsDaemon())
        spec.rewrite_run(
            python(
                "result = thread.isDaemon()",
                "result = thread.daemon",
            )
        )

    def test_no_change_when_using_property(self):
        spec = RecipeSpec(recipe=ReplaceThreadIsDaemon())
        spec.rewrite_run(
            python("result = thread.daemon")
        )


class TestReplaceThreadSetDaemon:
    """Tests for ReplaceThreadSetDaemon recipe."""

    def test_replaces_setdaemon(self):
        spec = RecipeSpec(recipe=ReplaceThreadSetDaemon())
        spec.rewrite_run(
            python(
                "thread.setDaemon(True)",
                "thread.daemon = True",
            )
        )
