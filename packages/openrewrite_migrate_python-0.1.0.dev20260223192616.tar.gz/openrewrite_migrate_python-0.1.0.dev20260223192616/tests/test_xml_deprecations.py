"""Tests for XML deprecation migration recipes."""

import pytest

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.xml_deprecations import (
    FindElementGetchildren,
    ReplaceElementGetiterator,
)


class TestReplaceElementGetiterator:
    """Tests for ReplaceElementGetiterator recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_replaces_getiterator(self):
        spec = RecipeSpec(recipe=ReplaceElementGetiterator())
        spec.rewrite_run(
            python(
                "items = list(element.getiterator())",
                "items = list(element.iter())",
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_replaces_getiterator_with_tag(self):
        spec = RecipeSpec(recipe=ReplaceElementGetiterator())
        spec.rewrite_run(
            python(
                "tags = list(element.getiterator('tag'))",
                "tags = list(element.iter('tag'))",
            )
        )

    def test_no_change_when_already_iter(self):
        spec = RecipeSpec(recipe=ReplaceElementGetiterator())
        spec.rewrite_run(
            python("items = list(element.iter())")
        )


class TestFindElementGetchildren:
    """Tests for FindElementGetchildren recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_getchildren(self):
        spec = RecipeSpec(recipe=FindElementGetchildren())
        spec.rewrite_run(
            python(
                "children = element.getchildren()",
                "children = /*~~(Element.getchildren() is deprecated. Use list(element) instead.)~~>*/element.getchildren()",
            )
        )

    def test_no_change_when_different_method(self):
        spec = RecipeSpec(recipe=FindElementGetchildren())
        spec.rewrite_run(
            python("children = list(element)")
        )
