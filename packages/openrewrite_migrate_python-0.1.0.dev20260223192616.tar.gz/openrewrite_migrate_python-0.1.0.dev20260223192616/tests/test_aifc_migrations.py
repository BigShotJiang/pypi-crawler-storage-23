"""Tests for PEP 594 audio/media module migration recipes."""

import pytest

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.aifc_migrations import (
    FindAifcModule,
    FindAudioopModule,
    FindChunkModule,
    FindImghdrModule,
    FindSndhdrModule,
    FindSunauModule,
)


class TestFindAifcModule:
    """Tests for FindAifcModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_aifc(self):
        spec = RecipeSpec(recipe=FindAifcModule())
        spec.rewrite_run(
            python(
                "import aifc",
                "/*~~(The `aifc` module was removed in Python 3.13. Use third-party audio libraries instead.)~~>*/import aifc",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindAifcModule())
        spec.rewrite_run(
            python("import wave")
        )


class TestFindAudioopModule:
    """Tests for FindAudioopModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_audioop(self):
        spec = RecipeSpec(recipe=FindAudioopModule())
        spec.rewrite_run(
            python(
                "import audioop",
                "/*~~(The `audioop` module was removed in Python 3.13. Use pydub, numpy, or scipy instead.)~~>*/import audioop",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindAudioopModule())
        spec.rewrite_run(
            python("import numpy")
        )


class TestFindChunkModule:
    """Tests for FindChunkModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_chunk(self):
        spec = RecipeSpec(recipe=FindChunkModule())
        spec.rewrite_run(
            python(
                "import chunk",
                "/*~~(The `chunk` module was removed in Python 3.13.)~~>*/import chunk",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindChunkModule())
        spec.rewrite_run(
            python("import struct")
        )


class TestFindImghdrModule:
    """Tests for FindImghdrModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_imghdr(self):
        spec = RecipeSpec(recipe=FindImghdrModule())
        spec.rewrite_run(
            python(
                "import imghdr",
                "/*~~(The `imghdr` module was removed in Python 3.13. Use `filetype`, `python-magic`, or `Pillow` instead.)~~>*/import imghdr",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindImghdrModule())
        spec.rewrite_run(
            python("import mimetypes")
        )


class TestFindSndhdrModule:
    """Tests for FindSndhdrModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_sndhdr(self):
        spec = RecipeSpec(recipe=FindSndhdrModule())
        spec.rewrite_run(
            python(
                "import sndhdr",
                "/*~~(The `sndhdr` module was removed in Python 3.13. Use `filetype` or audio libraries instead.)~~>*/import sndhdr",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindSndhdrModule())
        spec.rewrite_run(
            python("import wave")
        )


class TestFindSunauModule:
    """Tests for FindSunauModule recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_import_sunau(self):
        spec = RecipeSpec(recipe=FindSunauModule())
        spec.rewrite_run(
            python(
                "import sunau",
                "/*~~(The `sunau` module was removed in Python 3.13. Use `soundfile` or `pydub` instead.)~~>*/import sunau",
            )
        )

    def test_no_change_when_different_module(self):
        spec = RecipeSpec(recipe=FindSunauModule())
        spec.rewrite_run(
            python("import wave")
        )
