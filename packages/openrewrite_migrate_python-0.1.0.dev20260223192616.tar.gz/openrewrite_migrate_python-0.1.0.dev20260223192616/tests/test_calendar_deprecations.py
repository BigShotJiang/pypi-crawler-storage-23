"""Tests for calendar deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.calendar_deprecations import (
    ReplaceCalendarConstants,
)


class TestReplaceCalendarConstants:
    """Tests for the ReplaceCalendarConstants recipe."""

    def test_replaces_january(self):
        """Test that calendar.January is replaced with calendar.JANUARY."""
        spec = RecipeSpec(recipe=ReplaceCalendarConstants())
        spec.rewrite_run(
            python(
                """
                import calendar
                first_month = calendar.January
                """,
                """
                import calendar
                first_month = calendar.JANUARY
                """,
            )
        )

    def test_replaces_monday(self):
        """Test that calendar.Monday is replaced with calendar.MONDAY."""
        spec = RecipeSpec(recipe=ReplaceCalendarConstants())
        spec.rewrite_run(
            python(
                """
                import calendar
                start_of_week = calendar.Monday
                """,
                """
                import calendar
                start_of_week = calendar.MONDAY
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_replaces_multiple_constants(self):
        """Test that multiple constants are replaced."""
        spec = RecipeSpec(recipe=ReplaceCalendarConstants())
        spec.rewrite_run(
            python(
                """
                import calendar
                months = [calendar.January, calendar.February, calendar.December]
                days = [calendar.Monday, calendar.Friday]
                """,
                """
                import calendar
                months = [calendar.JANUARY, calendar.FEBRUARY, calendar.DECEMBER]
                days = [calendar.MONDAY, calendar.FRIDAY]
                """,
            )
        )

    def test_no_change_when_already_uppercase(self):
        """Test that already-uppercase constants are not changed."""
        spec = RecipeSpec(recipe=ReplaceCalendarConstants())
        spec.rewrite_run(
            python(
                """
                import calendar
                first_month = calendar.JANUARY
                """
            )
        )

    def test_no_change_when_different_module(self):
        """Test that non-calendar module accesses are not changed."""
        spec = RecipeSpec(recipe=ReplaceCalendarConstants())
        spec.rewrite_run(
            python(
                """
                class MyModule:
                    January = 1

                my_module = MyModule()
                first_month = my_module.January
                """
            )
        )
