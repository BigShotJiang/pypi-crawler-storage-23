"""Tests for HTMLParser.unescape() deprecation migration recipe."""

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.html_parser_deprecations import (
    FindHtmlParserUnescape,
)


class TestFindHtmlParserUnescape:
    """Tests for FindHtmlParserUnescape recipe."""

    def test_finds_parser_unescape(self):
        spec = RecipeSpec(recipe=FindHtmlParserUnescape())
        spec.rewrite_run(
            python(
                "text = parser.unescape(html_text)",
                "text = /*~~(HTMLParser.unescape() was removed in Python 3.9. Use html.unescape() instead.)~~>*/parser.unescape(html_text)",
            )
        )

    def test_no_change_when_using_html_unescape(self):
        spec = RecipeSpec(recipe=FindHtmlParserUnescape())
        spec.rewrite_run(
            python("text = html.unescape(html_text)")
        )
