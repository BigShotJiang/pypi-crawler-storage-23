"""Tests for locale deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.locale_deprecations import (
    ReplaceLocaleResetlocale,
)


class TestReplaceLocaleResetlocale:
    """Tests for the ReplaceLocaleResetlocale recipe."""

    def test_replaces_locale_resetlocale(self):
        """Test that locale.resetlocale() is replaced with setlocale."""
        spec = RecipeSpec(recipe=ReplaceLocaleResetlocale())
        spec.rewrite_run(
            python(
                """
                import locale
                locale.resetlocale()
                """,
                """
                import locale
                locale.setlocale(locale.LC_ALL, "")
                """,
            )
        )

    def test_no_change_when_setlocale(self):
        """Test that locale.setlocale() is not marked."""
        spec = RecipeSpec(recipe=ReplaceLocaleResetlocale())
        spec.rewrite_run(
            python(
                """
                import locale
                locale.setlocale(locale.LC_ALL, "")
                """
            )
        )

    def test_no_change_when_different_module(self):
        """Test that resetlocale on a different object is not marked."""
        spec = RecipeSpec(recipe=ReplaceLocaleResetlocale())
        spec.rewrite_run(
            python(
                """
                class MyLocale:
                    def resetlocale(self):
                        pass

                obj = MyLocale()
                obj.resetlocale()
                """
            )
        )
