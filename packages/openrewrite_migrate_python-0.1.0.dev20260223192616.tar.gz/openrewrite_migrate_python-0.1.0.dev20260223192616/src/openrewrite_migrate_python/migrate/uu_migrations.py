"""
Recipes for migrating from the deprecated uu module.

The uu module (uuencode/uudecode) was deprecated in Python 3.11 (PEP 594)
and removed in Python 3.13.

Replacements:
- Use `base64` module for encoding binary data as text
- Use `binascii` for low-level encoding utilities

See: https://peps.python.org/pep-0594/
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.utils import random_id
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport, Import
from rewrite.java.tree import Identifier, FieldAccess

# Define category path: Python > Migrate > Python 3.13
_Python313 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.13"),
]


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


def _get_import_name(import_node: Any) -> Optional[str]:
    """Extract the module name from an import node's qualid."""
    qualid = import_node.qualid
    if isinstance(qualid, FieldAccess):
        return qualid.name.simple_name
    if isinstance(qualid, Identifier):
        return qualid.simple_name
    return None


@categorize(_Python313)
class FindUuModule(Recipe):
    """
    Find imports of the deprecated `uu` module.

    The `uu` module (uuencode/uudecode) was deprecated in Python 3.11 and
    removed in Python 3.13 as part of PEP 594 ("Removing dead batteries").

    Alternatives:
    - Use `base64` module for encoding binary data as text
    - Use `binascii` for low-level encoding utilities

    See: https://peps.python.org/pep-0594/
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.FindUuModule"

    @property
    def display_name(self) -> str:
        return "Find deprecated `uu` module usage"

    @property
    def description(self) -> str:
        return (
            "The `uu` module was deprecated in Python 3.11 and removed in "
            "Python 3.13. Use `base64` module instead for encoding binary data."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.13", "PEP 594"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is not None:
                    if isinstance(from_part, Identifier) and from_part.simple_name == "uu":
                        return _mark_deprecated(
                            multi,
                            "The `uu` module was removed in Python 3.13. "
                            "Use the base64 module instead."
                        )
                else:
                    for import_node in multi.names:
                        name = _get_import_name(import_node)
                        if name == "uu":
                            return _mark_deprecated(
                                multi,
                                "The `uu` module was removed in Python 3.13. "
                                "Use the base64 module instead."
                            )

                return multi

            def visit_import(
                self, import_stmt: Import, p: ExecutionContext
            ) -> Optional[Import]:
                import_stmt = super().visit_import(import_stmt, p)
                if self.cursor.first_enclosing(MultiImport) is not None:
                    return import_stmt
                name = _get_import_name(import_stmt)
                if name == "uu":
                    return _mark_deprecated(
                        import_stmt,
                        "The `uu` module was removed in Python 3.13. "
                        "Use the base64 module instead."
                    )
                return import_stmt

        return Visitor()
