"""
Recipes for migrating deprecated threading module methods.

Several threading methods with camelCase names were deprecated in Python 3.10
and will be removed in Python 3.12:

- threading.currentThread() -> threading.current_thread()
- threading.activeCount() -> threading.active_count()
- threading.Condition.notifyAll() -> threading.Condition.notify_all()
- Thread.setDaemon() -> Thread.daemon = ...
- Thread.isDaemon() -> Thread.daemon
- Thread.setName() -> Thread.name = ...
- Thread.getName() -> Thread.name

See: https://docs.python.org/3/library/threading.html
"""

from typing import Any, List, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.10
_Python310 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.10"),
]


@categorize(_Python310)
class ReplaceThreadingCurrentThread(Recipe):
    """
    Replace `threading.currentThread()` with `threading.current_thread()`.

    The camelCase `currentThread()` was deprecated in Python 3.10 and
    removed in Python 3.12. Use the snake_case version instead.

    Example:
        Before:
            import threading
            t = threading.currentThread()

        After:
            import threading
            t = threading.current_thread()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceThreadingCurrentThread"

    @property
    def display_name(self) -> str:
        return "Replace `threading.currentThread()` with `threading.current_thread()`"

    @property
    def description(self) -> str:
        return (
            "Replace `threading.currentThread()` with `threading.current_thread()`. "
            "The camelCase version was deprecated in Python 3.10 and removed in 3.12."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "3.12", "threading"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "currentThread":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "threading":
                    return method

                # Replace currentThread with current_thread
                new_name = method.name.replace(_simple_name="current_thread")
                return method.replace(_name=new_name)

        return Visitor()


@categorize(_Python310)
class ReplaceThreadingActiveCount(Recipe):
    """
    Replace `threading.activeCount()` with `threading.active_count()`.

    The camelCase `activeCount()` was deprecated in Python 3.10 and
    removed in Python 3.12. Use the snake_case version instead.

    Example:
        Before:
            import threading
            count = threading.activeCount()

        After:
            import threading
            count = threading.active_count()
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceThreadingActiveCount"

    @property
    def display_name(self) -> str:
        return "Replace `threading.activeCount()` with `threading.active_count()`"

    @property
    def description(self) -> str:
        return (
            "Replace `threading.activeCount()` with `threading.active_count()`. "
            "The camelCase version was deprecated in Python 3.10 and removed in 3.12."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "3.12", "threading"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "activeCount":
                    return method

                select = method.select
                if not isinstance(select, Identifier):
                    return method
                if select.simple_name != "threading":
                    return method

                # Replace activeCount with active_count
                new_name = method.name.replace(_simple_name="active_count")
                return method.replace(_name=new_name)

        return Visitor()


@categorize(_Python310)
class ReplaceConditionNotifyAll(Recipe):
    """
    Replace `Condition.notifyAll()` with `Condition.notify_all()`.

    The camelCase `notifyAll()` was deprecated in Python 3.10 and
    removed in Python 3.12. Use the snake_case version instead.

    Example:
        Before:
            cond.notifyAll()

        After:
            cond.notify_all()

    Note: This matches any .notifyAll() call, as it's difficult to
    determine if the object is a threading.Condition at parse time.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceConditionNotifyAll"

    @property
    def display_name(self) -> str:
        return "Replace `Condition.notifyAll()` with `Condition.notify_all()`"

    @property
    def description(self) -> str:
        return (
            "Replace `notifyAll()` method calls with `notify_all()`. "
            "The camelCase version was deprecated in Python 3.10 and removed in 3.12."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "3.12", "threading"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "notifyAll":
                    return method

                # Replace notifyAll with notify_all
                new_name = method.name.replace(_simple_name="notify_all")
                return method.replace(_name=new_name)

        return Visitor()


# Pattern/template pairs for getter-to-property conversions
_obj_getName = capture('obj')
_getName_pattern = pattern("{obj}.getName()", obj=_obj_getName)
_getName_template = template("{obj}.name", obj=_obj_getName)

_obj_isDaemon = capture('obj')
_isDaemon_pattern = pattern("{obj}.isDaemon()", obj=_obj_isDaemon)
_isDaemon_template = template("{obj}.daemon", obj=_obj_isDaemon)

# Pattern/template pairs for setter-to-assignment conversions
_obj_setName = capture('obj')
_val_setName = capture('val')
_setName_pattern = pattern("{obj}.setName({val})", obj=_obj_setName, val=_val_setName)
_setName_template = template("{obj}.name = {val}", obj=_obj_setName, val=_val_setName)

_obj_setDaemon = capture('obj')
_val_setDaemon = capture('val')
_setDaemon_pattern = pattern("{obj}.setDaemon({val})", obj=_obj_setDaemon, val=_val_setDaemon)
_setDaemon_template = template("{obj}.daemon = {val}", obj=_obj_setDaemon, val=_val_setDaemon)


@categorize(_Python310)
class ReplaceEventIsSet(Recipe):
    """
    Replace `Event.isSet()` with `Event.is_set()`.

    The camelCase `isSet()` was deprecated in Python 3.10 and
    removed in Python 3.12. Use the snake_case version instead.

    Example:
        Before:
            event.isSet()

        After:
            event.is_set()

    Note: This matches any .isSet() call, as it's difficult to
    determine if the object is a threading.Event at parse time.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceEventIsSet"

    @property
    def display_name(self) -> str:
        return "Replace `Event.isSet()` with `Event.is_set()`"

    @property
    def description(self) -> str:
        return (
            "Replace `isSet()` method calls with `is_set()`. "
            "The camelCase version was deprecated in Python 3.10 and removed in 3.12."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "3.12", "threading"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method
                if method.name.simple_name != "isSet":
                    return method

                # Replace isSet with is_set
                new_name = method.name.replace(_simple_name="is_set")
                return method.replace(_name=new_name)

        return Visitor()


@categorize(_Python310)
class ReplaceThreadGetName(Recipe):
    """
    Replace `Thread.getName()` with `Thread.name`.

    `Thread.getName()` was deprecated in Python 3.10 and removed in
    Python 3.12. Use the `name` property instead.

    Example:
        Before:
            name = thread.getName()

        After:
            name = thread.name
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceThreadGetName"

    @property
    def display_name(self) -> str:
        return "Replace `Thread.getName()` with `Thread.name`"

    @property
    def description(self) -> str:
        return (
            "Replace `getName()` method calls with the `name` property. "
            "Deprecated in Python 3.10, removed in 3.12."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "3.12", "threading"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ):
                method = super().visit_method_invocation(method, p)
                match = _getName_pattern.match(method, self.cursor)
                if match:
                    return _getName_template.apply(self.cursor, values=match)
                return method

        return Visitor()


@categorize(_Python310)
class ReplaceThreadSetName(Recipe):
    """
    Replace `Thread.setName(x)` with `Thread.name = x`.

    `Thread.setName()` was deprecated in Python 3.10 and removed in
    Python 3.12. Use the `name` property instead.

    Example:
        Before:
            thread.setName("worker")

        After:
            thread.name = "worker"
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceThreadSetName"

    @property
    def display_name(self) -> str:
        return "Replace `Thread.setName()` with `Thread.name = ...`"

    @property
    def description(self) -> str:
        return (
            "Replace `setName()` method calls with `name` property assignment. "
            "Deprecated in Python 3.10, removed in 3.12."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "3.12", "threading"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ):
                method = super().visit_method_invocation(method, p)
                match = _setName_pattern.match(method, self.cursor)
                if match:
                    return _setName_template.apply(self.cursor, values=match)
                return method

        return Visitor()


@categorize(_Python310)
class ReplaceThreadIsDaemon(Recipe):
    """
    Replace `Thread.isDaemon()` with `Thread.daemon`.

    `Thread.isDaemon()` was deprecated in Python 3.10 and removed in
    Python 3.12. Use the `daemon` property instead.

    Example:
        Before:
            is_daemon = thread.isDaemon()

        After:
            is_daemon = thread.daemon
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceThreadIsDaemon"

    @property
    def display_name(self) -> str:
        return "Replace `Thread.isDaemon()` with `Thread.daemon`"

    @property
    def description(self) -> str:
        return (
            "Replace `isDaemon()` method calls with the `daemon` property. "
            "Deprecated in Python 3.10, removed in 3.12."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "3.12", "threading"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ):
                method = super().visit_method_invocation(method, p)
                match = _isDaemon_pattern.match(method, self.cursor)
                if match:
                    return _isDaemon_template.apply(self.cursor, values=match)
                return method

        return Visitor()


@categorize(_Python310)
class ReplaceThreadSetDaemon(Recipe):
    """
    Replace `Thread.setDaemon(x)` with `Thread.daemon = x`.

    `Thread.setDaemon()` was deprecated in Python 3.10 and removed in
    Python 3.12. Use the `daemon` property instead.

    Example:
        Before:
            thread.setDaemon(True)

        After:
            thread.daemon = True
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceThreadSetDaemon"

    @property
    def display_name(self) -> str:
        return "Replace `Thread.setDaemon()` with `Thread.daemon = ...`"

    @property
    def description(self) -> str:
        return (
            "Replace `setDaemon()` method calls with `daemon` property assignment. "
            "Deprecated in Python 3.10, removed in 3.12."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "3.10", "3.12", "threading"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ):
                method = super().visit_method_invocation(method, p)
                match = _setDaemon_pattern.match(method, self.cursor)
                if match:
                    return _setDaemon_template.apply(self.cursor, values=match)
                return method

        return Visitor()
