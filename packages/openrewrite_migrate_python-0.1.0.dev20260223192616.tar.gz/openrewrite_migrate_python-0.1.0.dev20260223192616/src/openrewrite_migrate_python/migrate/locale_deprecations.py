"""
Recipes for migrating deprecated locale module functions.

locale.resetlocale() was deprecated in Python 3.11 and removed in Python 3.13.
The replacement is locale.setlocale(locale.LC_ALL, "").

See: https://docs.python.org/3/library/locale.html
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation, Literal
from rewrite.java.support_types import JRightPadded, Space
from rewrite.utils import random_id

# Define category path: Python > Migrate > Python 3.11
_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]


def _is_locale_method(method: MethodInvocation, method_name: str) -> bool:
    """
    Check if this is a locale.method_name() call.

    Uses multiple strategies to identify the method:
    1. Check method name matches
    2. Check type attribution if available (FQN contains 'locale')
    3. Check simple name on select is 'locale'
    """
    # Check method name first
    if not isinstance(method.name, Identifier):
        return False
    if method.name.simple_name != method_name:
        return False

    # Check if type info confirms this is a locale method
    if method.method_type and method.method_type.declaring_type:
        dt = method.method_type.declaring_type
        if hasattr(dt, '_fully_qualified_name'):
            fqn = str(dt._fully_qualified_name)
            if 'locale' in fqn:
                return True

    # Fallback: Check simple name on select
    select = method.select
    if select is None:
        return False
    if isinstance(select, Identifier) and select.simple_name == "locale":
        return True

    return False


def _rename_method(method: MethodInvocation, new_name: str) -> MethodInvocation:
    """Rename a method invocation."""
    old_name = method.name
    if not isinstance(old_name, Identifier):
        return method

    new_identifier = old_name.replace(_simple_name=new_name)
    return method.replace(_name=new_identifier)


def _set_arguments(method: MethodInvocation, *arg_specs: tuple) -> MethodInvocation:
    """
    Replace all arguments in a method invocation.

    Each arg_spec is a tuple of (type, value) where:
    - ("id", "name") creates an identifier
    - ("str", "value") creates a string literal
    """
    from rewrite.java.tree import Identifier as JIdentifier, Empty

    # Get current arguments container
    old_container = method.padding.arguments

    new_elements = []
    for i, (arg_type, arg_value) in enumerate(arg_specs):
        # Add space prefix for arguments after the first
        prefix = Space.SINGLE_SPACE if i > 0 else Space.EMPTY

        if arg_type == "id":
            new_arg = JIdentifier(
                _id=random_id(),
                _prefix=prefix,
                _markers=Markers.EMPTY,
                _annotations=[],
                _simple_name=arg_value,
                _type=None,
                _field_type=None
            )
        elif arg_type == "str":
            new_arg = Literal(
                _id=random_id(),
                _prefix=prefix,
                _markers=Markers.EMPTY,
                _value=arg_value,
                _value_source=f'"{arg_value}"',
                _unicode_escapes=None,
                _type=None
            )
        else:
            continue

        new_padded = JRightPadded(new_arg, Space.EMPTY, Markers.EMPTY)
        new_elements.append(new_padded)

    # Create new JContainer with the new elements
    new_container = old_container.replace(_elements=new_elements)

    return method.replace(_arguments=new_container)


@categorize(_Python311)
class ReplaceLocaleResetlocale(Recipe):
    """
    Replace `locale.resetlocale()` calls with `locale.setlocale(locale.LC_ALL, "")`.

    The `locale.resetlocale()` function was deprecated in Python 3.11 and
    removed in Python 3.13. The recommended replacement is
    `locale.setlocale(locale.LC_ALL, "")`.

    Example:
        Before:
            import locale
            locale.resetlocale()

        After:
            import locale
            locale.setlocale(locale.LC_ALL, "")
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceLocaleResetlocale"

    @property
    def display_name(self) -> str:
        return "Replace `locale.resetlocale()` with `locale.setlocale(LC_ALL, '')`"

    @property
    def description(self) -> str:
        return (
            "The `locale.resetlocale()` function was deprecated in Python 3.11 and "
            "removed in Python 3.13. Replace with `locale.setlocale(locale.LC_ALL, '')`."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if _is_locale_method(method, "resetlocale"):
                    # Rename resetlocale -> setlocale
                    method = _rename_method(method, "setlocale")
                    # Set arguments to (locale.LC_ALL, "")
                    method = _set_arguments(
                        method,
                        ("id", "locale.LC_ALL"),
                        ("str", "")
                    )
                    return method

                return method

        return Visitor()
