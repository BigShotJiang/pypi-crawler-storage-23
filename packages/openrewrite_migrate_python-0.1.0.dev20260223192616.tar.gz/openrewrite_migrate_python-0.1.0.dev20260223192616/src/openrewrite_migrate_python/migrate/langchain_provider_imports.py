"""
Recipes for migrating langchain_community imports to provider-specific packages.

In LangChain v0.2+, provider-specific classes should be imported from their
dedicated packages instead of langchain_community. For example:

    from langchain_community.chat_models import ChatOpenAI
    from langchain_community.embeddings import OpenAIEmbeddings
    from langchain_community.vectorstores import Pinecone

should become:

    from langchain_openai import ChatOpenAI
    from langchain_openai import OpenAIEmbeddings
    from langchain_pinecone import Pinecone

See: https://python.langchain.com/v0.2/docs/versions/v0_2/
"""

from typing import Any, Dict, List, Optional, Set, Tuple

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport
from rewrite.java.tree import FieldAccess, Identifier
from rewrite.utils import random_id

_LangChain02 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="LangChain 0.2"),
]

# Maps (submodule, class_name) -> provider_package
PROVIDER_MAPPING: Dict[Tuple[str, str], str] = {
    # OpenAI
    ("chat_models", "ChatOpenAI"): "langchain_openai",
    ("chat_models", "AzureChatOpenAI"): "langchain_openai",
    ("llms", "OpenAI"): "langchain_openai",
    ("llms", "AzureOpenAI"): "langchain_openai",
    ("embeddings", "OpenAIEmbeddings"): "langchain_openai",
    ("embeddings", "AzureOpenAIEmbeddings"): "langchain_openai",
    # Anthropic
    ("chat_models", "ChatAnthropic"): "langchain_anthropic",
    ("llms", "Anthropic"): "langchain_anthropic",
    # Google GenAI
    ("chat_models", "ChatGoogleGenerativeAI"): "langchain_google_genai",
    ("llms", "GoogleGenerativeAI"): "langchain_google_genai",
    ("embeddings", "GoogleGenerativeAIEmbeddings"): "langchain_google_genai",
    # Google Vertex AI
    ("chat_models", "ChatVertexAI"): "langchain_google_vertexai",
    ("llms", "VertexAI"): "langchain_google_vertexai",
    ("embeddings", "VertexAIEmbeddings"): "langchain_google_vertexai",
    # AWS
    ("chat_models", "ChatBedrock"): "langchain_aws",
    ("chat_models", "ChatBedrockConverse"): "langchain_aws",
    ("llms", "Bedrock"): "langchain_aws",
    ("llms", "BedrockLLM"): "langchain_aws",
    ("embeddings", "BedrockEmbeddings"): "langchain_aws",
    # Cohere
    ("chat_models", "ChatCohere"): "langchain_cohere",
    ("llms", "Cohere"): "langchain_cohere",
    ("embeddings", "CohereEmbeddings"): "langchain_cohere",
    # Fireworks
    ("chat_models", "ChatFireworks"): "langchain_fireworks",
    ("llms", "Fireworks"): "langchain_fireworks",
    ("embeddings", "FireworksEmbeddings"): "langchain_fireworks",
    # Groq
    ("chat_models", "ChatGroq"): "langchain_groq",
    # MistralAI
    ("chat_models", "ChatMistralAI"): "langchain_mistralai",
    ("embeddings", "MistralAIEmbeddings"): "langchain_mistralai",
    # Ollama
    ("chat_models", "ChatOllama"): "langchain_ollama",
    ("llms", "Ollama"): "langchain_ollama",
    ("embeddings", "OllamaEmbeddings"): "langchain_ollama",
    # Pinecone
    ("vectorstores", "Pinecone"): "langchain_pinecone",
    # Chroma
    ("vectorstores", "Chroma"): "langchain_chroma",
    # HuggingFace
    ("embeddings", "HuggingFaceEmbeddings"): "langchain_huggingface",
    ("embeddings", "HuggingFaceBgeEmbeddings"): "langchain_huggingface",
    ("embeddings", "HuggingFaceInstructEmbeddings"): "langchain_huggingface",
    ("llms", "HuggingFacePipeline"): "langchain_huggingface",
    ("llms", "HuggingFaceEndpoint"): "langchain_huggingface",
    ("llms", "HuggingFaceHub"): "langchain_huggingface",
    # Nvidia
    ("chat_models", "ChatNVIDIA"): "langchain_nvidia_ai_endpoints",
    ("embeddings", "NVIDIAEmbeddings"): "langchain_nvidia_ai_endpoints",
    # IBM
    ("chat_models", "ChatWatsonx"): "langchain_ibm",
    ("llms", "WatsonxLLM"): "langchain_ibm",
    ("embeddings", "WatsonxEmbeddings"): "langchain_ibm",
    # Together
    ("chat_models", "ChatTogether"): "langchain_together",
    ("llms", "Together"): "langchain_together",
    ("embeddings", "TogetherEmbeddings"): "langchain_together",
}


def _get_import_names(multi: MultiImport) -> List[str]:
    """Get the list of names being imported from a MultiImport."""
    names = []
    for import_node in multi.names:
        qualid = import_node.qualid
        if isinstance(qualid, FieldAccess):
            if isinstance(qualid.name, Identifier):
                names.append(qualid.name.simple_name)
        elif isinstance(qualid, Identifier):
            names.append(qualid.simple_name)
    return names


def _get_submodule_from_community(from_part: Any) -> Optional[str]:
    """Get the submodule name from a langchain_community.X import.

    Returns the submodule name if from_part is 'langchain_community.X',
    None otherwise.
    """
    if not isinstance(from_part, FieldAccess):
        return None
    if not isinstance(from_part.target, Identifier):
        return None
    if from_part.target.simple_name != "langchain_community":
        return None
    if isinstance(from_part.name, Identifier):
        return from_part.name.simple_name
    return None


def _mark_provider_migration(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a provider migration suggestion."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_LangChain02)
class ReplaceLangchainProviderImports(Recipe):
    """
    Replace `langchain_community` imports with provider-specific packages.

    Provider-specific classes should be imported from their dedicated packages
    for better dependency management and versioning. This recipe auto-fixes
    imports when all imported classes map to the same provider package.

    Example:
        Before:
            from langchain_community.chat_models import ChatOpenAI

        After:
            from langchain_openai import ChatOpenAI
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.langchain.ReplaceLangchainProviderImports"

    @property
    def display_name(self) -> str:
        return "Replace `langchain_community` imports with provider packages"

    @property
    def description(self) -> str:
        return (
            "Migrate provider-specific imports from `langchain_community` to "
            "dedicated provider packages like `langchain_openai`, "
            "`langchain_anthropic`, etc."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "langchain", "0.2"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is None:
                    return multi

                submodule = _get_submodule_from_community(from_part)
                if submodule is None:
                    return multi

                imported_names = _get_import_names(multi)
                if not imported_names:
                    return multi

                # Look up provider packages for all imported names
                providers: Set[str] = set()
                has_unmapped = False
                for class_name in imported_names:
                    key = (submodule, class_name)
                    if key in PROVIDER_MAPPING:
                        providers.add(PROVIDER_MAPPING[key])
                    else:
                        has_unmapped = True

                if not providers:
                    return multi

                # Auto-fix only when all classes map to the same provider
                # and none are unmapped
                if len(providers) == 1 and not has_unmapped:
                    provider_package = providers.pop()
                    new_from = Identifier(
                        _id=random_id(),
                        _prefix=from_part.prefix,
                        _markers=Markers.EMPTY,
                        _annotations=[],
                        _simple_name=provider_package,
                        _type=None,
                        _field_type=None,
                    )
                    old_padded_from = multi.padding.from_
                    if old_padded_from is None:
                        return multi
                    new_padded_from = old_padded_from.replace(_element=new_from)
                    return multi.padding.replace(_from=new_padded_from)

                # Flag mixed-provider imports for manual migration
                provider_list = ", ".join(sorted(providers))
                return _mark_provider_migration(
                    multi,
                    f"Split this import across provider packages: {provider_list}",
                )

        return Visitor()
