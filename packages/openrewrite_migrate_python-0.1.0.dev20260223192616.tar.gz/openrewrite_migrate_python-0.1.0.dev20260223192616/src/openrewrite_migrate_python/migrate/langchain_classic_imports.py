"""
Recipes for migrating langchain imports to langchain_classic (v1.0).

In LangChain v1.0, legacy chains, retrievers, and indexing functionality
were moved from `langchain` to `langchain_classic`. This recipe handles:

    from langchain.chains import LLMChain -> from langchain_classic.chains import LLMChain
    from langchain.retrievers import ... -> from langchain_classic.retrievers import ...
    from langchain.indexes import ... -> from langchain_classic.indexes import ...
    from langchain import hub -> from langchain_classic import hub

See: https://docs.langchain.com/oss/python/migrate/langchain-v1
"""

from typing import Any, List, Optional, Set

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.markers import Markers, SearchResult
from rewrite.python.visitor import PythonVisitor
from rewrite.python.tree import MultiImport
from rewrite.java.tree import FieldAccess, Identifier
from rewrite.utils import random_id

_LangChain1 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="LangChain 1.0"),
]

# Submodules that moved from langchain to langchain_classic in v1.0
CLASSIC_SUBMODULES: Set[str] = {
    "chains",
    "indexes",
    "retrievers",
}

# Names that can be imported directly from langchain but moved to langchain_classic
CLASSIC_DIRECT_IMPORTS: Set[str] = {
    "hub",
}


def _get_root_and_first_submodule(from_part: Any) -> tuple:
    """Extract root module name and first submodule from a FieldAccess chain."""
    if not isinstance(from_part, FieldAccess):
        return None, None

    current = from_part
    while isinstance(current.target, FieldAccess):
        current = current.target

    if isinstance(current.target, Identifier):
        return current.target.simple_name, current.name.simple_name
    return None, None


def _replace_root_module(from_part: Any, new_root_name: str) -> Any:
    """Replace the root module name in a FieldAccess chain."""
    if isinstance(from_part, Identifier):
        return from_part.replace(_simple_name=new_root_name)
    if isinstance(from_part, FieldAccess):
        new_target = _replace_root_module(from_part.target, new_root_name)
        return from_part.replace(_target=new_target)
    return from_part


def _get_import_names(multi: MultiImport) -> List[str]:
    """Get the list of names being imported from a MultiImport."""
    names = []
    for import_node in multi.names:
        qualid = import_node.qualid
        if isinstance(qualid, FieldAccess):
            if isinstance(qualid.name, Identifier):
                names.append(qualid.name.simple_name)
        elif isinstance(qualid, Identifier):
            names.append(qualid.simple_name)
    return names


def _mark_deprecated(tree: Any, message: str) -> Any:
    """Add a SearchResult marker for a deprecation warning."""
    search_marker = SearchResult(random_id(), message)
    current_markers = tree.markers
    new_markers_list = list(current_markers.markers) + [search_marker]
    new_markers = Markers(current_markers.id, new_markers_list)
    return tree.replace(_markers=new_markers)


@categorize(_LangChain1)
class ReplaceLangchainClassicImports(Recipe):
    """
    Replace `langchain` legacy imports with `langchain_classic`.

    In LangChain v1.0, legacy chains, retrievers, and indexing functionality
    were moved to `langchain_classic`.

    Example:
        Before:
            from langchain.chains import LLMChain

        After:
            from langchain_classic.chains import LLMChain
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.langchain.ReplaceLangchainClassicImports"

    @property
    def display_name(self) -> str:
        return "Replace `langchain` legacy imports with `langchain_classic`"

    @property
    def description(self) -> str:
        return (
            "Migrate legacy chain, retriever, and indexing imports from "
            "`langchain` to `langchain_classic`. These were moved in "
            "LangChain v1.0."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "langchain", "1.0"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is None:
                    return multi

                # Handle 'from langchain.chains import ...' pattern
                if isinstance(from_part, FieldAccess):
                    root_name, first_sub = _get_root_and_first_submodule(from_part)
                    if root_name != "langchain":
                        return multi
                    if first_sub not in CLASSIC_SUBMODULES:
                        return multi

                    new_from = _replace_root_module(from_part, "langchain_classic")
                    old_padded_from = multi.padding.from_
                    if old_padded_from is None:
                        return multi
                    new_padded_from = old_padded_from.replace(_element=new_from)
                    return multi.padding.replace(_from=new_padded_from)

                # Handle 'from langchain import hub' pattern
                if isinstance(from_part, Identifier) and from_part.simple_name == "langchain":
                    imported_names = _get_import_names(multi)
                    if all(name in CLASSIC_DIRECT_IMPORTS for name in imported_names):
                        new_from = from_part.replace(_simple_name="langchain_classic")
                        old_padded_from = multi.padding.from_
                        if old_padded_from is None:
                            return multi
                        new_padded_from = old_padded_from.replace(_element=new_from)
                        return multi.padding.replace(_from=new_padded_from)

                return multi

        return Visitor()


@categorize(_LangChain1)
class FindDeprecatedLangchainAgents(Recipe):
    """
    Find deprecated LangChain agent patterns.

    In LangChain v1.0, the legacy agent helpers `initialize_agent` and
    `AgentExecutor` are deprecated. Use `create_agent` instead.

    Also detects usage of deprecated `LLMChain` which should be replaced
    with direct LLM invocation or LangGraph agents.
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.langchain.FindDeprecatedLangchainAgents"

    @property
    def display_name(self) -> str:
        return "Find deprecated LangChain agent patterns"

    @property
    def description(self) -> str:
        return (
            "Find usage of deprecated LangChain agent patterns including "
            "`initialize_agent`, `AgentExecutor`, and `LLMChain`. These "
            "were deprecated in LangChain v0.2 and removed in v1.0."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "langchain", "1.0"]

    DEPRECATED_IMPORTS: Set[str] = {
        "initialize_agent",
        "AgentExecutor",
        "LLMChain",
        "ConversationChain",
        "LLMRequestsChain",
        "TransformChain",
    }

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        deprecated_imports = self.DEPRECATED_IMPORTS

        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is None:
                    return multi

                imported_names = _get_import_names(multi)
                found_deprecated = [
                    name for name in imported_names if name in deprecated_imports
                ]

                if found_deprecated:
                    names_str = ", ".join(found_deprecated)
                    return _mark_deprecated(
                        multi,
                        f"Deprecated LangChain API: {names_str} "
                        f"(use create_agent / LangGraph in v1.0)",
                    )

                return multi

        return Visitor()


@categorize(_LangChain1)
class FindLangchainCreateReactAgent(Recipe):
    """
    Find `create_react_agent` imports that should be migrated.

    In LangChain v1.0, the agent creation function was renamed:

        from langgraph.prebuilt import create_react_agent

    should become:

        from langchain.agents import create_agent
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.langchain.FindLangchainCreateReactAgent"

    @property
    def display_name(self) -> str:
        return "Find `create_react_agent` usage (replace with `create_agent`)"

    @property
    def description(self) -> str:
        return (
            "Find `from langgraph.prebuilt import create_react_agent` which "
            "should be replaced with `from langchain.agents import create_agent` "
            "in LangChain v1.0."
        )

    @property
    def tags(self) -> List[str]:
        return ["python", "migration", "langchain", "1.0"]

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_multi_import(
                self, multi: MultiImport, p: ExecutionContext
            ) -> Optional[MultiImport]:
                multi = super().visit_multi_import(multi, p)

                from_part = multi.from_
                if from_part is None:
                    return multi

                # Check for 'from langgraph.prebuilt import create_react_agent'
                if not isinstance(from_part, FieldAccess):
                    return multi
                if not isinstance(from_part.target, Identifier):
                    return multi
                if from_part.target.simple_name != "langgraph":
                    return multi
                if not isinstance(from_part.name, Identifier):
                    return multi
                if from_part.name.simple_name != "prebuilt":
                    return multi

                imported_names = _get_import_names(multi)
                if "create_react_agent" not in imported_names:
                    return multi

                return _mark_deprecated(
                    multi,
                    "Migrate to `from langchain.agents import create_agent` (LangChain v1.0)",
                )

        return Visitor()
