"""Domain model tests."""
