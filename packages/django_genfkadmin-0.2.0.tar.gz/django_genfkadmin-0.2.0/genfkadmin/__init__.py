FIELD_ID_FORMAT = "{app_label}${model_name}[{pk}]"
GENERIC_FIELD_NAME = "{field_name}_gfk"
