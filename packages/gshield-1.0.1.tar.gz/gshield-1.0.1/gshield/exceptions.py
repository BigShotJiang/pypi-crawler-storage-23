"""
Gshield SDK 自定义异常
"""


class GshieldError(Exception):
    """Gshield SDK 基础异常"""
    pass


class GshieldConnectionError(GshieldError):
    """WebSocket 连接异常"""
    pass


class SessionError(GshieldError):
    """会话相关异常"""
    pass


class SessionNotFoundError(SessionError):
    """会话不存在"""
    pass


class SessionExistsError(SessionError):
    """会话已存在"""
    pass


class ClassifyError(GshieldError):
    """分类推理异常"""
    pass


class ProtocolError(GshieldError):
    """协议解析异常（收到非预期消息格式）"""
    pass
