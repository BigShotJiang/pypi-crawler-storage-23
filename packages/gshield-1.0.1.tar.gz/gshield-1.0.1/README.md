# Gshield SDK

Gshield 流式文本安全检测 Python SDK，通过 WebSocket 长连接实现 LLM 流式输出的实时内容安全检测。

## 安装

```bash
pip install -e ./gshield-sdk
```

## 快速开始

### 异步用法

```python
import asyncio
from gshield import GshieldStreamClient

async def main():
    async with GshieldStreamClient("ws://localhost:6006/ws/classify") as client:
        session = await client.create_session(
            classify_every_n_chars=100,
            classify_interval_secs=3.0,
        )
        session.on_result(lambda e: print(f"{e.result.main_label} ({e.result.main_confidence:.4f})"))

        for chunk in ["你好", "，这是", "一段测试", "文本。"]:
            await session.send_delta(chunk)

        final = await session.finish()
        print(f"终检: {final.main_label}")

asyncio.run(main())
```

### 同步用法

```python
from gshield import SyncGshieldStreamClient

with SyncGshieldStreamClient("ws://localhost:6006/ws/classify") as client:
    session = client.create_session()
    for chunk in ["你好", "，这是", "一段测试", "文本。"]:
        client.send_delta(session, chunk)
    final = client.finish(session)
    print(f"终检: {final.main_label}")
```

## 依赖

- Python >= 3.8
- websockets >= 11.0
- pydantic >= 2.0
