#	digtick - Digital logic design toolkit: simplify, minimize and transform Boolean expressions, draw KV-maps, etc.
#	Copyright (C) 2022-2026 Johannes Bauer
#
#	This file is part of digtick.
#
#	digtick is free software; you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation; this program is ONLY licensed under
#	version 3 of the License, later versions are explicitly excluded.
#
#	digtick is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with digtick; if not, write to the Free Software
#	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#	Johannes Bauer <JohannesBauer@gmx.de>

import pysvgedit
from .MultiCommand import BaseAction
from .DigitalTimingDiagram import DigitalTimingDiagram
from .Tools import open_file

class ActionDTDRender(BaseAction):
	def run(self):
		dtd = DigitalTimingDiagram()
		with open_file(self._args.filename) as f:
			timing_diagram_text = f.read()
		dtd.parse_and_write(timing_diagram_text)

		pysvgedit.Convenience.autosize(dtd.svg)
		with open(self._args.output_filename, "w") as f:
			dtd.svg.write(f)
