"""Tests for the beunec-asps package."""

import pytest

from beunec_asps.types import (
    ASPS,
    DistilledHeuristic,
    SkillDistillation,
    SkillReinforcement,
    AgenticNetwork,
)
from beunec_asps.asd import (
    create_heuristic,
    compile_heuristics_to_prompt,
    distill,
    HEURISTIC_LIBRARIES,
)
from beunec_asps.asr import (
    create_checkpoint,
    create_pseudonym_protocol,
    create_icrl_config,
    reinforce,
    wrap_prompt_with_reinforcement,
    GUARDRAIL_PRESETS,
    CHECKPOINT_PRESETS,
)
from beunec_asps.ans import (
    create_node,
    create_handoff,
    NetworkTopologies,
    build_network,
    generate_network_prompt_block,
)
from beunec_asps.builder import ASPSBuilder, build_asps
from beunec_asps.templates import ASPS_TEMPLATES


# ─── ASD™ Tests ──────────────────────────────────────────────────────


class TestASD:
    def test_create_heuristic_defaults(self):
        h = create_heuristic(name="Test", instruction="Do it")
        assert h.name == "Test"
        assert h.instruction == "Do it"
        assert h.determinism_score == 0.8
        assert h.input_schema == "string"
        assert h.output_schema == "string"
        assert h.id.startswith("heuristic-")

    def test_create_heuristic_custom(self):
        h = create_heuristic(
            name="Custom",
            instruction="Custom instruction",
            id="my-h",
            constraints=["c1", "c2"],
            determinism_score=0.95,
            sequence_index=42,
        )
        assert h.id == "my-h"
        assert h.constraints == ["c1", "c2"]
        assert h.determinism_score == 0.95
        assert h.sequence_index == 42

    def test_compile_heuristics_to_prompt(self):
        heuristics = [
            create_heuristic(name="Step A", instruction="Do A", sequence_index=2),
            create_heuristic(name="Step B", instruction="Do B", sequence_index=1),
        ]
        prompt = compile_heuristics_to_prompt("testing", heuristics)
        assert "Step 1: Step B" in prompt
        assert "Step 2: Step A" in prompt
        assert "expert testing agent" in prompt

    def test_distill(self):
        heuristics = [
            create_heuristic(name="H1", instruction="Inst1", sequence_index=1),
        ]
        result = distill("my-domain", heuristics, version="2.0.0")
        assert isinstance(result, SkillDistillation)
        assert result.version == "2.0.0"
        assert result.domain == "my-domain"
        assert result.distillation_id.startswith("asd-my-domain-")
        assert result.metadata.total_heuristics == 1

    def test_heuristic_libraries_exist(self):
        assert len(HEURISTIC_LIBRARIES) == 7
        for key, chain in HEURISTIC_LIBRARIES.items():
            assert len(chain) >= 5, f"{key} has only {len(chain)} heuristics"


# ─── ASR™ Tests ──────────────────────────────────────────────────────


class TestASR:
    def test_create_checkpoint(self):
        cp = create_checkpoint(name="Gate", condition="Check X")
        assert cp.name == "Gate"
        assert cp.failure_action == "halt"
        assert cp.severity == "warning"

    def test_create_pseudonym_protocol(self):
        pp = create_pseudonym_protocol(identity="Bot", persona="Helper")
        assert pp.identity == "Bot"
        assert len(pp.red_lines) == 3  # defaults

    def test_create_icrl_config(self):
        icrl = create_icrl_config(drift_tolerance=0.3)
        assert icrl.drift_tolerance == 0.3
        assert icrl.exemplar_count == 3

    def test_guardrail_presets(self):
        assert len(GUARDRAIL_PRESETS) == 5
        for key, rules in GUARDRAIL_PRESETS.items():
            assert len(rules) == 5, f"{key} has {len(rules)} rules"

    def test_checkpoint_presets(self):
        assert "standard" in CHECKPOINT_PRESETS
        assert len(CHECKPOINT_PRESETS["standard"]) == 5

    def test_reinforce(self):
        pp = create_pseudonym_protocol(identity="Agent", persona="Helper")
        r = reinforce(
            "asd-test-123",
            pseudonym_protocol=pp,
            guardrail_presets=["standard", "financial"],
        )
        assert isinstance(r, SkillReinforcement)
        assert r.distillation_id == "asd-test-123"
        assert len(r.guardrails) == 10  # 5 standard + 5 financial
        assert r.reinforcement_id.startswith("asr-")

    def test_wrap_prompt_with_reinforcement(self):
        pp = create_pseudonym_protocol(identity="Agent", persona="Helper")
        r = reinforce("asd-test-456", pseudonym_protocol=pp)
        wrapped = wrap_prompt_with_reinforcement("Do the thing.", r)
        assert "[IDENTITY]" in wrapped
        assert "[GUARDRAILS]" in wrapped
        assert "[BEHAVIORAL CHECKPOINTS]" in wrapped
        assert "[SKILL INSTRUCTIONS]" in wrapped
        assert "Do the thing." in wrapped


# ─── ANS™ Tests ──────────────────────────────────────────────────────


class TestANS:
    def test_create_node(self):
        n = create_node(node_type="agent", label="Worker")
        assert n.node_type == "agent"
        assert n.label == "Worker"
        assert n.node_id.startswith("node-")

    def test_create_handoff(self):
        h = create_handoff(from_node_id="n1", to_node_id="n2")
        assert h.from_node_id == "n1"
        assert h.to_node_id == "n2"
        assert h.timeout_ms == 30_000

    def test_hub_and_spoke(self):
        topo = NetworkTopologies.hub_and_spoke(
            orchestrator_label="Hub",
            spokes=[
                {"label": "Spoke1", "node_type": "agent", "capabilities": ["a"]},
                {"label": "Spoke2", "node_type": "api", "capabilities": ["b"]},
            ],
        )
        assert len(topo["nodes"]) == 4  # hub + 2 spokes + governance
        # 2 spokes × 2 directions + 1 governance = 5
        assert len(topo["handoffs"]) == 5

    def test_pipeline(self):
        topo = NetworkTopologies.pipeline(
            stages=[
                {"label": "S1", "node_type": "agent", "capabilities": ["x"]},
                {"label": "S2", "node_type": "agent", "capabilities": ["y"]},
                {"label": "S3", "node_type": "agent", "capabilities": ["z"]},
            ],
        )
        # 3 stages + governance = 4 nodes
        assert len(topo["nodes"]) == 4
        # 2 pipeline links + 3 audit links = 5
        assert len(topo["handoffs"]) == 5

    def test_mesh(self):
        topo = NetworkTopologies.mesh(
            agents=[
                {"label": "A", "capabilities": ["x"]},
                {"label": "B", "capabilities": ["y"]},
                {"label": "C", "capabilities": ["z"]},
            ],
        )
        # 3 agents + governance = 4
        assert len(topo["nodes"]) == 4
        # C(3,2) * 2 bidirectional + 3 audit = 6 + 3 = 9
        assert len(topo["handoffs"]) == 9

    def test_build_network(self):
        topo = NetworkTopologies.hub_and_spoke(
            orchestrator_label="Hub",
            spokes=[{"label": "S1", "node_type": "agent", "capabilities": []}],
        )
        net = build_network("asr-test-1", topo)
        assert isinstance(net, AgenticNetwork)
        assert net.reinforcement_id == "asr-test-1"

    def test_generate_network_prompt_block(self):
        topo = NetworkTopologies.hub_and_spoke(
            orchestrator_label="Hub",
            spokes=[{"label": "S1", "node_type": "agent", "capabilities": ["work"]}],
        )
        net = build_network("asr-test-2", topo)
        block = generate_network_prompt_block(net)
        assert "[AGENTIC NETWORK]" in block
        assert "Hub" in block


# ─── Builder Tests ───────────────────────────────────────────────────


class TestBuilder:
    def _make_skill(self) -> ASPS:
        heuristics = [
            create_heuristic(name="H1", instruction="Do H1", sequence_index=1),
            create_heuristic(name="H2", instruction="Do H2", sequence_index=2),
        ]
        pp = create_pseudonym_protocol(identity="TestBot", persona="Tester")
        topo = NetworkTopologies.hub_and_spoke(
            orchestrator_label="Hub",
            spokes=[{"label": "S", "node_type": "agent", "capabilities": []}],
        )

        return (
            ASPSBuilder(name="Test Skill", domain="testing", description="A test skill")
            .distill(heuristics)
            .reinforce(pseudonym_protocol=pp)
            .network(topo)
            .compile()
        )

    def test_full_build(self):
        skill = self._make_skill()
        assert isinstance(skill, ASPS)
        assert skill.name == "Test Skill"
        assert skill.domain == "testing"
        assert len(skill.compiled_system_prompt) > 100

    def test_compiled_prompt_contains_all_layers(self):
        skill = self._make_skill()
        prompt = skill.compiled_system_prompt
        assert "[IDENTITY]" in prompt
        assert "[GUARDRAILS]" in prompt
        assert "[SKILL INSTRUCTIONS]" in prompt
        assert "[AGENTIC NETWORK]" in prompt

    def test_build_order_enforcement(self):
        builder = ASPSBuilder(name="X", domain="x", description="x")
        with pytest.raises(RuntimeError):
            builder.compile()

    def test_build_asps_factory(self):
        heuristics = [create_heuristic(name="H", instruction="Do", sequence_index=1)]
        pp = create_pseudonym_protocol(identity="Bot", persona="P")
        topo = NetworkTopologies.hub_and_spoke(
            orchestrator_label="Hub",
            spokes=[{"label": "S", "node_type": "agent", "capabilities": []}],
        )
        skill = build_asps(
            name="Quick",
            domain="quick",
            description="Quick test",
            heuristics=heuristics,
            pseudonym_protocol=pp,
            topology=topo,
        )
        assert isinstance(skill, ASPS)
        assert skill.name == "Quick"


# ─── Template Tests ──────────────────────────────────────────────────


class TestTemplates:
    def test_all_templates_exist(self):
        assert len(ASPS_TEMPLATES) == 7

    @pytest.mark.parametrize("key", list(ASPS_TEMPLATES.keys()))
    def test_template_produces_valid_asps(self, key: str):
        factory = ASPS_TEMPLATES[key]
        skill = factory()
        assert isinstance(skill, ASPS)
        assert len(skill.compiled_system_prompt) > 200
        assert skill.distillation is not None
        assert skill.reinforcement is not None
        assert skill.network is not None
