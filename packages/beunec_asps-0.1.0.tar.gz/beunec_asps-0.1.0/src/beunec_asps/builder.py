"""
Beunec ASPS™ — Builder

Compose all three ASPS™ layers — ASD™ → ASR™ → ANS™ — into a
single, deployable skill artifact with a fluent builder API.
"""

from __future__ import annotations

import re
import time
from typing import Dict, List, Optional

from beunec_asps.types import (
    ASPS,
    ASPSBuildProgress,
    AgenticNetwork,
    BehavioralCheckpoint,
    DistilledHeuristic,
    ICRLConfig,
    NetworkNode,
    PseudonymProtocol,
    SkillDistillation,
    SkillReinforcement,
    TaskHandoff,
)
from beunec_asps.asd import distill as asd_distill
from beunec_asps.asr import (
    GuardrailPresetKey,
    reinforce as asr_reinforce,
    wrap_prompt_with_reinforcement,
)
from beunec_asps.ans import (
    build_network as ans_build_network,
    generate_network_prompt_block,
)


class ASPSBuilder:
    """
    Fluent builder for composing ASPS™ skill artifacts.

    Usage::

        skill = (
            ASPSBuilder(name="Stock Analyst", domain="finance", description="...")
            .distill(heuristics)
            .reinforce(pseudonym_protocol=pp, guardrail_presets=["financial"])
            .network(topology)
            .compile()
        )
    """

    def __init__(
        self,
        *,
        name: str,
        domain: str,
        description: str,
        tags: Optional[List[str]] = None,
        author: str = "Beunec Technologies, Inc.",
        origin: str = "custom",
    ):
        self._name = name
        self._domain = domain
        self._description = description
        self._tags = tags or []
        self._author = author
        self._origin = origin

        self._distillation: Optional[SkillDistillation] = None
        self._reinforcement: Optional[SkillReinforcement] = None
        self._network: Optional[AgenticNetwork] = None
        self._progress = ASPSBuildProgress(
            stage="distillation",
            percent_complete=0,
            current_step="Initialized",
        )

    @property
    def progress(self) -> ASPSBuildProgress:
        """Current build progress (returns a copy)."""
        return ASPSBuildProgress(
            stage=self._progress.stage,
            percent_complete=self._progress.percent_complete,
            current_step=self._progress.current_step,
            errors=list(self._progress.errors),
        )

    # ── Layer 1: Distillation (ASD™) ────────────────────────────────

    def distill(
        self,
        heuristics: List[DistilledHeuristic],
        *,
        version: str = "1.0.0",
        source_model: str = "gpt-4o-mini",
        expert_source_count: int = 1,
    ) -> "ASPSBuilder":
        """Distill an array of heuristics into the first ASPS™ layer."""
        if not heuristics:
            self._progress.errors.append(
                "ASD™: At least one heuristic is required."
            )
            return self

        self._distillation = asd_distill(
            self._domain,
            heuristics,
            version=version,
            source_model=source_model,
            expert_source_count=expert_source_count,
        )
        self._progress = ASPSBuildProgress(
            stage="reinforcement",
            percent_complete=33,
            current_step=f"ASD™ complete — {len(heuristics)} heuristics distilled",
        )
        return self

    # ── Layer 2: Reinforcement (ASR™) ───────────────────────────────

    def reinforce(
        self,
        *,
        pseudonym_protocol: PseudonymProtocol,
        checkpoints: Optional[List[BehavioralCheckpoint]] = None,
        icrl: Optional[ICRLConfig] = None,
        guardrails: Optional[List[str]] = None,
        guardrail_presets: Optional[List[GuardrailPresetKey]] = None,
        governance_system: str = "Beunec Cicero",
    ) -> "ASPSBuilder":
        """Wrap the distilled skill in an ASR™ reinforcement envelope."""
        if self._distillation is None:
            self._progress.errors.append(
                "ASR™: Must call .distill() before .reinforce()."
            )
            return self

        self._reinforcement = asr_reinforce(
            self._distillation.distillation_id,
            pseudonym_protocol=pseudonym_protocol,
            checkpoints=checkpoints,
            icrl=icrl,
            guardrails=guardrails,
            guardrail_presets=guardrail_presets,
            governance_system=governance_system,
        )
        self._progress = ASPSBuildProgress(
            stage="networking",
            percent_complete=66,
            current_step=(
                f"ASR™ complete — {len(self._reinforcement.checkpoints)} checkpoints, "
                f"{len(self._reinforcement.guardrails)} guardrails"
            ),
        )
        return self

    # ── Layer 3: Network (ANS™) ─────────────────────────────────────

    def network(
        self,
        topology: Dict[str, list],
        *,
        orchestration_framework: str = "Beunec ARG™ Framework",
        max_concurrent_handoffs: int = 10,
        global_timeout_ms: int = 120_000,
        circuit_breaker_threshold: int = 5,
    ) -> "ASPSBuilder":
        """Wire the reinforced skill into an ANS™ network topology."""
        if self._reinforcement is None:
            self._progress.errors.append(
                "ANS™: Must call .reinforce() before .network()."
            )
            return self

        self._network = ans_build_network(
            self._reinforcement.reinforcement_id,
            topology,
            orchestration_framework=orchestration_framework,
            max_concurrent_handoffs=max_concurrent_handoffs,
            global_timeout_ms=global_timeout_ms,
            circuit_breaker_threshold=circuit_breaker_threshold,
        )
        nodes = topology.get("nodes", [])
        handoffs = topology.get("handoffs", [])
        self._progress = ASPSBuildProgress(
            stage="compilation",
            percent_complete=90,
            current_step=f"ANS™ complete — {len(nodes)} nodes, {len(handoffs)} handoffs",
        )
        return self

    # ── Compile ─────────────────────────────────────────────────────

    def compile(self) -> ASPS:
        """
        Compile all three layers into a single ASPS™ skill artifact.
        Returns the complete, deployable skill with its compiled system prompt.
        """
        if self._distillation is None:
            raise RuntimeError(
                "ASPS™ Compile Error: Distillation layer (ASD™) is missing. Call .distill() first."
            )
        if self._reinforcement is None:
            raise RuntimeError(
                "ASPS™ Compile Error: Reinforcement layer (ASR™) is missing. Call .reinforce() first."
            )
        if self._network is None:
            raise RuntimeError(
                "ASPS™ Compile Error: Network layer (ANS™) is missing. Call .network() first."
            )

        reinforced_prompt = wrap_prompt_with_reinforcement(
            self._distillation.composite_system_prompt,
            self._reinforcement,
        )
        network_block = generate_network_prompt_block(self._network)
        compiled_system_prompt = reinforced_prompt + network_block

        from datetime import datetime, timezone

        now = datetime.now(timezone.utc).isoformat()
        slug = re.sub(r"\s+", "-", self._domain.lower())

        skill = ASPS(
            skill_id=f"asps-{slug}-{int(time.time() * 1000)}",
            name=self._name,
            version=self._distillation.version,
            author=self._author,
            origin=self._origin,
            domain=self._domain,
            description=self._description,
            tags=list(self._tags),
            distillation=self._distillation,
            reinforcement=self._reinforcement,
            network=self._network,
            compiled_system_prompt=compiled_system_prompt,
            created_at=now,
            updated_at=now,
        )

        self._progress = ASPSBuildProgress(
            stage="complete",
            percent_complete=100,
            current_step=f'ASPS™ skill "{self._name}" compiled — {len(compiled_system_prompt)} chars',
        )

        return skill


# ─── Convenience Factory ────────────────────────────────────────────

def build_asps(
    *,
    name: str,
    domain: str,
    description: str,
    heuristics: List[DistilledHeuristic],
    pseudonym_protocol: PseudonymProtocol,
    topology: Dict[str, list],
    tags: Optional[List[str]] = None,
    guardrail_presets: Optional[List[GuardrailPresetKey]] = None,
) -> ASPS:
    """
    One-shot factory for simple use cases.

    Combines ``.distill() → .reinforce() → .network() → .compile()``
    in a single call.
    """
    return (
        ASPSBuilder(name=name, domain=domain, description=description, tags=tags)
        .distill(heuristics)
        .reinforce(
            pseudonym_protocol=pseudonym_protocol,
            guardrail_presets=guardrail_presets,
        )
        .network(topology)
        .compile()
    )
