"""
Beunec ASPS™ — Core Type Definitions

All data contracts for ASD™, ASR™, and ANS™ as Python dataclasses.
Zero dependencies — uses only stdlib.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Literal


# ─── ASD™ Types ──────────────────────────────────────────────────────


@dataclass
class DistilledHeuristic:
    """A single expert heuristic extracted via ASD™."""

    id: str
    name: str
    instruction: str
    constraints: List[str] = field(default_factory=list)
    input_schema: str = "string"
    output_schema: str = "string"
    determinism_score: float = 0.8
    sequence_index: int = 0


@dataclass
class DistillationMetadata:
    total_heuristics: int
    average_determinism: float
    domain_coverage_percent: float
    expert_source_count: int


@dataclass
class SkillDistillation:
    """The complete ASD™ distillation product for a skill."""

    distillation_id: str
    version: str
    domain: str
    heuristics: List[DistilledHeuristic]
    composite_system_prompt: str
    source_model: str
    distilled_at: str
    metadata: DistillationMetadata


# ─── ASR™ Types ──────────────────────────────────────────────────────

FailureAction = Literal["halt", "retry", "escalate", "fallback"]
Severity = Literal["critical", "warning", "info"]
CheckpointStage = Literal["pre-execution", "mid-execution", "post-execution"]
LogLevel = Literal["minimal", "standard", "verbose"]


@dataclass
class BehavioralCheckpoint:
    """A behavioral checkpoint used by ASR™."""

    id: str
    name: str
    condition: str
    failure_action: FailureAction = "halt"
    fallback_prompt: Optional[str] = None
    severity: Severity = "warning"
    stage: CheckpointStage = "pre-execution"


@dataclass
class PseudonymProtocol:
    """Pseudonym protocol for identity alignment (ASR™)."""

    identity: str
    persona: str
    communication_style: str = "Professional and precise."
    red_lines: List[str] = field(default_factory=list)
    vocabulary: List[str] = field(default_factory=list)


@dataclass
class ICRLConfig:
    """In-Context Reinforcement Learning (ICRL) configuration."""

    exemplar_count: int = 3
    positive_signal_template: str = (
        "Excellent. That response correctly followed step {{step}} "
        "and produced valid output."
    )
    correction_signal_template: str = (
        "Correction needed: the response deviated at step {{step}}. "
        "Expected: {{expected}}. Received: {{received}}. "
        "Re-execute from step {{step}}."
    )
    drift_tolerance: float = 0.15
    checkpoint_frequency: int = 3


@dataclass
class AuditConfig:
    enabled: bool = True
    log_level: LogLevel = "standard"
    retention_days: int = 90


@dataclass
class SkillReinforcement:
    """The complete ASR™ reinforcement envelope for a skill."""

    reinforcement_id: str
    distillation_id: str
    checkpoints: List[BehavioralCheckpoint]
    pseudonym_protocol: PseudonymProtocol
    icrl: ICRLConfig
    governance_system: str = "Beunec Cicero"
    guardrails: List[str] = field(default_factory=list)
    audit_config: AuditConfig = field(default_factory=AuditConfig)


# ─── ANS™ Types ──────────────────────────────────────────────────────

NodeType = Literal["agent", "api", "database", "template", "user-interface", "governance"]
AuthMethod = Literal["api-key", "oauth", "service-account", "none"]
Priority = Literal["critical", "high", "normal", "low"]


@dataclass
class HealthCheck:
    endpoint: str
    interval_ms: int
    timeout_ms: int


@dataclass
class NetworkNode:
    """A connection point in the agentic network."""

    node_id: str
    node_type: NodeType
    label: str
    endpoint: str = ""
    auth_method: AuthMethod = "none"
    capabilities: List[str] = field(default_factory=list)
    health_check: Optional[HealthCheck] = None


@dataclass
class RetryPolicy:
    max_retries: int = 3
    backoff_ms: int = 1000
    backoff_multiplier: float = 2.0


@dataclass
class TaskHandoff:
    """A task handoff between two network nodes."""

    id: str
    from_node_id: str
    to_node_id: str
    payload_schema: str = "JSON"
    priority: Priority = "normal"
    timeout_ms: int = 30_000
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)


@dataclass
class NetworkPolicies:
    max_concurrent_handoffs: int = 10
    global_timeout_ms: int = 120_000
    circuit_breaker_threshold: int = 5


@dataclass
class AgenticNetwork:
    """The complete ANS™ network topology for a skill deployment."""

    network_id: str
    reinforcement_id: str
    nodes: List[NetworkNode]
    handoffs: List[TaskHandoff]
    orchestration_framework: str = "Beunec ARG™ Framework"
    policies: NetworkPolicies = field(default_factory=NetworkPolicies)


# ─── Builder Types ───────────────────────────────────────────────────

BuildStage = Literal["distillation", "reinforcement", "networking", "compilation", "complete"]


@dataclass
class ASPSBuildProgress:
    """Tracks the current stage of an ASPS™ build."""

    stage: BuildStage = "distillation"
    percent_complete: int = 0
    current_step: str = "Initialized"
    errors: List[str] = field(default_factory=list)


# ─── Composite ASPS™ Skill ──────────────────────────────────────────

Origin = Literal["built-in", "custom"]


@dataclass
class ASPS:
    """The complete Agentic-System-Prompt-as-a-Skill™."""

    skill_id: str
    name: str
    version: str
    author: str
    origin: Origin
    domain: str
    description: str
    tags: List[str]

    distillation: SkillDistillation
    reinforcement: SkillReinforcement
    network: AgenticNetwork

    compiled_system_prompt: str

    created_at: str
    updated_at: str
