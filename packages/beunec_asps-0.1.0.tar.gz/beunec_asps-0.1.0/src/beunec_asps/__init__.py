"""
Beunec Technologies, Inc. — Agentic-System-Prompt-as-a-Skill™ (ASPS™)

A lightweight, zero-dependency Python framework for deterministic skill
construction in agentic systems.

Three techniques:
  1. ASD™ — Agentic Skill Distillation
  2. ASR™ — Agentic Skill Reinforcement
  3. ANS™ — Agentic Network System
"""

from beunec_asps.types import (
    DistilledHeuristic,
    SkillDistillation,
    DistillationMetadata,
    BehavioralCheckpoint,
    PseudonymProtocol,
    ICRLConfig,
    AuditConfig,
    SkillReinforcement,
    HealthCheck,
    NetworkNode,
    RetryPolicy,
    TaskHandoff,
    NetworkPolicies,
    AgenticNetwork,
    ASPSBuildProgress,
    ASPS,
)
from beunec_asps.asd import (
    create_heuristic,
    compile_heuristics_to_prompt,
    distill,
    HEURISTIC_LIBRARIES,
)
from beunec_asps.asr import (
    create_checkpoint,
    create_pseudonym_protocol,
    create_icrl_config,
    reinforce,
    wrap_prompt_with_reinforcement,
    GUARDRAIL_PRESETS,
    CHECKPOINT_PRESETS,
)
from beunec_asps.ans import (
    create_node,
    create_handoff,
    build_network,
    generate_network_prompt_block,
    NetworkTopologies,
)
from beunec_asps.builder import ASPSBuilder, build_asps

__all__ = [
    # Types
    "DistilledHeuristic",
    "SkillDistillation",
    "DistillationMetadata",
    "BehavioralCheckpoint",
    "PseudonymProtocol",
    "ICRLConfig",
    "AuditConfig",
    "SkillReinforcement",
    "HealthCheck",
    "NetworkNode",
    "RetryPolicy",
    "TaskHandoff",
    "NetworkPolicies",
    "AgenticNetwork",
    "ASPSBuildProgress",
    "ASPS",
    # ASD
    "create_heuristic",
    "compile_heuristics_to_prompt",
    "distill",
    "HEURISTIC_LIBRARIES",
    # ASR
    "create_checkpoint",
    "create_pseudonym_protocol",
    "create_icrl_config",
    "reinforce",
    "wrap_prompt_with_reinforcement",
    "GUARDRAIL_PRESETS",
    "CHECKPOINT_PRESETS",
    # ANS
    "create_node",
    "create_handoff",
    "build_network",
    "generate_network_prompt_block",
    "NetworkTopologies",
    # Builder
    "ASPSBuilder",
    "build_asps",
]

__version__ = "0.1.0"
