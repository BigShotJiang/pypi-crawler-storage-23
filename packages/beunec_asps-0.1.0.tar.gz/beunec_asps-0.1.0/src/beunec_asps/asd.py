"""
Beunec ASPS™ — Agentic Skill Distillation™ (ASD™)

Layer 1: Extract expert heuristics → deterministic instruction chains.
"""

from __future__ import annotations

import re
import time
from datetime import datetime, timezone
from typing import Dict, List, Optional

from beunec_asps.types import DistilledHeuristic, DistillationMetadata, SkillDistillation

_heuristic_counter = 0


def create_heuristic(
    *,
    name: str,
    instruction: str,
    id: Optional[str] = None,
    constraints: Optional[List[str]] = None,
    input_schema: str = "string",
    output_schema: str = "string",
    determinism_score: float = 0.8,
    sequence_index: Optional[int] = None,
) -> DistilledHeuristic:
    """Create a single distilled heuristic with sensible defaults."""
    global _heuristic_counter
    _heuristic_counter += 1
    return DistilledHeuristic(
        id=id or f"heuristic-{_heuristic_counter}",
        name=name,
        instruction=instruction,
        constraints=constraints or [],
        input_schema=input_schema,
        output_schema=output_schema,
        determinism_score=determinism_score,
        sequence_index=sequence_index if sequence_index is not None else _heuristic_counter,
    )


def compile_heuristics_to_prompt(domain: str, heuristics: List[DistilledHeuristic]) -> str:
    """Compile an ordered array of heuristics into a deterministic system prompt."""
    sorted_h = sorted(heuristics, key=lambda h: h.sequence_index)
    sections: List[str] = []
    for i, h in enumerate(sorted_h):
        constraint_block = ""
        if h.constraints:
            constraint_block = f"\n   Constraints: {'; '.join(h.constraints)}"
        sections.append(
            f"Step {i + 1}: {h.name}\n"
            f"   {h.instruction}{constraint_block}\n"
            f"   Input:  {h.input_schema}\n"
            f"   Output: {h.output_schema}"
        )

    parts = [
        f"You are an expert {domain} agent.",
        "Follow these steps IN ORDER. Do NOT skip steps.",
        "",
        *sections,
        "",
        "Always produce structured, deterministic output.",
        "If any step fails, STOP and report which step failed and why.",
    ]
    return "\n".join(parts)


def distill(
    domain: str,
    heuristics: List[DistilledHeuristic],
    *,
    version: str = "1.0.0",
    source_model: str = "gpt-4o-mini",
    expert_source_count: int = 1,
) -> SkillDistillation:
    """Build a complete SkillDistillation from domain + heuristics."""
    composite = compile_heuristics_to_prompt(domain, heuristics)
    avg_det = sum(h.determinism_score for h in heuristics) / max(len(heuristics), 1)
    slug = re.sub(r"\s+", "-", domain.lower())

    return SkillDistillation(
        distillation_id=f"asd-{slug}-{int(time.time() * 1000)}",
        version=version,
        domain=domain,
        heuristics=sorted(heuristics, key=lambda h: h.sequence_index),
        composite_system_prompt=composite,
        source_model=source_model,
        distilled_at=datetime.now(timezone.utc).isoformat(),
        metadata=DistillationMetadata(
            total_heuristics=len(heuristics),
            average_determinism=round(avg_det, 2),
            domain_coverage_percent=min(100.0, round(len(heuristics) * 12.5)),
            expert_source_count=expert_source_count,
        ),
    )


# ─── Pre-Built Heuristic Libraries ──────────────────────────────────

def _fsd() -> List[DistilledHeuristic]:
    return [
        create_heuristic(name="Requirements Analysis", instruction="Parse the user request into functional and non-functional requirements. Identify the tech stack, constraints, and acceptance criteria.", constraints=["Must produce a numbered requirements list", "Separate functional from non-functional"], input_schema="UserRequest (natural language)", output_schema="RequirementsList { functional: list[str]; nonFunctional: list[str] }", determinism_score=0.85, sequence_index=1),
        create_heuristic(name="Architecture Decision", instruction="Select the architecture pattern (monolith, microservice, serverless, etc.) based on requirements. Justify the decision.", constraints=["Must reference at least 2 tradeoffs", "Must name specific frameworks"], input_schema="RequirementsList", output_schema="ArchitectureDecision { pattern: str; frameworks: list[str]; justification: str }", determinism_score=0.7, sequence_index=2),
        create_heuristic(name="File Structure Scaffold", instruction="Generate the complete directory tree and file list. Every file must have a purpose annotation.", constraints=["Follow framework conventions", "Include test directories"], input_schema="ArchitectureDecision", output_schema="DirectoryTree [{ path: str; purpose: str }]", determinism_score=0.95, sequence_index=3),
        create_heuristic(name="Implementation", instruction="Write production-quality code for each file. Use TypeScript strict mode. Include JSDoc for public APIs.", constraints=["No TODO comments in production files", "All functions must have explicit return types"], input_schema="DirectoryTree + RequirementsList", output_schema="SourceFiles [{ path: str; content: str }]", determinism_score=0.9, sequence_index=4),
        create_heuristic(name="Test Suite Generation", instruction="Generate unit tests for all public functions. Target ≥80% branch coverage.", constraints=["Use Jest + RTL for React", "Mock external APIs"], input_schema="SourceFiles", output_schema="TestFiles [{ path: str; content: str }]", determinism_score=0.9, sequence_index=5),
        create_heuristic(name="CI/CD Pipeline", instruction="Generate GitHub Actions workflow: lint → typecheck → test → build → deploy.", constraints=["Must include caching for node_modules", "Fail-fast on lint errors"], input_schema="ProjectStructure", output_schema="WorkflowYAML string", determinism_score=0.95, sequence_index=6),
    ]


def _fsa() -> List[DistilledHeuristic]:
    return [
        create_heuristic(name="Ticker Resolution", instruction="Resolve the user query to a valid stock ticker symbol. Validate against known exchanges (NYSE, NASDAQ, LSE).", constraints=["Must confirm ticker exists", "Handle common aliases (e.g. 'Google' → GOOGL)"], input_schema="UserQuery (natural language)", output_schema="TickerResolution { symbol: str; exchange: str; companyName: str }", determinism_score=0.95, sequence_index=1),
        create_heuristic(name="Fundamental Analysis", instruction="Retrieve and analyze P/E ratio, EPS, revenue growth, debt-to-equity, and free cash flow for the resolved ticker.", constraints=["Use trailing twelve months (TTM) data", "Flag any metric > 2σ from sector median"], input_schema="TickerResolution", output_schema="FundamentalReport { metrics: dict[str, float]; flags: list[str] }", determinism_score=0.85, sequence_index=2),
        create_heuristic(name="Technical Analysis", instruction="Compute 50-day and 200-day moving averages, RSI(14), MACD(12,26,9), and Bollinger Bands(20,2).", constraints=["Identify crossover signals", "Note overbought/oversold conditions"], input_schema="HistoricalPriceData[]", output_schema="TechnicalReport { indicators: dict[str, float]; signals: list[str] }", determinism_score=0.95, sequence_index=3),
        create_heuristic(name="Sentiment Scan", instruction="Summarize recent news sentiment (bullish / bearish / neutral) from the last 7 days. Cite sources.", constraints=["Minimum 3 source citations", "Weight institutional reports higher"], input_schema="TickerResolution", output_schema="SentimentReport { overall: str; sources: list[dict] }", determinism_score=0.6, sequence_index=4),
        create_heuristic(name="Risk Assessment", instruction="Evaluate macro, sector, and company-specific risks. Assign a composite risk score 1-10.", constraints=["Must address at least one macro risk", "Score must be justified"], input_schema="FundamentalReport + TechnicalReport + SentimentReport", output_schema="RiskAssessment { score: int; risks: list[dict] }", determinism_score=0.7, sequence_index=5),
        create_heuristic(name="Investment Thesis", instruction="Synthesize all prior analyses into a BUY / HOLD / SELL recommendation with a 12-month price target range.", constraints=["Must reference all prior steps", "Include confidence interval", "Disclaim that this is not financial advice"], input_schema="All prior reports", output_schema="InvestmentThesis { recommendation: str; priceTarget: dict; confidence: float }", determinism_score=0.65, sequence_index=6),
    ]


def _sr() -> List[DistilledHeuristic]:
    return [
        create_heuristic(name="Research Question Formulation", instruction="Transform the user query into a formal research question with defined scope, variables, and hypothesis.", constraints=["Must be falsifiable", "Define independent and dependent variables"], input_schema="UserQuery", output_schema="ResearchQuestion { question: str; hypothesis: str; variables: dict }", determinism_score=0.75, sequence_index=1),
        create_heuristic(name="Literature Review", instruction="Search for and summarize the 5-10 most relevant prior works. Identify the research gap.", constraints=["Prioritize peer-reviewed sources", "Must identify the specific gap this research fills"], input_schema="ResearchQuestion", output_schema="LiteratureReview { papers: list[dict]; gap: str }", determinism_score=0.6, sequence_index=2),
        create_heuristic(name="Methodology Design", instruction="Propose a study design (experimental, observational, computational, etc.) with sample size justification and controls.", constraints=["Must address confounding variables", "Include statistical power analysis rationale"], input_schema="ResearchQuestion + LiteratureReview", output_schema="Methodology { design: str; sampleSize: int; controls: list[str] }", determinism_score=0.7, sequence_index=3),
        create_heuristic(name="Data Analysis Plan", instruction="Specify statistical tests, significance thresholds, and visualization approach.", constraints=["α ≤ 0.05 unless justified", "Pre-register analysis plan"], input_schema="Methodology", output_schema="AnalysisPlan { tests: list[str]; alpha: float; visualizations: list[str] }", determinism_score=0.85, sequence_index=4),
        create_heuristic(name="Results Interpretation", instruction="Interpret findings in context of the hypothesis. Discuss effect sizes, not just p-values.", constraints=["Report confidence intervals", "Acknowledge limitations"], input_schema="RawResults + AnalysisPlan", output_schema="Interpretation { supported: bool; effectSize: float; limitations: list[str] }", determinism_score=0.7, sequence_index=5),
        create_heuristic(name="Publication Draft", instruction="Compose an abstract, introduction, methods, results, discussion, and conclusion in standard academic format.", constraints=["Follow APA/IEEE format as appropriate", "Include all citations"], input_schema="All prior outputs", output_schema="ManuscriptDraft { sections: dict[str, str] }", determinism_score=0.8, sequence_index=6),
    ]


def _cc() -> List[DistilledHeuristic]:
    return [
        create_heuristic(name="Audience & Platform Analysis", instruction="Identify the target audience demographics and the platform constraints (character limits, media types, algorithm preferences).", constraints=["Must specify at least one platform", "Define audience persona"], input_schema="ContentBrief", output_schema="AudienceProfile { persona: str; platform: str; constraints: list[str] }", determinism_score=0.8, sequence_index=1),
        create_heuristic(name="Content Strategy", instruction="Define the content type (article, thread, video script, newsletter), tone, key messages, and call-to-action.", constraints=["Align tone with audience persona", "Single clear CTA"], input_schema="AudienceProfile + ContentBrief", output_schema="ContentStrategy { type: str; tone: str; keyMessages: list[str]; cta: str }", determinism_score=0.75, sequence_index=2),
        create_heuristic(name="Outline Generation", instruction="Create a structured outline with sections, hooks, and transitions.", constraints=["Hook must appear in first 2 sentences", "Maximum 7 sections"], input_schema="ContentStrategy", output_schema="Outline { sections: list[dict] }", determinism_score=0.85, sequence_index=3),
        create_heuristic(name="Draft Composition", instruction="Write the full draft following the outline. Match the defined tone. Optimize for readability (Flesch-Kincaid ≥ 60).", constraints=["No jargon without definition", "Active voice preferred"], input_schema="Outline", output_schema="Draft string", determinism_score=0.7, sequence_index=4),
        create_heuristic(name="SEO / Discoverability Pass", instruction="Inject relevant keywords, optimize title/meta, add internal/external links suggestions.", constraints=["Keyword density 1-2%", "Title ≤ 60 characters"], input_schema="Draft", output_schema="SEOReport { keywords: list[str]; titleSuggestion: str; metaDescription: str }", determinism_score=0.9, sequence_index=5),
    ]


def _pea() -> List[DistilledHeuristic]:
    return [
        create_heuristic(name="Deal Screening", instruction="Evaluate the target company against fund thesis (sector, size, geography, EBITDA margin thresholds).", constraints=["Must produce a PASS/FAIL gate decision", "Log rejection reason if FAIL"], input_schema="CompanyProfile + FundThesis", output_schema="ScreeningResult { pass: bool; reason: str }", determinism_score=0.9, sequence_index=1),
        create_heuristic(name="Financial Model — LBO", instruction="Build a leveraged buyout model: entry multiple, debt structure, revenue projections (5yr), exit multiple, IRR calculation.", constraints=["Conservative, base, and optimistic cases", "Debt-to-EBITDA ≤ 6x at entry"], input_schema="FinancialStatements + DealTerms", output_schema="LBOModel { irr: dict[str, float]; moic: dict[str, float] }", determinism_score=0.85, sequence_index=2),
        create_heuristic(name="Due Diligence Checklist", instruction="Generate a comprehensive DD checklist: legal, financial, commercial, operational, IT, HR, ESG.", constraints=["Minimum 5 items per category", "Flag high-priority items"], input_schema="ScreeningResult + LBOModel", output_schema="DDChecklist { categories: dict[str, list[dict]] }", determinism_score=0.9, sequence_index=3),
        create_heuristic(name="Value Creation Plan", instruction="Identify 3-5 value creation levers (revenue growth, margin expansion, add-on acquisitions, working capital optimization).", constraints=["Each lever must have quantified impact", "Time-bound milestones"], input_schema="LBOModel + DDChecklist", output_schema="ValueCreationPlan { levers: list[dict] }", determinism_score=0.75, sequence_index=4),
        create_heuristic(name="Investment Memo", instruction="Synthesize all analyses into a formal IC (Investment Committee) memo: thesis, risks, returns, recommendation.", constraints=["Executive summary ≤ 300 words", "Must include dissenting view section"], input_schema="All prior outputs", output_schema="InvestmentMemo { recommendation: str; irr: float; risks: list[str] }", determinism_score=0.8, sequence_index=5),
    ]


def _ap() -> List[DistilledHeuristic]:
    return [
        create_heuristic(name="Course Objective Mapping", instruction="Define learning objectives using Bloom's Taxonomy. Map each objective to an assessment method.", constraints=["Use measurable action verbs", "Cover at least 3 Bloom levels"], input_schema="CourseDescription + StudentLevel", output_schema="ObjectiveMap { objectives: list[dict] }", determinism_score=0.85, sequence_index=1),
        create_heuristic(name="Syllabus Construction", instruction="Create a week-by-week syllabus with readings, activities, and deliverables.", constraints=["Include academic integrity policy", "Balance theory and application weeks"], input_schema="ObjectiveMap + SemesterLength", output_schema="Syllabus { weeks: list[dict] }", determinism_score=0.9, sequence_index=2),
        create_heuristic(name="Lecture Design", instruction="Design lecture slides outline with key concepts, examples, discussion questions, and active learning activities.", constraints=["Maximum 40 slides per lecture", "Include at least one active learning activity"], input_schema="SyllabusWeek", output_schema="LecturePlan { slides: list[dict] }", determinism_score=0.8, sequence_index=3),
        create_heuristic(name="Assessment Generation", instruction="Create exam questions, rubrics, and grading criteria aligned with learning objectives.", constraints=["Mix question types (MCQ, short answer, essay)", "Rubric must be criterion-referenced"], input_schema="ObjectiveMap", output_schema="Assessment { questions: list[dict] }", determinism_score=0.85, sequence_index=4),
        create_heuristic(name="Student Feedback Analysis", instruction="Analyze student evaluations, identify themes, and propose course improvements.", constraints=["Categorize feedback as structural, content, or pedagogical", "Prioritize by frequency"], input_schema="EvaluationData[]", output_schema="FeedbackAnalysis { themes: list[dict] }", determinism_score=0.7, sequence_index=5),
    ]


def _fia() -> List[DistilledHeuristic]:
    return [
        create_heuristic(name="Portfolio Context Assessment", instruction="Assess the investor's current portfolio, risk tolerance, time horizon, and investment goals.", constraints=["Must determine risk profile (conservative/moderate/aggressive)", "Identify concentration risks"], input_schema="InvestorProfile + CurrentHoldings", output_schema="PortfolioContext { riskProfile: str; gaps: list[str]; concentrationRisks: list[str] }", determinism_score=0.8, sequence_index=1),
        create_heuristic(name="Asset Allocation Strategy", instruction="Recommend target allocation across asset classes (equities, fixed income, alternatives, cash) based on risk profile.", constraints=["Sum to 100%", "Reference Modern Portfolio Theory"], input_schema="PortfolioContext", output_schema="AllocationStrategy { allocations: dict[str, float]; rationale: str }", determinism_score=0.8, sequence_index=2),
        create_heuristic(name="Security Selection", instruction="Select specific securities (ETFs, stocks, bonds) for each asset class bucket. Include expense ratios for funds.", constraints=["Prefer low-cost index funds where appropriate", "Diversify across geographies"], input_schema="AllocationStrategy", output_schema="SecuritySelection { picks: list[dict] }", determinism_score=0.75, sequence_index=3),
        create_heuristic(name="Tax Efficiency Analysis", instruction="Evaluate tax implications of proposed trades. Suggest tax-loss harvesting opportunities and account placement.", constraints=["Consider short vs long-term capital gains", "Account for wash sale rules"], input_schema="SecuritySelection + TaxSituation", output_schema="TaxAnalysis { harvestingOpportunities: list[str]; accountPlacement: dict[str, str] }", determinism_score=0.85, sequence_index=4),
        create_heuristic(name="Rebalancing Plan", instruction="Create a specific trade execution plan to move from current to target allocation with minimal tax drag.", constraints=["Minimize number of trades", "Respect wash sale windows", "Include order types"], input_schema="CurrentHoldings + SecuritySelection + TaxAnalysis", output_schema="RebalancingPlan { trades: list[dict] }", determinism_score=0.9, sequence_index=5),
    ]


HEURISTIC_LIBRARIES: Dict[str, List[DistilledHeuristic]] = {
    "full_stack_developer": _fsd(),
    "financial_stock_analyst": _fsa(),
    "scientific_researcher": _sr(),
    "content_creator": _cc(),
    "private_equity_analyst": _pea(),
    "academia_professor": _ap(),
    "financial_investment_analyst": _fia(),
}
