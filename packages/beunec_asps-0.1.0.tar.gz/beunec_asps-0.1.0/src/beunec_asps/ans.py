"""
Beunec ASPS™ — Agentic Network System™ (ANS™)

Layer 3: Wire reinforced skills into governed, multi-agent network
topologies with typed handoffs and orchestration policies.
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional

from beunec_asps.types import (
    AgenticNetwork,
    HealthCheck,
    NetworkNode,
    NetworkPolicies,
    RetryPolicy,
    TaskHandoff,
)

_node_counter = 0
_handoff_counter = 0


# ─── Node Builder ───────────────────────────────────────────────────

def create_node(
    *,
    node_type: str,
    label: str,
    node_id: Optional[str] = None,
    endpoint: str = "",
    auth_method: str = "none",
    capabilities: Optional[List[str]] = None,
    health_check: Optional[HealthCheck] = None,
) -> NetworkNode:
    """Create a single network node."""
    global _node_counter
    _node_counter += 1
    return NetworkNode(
        node_id=node_id or f"node-{_node_counter}",
        node_type=node_type,
        label=label,
        endpoint=endpoint,
        auth_method=auth_method,
        capabilities=capabilities or [],
        health_check=health_check,
    )


# ─── Handoff Builder ────────────────────────────────────────────────

def create_handoff(
    *,
    from_node_id: str,
    to_node_id: str,
    id: Optional[str] = None,
    payload_schema: str = "JSON",
    priority: str = "normal",
    timeout_ms: int = 30_000,
    retry_policy: Optional[RetryPolicy] = None,
) -> TaskHandoff:
    """Create a typed task handoff between two nodes."""
    global _handoff_counter
    _handoff_counter += 1
    return TaskHandoff(
        id=id or f"handoff-{_handoff_counter}",
        from_node_id=from_node_id,
        to_node_id=to_node_id,
        payload_schema=payload_schema,
        priority=priority,
        timeout_ms=timeout_ms,
        retry_policy=retry_policy or RetryPolicy(),
    )


# ─── Pre-Built Network Topologies ───────────────────────────────────

class NetworkTopologies:
    """Common ANS™ topology templates."""

    @staticmethod
    def hub_and_spoke(
        *,
        orchestrator_label: str,
        spokes: List[Dict[str, object]],
    ) -> Dict[str, list]:
        """
        Hub-and-spoke: single orchestrator agent talks to N specialist nodes.
        Typical for most single-domain skills.

        ``spokes`` should be a list of dicts with keys
        ``label``, ``node_type``, and ``capabilities``.
        """
        hub = create_node(
            node_type="agent",
            label=orchestrator_label,
            capabilities=["orchestration", "routing", "aggregation"],
        )

        spoke_nodes = [
            create_node(
                node_type=str(s["node_type"]),
                label=str(s["label"]),
                capabilities=list(s.get("capabilities", [])),  # type: ignore[arg-type]
            )
            for s in spokes
        ]

        governance = create_node(
            node_type="governance",
            label="Beunec Cicero Governance",
            capabilities=["audit", "policy-enforcement", "rate-limiting"],
        )

        handoffs: List[TaskHandoff] = []
        for spoke in spoke_nodes:
            handoffs.append(
                create_handoff(from_node_id=hub.node_id, to_node_id=spoke.node_id, priority="normal")
            )
            handoffs.append(
                create_handoff(from_node_id=spoke.node_id, to_node_id=hub.node_id, priority="normal")
            )

        # Governance node monitors the hub
        handoffs.append(
            create_handoff(
                from_node_id=hub.node_id,
                to_node_id=governance.node_id,
                priority="low",
                payload_schema="AuditLog",
            )
        )

        return {"nodes": [hub, *spoke_nodes, governance], "handoffs": handoffs}

    @staticmethod
    def pipeline(
        *,
        stages: List[Dict[str, object]],
    ) -> Dict[str, list]:
        """
        Pipeline: linear chain of agents, each passing output to the next.
        Matches the sequential nature of ASD™ heuristic chains.

        ``stages`` should be a list of dicts with keys
        ``label``, ``node_type``, and ``capabilities``.
        """
        nodes = [
            create_node(
                node_type=str(s["node_type"]),
                label=str(s["label"]),
                capabilities=list(s.get("capabilities", [])),  # type: ignore[arg-type]
            )
            for s in stages
        ]

        governance = create_node(
            node_type="governance",
            label="Beunec Cicero Governance",
            capabilities=["audit", "policy-enforcement"],
        )

        handoffs: List[TaskHandoff] = []
        for i in range(len(nodes) - 1):
            handoffs.append(
                create_handoff(
                    from_node_id=nodes[i].node_id,
                    to_node_id=nodes[i + 1].node_id,
                    priority="high",
                )
            )

        # Each stage reports to governance
        for node in nodes:
            handoffs.append(
                create_handoff(
                    from_node_id=node.node_id,
                    to_node_id=governance.node_id,
                    priority="low",
                    payload_schema="AuditLog",
                )
            )

        return {"nodes": [*nodes, governance], "handoffs": handoffs}

    @staticmethod
    def mesh(
        *,
        agents: List[Dict[str, object]],
    ) -> Dict[str, list]:
        """
        Mesh: every agent can talk to every other agent.
        For complex multi-domain skills where any node might need any other.

        ``agents`` should be a list of dicts with keys
        ``label`` and ``capabilities``.
        """
        nodes = [
            create_node(
                node_type="agent",
                label=str(a["label"]),
                capabilities=list(a.get("capabilities", [])),  # type: ignore[arg-type]
            )
            for a in agents
        ]

        governance = create_node(
            node_type="governance",
            label="Beunec Cicero Governance",
            capabilities=["audit", "policy-enforcement", "conflict-resolution"],
        )

        handoffs: List[TaskHandoff] = []
        for i in range(len(nodes)):
            for j in range(i + 1, len(nodes)):
                handoffs.append(
                    create_handoff(from_node_id=nodes[i].node_id, to_node_id=nodes[j].node_id)
                )
                handoffs.append(
                    create_handoff(from_node_id=nodes[j].node_id, to_node_id=nodes[i].node_id)
                )
            handoffs.append(
                create_handoff(
                    from_node_id=nodes[i].node_id,
                    to_node_id=governance.node_id,
                    priority="low",
                    payload_schema="AuditLog",
                )
            )

        return {"nodes": [*nodes, governance], "handoffs": handoffs}


# Convenience alias matching the TS API style
NETWORK_TOPOLOGIES = NetworkTopologies


# ─── Network Builder ────────────────────────────────────────────────

def build_network(
    reinforcement_id: str,
    topology: Dict[str, list],
    *,
    orchestration_framework: str = "Beunec ARG™ Framework",
    max_concurrent_handoffs: int = 10,
    global_timeout_ms: int = 120_000,
    circuit_breaker_threshold: int = 5,
) -> AgenticNetwork:
    """Assemble a governed AgenticNetwork from a topology dict."""
    slug = reinforcement_id.replace("asr-", "")
    return AgenticNetwork(
        network_id=f"ans-{slug}-{int(time.time() * 1000)}",
        reinforcement_id=reinforcement_id,
        nodes=topology["nodes"],
        handoffs=topology["handoffs"],
        orchestration_framework=orchestration_framework,
        policies=NetworkPolicies(
            max_concurrent_handoffs=max_concurrent_handoffs,
            global_timeout_ms=global_timeout_ms,
            circuit_breaker_threshold=circuit_breaker_threshold,
        ),
    )


# ─── Network Prompt Contribution ────────────────────────────────────

def generate_network_prompt_block(network: AgenticNetwork) -> str:
    """
    Generate the ANS™ network-awareness block that gets appended
    to the compiled system prompt. This lets the agent know which
    tools and connections it has access to at runtime.
    """
    node_descriptions = [
        f"  • [{n.node_type.upper()}] {n.label} — capabilities: {', '.join(n.capabilities)}"
        for n in network.nodes
        if n.node_type != "governance"
    ]

    # Build a quick node-id → label lookup
    node_map = {n.node_id: n for n in network.nodes}

    handoff_descriptions = [
        f"  {node_map.get(h.from_node_id, h).label if isinstance(node_map.get(h.from_node_id), NetworkNode) else h.from_node_id}"
        f" → {node_map.get(h.to_node_id, h).label if isinstance(node_map.get(h.to_node_id), NetworkNode) else h.to_node_id}"
        f" ({h.priority} priority, {h.payload_schema})"
        for h in network.handoffs
        if node_map.get(h.to_node_id) is None or node_map[h.to_node_id].node_type != "governance"
    ][:10]  # Keep prompt manageable

    return "\n".join([
        "",
        "[AGENTIC NETWORK]",
        f"Orchestration: {network.orchestration_framework}",
        "Available nodes:",
        *node_descriptions,
        "",
        "Available handoffs:",
        *handoff_descriptions,
        "",
        "When a task exceeds your capabilities, delegate to the appropriate node via handoff.",
        "All actions are audited by the governance node.",
    ])
