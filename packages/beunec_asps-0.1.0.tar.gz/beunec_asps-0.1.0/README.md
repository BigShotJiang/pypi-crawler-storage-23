# beunec-asps

**Agentic-System-Prompt-as-a-Skill™ (ASPS™)** — A lightweight, zero-dependency Python framework for deterministic skill construction in agentic systems.

> An LLM does not "have skills." It has parameters. ASPS™ provides the infrastructure that *makes* an agentic system skillful.

[![PyPI](https://img.shields.io/pypi/v/beunec-asps)](https://pypi.org/project/beunec-asps/)
[![Python](https://img.shields.io/pypi/pyversions/beunec-asps)](https://pypi.org/project/beunec-asps/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Install

```bash
pip install beunec-asps
```

## Quick Start

```python
from beunec_asps import (
    ASPSBuilder,
    create_heuristic,
    create_pseudonym_protocol,
    NetworkTopologies,
    HEURISTIC_LIBRARIES,
)

# Build a skill in 4 lines
skill = (
    ASPSBuilder(name="Stock Analyst", domain="Equity Research", description="...")
    .distill(HEURISTIC_LIBRARIES["financial_stock_analyst"])
    .reinforce(
        pseudonym_protocol=create_pseudonym_protocol(
            identity="CFA Charterholder",
            persona="A disciplined equity research analyst.",
        ),
        guardrail_presets=["standard", "financial"],
    )
    .network(NetworkTopologies.hub_and_spoke(
        orchestrator_label="Lead Analyst",
        spokes=[{"label": "Market Data API", "node_type": "api", "capabilities": ["quotes"]}],
    ))
    .compile()
)

# Use the compiled system prompt with any LLM
print(skill.compiled_system_prompt)
```

## Pre-Built Templates

```python
from beunec_asps.templates import ASPS_TEMPLATES

# 7 ready-to-use skill templates
skill = ASPS_TEMPLATES["financial_stock_analyst"]()
skill = ASPS_TEMPLATES["full_stack_developer"]()
skill = ASPS_TEMPLATES["scientific_researcher"]()
skill = ASPS_TEMPLATES["content_creator"]()
skill = ASPS_TEMPLATES["private_equity_analyst"]()
skill = ASPS_TEMPLATES["financial_investment_analyst"]()
skill = ASPS_TEMPLATES["academia_professor"]()
```

## The Three Techniques

| Layer | Technique | Purpose |
|---|---|---|
| 1 | **ASD™** (Agentic Skill Distillation) | Extract expert heuristics → deterministic instruction chains |
| 2 | **ASR™** (Agentic Skill Reinforcement) | Behavioral checkpoints, pseudonym protocols, ICRL, guardrails |
| 3 | **ANS™** (Agentic Network System) | Wire skills into governed multi-agent network topologies |

## Works With Everything

`beunec-asps` is **zero-dependency** and produces plain strings. It works alongside — never conflicts with:

- **LangChain** / **LangGraph** — use the compiled prompt as your agent's system message
- **OpenAI SDK** — pass `skill.compiled_system_prompt` as the system message
- **Anthropic SDK** — same
- **AutoGen** / **CrewAI** — use as the internal prompt for any agent in your graph
- **Any LLM** — it's just a string

## Custom Skills

```python
from beunec_asps import ASPSBuilder, create_heuristic, create_pseudonym_protocol, NetworkTopologies

skill = (
    ASPSBuilder(name="My Expert", domain="My Domain", description="What it does")
    .distill([
        create_heuristic(name="Step 1", instruction="Do this first."),
        create_heuristic(name="Step 2", instruction="Then do this."),
    ])
    .reinforce(
        pseudonym_protocol=create_pseudonym_protocol(
            identity="Domain Expert",
            persona="An experienced professional.",
        ),
        guardrail_presets=["standard"],
    )
    .network(NetworkTopologies.pipeline(stages=[
        {"label": "Agent A", "node_type": "agent", "capabilities": ["analyze"]},
        {"label": "Agent B", "node_type": "agent", "capabilities": ["synthesize"]},
    ]))
    .compile()
)
```

## License

MIT — © 2025 Beunec Technologies, Inc.

ASPS™, ASD™, ASR™, ANS™ are trademarks of Beunec Technologies, Inc.
