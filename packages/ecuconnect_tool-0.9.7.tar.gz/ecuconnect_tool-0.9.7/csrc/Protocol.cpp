///
/// CANyonero. (C) 2022 - 2023 Dr. Michael 'Mickey' Lauer <mickey@vanille-media.de>
///
#include "Protocol.hpp"

#include <algorithm>
#include <memory>
#include <sstream>
#include <cassert>
#include <new>

#include "lz4.h"

/// Protocol Implementation
namespace CANyonero {

//MARK: - Info
Info Info::from_vector(const Bytes& data) {
    Info info;
    std::stringstream ss;
    ss.str(std::string(data.begin(), data.end()));

    std::getline(ss, info.vendor, '\n');
    std::getline(ss, info.model, '\n');
    std::getline(ss, info.hardware, '\n');
    std::getline(ss, info.serial, '\n');
    std::getline(ss, info.firmware, '\n');

    return info;
}

//MARK: - Arbitration
void Arbitration::to_vector(Bytes& payload) const {
    vector_append_uint32(payload, request);
    payload.push_back(requestExtension);
    vector_append_uint32(payload, replyPattern);
    vector_append_uint32(payload, replyMask);
    payload.push_back(replyExtension);
}

static Arbitration from_vector(Bytes::const_iterator& it) {
    Arbitration a;
    a.request = vector_read_uint32(it);
    a.requestExtension = *it++;
    a.replyPattern = vector_read_uint32(it);
    a.replyMask = vector_read_uint32(it);
    a.replyExtension = *it++;
    return a;
}

const Info PDU::information() const {
    assert(_type == PDUType::info);
    return Info::from_vector(_payload);
}

const Arbitration PDU::arbitration() const {
    assert(_type == PDUType::setArbitration || _type == PDUType::startPeriodicMessage);

    auto it = _payload.begin() + 1; // skip channel info (setArbitration) or interval info (startPeriodic)
    return from_vector(it);
}

//MARK: - PDU
ChannelHandle PDU::channel() const {
    assert(_type == PDUType::openChannel ||
           _type == PDUType::openFDChannel ||
           _type == PDUType::closeChannel ||
           _type == PDUType::send ||
           _type == PDUType::sendCompressed ||
           _type == PDUType::received ||
           _type == PDUType::receivedCompressed ||
           _type == PDUType::setArbitration);

    return _payload[0];
}

PeriodicMessageHandle PDU::periodicMessage() const {
    assert(_type == PDUType::endPeriodicMessage);

    return _payload[0];
}

ChannelProtocol PDU::protocol() const {
    assert(_type == PDUType::openChannel || _type == PDUType::openFDChannel);
    return static_cast<ChannelProtocol>(_payload[0]);
}

uint32_t PDU::bitrate() const {
    assert(_type == PDUType::openChannel || _type == PDUType::openFDChannel);
    auto it = _payload.begin() + 1;
    return vector_read_uint32(it);
}

uint32_t PDU::dataBitrate() const {
    assert(_type == PDUType::openFDChannel);
    auto it = _payload.begin() + 5;
    return vector_read_uint32(it);
}

std::pair<uint16_t, uint16_t> PDU::separationTimes() const {
    assert(_type == PDUType::openChannel || _type == PDUType::openFDChannel);
    size_t offset = _type == PDUType::openFDChannel ? 9 : 5;
    SeparationTimeCode rxSeparation = _payload[offset] >> 4;
    SeparationTimeCode txSeparation = _payload[offset] & 0x0F;
    auto rxSeparationTime = microsecondsFromSeparationTimeCode(rxSeparation);
    auto txSeparationTime = microsecondsFromSeparationTimeCode(txSeparation);
    return std::make_pair(rxSeparationTime, txSeparationTime);
}

uint16_t PDU::milliseconds() const {
    assert(_type == PDUType::startPeriodicMessage);
    uint16_t interval = _payload[0];
    return interval * 500;
}

Bytes PDU::data() const {
    switch (_type) {
        case PDUType::received:
            return Bytes(_payload.begin() + 6, _payload.end());
        case PDUType::send:
            return Bytes(_payload.begin() + 1, _payload.end());
        case PDUType::sendUpdateData:
            return Bytes(_payload.begin(), _payload.end());
        case PDUType::startPeriodicMessage:
            return Bytes(_payload.begin() + 1 + CANyonero::Arbitration::size, _payload.end());
        default:
            assert(false);
            return {};
    }
}

Bytes PDU::uncompressedData() const {
    switch (_type) {
        case PDUType::receivedCompressed: {
            auto length = uncompressedLength();
            if (length == 0) { return {}; }
            if (_length < 8) { return {}; }
            const size_t compressedLength = _length - 8;
            Bytes output;
            try {
                output.resize(length);
            } catch (const std::bad_alloc&) {
                return {};
            }
            // offset computes from channel (1), id (4), extension (1), uncompressed length (2) = 8
            int decoded = LZ4_decompress_safe(reinterpret_cast<const char*>(_payload.data() + 8),
                                              reinterpret_cast<char*>(output.data()),
                                              static_cast<int>(compressedLength),
                                              static_cast<int>(length));
            if (decoded != static_cast<int>(length)) {
                output.clear();
            }
            return output;
        }

        case PDUType::sendCompressed: {
            auto length = uncompressedLength();
            if (length == 0) { return {}; }
            if (_length < 3) { return {}; }
            const size_t compressedLength = _length - 3;
            Bytes output;
            try {
                output.resize(length);
            } catch (const std::bad_alloc&) {
                return {};
            }
            // offset computes from channel (1), uncompressed length (2) = 3
            int decoded = LZ4_decompress_safe(reinterpret_cast<const char*>(_payload.data() + 3),
                                              reinterpret_cast<char*>(output.data()),
                                              static_cast<int>(compressedLength),
                                              static_cast<int>(length));
            if (decoded != static_cast<int>(length)) {
                output.clear();
            }
            return output;
        }
        default:
            return {};
    }
}

uint16_t PDU::uncompressedLength() const {
    switch (_type) {
        case PDUType::receivedCompressed: {
            // offset computes from channel (1), id (4), extension (1) = 6
            auto it = _payload.begin() + 6;
            return vector_read_uint16(it);
        }
        case PDUType::sendCompressed: {
            // offset computes from channel (1)
            auto it = _payload.begin() + 1;
            return vector_read_uint16(it);
        }
        default:
            assert(false);
            return 0;
    }
}

const Bytes& PDU::payload() const {
    return _payload;
}

std::string PDU::filename() const {
    assert(_type == PDUType::rpcSendBinary);
    return std::string(reinterpret_cast<const char*>(_payload.data()), _payload.size());
}

PDU::PDU(const Bytes& frame) {
    assert(frame.size() >= PDU::HEADER_SIZE);
    _length = frame[2] << 8 | frame[3];
    assert(frame.size() == PDU::HEADER_SIZE + _length);

    _type = static_cast<PDUType>(frame[1]);
    _payload = Bytes(frame.begin() + 4, frame.end());
}

const Bytes PDU::frame() const {

    std::vector<uint8_t> frame;
    frame.reserve(4 + _payload.size());
    frame.push_back(PDU::ATT);
    frame.push_back(static_cast<uint8_t>(_type));
    frame.push_back(static_cast<uint8_t>(_payload.size() >> 8));
    frame.push_back(static_cast<uint8_t>(_payload.size() & 0xff));

    frame.insert(frame.end(), _payload.begin(), _payload.end());
    return frame;
}

// Check whether there is a PDU in the `Bytes`.
// Returns > 0, if a complete PDU is found.
// Returns 0, if the contents looks like a PDU, but more data is needed.
// Returns < 0, if there is garbage in the buffer.
// If a negative value is returned, the caller SHOULD remove the offending bytes and immediately call this method again.
int PDU::containsPDU(const Bytes& bytes) {

    auto it = std::find(bytes.begin(), bytes.end(), 0x1F);
    if (it == bytes.end()) { return (int)-bytes.size(); } // ATT not found, remove everything.
    if (it != bytes.begin()) { return (int)std::distance(it, bytes.begin()); } // ATT found w/ leading garbage.

    if (bytes.size() < PDU::HEADER_SIZE) { return -0; }
    uint16_t payloadLength = bytes[2] << 8 | bytes[3];
    if (bytes.size() < PDU::HEADER_SIZE + payloadLength) { return -0; }
    return PDU::HEADER_SIZE + payloadLength;
}

bool PDU::exceedsMaxPduSize(const Bytes& bytes, size_t maxPduSize) {
    if (bytes.size() < PDU::HEADER_SIZE) { return false; }
    if (bytes[0] != PDU::ATT) { return false; }
    const size_t payloadLength = (static_cast<size_t>(bytes[2]) << 8) | bytes[3];
    return PDU::HEADER_SIZE + payloadLength > maxPduSize;
}

int PDU::scanBuffer(const Bytes& bytes) {
    return containsPDU(bytes);
}

bool PDU::tryRewritePingToPong(Bytes& frame) {
    if (frame.size() < PDU::HEADER_SIZE) { return false; }
    if (frame[0] != PDU::ATT) { return false; }
    const uint16_t payloadLength = static_cast<uint16_t>(frame[2] << 8 | frame[3]);
    if (frame.size() != PDU::HEADER_SIZE + payloadLength) { return false; }
    if (frame[1] != static_cast<uint8_t>(PDUType::ping)) { return false; }
    frame[1] = static_cast<uint8_t>(PDUType::pong);
    return true;
}

//MARK: - Tester -> Adapter PDU Construction
PDU PDU::ping(std::vector<uint8_t> payload) {
    return PDU(PDUType::ping, payload);
}

PDU PDU::requestInfo() {
    return PDU(PDUType::requestInfo);
}

PDU PDU::readVoltage() {
    return PDU(PDUType::readVoltage);
}

PDU PDU::reset() {
    return PDU(PDUType::reset);
}

PDU PDU::openChannel(const ChannelProtocol protocol, uint32_t bitrate, uint8_t rxSeparationTime, uint8_t txSeparationTime) {
    auto payload = Bytes(1, static_cast<uint8_t>(protocol));
    vector_append_uint32(payload, bitrate);
    uint8_t separationTime = rxSeparationTime << 4 | txSeparationTime;
    payload.push_back(separationTime);
    return PDU(PDUType::openChannel, payload);
}

PDU PDU::openFDChannel(const ChannelProtocol protocol, uint32_t bitrate, uint32_t dataBitrate, uint8_t rxSeparationTime, uint8_t txSeparationTime) {
    auto payload = Bytes(1, static_cast<uint8_t>(protocol));
    vector_append_uint32(payload, bitrate);
    vector_append_uint32(payload, dataBitrate);
    uint8_t separationTime = rxSeparationTime << 4 | txSeparationTime;
    payload.push_back(separationTime);
    return PDU(PDUType::openFDChannel, payload);
}

PDU PDU::closeChannel(const ChannelHandle handle) {
    auto payload = Bytes(1, handle);
    return PDU(PDUType::closeChannel, payload);
}

PDU PDU::send(const ChannelHandle handle, const Bytes& data) {
    auto payload = Bytes(1, handle);
    payload.insert(payload.end(), data.begin(), data.end());
    return PDU(PDUType::send, payload);
}

PDU PDU::sendCompressed(const ChannelHandle handle, const Bytes& uncompressedData) {
    const uint16_t uncompressedLength = uncompressedData.size();
    auto bound = LZ4_compressBound(uncompressedLength);
    std::vector<char> buffer(bound);
    auto compressedLength = LZ4_compress_default(reinterpret_cast<const char*>(uncompressedData.data()), buffer.data(), uncompressedLength, bound);

    auto payload = Bytes(1, handle);
    payload.reserve(3 + compressedLength);
    vector_append_uint16(payload, uncompressedLength);
    payload.insert(payload.end(), buffer.begin(), buffer.begin() + compressedLength);
    return PDU(PDUType::sendCompressed, payload);
}

PDU PDU::setArbitration(const ChannelHandle handle, const Arbitration arbitration) {
    auto payload = Bytes(1, handle);
    arbitration.to_vector(payload);
    return PDU(PDUType::setArbitration, payload);
}

PDU PDU::startPeriodicMessage(const uint8_t interval, const Arbitration arbitration, const Bytes& data) {
    auto payload = Bytes(1, interval);
    arbitration.to_vector(payload);
    payload.insert(payload.end(), data.begin(), data.end());
    return PDU(PDUType::startPeriodicMessage, payload);
}

PDU PDU::endPeriodicMessage(const PeriodicMessageHandle handle) {
    auto payload = Bytes(1, handle);
    return PDU(PDUType::endPeriodicMessage, payload);
}

PDU PDU::rpcCall(const std::string& string) {
    auto payload = Bytes(string.begin(), string.end());
    return PDU(PDUType::rpcCall, payload);
}

PDU PDU::rpcSendBinary(const std::string& filename) {
    auto payload = Bytes(filename.begin(), filename.end());
    return PDU(PDUType::rpcSendBinary, payload);
}

PDU PDU::prepareForUpdate() {
    return PDU(PDUType::prepareForUpdate);
}

PDU PDU::sendUpdateData(const Bytes& data) {
    return PDU(PDUType::sendUpdateData, data);
}

PDU PDU::commitUpdate() {
    return PDU(PDUType::commitUpdate);
}

//MARK: - Adapter -> Tester PDU Construction
PDU PDU::ok() {
    return PDU(PDUType::ok);
}

PDU PDU::pong(const Bytes payload) {
    return PDU(PDUType::pong, payload);
}

PDU PDU::info(const std::string vendor, const std::string model, const std::string hardware, const std::string serial, const std::string firmware) {
    std::vector<uint8_t> payload;
    payload.reserve(vendor.size() + model.size() + hardware.size() + serial.size() + firmware.size() + 5);

    payload.insert(payload.end(), vendor.begin(), vendor.end());
    payload.push_back('\n');
    payload.insert(payload.end(), model.begin(), model.end());
    payload.push_back('\n');
    payload.insert(payload.end(), hardware.begin(), hardware.end());
    payload.push_back('\n');
    payload.insert(payload.end(), serial.begin(), serial.end());
    payload.push_back('\n');
    payload.insert(payload.end(), firmware.begin(), firmware.end());

    return PDU(PDUType::info, payload);
}

PDU PDU::voltage(const uint16_t millivolts) {
    auto payload = Bytes();
    vector_append_uint16(payload, millivolts);
    return PDU(PDUType::voltage, payload);
}

PDU PDU::channelOpened(const ChannelHandle handle) {
    auto payload = Bytes(1, handle);
    return PDU(PDUType::channelOpened, payload);
}

PDU PDU::channelClosed(const ChannelHandle handle) {
    auto payload = Bytes(1, handle);
    return PDU(PDUType::channelClosed, payload);
}

PDU PDU::received(const ChannelHandle handle, const uint32_t id, const uint8_t extension, const Bytes& data) {
    auto payload = Bytes(1, handle);
    vector_append_uint32(payload, id);
    payload.push_back(extension);
    payload.insert(payload.end(), data.begin(), data.end());
    return PDU(PDUType::received, payload);
}

PDU PDU::receivedCompressed(const ChannelHandle handle, const uint32_t id, const uint8_t extension, const Bytes& uncompressedData) {
    const uint16_t uncompressedLength = uncompressedData.size();
    auto bound = LZ4_compressBound(uncompressedLength);
    std::vector<char> buffer(bound);
    auto compressedLength = LZ4_compress_default(reinterpret_cast<const char*>(uncompressedData.data()), buffer.data(), uncompressedLength, bound);

    auto payload = Bytes(1, handle);
    payload.reserve(8 + compressedLength);
    vector_append_uint32(payload, id);
    payload.push_back(extension);
    vector_append_uint16(payload, uncompressedLength);
    payload.insert(payload.end(), buffer.begin(), buffer.begin() + compressedLength);
    return PDU(PDUType::receivedCompressed, payload);
}

PDU PDU::periodicMessageStarted(const PeriodicMessageHandle handle) {
    auto payload = Bytes(1, handle);
    return PDU(PDUType::periodicMessageStarted, payload);
}

PDU PDU::periodicMessageEnded(const PeriodicMessageHandle handle) {
    auto payload = Bytes(1, handle);
    return PDU(PDUType::periodicMessageEnded, payload);
}

PDU PDU::rpcResponse(const std::string& string) {
    auto payload = Bytes(string.begin(), string.end());
    return PDU(PDUType::rpcResponse, payload);
}

PDU PDU::rpcBinaryResponse(const Bytes& data) {
    return PDU(PDUType::rpcBinaryResponse, data);
}

PDU PDU::errorUnspecified() {
    return PDU(PDUType::errorUnspecified);
}

PDU PDU::errorHardware() {
    return PDU(PDUType::errorHardware);
}

PDU PDU::errorInvalidChannel() {
    return PDU(PDUType::errorInvalidChannel);
}

PDU PDU::errorInvalidPeriodic() {
    return PDU(PDUType::errorInvalidPeriodic);
}

PDU PDU::errorInvalidRPC() {
    return PDU(PDUType::errorInvalidRPC);
}

PDU PDU::errorNoResponse() {
    return PDU(PDUType::errorNoResponse);
}

PDU PDU::errorInvalidCommand() {
    return PDU(PDUType::errorInvalidCommand);
}

//MARK: - Utilities
SeparationTimeCode PDU::separationTimeCodeFromMicroseconds(const Microseconds microseconds) {
    if (microseconds < 100) { return 0; }
    if (microseconds < 200) { return 0x07; }
    if (microseconds < 300) { return 0x08; }
    if (microseconds < 400) { return 0x09; }
    if (microseconds < 500) { return 0x0A; }
    if (microseconds < 600) { return 0x0B; }
    if (microseconds < 700) { return 0x0C; }
    if (microseconds < 800) { return 0x0D; }
    if (microseconds < 900) { return 0x0E; }
    if (microseconds < 1000) { return 0x0F; }
    if (microseconds < 2000) { return 0x01; }
    if (microseconds < 3000) { return 0x02; }
    if (microseconds < 4000) { return 0x03; }
    if (microseconds < 5000) { return 0x04; }
    if (microseconds < 6000) { return 0x05; }
    return 0x06;
}

Microseconds PDU::microsecondsFromSeparationTimeCode(const SeparationTimeCode separationTimeCode) {
    switch (separationTimeCode) {
        case 0x00: return 0;
        case 0x01: return 1000;
        case 0x02: return 2000;
        case 0x03: return 3000;
        case 0x04: return 4000;
        case 0x05: return 5000;
        case 0x06: return 6000;
        case 0x07: return 100;
        case 0x08: return 200;
        case 0x09: return 300;
        case 0x0A: return 400;
        case 0x0B: return 500;
        case 0x0C: return 600;
        case 0x0D: return 700;
        case 0x0E: return 800;
        case 0x0F: return 900;
        default: return 6000;
    }
}

};
