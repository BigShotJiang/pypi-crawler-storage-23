"""Test suite for data-related modules."""
