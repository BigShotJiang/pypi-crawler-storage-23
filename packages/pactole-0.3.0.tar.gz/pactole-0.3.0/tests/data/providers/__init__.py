"""Tests for data providers."""
