# Combinations

[Pactole Index](../README.md#pactole-index) / Combinations

> Auto-generated documentation for [combinations](https://github.com/cerbernetix/pactole/blob/main/src/pactole/combinations/__init__.py) module.

- [Combinations](#combinations)
  - [Modules](#modules)

## Modules

- [Combination](./combination.md)
- [EuroDreamsCombination](./eurodreams_combination.md)
- [EuroMillionsCombination](./euromillions_combination.md)
- [LotteryCombination](./lottery_combination.md)