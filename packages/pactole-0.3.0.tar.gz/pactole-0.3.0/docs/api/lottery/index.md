# Lottery

[Pactole Index](../README.md#pactole-index) / Lottery

> Auto-generated documentation for [lottery](https://github.com/cerbernetix/pactole/blob/main/src/pactole/lottery/__init__.py) module.

- [Lottery](#lottery)
  - [Modules](#modules)

## Modules

- [BaseLottery](./base_lottery.md)
- [EuroDreams](./eurodreams.md)
- [EuroMillions](./euromillions.md)