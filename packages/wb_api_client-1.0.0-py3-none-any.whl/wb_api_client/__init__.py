"""
WB API Client - Wildberries Content API Client
"""

from .client import WildberriesAPIClient
from .exceptions import (
    APIError,
    AuthenticationError,
    ForbiddenError,
    RateLimitError,
    ValidationError,
    NotFoundError,
    ServerError,
    ConnectionError,
)

__version__ = "1.0.0"
__all__ = [
    "WildberriesAPIClient",
    "APIError",
    "AuthenticationError",
    "ForbiddenError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "ServerError",
    "ConnectionError",
]