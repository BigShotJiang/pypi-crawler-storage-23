"""
Wildberries API Client
"""
import time
import requests
from typing import Optional, List, Dict, Any, Union
from .exceptions import (
    APIError, AuthenticationError, ForbiddenError, RateLimitError,
    ValidationError, NotFoundError, ServerError, ConnectionError
)


class WildberriesAPIClient:
    """Client for Wildberries Content API"""
    
    BASE_URL = "https://content-api.wildberries.ru"
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key
        self.session = requests.Session()
        self._last_request_time = 0
        self._min_request_interval = 0.6  # 600ms between requests
        self._timeout = 120  # 2 minutes timeout
        self._max_retries = 3
        
    def set_api_key(self, api_key: str):
        """Set API key for authentication"""
        self.api_key = api_key
        
    def _get_headers(self) -> dict:
        """Get headers for API request"""
        if not self.api_key:
            raise AuthenticationError("API key not set")
        return {
            "Authorization": self.api_key,
            "Content-Type": "application/json"
        }
    
    def _wait_for_rate_limit(self):
        """Wait to respect rate limiting"""
        elapsed = time.time() - self._last_request_time
        if elapsed < self._min_request_interval:
            time.sleep(self._min_request_interval - elapsed)
        self._last_request_time = time.time()
    
    def _make_request(self, method: str, endpoint: str, 
                      params: dict = None, data: dict = None,
                      files: dict = None) -> dict:
        """Make HTTP request to API with retries"""
        url = f"{self.BASE_URL}{endpoint}"
        headers = self._get_headers()
        
        if files:
            # Remove Content-Type for multipart requests
            headers.pop("Content-Type", None)
        
        last_error = None
        for attempt in range(self._max_retries):
            self._wait_for_rate_limit()
            
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    headers=headers,
                    params=params,
                    json=data if not files else None,
                    data=data if files else None,
                    files=files,
                    timeout=self._timeout
                )
                
                # Handle HTTP errors
                if response.status_code == 401:
                    raise AuthenticationError("Invalid API key", status_code=401)
                elif response.status_code == 403:
                    raise ForbiddenError("Access forbidden", status_code=403)
                elif response.status_code == 429:
                    retry_after = response.headers.get('Retry-After')
                    wait_time = int(retry_after) if retry_after else 5
                    time.sleep(wait_time)
                    continue
                elif response.status_code == 400:
                    error_data = response.json() if response.text else {}
                    raise ValidationError(
                        error_data.get('errorText', 'Validation error'),
                        status_code=400,
                        response_data=error_data
                    )
                elif response.status_code == 404:
                    raise NotFoundError("Resource not found", status_code=404)
                elif response.status_code >= 500:
                    raise ServerError(
                        f"Server error: {response.status_code}",
                        status_code=response.status_code
                    )
                
                response.raise_for_status()
                
                if response.text:
                    return response.json()
                return {}
                
            except requests.exceptions.Timeout as e:
                last_error = e
                time.sleep(2)  # Wait before retry
                continue
            except requests.exceptions.ConnectionError as e:
                last_error = e
                time.sleep(2)
                continue
            except requests.exceptions.RequestException as e:
                raise APIError(f"Request failed: {str(e)}")
        
        # All retries exhausted
        if last_error:
            if isinstance(last_error, requests.exceptions.Timeout):
                raise ConnectionError(f"Request timeout after {self._max_retries} attempts")
            else:
                raise ConnectionError(f"Connection failed after {self._max_retries} attempts: {str(last_error)}")
        raise APIError("Unknown error")
    
    # ==================== Parent Categories ====================
    
    def get_parent_categories(self, locale: str = "ru") -> List[dict]:
        """Get all parent categories"""
        params = {"locale": locale}
        response = self._make_request("GET", "/content/v2/object/parent/all", params=params)
        return response.get("data", [])
    
    # ==================== Subjects (Objects) ====================
    
    def get_subjects(self, locale: str = "ru", name: str = None,
                     limit: int = 30, offset: int = 0,
                     parent_id: int = None) -> List[dict]:
        """Get list of subjects"""
        params = {"locale": locale, "limit": limit, "offset": offset}
        if name:
            params["name"] = name
        if parent_id:
            params["parentID"] = parent_id
        
        response = self._make_request("GET", "/content/v2/object/all", params=params)
        return response.get("data", [])
    
    # ==================== Characteristics ====================
    
    def get_characteristics(self, subject_id: int, locale: str = "ru") -> List[dict]:
        """Get characteristics for a subject"""
        params = {"locale": locale}
        response = self._make_request(
            "GET", 
            f"/content/v2/object/charcs/{subject_id}", 
            params=params
        )
        return response.get("data", [])
    
    # ==================== Directories (Colors, Kinds, Countries, etc.) ====================
    
    def get_colors(self, locale: str = "ru") -> List[dict]:
        """Get available colors"""
        params = {"locale": locale}
        response = self._make_request("GET", "/content/v2/directory/colors", params=params)
        return response.get("data", [])
    
    def get_kinds(self, locale: str = "ru") -> List[str]:
        """Get available genders/kinds"""
        params = {"locale": locale}
        response = self._make_request("GET", "/content/v2/directory/kinds", params=params)
        return response.get("data", [])
    
    def get_countries(self, locale: str = "ru") -> List[dict]:
        """Get available countries"""
        params = {"locale": locale}
        response = self._make_request("GET", "/content/v2/directory/countries", params=params)
        return response.get("data", [])
    
    def get_seasons(self, locale: str = "ru") -> List[str]:
        """Get available seasons"""
        params = {"locale": locale}
        response = self._make_request("GET", "/content/v2/directory/seasons", params=params)
        return response.get("data", [])
    
    def get_vat_rates(self, locale: str = "ru") -> List[str]:
        """Get available VAT rates"""
        params = {"locale": locale}
        response = self._make_request("GET", "/content/v2/directory/vat", params=params)
        return response.get("data", [])
    
    def get_tnved(self, subject_id: int, search: str = None, locale: str = "ru") -> List[dict]:
        """Get TNVED codes for subject"""
        params = {"subjectID": subject_id, "locale": locale}
        if search:
            params["search"] = search
        response = self._make_request("GET", "/content/v2/directory/tnved", params=params)
        return response.get("data", [])
    
    # ==================== Brands ====================
    
    def get_brands(self, subject_id: int, next_id: int = None) -> dict:
        """Get brands for subject"""
        params = {"subjectId": subject_id}
        if next_id:
            params["next"] = next_id
        response = self._make_request("GET", "/api/content/v1/brands", params=params)
        return response
    
    # ==================== Card Limits ====================
    
    def get_card_limits(self) -> dict:
        """Get card creation limits"""
        response = self._make_request("GET", "/content/v2/cards/limits")
        return response.get("data", {})
    
    # ==================== Barcodes ====================
    
    def generate_barcodes(self, count: int) -> List[str]:
        """Generate barcodes"""
        data = {"count": count}
        response = self._make_request("POST", "/content/v2/barcodes", data=data)
        return response.get("data", [])
    
    # ==================== Cards CRUD ====================
    
    def create_cards(self, cards: List[dict]) -> dict:
        """Create product cards"""
        return self._make_request("POST", "/content/v2/cards/upload", data=cards)
    
    def create_cards_with_attachment(self, imt_id: int, cards_to_add: List[dict]) -> dict:
        """Create cards and attach to existing group"""
        data = {
            "imtID": imt_id,
            "cardsToAdd": cards_to_add
        }
        return self._make_request("POST", "/content/v2/cards/upload/add", data=data)
    
    def get_cards_list(self, settings: dict = None, locale: str = "ru") -> dict:
        """Get list of product cards (single page)"""
        params = {"locale": locale}
        if settings is None:
            settings = {
                "sort": {"ascending": False},
                "cursor": {"limit": 100},
                "filter": {"withPhoto": -1}
            }
        # API expects settings wrapped in "settings" key
        data = {"settings": settings}
        response = self._make_request("POST", "/content/v2/get/cards/list", 
                                       params=params, data=data)
        return response
    
    def get_all_cards(self, locale: str = "ru", callback=None) -> List[dict]:
        """Get all product cards with pagination"""
        all_cards = []
        settings = {
            "sort": {"ascending": False},
            "cursor": {"limit": 100},
            "filter": {"withPhoto": -1}
        }
        
        total_loaded = 0
        while True:
            params = {"locale": locale}
            data = {"settings": settings}
            response = self._make_request("POST", "/content/v2/get/cards/list",
                                          params=params, data=data)
            
            cards = response.get("cards", [])
            if not cards:
                break
            
            all_cards.extend(cards)
            total_loaded += len(cards)
            
            # Notify callback about progress
            if callback:
                callback(total_loaded, len(all_cards))
            
            # Get cursor for next page
            cursor = response.get("cursor", {})
            if not cursor.get("nmID"):
                break
            
            # Update cursor for next request
            settings["cursor"] = {
                "limit": 100,
                "nmID": cursor.get("nmID"),
                "updatedAt": cursor.get("updatedAt")
            }
        
        return all_cards
    
    def get_error_cards(self, cursor: dict = None, order: dict = None, 
                        locale: str = "ru") -> dict:
        """Get list of cards with errors"""
        params = {"locale": locale}
        if cursor is None:
            cursor = {"limit": 100}
        if order is None:
            order = {"ascending": True}
        data = {"cursor": cursor, "order": order}
        response = self._make_request("POST", "/content/v2/cards/error/list",
                                       params=params, data=data)
        return response
    
    def update_cards(self, cards: List[dict]) -> dict:
        """Update product cards"""
        return self._make_request("POST", "/content/v2/cards/update", data=cards)
    
    def move_cards_to_trash(self, nm_ids: List[int]) -> dict:
        """Move cards to trash"""
        data = {"nmIDs": nm_ids}
        return self._make_request("POST", "/content/v2/cards/delete/trash", data=data)
    
    def recover_cards_from_trash(self, nm_ids: List[int]) -> dict:
        """Recover cards from trash"""
        data = {"nmIDs": nm_ids}
        return self._make_request("POST", "/content/v2/cards/recover", data=data)
    
    def get_trash_cards(self, settings: dict = None, locale: str = "ru") -> dict:
        """Get list of cards in trash (single page)"""
        params = {"locale": locale}
        if settings is None:
            settings = {
                "sort": {"ascending": False},
                "cursor": {"limit": 100}
            }
        # API expects settings wrapped in "settings" key
        data = {"settings": settings}
        response = self._make_request("POST", "/content/v2/get/cards/trash",
                                       params=params, data=data)
        return response
    
    def get_all_trash_cards(self, locale: str = "ru", callback=None) -> List[dict]:
        """Get all cards from trash with pagination"""
        all_cards = []
        settings = {
            "sort": {"ascending": False},
            "cursor": {"limit": 100}
        }
        
        total_loaded = 0
        while True:
            params = {"locale": locale}
            # API expects settings wrapped in "settings" key
            data = {"settings": settings}
            response = self._make_request("POST", "/content/v2/get/cards/trash",
                                          params=params, data=data)
            
            cards = response.get("cards", [])
            if not cards:
                break
            
            all_cards.extend(cards)
            total_loaded += len(cards)
            
            # Notify callback about progress
            if callback:
                callback(total_loaded, len(all_cards))
            
            # Get cursor for next page
            cursor = response.get("cursor", {})
            if not cursor.get("nmID"):
                break
            
            # Update cursor for next request - use trashedAt for trash cards
            settings["cursor"] = {
                "limit": 100,
                "nmID": cursor.get("nmID"),
                "trashedAt": cursor.get("trashedAt")
            }
        
        return all_cards
    
    def move_cards(self, target_imt: int, nm_ids: List[int]) -> dict:
        """Move/merge cards"""
        data = {"targetIMT": target_imt, "nmIDs": nm_ids}
        return self._make_request("POST", "/content/v2/cards/moveNm", data=data)
    
    def disconnect_cards(self, nm_ids: List[int]) -> dict:
        """Disconnect cards from group"""
        data = {"nmIDs": nm_ids}
        return self._make_request("POST", "/content/v2/cards/moveNm", data=data)
    
    # ==================== Media ====================
    
    def upload_media_file(self, nm_id: int, photo_number: int, file_path: str) -> dict:
        """Upload media file to card"""
        with open(file_path, 'rb') as f:
            files = {'uploadfile': f}
            headers = self._get_headers()
            headers.pop("Content-Type", None)
            headers["X-Nm-Id"] = str(nm_id)
            headers["X-Photo-Number"] = str(photo_number)
            
            self._wait_for_rate_limit()
            response = self.session.post(
                f"{self.BASE_URL}/content/v3/media/file",
                headers=headers,
                files=files
            )
            
            if response.status_code not in (200, 201):
                raise APIError(f"Upload failed: {response.status_code}", 
                              status_code=response.status_code)
            
            return response.json()
    
    def upload_media_by_urls(self, nm_id: int, urls: List[str]) -> dict:
        """Upload media by URLs"""
        data = {
            "nmId": nm_id,
            "data": urls
        }
        return self._make_request("POST", "/content/v3/media/save", data=data)