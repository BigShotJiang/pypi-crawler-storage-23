"""
Wildberries API Exceptions
"""


class APIError(Exception):
    """Base exception for API errors"""
    
    def __init__(self, message: str, status_code: int = None, response_data: dict = None):
        self.message = message
        self.status_code = status_code
        self.response_data = response_data or {}
        super().__init__(self.message)
    
    def __str__(self):
        if self.status_code:
            return f"API Error ({self.status_code}): {self.message}"
        return f"API Error: {self.message}"


class AuthenticationError(APIError):
    """Raised when authentication fails (401)"""
    pass


class ForbiddenError(APIError):
    """Raised when access is forbidden (403)"""
    pass


class RateLimitError(APIError):
    """Raised when rate limit is exceeded (429)"""
    
    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = None, **kwargs):
        self.retry_after = retry_after
        super().__init__(message, status_code=429, **kwargs)


class ValidationError(APIError):
    """Raised when request validation fails (400)"""
    pass


class NotFoundError(APIError):
    """Raised when resource is not found (404)"""
    pass


class ServerError(APIError):
    """Raised for server errors (5xx)"""
    pass


class ConnectionError(APIError):
    """Raised when connection fails"""
    pass