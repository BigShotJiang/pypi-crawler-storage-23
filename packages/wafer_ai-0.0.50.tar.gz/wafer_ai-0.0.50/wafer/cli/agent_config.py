"""Agent configuration loaded from TOML files.

This is the experiment knob: everything that affects how the agent behaves.
Designed to be versioned alongside experiment results for reproducibility.

Usage:
    config = load_agent_config(Path("experiments/kernelbench_v1.toml"))
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ContextConfig:
    """Controls what runtime context is injected into the system prompt.

    TOML usage:
        [context]
        targets = true
        sandboxes = true
        working_dir = true
    """
    targets: bool = True
    sandboxes: bool = True
    working_dir: bool = True


@dataclass(frozen=True)
class ContextManagementConfig:
    """Controls how the agent manages conversation context (token pruning).

    TOML usage:
        [context_management]
        thinking_turns_keep = 2
        tool_uses_trigger_tokens = 100000
        tool_uses_keep = 5
        tool_uses_clear_at_least_tokens = 10000
        compact_trigger_tokens = 150000
        pause_after_compaction = true
    """
    thinking_turns_keep: int = 2
    tool_uses_trigger_tokens: int = 100_000
    tool_uses_keep: int = 5
    tool_uses_clear_at_least_tokens: int = 10_000
    compact_trigger_tokens: int = 150_000
    pause_after_compaction: bool = True


@dataclass(frozen=True)
class AgentFileConfig:
    """Agent configuration loaded from a TOML file.

    All fields are optional (None). Unset fields defer to CLI flags, then
    template defaults, then hard-coded defaults. Override precedence:
        CLI flag > config file > template > defaults
    """

    # Model selection
    model: str | None = None
    provider: str | None = None
    temperature: float | None = None
    max_tokens: int | None = None

    # Agent behavior
    max_turns: int | None = None
    single_turn: bool | None = None
    template: str | None = None

    # Prompts
    system_prompt: str | None = None
    user_prompt_template: str | None = None

    # Tools
    tools: list[str] | None = None
    bash_allowlist: list[str] | None = None
    bash_denylist: list[str] | None = None
    confirm_tools: list[str] | None = None

    # Extended thinking (Anthropic)
    thinking_enabled: bool | None = None
    thinking_budget_tokens: int | None = None

    # Reasoning (OpenAI)
    reasoning_effort: str | None = None
    max_completion_tokens: int | None = None

    # Environment
    allow_network: bool | None = None
    workspace: str | None = None

    # Runtime / routing
    agent: str | None = None  # Top-level agent: wafer, claude, or codex. Default wafer.
    target_name: str | None = None  # wafer target run --name <name> (e.g. Trainium)
    timeout_sec: float | None = None  # max seconds per eval problem
    defaults: dict[str, str] | None = None  # template variable defaults
    cloud_only: bool | None = None  # if true, must run in cloud (e.g. docs agent)

    # Named Modal volumes to mount (populated from [volumes] TOML section)
    # Maps volume_name -> mount_path (e.g. "wafer-corpus" -> "/corpus")
    volumes: dict[str, str] = field(default_factory=dict)

    # Context injection (what runtime info to inject into system prompt)
    context: ContextConfig = field(default_factory=ContextConfig)

    # Context management (token pruning strategy)
    context_management: ContextManagementConfig = field(default_factory=ContextManagementConfig)

    # Display (for --list-templates)
    description: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for JSON wire format. Only non-None/non-default fields."""
        d: dict[str, Any] = {}
        _SIMPLE_FIELDS = (
            "model", "provider", "temperature", "max_tokens",
            "max_turns", "single_turn", "template",
            "system_prompt", "user_prompt_template",
            "tools", "bash_allowlist", "bash_denylist", "confirm_tools",
            "thinking_enabled", "thinking_budget_tokens",
            "reasoning_effort", "max_completion_tokens",
            "allow_network", "workspace",
            "agent", "target_name", "timeout_sec", "defaults",
            "description", "cloud_only",
        )
        for key in _SIMPLE_FIELDS:
            val = getattr(self, key)
            if val is not None:
                d[key] = val
        if self.volumes:
            d["volumes"] = dict(self.volumes)
        ctx = self.context
        if ctx != ContextConfig():
            d["context"] = {
                "targets": ctx.targets,
                "sandboxes": ctx.sandboxes,
                "working_dir": ctx.working_dir,
            }
        cm = self.context_management
        if cm != ContextManagementConfig():
            d["context_management"] = {
                "thinking_turns_keep": cm.thinking_turns_keep,
                "tool_uses_trigger_tokens": cm.tool_uses_trigger_tokens,
                "tool_uses_keep": cm.tool_uses_keep,
                "tool_uses_clear_at_least_tokens": cm.tool_uses_clear_at_least_tokens,
                "compact_trigger_tokens": cm.compact_trigger_tokens,
                "pause_after_compaction": cm.pause_after_compaction,
            }
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "AgentFileConfig":
        """Deserialize from dict (JSON wire format)."""
        assert isinstance(d, dict), f"Expected dict, got {type(d)}"
        ctx_raw = d.get("context", {})
        context = ContextConfig(
            targets=ctx_raw.get("targets", True),
            sandboxes=ctx_raw.get("sandboxes", True),
            working_dir=ctx_raw.get("working_dir", True),
        )
        cm_raw = d.get("context_management", {})
        context_management = ContextManagementConfig(**cm_raw) if cm_raw else ContextManagementConfig()
        return cls(
            model=d.get("model"),
            provider=d.get("provider"),
            temperature=d.get("temperature"),
            max_tokens=d.get("max_tokens"),
            max_turns=d.get("max_turns"),
            single_turn=d.get("single_turn"),
            template=d.get("template"),
            system_prompt=d.get("system_prompt"),
            user_prompt_template=d.get("user_prompt_template"),
            tools=d.get("tools"),
            bash_allowlist=d.get("bash_allowlist"),
            bash_denylist=d.get("bash_denylist"),
            confirm_tools=d.get("confirm_tools"),
            thinking_enabled=d.get("thinking_enabled"),
            thinking_budget_tokens=d.get("thinking_budget_tokens"),
            reasoning_effort=d.get("reasoning_effort"),
            max_completion_tokens=d.get("max_completion_tokens"),
            allow_network=d.get("allow_network"),
            workspace=d.get("workspace"),
            agent=d.get("agent"),
            target_name=d.get("target_name"),
            timeout_sec=d.get("timeout_sec"),
            defaults=d.get("defaults"),
            cloud_only=d.get("cloud_only"),
            volumes=d.get("volumes", {}),
            context=context,
            context_management=context_management,
            description=d.get("description"),
        )

    def to_toml_string(self) -> str:
        """Serialize to TOML string for writing temp config files."""
        d = self.to_dict()
        context = d.pop("context", None)
        context_management = d.pop("context_management", None)
        volumes = d.pop("volumes", {})
        return _dict_to_toml_string(d, context=context,
                                     context_management=context_management, volumes=volumes)


def _dict_to_toml_string(
    d: dict[str, Any],
    *,
    context: dict[str, Any] | None = None,
    context_management: dict[str, Any] | None = None,
    volumes: dict[str, str] | None = None,
) -> str:
    """Convert a flat config dict to a TOML string."""
    lines: list[str] = []
    nested_sections: dict[str, dict[str, Any]] = {}

    for key, value in d.items():
        if value is None:
            continue
        if key == "thinking_enabled":
            nested_sections.setdefault("thinking", {})["enabled"] = value
        elif key == "thinking_budget_tokens":
            nested_sections.setdefault("thinking", {})["budget_tokens"] = value
        elif key == "bash_allowlist":
            nested_sections.setdefault("bash", {})["allowlist"] = value
        elif key == "bash_denylist":
            nested_sections.setdefault("bash", {})["denylist"] = value
        elif key == "reasoning_effort":
            nested_sections.setdefault("reasoning", {})["effort"] = value
        elif key == "max_completion_tokens":
            nested_sections.setdefault("reasoning", {})["max_tokens"] = value
        elif key == "defaults" and isinstance(value, dict):
            nested_sections["defaults"] = value
        elif isinstance(value, str) and "\n" in value:
            lines.append(f'{key} = """\n{value}"""')
        elif isinstance(value, str):
            lines.append(f'{key} = "{value}"')
        elif isinstance(value, bool):
            lines.append(f"{key} = {'true' if value else 'false'}")
        elif isinstance(value, (int, float)):
            lines.append(f"{key} = {value}")
        elif isinstance(value, list):
            items = ", ".join(f'"{v}"' for v in value)
            lines.append(f"{key} = [{items}]")

    for section_name, section_vals in nested_sections.items():
        lines.append(f"\n[{section_name}]")
        for k, v in section_vals.items():
            if isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")
            elif isinstance(v, (int, float)):
                lines.append(f"{k} = {v}")
            elif isinstance(v, str):
                lines.append(f'{k} = "{v}"')
            elif isinstance(v, list):
                items = ", ".join(f'"{i}"' for i in v)
                lines.append(f"{k} = [{items}]")

    if volumes:
        lines.append("\n[volumes]")
        for k, v in volumes.items():
            lines.append(f'{k} = "{v}"')

    if context:
        lines.append("\n[context]")
        for k, v in context.items():
            if isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")

    if context_management:
        lines.append("\n[context_management]")
        for k, v in context_management.items():
            if isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")
            elif isinstance(v, (int, float)):
                lines.append(f"{k} = {v}")

    return "\n".join(lines) + "\n"


def load_agent_config(path: Path) -> AgentFileConfig:
    """Load agent config from a TOML file.

    Returns AgentFileConfig with only the fields that were explicitly set.
    Unset fields remain None, allowing CLI flags and template defaults to fill in.

    Supports nested sections:
        [thinking]
        enabled = true
        budget_tokens = 10000

        [bash]
        allowlist = ["make", "hipcc"]

        [reasoning]
        effort = "high"
        max_tokens = 8192
    """
    import tomllib

    assert path.exists(), f"Config file not found: {path}"
    assert path.suffix == ".toml", f"Config file must be .toml, got: {path.suffix}"

    with open(path, "rb") as f:
        raw = tomllib.load(f)

    thinking = raw.pop("thinking", {})
    bash = raw.pop("bash", {})
    reasoning = raw.pop("reasoning", {})
    defaults = raw.pop("defaults", {})
    raw_volumes = raw.pop("volumes", {})
    raw_context = raw.pop("context", {})
    raw_ctx_mgmt = raw.pop("context_management", {})

    _validate_no_unknown_keys(raw, thinking, bash, reasoning, defaults, raw_context, raw_ctx_mgmt)

    agent = raw.get("agent")
    if agent is not None:
        assert agent in _VALID_TOP_LEVEL_AGENTS, (
            f"agent must be one of {_VALID_TOP_LEVEL_AGENTS}. Got: {agent!r}"
        )

    defaults_dict: dict[str, str] | None = None
    if defaults:
        defaults_dict = {k: str(v) for k, v in defaults.items()}

    context = ContextConfig(
        targets=raw_context.get("targets", True),
        sandboxes=raw_context.get("sandboxes", True),
        working_dir=raw_context.get("working_dir", True),
    )
    context_management = ContextManagementConfig(
        thinking_turns_keep=raw_ctx_mgmt.get("thinking_turns_keep", 2),
        tool_uses_trigger_tokens=raw_ctx_mgmt.get("tool_uses_trigger_tokens", 100_000),
        tool_uses_keep=raw_ctx_mgmt.get("tool_uses_keep", 5),
        tool_uses_clear_at_least_tokens=raw_ctx_mgmt.get("tool_uses_clear_at_least_tokens", 10_000),
        compact_trigger_tokens=raw_ctx_mgmt.get("compact_trigger_tokens", 150_000),
        pause_after_compaction=raw_ctx_mgmt.get("pause_after_compaction", True),
    )

    return AgentFileConfig(
        model=raw.get("model"),
        provider=raw.get("provider"),
        temperature=raw.get("temperature"),
        max_tokens=raw.get("max_tokens"),
        max_turns=raw.get("max_turns"),
        single_turn=raw.get("single_turn"),
        template=raw.get("template"),
        system_prompt=raw.get("system_prompt"),
        user_prompt_template=raw.get("user_prompt_template"),
        tools=raw.get("tools"),
        bash_allowlist=bash.get("allowlist") or raw.get("bash_allowlist"),
        bash_denylist=bash.get("denylist"),
        confirm_tools=raw.get("confirm_tools"),
        thinking_enabled=thinking.get("enabled"),
        thinking_budget_tokens=thinking.get("budget_tokens"),
        reasoning_effort=reasoning.get("effort") or raw.get("reasoning_effort"),
        max_completion_tokens=reasoning.get("max_tokens") or raw.get("max_completion_tokens"),
        allow_network=raw.get("allow_network"),
        workspace=raw.get("workspace"),
        agent=agent,
        target_name=raw.get("target_name"),
        timeout_sec=raw.get("timeout_sec"),
        cloud_only=raw.get("cloud_only"),
        volumes={k: str(v) for k, v in raw_volumes.items()} if raw_volumes else {},
        context=context,
        context_management=context_management,
        defaults=defaults_dict,
        description=raw.get("description"),
    )


_KNOWN_TOP_LEVEL_KEYS = frozenset({
    "model", "provider", "temperature", "max_tokens",
    "max_turns", "single_turn", "template",
    "system_prompt", "user_prompt_template",
    "tools", "bash_allowlist", "confirm_tools",
    "thinking_enabled", "thinking_budget_tokens",
    "reasoning_effort", "max_completion_tokens",
    "allow_network", "workspace",
    "agent", "env", "target_name", "timeout_sec", "defaults",
    "description", "cloud_only",
})
_KNOWN_CONTEXT_KEYS = frozenset({"targets", "sandboxes", "working_dir"})

_VALID_TOP_LEVEL_AGENTS = ("wafer", "claude", "codex")

_KNOWN_THINKING_KEYS = frozenset({"enabled", "budget_tokens"})
_KNOWN_BASH_KEYS = frozenset({"allowlist", "denylist"})
_KNOWN_REASONING_KEYS = frozenset({"effort", "max_tokens"})


def write_agent_config_toml(path: Path, **kwargs: Any) -> Path:
    """Write an AgentFileConfig as a TOML file.

    Handles multi-line strings (system_prompt) correctly with TOML triple-quotes.
    Returns the path for chaining.
    """
    lines: list[str] = []
    nested_sections: dict[str, dict[str, Any]] = {}

    for key, value in kwargs.items():
        if value is None:
            continue
        # Route nested keys to their sections
        if key == "thinking_enabled":
            nested_sections.setdefault("thinking", {})["enabled"] = value
        elif key == "thinking_budget_tokens":
            nested_sections.setdefault("thinking", {})["budget_tokens"] = value
        elif key == "bash_allowlist":
            nested_sections.setdefault("bash", {})["allowlist"] = value
        elif key == "reasoning_effort":
            nested_sections.setdefault("reasoning", {})["effort"] = value
        elif key == "max_completion_tokens":
            nested_sections.setdefault("reasoning", {})["max_tokens"] = value
        elif key == "defaults" and isinstance(value, dict):
            nested_sections["defaults"] = value
        elif isinstance(value, str) and "\n" in value:
            lines.append(f'{key} = """\n{value}"""')
        elif isinstance(value, str):
            lines.append(f'{key} = "{value}"')
        elif isinstance(value, bool):
            lines.append(f"{key} = {'true' if value else 'false'}")
        elif isinstance(value, (int, float)):
            lines.append(f"{key} = {value}")
        elif isinstance(value, list):
            items = ", ".join(f'"{v}"' for v in value)
            lines.append(f"{key} = [{items}]")

    for section_name, section_vals in nested_sections.items():
        lines.append(f"\n[{section_name}]")
        for k, v in section_vals.items():
            if isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")
            elif isinstance(v, (int, float)):
                lines.append(f"{k} = {v}")
            elif isinstance(v, str):
                lines.append(f'{k} = "{v}"')
            elif isinstance(v, list):
                items = ", ".join(f'"{i}"' for i in v)
                lines.append(f"{k} = [{items}]")

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n")
    return path


_BUNDLED_TOML_DIR = Path(__file__).parent / "templates" / "toml"


def get_bundled_template_path(name: str) -> Path | None:
    """Resolve a template name to its bundled TOML path, or None if not found.

    Normalizes name: "trace-analyze" -> "trace_analyze.toml".
    """
    module_name = name.replace("-", "_")
    toml_path = _BUNDLED_TOML_DIR / f"{module_name}.toml"
    if toml_path.exists():
        return toml_path
    toml_path = _BUNDLED_TOML_DIR / f"{name}.toml"
    if toml_path.exists():
        return toml_path
    return None


def list_bundled_templates() -> list[str]:
    """List available bundled TOML template names."""
    if not _BUNDLED_TOML_DIR.exists():
        return []
    return sorted(
        f.stem.replace("_", "-")
        for f in _BUNDLED_TOML_DIR.glob("*.toml")
    )


_KNOWN_CTX_MGMT_KEYS = frozenset({
    "thinking_turns_keep", "tool_uses_trigger_tokens", "tool_uses_keep",
    "tool_uses_clear_at_least_tokens", "compact_trigger_tokens", "pause_after_compaction",
})


def _validate_no_unknown_keys(
    raw: dict[str, Any],
    thinking: dict[str, Any],
    bash: dict[str, Any],
    reasoning: dict[str, Any],
    defaults: dict[str, Any],
    context: dict[str, Any] | None = None,
    context_management: dict[str, Any] | None = None,
) -> None:
    """Fail fast on unknown keys to catch typos."""
    unknown_top = set(raw.keys()) - _KNOWN_TOP_LEVEL_KEYS
    assert not unknown_top, f"Unknown keys in agent config: {unknown_top}"

    unknown_thinking = set(thinking.keys()) - _KNOWN_THINKING_KEYS
    assert not unknown_thinking, f"Unknown keys in [thinking]: {unknown_thinking}"

    unknown_bash = set(bash.keys()) - _KNOWN_BASH_KEYS
    assert not unknown_bash, f"Unknown keys in [bash]: {unknown_bash}"

    unknown_reasoning = set(reasoning.keys()) - _KNOWN_REASONING_KEYS
    assert not unknown_reasoning, f"Unknown keys in [reasoning]: {unknown_reasoning}"

    if context:
        unknown_context = set(context.keys()) - _KNOWN_CONTEXT_KEYS
        assert not unknown_context, f"Unknown keys in [context]: {unknown_context}"

    if context_management:
        unknown_ctx_mgmt = set(context_management.keys()) - _KNOWN_CTX_MGMT_KEYS
        assert not unknown_ctx_mgmt, f"Unknown keys in [context_management]: {unknown_ctx_mgmt}"
