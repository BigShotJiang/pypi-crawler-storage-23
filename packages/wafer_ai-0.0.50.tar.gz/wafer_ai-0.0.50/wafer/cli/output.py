"""Structured output formatting for CLI commands.
Provides JSON and JSONL output formats for machine-readable CLI output.
All --json output uses a standardized envelope:
    {"status": "ok"|"error", "data": {...}, "warnings": [...]}
"""
from __future__ import annotations

import json
import re
from enum import StrEnum
from typing import Any

import typer


def json_response(
    data: Any = None,
    *,
    status: str = "ok",
    warnings: list[str] | None = None,
    error: str | None = None,
) -> str:
    """Format standardized JSON response envelope.

    All --json CLI output uses: {"status": "ok"|"error", "data": {...}, "warnings": [...]}
    """
    response: dict[str, Any] = {"status": status}
    if data is not None:
        response["data"] = data
    if error is not None:
        response["error"] = error
    if warnings:
        response["warnings"] = warnings
    return json.dumps(response, indent=2, default=str)


def json_error(error: str, *, data: Any = None, warnings: list[str] | None = None) -> str:
    """Format standardized JSON error response."""
    return json_response(data=data, status="error", error=error, warnings=warnings)


class OutputFormat(StrEnum):
    """Output format for CLI commands."""
    TEXT = "text"  # Human-readable (default)
    JSON = "json"  # Single JSON object at end
    JSONL = "jsonl"  # Streaming JSON Lines


def parse_error_message(error_message: str) -> dict[str, Any]:
    """Parse error message to extract structured information."""
    error_info: dict[str, Any] = {"message": error_message}
    # Try to identify the phase and type from common patterns
    error_lower = error_message.lower()
    if "compilation" in error_lower or "compile" in error_lower:
        error_info["phase"] = "compilation"
        error_info["type"] = "CompilationError"
        # Try to parse compiler error format: file:line:col: error: message
        parsed = parse_compilation_error(error_message)
        if parsed:
            error_info.update(parsed)
    elif "hsa_status" in error_lower or "memory" in error_lower or "segfault" in error_lower:
        error_info["phase"] = "runtime"
        error_info["type"] = "MemoryViolation"
    elif "timeout" in error_lower:
        error_info["phase"] = "runtime"
        error_info["type"] = "Timeout"
    elif "correctness" in error_lower:
        error_info["phase"] = "correctness"
        error_info["type"] = "CorrectnessError"
    else:
        error_info["phase"] = "unknown"
        error_info["type"] = "UnknownError"
    return error_info


def parse_compilation_error(raw_output: str) -> dict[str, Any] | None:
    """Extract structured info from compiler error output.
    Matches patterns like: file.hip:10:14: error: message
    """
    match = re.search(
        r"(?P<file>[\w./]+):(?P<line>\d+):(?P<col>\d+): error: (?P<message>.+)",
        raw_output,
    )
    if match:
        return {
            "file": match.group("file"),
            "line": int(match.group("line")),
            "column": int(match.group("col")),
            "message": match.group("message").strip(),
        }
    return None


def get_output_format(json_flag: bool, jsonl_flag: bool) -> OutputFormat:
    """Determine output format from CLI flags."""
    if jsonl_flag:
        return OutputFormat.JSONL
    if json_flag:
        return OutputFormat.JSON
    return OutputFormat.TEXT
