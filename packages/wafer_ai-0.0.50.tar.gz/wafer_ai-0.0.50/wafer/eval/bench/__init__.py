"""Standalone bench scripts for eval tasks.

Each script is a standalone Python module that:
1. Runs in the target directory
2. Performs GPU measurements
3. Outputs JSON to stdout

Invoked by tasks via: python -m wafer.eval.bench.<name>
"""
