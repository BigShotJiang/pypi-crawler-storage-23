"""Run commands on a GPU target from within eval scorers.

When running on a GPU target (WAFER_TARGET_NAME is set), commands execute
locally as subprocesses. Otherwise, falls back to `wafer sandbox run` for
remote execution.

Usage in a custom scorer.py:

    from pathlib import Path
    from wafer.eval import Score, Metric
    from wafer.eval.sandbox_runner import sandbox_run

    async def score(work_dir: Path) -> Score:
        output = await sandbox_run(
            "nvcc -O3 gemm.cu -o gemm -lcublas && ./gemm",
            sync_path=work_dir,
        )
        # Parse output, return Score
        ...
"""
from __future__ import annotations

import asyncio
import os
from pathlib import Path


def _on_gpu_target() -> bool:
    return bool(os.environ.get("WAFER_TARGET_NAME"))


async def _run_local(
    command: str,
    *,
    timeout: int,
    sync_path: str | Path | None,
) -> str:
    """Execute command as a local subprocess (already on GPU target)."""
    cwd = str(Path(sync_path).resolve()) if sync_path else None
    proc = await asyncio.create_subprocess_shell(
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=cwd,
    )
    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            proc.communicate(), timeout=timeout
        )
    except asyncio.TimeoutError:
        proc.kill()
        raise RuntimeError(f"command timed out after {timeout}s: {command[:120]}")

    stdout = stdout_bytes.decode(errors="replace")
    stderr = stderr_bytes.decode(errors="replace")

    if proc.returncode != 0:
        parts = []
        if stderr.strip():
            parts.append(stderr.strip()[-2000:])
        if stdout.strip():
            parts.append(f"stdout: {stdout.strip()[-2000:]}")
        detail = "\n".join(parts) or "(no output)"
        raise RuntimeError(f"command failed (exit {proc.returncode}): {detail}")

    return stdout


async def _run_remote(
    command: str,
    *,
    target: str | None,
    timeout: int,
    sync_path: str | Path | None,
) -> str:
    """Execute command via `wafer sandbox run` (remote GPU sandbox)."""
    cli_args = ["wafer", "sandbox", "run"]
    if target:
        cli_args.extend(["--target", target])
    if sync_path is not None:
        path = Path(sync_path).resolve()
        assert path.is_dir(), f"sync_path must be a directory: {path}"
        cli_args.extend(["--sync", str(path)])
    cli_args.extend(["--timeout-sec", str(timeout), "--idle-timeout-sec", "120", "--", command])

    proc = await asyncio.create_subprocess_exec(
        *cli_args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout_bytes, stderr_bytes = await proc.communicate()
    stdout = stdout_bytes.decode(errors="replace")
    stderr = stderr_bytes.decode(errors="replace")

    if proc.returncode != 0:
        parts = []
        if stderr.strip():
            parts.append(stderr.strip()[-2000:])
        if stdout.strip():
            parts.append(f"stdout: {stdout.strip()[-2000:]}")
        detail = "\n".join(parts) or "(no output)"
        raise RuntimeError(f"sandbox command failed (exit {proc.returncode}): {detail}")

    return stdout


async def sandbox_run(
    command: str,
    *,
    target: str | None = None,
    timeout: int = 300,
    sync_path: str | Path | None = None,
) -> str:
    """Execute a command on a GPU and return stdout.

    When WAFER_TARGET_NAME is set (agent running on GPU target), runs locally.
    Otherwise uses `wafer sandbox run` for remote execution.
    """
    assert command, "command must not be empty"

    if _on_gpu_target():
        return await _run_local(command, timeout=timeout, sync_path=sync_path)
    return await _run_remote(command, target=target, timeout=timeout, sync_path=sync_path)


async def sandbox_run_all(
    commands: list[str],
    *,
    target: str | None = None,
    timeout: int = 300,
) -> list[str]:
    """Run multiple commands sequentially, return all outputs."""
    assert commands, "commands must not be empty"
    results: list[str] = []
    for cmd in commands:
        out = await sandbox_run(cmd, target=target, timeout=timeout)
        results.append(out)
    return results
