"""Tests for autotuner."""
