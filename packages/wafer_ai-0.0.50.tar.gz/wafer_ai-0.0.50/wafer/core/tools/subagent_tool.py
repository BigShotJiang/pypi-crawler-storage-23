"""Subagent tool: spawn a subagent via the wafer API.

The agent passes either a template name (string) or an inline config (dict)
alongside a prompt. No pre-configured named subagents required.
"""
from __future__ import annotations

import os
from collections.abc import Awaitable, Callable
from typing import Any

from wafer.core.rollouts.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
    ToolResultDelta,
)

SUBAGENT_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="subagent",
        description=(
            "Spawn a subagent to handle a task independently. "
            "Subagents are deployed to sandboxes on targets — use them for GPU/accelerator work. "
            "They do NOT create separate cloud instances. "
            "Pass a template name (e.g. 'default') or an inline config object "
            "with fields like system_prompt, tools, model, max_tokens."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "prompt": {"type": "string", "description": "Task for the subagent"},
                "config": {
                    "description": (
                        "Template name (string, e.g. 'default') or inline config object "
                        "with fields: system_prompt, tools, model, max_tokens, etc."
                    ),
                },
            },
        ),
        required=["prompt", "config"],
    ),
)


def _tool_call_summary(data: dict) -> str:
    name = data.get("name") or data.get("tool_name") or "tool"
    args = data.get("args", {})
    if name in ("read", "write", "edit"):
        return f"{name} {args.get('path', '')}".rstrip()
    if name == "bash":
        cmd = str(args.get("command", ""))
        return f"bash {cmd[:80]}"
    if name == "grep":
        return f"grep {args.get('pattern', '')}".rstrip()
    if name == "glob":
        return f"glob {args.get('pattern', '')}".rstrip()
    if name == "eval_task":
        return f"eval_task {args.get('subcommand', '')}".rstrip()
    if name == "subagent":
        agent = args.get("agent", "")
        return f"subagent {agent}".rstrip()
    return name


async def exec_subagent(
    tool_call: ToolCall,
    on_output: Callable[[ToolResultDelta], Awaitable[None]] | None = None,
    *,
    api_url: str | None = None,
    auth_token: str | None = None,
) -> ToolResult:
    """Execute a subagent via the wafer API.

    config can be a template name (string) resolved to a bundled TOML,
    or an inline config dict sent directly as inline_config.
    """
    from wafer.cli.agent_config import get_bundled_template_path, load_agent_config

    config_arg = tool_call.args.get("config")
    prompt = tool_call.args.get("prompt", "")
    assert config_arg, "subagent 'config' argument is required"
    assert prompt, "subagent 'prompt' argument is required"

    target_name: str | None = None
    if isinstance(config_arg, str):
        template_path = get_bundled_template_path(config_arg)
        assert template_path is not None, (
            f"Unknown template '{config_arg}'. "
            "Use a bundled template name (e.g. 'default') or pass an inline config dict."
        )
        file_config = load_agent_config(template_path)
        inline_config = file_config.to_dict()
        target_name = getattr(file_config, "target_name", None)
    else:
        assert isinstance(config_arg, dict), (
            f"config must be a template name (string) or inline config (dict), got {type(config_arg).__name__}"
        )
        inline_config = config_arg
        target_name = inline_config.pop("target_name", None)

    if not target_name:
        target_name = os.environ.get("WAFER_TARGET_NAME") or os.environ.get("WAFER_DEFAULT_TARGET")

    # Prevent recursive subagent calls — strip subagent from the tools list
    if "tools" in inline_config and isinstance(inline_config["tools"], list):
        inline_config["tools"] = [t for t in inline_config["tools"] if t != "subagent"]
    elif "tools" not in inline_config or inline_config["tools"] is None:
        from wafer.core.environments.wafer_ai import ALL_TOOLS
        inline_config["tools"] = [t for t in ALL_TOOLS if t != "subagent"]

    return await _exec_wafer_api_subagent(
        tool_call, prompt, inline_config,
        on_output=on_output,
        api_url=api_url, auth_token=auth_token,
        target_name=target_name,
    )


async def _exec_wafer_api_subagent(
    tool_call: ToolCall,
    prompt: str,
    inline_config: dict[str, Any],
    on_output: Callable[[ToolResultDelta], Awaitable[None]] | None,
    *,
    api_url: str | None,
    auth_token: str | None,
    target_name: str | None = None,
) -> ToolResult:
    """POST inline_config to /v1/cloud-agent/run and stream the response."""
    assert api_url, "api_url is required for subagent execution"
    assert auth_token, "auth_token is required for subagent execution"

    from wafer.core.api_client import WaferApiError, stream_wafer_api

    body: dict[str, object] = {
        "prompt": prompt,
        "inline_config": inline_config,
        "mode": "empty",
        "tags": {"source": "subagent"},
    }

    if target_name:
        body["target_name"] = target_name

    volume_env = os.environ.get("WAFER_VOLUME_ENV")
    if volume_env:
        body["volume_env"] = volume_env

    text_chunks: list[str] = []
    subagent_session_id: str = ""
    pending_tool_names: dict[str, str] = {}
    try:
        async for event in stream_wafer_api(
            api_url=api_url,
            auth_token=auth_token,
            endpoint="/v1/cloud-agent/run",
            body=body,
        ):
            if event.event_type == "session_started":
                subagent_session_id = event.data.get("session_id", "")
                if subagent_session_id and on_output:
                    await on_output(ToolResultDelta(
                        tool_call_id=tool_call.id,
                        delta=f"[subagent_session:{subagent_session_id}]\n",
                    ))
            elif event.event_type == "tool_call_end":
                tool_id = event.data.get("id", "")
                name = event.data.get("name") or event.data.get("tool_name") or "tool"
                pending_tool_names[tool_id] = name
                if on_output:
                    summary = _tool_call_summary(event.data)
                    await on_output(ToolResultDelta(
                        tool_call_id=tool_call.id,
                        delta=f"→ {summary}\n",
                    ))
            elif event.event_type == "tool_result":
                tc_id = event.data.get("tool_call_id", "")
                name = pending_tool_names.pop(tc_id, "")
                is_err = event.data.get("is_error", False)
                if on_output:
                    if is_err:
                        snippet = (event.data.get("content") or event.data.get("error") or "")[:120]
                        await on_output(ToolResultDelta(
                            tool_call_id=tool_call.id,
                            delta=f"  ✗ {name}: {snippet}\n",
                        ))
                    else:
                        snippet = (event.data.get("content") or "")[:200]
                        await on_output(ToolResultDelta(
                            tool_call_id=tool_call.id,
                            delta=f"  ✓ {name}: {snippet}\n",
                        ))
            elif event.event_type == "text_delta":
                text = event.data.get("delta", "")
                if text:
                    text_chunks.append(text)
                    if on_output:
                        await on_output(ToolResultDelta(
                            tool_call_id=tool_call.id,
                            delta=text,
                        ))
            elif event.event_type == "error":
                error_msg = event.data.get("error", "Unknown error from wafer API")
                return ToolResult(
                    tool_call_id=tool_call.id,
                    is_error=True,
                    content="",
                    error=error_msg,
                )
    except WaferApiError as e:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=str(e),
        )

    prefix = f"[subagent_session:{subagent_session_id}]\n" if subagent_session_id else ""
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=prefix + "".join(text_chunks),
    )
