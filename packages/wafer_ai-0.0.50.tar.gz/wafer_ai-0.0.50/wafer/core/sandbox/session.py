"""SandboxSession: manages tmux lifecycle and command execution on a remote machine."""
from __future__ import annotations

import json
import logging
import os
import shlex
import time
from collections.abc import Awaitable, Callable
from uuid import uuid4

import trio

from wafer.core.async_ssh import AsyncSSHClient
from wafer.core.sandbox.types import Sandbox

OnOutputCallback = Callable[[str], Awaitable[None]]

HARD_TIMEOUT_EXIT_CODE = -1
IDLE_EXIT_CODE = -2


class SandboxSession:
    """Holds AsyncSSHClient, manages tmux lifecycle and command execution."""

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox
        self._client: AsyncSSHClient | None = None
        self._initialized = False

    @property
    def _tmp_dir(self) -> str:
        """Per-sandbox temp directory for command output files."""
        return f"/tmp/.wafer_sandbox/{self._sandbox.tmux_session}"

    @property
    def _pid_file(self) -> str:
        """Path to the PID file for the destroy-timer process."""
        return f"{self._tmp_dir}/destroy.pid"

    def _schedule_destroy_cmd(self) -> str:
        """Build command that starts a destroy timer and writes its PID to a file."""
        session = self._sandbox.tmux_session
        timeout_sec = max(3600, self._sandbox.timeout_hours * 3600)
        tmp = self._tmp_dir
        pid_file = self._pid_file
        return (
            f"bash -c '"
            f"nohup bash -c \""
            f"sleep {timeout_sec}; "
            f"tmux kill-session -t {shlex.quote(session)} 2>/dev/null; "
            f"rm -rf {tmp}"
            f"\" >/dev/null 2>&1 & "
            f"echo $! > {pid_file}"
            f"'"
        )

    async def _kill_old_timer(self) -> None:
        """Kill destroy-timer by PID if pid file exists. Best-effort."""
        pid_file = self._pid_file
        result = await self._client.exec(f"cat {pid_file} 2>/dev/null")
        if result.exit_code == 0 and result.stdout.strip():
            pid = result.stdout.strip()
            await self._client.exec(f"kill {pid} 2>/dev/null || true")

    async def _refresh_timer(self) -> None:
        """Kill old destroy-timer, schedule a new one. Resets idle timer on activity."""
        await self._kill_old_timer()
        schedule_result = await self._client.exec(self._schedule_destroy_cmd())
        if schedule_result.exit_code != 0:
            logging.getLogger(__name__).warning(
                "sandbox: failed to schedule destroy timer: %s", schedule_result.stderr
            )

    async def _start_heartbeat(self) -> None:
        """Start heartbeat daemon in background on the target via nohup."""
        sb = self._sandbox
        vendor = sb.gpu_vendor or "nvidia"
        count = sb.gpu_count or 1
        api_url = os.environ.get("WAFER_API_URL", "")
        auth_token = os.environ.get("WAFER_AUTH_TOKEN", "")

        cmd = (
            f"WAFER_API_URL={shlex.quote(api_url)} "
            f"WAFER_AUTH_TOKEN={shlex.quote(auth_token)} "
            f"nohup wafer sandbox _heartbeat "
            f"--sandbox-id {shlex.quote(sb.id)} "
            f"--gpu-vendor {shlex.quote(vendor)} "
            f"--gpu-count {count} "
            f">/dev/null 2>&1 &"
        )
        await self._client.exec(cmd)

    async def start(self) -> None:
        """Connect, create NEW tmux session, schedule self-destruct."""
        self._client = AsyncSSHClient(
            self._sandbox.ssh_target,
            self._sandbox.ssh_key,
        )
        result = await self._client.exec("true")
        if result.exit_code != 0:
            raise RuntimeError(f"SSH connection failed: {result.stderr}")

        session = self._sandbox.tmux_session
        tmp = self._tmp_dir

        mkdir_result = await self._client.exec(f"mkdir -p {tmp}")
        if mkdir_result.exit_code != 0:
            raise RuntimeError(f"Failed to create sandbox tmp dir: {mkdir_result.stderr}")

        tmux_result = await self._client.exec(
            f"tmux new-session -d -s {shlex.quote(session)}"
        )
        if tmux_result.exit_code != 0:
            raise RuntimeError(f"Failed to create tmux session: {tmux_result.stderr}")

        schedule_result = await self._client.exec(self._schedule_destroy_cmd())
        if schedule_result.exit_code != 0:
            await self._client.exec(
                f"tmux kill-session -t {shlex.quote(session)} 2>/dev/null || true"
            )
            raise RuntimeError(
                f"Failed to schedule sandbox delete timer: {schedule_result.stderr}"
            )
        self._initialized = True
        await self._start_heartbeat()

    async def connect(self) -> None:
        """Connect to an EXISTING tmux session (no new session created)."""
        self._client = AsyncSSHClient(
            self._sandbox.ssh_target,
            self._sandbox.ssh_key,
        )
        result = await self._client.exec("true")
        if result.exit_code != 0:
            raise RuntimeError(f"SSH connection failed: {result.stderr}")

        session = self._sandbox.tmux_session
        check = await self._client.exec(
            f"tmux has-session -t {shlex.quote(session)} 2>/dev/null"
        )
        if check.exit_code != 0:
            raise RuntimeError(
                f"tmux session '{session}' does not exist on remote. "
                f"Create one first: wafer sandbox create"
            )

        await self._client.exec(f"mkdir -p {self._tmp_dir}")
        self._initialized = True
        await self._start_heartbeat()

    async def run_command(
        self,
        command: str,
        timeout: int = 180,
        no_change_timeout: int = 30,
        on_output: OnOutputCallback | None = None,
    ) -> tuple[str, int, dict]:
        """Run command in tmux session. Returns (output, exit_code, metadata).

        exit_code meanings:
          >=0: command completed with that exit code
          HARD_TIMEOUT_EXIT_CODE (-1): hard timeout exceeded
          IDLE_EXIT_CODE (-2): no output change for no_change_timeout seconds

        Refreshes the idle timer on each call so active sessions are not killed."""
        assert self._initialized, "SandboxSession not started; call start() first"
        assert self._client is not None, "SandboxSession client is None"

        await self._refresh_timer()

        cmd_id = uuid4().hex[:8]
        tmp = self._tmp_dir
        out_file = f"{tmp}/{cmd_id}.out"
        exit_file = f"{tmp}/{cmd_id}.exit"
        meta_file = f"{tmp}/{cmd_id}.meta"
        session = self._sandbox.tmux_session

        state_file = f"{tmp}/.state"
        wrapped = (
            f"{{ [ -f {state_file} ] && . {state_file}; "
            f"{{ {command}; }} > {out_file} 2>&1; "
            f"_wafer_ec=$?; "
            f'echo "cd \\"$PWD\\"" > {state_file}; '
            f"export -p >> {state_file}; "
            f"printf '{{\"cwd\":\"%s\",\"exit_code\":%d}}' \"$PWD\" $_wafer_ec > {meta_file}; "
            f"echo $_wafer_ec > {exit_file}; }}"
        )
        send_cmd = f"tmux send-keys -t {shlex.quote(session)} {shlex.quote(wrapped)} Enter"
        await self._client.exec(send_cmd)

        poll_interval = 0.5
        elapsed = 0.0
        last_streamed = 0
        last_output_size = 0
        last_change_time = time.monotonic()
        while elapsed < timeout:
            result = await self._client.exec(
                f"test -f {exit_file} && cat {exit_file}"
            )
            if result.exit_code == 0 and result.stdout.strip():
                exit_code_str = result.stdout.strip().split()[-1]
                try:
                    exit_code = int(exit_code_str)
                except ValueError:
                    exit_code = -1
                out_result = await self._client.exec(f"cat {out_file}")
                assert out_result.stdout is not None
                output = out_result.stdout
                if on_output and len(output) > last_streamed:
                    await on_output(output[last_streamed:])
                metadata = await self._read_metadata(meta_file)
                await self._client.exec(f"rm -f {out_file} {exit_file} {meta_file}")
                return output, exit_code, metadata

            size_result = await self._client.exec(
                f"wc -c < {out_file} 2>/dev/null || echo 0"
            )
            current_size = int(size_result.stdout.strip() or "0")
            if current_size != last_output_size:
                last_output_size = current_size
                last_change_time = time.monotonic()

            if on_output and current_size > last_streamed:
                new_data = await self._client.exec(
                    f"tail -c +{last_streamed + 1} {out_file} 2>/dev/null"
                )
                if new_data.stdout:
                    await on_output(new_data.stdout)
                    last_streamed += len(new_data.stdout.encode("utf-8"))

            if no_change_timeout > 0 and (time.monotonic() - last_change_time) >= no_change_timeout:
                partial = await self._read_output(out_file)
                if on_output and len(partial) > last_streamed:
                    await on_output(partial[last_streamed:])
                return partial, IDLE_EXIT_CODE, {}

            await trio.sleep(poll_interval)
            elapsed += poll_interval

        partial = await self._read_output(out_file)
        if on_output and len(partial) > last_streamed:
            await on_output(partial[last_streamed:])
        await self._client.exec(f"rm -f {out_file} {exit_file} {meta_file}")
        return partial, HARD_TIMEOUT_EXIT_CODE, {}

    async def _read_output(self, out_file: str) -> str:
        """Read command output file from remote."""
        assert self._client is not None
        result = await self._client.exec(f"cat {out_file} 2>/dev/null || true")
        assert result.stdout is not None
        return result.stdout

    async def _read_metadata(self, meta_file: str) -> dict:
        """Read command metadata JSON from remote. Returns empty dict on failure."""
        assert self._client is not None
        result = await self._client.exec(f"cat {meta_file} 2>/dev/null")
        if result.exit_code == 0 and result.stdout.strip():
            try:
                return json.loads(result.stdout.strip())
            except json.JSONDecodeError:
                return {}
        return {}

    async def send_input(self, text: str) -> None:
        """Send keystrokes to the tmux session.

        For special keys (C-c, C-z, C-d), sends without Enter.
        For regular text, sends with Enter.
        """
        assert self._initialized, "SandboxSession not started; call start() first"
        assert self._client is not None, "SandboxSession client is None"
        session = self._sandbox.tmux_session
        is_special = text.startswith("C-") and len(text) == 3
        if is_special:
            await self._client.exec(
                f"tmux send-keys -t {shlex.quote(session)} {text}"
            )
        else:
            await self._client.exec(
                f"tmux send-keys -t {shlex.quote(session)} {shlex.quote(text)} Enter"
            )

    async def close(self) -> None:
        """Kill tmux session, clean up per-sandbox temp dir, close SSH client."""
        if not self._initialized or self._client is None:
            return
        session = self._sandbox.tmux_session
        await self._client.exec(
            f"tmux kill-session -t {shlex.quote(session)} 2>/dev/null || true"
        )
        await self._client.exec(f"rm -rf {self._tmp_dir} 2>/dev/null || true")
        await self._client.close()
        self._client = None
        self._initialized = False
