"""HeadlessJsonFrontend - Bidirectional NDJSON for scripting and testing.
Unlike JsonFrontend which is output-only, this frontend supports:
- Reading NDJSON input from stdin (user messages, /skill invocations)
- Emitting NDJSON output to stdout (responses, errors)
Designed for:
- Scripted agent interactions
- Building external UIs that communicate via JSON
- CI/CD pipelines with interactive flows
Input format (one JSON per line):
    {"type": "user", "text": "hello"}
    {"type": "user", "text": "/wafer-guide how do I profile?"}
Output format (one JSON per line):
    {"type": "system", "subtype": "init", "session_id": "...", "tools": [...]}
    {"type": "assistant", "message": {"content": [...]}}
    {"type": "result", "subtype": "success", "session_id": "...", "num_turns": 1}
"""
from __future__ import annotations

import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

import trio

if TYPE_CHECKING:
    from ..dtypes import Endpoint, Environment, StreamEvent, ToolCall, Trajectory


@dataclass
class HeadlessJsonFrontend:
    """Bidirectional NDJSON streaming frontend.
    Reads JSON input from stdin, emits JSON output to stdout.
    Supports slash commands for testing /env, /model, /thinking, etc.
    """
    # Configuration
    input_file: Any = field(default_factory=lambda: sys.stdin)
    output_file: Any = field(default_factory=lambda: sys.stdout)
    include_thinking: bool = False
    include_timing: bool = True
    interactive_approval: bool = False  # If True, emit tool_approval_request and wait for response
    # State (initialized in __post_init__ or start)
    _current_text: list[str] = field(default_factory=list)
    _current_thinking: list[str] = field(default_factory=list)
    _current_tool_calls: list[dict] = field(default_factory=list)
    _tool_results: dict[str, dict] = field(default_factory=dict)
    _start_time: float = 0
    _num_turns: int = 0
    _session_id: str | None = None
    _tools: list[str] = field(default_factory=list)
    environment: Environment | None = None
    endpoint: Endpoint | None = None
    session_store: Any = None
    session_id: str | None = None
    trajectory: Trajectory | None = None
    # Input buffer for async reading
    _input_lines: list[str] = field(default_factory=list)
    _input_exhausted: bool = False

    def _emit(self, obj: dict) -> None:
        """Emit a single NDJSON line."""
        print(json.dumps(obj, ensure_ascii=False), file=self.output_file, flush=True)

    def _flush_assistant_turn(self) -> None:
        """Emit current assistant turn if there's content."""
        content = []
        if self._current_thinking and self.include_thinking:
            thinking_text = "".join(self._current_thinking).strip()
            if thinking_text:
                content.append({"type": "thinking", "thinking": thinking_text})
        text = "".join(self._current_text).strip()
        if text:
            content.append({"type": "text", "text": text})
        content.extend(self._current_tool_calls)
        if content:
            self._emit({"type": "assistant", "message": {"content": content}})
            self._num_turns += 1
        # Reset state
        self._current_text = []
        self._current_thinking = []
        self._current_tool_calls = []

    async def start(self) -> None:
        """Emit init event."""
        self._start_time = time.time()
        self._emit({
            "type": "system",
            "subtype": "init",
            "session_id": self._session_id or self.session_id or "",
            "tools": self._tools,
            "environment": self._get_current_env_name(),
        })

    async def stop(self) -> None:
        """Emit result event."""
        # Flush any remaining content
        self._flush_assistant_turn()
        result = {
            "type": "result",
            "subtype": "success",
            "session_id": self._session_id or self.session_id or "",
            "num_turns": self._num_turns,
        }
        if self.include_timing:
            result["duration_ms"] = int((time.time() - self._start_time) * 1000)
        self._emit(result)

    async def handle_event(self, event: StreamEvent) -> None:
        """Handle streaming event by emitting JSON."""
        from ..dtypes import (
            StreamDone,
            StreamError,
            TextDelta,
            ThinkingDelta,
            ToolCallEnd,
            ToolResultReceived,
        )
        if isinstance(event, TextDelta):
            self._current_text.append(event.delta)
        elif isinstance(event, ThinkingDelta):
            self._current_thinking.append(event.delta)
        elif isinstance(event, ToolCallEnd):
            self._current_tool_calls.append({
                "type": "tool_use",
                "id": event.tool_call.id,
                "name": event.tool_call.name,
                "input": dict(event.tool_call.args),
            })
        elif isinstance(event, ToolResultReceived):
            # Flush assistant turn before tool result
            self._flush_assistant_turn()
            # Emit tool result as user message
            self._emit({
                "type": "user",
                "message": {
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": event.tool_call_id,
                            "content": event.content,
                            "is_error": event.is_error,
                        }
                    ]
                },
            })
        elif isinstance(event, StreamDone):
            self._flush_assistant_turn()
        elif isinstance(event, StreamError):
            self._flush_assistant_turn()
            self._emit({
                "type": "error",
                "error": str(event.error),
            })

    def _get_current_env_name(self) -> str:
        """Get current environment name (mirrors TUI helper)."""
        if self.environment is None:
            return "none"
        if hasattr(self.environment, "environments"):
            names = []
            for env in self.environment.environments:
                if hasattr(env, "get_name"):
                    names.append(env.get_name())
                else:
                    names.append(type(env).__name__)
            return "+".join(names) if names else "composed"
        if hasattr(self.environment, "get_name"):
            return self.environment.get_name()
        return type(self.environment).__name__

    async def _resolve_and_execute_skill(self, text: str) -> tuple[str | None, str | None]:
        """Resolve /skill-name, execute (inline or fork). Returns (expanded, None) or (None, error)."""
        from ..skill_executor import execute_forked_skill, resolve_skill_command
        invocation, err = resolve_skill_command(text)
        if err:
            return None, err
        assert invocation is not None
        if invocation.context == "fork":
            result_text = await execute_forked_skill(invocation)
            return result_text, None
        return invocation.substituted_content, None

    async def get_input(self, prompt: str = "") -> str:
        """Get user input from stdin NDJSON.
        Reads JSON lines from stdin. Each line should be:
            {"type": "user", "text": "..."}
        Slash commands are processed internally.
        """
        while True:
            # Read next line from stdin
            line = await self._read_input_line()
            if line is None:
                # EOF - signal to stop
                raise EOFError("No more input")
            try:
                data = json.loads(line)
            except json.JSONDecodeError as e:
                self._emit({
                    "type": "error",
                    "error": f"Invalid JSON input: {e}",
                    "line": line,
                })
                continue
            text = data.get("text", "")
            if not text:
                self._emit({
                    "type": "error",
                    "error": "Missing 'text' field in input",
                    "input": data,
                })
                continue
            if text.startswith("/"):
                expanded, err = await self._resolve_and_execute_skill(text)
                if err:
                    self._emit({"type": "error", "error": err})
                    continue
                if expanded:
                    text = expanded
            return text

    async def _read_input_line(self) -> str | None:
        """Read a single line from stdin asynchronously."""
        try:
            # For testing, check if we have buffered lines
            if self._input_lines:
                return self._input_lines.pop(0)
            if self._input_exhausted:
                return None
            # Read from stdin using trio
            line = await trio.to_thread.run_sync(self.input_file.readline)
            if not line:
                self._input_exhausted = True
                return None
            return line.strip()
        except Exception:
            self._input_exhausted = True
            return None

    async def confirm_tool(self, tool_call: ToolCall) -> bool:
        """Request tool approval via NDJSON, blocking until response received.
        If interactive_approval is False (default), auto-approves all tools.
        If True, emits approval request and waits for response.
        Emits:
            {"type": "tool_approval_request", "tool_id": "...", "tool_name": "bash", "args": {...}}
        Expects input:
            {"type": "tool_approval_response", "tool_id": "...", "approved": true}
        """
        if not getattr(self, "interactive_approval", False):
            return True
        tool_id = tool_call.id
        tool_name = tool_call.name
        args = dict(tool_call.args)
        # Emit approval request
        self._emit({
            "type": "tool_approval_request",
            "tool_id": tool_id,
            "tool_name": tool_name,
            "args": args,
        })
        # Wait for approval response
        while True:
            line = await self._read_input_line()
            if line is None:
                # EOF - treat as rejection
                self._emit({
                    "type": "error",
                    "error": "Tool approval requested but stdin EOF reached",
                })
                return False
            try:
                data = json.loads(line)
            except json.JSONDecodeError as e:
                self._emit({
                    "type": "error",
                    "error": f"Invalid JSON in tool approval response: {e}",
                    "line": line,
                })
                continue
            if data.get("type") != "tool_approval_response":
                self._emit({
                    "type": "error",
                    "error": f"Expected tool_approval_response, got {data.get('type')}",
                    "input": data,
                })
                continue
            # Verify it's for the right tool (if tool_id provided)
            resp_tool_id = data.get("tool_id")
            if resp_tool_id is not None and resp_tool_id != tool_id:
                self._emit({
                    "type": "error",
                    "error": f"Tool approval for wrong tool_id: expected {tool_id}, got {resp_tool_id}",
                })
                continue
            approved = data.get("approved", False)
            self._emit({
                "type": "system",
                "subtype": "tool_approval_result",
                "tool_id": tool_id,
                "tool_name": tool_name,
                "approved": approved,
            })
            return approved

    def show_loader(self, text: str) -> None:
        """Emit loader event."""
        self._emit({"type": "system", "subtype": "loader", "text": text})

    def hide_loader(self) -> None:
        """Emit loader hide event."""
        self._emit({"type": "system", "subtype": "loader_hide"})

    def set_status(
        self,
        *,
        model: str | None = None,
        session_id: str | None = None,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        cost: float | None = None,
        env_info: dict[str, str] | None = None,
    ) -> None:
        """Track status for result emission."""
        if session_id is not None:
            self._session_id = session_id
            self.session_id = session_id

    def set_tools(self, tools: list[str]) -> None:
        """Set tool names for init event."""
        self._tools = tools


