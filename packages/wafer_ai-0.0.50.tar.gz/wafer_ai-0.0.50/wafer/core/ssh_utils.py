"""Shared SSH utilities. Single source of truth for SSH target parsing and rsync args."""
from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class SSHTarget:
    """Parsed SSH target: user@host:port."""

    user: str
    host: str
    port: int

    def __str__(self) -> str:
        return f"{self.user}@{self.host}:{self.port}"


def parse_ssh_target(target: str) -> SSHTarget:
    """Parse 'user@host:port' -> SSHTarget. Single source of truth.

    Raises:
        ValueError: If format is invalid (missing @, missing :, or invalid port)
    """
    if not target or "@" not in target:
        raise ValueError(
            f"Invalid ssh_target format: {target!r}. Expected: user@host:port"
        )
    parts = target.rsplit(":", 1)
    if len(parts) < 2:
        raise ValueError(
            f"Invalid ssh_target format: {target!r}. Expected: user@host:port"
        )
    user_host, port_str = parts
    user, _, host = user_host.partition("@")
    if not user or not host:
        raise ValueError(
            f"Invalid ssh_target format: {target!r}. Expected: user@host:port"
        )
    if not port_str:
        raise ValueError(
            f"Invalid ssh_target format: {target!r}. Expected: user@host:port"
        )
    try:
        port = int(port_str)
    except ValueError as e:
        raise ValueError(f"Invalid port in ssh_target: {port_str!r}") from e
    return SSHTarget(user=user, host=host, port=port)


def build_rsync_args(
    local_path: str,
    remote_path: str,
    user: str,
    host: str,
    port: int,
    ssh_key: str | None = None,
    exclude: list[str] | None = None,
    delete: bool = True,
    progress: bool = True,
) -> list[str]:
    """Build rsync command args for SSH transfer. Single source of truth.

    Args:
        local_path: Local source (directory should end with /)
        remote_path: Remote destination
        user: SSH user
        host: SSH host
        port: SSH port
        ssh_key: Path to SSH key (optional; if None, uses default SSH agent)
        exclude: Patterns to exclude (e.g. __pycache__, .git)
        delete: Add --delete flag (remove remote files not in source)
        progress: Add --progress flag

    Returns:
        List of args for subprocess.run(["rsync", ...])
    """
    ssh_opts_parts = [
        f"-p {port}",
        "-o StrictHostKeyChecking=no",
        "-o UserKnownHostsFile=/dev/null",
        "-o LogLevel=ERROR",
    ]
    if ssh_key:
        expanded_key = os.path.expanduser(ssh_key)
        ssh_opts_parts.insert(0, f"-i {expanded_key}")
    ssh_opts = " ".join(ssh_opts_parts)

    args = ["rsync", "-avz"]
    if progress:
        args.append("--progress")
    if delete:
        args.append("--delete")
    args.extend(["-e", f"ssh {ssh_opts}"])

    if exclude:
        for pattern in exclude:
            args.extend(["--exclude", pattern])

    args.append(local_path)
    args.append(f"{user}@{host}:{remote_path}")
    return args
