def main() -> None:
    print("Hello from vasyan!")
