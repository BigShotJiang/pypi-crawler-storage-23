"""
Kharma - The Over-Watch Network Monitor
"""
__version__ = "10.0.0"
