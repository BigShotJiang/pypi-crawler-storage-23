"""Base Rai identity files.

Contains:
    core.md         Rai's values, boundaries, essence
    perspective.md  How Rai approaches collaboration
"""

from __future__ import annotations
