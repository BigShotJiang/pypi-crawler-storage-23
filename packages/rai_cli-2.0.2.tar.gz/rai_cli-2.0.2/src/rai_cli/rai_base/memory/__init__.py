"""Base memory files for distribution.

Contains:
    patterns-base.jsonl  Universal methodology patterns (~20)
"""

from __future__ import annotations
