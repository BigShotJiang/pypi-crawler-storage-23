---
type: architecture_design
project: "{project_name}"
status: draft
layers: []
---

# System Design: {project_name}

> C4 Level 2 — Container/component decomposition
> Fill with /rai-project-create or /rai-project-onboard

## Architecture Overview

<!-- High-level architecture description -->

## Components

| Component | Responsibility | Technology |
|-----------|---------------|------------|

## Key Decisions

<!-- Reference ADRs when available: dev/decisions/adr-XXX.md -->
