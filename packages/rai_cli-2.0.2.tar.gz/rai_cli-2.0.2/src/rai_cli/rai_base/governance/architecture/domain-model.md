---
type: architecture_domain_model
project: "{project_name}"
status: draft
bounded_contexts: []
shared_kernel: {}
---

# Domain Model: {project_name}

> Bounded contexts and shared kernel
> Fill with /rai-project-create or /rai-project-onboard

## Bounded Contexts

<!-- Group modules into bounded contexts based on domain boundaries -->

## Shared Kernel

<!-- Modules shared across bounded contexts -->
