---
type: architecture_context
project: "{project_name}"
status: draft
tech_stack: {}
external_dependencies: []
users: []
governed_by: []
---

# System Context: {project_name}

> C4 Level 1 — System Context diagram and description
> Fill with /rai-project-create or /rai-project-onboard

## Overview

<!-- High-level description: what is this system and who uses it? -->

## Context Diagram

<!-- System context showing external actors and systems -->

```
┌──────────┐       ┌──────────────┐       ┌──────────┐
│  Users   │──────►│  {project_name}  │◄──────│ External │
│          │       │              │       │ Systems  │
└──────────┘       └──────────────┘       └──────────┘
```

## External Interfaces

| System | Direction | Protocol | Description |
|--------|-----------|----------|-------------|
