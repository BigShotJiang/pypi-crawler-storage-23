# Solution Vision: {project_name}

> Solution vision — fill with /rai-project-create or /rai-project-onboard

## Identity

### Description

<!-- One-paragraph description of what this project is and why it exists -->

## Outcomes

| **Outcome** | **Description** |
|-------------|-----------------|
| **Core Value** | <!-- Primary value delivered to users --> |
| **Quality** | <!-- Quality standards this project meets --> |
