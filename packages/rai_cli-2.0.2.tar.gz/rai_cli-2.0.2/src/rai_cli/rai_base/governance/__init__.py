"""Bundled governance templates for project scaffolding."""
