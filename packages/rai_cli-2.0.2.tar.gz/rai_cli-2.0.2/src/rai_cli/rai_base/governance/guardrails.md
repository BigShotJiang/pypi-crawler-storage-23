---
type: guardrails
version: "1.0.0"
---

# Guardrails: {project_name}

> Code and architecture guardrails — fill with /rai-project-create or /rai-project-onboard

---

## Guardrails Activos

### Code Quality

| ID | Level | Guardrail | Verification | Derived from |
|----|-------|-----------|--------------|--------------|
| must-code-001 | MUST | Type hints on all public APIs | pyright --strict | RF-01 |
