# PRD: {project_name}

> Product Requirements Document — fill with /rai-project-create or /rai-project-onboard

---

## Problem

<!-- Describe the problem this project solves -->

## Goals

<!-- What success looks like -->

---

## Requirements

### RF-01: Core Functionality

<!-- Describe the primary capability this project must provide -->

### RF-02: User Experience

<!-- Describe how users interact with the project -->
