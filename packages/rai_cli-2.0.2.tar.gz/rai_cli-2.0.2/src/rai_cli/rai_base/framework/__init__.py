"""Base framework files for distribution.

Contains:
    methodology.yaml  Skills, gates, and process rules
"""

from __future__ import annotations
