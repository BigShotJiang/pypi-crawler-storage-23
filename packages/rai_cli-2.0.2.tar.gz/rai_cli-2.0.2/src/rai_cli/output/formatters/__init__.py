"""Output formatters for domain-specific result types.

Each formatter module provides functions that take a result object
and output format, returning formatted output for the console.
"""

from __future__ import annotations

__all__: list[str] = []
