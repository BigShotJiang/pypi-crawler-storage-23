"""CLI presentation layer."""

from __future__ import annotations
