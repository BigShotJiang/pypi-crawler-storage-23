"""Publish module — quality gates, version management, and release workflow."""

from __future__ import annotations
