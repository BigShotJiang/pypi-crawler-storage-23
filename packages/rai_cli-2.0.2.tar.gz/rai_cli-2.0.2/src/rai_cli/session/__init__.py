"""Session protocol module.

Manages session state persistence and context bundle assembly
for deterministic session continuity.
"""
