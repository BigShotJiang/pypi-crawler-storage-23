import pytest
from dd_config.adapters.env_adapter import EnvAdapter


@pytest.fixture
def adapter():
    return EnvAdapter()


@pytest.fixture
def tmp_env(tmp_path):
    p = tmp_path / ".env"
    p.write_text('DB_HOST=localhost\nDB_PORT=5432\nAPP_NAME="My App"\n# comment\nEMPTY=\n')
    return p


def test_extensions(adapter):
    assert ".env" in adapter.extensions


def test_read_basic(adapter, tmp_env):
    data = adapter.read(tmp_env)
    assert data["DB_HOST"] == "localhost"
    assert data["DB_PORT"] == "5432"


def test_read_strips_quotes(adapter, tmp_env):
    data = adapter.read(tmp_env)
    assert data["APP_NAME"] == "My App"


def test_read_ignores_comments(adapter, tmp_env):
    data = adapter.read(tmp_env)
    assert not any(k.startswith("#") for k in data)


def test_write_roundtrip(adapter, tmp_path):
    p = tmp_path / "out.env"
    original = {"HOST": "localhost", "PORT": "5432"}
    adapter.write(p, original)
    result = adapter.read(p)
    assert result["HOST"] == "localhost"
    assert result["PORT"] == "5432"


def test_read_empty_value(adapter, tmp_env):
    data = adapter.read(tmp_env)
    assert data["EMPTY"] == ""
