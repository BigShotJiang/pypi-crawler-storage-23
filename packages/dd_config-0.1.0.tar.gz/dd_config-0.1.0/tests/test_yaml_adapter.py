import pytest
from dd_config.adapters.yaml_adapter import YAMLAdapter
from dd_config.models import ConfigError

yaml = pytest.importorskip("yaml", reason="pyyaml not installed")


@pytest.fixture
def adapter():
    return YAMLAdapter()


@pytest.fixture
def tmp_yaml(tmp_path):
    p = tmp_path / "config.yaml"
    p.write_text("key: value\nnum: 42\nnested:\n  host: localhost\n")
    return p


def test_extensions(adapter):
    assert ".yaml" in adapter.extensions
    assert ".yml" in adapter.extensions


def test_read(adapter, tmp_yaml):
    data = adapter.read(tmp_yaml)
    assert data["key"] == "value"
    assert data["num"] == 42
    assert data["nested"]["host"] == "localhost"


def test_write_roundtrip(adapter, tmp_path):
    p = tmp_path / "out.yaml"
    original = {"app": "test", "port": 8080, "db": {"host": "localhost"}}
    adapter.write(p, original)
    result = adapter.read(p)
    assert result == original


def test_empty_yaml_returns_dict(adapter, tmp_path):
    p = tmp_path / "empty.yaml"
    p.write_text("")
    result = adapter.read(p)
    assert result == {}


def test_read_invalid_yaml(adapter, tmp_path):
    bad = tmp_path / "bad.yaml"
    bad.write_text("key: [\nunclosed")
    with pytest.raises(ConfigError):
        adapter.read(bad)
