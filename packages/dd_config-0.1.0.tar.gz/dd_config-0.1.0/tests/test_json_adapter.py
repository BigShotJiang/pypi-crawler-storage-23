import json
import pytest
from dd_config.adapters.json_adapter import JSONAdapter
from dd_config.models import ConfigError


@pytest.fixture
def adapter():
    return JSONAdapter()


@pytest.fixture
def tmp_json(tmp_path):
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"key": "value", "num": 42}))
    return p


def test_extensions(adapter):
    assert ".json" in adapter.extensions


def test_read(adapter, tmp_json):
    data = adapter.read(tmp_json)
    assert data == {"key": "value", "num": 42}


def test_write_roundtrip(adapter, tmp_path):
    p = tmp_path / "out.json"
    original = {"name": "test", "nested": {"a": 1}}
    adapter.write(p, original)
    result = adapter.read(p)
    assert result == original


def test_read_invalid_json(adapter, tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text("not valid json {{{")
    with pytest.raises(ConfigError):
        adapter.read(bad)


def test_read_missing_file(adapter, tmp_path):
    with pytest.raises(ConfigError):
        adapter.read(tmp_path / "nonexistent.json")
