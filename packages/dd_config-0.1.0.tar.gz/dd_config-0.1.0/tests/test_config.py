"""Integration tests for the Config class."""
from __future__ import annotations

import json
import pytest

from dd_config import Config, ValidationError
from dd_config.utils import deep_merge, interpolate_env


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def json_file(tmp_path):
    p = tmp_path / "app.json"
    p.write_text(json.dumps({"app": "test", "port": 8080, "database": {"host": "localhost", "port": 5432}}))
    return p


@pytest.fixture
def yaml_file(tmp_path):
    pytest.importorskip("yaml")
    p = tmp_path / "app.yaml"
    p.write_text("app: test\nport: 8080\ndatabase:\n  host: localhost\n  port: 5432\n")
    return p


@pytest.fixture
def env_file(tmp_path):
    p = tmp_path / ".env"
    p.write_text("APP_ENV=production\nSECRET=s3cr3t\n")
    return p


@pytest.fixture
def override_file(tmp_path):
    p = tmp_path / "local.json"
    p.write_text(json.dumps({"port": 9090, "database": {"host": "remotehost"}}))
    return p


# ---------------------------------------------------------------------------
# Load / save
# ---------------------------------------------------------------------------

def test_load_json(json_file):
    cfg = Config.load(json_file)
    assert cfg["app"] == "test"
    assert cfg["port"] == 8080


def test_load_yaml(yaml_file):
    cfg = Config.load(yaml_file)
    assert cfg["app"] == "test"
    assert cfg["database"]["host"] == "localhost"


def test_load_env(env_file):
    cfg = Config.load(env_file)
    assert cfg["APP_ENV"] == "production"


def test_save_json(json_file, tmp_path):
    cfg = Config.load(json_file)
    out = tmp_path / "out.json"
    cfg.save(out)
    reloaded = Config.load(out)
    assert reloaded.to_dict() == cfg.to_dict()


# ---------------------------------------------------------------------------
# Format conversion
# ---------------------------------------------------------------------------

def test_convert_json_to_yaml(json_file, tmp_path):
    pytest.importorskip("yaml")
    out = tmp_path / "out.yaml"
    Config.convert(json_file, out)
    cfg = Config.load(out)
    assert cfg["app"] == "test"
    assert cfg["port"] == 8080


# ---------------------------------------------------------------------------
# Dict-like access
# ---------------------------------------------------------------------------

def test_getitem_plain(json_file):
    cfg = Config.load(json_file)
    assert cfg["app"] == "test"


def test_getitem_dot_path(json_file):
    cfg = Config.load(json_file)
    assert cfg["database.host"] == "localhost"


def test_setitem(json_file):
    cfg = Config.load(json_file)
    cfg["debug"] = True
    assert cfg["debug"] is True


def test_setitem_dot_path(json_file):
    cfg = Config.load(json_file)
    cfg["database.port"] = 9999
    assert cfg["database.port"] == 9999


def test_get_default(json_file):
    cfg = Config.load(json_file)
    assert cfg.get("missing", "fallback") == "fallback"


def test_contains(json_file):
    cfg = Config.load(json_file)
    assert "app" in cfg
    assert "missing" not in cfg


def test_len(json_file):
    cfg = Config.load(json_file)
    assert len(cfg) > 0


# ---------------------------------------------------------------------------
# Overrides / merge
# ---------------------------------------------------------------------------

def test_load_with_overrides(json_file, override_file):
    cfg = Config.load(json_file, overrides=[override_file])
    assert cfg["port"] == 9090
    assert cfg["database"]["host"] == "remotehost"
    # original nested key still present
    assert cfg["database"]["port"] == 5432


def test_merge(json_file):
    cfg1 = Config.load(json_file)
    other = Config.from_dict({"port": 1111, "extra": "yes"})
    merged = cfg1.merge(other)
    assert merged["port"] == 1111
    assert merged["extra"] == "yes"
    assert cfg1["port"] == 8080  # original unchanged


# ---------------------------------------------------------------------------
# Env interpolation
# ---------------------------------------------------------------------------

def test_env_interpolation(tmp_path, monkeypatch):
    monkeypatch.setenv("MY_HOST", "envhost")
    p = tmp_path / "cfg.json"
    p.write_text(json.dumps({"host": "${MY_HOST:-defaulthost}"}))
    cfg = Config.load(p)
    assert cfg["host"] == "envhost"


def test_env_interpolation_default(tmp_path):
    p = tmp_path / "cfg.json"
    p.write_text(json.dumps({"host": "${UNSET_VAR_XYZ:-fallback}"}))
    cfg = Config.load(p)
    assert cfg["host"] == "fallback"


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def test_validate_required_passes(json_file):
    cfg = Config.load(json_file)
    cfg.validate(required=["app", "database.host"])  # should not raise


def test_validate_required_fails(json_file):
    cfg = Config.load(json_file)
    with pytest.raises(ValidationError):
        cfg.validate(required=["nonexistent_key"])


def test_validate_schema_passes(json_file):
    cfg = Config.load(json_file)
    cfg.validate(schema={"app": str, "port": int})  # should not raise


def test_validate_schema_fails(json_file):
    cfg = Config.load(json_file)
    with pytest.raises(ValidationError):
        cfg.validate(schema={"port": str})  # port is int, not str


# ---------------------------------------------------------------------------
# Introspection
# ---------------------------------------------------------------------------

def test_info(json_file):
    cfg = Config.load(json_file)
    assert cfg.info.format == "json"
    assert len(cfg.info.sources) == 1


def test_to_dict(json_file):
    cfg = Config.load(json_file)
    d = cfg.to_dict()
    assert isinstance(d, dict)
    assert d["app"] == "test"


def test_repr(json_file):
    cfg = Config.load(json_file)
    r = repr(cfg)
    assert r.startswith("<Config json")
    assert "keys=" in r


def test_from_dict():
    cfg = Config.from_dict({"a": 1, "b": 2})
    assert cfg["a"] == 1
    assert len(cfg) == 2


# ---------------------------------------------------------------------------
# Utils
# ---------------------------------------------------------------------------

def test_deep_merge():
    base = {"a": 1, "nested": {"x": 10, "y": 20}}
    override = {"a": 99, "nested": {"x": 99}, "new": "val"}
    result = deep_merge(base, override)
    assert result == {"a": 99, "nested": {"x": 99, "y": 20}, "new": "val"}
    assert base == {"a": 1, "nested": {"x": 10, "y": 20}}  # unchanged


def test_interpolate_env(monkeypatch):
    monkeypatch.setenv("TEST_DB", "mydb")
    data = {"db": "${TEST_DB:-fallback}", "other": "static"}
    result = interpolate_env(data)
    assert result["db"] == "mydb"
    assert result["other"] == "static"
