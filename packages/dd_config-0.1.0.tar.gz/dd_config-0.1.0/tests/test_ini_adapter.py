import pytest
from dd_config.adapters.ini_adapter import INIAdapter


@pytest.fixture
def adapter():
    return INIAdapter()


@pytest.fixture
def tmp_ini(tmp_path):
    p = tmp_path / "config.ini"
    p.write_text("[database]\nhost = localhost\nport = 5432\n\n[app]\ndebug = true\n")
    return p


def test_extensions(adapter):
    assert ".ini" in adapter.extensions
    assert ".cfg" in adapter.extensions


def test_read_sections(adapter, tmp_ini):
    data = adapter.read(tmp_ini)
    assert "database" in data
    assert data["database"]["host"] == "localhost"
    assert data["database"]["port"] == "5432"


def test_write_roundtrip(adapter, tmp_path):
    p = tmp_path / "out.ini"
    original = {"section1": {"key": "value", "num": "10"}}
    adapter.write(p, original)
    result = adapter.read(p)
    assert result["section1"]["key"] == "value"
    assert result["section1"]["num"] == "10"


def test_read_missing_file(adapter, tmp_path):
    # configparser silently ignores missing files — it returns empty dict
    result = adapter.read(tmp_path / "nonexistent.ini")
    assert result == {}
