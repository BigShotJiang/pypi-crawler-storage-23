import pytest
from dd_config.adapters.toml_adapter import TOMLAdapter
from dd_config.models import ConfigError

tomli_w = pytest.importorskip("tomli_w", reason="tomli-w not installed")


@pytest.fixture
def adapter():
    return TOMLAdapter()


@pytest.fixture
def tmp_toml(tmp_path):
    p = tmp_path / "config.toml"
    p.write_bytes(b'key = "value"\nnum = 42\n\n[database]\nhost = "localhost"\n')
    return p


def test_extensions(adapter):
    assert ".toml" in adapter.extensions


def test_read(adapter, tmp_toml):
    data = adapter.read(tmp_toml)
    assert data["key"] == "value"
    assert data["num"] == 42
    assert data["database"]["host"] == "localhost"


def test_write_roundtrip(adapter, tmp_path):
    p = tmp_path / "out.toml"
    original = {"app": "test", "port": 8080, "db": {"host": "localhost"}}
    adapter.write(p, original)
    result = adapter.read(p)
    assert result == original


def test_read_invalid_toml(adapter, tmp_path):
    bad = tmp_path / "bad.toml"
    bad.write_bytes(b"key = [unclosed")
    with pytest.raises(ConfigError):
        adapter.read(bad)
