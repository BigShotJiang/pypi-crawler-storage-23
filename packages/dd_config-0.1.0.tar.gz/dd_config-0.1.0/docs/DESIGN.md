# dd-config Design Notes

## Motivation

The `dd-*` ecosystem (dd-db, dd-vectordb, dd-llm, dd-config, …) needs a single
configuration library that:

- Works for every common config format without forcing a dependency on all of them
- Keeps the in-memory representation as a plain Python `dict` (no magic objects)
- Treats the config file as the source of truth but lets env vars always win
- Is small enough to audit and understand in one sitting

---

## Architecture

```
Config.load("app.yaml", overrides=["local.yaml", ".env"])
       │
       ├── resolve_path()           utils.py
       ├── get_adapter(".yaml")     adapters/__init__.py  →  YAMLAdapter
       │       YAMLAdapter.read()   adapters/yaml_adapter.py
       ├── deep_merge(base, ov1)    utils.py
       ├── deep_merge(merged, ov2)  utils.py
       └── interpolate_env(data)    utils.py
               │
               └── returns Config(data, ConfigInfo)
```

### Pipeline

1. **Adapter** reads each file into a plain `dict`
2. **deep_merge** folds each override layer on top (override wins)
3. **interpolate_env** expands `${VAR:-default}` tokens in string values
4. **Config** wraps the final dict with metadata (`ConfigInfo`)

---

## Format adapters

Each adapter implements `BaseFormatAdapter` (ABC in `base.py`):

| Method | Description |
|--------|-------------|
| `read(path) → dict` | Parse file, return dict |
| `write(path, data)` | Serialise dict to file |
| `extensions → list[str]` | File extensions (e.g. `['.yaml', '.yml']`) |

The registry in `adapters/__init__.py` maps extensions → adapter instances.
Adding a new format requires: subclass `BaseFormatAdapter`, register in
`REGISTRY` and `FORMAT_NAMES`.

---

## Dependency strategy

| Feature | Dependency | Extra |
|---------|-----------|-------|
| JSON | stdlib `json` | (none) |
| YAML | `pyyaml` | `[yaml]` |
| TOML ≥3.11 | stdlib `tomllib` | (none) |
| TOML <3.11 | `tomli` | `[toml]` |
| TOML write | `tomli-w` | `[dev]` |
| INI | stdlib `configparser` | (none) |
| ENV | stdlib only | (none) |

Optional dependencies are imported lazily inside adapter methods so that
importing `dd_config` never raises `ImportError` for uninstalled extras.

---

## Key decisions

### Plain dict throughout
No custom namespace objects, no attribute access (`cfg.port`). Dot-path
access (`cfg["database.port"]`) is handled by `get_nested` / `set_nested`
in `utils.py`. This makes the in-memory state trivially serialisable and
avoids hidden state.

### Env vars always win (layered loading)
`Config.load(base, overrides=[local, env_file])` merges layers left-to-right.
The caller controls the order; a `.env` file passed last wins over everything.
OS-level env-var interpolation (`${VAR:-default}`) runs after all merges.

### No schema DSL
Validation intentionally uses plain Python types (`schema={"port": int}`).
If you need richer validation (e.g. ranges, regex), load the dict into a
Pydantic model directly — dd-config does not duplicate that work.

### Immutable source record
`ConfigInfo.sources` records every file in the load chain for observability
and debugging. `Config.merge()` concatenates source lists.
