from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any


_ENV_RE = re.compile(r"\$\{([^}:]+)(?::-([^}]*))?\}")


def resolve_path(path: str | Path) -> Path:
    """Return an absolute, OS-agnostic Path."""
    return Path(path).expanduser().resolve()


def file_extension(path: Path) -> str:
    """Return the file extension, handling dotfiles like ``.env``.

    ``Path(".env").suffix`` returns ``""`` in Python; this function returns
    ``".env"`` instead, treating the whole filename as the extension.
    """
    suffix = path.suffix
    if suffix:
        return suffix.lower()
    # Dotfile with no explicit extension — e.g. ".env", ".cfg"
    name = path.name
    if name.startswith("."):
        return name.lower()
    return ""


def _interpolate_value(value: Any) -> Any:
    """Replace ``${VAR:-default}`` tokens in a single string value."""
    if not isinstance(value, str):
        return value

    def replace(match: re.Match) -> str:
        var_name = match.group(1)
        default = match.group(2) if match.group(2) is not None else ""
        return os.environ.get(var_name, default)

    return _ENV_RE.sub(replace, value)


def interpolate_env(data: dict) -> dict:
    """Walk *data* recursively and expand ``${VAR:-default}`` in all string values."""
    result: dict = {}
    for key, value in data.items():
        if isinstance(value, dict):
            result[key] = interpolate_env(value)
        elif isinstance(value, list):
            result[key] = [
                interpolate_env(item) if isinstance(item, dict) else _interpolate_value(item)
                for item in value
            ]
        else:
            result[key] = _interpolate_value(value)
    return result


def deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into *base* (override wins on conflicts)."""
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def get_nested(data: dict, dot_path: str, default: Any = None) -> Any:
    """Access a nested value using dot-notation, e.g. ``'database.host'``."""
    keys = dot_path.split(".")
    node: Any = data
    for k in keys:
        if not isinstance(node, dict) or k not in node:
            return default
        node = node[k]
    return node


def set_nested(data: dict, dot_path: str, value: Any) -> None:
    """Set a nested value using dot-notation, creating intermediate dicts as needed."""
    keys = dot_path.split(".")
    node = data
    for k in keys[:-1]:
        if k not in node or not isinstance(node[k], dict):
            node[k] = {}
        node = node[k]
    node[keys[-1]] = value
