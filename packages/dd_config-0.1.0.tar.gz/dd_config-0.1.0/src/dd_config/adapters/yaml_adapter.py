from __future__ import annotations

from pathlib import Path

from dd_config.base import BaseFormatAdapter
from dd_config.models import ConfigError


class YAMLAdapter(BaseFormatAdapter):
    @property
    def extensions(self) -> list[str]:
        return [".yaml", ".yml"]

    def _yaml(self):
        try:
            import yaml
            return yaml
        except ImportError as exc:
            raise ConfigError(
                "pyyaml is required for YAML support. "
                "Install it with: pip install dd-config[yaml]"
            ) from exc

    def read(self, path: Path) -> dict:
        yaml = self._yaml()
        try:
            with path.open("r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh)
                return data if isinstance(data, dict) else {}
        except yaml.YAMLError as exc:
            raise ConfigError(f"YAML parse error in {path}: {exc}") from exc
        except OSError as exc:
            raise ConfigError(f"Cannot read {path}: {exc}") from exc

    def write(self, path: Path, data: dict) -> None:
        yaml = self._yaml()
        try:
            with path.open("w", encoding="utf-8") as fh:
                yaml.dump(data, fh, default_flow_style=False, allow_unicode=True)
        except OSError as exc:
            raise ConfigError(f"Cannot write {path}: {exc}") from exc
