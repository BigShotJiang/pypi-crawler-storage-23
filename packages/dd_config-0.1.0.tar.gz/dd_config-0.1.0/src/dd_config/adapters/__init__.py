"""Format registry: maps file extensions to adapter instances."""
from __future__ import annotations

from dd_config.adapters.env_adapter import EnvAdapter
from dd_config.adapters.ini_adapter import INIAdapter
from dd_config.adapters.json_adapter import JSONAdapter
from dd_config.adapters.toml_adapter import TOMLAdapter
from dd_config.adapters.yaml_adapter import YAMLAdapter
from dd_config.base import BaseFormatAdapter

_json = JSONAdapter()
_yaml = YAMLAdapter()
_toml = TOMLAdapter()
_ini = INIAdapter()
_env = EnvAdapter()

REGISTRY: dict[str, BaseFormatAdapter] = {
    ".json": _json,
    ".yaml": _yaml,
    ".yml":  _yaml,
    ".toml": _toml,
    ".ini":  _ini,
    ".cfg":  _ini,
    ".env":  _env,
}

# Human-readable format name from extension
FORMAT_NAMES: dict[str, str] = {
    ".json": "json",
    ".yaml": "yaml",
    ".yml":  "yaml",
    ".toml": "toml",
    ".ini":  "ini",
    ".cfg":  "ini",
    ".env":  "env",
}


def get_adapter(extension: str) -> BaseFormatAdapter:
    """Return the adapter for *extension* (e.g. ``'.yaml'``).

    Raises ``KeyError`` if the extension is unsupported.
    """
    ext = extension.lower()
    if ext not in REGISTRY:
        supported = ", ".join(sorted(REGISTRY))
        raise KeyError(f"Unsupported file extension '{ext}'. Supported: {supported}")
    return REGISTRY[ext]
