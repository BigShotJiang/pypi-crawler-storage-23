from __future__ import annotations

import sys
from pathlib import Path

from dd_config.base import BaseFormatAdapter
from dd_config.models import ConfigError


class TOMLAdapter(BaseFormatAdapter):
    @property
    def extensions(self) -> list[str]:
        return [".toml"]

    def _tomllib(self):
        if sys.version_info >= (3, 11):
            import tomllib
            return tomllib
        try:
            import tomli as tomllib
            return tomllib
        except ImportError as exc:
            raise ConfigError(
                "tomli is required for TOML support on Python <3.11. "
                "Install it with: pip install dd-config[toml]"
            ) from exc

    def _tomli_w(self):
        try:
            import tomli_w
            return tomli_w
        except ImportError as exc:
            raise ConfigError(
                "tomli-w is required for writing TOML files. "
                "Install it with: pip install tomli-w"
            ) from exc

    def read(self, path: Path) -> dict:
        tomllib = self._tomllib()
        try:
            with path.open("rb") as fh:
                return tomllib.load(fh)
        except Exception as exc:
            raise ConfigError(f"TOML parse error in {path}: {exc}") from exc

    def write(self, path: Path, data: dict) -> None:
        tomli_w = self._tomli_w()
        try:
            with path.open("wb") as fh:
                fh.write(tomli_w.dumps(data).encode())
        except OSError as exc:
            raise ConfigError(f"Cannot write {path}: {exc}") from exc
