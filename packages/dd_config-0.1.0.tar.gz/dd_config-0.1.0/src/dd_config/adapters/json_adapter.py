from __future__ import annotations

import json
from pathlib import Path

from dd_config.base import BaseFormatAdapter
from dd_config.models import ConfigError


class JSONAdapter(BaseFormatAdapter):
    @property
    def extensions(self) -> list[str]:
        return [".json"]

    def read(self, path: Path) -> dict:
        try:
            with path.open("r", encoding="utf-8") as fh:
                return json.load(fh)
        except json.JSONDecodeError as exc:
            raise ConfigError(f"JSON parse error in {path}: {exc}") from exc
        except OSError as exc:
            raise ConfigError(f"Cannot read {path}: {exc}") from exc

    def write(self, path: Path, data: dict) -> None:
        try:
            with path.open("w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, default=str)
                fh.write("\n")
        except OSError as exc:
            raise ConfigError(f"Cannot write {path}: {exc}") from exc
