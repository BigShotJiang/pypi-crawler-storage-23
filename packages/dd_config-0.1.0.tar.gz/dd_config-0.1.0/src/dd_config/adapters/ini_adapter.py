from __future__ import annotations

import configparser
from pathlib import Path

from dd_config.base import BaseFormatAdapter
from dd_config.models import ConfigError


class INIAdapter(BaseFormatAdapter):
    @property
    def extensions(self) -> list[str]:
        return [".ini", ".cfg"]

    def read(self, path: Path) -> dict:
        parser = configparser.ConfigParser()
        try:
            parser.read(path, encoding="utf-8")
        except configparser.Error as exc:
            raise ConfigError(f"INI parse error in {path}: {exc}") from exc
        except OSError as exc:
            raise ConfigError(f"Cannot read {path}: {exc}") from exc

        result: dict = {}
        # DEFAULT section items become top-level keys
        for key, value in parser.defaults().items():
            result[key] = value
        for section in parser.sections():
            result[section] = dict(parser.items(section))
            # Remove keys inherited from DEFAULT inside sections
            for default_key in parser.defaults():
                result[section].pop(default_key, None)
        return result

    def write(self, path: Path, data: dict) -> None:
        parser = configparser.ConfigParser()
        for key, value in data.items():
            if isinstance(value, dict):
                parser[key] = {k: str(v) for k, v in value.items()}
            else:
                # Flat keys go to DEFAULT
                parser["DEFAULT"][key] = str(value)
        try:
            with path.open("w", encoding="utf-8") as fh:
                parser.write(fh)
        except OSError as exc:
            raise ConfigError(f"Cannot write {path}: {exc}") from exc
