from __future__ import annotations

from pathlib import Path

from dd_config.base import BaseFormatAdapter
from dd_config.models import ConfigError


class EnvAdapter(BaseFormatAdapter):
    """Reads/writes ``.env`` files (KEY=VALUE, ``#`` comments, quoted values)."""

    @property
    def extensions(self) -> list[str]:
        return [".env"]

    def read(self, path: Path) -> dict:
        result: dict = {}
        try:
            text = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ConfigError(f"Cannot read {path}: {exc}") from exc

        for raw_line in text.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, _, raw_value = line.partition("=")
            key = key.strip()
            raw_value = raw_value.strip()
            # Strip surrounding quotes (single or double)
            if len(raw_value) >= 2 and raw_value[0] == raw_value[-1] and raw_value[0] in ('"', "'"):
                raw_value = raw_value[1:-1]
            result[key] = raw_value
        return result

    def write(self, path: Path, data: dict) -> None:
        lines: list[str] = []
        for key, value in data.items():
            str_value = str(value)
            # Quote values that contain spaces or special chars
            if " " in str_value or "\n" in str_value or "=" in str_value:
                str_value = f'"{str_value}"'
            lines.append(f"{key}={str_value}")
        try:
            path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        except OSError as exc:
            raise ConfigError(f"Cannot write {path}: {exc}") from exc
