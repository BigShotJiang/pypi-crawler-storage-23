"""dd-config — Unified configuration management for the dd-* ecosystem."""
from dd_config.config import Config
from dd_config.models import ConfigError, ConfigInfo, ValidationError

__all__ = [
    "Config",
    "ConfigInfo",
    "ConfigError",
    "ValidationError",
]

__version__ = "0.1.0"
