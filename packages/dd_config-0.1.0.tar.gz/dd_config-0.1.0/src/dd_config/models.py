from __future__ import annotations

from pathlib import Path
from typing import Optional

from pydantic import BaseModel


class ConfigInfo(BaseModel):
    """Metadata about a loaded configuration."""

    path: Optional[Path] = None
    format: str = "unknown"          # "json" | "yaml" | "toml" | "ini" | "env"
    sources: list[str] = []          # all files in the load chain


class ConfigError(Exception):
    """Raised on read/write/parse failures."""


class ValidationError(ConfigError):
    """Raised when required keys are missing or types do not match."""
