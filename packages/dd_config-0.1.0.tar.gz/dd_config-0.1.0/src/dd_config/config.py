from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from dd_config.adapters import FORMAT_NAMES, get_adapter
from dd_config.models import ConfigInfo, ValidationError
from dd_config.utils import deep_merge, file_extension, get_nested, interpolate_env, resolve_path


class Config:
    """Unified configuration object for the dd-* ecosystem.

    In-memory representation is always a plain Python ``dict``.
    Format is auto-detected from the file extension.

    Typical usage::

        cfg = Config.load("app.yaml")
        cfg = Config.load("app.yaml", overrides=["local.yaml", ".env"])

        host = cfg["database.host"]
        port = cfg.get("database.port", 5432)
        cfg["debug"] = True

        cfg.save("app.json")                       # convert YAML → JSON
        Config.convert("app.yaml", "app.json")     # one-liner class method

        cfg.validate(required=["database.host"])
        cfg.validate(schema={"database.host": str, "database.port": int})
    """

    # ------------------------------------------------------------------
    # Construction helpers
    # ------------------------------------------------------------------

    def __init__(self, data: dict, info: Optional[ConfigInfo] = None) -> None:
        self._data: dict = data
        self._info: ConfigInfo = info or ConfigInfo()

    # ------------------------------------------------------------------
    # Class-level factory methods
    # ------------------------------------------------------------------

    @classmethod
    def load(
        cls,
        path: str | Path,
        *,
        overrides: Optional[list[str | Path]] = None,
        interpolate: bool = True,
    ) -> "Config":
        """Load configuration from *path*, optionally layering *overrides* on top.

        Each entry in *overrides* is merged on top of the previous layer;
        environment variables (loaded from ``.env`` files or the OS) win last.

        Parameters
        ----------
        path:
            Primary configuration file.
        overrides:
            Additional files merged on top of *path* in order.
        interpolate:
            If ``True`` (default) expand ``${VAR:-default}`` tokens after
            loading each layer.
        """
        primary = resolve_path(path)
        ext = file_extension(primary)
        adapter = get_adapter(ext)
        fmt = FORMAT_NAMES.get(ext, "unknown")

        sources: list[str] = [str(primary)]
        data = adapter.read(primary)

        for override_path in (overrides or []):
            ov = resolve_path(override_path)
            ov_ext = file_extension(ov)
            ov_adapter = get_adapter(ov_ext)
            ov_data = ov_adapter.read(ov)
            data = deep_merge(data, ov_data)
            sources.append(str(ov))

        if interpolate:
            data = interpolate_env(data)

        info = ConfigInfo(path=primary, format=fmt, sources=sources)
        return cls(data, info)

    @classmethod
    def from_dict(cls, data: dict, *, fmt: str = "unknown") -> "Config":
        """Wrap an existing plain *dict* in a ``Config`` object."""
        return cls(dict(data), ConfigInfo(format=fmt))

    @classmethod
    def convert(cls, src: str | Path, dst: str | Path, *, interpolate: bool = True) -> None:
        """Load *src* and immediately write it as *dst* (format from extension)."""
        cfg = cls.load(src, interpolate=interpolate)
        cfg.save(dst)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str | Path) -> None:
        """Serialise current data to *path* (format auto-detected from extension)."""
        target = resolve_path(path)
        ext = file_extension(target)
        adapter = get_adapter(ext)
        target.parent.mkdir(parents=True, exist_ok=True)
        adapter.write(target, self._data)

    # ------------------------------------------------------------------
    # Dict-like access with dot-path support
    # ------------------------------------------------------------------

    def __getitem__(self, key: str) -> Any:
        """Support both plain keys and dot-path keys like ``'database.host'``."""
        if "." in key:
            value = get_nested(self._data, key)
            if value is None and key not in self._data:
                raise KeyError(key)
            return value
        try:
            return self._data[key]
        except KeyError:
            raise KeyError(key) from None

    def __setitem__(self, key: str, value: Any) -> None:
        from dd_config.utils import set_nested
        if "." in key:
            set_nested(self._data, key, value)
        else:
            self._data[key] = value

    def __contains__(self, key: str) -> bool:
        if "." in key:
            return get_nested(self._data, key) is not None
        return key in self._data

    def get(self, key: str, default: Any = None) -> Any:
        """Return value for *key* (dot-path supported) or *default*."""
        if "." in key:
            return get_nested(self._data, key, default)
        return self._data.get(key, default)

    def __len__(self) -> int:
        return len(self._data)

    def __iter__(self):
        return iter(self._data)

    def keys(self):
        return self._data.keys()

    def values(self):
        return self._data.values()

    def items(self):
        return self._data.items()

    # ------------------------------------------------------------------
    # Merge
    # ------------------------------------------------------------------

    def merge(self, other: "Config | dict") -> "Config":
        """Return a new Config with *other* merged on top (non-destructive)."""
        other_data = other._data if isinstance(other, Config) else other
        merged = deep_merge(self._data, other_data)
        new_sources = list(self._info.sources)
        if isinstance(other, Config):
            new_sources.extend(other._info.sources)
        new_info = ConfigInfo(
            path=self._info.path,
            format=self._info.format,
            sources=new_sources,
        )
        return Config(merged, new_info)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate(
        self,
        *,
        required: Optional[list[str]] = None,
        schema: Optional[dict[str, type]] = None,
    ) -> None:
        """Validate the configuration.

        Parameters
        ----------
        required:
            List of dot-path keys that must be present and non-``None``.
        schema:
            Mapping of dot-path key → expected Python type.  Raises
            ``ValidationError`` if a key is present but has the wrong type.
        """
        errors: list[str] = []

        for key in (required or []):
            value = get_nested(self._data, key) if "." in key else self._data.get(key)
            if value is None:
                errors.append(f"Required key '{key}' is missing")

        for key, expected_type in (schema or {}).items():
            value = get_nested(self._data, key) if "." in key else self._data.get(key)
            if value is not None and not isinstance(value, expected_type):
                errors.append(
                    f"Key '{key}' expected {expected_type.__name__}, "
                    f"got {type(value).__name__}"
                )

        if errors:
            raise ValidationError("\n".join(errors))

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Return a shallow copy of the underlying dict."""
        return dict(self._data)

    @property
    def info(self) -> ConfigInfo:
        """Return ``ConfigInfo`` metadata (path, format, sources)."""
        return self._info

    def __repr__(self) -> str:
        sources = self._info.sources
        src_str = ", ".join(f'"{s}"' for s in sources) if sources else '""'
        return (
            f"<Config {self._info.format} "
            f"sources=[{src_str}] "
            f"keys={len(self._data)}>"
        )
