from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path


class BaseFormatAdapter(ABC):
    """Abstract base for all format adapters."""

    @abstractmethod
    def read(self, path: Path) -> dict:
        """Read *path* and return its contents as a plain dict."""

    @abstractmethod
    def write(self, path: Path, data: dict) -> None:
        """Serialise *data* and write it to *path*."""

    @property
    @abstractmethod
    def extensions(self) -> list[str]:
        """File extensions handled by this adapter, e.g. ['.yaml', '.yml']."""
