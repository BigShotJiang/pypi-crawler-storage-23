"""dd-config basics cookbook.

Run with:
    python main.py
"""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

from dd_config import Config, ValidationError


def section(title: str) -> None:
    print(f"\n{'='*60}")
    print(f"  {title}")
    print('='*60)


def main() -> None:
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir)

        # ------------------------------------------------------------------ #
        # 1. Write sample config files
        # ------------------------------------------------------------------ #
        base_cfg = root / "app.json"
        base_cfg.write_text(json.dumps({
            "app": "my-service",
            "port": 8080,
            "debug": False,
            "database": {
                "host": "${DB_HOST:-localhost}",
                "port": 5432,
                "name": "mydb",
            },
        }, indent=2))

        local_cfg = root / "local.json"
        local_cfg.write_text(json.dumps({"debug": True, "port": 9090}))

        env_file = root / ".env"
        env_file.write_text("DB_HOST=db.example.com\nAPI_KEY=secret123\n")

        # ------------------------------------------------------------------ #
        # 2. Basic load
        # ------------------------------------------------------------------ #
        section("1. Basic load")
        cfg = Config.load(base_cfg)
        print(f"app    : {cfg['app']}")
        print(f"port   : {cfg['port']}")
        print(f"repr   : {cfg}")

        # ------------------------------------------------------------------ #
        # 3. Dot-path access
        # ------------------------------------------------------------------ #
        section("2. Dot-path access")
        print(f"database.host : {cfg['database.host']}")
        print(f"database.port : {cfg['database.port']}")
        print(f"get missing   : {cfg.get('missing_key', 'DEFAULT')}")

        # ------------------------------------------------------------------ #
        # 4. Layered loading with overrides
        # ------------------------------------------------------------------ #
        section("3. Layered loading (base + local + .env)")
        full_cfg = Config.load(base_cfg, overrides=[local_cfg, env_file])
        print(f"port (overridden)       : {full_cfg['port']}")
        print(f"debug (overridden)      : {full_cfg['debug']}")
        print(f"database.host (from env): {full_cfg['database.host']}")
        print(f"API_KEY (from .env)     : {full_cfg.get('API_KEY', 'NOT FOUND')}")
        print(f"sources: {full_cfg.info.sources}")

        # ------------------------------------------------------------------ #
        # 5. Mutation + save
        # ------------------------------------------------------------------ #
        section("4. Mutation + save")
        cfg["port"] = 7070
        cfg["database.name"] = "newdb"
        out = root / "updated.json"
        cfg.save(out)
        reloaded = Config.load(out)
        print(f"saved port        : {reloaded['port']}")
        print(f"saved db name     : {reloaded['database.name']}")

        # ------------------------------------------------------------------ #
        # 6. Format conversion
        # ------------------------------------------------------------------ #
        section("5. Format conversion (JSON → YAML)")
        try:
            import yaml  # noqa: F401
            yaml_out = root / "app.yaml"
            Config.convert(base_cfg, yaml_out)
            yaml_cfg = Config.load(yaml_out)
            print(f"YAML app  : {yaml_cfg['app']}")
            print(f"YAML port : {yaml_cfg['port']}")
        except ImportError:
            print("pyyaml not installed — skipping YAML conversion demo")

        # ------------------------------------------------------------------ #
        # 7. Validation
        # ------------------------------------------------------------------ #
        section("6. Validation")
        cfg2 = Config.load(base_cfg)
        try:
            cfg2.validate(
                required=["app", "database.host"],
                schema={"port": int, "app": str},
            )
            print("Validation passed ✓")
        except ValidationError as exc:
            print(f"Validation failed: {exc}")

        # Trigger a validation failure
        cfg3 = Config.from_dict({"app": "test"})
        try:
            cfg3.validate(required=["missing_required_key"])
        except ValidationError as exc:
            print(f"Expected ValidationError caught: {exc}")

        # ------------------------------------------------------------------ #
        # 8. Info / introspection
        # ------------------------------------------------------------------ #
        section("7. Introspection")
        info = cfg2.info
        print(f"format  : {info.format}")
        print(f"sources : {info.sources}")
        print(f"keys    : {list(cfg2.keys())}")
        d = cfg2.to_dict()
        print(f"to_dict type: {type(d).__name__}")

    print("\nAll done!")


if __name__ == "__main__":
    main()
