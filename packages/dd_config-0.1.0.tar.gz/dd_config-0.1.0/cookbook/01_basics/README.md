# 01 — dd-config Basics

Demonstrates core `dd-config` features:

- Load JSON / YAML config files
- Dot-path access (`cfg["database.host"]`)
- Override layering (base + local + `.env`)
- Format conversion (`Config.convert`)
- Validation (required keys + type checking)
- Env-var interpolation (`${VAR:-default}`)

## Run

```bash
pip install -r requirements.txt
python main.py
```
