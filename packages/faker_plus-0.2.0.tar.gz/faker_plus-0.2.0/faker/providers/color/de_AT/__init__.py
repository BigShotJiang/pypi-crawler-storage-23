from ..de import Provider as BaseProvider


class Provider(BaseProvider):
    pass
