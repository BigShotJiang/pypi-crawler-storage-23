from enum import StrEnum

class IconEnum(StrEnum):
    FA = "fa"
    EMOJI = "emoji"