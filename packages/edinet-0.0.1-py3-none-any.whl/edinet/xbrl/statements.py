"""XBRL 財務諸表構造ユーティリティ。

``build_line_items()`` が生成した :class:`~edinet.models.financial.LineItem` 群を
PL / BS / CF に分類し、選択ルール（期間・連結・dimension）を適用して
:class:`~edinet.models.financial.FinancialStatement` オブジェクトを組み立てる。
"""

from __future__ import annotations

import functools
import importlib.resources
import json
import logging
import warnings
from collections.abc import Sequence
from dataclasses import dataclass
from decimal import Decimal

from edinet.exceptions import EdinetWarning
from edinet.models.financial import (
    FinancialStatement,
    LineItem,
    StatementType,
)
from edinet.xbrl.contexts import DurationPeriod, InstantPeriod, Period

__all__ = ["build_statements", "Statements"]

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 定数
# ---------------------------------------------------------------------------

_CONSOLIDATED_AXIS_SUFFIX = "ConsolidatedOrNonConsolidatedAxis"
_CONSOLIDATED_MEMBER_SUFFIX = "ConsolidatedMember"
_NONCONSOLIDATED_MEMBER_SUFFIX = "NonConsolidatedMember"

# ---------------------------------------------------------------------------
# JSON データ読み込み
# ---------------------------------------------------------------------------


@functools.cache
def _load_concept_definitions(
    statement_type: StatementType,
) -> list[dict[str, object]]:
    """JSON データファイルから concept 定義を読み込む。

    Args:
        statement_type: 財務諸表の種類。

    Returns:
        concept 定義のリスト。各要素は
        ``{"concept": str, "order": int, "label_hint": str}``。
    """
    filename = {
        StatementType.INCOME_STATEMENT: "pl_jgaap.json",
        StatementType.BALANCE_SHEET: "bs_jgaap.json",
        StatementType.CASH_FLOW_STATEMENT: "cf_jgaap.json",
    }[statement_type]

    ref = importlib.resources.files("edinet.xbrl.data").joinpath(filename)
    with importlib.resources.as_file(ref) as path:
        return json.loads(path.read_text(encoding="utf-8"))  # type: ignore[no-any-return]


# ---------------------------------------------------------------------------
# 連結判定ヘルパー
# ---------------------------------------------------------------------------


def _is_consolidated(item: LineItem) -> bool:
    """連結 Fact か判定する。

    以下のいずれかの場合に True:
    - dimension なし（XBRL のデフォルト = 連結）
    - 連結軸の ConsolidatedMember が明示的に設定されている
      （他の軸を含まない場合のみ）

    XBRL では連結軸のデフォルト Member を明示的に設定する
    ケースがあり、その場合も連結として扱う。
    """
    if len(item.dimensions) == 0:
        return True
    return (
        all(
            dim.axis.endswith(_CONSOLIDATED_AXIS_SUFFIX)
            for dim in item.dimensions
        )
        and not _is_non_consolidated(item)
    )


def _is_non_consolidated(item: LineItem) -> bool:
    """NonConsolidatedMember を持つ = 個別。"""
    return any(
        dim.member.endswith(_NONCONSOLIDATED_MEMBER_SUFFIX)
        for dim in item.dimensions
    )


def _is_total(item: LineItem) -> bool:
    """連結軸以外の dimension がない全社合計。

    以下のいずれかの場合に True:
    - dimension なし（連結デフォルト）
    - 連結軸（ConsolidatedOrNonConsolidatedAxis）上の
      Member のみ（ConsolidatedMember / NonConsolidatedMember）

    セグメント軸等が含まれる場合は False（部分値であり全社合計ではない）。
    """
    if len(item.dimensions) == 0:
        return True
    return all(
        dim.axis.endswith(_CONSOLIDATED_AXIS_SUFFIX)
        for dim in item.dimensions
    )


# ---------------------------------------------------------------------------
# 期間フィルタ
# ---------------------------------------------------------------------------


def _select_latest_period(
    items: Sequence[LineItem],
    statement_type: StatementType,
) -> InstantPeriod | DurationPeriod | None:
    """最新期間を自動選択する。

    BS は InstantPeriod（instant が最新の日付）を選択する。
    PL / CF は DurationPeriod（end_date が最新の日付）を選択する。

    同一日付の instant と duration が混在する場合、statement_type に
    合致する期間タイプのみを候補とする。

    PL / CF で end_date が同値の場合は最長期間（start_date が最も古い）を
    選択する。ソートキーは ``(end_date DESC, start_date ASC)``。

    該当する periodType の Fact が 1 件も存在しない場合は ``None`` を返す。

    Args:
        items: 対象の LineItem シーケンス。
        statement_type: 財務諸表の種類。

    Returns:
        最新の期間。該当 periodType がなければ ``None``。
    """
    if statement_type == StatementType.BALANCE_SHEET:
        instant_periods = [
            item.period
            for item in items
            if isinstance(item.period, InstantPeriod)
        ]
        if not instant_periods:
            return None
        return max(instant_periods, key=lambda p: p.instant)
    else:
        # PL / CF: DurationPeriod を選択
        duration_periods = [
            item.period
            for item in items
            if isinstance(item.period, DurationPeriod)
        ]
        if not duration_periods:
            return None
        # end_date DESC, start_date ASC（最長期間優先）
        return max(
            duration_periods,
            key=lambda p: (p.end_date, -p.start_date.toordinal()),
        )


def _filter_by_period(
    items: Sequence[LineItem],
    period: InstantPeriod | DurationPeriod,
    statement_type: StatementType,
) -> list[LineItem]:
    """指定期間の Fact のみを返す。

    期間の一致判定は == 比較（完全一致）で行う。
    異なる periodType の Fact は型不一致で自然に除外される。

    Args:
        items: 対象の LineItem シーケンス。
        period: フィルタ対象の期間。
        statement_type: 財務諸表の種類（未使用、将来拡張用）。

    Returns:
        指定期間に一致する LineItem のリスト。
    """
    _ = statement_type  # v0.2.0 で periodType 検証等に使用予定
    return [item for item in items if item.period == period]


# ---------------------------------------------------------------------------
# 連結フィルタ
# ---------------------------------------------------------------------------


def _filter_consolidated_with_fallback(
    items: Sequence[LineItem],
    consolidated: bool,
) -> tuple[list[LineItem], bool]:
    """連結/個別フィルタ（フォールバック付き）。

    フォールバック判定は全社合計（``_is_total``）の Fact のみを対象とする。
    セグメント分解のみの個別 Fact（NonConsolidatedMember + SegmentAxis）が
    存在しても、全社合計の個別 Fact がなければフォールバックが発生する。

    consolidated=True の場合:
      1. 連結 Fact（dimension なし or 明示的 ConsolidatedMember）を優先
      2. 連結 Fact が 0 件なら、個別全社合計にフォールバック

    consolidated=False の場合:
      1. 個別全社合計（NonConsolidatedMember のみ）を優先
      2. 個別全社合計が 0 件なら、連結にフォールバック

    Args:
        items: 対象の LineItem シーケンス。
        consolidated: True なら連結優先、False なら個別。

    Returns:
        (フィルタ済み LineItem リスト, 実際に適用された連結/個別)。
        フォールバックが発生した場合、2 番目の値は引数と異なる。
    """
    if consolidated:
        # 連結 Fact は _is_consolidated で既に全社合計が保証される
        result = [item for item in items if _is_consolidated(item)]
        if result:
            return result, True
        # フォールバック: 個別全社合計のみ（セグメント分解は除外）
        result = [
            item
            for item in items
            if _is_non_consolidated(item) and _is_total(item)
        ]
        if result:
            return result, False
        # どちらも空: 要求されたモードを保持（フォールバックは発生していない）
        return [], True
    else:
        # 個別全社合計のみ（セグメント分解は除外）
        result = [
            item
            for item in items
            if _is_non_consolidated(item) and _is_total(item)
        ]
        if result:
            return result, False
        # フォールバック: 連結
        result = [item for item in items if _is_consolidated(item)]
        if result:
            return result, True
        # どちらも空: 要求されたモードを保持
        return [], False


# ---------------------------------------------------------------------------
# 中核: 単一 Statement 組み立て
# ---------------------------------------------------------------------------


def _build_single_statement(
    items: tuple[LineItem, ...],
    statement_type: StatementType,
    concept_defs: list[dict[str, object]],
    *,
    consolidated: bool = True,
    period: Period | None = None,
) -> FinancialStatement:
    """単一の財務諸表を組み立てる（内部関数）。

    §6 の選択ルールを順に適用する。

    Args:
        items: 全 LineItem（全期間・全 dimension）。
        statement_type: 財務諸表の種類。
        concept_defs: JSON から読み込んだ concept 定義。
        consolidated: True なら連結優先、False なら個別。
        period: 対象期間。None なら最新期間を自動選択。

    Returns:
        組み立て済みの FinancialStatement。
    """
    issued_warnings: list[str] = []

    # 1. concept 集合のセットを構築
    known_concepts = {str(d["concept"]) for d in concept_defs}

    # 2. 数値 Fact のみ（テキスト、nil 除外）
    numeric_items = [
        item
        for item in items
        if isinstance(item.value, Decimal) and not item.is_nil
    ]

    # 3. 科目分類 — JSON の concept 集合に含まれる LineItem のみを抽出
    candidates = [
        item for item in numeric_items if item.local_name in known_concepts
    ]
    if not candidates:
        return FinancialStatement(
            statement_type=statement_type,
            period=period,
            items=(),
            consolidated=consolidated,
            entity_id="",
            warnings_issued=(),
        )

    if period is None:
        period = _select_latest_period(candidates, statement_type)
    if period is None:
        # 該当する periodType の Fact がない（例: BS なのに InstantPeriod がない）
        msg = (
            f"{statement_type.value}: "
            f"該当する periodType の Fact がありません"
        )
        issued_warnings.append(msg)
        warnings.warn(msg, EdinetWarning, stacklevel=3)
        return FinancialStatement(
            statement_type=statement_type,
            period=None,
            items=(),
            consolidated=consolidated,
            entity_id="",
            warnings_issued=tuple(issued_warnings),
        )
    period_filtered = _filter_by_period(candidates, period, statement_type)

    # 5. 連結フィルタ（フォールバック付き）
    consolidated_filtered, actual_consolidated = (
        _filter_consolidated_with_fallback(period_filtered, consolidated)
    )
    if actual_consolidated != consolidated:
        if consolidated:
            msg = f"{statement_type.value}: 連結データなし、個別にフォールバック"
        else:
            msg = f"{statement_type.value}: 個別データなし、連結にフォールバック"
        issued_warnings.append(msg)
        warnings.warn(msg, EdinetWarning, stacklevel=3)

    # 6. dimension フィルタ（全社合計のみ）
    total_items = [
        item for item in consolidated_filtered if _is_total(item)
    ]

    # 7. 重複解決
    concept_to_items: dict[str, list[LineItem]] = {}
    for item in total_items:
        concept_to_items.setdefault(item.local_name, []).append(item)

    selected: list[LineItem] = []
    for concept_name, concept_items in concept_to_items.items():
        if len(concept_items) > 1:
            logger.debug(
                "%s: %d候補中1件を採用（context_id=%r）",
                concept_name,
                len(concept_items),
                concept_items[0].context_id,
            )
        selected.append(concept_items[0])

    # 8. 並び順: JSON order に従う
    concept_order = {
        str(d["concept"]): int(d["order"])  # type: ignore[arg-type]
        for d in concept_defs
    }
    max_order = max(concept_order.values()) if concept_order else 0

    def sort_key(item: LineItem) -> tuple[int, int]:
        json_order = concept_order.get(item.local_name)
        if json_order is not None:
            return (json_order, 0)
        return (max_order + 1, item.order)

    selected.sort(key=sort_key)

    entity_id = selected[0].entity_id if selected else ""

    logger.info(
        "%s を組み立て: %d 科目（候補 %d 件から選択）",
        statement_type.value,
        len(selected),
        len(items),
    )

    return FinancialStatement(
        statement_type=statement_type,
        period=period,
        items=tuple(selected),
        consolidated=actual_consolidated,
        entity_id=entity_id,
        warnings_issued=tuple(issued_warnings),
    )


# ---------------------------------------------------------------------------
# 公開 API
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True, kw_only=True)
class Statements:
    """財務諸表コンテナ。

    ``build_statements()`` 経由で構築すること。直接コンストラクトは非推奨。

    ``build_statements()`` の返り値。PL / BS / CF への
    アクセスメソッドを提供する。内部には全 LineItem を保持し、
    メソッド呼び出し時に選択ルールを適用する。

    JSON データファイルの読み込みはメソッド呼び出し時に行う
    （遅延読み込み）。これにより Statements のフィールドは
    ``_items`` のみとなり、frozen dataclass として自然な設計になる。

    Attributes:
        _items: 全 LineItem（全期間・全 dimension）。
    """

    _items: tuple[LineItem, ...]

    def __str__(self) -> str:
        """PL / BS / CF を連結して表示する。"""
        parts = [
            str(s)
            for s in (
                self.income_statement(),
                self.balance_sheet(),
                self.cash_flow_statement(),
            )
            if s.items
        ]
        return "\n\n".join(parts) if parts else "(財務諸表なし)"

    def income_statement(
        self,
        *,
        consolidated: bool = True,
        period: DurationPeriod | None = None,
    ) -> FinancialStatement:
        """損益計算書を組み立てる。

        選択ルール（v0.1.0）:
          1. period: None なら最新期間を選択
          2. consolidated: True なら連結を優先、連結がなければ個別にフォールバック
          3. dimensions: dimension なし（全社合計）の Fact のみを採用
          4. 重複: 同一 concept で上記ルール適用後も複数 Fact が残る場合は
             warnings.warn() で警告
          5. 並び順: JSON データファイルの order に従う。JSON にない科目は末尾

        Args:
            consolidated: True なら連結、False なら個別。
            period: 対象期間。None なら最新期間を自動選択。

        Returns:
            組み立て済みの損益計算書。
        """
        concept_defs = _load_concept_definitions(
            StatementType.INCOME_STATEMENT
        )
        return _build_single_statement(
            self._items,
            StatementType.INCOME_STATEMENT,
            concept_defs,
            consolidated=consolidated,
            period=period,
        )

    def balance_sheet(
        self,
        *,
        consolidated: bool = True,
        period: InstantPeriod | None = None,
    ) -> FinancialStatement:
        """貸借対照表を組み立てる。

        BS は InstantPeriod（時点）を使用する。
        選択ルールは income_statement() と同一。

        Args:
            consolidated: True なら連結、False なら個別。
            period: 対象時点。None なら最新時点を自動選択。

        Returns:
            組み立て済みの貸借対照表。
        """
        concept_defs = _load_concept_definitions(
            StatementType.BALANCE_SHEET
        )
        return _build_single_statement(
            self._items,
            StatementType.BALANCE_SHEET,
            concept_defs,
            consolidated=consolidated,
            period=period,
        )

    def cash_flow_statement(
        self,
        *,
        consolidated: bool = True,
        period: DurationPeriod | None = None,
    ) -> FinancialStatement:
        """キャッシュフロー計算書を組み立てる。

        選択ルールは income_statement() と同一。

        Args:
            consolidated: True なら連結、False なら個別。
            period: 対象期間。None なら最新期間を自動選択。

        Returns:
            組み立て済みのキャッシュフロー計算書。
        """
        concept_defs = _load_concept_definitions(
            StatementType.CASH_FLOW_STATEMENT
        )
        return _build_single_statement(
            self._items,
            StatementType.CASH_FLOW_STATEMENT,
            concept_defs,
            consolidated=consolidated,
            period=period,
        )


def build_statements(
    items: Sequence[LineItem],
) -> Statements:
    """LineItem 群から Statements コンテナを構築する。

    全 LineItem をそのまま保持し、``income_statement()`` 等の
    メソッド呼び出し時に選択ルールを適用する。

    Args:
        items: ``build_line_items()`` が返した LineItem のシーケンス。

    Returns:
        Statements コンテナ。
    """
    return Statements(_items=tuple(items))
