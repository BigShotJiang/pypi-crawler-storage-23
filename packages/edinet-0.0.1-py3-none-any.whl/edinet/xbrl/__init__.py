"""XBRL 関連機能を提供するサブパッケージ。"""

from edinet.xbrl.contexts import ContextCollection, structure_contexts
from edinet.xbrl.dei import DEI, AccountingStandard, PeriodType, extract_dei
from edinet.xbrl.facts import build_line_items
from edinet.xbrl.parser import parse_xbrl_facts
from edinet.xbrl.statements import Statements, build_statements
from edinet.xbrl.taxonomy import TaxonomyResolver
from edinet.xbrl.units import DivideMeasure, Measure, SimpleMeasure, StructuredUnit, structure_units

__all__ = [
    "parse_xbrl_facts",
    "structure_contexts",
    "ContextCollection",
    "TaxonomyResolver",
    "build_line_items",
    "build_statements",
    "Statements",
    "DEI",
    "AccountingStandard",
    "PeriodType",
    "extract_dei",
    "SimpleMeasure",
    "DivideMeasure",
    "Measure",
    "StructuredUnit",
    "structure_units",
]
