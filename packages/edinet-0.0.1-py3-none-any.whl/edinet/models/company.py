"""提出者（企業）モデル。"""
from __future__ import annotations

from datetime import date as DateType, datetime, timedelta, timezone
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import BaseModel, ConfigDict, computed_field, field_validator

from edinet._validators import normalize_edinet_code

if TYPE_CHECKING:
    from edinet.models.doc_types import DocType
    from edinet.models.filing import Filing


def _today_jst() -> DateType:
    """EDINET 基準（JST）の日付を返す。

    Returns:
        JST の当日。

    Note:
        tzdb 未導入環境では UTC+9 固定でフォールバックする。
    """
    try:
        return datetime.now(ZoneInfo("Asia/Tokyo")).date()
    except ZoneInfoNotFoundError:
        return (datetime.now(timezone.utc) + timedelta(hours=9)).date()


class Company(BaseModel):
    """提出者（企業）を表すモデル。"""

    model_config = ConfigDict(frozen=True)

    edinet_code: str
    name_ja: str | None = None
    sec_code: str | None = None

    @field_validator("edinet_code")
    @classmethod
    def _validate_edinet_code(cls, value: str) -> str:
        """EDINET コードを正規化して検証する。"""
        normalized = normalize_edinet_code(value, allow_none=False)
        assert isinstance(normalized, str)
        return normalized

    @computed_field  # type: ignore[prop-decorator]
    @property
    def ticker(self) -> str | None:
        """証券コード 4 桁を返す。"""
        if self.sec_code and len(self.sec_code) >= 4:
            return self.sec_code[:4]
        return None

    @classmethod
    def from_filing(cls, filing: Filing) -> Company | None:
        """Filing から Company を構築する。

        Args:
            filing: 変換元の提出書類。

        Returns:
            `filing.edinet_code` がある場合は `Company`。無い場合は `None`。
        """
        if filing.edinet_code is None:
            return None
        return cls(
            edinet_code=filing.edinet_code,
            name_ja=filing.filer_name,
            sec_code=filing.sec_code,
        )

    def get_filings(
        self,
        date: str | DateType | None = None,
        *,
        start: str | DateType | None = None,
        end: str | DateType | None = None,
        doc_type: DocType | str | None = None,
    ) -> list[Filing]:
        """この企業の提出書類一覧を返す。

        Args:
            date: 単日指定。
            start: 範囲指定の開始日。
            end: 範囲指定の終了日。
            doc_type: 書類種別フィルタ。

        Returns:
            企業コードで絞り込まれた提出書類一覧。

        Note:
            `date` / `start` / `end` がすべて省略された場合は JST 当日を使う。
        """
        from edinet import documents

        resolved_date = date
        if resolved_date is None and start is None and end is None:
            resolved_date = _today_jst()

        return documents(
            resolved_date,
            start=start,
            end=end,
            doc_type=doc_type,
            edinet_code=self.edinet_code,
        )

    def latest(
        self,
        doc_type: DocType | str | None = None,
        *,
        start: str | DateType | None = None,
        end: str | DateType | None = None,
    ) -> Filing | None:
        """この企業の最新の Filing を返す。

        ``get_filings()`` で書類一覧を取得し、``submit_date_time`` の降順で
        最初の Filing を返す。該当なしの場合は ``None``。

        ``start`` / ``end`` を省略した場合、過去 90 日間を検索する。

        Args:
            doc_type: 書類種別フィルタ。日本語文字列（``"有価証券報告書"``）
                または ``DocType`` Enum、コード文字列（``"120"``）を指定可能。
            start: 検索範囲の開始日。省略時は今日から 90 日前。
                ``end`` のみ指定した場合は ``end - 90日`` が自動設定される。
            end: 検索範囲の終了日。省略時は今日。
                ``start`` のみ指定した場合は今日が自動設定される。

        Returns:
            最新の Filing。見つからない場合は ``None``。

        Note:
            内部で ``get_filings()`` を呼び出すため、検索期間分の API コール
            が発生する（EDINET API は 1 日ずつ取得、レート制限 1.0s/call）。
            期間の目安: 30 日 → 約 30 秒、90 日（デフォルト） → 約 1.5 分、
            365 日 → 約 6 分。
        """
        import logging

        logger = logging.getLogger(__name__)

        # start/end の自動補完
        if start is None and end is None:
            end = _today_jst()
            start = end - timedelta(days=89)
            logger.debug(
                "latest(): start/end 未指定のため過去 90 日間 (%s 〜 %s) を検索します",
                start, end,
            )
        elif start is not None and end is None:
            end = _today_jst()
            logger.debug("latest(): end 未指定のため today (%s) を使用します", end)
        elif start is None and end is not None:
            if isinstance(end, str):
                from datetime import date as _date
                end = _date.fromisoformat(end)
            start = end - timedelta(days=89)
            logger.debug("latest(): start 未指定のため end - 89日 (%s) を使用します", start)

        filings = self.get_filings(start=start, end=end, doc_type=doc_type)
        if not filings:
            return None
        return max(filings, key=lambda f: f.submit_date_time)

    def __str__(self) -> str:
        """簡潔な文字列表現を返す。"""
        name = self.name_ja or "(不明)"
        return f"Company({self.edinet_code} | {name} | {self.ticker})"
