"""表示・整形ユーティリティを提供するサブパッケージ。"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from edinet.display.rich import render_statement as render_statement

__all__ = ["render_statement"]


def __getattr__(name: str):  # noqa: ANN202
    """遅延 import。Rich がインストールされていなくても import edinet.display は成功する。"""
    if name == "render_statement":
        from edinet.display.rich import render_statement

        return render_statement
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    """IDE 補完のために公開名を列挙する。"""
    return __all__
