"""edinet パッケージの公開 API。"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from edinet._config import configure as configure
    from edinet._http import aclose as aclose
    from edinet.models.company import Company as Company
    from edinet.models.doc_types import DocType as DocType
    from edinet.models.filing import Filing as Filing
    from edinet.models.financial import FinancialStatement as FinancialStatement
    from edinet.models.financial import LineItem as LineItem
    from edinet.public_api import adocuments as adocuments
    from edinet.public_api import documents as documents
    from edinet.xbrl.statements import Statements as Statements

_LAZY_EXPORTS: dict[str, tuple[str, str]] = {
    "configure": ("edinet._config", "configure"),
    "documents": ("edinet.public_api", "documents"),
    "adocuments": ("edinet.public_api", "adocuments"),
    "aclose": ("edinet._http", "aclose"),
    "Company": ("edinet.models.company", "Company"),
    "Filing": ("edinet.models.filing", "Filing"),
    "DocType": ("edinet.models.doc_types", "DocType"),
    "Statements": ("edinet.xbrl.statements", "Statements"),
    "FinancialStatement": ("edinet.models.financial", "FinancialStatement"),
    "LineItem": ("edinet.models.financial", "LineItem"),
}


def __getattr__(name: str):
    """公開シンボルを遅延ロードする。

    Args:
        name: 取得対象の属性名。

    Returns:
        遅延ロードされた属性。

    Raises:
        AttributeError: 公開対象外の属性名が指定された場合。
    """
    module_and_attr = _LAZY_EXPORTS.get(name)
    if module_and_attr is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_name, attr_name = module_and_attr
    module = __import__(module_name, fromlist=[attr_name])
    value = getattr(module, attr_name)
    globals()[name] = value
    return value


__all__ = [
    "configure",
    "documents",
    "adocuments",
    "aclose",
    "Company",
    "Filing",
    "DocType",
    "Statements",
    "FinancialStatement",
    "LineItem",
]
