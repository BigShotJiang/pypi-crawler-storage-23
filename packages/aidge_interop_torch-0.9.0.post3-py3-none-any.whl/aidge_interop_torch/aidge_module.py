import torch

import aidge_core

from .tensor_converter import aidge_tensor_to_torch, torch_tensor_to_aidge


class AidgeModule(torch.nn.Module):
    """
    PyTorch layer used to interface an aidge_core.GraphView object in a PyTorch Network.
    """

    def __init__(self, graph_view, batch_size=None):
        super().__init__()
        if not isinstance(graph_view, aidge_core.GraphView):
            raise TypeError(
                f"graph_view should be aidge_core.GraphView, got {type(graph_view)} instead"
            )
        self._graph_view = graph_view
        graph_view.set_backend("cpu")

        self.register_parameter(
            name="random_parameter", param=torch.nn.Parameter(torch.ones(1))
        )

        self.batch_size = batch_size
        self.current_batch_size = None
        self.multi_outputs_flag = False
        self.input_nodes = [None]
        self.scheduler = None
        self.optimizer = None
        self.grad_compiled = False

    def set_optimizer(self, opt):
        self.optimizer = opt

    def forward(self, inputs: torch.Tensor):
        class graph_view_computation(torch.autograd.Function):
            @staticmethod
            def forward(ctx, inputs):
                aidge_tensor = torch_tensor_to_aidge(inputs)

                if self.input_nodes[0] is None:
                    self.input_nodes[0] = aidge_core.Producer(aidge_tensor, "Input_0")
                    self.input_nodes[0].get_operator().set_datatype(
                        aidge_core.dtype.float32
                    )
                    self.input_nodes[0].get_operator().set_backend("cpu")
                    self.input_nodes[0].add_child(self._graph_view)
                    self._graph_view.add(self.input_nodes[0])
                else:
                    self.input_nodes[0].get_operator().set_output(0, aidge_tensor)

                if not self.scheduler:
                    self.scheduler = aidge_core.SequentialScheduler(self._graph_view)

                self.scheduler.forward(forward_dims=True)

                if len(self._graph_view.get_output_nodes()) > 1:
                    raise RuntimeError(
                        "Torch interop only supports graphs with one output."
                    )

                aidge_output = (
                    list(self._graph_view.get_output_nodes())[0]
                    .get_operator()
                    .get_output(0)
                )
                torch_output = aidge_tensor_to_torch(aidge_output)
                return torch_output.clone()

            @staticmethod
            def backward(ctx, grad_output):
                if self.multi_outputs_flag:
                    raise RuntimeError(
                        "Backward not supported for multi-output graphs."
                    )
                if len(self.input_nodes) != 1:
                    raise RuntimeError("Multi-input backward not supported yet.")

                aidge_grad_output = torch_tensor_to_aidge(grad_output)
                output_node = list(self._graph_view.get_output_nodes())[0]
                output_tensor = output_node.get_operator().get_output(0)
                self.optimizer.reset_grad(self._graph_view)

                output_tensor.set_grad(aidge_grad_output)
                self.scheduler.backward()
                self.optimizer.update()

                aidge_out_grad = self.input_nodes[0].get_operator().get_output(0).grad()
                torch_out_grad = aidge_tensor_to_torch(aidge_out_grad)
                return torch_out_grad

        inputs.requires_grad = True
        outputs = graph_view_computation.apply(inputs)
        return outputs
