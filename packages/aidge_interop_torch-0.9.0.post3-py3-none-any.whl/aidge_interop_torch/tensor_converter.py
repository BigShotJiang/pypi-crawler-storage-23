import numpy as np
import torch

import aidge_core


def convert_tensor(tensor):
    """Convert a torch tensor to aidge_core.Tensor and vice versa."""
    if isinstance(tensor, torch.Tensor):
        return torch_tensor_to_aidge(tensor)
    elif isinstance(tensor, aidge_core.Tensor):
        return aidge_tensor_to_torch(tensor)
    else:
        raise RuntimeError(f"Object of type {type(tensor)} is not convertible.")


def aidge_tensor_to_torch(aidge_tensor: aidge_core.Tensor) -> torch.Tensor:
    """Convert aidge_core.Tensor -> torch.Tensor"""
    torch_tensor = torch.from_numpy(np.array(aidge_tensor))
    # TODO : handle CUDA case
    return torch_tensor


def torch_tensor_to_aidge(torch_tensor: torch.Tensor) -> aidge_core.Tensor:
    """Convert torch.Tensor -> aidge_core.Tensor"""
    numpy_tensor = torch_tensor.cpu().detach().numpy()
    aidge_tensor = aidge_core.Tensor(numpy_tensor)
    return aidge_tensor
