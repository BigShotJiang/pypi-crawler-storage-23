import warnings
from pathlib import Path
from typing import Union

import onnx
import torch
from onnxsim import simplify

import aidge_core
import aidge_onnx

from .aidge_module import AidgeModule


class ContextNoBatchNormFuse:
    """
    PyTorch fuse batchnorm if train = False.
    Temporarily overrides forward of batchnorms to protect stats.
    """

    def __init__(self, model):
        self.model = model
        self.forwards = []

    def __enter__(self):
        for module in self.model.modules():
            if isinstance(module, torch.nn.modules.batchnorm._BatchNorm):

                def fake_forward(inputs, current_bn=module):
                    if current_bn.momentum is None:
                        eaf = 1.0 / (current_bn.num_batches_tracked.item() + 1)
                    else:
                        eaf = current_bn.momentum

                    saved_run_mean = current_bn.running_mean.detach().clone()
                    saved_run_var = current_bn.running_var.detach().clone()
                    if current_bn.affine:
                        saved_bias = current_bn.bias.detach().clone()
                        saved_weight = current_bn.weight.detach().clone()

                    output_tensor = torch.nn.functional.batch_norm(
                        inputs,
                        current_bn.running_mean,
                        current_bn.running_var,
                        current_bn.weight,
                        current_bn.bias,
                        True,
                        eaf,
                        current_bn.eps,
                    )

                    current_bn.running_mean = saved_run_mean
                    current_bn.running_var = saved_run_var
                    if current_bn.affine:
                        current_bn.bias = torch.nn.Parameter(saved_bias)
                        current_bn.weight = torch.nn.Parameter(saved_weight)
                    return output_tensor

                self.forwards.append(module.forward)
                module.forward = fake_forward
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        for module, orig_forward in zip(self.model.modules(), self.forwards):
            if isinstance(module, torch.nn.modules.batchnorm._BatchNorm):
                module.forward = orig_forward


def wrap(
    torch_model: torch.nn.Module,
    input_size: Union[list, tuple],
    opset_version: int = 18,
    save_onnx_model: bool = False,
    in_names: list = None,
    out_names: list = None,
    verbose: bool = False,
) -> AidgeModule:
    """Convert a PyTorch model to AidgeModule via ONNX."""
    raw_model_path = Path(f"./{torch_model.__class__.__name__}_raw.onnx")
    model_path = f"./{torch_model.__class__.__name__}.onnx"
    print("Exporting torch module to ONNX ...")

    try:
        torch_device = next(torch_model.parameters()).device
    except StopIteration:
        torch_device = torch.device("cpu")

    dummy_in = torch.zeros(input_size).to(torch_device)

    torch_model.train()

    warnings.filterwarnings(
        "ignore", message=".*Constant folding - Only steps=1 can be constant folded.*"
    )
    warnings.filterwarnings(
        "ignore",
        message="ONNX export mode is set to TrainingMode.EVAL, but operator 'batch_norm' is set to train=True. Exporting with train=True.",
    )

    torch.onnx.export(
        torch_model,
        dummy_in,
        raw_model_path,
        verbose=verbose,
        input_names=in_names,
        output_names=out_names,
        export_params=True,
        opset_version=opset_version,
        do_constant_folding=False,
    )

    print("Simplifying the ONNX model ...")
    onnx_model = onnx.load(raw_model_path)
    raw_model_path.unlink()
    model_simp, check = simplify(onnx_model)
    assert check, "Simplified ONNX model could not be validated"
    if save_onnx_model:
        onnx.save(model_simp, model_path)

    aidge_model = aidge_onnx.onnx_import.convert_onnx_to_aidge(model_simp)
    aidge_core.remove_flatten(aidge_model)
    return AidgeModule(aidge_model)
