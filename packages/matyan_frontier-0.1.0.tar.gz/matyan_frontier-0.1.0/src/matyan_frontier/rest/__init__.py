from .artifacts import rest_router

__all__ = ["rest_router"]
