from setuptools import setup, find_packages

setup(
    name='buildbetterlab',
    packages=find_packages(include=["buildbetterlab", "buildbetterlab.*"]),
    version='0.1.1',
    description='Utility to convert datetime between different timezones',
    author='Siddharth More',
)
