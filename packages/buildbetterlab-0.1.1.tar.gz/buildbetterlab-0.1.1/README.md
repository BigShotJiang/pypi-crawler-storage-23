# BuildBetter Lab Utility

## Description
Utility for most daily repeating tasks

## Features
Currently under construction, we just are delivering two functionalities
which allows user to convert datetime from any timezone to UTC and another
allows to convert to IST

## License
Read license here: [License](LICENSE)
