from datetime import datetime, timezone, timedelta
from dateutil import tz


def convert_to_utc(string_date_time: str, current_tz: str) -> str:
    """
    Convert given string date time to UTC time

    Parameters
    ----------
    string_date_time: str :
        Date time to convert to UTC time.
        Should be in format YYYY-MM-DD HH:MM:SS

    current_tz: str :
        Time zone to convert to UTC time

    Returns
    -------
    Datetime converted to UTC timezone
    """
    if string_date_time == "":
        raise ValueError("Input can't be empty")

    if current_tz == "UTC":
        return string_date_time

    date_time = datetime.strptime(string_date_time, "%Y-%m-%d %H:%M:%S")
    current_tz = tz.gettz(current_tz)

    date_time = date_time.replace(tzinfo=current_tz)
    return date_time.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def convert_to_ist(string_date_time: str, current_tz: str) -> str:
    """
    Convert given string date time to IST time

    Parameters
    ----------
    string_date_time: str :
        Date time to convert to IST time.
        Should be in format YYYY-MM-DD HH:MM:SS

    current_tz: str :
        Time zone to convert to IST time

    Returns
    -------
    Datetime converted to IST timezone
    """
    if string_date_time == "":
        raise ValueError("Input can't be empty")

    if current_tz == "Asia/Calcutta":
        return string_date_time

    date_time = datetime.strptime(string_date_time, "%Y-%m-%d %H:%M:%S")
    current_tz = tz.gettz(current_tz)

    date_time = date_time.replace(tzinfo=current_tz)
    return date_time.astimezone(
        timezone(timedelta(hours=5, minutes=30))
    ).strftime("%Y-%m-%d %H:%M:%S")
