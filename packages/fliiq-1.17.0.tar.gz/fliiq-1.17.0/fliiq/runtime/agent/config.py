"""Agent configuration — mode and iteration limits."""

from typing import Literal

from pydantic import BaseModel

MODE_CYCLE = ["plan", "supervised", "autonomous"]


def next_mode(current: str) -> str:
    """Cycle to the next mode in the sequence."""
    try:
        idx = MODE_CYCLE.index(current)
        return MODE_CYCLE[(idx + 1) % len(MODE_CYCLE)]
    except ValueError:
        return MODE_CYCLE[0]


class AgentConfig(BaseModel):
    """Configuration for the agent loop."""

    mode: Literal["plan", "supervised", "autonomous"] = "autonomous"
    max_iterations: int = 200
