"""Simple time-sortable unique ID generation."""

import base64
import os
import time


def generate_id(prefix: str) -> str:
    """Generate a prefixed, time-sortable unique ID.

    Example: generate_id("t") → "t_aebqga3k..."
    """
    ts = int(time.time() * 1000).to_bytes(6, "big")
    rand = os.urandom(10)
    encoded = base64.b32encode(ts + rand).decode().lower().rstrip("=")
    return f"{prefix}_{encoded}"
