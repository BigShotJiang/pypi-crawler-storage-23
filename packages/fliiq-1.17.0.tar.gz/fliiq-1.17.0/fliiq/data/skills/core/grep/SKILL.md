---
name: grep
description: "Search file contents using regex patterns, with optional context lines."
---

Use this tool to search for text patterns across files. Supports regex, case-insensitive search, and context lines around matches. Respects .gitignore if present. Results capped at a configurable limit.
