---
name: summarize
description: "Fetch and extract content from URLs, local files, or raw text for summarization. Returns cleaned text ready for analysis."
---

Use this tool to fetch and extract content from a source for summarization. Supports:
- **URLs**: Fetches web page and converts HTML to clean text/markdown
- **Local files**: Reads text files, PDFs (via read_pdf skill), etc.
- **Raw text**: Pass text directly for processing

The tool returns the extracted content. You (the agent) should then summarize it based on the user's request.

## No Setup Required
Uses no external API keys. For URLs, fetches via HTTP. For local files, reads directly from disk.
