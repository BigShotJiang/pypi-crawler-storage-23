---
name: find_email
description: "Find email addresses using Hunter.io API. Look up a specific person's email or search all emails at a domain with optional role filtering."
---

Use this tool to find someone's email address or discover emails at a company domain. Two actions:

- **find_email**: Find a specific person's email by name + domain (e.g., find John Smith at stripe.com)
- **domain_search**: List all email addresses at a domain, optionally filtered by role (e.g., "executives", "engineering", "sales")

Requires HUNTER_API_KEY environment variable. Get a free API key at https://hunter.io/
