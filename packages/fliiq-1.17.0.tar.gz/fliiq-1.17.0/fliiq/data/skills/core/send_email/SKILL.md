---
name: send_email
description: "Send an email via Gmail SMTP. Uses OAuth (via `fliiq google auth`) or app password fallback."
---

Send an email to one or more recipients via Gmail SMTP. Supports plain text body and subject line.

Setup: Run `fliiq google auth` for OAuth access (recommended). Alternatively, set GMAIL_ADDRESS and GMAIL_APP_PASSWORD in .env as fallback.

The "to" field accepts a single email or comma-separated list for multiple recipients.
