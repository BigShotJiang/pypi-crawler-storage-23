---
name: slack
description: "Send messages, react with emoji, pin messages, list channels, and read message history in Slack workspaces."
---

Use this tool to interact with Slack. Supports sending messages, adding emoji reactions, pinning messages, listing channels, and reading recent messages.

## Setup
1. Go to https://api.slack.com/apps and click "Create New App" > "From scratch"
2. Name the app, select your workspace
3. Go to **OAuth & Permissions** and add these **Bot Token Scopes**:
   - `chat:write` (send messages)
   - `channels:read` (list public channels)
   - `channels:history` (read public channel messages)
   - `reactions:write` (add emoji reactions)
   - `pins:write` (pin/unpin messages)
   - `groups:read` (list private channels, optional)
   - `groups:history` (read private channels, optional)
4. Click **"Install to Workspace"** and authorize
5. Copy the **Bot User OAuth Token** (`xoxb-...`)

Add to your `.env` file:
```
SLACK_BOT_TOKEN=xoxb-...
```

## Important Notes
- The bot can only access channels it has been **invited to**
- Adding new scopes after install requires **reinstalling** the app
- Use channel name (e.g. "general") or channel ID (e.g. "C01234ABCDE")
