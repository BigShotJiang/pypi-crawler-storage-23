---
name: tasks
description: "Manage personal tasks and projects: create, update, list, complete, and delete tasks with priorities, due dates, tags, and project grouping."
---

A local task tracker stored in ~/.fliiq/tasks.yaml. No external service needed.

## Actions
- **create**: Create a new task with title, priority, due date, project, tags, notes
- **update**: Modify an existing task (status, priority, due date, tags, notes)
- **list**: Query tasks by status, project, tag, priority, or due date. Default shows active (todo + in_progress)
- **complete**: Mark a task as done (shortcut for update status=done)
- **delete**: Remove a task permanently
