---
name: word
description: "Create, read, and modify Word (.docx) documents. Add headings, paragraphs, and tables. Extract text and structure."
---

Use this tool to work with Word document files (.docx) on the local filesystem.

## Available Actions
- create: Create a new .docx document with optional initial content
- read: Extract all text, headings, and tables from the document
- add_content: Append a heading, paragraph, or table to the document
- replace_text: Find and replace text throughout the document
- delete: Delete a .docx file

## Content Types for add_content
Set the `content_type` parameter:
- "heading": Adds a heading (use `level` param, 1-4, default 1)
- "paragraph": Adds a paragraph of text
- "table": Adds a table (pass `data` as a 2D array, first row = headers)

## Notes
- read returns structured output: list of elements with type (heading/paragraph/table) and content
- replace_text searches all paragraphs and table cells
