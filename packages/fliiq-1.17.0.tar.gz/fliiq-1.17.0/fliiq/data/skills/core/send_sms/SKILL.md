---
name: send_sms
description: "Send an SMS via Twilio. Requires TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER environment variables."
---

Send a text message to a phone number via Twilio's REST API.

Use E.164 format for the recipient number (e.g. +14155551234). Message body limited to 1600 characters.

Setup: Create a Twilio account at https://console.twilio.com/, get your Account SID, Auth Token, and a phone number. Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER in your .env file.
