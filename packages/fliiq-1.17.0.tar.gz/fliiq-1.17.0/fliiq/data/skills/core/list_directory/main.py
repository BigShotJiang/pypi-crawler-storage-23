import os


async def handler(params: dict) -> dict:
    """List directory contents with type indicators."""
    path = params["path"]

    if not os.path.isdir(path):
        raise NotADirectoryError(f"Not a directory: {path}")

    entries = sorted(os.listdir(path))
    lines = []
    for entry in entries:
        full = os.path.join(path, entry)
        prefix = "[DIR]" if os.path.isdir(full) else "[FILE]"
        lines.append(f"{prefix} {entry}")

    return {"entries": "\n".join(lines)}
