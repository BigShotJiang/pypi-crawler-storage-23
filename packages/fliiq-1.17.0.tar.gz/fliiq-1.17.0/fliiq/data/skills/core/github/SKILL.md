---
name: github
description: "Manage GitHub repositories: list/create issues and PRs, view CI runs, get repo info. Uses the gh CLI."
---

Use this tool to interact with GitHub repositories. Supports listing and creating issues, listing and creating pull requests, viewing CI workflow runs, and getting repository info.

## Setup
Requires the GitHub CLI (`gh`) to be installed and authenticated:

1. Install: `brew install gh` (macOS) or see https://cli.github.com/
2. Authenticate: `gh auth login` (one-time, follow the prompts)

No API keys or environment variables needed — uses your `gh` session.

## Notes
- Repository format: `owner/repo` (e.g. "anthropics/claude-code")
- If no `repo` is specified, uses the current git repository
- The `gh` CLI must be on your PATH
