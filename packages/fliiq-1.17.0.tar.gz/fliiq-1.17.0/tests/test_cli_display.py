"""Tests for CLI display module."""

import io
from unittest.mock import patch

import pytest

from fliiq.cli import display


def test_print_markdown_renders():
    """print_markdown renders without error."""
    with patch.object(display.console, "print") as mock_print:
        display.print_markdown("# Hello World\n\nSome **bold** text.")
        mock_print.assert_called_once()


def test_print_error_renders_to_stderr():
    """print_error renders to stderr console."""
    with patch.object(display.error_console, "print") as mock_print:
        display.print_error("Something went wrong")
        mock_print.assert_called_once()
        args = mock_print.call_args[0][0]
        assert "Something went wrong" in args


def test_print_tool_call_truncates_long_output():
    """print_tool_call truncates result to 200 chars."""
    long_result = "x" * 300
    with patch.object(display.console, "print") as mock_print:
        display.print_tool_call("my_tool", long_result)
        mock_print.assert_called_once()
        output = mock_print.call_args[0][0]
        assert "my_tool" in output
        # Check it's truncated (200 chars of x's)
        assert "x" * 200 in output
        assert "x" * 201 not in output


def test_print_tool_call_short_output():
    """print_tool_call shows full result when under 200 chars."""
    short_result = "Task completed"
    with patch.object(display.console, "print") as mock_print:
        display.print_tool_call("my_tool", short_result)
        mock_print.assert_called_once()
        output = mock_print.call_args[0][0]
        assert "Task completed" in output


def test_print_mode_colors():
    """print_mode uses correct colors for each mode."""
    modes = [
        ("autonomous", "green"),
        ("supervised", "yellow"),
        ("plan", "red"),
    ]
    for mode, expected_color in modes:
        with patch.object(display.console, "print") as mock_print:
            display.print_mode(mode)
            mock_print.assert_called_once()
            output = mock_print.call_args[0][0]
            assert expected_color in output
            assert mode in output


def test_create_spinner_context_manager():
    """create_spinner returns a working context manager."""
    # Just verify it doesn't error and can be used as context manager
    with patch("fliiq.cli.display.Live") as mock_live:
        mock_live.return_value.__enter__ = lambda self: self
        mock_live.return_value.__exit__ = lambda self, *args: None
        with display.create_spinner("Loading...") as spinner:
            assert spinner is not None


def test_print_table_renders():
    """print_table renders without error."""
    with patch.object(display.console, "print") as mock_print:
        display.print_table(
            headers=["Name", "Description"],
            rows=[["tool1", "Does something"], ["tool2", "Does another thing"]],
            title="My Tools",
        )
        mock_print.assert_called_once()


def test_print_status_renders():
    """print_status renders mode, message_count, and iteration_total."""
    with patch.object(display.console, "print") as mock_print:
        display.print_status("autonomous", 5, 10)
        assert mock_print.call_count == 3  # mode, messages, iterations
