import json
from typing import Any, Callable, Literal, cast, overload
from warnings import warn

from redis import Redis

from sqlmodel_dump.deserializer import Deserializer
from sqlmodel_dump.serializer import Serializer


class SQLModelDump:
    _class: dict[str, type[Any]] = {}

    _max_depth: int
    _self_ref: bool

    _key_factory: Callable[[Any], str] | None
    _attr_to_key: dict[str | type[Any], list[str]] | None
    _ref_alternative: Callable[[str], Any] | None

    _redis: Redis
    _store_obj_to_redis: bool
    _set_kwargs: dict[str, Any]
    _get_kwargs: dict[str, Any]

    def __init__(
        self,
        redis: Redis,
        max_depth: int = 3,
        self_ref: bool = False,
        key_factory: Callable[[Any], str] | None = None,
        attr_to_key: dict[str | type[Any], list[str]] | None = None,
        ref_alternative: Callable[[str], Any] | None = None,
        store_obj_to_redis: bool = False,
        set_kwargs: dict[str, Any] = {},
        get_kwargs: dict[str, Any] = {},
    ) -> None:
        """
        SQLModel dumping manager

        ## What is self_ref mode?

        With self_ref set to `False`, the Relationship reference will be stored in `SQLModelDump._ref` dict.
        This is the default mode and need a garbage collector in order not to raise the memory leak error..

        **Example:**
        Return object:
        ```
        {
            "__type": "model",
            "__class": "Enrollment",
            "id": "f2915205-831c-4941-b116-7c76b27ebd2f",
            "classroom": {
                "__type": "relationship",
                "__class": "Class",
                "__ref": "Class:b607a4a3-4a10-453b-aed4-cd575ebb6c36" # An address to the reference in `_ref` object
            },
            ...
        }
        ```
        `_ref` object
        ```
        {
            "Class:b607a4a3-4a10-453b-aed4-cd575ebb6c36": { # The relationship value
                "__type": "model",
                "__class": "Class",
                "id": "b607a4a3-4a10-453b-aed4-cd575ebb6c36",
                "name": "Test Class",
                "subject": "Test",
                "teacher_id": "3135756c-be25-41a5-a6a8-be2c6f667c99",
                "teacher": {
                    "__type": "relationship",
                    "__class": "Teacher",
                    "__ref": "Teacher:3135756c-be25-41a5-a6a8-be2c6f667c99" # Reference to another object
                }
            },
            ...
        }
        ```

        With self_ref set to `True`, the reference will be stored in the result object itself.
        This can help eliminate the garbage collector but the result object size will be significantly increased

        **Example:**
        ```
        {
            "__type": "model",
            "__class": "Enrollment",
            "id": "ae4efb62-cd94-47bf-a6e7-3f9c93703c00",
            "class_id": "bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
            "classroom": {
                "__type": "relationship",
                "__class": "Class",
                "__ref": "Class:bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
                "__val": { # The relationship will be store in itself
                    "__type": "model",
                    "__class": "Class",
                    "id": "bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
                    "created_at": {
                        "__type": "datetime",
                        "__val": 1772292084.449564
                    },
                    "updated_at": {
                        "__type": "datetime",
                        "__val": 1772292084.449624
                    },
                    "name": "Test Class",
                    "subject": "Test",
                    ...
                }
            },
            ...
        }
        ```

        :param Redis redis: Redis client
        :param int max_depth: control how deep the serializer and deserializer will go
        :param bool self_ref: Use self_ref mode
        :param dict attr_to_key: A map of class or class name and keys that will be used to create the reference key. For example, if you want class Enrollment use its class_id and student_id for reference key, it should be { Enrollment: ["class_id", "student_id"] }. This is the alternative way to modify the reference key.
        :param Callable key_factory: A custom function to produce the key for reference, should accept only one args is the reference object
        :prarm Callable ref_alternative: A function to call when a reference is missing, could be an async function
        :param bool store_obj_to_redis: Will the result object be stored in the Redis before returning
        :param dict set_kwargs: kwargs for Redis set function
        :param dict get_kwargs: kwargs for Redis get function
        """
        if attr_to_key and key_factory:
            warn("attr_to_key and key_factory is both set, key_factory will be used")
        self._max_depth = max_depth
        self._self_ref = self_ref
        self._attr_to_key = attr_to_key
        self._key_factory = key_factory
        self._ref_alternative = ref_alternative
        self._redis = redis
        self._store_obj_to_redis = store_obj_to_redis
        self._set_kwargs = set_kwargs
        self._get_kwargs = get_kwargs

    def _key_generator(self, obj: Any):
        if self._attr_to_key:
            try:
                keys = next(
                    keys
                    for key, keys in self._attr_to_key.items()
                    if (isinstance(key, str) and obj.__class__.__name__ == key)
                    or (issubclass(cast(type[Any], key), obj.__class__))
                )
                key = " ".join(f"{key}={getattr(obj, key, 'None')}" for key in keys)
                return f"{obj.__class__.__name__}({key})"
            except StopIteration:
                return f"{obj.__class__.__name__}:{getattr(obj, 'id', 'None')}"

        raise

    @overload
    def dumps(self, obj: Any) -> dict[str, Any]:
        """
        Dump the SQLModel into dict

        :param SQLModel obj: Obj to dump
        :return dict[str, Any]: The dumped object
        """

    @overload
    def dumps(
        self, obj: Any, store_obj_to_redis: Literal[False]
    ) -> dict[str, Any]:
        """
        Dump the SQLModel into dict

        :param SQLModel obj: Obj to dump
        :param bool store_obj_to_redis: Store the dumped object to the Redis too
        :return dict[str, Any]: The dumped object
        """

    @overload
    def dumps(
        self, obj: Any, store_obj_to_redis: Literal[True]
    ) -> tuple[dict[str, Any], str]:
        """
        Dump the SQLModel into dict

        :param SQLModel obj: Obj to dump
        :param bool store_obj_to_redis: Store the dumped object to the Redis too
        :return tuple[dict[str, Any], str]: The dumped object and the Redis key of that object
        """

    def dumps(
        self, obj: Any, store_obj_to_redis: bool = False
    ) -> dict[str, Any] | tuple[dict[str, Any], str]:
        """
        Dump the SQLModel into dict

        :param SQLModel obj: Obj to dump
        :param bool store_obj_to_redis: Store the dumped object to the Redis too
        :return tuple[dict[str, Any], str]: The dumped object and the Redis key of that object
        """
        serializer = Serializer(
            self_ref=self._self_ref,
            max_depth=self._max_depth,
            key_factory=self._key_factory,
        )
        dumps = serializer.serialize(obj)
        self._class |= serializer.base_class
        for key, val in serializer.ref.items():
            self._redis.set(key, val, **self._set_kwargs)
        if not store_obj_to_redis:
            return dumps

        redis_key = (
            self._key_factory(obj) if self._key_factory else self._key_generator(obj)
        )
        self._redis.set(redis_key, json.dumps(dumps))
        return dumps, redis_key

    def _redis_ref_alternative(self, key: str) -> Any:
        data = self._redis.get(key)
        if data:
            return data
        if self._ref_alternative:
            return self._ref_alternative(key)
        return None

    def loads_from_redis(self, key: str) -> Any:
        """
        Loads the object from Redis

        :param str key: The Redis key
        :return: The loaded object
        """
        obj = self._redis.get(key)
        if obj is not None:
            obj = json.loads(obj.__str__())
            return self.loads(obj)
        return None

    def loads(self, obj: Any) -> Any:
        """
        Loads the object

        :param Any obj: The object to load
        :return: The loaded object
        """
        deserializer = Deserializer(
            get_class=self._class.get,
            get_ref=lambda x: None,
            self_ref=self._self_ref,
            max_depth=self._max_depth,
            ref_alternative=self._redis_ref_alternative,
        )
        return deserializer.deserialize(obj)
