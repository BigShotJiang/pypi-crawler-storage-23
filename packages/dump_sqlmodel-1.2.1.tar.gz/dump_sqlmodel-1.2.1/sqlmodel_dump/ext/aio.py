from datetime import datetime
from enum import Enum
from typing import Any, Callable, Coroutine
from warnings import warn

from pydantic import BaseModel
from sqlalchemy import inspect
from sqlalchemy.orm import Mapper
from sqlmodel import SQLModel  # type: ignore

from sqlmodel_dump.error import (
    DeserializerMissing,
    DeserializerObjMissing,
    Invalid,
    InvalidOption,
    LostRef,
    WhereIsMyRef,
)
from sqlmodel_dump.serializer import Serializer


class SQLModelDump:
    _ref: dict[str, Any] = {}
    _class: dict[str, type[Any]] = {}

    _max_depth: int
    _self_ref: bool

    _attr_to_key: dict[str | type[Any], list[str]] | None
    _key_factory: Callable[[Any], str] | None
    _ref_alternative: Callable[[str], Coroutine[Any, Any, Any]] | None

    def __init__(
        self,
        max_depth: int = 3,
        self_ref: bool = False,
        key_factory: Callable[[Any], str] | None = None,
        attr_to_key: dict[str | type[Any], list[str]] | None = None,
        ref_alternative: Callable[[str], Coroutine[Any, Any, Any]] | None = None,
    ) -> None:
        """
        SQLModel dumping manager

        ## What is self_ref mode?

        With self_ref set to `False`, the Relationship reference will be stored in `SQLModelDump._ref` dict.
        This is the default mode and need a garbage collector in order not to raise the memory leak error..

        **Example:**
        Return object:
        ```
        {
            "__type": "model",
            "__class": "Enrollment",
            "id": "f2915205-831c-4941-b116-7c76b27ebd2f",
            "classroom": {
                "__type": "relationship",
                "__class": "Class",
                "__ref": "Class:b607a4a3-4a10-453b-aed4-cd575ebb6c36" # An address to the reference in `_ref` object
            },
            ...
        }
        ```
        `_ref` object
        ```
        {
            "Class:b607a4a3-4a10-453b-aed4-cd575ebb6c36": { # The relationship value
                "__type": "model",
                "__class": "Class",
                "id": "b607a4a3-4a10-453b-aed4-cd575ebb6c36",
                "name": "Test Class",
                "subject": "Test",
                "teacher_id": "3135756c-be25-41a5-a6a8-be2c6f667c99",
                "teacher": {
                    "__type": "relationship",
                    "__class": "Teacher",
                    "__ref": "Teacher:3135756c-be25-41a5-a6a8-be2c6f667c99" # Reference to another object
                }
            },
            ...
        }
        ```

        With self_ref set to `True`, the reference will be stored in the result object itself.
        This can help eliminate the garbage collector but the result object size will be significantly increased

        **Example:**
        ```
        {
            "__type": "model",
            "__class": "Enrollment",
            "id": "ae4efb62-cd94-47bf-a6e7-3f9c93703c00",
            "class_id": "bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
            "classroom": {
                "__type": "relationship",
                "__class": "Class",
                "__ref": "Class:bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
                "__val": { # The relationship will be store in itself
                    "__type": "model",
                    "__class": "Class",
                    "id": "bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
                    "created_at": {
                        "__type": "datetime",
                        "__val": 1772292084.449564
                    },
                    "updated_at": {
                        "__type": "datetime",
                        "__val": 1772292084.449624
                    },
                    "name": "Test Class",
                    "subject": "Test",
                    ...
                }
            },
            ...
        }
        ```

        :param int max_depth: control how deep the serializer and deserializer will go
        :param bool self_ref: Use self_ref mode
        :param dict attr_to_key: A map of class or class name and keys that will be used to create the reference key. For example, if you want class Enrollment use its class_id and student_id for reference key, it should be { Enrollment: ["class_id", "student_id"] }. This is the alternative way to modify the reference key.
        :param Callable key_factory: A custom function to produce the key for reference, should accept only one args is the reference object
        :prarm Callable ref_alternative: A function to call when a reference is missing, could be an async function
        """
        if attr_to_key and key_factory:
            warn("attr_to_key and key_factory is both set, key_factory will be used")
        self._max_depth = max_depth
        self._self_ref = self_ref
        self._attr_to_key = attr_to_key
        self._attr_to_key = attr_to_key
        self._key_factory = key_factory
        self._ref_alternative = ref_alternative

    def dumps(self, obj: SQLModel) -> dict[str, Any]:
        """
        Dump the SQLModel into dict

        :param SQLModel obj: Obj to dump
        :return dict[str, Any]: The dumped object
        """
        serializer = Serializer(
            self_ref=self._self_ref,
            max_depth=self._max_depth,
            attr_to_key=self._attr_to_key,
            key_factory=self._key_factory,
        )
        dumps = serializer.serialize(obj)
        self._ref |= serializer.ref
        self._class |= serializer.base_class
        return dumps

    async def loads(self, obj: Any) -> Any:
        """
        Loads the object

        :param Any obj: The object to load
        :return: The loaded object
        """
        deserializer = AsyncDeserializer(
            get_class=self._class.get,
            get_ref=self._ref.get,
            self_ref=self._self_ref,
            max_depth=self._max_depth,
            ref_alternative=self._ref_alternative,
        )
        return await deserializer.deserialize(obj)

class AsyncDeserializer:
    _max_depth: int
    _get_class: Callable[[str], type[Any] | None]
    _get_ref: Callable[[str], Any | None]
    _self_ref: bool
    _ref: dict[str, Any] = {}
    _key_factory: Callable[[Any], str]
    _ref_alternative: Callable[[str], Any] | None

    def __init__(
        self,
        get_class: Callable[[str], type[Any] | None],
        get_ref: Callable[[str], Any] | None = None,
        self_ref: bool = False,
        max_depth: int = 3,
        ref_alternative: Callable[[str], Any] | None = None,
    ) -> None:
        """
        Create a Deserializer

        :param Callable get_class: The function to get the reference class.
        :param Callable | None get_ref: The function to get the reference.
        :param bool self_ref: Use self_ref mode. Will return a `self_ref` object.
        :param int max_depth: Controll how deep the deserializer will dig into the object.
        :param Callable | None ref_alternative: The function to call when the ref is missing. Could be a function to call to the DB. Should return the obj, not a dict, for example, a SQLModel object.
        :param AbstractEventLoop | None running_loop: The current running event loop. Will be used to call the `ref_alternative` if it is an async function.
        """
        self._max_depth = max_depth
        self._get_class = get_class
        self._self_ref = self_ref
        if self_ref:
            self._get_ref = self._ref.get
        elif get_ref is None:
            raise InvalidOption("get_ref must be provided or self_ref must be true")
        else:
            self._get_ref = get_ref
        self._ref_alternative = ref_alternative
        
    async def deserialize(self, obj: Any, current_depth: int = 1) -> Any:
        """
        Deserialize json object into a object.

        :param Any obj: Object to deserialize
        :param int current_depth: To control the object depth

        :return Any: The loaded object 
        """
        if isinstance(obj, dict):
            return await self._ds_dict(obj, current_depth)
        elif isinstance(obj, list):
            return [await self.deserialize(item, current_depth) for item in obj]
        else:
            return obj

    async def _ds_dict(self, obj: dict, current_depth: int) -> Any:
        if "__type" not in obj:
            return obj

        match obj["__type"]:
            case "model":
                return await self._ds_model(obj, current_depth)

            case "datetime":
                if "__val" not in obj:
                    raise DeserializerObjMissing("datetime", "__val")
                if not isinstance(obj["__val"], float):
                    raise Invalid("obj __val", "float", obj["__val"].__class__.__name__)
                return datetime.fromtimestamp(obj["__val"])

            case "enum":
                if "__class" not in obj:
                    raise DeserializerObjMissing("enum", "__class")
                if "__val" not in obj:
                    raise DeserializerObjMissing("enum", "__val")
                class_ = self._get_class(obj["__class"])
                if class_ is None:
                    raise DeserializerMissing("class", obj["__class"])
                if not issubclass(class_, Enum):
                    raise Invalid("obj class", "python Enum", class_.__name__)
                return class_(obj["__val"])

    async def _ds_model(self, obj: dict, current_depth: int) -> BaseModel:
        if "__class" not in obj:
            raise DeserializerObjMissing("model", "__class")
        class_ = self._get_class(obj["__class"])
        if class_ is None:
            raise DeserializerMissing("class", obj["__class"])
        if not issubclass(class_, BaseModel):
            raise Invalid("obj class", "pydantic BaseModel", class_.__name__)

        data = {}
        for key in class_.model_fields:
            data[key] = await self.deserialize(obj[key], current_depth + 1)

        if issubclass(class_, SQLModel):
            data |= await self._handle_sqlmodel(class_, obj, current_depth)

        return class_(**data)

    async def _handle_sqlmodel(
        self, class_: type[SQLModel], obj: Any, current_depth: int
    ) -> dict[str, Any]:
        insp: Mapper | None = inspect(class_, raiseerr=False)
        if insp is None:
            raise ValueError(
                "obj class is sqlmodel but can't inspect"
            )  # should not happend

        data = {}
        for key in insp.relationships.keys():
            value = obj[key]
            if value is None:
                raise Invalid(
                    f"key {key}",
                    "relationship obj",
                    value.__class__.__name__,
                )
            if "__class" not in value:
                raise DeserializerObjMissing("relationship", "__class")
            if "__ref" not in value:
                raise DeserializerObjMissing("relationship", "__ref")

            if self._self_ref is True:
                data[key] = await self._handle_self_ref(value, current_depth)
            else:
                data[key] = await self._hanle_obj_ref(value, current_depth + 1)

        return data

    async def _handle_self_ref(self, value: Any, current_depth: int) -> BaseModel:
        if "__use_ref" in value and value["__use_ref"] is True:
            ref = self._get_ref(value["__ref"])
            if ref is None:
                raise WhereIsMyRef(value["__ref"])
            return ref
        else:
            if "__val" not in value:
                raise DeserializerObjMissing("self ref relationship", "__value")
            ref = await self._ds_model(value["__val"], current_depth)
            self._ref[value["__ref"]] = ref
            return ref

    async def _hanle_obj_ref(self, value: Any, current_depth: int) -> BaseModel:
        if "__use_ref" in value or "__val" in value:
            warn(
                "found '__use_ref' or '__val' in relationship model, do you forget to set 'self_ref' to true?"
            )
        ref_key = value["__ref"]
        ref = self._get_ref(ref_key)
        if ref is None:
            if self._ref_alternative:
                ref = await self._ref_alternative(ref_key)
                
            else:
                raise LostRef(ref_key)
        
        return await self._ds_model(ref, current_depth)