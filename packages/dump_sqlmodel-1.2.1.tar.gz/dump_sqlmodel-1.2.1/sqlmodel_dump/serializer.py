from datetime import datetime
from enum import Enum
from typing import Any, Callable, cast
from warnings import warn

from pydantic import BaseModel
from sqlalchemy import inspect
from sqlalchemy.orm import InstanceState
from sqlmodel import SQLModel


class Serializer:
    _seen: set[str]
    _trace: list[str]
    _max_depth: int
    _self_ref: bool
    _key_factory: Callable[[Any], str]
    _attr_to_key: dict[str | type[Any], list[str]] | None

    ref: dict[str, Any] = {}
    base_class: dict[str, type[Any]] = {}

    def __init__(
        self,
        self_ref: bool = False,
        max_depth: int = 3,
        attr_to_key: dict[str | type[Any], list[str]] | None = None,
        key_factory: Callable[[Any], str] | None = None,
    ) -> None:
        """
        Create a Serializer
        
        :param bool self_ref: Use self_ref mode. The output will be a self_ref object
        :param int max_depth: Controll how deep the serializer will dig into the object.
        :param dict attr_to_key: A map of class or class name and keys that will be used to create the reference key. For example, if you want class Enrollment use its class_id and student_id for reference key, it should be { Enrollment: ["class_id", "student_id"] }. This is the alternative way to modify the reference key.
        :param Callable key_factory: Modify how a reference key will be created. Accept the refering object as the input and the output must be a string as the reference key. The default key pattern is `obj_class_name:obj_id`
        """
        if attr_to_key and key_factory:
            warn("attr_to_key and key_factory is both set, key_factory will be used")
            
        self._max_depth = max_depth
        self._self_ref = self_ref
        self._seen = set()
        self._trace = []
        self.ref = {}
        self.base_class = {}

        if key_factory:
            self._key_factory = key_factory
        elif attr_to_key:
            self._attr_to_key = attr_to_key
            self._key_factory = self._key_generator
        else:
            self._key_factory = lambda x: f"{x.__class__.__name__}:{getattr(x, 'id', 'None')}"

    def _key_generator(self, obj: Any):
        if self._attr_to_key:
            try:
                keys = next(
                    keys
                    for key, keys in self._attr_to_key.items()
                    if (isinstance(key, str) and obj.__class__.__name__ == key)
                    or (issubclass(cast(type[Any], key), obj.__class__))
                )
                key = " ".join(f"{key}={getattr(obj, key, 'None')}" for key in keys)
                return f"{obj.__class__.__name__}({key})"
            except StopIteration:
                return f"{obj.__class__.__name__}:{getattr(obj, 'id', 'None')}"
        raise

    def serialize(self, obj: Any, current_depth: int = 1) -> Any:
        """
        Serialize object into a json object.

        :param Any obj: Object to serialize
        :param int current_depth: To control the object depth

        :return Any: The dumped object 
        """
        if isinstance(obj, SQLModel):
            obj_id = getattr(obj, "id")
            obj_class_name = obj.__class__.__name__
            if obj_id is None:
                raise ValueError(f"obj of class {obj_class_name} don't have id field")

            if current_depth > self._max_depth:
                return {"__id": obj_id, "__error": "exceed max depth"}

            obj_ref = f"{obj_class_name}:{obj_id}"
            if obj_ref in self._seen:
                return {"__ref": obj_ref, "__seen": True}
            self._seen.add(obj_ref)
            self._trace.append(obj_ref)

            insp: InstanceState | None = inspect(obj, raiseerr=False)
            if insp is None:
                raise ValueError(
                    f"obj of class {obj_class_name} is a sqlmodel but can't inspect it"
                )

            data: dict[str, Any] = {"__type": "model", "__class": obj_class_name}
            self.base_class[obj_class_name] = obj.__class__
            for key in obj.__class__.model_fields:
                data[key] = self.serialize(getattr(obj, key), current_depth + 1)
            for key in insp.mapper.relationships.keys():
                data[key] = {
                    "__type": "relationship",
                }
                if key in insp.unloaded:
                    data[key] |= {"__error": "unloaded"}
                    continue

                value = getattr(obj, key)
                value_class = value.__class__
                value_id = getattr(value, "id")
                if value_id is None:
                    raise ValueError(
                        f"obj of class {value_class.__name__} don't have id field"
                    )

                ref_key = self._key_factory(value)
                data[key] |= {"__class": value_class.__name__, "__ref": ref_key}

                serialized_value = self.serialize(value, current_depth + 1)
                if self._self_ref:
                    if (
                        "__seen" in serialized_value
                        and serialized_value["__seen"] is True
                    ):
                        data[key] |= {"__use_ref": True}
                    else:
                        data[key] |= {"__val": serialized_value}
                else:
                    if (
                        "__seen" in serialized_value
                        and serialized_value["__seen"] is True
                    ):
                        data[key] |= {"__seen": True}
                    else:
                        self.ref[ref_key] = serialized_value

            self._trace.pop()
            return data

        elif isinstance(obj, list):
            return [self.serialize(item, current_depth) for item in obj]
        elif isinstance(obj, BaseModel):
            self.base_class[obj.__class__.__name__] = obj.__class__
            return obj.model_dump() | {
                "__type": "model",
                "__class": obj.__class__.__name__,
            }
        elif isinstance(obj, Enum):
            self.base_class[obj.__class__.__name__] = obj.__class__
            return {
                "__type": "enum",
                "__class": obj.__class__.__name__,
                "__val": obj.value,
            }
        elif isinstance(obj, datetime):
            return {"__type": "datetime", "__val": obj.timestamp()}
        else:
            return obj
