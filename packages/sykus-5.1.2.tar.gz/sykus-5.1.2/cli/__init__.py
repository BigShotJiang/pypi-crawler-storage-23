"""Sykus CLI - Command line interface"""
from .syk_cli import main, SykusCLI

__all__ = ['main', 'SykusCLI']
