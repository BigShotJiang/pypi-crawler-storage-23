"""Sykus Ghost - Auto-install dependencies"""
from .dependency_manager import GhostDependencyManager, ghost_install, get_ghost_manager

__all__ = ['GhostDependencyManager', 'ghost_install', 'get_ghost_manager']
