"""Modal dialog for update prompts."""

from textual.containers import Vertical, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Static, Button


class UpdateModal(ModalScreen[bool]):
    """Modal asking user to accept or skip an available update."""

    CSS = """
    UpdateModal {
        align: center middle;
    }

    #update-dialog {
        width: 50;
        height: auto;
        border: thick $accent;
        background: $surface;
        padding: 1 2;
    }

    #update-title {
        text-align: center;
        text-style: bold;
        margin-bottom: 1;
    }

    #update-versions {
        text-align: center;
        margin-bottom: 1;
    }

    #update-buttons {
        height: auto;
        align: center middle;
    }

    #update-buttons Button {
        margin: 0 1;
    }
    """

    def __init__(self, current: str, latest: str) -> None:
        super().__init__()
        self._current = current
        self._latest = latest

    def compose(self):
        with Vertical(id="update-dialog"):
            yield Static("Update Available", id="update-title")
            yield Static(
                f"v{self._current} → [bold green]v{self._latest}[/bold green]",
                id="update-versions",
            )
            with Horizontal(id="update-buttons"):
                yield Button("Update", id="btn-update", variant="success")
                yield Button("Skip", id="btn-skip", variant="default")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "btn-update")
