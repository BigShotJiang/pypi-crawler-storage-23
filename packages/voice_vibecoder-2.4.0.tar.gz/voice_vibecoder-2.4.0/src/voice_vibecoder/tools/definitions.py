"""OpenAI Realtime API tool definitions.

Pure data — no logic. Each entry maps to a function_call tool that ChatGPT
can invoke during a voice session.

External tools registered via ``register_external_tools`` in dispatch.py
are appended at the end of ``TOOL_DEFINITIONS``.
"""

from typing import Any

# Core agent tools
_CORE_TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "name": "send_to_agent",
        "description": (
            "Send a CODING task to the coding agent. Returns immediately — the agent works in the background. "
            "IMPORTANT: You MUST provide the branch parameter — this tool is ONLY for code tasks "
            "(features, fixes, refactoring, tests, config). For non-code tasks (Jira, CI, questions, "
            "research, documentation), use send_to_session instead. "
            "If no instance exists for the branch, one is auto-created. "
            "Branch names are fuzzy-matched — e.g. 'branding' matches 'feat/branding-refresh'. "
            "Ask the user which branch if unclear."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "The coding task for the agent",
                },
                "branch": {
                    "type": "string",
                    "description": "Target branch name (required for code tasks).",
                },
                "agent": {
                    "type": "string",
                    "description": (
                        "Agent to use: 'claude' or 'cursor'. "
                        "Sets the agent for this branch. Defaults to the primary enabled agent."
                    ),
                },
            },
            "required": ["message"],
        },
    },
    {
        "type": "function",
        "name": "send_to_session",
        "description": (
            "Send a NON-CODE task to a session agent. Returns immediately — the agent works in the background. "
            "Use for anything that doesn't change code: research, Jira lookups, CI status, questions, "
            "documentation, planning, analysis, etc. "
            "Use short lowercase kebab-case session keys (e.g. 'jira', 'ci-status', 'events'). "
            "Session names are fuzzy-matched — reuse existing sessions for the same topic. "
            "If session_name is omitted, one is auto-generated from the message. "
            "Always provide a short, human-friendly display_name in the user's language "
            "(e.g. 'Arrangementer', 'Lønn', 'Jira-oppslag', 'Events', 'Salary')."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "The task or question for the session agent",
                },
                "session_name": {
                    "type": "string",
                    "description": "Short kebab-case key (e.g. 'events', 'salary'). Auto-generated if omitted.",
                },
                "display_name": {
                    "type": "string",
                    "description": "Human-friendly label shown in the UI (e.g. 'Arrangementer', 'Lønn'). Required.",
                },
                "agent": {
                    "type": "string",
                    "description": (
                        "Agent to use: 'claude' or 'cursor'. "
                        "Defaults to the primary enabled agent."
                    ),
                },
            },
            "required": ["message"],
        },
    },
    {
        "type": "function",
        "name": "switch_agent",
        "description": (
            "Switch the coding agent for a branch WITHOUT sending a task. "
            "Use when the user just wants to change agents (e.g. 'switch to Cursor', "
            "'use Claude on feat/login') without giving a new coding task."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "agent": {
                    "type": "string",
                    "description": "Agent to switch to: 'claude' or 'cursor'.",
                },
                "branch": {
                    "type": "string",
                    "description": "Target branch name.",
                },
            },
            "required": ["agent"],
        },
    },
    {
        "type": "function",
        "name": "create_branch_instance",
        "description": (
            "Create a new agent instance panel without sending a task. "
            "Usually not needed — send_to_agent auto-creates instances. "
            "Use this only if you want a panel visible before any task is sent."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "The git branch name (e.g. 'feat/login', 'fix/bug-123')",
                },
                "agent": {
                    "type": "string",
                    "description": (
                        "Agent to use: 'claude' or 'cursor'. "
                        "Defaults to the primary enabled agent."
                    ),
                },
            },
            "required": ["branch"],
        },
    },
    {
        "type": "function",
        "name": "get_agent_status",
        "description": (
            "Check if an agent is currently running a task and get its latest output. "
            "Specify a branch for code instances or session_name for session instances."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name to check. Optional — omit for all instances.",
                },
                "session_name": {
                    "type": "string",
                    "description": "Session name to check. Optional.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "cancel_agent",
        "description": (
            "Cancel the currently running agent task. Use when the user says cancel, stop, or abort. "
            "Specify a branch or session_name to cancel a specific instance."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name to cancel. Optional — omit to cancel all.",
                },
                "session_name": {
                    "type": "string",
                    "description": "Session name to cancel. Optional.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "reset_agent",
        "description": (
            "Reset an agent session. Starts fresh with no memory of previous commands. "
            "Use when user says 'start fresh', 'new session', or 'reset'. "
            "Specify a branch or session_name to reset a specific instance."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name to reset. Optional — omit to reset all.",
                },
                "session_name": {
                    "type": "string",
                    "description": "Session name to reset. Optional.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "list_branches",
        "description": "List all active agent instances and available git worktrees/branches.",
        "parameters": {"type": "object", "properties": {}},
    },
    {
        "type": "function",
        "name": "answer_agent_question",
        "description": (
            "Answer a question that the coding agent asked via voice. Use this when the agent "
            "is waiting for user input (status: waiting_input). The user answers "
            "verbally and you forward their answer here."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "answer": {
                    "type": "string",
                    "description": "The user's answer to the agent's question, forwarded verbatim.",
                },
                "branch": {
                    "type": "string",
                    "description": "Target branch name. Optional — omit if there is only one instance.",
                },
                "session_name": {
                    "type": "string",
                    "description": "Session name. Optional — use for session instances.",
                },
            },
            "required": ["answer"],
        },
    },
    {
        "type": "function",
        "name": "show_diff",
        "description": (
            "Show git diff for an instance. Replaces the agent output panel "
            "with a GitHub-style diff view (file list + colorized diff). "
            "Use the file parameter to show only a specific file's diff. "
            "File names are fuzzy-matched — e.g. 'config' matches 'src/config.ts'."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name.",
                },
                "file": {
                    "type": "string",
                    "description": "File name or partial path to filter the diff to a single file.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "show_output",
        "description": (
            "Switch back to normal view. Exits fullscreen if active, "
            "and switches from diff view back to agent output. "
            "Use when the user says 'go back', 'normal view', or 'show output'."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name.",
                },
                "session_name": {
                    "type": "string",
                    "description": "Session name.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "toggle_fullscreen",
        "description": (
            "Toggle fullscreen for one panel. Hides all other panels. "
            "Call again to restore the grid view."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name.",
                },
                "session_name": {
                    "type": "string",
                    "description": "Session name.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "remove_branch_instance",
        "description": (
            "Remove a branch code instance and its panel. "
            "Cancels any running agent task."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name to remove.",
                },
            },
            "required": ["branch"],
        },
    },
    {
        "type": "function",
        "name": "remove_session",
        "description": (
            "Remove a session instance and its panel. "
            "Cancels any running agent task."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "session_name": {
                    "type": "string",
                    "description": "Session name to remove.",
                },
            },
            "required": ["session_name"],
        },
    },
    {
        "type": "function",
        "name": "delete_worktree",
        "description": (
            "Delete a git worktree and optionally its branch. "
            "Also removes the agent instance if one exists. "
            "Cannot delete the main worktree."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "The branch name of the worktree to delete.",
                },
                "delete_branch": {
                    "type": "boolean",
                    "description": "Also delete the git branch. Defaults to false.",
                },
            },
            "required": ["branch"],
        },
    },
]

def get_tool_definitions() -> list[dict[str, Any]]:
    """Return all tool definitions, including any externally registered tools."""
    from voice_vibecoder.tools.dispatch import get_external_tool_definitions

    return _CORE_TOOLS + get_external_tool_definitions()


# Module-level constant — for backwards compatibility this is evaluated lazily
# via __getattr__ so that external tools registered before session configure
# are included.
def __getattr__(name: str) -> Any:
    if name == "TOOL_DEFINITIONS":
        return get_tool_definitions()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
