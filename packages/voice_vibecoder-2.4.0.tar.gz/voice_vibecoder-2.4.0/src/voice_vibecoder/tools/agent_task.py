"""Agent orchestration — sending tasks, background threading, voice relay.

Handles the lifecycle of sending a task to a coding agent, running it in a
background thread, and relaying interactive questions back through voice.
"""

import asyncio
import json
import logging
import threading
from pathlib import Path
from typing import Any

from voice_vibecoder.code_providers import AgentOutput, AgentRunner, truncate_output
from voice_vibecoder.code_providers.registry import get_agent
from voice_vibecoder.instances import AgentInstance, InstanceStatus, InstanceType

logger = logging.getLogger(__name__)

ANSWER_TIMEOUT = 300  # 5 min to answer a question

_CLAUDE_JSON = Path.home() / ".claude.json"

# Cached MCP servers — loaded once per session, files rarely change
_mcp_cache: dict[str, dict] | None = None


def _load_mcp_servers() -> dict[str, dict]:
    """Load MCP servers (cached after first call).

    Priority order:
    1. MCP_SERVERS_JSON environment variable (for Azure/production)
    2. .mcp.json in repo root (for repo-specific servers)
    3. ~/.claude.json project config (for local user config)
    """
    global _mcp_cache
    if _mcp_cache is not None:
        return _mcp_cache

    import os
    from voice_vibecoder.tools.dispatch import _repo_root

    servers: dict[str, dict] = {}

    # Load from .mcp.json in repo root
    if _repo_root:
        mcp_json = Path(_repo_root) / ".mcp.json"
        if mcp_json.exists():
            try:
                data = json.loads(mcp_json.read_text())
                servers.update(data.get("mcpServers", {}))
            except Exception as e:
                logger.warning("Failed to read .mcp.json: %s", e)

    # Load from ~/.claude.json
    if _repo_root and _CLAUDE_JSON.exists():
        try:
            data = json.loads(_CLAUDE_JSON.read_text())
            project_key = str(Path(_repo_root))
            project_data = data.get("projects", {}).get(project_key, {})
            local_servers = project_data.get("mcpServers", {})
            servers.update(local_servers)
        except Exception as e:
            logger.warning("Failed to read ~/.claude.json: %s", e)

    # MCP_SERVERS_JSON takes precedence (for Azure Container Apps)
    mcp_env = os.environ.get("MCP_SERVERS_JSON")
    if mcp_env:
        try:
            env_servers = json.loads(mcp_env)
            servers.update(env_servers.get("mcpServers", env_servers))
            logger.info("Loaded MCP servers from MCP_SERVERS_JSON environment variable")
        except Exception as e:
            logger.warning("Failed to parse MCP_SERVERS_JSON: %s", e)

    # Ensure each MCP server inherits process env vars (the Claude CLI may
    # not forward its own env to MCP server subprocesses).
    for _name, cfg in servers.items():
        if "env" not in cfg:
            cfg["env"] = dict(os.environ)

    _mcp_cache = servers
    return servers


def _create_runner(agent_type: str, permission_mode: str, mcp_servers: dict | None, env: dict | None = None) -> AgentRunner:
    """Create the appropriate AgentRunner for the given agent type."""
    return get_agent(agent_type).runner_factory(
        permission_mode=permission_mode,
        mcp_servers=mcp_servers,
        env=env,
    )


def _handle_send_to_agent(message: str, branch: str | None = None, agent: str | None = None) -> str:
    from voice_vibecoder.tools.dispatch import (
        _default_agent_type, _fuzzy_match_branch, _helper_override,
        _registry, _repo_root, _resolve_instance,
    )

    if not message.strip():
        return "Error: empty message"

    # Resolve agent type early so auto-created instances get the right type
    target_agent = agent or _default_agent_type()

    instance = _resolve_instance(branch)
    if not instance and branch and _registry and _repo_root:
        # Auto-create: fuzzy match against worktree branches, then resolve
        from voice_vibecoder.worktrees import list_worktrees, resolve_worktree_path

        worktrees = list_worktrees(_repo_root)
        wt_branches = [wt.branch for wt in worktrees if wt.branch and not wt.is_main]
        resolved_branch = _fuzzy_match_branch(branch, wt_branches) or branch
        try:
            worktree_path = resolve_worktree_path(resolved_branch, _repo_root)
            instance = _registry.create_instance(resolved_branch, str(worktree_path), agent_type=target_agent)
        except Exception:
            return f"Could not create instance for '{branch}'."

    if not instance:
        if branch:
            return f"No instance for branch '{branch}'."
        return "No agent instance available."

    # Update agent type if switching on an existing instance
    resolved_agent = agent or instance.agent_type or target_agent
    if resolved_agent != instance.agent_type:
        instance.agent_type = resolved_agent
        instance.session_id = ""  # Clear session when switching agents
        if _registry:
            _registry._save_state()

    if instance.status == InstanceStatus.RUNNING:
        return (
            f"Agent on '{instance.branch}' is already working on a task. "
            "Use get_agent_status to check progress, or cancel_agent to stop it."
        )

    # Capture registry at dispatch time so background threads use the correct
    # session's registry even if another WebSocket session connects and
    # overwrites the module-level _registry.
    registry = _registry

    instance.output_buffer = ""

    # Show the user's prompt and a separator in the panel
    if registry and registry.on_output:
        registry.on_output(instance.instance_id, "separator:")
        preview = message[:200] + ("..." if len(message) > 200 else "")
        registry.on_output(instance.instance_id, f"user_prompt:{preview}")

    if registry:
        registry.update_status(instance.instance_id, InstanceStatus.RUNNING)

    # Check if this is a helper instance with an override registered
    is_helper = _repo_root and str(instance.worktree_path) == str(_repo_root)

    if is_helper and _helper_override:
        thread = threading.Thread(
            target=_run_helper_override_background,
            args=(instance, message, registry),
            daemon=True,
        )
        thread.start()
        return "Sent to helper."

    thread = threading.Thread(
        target=_run_agent_background,
        args=(instance, message, registry),
        daemon=True,
    )
    thread.start()

    agent_label = get_agent(instance.agent_type).label
    return f"Sent to {agent_label}."


def _handle_send_to_session(message: str, session_name: str | None = None, agent: str | None = None, display_name: str | None = None) -> str:
    from voice_vibecoder.tools.dispatch import (
        _default_agent_type, _helper_override,
        _registry, _repo_root,
    )

    if not message.strip():
        return "Error: empty message"

    if not _registry:
        return "Error: tools not configured."

    target_agent = agent or _default_agent_type()

    # Auto-generate session name from message if not provided
    if not session_name:
        words = message.strip().split()[:4]
        session_name = "-".join(w.lower().strip(".,!?;:") for w in words if w.strip(".,!?;:"))
        if not session_name:
            session_name = "session"

    instance = _registry.get_session_by_name(session_name)
    if not instance:
        instance = _registry.create_session(session_name, agent_type=target_agent)
    # Update display_name if a better one was provided by the LLM
    if display_name and display_name != instance.display_name:
        instance.display_name = display_name
        _registry._save_state()

    # Update agent type if switching
    resolved_agent = agent or instance.agent_type or target_agent
    if resolved_agent != instance.agent_type:
        instance.agent_type = resolved_agent
        instance.session_id = ""
        _registry._save_state()

    if instance.status == InstanceStatus.RUNNING:
        return (
            f"Session '{instance.display_name}' is already working on a task. "
            "Use get_agent_status to check progress, or cancel_agent to stop it."
        )

    registry = _registry

    instance.output_buffer = ""

    # Show the user's prompt and a separator in the panel
    if registry and registry.on_output:
        registry.on_output(instance.instance_id, "separator:")
        preview = message[:200] + ("..." if len(message) > 200 else "")
        registry.on_output(instance.instance_id, f"user_prompt:{preview}")

    if registry:
        registry.update_status(instance.instance_id, InstanceStatus.RUNNING)

    # Route through helper override if registered (backward compat)
    if _helper_override:
        thread = threading.Thread(
            target=_run_helper_override_background,
            args=(instance, message, registry),
            daemon=True,
        )
        thread.start()
        return f"Sent to session '{instance.display_name}'."

    thread = threading.Thread(
        target=_run_agent_background,
        args=(instance, message, registry),
        daemon=True,
    )
    thread.start()

    return f"Sent to session '{instance.display_name}'."


def _run_agent_background(instance: AgentInstance, message: str, registry: "InstanceRegistry") -> None:

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    instance._bg_loop = loop

    try:
        loop.run_until_complete(_run_agent_async(instance, message, registry))
    finally:
        # Cancel any pending answer Future so _ask_user_via_voice doesn't hang
        pending = instance.pending_answer
        if pending and not pending.done():
            loop.call_soon_threadsafe(pending.cancel)
        instance.pending_answer = None
        instance.pending_question = None
        loop.close()
        instance._bg_loop = None
        instance._bg_task = None


def _run_helper_override_background(instance: AgentInstance, message: str, registry: "InstanceRegistry") -> None:
    """Run the helper override handler, falling back to Claude Code on failure."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    instance._bg_loop = loop

    try:
        loop.run_until_complete(_run_helper_override_async(instance, message, registry))
    finally:
        pending = instance.pending_answer
        if pending and not pending.done():
            loop.call_soon_threadsafe(pending.cancel)
        instance.pending_answer = None
        instance.pending_question = None
        loop.close()
        instance._bg_loop = None
        instance._bg_task = None


async def _run_helper_override_async(
    instance: AgentInstance, message: str, registry: "InstanceRegistry",
) -> None:
    """Call the helper override handler, fall back to Claude Code if it returns None."""
    from voice_vibecoder.tools.dispatch import _helper_override

    iid = instance.instance_id
    instance._bg_task = asyncio.current_task()

    try:
        result = await _helper_override(message, instance, registry, registry.user_jwt)
    except asyncio.CancelledError:
        instance._bg_task = None
        registry.update_status(iid, InstanceStatus.IDLE)
        _deliver_result(iid, "Agent task was cancelled.", registry)
        return
    except Exception as e:
        logger.error("Helper override error [%s]: %s", iid, e, exc_info=True)
        result = None

    if result is None:
        # Fall back to Claude Code
        logger.info("Helper override returned None, falling back to Claude Code")
        await _run_agent_async(instance, message, registry)
        return

    instance._bg_task = None
    instance.output_buffer = result

    registry.update_status(iid, InstanceStatus.IDLE)

    _deliver_result(iid, truncate_output(result), registry)


async def _run_agent_async(
    instance: AgentInstance, message: str, registry: "InstanceRegistry",
) -> None:
    import copy
    import os
    from voice_vibecoder.tools.dispatch import _permission_mode, _repo_root, _voice_config
    from voice_vibecoder.tools.file_tree import start_file_tree_updates, stop_file_tree_updates

    iid = instance.instance_id
    instance._bg_task = asyncio.current_task()

    mcp_servers = _load_mcp_servers()

    # Let the embedder inject tokens or mutate MCP server config before the agent runs.
    if _voice_config and _voice_config.pre_agent_hook:
        mcp_servers = copy.deepcopy(mcp_servers)
        _voice_config.pre_agent_hook(mcp_servers, registry.user_jwt)

    # Prepare environment variables for the agent
    # Start with a copy of os.environ to preserve PATH and other essentials
    agent_env = os.environ.copy()
    github_token = os.environ.get("GITHUB_TOKEN")

    if github_token:
        agent_env["GH_TOKEN"] = github_token
        agent_env["GIT_TERMINAL_PROMPT"] = "0"

        # Use GIT_CONFIG env vars to configure git auth
        agent_env["GIT_CONFIG_COUNT"] = "2"
        # Rewrite SSH URLs to HTTPS so credential helper works
        agent_env["GIT_CONFIG_KEY_0"] = "url.https://github.com/.insteadOf"
        agent_env["GIT_CONFIG_VALUE_0"] = "git@github.com:"
        # Use gh CLI as credential helper (reads GH_TOKEN automatically)
        agent_env["GIT_CONFIG_KEY_1"] = "credential.https://github.com.helper"
        agent_env["GIT_CONFIG_VALUE_1"] = "!gh auth git-credential"

    # Ensure standard paths are in PATH for finding gh and other system binaries
    current_path = agent_env.get("PATH", "")
    standard_paths = ["/usr/local/bin", "/usr/bin", "/bin"]
    path_parts = current_path.split(":") if current_path else []
    for std_path in standard_paths:
        if std_path not in path_parts:
            path_parts.append(std_path)
    agent_env["PATH"] = ":".join(path_parts)

    runner = _create_runner(instance.agent_type, _permission_mode, mcp_servers, env=agent_env)

    # Start periodic file tree updates while agent is running (skip for session instances)
    is_session = instance.instance_type == InstanceType.SESSION
    if not is_session:
        start_file_tree_updates(iid, instance.worktree_path, registry)

    def on_output(output: AgentOutput) -> None:
        if registry.on_output:
            registry.on_output(iid, f"{output.category}:{output.content}")
        instance.last_activity = output.content[:200]
        instance.output_buffer += output.content + "\n"
        if len(instance.output_buffer) > 50_000:
            instance.output_buffer = instance.output_buffer[-30_000:]

    async def can_use_tool(tool_name: str, input_data: dict, context: Any) -> Any:
        if tool_name == "AskUserQuestion":
            return await _ask_user_via_voice(instance, input_data)
        if tool_name == "ExitPlanMode":
            return await _approve_plan_via_voice(instance, input_data)
        return True  # auto-approve everything else

    # Use repo root as cwd for session instances (they have no worktree)
    cwd = str(instance.worktree_path) if instance.worktree_path else str(_repo_root)

    try:
        result = await runner.run(
            message=message,
            cwd=cwd,
            session_id=instance.session_id or None,
            on_output=on_output,
            can_use_tool=can_use_tool,
        )
    except asyncio.CancelledError:
        instance._bg_task = None
        if not is_session:
            stop_file_tree_updates(iid)
        registry.update_status(iid, InstanceStatus.IDLE)
        _deliver_result(iid, "Agent task was cancelled.", registry)
        return
    except Exception as e:
        logger.error("Agent error [%s]: %s", iid, e, exc_info=True)
        instance._bg_task = None
        if not is_session:
            stop_file_tree_updates(iid)
        registry.update_status(iid, InstanceStatus.ERROR)
        _deliver_result(iid, str(e), registry)
        return

    instance._bg_task = None
    if not is_session:
        stop_file_tree_updates(iid)

    # Fire one final tree update so the UI shows the final state (skip for sessions)
    from voice_vibecoder.tools.file_tree import get_file_tree
    if registry.on_ui_command and not is_session:
        try:
            tree_data = get_file_tree(instance.worktree_path)
            registry.on_ui_command(iid, "file_tree", tree_data)
        except Exception:
            pass

    if result.session_id:
        instance.session_id = result.session_id
        instance.first_call = False
        registry._save_state_now()  # session_id must persist immediately
    instance.output_buffer = result.text

    registry.update_status(iid, InstanceStatus.IDLE)

    if not result.text:
        _deliver_result(iid, "Agent completed the task with no output.", registry)
    else:
        _deliver_result(iid, truncate_output(result.text), registry)


def _deliver_result(
    instance_id: str, result: str, registry: "InstanceRegistry | None" = None,
) -> None:
    if registry is None:
        from voice_vibecoder.tools.dispatch import _registry
        registry = _registry

    if registry and registry.on_task_complete:
        registry.on_task_complete(instance_id, result)


def _format_question_for_voice(questions: list[dict]) -> str:
    if not questions:
        return "The agent has a question but no details were provided."
    parts = []
    for q in questions:
        text = q.get("question", "")
        options = q.get("options", [])
        if text:
            parts.append(text)
        if options:
            opt_strs = [f"- {o.get('label', '')}: {o.get('description', '')}" for o in options]
            parts.append("\n".join(opt_strs))
    return "\n".join(parts)


async def _wait_for_user_answer(
    instance: AgentInstance,
    tool_name: str,
    formatted_text: str,
    input_data: dict[str, Any],
) -> str | None:
    """Common logic: set up a Future, notify UI, and wait for the user's answer."""
    from voice_vibecoder.tools.dispatch import _registry

    iid = instance.instance_id

    loop = asyncio.get_running_loop()
    future: asyncio.Future[str] = loop.create_future()
    instance.pending_answer = future
    instance.pending_question = {
        "tool": tool_name,
        "input": input_data,
        "formatted": formatted_text,
    }

    if _registry:
        if _registry.on_output:
            _registry.on_output(iid, f"question:{formatted_text}")
        _registry.update_status(iid, InstanceStatus.WAITING_INPUT)
        if _registry.on_question:
            _registry.on_question(iid, instance.pending_question)

    try:
        answer = await asyncio.wait_for(future, timeout=ANSWER_TIMEOUT)
    except (asyncio.TimeoutError, asyncio.CancelledError):
        instance.pending_answer = None
        instance.pending_question = None
        if _registry:
            _registry.update_status(iid, InstanceStatus.RUNNING)
        return None

    instance.pending_answer = None
    instance.pending_question = None
    if _registry:
        _registry.update_status(iid, InstanceStatus.RUNNING)

    return answer


async def _ask_user_via_voice(
    instance: AgentInstance, input_data: dict[str, Any],
) -> str | None:
    """Route AskUserQuestion to voice and wait for the user's answer."""
    questions = input_data.get("questions", [])
    voice_text = _format_question_for_voice(questions)
    return await _wait_for_user_answer(instance, "AskUserQuestion", voice_text, input_data)


async def _approve_plan_via_voice(
    instance: AgentInstance, input_data: dict[str, Any],
) -> str | None:
    """Route ExitPlanMode to voice for plan approval."""
    answer = await _wait_for_user_answer(
        instance, "ExitPlanMode",
        "The agent has a plan ready. Should it proceed with the implementation?",
        input_data,
    )
    if answer is None:
        return None

    words = set(answer.lower().strip().split())
    reject_words = {"no", "reject", "nei", "nej", "don't", "ikke", "inte", "nope", "nah"}
    if words & reject_words:
        return None

    return answer
