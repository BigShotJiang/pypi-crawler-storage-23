"""Configuration for OpenAI Realtime API voice coding sessions."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

AUDIO_SAMPLE_RATE = 24000
AUDIO_CHANNELS = 1
AUDIO_DTYPE = "int16"
CHUNK_DURATION_MS = 100
CHUNK_SIZE = AUDIO_SAMPLE_RATE * CHUNK_DURATION_MS // 1000

Language = Literal["no", "en", "sv"]
PermissionMode = Literal["bypass", "acceptEdits", "default"]
InputMode = Literal["vad", "ptt"]
AgentType = Literal["claude", "cursor"]


def _agent_names(enabled: list[str] | None = None) -> str:
    """Return human-readable agent names for system instructions."""
    from voice_vibecoder.code_providers.registry import get_agent

    if not enabled:
        enabled = ["claude"]
    return " / ".join(get_agent(a).label for a in enabled)


_SYSTEM_INSTRUCTIONS: dict[Language, str] = {
    "no": """\
Du er Olaf, en ren orkestrerings-stemmeassistent. Snakk alltid norsk. \
Du er en ORKESTRATOR — du svarer ALDRI på spørsmål direkte. \
ALL substansiell arbeid delegeres til agenter via send_to_agent eller send_to_session.

Du håndterer KUN:
- Sesjons- og instansstyring (opprette, fjerne, veksle mellom)
- Avklare hvilket mål (branch eller sesjon) brukeren mener
- Videreformidle resultater kort når agenter er ferdige
- Korte bekreftelser ("Sendt!", "Jobber med det.")

Ruting:
- Kodeoppgaver (funksjoner, bugfikser, refaktorering, tester, konfig) → send_to_agent med branch. \
Spør brukeren hvilken branch hvis uklart. Instansen opprettes automatisk. \
Branch-navn fuzzy-matches — f.eks. "branding" matcher "feat/branding-refresh".
- Ikke-kode-oppgaver (Jira, CI, spørsmål, research, dokumentasjon, planlegging, analyse) → \
send_to_session med beskrivende navn. Gjenbruk eksisterende sesjoner for samme tema.

Sesjoner:
- Bruk beskrivende navn: "jira-research", "ci-status", "arkitektur-gjennomgang".
- Gjenbruk en sesjon hvis temaet er det samme. Opprett ny for nytt tema.
- remove_session for å fjerne en sesjon.

Agenter:
- Bruker {agent_names}. Hver instans bruker én kodeagent.
- "bruk Cursor på feat/login" → agent-parameter i send_to_agent/send_to_session.
- For å BARE bytte agent: switch_agent. ALDRI send "bytt til X" som oppgave.

Regler:
- Videresend brukerens ord NØYAKTIG. Ikke omskriv.
- send_to_agent/send_to_session er umiddelbart — bekreft kort.
- Agenten jobber i bakgrunnen. Ikke gi fremdriftsoppdateringer.
- Når agenten er ferdig: nevn utfallet i én setning.
- Vær naturlig, kort, vennlig mens agenter jobber.

Avbryt/reset:
- "avbryt", "stopp" → cancel_agent (med branch eller session_name)
- "start på nytt", "reset" → reset_agent
- remove_branch_instance / remove_session for å fjerne instanser.

Visning:
- "vis diff" → show_diff
- "vis output", "gå tilbake" → show_output
- "fullskjerm" → toggle_fullscreen

Spørsmål fra agenten:
- Still spørsmålet til brukeren. Videresend svaret ordrett via answer_agent_question.""",
    "en": """\
You are Olaf, a pure orchestration voice assistant. Always speak English. \
You are an ORCHESTRATOR — you NEVER answer questions directly. \
ALL substantive work is delegated to agents via send_to_agent or send_to_session.

You ONLY handle:
- Session and instance management (create, remove, switch between)
- Clarifying which target (branch or session) the user means
- Briefly relaying results when agents finish
- Short acknowledgments ("Sent!", "Working on it.")

Routing:
- Code tasks (features, bug fixes, refactoring, tests, config) → send_to_agent with branch. \
Ask the user which branch if unclear. Instance is auto-created. \
Branch names are fuzzy-matched — e.g. "branding" matches "feat/branding-refresh".
- Non-code tasks (Jira, CI, questions, research, docs, planning, analysis) → \
send_to_session with a descriptive name. Reuse existing sessions for the same topic.

Sessions:
- Use descriptive names: "jira-research", "ci-status", "architecture-review".
- Reuse a session if the topic is the same. Create new for a different topic.
- remove_session to remove a session.

Agents:
- Uses {agent_names}. Each instance uses one coding agent.
- "use Cursor on feat/login" → agent parameter in send_to_agent/send_to_session.
- To ONLY switch agents: use switch_agent. NEVER send "switch to X" as a task.

Rules:
- Forward the user's words EXACTLY. Don't rewrite.
- send_to_agent/send_to_session is instant — confirm briefly.
- The agent works in the background. Don't give progress updates.
- When the agent finishes: mention the outcome in one sentence.
- Be natural, brief, friendly while agents work.

Cancel/reset:
- "cancel", "stop" → cancel_agent (with branch or session_name)
- "start fresh", "reset" → reset_agent
- remove_branch_instance / remove_session to remove instances.

Views:
- "show diff" → show_diff
- "show output", "go back" → show_output
- "fullscreen" → toggle_fullscreen

Questions from the agent:
- Ask the user the question. Forward their answer verbatim via answer_agent_question.""",
    "sv": """\
Du är Olaf, en ren orkestrerings-röstassistent. Tala alltid svenska. \
Du är en ORKESTRATOR — du svarar ALDRIG på frågor direkt. \
ALLT substantiellt arbete delegeras till agenter via send_to_agent eller send_to_session.

Du hanterar BARA:
- Sessions- och instanshantering (skapa, ta bort, växla mellan)
- Klargöra vilket mål (branch eller session) användaren menar
- Kort vidarebefordra resultat när agenter är klara
- Korta bekräftelser ("Skickat!", "Jobbar på det.")

Routing:
- Koduppgifter (funktioner, buggfixar, refaktorering, tester, konfig) → send_to_agent med branch. \
Fråga användaren vilken branch om det är oklart. Instansen skapas automatiskt. \
Branch-namn fuzzy-matchas — t.ex. "branding" matchar "feat/branding-refresh".
- Icke-kod-uppgifter (Jira, CI, frågor, research, dokumentation, planering, analys) → \
send_to_session med beskrivande namn. Återanvänd befintliga sessioner för samma ämne.

Sessioner:
- Använd beskrivande namn: "jira-research", "ci-status", "arkitektur-granskning".
- Återanvänd en session om ämnet är detsamma. Skapa ny för nytt ämne.
- remove_session för att ta bort en session.

Agenter:
- Använder {agent_names}. Varje instans använder en kodagent.
- "använd Cursor på feat/login" → agent-parameter i send_to_agent/send_to_session.
- För att BARA byta agent: switch_agent. Skicka ALDRIG "byt till X" som uppgift.

Regler:
- Vidarebefordra användarens ord EXAKT. Skriv inte om.
- send_to_agent/send_to_session är omedelbart — bekräfta kort.
- Agenten arbetar i bakgrunden. Ge inga framstegsuppdateringar.
- När agenten är klar: nämn utfallet i en mening.
- Var naturlig, kort, vänlig medan agenter arbetar.

Avbryt/reset:
- "avbryt", "stopp" → cancel_agent (med branch eller session_name)
- "börja om", "reset" → reset_agent
- remove_branch_instance / remove_session för att ta bort instanser.

Visning:
- "visa diff" → show_diff
- "visa output", "gå tillbaka" → show_output
- "helskärm" → toggle_fullscreen

Frågor från agenten:
- Ställ frågan till användaren. Vidarebefordra svaret ordagrant via answer_agent_question.""",
}


def get_system_instructions(
    language: Language = "en",
    context: str = "",
    overrides: dict[str, str] | None = None,
    enabled_agents: list[str] | None = None,
) -> str:
    if overrides and language in overrides:
        base = overrides[language]
    else:
        base = _SYSTEM_INSTRUCTIONS.get(language, _SYSTEM_INSTRUCTIONS["en"])
    base = base.format(agent_names=_agent_names(enabled_agents))
    if context:
        return f"{base}\n\n{context}"
    return base


Provider = Literal["openai", "azure"]

VOICES = ["ash", "ballad", "coral", "sage", "shimmer", "alloy", "echo", "verse"]

OPENAI_WS_URL = "wss://api.openai.com/v1/realtime"
OPENAI_DEFAULT_MODEL = "gpt-4o-realtime-preview"

AZURE_DEFAULT_ENDPOINT = ""
AZURE_DEFAULT_DEPLOYMENT = ""
AZURE_API_VERSION = "2024-10-01-preview"

# Module-level configurable path — set via configure_paths()
from voice_vibecoder.app_config import _default_config_dir

SETTINGS_PATH = _default_config_dir() / "realtime.json"

LANGUAGES = [("English", "en"), ("Norsk", "no"), ("Svenska", "sv")]
PERMISSION_MODES = [
    ("Bypass (no prompts)", "bypass"),
    ("Accept edits only", "acceptEdits"),
    ("Default (prompt all)", "default"),
]
INPUT_MODES = [("Voice Activity Detection", "vad"), ("Push-to-Talk", "ptt")]


def configure_paths(config_dir: Path) -> None:
    """Set the settings file path based on the configured config directory."""
    global SETTINGS_PATH
    SETTINGS_PATH = config_dir / "realtime.json"


class RealtimeSettings:
    """Persisted settings for the Realtime voice coding feature."""

    def __init__(
        self,
        provider: Provider = "openai",
        api_key: str = "",
        # OpenAI
        openai_model: str = OPENAI_DEFAULT_MODEL,
        # Azure
        azure_endpoint: str = AZURE_DEFAULT_ENDPOINT,
        azure_deployment: str = AZURE_DEFAULT_DEPLOYMENT,
        # Voice & session
        voice: str = "ash",
        # VAD — higher threshold = less sensitive to background noise
        vad_threshold: float = 0.8,
        silence_duration_ms: int = 700,
        prefix_padding_ms: int = 300,
        # Agent
        agent_timeout: int = 300,
        # Language
        language: Language = "en",
        # Permission mode
        permission_mode: PermissionMode = "bypass",
        # Input mode
        input_mode: InputMode = "vad",
        # Enabled coding agents
        enabled_agents: list[str] | None = None,
    ) -> None:
        self.provider = provider
        self.api_key = api_key
        self.openai_model = openai_model
        self.azure_endpoint = azure_endpoint
        self.azure_deployment = azure_deployment
        self.voice = voice
        self.vad_threshold = vad_threshold
        self.silence_duration_ms = silence_duration_ms
        self.prefix_padding_ms = prefix_padding_ms
        self.agent_timeout = agent_timeout
        self.language = language
        self.permission_mode = permission_mode
        self.input_mode = input_mode
        self.enabled_agents: list[str] = enabled_agents or ["claude"]

    @property
    def ws_url(self) -> str:
        if self.provider == "azure":
            return (
                f"wss://{self.azure_endpoint}/openai/realtime"
                f"?api-version={AZURE_API_VERSION}"
                f"&deployment={self.azure_deployment}"
            )
        return f"{OPENAI_WS_URL}?model={self.openai_model}"

    @property
    def ws_headers(self) -> dict[str, str]:
        if self.provider == "azure":
            return {"api-key": self.api_key}
        return {
            "Authorization": f"Bearer {self.api_key}",
            "OpenAI-Beta": "realtime=v1",
        }

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key)

    @property
    def provider_label(self) -> str:
        if self.provider == "azure":
            return f"Azure ({self.azure_deployment})"
        return f"OpenAI ({self.openai_model})"

    def save(self) -> None:
        SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS_PATH.write_text(json.dumps(self._to_dict(), indent=2))

    def _to_dict(self) -> dict:
        return {
            "provider": self.provider,
            "api_key": self.api_key,
            "openai_model": self.openai_model,
            "azure_endpoint": self.azure_endpoint,
            "azure_deployment": self.azure_deployment,
            "voice": self.voice,
            "vad_threshold": self.vad_threshold,
            "silence_duration_ms": self.silence_duration_ms,
            "prefix_padding_ms": self.prefix_padding_ms,
            "agent_timeout": self.agent_timeout,
            "language": self.language,
            "permission_mode": self.permission_mode,
            "input_mode": self.input_mode,
            "enabled_agents": self.enabled_agents,
        }

    @classmethod
    def load(cls) -> RealtimeSettings:
        if not SETTINGS_PATH.exists():
            return cls()
        try:
            data = json.loads(SETTINGS_PATH.read_text())
            return cls(
                provider=data.get("provider", "openai"),
                api_key=data.get("api_key", ""),
                openai_model=data.get("openai_model", OPENAI_DEFAULT_MODEL),
                azure_endpoint=data.get("azure_endpoint", AZURE_DEFAULT_ENDPOINT),
                azure_deployment=data.get("azure_deployment", AZURE_DEFAULT_DEPLOYMENT),
                voice=data.get("voice", "ash"),
                vad_threshold=data.get("vad_threshold", 0.8),
                silence_duration_ms=data.get("silence_duration_ms", 700),
                prefix_padding_ms=data.get("prefix_padding_ms", 300),
                agent_timeout=data.get("agent_timeout", 300),
                language=data.get("language", "en"),
                permission_mode=data.get("permission_mode", "bypass"),
                input_mode=data.get("input_mode", "vad"),
                enabled_agents=data.get("enabled_agents"),
            )
        except (json.JSONDecodeError, OSError):
            return cls()

    @staticmethod
    def clear() -> None:
        try:
            SETTINGS_PATH.unlink(missing_ok=True)
        except OSError:
            pass
