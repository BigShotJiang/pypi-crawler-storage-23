"""CLI entry point for the voice coding WebSocket server.

Usage:
    vibecoder-serve --port 8765 --repo /path/to/monorepo -v
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import subprocess
from pathlib import Path

from voice_vibecoder.app_config import VoiceConfig
from voice_vibecoder.config import RealtimeSettings, configure_paths as configure_config_paths
from voice_vibecoder.instances import configure_paths as configure_instance_paths
from voice_vibecoder.worktrees import configure_paths as configure_worktree_paths

logger = logging.getLogger(__name__)


def _detect_git_root() -> Path:
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"],
            stderr=subprocess.DEVNULL,
            text=True,
        )
        return Path(out.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return Path.cwd()


def _apply_env_overrides(settings: RealtimeSettings) -> RealtimeSettings:
    """Override settings with VOICE_* environment variables when present."""
    env_map = {
        "VOICE_PROVIDER": "provider",
        "VOICE_API_KEY": "api_key",
        "VOICE_AZURE_ENDPOINT": "azure_endpoint",
        "VOICE_AZURE_DEPLOYMENT": "azure_deployment",
        "VOICE_LANGUAGE": "language",
        "VOICE_PERMISSION_MODE": "permission_mode",
    }
    applied = []
    for env_var, attr in env_map.items():
        value = os.environ.get(env_var)
        if value:
            setattr(settings, attr, value)
            safe = env_var if "KEY" not in env_var else f"{env_var}=***"
            applied.append(safe)

    if applied:
        logger.info("Env overrides applied: %s", ", ".join(applied))
    return settings


def main(voice_config: VoiceConfig | None = None) -> None:
    parser = argparse.ArgumentParser(description="Voice coding WebSocket server")
    parser.add_argument("--host", default="127.0.0.1", help="Bind address (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8765, help="Port (default: 8765)")
    parser.add_argument("--repo", type=str, default=None, help="Repo root (auto-detects git root)")
    parser.add_argument("-v", "--verbose", action="store_true", help="Debug logging")
    args = parser.parse_args()

    # Clear CLAUDECODE so agent subprocesses don't think they're nested
    os.environ.pop("CLAUDECODE", None)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
    )

    repo_root = Path(args.repo) if args.repo else _detect_git_root()
    config = voice_config or VoiceConfig()

    configure_config_paths(config.config_dir)
    configure_instance_paths(config.data_dir)
    worktrees_env = os.environ.get("VOICE_WORKTREES_DIR")
    worktrees_dir = Path(worktrees_env) if worktrees_env else (config.worktrees_dir or repo_root.parent)
    configure_worktree_paths(worktrees_dir)

    # Load settings from file, then override with env vars (for container deployment)
    settings = RealtimeSettings.load()
    settings = _apply_env_overrides(settings)

    from voice_vibecoder.server import serve

    asyncio.run(serve(
        host=args.host,
        port=args.port,
        repo_root=repo_root,
        voice_config=config,
        settings=settings,
    ))


if __name__ == "__main__":
    main()
