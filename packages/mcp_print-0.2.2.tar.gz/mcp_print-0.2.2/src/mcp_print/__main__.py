"""Allow running with `python -m mcp_print`."""

from mcp_print.server import main

main()
