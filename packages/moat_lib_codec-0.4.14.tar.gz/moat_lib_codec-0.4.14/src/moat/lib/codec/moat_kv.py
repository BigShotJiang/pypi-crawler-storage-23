"""
Alias for moat-kv legacy
"""

from __future__ import annotations

from moat.lib.codec.moat_msgpack import Codec  # noqa:F401
