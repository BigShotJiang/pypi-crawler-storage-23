"""Tests for enhanced model features: type coercion, computed properties, classifications."""

from datetime import datetime, timedelta

import pytest

from uma_api.models import (
    ArrayStatus,
    CollectorDetails,
    CollectorStatus,
    ContainerInfo,
    DiskInfo,
    DiskSettings,
    FanInfo,
    FlashDriveInfo,
    GPUInfo,
    NetworkInterface,
    NotificationCounts,
    NotificationOverview,
    NotificationsResponse,
    ParityCheckRecord,
    ParityHistory,
    ParitySchedule,
    PluginUpdateInfo,
    PluginUpdatesResult,
    ShareInfo,
    SMARTAttribute,
    SystemInfo,
    UPSInfo,
    VMInfo,
    ZFSPool,
)

# ────────────────────────────────────────────────────────
# Type Coercion (CoercedFloat / CoercedInt)
# ────────────────────────────────────────────────────────


class TestCoercedFloat:
    """Tests for CoercedFloat type coercion via Pydantic BeforeValidator."""

    def test_float_passthrough(self):
        info = SystemInfo(cpu_usage_percent=45.2)
        assert info.cpu_usage_percent == 45.2

    def test_int_to_float(self):
        info = SystemInfo(cpu_usage_percent=45)
        assert info.cpu_usage_percent == 45.0
        assert isinstance(info.cpu_usage_percent, float)

    def test_string_to_float(self):
        info = SystemInfo(cpu_usage_percent="45.2")
        assert info.cpu_usage_percent == 45.2

    def test_empty_string_to_none(self):
        info = SystemInfo(cpu_usage_percent="")
        assert info.cpu_usage_percent is None

    def test_dash_to_none(self):
        info = SystemInfo(cpu_usage_percent="-")
        assert info.cpu_usage_percent is None

    def test_none_passthrough(self):
        info = SystemInfo(cpu_usage_percent=None)
        assert info.cpu_usage_percent is None

    def test_whitespace_string_to_none(self):
        info = SystemInfo(cpu_usage_percent="  ")
        assert info.cpu_usage_percent is None

    def test_string_with_whitespace(self):
        info = SystemInfo(cpu_usage_percent="  45.2  ")
        assert info.cpu_usage_percent == 45.2

    def test_unparseable_string_to_none(self):
        info = SystemInfo(cpu_usage_percent="N/A")
        assert info.cpu_usage_percent is None


class TestCoercedInt:
    """Tests for CoercedInt type coercion via Pydantic BeforeValidator."""

    def test_int_passthrough(self):
        info = SystemInfo(cpu_cores=8)
        assert info.cpu_cores == 8

    def test_float_to_int(self):
        info = SystemInfo(cpu_cores=8.0)
        assert info.cpu_cores == 8
        assert isinstance(info.cpu_cores, int)

    def test_string_to_int(self):
        info = SystemInfo(cpu_cores="8")
        assert info.cpu_cores == 8

    def test_float_string_to_int(self):
        info = SystemInfo(cpu_cores="8.5")
        assert info.cpu_cores == 8

    def test_empty_string_to_none(self):
        info = SystemInfo(cpu_cores="")
        assert info.cpu_cores is None

    def test_dash_to_none(self):
        info = SystemInfo(cpu_cores="-")
        assert info.cpu_cores is None

    def test_none_passthrough(self):
        info = SystemInfo(cpu_cores=None)
        assert info.cpu_cores is None

    def test_unparseable_string_to_none(self):
        info = SystemInfo(cpu_cores="N/A")
        assert info.cpu_cores is None

    def test_bool_excluded(self):
        """Booleans should not be treated as ints."""
        info = SystemInfo(cpu_cores=True)
        assert info.cpu_cores is not True  # noqa: E712


# ────────────────────────────────────────────────────────
# FanInfo
# ────────────────────────────────────────────────────────


class TestFanInfo:
    """Tests for FanInfo.normalized_name property."""

    def test_normalized_name_strips_hwmon_prefix(self):
        fan = FanInfo(name="hwmon2/fan1", rpm=1200)
        assert fan.normalized_name == "fan1"

    def test_normalized_name_strips_chip_prefix(self):
        fan = FanInfo(name="it8688/fan3", rpm=900)
        assert fan.normalized_name == "fan3"

    def test_normalized_name_no_prefix(self):
        fan = FanInfo(name="CPU Fan", rpm=1500)
        assert fan.normalized_name == "CPU Fan"

    def test_normalized_name_none(self):
        fan = FanInfo(name=None, rpm=0)
        assert fan.normalized_name is None

    def test_normalized_name_multiple_slashes(self):
        fan = FanInfo(name="nct6798/hwmon3/fan2", rpm=800)
        assert fan.normalized_name == "fan2"

    def test_normalized_name_underscore_hwmon_prefix(self):
        fan = FanInfo(name="hwmon4_fan5", rpm=1464)
        assert fan.normalized_name == "fan5"

    def test_normalized_name_underscore_it_prefix(self):
        fan = FanInfo(name="it8688_fan3", rpm=900)
        assert fan.normalized_name == "fan3"


# ────────────────────────────────────────────────────────
# SystemInfo
# ────────────────────────────────────────────────────────


class TestSystemInfoUptime:
    """Tests for SystemInfo uptime decomposition properties."""

    def test_uptime_days(self):
        info = SystemInfo(uptime_seconds=90061)
        assert info.uptime_days == 1

    def test_uptime_hours(self):
        info = SystemInfo(uptime_seconds=90061)
        assert info.uptime_hours == 1

    def test_uptime_minutes(self):
        info = SystemInfo(uptime_seconds=90061)
        assert info.uptime_minutes == 1

    def test_uptime_none_when_no_seconds(self):
        info = SystemInfo()
        assert info.uptime_days is None
        assert info.uptime_hours is None
        assert info.uptime_minutes is None

    def test_uptime_zero(self):
        info = SystemInfo(uptime_seconds=0)
        assert info.uptime_days == 0
        assert info.uptime_hours == 0
        assert info.uptime_minutes == 0

    def test_uptime_full_decomposition(self):
        # 2 days, 3 hours, 15 minutes, 30 seconds
        seconds = 2 * 86400 + 3 * 3600 + 15 * 60 + 30
        info = SystemInfo(uptime_seconds=seconds)
        assert info.uptime_days == 2
        assert info.uptime_hours == 3
        assert info.uptime_minutes == 15


class TestSystemInfoCPUCorrection:
    """Tests for SystemInfo._correct_cpu_cores model validator."""

    def test_cpu_cores_corrected_when_per_core_has_more(self):
        per_core = {str(i): 25.0 for i in range(16)}
        info = SystemInfo(cpu_cores=8, cpu_per_core_usage=per_core)
        assert info.cpu_cores == 16

    def test_cpu_cores_not_changed_when_matching(self):
        per_core = {str(i): 25.0 for i in range(8)}
        info = SystemInfo(cpu_cores=8, cpu_per_core_usage=per_core)
        assert info.cpu_cores == 8

    def test_cpu_cores_not_changed_when_no_per_core(self):
        info = SystemInfo(cpu_cores=8)
        assert info.cpu_cores == 8

    def test_cpu_cores_not_changed_when_fewer_per_core(self):
        per_core = {str(i): 25.0 for i in range(4)}
        info = SystemInfo(cpu_cores=8, cpu_per_core_usage=per_core)
        assert info.cpu_cores == 8

    def test_cpu_cores_string_coerced_then_corrected(self):
        per_core = {str(i): 25.0 for i in range(12)}
        info = SystemInfo(cpu_cores="6", cpu_per_core_usage=per_core)
        assert info.cpu_cores == 12


# ────────────────────────────────────────────────────────
# ArrayStatus
# ────────────────────────────────────────────────────────


class TestArrayStatusComputedProperties:
    """Tests for ArrayStatus computed properties."""

    def test_computed_used_percent_from_api(self):
        status = ArrayStatus(used_percent=42.5)
        assert status.computed_used_percent == 42.5

    def test_computed_used_percent_from_bytes(self):
        status = ArrayStatus(total_bytes=1000, used_bytes=250)
        assert status.computed_used_percent == 25.0

    def test_computed_used_percent_none_when_insufficient(self):
        status = ArrayStatus()
        assert status.computed_used_percent is None

    def test_computed_used_percent_zero_total(self):
        status = ArrayStatus(total_bytes=0, used_bytes=0)
        assert status.computed_used_percent is None

    def test_is_parity_check_running_true(self):
        for s in ("running", "checking", "in progress"):
            status = ArrayStatus(parity_check_status=s)
            assert status.is_parity_check_running is True

    def test_is_parity_check_running_false(self):
        status = ArrayStatus(parity_check_status="idle")
        assert status.is_parity_check_running is False

    def test_is_parity_check_running_none(self):
        status = ArrayStatus()
        assert status.is_parity_check_running is False

    def test_is_parity_check_stuck_false_when_not_running(self):
        status = ArrayStatus(parity_check_status="idle")
        assert status.is_parity_check_stuck is False

    def test_is_parity_check_stuck_false_when_high_progress(self):
        """Progress >= 95% but < 100% should be considered stuck."""
        status = ArrayStatus(parity_check_status="running", parity_check_progress=95.0)
        assert status.is_parity_check_stuck is True

    def test_is_parity_check_stuck_true_at_97(self):
        status = ArrayStatus(parity_check_status="running", parity_check_progress=97.0)
        assert status.is_parity_check_stuck is True

    def test_is_parity_check_stuck_false_at_100(self):
        status = ArrayStatus(parity_check_status="running", parity_check_progress=100.0)
        assert status.is_parity_check_stuck is False

    def test_is_parity_check_stuck_false_low_progress(self):
        status = ArrayStatus(parity_check_status="running", parity_check_progress=50.0)
        assert status.is_parity_check_stuck is False

    def test_string_coercion_on_numeric_fields(self):
        status = ArrayStatus(
            total_bytes="10000",
            used_bytes="2500",
            used_percent="25.0",
            parity_check_progress="50.5",
        )
        assert status.total_bytes == 10000
        assert status.used_bytes == 2500
        assert status.used_percent == 25.0
        assert status.parity_check_progress == 50.5


# ────────────────────────────────────────────────────────
# DiskInfo
# ────────────────────────────────────────────────────────


class TestDiskInfoComputedProperties:
    """Tests for DiskInfo computed and classification properties."""

    def test_computed_used_percent_from_api(self):
        disk = DiskInfo(usage_percent=42.5)
        assert disk.computed_used_percent == 42.5

    def test_computed_used_percent_from_bytes(self):
        disk = DiskInfo(size_bytes=1000, used_bytes=250)
        assert disk.computed_used_percent == 25.0

    def test_computed_used_percent_none(self):
        disk = DiskInfo()
        assert disk.computed_used_percent is None


class TestDiskInfoClassification:
    """Tests for DiskInfo classification properties."""

    def test_is_physical_data_disk(self):
        disk = DiskInfo(role="data")
        assert disk.is_physical is True

    def test_is_physical_parity_disk(self):
        disk = DiskInfo(role="parity")
        assert disk.is_physical is True

    def test_is_physical_cache_disk(self):
        disk = DiskInfo(role="cache")
        assert disk.is_physical is True

    def test_is_not_physical_docker_vdisk(self):
        disk = DiskInfo(role="docker_vdisk")
        assert disk.is_physical is False

    def test_is_not_physical_log(self):
        disk = DiskInfo(role="log")
        assert disk.is_physical is False

    def test_is_physical_none_role(self):
        disk = DiskInfo(role=None)
        assert disk.is_physical is True

    def test_is_ssd_by_device(self):
        disk = DiskInfo(device="/dev/nvme0n1")
        assert disk.is_ssd is True

    def test_is_ssd_by_model(self):
        disk = DiskInfo(model="Samsung SSD 870 EVO")
        assert disk.is_ssd is True

    def test_is_ssd_by_model_nvme(self):
        disk = DiskInfo(model="WD Black NVMe 1TB")
        assert disk.is_ssd is True

    def test_is_ssd_by_smart_rotation_rate(self):
        attr = SMARTAttribute(id=1, name="rotation_rate", raw_value="0")
        disk = DiskInfo(smart_attributes={"rotation_rate": attr})
        assert disk.is_ssd is True

    def test_is_not_ssd_hdd(self):
        disk = DiskInfo(device="/dev/sda", model="Seagate Barracuda 4TB")
        assert disk.is_ssd is False

    def test_is_standby(self):
        disk = DiskInfo(spin_state="standby")
        assert disk.is_standby is True

    def test_is_not_standby(self):
        disk = DiskInfo(spin_state="active")
        assert disk.is_standby is False

    def test_is_standby_none(self):
        disk = DiskInfo()
        assert disk.is_standby is False

    def test_has_smart_errors_by_count(self):
        disk = DiskInfo(smart_errors=2)
        assert disk.has_smart_errors is True

    def test_has_smart_errors_by_status(self):
        disk = DiskInfo(smart_status="FAILED")
        assert disk.has_smart_errors is True

    def test_no_smart_errors(self):
        disk = DiskInfo(smart_errors=0, smart_status="PASSED")
        assert disk.has_smart_errors is False

    def test_no_smart_errors_none(self):
        disk = DiskInfo()
        assert disk.has_smart_errors is False


class TestDiskInfoTemperature:
    """Tests for DiskInfo temperature evaluation methods."""

    def test_get_temp_thresholds_per_disk(self):
        disk = DiskInfo(temp_warning=45, temp_critical=55)
        w, c = disk.get_temp_thresholds()
        assert w == 45
        assert c == 55

    def test_get_temp_thresholds_from_settings_hdd(self):
        disk = DiskInfo(device="/dev/sda", model="HDD")
        settings = DiskSettings(
            hdd_temp_warning_celsius=40,
            hdd_temp_critical_celsius=50,
            ssd_temp_warning_celsius=55,
            ssd_temp_critical_celsius=65,
        )
        w, c = disk.get_temp_thresholds(settings)
        assert w == 40
        assert c == 50

    def test_get_temp_thresholds_from_settings_ssd(self):
        disk = DiskInfo(device="/dev/nvme0n1")
        settings = DiskSettings(
            hdd_temp_warning_celsius=40,
            hdd_temp_critical_celsius=50,
            ssd_temp_warning_celsius=55,
            ssd_temp_critical_celsius=65,
        )
        w, c = disk.get_temp_thresholds(settings)
        assert w == 55
        assert c == 65

    def test_get_temp_thresholds_per_disk_overrides_settings(self):
        disk = DiskInfo(device="/dev/sda", temp_warning=38, temp_critical=48)
        settings = DiskSettings(hdd_temp_warning_celsius=40, hdd_temp_critical_celsius=50)
        w, c = disk.get_temp_thresholds(settings)
        assert w == 38
        assert c == 48

    def test_get_temp_thresholds_no_settings_no_overrides(self):
        disk = DiskInfo()
        w, c = disk.get_temp_thresholds()
        assert w is None
        assert c is None

    def test_temperature_status_normal(self):
        disk = DiskInfo(temperature_celsius=30.0, temp_warning=45, temp_critical=55)
        assert disk.temperature_status() == "normal"

    def test_temperature_status_warning(self):
        disk = DiskInfo(temperature_celsius=50.0, temp_warning=45, temp_critical=55)
        assert disk.temperature_status() == "warning"

    def test_temperature_status_critical(self):
        disk = DiskInfo(temperature_celsius=60.0, temp_warning=45, temp_critical=55)
        assert disk.temperature_status() == "critical"

    def test_temperature_status_no_temp(self):
        disk = DiskInfo(temp_warning=45, temp_critical=55)
        assert disk.temperature_status() == "normal"

    def test_temperature_status_no_thresholds(self):
        disk = DiskInfo(temperature_celsius=100.0)
        assert disk.temperature_status() == "normal"

    def test_temperature_status_with_settings(self):
        disk = DiskInfo(device="/dev/sda", model="HDD", temperature_celsius=42.0)
        settings = DiskSettings(hdd_temp_warning_celsius=40, hdd_temp_critical_celsius=50)
        assert disk.temperature_status(settings) == "warning"

    def test_temperature_status_at_exact_threshold(self):
        disk = DiskInfo(temperature_celsius=45.0, temp_warning=45, temp_critical=55)
        assert disk.temperature_status() == "warning"


# ────────────────────────────────────────────────────────
# ContainerInfo / VMInfo string coercion
# ────────────────────────────────────────────────────────


class TestContainerInfoCoercion:
    """Test that ContainerInfo accepts string numeric fields."""

    def test_string_cpu_percent(self):
        c = ContainerInfo(cpu_percent="12.5")
        assert c.cpu_percent == 12.5

    def test_string_memory_bytes(self):
        c = ContainerInfo(memory_usage_bytes="1048576")
        assert c.memory_usage_bytes == 1048576


class TestVMInfoCoercion:
    """Test that VMInfo accepts string numeric fields."""

    def test_string_cpu_count(self):
        vm = VMInfo(cpu_count="4")
        assert vm.cpu_count == 4

    def test_string_memory_bytes(self):
        vm = VMInfo(memory_allocated_bytes="8589934592")
        assert vm.memory_allocated_bytes == 8589934592


# ────────────────────────────────────────────────────────
# ShareInfo
# ────────────────────────────────────────────────────────


class TestShareInfoComputedProperties:
    """Tests for ShareInfo computed properties."""

    def test_computed_used_percent_from_api(self):
        share = ShareInfo(usage_percent=50.0)
        assert share.computed_used_percent == 50.0

    def test_computed_used_percent_from_bytes(self):
        share = ShareInfo(total_bytes=2000, used_bytes=500)
        assert share.computed_used_percent == 25.0

    def test_computed_used_percent_none(self):
        share = ShareInfo()
        assert share.computed_used_percent is None


# ────────────────────────────────────────────────────────
# NetworkInterface
# ────────────────────────────────────────────────────────


class TestNetworkInterfaceClassification:
    """Tests for NetworkInterface.is_physical property."""

    @pytest.mark.parametrize(
        "name",
        ["eth0", "eth1", "wlan0", "bond0", "eno1", "enp3s0", "br0"],
    )
    def test_physical_interfaces(self, name):
        iface = NetworkInterface(name=name)
        assert iface.is_physical is True

    @pytest.mark.parametrize(
        "name",
        ["docker0", "veth123abc", "virbr0", "lo", "tun0", "shim-br0"],
    )
    def test_virtual_interfaces(self, name):
        iface = NetworkInterface(name=name)
        assert iface.is_physical is False

    def test_none_name(self):
        iface = NetworkInterface(name=None)
        assert iface.is_physical is False


# ────────────────────────────────────────────────────────
# GPUInfo
# ────────────────────────────────────────────────────────


class TestGPUInfoProperties:
    """Tests for GPUInfo computed properties."""

    def test_gpu_temperature_available(self):
        gpu = GPUInfo(temperature_celsius=65.0, cpu_temperature_celsius=45.0)
        assert gpu.gpu_temperature == 65.0

    def test_gpu_temperature_none(self):
        gpu = GPUInfo(cpu_temperature_celsius=45.0)
        assert gpu.gpu_temperature == 45.0

    def test_gpu_temperature_fallback_to_cpu(self):
        """When temperature_celsius is None, fall back to cpu_temperature_celsius."""
        gpu = GPUInfo(cpu_temperature_celsius=55.0)
        assert gpu.gpu_temperature == 55.0

    def test_gpu_temperature_both_none(self):
        gpu = GPUInfo()
        assert gpu.gpu_temperature is None

    def test_string_coercion(self):
        gpu = GPUInfo(
            utilization_gpu_percent="85.5",
            memory_total_bytes="4294967296",
            temperature_celsius="72",
        )
        assert gpu.utilization_gpu_percent == 85.5
        assert gpu.memory_total_bytes == 4294967296
        assert gpu.temperature_celsius == 72.0


# ────────────────────────────────────────────────────────
# UPSInfo
# ────────────────────────────────────────────────────────


class TestUPSInfoProperties:
    """Tests for UPSInfo properties and AliasChoices."""

    def test_runtime_minutes(self):
        ups = UPSInfo(runtime_left_seconds=3600)
        assert ups.runtime_minutes == 60.0

    def test_runtime_minutes_none(self):
        ups = UPSInfo()
        assert ups.runtime_minutes is None

    def test_runtime_minutes_small(self):
        ups = UPSInfo(runtime_left_seconds=90)
        assert ups.runtime_minutes == 1.5

    def test_alias_battery_runtime_seconds(self):
        ups = UPSInfo.model_validate({"battery_runtime_seconds": 600})
        assert ups.runtime_left_seconds == 600
        assert ups.runtime_minutes == 10.0

    def test_alias_runtime_seconds(self):
        ups = UPSInfo.model_validate({"runtime_seconds": 1200})
        assert ups.runtime_left_seconds == 1200
        assert ups.runtime_minutes == 20.0

    def test_primary_field_name(self):
        ups = UPSInfo.model_validate({"runtime_left_seconds": 300})
        assert ups.runtime_left_seconds == 300

    def test_string_coercion(self):
        ups = UPSInfo(
            battery_charge_percent="95.5",
            load_percent="32",
            runtime_left_seconds="1800",
        )
        assert ups.battery_charge_percent == 95.5
        assert ups.load_percent == 32.0
        assert ups.runtime_left_seconds == 1800


# ────────────────────────────────────────────────────────
# NotificationOverview / NotificationsResponse
# ────────────────────────────────────────────────────────


class TestNotificationOverviewProperties:
    """Tests for NotificationOverview.unread_count property."""

    def test_unread_count(self):
        overview = NotificationOverview(unread=NotificationCounts(total=5))
        assert overview.unread_count == 5

    def test_unread_count_zero(self):
        overview = NotificationOverview(unread=NotificationCounts(total=0))
        assert overview.unread_count == 0

    def test_unread_count_none_counts(self):
        overview = NotificationOverview()
        assert overview.unread_count == 0

    def test_unread_count_none_total(self):
        overview = NotificationOverview(unread=NotificationCounts())
        assert overview.unread_count == 0


class TestNotificationsResponseProperties:
    """Tests for NotificationsResponse.unread_count property."""

    def test_unread_count_delegates(self):
        resp = NotificationsResponse(
            overview=NotificationOverview(unread=NotificationCounts(total=3))
        )
        assert resp.unread_count == 3

    def test_unread_count_no_overview(self):
        resp = NotificationsResponse()
        assert resp.unread_count == 0


# ────────────────────────────────────────────────────────
# FlashDriveInfo
# ────────────────────────────────────────────────────────


class TestFlashDriveInfoProperties:
    """Tests for FlashDriveInfo computed properties."""

    def test_computed_used_percent_from_api(self):
        flash = FlashDriveInfo(usage_percent=25.0)
        assert flash.computed_used_percent == 25.0

    def test_computed_used_percent_from_bytes(self):
        flash = FlashDriveInfo(size_bytes=4000, used_bytes=1000)
        assert flash.computed_used_percent == 25.0

    def test_is_healthy_below_threshold(self):
        flash = FlashDriveInfo(usage_percent=50.0)
        assert flash.is_healthy is True

    def test_is_healthy_above_threshold(self):
        flash = FlashDriveInfo(usage_percent=95.0)
        assert flash.is_healthy is False

    def test_is_healthy_at_90_percent(self):
        flash = FlashDriveInfo(usage_percent=90.0)
        assert flash.is_healthy is False

    def test_is_healthy_no_data(self):
        flash = FlashDriveInfo()
        assert flash.is_healthy is True


# ────────────────────────────────────────────────────────
# ParityHistory
# ────────────────────────────────────────────────────────


class TestParityHistoryProperties:
    """Tests for ParityHistory.most_recent property."""

    def test_most_recent_with_records(self):
        records = [
            ParityCheckRecord(action="Parity-Check", status="OK"),
            ParityCheckRecord(action="Parity-Check", status="Errors"),
        ]
        history = ParityHistory(records=records)
        assert history.most_recent is not None
        assert history.most_recent.status == "OK"

    def test_most_recent_empty_records(self):
        history = ParityHistory(records=[])
        assert history.most_recent is None

    def test_most_recent_none_records(self):
        history = ParityHistory()
        assert history.most_recent is None


# ────────────────────────────────────────────────────────
# ZFSPool
# ────────────────────────────────────────────────────────


class TestZFSPoolComputedProperties:
    """Tests for ZFSPool computed properties."""

    def test_computed_used_percent(self):
        pool = ZFSPool(size_bytes=10000, used_bytes=2500)
        assert pool.computed_used_percent == 25.0

    def test_computed_used_percent_none(self):
        pool = ZFSPool()
        assert pool.computed_used_percent is None

    def test_computed_used_percent_zero_size(self):
        pool = ZFSPool(size_bytes=0, used_bytes=0)
        assert pool.computed_used_percent is None

    def test_string_coercion(self):
        pool = ZFSPool(size_bytes="1000000", used_bytes="250000")
        assert pool.size_bytes == 1000000
        assert pool.used_bytes == 250000
        assert pool.computed_used_percent == 25.0


# ────────────────────────────────────────────────────────
# ParitySchedule
# ────────────────────────────────────────────────────────


class TestParityScheduleProperties:
    """Tests for ParitySchedule properties and AliasChoices."""

    def test_is_enabled_explicit(self):
        sched = ParitySchedule(enabled=True)
        assert sched.is_enabled is True

    def test_is_enabled_explicit_false(self):
        sched = ParitySchedule(enabled=False)
        assert sched.is_enabled is False

    def test_is_enabled_from_mode_disabled(self):
        sched = ParitySchedule(mode="disabled")
        assert sched.is_enabled is False

    def test_is_enabled_from_mode_weekly(self):
        sched = ParitySchedule(mode="weekly", day=1, hour=2)
        assert sched.is_enabled is True

    def test_is_enabled_no_data(self):
        sched = ParitySchedule()
        assert sched.is_enabled is False


class TestParityScheduleAliasChoices:
    """Tests for ParitySchedule AliasChoices on fields."""

    def test_mode_alias_schedule_mode(self):
        sched = ParitySchedule.model_validate({"schedule_mode": "weekly"})
        assert sched.mode == "weekly"

    def test_mode_alias_parity_mode(self):
        sched = ParitySchedule.model_validate({"parity_mode": "daily"})
        assert sched.mode == "daily"

    def test_day_alias_day_of_week(self):
        sched = ParitySchedule.model_validate({"day_of_week": 3})
        assert sched.day == 3

    def test_day_alias_weekday(self):
        sched = ParitySchedule.model_validate({"weekday": 5})
        assert sched.day == 5

    def test_hour_alias_schedule_hour(self):
        sched = ParitySchedule.model_validate({"schedule_hour": 14})
        assert sched.hour == 14

    def test_hour_alias_start_hour(self):
        sched = ParitySchedule.model_validate({"start_hour": 22})
        assert sched.hour == 22

    def test_minute_alias_schedule_minute(self):
        sched = ParitySchedule.model_validate({"schedule_minute": 30})
        assert sched.minute == 30

    def test_minute_alias_start_minute(self):
        sched = ParitySchedule.model_validate({"start_minute": 45})
        assert sched.minute == 45

    def test_correcting_alias_write_corrections(self):
        sched = ParitySchedule.model_validate({"write_corrections": True})
        assert sched.correcting is True

    def test_correcting_alias_auto_correct(self):
        sched = ParitySchedule.model_validate({"auto_correct": False})
        assert sched.correcting is False

    def test_enabled_alias_schedule_enabled(self):
        sched = ParitySchedule.model_validate({"schedule_enabled": True})
        assert sched.enabled is True

    def test_enabled_alias_scheduled(self):
        sched = ParitySchedule.model_validate({"scheduled": True})
        assert sched.enabled is True

    def test_day_alias_schedule_day(self):
        sched = ParitySchedule.model_validate({"schedule_day": 2})
        assert sched.day == 2

    def test_day_alias_dayOfWeek(self):
        sched = ParitySchedule.model_validate({"dayOfWeek": 4})
        assert sched.day == 4


class TestParityScheduleNextCheck:
    """Tests for ParitySchedule.next_check_datetime property."""

    def test_daily_next_check(self):
        sched = ParitySchedule(mode="daily", hour=3, minute=0)
        result = sched.next_check_datetime
        assert result is not None
        assert result > datetime.now()  # noqa: DTZ005
        assert result.hour == 3
        assert result.minute == 0

    def test_weekly_next_check(self):
        sched = ParitySchedule(mode="weekly", day=0, hour=2, minute=30)
        result = sched.next_check_datetime
        assert result is not None
        assert result > datetime.now()  # noqa: DTZ005
        assert result.weekday() == 0  # Monday
        assert result.hour == 2
        assert result.minute == 30

    def test_monthly_next_check(self):
        sched = ParitySchedule(mode="monthly", day_of_month=15, hour=1, minute=0)
        result = sched.next_check_datetime
        assert result is not None
        assert result > datetime.now()  # noqa: DTZ005
        assert result.day == 15
        assert result.hour == 1

    def test_disabled_returns_none(self):
        sched = ParitySchedule(mode="disabled")
        assert sched.next_check_datetime is None

    def test_no_mode_returns_none(self):
        sched = ParitySchedule()
        assert sched.next_check_datetime is None

    def test_weekly_no_day_returns_none(self):
        sched = ParitySchedule(mode="weekly", hour=2)
        assert sched.next_check_datetime is None

    def test_daily_result_is_future(self):
        sched = ParitySchedule(mode="daily", hour=3, minute=0)
        result = sched.next_check_datetime
        assert result is not None
        # Should be within 24 hours
        assert result - datetime.now() < timedelta(days=1, seconds=60)  # noqa: DTZ005


# ────────────────────────────────────────────────────────
# CollectorStatus
# ────────────────────────────────────────────────────────


class TestCollectorStatusLookup:
    """Tests for CollectorStatus.get_collector_by_name method."""

    def test_find_existing_collector(self):
        collectors = [
            CollectorDetails(name="system", enabled=True, interval_seconds=30),
            CollectorDetails(name="docker", enabled=True, interval_seconds=60),
        ]
        status = CollectorStatus(collectors=collectors)
        result = status.get_collector_by_name("system")
        assert result is not None
        assert result.name == "system"
        assert result.enabled is True

    def test_case_insensitive_search(self):
        collectors = [CollectorDetails(name="System", enabled=True)]
        status = CollectorStatus(collectors=collectors)
        assert status.get_collector_by_name("system") is not None
        assert status.get_collector_by_name("SYSTEM") is not None

    def test_not_found(self):
        collectors = [CollectorDetails(name="system", enabled=True)]
        status = CollectorStatus(collectors=collectors)
        assert status.get_collector_by_name("nonexistent") is None

    def test_none_collectors(self):
        status = CollectorStatus()
        assert status.get_collector_by_name("system") is None


# ────────────────────────────────────────────────────────
# PluginUpdatesResult
# ────────────────────────────────────────────────────────


class TestPluginUpdatesResultProperties:
    """Tests for PluginUpdatesResult.update_count property."""

    def test_update_count_from_count_field(self):
        result = PluginUpdatesResult(count=3)
        assert result.update_count == 3

    def test_update_count_from_list(self):
        plugins = [
            PluginUpdateInfo(name="plugin1", update_available=True),
            PluginUpdateInfo(name="plugin2", update_available=True),
        ]
        result = PluginUpdatesResult(plugins_with_updates=plugins)
        assert result.update_count == 2

    def test_update_count_zero(self):
        result = PluginUpdatesResult()
        assert result.update_count == 0

    def test_update_count_prefers_count_field(self):
        plugins = [PluginUpdateInfo(name="plugin1")]
        result = PluginUpdatesResult(count=5, plugins_with_updates=plugins)
        assert result.update_count == 5


# ────────────────────────────────────────────────────────
# DiskSettings string coercion
# ────────────────────────────────────────────────────────


class TestDiskSettingsCoercion:
    """Tests for DiskSettings string coercion."""

    def test_string_thresholds(self):
        settings = DiskSettings(
            hdd_temp_warning_celsius="45",
            hdd_temp_critical_celsius="55",
            ssd_temp_warning_celsius="55",
            ssd_temp_critical_celsius="65",
        )
        assert settings.hdd_temp_warning_celsius == 45
        assert settings.hdd_temp_critical_celsius == 55
        assert settings.ssd_temp_warning_celsius == 55
        assert settings.ssd_temp_critical_celsius == 65

    def test_dash_thresholds(self):
        settings = DiskSettings(
            hdd_temp_warning_celsius="-",
            hdd_temp_critical_celsius="-",
        )
        assert settings.hdd_temp_warning_celsius is None
        assert settings.hdd_temp_critical_celsius is None
