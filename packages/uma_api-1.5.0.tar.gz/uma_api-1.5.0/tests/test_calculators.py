"""Tests for calculators module: EnergyIntegrator, RateCalculator, parse_timestamp."""

from datetime import datetime

from uma_api.calculators import EnergyIntegrator, RateCalculator, parse_timestamp


class TestEnergyIntegrator:
    """Tests for EnergyIntegrator trapezoidal integration."""

    def test_basic_integration(self):
        integrator = EnergyIntegrator()
        integrator.add_sample(100.0, 1000.0)
        integrator.add_sample(100.0, 2000.0)
        # 100W * 1000s / 3600 = 27.78 Wh
        assert abs(integrator.total_wh - 27.778) < 0.01

    def test_trapezoidal_integration(self):
        integrator = EnergyIntegrator()
        integrator.add_sample(100.0, 1000.0)
        integrator.add_sample(120.0, 2000.0)
        # avg(100, 120) = 110W * 1000s / 3600 = 30.56 Wh
        assert abs(integrator.total_wh - 30.556) < 0.01

    def test_first_sample_no_integration(self):
        integrator = EnergyIntegrator()
        integrator.add_sample(100.0, 1000.0)
        assert integrator.total_wh == 0.0

    def test_cumulative_samples(self):
        integrator = EnergyIntegrator()
        integrator.add_sample(100.0, 0.0)
        integrator.add_sample(100.0, 3600.0)  # 100 Wh
        integrator.add_sample(200.0, 7200.0)  # avg 150W * 1h = 150 Wh
        assert abs(integrator.total_wh - 250.0) < 0.01

    def test_stale_threshold_resets_series(self):
        integrator = EnergyIntegrator(stale_threshold_seconds=60.0)
        integrator.add_sample(100.0, 0.0)
        integrator.add_sample(100.0, 30.0)  # within threshold
        wh_after_first = integrator.total_wh
        # Jump beyond stale threshold
        integrator.add_sample(100.0, 200.0)  # 170s gap > 60s
        # Should not add energy for this gap
        assert integrator.total_wh == wh_after_first

    def test_reset(self):
        integrator = EnergyIntegrator()
        integrator.add_sample(100.0, 0.0)
        integrator.add_sample(100.0, 3600.0)
        assert integrator.total_wh > 0
        integrator.reset()
        assert integrator.total_wh == 0.0

    def test_zero_time_delta(self):
        """Same timestamp should not add energy."""
        integrator = EnergyIntegrator()
        integrator.add_sample(100.0, 1000.0)
        integrator.add_sample(200.0, 1000.0)  # dt=0
        assert integrator.total_wh == 0.0

    def test_negative_time_delta(self):
        """Backward timestamp should not add energy."""
        integrator = EnergyIntegrator()
        integrator.add_sample(100.0, 2000.0)
        integrator.add_sample(200.0, 1000.0)  # dt<0
        assert integrator.total_wh == 0.0

    def test_custom_stale_threshold(self):
        integrator = EnergyIntegrator(stale_threshold_seconds=10.0)
        integrator.add_sample(100.0, 0.0)
        integrator.add_sample(100.0, 5.0)  # within 10s
        assert integrator.total_wh > 0
        integrator.reset()
        integrator.add_sample(100.0, 0.0)
        integrator.add_sample(100.0, 15.0)  # beyond 10s
        assert integrator.total_wh == 0.0


class TestRateCalculator:
    """Tests for RateCalculator byte-counter rate calculation."""

    def test_basic_rate(self):
        calc = RateCalculator()
        calc.add_sample(1000, 1000.0)
        calc.add_sample(2000, 2000.0)
        # 1000 bytes / 1000s * 8 / 1000 = 0.008 kbps
        assert abs(calc.rate_kbps - 0.008) < 0.001

    def test_first_sample_zero_rate(self):
        calc = RateCalculator()
        calc.add_sample(1000, 1000.0)
        assert calc.rate_kbps == 0.0

    def test_higher_rate(self):
        calc = RateCalculator()
        calc.add_sample(0, 0.0)
        calc.add_sample(125000, 1.0)  # 125000 bytes/s = 1000 kbps
        assert abs(calc.rate_kbps - 1000.0) < 0.01

    def test_counter_wrap_32bit(self):
        calc = RateCalculator()
        max_32 = 2**32
        calc.add_sample(max_32 - 100, 0.0)
        calc.add_sample(50, 1.0)  # Wrapped: actual delta = 150
        # 150 bytes / 1s * 8 / 1000 = 1.2 kbps
        assert abs(calc.rate_kbps - 1.2) < 0.01

    def test_counter_wrap_64bit(self):
        calc = RateCalculator()
        max_32 = 2**32
        # Use a value > 32-bit max to trigger 64-bit wrap detection
        calc.add_sample(max_32 + 100, 0.0)
        calc.add_sample(50, 1.0)  # Wrapped 64-bit
        # Delta = 50 - (max_32+100) + 2**64
        assert calc.rate_kbps > 0

    def test_reset(self):
        calc = RateCalculator()
        calc.add_sample(0, 0.0)
        calc.add_sample(1000, 1.0)
        assert calc.rate_kbps > 0
        calc.reset()
        assert calc.rate_kbps == 0.0

    def test_zero_time_delta(self):
        calc = RateCalculator()
        calc.add_sample(0, 1.0)
        calc.add_sample(1000, 1.0)  # dt=0
        assert calc.rate_kbps == 0.0


class TestParseTimestamp:
    """Tests for parse_timestamp function."""

    def test_iso_8601(self):
        result = parse_timestamp("2024-01-15T10:30:00")
        assert result is not None
        assert result.year == 2024
        assert result.month == 1
        assert result.day == 15
        assert result.hour == 10
        assert result.minute == 30

    def test_iso_8601_with_timezone(self):
        result = parse_timestamp("2024-01-15T10:30:00+00:00")
        assert result is not None
        assert result.year == 2024

    def test_unix_timestamp_seconds(self):
        # 2024-01-15 ~10:30 UTC
        result = parse_timestamp("1705312200")
        assert result is not None
        assert isinstance(result, datetime)

    def test_unix_timestamp_milliseconds(self):
        result = parse_timestamp("1705312200000")
        assert result is not None
        assert isinstance(result, datetime)

    def test_empty_string(self):
        assert parse_timestamp("") is None

    def test_none_input(self):
        assert parse_timestamp(None) is None  # type: ignore[arg-type]

    def test_non_string_input(self):
        assert parse_timestamp(12345) is None  # type: ignore[arg-type]

    def test_garbage_string(self):
        assert parse_timestamp("not-a-timestamp") is None

    def test_whitespace_handling(self):
        result = parse_timestamp("  2024-01-15T10:30:00  ")
        assert result is not None
        assert result.year == 2024

    def test_out_of_range_timestamp(self):
        assert parse_timestamp("100") is None  # Too small
