"""Version information for uma-api."""

__version__ = "1.5.0"
