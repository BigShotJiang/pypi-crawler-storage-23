from setuptools import setup
setup(
    name='sunnyday23',
    packages=['sunnyday23'],
    version='2.0.0',
    license='MIT',
    description='Sunny Day',
    author='MM',
    author_email='testbasetra@gmail.com',
    url='https://github.com/MM/sunnyday',
    keywords=['sunnyday23', 'day', 'weather', 'forecast'],
    install_requires=['requests',],
    classifiers=['Development Status :: 3 - Alpha',
                 'Intended Audience :: Developers',
                 'Topic :: Software Development :: Build Tools',
                 'License :: OSI Approved :: MIT License',
                 'Programming Language :: Python :: 3.13',],
)