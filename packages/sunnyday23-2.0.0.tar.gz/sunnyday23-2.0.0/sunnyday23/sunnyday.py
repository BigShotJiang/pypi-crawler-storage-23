import requests

class Weather:
    """
    Weather class
    """
    def __init__(self, apikey, city, lat=None, lon=None):

        if city:
            url = f"http://api.openweathermap.org/data/2.5/forecast?q={city}&APPID={apikey}&units=metric"
            r = requests.get(url)
            self.data = r.json()
        elif lat and lon:
            url = f"http://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&APPID=26631f0f41b95fb9f5ac0df9a8f43c92&units=metric"
            r = requests.get(url)
            self.data = r.json()
        else:
            raise TypeError("Either city or lat/lon must be provided")

        if self.data["cod"] != "200":
            raise ValueError(self.data["message"])

    def next_12h(self):
        return self.data['list'][:4]

    def next_12h_simplified(self):
        simple_data = []
        for dicty in self.data['list'][:4]:
            simple_data.append((dicty['dt_txt'], dicty['main']['temp'], dicty['weather'][0]['description'], dicty['weather'][0]['icon']))

        return simple_data
