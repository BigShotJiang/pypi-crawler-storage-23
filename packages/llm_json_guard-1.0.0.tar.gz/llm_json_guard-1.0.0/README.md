```markdown
# llm-json-guard

Production-safe JSON repair and schema validation for LLM outputs.

Large Language Models frequently return malformed JSON containing:

- Missing quotes  
- Trailing commas  
- Invalid tokens  
- Broken object structures  

This package provides a lightweight wrapper around a production-grade JSON repair and validation API, allowing you to sanitize and enforce schema validation in seconds.

---

## Installation

```bash
pip install llm-json-guard
````

---

## Requirements

* Python 3.8+
* RapidAPI key

Get your RapidAPI key here:
[https://rapidapi.com/scotedflotsincoltd/api/llm-json-sanitizer-schema-guard](https://rapidapi.com/scotedflotsincoltd/api/llm-json-sanitizer-schema-guard)

---

## Basic Usage

```python
from llm_json_guard import LLMJsonGuard

guard = LLMJsonGuard(api_key="YOUR_RAPIDAPI_KEY")

# Sanitize only
sanitized = guard.sanitize("{name: 'Harsh', age: 21,}")
print(sanitized["data"])

# Sanitize + Validate
validated = guard.guard(
    "{name: 'Harsh', age: 21,}",
    {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "number"}
        },
        "required": ["name", "age"]
    }
)

print(validated["data"])
```

---

## API Methods

### sanitize(raw_output)

Repairs malformed JSON and returns safely parsed output.

Returns:

* `success`
* `stage`
* `meta` (repair status + confidence)
* `data`
* `errors`

---

### guard(raw_output, schema)

Repairs malformed JSON and validates it against a JSON Schema.

Returns:

* `validated` stage if schema passes
* `validation_failed` if schema check fails
* structured validation errors

---

## Response Structure

Example successful response:

```json
{
  "success": true,
  "stage": "validated",
  "meta": {
    "repaired": true,
    "confidence": 0.95
  },
  "data": {
    "name": "Harsh",
    "age": 21
  },
  "errors": []
}
```

---

## When To Use

* AI agents generating structured output
* RAG pipelines
* Backend systems consuming LLM JSON
* Automation workflows
* Webhook normalization
* Contract enforcement

If your system depends on structured AI output, this acts as a guardrail between the LLM and your production logic.

---

## License

MIT

```

---