
import pynmrstar
entry = pynmrstar.Entry.from_database("6457")
for sf in entry:
    if "coupling" in sf.name.lower() or "coupling" in sf.category.lower():
        print(f"Found match: Name={sf.name}, Category={sf.category}")
