
import biotite.structure as struc
import sys

print(f"Biotite version: {getattr(struc, '__version__', 'unknown')}")
attrs = [a for a in dir(struc) if 'dihedral' in a.lower()]
print(f"Dihedral-related attributes: {attrs}")
