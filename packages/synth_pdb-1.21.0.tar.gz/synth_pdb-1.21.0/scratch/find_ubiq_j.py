
import pynmrstar
import requests

# Search for ubiquitin entries
url = "https://api.bmrb.io/v3/search/entries?name=ubiquitin"
response = requests.get(url)
data = response.json()

for entry in data.get('entries', []):
    eid = entry['entry_id']
    title = entry['title']
    print(f"Checking entry {eid}: {title}")
    try:
        star_entry = pynmrstar.Entry.from_database(eid)
        for sf in star_entry:
            if sf.category == 'coupling_constants':
                print(f"  >>> FOUND coupling_constants in {eid}")
    except:
        pass
