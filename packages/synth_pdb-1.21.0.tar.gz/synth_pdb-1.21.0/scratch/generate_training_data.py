
import os
import json
import numpy as np
import logging
import time
from concurrent.futures import ProcessPoolExecutor
from synth_pdb.generator import generate_pdb_content
import biotite.structure as struc
import biotite.structure.io.pdb as biotite_pdb
import io

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

def generate_sample(args):
    """
    Generates a single protein structure and extracts ML-ready features.
    """
    length, seed = args
    amino_acids = ["ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE", 
                   "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL"]
    
    # Random sequence
    np.random.seed(seed)
    seq_list = np.random.choice(amino_acids, length)
    sequence_str = "-".join(seq_list)
    
    # Mixed secondary structure
    structures = ["alpha", "beta", "random"]
    ss_type = np.random.choice(structures)
    
    try:
        pdb_content = generate_pdb_content(
            sequence_str=sequence_str,
            structure=f"1-{length}:{ss_type}",
            minimize_energy=True,
            seed=seed
        )
        
        if "REMARK 2  Simulation failed" in pdb_content:
            return None
            
        # Parse with Biotite to get coordinates and features
        f = io.StringIO(pdb_content)
        struct = biotite_pdb.PDBFile.read(f).get_structure(model=1)
        
        # Features for ML:
        # 1. Coordinates (Target)
        coords = struct.coord # Shape (N_atoms, 3)
        
        # 2. Sequence (Input)
        res_names = struct.res_name[struc.get_residue_starts(struct)]
        
        # 3. Backbone masks (to identify CA, N, C, O)
        is_ca = (struct.atom_name == "CA")
        
        return {
            "sequence": res_names.tolist(),
            "coords": coords.tolist(),
            "ca_mask": [bool(b) for b in is_ca],
            "length": int(length)
        }
    except Exception as e:
        logger.error(f"Error generating sample {seed}: {e}")
        return None

def main(num_samples=10, output_dir="training_data"):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        
    logger.info(f"Starting Data Factory: Generating {num_samples} samples...")
    start_time = time.time()
    
    # We use a mix of lengths
    lengths = np.random.randint(10, 30, num_samples)
    seeds = range(num_samples)
    tasks = zip(lengths, seeds)
    
    results = []
    # Note: ProcessPoolExecutor might struggle with OpenMM contexts in some systems,
    # but for small peptides it's usually fine. Serial for high stability.
    for task in tasks:
        res = generate_sample(task)
        if res:
            results.append(res)
            logger.info(f"Generated sample {task[1]} (length {task[0]})")
            
    # Save as JSON (or NPZ for larger datasets)
    output_path = os.path.join(output_dir, "dataset.json")
    with open(output_path, 'w') as f:
        json.dump(results, f)
        
    duration = time.time() - start_time
    logger.info(f"Finished! Generated {len(results)} samples in {duration:.2f}s.")
    logger.info(f"Dataset saved to: {output_path}")

if __name__ == "__main__":
    main(num_samples=5) # Small batch for demonstration
