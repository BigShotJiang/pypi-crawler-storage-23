
from synth_pdb.generator import generate_pdb_content
from synth_pdb.ai.features import extract_quality_features
from synth_pdb.validator import PDBValidator
import logging
import numpy as np

# Configure logging to see validator output
logging.basicConfig(level=logging.DEBUG)

print("Generating 'Good' Alpha Helix...")
pdb_content = generate_pdb_content(length=20, conformation='alpha', minimize_energy=False, optimize_sidechains=False)

print("\nRunning Validator...")
validator = PDBValidator(pdb_content)
validator.validate_all()
violations = validator.get_violations()

print(f"\nTotal Violations: {len(violations)}")
for v in violations[:10]:
    print(v)
    
features = extract_quality_features(pdb_content)
print("\nFeatures:")
names = ["ram_fav", "ram_out", "clash", "bond_len", "bond_ang", "pep_bond", "rg", "b_fac"]
for n, v in zip(names, features):
    print(f"{n}: {v}")
