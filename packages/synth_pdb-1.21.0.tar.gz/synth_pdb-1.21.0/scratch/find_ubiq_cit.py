
import pynmrstar
import requests

# Search for entries by citation title
# Since BMRB doesn't have a direct search by citation title in API, we can try to find common ones.
# Actually, I'll search for 'ubiquitin' and check citations.
url = "https://api.bmrb.io/v3/search/entries?name=ubiquitin"
response = requests.get(url)
data = response.json()

for entry in data.get('entries', []):
    eid = entry['entry_id']
    try:
        star_entry = pynmrstar.Entry.from_database(eid)
        found = False
        for sf in star_entry:
            if sf.category == 'citations':
                title_tag = '_Citation.Title'
                if title_tag in sf:
                    title = sf[title_tag][0]
                    if "Karplus" in title and "ubiquitin" in title.lower():
                        print(f"Entry {eid} matches Karplus citation: {title}")
                        found = True
            if sf.category == 'coupling_constants':
                print(f"  >>> Entry {eid} HAS coupling_constants saveframe!")
                found = True
        if found:
            print(f"Checked entry {eid}")
    except:
        pass
