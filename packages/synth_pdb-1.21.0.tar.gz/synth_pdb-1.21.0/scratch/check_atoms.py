
import biotite.structure.info as info

try:
    res = info.residue("ALA")
    print(f"Atoms in ALA: {res.atom_name}")
except Exception as e:
    print(f"Failed to get residue: {e}")
