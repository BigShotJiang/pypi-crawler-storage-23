
import openmm as mm

print(f"OpenMM Version: {mm.version.version}")
print("Available Platforms:")
for i in range(mm.Platform.getNumPlatforms()):
    p = mm.Platform.getPlatform(i)
    name = p.getName()
    print(f"  - {name}: Speed={p.getSpeed()}")
    
# Check specifically for Metal
try:
    metal = mm.Platform.getPlatformByName("Metal")
    print("\nSUCCESS: 'Metal' platform is available! This supports Apple Silicon (M1/M2/M3/M4).")
except Exception as e:
    print(f"\nNOTE: 'Metal' platform not found ({e}). Acceleration might be limited to CPU or OpenCL.")
