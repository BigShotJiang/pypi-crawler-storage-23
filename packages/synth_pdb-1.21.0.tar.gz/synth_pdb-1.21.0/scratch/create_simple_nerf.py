"""
Create the SIMPLEST possible working version using ipywidgets.interact
This automatically handles layout and updates - no manual Output widgets needed
"""

import json

notebook = {
    "cells": [
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "# 🔬 NeRF Geometry Lab\n",
                "\n",
                "Explore how changing backbone angles (φ, ψ) affects protein structure.\n"
            ]
        },
        
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "# Setup\n",
                "import sys, os\n",
                "IN_COLAB = 'google.colab' in sys.modules\n",
                "if IN_COLAB:\n",
                "    try:\n",
                "        import synth_pdb\n",
                "    except ImportError:\n",
                "        !pip install -q synth-pdb\n",
                "else:\n",
                "    sys.path.append(os.path.abspath('../../'))\n",
                "print('✅ Ready')"
            ]
        },
        
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "# Imports\n",
                "from ipywidgets import interact, FloatSlider\n",
                "import numpy as np\n",
                "import py3Dmol\n",
                "import plotly.graph_objects as go\n",
                "from plotly.subplots import make_subplots\n",
                "from synth_pdb import PeptideGenerator\n",
                "from biotite.structure.io.pdb import PDBFile\n",
                "import io\n",
                "\n",
                "gen = PeptideGenerator('ALA-ALA-ALA-ALA-ALA-ALA-ALA-ALA-ALA-ALA')\n",
                "print('✅ Loaded')"
            ]
        },
        
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Interactive Explorer\n",
                "\n",
                "Use the sliders below to modify the central residue's backbone angles.\n"
            ]
        },
        
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "@interact(phi=FloatSlider(min=-180, max=180, step=10, value=0, description='Δφ'),\n",
                "          psi=FloatSlider(min=-180, max=180, step=10, value=0, description='Δψ'))\n",
                "def explore(phi=0, psi=0):\n",
                "    # Generate structure\n",
                "    phis = [-57.0] * 10\n",
                "    psis = [-47.0] * 10\n",
                "    phis[4] += phi\n",
                "    psis[4] += psi\n",
                "    res = gen.generate(phi_list=phis, psi_list=psis)\n",
                "    \n",
                "    final_phi = -57.0 + phi\n",
                "    final_psi = -47.0 + psi\n",
                "    \n",
                "    print(f'\\nφ = {final_phi:.0f}°, ψ = {final_psi:.0f}°\\n')\n",
                "    \n",
                "    # 3D Structure\n",
                "    pf = PDBFile()\n",
                "    pf.set_structure(res.structure)\n",
                "    sink = io.StringIO()\n",
                "    pf.write(sink)\n",
                "    view = py3Dmol.view(width=600, height=400)\n",
                "    view.addModel(sink.getvalue(), 'pdb')\n",
                "    view.setStyle({'stick': {}})\n",
                "    view.setStyle({'resi': 5}, {'stick': {'color': 'red'}})\n",
                "    view.setBackgroundColor('#1a1a1a')\n",
                "    view.zoomTo()\n",
                "    view.show()\n",
                "    \n",
                "    # Ramachandran + Distance Matrix side by side\n",
                "    fig = make_subplots(rows=1, cols=2,\n",
                "                       subplot_titles=('Ramachandran Plot', 'Distance Matrix'))\n",
                "    \n",
                "    # Ramachandran\n",
                "    fig.add_trace(go.Scatter(x=[final_phi], y=[final_psi], mode='markers',\n",
                "                            marker=dict(size=12, color='red')), row=1, col=1)\n",
                "    fig.update_xaxes(title_text='φ', range=[-180, 180], row=1, col=1)\n",
                "    fig.update_yaxes(title_text='ψ', range=[-180, 180], row=1, col=1)\n",
                "    \n",
                "    # Distance matrix\n",
                "    ca = res.structure[res.structure.atom_name == 'CA']\n",
                "    n = len(ca)\n",
                "    dm = np.zeros((n, n))\n",
                "    for i in range(n):\n",
                "        for j in range(n):\n",
                "            dm[i,j] = np.linalg.norm(ca.coord[i] - ca.coord[j])\n",
                "    fig.add_trace(go.Heatmap(z=dm, colorscale='Viridis'), row=1, col=2)\n",
                "    \n",
                "    fig.update_layout(height=400, width=800, template='plotly_dark', showlegend=False)\n",
                "    fig.show()\n"
            ]
        }
    ],
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "version": "3.12.3"}
    },
    "nbformat": 4,
    "nbformat_minor": 4
}

with open("examples/interactive_tutorials/nerf_geometry_lab.ipynb", 'w') as f:
    json.dump(nb, f, indent=1)

print("✅ Created ULTRA-SIMPLE version using @interact decorator")
print("   - ipywidgets handles ALL layout automatically")
print("   - No manual Output widgets")
print("   - No clear_output() needed")
print("   - Just works!")
