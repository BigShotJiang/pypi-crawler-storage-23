
import os
import ast
import tokenize
import io

def get_code_comment_ratio(file_path):
    with open(file_path, 'r') as f:
        content = f.read()
    
    lines = content.splitlines()
    total_lines = len(lines)
    
    # Simple counting
    comment_lines = 0
    code_lines = 0
    blank_lines = 0
    
    # Use tokenize to get precise counts
    try:
        f_obj = io.StringIO(content)
        tokens = list(tokenize.generate_tokens(f_obj.readline))
        
        # Track lines that have comments
        comment_line_indices = set()
        code_line_indices = set()
        
        for tok in tokens:
            start_line = tok.start[0]
            end_line = tok.end[0]
            
            if tok.type == tokenize.COMMENT:
                comment_line_indices.add(start_line)
            elif tok.type == tokenize.STRING:
                # Check if it's a docstring or just a string
                # This is a bit simplified but usually works for top-level/class/function docstrings
                # if the string is its own statement.
                comment_line_indices.update(range(start_line, end_line + 1))
            elif tok.type not in (tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER):
                code_line_indices.add(start_line)
        
        # Remove overlaps (if a line has code AND a comment, it counts as both in terms of content, 
        # but let's decide: Docstrings are comments for this metric).
        
        final_comment_count = len(comment_line_indices)
        final_code_count = len(code_line_indices - comment_line_indices)
        
        return {
            "total": total_lines,
            "comments": final_comment_count,
            "code": final_code_count,
            "ratio": round(final_comment_count / max(1, final_code_count), 2)
        }
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    files = ["synth_pdb/physics.py", "synth_pdb/validator.py", "synth_pdb/generator.py"]
    for f in files:
        if os.path.exists(f):
            stats = get_code_comment_ratio(f)
            print(f"{f}: {stats}")
