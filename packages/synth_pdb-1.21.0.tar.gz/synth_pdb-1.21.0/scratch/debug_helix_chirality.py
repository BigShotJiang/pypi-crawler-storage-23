
from synth_pdb.generator import BatchedGenerator
import biotite.structure as struc
import numpy as np
from synth_pdb.validator import PDBValidator

print("Generating Alpha Helix...")
gen = BatchedGenerator("AAAAAAAAAA", n_batch=1, full_atom=True)
helix = gen.generate_batch(conformation='alpha')
pdb_content = helix.to_pdb(0)

# 1. Check Angles with Biotite / Validator
val = PDBValidator(pdb_content)
dihedrals = val.calculate_dihedrals()
phi = dihedrals['phi']
psi = dihedrals['psi']

print(f"Phi: {phi}")
print(f"Psi: {psi}")

avg_phi = np.nanmean(phi)
avg_psi = np.nanmean(psi)

print(f"Average Phi: {avg_phi:.2f}")
print(f"Average Psi: {avg_psi:.2f}")

if avg_phi > 0:
    print("CHIRALITY: LEFT-HANDED (Inverted?)")
else:
    print("CHIRALITY: RIGHT-HANDED (Standard)")

# 2. Check Validator Violations
val.validate_ramachandran()
print(f"Violations: {val.get_violations()}")

# 3. Check Dynamics Recognition
from synth_pdb.structure_utils import get_secondary_structure
import biotite.structure.io.pdb as pdb
import io

f = pdb.PDBFile.read(io.StringIO(pdb_content))
structure = f.get_structure(model=1)
ss = get_secondary_structure(structure)
print(f"Detected Secondary Structure: {ss}")
