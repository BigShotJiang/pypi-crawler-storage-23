
import pynmrstar
import sys

def check_entry(entry_id):
    try:
        entry = pynmrstar.Entry.from_database(entry_id)
        print(f"Entry {entry_id}:")
        for sf in entry:
            if sf.category == 'coupling_constants':
                print(f"  Found coupling_constants saveframe: {sf.name}")
                return True
        print(f"  No coupling_constants saveframe found in entry {entry_id}")
        return False
    except Exception as e:
        print(f"  Error loading entry {entry_id}: {e}")
        return False

entries = ["7111", "6457", "68", "5387", "11547", "17769", "4375"]
for eid in entries:
    check_entry(eid)
