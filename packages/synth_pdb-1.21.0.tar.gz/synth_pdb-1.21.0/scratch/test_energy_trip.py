
import os
import sys
sys.path.append(os.path.abspath('.'))
from synth_pdb import PeptideGenerator, EnergyMinimizer

gen = PeptideGenerator("ALA-ALA-ALA")
res = gen.generate()
minimizer = EnergyMinimizer()

try:
    energy = minimizer.calculate_energy(res)
    print(f"Energy: {energy}")
except Exception as e:
    print(f"Error: {e}")
