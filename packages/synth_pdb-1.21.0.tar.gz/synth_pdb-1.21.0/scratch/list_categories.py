
import pynmrstar
entry = pynmrstar.Entry.from_database("6457")
categories = set(sf.category for sf in entry)
print(f"Categories in 6457: {sorted(categories)}")
