"""
OpenTelemetry instrumentation integration tests for LLM providers.
"""
