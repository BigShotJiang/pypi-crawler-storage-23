"""Internal helpers and private modules for the basalt SDK.

This package is intentionally private (leading underscore).
"""

__all__ = []
