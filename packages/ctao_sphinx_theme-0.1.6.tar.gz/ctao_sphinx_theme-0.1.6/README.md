# ctao-sphinx-theme

Sphinx theme for CTAO.

Install the package and use it by setting the html theme in `docs/conf.py`:
```
html_theme = "ctao"
```

See the [python-project-template](https://gitlab.cta-observatory.org/cta-computing/documentation/python-project-template) for a full example.
