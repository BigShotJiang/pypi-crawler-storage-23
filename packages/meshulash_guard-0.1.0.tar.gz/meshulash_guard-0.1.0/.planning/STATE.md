# Project State

## Project Reference

See: .planning/PROJECT.md (updated 2026-02-26)

**Core value:** Developers can protect their LLM applications from PII leakage, toxic content, jailbreaks, and cyber threats with a single `pip install` and a few lines of Python — no knowledge of the underlying engine required.
**Current focus:** Project complete — all 5 phases done. Ready for first PyPI publish (merge to main).

## Current Position

Phase: 5 of 5 (Publish & Deploy) — COMPLETE
Plan: 3 of 3 in current phase
Status: All plans complete
Last activity: 2026-02-27 — Completed 05-03-PLAN.md (manual setup + end-to-end verification)

Progress: [██████████] 100%

## Performance Metrics

**Velocity:**
- Total plans completed: 11
- Average duration: 2.1min
- Total execution time: ~23min

**By Phase:**

| Phase | Plans | Total | Avg/Plan |
|-------|-------|-------|----------|
| 01-foundation | 2 | 6min | 3min |
| 02-scanners | 2 | 4min | 2min |
| 03-vault | 1 | 1min | 1min |
| 03.1-demo-chatbot | 1 | 2min | 2min |
| 04-docs | 3 | 7min | 2.3min |
| 05-publish-and-deploy | 3 | 5min | 1.7min |

*Updated after each plan completion*

## Accumulated Context

### Decisions

Decisions are logged in PROJECT.md Key Decisions table.
Recent decisions affecting current work:

- SDK is HTTP client wrapper over existing AIM security server (not engine extraction)
- TC heads hidden from developer — SDK maps scanner labels to heads internally
- Placeholder cache is client-side — deanonymize needs no server round-trip
- scan_output(text, scanners) matches scan_input signature — both delegate to private _scan() method
- deanonymize() uses longest-first sort for defensive placeholder replacement ordering
- Guard constructor requires tenant_id
- Vault must NOT be cleared inside turn loop — clear_cache() only at session start or explicit /reset command
- mkdocs-material 9.x installed in .venv; custom color scheme named "meshulash" references AIM purple (#8b5cf6)
- CNAME placed in docs/ (not repo root) so mkdocs copies it to site/ and gh-deploy preserves custom domain
- Quickstart serves as landing page (index.md) — no separate hero/home page
- Header uses linear-gradient (white 0-33% for logo, purple 33-100%)
- JailbreakScanner fully operational — server jailbreak head deployed, forward-compat note removed
- EmotionScanner uses 30 server labels with mixed casing (Title Case for primary, lowercase for secondary/complex); server 'emotion' TC head confirmed deployed
- Drop Python 3.9 (EOL Oct 2025) — requires-python bumped to >=3.10
- OIDC id-token: write scoped to publish job only (not workflow-level) for security
- version-check job enforces version bumps on every PR to main via pyproject-check-version@v4
- Two-job build+publish pattern: build creates dist/, publish downloads and uploads to PyPI via OIDC
- docs.guard.meshulash.ai replaces docs.meshulash.ai as the custom domain for the docs site
- git user configured as github-actions[bot] before mkdocs gh-deploy (required for gh-pages commit)
- PyPI Pending Trusted Publisher registered with exact workflow name publish.yml and environment pypi
- dev branch created for development; feature work flows dev → main where CI and publish trigger
- GitHub Pages source set to gh-pages branch, custom domain docs.guard.meshulash.ai with HTTPS enforced

### Roadmap Evolution

- Phase 3.1 inserted after Phase 3: Gemini chatbot demo stress-testing SDK with varied scanner configs (INSERTED)
- Phase 5 added: Publish SDK to PyPI with CI/CD (dev/prod branches), deploy docs to docs.meshulash.ai

### Pending Todos

None.

### Quick Tasks Completed

| # | Description | Date | Commit | Directory |
|---|-------------|------|--------|-----------|
| 001 | Add EmotionScanner to SDK and docs | 2026-02-27 | `a8eb003` | [001-add-emotionscanner](./quick/001-add-emotionscanner-to-sdk-and-docs/) |

### Blockers/Concerns

None — all blockers resolved:
- Server endpoint deployed and reachable
- JailbreakScanner server head now deployed and operational

## Session Continuity

Last session: 2026-02-27
Stopped at: Completed 05-03-PLAN.md — all phases complete, pipeline ready for first publish
Resume file: None
