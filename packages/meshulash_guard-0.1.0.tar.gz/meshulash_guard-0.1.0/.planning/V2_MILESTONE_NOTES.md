# V2 Milestone — Pre-Planning Notes

**Captured:** 2026-02-27
**Status:** Discussed, not yet formalized. Run `/gsd:new-milestone` after Phase 5 completes.

## Scope

Full-stack milestone: engine + SDK + API + docs for each feature.

### 1. Normalizers (Engine Work)
- Build normalizer pipeline in the AIM server
- Expose via SDK (BaseNormalizer already defined in v1)
- Document in MkDocs site
- Existing v2 requirements: NORM-01 through NORM-05
  - NORM-01: Server-side normalizer registry with per-request configuration
  - NORM-02: Unicode normalization (NFC/NFKC/NFD/NFKD)
  - NORM-03: Invisible text stripping (zero-width chars, PUA range, Unicode tag blocks)
  - NORM-04: Homoglyph normalization (Cyrillic/lookalike → ASCII)
  - NORM-05: Encoding detection and decode (base64, URL encoding, HTML entities)

### 2. New Scanners (Engine + SDK + Docs)
- Build new TC heads / detection logic server-side, then expose via SDK
- **Key approach:** Research competitive landscape first (ProtectAI, LLM Guard, NeMo Guardrails, Rebuff, etc.)
  - Identify which scanners competitors offer
  - Map against existing engine capabilities
  - Prioritize low-hanging fruit — scanners we can add leveraging existing engine + easy additions
- Existing v2 scanner requirements: NSCAN-01 through NSCAN-06
  - NSCAN-01: SecretsScanner (entropy + API key patterns)
  - NSCAN-02: LanguageScanner (detect/restrict languages)
  - NSCAN-03: CodeScanner (detect code blocks)
  - NSCAN-04: SentimentScanner (hostile tone)
  - NSCAN-05: GibberishScanner (random/adversarial noise)
  - NSCAN-06: BanSubstringsScanner (configurable block lists)
- Additional scanners to identify through competitive research

## User Decisions
- This is a **new milestone (v2)**, not extending v1
- **Engine + SDK + docs** for both normalizers and scanners (full stack)
- Competitive research is a priority before committing to scanner list

## Next Step
After Phase 5 completes: `/gsd:new-milestone`
The research phase will analyze competitors and inform the final scope.
