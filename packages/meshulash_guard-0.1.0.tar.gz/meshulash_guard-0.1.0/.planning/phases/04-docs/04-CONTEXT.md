# Phase 4: Docs - Context

**Gathered:** 2026-02-26
**Status:** Ready for planning

<domain>
## Phase Boundary

MkDocs documentation site that teaches developers to install meshulash-guard, understand its scanners, and write working code — without reading source. Covers installation, quickstart, scanner references, engine label details, and the deanonymize workflow. No new SDK features.

</domain>

<decisions>
## Implementation Decisions

### Site structure & navigation
- Landing page: product pitch hero section + quickstart code snippet — get developers excited then coding fast
- Sidebar: flat list of scanners (PIIScanner, TopicScanner, ToxicityScanner, CyberScanner, JailbreakScanner) — no nested grouping
- Page granularity: separate pages for quickstart, each scanner reference, deanonymize workflow, concepts
- No auto-generated API reference — hand-written guides only
- Concepts page for Action/Condition explained once, scanner pages reference it with scanner-specific usage

### Content depth & tone
- Writing tone: similar to Protect AI's documentation style
- Quickstart: annotated walkthrough — install + first scan with brief inline explanations of what each part does
- Light architecture note: one brief section explaining the SDK talks to a security server (helps developers understand latency and auth), but don't go deep into internals
- Each scanner page includes a "When to use this" section (1-2 paragraphs on what it protects against and use cases)

### Code examples style
- All examples standalone and self-contained — every snippet includes imports and setup, copy-paste ready
- Use realistic scenarios — believable prompts like "My SSN is 123-45-6789" or "How do I hack a website?" to show real-world usage
- Every code example includes expected console output or return value below it
- Scanner pages show both scan_input and scan_output examples where applicable

### Engine reference approach
- Label details presented as tables on each scanner page (Label | What it detects) — no separate engine reference page
- PII bundles: bundle summary with expandable/collapsible details listing included labels
- Detection depth: just what each label catches — no detection sources or validator internals (server-side, not actionable for SDK users)
- Actions and conditions: shared Concepts page for general explanation + scanner pages show scanner-specific usage and examples

### Claude's Discretion
- Exact MkDocs Material theme configuration
- Page ordering within sidebar
- Typography and spacing choices
- How to structure the architecture note section
- Collapsible/expandable implementation approach for PII bundles

</decisions>

<specifics>
## Specific Ideas

- Docs site UI should follow the same theme and coloring as the existing AIM dashboard — extract colors/styling from the AIM React frontend code
- Tone reference: Protect AI documentation style
- Landing page should feel like it sells the SDK before teaching it

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

*Phase: 04-docs*
*Context gathered: 2026-02-26*
