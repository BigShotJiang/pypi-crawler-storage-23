# Phase 5: Publish & Deploy - Context

**Gathered:** 2026-02-27
**Status:** Ready for planning

<domain>
## Phase Boundary

Publish meshulash-guard to PyPI with CI/CD automation (dev→main workflow), and deploy the docs site to docs.guard.meshulash.ai via GitHub Pages. Two repos, two pipelines, one phase.

</domain>

<decisions>
## Implementation Decisions

### PyPI Publishing
- Package name: `meshulash-guard` (matches pyproject.toml)
- Public on PyPI — SDK requires server_url, api_key, tenant_id to function, so no risk exposing the package
- PyPI account under shalev@meshulash.ai
- Trusted Publisher (GitHub Actions OIDC) — no API tokens to manage
- Versioning: semver in pyproject.toml, bumped manually before merge to main

### CI/CD Branching Model
- Two branches: `dev` (development) and `main` (production/publish)
- GitHub Actions (not Cloud Build) — SDK has no GCP footprint, and Actions has native Trusted Publisher support
- On PR to main: version bump check (pyproject.toml version > current PyPI version)
- On merge to main: build and publish to PyPI

### Docs Hosting
- GitHub Pages from the meshulash-guard-docs repo (private repo, public site)
- GitHub Team plan (believed to be active — required for Pages on private repos)
- Auto-deploy: GitHub Action runs mkdocs gh-deploy on push to main
- Docs repo is fully self-contained (own mkdocs.yml, requirements.txt, docs/ subfolder)

### Domain & DNS
- Domain: docs.guard.meshulash.ai
- DNS managed via Cloudflare
- CNAME record added: `docs.guard` → `meshulash.github.io` (DNS only, gray cloud) — VERIFIED LIVE
- GitHub Pages handles SSL via Let's Encrypt
- CNAME file in docs repo must be updated to `docs.guard.meshulash.ai`
- mkdocs.yml site_url must be updated to `https://docs.guard.meshulash.ai`

### Claude's Discretion
- Python version support range (3.9+ vs 3.10+ vs 3.11+)
- Exact GitHub Actions workflow structure
- TestPyPI one-time verification (optional)
- Build system details (hatchling already in pyproject.toml)

</decisions>

<specifics>
## Specific Ideas

- Cloudflare DNS records reviewed — no conflicts with existing records (app, staging.app, n8n, oc-sec-server all on different subdomains)
- Existing infra uses Cloud Build + GCP for AIM services, but SDK/docs deliberately use GitHub Actions for simplicity
- meshulash.ai root and www point to meshulashdotai.pages.dev (Cloudflare Pages)

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope

</deferred>

---

*Phase: 05-publish-and-deploy*
*Context gathered: 2026-02-27*
