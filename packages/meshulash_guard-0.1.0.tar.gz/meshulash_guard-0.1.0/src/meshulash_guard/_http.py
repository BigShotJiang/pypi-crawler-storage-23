"""Private HTTP client builder for meshulash-guard.

Builds a requests.Session with:
- X-Api-Key and X-Tenant-Id as session-level headers
- Accept: application/json as session-level header
- Retry adapter for 5xx responses on POST (explicitly required — POST is not
  retried by urllib3 by default because it is not idempotent per HTTP RFC).
- Content-Type is NOT set at session level — it must be set per-request to
  avoid breaking multipart uploads in future phases (Pitfall 3 from research).
"""

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


def _build_session(api_key: str, tenant_id: str) -> requests.Session:
    """Build a requests.Session with auth headers and retry configuration.

    Args:
        api_key: Meshulash API key (passed as X-Api-Key header).
        tenant_id: Tenant identifier (passed as X-Tenant-Id header).

    Returns:
        A configured requests.Session. Content-Type is intentionally NOT set
        at session level — callers should pass it per-request (or use the
        ``json=`` kwarg which sets it automatically).
    """
    session = requests.Session()
    session.headers.update(
        {
            "X-Api-Key": api_key,
            "X-Tenant-Id": tenant_id,
            "Accept": "application/json",
        }
    )
    retry = Retry(
        total=3,
        backoff_factor=0.5,
        status_forcelist=[502, 503, 504],
        allowed_methods={"POST"},  # POST must be explicit — not retried by default
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session
