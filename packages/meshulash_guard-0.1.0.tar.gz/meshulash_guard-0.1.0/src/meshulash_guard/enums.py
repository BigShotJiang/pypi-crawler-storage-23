"""Action and Condition enums for the meshulash-guard SDK.

These map exactly to server-side string values so they can be used
directly in JSON payloads without calling .value.

Note on Python 3.12+ compatibility: Python 3.12 changed the default
``str()`` / ``__format__()`` behavior for mixed-in ``(str, Enum)`` members,
so ``str(Action.REPLACE)`` returns ``'Action.REPLACE'`` rather than
``'replace'``. We override ``__str__`` and ``__format__`` to always return
the member's string value, preserving v1 behaviour across Python 3.9–3.13+.
"""

from enum import Enum


class _StrValueMixin(str, Enum):
    """Mixin that makes str(member) and f'{member}' return the member's value."""

    def __str__(self) -> str:  # type: ignore[override]
        return self.value

    def __format__(self, format_spec: str) -> str:  # type: ignore[override]
        return format(self.value, format_spec)


class Action(_StrValueMixin):
    """Maps to server PolicyAction values."""

    REPLACE = "replace"
    BLOCK = "block"
    LOG = "log"


class Condition(_StrValueMixin):
    """Maps to server gating conditions."""

    ANY = "any"
    ALL = "all"
    K_OF = "k_of"
    CONTEXTUAL = "contextual_analysis"
