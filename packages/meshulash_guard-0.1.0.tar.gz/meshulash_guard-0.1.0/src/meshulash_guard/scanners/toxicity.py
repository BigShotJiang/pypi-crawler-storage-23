"""ToxicityScanner and ToxicityLabel enum for meshulash-guard SDK.

ToxicityScanner detects and acts on text categorized as toxic, hateful, or
offensive by the server's 'hate_speech' TC classification head. Label values
are the exact strings from the server's label_config.json (case-sensitive).
"""

from __future__ import annotations

from typing import Sequence

from ..enums import Action, Condition, _StrValueMixin
from .base import BaseScanner


class ToxicityLabel(_StrValueMixin):
    """Labels for toxicity and hate speech detection.

    Values are the exact strings used by the server's 'hate_speech' TC head.
    Member names are uppercase/underscored for Python ergonomics.
    """

    TOXICITY = "Toxicity"
    HATE_SPEECH = "hate speech"
    NON_HATE = "non-hate"
    OFFENSIVE_LANGUAGE = "offensive language"
    ALL = "__ALL__"


class ToxicityScanner(BaseScanner):
    """Scanner for toxicity and hate speech detection.

    Detects text containing toxic content, hate speech, or offensive language
    using the server's 'hate_speech' TC classification head.

    Args:
        labels: One or more ToxicityLabel members. Use ToxicityLabel.ALL to
            scan all toxicity categories. Cannot be empty.
        action: Action to take when toxicity is detected. Defaults to BLOCK.
        condition: Gating condition (ANY, ALL, K_OF, CONTEXTUAL).
        threshold: Optional confidence threshold (0.0–1.0).
        allowlist: Optional list of values to allow through even if detected.
    """

    _TC_HEAD = "hate_speech"

    def __init__(
        self,
        labels: Sequence[ToxicityLabel],
        action: Action = Action.BLOCK,
        condition: Condition = Condition.ANY,
        threshold: float | None = None,
        allowlist: list[str] | None = None,
    ) -> None:
        if not labels:
            raise ValueError(
                "ToxicityScanner requires at least one label. "
                "Use ToxicityLabel.ALL to scan everything."
            )
        self._labels = list(labels)
        self._action = action
        self._condition = condition
        self._threshold = threshold
        self._allowlist = allowlist or []

    def to_guardline_spec(self) -> dict:
        """Return a guardline spec dict for this scanner configuration."""
        if any(lbl.value == "__ALL__" for lbl in self._labels):
            all_labels = [m for m in type(self._labels[0]) if m.value != "__ALL__"]
        else:
            all_labels = self._labels
        tc_pairs = [[self._TC_HEAD, lbl.value] for lbl in all_labels]
        spec: dict = {
            "name": self.__class__.__name__,
            "condition": str(self._condition),
            "action": str(self._action),
            "level": 2,
            "types": {"regex": False, "ner": False, "tc": True},
            "required": {"regex": [], "ner": [], "tc": tc_pairs},
            "allowlist": list(self._allowlist),
            "bundles": [],
            "k": 0,
        }
        if self._threshold is not None:
            spec["threshold"] = self._threshold
        return spec
