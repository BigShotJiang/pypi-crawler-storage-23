"""JailbreakScanner and JailbreakLabel enum for meshulash-guard SDK.

JailbreakScanner detects and acts on jailbreak attempts categorized by the
server's 'jailbreak' TC classification head. Label values are the exact
strings from the server's label_config.json (case-sensitive).

NOTE: The jailbreak TC head is coming soon on the server. Results may be
empty until the server deploys the jailbreak classification head.
"""

from __future__ import annotations

from typing import Sequence

from ..enums import Action, Condition, _StrValueMixin
from .base import BaseScanner


class JailbreakLabel(_StrValueMixin):
    """Labels for jailbreak attempt detection.

    Values are the exact strings used by the server's 'jailbreak' TC head.
    Member names are uppercase/underscored for Python ergonomics.

    NOTE: The jailbreak TC head is coming soon on the server. Results may be
    empty until the server deploys the jailbreak classification head.
    """

    BENIGN = "benign"
    JAILBREAK = "jailbreak"
    ALL = "__ALL__"


class JailbreakScanner(BaseScanner):
    """Scanner for jailbreak attempt detection.

    Detects text that attempts to bypass AI safety guardrails using the
    server's 'jailbreak' TC classification head.

    NOTE: The jailbreak TC head is coming soon on the server. Results may be
    empty until the server deploys the jailbreak classification head.

    Args:
        labels: One or more JailbreakLabel members. Use JailbreakLabel.ALL to
            scan all jailbreak categories. Cannot be empty.
        action: Action to take when a jailbreak is detected. Defaults to BLOCK.
        condition: Gating condition (ANY, ALL, K_OF, CONTEXTUAL).
        threshold: Optional confidence threshold (0.0–1.0).
        allowlist: Optional list of values to allow through even if detected.
    """

    _TC_HEAD = "jailbreak"

    def __init__(
        self,
        labels: Sequence[JailbreakLabel],
        action: Action = Action.BLOCK,
        condition: Condition = Condition.ANY,
        threshold: float | None = None,
        allowlist: list[str] | None = None,
    ) -> None:
        if not labels:
            raise ValueError(
                "JailbreakScanner requires at least one label. "
                "Use JailbreakLabel.ALL to scan everything."
            )
        self._labels = list(labels)
        self._action = action
        self._condition = condition
        self._threshold = threshold
        self._allowlist = allowlist or []

    def to_guardline_spec(self) -> dict:
        """Return a guardline spec dict for this scanner configuration."""
        if any(lbl.value == "__ALL__" for lbl in self._labels):
            all_labels = [m for m in type(self._labels[0]) if m.value != "__ALL__"]
        else:
            all_labels = self._labels
        tc_pairs = [[self._TC_HEAD, lbl.value] for lbl in all_labels]
        spec: dict = {
            "name": self.__class__.__name__,
            "condition": str(self._condition),
            "action": str(self._action),
            "level": 2,
            "types": {"regex": False, "ner": False, "tc": True},
            "required": {"regex": [], "ner": [], "tc": tc_pairs},
            "allowlist": list(self._allowlist),
            "bundles": [],
            "k": 0,
        }
        if self._threshold is not None:
            spec["threshold"] = self._threshold
        return spec
