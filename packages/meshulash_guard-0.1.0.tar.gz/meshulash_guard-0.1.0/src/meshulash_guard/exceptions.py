"""Custom exception hierarchy for meshulash-guard.

Note: ``ConnectionError`` intentionally shadows the Python builtin — this is the
same pattern used by ``requests.exceptions.ConnectionError``. Callers should
import SDK exceptions via ``from meshulash_guard import ConnectionError`` (or
``from meshulash_guard.exceptions import ConnectionError``) rather than relying
on the builtin name after this import.
"""


class MeshulashError(Exception):
    """Base exception for all meshulash-guard errors."""


class AuthError(MeshulashError):
    """API key invalid or missing."""


class ServerError(MeshulashError):
    """Server returned 5xx response."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code


class ConnectionError(MeshulashError):  # noqa: A001
    """Could not reach the security server."""


class ValidationError(MeshulashError):
    """Request payload failed server-side validation."""
