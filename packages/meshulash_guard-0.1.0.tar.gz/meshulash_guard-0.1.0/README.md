# meshulash-guard

Python SDK for the Meshulash AI security engine.

Protect LLM applications from PII leakage, toxic content, jailbreaks, and cyber threats
with a single `pip install` and a few lines of Python.

```python
from meshulash_guard import Guard

guard = Guard(api_key="sk-xxx", tenant_id="your-tenant-id")
result = guard.scan_input(text, scanners=[pii_scanner])
```
