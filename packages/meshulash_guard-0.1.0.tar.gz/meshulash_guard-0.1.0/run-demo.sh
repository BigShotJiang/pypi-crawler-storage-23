#!/bin/bash
export GEMINI_API_KEY="AIzaSyBmkkrfl1VcHOPzxh2Sj5kSB3g3kRmee3c"
export MESHULASH_API_KEY="FYkqL0CizYnRoIgHrI1ZOHtbFh9ZqLgxYrcu5UWeWS034CvQ"
export MESHULASH_TENANT_ID="local"
export MESHULASH_SERVER_URL="http://localhost:8000"
.venv/bin/python demo/chatbot.py
