"""
Base check classes for FEP check implementations.

Provides the foundation for both synchronous and asynchronous check implementations
with proper evaluation context handling, including JSONPath validation.
"""

from abc import ABC, abstractmethod
from dataclasses import asdict
from datetime import datetime, UTC
from enum import Enum
from types import UnionType
from typing import Any, ClassVar, TypeAlias, TYPE_CHECKING
import typing
from pydantic import BaseModel, Field, field_validator

if TYPE_CHECKING:
    from ..schemas.check import Check

from ..constants import CheckType
from ..exceptions import CheckExecutionError, JSONPathError, ValidationError
from ..utils.jsonpath_resolver import (
    validate_jsonpath,
    resolve_argument,
)
from ..schemas import CheckResult, CheckError, Output, TestCase


# JSONPath validation utilities
class JSONPathBehavior(Enum):
    """Enum defining JSONPath behavior for schema fields."""

    REQUIRED = 'required'  # Must be valid JSONPath
    OPTIONAL = 'optional'  # Can be literal or JSONPath (validates if starts with $)


def get_jsonpath_behavior(model_class: type, field_name: str) -> JSONPathBehavior | None:
    """
    Get JSONPath behavior for a field by inspecting its type annotation.

    This function determines whether a Pydantic field should be treated as:
    - REQUIRED: Field must be a JSONPath (type annotation is exactly `JSONPath`)
    - OPTIONAL: Field can be literal or JSONPath (type annotation is union like `str | JSONPath`)
    - None: Field doesn't support JSONPath (no JSONPath in type annotation)

    Used by the schema generator and validation systems to understand how to handle
    field values during check execution.

    Args:
        model_class: Pydantic model class to inspect
        field_name: Name of the field to check

    Returns:
        JSONPathBehavior.REQUIRED if field type is exactly JSONPath
        JSONPathBehavior.OPTIONAL if field type is a union containing JSONPath
        None if field doesn't exist or doesn't support JSONPath

    Examples:
        >>> class MyCheck(BaseCheck):
        ...     path: JSONPath = Field(...)  # REQUIRED
        ...     text: str | JSONPath = Field(...)  # OPTIONAL
        ...     literal: str = Field(...)  # None
        >>> get_jsonpath_behavior(MyCheck, 'path')
        JSONPathBehavior.REQUIRED
    """
    # Handle None or invalid model_class gracefully
    if not model_class or not hasattr(model_class, 'model_fields'):
        return None

    field_info = model_class.model_fields.get(field_name)
    if not field_info:
        return None

    # Get the field's type annotation
    field_type = field_info.annotation

    # Check if the field type is exactly JSONPath (required)
    if field_type is JSONPath:
        return JSONPathBehavior.REQUIRED

    # Check if the field type is a Union that includes JSONPath (optional)
    # This handles cases like str | JSONPath, bool | JSONPath, etc.
    origin = typing.get_origin(field_type)

    # Handle both old-style typing.Union and new-style types.UnionType (Python 3.10+)
    if origin is typing.Union or isinstance(field_type, UnionType):
        args = typing.get_args(field_type)
        if JSONPath in args:
            return JSONPathBehavior.OPTIONAL

    return None


# JSONPath type for clean field definitions
# validate_jsonpath is now imported from jsonpath_resolver module
class JSONPath(BaseModel):
    """Represents a JSONPath expression that needs resolution."""

    expression: str = Field(..., description="The JSONPath expression to resolve")

    @field_validator('expression')
    @classmethod
    def validate_expression(cls, v: str) -> str:
        """Validate that the expression is a valid JSONPath."""
        if not validate_jsonpath(v):
            raise ValueError(f"Invalid JSONPath expression: '{v}'")
        return v

    def __str__(self) -> str:
        return self.expression

    def __repr__(self) -> str:
        return f"JSONPath('{self.expression}')"


def _convert_to_jsonpath(value: object) -> object | JSONPath:
    """Convert JSONPath-like strings to JSONPath objects."""
    if isinstance(value, str) and value.startswith('$.'):
        return JSONPath(expression=value)
    return value


def _create_evaluation_context(test_case: TestCase, output: Output) -> dict[str, Any]:
    """
    Create evaluation context structure from test case and output.

    Args:
        test_case: The test case being evaluated
        output: The system output for this test case

    Returns:
        Dict with evaluation context matching FEP protocol structure:
        {
            "test_case": {
                "id": "string",
                "input": "string | object",
                "expected": "string | object | null",
                "metadata": "object"
            },
            "output": {
                "value": "string | object",
                "metadata": "object"
            }
        }
    """
    return {
        'test_case': asdict(test_case),
        'output': output.to_dict(),
    }


class EvaluationContext:
    """
    Evaluation context that provides access to test case and output data.

    This is a convenience wrapper around the raw context dictionary that
    provides type-safe access to test case and output data.
    """

    def __init__(self, test_case: TestCase, output: Output):
        self.test_case = test_case
        self.output = output
        self._context_dict = _create_evaluation_context(test_case, output)

    @property
    def context_dict(self) -> dict[str, Any]:
        """Get the raw context dictionary for JSONPath resolution."""
        return self._context_dict


class _CheckMixin:
    """
    Shared logic for BaseCheck and BaseAsyncCheck.

    Provides check_type lookup, argument serialization, JSONPath field resolution,
    and error handling. Intended to be used as the first parent in MRO before
    BaseModel and ABC.
    """

    @property
    def check_type(self) -> CheckType | str:
        """Return the CheckType for this check."""
        from ..registry import get_check_type_for_class  # noqa: PLC0415
        check_type_str = get_check_type_for_class(self.__class__)
        try:
            return CheckType(check_type_str)
        except ValueError:
            return check_type_str

    def to_arguments(self) -> dict[str, Any]:
        """Convert Pydantic fields to arguments dict for engine compatibility."""
        data = self.model_dump()
        data.pop('metadata', None)
        for key, value in data.items():
            if isinstance(value, JSONPath):
                data[key] = value.expression
        return data

    def _get_version(self) -> str:
        """Get the registered version for this check class."""
        from ..registry import get_version_for_class  # noqa: PLC0415
        return get_version_for_class(self.__class__)

    def resolve_fields(self, context: EvaluationContext) -> dict[str, Any]:
        """Resolve any JSONPath fields in-place using the evaluation context."""
        resolved_arguments = {}

        for field_name in self.__class__.model_fields:
            field_value = getattr(self, field_name)

            if isinstance(field_value, JSONPath):
                try:
                    resolved_result = resolve_argument(
                        field_value.expression,
                        context.context_dict,
                    )
                    resolved_value = resolved_result.get("value")
                    setattr(self, field_name, resolved_value)
                    resolved_arguments[field_name] = resolved_result
                except Exception as e:
                    raise JSONPathError(
                        f"Failed to resolve JSONPath in field '{field_name}': {e}",
                        jsonpath_expression=field_value.expression,
                    ) from e
            else:
                resolved_arguments[field_name] = {
                    "value": field_value,
                    "resolved_from": "literal",
                }

        self._resolved_arguments = resolved_arguments
        return resolved_arguments

    def _restore_jsonpath_fields(self) -> None:
        """Restore JSONPath objects from their resolved values (for reuse of check instances)."""
        if not hasattr(self, '_resolved_arguments'):
            return

        for field_name, resolved_info in self._resolved_arguments.items():
            if 'jsonpath' in resolved_info:
                original_jsonpath = JSONPath(expression=resolved_info['jsonpath'])
                setattr(self, field_name, original_jsonpath)

    def _handle_check_error(
        self,
        error: Exception,
        check_type: str,
        check_version: str,
        evaluated_at: datetime,
        check_metadata: dict[str, Any] | None,
    ) -> CheckResult:
        """Map an exception from check execution to a CheckResult error."""
        if isinstance(error, JSONPathError):
            error_type = 'jsonpath_error'
            error_message = str(error)
        elif isinstance(error, ValidationError):
            error_type = 'validation_error'
            error_message = str(error)
        elif isinstance(error, CheckExecutionError):
            error_type = 'unknown_error'
            error_message = str(error)
        else:
            error_type = 'unknown_error'
            error_message = f"Unexpected error during check execution: {error!s}"

        return self._create_error_result(
            check_type=check_type,
            error_type=error_type,
            error_message=error_message,
            resolved_arguments={},
            evaluated_at=evaluated_at,
            check_version=check_version,
            check_metadata=check_metadata,
        )

    def _create_error_result(
        self,
        check_type: str,
        error_type: str,
        error_message: str,
        resolved_arguments: dict[str, Any],
        evaluated_at: datetime,
        check_version: str,
        check_metadata: dict[str, Any] | None = None,
    ) -> CheckResult:
        """Create a CheckResult for error cases with default results."""
        return CheckResult(
            check_type=check_type,
            check_version=check_version,
            status='error',
            results=self.default_results,
            resolved_arguments=resolved_arguments,
            evaluated_at=evaluated_at,
            metadata=check_metadata,
            error=CheckError(
                type=error_type,
                message=error_message,
            ),
        )


class BaseCheck(_CheckMixin, BaseModel, ABC):
    """
    Base class for synchronous check implementations.

    Combines Pydantic field validation with check execution capabilities.
    Subclasses should define their Pydantic fields and implement __call__().
    """

    model_config: ClassVar[dict[str, Any]] = {'extra': 'forbid'}
    metadata: dict[str, Any] | None = None

    @property
    @abstractmethod
    def default_results(self) -> dict[str, Any]:
        """
        Return the default results structure for this check type.

        This ensures a consistent API where consumers can always access expected
        fields (like 'passed', 'score') even when checks fail.

        Returns:
            Dict with default values for all result fields this check type produces

        Example:
            For exact_match: {'passed': False}
            For semantic_similarity: {'score': None, 'passed': False}
        """
        pass

    @abstractmethod
    def __call__(self, **kwargs: Any) -> dict[str, Any]:  # noqa
        """
        Execute the check with direct arguments.

        Args:
            **kwargs: Check arguments passed directly as keyword arguments

        Returns:
            Dict containing check-specific results

        Raises:
            CheckExecutionError: If check execution fails
            ValidationError: If arguments are invalid for this check
        """
        pass

    def execute(
        self,
        context: EvaluationContext,
        check_metadata: dict[str, Any] | None = None,
    ) -> CheckResult:
        """
        Execute the check and return a complete CheckResult.

        This method handles JSONPath field resolution, error handling, and result formatting
        according to the FEP protocol.

        Note:
            Check instances are not safe for concurrent use. The engine uses deepcopy
            internally, but if calling execute() directly on a shared instance, use
            separate instances or deepcopy for concurrent execution.

        Args:
            context: Evaluation context for JSONPath resolution
            check_metadata: Additional metadata from the check definition

        Returns:
            Complete CheckResult with all required fields
        """
        evaluated_at = datetime.now(UTC)
        check_version = self._get_version()
        check_type = str(self.check_type)

        try:
            resolved_arguments = self.resolve_fields(context)
            try:
                results = self()
            except TypeError as e:
                raise ValidationError(f"Invalid arguments for check: {e!s}") from e
            finally:
                self._restore_jsonpath_fields()

            return CheckResult(
                check_type=check_type,
                check_version=check_version,
                status='completed',
                results=results,
                resolved_arguments=resolved_arguments,
                evaluated_at=evaluated_at,
                metadata=check_metadata,
            )

        except Exception as e:
            return self._handle_check_error(
                error=e,
                check_type=check_type,
                check_version=check_version,
                evaluated_at=evaluated_at,
                check_metadata=check_metadata,
            )


class BaseAsyncCheck(_CheckMixin, BaseModel, ABC):
    """
    Base class for asynchronous check implementations.

    Combines Pydantic field validation with async check execution capabilities.
    Subclasses should define their Pydantic fields and implement async __call__().
    """

    model_config: ClassVar[dict[str, Any]] = {'extra': 'forbid'}
    metadata: dict[str, Any] | None = None

    @property
    @abstractmethod
    def default_results(self) -> dict[str, Any]:
        """
        Return the default results structure for this check type.

        This ensures a consistent API where consumers can always access expected
        fields (like 'passed', 'score') even when checks fail.

        Returns:
            Dict with default values for all result fields this check type produces

        Example:
            For exact_match: {'passed': False}
            For semantic_similarity: {'score': None, 'passed': False}
        """
        pass

    @abstractmethod
    async def __call__(self, **kwargs: Any) -> dict[str, Any]:  # noqa
        """
        Execute the check with direct arguments asynchronously.

        Args:
            **kwargs: Check arguments passed directly as keyword arguments

        Returns:
            Dict containing check-specific results

        Raises:
            CheckExecutionError: If check execution fails
            ValidationError: If arguments are invalid for this check
        """
        pass

    async def execute(
        self,
        context: EvaluationContext,
        check_metadata: dict[str, Any] | None = None,
    ) -> CheckResult:
        """
        Execute the check asynchronously and return a complete CheckResult.

        This method handles argument resolution, error handling, and result formatting
        according to the FEP protocol.

        Note:
            Check instances are not safe for concurrent use. The engine uses deepcopy
            internally, but if calling execute() directly on a shared instance, use
            separate instances or deepcopy for concurrent execution.

        Args:
            context: Evaluation context for JSONPath resolution
            check_metadata: Additional metadata from the check definition

        Returns:
            Complete CheckResult with all required fields
        """
        evaluated_at = datetime.now(UTC)
        check_version = self._get_version()
        check_type = str(self.check_type)

        try:
            resolved_arguments = self.resolve_fields(context)
            try:
                results = await self()
            except TypeError as e:
                raise ValidationError(f"Invalid arguments for check: {e!s}") from e
            finally:
                self._restore_jsonpath_fields()

            return CheckResult(
                check_type=check_type,
                check_version=check_version,
                status='completed',
                results=results,
                resolved_arguments=resolved_arguments,
                evaluated_at=evaluated_at,
                metadata=check_metadata,
            )

        except Exception as e:
            return self._handle_check_error(
                error=e,
                check_type=check_type,
                check_version=check_version,
                evaluated_at=evaluated_at,
                check_metadata=check_metadata,
            )


# Type alias for any check type
CheckTypes: TypeAlias = 'Check | BaseCheck | BaseAsyncCheck'
