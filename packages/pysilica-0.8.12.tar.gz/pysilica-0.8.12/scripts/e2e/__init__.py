"""E2E test scripts for coordinator mode validation."""
