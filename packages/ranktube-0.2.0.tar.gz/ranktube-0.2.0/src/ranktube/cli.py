"""CLI entry point for RankTube."""

from __future__ import annotations

import argparse
import os
import sys

from dotenv import load_dotenv

from .api import search_videos
from .formatter import format_output
from .resolver import resolve_channel_id
from .scorer import score_and_filter


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rt",
        description="RankTube — Search YouTube and output scored video URLs.",
    )

    parser.add_argument(
        "keywords",
        nargs="+",
        help="One or more keyword strings to search for.",
    )

    channel_group = parser.add_mutually_exclusive_group()
    channel_group.add_argument(
        "--channel",
        metavar="NAME",
        help="Channel display name (resolved to a channel ID automatically).",
    )
    channel_group.add_argument(
        "--channel-id",
        metavar="ID",
        dest="channel_id",
        help="Direct YouTube channel ID (skips name resolution).",
    )

    parser.add_argument(
        "--top",
        type=int,
        default=None,
        metavar="N",
        help="Limit output to the top N results.",
    )
    parser.add_argument(
        "--min-score",
        type=float,
        default=0.1,
        metavar="THRESHOLD",
        help="Minimum relevance score to include a result (default: 0.1).",
    )
    parser.add_argument(
        "--output",
        choices=["urls", "details", "json", "verbose"],
        default="urls",
        help="Output format (default: urls).",
    )
    parser.add_argument(
        "--api-key",
        metavar="KEY",
        default=None,
        help="YouTube Data API v3 key (falls back to YOUTUBE_API_KEY env var).",
    )

    return parser


def main(argv: list[str] | None = None) -> None:
    load_dotenv()  # loads .env from cwd or any parent directory

    parser = _build_parser()
    args = parser.parse_args(argv)

    # --- Resolve API key ---
    api_key = args.api_key or os.environ.get("YOUTUBE_API_KEY")
    if not api_key:
        parser.error(
            "A YouTube API key is required. "
            "Pass --api-key or set the YOUTUBE_API_KEY environment variable."
        )

    # --- Resolve channel ID ---
    channel_id: str | None = None
    if args.channel_id:
        channel_id = args.channel_id
    elif args.channel:
        channel_id = resolve_channel_id(args.channel, api_key)
        if channel_id is None:
            print(
                f"Error: could not resolve channel '{args.channel}'.",
                file=sys.stderr,
            )
            sys.exit(1)

    # --- Fetch videos ---
    videos = search_videos(
        keywords=args.keywords,
        api_key=api_key,
        channel_id=channel_id,
        top=args.top,
    )

    # --- Score and filter ---
    scored = score_and_filter(
        videos=videos,
        keywords=args.keywords,
        min_score=args.min_score,
    )

    # --- Limit to top N ---
    if args.top is not None:
        scored = scored[: args.top]

    # --- Format output ---
    format_output(scored, mode=args.output)


if __name__ == "__main__":
    main()
