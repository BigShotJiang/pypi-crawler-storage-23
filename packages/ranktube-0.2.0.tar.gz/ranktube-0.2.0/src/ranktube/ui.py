"""Streamlit browser UI for RankTube."""

from __future__ import annotations

import configparser
import contextlib
import io
import json
import os
import pathlib
import sys

from dotenv import load_dotenv
from googleapiclient.errors import HttpError
import streamlit as st

# Allow `streamlit run src/ranktube/ui.py` (no package context) as well as
# the normal `from ranktube import ui` import path.
import pathlib as _pathlib
import sys as _sys

_src = str(_pathlib.Path(__file__).parent.parent)  # …/src
if _src not in _sys.path:
    _sys.path.insert(0, _src)

from ranktube.api import search_videos  # noqa: E402
from ranktube.formatter import _fmt_count, _fmt_duration, format_output  # noqa: E402
from ranktube.resolver import resolve_channel_id  # noqa: E402
from ranktube.scorer import ScoredVideo, score_and_filter  # noqa: E402

# ---------------------------------------------------------------------------
# Page config — must be the first Streamlit call
# ---------------------------------------------------------------------------

st.set_page_config(page_title="RankTube", layout="wide")


# ---------------------------------------------------------------------------
# Error helpers
# ---------------------------------------------------------------------------

def _show_api_error(exc: HttpError) -> None:
    """Display a human-readable error for a YouTube API HttpError."""
    status = exc.resp.status
    try:
        reason = exc.error_details[0].get("reason", "") if exc.error_details else ""
        message = exc.error_details[0].get("message", str(exc)) if exc.error_details else str(exc)
    except Exception:
        reason = ""
        message = str(exc)

    if status == 403 and "quotaExceeded" in (reason + str(exc)):
        st.error(
            "**\u26a0\ufe0f YouTube API quota exceeded.**\n\n"
            "Your API key has used up its daily quota (10,000 units by default). "
            "Quota resets at midnight Pacific Time.\n\n"
            "**What you can do:**\n"
            "- Wait for the daily reset and try again.\n"
            "- Use a different API key.\n"
            "- Request a higher quota in the "
            "[Google Cloud Console](https://console.cloud.google.com/apis/api/youtube.googleapis.com/quotas)."
        )
    elif status == 403 and "forbidden" in message.lower():
        st.error(
            "\U0001f512 **API key not authorised.**\n\n"
            f"{message}\n\n"
            "Make sure the YouTube Data API v3 is enabled for your key in the "
            "[Google Cloud Console](https://console.cloud.google.com/apis/library/youtube.googleapis.com)."
        )
    elif status == 400 and "keyInvalid" in (reason + str(exc)):
        st.error(
            "\U0001f6ab **Invalid API key.**\n\n"
            "The key was not recognised by the YouTube API. "
            "Double-check it in the sidebar — it should be a 39-character string starting with `AIza`."
        )
    else:
        st.error(
            f"\U0001f4f4 **YouTube API error (HTTP {status}).**\n\n{message}"
        )


# ---------------------------------------------------------------------------
# API key persistence  (~/.ranktube/config)
# ---------------------------------------------------------------------------

_CONFIG_DIR = pathlib.Path.home() / ".ranktube"
_CONFIG_FILE = _CONFIG_DIR / "config"
_CONFIG_SECTION = "youtube"
_CONFIG_KEY = "api_key"


def _load_api_key() -> str | None:
    """Return the stored API key, or None if not set."""
    if not _CONFIG_FILE.exists():
        return None
    cfg = configparser.ConfigParser()
    cfg.read(_CONFIG_FILE)
    return cfg.get(_CONFIG_SECTION, _CONFIG_KEY, fallback=None) or None


def _save_api_key(key: str) -> None:
    """Write the API key to ~/.ranktube/config, creating the directory if needed."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    cfg = configparser.ConfigParser()
    if _CONFIG_FILE.exists():
        cfg.read(_CONFIG_FILE)
    if not cfg.has_section(_CONFIG_SECTION):
        cfg.add_section(_CONFIG_SECTION)
    cfg.set(_CONFIG_SECTION, _CONFIG_KEY, key)
    with open(_CONFIG_FILE, "w") as f:
        cfg.write(f)


def _key_looks_valid(key: str) -> bool:
    """Basic format check: YouTube API keys start with 'AIza' and are 39 chars."""
    return key.startswith("AIza") and len(key) == 39


# ---------------------------------------------------------------------------
# First-run setup screen
# ---------------------------------------------------------------------------

def _render_setup_screen() -> None:
    """Full-page setup screen shown when no API key is stored."""
    col_l, col_c, col_r = st.columns([1, 2, 1])
    with col_c:
        st.title("Welcome to RankTube")
        st.markdown(
            "Before you start searching, RankTube needs a **YouTube Data API v3 key**. "
            "This key is free and takes about 5 minutes to create. It will be saved "
            "to `~/.ranktube/config` so you only need to do this once."
        )
        st.divider()

        st.subheader("How to get a YouTube API key")
        st.markdown(
            "**Step 1 — Open Google Cloud Console**\n\n"
            "Go to [console.cloud.google.com](https://console.cloud.google.com/) "
            "and sign in with your Google account."
        )
        st.markdown(
            "**Step 2 — Create or select a project**\n\n"
            "Click the project dropdown at the top, then **New Project**. "
            "Give it any name (e.g. `ranktube`) and click **Create**."
        )
        st.markdown(
            "**Step 3 — Enable the YouTube Data API v3**\n\n"
            "In the left menu go to **APIs & Services → Library**. "
            "Search for **YouTube Data API v3**, click it, then click **Enable**."
        )
        st.markdown(
            "**Step 4 — Create an API key**\n\n"
            "Go to **APIs & Services → Credentials**. "
            "Click **+ Create Credentials → API key**. "
            "Copy the key shown in the dialog."
        )
        st.info(
            "The free quota is **10,000 units per day** — enough for dozens of searches. "
            "You can optionally restrict the key to the YouTube Data API v3 in the "
            "Credentials page for added security.",
            icon="💡",
        )
        st.divider()

        st.subheader("Paste your API key")
        key_input = st.text_input(
            "YouTube API Key",
            type="password",
            placeholder="AIza...",
            help="39-character key starting with AIza. It will be stored in ~/.ranktube/config.",
        )

        if st.button("Save & continue", type="primary", use_container_width=True):
            key = key_input.strip()
            if not key:
                st.error("Please paste your API key before continuing.")
            elif not _key_looks_valid(key):
                st.error(
                    "That doesn't look like a valid YouTube API key. "
                    "It should be 39 characters and start with `AIza`."
                )
            else:
                _save_api_key(key)
                st.success("API key saved to `~/.ranktube/config`.")
                st.rerun()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _capture_format_output(scored: list[ScoredVideo], mode: str) -> str:
    """Capture format_output's stdout as a string."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        format_output(scored, mode=mode)
    return buf.getvalue()


def _render_urls_mode(scored: list[ScoredVideo]) -> None:
    url_text = "\n".join(v.url for v in scored)
    st.code(url_text, language=None)
    st.download_button(
        label="Download URLs (.txt)",
        data=url_text,
        file_name="ranktube_urls.txt",
        mime="text/plain",
    )


def _render_rich_table(scored: list[ScoredVideo]) -> None:
    rows = []
    for rank, v in enumerate(scored, start=1):
        rows.append(
            {
                "Rank": rank,
                "Title": v.title,
                "Channel": v.channel,
                "Views": _fmt_count(v.view_count),
                "Subscribers": _fmt_count(v.subscriber_count),
                "Duration": _fmt_duration(v.duration_seconds),
                "Relevance Score": round(v.score, 4),
                "Rank Score": round(v.rank_score, 4),
                "Matched Keywords": ", ".join(v.matched_keywords),
                "URL": v.url,
            }
        )

    st.dataframe(
        rows,
        column_config={
            "URL": st.column_config.LinkColumn("URL"),
        },
        use_container_width=True,
        hide_index=True,
    )

    json_data = json.dumps(
        [
            {
                "rank": i + 1,
                "title": v.title,
                "channel": v.channel,
                "url": v.url,
                "views": v.view_count,
                "subscribers": v.subscriber_count,
                "duration_seconds": v.duration_seconds,
                "relevance_score": v.score,
                "rank_score": v.rank_score,
                "matched_keywords": v.matched_keywords,
            }
            for i, v in enumerate(scored)
        ],
        indent=2,
        ensure_ascii=False,
    )
    st.download_button(
        label="Download Results (.json)",
        data=json_data,
        file_name="ranktube_results.json",
        mime="application/json",
    )


def _render_formatted_text(scored: list[ScoredVideo], mode: str) -> None:
    raw = _capture_format_output(scored, mode)
    with st.expander("Raw formatted output"):
        st.text(raw)


def _render_json_mode(scored: list[ScoredVideo]) -> None:
    captured = _capture_format_output(scored, "json")
    st.code(captured, language="json")
    st.download_button(
        label="Download JSON (.json)",
        data=captured,
        file_name="ranktube_results.json",
        mime="application/json",
    )


def _render_info_panel() -> None:
    """Right-hand info panel shown before any search is run."""
    st.markdown("### What is RankTube?")
    st.markdown(
        "RankTube searches YouTube and **ranks results by relevance**, not by YouTube's "
        "default popularity algorithm. It scores each video across title, description, "
        "tags, and channel name — then combines that with view and subscriber counts to "
        "produce a final ranked list."
    )

    st.divider()

    st.markdown("### What does it output?")
    st.markdown(
        "| Mode | Output |\n"
        "|---|---|\n"
        "| **urls** | One YouTube URL per line — plain list |\n"
        "| **details** | Table with scores, views, duration, channel |\n"
        "| **json** | Machine-readable JSON array |\n"
        "| **verbose** | Full detail with description snippets |"
    )

    st.divider()

    st.markdown("### What can you do with the results?")

    st.markdown("**Research & learning**")
    st.markdown(
        "- Upload the URL list to **[NotebookLM](https://notebooklm.google.com/)** "
        "— Google's AI research tool ingests YouTube URLs directly. "
        "Great for deep-diving a topic across multiple videos.\n"
        "- Paste URLs into **[Claude](https://claude.ai/)** or **ChatGPT** and ask "
        "it to summarise, compare, or extract key concepts across the set.\n"
        "- Feed URLs to **[Fabric](https://github.com/danielmiessler/fabric)** "
        "(`yt` + `extract_wisdom` pattern) for automated transcript analysis."
    )

    st.markdown("**Content creation**")
    st.markdown(
        "- Use ranked results to audit what's already covered in your niche "
        "before recording your own video.\n"
        "- Export as JSON and load into a spreadsheet to track competitor channels "
        "over time."
    )

    st.markdown("**Developer / automation**")
    st.markdown(
        "- The JSON output can be piped directly into any downstream script or "
        "data pipeline.\n"
        "- Use the CLI (`ranktube` command) in cron jobs or CI workflows to build "
        "scheduled keyword-monitoring reports."
    )

    st.divider()

    st.markdown("### How scoring works")
    st.markdown(
        "Each video gets a **relevance score** (0–1) based on keyword matches:\n\n"
        "| Field | Weight |\n"
        "|---|---|\n"
        "| Title | 40% |\n"
        "| Description | 25% |\n"
        "| Tags | 20% |\n"
        "| Exact phrase | 10% |\n"
        "| Channel name | 5% |\n\n"
        "The final **rank score** blends relevance (60%) with log-normalised "
        "view count (25%) and subscriber count (15%)."
    )

    st.divider()

    st.caption(
        "Tip: lower the Min Relevance Score slider if you get zero results. "
        "Use Channel filter to narrow results to a specific creator."
    )


def _render_results(scored: list[ScoredVideo], output_mode: str) -> None:
    st.markdown(f"**{len(scored)} result(s) found.**")

    if output_mode == "urls":
        _render_urls_mode(scored)
    elif output_mode in ("details", "verbose"):
        _render_rich_table(scored)
        _render_formatted_text(scored, output_mode)
    elif output_mode == "json":
        _render_json_mode(scored)


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------


def _build_sidebar(stored_key: str) -> dict:
    """Render all sidebar widgets and return a dict of input values."""
    with st.sidebar:
        st.title("RankTube")
        st.markdown("Search and rank YouTube videos by relevance.")
        st.divider()

        keywords_raw = st.text_input(
            "Keywords",
            help=(
                "Comma-separated phrases matched against video title, description, "
                "tags, and channel name. Each phrase is scored independently."
            ),
        )
        st.caption("Separate multiple phrases with commas.")

        channel_filter = st.radio(
            "Channel filter",
            options=["None", "Channel Name", "Channel ID"],
            help=(
                "**None** — search all of YouTube (no quota cost for resolution).\n\n"
                "**Channel Name** — enter a display name; the app resolves it to a "
                "channel ID automatically (costs one extra API call).\n\n"
                "**Channel ID** — paste the exact YouTube channel ID (e.g. "
                "UC4a-Gbdigs3jaI_mG1Um6Hg); no resolution step needed."
            ),
        )

        channel_name_input = ""
        channel_id_input = ""
        if channel_filter == "Channel Name":
            channel_name_input = st.text_input(
                "Channel Name",
                help=(
                    "The channel's display name (e.g. 'Khan Academy'). "
                    "It will be resolved to a channel ID automatically."
                ),
            )
        elif channel_filter == "Channel ID":
            channel_id_input = st.text_input(
                "Channel ID",
                help=(
                    "The exact YouTube channel ID (e.g. UC4a-Gbdigs3jaI_mG1Um6Hg). "
                    "Find it in the channel's About page or URL."
                ),
            )

        top_n = st.number_input(
            "Max Results (Top N)",
            min_value=1,
            value=None,
            placeholder="All",
            help=(
                "Cap the number of results returned. Leave blank to retrieve all "
                "available results (up to the API pagination limit)."
            ),
        )

        min_score = st.slider(
            "Min Relevance Score",
            min_value=0.0,
            max_value=1.0,
            value=0.1,
            step=0.05,
            help=(
                "Minimum relevance score a video must reach to appear in results. "
                "Scoring weights: title 40%, description 25%, tags 20%, "
                "exact phrase 10%, channel name 5%."
            ),
        )

        output_mode = st.radio(
            "Output Mode",
            options=["urls", "details", "json", "verbose"],
            help=(
                "**urls** — one URL per line, good for piping.\n\n"
                "**details** — human-readable summary with scores and snippets.\n\n"
                "**json** — machine-readable JSON array.\n\n"
                "**verbose** — detailed view with separator lines between results."
            ),
        )

        st.divider()

        # Show masked key + option to change it
        masked = stored_key[:4] + "•" * (len(stored_key) - 8) + stored_key[-4:]
        st.caption(f"API key: `{masked}`")
        with st.expander("Change API key"):
            new_key_input = st.text_input(
                "New API Key",
                type="password",
                placeholder="AIza...",
                key="change_api_key_input",
            )
            if st.button("Update key", use_container_width=True):
                new_key = new_key_input.strip()
                if not new_key:
                    st.error("Key cannot be empty.")
                elif not _key_looks_valid(new_key):
                    st.error("Must be 39 characters starting with `AIza`.")
                else:
                    _save_api_key(new_key)
                    st.success("Key updated.")
                    st.rerun()

        st.divider()
        search_clicked = st.button("Search", type="primary", use_container_width=True)

    return {
        "keywords_raw": keywords_raw,
        "channel_filter": channel_filter,
        "channel_name_input": channel_name_input,
        "channel_id_input": channel_id_input,
        "top_n": int(top_n) if top_n is not None else None,
        "min_score": min_score,
        "output_mode": output_mode,
        "search_clicked": search_clicked,
    }


# ---------------------------------------------------------------------------
# Main app
# ---------------------------------------------------------------------------


def run_app() -> None:
    load_dotenv()

    # Setup is considered complete only when ~/.ranktube/config exists.
    # The env var is a runtime fallback but does NOT bypass the setup screen —
    # otherwise deleting the config file would have no effect on first-run UX.
    config_key: str | None = _load_api_key()

    if not config_key:
        _render_setup_screen()
        st.stop()

    # Runtime key: config file takes precedence, env var as fallback.
    stored_key: str = config_key or os.environ.get("YOUTUBE_API_KEY", "")

    inputs = _build_sidebar(stored_key)

    st.title("RankTube")

    has_results = "last_results" in st.session_state

    if inputs["search_clicked"]:
        # --- Validate inputs ---
        keywords_raw: str = inputs["keywords_raw"].strip()
        if not keywords_raw:
            st.error("Please enter at least one keyword.")
            st.stop()

        api_key: str = stored_key

        keywords = [k.strip() for k in keywords_raw.split(",") if k.strip()]

        # --- Resolve channel filter ---
        channel_id: str | None = None
        if inputs["channel_filter"] == "Channel Name":
            name = inputs["channel_name_input"].strip()
            if name:
                try:
                    with st.spinner(f"Resolving channel '{name}'…"):
                        channel_id = resolve_channel_id(name, api_key)
                except HttpError as exc:
                    _show_api_error(exc)
                    st.stop()
                if channel_id is None:
                    st.warning(
                        f"Could not resolve channel name '{name}'. "
                        "Continuing without channel filter."
                    )
        elif inputs["channel_filter"] == "Channel ID":
            raw_id = inputs["channel_id_input"].strip()
            if raw_id:
                channel_id = raw_id

        # --- Run pipeline ---
        try:
            with st.spinner("Searching YouTube…"):
                raw_videos = search_videos(
                    keywords=keywords,
                    api_key=api_key,
                    channel_id=channel_id,
                    top=inputs["top_n"],
                )
        except HttpError as exc:
            _show_api_error(exc)
            st.stop()
        except Exception as exc:
            st.error(f"\u26a0\ufe0f **Unexpected error:** {exc}")
            st.stop()

        with st.spinner("Scoring and filtering results…"):
            scored = score_and_filter(
                videos=raw_videos,
                keywords=keywords,
                min_score=inputs["min_score"],
            )

        if not scored:
            st.warning(
                "No results matched the criteria. "
                "Try lowering the Min Relevance Score or using different keywords."
            )
            st.stop()

        st.session_state["last_results"] = scored
        st.session_state["last_mode"] = inputs["output_mode"]
        has_results = True

    if has_results:
        _render_results(st.session_state["last_results"], st.session_state["last_mode"])
    else:
        _render_info_panel()


# ---------------------------------------------------------------------------
# Module-level execution (for `streamlit run src/ranktube/ui.py`)
# ---------------------------------------------------------------------------

run_app()


# ---------------------------------------------------------------------------
# Entry point for `rt-ui` script
# ---------------------------------------------------------------------------


def main() -> None:
    """Entry point for the rt-ui console script."""
    try:
        import streamlit  # noqa: F401
    except ImportError:
        print(
            "Error: the UI extra is not installed.\n"
            "\n"
            "Install it with:\n"
            "    pip install ranktube[ui]\n"
            "\n"
            "Or, to install everything:\n"
            "    pip install ranktube[all]",
            file=sys.stderr,
        )
        sys.exit(1)

    import subprocess  # noqa: PLC0415

    subprocess.run(
        [sys.executable, "-m", "streamlit", "run", __file__] + sys.argv[1:],
        check=True,
    )
