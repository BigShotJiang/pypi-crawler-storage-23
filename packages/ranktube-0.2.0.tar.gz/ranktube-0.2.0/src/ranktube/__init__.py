"""RankTube — YouTube URL scraper using YouTube Data API v3."""

__version__ = "0.1.0"
