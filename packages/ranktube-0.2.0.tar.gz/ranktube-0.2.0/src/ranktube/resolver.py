"""Channel name → channel ID resolution via YouTube Data API v3."""

from __future__ import annotations

import sys

from googleapiclient.errors import HttpError

from .api import build_youtube_service

_CHANNEL_SEARCH_RESULTS = 5


def resolve_channel_id(channel_name: str, api_key: str) -> str | None:
    """Resolve a human-readable channel name to a YouTube channel ID.

    Strategy:
    1. Search for up to ``_CHANNEL_SEARCH_RESULTS`` channels matching the query.
    2. Return the first result whose title contains ``channel_name`` as a
       case-insensitive substring.
    3. Fall back to the first result with a warning printed to stderr.
    4. Return ``None`` if the API returns no results.

    Args:
        channel_name: The display name to search for (e.g. ``"Khan Academy"``).
        api_key: YouTube Data API v3 key.

    Returns:
        The channel ID string (e.g. ``"UC4a-Gbdigs3jaI_mG1Um6Hg"``), or
        ``None`` if no results were found.
    """
    youtube = build_youtube_service(api_key)

    try:
        response = (
            youtube.search()
            .list(
                part="snippet",
                q=channel_name,
                type="channel",
                maxResults=_CHANNEL_SEARCH_RESULTS,
            )
            .execute()
        )
    except HttpError as exc:
        print(f"YouTube API error resolving channel: {exc}", file=sys.stderr)
        raise

    items = response.get("items", [])
    if not items:
        print(
            f"Warning: no channels found for '{channel_name}'.",
            file=sys.stderr,
        )
        return None

    name_lower = channel_name.lower()
    for item in items:
        title: str = item.get("snippet", {}).get("title", "")
        if name_lower in title.lower():
            return item["id"]["channelId"]

    # Fallback: use the first result
    first_title = items[0].get("snippet", {}).get("title", "")
    first_id = items[0]["id"]["channelId"]
    print(
        f"Warning: exact match for '{channel_name}' not found; "
        f"using first result '{first_title}' ({first_id}).",
        file=sys.stderr,
    )
    return first_id
