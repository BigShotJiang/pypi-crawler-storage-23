"""YouTube Data API v3 client — search and video-detail fetching."""

from __future__ import annotations

import re
import sys
from typing import Any

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

_YOUTUBE_API_SERVICE = "youtube"
_YOUTUBE_API_VERSION = "v3"
_SEARCH_PAGE_SIZE = 50   # max allowed by the API
_DETAIL_BATCH_SIZE = 50  # videos.list accepts up to 50 IDs per call
_MAX_PAGES = 10          # safety cap when no --top is given (10 × 50 = 500 candidates)

# Shorts are <= 60 seconds; we want long-form content only.
_MIN_DURATION_SECONDS = 180  # drop anything under 3 minutes


def build_youtube_service(api_key: str) -> Any:
    """Return an authenticated googleapiclient Resource for the YouTube Data API."""
    return build(_YOUTUBE_API_SERVICE, _YOUTUBE_API_VERSION, developerKey=api_key)


def _parse_duration_seconds(iso_duration: str) -> int:
    """Convert an ISO 8601 duration string (PT#H#M#S) to total seconds."""
    match = re.fullmatch(
        r"P(?:(\d+)D)?T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?",
        iso_duration,
    )
    if not match:
        return 0
    days, hours, minutes, seconds = (int(v) if v else 0 for v in match.groups())
    return days * 86400 + hours * 3600 + minutes * 60 + seconds


def search_videos(
    keywords: list[str],
    api_key: str,
    channel_id: str | None = None,
    top: int | None = None,
) -> list[dict]:
    """Search YouTube for videos matching *keywords*.

    Args:
        keywords:   One or more keyword strings joined into a single query.
        api_key:    YouTube Data API v3 key.
        channel_id: Optional channel ID to restrict results.
        top:        Stop fetching once this many results are collected (``None`` = all).

    Returns:
        List of raw video dicts enriched with tags, duration, view_count, and
        subscriber_count. Shorts (< 3 minutes) are excluded.
    """
    youtube = build_youtube_service(api_key)
    query = " ".join(keywords)
    results: list[dict] = []
    page_token: str | None = None

    # Fetch more candidates than requested so the duration filter still leaves
    # enough results. When top is None we paginate up to _MAX_PAGES pages.
    fetch_target = (top * 5) if top is not None else None
    pages_fetched = 0

    try:
        while True:
            if fetch_target is not None:
                remaining = fetch_target - len(results)
                if remaining <= 0:
                    break
                page_size = min(_SEARCH_PAGE_SIZE, remaining)
            else:
                page_size = _SEARCH_PAGE_SIZE

            request_kwargs: dict[str, Any] = {
                "part": "snippet",
                "q": query,
                "type": "video",
                # No videoDuration filter here — we apply our own _MIN_DURATION_SECONDS
                # check after fetching details. The API's "medium" filter silently drops
                # videos >20 min (e.g. full TED talks), and "long" drops 4-20 min content.
                "maxResults": page_size,
            }
            if channel_id:
                request_kwargs["channelId"] = channel_id
            if page_token:
                request_kwargs["pageToken"] = page_token

            response = youtube.search().list(**request_kwargs).execute()
            pages_fetched += 1

            for item in response.get("items", []):
                video_id = item["id"]["videoId"]
                snippet = item.get("snippet", {})
                results.append(
                    {
                        "video_id": video_id,
                        "url": f"https://www.youtube.com/watch?v={video_id}",
                        "title": snippet.get("title", ""),
                        "channel": snippet.get("channelTitle", ""),
                        "channel_id": snippet.get("channelId", ""),
                        "description": snippet.get("description", ""),
                        "tags": [],
                        "duration_seconds": 0,
                        "view_count": 0,
                        "subscriber_count": 0,
                    }
                )

            page_token = response.get("nextPageToken")
            if not page_token:
                break
            if fetch_target is None and pages_fetched >= _MAX_PAGES:
                break

    except HttpError as exc:
        print(f"YouTube API error during search: {exc}", file=sys.stderr)
        raise

    if not results:
        return results

    # Enrich with tags, duration, and view count from videos.list
    video_ids = [r["video_id"] for r in results]
    details = fetch_video_details(video_ids, api_key)
    for r in results:
        d = details.get(r["video_id"], {})
        r["tags"] = d.get("tags", [])
        r["duration_seconds"] = d.get("duration_seconds", 0)
        r["view_count"] = d.get("view_count", 0)

    # Filter out shorts / very short videos
    results = [r for r in results if r["duration_seconds"] >= _MIN_DURATION_SECONDS]

    # Enrich with subscriber counts from channels.list
    channel_ids = list({r["channel_id"] for r in results if r["channel_id"]})
    sub_map = fetch_subscriber_counts(channel_ids, api_key)
    for r in results:
        r["subscriber_count"] = sub_map.get(r["channel_id"], 0)

    return results


def fetch_video_details(video_ids: list[str], api_key: str) -> dict[str, dict]:
    """Fetch snippet + contentDetails + statistics for a list of video IDs.

    Returns:
        Mapping of ``video_id → detail_dict`` with tags, duration_seconds,
        and view_count.
    """
    youtube = build_youtube_service(api_key)
    details: dict[str, dict] = {}

    try:
        for batch_start in range(0, len(video_ids), _DETAIL_BATCH_SIZE):
            batch = video_ids[batch_start : batch_start + _DETAIL_BATCH_SIZE]
            response = (
                youtube.videos()
                .list(
                    part="snippet,contentDetails,statistics",
                    id=",".join(batch),
                )
                .execute()
            )
            for item in response.get("items", []):
                vid = item["id"]
                snippet = item.get("snippet", {})
                content = item.get("contentDetails", {})
                stats = item.get("statistics", {})
                details[vid] = {
                    "tags": snippet.get("tags", []),
                    "title": snippet.get("title", ""),
                    "description": snippet.get("description", ""),
                    "channel": snippet.get("channelTitle", ""),
                    "duration_seconds": _parse_duration_seconds(
                        content.get("duration", "PT0S")
                    ),
                    "view_count": int(stats.get("viewCount", 0)),
                }
    except HttpError as exc:
        print(f"YouTube API error fetching video details: {exc}", file=sys.stderr)
        raise

    return details


def fetch_subscriber_counts(channel_ids: list[str], api_key: str) -> dict[str, int]:
    """Fetch subscriber counts for a list of channel IDs.

    Returns:
        Mapping of ``channel_id → subscriber_count``.
    """
    if not channel_ids:
        return {}

    youtube = build_youtube_service(api_key)
    sub_map: dict[str, int] = {}

    try:
        for batch_start in range(0, len(channel_ids), _DETAIL_BATCH_SIZE):
            batch = channel_ids[batch_start : batch_start + _DETAIL_BATCH_SIZE]
            response = (
                youtube.channels()
                .list(part="statistics", id=",".join(batch))
                .execute()
            )
            for item in response.get("items", []):
                cid = item["id"]
                stats = item.get("statistics", {})
                # Some channels hide subscriber counts; default to 0
                sub_map[cid] = int(stats.get("subscriberCount", 0))
    except HttpError as exc:
        print(f"YouTube API error fetching channel stats: {exc}", file=sys.stderr)
        raise

    return sub_map
