"""Relevance scoring engine for YouTube search results."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Relevance scoring weights — must sum to 1.0
# ---------------------------------------------------------------------------
_W_TITLE = 0.40
_W_DESC = 0.25
_W_TAGS = 0.20
_W_EXACT = 0.10
_W_CHANNEL = 0.05

_DESC_CHAR_LIMIT = 500  # only first N chars of description are scored

# ---------------------------------------------------------------------------
# Final ranking weights
# Composite rank = relevance * _R_RELEVANCE
#                + log_views   * _R_VIEWS
#                + log_subs    * _R_SUBS
# ---------------------------------------------------------------------------
_R_RELEVANCE = 0.60
_R_VIEWS = 0.25
_R_SUBS = 0.15


@dataclass
class ScoredVideo:
    """A YouTube video enriched with a relevance score and engagement signals."""

    video_id: str
    url: str
    title: str
    channel: str
    description: str
    score: float                          # pure relevance score (0–1)
    rank_score: float = 0.0               # composite score used for final ordering
    duration_seconds: int = 0
    view_count: int = 0
    subscriber_count: int = 0
    matched_keywords: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _tokenize(text: str) -> set[str]:
    """Lowercase, strip punctuation, split on whitespace."""
    return set(re.sub(r"[^\w\s]", " ", text.lower()).split())


def _token_overlap(a_tokens: set[str], b_tokens: set[str]) -> float:
    """Fraction of *b_tokens* that appear in *a_tokens*.

    Returns 0.0 when *b_tokens* is empty.
    """
    if not b_tokens:
        return 0.0
    return len(a_tokens & b_tokens) / len(b_tokens)


def _exact_phrase_bonus(text: str, phrases: list[str]) -> float:
    """1.0 if *any* multi-word phrase appears literally in *text*, else 0.0."""
    text_lower = text.lower()
    for phrase in phrases:
        if len(phrase.split()) > 1 and phrase.lower() in text_lower:
            return 1.0
    return 0.0


def _score_video(
    video: dict, keyword_tokens: set[str], phrases: list[str]
) -> tuple[float, list[str]]:
    """Compute a relevance score for *video* against *keyword_tokens*.

    Returns:
        (score, matched_keywords)
    """
    title_tokens = _tokenize(video.get("title", ""))
    desc_tokens = _tokenize(video.get("description", "")[:_DESC_CHAR_LIMIT])
    tag_tokens: set[str] = set()
    for tag in video.get("tags", []):
        tag_tokens |= _tokenize(tag)
    channel_tokens = _tokenize(video.get("channel", ""))

    combined_text = video.get("title", "") + " " + video.get("description", "")

    score = (
        _W_TITLE * _token_overlap(title_tokens, keyword_tokens)
        + _W_DESC * _token_overlap(desc_tokens, keyword_tokens)
        + _W_TAGS * _token_overlap(tag_tokens, keyword_tokens)
        + _W_EXACT * _exact_phrase_bonus(combined_text, phrases)
        + _W_CHANNEL * _token_overlap(channel_tokens, keyword_tokens)
    )

    matched: list[str] = []
    for phrase in phrases:
        phrase_tokens = _tokenize(phrase)
        if phrase_tokens & (title_tokens | desc_tokens | tag_tokens):
            matched.append(phrase)

    return round(score, 4), matched


def _log_norm(value: int, scale: float) -> float:
    """Map *value* to [0, 1] using log scaling.

    log(1 + value) / log(1 + scale)  — capped at 1.0.
    scale should be a representative "very high" value for the signal.
    """
    if value <= 0:
        return 0.0
    return min(1.0, math.log1p(value) / math.log1p(scale))


# Reference points for normalisation (tunable)
_VIEW_SCALE = 10_000_000   # 10 M views → score ≈ 1.0
_SUB_SCALE = 10_000_000    # 10 M subscribers → score ≈ 1.0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def score_and_filter(
    videos: list[dict],
    keywords: list[str],
    min_score: float = 0.1,
) -> list[ScoredVideo]:
    """Score each video and return those meeting *min_score*, sorted by rank.

    Ranking combines:
      - Relevance score (keyword match quality)        — 60 %
      - Normalised view count (log scale, 10 M ref)    — 25 %
      - Normalised subscriber count (log scale, 10 M)  — 15 %

    Args:
        videos:    Raw video dicts from ``api.search_videos``.
        keywords:  The original keyword phrases supplied by the user.
        min_score: Minimum *relevance* score (0.0–1.0) to keep a video.

    Returns:
        List of :class:`ScoredVideo` sorted by composite rank_score descending.
    """
    keyword_tokens: set[str] = set()
    for kw in keywords:
        keyword_tokens |= _tokenize(kw)

    scored: list[ScoredVideo] = []
    for v in videos:
        relevance, matched = _score_video(v, keyword_tokens, keywords)
        if relevance < min_score:
            continue

        view_count = v.get("view_count", 0)
        subscriber_count = v.get("subscriber_count", 0)

        rank_score = round(
            _R_RELEVANCE * relevance
            + _R_VIEWS * _log_norm(view_count, _VIEW_SCALE)
            + _R_SUBS * _log_norm(subscriber_count, _SUB_SCALE),
            4,
        )

        scored.append(
            ScoredVideo(
                video_id=v.get("video_id", ""),
                url=v.get("url", ""),
                title=v.get("title", ""),
                channel=v.get("channel", ""),
                description=v.get("description", ""),
                score=relevance,
                rank_score=rank_score,
                duration_seconds=v.get("duration_seconds", 0),
                view_count=view_count,
                subscriber_count=subscriber_count,
                matched_keywords=matched,
                tags=v.get("tags", []),
            )
        )

    scored.sort(key=lambda sv: sv.rank_score, reverse=True)
    return scored
