"""Output formatters for RankTube results."""

from __future__ import annotations

import json
import sys

from .scorer import ScoredVideo

_SEPARATOR = "-" * 60


def _fmt_count(n: int) -> str:
    """Human-readable number: 1234567 → '1.2M', 12345 → '12.3K'."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def _fmt_duration(seconds: int) -> str:
    """Seconds to mm:ss or h:mm:ss."""
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def format_output(videos: list[ScoredVideo], mode: str) -> None:
    """Write formatted results to stdout.

    Args:
        videos: Scored and filtered videos, sorted by rank_score.
        mode:   One of ``"urls"``, ``"details"``, ``"json"``, or ``"verbose"``.
    """
    if not videos:
        print("No results matched the given criteria.", file=sys.stderr)
        return

    if mode == "urls":
        _format_urls(videos)
    elif mode == "details":
        _format_details(videos)
    elif mode == "json":
        _format_json(videos)
    elif mode == "verbose":
        _format_verbose(videos)
    else:
        raise ValueError(f"Unknown output mode: {mode!r}")


def _format_urls(videos: list[ScoredVideo]) -> None:
    for v in videos:
        print(v.url)


def _format_details(videos: list[ScoredVideo]) -> None:
    for v in videos:
        print(f"Title:    {v.title}")
        print(f"Channel:  {v.channel}  ({_fmt_count(v.subscriber_count)} subs)")
        print(f"Views:    {_fmt_count(v.view_count)}  |  Duration: {_fmt_duration(v.duration_seconds)}")
        print(f"Rank:     {v.rank_score:.4f}  (relevance: {v.score:.4f})")
        print(f"URL:      {v.url}")
        if v.description:
            snippet = v.description[:200].replace("\n", " ")
            print(f"Snippet:  {snippet}...")
        if v.matched_keywords:
            print(f"Matched:  {', '.join(v.matched_keywords)}")
        print()


def _format_json(videos: list[ScoredVideo]) -> None:
    records = [
        {
            "url": v.url,
            "title": v.title,
            "channel": v.channel,
            "duration": _fmt_duration(v.duration_seconds),
            "duration_seconds": v.duration_seconds,
            "views": v.view_count,
            "subscribers": v.subscriber_count,
            "rank_score": v.rank_score,
            "relevance_score": v.score,
            "matched_keywords": v.matched_keywords,
        }
        for v in videos
    ]
    print(json.dumps(records, indent=2, ensure_ascii=False))


def _format_verbose(videos: list[ScoredVideo]) -> None:
    for i, v in enumerate(videos, start=1):
        print(_SEPARATOR)
        print(f"#{i}  Rank: {v.rank_score:.4f}  (relevance: {v.score:.4f})")
        print(f"Title:    {v.title}")
        print(f"Channel:  {v.channel}  ({_fmt_count(v.subscriber_count)} subs)")
        print(f"Views:    {_fmt_count(v.view_count)}  |  Duration: {_fmt_duration(v.duration_seconds)}")
        print(f"URL:      {v.url}")
        if v.description:
            snippet = v.description[:200].replace("\n", " ")
            print(f"Snippet:  {snippet}...")
        if v.matched_keywords:
            print(f"Matched:  {', '.join(v.matched_keywords)}")
    print(_SEPARATOR)
