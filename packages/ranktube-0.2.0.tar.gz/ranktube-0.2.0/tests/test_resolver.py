"""Tests for resolver.py — all YouTube API calls are mocked."""

from unittest.mock import MagicMock, patch

import pytest

from ytscraper.resolver import resolve_channel_id


def _make_channel_item(channel_id: str, title: str) -> dict:
    return {
        "id": {"channelId": channel_id},
        "snippet": {"title": title},
    }


@patch("ytscraper.resolver.build_youtube_service")
class TestResolveChannelId:
    def _setup_mock(self, mock_build, items: list[dict]) -> MagicMock:
        mock_youtube = MagicMock()
        mock_build.return_value = mock_youtube
        (
            mock_youtube.search.return_value.list.return_value.execute.return_value
        ) = {"items": items}
        return mock_youtube

    def test_exact_match_returned(self, mock_build):
        items = [
            _make_channel_item("UC_correct", "Khan Academy"),
            _make_channel_item("UC_other", "Khan Academy Fan"),
        ]
        self._setup_mock(mock_build, items)
        result = resolve_channel_id("Khan Academy", "fake_key")
        assert result == "UC_correct"

    def test_case_insensitive_match(self, mock_build):
        items = [_make_channel_item("UC_correct", "Khan Academy")]
        self._setup_mock(mock_build, items)
        result = resolve_channel_id("khan academy", "fake_key")
        assert result == "UC_correct"

    def test_substring_match(self, mock_build):
        items = [_make_channel_item("UC_correct", "Khan Academy Official")]
        self._setup_mock(mock_build, items)
        result = resolve_channel_id("Khan Academy", "fake_key")
        assert result == "UC_correct"

    def test_fallback_to_first_result_when_no_match(self, mock_build, capsys):
        items = [
            _make_channel_item("UC_first", "Totally Different Channel"),
            _make_channel_item("UC_second", "Another Channel"),
        ]
        self._setup_mock(mock_build, items)
        result = resolve_channel_id("Khan Academy", "fake_key")
        assert result == "UC_first"
        captured = capsys.readouterr()
        assert "Warning" in captured.err

    def test_no_results_returns_none(self, mock_build, capsys):
        self._setup_mock(mock_build, [])
        result = resolve_channel_id("Nonexistent Channel", "fake_key")
        assert result is None
        captured = capsys.readouterr()
        assert "Warning" in captured.err

    def test_api_called_with_correct_params(self, mock_build):
        items = [_make_channel_item("UC_correct", "Khan Academy")]
        mock_youtube = self._setup_mock(mock_build, items)
        resolve_channel_id("Khan Academy", "my_api_key")
        mock_youtube.search.return_value.list.assert_called_once_with(
            part="snippet",
            q="Khan Academy",
            type="channel",
            maxResults=5,
        )
