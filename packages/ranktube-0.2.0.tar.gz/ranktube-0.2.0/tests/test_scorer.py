"""Unit tests for scorer.py — no API calls required."""

import pytest

from ytscraper.scorer import (
    ScoredVideo,
    _exact_phrase_bonus,
    _token_overlap,
    _tokenize,
    score_and_filter,
)


# ---------------------------------------------------------------------------
# _tokenize
# ---------------------------------------------------------------------------

class TestTokenize:
    def test_lowercases(self):
        assert "hello" in _tokenize("Hello World")

    def test_strips_punctuation(self):
        tokens = _tokenize("kids, brainstorming!")
        assert "kids" in tokens
        assert "brainstorming" in tokens

    def test_empty_string(self):
        assert _tokenize("") == set()

    def test_deduplicates(self):
        tokens = _tokenize("cat cat cat")
        assert tokens == {"cat"}


# ---------------------------------------------------------------------------
# _token_overlap
# ---------------------------------------------------------------------------

class TestTokenOverlap:
    def test_full_overlap(self):
        a = {"kids", "learn"}
        b = {"kids", "learn"}
        assert _token_overlap(a, b) == 1.0

    def test_no_overlap(self):
        a = {"kids", "learn"}
        b = {"math", "science"}
        assert _token_overlap(a, b) == 0.0

    def test_partial_overlap(self):
        a = {"kids", "learn"}
        b = {"kids", "math"}
        assert _token_overlap(a, b) == 0.5

    def test_empty_b(self):
        assert _token_overlap({"kids"}, set()) == 0.0

    def test_empty_both(self):
        assert _token_overlap(set(), set()) == 0.0


# ---------------------------------------------------------------------------
# _exact_phrase_bonus
# ---------------------------------------------------------------------------

class TestExactPhraseBonus:
    def test_multi_word_phrase_present(self):
        assert _exact_phrase_bonus("kids brainstorming video", ["kids brainstorming"]) == 1.0

    def test_multi_word_phrase_absent(self):
        assert _exact_phrase_bonus("math learning video", ["kids brainstorming"]) == 0.0

    def test_single_word_phrase_ignored(self):
        # Single-word phrases don't trigger the exact bonus
        assert _exact_phrase_bonus("kids learning", ["kids"]) == 0.0

    def test_case_insensitive(self):
        assert _exact_phrase_bonus("Kids Brainstorming", ["kids brainstorming"]) == 1.0

    def test_any_phrase_match(self):
        assert (
            _exact_phrase_bonus("math video", ["kids brainstorming", "math video"]) == 1.0
        )


# ---------------------------------------------------------------------------
# score_and_filter
# ---------------------------------------------------------------------------

def _make_video(**kwargs) -> dict:
    defaults = {
        "video_id": "abc123",
        "url": "https://www.youtube.com/watch?v=abc123",
        "title": "",
        "channel": "",
        "description": "",
        "tags": [],
    }
    defaults.update(kwargs)
    return defaults


class TestScoreAndFilter:
    def test_returns_sorted_descending(self):
        videos = [
            _make_video(title="kids brainstorming activity", video_id="v1", url="u1"),
            _make_video(title="random unrelated content", video_id="v2", url="u2"),
        ]
        results = score_and_filter(videos, ["kids brainstorming"], min_score=0.0)
        assert results[0].score >= results[1].score

    def test_filters_below_min_score(self):
        videos = [
            _make_video(title="kids brainstorming activity", video_id="v1", url="u1"),
            _make_video(title="random unrelated content", video_id="v2", url="u2"),
        ]
        results = score_and_filter(videos, ["kids brainstorming"], min_score=0.9)
        for r in results:
            assert r.score >= 0.9

    def test_returns_scored_video_instances(self):
        videos = [_make_video(title="kids learning", video_id="v1", url="u1")]
        results = score_and_filter(videos, ["kids learning"], min_score=0.0)
        assert isinstance(results[0], ScoredVideo)

    def test_empty_videos(self):
        assert score_and_filter([], ["kids"], min_score=0.0) == []

    def test_matched_keywords_populated(self):
        videos = [_make_video(title="kids brainstorming session", video_id="v1", url="u1")]
        results = score_and_filter(videos, ["kids brainstorming", "math"], min_score=0.0)
        assert "kids brainstorming" in results[0].matched_keywords
        assert "math" not in results[0].matched_keywords

    def test_exact_phrase_boosts_score(self):
        with_phrase = _make_video(title="kids brainstorming activity", video_id="v1", url="u1")
        without_phrase = _make_video(title="kids doing brainstorming activities", video_id="v2", url="u2")
        results = score_and_filter(
            [with_phrase, without_phrase], ["kids brainstorming"], min_score=0.0
        )
        # The video with the exact phrase in title should score higher
        ids = [r.video_id for r in results]
        assert ids[0] == "v1"

    def test_description_contributes_to_score(self):
        video = _make_video(
            title="science video",
            description="kids brainstorming creative ideas",
            video_id="v1",
            url="u1",
        )
        results = score_and_filter([video], ["kids brainstorming"], min_score=0.0)
        assert results[0].score > 0.0

    def test_tags_contribute_to_score(self):
        video = _make_video(
            title="fun activity",
            tags=["kids", "brainstorming"],
            video_id="v1",
            url="u1",
        )
        results = score_and_filter([video], ["kids brainstorming"], min_score=0.0)
        assert results[0].score > 0.0

    def test_channel_contributes_to_score(self):
        video = _make_video(
            title="fun video",
            channel="kids brainstorming channel",
            video_id="v1",
            url="u1",
        )
        results = score_and_filter([video], ["kids brainstorming"], min_score=0.0)
        assert results[0].score > 0.0

    def test_score_bounded_between_zero_and_one(self):
        video = _make_video(
            title="kids brainstorming",
            description="kids brainstorming " * 50,
            tags=["kids", "brainstorming"],
            channel="kids brainstorming",
            video_id="v1",
            url="u1",
        )
        results = score_and_filter([video], ["kids brainstorming"], min_score=0.0)
        assert 0.0 <= results[0].score <= 1.0

    def test_multiple_keywords_union(self):
        video = _make_video(title="kids learning math", video_id="v1", url="u1")
        results = score_and_filter([video], ["kids brainstorming", "kids learning"], min_score=0.0)
        # "kids" and "learning" from the second phrase both appear in title
        assert results[0].score > 0.0
