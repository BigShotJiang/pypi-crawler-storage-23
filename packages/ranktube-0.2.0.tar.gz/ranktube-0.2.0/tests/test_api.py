"""Tests for api.py — all YouTube API calls are mocked."""

from unittest.mock import MagicMock, call, patch

import pytest

from ytscraper.api import fetch_video_details, search_videos


def _make_search_item(video_id: str, title: str = "", channel: str = "", description: str = "") -> dict:
    return {
        "id": {"videoId": video_id},
        "snippet": {
            "title": title,
            "channelTitle": channel,
            "description": description,
        },
    }


def _make_video_item(video_id: str, tags: list[str] | None = None) -> dict:
    return {
        "id": video_id,
        "snippet": {
            "title": "Title",
            "description": "Desc",
            "channelTitle": "Chan",
            "tags": tags or [],
        },
    }


@patch("ytscraper.api.build_youtube_service")
class TestSearchVideos:
    def _setup_search_mock(self, mock_build, pages: list[list[dict]], next_tokens: list[str | None]) -> MagicMock:
        """Wire up multiple paginated search responses."""
        mock_youtube = MagicMock()
        mock_build.return_value = mock_youtube

        # Each call to search().list().execute() returns the next page
        side_effects = []
        for page, token in zip(pages, next_tokens):
            resp: dict = {"items": page}
            if token:
                resp["nextPageToken"] = token
            side_effects.append(resp)

        mock_youtube.search.return_value.list.return_value.execute.side_effect = side_effects

        # videos.list always returns empty (tags tested separately)
        mock_youtube.videos.return_value.list.return_value.execute.return_value = {"items": []}
        return mock_youtube

    def test_single_page_results(self, mock_build):
        items = [_make_search_item("v1", "Title 1"), _make_search_item("v2", "Title 2")]
        self._setup_search_mock(mock_build, [items], [None])
        results = search_videos(["kids"], "fake_key")
        assert len(results) == 2
        assert results[0]["video_id"] == "v1"

    def test_pagination_continues_until_no_token(self, mock_build):
        page1 = [_make_search_item("v1")]
        page2 = [_make_search_item("v2")]
        self._setup_search_mock(mock_build, [page1, page2], ["token1", None])
        results = search_videos(["kids"], "fake_key")
        assert len(results) == 2

    def test_top_stops_early(self, mock_build):
        page1 = [_make_search_item(f"v{i}") for i in range(50)]
        page2 = [_make_search_item(f"v{i}") for i in range(50, 100)]
        self._setup_search_mock(mock_build, [page1, page2], ["token1", None])
        results = search_videos(["kids"], "fake_key", top=50)
        assert len(results) == 50

    def test_url_format(self, mock_build):
        items = [_make_search_item("abc123")]
        self._setup_search_mock(mock_build, [items], [None])
        results = search_videos(["kids"], "fake_key")
        assert results[0]["url"] == "https://www.youtube.com/watch?v=abc123"

    def test_channel_id_passed_to_api(self, mock_build):
        items = [_make_search_item("v1")]
        mock_youtube = self._setup_search_mock(mock_build, [items], [None])
        search_videos(["kids"], "fake_key", channel_id="UC_channel")
        call_kwargs = mock_youtube.search.return_value.list.call_args.kwargs
        assert call_kwargs["channelId"] == "UC_channel"

    def test_no_channel_id_not_in_call(self, mock_build):
        items = [_make_search_item("v1")]
        mock_youtube = self._setup_search_mock(mock_build, [items], [None])
        search_videos(["kids"], "fake_key")
        call_kwargs = mock_youtube.search.return_value.list.call_args.kwargs
        assert "channelId" not in call_kwargs

    def test_keywords_joined_into_query(self, mock_build):
        items = [_make_search_item("v1")]
        mock_youtube = self._setup_search_mock(mock_build, [items], [None])
        search_videos(["kids brainstorming", "kids learning"], "fake_key")
        call_kwargs = mock_youtube.search.return_value.list.call_args.kwargs
        assert call_kwargs["q"] == "kids brainstorming kids learning"

    def test_empty_results(self, mock_build):
        self._setup_search_mock(mock_build, [[]], [None])
        results = search_videos(["kids"], "fake_key")
        assert results == []


@patch("ytscraper.api.build_youtube_service")
class TestFetchVideoDetails:
    def _setup_mock(self, mock_build, items: list[dict]) -> MagicMock:
        mock_youtube = MagicMock()
        mock_build.return_value = mock_youtube
        mock_youtube.videos.return_value.list.return_value.execute.return_value = {"items": items}
        return mock_youtube

    def test_returns_tags(self, mock_build):
        items = [_make_video_item("v1", tags=["kids", "learning"])]
        self._setup_mock(mock_build, items)
        details = fetch_video_details(["v1"], "fake_key")
        assert details["v1"]["tags"] == ["kids", "learning"]

    def test_missing_tags_defaults_to_empty_list(self, mock_build):
        item = {
            "id": "v1",
            "snippet": {"title": "T", "description": "D", "channelTitle": "C"},
        }
        self._setup_mock(mock_build, [item])
        details = fetch_video_details(["v1"], "fake_key")
        assert details["v1"]["tags"] == []

    def test_batches_50_at_a_time(self, mock_build):
        mock_youtube = MagicMock()
        mock_build.return_value = mock_youtube
        mock_youtube.videos.return_value.list.return_value.execute.return_value = {"items": []}
        video_ids = [f"v{i}" for i in range(110)]
        fetch_video_details(video_ids, "fake_key")
        # Should have been called 3 times: 50, 50, 10
        assert mock_youtube.videos.return_value.list.call_count == 3

    def test_empty_list(self, mock_build):
        self._setup_mock(mock_build, [])
        details = fetch_video_details([], "fake_key")
        assert details == {}
