"""Bundled installer/uninstaller scripts for Claude Code integration."""
