# gss-bi-udfs

Creo modulo para guardar UDFs comunes a todas las areas de BI.

# para compilar local

python3 -m build

# para publicar local (manual)

python3 -m twine upload dist/*

# publicar nueva version en pypi con github actions

Prerequisitos:
- Secret del repo configurado: `PYPI_API_TOKEN`
- Workflow: `.github/workflows/python-publish.yml`

Pasos:
1. Asegurate de tener los cambios listos en `main`.
   ```bash
   git checkout main
   git pull
   git status
   ```
2. Defini la nueva version semantica (`X.Y.Z`) y crea el tag `vX.Y.Z`.
   ```bash
   git tag -a v0.1.5 -m "Release v0.1.5"
   ```
3. Publica rama y tag en GitHub.
   ```bash
   git push origin main
   git push origin v0.1.5
   ```
4. Crea el release asociado al tag.
   - GitHub -> `Releases` -> `Draft a new release`
   - Seleccionar tag `v0.1.5`
   - Publicar (`Publish release`)
5. Verifica la corrida del workflow.
   - GitHub -> `Actions` -> `Publish Python Package to PyPI`
   - Debe finalizar en verde.
6. Verifica la version publicada en PyPI.
   - `https://pypi.org/project/gss-bi-udfs/`

Notas:
- El workflow valida que el tag tenga formato `vX.Y.Z`.
- La version del paquete se toma del tag (sin la `v`).
- Si falla el release, podes reintentar desde `Actions` con `Run workflow` y el input `tag` (ejemplo: `v0.1.5`).
