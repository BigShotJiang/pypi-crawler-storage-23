"""
validators.py

Contiene validaciones lógicas para proteger la integridad
del metadata layer antes de escribir en Delta.
"""

from datetime import datetime
from typing import Optional


# ==========================================================
# STATUS ENUMS
# ==========================================================

VALID_RUN_STATUS = {"RUNNING", "SUCCESS", "FAILED", "CANCELLED"}
VALID_TASK_STATUS = {"RUNNING", "SUCCESS", "FAILED", "SKIPPED"}
VALID_DQ_STATUS = {"PASSED", "FAILED"}


# ==========================================================
# STATUS VALIDATIONS
# ==========================================================

def validate_run_status(status: str):
    if status not in VALID_RUN_STATUS:
        raise ValueError(
            f"Invalid run status '{status}'. "
            f"Allowed: {VALID_RUN_STATUS}"
        )


def validate_task_status(status: str):
    if status not in VALID_TASK_STATUS:
        raise ValueError(
            f"Invalid task status '{status}'. "
            f"Allowed: {VALID_TASK_STATUS}"
        )


def validate_dq_status(status: str):
    if status not in VALID_DQ_STATUS:
        raise ValueError(
            f"Invalid data quality status '{status}'. "
            f"Allowed: {VALID_DQ_STATUS}"
        )


# ==========================================================
# NUMERIC VALIDATIONS
# ==========================================================

def validate_positive(value: Optional[float], field_name: str):
    if value is not None and value < 0:
        raise ValueError(f"{field_name} must be >= 0")


def validate_non_negative_int(value: Optional[int], field_name: str):
    if value is not None:
        if not isinstance(value, int):
            raise TypeError(f"{field_name} must be int")
        if value < 0:
            raise ValueError(f"{field_name} must be >= 0")


# ==========================================================
# WATERMARK VALIDATIONS
# ==========================================================

def validate_watermark_not_null(watermark):
    if watermark is None:
        raise ValueError("Watermark cannot be None")


def validate_watermark_progression(
    previous_wm,
    new_wm
):
    """
    Evita que el watermark retroceda.
    """
    if previous_wm is None:
        return

    if new_wm < previous_wm:
        raise ValueError(
            f"Watermark regression detected: "
            f"previous={previous_wm}, new={new_wm}"
        )


# ==========================================================
# TIME VALIDATIONS
# ==========================================================

def validate_timestamps(start_ts: datetime, end_ts: datetime):
    if start_ts and end_ts:
        if end_ts < start_ts:
            raise ValueError(
                f"Invalid timestamps: end_ts {end_ts} "
                f"is before start_ts {start_ts}"
            )


# ==========================================================
# SLA VALIDATION
# ==========================================================

def validate_sla(duration_ms: int, sla_minutes: Optional[int]):
    """
    No rompe el pipeline.
    Solo retorna si se incumple SLA.
    """
    if sla_minutes is None:
        return False

    sla_ms = sla_minutes * 60 * 1000

    return duration_ms > sla_ms


# ==========================================================
# CONSISTENCY VALIDATIONS
# ==========================================================

def validate_success_has_end_ts(status: str, end_ts):
    if status == "SUCCESS" and end_ts is None:
        raise ValueError(
            "SUCCESS status must have end_ts defined"
        )


def validate_failed_has_error(status: str, error_logged: bool):
    if status == "FAILED" and not error_logged:
        raise ValueError(
            "FAILED status requires an error_log entry"
        )


# ==========================================================
# DATA QUALITY VALIDATION
# ==========================================================

def validate_threshold(metric_value: float, threshold_value: float):
    """
    Retorna PASSED o FAILED según comparación.
    """
    if metric_value <= threshold_value:
        return "PASSED"
    return "FAILED"
