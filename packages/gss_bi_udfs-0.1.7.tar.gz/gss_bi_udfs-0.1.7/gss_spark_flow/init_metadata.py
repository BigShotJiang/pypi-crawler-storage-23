def _get_existing_columns(spark, full_table_name):
    if not _table_exists(spark, full_table_name):
        return set()
    return {
        row[0]
        for row in spark.sql(f"DESCRIBE TABLE {full_table_name}").collect()
        if row[0] and not row[0].startswith("#")
    }


def _table_exists(spark, full_table_name):
    parts = full_table_name.split(".")
    if len(parts) != 3:
        return bool(spark.catalog.tableExists(full_table_name))

    catalog, schema, table = parts
    query = f"""
    SELECT 1
    FROM {catalog}.information_schema.tables
    WHERE table_schema = '{schema}'
      AND table_name = '{table}'
    LIMIT 1
    """
    return bool(spark.sql(query).collect())


def _add_missing_columns(spark, full_table_name, expected_columns):
    existing_columns = _get_existing_columns(spark, full_table_name)
    cols_to_add = [
        f"{column_name} {column_type}"
        for column_name, column_type in expected_columns.items()
        if column_name not in existing_columns
    ]
    if cols_to_add:
        spark.sql(
            f"ALTER TABLE {full_table_name} "
            f"ADD COLUMNS ({', '.join(cols_to_add)})"
        )
    return cols_to_add


def _escape_sql_literal(value):
    return value.replace("'", "''")


def _normalize_location_path(location):
    return location.rstrip("/")


def _build_table_definitions(catalog, schema, external_location=None):
    base_location = (
        _normalize_location_path(external_location) if external_location else None
    )

    def location_clause(table_name):
        if not base_location:
            return ""
        table_location = _escape_sql_literal(f"{base_location}/{table_name}")
        return f"\n        LOCATION '{table_location}'"

    return {
        f"{catalog}.{schema}.run": f"""
        CREATE TABLE IF NOT EXISTS {catalog}.{schema}.run (
            run_id STRING NOT NULL,
            pipeline_name STRING NOT NULL,
            git_sha STRING,
            triggered_by STRING,
            trigger_type STRING,
            start_ts TIMESTAMP NOT NULL,
            end_ts TIMESTAMP,
            status STRING,
            sla_minutes INT,
            duration_ms BIGINT,
            spark_app_id STRING
        )
        USING DELTA
        TBLPROPERTIES (
            delta.autoOptimize.optimizeWrite = true,
            delta.autoOptimize.autoCompact = true
        ){location_clause("run")}
        """,
        f"{catalog}.{schema}.task_run": f"""
        CREATE TABLE IF NOT EXISTS {catalog}.{schema}.task_run (
            task_run_id STRING NOT NULL,
            run_id STRING,
            task_name STRING,
            start_ts TIMESTAMP,
            end_ts TIMESTAMP,
            status STRING,
            rows_in BIGINT,
            rows_out BIGINT,
            rows_inserted BIGINT,
            rows_updated BIGINT,
            rows_deleted BIGINT,
            target_rows_total BIGINT,
            duration_ms BIGINT,
            watermark_in STRING,
            watermark_out STRING
        )
        USING DELTA{location_clause("task_run")}
        """,
        f"{catalog}.{schema}.error_log": f"""
        CREATE TABLE IF NOT EXISTS {catalog}.{schema}.error_log (
            error_id STRING NOT NULL,
            run_id STRING,
            task_name STRING,
            error_type STRING,
            message STRING,
            stacktrace STRING,
            created_ts TIMESTAMP
        )
        USING DELTA{location_clause("error_log")}
        """,
        f"{catalog}.{schema}.watermark_state": f"""
        CREATE TABLE IF NOT EXISTS {catalog}.{schema}.watermark_state (
            pipeline_name STRING,
            dataset STRING,
            last_watermark STRING,
            watermark_column STRING,
            watermark_type STRING,
            last_run_id STRING,
            updated_ts TIMESTAMP
        )
        USING DELTA{location_clause("watermark_state")}
        """,
        f"{catalog}.{schema}.dataset_config": f"""
        CREATE TABLE IF NOT EXISTS {catalog}.{schema}.dataset_config (
            pipeline_name STRING,
            dataset STRING,
            source_table STRING,
            target_table STRING,
            watermark_column STRING,
            watermark_type STRING,
            merge_keys STRING,
            updated_ts TIMESTAMP
        )
        USING DELTA{location_clause("dataset_config")}
        """,
        f"{catalog}.{schema}.pipeline_dependency": f"""
        CREATE TABLE IF NOT EXISTS {catalog}.{schema}.pipeline_dependency (
            parent_pipeline STRING,
            parent_dataset STRING,
            child_pipeline STRING,
            child_dataset STRING,
            dependency_mode STRING,
            freshness_hours INT
        )
        USING DELTA{location_clause("pipeline_dependency")}
        """,
        f"{catalog}.{schema}.lineage": f"""
        CREATE TABLE IF NOT EXISTS {catalog}.{schema}.lineage (
            run_id STRING,
            task_name STRING,
            input_table STRING,
            output_table STRING,
            created_ts TIMESTAMP
        )
        USING DELTA{location_clause("lineage")}
        """,
        f"{catalog}.{schema}.data_quality": f"""
        CREATE TABLE IF NOT EXISTS {catalog}.{schema}.data_quality (
            run_id STRING,
            task_name STRING,
            check_name STRING,
            metric_value DOUBLE,
            threshold_value DOUBLE,
            status STRING,
            created_ts TIMESTAMP
        )
        USING DELTA{location_clause("data_quality")}
        """,
        f"{catalog}.{schema}.schema_version": f"""
        CREATE TABLE IF NOT EXISTS {catalog}.{schema}.schema_version (
            version STRING,
            applied_ts TIMESTAMP,
            description STRING,
            modified_tables STRING
        )
        USING DELTA{location_clause("schema_version")}
        """,
    }


def _create_or_migrate_metadata_tables(
    spark, catalog, schema, version, external_location=None
):
    table_definitions = _build_table_definitions(
        catalog=catalog,
        schema=schema,
        external_location=external_location,
    )

    existing_tables_before = {
        full_table_name: _table_exists(spark, full_table_name)
        for full_table_name in table_definitions
    }

    for sql in table_definitions.values():
        spark.sql(sql)

    # -------------------------
    # Additive migrations
    # -------------------------
    expected_columns_by_table = {
        f"{catalog}.{schema}.run": {
            "run_id": "STRING",
            "pipeline_name": "STRING",
            "git_sha": "STRING",
            "triggered_by": "STRING",
            "trigger_type": "STRING",
            "start_ts": "TIMESTAMP",
            "end_ts": "TIMESTAMP",
            "status": "STRING",
            "sla_minutes": "INT",
            "duration_ms": "BIGINT",
            "spark_app_id": "STRING",
        },
        f"{catalog}.{schema}.task_run": {
            "task_run_id": "STRING",
            "run_id": "STRING",
            "task_name": "STRING",
            "start_ts": "TIMESTAMP",
            "end_ts": "TIMESTAMP",
            "status": "STRING",
            "rows_in": "BIGINT",
            "rows_out": "BIGINT",
            "rows_inserted": "BIGINT",
            "rows_updated": "BIGINT",
            "rows_deleted": "BIGINT",
            "target_rows_total": "BIGINT",
            "duration_ms": "BIGINT",
            "watermark_in": "STRING",
            "watermark_out": "STRING",
        },
        f"{catalog}.{schema}.error_log": {
            "error_id": "STRING",
            "run_id": "STRING",
            "task_name": "STRING",
            "error_type": "STRING",
            "message": "STRING",
            "stacktrace": "STRING",
            "created_ts": "TIMESTAMP",
        },
        f"{catalog}.{schema}.watermark_state": {
            "pipeline_name": "STRING",
            "dataset": "STRING",
            "last_watermark": "STRING",
            "watermark_column": "STRING",
            "watermark_type": "STRING",
            "last_run_id": "STRING",
            "updated_ts": "TIMESTAMP",
        },
        f"{catalog}.{schema}.dataset_config": {
            "pipeline_name": "STRING",
            "dataset": "STRING",
            "source_table": "STRING",
            "target_table": "STRING",
            "watermark_column": "STRING",
            "watermark_type": "STRING",
            "merge_keys": "STRING",
            "updated_ts": "TIMESTAMP",
        },
        f"{catalog}.{schema}.pipeline_dependency": {
            "parent_pipeline": "STRING",
            "parent_dataset": "STRING",
            "child_pipeline": "STRING",
            "child_dataset": "STRING",
            "dependency_mode": "STRING",
            "freshness_hours": "INT",
        },
        f"{catalog}.{schema}.lineage": {
            "run_id": "STRING",
            "task_name": "STRING",
            "input_table": "STRING",
            "output_table": "STRING",
            "created_ts": "TIMESTAMP",
        },
        f"{catalog}.{schema}.data_quality": {
            "run_id": "STRING",
            "task_name": "STRING",
            "check_name": "STRING",
            "metric_value": "DOUBLE",
            "threshold_value": "DOUBLE",
            "status": "STRING",
            "created_ts": "TIMESTAMP",
        },
        f"{catalog}.{schema}.schema_version": {
            "version": "STRING",
            "applied_ts": "TIMESTAMP",
            "description": "STRING",
            "modified_tables": "STRING",
        },
    }

    structural_changes = []
    for full_table_name, expected_columns in expected_columns_by_table.items():
        if not existing_tables_before.get(full_table_name, True):
            structural_changes.append(f"{full_table_name} [created]")

        added_columns = _add_missing_columns(spark, full_table_name, expected_columns)
        if added_columns:
            structural_changes.append(
                f"{full_table_name} [added: {', '.join(added_columns)}]"
            )

    # -------------------------
    # Register schema version
    # -------------------------
    modified_tables_text = "; ".join(structural_changes) if structural_changes else "none"
    description = (
        "Metadata layer initialization/migration (additive, no-drop). "
        f"Structural changes: {modified_tables_text}"
    ).replace("'", "")

    spark.sql(f"""
    INSERT INTO {catalog}.{schema}.schema_version (version, applied_ts, description, modified_tables)
    VALUES (
        '{version}',
        current_timestamp(),
        '{description}',
        '{modified_tables_text.replace("'", "")}'
    )
    """)

    print(f"Metadata layer initialized. Version: {version}")

def init_metadata_layer_with_location(
    spark,
    catalog="spark_catalog",
    schema="dbo",
    version="1.0.0",
    managed_location=None,
    external_location=None,
):
    """
    Initialize metadata schema/tables with an explicit schema location.

    Rules:
    - Provide exactly one of `managed_location` or `external_location`.
    - In Unity Catalog, schema creation uses MANAGED LOCATION.
    - If `external_location` is provided, each metadata table is created with an
      explicit LOCATION derived from it: `<external_location>/<table_name>`.
    - If `managed_location` is provided, schema-level MANAGED LOCATION is used
      and tables are created as managed tables without per-table LOCATION.
    """
    if bool(managed_location) == bool(external_location):
        raise ValueError(
            "Provide exactly one location: managed_location or external_location."
        )

    if managed_location:
        schema_location_value = _escape_sql_literal(managed_location)
        schema_location_clause = f"MANAGED LOCATION '{schema_location_value}'"
    else:
        # Unity Catalog requires MANAGED LOCATION at schema level.
        schema_location_value = _escape_sql_literal(external_location)
        schema_location_clause = f"MANAGED LOCATION '{schema_location_value}'"

    # Validate catalog and create schema with explicit location.
    try:
        catalogs = spark.sql("SHOW CATALOGS").collect()
        catalog_exists = any(row[0] == catalog for row in catalogs)

        if not catalog_exists:
            raise Exception(
                f"Catalog '{catalog}' not exist. "
                "Please create and re-run the initialization to create the schema and tables."
            )
        sql = f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema} {schema_location_clause}"
        print(f"Creating schema with SQL: {sql}")
        spark.sql(sql)
    except Exception as e:
        if "CATALOG_NOT_FOUND" not in str(e) and "SCHEMA_NOT_FOUND" not in str(e):
            raise

    _create_or_migrate_metadata_tables(
        spark,
        catalog=catalog,
        schema=schema,
        version=version,
        external_location=external_location,
    )


def init_metadata_layer(spark, catalog="spark_catalog", schema="dbo", version="1.0.0"):

    # Validate catalog and create schema if needed.
    try:
        catalogs = spark.sql("SHOW CATALOGS").collect()
        catalog_exists = any(row[0] == catalog for row in catalogs)

        if not catalog_exists:
            raise Exception(
                f"Catalog '{catalog}' not exist. "
                "Please create and re-run the initialization to create the schema and tables."
            )
        sql = f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}"
        print(f"Creating schema with SQL: {sql}")
        spark.sql(sql)

    except Exception as e:
        if "CATALOG_NOT_FOUND" not in str(e) and "SCHEMA_NOT_FOUND" not in str(e):
            raise

    _create_or_migrate_metadata_tables(
        spark,
        catalog=catalog,
        schema=schema,
        version=version,
    )
