from cognite.neat._data_model.rules._base import NeatRule


class DataModelRule(NeatRule):
    """Rules for data model principles."""
