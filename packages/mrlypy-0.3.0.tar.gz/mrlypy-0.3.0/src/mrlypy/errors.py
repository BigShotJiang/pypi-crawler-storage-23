class MrlyError(Exception):
    pass