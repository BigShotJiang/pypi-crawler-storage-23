"""This is the way. Why is the secret."""

__version__ = "0"
__license__ = "MIT"
__author__ = "MrlyProd, Inc."
__url__ = "mrlyprod.com"
__description__ = "Cantor Sets, Sierpinski Carpets, Menger Sponges, And More."

__all__ = [

    # MODULES

    "binary",
    "formulas",
    "hex",

    # EXTRAS

    "Color", "gradient", "mix",
    "seed",
    "Mode",
    "MrlyError",
    
    # DESIGNS

    "zeros_2d", "ones_2d", "noise_2d", "carpet_2d", "net_2d", "tree_2d", "void_2d",
    "zeros_3d", "ones_3d", "noise_3d", "carpet_3d", "net_3d", "tree_3d", "void_3d",
    "random_2d", "random_3d",

    # MODELS
    
    "Cell2d", "Cell3d",

    # COLORS

    "alpha",
    "black",
    "white",
    "gray",
    "red",
    "green",
    "blue",
    "cyan",
    "magenta",
    "yellow",

    # 2D

    "merge_2d",
    "combine_2d",
    "magic_2d",
    "special_2d",
    "mosaic_2d",

    # 3D

    "merge_3d",
    "combine_3d",
    "magic_3d",
    "special_3d",
    "mosaic_3d",   
]

# MODULES

from . import binary
from . import formulas
from . import hex

# EXTRAS

from .colors import Color, gradient, mix
from .state import seed
from .enums import Mode
from .errors import MrlyError

# DESIGNS

from .designs import zeros_2d, ones_2d, noise_2d, carpet_2d, net_2d, tree_2d, void_2d
from .designs import zeros_3d, ones_3d, noise_3d, carpet_3d, net_3d, tree_3d, void_3d
from .designs import random_2d, random_3d

# MODELS

from .models import Cell2d, Cell3d

# COLORS

from .colors import (
    alpha,
    black,
    white,
    gray,
    red,
    green,
    blue,
    cyan,
    magenta,
    yellow,
)

# 2D

from .geometry import (
    merge_2d,
    combine_2d,
    magic_2d,
    special_2d,
    mosaic_2d,
)

# 3D

from .geometry import (
    merge_3d,
    combine_3d,
    magic_3d,
    special_3d,
    mosaic_3d,
)
