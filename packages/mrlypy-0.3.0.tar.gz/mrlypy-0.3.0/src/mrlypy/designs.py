import numpy as np
from typing import TYPE_CHECKING
from . import binary
from .state import state

if TYPE_CHECKING:
    from .models import Cell2d, Cell3d

def build_2d(pattern: np.ndarray, level: int = 1, rotation: int = 0) -> "Cell2d":
    from .models import Cell2d
    cell = Cell2d(types=pattern)
    if level > 1:
        cell.fractal(level)
    if rotation != 0:
        cell.rotate(rotation)
    return cell

def build_3d(pattern: np.ndarray, level: int = 1) -> "Cell3d":
    from .models import Cell3d
    cell = Cell3d(types=pattern)
    if level > 1:
        cell.fractal(level)
    return cell

# 2D

def zeros_2d(number: int, level: int = 1, rotation: int = 0) -> "Cell2d":
    return build_2d(binary.zeros_2d(number), level, rotation)

def ones_2d(number: int, level: int = 1, rotation: int = 0) -> "Cell2d":
    return build_2d(binary.ones_2d(number), level, rotation)

def noise_2d(number: int, level: int = 1, density: float = 0.5, rotation: int = 0) -> "Cell2d":
    pattern = binary.noise_2d(number, density, state.rng)
    return build_2d(pattern, level, rotation)

def carpet_2d(number: int, level: int = 1, rotation: int = 0) -> "Cell2d":
    return build_2d(binary.carpet_2d(number), level, rotation)
    
def net_2d(number: int, level: int = 1, rotation: int = 0) -> "Cell2d":
    return build_2d(binary.net_2d(number), level, rotation)

def tree_2d(number: int, level: int = 1, rotation: int = 0) -> "Cell2d":
    return build_2d(binary.tree_2d(number), level, rotation)

def void_2d(number: int, level: int = 1, rotation: int = 0) -> "Cell2d":
    return build_2d(binary.void_2d(number), level, rotation)

# 3D

def zeros_3d(number: int, level: int = 1) -> "Cell3d":
    return build_3d(binary.zeros_3d(number), level)

def ones_3d(number: int, level: int = 1) -> "Cell3d":
    return build_3d(binary.ones_3d(number), level)

def noise_3d(number: int, level: int = 1, density: float = 0.5) -> "Cell3d":
    pattern = binary.noise_3d(number, density, state.rng)
    return build_3d(pattern, level)

def carpet_3d(number: int, level: int = 1) -> "Cell3d":
    return build_3d(binary.carpet_3d(number), level)
    
def net_3d(number: int, level: int = 1) -> "Cell3d":
    return build_3d(binary.net_3d(number), level)

def tree_3d(number: int, level: int = 1) -> "Cell3d":
    return build_3d(binary.tree_3d(number), level)

def void_3d(number: int, level: int = 1) -> "Cell3d":
    return build_3d(binary.void_3d(number), level)

# RANDOM

def random_2d(number: int, level: int = 1, rotation: int = 0) -> "Cell2d":
    choices = [carpet_2d, net_2d, tree_2d, void_2d]
    idx = state.rng.choice(len(choices))
    return choices[idx](number, level, rotation)

def random_3d(number: int, level: int = 1) -> "Cell3d":
    choices = [carpet_3d, net_3d, tree_3d, void_3d]
    idx = state.rng.choice(len(choices))
    return choices[idx](number, level)
