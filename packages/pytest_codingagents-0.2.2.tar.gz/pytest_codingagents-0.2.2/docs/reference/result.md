# CopilotResult

::: pytest_codingagents.copilot.result.CopilotResult
    options:
      show_source: false

::: pytest_codingagents.copilot.result.UsageInfo
    options:
      show_source: false

::: pytest_codingagents.copilot.result.SubagentInvocation
    options:
      show_source: false

## Turn and ToolCall

`Turn` and `ToolCall` are re-exported from [`pytest_aitest.core.result`](https://sbroenne.github.io/pytest-aitest/reference/result/) for convenience. See the pytest-aitest documentation for their full API.

```python
from pytest_codingagents.copilot.result import Turn, ToolCall
```
