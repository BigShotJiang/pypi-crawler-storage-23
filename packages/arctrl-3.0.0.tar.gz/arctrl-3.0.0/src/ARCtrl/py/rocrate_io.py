from __future__ import annotations
from typing import Any
from .Core.arc_types import (ArcInvestigation, ArcRun, ArcWorkflow)
from .Core.Helper.collections_ import ResizeArray_choose
from .FileSystem.file_system import FileSystem
from .Json.ROCrate.ldgraph import (encoder, decoder)
from .Json.ROCrate.ldnode import decoder as decoder_1
from .ROCrate.ldcontext import LDContext
from .ROCrate.ldobject import (LDNode, LDRef, LDGraph, DynamicObj_DynamicObj__DynamicObj_HasProperty_Z721C83C5)
from .ROCrate.LDTypes.computational_workflow import LDComputationalWorkflow
from .ROCrate.LDTypes.create_action import LDCreateAction
from .ROCrate.LDTypes.creative_work import LDCreativeWork
from .ROCrate.LDTypes.dataset import LDDataset
from .ROCrate.LDTypes.file import LDFile
from .ROCrate.rocrate_context import (init_v1_2, init_bioschemas_context, init_v1_1)
from .conversion import (ARCtrl_ArcInvestigation__ArcInvestigation_ToROCrateInvestigation_Z7960E96B, ARCtrl_ArcInvestigation__ArcInvestigation_fromROCrateInvestigation_Static_Z6839B9E8, ARCtrl_ArcRun__ArcRun_ToROCrateRun_1695DD5C, ARCtrl_ArcWorkflow__ArcWorkflow_ToROCrateWorkflow_1695DD5C)
from .JsonIO.ldobject import ARCtrl_ROCrate_LDGraph__LDGraph_toROCrateJsonString_Static_71136F3F
from .license import License
from .fable_modules.fable_library.date import now
from .fable_modules.fable_library.list import (of_array, filter, FSharpList, is_empty, map as map_1)
from .fable_modules.fable_library.option import (bind, default_arg, value as value_2)
from .fable_modules.fable_library.reflection import (TypeInfo, class_type)
from .fable_modules.fable_library.seq import (iterate, try_head, exactly_one)
from .fable_modules.fable_library.string_ import (join, replace, to_fail, printf)
from .fable_modules.fable_library.types import Array
from .fable_modules.thoth_json_core.decode import map
from .fable_modules.thoth_json_core.types import (IEncodable, Decoder_1)

def _expr4425() -> TypeInfo:
    return class_type("ARCtrl.Json.ARC.ROCrate", None, ROCrate)


class ROCrate:
    ...

ROCrate_reflection = _expr4425

def ROCrate_get_metadataFileDescriptor(__unit: None=None) -> LDNode:
    node: LDNode = LDNode("ro-crate-metadata.json", ["http://schema.org/CreativeWork"])
    node.SetProperty("http://purl.org/dc/terms/conformsTo", LDRef("https://w3id.org/ro/crate/1.2"))
    node.SetProperty("http://schema.org/about", LDRef("./"))
    return node


def ROCrate_get_metadataFileDescriptorWfRun(__unit: None=None) -> LDNode:
    node: LDNode = LDNode("ro-crate-metadata.json", ["http://schema.org/CreativeWork"])
    node.SetProperty("http://purl.org/dc/terms/conformsTo", of_array([LDRef("https://w3id.org/ro/crate/1.1"), LDRef("https://w3id.org/workflowhub/workflow-ro-crate/1.0")]))
    node.SetProperty("http://schema.org/about", LDRef("./"))
    return node


def ROCrate_createLicenseNode_29619109(license: License | None=None) -> LDNode:
    if license is None:
        return LDCreativeWork.create("#LICENSE", None, None, None, None, None, None, None, None, "ALL RIGHTS RESERVED BY THE AUTHORS")

    else: 
        license_1: License = license
        text: str
        match_value: str = license_1.Type
        text = license_1.Content
        return LDCreativeWork.create(license_1.Path, None, None, None, None, None, None, None, None, text)



def ROCrate_getLicense_Z2F770004(license: LDNode, context: LDContext | None=None) -> License | None:
    text: str | None = LDCreativeWork.try_get_text_as_string(license, context)
    match_value: str = license.Id
    (pattern_matching_result, text_1, path, text_2, path_1) = (None, None, None, None, None)
    if match_value == "#LICENSE":
        if text is not None:
            if text == "ALL RIGHTS RESERVED BY THE AUTHORS":
                pattern_matching_result = 0

            else: 
                pattern_matching_result = 1
                text_1 = text


        else: 
            pattern_matching_result = 0


    elif text is None:
        pattern_matching_result = 3
        path_1 = match_value

    else: 
        pattern_matching_result = 2
        path = match_value
        text_2 = text

    if pattern_matching_result == 0:
        return None

    elif pattern_matching_result == 1:
        return License("fulltext", text_1)

    elif pattern_matching_result == 2:
        return License("fulltext", text_2, path)

    elif pattern_matching_result == 3:
        return License("fulltext", "", path_1)



def ROCrate_encoder_Z7FE34C43(isa: ArcInvestigation, license: License | None=None, fs: FileSystem | None=None, ignore_broken_wr: bool | None=None) -> IEncodable:
    license_1: LDNode = ROCrate_createLicenseNode_29619109(license)
    isa_1: LDNode = ARCtrl_ArcInvestigation__ArcInvestigation_ToROCrateInvestigation_Z7960E96B(isa, fs, ignore_broken_wr)
    LDDataset.set_sddate_published_as_date_time(isa_1, now())
    LDDataset.set_license_as_creative_work(isa_1, license_1)
    graph: LDGraph = isa_1.Flatten()
    context: LDContext = LDContext(None, [init_v1_2(), init_bioschemas_context()])
    graph.SetContext(context)
    graph.AddNode(ROCrate_get_metadataFileDescriptor())
    graph.Compact_InPlace()
    return encoder(graph)


def ROCrate_get_decoder(__unit: None=None) -> Decoder_1[tuple[ArcInvestigation, Array[str], License | None]]:
    def ctor(graph: LDGraph) -> tuple[ArcInvestigation, Array[str], License | None]:
        match_value: LDNode | None = graph.TryGetNode("./")
        if match_value is None:
            raise Exception("RO-Crate graph did not contain root data Entity")

        else: 
            node: LDNode = match_value
            def f(n: LDNode, graph: Any=graph) -> str | None:
                if (not n.HasType(LDDataset.schema_type(), graph.TryGetContext())) if ((not (n.Id.find("#") >= 0)) if LDFile.validate(n, graph.TryGetContext()) else False) else False:
                    return n.Id

                else: 
                    return None


            files: Array[str] = ResizeArray_choose(f, graph.Nodes)
            def binder(n_1: LDNode, graph: Any=graph) -> License | None:
                return ROCrate_getLicense_Z2F770004(n_1, graph.TryGetContext())

            license: License | None = bind(binder, LDDataset.try_get_license_as_creative_work(node, graph, graph.TryGetContext()))
            return (ARCtrl_ArcInvestigation__ArcInvestigation_fromROCrateInvestigation_Static_Z6839B9E8(node, graph, graph.TryGetContext()), files, license)


    return map(ctor, decoder)


def ROCrate_packDatasetAsCrate_Z2DB026F7(dataset: LDNode, dataset_name: str, dataset_description: str, metadata_file_descriptor: LDNode | None, license: License) -> LDGraph:
    metadata_file_descriptor_1: LDNode = default_arg(metadata_file_descriptor, ROCrate_get_metadataFileDescriptor())
    license_1: LDNode = ROCrate_createLicenseNode_29619109(license)
    main_entity: LDNode = LDDataset.create("./", None, None, None, None, None, dataset_description, None, dataset_name)
    def action(kv: Any, dataset: Any=dataset, dataset_name: Any=dataset_name, dataset_description: Any=dataset_description, metadata_file_descriptor: Any=metadata_file_descriptor, license: Any=license) -> None:
        main_entity.SetProperty(kv[0], kv[1])

    iterate(action, dataset.GetProperties(False))
    LDDataset.set_date_created_as_date_time(main_entity, now())
    LDDataset.set_license_as_creative_work(main_entity, license_1)
    graph: LDGraph = main_entity.Flatten()
    context: LDContext = LDContext(None, [init_v1_2(), init_bioschemas_context()])
    graph.SetContext(context)
    graph.AddNode(metadata_file_descriptor_1)
    graph.Compact_InPlace()
    return graph


def ROCrate_writeRunAsCrate_5E53831D(arc_run: ArcRun, file_system: FileSystem, license: License) -> str:
    run_dataset: LDNode = ARCtrl_ArcRun__ArcRun_ToROCrateRun_1695DD5C(arc_run, file_system)
    def predicate(prop: str, arc_run: Any=arc_run, file_system: Any=file_system, license: Any=license) -> bool:
        return not DynamicObj_DynamicObj__DynamicObj_HasProperty_Z721C83C5(run_dataset, prop)

    missing_dataset_props: FSharpList[str] = filter(predicate, of_array([LDDataset.identifier(), LDDataset.name(), LDDataset.description(), LDDataset.about(), LDDataset.mentions(), LDDataset.creator(), LDDataset.has_part()]))
    if not is_empty(missing_dataset_props):
        def mapping(p: str, arc_run: Any=arc_run, file_system: Any=file_system, license: Any=license) -> str:
            return replace(p, "http://schema.org/", "")

        missing_props_str: str = join(", ", map_1(mapping, missing_dataset_props))
        to_fail(printf("Run dataset is missing required properties: %s"))(missing_props_str)

    workflow_invocation: LDNode
    match_value: LDNode | None = try_head(LDDataset.get_abouts_as_workflow_invocation(run_dataset))
    if match_value is None:
        raise Exception("Run dataset \'about\' property must contain a workflowInvocation")

    else: 
        workflow_invocation = match_value

    def predicate_1(prop_1: str, arc_run: Any=arc_run, file_system: Any=file_system, license: Any=license) -> bool:
        return not DynamicObj_DynamicObj__DynamicObj_HasProperty_Z721C83C5(workflow_invocation, prop_1)

    missing_wf_invocation_props: FSharpList[str] = filter(predicate_1, of_array([LDCreateAction.name(), LDCreateAction.instrument(), LDCreateAction.result(), LDCreateAction.object_()]))
    if not is_empty(missing_wf_invocation_props):
        def mapping_1(p_1: str, arc_run: Any=arc_run, file_system: Any=file_system, license: Any=license) -> str:
            return replace(p_1, "http://schema.org/", "")

        missing_props_str_1: str = join(", ", map_1(mapping_1, missing_wf_invocation_props))
        to_fail(printf("WorkflowInvocation is missing required properties: %s"))(missing_props_str_1)

    return ARCtrl_ROCrate_LDGraph__LDGraph_toROCrateJsonString_Static_71136F3F(2)(ROCrate_packDatasetAsCrate_Z2DB026F7(run_dataset, value_2(arc_run.Title), value_2(arc_run.Description), ROCrate_get_metadataFileDescriptorWfRun(), license))


def ROCrate_writeWorkflowAsCrate_Z4A0538D9(arc_workflow: ArcWorkflow, file_system: FileSystem, license: License) -> str:
    workflow_dataset: LDNode = ARCtrl_ArcWorkflow__ArcWorkflow_ToROCrateWorkflow_1695DD5C(arc_workflow, file_system)
    def predicate(prop: str, arc_workflow: Any=arc_workflow, file_system: Any=file_system, license: Any=license) -> bool:
        return not DynamicObj_DynamicObj__DynamicObj_HasProperty_Z721C83C5(workflow_dataset, prop)

    missing_dataset_props: FSharpList[str] = filter(predicate, of_array([LDDataset.identifier(), LDDataset.name(), LDDataset.description(), LDDataset.main_entity(), LDDataset.has_part(), LDDataset.creator()]))
    if not is_empty(missing_dataset_props):
        def mapping(p: str, arc_workflow: Any=arc_workflow, file_system: Any=file_system, license: Any=license) -> str:
            return replace(p, "http://schema.org/", "")

        missing_props_str: str = join(", ", map_1(mapping, missing_dataset_props))
        to_fail(printf("Workflow dataset is missing required properties: %s"))(missing_props_str)

    workflow_protocol: LDNode
    match_value: LDNode | None = LDDataset.try_get_main_entity_as_workflow_protocol(workflow_dataset)
    if match_value is None:
        raise Exception("Workflow dataset \'mainEntity\' property must contain a workflow protocol")

    else: 
        workflow_protocol = match_value

    def predicate_1(prop_1: str, arc_workflow: Any=arc_workflow, file_system: Any=file_system, license: Any=license) -> bool:
        return not DynamicObj_DynamicObj__DynamicObj_HasProperty_Z721C83C5(workflow_protocol, prop_1)

    missing_protocol_props: FSharpList[str] = filter(predicate_1, of_array([LDComputationalWorkflow.creator(), LDComputationalWorkflow.name(), LDComputationalWorkflow.input(), LDComputationalWorkflow.output(), LDComputationalWorkflow.programming_language(), LDComputationalWorkflow.url(), LDComputationalWorkflow.version(), LDComputationalWorkflow.date_created()]))
    if not is_empty(missing_protocol_props):
        def mapping_1(p_1: str, arc_workflow: Any=arc_workflow, file_system: Any=file_system, license: Any=license) -> str:
            return replace(p_1, "http://schema.org/", "")

        missing_props_str_1: str = join(", ", map_1(mapping_1, missing_protocol_props))
        to_fail(printf("Workflow protocol is missing required properties: %s"))(missing_props_str_1)

    return ARCtrl_ROCrate_LDGraph__LDGraph_toROCrateJsonString_Static_71136F3F(2)(ROCrate_packDatasetAsCrate_Z2DB026F7(workflow_dataset, value_2(arc_workflow.Title), value_2(arc_workflow.Description), ROCrate_get_metadataFileDescriptorWfRun(), license))


def ROCrate_get_decoderDeprecated(__unit: None=None) -> Decoder_1[ArcInvestigation]:
    def ctor(ldnode: LDNode) -> ArcInvestigation:
        return ARCtrl_ArcInvestigation__ArcInvestigation_fromROCrateInvestigation_Static_Z6839B9E8(exactly_one(LDDataset.get_abouts(ldnode)), None, init_v1_1())

    return map(ctor, decoder_1)


__all__ = ["ROCrate_reflection", "ROCrate_get_metadataFileDescriptor", "ROCrate_get_metadataFileDescriptorWfRun", "ROCrate_createLicenseNode_29619109", "ROCrate_getLicense_Z2F770004", "ROCrate_encoder_Z7FE34C43", "ROCrate_get_decoder", "ROCrate_packDatasetAsCrate_Z2DB026F7", "ROCrate_writeRunAsCrate_5E53831D", "ROCrate_writeWorkflowAsCrate_Z4A0538D9", "ROCrate_get_decoderDeprecated"]

