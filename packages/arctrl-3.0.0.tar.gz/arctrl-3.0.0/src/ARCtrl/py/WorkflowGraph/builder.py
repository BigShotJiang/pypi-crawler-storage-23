from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from ..fable_modules.dynamic_obj.dynamic_obj import DynamicObj
from ..fable_modules.dynamic_obj.dyn_obj import set_property
from ..fable_modules.fable_library.array_ import (filter, map as map_1, try_pick as try_pick_1)
from ..fable_modules.fable_library.list import (FSharpList, of_array, try_pick, singleton)
from ..fable_modules.fable_library.map import (empty as empty_1, FSharpMap__ContainsKey, FSharpMap__get_Item, FSharpMap__Add, try_find)
from ..fable_modules.fable_library.option import (value as value_9, map, default_arg, bind, some)
from ..fable_modules.fable_library.reflection import (TypeInfo, string_type, class_type, record_type, option_type, bool_type, array_type)
from ..fable_modules.fable_library.seq import (to_array, iterate, try_head, to_list, delay, singleton as singleton_1)
from ..fable_modules.fable_library.seq2 import Array_distinct
from ..fable_modules.fable_library.set import (empty, FSharpSet__Contains, FSharpSet__Add)
from ..fable_modules.fable_library.string_ import (is_null_or_white_space, starts_with_exact, substring, ends_with)
from ..fable_modules.fable_library.types import (Record, Array)
from ..fable_modules.fable_library.util import (compare_primitives, get_enumerator, ignore, string_hash, IEnumerable_1, dispose)
from ..CWL.cwlprocessing_unit import (CWLProcessingUnit, WorkflowStepRunOps_fromWorkflow, WorkflowStepRunOps_fromExpressionTool, WorkflowStepRunOps_fromOperation, WorkflowStepRunOps_fromTool, WorkflowStepRunOps_tryGetTool, WorkflowStepRunOps_tryGetWorkflow, WorkflowStepRunOps_tryGetExpressionTool, WorkflowStepRunOps_tryGetOperation)
from ..CWL.expression_tool_description import CWLExpressionToolDescription
from ..CWL.inputs import CWLInput
from ..CWL.operation_description import CWLOperationDescription
from ..CWL.outputs import CWLOutput
from ..CWL.tool_description import CWLToolDescription
from ..CWL.workflow_description import CWLWorkflowDescription
from ..CWL.workflow_steps import (WorkflowStepRun_reflection, WorkflowStepRun, ScatterMethod, WorkflowStep, StepInput, StepOutput)
from ..FileSystem.path import (get_file_name, normalize, resolve_path_from_file, normalize_path_key)
from .build_options import (WorkflowGraphBuildOptions, WorkflowGraphBuildOptions_reflection, WorkflowGraphBuildOptionsModule_defaultOptions)
from .graph_types import (WorkflowGraph, WorkflowGraph_reflection, WorkflowGraph_create_4D231A1, GraphBuildIssue_create_Z2F3B511A, GraphIssueKind, WorkflowGraphNode, WorkflowGraphEdge, WorkflowGraphEdge_create_5E4B5E48, GraphId_edgeId, EdgeKind, GraphId_unitNodeId, WorkflowGraphNode_create_62C775C0, NodeKind, ProcessingUnitKind, GraphId_portNodeId, PortDirection, GraphId_stepNodeId, GraphId_childScope, GraphId_normalizeSegment)
from .reference_parsing import (ReferenceParsing_extractStepOutputId, ReferenceParsing_parseSourceReference, ParsedSourceReference)

def _expr1405() -> TypeInfo:
    return record_type("ARCtrl.WorkflowGraph.Builder.BuildState", [], BuildState, lambda: [("Graph", WorkflowGraph_reflection()), ("NodeIds", class_type("Microsoft.FSharp.Collections.FSharpSet`1", [string_type])), ("EdgeIds", class_type("Microsoft.FSharp.Collections.FSharpSet`1", [string_type])), ("RunResolutionStack", class_type("Microsoft.FSharp.Collections.FSharpSet`1", [string_type])), ("RunResolutionCache", class_type("Microsoft.FSharp.Collections.FSharpMap`2", [string_type, WorkflowStepRun_reflection()])), ("RunNodeCache", class_type("Microsoft.FSharp.Collections.FSharpMap`2", [string_type, string_type])), ("Options", WorkflowGraphBuildOptions_reflection())])


@dataclass(eq = False, repr = False, slots = True)
class BuildState(Record):
    Graph: WorkflowGraph
    NodeIds: Any
    EdgeIds: Any
    RunResolutionStack: Any
    RunResolutionCache: Any
    RunNodeCache: Any
    Options: WorkflowGraphBuildOptions

BuildState_reflection = _expr1405

def _expr1406() -> TypeInfo:
    return record_type("ARCtrl.WorkflowGraph.Builder.RunResolutionResult", [], RunResolutionResult, lambda: [("ResolvedRun", WorkflowStepRun_reflection()), ("ResolvedFromPath", option_type(string_type)), ("AttemptedLookup", bool_type), ("ResolutionPathKeys", array_type(string_type))])


@dataclass(eq = False, repr = False, slots = True)
class RunResolutionResult(Record):
    ResolvedRun: WorkflowStepRun
    ResolvedFromPath: str | None
    AttemptedLookup: bool
    ResolutionPathKeys: Array[str]

RunResolutionResult_reflection = _expr1406

def create_graph(root_node_id: str) -> WorkflowGraph:
    return WorkflowGraph_create_4D231A1(root_node_id)


def create_state(options: WorkflowGraphBuildOptions, root_node_id: str) -> BuildState:
    class ObjectExpr1409:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    class ObjectExpr1410:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    class ObjectExpr1411:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    class ObjectExpr1412:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    class ObjectExpr1413:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    return BuildState(create_graph(root_node_id), empty(ObjectExpr1409()), empty(ObjectExpr1410()), empty(ObjectExpr1411()), empty_1(ObjectExpr1412()), empty_1(ObjectExpr1413()), options)


def add_diagnostic(state: BuildState, kind: GraphIssueKind, message: str, scope: str | None=None, reference: str | None=None) -> None:
    (state.Graph.Diagnostics.append(GraphBuildIssue_create_Z2F3B511A(kind, message, scope, reference)))


def has_node(state: BuildState, node_id: str) -> bool:
    return FSharpSet__Contains(state.NodeIds, node_id)


def add_node(state: BuildState, node: WorkflowGraphNode) -> None:
    if not FSharpSet__Contains(state.NodeIds, node.Id):
        state.NodeIds = FSharpSet__Add(state.NodeIds, node.Id)
        (state.Graph.Nodes.append(node))



def add_edge(state: BuildState, edge: WorkflowGraphEdge) -> None:
    if not FSharpSet__Contains(state.EdgeIds, edge.Id):
        state.EdgeIds = FSharpSet__Add(state.EdgeIds, edge.Id)
        (state.Graph.Edges.append(edge))



def add_edge_by_type(state: BuildState, kind: EdgeKind, source_node_id: str, target_node_id: str, label: str | None=None) -> None:
    add_edge(state, WorkflowGraphEdge_create_5E4B5E48(GraphId_edgeId(kind, source_node_id, target_node_id), source_node_id, target_node_id, kind, label))


def create_metadata(pairs: FSharpList[tuple[str, Any | None]]) -> DynamicObj | None:
    metadata: DynamicObj = DynamicObj()
    has_metadata: bool = False
    with get_enumerator(pairs) as enumerator:
        while enumerator.System_Collections_IEnumerator_MoveNext():
            for_loop_var: tuple[str, Any | None] = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            value_opt: Any | None = for_loop_var[1]
            if value_opt is None:
                pass

            else: 
                value: Any = value_9(value_opt)
                has_metadata = True
                set_property(for_loop_var[0], value, metadata)

    if has_metadata:
        return metadata

    else: 
        return None



def add_processing_unit_node(state: BuildState, scope: str, kind: ProcessingUnitKind, label: str, owner_node_id: str | None=None, reference: str | None=None, metadata: DynamicObj | None=None) -> str:
    node_id: str = GraphId_unitNodeId(scope)
    add_node(state, WorkflowGraphNode_create_62C775C0(node_id, NodeKind(0, kind), label, owner_node_id, reference, metadata))
    return node_id


def add_port_node(state: BuildState, owner_node_id: str, direction: PortDirection, port_id: str, label: str) -> str:
    node_id: str = GraphId_portNodeId(owner_node_id, direction, port_id)
    add_node(state, WorkflowGraphNode_create_62C775C0(node_id, NodeKind(2, direction), label, owner_node_id))
    return node_id


def add_step_node(state: BuildState, scope: str, workflow_node_id: str, step: WorkflowStep) -> str:
    step_node_id: str = GraphId_stepNodeId(scope, step.Id)
    def mapping(value: str, state: Any=state, scope: Any=scope, workflow_node_id: Any=workflow_node_id, step: Any=step) -> Any:
        return value

    def mapping_1(sm: ScatterMethod, state: Any=state, scope: Any=scope, workflow_node_id: Any=workflow_node_id, step: Any=step) -> Any:
        return sm.AsCwlString

    def mapping_2(values: Array[str], state: Any=state, scope: Any=scope, workflow_node_id: Any=workflow_node_id, step: Any=step) -> Any:
        return to_array(values)

    metadata: DynamicObj | None = create_metadata(of_array([("when", map(mapping, step.When_)), ("scatterMethod", map(mapping_1, step.ScatterMethod)), ("scatter", map(mapping_2, step.Scatter))]))
    add_node(state, WorkflowGraphNode_create_62C775C0(step_node_id, NodeKind(1), default_arg(step.Label, step.Id), workflow_node_id, None, metadata))
    add_edge_by_type(state, EdgeKind(0), workflow_node_id, step_node_id, None)
    return step_node_id


def add_workflow_ports(state: BuildState, workflow_node_id: str, workflow: CWLWorkflowDescription) -> None:
    def action(input: CWLInput, state: Any=state, workflow_node_id: Any=workflow_node_id, workflow: Any=workflow) -> None:
        ignore(add_port_node(state, workflow_node_id, PortDirection(0), input.Name, input.Name))

    iterate(action, workflow.Inputs)
    def action_1(output: CWLOutput, state: Any=state, workflow_node_id: Any=workflow_node_id, workflow: Any=workflow) -> None:
        ignore(add_port_node(state, workflow_node_id, PortDirection(1), output.Name, output.Name))

    iterate(action_1, workflow.Outputs)


def add_tool_ports(state: BuildState, tool_node_id: str, tool: CWLToolDescription) -> None:
    def action(input: CWLInput, state: Any=state, tool_node_id: Any=tool_node_id, tool: Any=tool) -> None:
        ignore(add_port_node(state, tool_node_id, PortDirection(0), input.Name, input.Name))

    iterate(action, default_arg(tool.Inputs, []))
    def action_1(output: CWLOutput, state: Any=state, tool_node_id: Any=tool_node_id, tool: Any=tool) -> None:
        ignore(add_port_node(state, tool_node_id, PortDirection(1), output.Name, output.Name))

    iterate(action_1, tool.Outputs)


def add_expression_tool_ports(state: BuildState, tool_node_id: str, tool: CWLExpressionToolDescription) -> None:
    def action(input: CWLInput, state: Any=state, tool_node_id: Any=tool_node_id, tool: Any=tool) -> None:
        ignore(add_port_node(state, tool_node_id, PortDirection(0), input.Name, input.Name))

    iterate(action, default_arg(tool.Inputs, []))
    def action_1(output: CWLOutput, state: Any=state, tool_node_id: Any=tool_node_id, tool: Any=tool) -> None:
        ignore(add_port_node(state, tool_node_id, PortDirection(1), output.Name, output.Name))

    iterate(action_1, tool.Outputs)


def add_operation_ports(state: BuildState, operation_node_id: str, operation: CWLOperationDescription) -> None:
    def action(input: CWLInput, state: Any=state, operation_node_id: Any=operation_node_id, operation: Any=operation) -> None:
        ignore(add_port_node(state, operation_node_id, PortDirection(0), input.Name, input.Name))

    iterate(action, operation.Inputs)
    def action_1(output: CWLOutput, state: Any=state, operation_node_id: Any=operation_node_id, operation: Any=operation) -> None:
        ignore(add_port_node(state, operation_node_id, PortDirection(1), output.Name, output.Name))

    iterate(action_1, operation.Outputs)


def add_step_ports(state: BuildState, step_node_id: str, step: WorkflowStep) -> None:
    def action(input: StepInput, state: Any=state, step_node_id: Any=step_node_id, step: Any=step) -> None:
        ignore(add_port_node(state, step_node_id, PortDirection(0), input.Id, input.Id))

    iterate(action, step.In)
    def action_1(output: StepOutput, state: Any=state, step_node_id: Any=step_node_id, step: Any=step) -> None:
        output_id: str = ReferenceParsing_extractStepOutputId(output)
        ignore(add_port_node(state, step_node_id, PortDirection(1), output_id, output_id))

    iterate(action_1, step.Out)


def trim_to_name_candidate(value: str) -> str:
    if is_null_or_white_space(value):
        return ""

    else: 
        trimmed: str = value.strip()
        if starts_with_exact(trimmed, "#"):
            return substring(trimmed, 1)

        else: 
            hash_index: int = trimmed.find("#") or 0
            without_hash: str = substring(trimmed, 0, hash_index) if (hash_index >= 0) else trimmed
            query_index: int = without_hash.find("?") or 0
            if query_index >= 0:
                return substring(without_hash, 0, query_index)

            else: 
                return without_hash





def is_cwl_reference(run_path: str) -> bool:
    candidate: str = trim_to_name_candidate(run_path)
    if not is_null_or_white_space(candidate):
        return ends_with(candidate, ".cwl", 5)

    else: 
        return False



def try_basename_no_cwl_extension(value: str) -> str | None:
    candidate: str = trim_to_name_candidate(value)
    if is_null_or_white_space(candidate):
        return None

    else: 
        file_name: str = get_file_name(candidate) if (True if (candidate.find("/") >= 0) else (candidate.find("\\") >= 0)) else candidate
        without_cwl_extension: str = substring(file_name, 0, len(file_name) - len(".cwl")) if ends_with(file_name, ".cwl", 5) else file_name
        if is_null_or_white_space(without_cwl_extension):
            return None

        else: 
            return without_cwl_extension




def try_get_processing_unit_name(processing_unit: Any | None=None) -> str | None:
    def chooser(key: str, processing_unit: Any=processing_unit) -> str | None:
        def _arrow1414(value: str, key: Any=key) -> str | None:
            return try_basename_no_cwl_extension(value)

        def _arrow1415(__unit: None=None, key: Any=key) -> str | None:
            match_value: Any | None = processing_unit.TryGetPropertyValue(key)
            if match_value is not None:
                o: Any = value_9(match_value)
                return o if (str(type(o)) == "<class \'str\'>") else None

            else: 
                return None


        return bind(_arrow1414, _arrow1415())

    return try_pick(chooser, of_array(["name", "id"]))


def choose_label(fallback: str, candidates: FSharpList[str | None]) -> str:
    def chooser(x: str | None=None, fallback: Any=fallback, candidates: Any=candidates) -> str | None:
        return x

    return default_arg(try_pick(chooser, candidates), fallback)


def get_run_path_candidates(workflow_file_path: str | None, run_path: str) -> Array[str]:
    if is_null_or_white_space(run_path):
        return []

    else: 
        trimmed_run_path: str = run_path.strip()
        normalized_run_path: str = normalize(trimmed_run_path)
        (pattern_matching_result, workflow_path_1) = (None, None)
        if workflow_file_path is not None:
            if not is_null_or_white_space(workflow_file_path):
                pattern_matching_result = 0
                workflow_path_1 = workflow_file_path

            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1

        if pattern_matching_result == 0:
            path_from_workflow_file: str = resolve_path_from_file(workflow_path_1, trimmed_run_path)
            def predicate(arg: str, workflow_file_path: Any=workflow_file_path, run_path: Any=run_path) -> bool:
                return not is_null_or_white_space(arg)

            class ObjectExpr1417:
                @property
                def Equals(self) -> Callable[[str, str], bool]:
                    def _arrow1416(x: str, y: str) -> bool:
                        return x == y

                    return _arrow1416

                @property
                def GetHashCode(self) -> Callable[[str], int]:
                    return string_hash

            return Array_distinct(filter(predicate, [trimmed_run_path, normalized_run_path, path_from_workflow_file, normalize(path_from_workflow_file)]), ObjectExpr1417())

        elif pattern_matching_result == 1:
            def predicate_1(arg_1: str, workflow_file_path: Any=workflow_file_path, run_path: Any=run_path) -> bool:
                return not is_null_or_white_space(arg_1)

            class ObjectExpr1419:
                @property
                def Equals(self) -> Callable[[str, str], bool]:
                    def _arrow1418(x_1: str, y_1: str) -> bool:
                        return x_1 == y_1

                    return _arrow1418

                @property
                def GetHashCode(self) -> Callable[[str], int]:
                    return string_hash

            return Array_distinct(filter(predicate_1, [trimmed_run_path, normalized_run_path]), ObjectExpr1419())




def resolve_run_string(state: BuildState, workflow_file_path: str | None, run_path: str) -> RunResolutionResult:
    if True if is_null_or_white_space(run_path) else (not is_cwl_reference(run_path)):
        return RunResolutionResult(WorkflowStepRun(0, run_path), None, False, [])

    else: 
        match_value: Callable[[str], CWLProcessingUnit | None] | None = state.Options.TryResolveRunPath
        if match_value is not None:
            try_resolve_run_path: Callable[[str], CWLProcessingUnit | None] = match_value
            candidates: Array[str] = get_run_path_candidates(workflow_file_path, run_path)
            def _arrow1420(path: str, state: Any=state, workflow_file_path: Any=workflow_file_path, run_path: Any=run_path) -> str:
                return normalize_path_key(path)

            class ObjectExpr1422:
                @property
                def Equals(self) -> Callable[[str, str], bool]:
                    def _arrow1421(x: str, y: str) -> bool:
                        return x == y

                    return _arrow1421

                @property
                def GetHashCode(self) -> Callable[[str], int]:
                    return string_hash

            candidate_keys: Array[str] = Array_distinct(map_1(_arrow1420, candidates, None), ObjectExpr1422())
            resolved_run: tuple[WorkflowStepRun, str] | None = None
            for idx in range(0, (len(candidates) - 1) + 1, 1):
                candidate: str = candidates[idx]
                if resolved_run is None:
                    path_key: str = normalize_path_key(candidate)
                    if FSharpSet__Contains(state.RunResolutionStack, path_key):
                        add_diagnostic(state, GraphIssueKind(3), ("Cycle detected while resolving run reference \'" + candidate) + "\'.", workflow_file_path, candidate)

                    elif FSharpMap__ContainsKey(state.RunResolutionCache, path_key):
                        resolved_run = (FSharpMap__get_Item(state.RunResolutionCache, path_key), candidate)

                    else: 
                        match_value_1: CWLProcessingUnit | None = try_resolve_run_path(candidate)
                        if match_value_1 is None:
                            pass

                        elif match_value_1.tag == 1:
                            workflow: CWLWorkflowDescription = match_value_1.fields[0]
                            run_1: WorkflowStepRun = WorkflowStepRunOps_fromWorkflow(workflow)
                            for idx_2 in range(0, (len(candidate_keys) - 1) + 1, 1):
                                key_1: str = candidate_keys[idx_2]
                                state.RunResolutionCache = FSharpMap__Add(state.RunResolutionCache, key_1, run_1)
                            resolved_run = (run_1, candidate)

                        elif match_value_1.tag == 2:
                            expression_tool: CWLExpressionToolDescription = match_value_1.fields[0]
                            run_2: WorkflowStepRun = WorkflowStepRunOps_fromExpressionTool(expression_tool)
                            for idx_3 in range(0, (len(candidate_keys) - 1) + 1, 1):
                                key_2: str = candidate_keys[idx_3]
                                state.RunResolutionCache = FSharpMap__Add(state.RunResolutionCache, key_2, run_2)
                            resolved_run = (run_2, candidate)

                        elif match_value_1.tag == 3:
                            operation: CWLOperationDescription = match_value_1.fields[0]
                            run_3: WorkflowStepRun = WorkflowStepRunOps_fromOperation(operation)
                            for idx_4 in range(0, (len(candidate_keys) - 1) + 1, 1):
                                key_3: str = candidate_keys[idx_4]
                                state.RunResolutionCache = FSharpMap__Add(state.RunResolutionCache, key_3, run_3)
                            resolved_run = (run_3, candidate)

                        else: 
                            tool: CWLToolDescription = match_value_1.fields[0]
                            run: WorkflowStepRun = WorkflowStepRunOps_fromTool(tool)
                            for idx_1 in range(0, (len(candidate_keys) - 1) + 1, 1):
                                key: str = candidate_keys[idx_1]
                                state.RunResolutionCache = FSharpMap__Add(state.RunResolutionCache, key, run)
                            resolved_run = (run, candidate)



            if resolved_run is None:
                add_diagnostic(state, GraphIssueKind(2), ("Unable to resolve CWL run reference \'" + run_path) + "\'.", workflow_file_path, run_path)
                return RunResolutionResult(WorkflowStepRun(0, run_path), None, True, candidate_keys)

            else: 
                return RunResolutionResult(resolved_run[0], resolved_run[1], True, candidate_keys)


        else: 
            if state.Options.StrictUnresolvedRunReferences:
                add_diagnostic(state, GraphIssueKind(2), ("Unable to resolve CWL run reference \'" + run_path) + "\' because no run resolver is configured.", workflow_file_path, run_path)

            return RunResolutionResult(WorkflowStepRun(0, run_path), None, state.Options.StrictUnresolvedRunReferences, [])




def build_processing_unit(state: BuildState, scope: str, workflow_file_path: str | None, owner_node_id: str | None, is_root: bool, processing_unit: CWLProcessingUnit) -> str:
    if processing_unit.tag == 2:
        expression_tool: CWLExpressionToolDescription = processing_unit.fields[0]
        def _arrow1423(value_3: str, state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, owner_node_id: Any=owner_node_id, is_root: Any=is_root, processing_unit: Any=processing_unit) -> str | None:
            return try_basename_no_cwl_extension(value_3)

        def _arrow1424(value_4: str, state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, owner_node_id: Any=owner_node_id, is_root: Any=is_root, processing_unit: Any=processing_unit) -> str | None:
            return try_basename_no_cwl_extension(value_4)

        node_id_1: str = add_processing_unit_node(state, scope, ProcessingUnitKind(2), choose_label("ExpressionTool", of_array([try_get_processing_unit_name(expression_tool), bind(_arrow1423, expression_tool.Label), bind(_arrow1424, workflow_file_path)])), owner_node_id, None, create_metadata(of_array([("cwlVersion", some(expression_tool.CWLVersion)), ("expression", some(expression_tool.Expression))])))
        add_expression_tool_ports(state, node_id_1, expression_tool)
        return node_id_1

    elif processing_unit.tag == 3:
        operation: CWLOperationDescription = processing_unit.fields[0]
        def _arrow1425(value_5: str, state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, owner_node_id: Any=owner_node_id, is_root: Any=is_root, processing_unit: Any=processing_unit) -> str | None:
            return try_basename_no_cwl_extension(value_5)

        def _arrow1426(value_6: str, state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, owner_node_id: Any=owner_node_id, is_root: Any=is_root, processing_unit: Any=processing_unit) -> str | None:
            return try_basename_no_cwl_extension(value_6)

        node_id_2: str = add_processing_unit_node(state, scope, ProcessingUnitKind(3), choose_label("Operation", of_array([try_get_processing_unit_name(operation), bind(_arrow1425, operation.Label), bind(_arrow1426, workflow_file_path)])), owner_node_id, None, create_metadata(singleton(("cwlVersion", some(operation.CWLVersion)))))
        add_operation_ports(state, node_id_2, operation)
        return node_id_2

    elif processing_unit.tag == 1:
        workflow: CWLWorkflowDescription = processing_unit.fields[0]
        def _arrow1427(value_7: str, state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, owner_node_id: Any=owner_node_id, is_root: Any=is_root, processing_unit: Any=processing_unit) -> str | None:
            return try_basename_no_cwl_extension(value_7)

        def _arrow1428(value_8: str, state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, owner_node_id: Any=owner_node_id, is_root: Any=is_root, processing_unit: Any=processing_unit) -> str | None:
            return try_basename_no_cwl_extension(value_8)

        node_id_3: str = add_processing_unit_node(state, scope, ProcessingUnitKind(0), choose_label("Workflow", of_array([try_get_processing_unit_name(workflow), bind(_arrow1427, workflow.Label), bind(_arrow1428, workflow_file_path)])), owner_node_id, None, create_metadata(singleton(("cwlVersion", some(workflow.CWLVersion)))))
        add_workflow_ports(state, node_id_3, workflow)
        if True if is_root else state.Options.ExpandNestedWorkflows:
            build_workflow_steps(state, scope, workflow_file_path, node_id_3, workflow)

        return node_id_3

    else: 
        tool: CWLToolDescription = processing_unit.fields[0]
        def _arrow1429(value: str, state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, owner_node_id: Any=owner_node_id, is_root: Any=is_root, processing_unit: Any=processing_unit) -> str | None:
            return try_basename_no_cwl_extension(value)

        def _arrow1430(value_1: str, state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, owner_node_id: Any=owner_node_id, is_root: Any=is_root, processing_unit: Any=processing_unit) -> str | None:
            return try_basename_no_cwl_extension(value_1)

        def binder(source: Array[str], state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, owner_node_id: Any=owner_node_id, is_root: Any=is_root, processing_unit: Any=processing_unit) -> str | None:
            return try_head(source)

        def _arrow1431(value_2: str, state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, owner_node_id: Any=owner_node_id, is_root: Any=is_root, processing_unit: Any=processing_unit) -> str | None:
            return try_basename_no_cwl_extension(value_2)

        node_id: str = add_processing_unit_node(state, scope, ProcessingUnitKind(1), choose_label("CommandLineTool", of_array([try_get_processing_unit_name(tool), bind(_arrow1429, tool.Label), bind(_arrow1430, bind(binder, tool.BaseCommand)), bind(_arrow1431, workflow_file_path)])), owner_node_id, None, create_metadata(singleton(("cwlVersion", some(tool.CWLVersion)))))
        add_tool_ports(state, node_id, tool)
        return node_id



def build_run_node(state: BuildState, run_scope: str, step_node_id: str, workflow_file_path: str | None, run: WorkflowStepRun) -> tuple[WorkflowStepRun, str]:
    if run.tag == 1:
        match_value_2: CWLToolDescription | None = WorkflowStepRunOps_tryGetTool(run)
        if match_value_2 is None:
            bad_node_id: str = add_processing_unit_node(state, run_scope, ProcessingUnitKind(5), "Invalid CommandLineTool payload", step_node_id, None, None)
            add_diagnostic(state, GraphIssueKind(5), "WorkflowStepRun.RunCommandLineTool had an unexpected payload type.", workflow_file_path, None)
            return (run, bad_node_id)

        else: 
            return (run, build_processing_unit(state, run_scope, workflow_file_path, step_node_id, False, CWLProcessingUnit(0, match_value_2)))


    elif run.tag == 2:
        match_value_3: CWLWorkflowDescription | None = WorkflowStepRunOps_tryGetWorkflow(run)
        if match_value_3 is None:
            bad_node_id_1: str = add_processing_unit_node(state, run_scope, ProcessingUnitKind(5), "Invalid Workflow payload", step_node_id, None, None)
            add_diagnostic(state, GraphIssueKind(5), "WorkflowStepRun.RunWorkflow had an unexpected payload type.", workflow_file_path, None)
            return (run, bad_node_id_1)

        else: 
            workflow: CWLWorkflowDescription = match_value_3
            def _arrow1432(__unit: None=None, state: Any=state, run_scope: Any=run_scope, step_node_id: Any=step_node_id, workflow_file_path: Any=workflow_file_path, run: Any=run) -> str | None:
                current_path: str = default_arg(workflow_file_path, "")
                return None if is_null_or_white_space(current_path) else current_path

            return (run, build_processing_unit(state, run_scope, _arrow1432(), step_node_id, False, CWLProcessingUnit(1, workflow)))


    elif run.tag == 3:
        match_value_4: CWLExpressionToolDescription | None = WorkflowStepRunOps_tryGetExpressionTool(run)
        if match_value_4 is None:
            bad_node_id_2: str = add_processing_unit_node(state, run_scope, ProcessingUnitKind(5), "Invalid ExpressionTool payload", step_node_id, None, None)
            add_diagnostic(state, GraphIssueKind(5), "WorkflowStepRun.RunExpressionTool had an unexpected payload type.", workflow_file_path, None)
            return (run, bad_node_id_2)

        else: 
            return (run, build_processing_unit(state, run_scope, workflow_file_path, step_node_id, False, CWLProcessingUnit(2, match_value_4)))


    elif run.tag == 4:
        match_value_5: CWLOperationDescription | None = WorkflowStepRunOps_tryGetOperation(run)
        if match_value_5 is None:
            bad_node_id_3: str = add_processing_unit_node(state, run_scope, ProcessingUnitKind(5), "Invalid Operation payload", step_node_id, None, None)
            add_diagnostic(state, GraphIssueKind(5), "WorkflowStepRun.RunOperation had an unexpected payload type.", workflow_file_path, None)
            return (run, bad_node_id_3)

        else: 
            return (run, build_processing_unit(state, run_scope, workflow_file_path, step_node_id, False, CWLProcessingUnit(3, match_value_5)))


    else: 
        resolution: RunResolutionResult = resolve_run_string(state, workflow_file_path, run.fields[0])
        match_value: WorkflowStepRun = resolution.ResolvedRun
        if match_value.tag == 0:
            unresolved_path: str = match_value.fields[0]
            def _arrow1433(__unit: None=None, state: Any=state, run_scope: Any=run_scope, step_node_id: Any=step_node_id, workflow_file_path: Any=workflow_file_path, run: Any=run) -> IEnumerable_1[str | None]:
                return singleton_1(try_basename_no_cwl_extension(unresolved_path)) if is_cwl_reference(unresolved_path) else singleton_1(None)

            unresolved_label: str = choose_label(unresolved_path, to_list(delay(_arrow1433)))
            return (resolution.ResolvedRun, add_processing_unit_node(state, run_scope, ProcessingUnitKind(5) if (is_cwl_reference(unresolved_path) if resolution.AttemptedLookup else False) else ProcessingUnitKind(4), unresolved_label, step_node_id, unresolved_path, None))

        else: 
            resolved_run: WorkflowStepRun = match_value
            def chooser(key: str, state: Any=state, run_scope: Any=run_scope, step_node_id: Any=step_node_id, workflow_file_path: Any=workflow_file_path, run: Any=run) -> str | None:
                return try_find(key, state.RunNodeCache)

            cached_run_node_id: str | None = try_pick_1(chooser, resolution.ResolutionPathKeys)
            if cached_run_node_id is None:
                pattern_input: tuple[WorkflowStepRun, str]
                match_value_1: str | None = resolution.ResolvedFromPath
                if match_value_1 is None:
                    pattern_input = build_run_node(state, run_scope, step_node_id, resolution.ResolvedFromPath, resolved_run)

                else: 
                    resolved_path_key: str = normalize_path_key(match_value_1)
                    previous_stack: Any = state.RunResolutionStack
                    state.RunResolutionStack = FSharpSet__Add(previous_stack, resolved_path_key)
                    try: 
                        pattern_input = build_run_node(state, run_scope, step_node_id, resolution.ResolvedFromPath, resolved_run)

                    finally: 
                        state.RunResolutionStack = previous_stack


                built_node_id: str = pattern_input[1]
                arr: Array[str] = resolution.ResolutionPathKeys
                for idx in range(0, (len(arr) - 1) + 1, 1):
                    key_1: str = arr[idx]
                    state.RunNodeCache = FSharpMap__Add(state.RunNodeCache, key_1, built_node_id)
                return (pattern_input[0], built_node_id)

            else: 
                return (resolved_run, cached_run_node_id)





def wire_step_inputs(state: BuildState, scope: str, workflow_node_id: str, step: WorkflowStep) -> None:
    step_node_id: str = GraphId_stepNodeId(scope, step.Id)
    enumerator: Any = get_enumerator(step.In)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            step_input: StepInput = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            target_input_port_id: str = GraphId_portNodeId(step_node_id, PortDirection(0), step_input.Id)
            match_value: Array[str] | None = step_input.Source
            if match_value is not None:
                enumerator_1: Any = get_enumerator(match_value)
                try: 
                    while enumerator_1.System_Collections_IEnumerator_MoveNext():
                        source: str = enumerator_1.System_Collections_Generic_IEnumerator_1_get_Current()
                        source_ref: ParsedSourceReference = ReferenceParsing_parseSourceReference(source)
                        if is_null_or_white_space(source_ref.PortId):
                            add_diagnostic(state, GraphIssueKind(1), ((((("Step \'" + step.Id) + "\' input \'") + step_input.Id) + "\' has invalid source \'") + source) + "\'.", scope, source)

                        else: 
                            source_port_id: str
                            match_value_1: str | None = source_ref.StepId
                            source_port_id = GraphId_portNodeId(workflow_node_id, PortDirection(0), source_ref.PortId) if (match_value_1 is None) else GraphId_portNodeId(GraphId_stepNodeId(scope, match_value_1), PortDirection(1), source_ref.PortId)
                            if has_node(state, target_input_port_id) if has_node(state, source_port_id) else False:
                                add_edge_by_type(state, EdgeKind(2) if (source_ref.StepId is None) else EdgeKind(3), source_port_id, target_input_port_id, None)

                            else: 
                                add_diagnostic(state, GraphIssueKind(0), ((((("Unable to wire source \'" + source) + "\' to step input \'") + step.Id) + "/") + step_input.Id) + "\'.", scope, source)



                finally: 
                    dispose(enumerator_1)



    finally: 
        dispose(enumerator)



def wire_workflow_outputs(state: BuildState, scope: str, workflow_node_id: str, workflow: CWLWorkflowDescription) -> None:
    enumerator: Any = get_enumerator(workflow.Outputs)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            output: CWLOutput = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            enumerator_1: Any = get_enumerator(output.GetOutputSources())
            try: 
                while enumerator_1.System_Collections_IEnumerator_MoveNext():
                    output_source: str = enumerator_1.System_Collections_Generic_IEnumerator_1_get_Current()
                    parsed_source: ParsedSourceReference = ReferenceParsing_parseSourceReference(output_source)
                    if is_null_or_white_space(parsed_source.PortId):
                        add_diagnostic(state, GraphIssueKind(1), ((("Workflow output \'" + output.Name) + "\' has invalid outputSource \'") + output_source) + "\'.", scope, output_source)

                    else: 
                        source_port_id: str
                        match_value: str | None = parsed_source.StepId
                        source_port_id = GraphId_portNodeId(workflow_node_id, PortDirection(0), parsed_source.PortId) if (match_value is None) else GraphId_portNodeId(GraphId_stepNodeId(scope, match_value), PortDirection(1), parsed_source.PortId)
                        target_port_id: str = GraphId_portNodeId(workflow_node_id, PortDirection(1), output.Name)
                        if has_node(state, target_port_id) if has_node(state, source_port_id) else False:
                            add_edge_by_type(state, EdgeKind(4), source_port_id, target_port_id, None)

                        else: 
                            add_diagnostic(state, GraphIssueKind(0), ((("Unable to wire workflow output \'" + output.Name) + "\' from source \'") + output_source) + "\'.", scope, output_source)



            finally: 
                dispose(enumerator_1)


    finally: 
        dispose(enumerator)



def build_workflow_steps(state: BuildState, scope: str, workflow_file_path: str | None, workflow_node_id: str, workflow: CWLWorkflowDescription) -> None:
    enumerator: Any = get_enumerator(workflow.Steps)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            step: WorkflowStep = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            step_node_id: str = add_step_node(state, scope, workflow_node_id, step)
            add_step_ports(state, step_node_id, step)
            add_edge_by_type(state, EdgeKind(1), step_node_id, build_run_node(state, GraphId_childScope(scope, ("" + step.Id) + "/run"), step_node_id, workflow_file_path, step.Run)[1], "calls")

    finally: 
        dispose(enumerator)

    def action(step_1: WorkflowStep, state: Any=state, scope: Any=scope, workflow_file_path: Any=workflow_file_path, workflow_node_id: Any=workflow_node_id, workflow: Any=workflow) -> None:
        wire_step_inputs(state, scope, workflow_node_id, step_1)

    iterate(action, workflow.Steps)
    wire_workflow_outputs(state, scope, workflow_node_id, workflow)


def build_with(options: WorkflowGraphBuildOptions, processing_unit: CWLProcessingUnit) -> WorkflowGraph:
    root_scope: str = GraphId_normalizeSegment(options.RootScope)
    root_scope_1: str = "root" if is_null_or_white_space(root_scope) else root_scope
    state: BuildState = create_state(options, GraphId_unitNodeId(root_scope_1))
    ignore(build_processing_unit(state, root_scope_1, options.RootWorkflowFilePath, None, True, processing_unit))
    return state.Graph


def build(processing_unit: CWLProcessingUnit) -> WorkflowGraph:
    return build_with(WorkflowGraphBuildOptionsModule_defaultOptions, processing_unit)


__all__ = ["BuildState_reflection", "RunResolutionResult_reflection", "create_graph", "create_state", "add_diagnostic", "has_node", "add_node", "add_edge", "add_edge_by_type", "create_metadata", "add_processing_unit_node", "add_port_node", "add_step_node", "add_workflow_ports", "add_tool_ports", "add_expression_tool_ports", "add_operation_ports", "add_step_ports", "trim_to_name_candidate", "is_cwl_reference", "try_basename_no_cwl_extension", "try_get_processing_unit_name", "choose_label", "get_run_path_candidates", "resolve_run_string", "build_processing_unit", "build_run_node", "wire_step_inputs", "wire_workflow_outputs", "build_workflow_steps", "build_with", "build"]

