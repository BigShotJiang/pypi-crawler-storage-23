from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass
from ..fable_modules.fable_library.reflection import (TypeInfo, string_type, option_type, lambda_type, bool_type, record_type)
from ..fable_modules.fable_library.types import Record
from ..CWL.cwlprocessing_unit import (CWLProcessingUnit, CWLProcessingUnit_reflection)

def _expr1328() -> TypeInfo:
    return record_type("ARCtrl.WorkflowGraph.WorkflowGraphBuildOptions", [], WorkflowGraphBuildOptions, lambda: [("RootScope", string_type), ("RootWorkflowFilePath", option_type(string_type)), ("TryResolveRunPath", option_type(lambda_type(string_type, option_type(CWLProcessingUnit_reflection())))), ("StrictUnresolvedRunReferences", bool_type), ("ExpandNestedWorkflows", bool_type)])


@dataclass(eq = False, repr = False, slots = True)
class WorkflowGraphBuildOptions(Record):
    RootScope: str
    RootWorkflowFilePath: str | None
    TryResolveRunPath: Callable[[str], CWLProcessingUnit | None] | None
    StrictUnresolvedRunReferences: bool
    ExpandNestedWorkflows: bool

WorkflowGraphBuildOptions_reflection = _expr1328

WorkflowGraphBuildOptionsModule_defaultOptions: WorkflowGraphBuildOptions = WorkflowGraphBuildOptions("root", None, None, False, True)

def WorkflowGraphBuildOptionsModule_withRootScope(root_scope: str, options: WorkflowGraphBuildOptions) -> WorkflowGraphBuildOptions:
    return WorkflowGraphBuildOptions(root_scope, options.RootWorkflowFilePath, options.TryResolveRunPath, options.StrictUnresolvedRunReferences, options.ExpandNestedWorkflows)


def WorkflowGraphBuildOptionsModule_withRootWorkflowFilePath(root_workflow_file_path: str | None, options: WorkflowGraphBuildOptions) -> WorkflowGraphBuildOptions:
    return WorkflowGraphBuildOptions(options.RootScope, root_workflow_file_path, options.TryResolveRunPath, options.StrictUnresolvedRunReferences, options.ExpandNestedWorkflows)


def WorkflowGraphBuildOptionsModule_withTryResolveRunPath(try_resolve_run_path: Callable[[str], CWLProcessingUnit | None] | None, options: WorkflowGraphBuildOptions) -> WorkflowGraphBuildOptions:
    return WorkflowGraphBuildOptions(options.RootScope, options.RootWorkflowFilePath, try_resolve_run_path, options.StrictUnresolvedRunReferences, options.ExpandNestedWorkflows)


def WorkflowGraphBuildOptionsModule_withStrictUnresolvedRunReferences(strict: bool, options: WorkflowGraphBuildOptions) -> WorkflowGraphBuildOptions:
    return WorkflowGraphBuildOptions(options.RootScope, options.RootWorkflowFilePath, options.TryResolveRunPath, strict, options.ExpandNestedWorkflows)


def WorkflowGraphBuildOptionsModule_withExpandNestedWorkflows(expand_nested_workflows: bool, options: WorkflowGraphBuildOptions) -> WorkflowGraphBuildOptions:
    return WorkflowGraphBuildOptions(options.RootScope, options.RootWorkflowFilePath, options.TryResolveRunPath, options.StrictUnresolvedRunReferences, expand_nested_workflows)


__all__ = ["WorkflowGraphBuildOptions_reflection", "WorkflowGraphBuildOptionsModule_defaultOptions", "WorkflowGraphBuildOptionsModule_withRootScope", "WorkflowGraphBuildOptionsModule_withRootWorkflowFilePath", "WorkflowGraphBuildOptionsModule_withTryResolveRunPath", "WorkflowGraphBuildOptionsModule_withStrictUnresolvedRunReferences", "WorkflowGraphBuildOptionsModule_withExpandNestedWorkflows"]

