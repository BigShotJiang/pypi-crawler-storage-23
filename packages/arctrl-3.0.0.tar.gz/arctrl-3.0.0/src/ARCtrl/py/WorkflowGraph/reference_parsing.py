from __future__ import annotations
from dataclasses import dataclass
from ..fable_modules.fable_library.option import (default_arg, of_nullable)
from ..fable_modules.fable_library.reflection import (TypeInfo, string_type, option_type, record_type)
from ..fable_modules.fable_library.string_ import (starts_with_exact, substring, is_null_or_white_space)
from ..fable_modules.fable_library.types import Record
from ..CWL.workflow_steps import StepOutput

def _expr1327() -> TypeInfo:
    return record_type("ARCtrl.WorkflowGraph.ParsedSourceReference", [], ParsedSourceReference, lambda: [("StepId", option_type(string_type)), ("PortId", string_type), ("Raw", string_type)])


@dataclass(eq = False, repr = False, slots = True)
class ParsedSourceReference(Record):
    StepId: str | None
    PortId: str
    Raw: str

ParsedSourceReference_reflection = _expr1327

def ReferenceParsing_trimHashPrefix(value: str) -> str:
    trimmed: str = value.strip()
    if starts_with_exact(trimmed, "#"):
        return substring(trimmed, 1)

    else: 
        return trimmed



def ReferenceParsing_parseSourceReference(source: str) -> ParsedSourceReference:
    if is_null_or_white_space(source):
        return ParsedSourceReference(None, "", default_arg(of_nullable(source), ""))

    else: 
        normalized: str = ReferenceParsing_trimHashPrefix(source)
        separator_index: int = normalized.find("/") or 0
        if separator_index < 0:
            return ParsedSourceReference(None, normalized, source)

        else: 
            step_id: str = substring(normalized, 0, separator_index).strip()
            port_id: str = substring(normalized, separator_index + 1).strip()
            return ParsedSourceReference(None if is_null_or_white_space(step_id) else step_id, port_id, source)




def ReferenceParsing_extractStepOutputId(output: StepOutput) -> str:
    if output.tag == 1:
        return output.fields[0].Id

    else: 
        return output.fields[0]



__all__ = ["ParsedSourceReference_reflection", "ReferenceParsing_trimHashPrefix", "ReferenceParsing_parseSourceReference", "ReferenceParsing_extractStepOutputId"]

