from __future__ import annotations
from collections.abc import Callable
from typing import Any
from ..fable_modules.fable_library.map import (of_seq, empty as empty_1, is_empty, try_find)
from ..fable_modules.fable_library.result import FSharpResult_2
from ..fable_modules.fable_library.seq import (map, delay, append, collect, empty, singleton)
from ..fable_modules.fable_library.types import Array
from ..fable_modules.fable_library.util import (IEnumerable_1, compare_primitives, get_enumerator, dispose)
from ..Core.arc_types import (ArcInvestigation, ArcWorkflow, ArcRun)
from ..Core.Helper.identifier import (Workflow_cwlFileNameFromIdentifier, Run_cwlFileNameFromIdentifier)
from ..CWL.cwlprocessing_unit import CWLProcessingUnit
from ..FileSystem.path import normalize_path_key
from .builder import build_with
from .build_options import (WorkflowGraphBuildOptions, WorkflowGraphBuildOptionsModule_withRootScope, WorkflowGraphBuildOptionsModule_defaultOptions, WorkflowGraphBuildOptionsModule_withRootWorkflowFilePath, WorkflowGraphBuildOptionsModule_withTryResolveRunPath)
from .graph_types import (GraphBuildIssue_create_Z2F3B511A, GraphIssueKind, GraphBuildIssue, WorkflowGraph, WorkflowGraphIndex_create_56E060E0, WorkflowGraphIndex)

def create_cwl_lookup_from_investigation(investigation: ArcInvestigation | None=None) -> Any:
    if investigation is not None:
        inv: ArcInvestigation = investigation
        def mapping(tupled_arg: tuple[str, CWLProcessingUnit], investigation: Any=investigation) -> tuple[str, CWLProcessingUnit]:
            return (normalize_path_key(tupled_arg[0]), tupled_arg[1])

        def _arrow1333(__unit: None=None, investigation: Any=investigation) -> IEnumerable_1[tuple[str, CWLProcessingUnit]]:
            def _arrow1330(workflow: ArcWorkflow) -> IEnumerable_1[tuple[str, CWLProcessingUnit]]:
                match_value: CWLProcessingUnit | None = workflow.CWLDescription
                if match_value is None:
                    return empty()

                else: 
                    cwl: CWLProcessingUnit = match_value
                    return singleton((Workflow_cwlFileNameFromIdentifier(workflow.Identifier), cwl))


            def _arrow1332(__unit: None=None) -> IEnumerable_1[tuple[str, CWLProcessingUnit]]:
                def _arrow1331(run: ArcRun) -> IEnumerable_1[tuple[str, CWLProcessingUnit]]:
                    match_value_1: CWLProcessingUnit | None = run.CWLDescription
                    if match_value_1 is None:
                        return empty()

                    else: 
                        cwl_1: CWLProcessingUnit = match_value_1
                        return singleton((Run_cwlFileNameFromIdentifier(run.Identifier), cwl_1))


                return collect(_arrow1331, inv.Runs)

            return append(collect(_arrow1330, inv.Workflows), delay(_arrow1332))

        class ObjectExpr1334:
            @property
            def Compare(self) -> Callable[[str, str], int]:
                return compare_primitives

        return of_seq(map(mapping, delay(_arrow1333)), ObjectExpr1334())

    else: 
        class ObjectExpr1335:
            @property
            def Compare(self) -> Callable[[str, str], int]:
                return compare_primitives

        return empty_1(ObjectExpr1335())



def create_resolver(lookup: Any) -> Callable[[str], CWLProcessingUnit | None] | None:
    if is_empty(lookup):
        return None

    else: 
        def _arrow1336(path: str, lookup: Any=lookup) -> CWLProcessingUnit | None:
            return try_find(normalize_path_key(path), lookup)

        return _arrow1336



def create_missing_description_error(identifier: str, scope_type: Any) -> GraphBuildIssue:
    return GraphBuildIssue_create_Z2F3B511A(GraphIssueKind(4), ((("No CWLDescription available for " + str(scope_type)) + " \'") + identifier) + "\'.", identifier)


def of_workflow(workflow: ArcWorkflow) -> FSharpResult_2[WorkflowGraph, GraphBuildIssue]:
    match_value: CWLProcessingUnit | None = workflow.CWLDescription
    if match_value is not None:
        processing_unit: CWLProcessingUnit = match_value
        def _arrow1337(__unit: None=None, workflow: Any=workflow) -> WorkflowGraphBuildOptions:
            options_2: WorkflowGraphBuildOptions
            options_1: WorkflowGraphBuildOptions = WorkflowGraphBuildOptionsModule_withRootScope(workflow.Identifier, WorkflowGraphBuildOptionsModule_defaultOptions)
            options_2 = WorkflowGraphBuildOptionsModule_withRootWorkflowFilePath(Workflow_cwlFileNameFromIdentifier(workflow.Identifier), options_1)
            return WorkflowGraphBuildOptionsModule_withTryResolveRunPath(create_resolver(create_cwl_lookup_from_investigation(workflow.Investigation)), options_2)

        return FSharpResult_2(0, build_with(_arrow1337(), processing_unit))

    else: 
        return FSharpResult_2(1, create_missing_description_error(workflow.Identifier, "workflow"))



def of_run(run: ArcRun) -> FSharpResult_2[WorkflowGraph, GraphBuildIssue]:
    match_value: CWLProcessingUnit | None = run.CWLDescription
    if match_value is not None:
        processing_unit: CWLProcessingUnit = match_value
        def _arrow1338(__unit: None=None, run: Any=run) -> WorkflowGraphBuildOptions:
            options_2: WorkflowGraphBuildOptions
            options_1: WorkflowGraphBuildOptions = WorkflowGraphBuildOptionsModule_withRootScope(run.Identifier, WorkflowGraphBuildOptionsModule_defaultOptions)
            options_2 = WorkflowGraphBuildOptionsModule_withRootWorkflowFilePath(Run_cwlFileNameFromIdentifier(run.Identifier), options_1)
            return WorkflowGraphBuildOptionsModule_withTryResolveRunPath(create_resolver(create_cwl_lookup_from_investigation(run.Investigation)), options_2)

        return FSharpResult_2(0, build_with(_arrow1338(), processing_unit))

    else: 
        return FSharpResult_2(1, create_missing_description_error(run.Identifier, "run"))



def of_investigation(investigation: ArcInvestigation) -> WorkflowGraphIndex:
    workflow_graphs: Array[tuple[str, FSharpResult_2[WorkflowGraph, GraphBuildIssue]]] = []
    run_graphs: Array[tuple[str, FSharpResult_2[WorkflowGraph, GraphBuildIssue]]] = []
    enumerator: Any = get_enumerator(investigation.Workflows)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            workflow: ArcWorkflow = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            (workflow_graphs.append((workflow.Identifier, of_workflow(workflow))))

    finally: 
        dispose(enumerator)

    enumerator_1: Any = get_enumerator(investigation.Runs)
    try: 
        while enumerator_1.System_Collections_IEnumerator_MoveNext():
            run: ArcRun = enumerator_1.System_Collections_Generic_IEnumerator_1_get_Current()
            (run_graphs.append((run.Identifier, of_run(run))))

    finally: 
        dispose(enumerator_1)

    return WorkflowGraphIndex_create_56E060E0(workflow_graphs, run_graphs)


__all__ = ["create_cwl_lookup_from_investigation", "create_resolver", "create_missing_description_error", "of_workflow", "of_run", "of_investigation"]

