from __future__ import annotations
from typing import Any
from ..fable_modules.fable_library.list import (of_seq, FSharpList)
from ..fable_modules.fable_library.seq import (try_find, filter)
from ..fable_modules.fable_library.util import equals
from .graph_types import (WorkflowGraphNode, WorkflowGraph, NodeKind, WorkflowGraphEdge, EdgeKind, PortDirection, WorkflowGraph__get_NodeCount, WorkflowGraph__get_EdgeCount)

def try_find_node(node_id: str, graph: WorkflowGraph) -> WorkflowGraphNode | None:
    def predicate(node: WorkflowGraphNode, node_id: Any=node_id, graph: Any=graph) -> bool:
        return node.Id == node_id

    return try_find(predicate, graph.Nodes)


def get_nodes(kind: NodeKind, graph: WorkflowGraph) -> FSharpList[WorkflowGraphNode]:
    def predicate(node: WorkflowGraphNode, kind: Any=kind, graph: Any=graph) -> bool:
        return equals(node.Kind, kind)

    return of_seq(filter(predicate, graph.Nodes))


def get_edges_from(node_id: str, graph: WorkflowGraph) -> FSharpList[WorkflowGraphEdge]:
    def predicate(edge: WorkflowGraphEdge, node_id: Any=node_id, graph: Any=graph) -> bool:
        return edge.SourceNodeId == node_id

    return of_seq(filter(predicate, graph.Edges))


def get_edges_to(node_id: str, graph: WorkflowGraph) -> FSharpList[WorkflowGraphEdge]:
    def predicate(edge: WorkflowGraphEdge, node_id: Any=node_id, graph: Any=graph) -> bool:
        return edge.TargetNodeId == node_id

    return of_seq(filter(predicate, graph.Edges))


def get_edges_by_kind(kind: EdgeKind, graph: WorkflowGraph) -> FSharpList[WorkflowGraphEdge]:
    def predicate(edge: WorkflowGraphEdge, kind: Any=kind, graph: Any=graph) -> bool:
        return equals(edge.Kind, kind)

    return of_seq(filter(predicate, graph.Edges))


def get_input_ports(owner_node_id: str, graph: WorkflowGraph) -> FSharpList[WorkflowGraphNode]:
    def predicate(node: WorkflowGraphNode, owner_node_id: Any=owner_node_id, graph: Any=graph) -> bool:
        if equals(node.OwnerNodeId, owner_node_id):
            return equals(node.Kind, NodeKind(2, PortDirection(0)))

        else: 
            return False


    return of_seq(filter(predicate, graph.Nodes))


def get_output_ports(owner_node_id: str, graph: WorkflowGraph) -> FSharpList[WorkflowGraphNode]:
    def predicate(node: WorkflowGraphNode, owner_node_id: Any=owner_node_id, graph: Any=graph) -> bool:
        if equals(node.OwnerNodeId, owner_node_id):
            return equals(node.Kind, NodeKind(2, PortDirection(1)))

        else: 
            return False


    return of_seq(filter(predicate, graph.Nodes))


def node_count(graph: WorkflowGraph) -> int:
    return WorkflowGraph__get_NodeCount(graph)


def edge_count(graph: WorkflowGraph) -> int:
    return WorkflowGraph__get_EdgeCount(graph)


__all__ = ["try_find_node", "get_nodes", "get_edges_from", "get_edges_to", "get_edges_by_kind", "get_input_ports", "get_output_ports", "node_count", "edge_count"]

