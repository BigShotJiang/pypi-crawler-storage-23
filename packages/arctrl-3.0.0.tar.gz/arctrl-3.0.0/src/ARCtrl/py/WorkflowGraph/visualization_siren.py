from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from ..fable_modules.fable_library.array_ import (iterate, map as map_1, filter as filter_1)
from ..fable_modules.fable_library.char import (is_letter_or_digit, is_digit)
from ..fable_modules.fable_library.list import of_array
from ..fable_modules.fable_library.map import (of_seq, try_find)
from ..fable_modules.fable_library.option import (default_arg, to_array as to_array_1, filter as filter_2, bind)
from ..fable_modules.fable_library.reflection import (TypeInfo, bool_type, record_type)
from ..fable_modules.fable_library.seq import (map, filter, exists, to_array, sort_by, choose, iterate as iterate_1)
from ..fable_modules.fable_library.set import (empty, FSharpSet__Contains, FSharpSet__Add, of_array as of_array_1, of_seq as of_seq_1)
from ..fable_modules.fable_library.string_ import (is_null_or_white_space, index_of_any, replace)
from ..fable_modules.fable_library.types import (Record, Array)
from ..fable_modules.fable_library.util import (equals, compare_primitives)
from ..fable_modules.siren.siren import (flowchart, siren)
from ..fable_modules.siren.siren_types import (Direction, Direction_reflection, FlowchartElement, SirenElement)
from ..CWL.cwlprocessing_unit import CWLProcessingUnit
from .builder import (build, build_with)
from .build_options import WorkflowGraphBuildOptions
from .graph_types import (NodeKind, WorkflowGraphNode, WorkflowGraphEdge, EdgeKind, WorkflowGraph, ProcessingUnitKind, EdgeKindModule_asKey, PortDirection)

def _expr1501() -> TypeInfo:
    return record_type("ARCtrl.WorkflowGraph.WorkflowGraphVisualizationOptions", [], WorkflowGraphVisualizationOptions, lambda: [("Direction", Direction_reflection()), ("EnableStyling", bool_type), ("RenderContainsLinks", bool_type)])


@dataclass(eq = False, repr = False, slots = True)
class WorkflowGraphVisualizationOptions(Record):
    Direction: Direction
    EnableStyling: bool
    RenderContainsLinks: bool

WorkflowGraphVisualizationOptions_reflection = _expr1501

WorkflowGraphVisualizationOptionsModule_defaultOptions: WorkflowGraphVisualizationOptions = WorkflowGraphVisualizationOptions(Direction(1), True, False)

WorkflowGraphSiren_mermaidSpecials: Array[str] = ["/", "\\", "[", "]", "{", "}", "(", ")", ">", "<", "|"]

def WorkflowGraphSiren_sanitizeMermaidId(id: str) -> str:
    if is_null_or_white_space(id):
        return "node"

    else: 
        normalized: str
        chars: Array[str] = []
        def action(c: str, id: Any=id) -> None:
            if True if is_letter_or_digit(c) else (c == "_"):
                (chars.append(c))

            elif True if (c == "/") else (c == "\\"):
                (chars.append("_"))
                (chars.append("_"))

            else: 
                (chars.append("_"))


        iterate(action, list(id))
        value: Array[str] = chars[:]
        normalized = ''.join(value)
        if is_digit(normalized[0]) if (len(normalized) > 0) else False:
            return "_" + normalized

        else: 
            return normalized




def WorkflowGraphSiren_quoteMermaidLabel(label: str) -> str:
    if is_null_or_white_space(label):
        return label

    elif True if (index_of_any(label, WorkflowGraphSiren_mermaidSpecials) >= 0) else (label.find("\"") >= 0):
        return ("\"" + replace(label, "\"", "#quot;")) + "\""

    else: 
        return label



def WorkflowGraphSiren_nodeToElement(node: WorkflowGraphNode) -> FlowchartElement:
    node_id: str = WorkflowGraphSiren_sanitizeMermaidId(node.Id)
    label: str = WorkflowGraphSiren_quoteMermaidLabel(node.Label)
    match_value: NodeKind = node.Kind
    if match_value.tag == 1:
        return flowchart.node(node_id, label)

    elif match_value.tag == 2:
        if match_value.fields[0].tag == 1:
            return flowchart.node_stadium(node_id, label)

        else: 
            return flowchart.node_round(node_id, label)


    elif match_value.fields[0].tag == 1:
        return flowchart.node_hexagon(node_id, label)

    elif match_value.fields[0].tag == 2:
        return flowchart.node_rhombus(node_id, label)

    elif match_value.fields[0].tag == 3:
        return flowchart.node(node_id, label)

    elif match_value.fields[0].tag == 4:
        return flowchart.node(node_id, label)

    elif match_value.fields[0].tag == 5:
        return flowchart.node(node_id, label)

    else: 
        return flowchart.node_subroutine(node_id, label)



def WorkflowGraphSiren_tryGetStepRunLookup(graph: WorkflowGraph) -> Any:
    def mapping(e_1: WorkflowGraphEdge, graph: Any=graph) -> tuple[str, str]:
        return (e_1.SourceNodeId, e_1.TargetNodeId)

    def predicate(e: WorkflowGraphEdge, graph: Any=graph) -> bool:
        return equals(e.Kind, EdgeKind(1))

    class ObjectExpr1508:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    return of_seq(map(mapping, filter(predicate, graph.Edges)), ObjectExpr1508())


def WorkflowGraphSiren_addStyles(elements: Array[FlowchartElement], processing_unit_nodes: Array[WorkflowGraphNode], root_input_nodes: Array[WorkflowGraphNode], root_output_nodes: Array[WorkflowGraphNode]) -> None:
    def node_ids_by_predicate(predicate: Callable[[WorkflowGraphNode], bool], nodes: Array[WorkflowGraphNode], elements: Any=elements, processing_unit_nodes: Any=processing_unit_nodes, root_input_nodes: Any=root_input_nodes, root_output_nodes: Any=root_output_nodes) -> Array[str]:
        def mapping(n: WorkflowGraphNode, predicate: Any=predicate, nodes: Any=nodes) -> str:
            return WorkflowGraphSiren_sanitizeMermaidId(n.Id)

        return map_1(mapping, filter_1(predicate, nodes), None)

    def _arrow1510(n_1: WorkflowGraphNode, elements: Any=elements, processing_unit_nodes: Any=processing_unit_nodes, root_input_nodes: Any=root_input_nodes, root_output_nodes: Any=root_output_nodes) -> bool:
        return equals(n_1.Kind, NodeKind(0, ProcessingUnitKind(0)))

    workflow_ids: Array[str] = node_ids_by_predicate(_arrow1510, processing_unit_nodes)
    def _arrow1511(n_2: WorkflowGraphNode, elements: Any=elements, processing_unit_nodes: Any=processing_unit_nodes, root_input_nodes: Any=root_input_nodes, root_output_nodes: Any=root_output_nodes) -> bool:
        return equals(n_2.Kind, NodeKind(0, ProcessingUnitKind(1)))

    tool_ids: Array[str] = node_ids_by_predicate(_arrow1511, processing_unit_nodes)
    def _arrow1512(n_3: WorkflowGraphNode, elements: Any=elements, processing_unit_nodes: Any=processing_unit_nodes, root_input_nodes: Any=root_input_nodes, root_output_nodes: Any=root_output_nodes) -> bool:
        return equals(n_3.Kind, NodeKind(0, ProcessingUnitKind(2)))

    expression_ids: Array[str] = node_ids_by_predicate(_arrow1512, processing_unit_nodes)
    def _arrow1513(n_4: WorkflowGraphNode, elements: Any=elements, processing_unit_nodes: Any=processing_unit_nodes, root_input_nodes: Any=root_input_nodes, root_output_nodes: Any=root_output_nodes) -> bool:
        return equals(n_4.Kind, NodeKind(0, ProcessingUnitKind(3)))

    operation_ids: Array[str] = node_ids_by_predicate(_arrow1513, processing_unit_nodes)
    def _arrow1514(n_5: WorkflowGraphNode, elements: Any=elements, processing_unit_nodes: Any=processing_unit_nodes, root_input_nodes: Any=root_input_nodes, root_output_nodes: Any=root_output_nodes) -> bool:
        return True if equals(n_5.Kind, NodeKind(0, ProcessingUnitKind(5))) else equals(n_5.Kind, NodeKind(0, ProcessingUnitKind(4)))

    unresolved_ids: Array[str] = node_ids_by_predicate(_arrow1514, processing_unit_nodes)
    def mapping_1(n_6: WorkflowGraphNode, elements: Any=elements, processing_unit_nodes: Any=processing_unit_nodes, root_input_nodes: Any=root_input_nodes, root_output_nodes: Any=root_output_nodes) -> str:
        return WorkflowGraphSiren_sanitizeMermaidId(n_6.Id)

    input_ids: Array[str] = map_1(mapping_1, root_input_nodes, None)
    def mapping_2(n_7: WorkflowGraphNode, elements: Any=elements, processing_unit_nodes: Any=processing_unit_nodes, root_input_nodes: Any=root_input_nodes, root_output_nodes: Any=root_output_nodes) -> str:
        return WorkflowGraphSiren_sanitizeMermaidId(n_7.Id)

    output_ids: Array[str] = map_1(mapping_2, root_output_nodes, None)
    (elements.append(flowchart.class_def("wg_workflow", of_array([("fill", "#dff4ff"), ("stroke", "#246fa8"), ("stroke-width", "2px")]))))
    (elements.append(flowchart.class_def("wg_tool", of_array([("fill", "#e8f5e9"), ("stroke", "#2e7d32"), ("stroke-width", "2px")]))))
    (elements.append(flowchart.class_def("wg_expression", of_array([("fill", "#fff3e0"), ("stroke", "#e65100"), ("stroke-width", "2px")]))))
    if len(operation_ids) > 0:
        (elements.append(flowchart.class_def("wg_operation", of_array([("fill", "#ede7f6"), ("stroke", "#5e35b1"), ("stroke-width", "2px")]))))

    (elements.append(flowchart.class_def("wg_unresolved", of_array([("fill", "#ffebee"), ("stroke", "#c62828"), ("stroke-width", "2px"), ("stroke-dasharray", "5 5")]))))
    (elements.append(flowchart.class_def("wg_initial_input", of_array([("fill", "#e1f5fe"), ("stroke", "#0288d1"), ("stroke-width", "2px")]))))
    (elements.append(flowchart.class_def("wg_final_output", of_array([("fill", "#f3e5f5"), ("stroke", "#7b1fa2"), ("stroke-width", "2px")]))))
    if len(workflow_ids) > 0:
        (elements.append(flowchart.class_(workflow_ids, "wg_workflow")))

    if len(tool_ids) > 0:
        (elements.append(flowchart.class_(tool_ids, "wg_tool")))

    if len(expression_ids) > 0:
        (elements.append(flowchart.class_(expression_ids, "wg_expression")))

    if len(operation_ids) > 0:
        (elements.append(flowchart.class_(operation_ids, "wg_operation")))

    if len(unresolved_ids) > 0:
        (elements.append(flowchart.class_(unresolved_ids, "wg_unresolved")))

    if len(input_ids) > 0:
        (elements.append(flowchart.class_(input_ids, "wg_initial_input")))

    if len(output_ids) > 0:
        (elements.append(flowchart.class_(output_ids, "wg_final_output")))



def WorkflowGraphSiren_fromGraphWithOptions(options: WorkflowGraphVisualizationOptions, graph: WorkflowGraph) -> SirenElement:
    elements: Array[FlowchartElement] = []
    class ObjectExpr1519:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    edge_keys: Any = empty(ObjectExpr1519())
    def add_grouped_nodes(group_id: str, group_label: str, nodes: Array[WorkflowGraphNode], options: Any=options, graph: Any=graph) -> None:
        if len(nodes) > 0:
            grouped: Array[FlowchartElement] = []
            def action(node: WorkflowGraphNode, group_id: Any=group_id, group_label: Any=group_label, nodes: Any=nodes) -> None:
                (grouped.append(WorkflowGraphSiren_nodeToElement(node)))

            iterate(action, nodes)
            (elements.append(flowchart.subgraph_named(group_id, WorkflowGraphSiren_quoteMermaidLabel(group_label), grouped)))


    def add_rendered_edge(kind: EdgeKind, source_node_id: str, target_node_id: str, label: str | None=None, options: Any=options, graph: Any=graph) -> None:
        nonlocal edge_keys
        label_key: str = default_arg(label, "")
        key: str = ((((((("" + EdgeKindModule_asKey(kind)) + "::") + source_node_id) + "::") + target_node_id) + "::") + label_key) + ""
        if not FSharpSet__Contains(edge_keys, key):
            edge_keys = FSharpSet__Add(edge_keys, key)
            src: str = WorkflowGraphSiren_sanitizeMermaidId(source_node_id)
            tgt: str = WorkflowGraphSiren_sanitizeMermaidId(target_node_id)
            def _arrow1522(__unit: None=None, kind: Any=kind, source_node_id: Any=source_node_id, target_node_id: Any=target_node_id, label: Any=label) -> FlowchartElement:
                l_3: str = label
                return flowchart.link_thick_arrow(src, tgt, WorkflowGraphSiren_quoteMermaidLabel(l_3))

            def _arrow1523(__unit: None=None, kind: Any=kind, source_node_id: Any=source_node_id, target_node_id: Any=target_node_id, label: Any=label) -> FlowchartElement:
                l_4: str = label
                return flowchart.link_dotted_arrow(src, tgt, WorkflowGraphSiren_quoteMermaidLabel(l_4))

            def _arrow1524(__unit: None=None, kind: Any=kind, source_node_id: Any=source_node_id, target_node_id: Any=target_node_id, label: Any=label) -> FlowchartElement:
                l_5: str = label
                return flowchart.link_arrow(src, tgt, WorkflowGraphSiren_quoteMermaidLabel(l_5))

            link: FlowchartElement = ((_arrow1522() if (not is_null_or_white_space(label)) else flowchart.link_thick_arrow(src, tgt)) if (label is not None) else flowchart.link_thick_arrow(src, tgt)) if (kind.tag == 3) else (((_arrow1523() if (not is_null_or_white_space(label)) else flowchart.link_dotted_arrow(src, tgt)) if (label is not None) else flowchart.link_dotted_arrow(src, tgt)) if (kind.tag == 0) else ((_arrow1524() if (not is_null_or_white_space(label)) else flowchart.link_arrow(src, tgt)) if (label is not None) else flowchart.link_arrow(src, tgt)))
            (elements.append(link))


    def predicate(e: WorkflowGraphEdge, options: Any=options, graph: Any=graph) -> bool:
        return equals(e.Kind, EdgeKind(1))

    has_calls: bool = exists(predicate, graph.Edges)
    def projection(n_2: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> str:
        return n_2.Id

    def predicate_2(n_1: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> bool:
        if has_calls:
            return n_1.Id != graph.RootProcessingUnitNodeId

        else: 
            return True


    def predicate_1(n: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> bool:
        if n.Kind.tag == 0:
            return True

        else: 
            return False


    class ObjectExpr1525:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    processing_unit_nodes: Array[WorkflowGraphNode] = to_array(sort_by(projection, filter(predicate_2, filter(predicate_1, graph.Nodes)), ObjectExpr1525()))
    def projection_1(n_4: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> str:
        return n_4.Id

    def predicate_3(n_3: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> bool:
        if equals(n_3.Kind, NodeKind(2, PortDirection(0))):
            return equals(n_3.OwnerNodeId, graph.RootProcessingUnitNodeId)

        else: 
            return False


    class ObjectExpr1528:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    root_input_nodes: Array[WorkflowGraphNode] = to_array(sort_by(projection_1, filter(predicate_3, graph.Nodes), ObjectExpr1528()))
    def projection_2(n_6: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> str:
        return n_6.Id

    def predicate_4(n_5: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> bool:
        if equals(n_5.Kind, NodeKind(2, PortDirection(1))):
            return equals(n_5.OwnerNodeId, graph.RootProcessingUnitNodeId)

        else: 
            return False


    class ObjectExpr1530:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    root_output_nodes: Array[WorkflowGraphNode] = to_array(sort_by(projection_2, filter(predicate_4, graph.Nodes), ObjectExpr1530()))
    def mapping(n_7: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> str:
        return n_7.Id

    class ObjectExpr1531:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    processing_unit_node_ids: Any = of_array_1(map_1(mapping, processing_unit_nodes, None), ObjectExpr1531())
    def mapping_1(n_8: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> str:
        return n_8.Id

    class ObjectExpr1532:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    root_input_node_ids: Any = of_array_1(map_1(mapping_1, root_input_nodes, None), ObjectExpr1532())
    def mapping_2(n_9: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> str:
        return n_9.Id

    class ObjectExpr1533:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    root_output_node_ids: Any = of_array_1(map_1(mapping_2, root_output_nodes, None), ObjectExpr1533())
    def chooser(n_10: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> str | None:
        if equals(n_10.Kind, NodeKind(1)):
            return n_10.Id

        else: 
            return None


    class ObjectExpr1535:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    step_node_ids: Any = of_seq_1(choose(chooser, graph.Nodes), ObjectExpr1535())
    def mapping_3(n_12: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> tuple[str, WorkflowGraphNode]:
        return (n_12.Id, n_12)

    def predicate_6(n_11: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> bool:
        if equals(n_11.Kind, NodeKind(2, PortDirection(0))):
            def predicate_5(value_4: str, n_11: Any=n_11) -> bool:
                return FSharpSet__Contains(step_node_ids, value_4)

            return exists(predicate_5, to_array_1(n_11.OwnerNodeId))

        else: 
            return False


    class ObjectExpr1536:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    step_input_ports: Any = of_seq(map(mapping_3, filter(predicate_6, graph.Nodes)), ObjectExpr1536())
    def mapping_4(n_14: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> tuple[str, WorkflowGraphNode]:
        return (n_14.Id, n_14)

    def predicate_8(n_13: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> bool:
        if equals(n_13.Kind, NodeKind(2, PortDirection(1))):
            def predicate_7(value_5: str, n_13: Any=n_13) -> bool:
                return FSharpSet__Contains(step_node_ids, value_5)

            return exists(predicate_7, to_array_1(n_13.OwnerNodeId))

        else: 
            return False


    class ObjectExpr1538:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    step_output_ports: Any = of_seq(map(mapping_4, filter(predicate_8, graph.Nodes)), ObjectExpr1538())
    step_to_run: Any = WorkflowGraphSiren_tryGetStepRunLookup(graph)
    def predicate_9(e_1: WorkflowGraphEdge, options: Any=options, graph: Any=graph) -> bool:
        return equals(e_1.Kind, EdgeKind(0))

    contains_step_edges: Array[WorkflowGraphEdge] = to_array(filter(predicate_9, graph.Edges))
    def try_get_run_of_step(step_node_id: str, options: Any=options, graph: Any=graph) -> str | None:
        def predicate_10(value_6: str, step_node_id: Any=step_node_id) -> bool:
            return FSharpSet__Contains(processing_unit_node_ids, value_6)

        return filter_2(predicate_10, try_find(step_node_id, step_to_run))

    add_grouped_nodes("wg_initial_inputs", "Initial Inputs", root_input_nodes)
    def action_1(arg: WorkflowGraphNode, options: Any=options, graph: Any=graph) -> None:
        item: FlowchartElement = WorkflowGraphSiren_nodeToElement(arg)
        (elements.append(item))

    iterate(action_1, processing_unit_nodes)
    add_grouped_nodes("wg_final_outputs", "Final Outputs", root_output_nodes)
    if FSharpSet__Contains(processing_unit_node_ids, graph.RootProcessingUnitNodeId) if (not has_calls) else False:
        for idx in range(0, (len(root_input_nodes) - 1) + 1, 1):
            input_node: WorkflowGraphNode = root_input_nodes[idx]
            add_rendered_edge(EdgeKind(2), input_node.Id, graph.RootProcessingUnitNodeId, input_node.Label)
        for idx_1 in range(0, (len(root_output_nodes) - 1) + 1, 1):
            add_rendered_edge(EdgeKind(4), graph.RootProcessingUnitNodeId, root_output_nodes[idx_1].Id, None)

    def action_2(e_2: WorkflowGraphEdge, options: Any=options, graph: Any=graph) -> None:
        if FSharpSet__Contains(processing_unit_node_ids, e_2.SourceNodeId):
            match_value_2: str | None = try_get_run_of_step(e_2.TargetNodeId)
            if match_value_2 is None:
                pass

            else: 
                add_rendered_edge(EdgeKind(0), e_2.SourceNodeId, match_value_2, None)



    iterate(action_2, contains_step_edges)
    def action_3(edge: WorkflowGraphEdge, options: Any=options, graph: Any=graph) -> None:
        match_value_3: EdgeKind = edge.Kind
        (pattern_matching_result,) = (None,)
        if match_value_3.tag == 2:
            if FSharpSet__Contains(root_input_node_ids, edge.SourceNodeId):
                pattern_matching_result = 0

            else: 
                pattern_matching_result = 3


        elif match_value_3.tag == 3:
            pattern_matching_result = 1

        elif match_value_3.tag == 4:
            if FSharpSet__Contains(root_output_node_ids, edge.TargetNodeId):
                pattern_matching_result = 2

            else: 
                pattern_matching_result = 3


        else: 
            pattern_matching_result = 3

        if pattern_matching_result == 0:
            match_value_4: WorkflowGraphNode | None = try_find(edge.TargetNodeId, step_input_ports)
            if match_value_4 is None:
                pass

            else: 
                target_port: WorkflowGraphNode = match_value_4
                match_value_5: str | None = bind(try_get_run_of_step, target_port.OwnerNodeId)
                if match_value_5 is None:
                    pass

                else: 
                    add_rendered_edge(EdgeKind(2), edge.SourceNodeId, match_value_5, target_port.Label)



        elif pattern_matching_result == 1:
            match_value: WorkflowGraphNode | None = try_find(edge.SourceNodeId, step_output_ports)
            match_value_1: WorkflowGraphNode | None = try_find(edge.TargetNodeId, step_input_ports)
            (pattern_matching_result_1, source_port, target_port_1) = (None, None, None)
            if match_value is not None:
                if match_value_1 is not None:
                    pattern_matching_result_1 = 0
                    source_port = match_value
                    target_port_1 = match_value_1

                else: 
                    pattern_matching_result_1 = 1


            else: 
                pattern_matching_result_1 = 1

            if pattern_matching_result_1 == 0:
                match_value_2: str | None = bind(try_get_run_of_step, source_port.OwnerNodeId)
                match_value_3: str | None = bind(try_get_run_of_step, target_port_1.OwnerNodeId)
                (pattern_matching_result_2, consumer_run_id_1, producer_run_id) = (None, None, None)
                if match_value_2 is not None:
                    if match_value_3 is not None:
                        pattern_matching_result_2 = 0
                        consumer_run_id_1 = match_value_3
                        producer_run_id = match_value_2

                    else: 
                        pattern_matching_result_2 = 1


                else: 
                    pattern_matching_result_2 = 1

                if pattern_matching_result_2 == 0:
                    add_rendered_edge(EdgeKind(3), producer_run_id, consumer_run_id_1, target_port_1.Label)

                elif pattern_matching_result_2 == 1:
                    pass


            elif pattern_matching_result_1 == 1:
                pass


        elif pattern_matching_result == 2:
            match_value_8: WorkflowGraphNode | None = try_find(edge.SourceNodeId, step_output_ports)
            if match_value_8 is None:
                if FSharpSet__Contains(root_input_node_ids, edge.SourceNodeId):
                    add_rendered_edge(EdgeKind(4), edge.SourceNodeId, edge.TargetNodeId, None)


            else: 
                match_value_9: str | None = bind(try_get_run_of_step, match_value_8.OwnerNodeId)
                if match_value_9 is None:
                    pass

                else: 
                    add_rendered_edge(EdgeKind(4), match_value_9, edge.TargetNodeId, None)



        elif pattern_matching_result == 3:
            pass


    def projection_3(e_3: WorkflowGraphEdge, options: Any=options, graph: Any=graph) -> str:
        return e_3.Id

    class ObjectExpr1540:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    iterate_1(action_3, sort_by(projection_3, graph.Edges, ObjectExpr1540()))
    if options.EnableStyling:
        WorkflowGraphSiren_addStyles(elements, processing_unit_nodes, root_input_nodes, root_output_nodes)

    return siren.flowchart(options.Direction, elements)


def WorkflowGraphSiren_fromGraph(graph: WorkflowGraph) -> SirenElement:
    return WorkflowGraphSiren_fromGraphWithOptions(WorkflowGraphVisualizationOptionsModule_defaultOptions, graph)


def WorkflowGraphSiren_fromProcessingUnit(processing_unit: CWLProcessingUnit) -> SirenElement:
    return WorkflowGraphSiren_fromGraph(build(processing_unit))


def WorkflowGraphSiren_fromProcessingUnitResolved(build_options: WorkflowGraphBuildOptions, processing_unit: CWLProcessingUnit) -> SirenElement:
    return WorkflowGraphSiren_fromGraph(build_with(build_options, processing_unit))


def WorkflowGraphSiren_toMermaidWithOptions(options: WorkflowGraphVisualizationOptions, graph: WorkflowGraph) -> str:
    diagram: SirenElement = WorkflowGraphSiren_fromGraphWithOptions(options, graph)
    return siren.write(diagram)


def WorkflowGraphSiren_toMermaid(graph: WorkflowGraph) -> str:
    return WorkflowGraphSiren_toMermaidWithOptions(WorkflowGraphVisualizationOptionsModule_defaultOptions, graph)


def WorkflowGraphSiren_toMarkdownWithOptions(options: WorkflowGraphVisualizationOptions, graph: WorkflowGraph) -> str:
    return ("```mermaid\n" + WorkflowGraphSiren_toMermaidWithOptions(options, graph)) + "\n```"


def WorkflowGraphSiren_toMarkdown(graph: WorkflowGraph) -> str:
    return WorkflowGraphSiren_toMarkdownWithOptions(WorkflowGraphVisualizationOptionsModule_defaultOptions, graph)


__all__ = ["WorkflowGraphVisualizationOptions_reflection", "WorkflowGraphVisualizationOptionsModule_defaultOptions", "WorkflowGraphSiren_mermaidSpecials", "WorkflowGraphSiren_sanitizeMermaidId", "WorkflowGraphSiren_quoteMermaidLabel", "WorkflowGraphSiren_nodeToElement", "WorkflowGraphSiren_tryGetStepRunLookup", "WorkflowGraphSiren_addStyles", "WorkflowGraphSiren_fromGraphWithOptions", "WorkflowGraphSiren_fromGraph", "WorkflowGraphSiren_fromProcessingUnit", "WorkflowGraphSiren_fromProcessingUnitResolved", "WorkflowGraphSiren_toMermaidWithOptions", "WorkflowGraphSiren_toMermaid", "WorkflowGraphSiren_toMarkdownWithOptions", "WorkflowGraphSiren_toMarkdown"]

