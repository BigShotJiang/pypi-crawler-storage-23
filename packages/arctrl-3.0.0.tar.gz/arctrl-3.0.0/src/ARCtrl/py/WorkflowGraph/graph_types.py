from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from ..fable_modules.dynamic_obj.dynamic_obj import (DynamicObj, DynamicObj_reflection)
from ..fable_modules.fable_library.option import default_arg
from ..fable_modules.fable_library.reflection import (TypeInfo, union_type, string_type, option_type, record_type, array_type, tuple_type)
from ..fable_modules.fable_library.result import FSharpResult_2
from ..fable_modules.fable_library.string_ import is_null_or_white_space
from ..fable_modules.fable_library.types import (Array, Union, Record)
from ..FileSystem.path import (normalize_path_key, combine)

def _expr1317() -> TypeInfo:
    return union_type("ARCtrl.WorkflowGraph.ProcessingUnitKind", [], ProcessingUnitKind, lambda: [[], [], [], [], [], []])


class ProcessingUnitKind(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Workflow", "CommandLineTool", "ExpressionTool", "Operation", "ExternalReference", "UnresolvedReference"]


ProcessingUnitKind_reflection = _expr1317

def _expr1318() -> TypeInfo:
    return union_type("ARCtrl.WorkflowGraph.PortDirection", [], PortDirection, lambda: [[], []])


class PortDirection(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Input", "Output"]


PortDirection_reflection = _expr1318

def _expr1319() -> TypeInfo:
    return union_type("ARCtrl.WorkflowGraph.NodeKind", [], NodeKind, lambda: [[("Item", ProcessingUnitKind_reflection())], [], [("Item", PortDirection_reflection())]])


class NodeKind(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["ProcessingUnitNode", "StepNode", "PortNode"]


NodeKind_reflection = _expr1319

def _expr1320() -> TypeInfo:
    return union_type("ARCtrl.WorkflowGraph.EdgeKind", [], EdgeKind, lambda: [[], [], [], [], []])


class EdgeKind(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Contains", "Calls", "BindsWorkflowInput", "DataFlow", "BindsWorkflowOutput"]


EdgeKind_reflection = _expr1320

def _expr1321() -> TypeInfo:
    return union_type("ARCtrl.WorkflowGraph.GraphIssueKind", [], GraphIssueKind, lambda: [[], [], [], [], [], []])


class GraphIssueKind(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["MissingReference", "InvalidReference", "ResolutionFailed", "CycleDetected", "MissingCwlDescription", "UnexpectedRuntimeType"]


GraphIssueKind_reflection = _expr1321

def _expr1322() -> TypeInfo:
    return record_type("ARCtrl.WorkflowGraph.GraphBuildIssue", [], GraphBuildIssue, lambda: [("Kind", GraphIssueKind_reflection()), ("Message", string_type), ("Scope", option_type(string_type)), ("Reference", option_type(string_type))])


@dataclass(eq = False, repr = False, slots = True)
class GraphBuildIssue(Record):
    Kind: GraphIssueKind
    Message: str
    Scope: str | None
    Reference: str | None

GraphBuildIssue_reflection = _expr1322

def GraphBuildIssue_create_Z2F3B511A(kind: GraphIssueKind, message: str, scope: str | None=None, reference: str | None=None) -> GraphBuildIssue:
    return GraphBuildIssue(kind, message, scope, reference)


def _expr1323() -> TypeInfo:
    return record_type("ARCtrl.WorkflowGraph.WorkflowGraphNode", [], WorkflowGraphNode, lambda: [("Id", string_type), ("Kind", NodeKind_reflection()), ("Label", string_type), ("OwnerNodeId", option_type(string_type)), ("Reference", option_type(string_type)), ("Metadata", option_type(DynamicObj_reflection()))])


@dataclass(eq = False, repr = False, slots = True)
class WorkflowGraphNode(Record):
    Id: str
    Kind: NodeKind
    Label: str
    OwnerNodeId: str | None
    Reference: str | None
    Metadata: DynamicObj | None

WorkflowGraphNode_reflection = _expr1323

def WorkflowGraphNode_create_62C775C0(id: str, kind: NodeKind, label: str, owner_node_id: str | None=None, reference: str | None=None, metadata: DynamicObj | None=None) -> WorkflowGraphNode:
    return WorkflowGraphNode(id, kind, label, owner_node_id, reference, metadata)


def _expr1324() -> TypeInfo:
    return record_type("ARCtrl.WorkflowGraph.WorkflowGraphEdge", [], WorkflowGraphEdge, lambda: [("Id", string_type), ("SourceNodeId", string_type), ("TargetNodeId", string_type), ("Kind", EdgeKind_reflection()), ("Label", option_type(string_type))])


@dataclass(eq = False, repr = False, slots = True)
class WorkflowGraphEdge(Record):
    Id: str
    SourceNodeId: str
    TargetNodeId: str
    Kind: EdgeKind
    Label: str | None

WorkflowGraphEdge_reflection = _expr1324

def WorkflowGraphEdge_create_5E4B5E48(id: str, source_node_id: str, target_node_id: str, kind: EdgeKind, label: str | None=None) -> WorkflowGraphEdge:
    return WorkflowGraphEdge(id, source_node_id, target_node_id, kind, label)


def _expr1325() -> TypeInfo:
    return record_type("ARCtrl.WorkflowGraph.WorkflowGraph", [], WorkflowGraph, lambda: [("RootProcessingUnitNodeId", string_type), ("Nodes", array_type(WorkflowGraphNode_reflection())), ("Edges", array_type(WorkflowGraphEdge_reflection())), ("Diagnostics", array_type(GraphBuildIssue_reflection()))])


@dataclass(eq = False, repr = False, slots = True)
class WorkflowGraph(Record):
    RootProcessingUnitNodeId: str
    Nodes: Array[WorkflowGraphNode]
    Edges: Array[WorkflowGraphEdge]
    Diagnostics: Array[GraphBuildIssue]

WorkflowGraph_reflection = _expr1325

def WorkflowGraph_create_4D231A1(root_processing_unit_node_id: str, nodes: Array[WorkflowGraphNode] | None=None, edges: Array[WorkflowGraphEdge] | None=None, diagnostics: Array[GraphBuildIssue] | None=None) -> WorkflowGraph:
    return WorkflowGraph(root_processing_unit_node_id, default_arg(nodes, []), default_arg(edges, []), default_arg(diagnostics, []))


def WorkflowGraph__get_NodeCount(this: WorkflowGraph) -> int:
    return len(this.Nodes)


def WorkflowGraph__get_EdgeCount(this: WorkflowGraph) -> int:
    return len(this.Edges)


def _expr1326() -> TypeInfo:
    return record_type("ARCtrl.WorkflowGraph.WorkflowGraphIndex", [], WorkflowGraphIndex, lambda: [("WorkflowGraphs", array_type(tuple_type(string_type, union_type("Microsoft.FSharp.Core.FSharpResult`2", [WorkflowGraph_reflection(), GraphBuildIssue_reflection()], FSharpResult_2, lambda: [[("ResultValue", WorkflowGraph_reflection())], [("ErrorValue", GraphBuildIssue_reflection())]])))), ("RunGraphs", array_type(tuple_type(string_type, union_type("Microsoft.FSharp.Core.FSharpResult`2", [WorkflowGraph_reflection(), GraphBuildIssue_reflection()], FSharpResult_2, lambda: [[("ResultValue", WorkflowGraph_reflection())], [("ErrorValue", GraphBuildIssue_reflection())]]))))])


@dataclass(eq = False, repr = False, slots = True)
class WorkflowGraphIndex(Record):
    WorkflowGraphs: Array[tuple[str, FSharpResult_2[WorkflowGraph, GraphBuildIssue]]]
    RunGraphs: Array[tuple[str, FSharpResult_2[WorkflowGraph, GraphBuildIssue]]]

WorkflowGraphIndex_reflection = _expr1326

def WorkflowGraphIndex_create_56E060E0(workflow_graphs: Array[tuple[str, FSharpResult_2[WorkflowGraph, GraphBuildIssue]]] | None=None, run_graphs: Array[tuple[str, FSharpResult_2[WorkflowGraph, GraphBuildIssue]]] | None=None) -> WorkflowGraphIndex:
    return WorkflowGraphIndex(default_arg(workflow_graphs, []), default_arg(run_graphs, []))


def EdgeKindModule_asKey(kind: EdgeKind) -> str:
    if kind.tag == 1:
        return "calls"

    elif kind.tag == 2:
        return "binds_workflow_input"

    elif kind.tag == 3:
        return "dataflow"

    elif kind.tag == 4:
        return "binds_workflow_output"

    else: 
        return "contains"



def PortDirectionModule_asKey(direction: PortDirection) -> str:
    if direction.tag == 1:
        return "out"

    else: 
        return "in"



def GraphId_normalizeSegment(value: str) -> str:
    if is_null_or_white_space(value):
        return ""

    else: 
        return normalize_path_key(value.strip())



def GraphId_childScope(scope: str, child: str) -> str:
    normalized_scope: str = GraphId_normalizeSegment(scope)
    normalized_child: str = GraphId_normalizeSegment(child)
    if is_null_or_white_space(normalized_scope):
        return normalized_child

    elif is_null_or_white_space(normalized_child):
        return normalized_scope

    else: 
        return normalize_path_key(combine(normalized_scope, normalized_child))



def GraphId_unitNodeId(scope: str) -> str:
    return ("unit:" + GraphId_normalizeSegment(scope)) + ""


def GraphId_stepNodeId(scope: str, step_id: str) -> str:
    normalized_step_id: str = GraphId_normalizeSegment(step_id)
    return ((("step:" + GraphId_normalizeSegment(scope)) + "/") + normalized_step_id) + ""


def GraphId_portNodeId(owner_node_id: str, direction: PortDirection, port_id: str) -> str:
    normalized_port_id: str = GraphId_normalizeSegment(port_id)
    return ((((("port:" + owner_node_id) + "/") + PortDirectionModule_asKey(direction)) + "/") + normalized_port_id) + ""


def GraphId_edgeId(kind: EdgeKind, source_node_id: str, target_node_id: str) -> str:
    return ((((("edge:" + EdgeKindModule_asKey(kind)) + ":") + source_node_id) + "->") + target_node_id) + ""


__all__ = ["ProcessingUnitKind_reflection", "PortDirection_reflection", "NodeKind_reflection", "EdgeKind_reflection", "GraphIssueKind_reflection", "GraphBuildIssue_reflection", "GraphBuildIssue_create_Z2F3B511A", "WorkflowGraphNode_reflection", "WorkflowGraphNode_create_62C775C0", "WorkflowGraphEdge_reflection", "WorkflowGraphEdge_create_5E4B5E48", "WorkflowGraph_reflection", "WorkflowGraph_create_4D231A1", "WorkflowGraph__get_NodeCount", "WorkflowGraph__get_EdgeCount", "WorkflowGraphIndex_reflection", "WorkflowGraphIndex_create_56E060E0", "EdgeKindModule_asKey", "PortDirectionModule_asKey", "GraphId_normalizeSegment", "GraphId_childScope", "GraphId_unitNodeId", "GraphId_stepNodeId", "GraphId_portNodeId", "GraphId_edgeId"]

