from __future__ import annotations
from collections.abc import Callable
from ..fable_modules.fable_library.list import FSharpList
from ..fable_modules.fable_library.result import FSharpResult_2
from ..fable_modules.siren.siren_types import SirenElement
from ..Core.arc_types import (ArcWorkflow, ArcRun, ArcInvestigation)
from ..CWL.cwlprocessing_unit import CWLProcessingUnit
from .adapters import (of_workflow as of_workflow_1, of_run as of_run_1, of_investigation as of_investigation_1)
from .builder import (build as build_1, build_with as build_with_1)
from .build_options import WorkflowGraphBuildOptions
from .graph_types import (WorkflowGraph, GraphBuildIssue, WorkflowGraphIndex, WorkflowGraphNode, NodeKind, WorkflowGraphEdge, EdgeKind)
from .query_helpers import (try_find_node as try_find_node_1, get_nodes as get_nodes_1, get_edges_from as get_edges_from_1, get_edges_to as get_edges_to_1, get_edges_by_kind as get_edges_by_kind_1, get_input_ports as get_input_ports_1, get_output_ports as get_output_ports_1)
from .visualization_siren import (WorkflowGraphSiren_fromGraph, WorkflowGraphSiren_toMermaid, WorkflowGraphSiren_toMarkdown, WorkflowGraphSiren_fromProcessingUnit, WorkflowGraphSiren_fromProcessingUnitResolved)

build: Callable[[CWLProcessingUnit], WorkflowGraph] = build_1

def _arrow1390(options: WorkflowGraphBuildOptions) -> Callable[[CWLProcessingUnit], WorkflowGraph]:
    def _arrow1389(processing_unit: CWLProcessingUnit) -> WorkflowGraph:
        return build_with_1(options, processing_unit)

    return _arrow1389


build_with: Callable[[WorkflowGraphBuildOptions, CWLProcessingUnit], WorkflowGraph] = _arrow1390

of_workflow: Callable[[ArcWorkflow], FSharpResult_2[WorkflowGraph, GraphBuildIssue]] = of_workflow_1

of_run: Callable[[ArcRun], FSharpResult_2[WorkflowGraph, GraphBuildIssue]] = of_run_1

of_investigation: Callable[[ArcInvestigation], WorkflowGraphIndex] = of_investigation_1

def _arrow1392(node_id: str) -> Callable[[WorkflowGraph], WorkflowGraphNode | None]:
    def _arrow1391(graph: WorkflowGraph) -> WorkflowGraphNode | None:
        return try_find_node_1(node_id, graph)

    return _arrow1391


try_find_node: Callable[[str, WorkflowGraph], WorkflowGraphNode | None] = _arrow1392

def _arrow1394(kind: NodeKind) -> Callable[[WorkflowGraph], FSharpList[WorkflowGraphNode]]:
    def _arrow1393(graph: WorkflowGraph) -> FSharpList[WorkflowGraphNode]:
        return get_nodes_1(kind, graph)

    return _arrow1393


get_nodes: Callable[[NodeKind, WorkflowGraph], FSharpList[WorkflowGraphNode]] = _arrow1394

def _arrow1396(node_id: str) -> Callable[[WorkflowGraph], FSharpList[WorkflowGraphEdge]]:
    def _arrow1395(graph: WorkflowGraph) -> FSharpList[WorkflowGraphEdge]:
        return get_edges_from_1(node_id, graph)

    return _arrow1395


get_edges_from: Callable[[str, WorkflowGraph], FSharpList[WorkflowGraphEdge]] = _arrow1396

def _arrow1398(node_id: str) -> Callable[[WorkflowGraph], FSharpList[WorkflowGraphEdge]]:
    def _arrow1397(graph: WorkflowGraph) -> FSharpList[WorkflowGraphEdge]:
        return get_edges_to_1(node_id, graph)

    return _arrow1397


get_edges_to: Callable[[str, WorkflowGraph], FSharpList[WorkflowGraphEdge]] = _arrow1398

def _arrow1400(kind: EdgeKind) -> Callable[[WorkflowGraph], FSharpList[WorkflowGraphEdge]]:
    def _arrow1399(graph: WorkflowGraph) -> FSharpList[WorkflowGraphEdge]:
        return get_edges_by_kind_1(kind, graph)

    return _arrow1399


get_edges_by_kind: Callable[[EdgeKind, WorkflowGraph], FSharpList[WorkflowGraphEdge]] = _arrow1400

def _arrow1402(owner_node_id: str) -> Callable[[WorkflowGraph], FSharpList[WorkflowGraphNode]]:
    def _arrow1401(graph: WorkflowGraph) -> FSharpList[WorkflowGraphNode]:
        return get_input_ports_1(owner_node_id, graph)

    return _arrow1401


get_input_ports: Callable[[str, WorkflowGraph], FSharpList[WorkflowGraphNode]] = _arrow1402

def _arrow1404(owner_node_id: str) -> Callable[[WorkflowGraph], FSharpList[WorkflowGraphNode]]:
    def _arrow1403(graph: WorkflowGraph) -> FSharpList[WorkflowGraphNode]:
        return get_output_ports_1(owner_node_id, graph)

    return _arrow1403


get_output_ports: Callable[[str, WorkflowGraph], FSharpList[WorkflowGraphNode]] = _arrow1404

from_graph_to_siren: Callable[[WorkflowGraph], SirenElement] = WorkflowGraphSiren_fromGraph

to_mermaid: Callable[[WorkflowGraph], str] = WorkflowGraphSiren_toMermaid

to_markdown: Callable[[WorkflowGraph], str] = WorkflowGraphSiren_toMarkdown

from_processing_unit_to_siren: Callable[[CWLProcessingUnit], SirenElement] = WorkflowGraphSiren_fromProcessingUnit

def _arrow1408(build_options: WorkflowGraphBuildOptions) -> Callable[[CWLProcessingUnit], SirenElement]:
    def _arrow1407(processing_unit: CWLProcessingUnit) -> SirenElement:
        return WorkflowGraphSiren_fromProcessingUnitResolved(build_options, processing_unit)

    return _arrow1407


from_processing_unit_to_siren_resolved: Callable[[WorkflowGraphBuildOptions, CWLProcessingUnit], SirenElement] = _arrow1408

from_arc_workflow: Callable[[ArcWorkflow], FSharpResult_2[WorkflowGraph, GraphBuildIssue]] = of_workflow

from_arc_run: Callable[[ArcRun], FSharpResult_2[WorkflowGraph, GraphBuildIssue]] = of_run

from_arc_investigation: Callable[[ArcInvestigation], WorkflowGraphIndex] = of_investigation

__all__ = ["build", "build_with", "of_workflow", "of_run", "of_investigation", "try_find_node", "get_nodes", "get_edges_from", "get_edges_to", "get_edges_by_kind", "get_input_ports", "get_output_ports", "from_graph_to_siren", "to_mermaid", "to_markdown", "from_processing_unit_to_siren", "from_processing_unit_to_siren_resolved", "from_arc_workflow", "from_arc_run", "from_arc_investigation"]

