
def is_string(s: str) -> bool:
    return isinstance(s, str)


__all__ = ["is_string"]

