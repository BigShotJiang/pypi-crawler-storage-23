from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from ..fable_library.int32 import parse
from ..fable_library.list import (reverse, empty, of_array_with_tail, cons, is_empty, head, tail, FSharpList, to_array, of_array, append, of_seq, singleton, collect)
from ..fable_library.reflection import (TypeInfo, int32_type, string_type, class_type, record_type, union_type)
from ..fable_library.reg_exp import (match, create, get_item, groups)
from ..fable_library.string_ import (to_text, printf, starts_with_exact, trim_end, join)
from ..fable_library.types import (Record, Array, Union)
from .regex import (FlowStyleObjectPattern, FlowStyleArrayPattern, FlowStyleObjectOpenerPattern, FlowStyleObjectCloserPattern)
from .yamlicious_types import PreprocessorElement

def _expr586() -> TypeInfo:
    return record_type("YAMLicious.FlowToBlock.TransformContext", [], TransformContext, lambda: [("BaseIndent", int32_type), ("IndentStep", int32_type), ("StringDict", class_type("System.Collections.Generic.Dictionary`2", [int32_type, string_type]))])


@dataclass(eq = False, repr = False, slots = True)
class TransformContext(Record):
    BaseIndent: int
    IndentStep: int
    StringDict: Any

TransformContext_reflection = _expr586

def default_context(string_dict: Any) -> TransformContext:
    return TransformContext(0, 2, string_dict)


def _expr587() -> TypeInfo:
    return union_type("YAMLicious.FlowToBlock.Token", [], Token, lambda: [[], [], [], [], [], [], [("Item", string_type)], []])


class Token(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["OpenBrace", "CloseBrace", "OpenBracket", "CloseBracket", "Colon", "Comma", "String", "EOF"]


Token_reflection = _expr587

def tokenize(input: str) -> FSharpList[Token]:
    def parse_string(chars_mut: FSharpList[str], acc_mut: FSharpList[str], input: Any=input) -> tuple[FSharpList[str], FSharpList[str]]:
        while True:
            (chars, acc) = (chars_mut, acc_mut)
            (pattern_matching_result, rest, c, rest_1, c_1, rest_2) = (None, None, None, None, None, None)
            if not is_empty(chars):
                if head(chars) == "\"":
                    pattern_matching_result = 1
                    rest = tail(chars)

                elif head(chars) == "\\":
                    if not is_empty(tail(chars)):
                        pattern_matching_result = 2
                        c = head(tail(chars))
                        rest_1 = tail(tail(chars))

                    else: 
                        pattern_matching_result = 3
                        c_1 = head(chars)
                        rest_2 = tail(chars)


                else: 
                    pattern_matching_result = 3
                    c_1 = head(chars)
                    rest_2 = tail(chars)


            else: 
                pattern_matching_result = 0

            if pattern_matching_result == 0:
                return (reverse(acc), empty())

            elif pattern_matching_result == 1:
                return (reverse(acc), rest)

            elif pattern_matching_result == 2:
                chars_mut = rest_1
                acc_mut = of_array_with_tail([c, "\\"], acc)
                continue

            elif pattern_matching_result == 3:
                chars_mut = rest_2
                acc_mut = cons(c_1, acc)
                continue

            break

    def tokenize_chars(chars_1_mut: FSharpList[str], acc_1_mut: FSharpList[Token], input: Any=input) -> FSharpList[Token]:
        while True:
            (chars_1, acc_1) = (chars_1_mut, acc_1_mut)
            (pattern_matching_result_1, rest_3, rest_4, rest_5, rest_6, rest_7, rest_8, rest_9, rest_10, chars_2) = (None, None, None, None, None, None, None, None, None, None)
            if not is_empty(chars_1):
                if head(chars_1) == "\t":
                    pattern_matching_result_1 = 1
                    rest_3 = tail(chars_1)

                elif head(chars_1) == "\n":
                    pattern_matching_result_1 = 1
                    rest_3 = tail(chars_1)

                elif head(chars_1) == "\r":
                    pattern_matching_result_1 = 1
                    rest_3 = tail(chars_1)

                elif head(chars_1) == " ":
                    pattern_matching_result_1 = 1
                    rest_3 = tail(chars_1)

                elif head(chars_1) == "\"":
                    pattern_matching_result_1 = 8
                    rest_10 = tail(chars_1)

                elif head(chars_1) == ",":
                    pattern_matching_result_1 = 7
                    rest_9 = tail(chars_1)

                elif head(chars_1) == ":":
                    pattern_matching_result_1 = 6
                    rest_8 = tail(chars_1)

                elif head(chars_1) == "[":
                    pattern_matching_result_1 = 4
                    rest_6 = tail(chars_1)

                elif head(chars_1) == "]":
                    pattern_matching_result_1 = 5
                    rest_7 = tail(chars_1)

                elif head(chars_1) == "{":
                    pattern_matching_result_1 = 2
                    rest_4 = tail(chars_1)

                elif head(chars_1) == "}":
                    pattern_matching_result_1 = 3
                    rest_5 = tail(chars_1)

                else: 
                    pattern_matching_result_1 = 9
                    chars_2 = chars_1


            else: 
                pattern_matching_result_1 = 0

            if pattern_matching_result_1 == 0:
                return reverse(cons(Token(7), acc_1))

            elif pattern_matching_result_1 == 1:
                chars_1_mut = rest_3
                acc_1_mut = acc_1
                continue

            elif pattern_matching_result_1 == 2:
                chars_1_mut = rest_4
                acc_1_mut = cons(Token(0), acc_1)
                continue

            elif pattern_matching_result_1 == 3:
                chars_1_mut = rest_5
                acc_1_mut = cons(Token(1), acc_1)
                continue

            elif pattern_matching_result_1 == 4:
                chars_1_mut = rest_6
                acc_1_mut = cons(Token(2), acc_1)
                continue

            elif pattern_matching_result_1 == 5:
                chars_1_mut = rest_7
                acc_1_mut = cons(Token(3), acc_1)
                continue

            elif pattern_matching_result_1 == 6:
                chars_1_mut = rest_8
                acc_1_mut = cons(Token(4), acc_1)
                continue

            elif pattern_matching_result_1 == 7:
                chars_1_mut = rest_9
                acc_1_mut = cons(Token(5), acc_1)
                continue

            elif pattern_matching_result_1 == 8:
                pattern_input: tuple[FSharpList[str], FSharpList[str]] = parse_string(rest_10, empty())
                chars_1_mut = pattern_input[1]
                acc_1_mut = cons(Token(6, ''.join(to_array(pattern_input[0]))), acc_1)
                continue

            elif pattern_matching_result_1 == 9:
                def consume_placeholder(cs: FSharpList[str], acc_2: FSharpList[str], chars_1: Any=chars_1, acc_1: Any=acc_1) -> tuple[FSharpList[str], FSharpList[str]]:
                    def loop(cs_1_mut: FSharpList[str], acc_3_mut: FSharpList[str], cs: Any=cs, acc_2: Any=acc_2) -> tuple[FSharpList[str], FSharpList[str]]:
                        while True:
                            (cs_1, acc_3) = (cs_1_mut, acc_3_mut)
                            (pattern_matching_result_2, rest_11, c_2, rest_12) = (None, None, None, None)
                            if is_empty(cs_1):
                                pattern_matching_result_2 = 2

                            elif head(cs_1) == "/":
                                if not is_empty(tail(cs_1)):
                                    if head(tail(cs_1)) == ">":
                                        pattern_matching_result_2 = 0
                                        rest_11 = tail(tail(cs_1))

                                    else: 
                                        pattern_matching_result_2 = 1
                                        c_2 = head(cs_1)
                                        rest_12 = tail(cs_1)


                                else: 
                                    pattern_matching_result_2 = 1
                                    c_2 = head(cs_1)
                                    rest_12 = tail(cs_1)


                            else: 
                                pattern_matching_result_2 = 1
                                c_2 = head(cs_1)
                                rest_12 = tail(cs_1)

                            if pattern_matching_result_2 == 0:
                                return (reverse(of_array_with_tail([">", "/"], acc_3)), rest_11)

                            elif pattern_matching_result_2 == 1:
                                cs_1_mut = rest_12
                                acc_3_mut = cons(c_2, acc_3)
                                continue

                            elif pattern_matching_result_2 == 2:
                                return (reverse(acc_3), empty())

                            break

                    return loop(cs, acc_2)

                consume_placeholder: Callable[[FSharpList[str], FSharpList[str]], tuple[FSharpList[str], FSharpList[str]]] = consume_placeholder
                def parse_unquoted(cs_2_mut: FSharpList[str], acc_4_mut: FSharpList[str], chars_1: Any=chars_1, acc_1: Any=acc_1) -> tuple[FSharpList[str], FSharpList[str]]:
                    while True:
                        (cs_2, acc_4) = (cs_2_mut, acc_4_mut)
                        (pattern_matching_result_3, rest_30, rest_31, rest_33, c_20, rest_34) = (None, None, None, None, None, None)
                        if not is_empty(cs_2):
                            if head(cs_2) == " ":
                                def _arrow588(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                    c_3: str = head(cs_2)
                                    return True if (True if (True if (True if (True if (True if (True if (True if (c_3 == "{") else (c_3 == "}")) else (c_3 == "[")) else (c_3 == "]")) else (c_3 == ":")) else (c_3 == ",")) else (c_3 == "\n")) else (c_3 == "\r")) else (c_3 == "\t")

                                if _arrow588():
                                    pattern_matching_result_3 = 3

                                elif is_empty(acc_4):
                                    pattern_matching_result_3 = 4
                                    rest_33 = tail(cs_2)

                                else: 
                                    pattern_matching_result_3 = 5
                                    c_20 = head(cs_2)
                                    rest_34 = tail(cs_2)


                            elif head(cs_2) == "<":
                                if not is_empty(tail(cs_2)):
                                    if head(tail(cs_2)) == "c":
                                        if not is_empty(tail(tail(cs_2))):
                                            if head(tail(tail(cs_2))) == " ":
                                                if not is_empty(tail(tail(tail(cs_2)))):
                                                    if head(tail(tail(tail(cs_2)))) == "f":
                                                        if not is_empty(tail(tail(tail(tail(cs_2))))):
                                                            if head(tail(tail(tail(tail(cs_2))))) == "=":
                                                                pattern_matching_result_3 = 2
                                                                rest_31 = tail(tail(tail(tail(tail(cs_2)))))

                                                            else: 
                                                                def _arrow589(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                                    c_4: str = head(cs_2)
                                                                    return True if (True if (True if (True if (True if (True if (True if (True if (c_4 == "{") else (c_4 == "}")) else (c_4 == "[")) else (c_4 == "]")) else (c_4 == ":")) else (c_4 == ",")) else (c_4 == "\n")) else (c_4 == "\r")) else (c_4 == "\t")

                                                                if _arrow589():
                                                                    pattern_matching_result_3 = 3

                                                                else: 
                                                                    pattern_matching_result_3 = 5
                                                                    c_20 = head(cs_2)
                                                                    rest_34 = tail(cs_2)



                                                        else: 
                                                            def _arrow590(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                                c_5: str = head(cs_2)
                                                                return True if (True if (True if (True if (True if (True if (True if (True if (c_5 == "{") else (c_5 == "}")) else (c_5 == "[")) else (c_5 == "]")) else (c_5 == ":")) else (c_5 == ",")) else (c_5 == "\n")) else (c_5 == "\r")) else (c_5 == "\t")

                                                            if _arrow590():
                                                                pattern_matching_result_3 = 3

                                                            else: 
                                                                pattern_matching_result_3 = 5
                                                                c_20 = head(cs_2)
                                                                rest_34 = tail(cs_2)



                                                    else: 
                                                        def _arrow591(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                            c_6: str = head(cs_2)
                                                            return True if (True if (True if (True if (True if (True if (True if (True if (c_6 == "{") else (c_6 == "}")) else (c_6 == "[")) else (c_6 == "]")) else (c_6 == ":")) else (c_6 == ",")) else (c_6 == "\n")) else (c_6 == "\r")) else (c_6 == "\t")

                                                        if _arrow591():
                                                            pattern_matching_result_3 = 3

                                                        else: 
                                                            pattern_matching_result_3 = 5
                                                            c_20 = head(cs_2)
                                                            rest_34 = tail(cs_2)



                                                else: 
                                                    def _arrow592(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                        c_7: str = head(cs_2)
                                                        return True if (True if (True if (True if (True if (True if (True if (True if (c_7 == "{") else (c_7 == "}")) else (c_7 == "[")) else (c_7 == "]")) else (c_7 == ":")) else (c_7 == ",")) else (c_7 == "\n")) else (c_7 == "\r")) else (c_7 == "\t")

                                                    if _arrow592():
                                                        pattern_matching_result_3 = 3

                                                    else: 
                                                        pattern_matching_result_3 = 5
                                                        c_20 = head(cs_2)
                                                        rest_34 = tail(cs_2)



                                            else: 
                                                def _arrow593(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                    c_8: str = head(cs_2)
                                                    return True if (True if (True if (True if (True if (True if (True if (True if (c_8 == "{") else (c_8 == "}")) else (c_8 == "[")) else (c_8 == "]")) else (c_8 == ":")) else (c_8 == ",")) else (c_8 == "\n")) else (c_8 == "\r")) else (c_8 == "\t")

                                                if _arrow593():
                                                    pattern_matching_result_3 = 3

                                                else: 
                                                    pattern_matching_result_3 = 5
                                                    c_20 = head(cs_2)
                                                    rest_34 = tail(cs_2)



                                        else: 
                                            def _arrow594(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                c_9: str = head(cs_2)
                                                return True if (True if (True if (True if (True if (True if (True if (True if (c_9 == "{") else (c_9 == "}")) else (c_9 == "[")) else (c_9 == "]")) else (c_9 == ":")) else (c_9 == ",")) else (c_9 == "\n")) else (c_9 == "\r")) else (c_9 == "\t")

                                            if _arrow594():
                                                pattern_matching_result_3 = 3

                                            else: 
                                                pattern_matching_result_3 = 5
                                                c_20 = head(cs_2)
                                                rest_34 = tail(cs_2)



                                    elif head(tail(cs_2)) == "s":
                                        if not is_empty(tail(tail(cs_2))):
                                            if head(tail(tail(cs_2))) == " ":
                                                if not is_empty(tail(tail(tail(cs_2)))):
                                                    if head(tail(tail(tail(cs_2)))) == "f":
                                                        if not is_empty(tail(tail(tail(tail(cs_2))))):
                                                            if head(tail(tail(tail(tail(cs_2))))) == "=":
                                                                pattern_matching_result_3 = 1
                                                                rest_30 = tail(tail(tail(tail(tail(cs_2)))))

                                                            else: 
                                                                def _arrow595(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                                    c_10: str = head(cs_2)
                                                                    return True if (True if (True if (True if (True if (True if (True if (True if (c_10 == "{") else (c_10 == "}")) else (c_10 == "[")) else (c_10 == "]")) else (c_10 == ":")) else (c_10 == ",")) else (c_10 == "\n")) else (c_10 == "\r")) else (c_10 == "\t")

                                                                if _arrow595():
                                                                    pattern_matching_result_3 = 3

                                                                else: 
                                                                    pattern_matching_result_3 = 5
                                                                    c_20 = head(cs_2)
                                                                    rest_34 = tail(cs_2)



                                                        else: 
                                                            def _arrow596(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                                c_11: str = head(cs_2)
                                                                return True if (True if (True if (True if (True if (True if (True if (True if (c_11 == "{") else (c_11 == "}")) else (c_11 == "[")) else (c_11 == "]")) else (c_11 == ":")) else (c_11 == ",")) else (c_11 == "\n")) else (c_11 == "\r")) else (c_11 == "\t")

                                                            if _arrow596():
                                                                pattern_matching_result_3 = 3

                                                            else: 
                                                                pattern_matching_result_3 = 5
                                                                c_20 = head(cs_2)
                                                                rest_34 = tail(cs_2)



                                                    else: 
                                                        def _arrow597(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                            c_12: str = head(cs_2)
                                                            return True if (True if (True if (True if (True if (True if (True if (True if (c_12 == "{") else (c_12 == "}")) else (c_12 == "[")) else (c_12 == "]")) else (c_12 == ":")) else (c_12 == ",")) else (c_12 == "\n")) else (c_12 == "\r")) else (c_12 == "\t")

                                                        if _arrow597():
                                                            pattern_matching_result_3 = 3

                                                        else: 
                                                            pattern_matching_result_3 = 5
                                                            c_20 = head(cs_2)
                                                            rest_34 = tail(cs_2)



                                                else: 
                                                    def _arrow598(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                        c_13: str = head(cs_2)
                                                        return True if (True if (True if (True if (True if (True if (True if (True if (c_13 == "{") else (c_13 == "}")) else (c_13 == "[")) else (c_13 == "]")) else (c_13 == ":")) else (c_13 == ",")) else (c_13 == "\n")) else (c_13 == "\r")) else (c_13 == "\t")

                                                    if _arrow598():
                                                        pattern_matching_result_3 = 3

                                                    else: 
                                                        pattern_matching_result_3 = 5
                                                        c_20 = head(cs_2)
                                                        rest_34 = tail(cs_2)



                                            else: 
                                                def _arrow599(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                    c_14: str = head(cs_2)
                                                    return True if (True if (True if (True if (True if (True if (True if (True if (c_14 == "{") else (c_14 == "}")) else (c_14 == "[")) else (c_14 == "]")) else (c_14 == ":")) else (c_14 == ",")) else (c_14 == "\n")) else (c_14 == "\r")) else (c_14 == "\t")

                                                if _arrow599():
                                                    pattern_matching_result_3 = 3

                                                else: 
                                                    pattern_matching_result_3 = 5
                                                    c_20 = head(cs_2)
                                                    rest_34 = tail(cs_2)



                                        else: 
                                            def _arrow600(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                                c_15: str = head(cs_2)
                                                return True if (True if (True if (True if (True if (True if (True if (True if (c_15 == "{") else (c_15 == "}")) else (c_15 == "[")) else (c_15 == "]")) else (c_15 == ":")) else (c_15 == ",")) else (c_15 == "\n")) else (c_15 == "\r")) else (c_15 == "\t")

                                            if _arrow600():
                                                pattern_matching_result_3 = 3

                                            else: 
                                                pattern_matching_result_3 = 5
                                                c_20 = head(cs_2)
                                                rest_34 = tail(cs_2)



                                    else: 
                                        def _arrow601(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                            c_16: str = head(cs_2)
                                            return True if (True if (True if (True if (True if (True if (True if (True if (c_16 == "{") else (c_16 == "}")) else (c_16 == "[")) else (c_16 == "]")) else (c_16 == ":")) else (c_16 == ",")) else (c_16 == "\n")) else (c_16 == "\r")) else (c_16 == "\t")

                                        if _arrow601():
                                            pattern_matching_result_3 = 3

                                        else: 
                                            pattern_matching_result_3 = 5
                                            c_20 = head(cs_2)
                                            rest_34 = tail(cs_2)



                                else: 
                                    def _arrow602(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                        c_17: str = head(cs_2)
                                        return True if (True if (True if (True if (True if (True if (True if (True if (c_17 == "{") else (c_17 == "}")) else (c_17 == "[")) else (c_17 == "]")) else (c_17 == ":")) else (c_17 == ",")) else (c_17 == "\n")) else (c_17 == "\r")) else (c_17 == "\t")

                                    if _arrow602():
                                        pattern_matching_result_3 = 3

                                    else: 
                                        pattern_matching_result_3 = 5
                                        c_20 = head(cs_2)
                                        rest_34 = tail(cs_2)



                            else: 
                                def _arrow603(__unit: None=None, cs_2: Any=cs_2, acc_4: Any=acc_4) -> bool:
                                    c_18: str = head(cs_2)
                                    return True if (True if (True if (True if (True if (True if (True if (True if (c_18 == "{") else (c_18 == "}")) else (c_18 == "[")) else (c_18 == "]")) else (c_18 == ":")) else (c_18 == ",")) else (c_18 == "\n")) else (c_18 == "\r")) else (c_18 == "\t")

                                if _arrow603():
                                    pattern_matching_result_3 = 3

                                else: 
                                    pattern_matching_result_3 = 5
                                    c_20 = head(cs_2)
                                    rest_34 = tail(cs_2)



                        else: 
                            pattern_matching_result_3 = 0

                        if pattern_matching_result_3 == 0:
                            return (reverse(acc_4), empty())

                        elif pattern_matching_result_3 == 1:
                            pattern_input_1: tuple[FSharpList[str], FSharpList[str]] = consume_placeholder(rest_30, of_array(["=", "f", " ", "s", "<"]))
                            pattern_input_2: tuple[FSharpList[str], FSharpList[str]] = parse_unquoted(pattern_input_1[1], empty())
                            return (append(pattern_input_1[0], pattern_input_2[0]), pattern_input_2[1])

                        elif pattern_matching_result_3 == 2:
                            pattern_input_3: tuple[FSharpList[str], FSharpList[str]] = consume_placeholder(rest_31, of_array(["=", "f", " ", "c", "<"]))
                            pattern_input_4: tuple[FSharpList[str], FSharpList[str]] = parse_unquoted(pattern_input_3[1], empty())
                            return (append(pattern_input_3[0], pattern_input_4[0]), pattern_input_4[1])

                        elif pattern_matching_result_3 == 3:
                            return (reverse(acc_4), cs_2)

                        elif pattern_matching_result_3 == 4:
                            cs_2_mut = rest_33
                            acc_4_mut = acc_4
                            continue

                        elif pattern_matching_result_3 == 5:
                            cs_2_mut = rest_34
                            acc_4_mut = cons(c_20, acc_4)
                            continue

                        break

                parse_unquoted: Callable[[FSharpList[str], FSharpList[str]], tuple[FSharpList[str], FSharpList[str]]] = parse_unquoted
                pattern_input_5: tuple[FSharpList[str], FSharpList[str]] = parse_unquoted(chars_2, empty())
                str_2: FSharpList[str] = pattern_input_5[0]
                remaining_3: FSharpList[str] = pattern_input_5[1]
                if is_empty(str_2):
                    chars_1_mut = remaining_3
                    acc_1_mut = acc_1
                    continue

                else: 
                    chars_1_mut = remaining_3
                    acc_1_mut = cons(Token(6, ''.join(to_array(str_2))), acc_1)
                    continue


            break

    return tokenize_chars(of_seq(input), empty())


def tokens_to_block_elements(ctx: TransformContext, tokens: FSharpList[Token]) -> tuple[FSharpList[PreprocessorElement], FSharpList[Token]]:
    (pattern_matching_result, rest, rest_1, key, rest_2, rest_3, s) = (None, None, None, None, None, None, None)
    if not is_empty(tokens):
        if head(tokens).tag == 0:
            pattern_matching_result = 0
            rest = tail(tokens)

        elif head(tokens).tag == 2:
            pattern_matching_result = 1
            rest_1 = tail(tokens)

        elif head(tokens).tag == 6:
            if not is_empty(tail(tokens)):
                if head(tail(tokens)).tag == 4:
                    pattern_matching_result = 2
                    key = head(tokens).fields[0]
                    rest_2 = tail(tail(tokens))

                else: 
                    pattern_matching_result = 3
                    rest_3 = tail(tokens)
                    s = head(tokens).fields[0]


            else: 
                pattern_matching_result = 3
                rest_3 = tail(tokens)
                s = head(tokens).fields[0]


        elif head(tokens).tag == 7:
            pattern_matching_result = 4

        else: 
            pattern_matching_result = 5


    else: 
        pattern_matching_result = 5

    if pattern_matching_result == 0:
        return object_to_block_elements(ctx, rest)

    elif pattern_matching_result == 1:
        return array_to_block_elements(ctx, rest_1)

    elif pattern_matching_result == 2:
        child_ctx: TransformContext = TransformContext(ctx.BaseIndent + ctx.IndentStep, ctx.IndentStep, ctx.StringDict)
        (pattern_matching_result_1,) = (None,)
        if not is_empty(rest_2):
            if head(rest_2).tag == 0:
                pattern_matching_result_1 = 0

            elif head(rest_2).tag == 2:
                pattern_matching_result_1 = 1

            else: 
                pattern_matching_result_1 = 2


        else: 
            pattern_matching_result_1 = 2

        if pattern_matching_result_1 == 0:
            pattern_input: tuple[FSharpList[PreprocessorElement], FSharpList[Token]] = tokens_to_block_elements(child_ctx, rest_2)
            return (of_array([PreprocessorElement(2, to_text(printf("%s:"))(key)), PreprocessorElement(1, pattern_input[0])]), pattern_input[1])

        elif pattern_matching_result_1 == 1:
            pattern_input_1: tuple[FSharpList[PreprocessorElement], FSharpList[Token]] = tokens_to_block_elements(child_ctx, rest_2)
            return (of_array([PreprocessorElement(2, to_text(printf("%s:"))(key)), PreprocessorElement(1, pattern_input_1[0])]), pattern_input_1[1])

        elif pattern_matching_result_1 == 2:
            pattern_input_2: tuple[FSharpList[PreprocessorElement], FSharpList[Token]] = tokens_to_block_elements(child_ctx, rest_2)
            value_elements_2: FSharpList[PreprocessorElement] = pattern_input_2[0]
            return (singleton(PreprocessorElement(2, to_text(printf("%s: {}"))(key))) if is_empty(value_elements_2) else ((singleton(PreprocessorElement(2, to_text(printf("%s: %s"))(key)(head(value_elements_2).fields[0]))) if is_empty(tail(value_elements_2)) else of_array([PreprocessorElement(2, to_text(printf("%s:"))(key)), PreprocessorElement(1, value_elements_2)])) if (head(value_elements_2).tag == 2) else of_array([PreprocessorElement(2, to_text(printf("%s:"))(key)), PreprocessorElement(1, value_elements_2)])), pattern_input_2[1])


    elif pattern_matching_result == 3:
        return (singleton(PreprocessorElement(2, s)), rest_3)

    elif pattern_matching_result == 4:
        return (empty(), tokens)

    elif pattern_matching_result == 5:
        raise Exception(("Unexpected token in tokensToBlockElements: " + str(tokens)) + "")



def object_to_block_elements(ctx: TransformContext, tokens: FSharpList[Token]) -> tuple[FSharpList[PreprocessorElement], FSharpList[Token]]:
    child_ctx: TransformContext = TransformContext(ctx.BaseIndent + ctx.IndentStep, ctx.IndentStep, ctx.StringDict)
    def parse_key_values(tokens_1_mut: FSharpList[Token], acc_mut: FSharpList[PreprocessorElement], ctx: Any=ctx, tokens: Any=tokens) -> tuple[FSharpList[PreprocessorElement], FSharpList[Token]]:
        while True:
            (tokens_1, acc) = (tokens_1_mut, acc_mut)
            (pattern_matching_result, rest, rest_1, key, rest_2) = (None, None, None, None, None)
            if not is_empty(tokens_1):
                if head(tokens_1).tag == 1:
                    pattern_matching_result = 0
                    rest = tail(tokens_1)

                elif head(tokens_1).tag == 5:
                    pattern_matching_result = 1
                    rest_1 = tail(tokens_1)

                elif head(tokens_1).tag == 7:
                    pattern_matching_result = 2

                elif head(tokens_1).tag == 6:
                    if not is_empty(tail(tokens_1)):
                        if head(tail(tokens_1)).tag == 4:
                            pattern_matching_result = 3
                            key = head(tokens_1).fields[0]
                            rest_2 = tail(tail(tokens_1))

                        else: 
                            pattern_matching_result = 4


                    else: 
                        pattern_matching_result = 4


                else: 
                    pattern_matching_result = 4


            else: 
                pattern_matching_result = 4

            if pattern_matching_result == 0:
                return (reverse(acc), rest)

            elif pattern_matching_result == 1:
                tokens_1_mut = rest_1
                acc_mut = acc
                continue

            elif pattern_matching_result == 2:
                return (reverse(acc), tokens_1)

            elif pattern_matching_result == 3:
                (pattern_matching_result_1,) = (None,)
                if not is_empty(rest_2):
                    if head(rest_2).tag == 0:
                        pattern_matching_result_1 = 0

                    elif head(rest_2).tag == 2:
                        pattern_matching_result_1 = 1

                    else: 
                        pattern_matching_result_1 = 2


                else: 
                    pattern_matching_result_1 = 2

                if pattern_matching_result_1 == 0:
                    pattern_input: tuple[FSharpList[PreprocessorElement], FSharpList[Token]] = tokens_to_block_elements(child_ctx, rest_2)
                    tokens_1_mut = pattern_input[1]
                    acc_mut = append(reverse(of_array([PreprocessorElement(2, to_text(printf("%s:"))(key)), PreprocessorElement(1, pattern_input[0])])), acc)
                    continue

                elif pattern_matching_result_1 == 1:
                    pattern_input_1: tuple[FSharpList[PreprocessorElement], FSharpList[Token]] = tokens_to_block_elements(child_ctx, rest_2)
                    tokens_1_mut = pattern_input_1[1]
                    acc_mut = append(reverse(of_array([PreprocessorElement(2, to_text(printf("%s:"))(key)), PreprocessorElement(1, pattern_input_1[0])])), acc)
                    continue

                elif pattern_matching_result_1 == 2:
                    pattern_input_2: tuple[FSharpList[PreprocessorElement], FSharpList[Token]] = tokens_to_block_elements(child_ctx, rest_2)
                    value_elements_2: FSharpList[PreprocessorElement] = pattern_input_2[0]
                    tokens_1_mut = pattern_input_2[1]
                    acc_mut = append(reverse(singleton(PreprocessorElement(2, to_text(printf("%s: {}"))(key))) if is_empty(value_elements_2) else ((singleton(PreprocessorElement(2, to_text(printf("%s: %s"))(key)(head(value_elements_2).fields[0]))) if is_empty(tail(value_elements_2)) else of_array([PreprocessorElement(2, to_text(printf("%s:"))(key)), PreprocessorElement(1, value_elements_2)])) if (head(value_elements_2).tag == 2) else of_array([PreprocessorElement(2, to_text(printf("%s:"))(key)), PreprocessorElement(1, value_elements_2)]))), acc)
                    continue


            elif pattern_matching_result == 4:
                raise Exception(("Expected key or close brace in object, got: " + str(tokens_1)) + "")

            break

    return parse_key_values(tokens, empty())


def array_to_block_elements(ctx: TransformContext, tokens: FSharpList[Token]) -> tuple[FSharpList[PreprocessorElement], FSharpList[Token]]:
    child_ctx: TransformContext = TransformContext(ctx.BaseIndent + ctx.IndentStep, ctx.IndentStep, ctx.StringDict)
    def parse_elements(tokens_1_mut: FSharpList[Token], acc_mut: FSharpList[PreprocessorElement], ctx: Any=ctx, tokens: Any=tokens) -> tuple[FSharpList[PreprocessorElement], FSharpList[Token]]:
        while True:
            (tokens_1, acc) = (tokens_1_mut, acc_mut)
            (pattern_matching_result, rest, rest_1) = (None, None, None)
            if not is_empty(tokens_1):
                if head(tokens_1).tag == 3:
                    pattern_matching_result = 0
                    rest = tail(tokens_1)

                elif head(tokens_1).tag == 5:
                    pattern_matching_result = 1
                    rest_1 = tail(tokens_1)

                elif head(tokens_1).tag == 7:
                    pattern_matching_result = 2

                else: 
                    pattern_matching_result = 3


            else: 
                pattern_matching_result = 3

            if pattern_matching_result == 0:
                return (reverse(acc), rest)

            elif pattern_matching_result == 1:
                tokens_1_mut = rest_1
                acc_mut = acc
                continue

            elif pattern_matching_result == 2:
                return (reverse(acc), tokens_1)

            elif pattern_matching_result == 3:
                pattern_input: tuple[FSharpList[PreprocessorElement], FSharpList[Token]] = tokens_to_block_elements(child_ctx, tokens_1)
                element_lines: FSharpList[PreprocessorElement] = pattern_input[0]
                tokens_1_mut = pattern_input[1]
                acc_mut = append(reverse(singleton(PreprocessorElement(2, "- {}")) if is_empty(element_lines) else ((singleton(PreprocessorElement(2, to_text(printf("- %s"))(head(element_lines).fields[0]))) if is_empty(tail(element_lines)) else of_array([PreprocessorElement(2, "-"), PreprocessorElement(1, element_lines)])) if (head(element_lines).tag == 2) else of_array([PreprocessorElement(2, "-"), PreprocessorElement(1, element_lines)]))), acc)
                continue

            break

    return parse_elements(tokens, empty())


def transform_flow_content(ctx: TransformContext, content: str) -> FSharpList[PreprocessorElement]:
    return tokens_to_block_elements(ctx, tokenize(content))[0]


def transform_element(ctx: TransformContext, element: PreprocessorElement) -> FSharpList[PreprocessorElement]:
    if element.tag == 2:
        s: str = element.fields[0]
        key_value_match: Any = match(create("^(?P<key>[^\\{{\\[]+):\\s+(?P<value>.*)$"), s)
        if key_value_match is not None:
            key: str = get_item(groups(key_value_match), "key") or ""
            value: str = get_item(groups(key_value_match), "value") or "".strip()
            if starts_with_exact(value, "{"):
                child_ctx: TransformContext = TransformContext(ctx.BaseIndent + ctx.IndentStep, ctx.IndentStep, ctx.StringDict)
                obj_comment_match: Any = match(create("^(\\{.*\\})\\s*(<c f=(\\d+)/>)?$"), value)
                if obj_comment_match is not None:
                    obj_content: str = get_item(groups(obj_comment_match), 1) or ""
                    comment_group: Any = get_item(groups(obj_comment_match), 3)
                    transformed_value: FSharpList[PreprocessorElement] = transform_flow_content(child_ctx, obj_content)
                    key_line: PreprocessorElement = PreprocessorElement(2, to_text(printf("%s:"))(key))
                    if comment_group is not None:
                        comment_id: int = parse(comment_group or "", 511, False, 32) or 0
                        def _arrow605(__unit: None=None, ctx: Any=ctx, element: Any=element) -> str:
                            arg_1: str = comment_group or ""
                            return to_text(printf("<c f=%s/>"))(arg_1)

                        return of_array([key_line, PreprocessorElement(1, cons(PreprocessorElement(2, _arrow605()), transformed_value))])

                    else: 
                        return of_array([key_line, PreprocessorElement(1, transformed_value)])


                else: 
                    transformed_value_1: FSharpList[PreprocessorElement] = transform_flow_content(child_ctx, value)
                    return of_array([PreprocessorElement(2, to_text(printf("%s:"))(key)), PreprocessorElement(1, transformed_value_1)])


            elif starts_with_exact(value, "["):
                child_ctx_1: TransformContext = TransformContext(ctx.BaseIndent + ctx.IndentStep, ctx.IndentStep, ctx.StringDict)
                arr_comment_match: Any = match(create("^(\\[.*\\])\\s*(<c f=(\\d+)/>)?$"), value)
                if arr_comment_match is not None:
                    arr_content: str = get_item(groups(arr_comment_match), 1) or ""
                    comment_group_1: Any = get_item(groups(arr_comment_match), 3)
                    transformed_value_2: FSharpList[PreprocessorElement] = transform_flow_content(child_ctx_1, arr_content)
                    key_line_1: PreprocessorElement = PreprocessorElement(2, to_text(printf("%s:"))(key))
                    if comment_group_1 is not None:
                        def _arrow607(__unit: None=None, ctx: Any=ctx, element: Any=element) -> str:
                            arg_4: str = comment_group_1 or ""
                            return to_text(printf("<c f=%s/>"))(arg_4)

                        return of_array([key_line_1, PreprocessorElement(1, cons(PreprocessorElement(2, _arrow607()), transformed_value_2))])

                    else: 
                        return of_array([key_line_1, PreprocessorElement(1, transformed_value_2)])


                else: 
                    transformed_value_3: FSharpList[PreprocessorElement] = transform_flow_content(child_ctx_1, value)
                    return of_array([PreprocessorElement(2, to_text(printf("%s:"))(key)), PreprocessorElement(1, transformed_value_3)])


            else: 
                return singleton(element)


        else: 
            inline_json_match: Any = match(create(FlowStyleObjectPattern), s)
            if inline_json_match is not None:
                content: str = get_item(groups(inline_json_match), "inlineSequence") or ""
                if content.strip() == "":
                    return singleton(PreprocessorElement(2, "{}"))

                else: 
                    return transform_flow_content(ctx, ("{" + content) + "}")


            else: 
                inline_seq_match: Any = match(create(FlowStyleArrayPattern), s)
                if inline_seq_match is not None:
                    content_1: str = get_item(groups(inline_seq_match), "inlineSequence") or ""
                    comment_group_2: Any = get_item(groups(inline_seq_match), "comment")
                    transformed_1: FSharpList[PreprocessorElement] = transform_flow_content(ctx, ("[" + content_1) + "]")
                    if comment_group_2 is not None:
                        comment_id_1: int = parse(comment_group_2 or "", 511, False, 32) or 0
                        return cons(PreprocessorElement(2, to_text(printf("<c f=%d/>"))(comment_id_1)), transformed_1)

                    else: 
                        return transformed_1


                else: 
                    return singleton(element)




    elif element.tag == 1:
        return singleton(PreprocessorElement(1, transform_elements(ctx, element.fields[0])))

    else: 
        return singleton(element)



def transform_elements(ctx: TransformContext, elements: FSharpList[PreprocessorElement]) -> FSharpList[PreprocessorElement]:
    def process_elements(elems_mut: FSharpList[PreprocessorElement], acc_mut: FSharpList[PreprocessorElement], ctx: Any=ctx, elements: Any=elements) -> FSharpList[PreprocessorElement]:
        while True:
            (elems, acc) = (elems_mut, acc_mut)
            (pattern_matching_result, closer, i_list, opener, rest, elem, rest_1) = (None, None, None, None, None, None, None)
            if not is_empty(elems):
                if head(elems).tag == 2:
                    if not is_empty(tail(elems)):
                        if head(tail(elems)).tag == 1:
                            if not is_empty(tail(tail(elems))):
                                if head(tail(tail(elems))).tag == 2:
                                    pattern_matching_result = 1
                                    closer = head(tail(tail(elems))).fields[0]
                                    i_list = head(tail(elems)).fields[0]
                                    opener = head(elems).fields[0]
                                    rest = tail(tail(tail(elems)))

                                else: 
                                    pattern_matching_result = 2
                                    elem = head(elems)
                                    rest_1 = tail(elems)


                            else: 
                                pattern_matching_result = 2
                                elem = head(elems)
                                rest_1 = tail(elems)


                        else: 
                            pattern_matching_result = 2
                            elem = head(elems)
                            rest_1 = tail(elems)


                    else: 
                        pattern_matching_result = 2
                        elem = head(elems)
                        rest_1 = tail(elems)


                else: 
                    pattern_matching_result = 2
                    elem = head(elems)
                    rest_1 = tail(elems)


            else: 
                pattern_matching_result = 0

            if pattern_matching_result == 0:
                return reverse(acc)

            elif pattern_matching_result == 1:
                json_opener_match: Any = match(create(FlowStyleObjectOpenerPattern), opener)
                if (match(create(FlowStyleObjectCloserPattern), closer) is not None) if (json_opener_match is not None) else False:
                    key: str = get_item(groups(json_opener_match), "key") or ""
                    def flatten_lines(eles: FSharpList[PreprocessorElement], elems: Any=elems, acc: Any=acc) -> FSharpList[str]:
                        def mapping(_arg: PreprocessorElement, eles: Any=eles) -> FSharpList[str]:
                            if _arg.tag == 2:
                                return singleton(trim_end(_arg.fields[0], ","))

                            elif _arg.tag == 1:
                                return flatten_lines(_arg.fields[0])

                            else: 
                                return empty()


                        return collect(mapping, eles)

                    elems_mut = rest
                    acc_mut = of_array_with_tail([PreprocessorElement(1, transform_flow_content(TransformContext(ctx.BaseIndent + ctx.IndentStep, ctx.IndentStep, ctx.StringDict), ("{" + join("\n", flatten_lines(i_list))) + "}")), PreprocessorElement(2, to_text(printf("%s:"))(key))], acc)
                    continue

                else: 
                    transformed1: FSharpList[PreprocessorElement] = transform_element(ctx, PreprocessorElement(2, opener))
                    transformed2: FSharpList[PreprocessorElement] = transform_element(ctx, PreprocessorElement(1, i_list))
                    elems_mut = rest
                    acc_mut = append(reverse(transform_element(ctx, PreprocessorElement(2, closer))), append(reverse(transformed2), append(reverse(transformed1), acc)))
                    continue


            elif pattern_matching_result == 2:
                elems_mut = rest_1
                acc_mut = append(reverse(transform_element(ctx, elem)), acc)
                continue

            break

    return process_elements(elements, empty())


__all__ = ["TransformContext_reflection", "default_context", "Token_reflection", "tokenize", "tokens_to_block_elements", "object_to_block_elements", "array_to_block_elements", "transform_flow_content", "transform_element", "transform_elements"]

