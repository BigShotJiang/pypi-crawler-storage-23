from __future__ import annotations
from ..fable_modules.dynamic_obj.dynamic_obj import (DynamicObj, DynamicObj_reflection)
from ..fable_modules.fable_library.option import default_arg
from ..fable_modules.fable_library.reflection import (TypeInfo, class_type)
from ..fable_modules.fable_library.types import Array
from .inputs import CWLInput
from .outputs import CWLOutput
from .requirements import (Requirement, HintEntry)
from .workflow_steps import WorkflowStep

def _expr769() -> TypeInfo:
    return class_type("ARCtrl.CWL.CWLWorkflowDescription", None, CWLWorkflowDescription, DynamicObj_reflection())


class CWLWorkflowDescription(DynamicObj):
    def __init__(self, steps: Array[WorkflowStep], inputs: Array[CWLInput], outputs: Array[CWLOutput], cwl_version: str | None=None, requirements: Array[Requirement] | None=None, hints: Array[HintEntry] | None=None, intent: Array[str] | None=None, metadata: DynamicObj | None=None, label: str | None=None, doc: str | None=None) -> None:
        super().__init__()
        self._cwlVersion: str = default_arg(cwl_version, "v1.2")
        self._steps: Array[WorkflowStep] = steps
        self._inputs: Array[CWLInput] = inputs
        self._outputs: Array[CWLOutput] = outputs
        self._requirements: Array[Requirement] | None = requirements
        self._hints: Array[HintEntry] | None = hints
        self._intent: Array[str] | None = intent
        self._metadata: DynamicObj | None = metadata
        self._label: str | None = label
        self._doc: str | None = doc

    @property
    def CWLVersion(self, __unit: None=None) -> str:
        this: CWLWorkflowDescription = self
        return this._cwlVersion

    @CWLVersion.setter
    def CWLVersion(self, version: str) -> None:
        this: CWLWorkflowDescription = self
        this._cwlVersion = version

    @property
    def Steps(self, __unit: None=None) -> Array[WorkflowStep]:
        this: CWLWorkflowDescription = self
        return this._steps

    @Steps.setter
    def Steps(self, steps: Array[WorkflowStep]) -> None:
        this: CWLWorkflowDescription = self
        this._steps = steps

    @property
    def Inputs(self, __unit: None=None) -> Array[CWLInput]:
        this: CWLWorkflowDescription = self
        return this._inputs

    @Inputs.setter
    def Inputs(self, inputs: Array[CWLInput]) -> None:
        this: CWLWorkflowDescription = self
        this._inputs = inputs

    @property
    def Outputs(self, __unit: None=None) -> Array[CWLOutput]:
        this: CWLWorkflowDescription = self
        return this._outputs

    @Outputs.setter
    def Outputs(self, outputs: Array[CWLOutput]) -> None:
        this: CWLWorkflowDescription = self
        this._outputs = outputs

    @property
    def Requirements(self, __unit: None=None) -> Array[Requirement] | None:
        this: CWLWorkflowDescription = self
        return this._requirements

    @Requirements.setter
    def Requirements(self, requirements: Array[Requirement] | None=None) -> None:
        this: CWLWorkflowDescription = self
        this._requirements = requirements

    @property
    def Hints(self, __unit: None=None) -> Array[HintEntry] | None:
        this: CWLWorkflowDescription = self
        return this._hints

    @Hints.setter
    def Hints(self, hints: Array[HintEntry] | None=None) -> None:
        this: CWLWorkflowDescription = self
        this._hints = hints

    @property
    def Intent(self, __unit: None=None) -> Array[str] | None:
        this: CWLWorkflowDescription = self
        return this._intent

    @Intent.setter
    def Intent(self, intent: Array[str] | None=None) -> None:
        this: CWLWorkflowDescription = self
        this._intent = intent

    @property
    def Metadata(self, __unit: None=None) -> DynamicObj | None:
        this: CWLWorkflowDescription = self
        return this._metadata

    @Metadata.setter
    def Metadata(self, metadata: DynamicObj | None=None) -> None:
        this: CWLWorkflowDescription = self
        this._metadata = metadata

    @property
    def Label(self, __unit: None=None) -> str | None:
        this: CWLWorkflowDescription = self
        return this._label

    @Label.setter
    def Label(self, label: str | None=None) -> None:
        this: CWLWorkflowDescription = self
        this._label = label

    @property
    def Doc(self, __unit: None=None) -> str | None:
        this: CWLWorkflowDescription = self
        return this._doc

    @Doc.setter
    def Doc(self, doc: str | None=None) -> None:
        this: CWLWorkflowDescription = self
        this._doc = doc

    @staticmethod
    def get_inputs(workflow: CWLWorkflowDescription) -> Array[CWLInput]:
        return workflow.Inputs

    @staticmethod
    def get_outputs(workflow: CWLWorkflowDescription) -> Array[CWLOutput]:
        return workflow.Outputs

    @staticmethod
    def get_requirements_or_empty(workflow: CWLWorkflowDescription) -> Array[Requirement]:
        return default_arg(workflow.Requirements, [])

    @staticmethod
    def get_hints_or_empty(workflow: CWLWorkflowDescription) -> Array[HintEntry]:
        return default_arg(workflow.Hints, [])

    @staticmethod
    def get_intent_or_empty(workflow: CWLWorkflowDescription) -> Array[str]:
        return default_arg(workflow.Intent, [])

    @staticmethod
    def get_or_create_hints(workflow: CWLWorkflowDescription) -> Array[HintEntry]:
        match_value: Array[HintEntry] | None = workflow.Hints
        if match_value is None:
            hints_1: Array[HintEntry] = []
            workflow.Hints = hints_1
            return hints_1

        else: 
            return match_value


    @staticmethod
    def get_or_create_intent(workflow: CWLWorkflowDescription) -> Array[str]:
        match_value: Array[str] | None = workflow.Intent
        if match_value is None:
            intent_1: Array[str] = []
            workflow.Intent = intent_1
            return intent_1

        else: 
            return match_value



CWLWorkflowDescription_reflection = _expr769

def CWLWorkflowDescription__ctor_Z5554389(steps: Array[WorkflowStep], inputs: Array[CWLInput], outputs: Array[CWLOutput], cwl_version: str | None=None, requirements: Array[Requirement] | None=None, hints: Array[HintEntry] | None=None, intent: Array[str] | None=None, metadata: DynamicObj | None=None, label: str | None=None, doc: str | None=None) -> CWLWorkflowDescription:
    return CWLWorkflowDescription(steps, inputs, outputs, cwl_version, requirements, hints, intent, metadata, label, doc)


__all__ = ["CWLWorkflowDescription_reflection"]

