from __future__ import annotations
from collections.abc import Callable
from typing import Any
from ..fable_modules.dynamic_obj.dynamic_obj import DynamicObj
from ..fable_modules.fable_library.choice import FSharpChoice_2
from ..fable_modules.fable_library.list import (FSharpList, is_empty, head, tail, map as map_1, singleton, of_array, empty, append, of_seq, choose, exists, cons, filter as filter_1, contains, try_find, reverse, length)
from ..fable_modules.fable_library.option import (map, bind, filter)
from ..fable_modules.fable_library.seq import (to_list, map as map_2, choose as choose_1, fold, delay, append as append_1, singleton as singleton_1, empty as empty_1)
from ..fable_modules.fable_library.set import (of_list, FSharpSet__Contains)
from ..fable_modules.fable_library.string_ import (trim_end, replace, to_text, interpolate, trim_start, join, split)
from ..fable_modules.fable_library.types import (Array, to_string)
from ..fable_modules.fable_library.util import (int64_to_string, curry2, string_hash, compare_primitives, IEnumerable_1)
from ..fable_modules.yamlicious.encode import (string, int_1, float_1)
from ..fable_modules.yamlicious.writer import write
from ..fable_modules.yamlicious.yamlicious_types import (YAMLContent, YAMLElement, Config)
from .cwlprocessing_unit import (WorkflowStepRunOps_tryGetTool, WorkflowStepRunOps_tryGetWorkflow, WorkflowStepRunOps_tryGetExpressionTool, WorkflowStepRunOps_tryGetOperation, CWLProcessingUnit)
from .cwltypes import (CWLType, SchemaSaladString, SoftwarePackage, DirentInstance, InputArraySchema, InputRecordField, InputRecordSchema, InputEnumSchema, SchemaDefRequirementType)
from .expression_tool_description import CWLExpressionToolDescription
from .inputs import (InputBinding, CWLInput)
from .operation_description import CWLOperationDescription
from .outputs import (OutputBinding, OutputSource, CWLOutput)
from .requirements import (EnvironmentDef, DockerRequirement, LoadListingEnum_get_toCwlString, InitialWorkDirEntry, ToolTimeLimitValue, Requirement, HintEntry)
from .tool_description import CWLToolDescription
from .workflow_description import CWLWorkflowDescription
from .workflow_steps import (LinkMergeMethod, PickValueMethod, ScatterMethod, StepInput, StepOutputParameter, StepOutput, WorkflowStepRun, WorkflowStep)

def _007CPrimitiveType_007CComplexType_007C(t: CWLType) -> Any:
    if t.tag == 1:
        return FSharpChoice_2(0, "Directory")

    elif t.tag == 2:
        return FSharpChoice_2(0, "Dirent")

    elif t.tag == 3:
        return FSharpChoice_2(0, "string")

    elif t.tag == 4:
        return FSharpChoice_2(0, "int")

    elif t.tag == 5:
        return FSharpChoice_2(0, "long")

    elif t.tag == 6:
        return FSharpChoice_2(0, "float")

    elif t.tag == 7:
        return FSharpChoice_2(0, "double")

    elif t.tag == 8:
        return FSharpChoice_2(0, "boolean")

    elif t.tag == 10:
        return FSharpChoice_2(0, "null")

    elif t.tag == 9:
        return FSharpChoice_2(0, "stdout")

    elif ((t.tag == 12) or (t.tag == 13)) or (t.tag == 14):
        return FSharpChoice_2(1, None)

    elif t.tag == 11:
        if _007CPrimitiveType_007CComplexType_007C(t.fields[0].Items).tag == 1:
            return FSharpChoice_2(1, None)

        else: 
            return FSharpChoice_2(0, "array")


    else: 
        return FSharpChoice_2(0, "File")



def try_get_array_shorthand(cwl_type: CWLType) -> str | None:
    (pattern_matching_result, name_1, array_schema) = (None, None, None)
    active_pattern_result: Any = _007CPrimitiveType_007CComplexType_007C(cwl_type)
    if active_pattern_result.tag == 0:
        if active_pattern_result.fields[0] != "array":
            pattern_matching_result = 0
            name_1 = active_pattern_result.fields[0]

        elif cwl_type.tag == 11:
            pattern_matching_result = 1
            array_schema = cwl_type.fields[0]

        else: 
            pattern_matching_result = 2


    elif cwl_type.tag == 11:
        pattern_matching_result = 1
        array_schema = cwl_type.fields[0]

    else: 
        pattern_matching_result = 2

    if pattern_matching_result == 0:
        return name_1

    elif pattern_matching_result == 1:
        def mapping(s: str, cwl_type: Any=cwl_type) -> str:
            return s + "[]"

        return map(mapping, try_get_array_shorthand(array_schema.Items))

    elif pattern_matching_result == 2:
        return None



def is_complex_type(t_mut: CWLType) -> bool:
    while True:
        (t,) = (t_mut,)
        if (t.tag == 12) or (t.tag == 13):
            return True

        elif t.tag == 11:
            return try_get_array_shorthand(t.fields[0].Items) is None

        elif t.tag == 14:
            types_list: FSharpList[CWLType] = to_list(t.fields[0])
            (pattern_matching_result, other_type) = (None, None)
            if not is_empty(types_list):
                if head(types_list).tag == 10:
                    if not is_empty(tail(types_list)):
                        if is_empty(tail(tail(types_list))):
                            pattern_matching_result = 0
                            other_type = head(tail(types_list))

                        else: 
                            pattern_matching_result = 1


                    else: 
                        pattern_matching_result = 1


                elif not is_empty(tail(types_list)):
                    if head(tail(types_list)).tag == 10:
                        if is_empty(tail(tail(types_list))):
                            pattern_matching_result = 0
                            other_type = head(types_list)

                        else: 
                            pattern_matching_result = 1


                    else: 
                        pattern_matching_result = 1


                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1

            if pattern_matching_result == 0:
                t_mut = other_type
                continue

            elif pattern_matching_result == 1:
                return True


        else: 
            return False

        break


def y_bool(b: bool) -> YAMLElement:
    return YAMLElement(1, YAMLContent("true" if b else "false", None))


def y_map(pairs: FSharpList[tuple[str, YAMLElement]]) -> YAMLElement:
    def mapping(tupled_arg: tuple[str, YAMLElement], pairs: Any=pairs) -> YAMLElement:
        def _arrow984(__unit: None=None, tupled_arg: Any=tupled_arg) -> YAMLElement:
            _arg: YAMLElement = tupled_arg[1]
            (pattern_matching_result, single, other) = (None, None, None)
            if _arg.tag == 3:
                if not is_empty(_arg.fields[0]):
                    if is_empty(tail(_arg.fields[0])):
                        pattern_matching_result = 1
                        single = head(_arg.fields[0])

                    else: 
                        pattern_matching_result = 2
                        other = _arg


                else: 
                    pattern_matching_result = 0


            else: 
                pattern_matching_result = 2
                other = _arg

            if pattern_matching_result == 0:
                return YAMLElement(1, YAMLContent("{}", None))

            elif pattern_matching_result == 1:
                return single

            elif pattern_matching_result == 2:
                return other


        return YAMLElement(0, YAMLContent(tupled_arg[0], None), _arrow984())

    return YAMLElement(3, map_1(mapping, pairs))


def normalize_doc_string(doc: str) -> str:
    return trim_end(trim_end(replace(doc, "\r\n", "\n"), "\n"), "\r")


def encode_schema_salad_string(value: SchemaSaladString) -> YAMLElement:
    if value.tag == 1:
        return y_map(singleton(("$include", string(value.fields[0]))))

    elif value.tag == 2:
        return y_map(singleton(("$import", string(value.fields[0]))))

    else: 
        return string(value.fields[0])



def normalize_env_value_for_encode(env_value: str) -> str:
    if True if (env_value == "true") else (env_value == "false"):
        return ("\"" + env_value) + "\""

    else: 
        return env_value



def encode_env_var_requirement_compact_map(envs: Array[EnvironmentDef]) -> YAMLElement:
    def mapping(env: EnvironmentDef, envs: Any=envs) -> tuple[str, YAMLElement]:
        return (env.EnvName, string(normalize_env_value_for_encode(env.EnvValue)))

    env_def_map: YAMLElement = y_map(to_list(map_2(mapping, envs)))
    return y_map(of_array([("class", string("EnvVarRequirement")), ("envDef", env_def_map)]))


def encode_software_requirement_compact_map(packages: Array[SoftwarePackage]) -> YAMLElement:
    def mapping(package_1: SoftwarePackage, packages: Any=packages) -> tuple[str, YAMLElement]:
        def _arrow986(__unit: None=None, package_1: Any=package_1) -> YAMLElement:
            package: SoftwarePackage = package_1
            match_value_1: Array[str] | None = package.Specs
            def _arrow985(__unit: None=None) -> FSharpList[tuple[str, YAMLElement]]:
                value_6: Array[str] | None = package.Specs
                acc_3: FSharpList[tuple[str, YAMLElement]]
                value_3: Array[str] | None = package.Version
                acc_1: FSharpList[tuple[str, YAMLElement]] = empty()
                acc_3 = acc_1 if (value_3 is None) else append(acc_1, singleton(("version", YAMLElement(2, to_list(map_2(string, value_3))))))
                return acc_3 if (value_6 is None) else append(acc_3, singleton(("specs", YAMLElement(2, to_list(map_2(string, value_6))))))

            return (YAMLElement(2, to_list(map_2(string, match_value_1))) if (match_value_1 is not None) else y_map(empty())) if (package.Version is None) else y_map(_arrow985())

        return (package_1.Package, _arrow986())

    packages_map: YAMLElement = y_map(to_list(map_2(mapping, packages)))
    return y_map(of_array([("class", string("SoftwareRequirement")), ("packages", packages_map)]))


def encode_label(label: str) -> tuple[str, YAMLElement]:
    return ("label", string(label))


def encode_doc(doc: str) -> tuple[str, YAMLElement]:
    return ("doc", string(normalize_doc_string(doc)))


def encode_intent(intent: Array[str]) -> tuple[str, YAMLElement]:
    def _arrow987(value: str, intent: Any=intent) -> YAMLElement:
        return string(value)

    return ("intent", YAMLElement(2, of_seq(map_2(_arrow987, intent))))


def encode_cwltype(t: CWLType) -> YAMLElement:
    if t.tag == 1:
        return string("Directory")

    elif t.tag == 2:
        d: DirentInstance = t.fields[0]
        def _arrow988(__unit: None=None, t: Any=t) -> FSharpList[tuple[str, YAMLElement]]:
            value_4: bool | None = d.Writable
            acc_3: FSharpList[tuple[str, YAMLElement]]
            value_2: SchemaSaladString | None = d.Entryname
            acc_1: FSharpList[tuple[str, YAMLElement]] = singleton(("entry", encode_schema_salad_string(d.Entry)))
            acc_3 = acc_1 if (value_2 is None) else append(acc_1, singleton(("entryname", encode_schema_salad_string(value_2))))
            return acc_3 if (value_4 is None) else append(acc_3, singleton(("writable", y_bool(value_4))))

        return y_map(_arrow988())

    elif t.tag == 3:
        return string("string")

    elif t.tag == 4:
        return string("int")

    elif t.tag == 5:
        return string("long")

    elif t.tag == 6:
        return string("float")

    elif t.tag == 7:
        return string("double")

    elif t.tag == 8:
        return string("boolean")

    elif t.tag == 9:
        return string("stdout")

    elif t.tag == 10:
        return string("null")

    elif t.tag == 14:
        types_list: FSharpList[CWLType] = to_list(t.fields[0])
        (pattern_matching_result, other_type) = (None, None)
        if not is_empty(types_list):
            if head(types_list).tag == 10:
                if not is_empty(tail(types_list)):
                    if is_empty(tail(tail(types_list))):
                        pattern_matching_result = 0
                        other_type = head(tail(types_list))

                    else: 
                        pattern_matching_result = 1


                else: 
                    pattern_matching_result = 1


            elif not is_empty(tail(types_list)):
                if head(tail(types_list)).tag == 10:
                    if is_empty(tail(tail(types_list))):
                        pattern_matching_result = 0
                        other_type = head(types_list)

                    else: 
                        pattern_matching_result = 1


                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1

        if pattern_matching_result == 0:
            if other_type.tag == 0:
                return string("File?")

            elif other_type.tag == 1:
                return string("Directory?")

            elif other_type.tag == 3:
                return string("string?")

            elif other_type.tag == 4:
                return string("int?")

            elif other_type.tag == 5:
                return string("long?")

            elif other_type.tag == 6:
                return string("float?")

            elif other_type.tag == 7:
                return string("double?")

            elif other_type.tag == 8:
                return string("boolean?")

            elif other_type.tag == 11:
                array_schema: InputArraySchema = other_type.fields[0]
                match_value: str | None = try_get_array_shorthand(array_schema.Items)
                if match_value is None:
                    return YAMLElement(2, of_array([string("null"), encode_input_array_schema(array_schema)]))

                else: 
                    return string(match_value + "[]?")


            else: 
                def mapping(t_1: CWLType, t: Any=t) -> YAMLElement:
                    return encode_cwltype(t_1)

                return YAMLElement(2, map_1(mapping, types_list))


        elif pattern_matching_result == 1:
            def mapping_1(t_2: CWLType, t: Any=t) -> YAMLElement:
                return encode_cwltype(t_2)

            return YAMLElement(2, map_1(mapping_1, types_list))


    elif t.tag == 11:
        array_schema_1: InputArraySchema = t.fields[0]
        match_value_1: str | None = try_get_array_shorthand(array_schema_1.Items)
        if match_value_1 is None:
            return encode_input_array_schema(array_schema_1)

        else: 
            return string(match_value_1 + "[]")


    elif t.tag == 12:
        return encode_input_record_schema(t.fields[0])

    elif t.tag == 13:
        return encode_input_enum_schema(t.fields[0])

    else: 
        return string("File")



def encode_input_record_field(field: InputRecordField) -> tuple[str, YAMLElement]:
    return (field.Name, y_map(singleton(("type", encode_cwltype(field.Type)))))


def encode_input_record_schema(schema: InputRecordSchema) -> YAMLElement:
    fields_element: YAMLElement
    match_value: Array[InputRecordField] | None = schema.Fields
    def mapping(field: InputRecordField, schema: Any=schema) -> tuple[str, YAMLElement]:
        return encode_input_record_field(field)

    fields_element = y_map(empty()) if (match_value is None) else y_map(to_list(map_2(mapping, match_value)))
    return y_map(of_array([("type", string("record")), ("fields", fields_element)]))


def encode_input_enum_schema(schema: InputEnumSchema) -> YAMLElement:
    def _arrow1002(value: str, schema: Any=schema) -> YAMLElement:
        return string(value)

    return y_map(append(singleton(("type", string("enum"))), singleton(("symbols", YAMLElement(2, of_seq(map_2(_arrow1002, schema.Symbols)))))))


def encode_input_array_schema(schema: InputArraySchema) -> YAMLElement:
    return y_map(of_array([("type", string("array")), ("items", encode_cwltype(schema.Items))]))


def encode_output_binding(ob: OutputBinding) -> YAMLElement:
    def chooser(x: tuple[str, YAMLElement] | None=None, ob: Any=ob) -> tuple[str, YAMLElement] | None:
        return x

    def mapping(g: str, ob: Any=ob) -> tuple[str, YAMLElement]:
        return ("glob", string(g))

    return y_map(choose(chooser, singleton(map(mapping, ob.Glob))))


def encode_string_array_or_scalar(values: Array[str]) -> YAMLElement:
    if len(values) == 1:
        return string(values[0])

    else: 
        def _arrow1003(value: str, values: Any=values) -> YAMLElement:
            return string(value)

        return YAMLElement(2, of_seq(map_2(_arrow1003, values)))



def encode_cwloutput(o: CWLOutput) -> tuple[str, YAMLElement]:
    def mapping(t: CWLType, o: Any=o) -> YAMLElement:
        if t.tag == 14:
            types_list: FSharpList[CWLType] = to_list(t.fields[0])
            (pattern_matching_result, other_type) = (None, None)
            if not is_empty(types_list):
                if head(types_list).tag == 10:
                    if not is_empty(tail(types_list)):
                        if is_empty(tail(tail(types_list))):
                            pattern_matching_result = 0
                            other_type = head(tail(types_list))

                        else: 
                            pattern_matching_result = 1


                    else: 
                        pattern_matching_result = 1


                elif not is_empty(tail(types_list)):
                    if head(tail(types_list)).tag == 10:
                        if is_empty(tail(tail(types_list))):
                            pattern_matching_result = 0
                            other_type = head(types_list)

                        else: 
                            pattern_matching_result = 1


                    else: 
                        pattern_matching_result = 1


                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1

            if pattern_matching_result == 0:
                if (((((((other_type.tag == 0) or (other_type.tag == 1)) or (other_type.tag == 3)) or (other_type.tag == 4)) or (other_type.tag == 5)) or (other_type.tag == 6)) or (other_type.tag == 7)) or (other_type.tag == 8):
                    return encode_cwltype(t)

                elif other_type.tag == 11:
                    match_value: CWLType = other_type.fields[0].Items
                    if (((((((match_value.tag == 0) or (match_value.tag == 1)) or (match_value.tag == 3)) or (match_value.tag == 4)) or (match_value.tag == 5)) or (match_value.tag == 6)) or (match_value.tag == 7)) or (match_value.tag == 8):
                        return encode_cwltype(t)

                    else: 
                        return encode_cwltype(t)


                else: 
                    return encode_cwltype(t)


            elif pattern_matching_result == 1:
                return encode_cwltype(t)


        elif t.tag == 11:
            array_schema_1: InputArraySchema = t.fields[0]
            match_value_1: CWLType = array_schema_1.Items
            if ((((((((match_value_1.tag == 0) or (match_value_1.tag == 1)) or (match_value_1.tag == 2)) or (match_value_1.tag == 3)) or (match_value_1.tag == 4)) or (match_value_1.tag == 5)) or (match_value_1.tag == 6)) or (match_value_1.tag == 7)) or (match_value_1.tag == 8):
                return encode_cwltype(t)

            else: 
                return y_map(singleton(("type", encode_input_array_schema(array_schema_1))))


        elif t.tag == 12:
            return y_map(singleton(("type", encode_input_record_schema(t.fields[0]))))

        elif t.tag == 13:
            return y_map(singleton(("type", encode_input_enum_schema(t.fields[0]))))

        else: 
            return encode_cwltype(t)


    type_element: YAMLElement | None = map(mapping, o.Type_)
    pairs: FSharpList[tuple[str, YAMLElement]]
    value_4: YAMLElement | None
    match_value_2: OutputSource | None = o.OutputSource
    (pattern_matching_result_1, value, values_1) = (None, None, None)
    if match_value_2 is not None:
        if match_value_2.tag == 1:
            if len(match_value_2.fields[0]) > 0:
                pattern_matching_result_1 = 1
                values_1 = match_value_2.fields[0]

            else: 
                pattern_matching_result_1 = 2


        else: 
            pattern_matching_result_1 = 0
            value = match_value_2.fields[0]


    else: 
        pattern_matching_result_1 = 2

    if pattern_matching_result_1 == 0:
        value_4 = string(value)

    elif pattern_matching_result_1 == 1:
        value_4 = encode_string_array_or_scalar(values_1)

    elif pattern_matching_result_1 == 2:
        value_4 = None

    acc_5: FSharpList[tuple[str, YAMLElement]]
    acc_2: FSharpList[tuple[str, YAMLElement]]
    value_1: YAMLElement | None = type_element
    acc_1: FSharpList[tuple[str, YAMLElement]] = empty()
    acc_2 = acc_1 if (value_1 is None) else append(acc_1, singleton(("type", value_1)))
    value_3: OutputBinding | None = o.OutputBinding
    acc_3: FSharpList[tuple[str, YAMLElement]] = acc_2
    acc_5 = acc_3 if (value_3 is None) else append(acc_3, singleton(("outputBinding", encode_output_binding(value_3))))
    pairs = acc_5 if (value_4 is None) else append(acc_5, singleton(("outputSource", value_4)))
    (pattern_matching_result_2, t_1) = (None, None)
    if not is_empty(pairs):
        if head(pairs)[0] == "type":
            if is_empty(tail(pairs)):
                pattern_matching_result_2 = 0
                t_1 = head(pairs)[1]

            else: 
                pattern_matching_result_2 = 1


        else: 
            pattern_matching_result_2 = 1


    else: 
        pattern_matching_result_2 = 1

    if pattern_matching_result_2 == 0:
        return (o.Name, t_1)

    elif pattern_matching_result_2 == 1:
        return (o.Name, y_map(pairs))



def encode_input_binding(ib: InputBinding) -> YAMLElement:
    def _arrow1005(__unit: None=None, ib: Any=ib) -> FSharpList[tuple[str, YAMLElement]]:
        value_9: bool | None = ib.Separate
        acc_7: FSharpList[tuple[str, YAMLElement]]
        value_7: str | None = ib.ItemSeparator
        acc_5: FSharpList[tuple[str, YAMLElement]]
        value_4: int | None = ib.Position
        acc_3: FSharpList[tuple[str, YAMLElement]]
        value_2: str | None = ib.Prefix
        acc_1: FSharpList[tuple[str, YAMLElement]] = empty()
        acc_3 = acc_1 if (value_2 is None) else append(acc_1, singleton(("prefix", string(value_2))))
        acc_5 = acc_3 if (value_4 is None) else append(acc_3, singleton(("position", int_1(value_4))))
        acc_7 = acc_5 if (value_7 is None) else append(acc_5, singleton(("itemSeparator", string(value_7))))
        return acc_7 if (value_9 is None) else append(acc_7, singleton(("separate", y_bool(value_9))))

    return y_map(_arrow1005())


def encode_cwlinput(i: CWLInput) -> tuple[str, YAMLElement]:
    pairs: FSharpList[tuple[str, YAMLElement]]
    acc_4: FSharpList[tuple[str, YAMLElement]]
    acc_2: FSharpList[tuple[str, YAMLElement]]
    def mapping(t: CWLType, i: Any=i) -> YAMLElement:
        if t.tag == 14:
            types_list: FSharpList[CWLType] = to_list(t.fields[0])
            (pattern_matching_result, other_type) = (None, None)
            if not is_empty(types_list):
                if head(types_list).tag == 10:
                    if not is_empty(tail(types_list)):
                        if is_empty(tail(tail(types_list))):
                            pattern_matching_result = 0
                            other_type = head(tail(types_list))

                        else: 
                            pattern_matching_result = 1


                    else: 
                        pattern_matching_result = 1


                elif not is_empty(tail(types_list)):
                    if head(tail(types_list)).tag == 10:
                        if is_empty(tail(tail(types_list))):
                            pattern_matching_result = 0
                            other_type = head(types_list)

                        else: 
                            pattern_matching_result = 1


                    else: 
                        pattern_matching_result = 1


                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1

            if pattern_matching_result == 0:
                if (((((((other_type.tag == 0) or (other_type.tag == 1)) or (other_type.tag == 3)) or (other_type.tag == 4)) or (other_type.tag == 5)) or (other_type.tag == 6)) or (other_type.tag == 7)) or (other_type.tag == 8):
                    return encode_cwltype(t)

                elif other_type.tag == 11:
                    match_value: CWLType = other_type.fields[0].Items
                    if (((((((match_value.tag == 0) or (match_value.tag == 1)) or (match_value.tag == 3)) or (match_value.tag == 4)) or (match_value.tag == 5)) or (match_value.tag == 6)) or (match_value.tag == 7)) or (match_value.tag == 8):
                        return encode_cwltype(t)

                    else: 
                        return encode_cwltype(t)


                else: 
                    return encode_cwltype(t)


            elif pattern_matching_result == 1:
                return encode_cwltype(t)


        elif t.tag == 11:
            array_schema_1: InputArraySchema = t.fields[0]
            match_value_1: CWLType = array_schema_1.Items
            if ((((((((match_value_1.tag == 0) or (match_value_1.tag == 1)) or (match_value_1.tag == 2)) or (match_value_1.tag == 3)) or (match_value_1.tag == 4)) or (match_value_1.tag == 5)) or (match_value_1.tag == 6)) or (match_value_1.tag == 7)) or (match_value_1.tag == 8):
                return encode_cwltype(t)

            else: 
                return y_map(singleton(("type", encode_input_array_schema(array_schema_1))))


        elif t.tag == 12:
            return y_map(singleton(("type", encode_input_record_schema(t.fields[0]))))

        elif t.tag == 13:
            return y_map(singleton(("type", encode_input_enum_schema(t.fields[0]))))

        else: 
            return encode_cwltype(t)


    value: YAMLElement | None = map(mapping, i.Type_)
    acc_1: FSharpList[tuple[str, YAMLElement]] = empty()
    acc_2 = acc_1 if (value is None) else append(acc_1, singleton(("type", value)))
    value_2: InputBinding | None = i.InputBinding
    acc_3: FSharpList[tuple[str, YAMLElement]] = acc_2
    acc_4 = acc_3 if (value_2 is None) else append(acc_3, singleton(("inputBinding", encode_input_binding(value_2))))
    value_4: bool | None = i.Optional
    acc_5: FSharpList[tuple[str, YAMLElement]] = acc_4
    pairs = acc_5 if (value_4 is None) else append(acc_5, singleton(("optional", y_bool(value_4))))
    (pattern_matching_result_1, t_1) = (None, None)
    if not is_empty(pairs):
        if head(pairs)[0] == "type":
            if is_empty(tail(pairs)):
                pattern_matching_result_1 = 0
                t_1 = head(pairs)[1]

            else: 
                pattern_matching_result_1 = 1


        else: 
            pattern_matching_result_1 = 1


    else: 
        pattern_matching_result_1 = 1

    if pattern_matching_result_1 == 0:
        return (i.Name, t_1)

    elif pattern_matching_result_1 == 1:
        return (i.Name, y_map(pairs))



def encode_schema_def_requirement_type(s: SchemaDefRequirementType) -> YAMLElement:
    return y_map(of_array([("name", string(s.Name)), ("type", encode_cwltype(s.Type_))]))


def encode_requirement(r: Requirement) -> YAMLElement:
    if r.tag == 1:
        def _arrow1006(s: SchemaDefRequirementType, r: Any=r) -> YAMLElement:
            return encode_schema_def_requirement_type(s)

        return y_map(of_array([("class", string("SchemaDefRequirement")), ("types", YAMLElement(2, of_seq(map_2(_arrow1006, r.fields[0]))))]))

    elif r.tag == 2:
        dr: DockerRequirement = r.fields[0]
        def _arrow1007(__unit: None=None, r: Any=r) -> FSharpList[tuple[str, YAMLElement]]:
            value_20: str | None = dr.DockerOutputDirectory
            acc_13: FSharpList[tuple[str, YAMLElement]]
            value_17: str | None = dr.DockerImport
            acc_11: FSharpList[tuple[str, YAMLElement]]
            value_14: str | None = dr.DockerLoad
            acc_9: FSharpList[tuple[str, YAMLElement]]
            value_11: str | None = dr.DockerImageId
            acc_7: FSharpList[tuple[str, YAMLElement]]
            value_8: SchemaSaladString | None = dr.DockerFile
            acc_5: FSharpList[tuple[str, YAMLElement]]
            value_5: str | None = dr.DockerPull
            acc_3: FSharpList[tuple[str, YAMLElement]] = singleton(("class", string("DockerRequirement")))
            acc_5 = acc_3 if (value_5 is None) else append(acc_3, singleton(("dockerPull", string(value_5))))
            acc_7 = acc_5 if (value_8 is None) else append(acc_5, singleton(("dockerFile", encode_schema_salad_string(value_8))))
            acc_9 = acc_7 if (value_11 is None) else append(acc_7, singleton(("dockerImageId", string(value_11))))
            acc_11 = acc_9 if (value_14 is None) else append(acc_9, singleton(("dockerLoad", string(value_14))))
            acc_13 = acc_11 if (value_17 is None) else append(acc_11, singleton(("dockerImport", string(value_17))))
            return acc_13 if (value_20 is None) else append(acc_13, singleton(("dockerOutputDirectory", string(value_20))))

        return y_map(_arrow1007())

    elif r.tag == 3:
        def encode_pkg(p: SoftwarePackage, r: Any=r) -> YAMLElement:
            def _arrow1008(__unit: None=None, p: Any=p) -> FSharpList[tuple[str, YAMLElement]]:
                value_26: Array[str] | None = p.Specs
                acc_18: FSharpList[tuple[str, YAMLElement]]
                value_23: Array[str] | None = p.Version
                acc_16: FSharpList[tuple[str, YAMLElement]] = append(empty(), singleton(("package", string(p.Package))))
                acc_18 = acc_16 if (value_23 is None) else append(acc_16, singleton(("version", YAMLElement(2, of_seq(map_2(string, value_23))))))
                return acc_18 if (value_26 is None) else append(acc_18, singleton(("specs", YAMLElement(2, of_seq(map_2(string, value_26))))))

            return y_map(_arrow1008())

        return y_map(of_array([("class", string("SoftwareRequirement")), ("packages", YAMLElement(2, of_seq(map_2(encode_pkg, r.fields[0]))))]))

    elif r.tag == 4:
        return y_map(of_array([("class", string("LoadListingRequirement")), ("loadListing", string(LoadListingEnum_get_toCwlString()(r.fields[0].LoadListing)))]))

    elif r.tag == 5:
        def encode_dynamic_obj_with_class(class_name: str, dyn_obj: DynamicObj, r: Any=r) -> YAMLElement:
            def chooser(kvp: Any, class_name: Any=class_name, dyn_obj: Any=dyn_obj) -> tuple[str, YAMLElement] | None:
                match_value: Any = kvp[1]
                if str(type(match_value)) == "<class \'str\'>":
                    return (kvp[0], string(match_value))

                elif str(type(match_value)) == "<class \'bool\'>":
                    return (kvp[0], y_bool(match_value))

                elif str(type(match_value)) == "<class \'int\'>":
                    return (kvp[0], int_1(match_value))

                elif str(type(match_value)) == "<class \'fable_modules.fable_library.types.int64\'>":
                    return (kvp[0], string(int64_to_string(match_value)))

                elif str(type(match_value)) == "<class \'float\'>":
                    return (kvp[0], float_1(match_value))

                elif isinstance(match_value, YAMLElement):
                    return (kvp[0], match_value)

                else: 
                    return None


            dynamic_pairs: FSharpList[tuple[str, YAMLElement]] = to_list(choose_1(chooser, dyn_obj.GetProperties(False)))
            def predicate(tupled_arg: tuple[str, YAMLElement], class_name: Any=class_name, dyn_obj: Any=dyn_obj) -> bool:
                return tupled_arg[0] == "class"

            if exists(predicate, dynamic_pairs):
                return y_map(dynamic_pairs)

            else: 
                return y_map(cons(("class", string(class_name)), dynamic_pairs))


        encode_dynamic_obj_with_class: Callable[[str, DynamicObj], YAMLElement] = encode_dynamic_obj_with_class
        def encode_initial_work_dir_entry(_arg_1: InitialWorkDirEntry, r: Any=r) -> YAMLElement:
            if _arg_1.tag == 1:
                return encode_schema_salad_string(_arg_1.fields[0])

            elif _arg_1.tag == 2:
                return encode_dynamic_obj_with_class("File", _arg_1.fields[0])

            elif _arg_1.tag == 3:
                return encode_dynamic_obj_with_class("Directory", _arg_1.fields[0])

            else: 
                d: DirentInstance = _arg_1.fields[0]
                def _arrow1010(__unit: None=None, _arg_1: Any=_arg_1) -> FSharpList[tuple[str, YAMLElement]]:
                    value_31: bool | None = d.Writable
                    def _arrow1009(__unit: None=None) -> FSharpList[tuple[str, YAMLElement]]:
                        value_29: SchemaSaladString | None = d.Entryname
                        acc_20: FSharpList[tuple[str, YAMLElement]] = empty()
                        return acc_20 if (value_29 is None) else append(acc_20, singleton(("entryname", encode_schema_salad_string(value_29))))

                    acc_23: FSharpList[tuple[str, YAMLElement]] = append(_arrow1009(), singleton(("entry", encode_schema_salad_string(d.Entry))))
                    return acc_23 if (value_31 is None) else append(acc_23, singleton(("writable", y_bool(value_31))))

                return y_map(_arrow1010())


        return y_map(of_array([("class", string("InitialWorkDirRequirement")), ("listing", YAMLElement(2, of_seq(map_2(encode_initial_work_dir_entry, r.fields[0]))))]))

    elif r.tag == 6:
        def encode_env(e: EnvironmentDef, r: Any=r) -> YAMLElement:
            v_11: str = normalize_env_value_for_encode(e.EnvValue)
            return y_map(of_array([("envName", string(e.EnvName)), ("envValue", string(v_11))]))

        return y_map(of_array([("class", string("EnvVarRequirement")), ("envDef", YAMLElement(2, of_seq(map_2(encode_env, r.fields[0]))))]))

    elif r.tag == 7:
        return y_map(singleton(("class", string("ShellCommandRequirement"))))

    elif r.tag == 8:
        def try_encode_scalar(key: str, value_32: Any=None, r: Any=r) -> tuple[str, YAMLElement] | None:
            if str(type(value_32)) == "<class \'int\'>":
                return (key, int_1(value_32))

            elif str(type(value_32)) == "<class \'fable_modules.fable_library.types.int64\'>":
                return (key, YAMLElement(1, YAMLContent(int64_to_string(value_32), None)))

            elif str(type(value_32)) == "<class \'float\'>":
                return (key, float_1(value_32))

            elif str(type(value_32)) == "<class \'str\'>":
                return (key, string(value_32))

            elif str(type(value_32)) == "<class \'bool\'>":
                return (key, y_bool(value_32))

            else: 
                return None


        try_encode_scalar: Callable[[str, Any], tuple[str, YAMLElement] | None] = try_encode_scalar
        def chooser_1(kvp_1: Any, r: Any=r) -> tuple[str, YAMLElement] | None:
            match_value_1: Any = kvp_1[1]
            return bind(curry2(try_encode_scalar)(kvp_1[0]), match_value_1)

        dynamic_pairs_1: FSharpList[tuple[str, YAMLElement]] = to_list(choose_1(chooser_1, r.fields[0].GetProperties(False)))
        return y_map(append(singleton(("class", string("ResourceRequirement"))), dynamic_pairs_1))

    elif r.tag == 9:
        return y_map(of_array([("class", string("WorkReuse")), ("enableReuse", y_bool(r.fields[0].EnableReuse))]))

    elif r.tag == 10:
        return y_map(of_array([("class", string("WorkReuse")), ("enableReuse", string(r.fields[0]))]))

    elif r.tag == 11:
        return y_map(of_array([("class", string("NetworkAccess")), ("networkAccess", y_bool(r.fields[0].NetworkAccess))]))

    elif r.tag == 12:
        return y_map(of_array([("class", string("NetworkAccess")), ("networkAccess", string(r.fields[0]))]))

    elif r.tag == 13:
        return y_map(of_array([("class", string("InplaceUpdateRequirement")), ("inplaceUpdate", y_bool(r.fields[0].InplaceUpdate))]))

    elif r.tag == 14:
        tl: ToolTimeLimitValue = r.fields[0]
        timelimit: YAMLElement = string(tl.fields[0]) if (tl.tag == 1) else YAMLElement(1, YAMLContent(int64_to_string(tl.fields[0]), None))
        return y_map(of_array([("class", string("ToolTimeLimit")), ("timelimit", timelimit)]))

    elif r.tag == 15:
        return y_map(singleton(("class", string("SubworkflowFeatureRequirement"))))

    elif r.tag == 16:
        return y_map(singleton(("class", string("ScatterFeatureRequirement"))))

    elif r.tag == 17:
        return y_map(singleton(("class", string("MultipleInputFeatureRequirement"))))

    elif r.tag == 18:
        return y_map(singleton(("class", string("StepInputExpressionRequirement"))))

    else: 
        def _arrow1011(__unit: None=None, r: Any=r) -> FSharpList[tuple[str, YAMLElement]]:
            def binder(entries: Array[str]) -> Array[str] | None:
                if len(entries) > 0:
                    return entries

                else: 
                    return None


            value_2: Array[str] | None = bind(binder, r.fields[0].ExpressionLib)
            acc_1: FSharpList[tuple[str, YAMLElement]] = singleton(("class", string("InlineJavascriptRequirement")))
            return acc_1 if (value_2 is None) else append(acc_1, singleton(("expressionLib", YAMLElement(2, of_seq(map_2(string, value_2))))))

        return y_map(_arrow1011())



def encode_hint_entry(hint: HintEntry) -> YAMLElement:
    if hint.tag == 1:
        return hint.fields[0].Raw

    else: 
        return encode_requirement(hint.fields[0])



def encode_source_array(sources: Array[str]) -> YAMLElement:
    if len(sources) == 1:
        return string(sources[0])

    else: 
        def mapping(s: str, sources: Any=sources) -> YAMLElement:
            return YAMLElement(3, singleton(YAMLElement(1, YAMLContent(s, None))))

        return YAMLElement(2, of_seq(map_2(mapping, sources)))



def encode_link_merge_method(link_merge: LinkMergeMethod) -> YAMLElement:
    return string(link_merge.AsCwlString)


def encode_pick_value_method(pick_value: PickValueMethod) -> YAMLElement:
    return string(pick_value.AsCwlString)


def encode_scatter_method(scatter_method: ScatterMethod) -> YAMLElement:
    return string(scatter_method.AsCwlString)


def encode_step_input(si: StepInput) -> tuple[str, YAMLElement]:
    pairs: FSharpList[tuple[str, YAMLElement]]
    value_21: str | None = si.Label
    acc_17: FSharpList[tuple[str, YAMLElement]]
    value_18: str | None = si.LoadListing
    acc_15: FSharpList[tuple[str, YAMLElement]]
    value_15: bool | None = si.LoadContents
    acc_13: FSharpList[tuple[str, YAMLElement]]
    value_13: str | None = si.Doc
    acc_11: FSharpList[tuple[str, YAMLElement]]
    value_10: PickValueMethod | None = si.PickValue
    acc_9: FSharpList[tuple[str, YAMLElement]]
    value_8: LinkMergeMethod | None = si.LinkMerge
    acc_7: FSharpList[tuple[str, YAMLElement]]
    value_6: str | None = si.ValueFrom
    acc_5: FSharpList[tuple[str, YAMLElement]]
    value_3: YAMLElement | None = si.DefaultValue
    acc_3: FSharpList[tuple[str, YAMLElement]]
    value_1: Array[str] | None = si.Source
    acc_1: FSharpList[tuple[str, YAMLElement]] = empty()
    acc_3 = acc_1 if (value_1 is None) else append(acc_1, singleton(("source", encode_source_array(value_1))))
    acc_5 = acc_3 if (value_3 is None) else append(acc_3, singleton(("default", value_3)))
    acc_7 = acc_5 if (value_6 is None) else append(acc_5, singleton(("valueFrom", string(value_6))))
    acc_9 = acc_7 if (value_8 is None) else append(acc_7, singleton(("linkMerge", encode_link_merge_method(value_8))))
    acc_11 = acc_9 if (value_10 is None) else append(acc_9, singleton(("pickValue", encode_pick_value_method(value_10))))
    acc_13 = acc_11 if (value_13 is None) else append(acc_11, singleton(("doc", string(value_13))))
    acc_15 = acc_13 if (value_15 is None) else append(acc_13, singleton(("loadContents", y_bool(value_15))))
    acc_17 = acc_15 if (value_18 is None) else append(acc_15, singleton(("loadListing", string(value_18))))
    pairs = acc_17 if (value_21 is None) else append(acc_17, singleton(("label", string(value_21))))
    (pattern_matching_result, s_1) = (None, None)
    if not is_empty(pairs):
        if head(pairs)[0] == "source":
            if is_empty(tail(pairs)):
                if (si.Label is None) if ((si.LoadListing is None) if ((si.LoadContents is None) if ((si.Doc is None) if ((si.PickValue is None) if ((si.LinkMerge is None) if ((si.ValueFrom is None) if (si.DefaultValue is None) else False) else False) else False) else False) else False) else False) else False:
                    pattern_matching_result = 0
                    s_1 = head(pairs)[1]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return (si.Id, s_1)

    elif pattern_matching_result == 1:
        return (si.Id, y_map(pairs))



def encode_step_inputs(inputs: Array[StepInput]) -> YAMLElement:
    def _arrow1012(si: StepInput, inputs: Any=inputs) -> tuple[str, YAMLElement]:
        return encode_step_input(si)

    return y_map(to_list(map_2(_arrow1012, inputs)))


def encode_step_output_parameter(so: StepOutputParameter) -> YAMLElement:
    return y_map(singleton(("id", string(so.Id))))


def encode_step_outputs(outputs: Array[StepOutput]) -> YAMLElement:
    def mapping(output: StepOutput, outputs: Any=outputs) -> YAMLElement:
        if output.tag == 1:
            return encode_step_output_parameter(output.fields[0])

        else: 
            return string(output.fields[0])


    return YAMLElement(2, of_seq(map_2(mapping, outputs)))


def encode_scatter(scatter: Array[str]) -> YAMLElement:
    if len(scatter) == 1:
        return string(scatter[0])

    else: 
        def _arrow1013(value: str, scatter: Any=scatter) -> YAMLElement:
            return string(value)

        return YAMLElement(2, of_seq(map_2(_arrow1013, scatter)))



def encode_workflow_step_run(run: WorkflowStepRun) -> YAMLElement:
    if run.tag == 1:
        match_value: CWLToolDescription | None = WorkflowStepRunOps_tryGetTool(run)
        if match_value is None:
            raise Exception(to_text(interpolate("RunCommandLineTool must contain CWLToolDescription but got %A%P()", [run.fields[0]])))

        else: 
            return encode_tool_description_element(match_value)


    elif run.tag == 2:
        match_value_1: CWLWorkflowDescription | None = WorkflowStepRunOps_tryGetWorkflow(run)
        if match_value_1 is None:
            raise Exception(to_text(interpolate("RunWorkflow must contain CWLWorkflowDescription but got %A%P()", [run.fields[0]])))

        else: 
            return encode_workflow_description_element(match_value_1)


    elif run.tag == 3:
        match_value_2: CWLExpressionToolDescription | None = WorkflowStepRunOps_tryGetExpressionTool(run)
        if match_value_2 is None:
            raise Exception(to_text(interpolate("RunExpressionTool must contain CWLExpressionToolDescription but got %A%P()", [run.fields[0]])))

        else: 
            return encode_expression_tool_description_element(match_value_2)


    elif run.tag == 4:
        match_value_3: CWLOperationDescription | None = WorkflowStepRunOps_tryGetOperation(run)
        if match_value_3 is None:
            raise Exception(to_text(interpolate("RunOperation must contain CWLOperationDescription but got %A%P()", [run.fields[0]])))

        else: 
            return encode_operation_description_element(match_value_3)


    else: 
        return string(run.fields[0])



def encode_tool_description_element(td: CWLToolDescription) -> YAMLElement:
    base_pairs: FSharpList[tuple[str, YAMLElement]]
    acc_4: FSharpList[tuple[str, YAMLElement]]
    acc_2: FSharpList[tuple[str, YAMLElement]]
    acc: FSharpList[tuple[str, YAMLElement]] = of_array([("cwlVersion", string(td.CWLVersion)), ("class", string("CommandLineTool"))])
    def _arrow1014(label: str, td: Any=td) -> tuple[str, YAMLElement]:
        return encode_label(label)

    pair_opt_1: tuple[str, YAMLElement] | None = map(_arrow1014, td.Label)
    acc_1: FSharpList[tuple[str, YAMLElement]] = acc
    acc_2 = acc_1 if (pair_opt_1 is None) else append(acc_1, singleton(pair_opt_1))
    def _arrow1015(doc: str, td: Any=td) -> tuple[str, YAMLElement]:
        return encode_doc(doc)

    pair_opt_3: tuple[str, YAMLElement] | None = map(_arrow1015, td.Doc)
    acc_3: FSharpList[tuple[str, YAMLElement]] = acc_2
    acc_4 = acc_3 if (pair_opt_3 is None) else append(acc_3, singleton(pair_opt_3))
    def mapping(intent_1: Array[str], td: Any=td) -> tuple[str, YAMLElement]:
        return encode_intent(intent_1)

    def predicate(intent: Array[str], td: Any=td) -> bool:
        return len(intent) > 0

    pair_opt_5: tuple[str, YAMLElement] | None = map(mapping, filter(predicate, td.Intent))
    acc_5: FSharpList[tuple[str, YAMLElement]] = acc_4
    base_pairs = acc_5 if (pair_opt_5 is None) else append(acc_5, singleton(pair_opt_5))
    with_hints: FSharpList[tuple[str, YAMLElement]]
    match_value: Array[HintEntry] | None = td.Hints
    (pattern_matching_result, h_1) = (None, None)
    if match_value is not None:
        if len(match_value) > 0:
            pattern_matching_result = 0
            h_1 = match_value

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        def _arrow1016(hint: HintEntry, td: Any=td) -> YAMLElement:
            return encode_hint_entry(hint)

        with_hints = append(base_pairs, singleton(("hints", YAMLElement(2, of_seq(map_2(_arrow1016, h_1))))))

    elif pattern_matching_result == 1:
        with_hints = base_pairs

    with_requirements: FSharpList[tuple[str, YAMLElement]]
    match_value_1: Array[Requirement] | None = td.Requirements
    (pattern_matching_result_1, r_1) = (None, None)
    if match_value_1 is not None:
        if len(match_value_1) > 0:
            pattern_matching_result_1 = 0
            r_1 = match_value_1

        else: 
            pattern_matching_result_1 = 1


    else: 
        pattern_matching_result_1 = 1

    if pattern_matching_result_1 == 0:
        def _arrow1017(r_2: Requirement, td: Any=td) -> YAMLElement:
            return encode_requirement(r_2)

        with_requirements = append(with_hints, singleton(("requirements", YAMLElement(2, of_seq(map_2(_arrow1017, r_1))))))

    elif pattern_matching_result_1 == 1:
        with_requirements = with_hints

    with_base_command: FSharpList[tuple[str, YAMLElement]]
    match_value_2: Array[str] | None = td.BaseCommand
    (pattern_matching_result_2, bc_1) = (None, None)
    if match_value_2 is not None:
        if len(match_value_2) > 0:
            pattern_matching_result_2 = 0
            bc_1 = match_value_2

        else: 
            pattern_matching_result_2 = 1


    else: 
        pattern_matching_result_2 = 1

    if pattern_matching_result_2 == 0:
        def _arrow1018(value: str, td: Any=td) -> YAMLElement:
            return string(value)

        with_base_command = append(with_requirements, singleton(("baseCommand", YAMLElement(2, of_seq(map_2(_arrow1018, bc_1))))))

    elif pattern_matching_result_2 == 1:
        with_base_command = with_requirements

    def _arrow1019(__unit: None=None, td: Any=td) -> FSharpList[tuple[str, YAMLElement]]:
        match_value_3: Array[CWLInput] | None = td.Inputs
        (pattern_matching_result_3, i_1) = (None, None)
        if match_value_3 is not None:
            if len(match_value_3) > 0:
                pattern_matching_result_3 = 0
                i_1 = match_value_3

            else: 
                pattern_matching_result_3 = 1


        else: 
            pattern_matching_result_3 = 1

        if pattern_matching_result_3 == 0:
            return append(with_base_command, singleton(("inputs", y_map(to_list(map_2(encode_cwlinput, i_1))))))

        elif pattern_matching_result_3 == 1:
            return with_base_command


    def mapping_2(o: CWLOutput, td: Any=td) -> tuple[str, YAMLElement]:
        return encode_cwloutput(o)

    with_outputs: FSharpList[tuple[str, YAMLElement]] = append(_arrow1019(), singleton(("outputs", y_map(to_list(map_2(mapping_2, td.Outputs))))))
    def _arrow1021(__unit: None=None, td: Any=td) -> FSharpList[tuple[str, YAMLElement]]:
        match_value_4: DynamicObj | None = td.Metadata
        if match_value_4 is None:
            return with_outputs

        else: 
            md: DynamicObj = match_value_4
            def folder(acc_6: FSharpList[tuple[str, YAMLElement]], kvp: Any) -> FSharpList[tuple[str, YAMLElement]]:
                def _arrow1020(__unit: None=None, acc_6: Any=acc_6, kvp: Any=kvp) -> YAMLElement:
                    match_value_5: Any = kvp[1]
                    return string(match_value_5) if (str(type(match_value_5)) == "<class \'str\'>") else (y_bool(match_value_5) if (str(type(match_value_5)) == "<class \'bool\'>") else (int_1(match_value_5) if (str(type(match_value_5)) == "<class \'int\'>") else (float_1(match_value_5) if (str(type(match_value_5)) == "<class \'float\'>") else (match_value_5 if isinstance(match_value_5, YAMLElement) else string(to_string(kvp[1]))))))

                return append(acc_6, singleton((kvp[0], _arrow1020())))

            return fold(folder, with_outputs, md.GetProperties(False))


    return y_map(_arrow1021())


def encode_expression_tool_description_element(et: CWLExpressionToolDescription) -> YAMLElement:
    base_pairs: FSharpList[tuple[str, YAMLElement]]
    acc_4: FSharpList[tuple[str, YAMLElement]]
    acc_2: FSharpList[tuple[str, YAMLElement]]
    acc: FSharpList[tuple[str, YAMLElement]] = of_array([("cwlVersion", string(et.CWLVersion)), ("class", string("ExpressionTool"))])
    def _arrow1022(label: str, et: Any=et) -> tuple[str, YAMLElement]:
        return encode_label(label)

    pair_opt_1: tuple[str, YAMLElement] | None = map(_arrow1022, et.Label)
    acc_1: FSharpList[tuple[str, YAMLElement]] = acc
    acc_2 = acc_1 if (pair_opt_1 is None) else append(acc_1, singleton(pair_opt_1))
    def _arrow1023(doc: str, et: Any=et) -> tuple[str, YAMLElement]:
        return encode_doc(doc)

    pair_opt_3: tuple[str, YAMLElement] | None = map(_arrow1023, et.Doc)
    acc_3: FSharpList[tuple[str, YAMLElement]] = acc_2
    acc_4 = acc_3 if (pair_opt_3 is None) else append(acc_3, singleton(pair_opt_3))
    def mapping(intent_1: Array[str], et: Any=et) -> tuple[str, YAMLElement]:
        return encode_intent(intent_1)

    def predicate(intent: Array[str], et: Any=et) -> bool:
        return len(intent) > 0

    pair_opt_5: tuple[str, YAMLElement] | None = map(mapping, filter(predicate, et.Intent))
    acc_5: FSharpList[tuple[str, YAMLElement]] = acc_4
    base_pairs = acc_5 if (pair_opt_5 is None) else append(acc_5, singleton(pair_opt_5))
    with_hints: FSharpList[tuple[str, YAMLElement]]
    match_value: Array[HintEntry] | None = et.Hints
    (pattern_matching_result, h_1) = (None, None)
    if match_value is not None:
        if len(match_value) > 0:
            pattern_matching_result = 0
            h_1 = match_value

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        def _arrow1024(hint: HintEntry, et: Any=et) -> YAMLElement:
            return encode_hint_entry(hint)

        with_hints = append(base_pairs, singleton(("hints", YAMLElement(2, of_seq(map_2(_arrow1024, h_1))))))

    elif pattern_matching_result == 1:
        with_hints = base_pairs

    with_requirements: FSharpList[tuple[str, YAMLElement]]
    match_value_1: Array[Requirement] | None = et.Requirements
    (pattern_matching_result_1, r_1) = (None, None)
    if match_value_1 is not None:
        if len(match_value_1) > 0:
            pattern_matching_result_1 = 0
            r_1 = match_value_1

        else: 
            pattern_matching_result_1 = 1


    else: 
        pattern_matching_result_1 = 1

    if pattern_matching_result_1 == 0:
        def _arrow1025(r_2: Requirement, et: Any=et) -> YAMLElement:
            return encode_requirement(r_2)

        with_requirements = append(with_hints, singleton(("requirements", YAMLElement(2, of_seq(map_2(_arrow1025, r_1))))))

    elif pattern_matching_result_1 == 1:
        with_requirements = with_hints

    def _arrow1026(__unit: None=None, et: Any=et) -> FSharpList[tuple[str, YAMLElement]]:
        match_value_2: Array[CWLInput] | None = et.Inputs
        (pattern_matching_result_2, i_1) = (None, None)
        if match_value_2 is not None:
            if len(match_value_2) > 0:
                pattern_matching_result_2 = 0
                i_1 = match_value_2

            else: 
                pattern_matching_result_2 = 1


        else: 
            pattern_matching_result_2 = 1

        if pattern_matching_result_2 == 0:
            return append(with_requirements, singleton(("inputs", y_map(to_list(map_2(encode_cwlinput, i_1))))))

        elif pattern_matching_result_2 == 1:
            return with_requirements


    def mapping_2(o: CWLOutput, et: Any=et) -> tuple[str, YAMLElement]:
        return encode_cwloutput(o)

    with_expression: FSharpList[tuple[str, YAMLElement]] = append(append(_arrow1026(), singleton(("outputs", y_map(to_list(map_2(mapping_2, et.Outputs)))))), singleton(("expression", string(et.Expression))))
    def _arrow1028(__unit: None=None, et: Any=et) -> FSharpList[tuple[str, YAMLElement]]:
        match_value_3: DynamicObj | None = et.Metadata
        if match_value_3 is None:
            return with_expression

        else: 
            md: DynamicObj = match_value_3
            def folder(acc_6: FSharpList[tuple[str, YAMLElement]], kvp: Any) -> FSharpList[tuple[str, YAMLElement]]:
                def _arrow1027(__unit: None=None, acc_6: Any=acc_6, kvp: Any=kvp) -> YAMLElement:
                    match_value_4: Any = kvp[1]
                    return string(match_value_4) if (str(type(match_value_4)) == "<class \'str\'>") else (y_bool(match_value_4) if (str(type(match_value_4)) == "<class \'bool\'>") else (int_1(match_value_4) if (str(type(match_value_4)) == "<class \'int\'>") else (float_1(match_value_4) if (str(type(match_value_4)) == "<class \'float\'>") else (match_value_4 if isinstance(match_value_4, YAMLElement) else string(to_string(kvp[1]))))))

                return append(acc_6, singleton((kvp[0], _arrow1027())))

            return fold(folder, with_expression, md.GetProperties(False))


    return y_map(_arrow1028())


def encode_operation_description_element(op: CWLOperationDescription) -> YAMLElement:
    base_pairs: FSharpList[tuple[str, YAMLElement]]
    acc_4: FSharpList[tuple[str, YAMLElement]]
    acc_2: FSharpList[tuple[str, YAMLElement]]
    acc: FSharpList[tuple[str, YAMLElement]] = of_array([("cwlVersion", string(op.CWLVersion)), ("class", string("Operation"))])
    def _arrow1029(label: str, op: Any=op) -> tuple[str, YAMLElement]:
        return encode_label(label)

    pair_opt_1: tuple[str, YAMLElement] | None = map(_arrow1029, op.Label)
    acc_1: FSharpList[tuple[str, YAMLElement]] = acc
    acc_2 = acc_1 if (pair_opt_1 is None) else append(acc_1, singleton(pair_opt_1))
    def _arrow1030(doc: str, op: Any=op) -> tuple[str, YAMLElement]:
        return encode_doc(doc)

    pair_opt_3: tuple[str, YAMLElement] | None = map(_arrow1030, op.Doc)
    acc_3: FSharpList[tuple[str, YAMLElement]] = acc_2
    acc_4 = acc_3 if (pair_opt_3 is None) else append(acc_3, singleton(pair_opt_3))
    def mapping(intent_1: Array[str], op: Any=op) -> tuple[str, YAMLElement]:
        return encode_intent(intent_1)

    def predicate(intent: Array[str], op: Any=op) -> bool:
        return len(intent) > 0

    pair_opt_5: tuple[str, YAMLElement] | None = map(mapping, filter(predicate, op.Intent))
    acc_5: FSharpList[tuple[str, YAMLElement]] = acc_4
    base_pairs = acc_5 if (pair_opt_5 is None) else append(acc_5, singleton(pair_opt_5))
    with_hints: FSharpList[tuple[str, YAMLElement]]
    match_value: Array[HintEntry] | None = op.Hints
    (pattern_matching_result, h_1) = (None, None)
    if match_value is not None:
        if len(match_value) > 0:
            pattern_matching_result = 0
            h_1 = match_value

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        def _arrow1031(hint: HintEntry, op: Any=op) -> YAMLElement:
            return encode_hint_entry(hint)

        with_hints = append(base_pairs, singleton(("hints", YAMLElement(2, of_seq(map_2(_arrow1031, h_1))))))

    elif pattern_matching_result == 1:
        with_hints = base_pairs

    def _arrow1032(__unit: None=None, op: Any=op) -> FSharpList[tuple[str, YAMLElement]]:
        match_value_1: Array[Requirement] | None = op.Requirements
        (pattern_matching_result_1, r_1) = (None, None)
        if match_value_1 is not None:
            if len(match_value_1) > 0:
                pattern_matching_result_1 = 0
                r_1 = match_value_1

            else: 
                pattern_matching_result_1 = 1


        else: 
            pattern_matching_result_1 = 1

        if pattern_matching_result_1 == 0:
            return append(with_hints, singleton(("requirements", YAMLElement(2, of_seq(map_2(encode_requirement, r_1))))))

        elif pattern_matching_result_1 == 1:
            return with_hints


    def mapping_1(i: CWLInput, op: Any=op) -> tuple[str, YAMLElement]:
        return encode_cwlinput(i)

    def mapping_2(o: CWLOutput, op: Any=op) -> tuple[str, YAMLElement]:
        return encode_cwloutput(o)

    with_outputs: FSharpList[tuple[str, YAMLElement]] = append(append(_arrow1032(), singleton(("inputs", y_map(to_list(map_2(mapping_1, op.Inputs)))))), singleton(("outputs", y_map(to_list(map_2(mapping_2, op.Outputs))))))
    def _arrow1034(__unit: None=None, op: Any=op) -> FSharpList[tuple[str, YAMLElement]]:
        match_value_2: DynamicObj | None = op.Metadata
        if match_value_2 is None:
            return with_outputs

        else: 
            md: DynamicObj = match_value_2
            def folder(acc_6: FSharpList[tuple[str, YAMLElement]], kvp: Any) -> FSharpList[tuple[str, YAMLElement]]:
                def _arrow1033(__unit: None=None, acc_6: Any=acc_6, kvp: Any=kvp) -> YAMLElement:
                    match_value_3: Any = kvp[1]
                    return string(match_value_3) if (str(type(match_value_3)) == "<class \'str\'>") else (y_bool(match_value_3) if (str(type(match_value_3)) == "<class \'bool\'>") else (int_1(match_value_3) if (str(type(match_value_3)) == "<class \'int\'>") else (float_1(match_value_3) if (str(type(match_value_3)) == "<class \'float\'>") else (match_value_3 if isinstance(match_value_3, YAMLElement) else string(to_string(kvp[1]))))))

                return append(acc_6, singleton((kvp[0], _arrow1033())))

            return fold(folder, with_outputs, md.GetProperties(False))


    return y_map(_arrow1034())


def encode_workflow_description_element(wd: CWLWorkflowDescription) -> YAMLElement:
    base_pairs: FSharpList[tuple[str, YAMLElement]]
    acc_4: FSharpList[tuple[str, YAMLElement]]
    acc_2: FSharpList[tuple[str, YAMLElement]]
    acc: FSharpList[tuple[str, YAMLElement]] = of_array([("cwlVersion", string(wd.CWLVersion)), ("class", string("Workflow"))])
    def _arrow1035(label: str, wd: Any=wd) -> tuple[str, YAMLElement]:
        return encode_label(label)

    pair_opt_1: tuple[str, YAMLElement] | None = map(_arrow1035, wd.Label)
    acc_1: FSharpList[tuple[str, YAMLElement]] = acc
    acc_2 = acc_1 if (pair_opt_1 is None) else append(acc_1, singleton(pair_opt_1))
    def _arrow1036(doc: str, wd: Any=wd) -> tuple[str, YAMLElement]:
        return encode_doc(doc)

    pair_opt_3: tuple[str, YAMLElement] | None = map(_arrow1036, wd.Doc)
    acc_3: FSharpList[tuple[str, YAMLElement]] = acc_2
    acc_4 = acc_3 if (pair_opt_3 is None) else append(acc_3, singleton(pair_opt_3))
    def mapping(intent_1: Array[str], wd: Any=wd) -> tuple[str, YAMLElement]:
        return encode_intent(intent_1)

    def predicate(intent: Array[str], wd: Any=wd) -> bool:
        return len(intent) > 0

    pair_opt_5: tuple[str, YAMLElement] | None = map(mapping, filter(predicate, wd.Intent))
    acc_5: FSharpList[tuple[str, YAMLElement]] = acc_4
    base_pairs = acc_5 if (pair_opt_5 is None) else append(acc_5, singleton(pair_opt_5))
    with_hints: FSharpList[tuple[str, YAMLElement]]
    match_value: Array[HintEntry] | None = wd.Hints
    (pattern_matching_result, h_1) = (None, None)
    if match_value is not None:
        if len(match_value) > 0:
            pattern_matching_result = 0
            h_1 = match_value

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        def _arrow1037(hint: HintEntry, wd: Any=wd) -> YAMLElement:
            return encode_hint_entry(hint)

        with_hints = append(base_pairs, singleton(("hints", YAMLElement(2, of_seq(map_2(_arrow1037, h_1))))))

    elif pattern_matching_result == 1:
        with_hints = base_pairs

    def _arrow1038(__unit: None=None, wd: Any=wd) -> FSharpList[tuple[str, YAMLElement]]:
        match_value_1: Array[Requirement] | None = wd.Requirements
        (pattern_matching_result_1, r_1) = (None, None)
        if match_value_1 is not None:
            if len(match_value_1) > 0:
                pattern_matching_result_1 = 0
                r_1 = match_value_1

            else: 
                pattern_matching_result_1 = 1


        else: 
            pattern_matching_result_1 = 1

        if pattern_matching_result_1 == 0:
            return append(with_hints, singleton(("requirements", YAMLElement(2, of_seq(map_2(encode_requirement, r_1))))))

        elif pattern_matching_result_1 == 1:
            return with_hints


    def mapping_1(i: CWLInput, wd: Any=wd) -> tuple[str, YAMLElement]:
        return encode_cwlinput(i)

    def mapping_2(ws: WorkflowStep, wd: Any=wd) -> tuple[str, YAMLElement]:
        return encode_workflow_step(ws)

    def mapping_3(o: CWLOutput, wd: Any=wd) -> tuple[str, YAMLElement]:
        return encode_cwloutput(o)

    with_outputs: FSharpList[tuple[str, YAMLElement]] = append(append(append(_arrow1038(), singleton(("inputs", y_map(to_list(map_2(mapping_1, wd.Inputs)))))), singleton(("steps", y_map(to_list(map_2(mapping_2, wd.Steps)))))), singleton(("outputs", y_map(to_list(map_2(mapping_3, wd.Outputs))))))
    def _arrow1040(__unit: None=None, wd: Any=wd) -> FSharpList[tuple[str, YAMLElement]]:
        match_value_2: DynamicObj | None = wd.Metadata
        if match_value_2 is None:
            return with_outputs

        else: 
            md: DynamicObj = match_value_2
            def folder(acc_6: FSharpList[tuple[str, YAMLElement]], kvp: Any) -> FSharpList[tuple[str, YAMLElement]]:
                def _arrow1039(__unit: None=None, acc_6: Any=acc_6, kvp: Any=kvp) -> YAMLElement:
                    match_value_3: Any = kvp[1]
                    return string(match_value_3) if (str(type(match_value_3)) == "<class \'str\'>") else (y_bool(match_value_3) if (str(type(match_value_3)) == "<class \'bool\'>") else (int_1(match_value_3) if (str(type(match_value_3)) == "<class \'int\'>") else (float_1(match_value_3) if (str(type(match_value_3)) == "<class \'float\'>") else (match_value_3 if isinstance(match_value_3, YAMLElement) else string(to_string(kvp[1]))))))

                return append(acc_6, singleton((kvp[0], _arrow1039())))

            return fold(folder, with_outputs, md.GetProperties(False))


    return y_map(_arrow1040())


def encode_workflow_step(ws: WorkflowStep) -> tuple[str, YAMLElement]:
    base_pairs: FSharpList[tuple[str, YAMLElement]]
    acc_8: FSharpList[tuple[str, YAMLElement]]
    acc_6: FSharpList[tuple[str, YAMLElement]]
    acc_4: FSharpList[tuple[str, YAMLElement]]
    acc_2: FSharpList[tuple[str, YAMLElement]]
    acc: FSharpList[tuple[str, YAMLElement]] = of_array([("run", encode_workflow_step_run(ws.Run)), ("in", encode_step_inputs(ws.In)), ("out", encode_step_outputs(ws.Out))])
    value_2: str | None = ws.Label
    acc_1: FSharpList[tuple[str, YAMLElement]] = acc
    acc_2 = acc_1 if (value_2 is None) else append(acc_1, singleton(("label", string(value_2))))
    value_5: str | None = ws.Doc
    acc_3: FSharpList[tuple[str, YAMLElement]] = acc_2
    acc_4 = acc_3 if (value_5 is None) else append(acc_3, singleton(("doc", string(value_5))))
    value_7: Array[str] | None = ws.Scatter
    acc_5: FSharpList[tuple[str, YAMLElement]] = acc_4
    acc_6 = acc_5 if (value_7 is None) else append(acc_5, singleton(("scatter", encode_scatter(value_7))))
    value_9: ScatterMethod | None = ws.ScatterMethod
    acc_7: FSharpList[tuple[str, YAMLElement]] = acc_6
    acc_8 = acc_7 if (value_9 is None) else append(acc_7, singleton(("scatterMethod", encode_scatter_method(value_9))))
    value_12: str | None = ws.When_
    acc_9: FSharpList[tuple[str, YAMLElement]] = acc_8
    base_pairs = acc_9 if (value_12 is None) else append(acc_9, singleton(("when", string(value_12))))
    with_hints: FSharpList[tuple[str, YAMLElement]]
    match_value: Array[HintEntry] | None = ws.Hints
    (pattern_matching_result, h_1) = (None, None)
    if match_value is not None:
        if len(match_value) > 0:
            pattern_matching_result = 0
            h_1 = match_value

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        def _arrow1041(hint: HintEntry, ws: Any=ws) -> YAMLElement:
            return encode_hint_entry(hint)

        with_hints = append(base_pairs, singleton(("hints", YAMLElement(2, of_seq(map_2(_arrow1041, h_1))))))

    elif pattern_matching_result == 1:
        with_hints = base_pairs

    with_req: FSharpList[tuple[str, YAMLElement]]
    match_value_1: Array[Requirement] | None = ws.Requirements
    (pattern_matching_result_1, r_1) = (None, None)
    if match_value_1 is not None:
        if len(match_value_1) > 0:
            pattern_matching_result_1 = 0
            r_1 = match_value_1

        else: 
            pattern_matching_result_1 = 1


    else: 
        pattern_matching_result_1 = 1

    if pattern_matching_result_1 == 0:
        def _arrow1042(r_2: Requirement, ws: Any=ws) -> YAMLElement:
            return encode_requirement(r_2)

        with_req = append(with_hints, singleton(("requirements", YAMLElement(2, of_seq(map_2(_arrow1042, r_1))))))

    elif pattern_matching_result_1 == 1:
        with_req = with_hints

    return (ws.Id, y_map(with_req))


def write_yaml(element: YAMLElement) -> str:
    def _arrow1043(c: Config, element: Any=element) -> Config:
        return Config(2, c.Level)

    return write(element, _arrow1043)


def get_object_pairs(element: YAMLElement) -> FSharpList[tuple[str, YAMLElement]]:
    if element.tag == 3:
        def chooser(_arg: YAMLElement, element: Any=element) -> tuple[str, YAMLElement] | None:
            if _arg.tag == 0:
                return (_arg.fields[0].Value, _arg.fields[1])

            else: 
                return None


        return choose(chooser, element.fields[0])

    else: 
        return empty()



def render_top_level_element(base_keys: FSharpList[str], ordered_section_keys: FSharpList[str], element: YAMLElement) -> str:
    def section(pairs: FSharpList[tuple[str, YAMLElement]], base_keys: Any=base_keys, ordered_section_keys: Any=ordered_section_keys, element: Any=element) -> str:
        return trim_end(replace(write_yaml(y_map(pairs)), "\r\n", "\n"), "\n")

    pairs_2: FSharpList[tuple[str, YAMLElement]] = get_object_pairs(element)
    def predicate(tupled_arg: tuple[str, YAMLElement], base_keys: Any=base_keys, ordered_section_keys: Any=ordered_section_keys, element: Any=element) -> bool:
        class ObjectExpr1045:
            @property
            def Equals(self) -> Callable[[str, str], bool]:
                def _arrow1044(x: str, y: str) -> bool:
                    return x == y

                return _arrow1044

            @property
            def GetHashCode(self) -> Callable[[str], int]:
                return string_hash

        return contains(tupled_arg[0], base_keys, ObjectExpr1045())

    base_pairs: FSharpList[tuple[str, YAMLElement]] = filter_1(predicate, pairs_2)
    def chooser(section_key: str, base_keys: Any=base_keys, ordered_section_keys: Any=ordered_section_keys, element: Any=element) -> FSharpList[tuple[str, YAMLElement]] | None:
        def mapping(value: tuple[str, YAMLElement], section_key: Any=section_key) -> FSharpList[tuple[str, YAMLElement]]:
            return singleton(value)

        def predicate_1(tupled_arg_1: tuple[str, YAMLElement], section_key: Any=section_key) -> bool:
            return tupled_arg_1[0] == section_key

        return map(mapping, try_find(predicate_1, pairs_2))

    known_sections: FSharpList[FSharpList[tuple[str, YAMLElement]]] = choose(chooser, ordered_section_keys)
    class ObjectExpr1046:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    reserved_keys: Any = of_list(append(base_keys, ordered_section_keys), ObjectExpr1046())
    def predicate_2(tupled_arg_2: tuple[str, YAMLElement], base_keys: Any=base_keys, ordered_section_keys: Any=ordered_section_keys, element: Any=element) -> bool:
        return not FSharpSet__Contains(reserved_keys, tupled_arg_2[0])

    metadata_pairs: FSharpList[tuple[str, YAMLElement]] = filter_1(predicate_2, pairs_2)
    def merge(acc_mut: FSharpList[str], remaining_mut: FSharpList[str], base_keys: Any=base_keys, ordered_section_keys: Any=ordered_section_keys, element: Any=element) -> FSharpList[str]:
        while True:
            (acc, remaining) = (acc_mut, remaining_mut)
            (pattern_matching_result, a_1, b_1, rest_1, l, rest_2) = (None, None, None, None, None, None)
            if is_empty(remaining):
                pattern_matching_result = 2

            elif not is_empty(tail(remaining)):
                if (trim_start(head(tail(remaining))).find(":") >= 0) if (head(remaining).strip() == "-") else False:
                    pattern_matching_result = 0
                    a_1 = head(remaining)
                    b_1 = head(tail(remaining))
                    rest_1 = tail(tail(remaining))

                else: 
                    pattern_matching_result = 1
                    l = head(remaining)
                    rest_2 = tail(remaining)


            else: 
                pattern_matching_result = 1
                l = head(remaining)
                rest_2 = tail(remaining)

            if pattern_matching_result == 0:
                acc_mut = cons((a_1 + " ") + b_1.strip(), acc)
                remaining_mut = rest_1
                continue

            elif pattern_matching_result == 1:
                acc_mut = cons(l, acc)
                remaining_mut = rest_2
                continue

            elif pattern_matching_result == 2:
                return reverse(acc)

            break

    def _arrow1049(__unit: None=None, base_keys: Any=base_keys, ordered_section_keys: Any=ordered_section_keys, element: Any=element) -> IEnumerable_1[str]:
        def _arrow1048(__unit: None=None) -> IEnumerable_1[str]:
            def _arrow1047(__unit: None=None) -> IEnumerable_1[str]:
                return singleton_1(section(metadata_pairs)) if (length(metadata_pairs) > 0) else empty_1()

            return append_1(map_1(section, known_sections), delay(_arrow1047))

        return append_1(singleton_1(section(base_pairs)) if (length(base_pairs) > 0) else empty_1(), delay(_arrow1048))

    return join("\r\n", merge(empty(), of_array(split(join("\r\n\r\n", to_list(delay(_arrow1049))), ["\r\n"], None, 0))))


def encode_tool_description(td: CWLToolDescription) -> str:
    return render_top_level_element(of_array(["cwlVersion", "class", "label", "doc", "intent"]), of_array(["hints", "requirements", "baseCommand", "inputs", "outputs"]), encode_tool_description_element(td))


def encode_workflow_description(wd: CWLWorkflowDescription) -> str:
    return render_top_level_element(of_array(["cwlVersion", "class", "label", "doc", "intent"]), of_array(["hints", "requirements", "inputs", "steps", "outputs"]), encode_workflow_description_element(wd))


def encode_expression_tool_description(et: CWLExpressionToolDescription) -> str:
    return render_top_level_element(of_array(["cwlVersion", "class", "label", "doc", "intent"]), of_array(["hints", "requirements", "inputs", "outputs", "expression"]), encode_expression_tool_description_element(et))


def encode_operation_description(op: CWLOperationDescription) -> str:
    return render_top_level_element(of_array(["cwlVersion", "class", "label", "doc", "intent"]), of_array(["hints", "requirements", "inputs", "outputs"]), encode_operation_description_element(op))


def encode_processing_unit(pu: CWLProcessingUnit) -> str:
    if pu.tag == 1:
        return encode_workflow_description(pu.fields[0])

    elif pu.tag == 2:
        return encode_expression_tool_description(pu.fields[0])

    elif pu.tag == 3:
        return encode_operation_description(pu.fields[0])

    else: 
        return encode_tool_description(pu.fields[0])



def encode_cwltype_yaml(t: CWLType) -> str:
    if t.tag == 14:
        def mapping(t_1: CWLType, t: Any=t) -> str:
            return encode_cwltype_yaml(t_1)

        return ("[" + join(", ", map_2(mapping, t.fields[0]))) + "]"

    elif t.tag == 11:
        return encode_input_array_schema_yaml(t.fields[0])

    elif t.tag == 12:
        return encode_input_record_schema_yaml(t.fields[0])

    elif t.tag == 13:
        return encode_input_enum_schema_yaml(t.fields[0])

    elif t.tag == 10:
        return "\"null\""

    else: 
        yaml_form: str = write_yaml(encode_cwltype(t))
        return yaml_form.strip()



def encode_input_record_field_yaml(field: InputRecordField) -> str:
    return ((("{name: " + field.Name) + ", type: ") + encode_cwltype_yaml(field.Type)) + "}"


def encode_input_record_schema_yaml(schema: InputRecordSchema) -> str:
    fields_yaml: str
    match_value: Array[InputRecordField] | None = schema.Fields
    (pattern_matching_result, fs_1) = (None, None)
    if match_value is not None:
        if len(match_value) > 0:
            pattern_matching_result = 0
            fs_1 = match_value

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        def mapping(field: InputRecordField, schema: Any=schema) -> str:
            return encode_input_record_field_yaml(field)

        fields_yaml = join(", ", map_2(mapping, fs_1))

    elif pattern_matching_result == 1:
        fields_yaml = ""

    if fields_yaml == "":
        return "{type: record, fields: []}"

    else: 
        return ("{type: record, fields: [" + fields_yaml) + "]}"



def encode_input_enum_schema_yaml(schema: InputEnumSchema) -> str:
    return ("{type: enum, symbols: [" + join(", ", schema.Symbols)) + "]}"


def encode_input_array_schema_yaml(schema: InputArraySchema) -> str:
    return ("{type: array, items: " + encode_cwltype_yaml(schema.Items)) + "}"


def cwl_type_to_yaml_string(t: CWLType) -> str:
    return encode_cwltype_yaml(t)


__all__ = ["_007CPrimitiveType_007CComplexType_007C", "try_get_array_shorthand", "is_complex_type", "y_bool", "y_map", "normalize_doc_string", "encode_schema_salad_string", "normalize_env_value_for_encode", "encode_env_var_requirement_compact_map", "encode_software_requirement_compact_map", "encode_label", "encode_doc", "encode_intent", "encode_cwltype", "encode_input_record_field", "encode_input_record_schema", "encode_input_enum_schema", "encode_input_array_schema", "encode_output_binding", "encode_string_array_or_scalar", "encode_cwloutput", "encode_input_binding", "encode_cwlinput", "encode_schema_def_requirement_type", "encode_requirement", "encode_hint_entry", "encode_source_array", "encode_link_merge_method", "encode_pick_value_method", "encode_scatter_method", "encode_step_input", "encode_step_inputs", "encode_step_output_parameter", "encode_step_outputs", "encode_scatter", "encode_workflow_step_run", "encode_tool_description_element", "encode_expression_tool_description_element", "encode_operation_description_element", "encode_workflow_description_element", "encode_workflow_step", "write_yaml", "get_object_pairs", "render_top_level_element", "encode_tool_description", "encode_workflow_description", "encode_expression_tool_description", "encode_operation_description", "encode_processing_unit", "encode_cwltype_yaml", "encode_input_record_field_yaml", "encode_input_record_schema_yaml", "encode_input_enum_schema_yaml", "encode_input_array_schema_yaml", "cwl_type_to_yaml_string"]

