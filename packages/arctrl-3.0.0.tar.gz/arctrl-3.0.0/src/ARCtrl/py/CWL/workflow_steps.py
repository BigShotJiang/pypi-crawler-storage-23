from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from ..fable_modules.dynamic_obj.dynamic_obj import (DynamicObj, DynamicObj_reflection)
from ..fable_modules.fable_library.option import to_array
from ..fable_modules.fable_library.reflection import (TypeInfo, union_type, string_type, array_type, option_type, bool_type, record_type, obj_type, class_type)
from ..fable_modules.fable_library.seq import (filter, iterate, try_find_index)
from ..fable_modules.fable_library.types import (Array, Union, Record)
from ..fable_modules.yamlicious.yamlicious_types import (YAMLElement, YAMLElement_reflection)
from .requirements import (Requirement, HintEntry)

def _expr760() -> TypeInfo:
    return union_type("ARCtrl.CWL.LinkMergeMethod", [], LinkMergeMethod, lambda: [[], []])


class LinkMergeMethod(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["MergeNested", "MergeFlattened"]

    @property
    def AsCwlString(self, __unit: None=None) -> str:
        this: LinkMergeMethod = self
        return "merge_flattened" if (this.tag == 1) else "merge_nested"

    @staticmethod
    def try_parse(value: str) -> LinkMergeMethod | None:
        return LinkMergeMethod(0) if (value == "merge_nested") else (LinkMergeMethod(1) if (value == "merge_flattened") else None)


LinkMergeMethod_reflection = _expr760

def _expr761() -> TypeInfo:
    return union_type("ARCtrl.CWL.PickValueMethod", [], PickValueMethod, lambda: [[], [], []])


class PickValueMethod(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["FirstNonNull", "TheOnlyNonNull", "AllNonNull"]

    @property
    def AsCwlString(self, __unit: None=None) -> str:
        this: PickValueMethod = self
        if this.tag == 1:
            return "the_only_non_null"

        elif this.tag == 2:
            return "all_non_null"

        else: 
            return "first_non_null"


    @staticmethod
    def try_parse(value: str) -> PickValueMethod | None:
        return PickValueMethod(0) if (value == "first_non_null") else (PickValueMethod(1) if (value == "the_only_non_null") else (PickValueMethod(2) if (value == "all_non_null") else None))


PickValueMethod_reflection = _expr761

def _expr762() -> TypeInfo:
    return union_type("ARCtrl.CWL.ScatterMethod", [], ScatterMethod, lambda: [[], [], []])


class ScatterMethod(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["DotProduct", "NestedCrossProduct", "FlatCrossProduct"]

    @property
    def AsCwlString(self, __unit: None=None) -> str:
        this: ScatterMethod = self
        if this.tag == 1:
            return "nested_crossproduct"

        elif this.tag == 2:
            return "flat_crossproduct"

        else: 
            return "dotproduct"


    @staticmethod
    def try_parse(value: str) -> ScatterMethod | None:
        return ScatterMethod(0) if (value == "dotproduct") else (ScatterMethod(1) if (value == "nested_crossproduct") else (ScatterMethod(2) if (value == "flat_crossproduct") else None))


ScatterMethod_reflection = _expr762

def _expr763() -> TypeInfo:
    return record_type("ARCtrl.CWL.StepInput", [], StepInput, lambda: [("Id", string_type), ("Source", option_type(array_type(string_type))), ("DefaultValue", option_type(YAMLElement_reflection())), ("ValueFrom", option_type(string_type)), ("LinkMerge", option_type(LinkMergeMethod_reflection())), ("PickValue", option_type(PickValueMethod_reflection())), ("Doc", option_type(string_type)), ("LoadContents", option_type(bool_type)), ("LoadListing", option_type(string_type)), ("Label", option_type(string_type))])


@dataclass(eq = False, repr = False, slots = True)
class StepInput(Record):
    Id: str
    Source: Array[str] | None
    DefaultValue: YAMLElement | None
    ValueFrom: str | None
    LinkMerge: LinkMergeMethod | None
    PickValue: PickValueMethod | None
    Doc: str | None
    LoadContents: bool | None
    LoadListing: str | None
    Label: str | None
    @staticmethod
    def create(id: str, source: Array[str] | None=None, default_value: YAMLElement | None=None, value_from: str | None=None, link_merge: LinkMergeMethod | None=None, pick_value: PickValueMethod | None=None, doc: str | None=None, load_contents: bool | None=None, load_listing: str | None=None, label: str | None=None) -> StepInput:
        return StepInput(id, source, default_value, value_from, link_merge, pick_value, doc, load_contents, load_listing, label)

    @staticmethod
    def update_at(index: int, f: Callable[[StepInput], StepInput], inputs: Array[StepInput]) -> None:
        if True if (index < 0) else (index >= len(inputs)):
            raise Exception(((("StepInput index " + str(index)) + " is out of range.") + "\\nParameter name: ") + "index")

        inputs[index] = f(inputs[index])


StepInput_reflection = _expr763

def _expr764() -> TypeInfo:
    return record_type("ARCtrl.CWL.StepOutputParameter", [], StepOutputParameter, lambda: [("Id", string_type)])


@dataclass(eq = False, repr = False, slots = True)
class StepOutputParameter(Record):
    Id: str
    @staticmethod
    def create(id: str) -> StepOutputParameter:
        return StepOutputParameter(id)


StepOutputParameter_reflection = _expr764

def _expr765() -> TypeInfo:
    return union_type("ARCtrl.CWL.StepOutput", [], StepOutput, lambda: [[("Item", string_type)], [("Item", StepOutputParameter_reflection())]])


class StepOutput(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["StepOutputString", "StepOutputRecord"]


StepOutput_reflection = _expr765

def _expr766() -> TypeInfo:
    return union_type("ARCtrl.CWL.WorkflowStepRun", [], WorkflowStepRun, lambda: [[("Item", string_type)], [("Item", obj_type)], [("Item", obj_type)], [("Item", obj_type)], [("Item", obj_type)]])


class WorkflowStepRun(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["RunString", "RunCommandLineTool", "RunWorkflow", "RunExpressionTool", "RunOperation"]


WorkflowStepRun_reflection = _expr766

def _expr767() -> TypeInfo:
    return class_type("ARCtrl.CWL.WorkflowStep", None, WorkflowStep, DynamicObj_reflection())


class WorkflowStep(DynamicObj):
    def __init__(self, id: str, in_: Array[StepInput], out_: Array[StepOutput], run: WorkflowStepRun, label: str | None=None, doc: str | None=None, scatter: Array[str] | None=None, scatter_method: ScatterMethod | None=None, when_: str | None=None, requirements: Array[Requirement] | None=None, hints: Array[HintEntry] | None=None) -> None:
        super().__init__()
        self._id: str = id
        self._in: Array[StepInput] = in_
        self._out: Array[StepOutput] = out_
        self._run: WorkflowStepRun = run
        self._label: str | None = label
        self._doc: str | None = doc
        self._scatter: Array[str] | None = scatter
        self._scatterMethod: ScatterMethod | None = scatter_method
        self._when: str | None = when_
        self._requirements: Array[Requirement] | None = requirements
        self._hints: Array[HintEntry] | None = hints

    @property
    def Id(self, __unit: None=None) -> str:
        this: WorkflowStep = self
        return this._id

    @Id.setter
    def Id(self, id: str) -> None:
        this: WorkflowStep = self
        this._id = id

    @property
    def In(self, __unit: None=None) -> Array[StepInput]:
        this: WorkflowStep = self
        return this._in

    @In.setter
    def In(self, in_: Array[StepInput]) -> None:
        this: WorkflowStep = self
        this._in = in_

    @property
    def Out(self, __unit: None=None) -> Array[StepOutput]:
        this: WorkflowStep = self
        return this._out

    @Out.setter
    def Out(self, out_: Array[StepOutput]) -> None:
        this: WorkflowStep = self
        this._out = out_

    @property
    def Run(self, __unit: None=None) -> WorkflowStepRun:
        this: WorkflowStep = self
        return this._run

    @Run.setter
    def Run(self, run: WorkflowStepRun) -> None:
        this: WorkflowStep = self
        this._run = run

    @property
    def Label(self, __unit: None=None) -> str | None:
        this: WorkflowStep = self
        return this._label

    @Label.setter
    def Label(self, label: str | None=None) -> None:
        this: WorkflowStep = self
        this._label = label

    @property
    def Doc(self, __unit: None=None) -> str | None:
        this: WorkflowStep = self
        return this._doc

    @Doc.setter
    def Doc(self, doc: str | None=None) -> None:
        this: WorkflowStep = self
        this._doc = doc

    @property
    def Scatter(self, __unit: None=None) -> Array[str] | None:
        this: WorkflowStep = self
        return this._scatter

    @Scatter.setter
    def Scatter(self, scatter: Array[str] | None=None) -> None:
        this: WorkflowStep = self
        this._scatter = scatter

    @property
    def ScatterMethod(self, __unit: None=None) -> ScatterMethod | None:
        this: WorkflowStep = self
        return this._scatterMethod

    @ScatterMethod.setter
    def ScatterMethod(self, scatter_method: ScatterMethod | None=None) -> None:
        this: WorkflowStep = self
        this._scatterMethod = scatter_method

    @property
    def When_(self, __unit: None=None) -> str | None:
        this: WorkflowStep = self
        return this._when

    @When_.setter
    def When_(self, when_: str | None=None) -> None:
        this: WorkflowStep = self
        this._when = when_

    @property
    def Requirements(self, __unit: None=None) -> Array[Requirement] | None:
        this: WorkflowStep = self
        return this._requirements

    @Requirements.setter
    def Requirements(self, requirements: Array[Requirement] | None=None) -> None:
        this: WorkflowStep = self
        this._requirements = requirements

    @property
    def Hints(self, __unit: None=None) -> Array[HintEntry] | None:
        this: WorkflowStep = self
        return this._hints

    @Hints.setter
    def Hints(self, hints: Array[HintEntry] | None=None) -> None:
        this: WorkflowStep = self
        this._hints = hints

    @staticmethod
    def from_run_path(id: str, in_: Array[StepInput], out_: Array[StepOutput], run_path: str, label: str | None=None, doc: str | None=None, scatter: Array[str] | None=None, scatter_method: ScatterMethod | None=None, when_: str | None=None, requirements: Array[Requirement] | None=None, hints: Array[HintEntry] | None=None) -> WorkflowStep:
        return WorkflowStep(id, in_, out_, WorkflowStepRun(0, run_path), label, doc, scatter, scatter_method, when_, requirements, hints)

    @staticmethod
    def update_input_at(index: int, f: Callable[[StepInput], StepInput], step: WorkflowStep) -> None:
        inputs: Array[StepInput] = step.In
        StepInput.update_at(index, f, inputs)

    @staticmethod
    def add_input(input: StepInput, step: WorkflowStep) -> None:
        (step.In.append(input))

    @staticmethod
    def remove_inputs_by_id(id: str, step: WorkflowStep) -> None:
        def predicate(i: StepInput) -> bool:
            return i.Id != id

        remaining: Array[StepInput] = list(filter(predicate, step.In))
        step.In = remaining

    @staticmethod
    def update_input_by_id(id: str, f: Callable[[StepInput], StepInput], step: WorkflowStep) -> None:
        def action(i_1: int) -> None:
            inputs: Array[StepInput] = step.In
            StepInput.update_at(i_1, f, inputs)

        def predicate(i: StepInput) -> bool:
            return i.Id == id

        iterate(action, to_array(try_find_index(predicate, step.In)))


WorkflowStep_reflection = _expr767

def WorkflowStep__ctor_Z76380C57(id: str, in_: Array[StepInput], out_: Array[StepOutput], run: WorkflowStepRun, label: str | None=None, doc: str | None=None, scatter: Array[str] | None=None, scatter_method: ScatterMethod | None=None, when_: str | None=None, requirements: Array[Requirement] | None=None, hints: Array[HintEntry] | None=None) -> WorkflowStep:
    return WorkflowStep(id, in_, out_, run, label, doc, scatter, scatter_method, when_, requirements, hints)


__all__ = ["LinkMergeMethod_reflection", "PickValueMethod_reflection", "ScatterMethod_reflection", "StepInput_reflection", "StepOutputParameter_reflection", "StepOutput_reflection", "WorkflowStepRun_reflection", "WorkflowStep_reflection"]

