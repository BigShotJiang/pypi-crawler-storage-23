from __future__ import annotations
from collections.abc import Callable
from typing import (Any, TypeVar)
from ..fable_modules.dynamic_obj.dynamic_obj import DynamicObj
from ..fable_modules.dynamic_obj.dyn_obj import (set_property, set_optional_property)
from ..fable_modules.fable_library.array_ import filter
from ..fable_modules.fable_library.double import try_parse as try_parse_1
from ..fable_modules.fable_library.list import (choose, is_empty, iterate, map, empty, head, tail, FSharpList, exists, try_pick, singleton as singleton_1, cons, of_array, try_head)
from ..fable_modules.fable_library.long import try_parse
from ..fable_modules.fable_library.map_util import get_item_from_dict
from ..fable_modules.fable_library.option import (map as map_1, default_arg, some, bind)
from ..fable_modules.fable_library.seq import (to_array, delay, collect, append, empty as empty_1, singleton, head as head_1, map as map_2, length)
from ..fable_modules.fable_library.string_ import (replace, trim_end, join, starts_with_exact, trim_start, to_text, printf, interpolate, ends_with_exact, substring, trim)
from ..fable_modules.fable_library.types import (Array, int64, FSharpRef)
from ..fable_modules.fable_library.util import (get_enumerator, dispose, ignore, Lazy, IEnumerable_1)
from ..fable_modules.yamlicious.decode import (read, object, IGetters, IOptionalGetter, string, IRequiredGetter, bool_1, resizearray, int_1)
from ..fable_modules.yamlicious.yamlicious_types import (YAMLElement, YAMLContent)
from .cwlprocessing_unit import (CWLProcessingUnit, WorkflowStepRunOps_fromWorkflow, WorkflowStepRunOps_fromExpressionTool, WorkflowStepRunOps_fromOperation, WorkflowStepRunOps_fromTool)
from .cwltypes import (SchemaSaladString, SchemaSaladStringModule_toDirectiveString, DirentInstance, CWLType, FileInstance__ctor, FileInstance, DirectoryInstance__ctor, DirectoryInstance, InputArraySchema, InputRecordField, InputRecordSchema, InputEnumSchema, SoftwarePackage, SchemaDefRequirementType)
from .expression_tool_description import CWLExpressionToolDescription
from .inputs import (InputBinding, CWLInput)
from .operation_description import CWLOperationDescription
from .outputs import (OutputBinding, CWLOutput, OutputSource)
from .parameter_reference import CWLParameterReference
from .requirements import (InitialWorkDirEntry, DockerRequirement_create_Z14898805, DockerRequirement, EnvironmentDef, LoadListingEnum_tryParse_Z721C83C5, LoadListingEnum, LoadListingRequirementValue, ResourceRequirementInstance__ctor_D76FC00, ResourceRequirementInstance, Requirement, WorkReuseRequirementValue, NetworkAccessRequirementValue, InplaceUpdateRequirementValue, ToolTimeLimitValue, InlineJavascriptRequirementValue, HintUnknownValue, HintEntry)
from .tool_description import CWLToolDescription
from .workflow_description import CWLWorkflowDescription
from .workflow_steps import (LinkMergeMethod, PickValueMethod, ScatterMethod, StepInput, StepOutput, StepOutputParameter, WorkflowStepRun, WorkflowStep)

__B = TypeVar("__B")

__A = TypeVar("__A")

def ResizeArray_map(f: Callable[[__A], __B], a: Array[Any]) -> Array[Any]:
    b: Array[__B] = []
    enumerator: Any = get_enumerator(a)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            i: __A = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            (b.append(f(i)))

    finally: 
        dispose(enumerator)

    return b


def Decode_normalizeYamlInput(yaml: str) -> str:
    normalized: str = "" if (yaml is None) else replace(yaml, "\r\n", "\n")
    lines: Array[str] = normalized.split("\n")
    return trim_end(join("\n", lines[1:len(lines)] if (starts_with_exact(lines[0], "#!") if (len(lines) > 0) else False) else lines))


def Decode_removeFullLineComments(yaml: str) -> str:
    def predicate(line: str, yaml: Any=yaml) -> bool:
        return not starts_with_exact(trim_start(line), "#")

    return join("\n", filter(predicate, yaml.split("\n")))


def Decode_removeYamlComments(yaml_element: YAMLElement) -> YAMLElement:
    if yaml_element.tag == 3:
        def chooser(element: YAMLElement, yaml_element: Any=yaml_element) -> YAMLElement | None:
            if element.tag == 4:
                return None

            else: 
                return Decode_removeYamlComments(element)


        return YAMLElement(3, choose(chooser, yaml_element.fields[0]))

    elif yaml_element.tag == 2:
        def chooser_1(element_1: YAMLElement, yaml_element: Any=yaml_element) -> YAMLElement | None:
            match_value: YAMLElement = Decode_removeYamlComments(element_1)
            (pattern_matching_result, other_1) = (None, None)
            if match_value.tag == 4:
                pattern_matching_result = 0

            elif match_value.tag == 3:
                if is_empty(match_value.fields[0]):
                    pattern_matching_result = 1

                else: 
                    pattern_matching_result = 2
                    other_1 = match_value


            else: 
                pattern_matching_result = 2
                other_1 = match_value

            if pattern_matching_result == 0:
                return None

            elif pattern_matching_result == 1:
                return None

            elif pattern_matching_result == 2:
                return other_1


        return YAMLElement(2, choose(chooser_1, yaml_element.fields[0]))

    elif yaml_element.tag == 0:
        return YAMLElement(0, yaml_element.fields[0], Decode_removeYamlComments(yaml_element.fields[1]))

    else: 
        return yaml_element



def Decode_isRecoverableDecodingError(ex: Exception) -> bool:
    (pattern_matching_result,) = (None,)
    pattern_matching_result = 0
    if pattern_matching_result == 0:
        return True

    elif pattern_matching_result == 1:
        return True

    elif pattern_matching_result == 2:
        return True

    elif pattern_matching_result == 3:
        return True

    elif pattern_matching_result == 4:
        return True

    elif pattern_matching_result == 5:
        return True

    elif pattern_matching_result == 6:
        return False



def Decode_readSanitizedYaml(yaml: str) -> YAMLElement:
    normalized: str = Decode_normalizeYamlInput(yaml)
    def try_read(text: str, yaml: Any=yaml) -> YAMLElement:
        return Decode_removeYamlComments(read(text))

    try: 
        return try_read(normalized)

    except Exception as match_value:
        if Decode_isRecoverableDecodingError(match_value):
            return try_read(Decode_removeFullLineComments(normalized))

        else: 
            raise match_value




def Decode_overflowDecoder(dyn_obj: DynamicObj, dict_1: Any) -> DynamicObj:
    enumerator: Any = get_enumerator(dict_1)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            e: Any = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            match_value: YAMLElement = e[1]
            (pattern_matching_result, v, s) = (None, None, None)
            if match_value.tag == 3:
                if not is_empty(match_value.fields[0]):
                    if head(match_value.fields[0]).tag == 1:
                        if is_empty(tail(match_value.fields[0])):
                            pattern_matching_result = 0
                            v = head(match_value.fields[0]).fields[0]

                        else: 
                            pattern_matching_result = 2


                    elif head(match_value.fields[0]).tag == 2:
                        if is_empty(tail(match_value.fields[0])):
                            pattern_matching_result = 1
                            s = head(match_value.fields[0]).fields[0]

                        else: 
                            pattern_matching_result = 2


                    else: 
                        pattern_matching_result = 2


                else: 
                    pattern_matching_result = 2


            else: 
                pattern_matching_result = 2

            if pattern_matching_result == 0:
                set_property(e[0], v.Value, dyn_obj)

            elif pattern_matching_result == 1:
                new_dyn_obj: DynamicObj = DynamicObj()
                def action(x: DynamicObj) -> None:
                    set_property(e[0], x, dyn_obj)

                def mapping(arg: YAMLElement) -> DynamicObj:
                    def getter(get: IGetters, arg: Any=arg) -> Any:
                        return get.Overflow.FieldList(empty())

                    return Decode_overflowDecoder(new_dyn_obj, object(getter, arg))

                iterate(action, map(mapping, s))

            elif pattern_matching_result == 2:
                set_property(e[0], e[1], dyn_obj)


    finally: 
        dispose(enumerator)

    return dyn_obj


def Decode_decodeSchemaSaladString(y_ele: YAMLElement) -> SchemaSaladString:
    (pattern_matching_result, v, c, v_1) = (None, None, None, None)
    if y_ele.tag == 1:
        pattern_matching_result = 0
        v = y_ele.fields[0]

    elif y_ele.tag == 3:
        if not is_empty(y_ele.fields[0]):
            if head(y_ele.fields[0]).tag == 1:
                if is_empty(tail(y_ele.fields[0])):
                    pattern_matching_result = 0
                    v = head(y_ele.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 2


            elif head(y_ele.fields[0]).tag == 0:
                if head(y_ele.fields[0]).fields[1].tag == 1:
                    if is_empty(tail(y_ele.fields[0])):
                        pattern_matching_result = 1
                        c = head(y_ele.fields[0]).fields[0]
                        v_1 = head(y_ele.fields[0]).fields[1].fields[0]

                    else: 
                        pattern_matching_result = 2


                elif head(y_ele.fields[0]).fields[1].tag == 3:
                    if not is_empty(head(y_ele.fields[0]).fields[1].fields[0]):
                        if head(head(y_ele.fields[0]).fields[1].fields[0]).tag == 1:
                            if is_empty(tail(head(y_ele.fields[0]).fields[1].fields[0])):
                                if is_empty(tail(y_ele.fields[0])):
                                    pattern_matching_result = 1
                                    c = head(y_ele.fields[0]).fields[0]
                                    v_1 = head(head(y_ele.fields[0]).fields[1].fields[0]).fields[0]

                                else: 
                                    pattern_matching_result = 2


                            else: 
                                pattern_matching_result = 2


                        else: 
                            pattern_matching_result = 2


                    else: 
                        pattern_matching_result = 2


                else: 
                    pattern_matching_result = 2


            else: 
                pattern_matching_result = 2


        else: 
            pattern_matching_result = 2


    else: 
        pattern_matching_result = 2

    if pattern_matching_result == 0:
        return SchemaSaladString(0, v.Value)

    elif pattern_matching_result == 1:
        match_value: str = c.Value
        if match_value == "$include":
            return SchemaSaladString(1, v_1.Value)

        elif match_value == "$import":
            return SchemaSaladString(2, v_1.Value)

        else: 
            return SchemaSaladString(0, to_text(printf("%s: %s"))(c.Value)(v_1.Value))


    elif pattern_matching_result == 2:
        raise Exception(to_text(interpolate("Unexpected YAMLElement format in decodeSchemaSaladString: %A%P()", [y_ele])))



def Decode_decodeStringOrExpression(y_ele: YAMLElement) -> str:
    return SchemaSaladStringModule_toDirectiveString(Decode_decodeSchemaSaladString(y_ele))


def _arrow819(value_1: YAMLElement) -> OutputBinding:
    def getter(get: IGetters) -> OutputBinding:
        def _arrow818(__unit: None=None, get: Any=get) -> str | None:
            object_arg: IOptionalGetter = get.Optional
            return object_arg.Field("glob", string)

        return OutputBinding(_arrow818())

    return object(getter, value_1)


Decode_outputBindingGlobDecoder: Callable[[YAMLElement], OutputBinding] = _arrow819

def _arrow820(value: YAMLElement) -> OutputBinding | None:
    def getter(get: IGetters) -> OutputBinding | None:
        object_arg: IOptionalGetter = get.Optional
        return object_arg.Field("outputBinding", Decode_outputBindingGlobDecoder)

    return object(getter, value)


Decode_outputBindingDecoder: Callable[[YAMLElement], OutputBinding | None] = _arrow820

def Decode_decodeStringArrayOrScalar(value: YAMLElement) -> Array[str]:
    (pattern_matching_result, items) = (None, None)
    if value.tag == 3:
        if not is_empty(value.fields[0]):
            if head(value.fields[0]).tag == 2:
                if is_empty(tail(value.fields[0])):
                    pattern_matching_result = 0
                    items = head(value.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    elif value.tag == 2:
        pattern_matching_result = 0
        items = value.fields[0]

    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        def _arrow821(y_ele: YAMLElement, value: Any=value) -> str:
            return Decode_decodeStringOrExpression(y_ele)

        return list(map(_arrow821, items))

    elif pattern_matching_result == 1:
        return [Decode_decodeStringOrExpression(value)]



def _arrow822(value_1: YAMLElement) -> Array[str] | None:
    def getter(get: IGetters) -> Array[str] | None:
        object_arg: IOptionalGetter = get.Optional
        def arg_1(value: YAMLElement, get: Any=get) -> Array[str]:
            return Decode_decodeStringArrayOrScalar(value)

        return object_arg.Field("outputSource", arg_1)

    return object(getter, value_1)


Decode_outputSourceDecoder: Callable[[YAMLElement], Array[str] | None] = _arrow822

def _arrow826(value_1: YAMLElement) -> CWLType:
    def getter(get: IGetters) -> CWLType:
        def _arrow823(__unit: None=None, get: Any=get) -> SchemaSaladString:
            object_arg: IRequiredGetter = get.Required
            return object_arg.Field("entry", Decode_decodeSchemaSaladString)

        def _arrow824(__unit: None=None, get: Any=get) -> SchemaSaladString | None:
            object_arg_1: IOptionalGetter = get.Optional
            return object_arg_1.Field("entryname", Decode_decodeSchemaSaladString)

        def _arrow825(__unit: None=None, get: Any=get) -> bool | None:
            object_arg_2: IOptionalGetter = get.Optional
            return object_arg_2.Field("writable", bool_1)

        return CWLType(2, DirentInstance(_arrow823(), _arrow824(), _arrow825()))

    return object(getter, value_1)


Decode_direntDecoder: Callable[[YAMLElement], CWLType] = _arrow826

def Decode_initialWorkDirEntryDecoder(value: YAMLElement) -> InitialWorkDirEntry:
    if value.tag == 3:
        mappings: FSharpList[YAMLElement] = value.fields[0]
        def predicate(_arg: YAMLElement, value: Any=value) -> bool:
            (pattern_matching_result,) = (None,)
            if _arg.tag == 0:
                if _arg.fields[0].Value == "entry":
                    pattern_matching_result = 0

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1

            if pattern_matching_result == 0:
                return True

            elif pattern_matching_result == 1:
                return False


        if exists(predicate, mappings):
            match_value: CWLType = Decode_direntDecoder(value)
            if match_value.tag == 2:
                return InitialWorkDirEntry(0, match_value.fields[0])

            else: 
                raise Exception("Unexpected InitialWorkDir Dirent decoding result.")


        else: 
            def chooser(_arg_1: YAMLElement, value: Any=value) -> str | None:
                (pattern_matching_result_1, k_4, v_2, k_5, v_3) = (None, None, None, None, None)
                if _arg_1.tag == 0:
                    if _arg_1.fields[1].tag == 3:
                        if not is_empty(_arg_1.fields[1].fields[0]):
                            if head(_arg_1.fields[1].fields[0]).tag == 1:
                                if is_empty(tail(_arg_1.fields[1].fields[0])):
                                    if _arg_1.fields[0].Value == "class":
                                        pattern_matching_result_1 = 0
                                        k_4 = _arg_1.fields[0]
                                        v_2 = head(_arg_1.fields[1].fields[0]).fields[0]

                                    else: 
                                        pattern_matching_result_1 = 2


                                else: 
                                    pattern_matching_result_1 = 2


                            else: 
                                pattern_matching_result_1 = 2


                        else: 
                            pattern_matching_result_1 = 2


                    elif _arg_1.fields[1].tag == 1:
                        if _arg_1.fields[0].Value == "class":
                            pattern_matching_result_1 = 1
                            k_5 = _arg_1.fields[0]
                            v_3 = _arg_1.fields[1].fields[0]

                        else: 
                            pattern_matching_result_1 = 2


                    else: 
                        pattern_matching_result_1 = 2


                else: 
                    pattern_matching_result_1 = 2

                if pattern_matching_result_1 == 0:
                    return v_2.Value

                elif pattern_matching_result_1 == 1:
                    return v_3.Value

                elif pattern_matching_result_1 == 2:
                    return None


            class_value: str | None = try_pick(chooser, mappings)
            (pattern_matching_result_2,) = (None,)
            if class_value is not None:
                if class_value == "File":
                    pattern_matching_result_2 = 0

                elif class_value == "Directory":
                    pattern_matching_result_2 = 1

                else: 
                    pattern_matching_result_2 = 2


            else: 
                pattern_matching_result_2 = 2

            if pattern_matching_result_2 == 0:
                def _arrow827(__unit: None=None, value: Any=value) -> FileInstance:
                    file_instance: FileInstance = FileInstance__ctor()
                    def getter(get: IGetters) -> DynamicObj:
                        return Decode_overflowDecoder(file_instance, get.Overflow.FieldList(empty()))

                    ignore(object(getter, value))
                    return file_instance

                return InitialWorkDirEntry(2, _arrow827())

            elif pattern_matching_result_2 == 1:
                def _arrow828(__unit: None=None, value: Any=value) -> DirectoryInstance:
                    directory_instance: DirectoryInstance = DirectoryInstance__ctor()
                    def getter_1(get_1: IGetters) -> DynamicObj:
                        return Decode_overflowDecoder(directory_instance, get_1.Overflow.FieldList(empty()))

                    ignore(object(getter_1, value))
                    return directory_instance

                return InitialWorkDirEntry(3, _arrow828())

            elif pattern_matching_result_2 == 2:
                return InitialWorkDirEntry(1, Decode_decodeSchemaSaladString(value))



    elif value.tag == 1:
        return InitialWorkDirEntry(1, Decode_decodeSchemaSaladString(value))

    else: 
        raise Exception(to_text(interpolate("Invalid InitialWorkDir listing entry: %A%P()", [value])))



def Decode_cwlSimpleTypeFromString(s: str) -> CWLType:
    if s == "File":
        return CWLType(0, FileInstance__ctor())

    elif s == "Directory":
        return CWLType(1, DirectoryInstance__ctor())

    elif s == "string":
        return CWLType(3)

    elif s == "int":
        return CWLType(4)

    elif s == "long":
        return CWLType(5)

    elif s == "float":
        return CWLType(6)

    elif s == "double":
        return CWLType(7)

    elif s == "boolean":
        return CWLType(8)

    elif s == "stdout":
        return CWLType(9)

    elif s == "null":
        return CWLType(10)

    else: 
        raise Exception(("Invalid CWL simple type: " + s) + "")



def Decode_parseArrayShorthand(type_str: str) -> CWLType | None:
    if ends_with_exact(type_str, "[]"):
        inner_type: str = substring(type_str, 0, len(type_str) - 2)
        match_value: CWLType | None = Decode_parseArrayShorthand(inner_type)
        if match_value is None:
            try: 
                return CWLType(11, InputArraySchema(Decode_cwlSimpleTypeFromString(inner_type), None, None, None))

            except Exception as match_value_1:
                if Decode_isRecoverableDecodingError(match_value_1):
                    return None

                else: 
                    raise match_value_1



        else: 
            return CWLType(11, InputArraySchema(match_value, None, None, None))


    else: 
        return None



def input_array_schema_decoder_0040261(__unit: None=None) -> Callable[[YAMLElement], InputArraySchema]:
    def _arrow833(value_3: YAMLElement) -> InputArraySchema:
        def getter(get: IGetters) -> InputArraySchema:
            def _arrow829(__unit: None=None, get: Any=get) -> YAMLElement:
                object_arg: IRequiredGetter = get.Required
                def arg_1(x: YAMLElement) -> YAMLElement:
                    return x

                return object_arg.Field("items", arg_1)

            def _arrow830(__unit: None=None, get: Any=get) -> str | None:
                object_arg_1: IOptionalGetter = get.Optional
                return object_arg_1.Field("label", string)

            def _arrow831(__unit: None=None, get: Any=get) -> str | None:
                object_arg_2: IOptionalGetter = get.Optional
                return object_arg_2.Field("doc", string)

            def _arrow832(__unit: None=None, get: Any=get) -> str | None:
                object_arg_3: IOptionalGetter = get.Optional
                return object_arg_3.Field("name", string)

            return InputArraySchema(Decode_cwlTypeDecoder_0027(_arrow829()), _arrow830(), _arrow831(), _arrow832())

        return object(getter, value_3)

    return _arrow833


input_array_schema_decoder_0040261_002d1: Any = Lazy(input_array_schema_decoder_0040261)

def input_record_field_decoder_0040275(__unit: None=None) -> Callable[[YAMLElement], InputRecordField]:
    def _arrow838(value_3: YAMLElement) -> InputRecordField:
        def getter(get: IGetters) -> InputRecordField:
            def _arrow834(__unit: None=None, get: Any=get) -> str:
                object_arg: IRequiredGetter = get.Required
                return object_arg.Field("name", string)

            def _arrow835(__unit: None=None, get: Any=get) -> YAMLElement:
                object_arg_1: IRequiredGetter = get.Required
                def arg_3(x: YAMLElement) -> YAMLElement:
                    return x

                return object_arg_1.Field("type", arg_3)

            def _arrow836(__unit: None=None, get: Any=get) -> str | None:
                object_arg_2: IOptionalGetter = get.Optional
                return object_arg_2.Field("doc", string)

            def _arrow837(__unit: None=None, get: Any=get) -> str | None:
                object_arg_3: IOptionalGetter = get.Optional
                return object_arg_3.Field("label", string)

            return InputRecordField(_arrow834(), Decode_cwlTypeDecoder_0027(_arrow835()), _arrow836(), _arrow837())

        return object(getter, value_3)

    return _arrow838


input_record_field_decoder_0040275_002d1: Any = Lazy(input_record_field_decoder_0040275)

def input_record_schema_decoder_0040314(__unit: None=None) -> Callable[[YAMLElement], InputRecordSchema]:
    def _arrow844(value_3: YAMLElement) -> InputRecordSchema:
        def getter(get: IGetters) -> InputRecordSchema:
            def _arrow839(__unit: None=None, get: Any=get) -> Array[InputRecordField] | None:
                fields_element: YAMLElement | None
                object_arg: IOptionalGetter = get.Optional
                def arg_1(x: YAMLElement) -> YAMLElement:
                    return x

                fields_element = object_arg.Field("fields", arg_1)
                (pattern_matching_result, element) = (None, None)
                if fields_element is None:
                    pattern_matching_result = 2

                elif fields_element.tag == 3:
                    if is_empty(fields_element.fields[0]):
                        pattern_matching_result = 0

                    else: 
                        pattern_matching_result = 1
                        element = fields_element


                else: 
                    pattern_matching_result = 1
                    element = fields_element

                if pattern_matching_result == 0:
                    return []

                elif pattern_matching_result == 1:
                    match_value: Array[InputRecordField] | None = Decode_tryDecodeFieldsAsArray(element)
                    return Decode_tryDecodeFieldsAsMap(element) if (match_value is None) else match_value

                elif pattern_matching_result == 2:
                    return None


            def _arrow840(__unit: None=None, get: Any=get) -> str | None:
                object_arg_1: IOptionalGetter = get.Optional
                return object_arg_1.Field("label", string)

            def _arrow842(__unit: None=None, get: Any=get) -> str | None:
                object_arg_2: IOptionalGetter = get.Optional
                return object_arg_2.Field("doc", string)

            def _arrow843(__unit: None=None, get: Any=get) -> str | None:
                object_arg_3: IOptionalGetter = get.Optional
                return object_arg_3.Field("name", string)

            return InputRecordSchema(_arrow839(), _arrow840(), _arrow842(), _arrow843())

        return object(getter, value_3)

    return _arrow844


input_record_schema_decoder_0040314_002d1: Any = Lazy(input_record_schema_decoder_0040314)

def input_enum_schema_decoder_0040341(__unit: None=None) -> Callable[[YAMLElement], InputEnumSchema]:
    def _arrow852(value_5: YAMLElement) -> InputEnumSchema:
        def getter(get: IGetters) -> InputEnumSchema:
            def _arrow846(__unit: None=None, get: Any=get) -> Array[str]:
                object_arg: IRequiredGetter = get.Required
                def arg_1(value: YAMLElement) -> Array[str]:
                    def _arrow845(value_1: YAMLElement, value: Any=value) -> str:
                        return string(value_1)

                    return resizearray(_arrow845, value)

                return object_arg.Field("symbols", arg_1)

            def _arrow847(__unit: None=None, get: Any=get) -> str | None:
                object_arg_1: IOptionalGetter = get.Optional
                return object_arg_1.Field("label", string)

            def _arrow849(__unit: None=None, get: Any=get) -> str | None:
                object_arg_2: IOptionalGetter = get.Optional
                return object_arg_2.Field("doc", string)

            def _arrow851(__unit: None=None, get: Any=get) -> str | None:
                object_arg_3: IOptionalGetter = get.Optional
                return object_arg_3.Field("name", string)

            return InputEnumSchema(_arrow846(), _arrow847(), _arrow849(), _arrow851())

        return object(getter, value_5)

    return _arrow852


input_enum_schema_decoder_0040341_002d1: Any = Lazy(input_enum_schema_decoder_0040341)

Decode_inputArraySchemaDecoder: Callable[[YAMLElement], InputArraySchema] = input_array_schema_decoder_0040261_002d1.Value

Decode_inputRecordFieldDecoder: Callable[[YAMLElement], InputRecordField] = input_record_field_decoder_0040275_002d1.Value

def Decode_tryDecodeFieldsAsArray(element: YAMLElement) -> Array[InputRecordField] | None:
    try: 
        return resizearray(input_record_field_decoder_0040275_002d1.Value, element)

    except Exception as match_value:
        if Decode_isRecoverableDecodingError(match_value):
            return None

        else: 
            raise match_value




def Decode_tryDecodeFieldsAsMap(element: YAMLElement) -> Array[InputRecordField] | None:
    try: 
        fields: Array[InputRecordField] = []
        def _arrow853(get2: IGetters) -> Any:
            return get2.Overflow.FieldList(empty())

        enumerator: Any = get_enumerator(object(_arrow853, element))
        try: 
            while enumerator.System_Collections_IEnumerator_MoveNext():
                kvp: Any = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
                field_type: CWLType = Decode_cwlTypeDecoder_0027(kvp[1])
                (fields.append(InputRecordField(kvp[0], field_type, None, None)))

        finally: 
            dispose(enumerator)

        return fields

    except Exception as match_value:
        if Decode_isRecoverableDecodingError(match_value):
            return None

        else: 
            raise match_value




Decode_inputRecordSchemaDecoder: Callable[[YAMLElement], InputRecordSchema] = input_record_schema_decoder_0040314_002d1.Value

Decode_inputEnumSchemaDecoder: Callable[[YAMLElement], InputEnumSchema] = input_enum_schema_decoder_0040341_002d1.Value

def Decode_cwlTypeDecoder_0027(element: YAMLElement) -> CWLType:
    def parse_type_string(type_str: str, element: Any=element) -> CWLType:
        pattern_input: tuple[str, bool] = ((replace(type_str, "?", ""), True)) if ends_with_exact(type_str, "?") else ((type_str, False))
        stripped: str = pattern_input[0]
        base_type: CWLType
        match_value: CWLType | None = Decode_parseArrayShorthand(stripped)
        base_type = Decode_cwlSimpleTypeFromString(stripped) if (match_value is None) else match_value
        if pattern_input[1]:
            return CWLType(14, [CWLType(10), base_type])

        else: 
            return base_type


    (pattern_matching_result, v, items) = (None, None, None)
    if element.tag == 1:
        pattern_matching_result = 0
        v = element.fields[0]

    elif element.tag == 3:
        if not is_empty(element.fields[0]):
            if head(element.fields[0]).tag == 1:
                if is_empty(tail(element.fields[0])):
                    pattern_matching_result = 0
                    v = head(element.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 2


            else: 
                pattern_matching_result = 2


        else: 
            pattern_matching_result = 2


    elif element.tag == 2:
        pattern_matching_result = 1
        items = element.fields[0]

    else: 
        pattern_matching_result = 3

    if pattern_matching_result == 0:
        return parse_type_string(v.Value)

    elif pattern_matching_result == 1:
        def mapping(element_1: YAMLElement, element: Any=element) -> CWLType:
            return Decode_cwlTypeDecoder_0027(element_1)

        return CWLType(14, list(map(mapping, items)))

    elif pattern_matching_result == 2:
        def _arrow855(get: IGetters, element: Any=element) -> CWLType:
            type_field: YAMLElement | None
            object_arg: IOptionalGetter = get.Optional
            def arg_1(x: YAMLElement) -> YAMLElement:
                return x

            type_field = object_arg.Field("type", arg_1)
            (pattern_matching_result_1, v_1) = (None, None)
            if type_field is not None:
                if type_field.tag == 3:
                    if not is_empty(type_field.fields[0]):
                        if head(type_field.fields[0]).tag == 1:
                            if is_empty(tail(type_field.fields[0])):
                                pattern_matching_result_1 = 0
                                v_1 = head(type_field.fields[0]).fields[0]

                            else: 
                                pattern_matching_result_1 = 1


                        else: 
                            pattern_matching_result_1 = 1


                    else: 
                        pattern_matching_result_1 = 1


                else: 
                    pattern_matching_result_1 = 2


            else: 
                pattern_matching_result_1 = 2

            if pattern_matching_result_1 == 0:
                match_value_1: str = v_1.Value
                return CWLType(12, input_record_schema_decoder_0040314_002d1.Value(element)) if (match_value_1 == "record") else (CWLType(13, input_enum_schema_decoder_0040341_002d1.Value(element)) if (match_value_1 == "enum") else (CWLType(11, input_array_schema_decoder_0040261_002d1.Value(element)) if (match_value_1 == "array") else parse_type_string(match_value_1)))

            elif pattern_matching_result_1 == 1:
                def _arrow854(__unit: None=None) -> YAMLElement:
                    object_arg_1: IRequiredGetter = get.Required
                    def arg_3(x_1: YAMLElement) -> YAMLElement:
                        return x_1

                    return object_arg_1.Field("type", arg_3)

                return Decode_cwlTypeDecoder_0027(_arrow854())

            elif pattern_matching_result_1 == 2:
                raise Exception("Unexpected type format in cwlTypeDecoder\'")


        return object(_arrow855, element)

    elif pattern_matching_result == 3:
        raise Exception("Unexpected YAMLElement in cwlTypeDecoder\'")



def Decode_cwlTypeStringMatcher(t: str, get: IGetters) -> tuple[CWLType, bool]:
    pattern_input: tuple[bool, str] = ((True, replace(t, "?", ""))) if ends_with_exact(t, "?") else ((False, t))
    optional: bool = pattern_input[0]
    new_t: str = pattern_input[1]
    cwl_type: CWLType
    match_value: CWLType | None = Decode_parseArrayShorthand(new_t)
    if match_value is None:
        if new_t == "File":
            cwl_type = CWLType(0, FileInstance__ctor())

        elif new_t == "Directory":
            cwl_type = CWLType(1, DirectoryInstance__ctor())

        elif new_t == "Dirent":
            object_arg: IRequiredGetter = get.Required
            cwl_type = object_arg.Field("listing", Decode_direntDecoder)

        elif new_t == "string":
            cwl_type = CWLType(3)

        elif new_t == "int":
            cwl_type = CWLType(4)

        elif new_t == "long":
            cwl_type = CWLType(5)

        elif new_t == "float":
            cwl_type = CWLType(6)

        elif new_t == "double":
            cwl_type = CWLType(7)

        elif new_t == "boolean":
            cwl_type = CWLType(8)

        elif new_t == "stdout":
            cwl_type = CWLType(9)

        elif new_t == "null":
            cwl_type = CWLType(10)

        else: 
            raise Exception("Invalid CWL type")


    else: 
        cwl_type = match_value

    return (CWLType(14, [CWLType(10), cwl_type]) if optional else cwl_type, optional)


def _arrow857(value_1: YAMLElement) -> tuple[CWLType, bool]:
    def getter(get: IGetters) -> tuple[CWLType, bool]:
        cwl_type: str | None
        object_arg: IRequiredGetter = get.Required
        def arg_1(value: YAMLElement, get: Any=get) -> str | None:
            (pattern_matching_result, v) = (None, None)
            if value.tag == 1:
                pattern_matching_result = 0
                v = value.fields[0]

            elif value.tag == 3:
                if not is_empty(value.fields[0]):
                    if head(value.fields[0]).tag == 1:
                        if is_empty(tail(value.fields[0])):
                            pattern_matching_result = 0
                            v = head(value.fields[0]).fields[0]

                        else: 
                            pattern_matching_result = 1


                    else: 
                        pattern_matching_result = 1


                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 2

            if pattern_matching_result == 0:
                return v.Value

            elif pattern_matching_result == 1:
                return None

            elif pattern_matching_result == 2:
                raise Exception("Unexpected YAMLElement in cwlTypeDecoder")


        cwl_type = object_arg.Field("type", arg_1)
        if cwl_type is None:
            def _arrow856(__unit: None=None, get: Any=get) -> CWLType:
                object_arg_1: IRequiredGetter = get.Required
                return object_arg_1.Field("type", Decode_cwlTypeDecoder_0027)

            return (_arrow856(), False)

        else: 
            return Decode_cwlTypeStringMatcher(cwl_type, get)


    return object(getter, value_1)


Decode_cwlTypeDecoder: Callable[[YAMLElement], tuple[CWLType, bool]] = _arrow857

def _arrow864(value_1: YAMLElement) -> Array[CWLOutput]:
    def getter(get: IGetters) -> Array[CWLOutput]:
        dict_1: Any = get.Overflow.FieldList(empty())
        def _arrow863(__unit: None=None, get: Any=get) -> IEnumerable_1[CWLOutput]:
            def _arrow862(key: str) -> IEnumerable_1[CWLOutput]:
                value: YAMLElement = get_item_from_dict(dict_1, key)
                output_binding: OutputBinding | None = Decode_outputBindingDecoder(value)
                output_source_values: Array[str] | None = Decode_outputSourceDecoder(value)
                output: CWLOutput = CWLOutput(key, (((Decode_cwlTypeStringMatcher(head(value.fields[0]).fields[0].Value, get)[0] if is_empty(tail(value.fields[0])) else Decode_cwlTypeDecoder(value)[0]) if (head(value.fields[0]).tag == 1) else Decode_cwlTypeDecoder(value)[0]) if (not is_empty(value.fields[0])) else Decode_cwlTypeDecoder(value)[0]) if (value.tag == 3) else Decode_cwlTypeDecoder(value)[0])
                def _expr858():
                    set_optional_property("outputBinding", output_binding, output)
                    return empty_1()

                def _arrow861(__unit: None=None) -> IEnumerable_1[CWLOutput]:
                    def _arrow859(__unit: None=None) -> IEnumerable_1[CWLOutput]:
                        match_value: Array[str] | None = output_source_values
                        (pattern_matching_result, values_2, values_3) = (None, None, None)
                        if match_value is not None:
                            if len(match_value) > 1:
                                pattern_matching_result = 0
                                values_2 = match_value

                            elif len(match_value) == 1:
                                pattern_matching_result = 1
                                values_3 = match_value

                            else: 
                                pattern_matching_result = 2


                        else: 
                            pattern_matching_result = 2

                        if pattern_matching_result == 0:
                            output.OutputSource = OutputSource(1, values_2)
                            return empty_1()

                        elif pattern_matching_result == 1:
                            output.OutputSource = OutputSource(0, values_3[0])
                            return empty_1()

                        elif pattern_matching_result == 2:
                            return empty_1()


                    def _arrow860(__unit: None=None) -> IEnumerable_1[CWLOutput]:
                        return singleton(output)

                    return append(_arrow859(), delay(_arrow860))

                return append(_expr858() if (output_binding is not None) else empty_1(), delay(_arrow861))

            return collect(_arrow862, dict_1.keys())

        return list(to_array(delay(_arrow863)))

    return object(getter, value_1)


Decode_outputArrayDecoder: Callable[[YAMLElement], Array[CWLOutput]] = _arrow864

def _arrow865(value: YAMLElement) -> Array[CWLOutput]:
    def getter(get: IGetters) -> Array[CWLOutput]:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("outputs", Decode_outputArrayDecoder)

    return object(getter, value)


Decode_outputsDecoder: Callable[[YAMLElement], Array[CWLOutput]] = _arrow865

def Decode_dockerRequirementDecoder(get: IGetters) -> DockerRequirement:
    def _arrow866(y_ele: YAMLElement, get: Any=get) -> SchemaSaladString:
        return Decode_decodeSchemaSaladString(y_ele)

    def _arrow867(__unit: None=None, get: Any=get) -> YAMLElement | None:
        object_arg: IOptionalGetter = get.Optional
        def arg_1(x: YAMLElement) -> YAMLElement:
            return x

        return object_arg.Field("dockerFile", arg_1)

    docker_file: SchemaSaladString | None = map_1(_arrow866, _arrow867())
    def _arrow868(__unit: None=None, get: Any=get) -> str | None:
        object_arg_1: IOptionalGetter = get.Optional
        return object_arg_1.Field("dockerPull", string)

    def _arrow869(__unit: None=None, get: Any=get) -> str | None:
        object_arg_2: IOptionalGetter = get.Optional
        return object_arg_2.Field("dockerImageId", string)

    def _arrow870(__unit: None=None, get: Any=get) -> str | None:
        object_arg_3: IOptionalGetter = get.Optional
        return object_arg_3.Field("dockerLoad", string)

    def _arrow871(__unit: None=None, get: Any=get) -> str | None:
        object_arg_4: IOptionalGetter = get.Optional
        return object_arg_4.Field("dockerImport", string)

    def _arrow872(__unit: None=None, get: Any=get) -> str | None:
        object_arg_5: IOptionalGetter = get.Optional
        return object_arg_5.Field("dockerOutputDirectory", string)

    return DockerRequirement_create_Z14898805(_arrow868(), None, docker_file, _arrow869(), _arrow870(), _arrow871(), _arrow872())


def Decode_envVarRequirementDecoder(get: IGetters) -> Array[EnvironmentDef]:
    env_def_element: YAMLElement
    _arg: YAMLElement
    object_arg: IRequiredGetter = get.Required
    def arg_1(x: YAMLElement, get: Any=get) -> YAMLElement:
        return x

    _arg = object_arg.Field("envDef", arg_1)
    (pattern_matching_result, sequence, mappings, other) = (None, None, None, None)
    if _arg.tag == 3:
        if not is_empty(_arg.fields[0]):
            if head(_arg.fields[0]).tag == 2:
                if is_empty(tail(_arg.fields[0])):
                    pattern_matching_result = 0
                    sequence = head(_arg.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 2
                    other = _arg


            elif head(_arg.fields[0]).tag == 3:
                if is_empty(tail(_arg.fields[0])):
                    pattern_matching_result = 1
                    mappings = head(_arg.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 2
                    other = _arg


            else: 
                pattern_matching_result = 2
                other = _arg


        else: 
            pattern_matching_result = 2
            other = _arg


    else: 
        pattern_matching_result = 2
        other = _arg

    if pattern_matching_result == 0:
        env_def_element = YAMLElement(2, sequence)

    elif pattern_matching_result == 1:
        env_def_element = YAMLElement(3, mappings)

    elif pattern_matching_result == 2:
        env_def_element = other

    if env_def_element.tag == 2:
        def _arrow875(value_3: YAMLElement, get: Any=get) -> EnvironmentDef:
            def getter(get2: IGetters) -> EnvironmentDef:
                def _arrow873(__unit: None=None, get2: Any=get2) -> str:
                    object_arg_1: IRequiredGetter = get2.Required
                    return object_arg_1.Field("envName", string)

                def _arrow874(__unit: None=None, get2: Any=get2) -> str:
                    object_arg_2: IRequiredGetter = get2.Required
                    return object_arg_2.Field("envValue", string)

                return EnvironmentDef(_arrow873(), _arrow874())

            return object(getter, value_3)

        return resizearray(_arrow875, env_def_element)

    elif env_def_element.tag == 3:
        def chooser(_arg_2: YAMLElement, get: Any=get) -> EnvironmentDef | None:
            if _arg_2.tag == 0:
                def _arrow876(__unit: None=None, _arg_2: Any=_arg_2) -> str:
                    _arg_1: YAMLElement = _arg_2.fields[1]
                    (pattern_matching_result_1, value, other_1) = (None, None, None)
                    if _arg_1.tag == 1:
                        pattern_matching_result_1 = 0
                        value = _arg_1.fields[0]

                    elif _arg_1.tag == 3:
                        if not is_empty(_arg_1.fields[0]):
                            if head(_arg_1.fields[0]).tag == 1:
                                if is_empty(tail(_arg_1.fields[0])):
                                    pattern_matching_result_1 = 0
                                    value = head(_arg_1.fields[0]).fields[0]

                                else: 
                                    pattern_matching_result_1 = 1
                                    other_1 = _arg_1


                            else: 
                                pattern_matching_result_1 = 1
                                other_1 = _arg_1


                        else: 
                            pattern_matching_result_1 = 1
                            other_1 = _arg_1


                    else: 
                        pattern_matching_result_1 = 1
                        other_1 = _arg_1

                    if pattern_matching_result_1 == 0:
                        return trim(value.Value, "\"")

                    elif pattern_matching_result_1 == 1:
                        return Decode_decodeStringOrExpression(other_1)


                return EnvironmentDef(_arg_2.fields[0].Value, _arrow876())

            else: 
                return None


        return list(choose(chooser, env_def_element.fields[0]))

    else: 
        raise Exception("Invalid envDef format. Expected array or map.")



def Decode_softwareRequirementDecoder(get: IGetters) -> Array[SoftwarePackage]:
    def normalize_collection_element(_arg: YAMLElement, get: Any=get) -> YAMLElement:
        (pattern_matching_result, sequence, mappings, other) = (None, None, None, None)
        if _arg.tag == 3:
            if not is_empty(_arg.fields[0]):
                if head(_arg.fields[0]).tag == 2:
                    if is_empty(tail(_arg.fields[0])):
                        pattern_matching_result = 0
                        sequence = head(_arg.fields[0]).fields[0]

                    else: 
                        pattern_matching_result = 2
                        other = _arg


                elif head(_arg.fields[0]).tag == 3:
                    if is_empty(tail(_arg.fields[0])):
                        pattern_matching_result = 1
                        mappings = head(_arg.fields[0]).fields[0]

                    else: 
                        pattern_matching_result = 2
                        other = _arg


                else: 
                    pattern_matching_result = 2
                    other = _arg


            else: 
                pattern_matching_result = 2
                other = _arg


        else: 
            pattern_matching_result = 2
            other = _arg

        if pattern_matching_result == 0:
            return YAMLElement(2, sequence)

        elif pattern_matching_result == 1:
            return YAMLElement(3, mappings)

        elif pattern_matching_result == 2:
            return other


    def _arrow877(__unit: None=None, get: Any=get) -> YAMLElement:
        object_arg: IRequiredGetter = get.Required
        def arg_1(x: YAMLElement) -> YAMLElement:
            return x

        return object_arg.Field("packages", arg_1)

    packages_element: YAMLElement = normalize_collection_element(_arrow877())
    def decode_specs_array(element: YAMLElement, get: Any=get) -> Array[str]:
        def _arrow878(y_ele: YAMLElement, element: Any=element) -> str:
            return Decode_decodeStringOrExpression(y_ele)

        return resizearray(_arrow878, normalize_collection_element(element))

    if packages_element.tag == 2:
        def _arrow884(value_5: YAMLElement, get: Any=get) -> SoftwarePackage:
            def getter(get2: IGetters) -> SoftwarePackage:
                def _arrow879(__unit: None=None, get2: Any=get2) -> str:
                    object_arg_1: IRequiredGetter = get2.Required
                    return object_arg_1.Field("package", string)

                def _arrow881(__unit: None=None, get2: Any=get2) -> Array[str] | None:
                    object_arg_2: IOptionalGetter = get2.Optional
                    def arg_5(value_1: YAMLElement) -> Array[str]:
                        def _arrow880(value_2: YAMLElement, value_1: Any=value_1) -> str:
                            return string(value_2)

                        return resizearray(_arrow880, value_1)

                    return object_arg_2.Field("version", arg_5)

                def _arrow883(__unit: None=None, get2: Any=get2) -> Array[str] | None:
                    object_arg_3: IOptionalGetter = get2.Optional
                    def arg_7(value_3: YAMLElement) -> Array[str]:
                        def _arrow882(value_4: YAMLElement, value_3: Any=value_3) -> str:
                            return string(value_4)

                        return resizearray(_arrow882, value_3)

                    return object_arg_3.Field("specs", arg_7)

                return SoftwarePackage(_arrow879(), _arrow881(), _arrow883())

            return object(getter, value_5)

        return resizearray(_arrow884, packages_element)

    elif packages_element.tag == 3:
        def chooser_2(_arg_3: YAMLElement, get: Any=get) -> SoftwarePackage | None:
            if _arg_3.tag == 0:
                def _arrow885(__unit: None=None, _arg_3: Any=_arg_3) -> SoftwarePackage:
                    package_name: str = _arg_3.fields[0].Value
                    package_value: YAMLElement = _arg_3.fields[1]
                    normalized_package_value: YAMLElement = normalize_collection_element(package_value)
                    def chooser(_arg_1: YAMLElement) -> Array[str] | None:
                        (pattern_matching_result_1, k_1, v_1) = (None, None, None)
                        if _arg_1.tag == 0:
                            if _arg_1.fields[0].Value == "version":
                                pattern_matching_result_1 = 0
                                k_1 = _arg_1.fields[0]
                                v_1 = _arg_1.fields[1]

                            else: 
                                pattern_matching_result_1 = 1


                        else: 
                            pattern_matching_result_1 = 1

                        if pattern_matching_result_1 == 0:
                            return decode_specs_array(v_1)

                        elif pattern_matching_result_1 == 1:
                            return None


                    def chooser_1(_arg_2: YAMLElement) -> Array[str] | None:
                        (pattern_matching_result_2, k_3, v_3) = (None, None, None)
                        if _arg_2.tag == 0:
                            if _arg_2.fields[0].Value == "specs":
                                pattern_matching_result_2 = 0
                                k_3 = _arg_2.fields[0]
                                v_3 = _arg_2.fields[1]

                            else: 
                                pattern_matching_result_2 = 1


                        else: 
                            pattern_matching_result_2 = 1

                        if pattern_matching_result_2 == 0:
                            return decode_specs_array(v_3)

                        elif pattern_matching_result_2 == 1:
                            return None


                    return (SoftwarePackage(package_name, None, None) if is_empty(normalized_package_value.fields[0]) else SoftwarePackage(package_name, try_pick(chooser, normalized_package_value.fields[0]), try_pick(chooser_1, normalized_package_value.fields[0]))) if (normalized_package_value.tag == 3) else (SoftwarePackage(package_name, None, decode_specs_array(normalized_package_value)) if (normalized_package_value.tag == 2) else SoftwarePackage(package_name, None, [Decode_decodeStringOrExpression(package_value)]))

                return _arrow885()

            else: 
                return None


        return list(choose(chooser_2, packages_element.fields[0]))

    else: 
        raise Exception("Invalid packages format. Expected array or map.")



def Decode_initialWorkDirRequirementDecoder(get: IGetters) -> Array[InitialWorkDirEntry]:
    listing_element: YAMLElement
    object_arg: IRequiredGetter = get.Required
    def arg_1(x: YAMLElement, get: Any=get) -> YAMLElement:
        return x

    listing_element = object_arg.Field("listing", arg_1)
    (pattern_matching_result,) = (None,)
    if listing_element.tag == 3:
        if not is_empty(listing_element.fields[0]):
            if head(listing_element.fields[0]).tag == 2:
                if is_empty(tail(listing_element.fields[0])):
                    pattern_matching_result = 0

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    elif listing_element.tag == 2:
        pattern_matching_result = 0

    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        def _arrow886(value: YAMLElement, get: Any=get) -> InitialWorkDirEntry:
            return Decode_initialWorkDirEntryDecoder(value)

        return resizearray(_arrow886, listing_element)

    elif pattern_matching_result == 1:
        return [Decode_initialWorkDirEntryDecoder(listing_element)]



def Decode_loadListingRequirementDecoder(get: IGetters) -> LoadListingRequirementValue:
    def _arrow887(__unit: None=None, get: Any=get) -> str | None:
        object_arg: IOptionalGetter = get.Optional
        return object_arg.Field("loadListing", string)

    load_listing_value: str = default_arg(_arrow887(), "no_listing")
    def _arrow888(__unit: None=None, get: Any=get) -> LoadListingEnum:
        match_value: LoadListingEnum | None = LoadListingEnum_tryParse_Z721C83C5(load_listing_value)
        if match_value is None:
            raise Exception(("Invalid loadListing value \'" + load_listing_value) + "\'. Expected one of: no_listing, shallow_listing, deep_listing.")

        else: 
            return match_value


    return LoadListingRequirementValue(_arrow888())


def Decode_decodeResourceScalar(element: YAMLElement) -> Any:
    match_value: str | None
    _arg: YAMLElement = element
    (pattern_matching_result, value) = (None, None)
    if _arg.tag == 1:
        pattern_matching_result = 0
        value = _arg.fields[0]

    elif _arg.tag == 3:
        if not is_empty(_arg.fields[0]):
            if head(_arg.fields[0]).tag == 1:
                if is_empty(tail(_arg.fields[0])):
                    pattern_matching_result = 0
                    value = head(_arg.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        match_value = value.Value

    elif pattern_matching_result == 1:
        match_value = None

    if match_value is None:
        return Decode_decodeStringOrExpression(element)

    else: 
        scalar_value: str = match_value
        match_value_1: tuple[bool, int64]
        out_arg: int64 = int64(0)
        def _arrow889(__unit: None=None, element: Any=element) -> int64:
            return out_arg

        def _arrow890(v: int64, element: Any=element) -> None:
            nonlocal out_arg
            out_arg = v

        match_value_1 = (try_parse(scalar_value, 7, False, 64, FSharpRef(_arrow889, _arrow890)), out_arg)
        if match_value_1[0]:
            return match_value_1[1]

        else: 
            match_value_2: tuple[bool, float]
            out_arg_1: float = 0.0
            def _arrow891(__unit: None=None, element: Any=element) -> float:
                return out_arg_1

            def _arrow892(v_1: float, element: Any=element) -> None:
                nonlocal out_arg_1
                out_arg_1 = v_1

            match_value_2 = (try_parse_1(scalar_value, FSharpRef(_arrow891, _arrow892)), out_arg_1)
            if match_value_2[0]:
                return match_value_2[1]

            else: 
                return Decode_decodeStringOrExpression(element)





def Decode_optionalResourceField(get: IGetters, field_name: str) -> Any | None:
    def _arrow893(element: YAMLElement, get: Any=get, field_name: Any=field_name) -> Any:
        return Decode_decodeResourceScalar(element)

    def _arrow894(__unit: None=None, get: Any=get, field_name: Any=field_name) -> YAMLElement | None:
        object_arg: IOptionalGetter = get.Optional
        def arg_1(x: YAMLElement) -> YAMLElement:
            return x

        return object_arg.Field(field_name, arg_1)

    return map_1(_arrow893, _arrow894())


def Decode_resourceRequirementDecoder(get: IGetters) -> ResourceRequirementInstance:
    return ResourceRequirementInstance__ctor_D76FC00(some(Decode_optionalResourceField(get, "coresMin")), some(Decode_optionalResourceField(get, "coresMax")), some(Decode_optionalResourceField(get, "ramMin")), some(Decode_optionalResourceField(get, "ramMax")), some(Decode_optionalResourceField(get, "tmpdirMin")), some(Decode_optionalResourceField(get, "tmpdirMax")), some(Decode_optionalResourceField(get, "outdirMin")), some(Decode_optionalResourceField(get, "outdirMax")))


def Decode_schemaDefRequirementTypeDecoder(value: YAMLElement) -> SchemaDefRequirementType:
    def _arrow895(get: IGetters, value: Any=value) -> Any:
        return get.Overflow.FieldList(empty())

    dict_1: Any = object(_arrow895, value)
    if "name" in dict_1:
        return SchemaDefRequirementType(Decode_decodeStringOrExpression(get_item_from_dict(dict_1, "name")), Decode_cwlTypeDecoder_0027(value))

    else: 
        if len(dict_1) == 0:
            raise Exception("SchemaDefRequirement entry cannot be empty.")

        kv: Any = head_1(dict_1)
        return SchemaDefRequirementType(kv[0], Decode_cwlTypeDecoder_0027(kv[1]))



def Decode_schemaDefRequirementDecoder(get: IGetters) -> Array[SchemaDefRequirementType]:
    object_arg: IRequiredGetter = get.Required
    def arg_1(value: YAMLElement, get: Any=get) -> Array[SchemaDefRequirementType]:
        def _arrow896(value_1: YAMLElement, value: Any=value) -> SchemaDefRequirementType:
            return Decode_schemaDefRequirementTypeDecoder(value_1)

        return resizearray(_arrow896, value)

    return object_arg.Field("types", arg_1)


def Decode_tryDecodeBoolScalar(element: YAMLElement) -> bool | None:
    (pattern_matching_result, value) = (None, None)
    if element.tag == 1:
        pattern_matching_result = 0
        value = element.fields[0]

    elif element.tag == 3:
        if not is_empty(element.fields[0]):
            if head(element.fields[0]).tag == 1:
                if is_empty(tail(element.fields[0])):
                    pattern_matching_result = 0
                    value = head(element.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        match_value: str = value.Value.strip().lower()
        if match_value == "true":
            return True

        elif match_value == "false":
            return False

        else: 
            return None


    elif pattern_matching_result == 1:
        return None



def Decode_workReuseRequirementDecoder(get: IGetters) -> Requirement:
    match_value: YAMLElement | None
    object_arg: IOptionalGetter = get.Optional
    def arg_1(x: YAMLElement, get: Any=get) -> YAMLElement:
        return x

    match_value = object_arg.Field("enableReuse", arg_1)
    if match_value is not None:
        value: YAMLElement = match_value
        match_value_1: bool | None = Decode_tryDecodeBoolScalar(value)
        if match_value_1 is None:
            return Requirement(10, Decode_decodeStringOrExpression(value))

        else: 
            return Requirement(9, WorkReuseRequirementValue(match_value_1))


    else: 
        return Requirement(9, WorkReuseRequirementValue(True))



def Decode_networkAccessRequirementDecoder(get: IGetters) -> Requirement:
    match_value: YAMLElement | None
    object_arg: IOptionalGetter = get.Optional
    def arg_1(x: YAMLElement, get: Any=get) -> YAMLElement:
        return x

    match_value = object_arg.Field("networkAccess", arg_1)
    if match_value is not None:
        value: YAMLElement = match_value
        match_value_1: bool | None = Decode_tryDecodeBoolScalar(value)
        if match_value_1 is None:
            return Requirement(12, Decode_decodeStringOrExpression(value))

        else: 
            return Requirement(11, NetworkAccessRequirementValue(match_value_1))


    else: 
        return Requirement(11, NetworkAccessRequirementValue(True))



def Decode_inplaceUpdateRequirementDecoder(get: IGetters) -> InplaceUpdateRequirementValue:
    def _arrow897(__unit: None=None, get: Any=get) -> bool | None:
        object_arg: IOptionalGetter = get.Optional
        return object_arg.Field("inplaceUpdate", bool_1)

    return InplaceUpdateRequirementValue(default_arg(_arrow897(), True))


def Decode_toolTimeLimitRequirementDecoder(get: IGetters) -> ToolTimeLimitValue:
    time_limit_element: YAMLElement
    object_arg: IRequiredGetter = get.Required
    def arg_1(x: YAMLElement, get: Any=get) -> YAMLElement:
        return x

    time_limit_element = object_arg.Field("timelimit", arg_1)
    try_get_scalar_string: str | None = time_limit_element.fields[0].Value if (time_limit_element.tag == 1) else ((((head(time_limit_element.fields[0]).fields[0].Value if is_empty(tail(time_limit_element.fields[0])) else None) if (head(time_limit_element.fields[0]).tag == 1) else None) if (not is_empty(time_limit_element.fields[0])) else None) if (time_limit_element.tag == 3) else None)
    if try_get_scalar_string is None:
        return ToolTimeLimitValue(1, Decode_decodeStringOrExpression(time_limit_element))

    else: 
        match_value: tuple[bool, int64]
        out_arg: int64 = int64(0)
        def _arrow898(__unit: None=None, get: Any=get) -> int64:
            return out_arg

        def _arrow899(v: int64, get: Any=get) -> None:
            nonlocal out_arg
            out_arg = v

        match_value = (try_parse(try_get_scalar_string, 7, False, 64, FSharpRef(_arrow898, _arrow899)), out_arg)
        if match_value[0]:
            if match_value[1] >= int64(0):
                return ToolTimeLimitValue(0, match_value[1])

            else: 
                raise Exception("ToolTimeLimit timelimit must be non-negative.")


        else: 
            return ToolTimeLimitValue(1, Decode_decodeStringOrExpression(time_limit_element))




def Decode_inlineJavascriptRequirementDecoder(get: IGetters) -> InlineJavascriptRequirementValue:
    def _arrow900(__unit: None=None, get: Any=get) -> Array[str] | None:
        object_arg: IOptionalGetter = get.Optional
        return object_arg.Field("expressionLib", Decode_decodeStringArrayOrScalar)

    return InlineJavascriptRequirementValue(_arrow900())


def Decode_requirementFromTypeName(cls: str, get: IGetters) -> Requirement:
    (pattern_matching_result,) = (None,)
    if cls == "InlineJavascriptRequirement":
        pattern_matching_result = 0

    elif cls == "SchemaDefRequirement":
        pattern_matching_result = 1

    elif cls == "DockerRequirement":
        pattern_matching_result = 2

    elif cls == "SoftwareRequirement":
        pattern_matching_result = 3

    elif cls == "LoadListingRequirement":
        pattern_matching_result = 4

    elif cls == "InitialWorkDirRequirement":
        pattern_matching_result = 5

    elif cls == "EnvVarRequirement":
        pattern_matching_result = 6

    elif cls == "ShellCommandRequirement":
        pattern_matching_result = 7

    elif cls == "ResourceRequirement":
        pattern_matching_result = 8

    elif cls == "WorkReuse":
        pattern_matching_result = 9

    elif cls == "WorkReuseRequirement":
        pattern_matching_result = 9

    elif cls == "NetworkAccess":
        pattern_matching_result = 10

    elif cls == "NetworkAccessRequirement":
        pattern_matching_result = 10

    elif cls == "InplaceUpdateRequirement":
        pattern_matching_result = 11

    elif cls == "InplaceUpdate":
        pattern_matching_result = 11

    elif cls == "ToolTimeLimit":
        pattern_matching_result = 12

    elif cls == "ToolTimeLimitRequirement":
        pattern_matching_result = 12

    elif cls == "SubworkflowFeatureRequirement":
        pattern_matching_result = 13

    elif cls == "ScatterFeatureRequirement":
        pattern_matching_result = 14

    elif cls == "MultipleInputFeatureRequirement":
        pattern_matching_result = 15

    elif cls == "StepInputExpressionRequirement":
        pattern_matching_result = 16

    else: 
        pattern_matching_result = 17

    if pattern_matching_result == 0:
        return Requirement(0, Decode_inlineJavascriptRequirementDecoder(get))

    elif pattern_matching_result == 1:
        return Requirement(1, Decode_schemaDefRequirementDecoder(get))

    elif pattern_matching_result == 2:
        return Requirement(2, Decode_dockerRequirementDecoder(get))

    elif pattern_matching_result == 3:
        return Requirement(3, Decode_softwareRequirementDecoder(get))

    elif pattern_matching_result == 4:
        return Requirement(4, Decode_loadListingRequirementDecoder(get))

    elif pattern_matching_result == 5:
        return Requirement(5, Decode_initialWorkDirRequirementDecoder(get))

    elif pattern_matching_result == 6:
        return Requirement(6, Decode_envVarRequirementDecoder(get))

    elif pattern_matching_result == 7:
        return Requirement(7)

    elif pattern_matching_result == 8:
        return Requirement(8, Decode_resourceRequirementDecoder(get))

    elif pattern_matching_result == 9:
        return Decode_workReuseRequirementDecoder(get)

    elif pattern_matching_result == 10:
        return Decode_networkAccessRequirementDecoder(get)

    elif pattern_matching_result == 11:
        return Requirement(13, Decode_inplaceUpdateRequirementDecoder(get))

    elif pattern_matching_result == 12:
        return Requirement(14, Decode_toolTimeLimitRequirementDecoder(get))

    elif pattern_matching_result == 13:
        return Requirement(15)

    elif pattern_matching_result == 14:
        return Requirement(16)

    elif pattern_matching_result == 15:
        return Requirement(17)

    elif pattern_matching_result == 16:
        return Requirement(18)

    elif pattern_matching_result == 17:
        raise Exception(("Invalid or unsupported requirement class: " + cls) + "")



def Decode_requirementArrayDecoder(y_ele: YAMLElement) -> Array[Requirement]:
    (pattern_matching_result, items, other) = (None, None, None)
    if y_ele.tag == 3:
        if not is_empty(y_ele.fields[0]):
            if head(y_ele.fields[0]).tag == 2:
                if is_empty(tail(y_ele.fields[0])):
                    pattern_matching_result = 0
                    items = head(y_ele.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 2
        other = y_ele

    if pattern_matching_result == 0:
        def decode_single_requirement_object(ele: YAMLElement, y_ele: Any=y_ele) -> Requirement:
            def _arrow902(get: IGetters, ele: Any=ele) -> Requirement:
                def _arrow901(__unit: None=None) -> str:
                    object_arg: IRequiredGetter = get.Required
                    return object_arg.Field("class", string)

                return Decode_requirementFromTypeName(_arrow901(), get)

            return object(_arrow902, ele)

        return list(map(decode_single_requirement_object, items))

    elif pattern_matching_result == 1:
        def _arrow904(get_1: IGetters, y_ele: Any=y_ele) -> Array[Requirement]:
            def mapping(kv: Any) -> Requirement:
                def _arrow903(get_2: IGetters, kv: Any=kv) -> Requirement:
                    return Decode_requirementFromTypeName(kv[0], get_2)

                return object(_arrow903, kv[1])

            return list(map_2(mapping, get_1.Overflow.FieldList(empty())))

        return object(_arrow904, y_ele)

    elif pattern_matching_result == 2:
        raise Exception(("Invalid CWL requirements syntax: " + str(other)) + "")



def Decode_tryDecodeKnownRequirementFromElement(element: YAMLElement) -> Requirement | None:
    try: 
        def _arrow907(get: IGetters) -> Requirement:
            def _arrow906(__unit: None=None) -> str:
                object_arg: IRequiredGetter = get.Required
                return object_arg.Field("class", string)

            return Decode_requirementFromTypeName(_arrow906(), get)

        return object(_arrow907, element)

    except Exception as ex:
        hint_class: str | None
        try: 
            def _arrow905(get_1: IGetters) -> str | None:
                object_arg_1: IOptionalGetter = get_1.Optional
                return object_arg_1.Field("class", string)

            hint_class = object(_arrow905, element)

        except Exception as match_value:
            hint_class = None

        if hint_class is None:
            pass

        else: 
            known_class: str = hint_class

        return None



def Decode_decodeHintElement(element: YAMLElement) -> HintEntry:
    match_value: Requirement | None = Decode_tryDecodeKnownRequirementFromElement(element)
    if match_value is None:
        def _arrow909(__unit: None=None, element: Any=element) -> str | None:
            try: 
                def _arrow908(get: IGetters) -> str | None:
                    object_arg: IOptionalGetter = get.Optional
                    return object_arg.Field("class", string)

                return object(_arrow908, element)

            except Exception as match_value_1:
                return None


        return HintEntry(1, HintUnknownValue(_arrow909(), element))

    else: 
        return HintEntry(0, match_value)



def Decode_hintArrayDecoder(y_ele: YAMLElement) -> Array[HintEntry]:
    (pattern_matching_result, items, other_1) = (None, None, None)
    if y_ele.tag == 3:
        if not is_empty(y_ele.fields[0]):
            if head(y_ele.fields[0]).tag == 2:
                if is_empty(tail(y_ele.fields[0])):
                    pattern_matching_result = 0
                    items = head(y_ele.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    elif y_ele.tag == 2:
        pattern_matching_result = 0
        items = y_ele.fields[0]

    else: 
        pattern_matching_result = 2
        other_1 = y_ele

    if pattern_matching_result == 0:
        def _arrow910(element: YAMLElement, y_ele: Any=y_ele) -> HintEntry:
            return Decode_decodeHintElement(element)

        return list(map(_arrow910, items))

    elif pattern_matching_result == 1:
        def _arrow912(get: IGetters, y_ele: Any=y_ele) -> Array[HintEntry]:
            def mapping(kv: Any) -> HintEntry:
                def _arrow911(__unit: None=None, kv: Any=kv) -> YAMLElement:
                    match_value: YAMLElement = kv[1]
                    if match_value.tag == 3:
                        mappings: FSharpList[YAMLElement] = match_value.fields[0]
                        def predicate(_arg: YAMLElement) -> bool:
                            (pattern_matching_result_1,) = (None,)
                            if _arg.tag == 0:
                                if _arg.fields[0].Value == "class":
                                    pattern_matching_result_1 = 0

                                else: 
                                    pattern_matching_result_1 = 1


                            else: 
                                pattern_matching_result_1 = 1

                            if pattern_matching_result_1 == 0:
                                return True

                            elif pattern_matching_result_1 == 1:
                                return False


                        return kv[1] if exists(predicate, mappings) else YAMLElement(3, cons(YAMLElement(0, YAMLContent("class", None), YAMLElement(3, singleton_1(YAMLElement(1, YAMLContent(kv[0], None))))), mappings))

                    else: 
                        return YAMLElement(3, of_array([YAMLElement(0, YAMLContent("class", None), YAMLElement(3, singleton_1(YAMLElement(1, YAMLContent(kv[0], None))))), YAMLElement(0, YAMLContent("value", None), match_value)]))


                return Decode_decodeHintElement(_arrow911())

            return list(map_2(mapping, get.Overflow.FieldList(empty())))

        return object(_arrow912, y_ele)

    elif pattern_matching_result == 2:
        raise Exception(("Invalid CWL hints syntax: " + str(other_1)) + "")



def _arrow913(value: YAMLElement) -> Array[Requirement] | None:
    def getter(get: IGetters) -> Array[Requirement] | None:
        object_arg: IOptionalGetter = get.Optional
        def arg_1(y_ele: YAMLElement, get: Any=get) -> Array[Requirement]:
            return Decode_requirementArrayDecoder(y_ele)

        return object_arg.Field("requirements", arg_1)

    return object(getter, value)


Decode_requirementsDecoder: Callable[[YAMLElement], Array[Requirement] | None] = _arrow913

def _arrow914(value: YAMLElement) -> Array[HintEntry] | None:
    def getter(get: IGetters) -> Array[HintEntry] | None:
        object_arg: IOptionalGetter = get.Optional
        def arg_1(y_ele: YAMLElement, get: Any=get) -> Array[HintEntry]:
            return Decode_hintArrayDecoder(y_ele)

        return object_arg.Field("hints", arg_1)

    return object(getter, value)


Decode_hintsDecoder: Callable[[YAMLElement], Array[HintEntry] | None] = _arrow914

def _arrow919(value_5: YAMLElement) -> InputBinding | None:
    def getter_1(get: IGetters) -> InputBinding | None:
        object_arg: IOptionalGetter = get.Optional
        def arg_1(value_4: YAMLElement, get: Any=get) -> InputBinding:
            def getter(get_0027: IGetters, value_4: Any=value_4) -> InputBinding:
                def _arrow915(__unit: None=None, get_0027: Any=get_0027) -> str | None:
                    object_arg_1: IOptionalGetter = get_0027.Optional
                    return object_arg_1.Field("prefix", string)

                def _arrow916(__unit: None=None, get_0027: Any=get_0027) -> int | None:
                    object_arg_2: IOptionalGetter = get_0027.Optional
                    return object_arg_2.Field("position", int_1)

                def _arrow917(__unit: None=None, get_0027: Any=get_0027) -> str | None:
                    object_arg_3: IOptionalGetter = get_0027.Optional
                    return object_arg_3.Field("itemSeparator", string)

                def _arrow918(__unit: None=None, get_0027: Any=get_0027) -> bool | None:
                    object_arg_4: IOptionalGetter = get_0027.Optional
                    return object_arg_4.Field("separate", bool_1)

                return InputBinding(_arrow915(), _arrow916(), _arrow917(), _arrow918())

            return object(getter, value_4)

        return object_arg.Field("inputBinding", arg_1)

    return object(getter_1, value_5)


Decode_inputBindingDecoder: Callable[[YAMLElement], InputBinding | None] = _arrow919

def _arrow926(value_1: YAMLElement) -> Array[CWLInput]:
    def getter(get: IGetters) -> Array[CWLInput]:
        dict_1: Any = get.Overflow.FieldList(empty())
        def _arrow925(__unit: None=None, get: Any=get) -> IEnumerable_1[CWLInput]:
            def _arrow924(key: str) -> IEnumerable_1[CWLInput]:
                value: YAMLElement = get_item_from_dict(dict_1, key)
                input_binding: InputBinding | None = Decode_inputBindingDecoder(value)
                pattern_input: tuple[CWLType, bool]
                (pattern_matching_result, v, mappings) = (None, None, None)
                if value.tag == 3:
                    if not is_empty(value.fields[0]):
                        if head(value.fields[0]).tag == 1:
                            if is_empty(tail(value.fields[0])):
                                pattern_matching_result = 0
                                v = head(value.fields[0]).fields[0]

                            else: 
                                pattern_matching_result = 1
                                mappings = value.fields[0]


                        else: 
                            pattern_matching_result = 1
                            mappings = value.fields[0]


                    else: 
                        pattern_matching_result = 1
                        mappings = value.fields[0]


                else: 
                    pattern_matching_result = 2

                if pattern_matching_result == 0:
                    pattern_input = Decode_cwlTypeStringMatcher(v.Value, get)

                elif pattern_matching_result == 1:
                    def predicate(m: YAMLElement) -> bool:
                        (pattern_matching_result_1,) = (None,)
                        if m.tag == 0:
                            if m.fields[0].Value == "type":
                                pattern_matching_result_1 = 0

                            else: 
                                pattern_matching_result_1 = 1


                        else: 
                            pattern_matching_result_1 = 1

                        if pattern_matching_result_1 == 0:
                            return True

                        elif pattern_matching_result_1 == 1:
                            return False


                    if exists(predicate, mappings):
                        pattern_input = Decode_cwlTypeDecoder(value)

                    else: 
                        (pattern_matching_result_2, v_1) = (None, None)
                        if value.tag == 3:
                            if not is_empty(value.fields[0]):
                                if head(value.fields[0]).tag == 1:
                                    if is_empty(tail(value.fields[0])):
                                        pattern_matching_result_2 = 0
                                        v_1 = head(value.fields[0]).fields[0]

                                    else: 
                                        pattern_matching_result_2 = 1


                                else: 
                                    pattern_matching_result_2 = 1


                            else: 
                                pattern_matching_result_2 = 1


                        else: 
                            pattern_matching_result_2 = 1

                        if pattern_matching_result_2 == 0:
                            pattern_input = Decode_cwlTypeStringMatcher(v_1.Value, get)

                        elif pattern_matching_result_2 == 1:
                            raise Exception("Unexpected input format without type field")



                elif pattern_matching_result == 2:
                    raise Exception("Unexpected input format in inputArrayDecoder")

                input: CWLInput = CWLInput(key, pattern_input[0])
                def _expr920():
                    set_optional_property("optional", True, input)
                    return empty_1()

                def _arrow923(__unit: None=None) -> IEnumerable_1[CWLInput]:
                    def _expr921():
                        set_optional_property("inputBinding", input_binding, input)
                        return empty_1()

                    def _arrow922(__unit: None=None) -> IEnumerable_1[CWLInput]:
                        return singleton(input)

                    return append(_expr921() if (input_binding is not None) else empty_1(), delay(_arrow922))

                return append(_expr920() if pattern_input[1] else empty_1(), delay(_arrow923))

            return collect(_arrow924, dict_1.keys())

        return list(to_array(delay(_arrow925)))

    return object(getter, value_1)


Decode_inputArrayDecoder: Callable[[YAMLElement], Array[CWLInput]] = _arrow926

def _arrow927(value: YAMLElement) -> Array[CWLInput] | None:
    def getter(get: IGetters) -> Array[CWLInput] | None:
        object_arg: IOptionalGetter = get.Optional
        return object_arg.Field("inputs", Decode_inputArrayDecoder)

    return object(getter, value)


Decode_inputsDecoder: Callable[[YAMLElement], Array[CWLInput] | None] = _arrow927

def _arrow930(value_2: YAMLElement) -> Array[str] | None:
    def getter(get: IGetters) -> Array[str] | None:
        base_command_field: YAMLElement | None
        object_arg: IOptionalGetter = get.Optional
        def arg_1(x: YAMLElement, get: Any=get) -> YAMLElement:
            return x

        base_command_field = object_arg.Field("baseCommand", arg_1)
        (pattern_matching_result, v, v_1, s, s_1) = (None, None, None, None, None)
        if base_command_field is None:
            pattern_matching_result = 4

        elif base_command_field.tag == 3:
            if not is_empty(base_command_field.fields[0]):
                if head(base_command_field.fields[0]).tag == 1:
                    if is_empty(tail(base_command_field.fields[0])):
                        pattern_matching_result = 0
                        v = head(base_command_field.fields[0]).fields[0]

                    else: 
                        pattern_matching_result = 5


                elif head(base_command_field.fields[0]).tag == 2:
                    if is_empty(tail(base_command_field.fields[0])):
                        pattern_matching_result = 2
                        s = head(base_command_field.fields[0]).fields[0]

                    else: 
                        pattern_matching_result = 5


                else: 
                    pattern_matching_result = 5


            else: 
                pattern_matching_result = 5


        elif base_command_field.tag == 1:
            pattern_matching_result = 1
            v_1 = base_command_field.fields[0]

        elif base_command_field.tag == 2:
            pattern_matching_result = 3
            s_1 = base_command_field.fields[0]

        else: 
            pattern_matching_result = 5

        if pattern_matching_result == 0:
            return [v.Value]

        elif pattern_matching_result == 1:
            return [v_1.Value]

        elif pattern_matching_result == 2:
            def _arrow928(value: YAMLElement, get: Any=get) -> str:
                return string(value)

            return resizearray(_arrow928, YAMLElement(2, s))

        elif pattern_matching_result == 3:
            def _arrow929(value_1: YAMLElement, get: Any=get) -> str:
                return string(value_1)

            return resizearray(_arrow929, YAMLElement(2, s_1))

        elif pattern_matching_result == 4:
            return None

        elif pattern_matching_result == 5:
            return None


    return object(getter, value_2)


Decode_baseCommandDecoder: Callable[[YAMLElement], Array[str] | None] = _arrow930

def _arrow931(value_1: YAMLElement) -> str:
    def getter(get: IGetters) -> str:
        object_arg: IRequiredGetter = get.Required
        def arg_1(value: YAMLElement, get: Any=get) -> str:
            return string(value)

        return object_arg.Field("cwlVersion", arg_1)

    return object(getter, value_1)


Decode_versionDecoder: Callable[[YAMLElement], str] = _arrow931

def _arrow932(value_1: YAMLElement) -> str:
    def getter(get: IGetters) -> str:
        object_arg: IRequiredGetter = get.Required
        def arg_1(value: YAMLElement, get: Any=get) -> str:
            return string(value)

        return object_arg.Field("class", arg_1)

    return object(getter, value_1)


Decode_classDecoder: Callable[[YAMLElement], str] = _arrow932

def Decode_stringOptionFieldDecoder(field: str) -> Callable[[YAMLElement], str | None]:
    def _arrow933(value_1: YAMLElement, field: Any=field) -> str | None:
        def getter(get: IGetters) -> str | None:
            object_arg: IOptionalGetter = get.Optional
            def arg_1(value: YAMLElement, get: Any=get) -> str:
                return string(value)

            return object_arg.Field(field, arg_1)

        return object(getter, value_1)

    return _arrow933


def Decode_boolOptionFieldDecoder(field: str) -> Callable[[YAMLElement], bool | None]:
    def _arrow934(value_1: YAMLElement, field: Any=field) -> bool | None:
        def getter(get: IGetters) -> bool | None:
            object_arg: IOptionalGetter = get.Optional
            def arg_1(value: YAMLElement, get: Any=get) -> bool:
                return bool_1(value)

            return object_arg.Field(field, arg_1)

        return object(getter, value_1)

    return _arrow934


def Decode_yamlElementOptionFieldDecoder(field: str) -> Callable[[YAMLElement], YAMLElement | None]:
    def _arrow935(value: YAMLElement, field: Any=field) -> YAMLElement | None:
        def getter(get: IGetters) -> YAMLElement | None:
            object_arg: IOptionalGetter = get.Optional
            def arg_1(x: YAMLElement, get: Any=get) -> YAMLElement:
                return x

            return object_arg.Field(field, arg_1)

        return object(getter, value)

    return _arrow935


def Decode_stringFieldDecoder(field: str) -> Callable[[YAMLElement], str]:
    def _arrow936(value_1: YAMLElement, field: Any=field) -> str:
        def getter(get: IGetters) -> str:
            object_arg: IRequiredGetter = get.Required
            def arg_1(value: YAMLElement, get: Any=get) -> str:
                return string(value)

            return object_arg.Field(field, arg_1)

        return object(getter, value_1)

    return _arrow936


def Decode_stringOrStringArrayDecoder(value: YAMLElement) -> Array[str] | None:
    (pattern_matching_result, v, s) = (None, None, None)
    if value.tag == 3:
        if not is_empty(value.fields[0]):
            if head(value.fields[0]).tag == 1:
                if is_empty(tail(value.fields[0])):
                    pattern_matching_result = 0
                    v = head(value.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 2


            elif head(value.fields[0]).tag == 2:
                if is_empty(tail(value.fields[0])):
                    pattern_matching_result = 1
                    s = head(value.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 2


            else: 
                pattern_matching_result = 2


        else: 
            pattern_matching_result = 2


    elif value.tag == 1:
        pattern_matching_result = 0
        v = value.fields[0]

    elif value.tag == 2:
        pattern_matching_result = 1
        s = value.fields[0]

    else: 
        pattern_matching_result = 2

    if pattern_matching_result == 0:
        return [v.Value]

    elif pattern_matching_result == 1:
        def _arrow937(value_1: YAMLElement, value: Any=value) -> str:
            return string(value_1)

        return resizearray(_arrow937, YAMLElement(2, s))

    elif pattern_matching_result == 2:
        return None



def Decode_sourceArrayFieldDecoder(field: str) -> Callable[[YAMLElement], Array[str] | None]:
    def _arrow940(value_1: YAMLElement, field: Any=field) -> Array[str] | None:
        def getter(get: IGetters) -> Array[str] | None:
            def _arrow938(value: YAMLElement, get: Any=get) -> Array[str] | None:
                return Decode_stringOrStringArrayDecoder(value)

            def _arrow939(__unit: None=None, get: Any=get) -> YAMLElement | None:
                object_arg: IOptionalGetter = get.Optional
                def arg_1(x: YAMLElement) -> YAMLElement:
                    return x

                return object_arg.Field(field, arg_1)

            return bind(_arrow938, _arrow939())

        return object(getter, value_1)

    return _arrow940


def Decode_linkMergeFieldDecoder(field: str) -> Callable[[YAMLElement], LinkMergeMethod | None]:
    def _arrow941(value_1: YAMLElement, field: Any=field) -> LinkMergeMethod | None:
        def getter(get: IGetters) -> LinkMergeMethod | None:
            link_merge_field: str | None
            object_arg: IOptionalGetter = get.Optional
            def arg_1(value: YAMLElement, get: Any=get) -> str:
                return string(value)

            link_merge_field = object_arg.Field(field, arg_1)
            if link_merge_field is None:
                return None

            else: 
                link_merge_string: str = link_merge_field
                match_value: LinkMergeMethod | None = LinkMergeMethod.try_parse(link_merge_string)
                if match_value is None:
                    raise Exception(("Invalid linkMerge value: " + link_merge_string) + "")

                else: 
                    return match_value



        return object(getter, value_1)

    return _arrow941


def Decode_pickValueFieldDecoder(field: str) -> Callable[[YAMLElement], PickValueMethod | None]:
    def _arrow942(value_1: YAMLElement, field: Any=field) -> PickValueMethod | None:
        def getter(get: IGetters) -> PickValueMethod | None:
            pick_value_field: str | None
            object_arg: IOptionalGetter = get.Optional
            def arg_1(value: YAMLElement, get: Any=get) -> str:
                return string(value)

            pick_value_field = object_arg.Field(field, arg_1)
            if pick_value_field is None:
                return None

            else: 
                pick_value_string: str = pick_value_field
                match_value: PickValueMethod | None = PickValueMethod.try_parse(pick_value_string)
                if match_value is None:
                    raise Exception(("Invalid pickValue value: " + pick_value_string) + "")

                else: 
                    return match_value



        return object(getter, value_1)

    return _arrow942


def Decode_scatterFieldDecoder(field: str) -> Callable[[YAMLElement], Array[str] | None]:
    def _arrow945(value_1: YAMLElement, field: Any=field) -> Array[str] | None:
        def getter(get: IGetters) -> Array[str] | None:
            def _arrow943(value: YAMLElement, get: Any=get) -> Array[str] | None:
                return Decode_stringOrStringArrayDecoder(value)

            def _arrow944(__unit: None=None, get: Any=get) -> YAMLElement | None:
                object_arg: IOptionalGetter = get.Optional
                def arg_1(x: YAMLElement) -> YAMLElement:
                    return x

                return object_arg.Field(field, arg_1)

            return bind(_arrow943, _arrow944())

        return object(getter, value_1)

    return _arrow945


def Decode_scatterMethodFieldDecoder(field: str) -> Callable[[YAMLElement], ScatterMethod | None]:
    def _arrow946(value_1: YAMLElement, field: Any=field) -> ScatterMethod | None:
        def getter(get: IGetters) -> ScatterMethod | None:
            scatter_method_field: str | None
            object_arg: IOptionalGetter = get.Optional
            def arg_1(value: YAMLElement, get: Any=get) -> str:
                return string(value)

            scatter_method_field = object_arg.Field(field, arg_1)
            if scatter_method_field is None:
                return None

            else: 
                scatter_method_string: str = scatter_method_field
                match_value: ScatterMethod | None = ScatterMethod.try_parse(scatter_method_string)
                if match_value is None:
                    raise Exception(("Invalid scatterMethod value: " + scatter_method_string) + "")

                else: 
                    return match_value



        return object(getter, value_1)

    return _arrow946


def Decode_expressionStringOptionFieldDecoder(field: str) -> Callable[[YAMLElement], str | None]:
    def _arrow949(value: YAMLElement, field: Any=field) -> str | None:
        def getter(get: IGetters) -> str | None:
            def _arrow947(y_ele: YAMLElement, get: Any=get) -> str:
                return Decode_decodeStringOrExpression(y_ele)

            def _arrow948(__unit: None=None, get: Any=get) -> YAMLElement | None:
                object_arg: IOptionalGetter = get.Optional
                def arg_1(x: YAMLElement) -> YAMLElement:
                    return x

                return object_arg.Field(field, arg_1)

            return map_1(_arrow947, _arrow948())

        return object(getter, value)

    return _arrow949


def Decode_decodeStepInputFromValue(id: str, value: YAMLElement, allow_scalar_source: bool) -> StepInput:
    scalar_source: Array[str] | None = Decode_stringOrStringArrayDecoder(value) if allow_scalar_source else None
    field_source: Array[str] | None = Decode_sourceArrayFieldDecoder("source")(value)
    return StepInput(id, scalar_source if (scalar_source is not None) else (field_source if (field_source is not None) else None), Decode_yamlElementOptionFieldDecoder("default")(value), Decode_stringOptionFieldDecoder("valueFrom")(value), Decode_linkMergeFieldDecoder("linkMerge")(value), Decode_pickValueFieldDecoder("pickValue")(value), Decode_stringOptionFieldDecoder("doc")(value), Decode_boolOptionFieldDecoder("loadContents")(value), Decode_stringOptionFieldDecoder("loadListing")(value), Decode_stringOptionFieldDecoder("label")(value))


def Decode_decodeStepInputsFromMap(value: YAMLElement) -> Array[StepInput]:
    def _arrow950(get: IGetters, value: Any=value) -> Any:
        return get.Overflow.FieldList(empty())

    dict_1: Any = object(_arrow950, value)
    def _arrow952(__unit: None=None, value: Any=value) -> IEnumerable_1[StepInput]:
        def _arrow951(key: str) -> StepInput:
            return Decode_decodeStepInputFromValue(key, get_item_from_dict(dict_1, key), True)

        return map_2(_arrow951, dict_1.keys())

    return list(to_array(delay(_arrow952)))


def Decode_decodeStepInputFromArrayItem(item: YAMLElement) -> StepInput:
    return Decode_decodeStepInputFromValue(Decode_stringFieldDecoder("id")(item), item, False)


def Decode_decodeStepInputsFromArray(items: FSharpList[YAMLElement]) -> Array[StepInput]:
    def _arrow953(item: YAMLElement, items: Any=items) -> StepInput:
        return Decode_decodeStepInputFromArrayItem(item)

    return list(map(_arrow953, items))


def Decode_inputStepDecoder(value: YAMLElement) -> Array[StepInput]:
    (pattern_matching_result, items) = (None, None)
    if value.tag == 3:
        if not is_empty(value.fields[0]):
            if head(value.fields[0]).tag == 2:
                if is_empty(tail(value.fields[0])):
                    pattern_matching_result = 0
                    items = head(value.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    elif value.tag == 2:
        pattern_matching_result = 0
        items = value.fields[0]

    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return Decode_decodeStepInputsFromArray(items)

    elif pattern_matching_result == 1:
        return Decode_decodeStepInputsFromMap(value)



def Decode_decodeStepOutputItem(value: YAMLElement) -> StepOutput:
    (pattern_matching_result, v) = (None, None)
    if value.tag == 3:
        if not is_empty(value.fields[0]):
            if head(value.fields[0]).tag == 1:
                if is_empty(tail(value.fields[0])):
                    pattern_matching_result = 0
                    v = head(value.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    elif value.tag == 1:
        pattern_matching_result = 0
        v = value.fields[0]

    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return StepOutput(0, v.Value)

    elif pattern_matching_result == 1:
        return StepOutput(1, StepOutputParameter(Decode_stringFieldDecoder("id")(value)))



def _arrow956(value_2: YAMLElement) -> Array[StepOutput]:
    def getter(get: IGetters) -> Array[StepOutput]:
        out_field: YAMLElement
        object_arg: IRequiredGetter = get.Required
        def arg_1(x: YAMLElement, get: Any=get) -> YAMLElement:
            return x

        out_field = object_arg.Field("out", arg_1)
        (pattern_matching_result, outputs, value_1) = (None, None, None)
        if out_field.tag == 3:
            if not is_empty(out_field.fields[0]):
                if head(out_field.fields[0]).tag == 1:
                    if is_empty(tail(out_field.fields[0])):
                        if head(out_field.fields[0]).fields[0].Value == "[]":
                            pattern_matching_result = 1

                        else: 
                            pattern_matching_result = 4
                            value_1 = out_field


                    else: 
                        pattern_matching_result = 4
                        value_1 = out_field


                elif head(out_field.fields[0]).tag == 2:
                    if is_empty(head(out_field.fields[0]).fields[0]):
                        if is_empty(tail(out_field.fields[0])):
                            pattern_matching_result = 2

                        else: 
                            pattern_matching_result = 4
                            value_1 = out_field


                    elif is_empty(tail(out_field.fields[0])):
                        pattern_matching_result = 3
                        outputs = head(out_field.fields[0]).fields[0]

                    else: 
                        pattern_matching_result = 4
                        value_1 = out_field


                else: 
                    pattern_matching_result = 4
                    value_1 = out_field


            else: 
                pattern_matching_result = 0


        elif out_field.tag == 2:
            if is_empty(out_field.fields[0]):
                pattern_matching_result = 2

            else: 
                pattern_matching_result = 3
                outputs = out_field.fields[0]


        else: 
            pattern_matching_result = 4
            value_1 = out_field

        if pattern_matching_result == 0:
            return []

        elif pattern_matching_result == 1:
            return []

        elif pattern_matching_result == 2:
            return []

        elif pattern_matching_result == 3:
            def _arrow955(value: YAMLElement, get: Any=get) -> StepOutput:
                return Decode_decodeStepOutputItem(value)

            return list(map(_arrow955, outputs))

        elif pattern_matching_result == 4:
            return [Decode_decodeStepOutputItem(value_1)]


    return object(getter, value_2)


Decode_outputStepsDecoder: Callable[[YAMLElement], Array[StepOutput]] = _arrow956

def _arrow957(value_1: YAMLElement) -> str | None:
    def getter(get: IGetters) -> str | None:
        object_arg: IOptionalGetter = get.Optional
        def arg_1(value: YAMLElement, get: Any=get) -> str:
            return string(value)

        return object_arg.Field("doc", arg_1)

    return object(getter, value_1)


Decode_docDecoder: Callable[[YAMLElement], str | None] = _arrow957

def _arrow958(value_1: YAMLElement) -> str | None:
    def getter(get: IGetters) -> str | None:
        object_arg: IOptionalGetter = get.Optional
        def arg_1(value: YAMLElement, get: Any=get) -> str:
            return string(value)

        return object_arg.Field("label", arg_1)

    return object(getter, value_1)


Decode_labelDecoder: Callable[[YAMLElement], str | None] = _arrow958

def _arrow961(value_1: YAMLElement) -> Array[str] | None:
    def getter(get: IGetters) -> Array[str] | None:
        def _arrow959(value: YAMLElement, get: Any=get) -> Array[str] | None:
            return Decode_stringOrStringArrayDecoder(value)

        def _arrow960(__unit: None=None, get: Any=get) -> YAMLElement | None:
            object_arg: IOptionalGetter = get.Optional
            def arg_1(x: YAMLElement) -> YAMLElement:
                return x

            return object_arg.Field("intent", arg_1)

        return bind(_arrow959, _arrow960())

    return object(getter, value_1)


Decode_intentDecoder: Callable[[YAMLElement], Array[str] | None] = _arrow961

def Decode_hasField(field_name: str, yaml_element: YAMLElement) -> bool:
    if yaml_element.tag == 3:
        def predicate(_arg: YAMLElement, field_name: Any=field_name, yaml_element: Any=yaml_element) -> bool:
            (pattern_matching_result,) = (None,)
            if _arg.tag == 0:
                if _arg.fields[0].Value == field_name:
                    pattern_matching_result = 0

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1

            if pattern_matching_result == 0:
                return True

            elif pattern_matching_result == 1:
                return False


        return exists(predicate, yaml_element.fields[0])

    else: 
        return False



def Decode_withDefaultCwlVersion(default_cwl_version: str, yaml_element: YAMLElement) -> YAMLElement:
    if yaml_element.tag == 3:
        if Decode_hasField("cwlVersion", yaml_element):
            return yaml_element

        else: 
            return YAMLElement(3, cons(YAMLElement(0, YAMLContent("cwlVersion", None), YAMLElement(3, singleton_1(YAMLElement(1, YAMLContent(default_cwl_version, None))))), yaml_element.fields[0]))


    else: 
        return yaml_element



def Decode_workflowStepRunDecoder(default_cwl_version: str, run_value: YAMLElement) -> WorkflowStepRun:
    (pattern_matching_result, v) = (None, None)
    if run_value.tag == 3:
        if not is_empty(run_value.fields[0]):
            if head(run_value.fields[0]).tag == 1:
                if is_empty(tail(run_value.fields[0])):
                    pattern_matching_result = 0
                    v = head(run_value.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    elif run_value.tag == 1:
        pattern_matching_result = 0
        v = run_value.fields[0]

    else: 
        pattern_matching_result = 2

    if pattern_matching_result == 0:
        return WorkflowStepRun(0, v.Value)

    elif pattern_matching_result == 1:
        match_value: CWLProcessingUnit = Decode_decodeCWLProcessingUnitElement(Decode_withDefaultCwlVersion(default_cwl_version, run_value))
        if match_value.tag == 1:
            return WorkflowStepRunOps_fromWorkflow(match_value.fields[0])

        elif match_value.tag == 2:
            return WorkflowStepRunOps_fromExpressionTool(match_value.fields[0])

        elif match_value.tag == 3:
            return WorkflowStepRunOps_fromOperation(match_value.fields[0])

        else: 
            return WorkflowStepRunOps_fromTool(match_value.fields[0])


    elif pattern_matching_result == 2:
        raise Exception(to_text(interpolate("Unsupported run value for workflow step: %A%P()", [run_value])))



def Decode_decodeWorkflowStepFromValueWithId(default_cwl_version: str, step_id: str, value: YAMLElement) -> WorkflowStep:
    def _arrow962(get_0027: IGetters, default_cwl_version: Any=default_cwl_version, step_id: Any=step_id, value: Any=value) -> YAMLElement:
        object_arg: IRequiredGetter = get_0027.Required
        def arg_1(x: YAMLElement) -> YAMLElement:
            return x

        return object_arg.Field("run", arg_1)

    run: WorkflowStepRun = Decode_workflowStepRunDecoder(default_cwl_version, object(_arrow962, value))
    def _arrow963(get_0027_1: IGetters, default_cwl_version: Any=default_cwl_version, step_id: Any=step_id, value: Any=value) -> Array[StepInput]:
        object_arg_1: IRequiredGetter = get_0027_1.Required
        return object_arg_1.Field("in", Decode_inputStepDecoder)

    inputs: Array[StepInput] = object(_arrow963, value)
    outputs: Array[StepOutput] = Decode_outputStepsDecoder(value)
    requirements: Array[Requirement] | None = Decode_requirementsDecoder(value)
    hints: Array[HintEntry] | None = Decode_hintsDecoder(value)
    doc: str | None = Decode_docDecoder(value)
    wf_step: WorkflowStep = WorkflowStep(step_id, inputs, outputs, run, Decode_labelDecoder(value), doc, Decode_scatterFieldDecoder("scatter")(value), Decode_scatterMethodFieldDecoder("scatterMethod")(value), Decode_expressionStringOptionFieldDecoder("when")(value))
    if requirements is not None:
        wf_step.Requirements = requirements

    if hints is not None:
        wf_step.Hints = hints

    return wf_step


def Decode_decodeWorkflowStepFromArrayItem(default_cwl_version: str, item: YAMLElement) -> WorkflowStep:
    return Decode_decodeWorkflowStepFromValueWithId(default_cwl_version, Decode_stringFieldDecoder("id")(item), item)


def Decode_stepArrayDecoderWithVersion(default_cwl_version: str, value: YAMLElement) -> Array[WorkflowStep]:
    (pattern_matching_result, items) = (None, None)
    if value.tag == 3:
        if not is_empty(value.fields[0]):
            if head(value.fields[0]).tag == 2:
                if is_empty(tail(value.fields[0])):
                    pattern_matching_result = 0
                    items = head(value.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 1


            else: 
                pattern_matching_result = 1


        else: 
            pattern_matching_result = 1


    elif value.tag == 2:
        pattern_matching_result = 0
        items = value.fields[0]

    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        def mapping(item: YAMLElement, default_cwl_version: Any=default_cwl_version, value: Any=value) -> WorkflowStep:
            return Decode_decodeWorkflowStepFromArrayItem(default_cwl_version, item)

        return list(map(mapping, items))

    elif pattern_matching_result == 1:
        def _arrow965(get: IGetters, default_cwl_version: Any=default_cwl_version, value: Any=value) -> Any:
            return get.Overflow.FieldList(empty())

        dict_1: Any = object(_arrow965, value)
        def _arrow967(__unit: None=None, default_cwl_version: Any=default_cwl_version, value: Any=value) -> IEnumerable_1[WorkflowStep]:
            def _arrow966(key: str) -> WorkflowStep:
                return Decode_decodeWorkflowStepFromValueWithId(default_cwl_version, key, get_item_from_dict(dict_1, key))

            return map_2(_arrow966, dict_1.keys())

        return list(to_array(delay(_arrow967)))



def Decode_stepsDecoderWithVersion(default_cwl_version: str) -> Callable[[YAMLElement], Array[WorkflowStep]]:
    def _arrow968(value_1: YAMLElement, default_cwl_version: Any=default_cwl_version) -> Array[WorkflowStep]:
        def getter(get: IGetters) -> Array[WorkflowStep]:
            object_arg: IRequiredGetter = get.Required
            def arg_1(value: YAMLElement, get: Any=get) -> Array[WorkflowStep]:
                return Decode_stepArrayDecoderWithVersion(default_cwl_version, value)

            return object_arg.Field("steps", arg_1)

        return object(getter, value_1)

    return _arrow968


def Decode_commandLineToolDecoder(yaml_cwl: YAMLElement) -> CWLToolDescription:
    cwl_version: str = Decode_versionDecoder(yaml_cwl)
    outputs: Array[CWLOutput] = Decode_outputsDecoder(yaml_cwl)
    inputs: Array[CWLInput] | None = Decode_inputsDecoder(yaml_cwl)
    requirements: Array[Requirement] | None = Decode_requirementsDecoder(yaml_cwl)
    hints: Array[HintEntry] | None = Decode_hintsDecoder(yaml_cwl)
    intent: Array[str] | None = Decode_intentDecoder(yaml_cwl)
    base_command: Array[str] | None = Decode_baseCommandDecoder(yaml_cwl)
    doc: str | None = Decode_docDecoder(yaml_cwl)
    label: str | None = Decode_labelDecoder(yaml_cwl)
    description: CWLToolDescription = CWLToolDescription(outputs, cwl_version)
    metadata: DynamicObj
    md: DynamicObj = DynamicObj()
    def getter(get: IGetters, yaml_cwl: Any=yaml_cwl) -> DynamicObj:
        return Decode_overflowDecoder(md, get.Overflow.FieldList(of_array(["inputs", "outputs", "class", "id", "label", "doc", "intent", "requirements", "hints", "cwlVersion", "baseCommand", "arguments", "stdin", "stderr", "stdout", "successCodes", "temporaryFailCodes", "permanentFailCodes"])))

    ignore(object(getter, yaml_cwl))
    metadata = md
    def getter_1(get_1: IGetters, yaml_cwl: Any=yaml_cwl) -> DynamicObj:
        return Decode_overflowDecoder(description, get_1.MultipleOptional.FieldList(of_array(["id", "arguments", "stdin", "stderr", "stdout", "successCodes", "temporaryFailCodes", "permanentFailCodes"])))

    ignore(object(getter_1, yaml_cwl))
    if inputs is not None:
        description.Inputs = inputs

    if requirements is not None:
        description.Requirements = requirements

    if hints is not None:
        description.Hints = hints

    if intent is not None:
        description.Intent = intent

    if base_command is not None:
        description.BaseCommand = base_command

    if doc is not None:
        description.Doc = doc

    if label is not None:
        description.Label = label

    if length(metadata.GetProperties(False)) > 0:
        description.Metadata = metadata

    return description


def Decode_expressionToolDecoder(yaml_cwl: YAMLElement) -> CWLExpressionToolDescription:
    cwl_version: str = Decode_versionDecoder(yaml_cwl)
    outputs: Array[CWLOutput] = Decode_outputsDecoder(yaml_cwl)
    inputs: Array[CWLInput] | None = Decode_inputsDecoder(yaml_cwl)
    requirements: Array[Requirement] | None = Decode_requirementsDecoder(yaml_cwl)
    hints: Array[HintEntry] | None = Decode_hintsDecoder(yaml_cwl)
    intent: Array[str] | None = Decode_intentDecoder(yaml_cwl)
    doc: str | None = Decode_docDecoder(yaml_cwl)
    label: str | None = Decode_labelDecoder(yaml_cwl)
    def _arrow970(get: IGetters, yaml_cwl: Any=yaml_cwl) -> str:
        object_arg: IRequiredGetter = get.Required
        return object_arg.Field("expression", Decode_decodeStringOrExpression)

    description: CWLExpressionToolDescription = CWLExpressionToolDescription(outputs, object(_arrow970, yaml_cwl), cwl_version)
    metadata: DynamicObj
    md: DynamicObj = DynamicObj()
    def getter(get_1: IGetters, yaml_cwl: Any=yaml_cwl) -> DynamicObj:
        return Decode_overflowDecoder(md, get_1.Overflow.FieldList(of_array(["inputs", "outputs", "class", "id", "label", "doc", "intent", "requirements", "hints", "cwlVersion", "expression"])))

    ignore(object(getter, yaml_cwl))
    metadata = md
    def getter_1(get_2: IGetters, yaml_cwl: Any=yaml_cwl) -> DynamicObj:
        return Decode_overflowDecoder(description, get_2.MultipleOptional.FieldList(singleton_1("id")))

    ignore(object(getter_1, yaml_cwl))
    if inputs is not None:
        description.Inputs = inputs

    if requirements is not None:
        description.Requirements = requirements

    if hints is not None:
        description.Hints = hints

    if intent is not None:
        description.Intent = intent

    if doc is not None:
        description.Doc = doc

    if label is not None:
        description.Label = label

    if length(metadata.GetProperties(False)) > 0:
        description.Metadata = metadata

    return description


def Decode_operationDecoder(yaml_cwl: YAMLElement) -> CWLOperationDescription:
    cwl_version: str = Decode_versionDecoder(yaml_cwl)
    outputs: Array[CWLOutput] = Decode_outputsDecoder(yaml_cwl)
    inputs: Array[CWLInput]
    match_value: Array[CWLInput] | None = Decode_inputsDecoder(yaml_cwl)
    if match_value is None:
        raise Exception("Inputs are required for an operation")

    else: 
        inputs = match_value

    requirements: Array[Requirement] | None = Decode_requirementsDecoder(yaml_cwl)
    hints: Array[HintEntry] | None = Decode_hintsDecoder(yaml_cwl)
    intent: Array[str] | None = Decode_intentDecoder(yaml_cwl)
    doc: str | None = Decode_docDecoder(yaml_cwl)
    label: str | None = Decode_labelDecoder(yaml_cwl)
    description: CWLOperationDescription = CWLOperationDescription(inputs, outputs, cwl_version)
    metadata: DynamicObj
    md: DynamicObj = DynamicObj()
    def getter(get: IGetters, yaml_cwl: Any=yaml_cwl) -> DynamicObj:
        return Decode_overflowDecoder(md, get.Overflow.FieldList(of_array(["inputs", "outputs", "label", "doc", "intent", "class", "id", "requirements", "hints", "cwlVersion"])))

    ignore(object(getter, yaml_cwl))
    metadata = md
    def getter_1(get_1: IGetters, yaml_cwl: Any=yaml_cwl) -> DynamicObj:
        return Decode_overflowDecoder(description, get_1.MultipleOptional.FieldList(singleton_1("id")))

    ignore(object(getter_1, yaml_cwl))
    if requirements is not None:
        description.Requirements = requirements

    if hints is not None:
        description.Hints = hints

    if intent is not None:
        description.Intent = intent

    if doc is not None:
        description.Doc = doc

    if label is not None:
        description.Label = label

    if length(metadata.GetProperties(False)) > 0:
        description.Metadata = metadata

    return description


def Decode_workflowDecoder(yaml_cwl: YAMLElement) -> CWLWorkflowDescription:
    cwl_version: str = Decode_versionDecoder(yaml_cwl)
    outputs: Array[CWLOutput] = Decode_outputsDecoder(yaml_cwl)
    inputs: Array[CWLInput]
    match_value: Array[CWLInput] | None = Decode_inputsDecoder(yaml_cwl)
    if match_value is None:
        raise Exception("Inputs are required for a workflow")

    else: 
        inputs = match_value

    requirements: Array[Requirement] | None = Decode_requirementsDecoder(yaml_cwl)
    hints: Array[HintEntry] | None = Decode_hintsDecoder(yaml_cwl)
    intent: Array[str] | None = Decode_intentDecoder(yaml_cwl)
    steps: Array[WorkflowStep] = Decode_stepsDecoderWithVersion(cwl_version)(yaml_cwl)
    doc: str | None = Decode_docDecoder(yaml_cwl)
    label: str | None = Decode_labelDecoder(yaml_cwl)
    description: CWLWorkflowDescription = CWLWorkflowDescription(steps, inputs, outputs, cwl_version)
    metadata: DynamicObj
    md: DynamicObj = DynamicObj()
    def getter(get: IGetters, yaml_cwl: Any=yaml_cwl) -> DynamicObj:
        return Decode_overflowDecoder(md, get.Overflow.FieldList(of_array(["inputs", "outputs", "label", "doc", "intent", "class", "steps", "id", "requirements", "hints", "cwlVersion"])))

    ignore(object(getter, yaml_cwl))
    metadata = md
    def getter_1(get_1: IGetters, yaml_cwl: Any=yaml_cwl) -> DynamicObj:
        return Decode_overflowDecoder(description, get_1.MultipleOptional.FieldList(singleton_1("id")))

    ignore(object(getter_1, yaml_cwl))
    if requirements is not None:
        description.Requirements = requirements

    if hints is not None:
        description.Hints = hints

    if intent is not None:
        description.Intent = intent

    if doc is not None:
        description.Doc = doc

    if label is not None:
        description.Label = label

    if length(metadata.GetProperties(False)) > 0:
        description.Metadata = metadata

    return description


def Decode_decodeCWLProcessingUnitElement(yaml_cwl: YAMLElement) -> CWLProcessingUnit:
    cls: str = Decode_classDecoder(yaml_cwl)
    if cls == "CommandLineTool":
        return CWLProcessingUnit(0, Decode_commandLineToolDecoder(yaml_cwl))

    elif cls == "Workflow":
        return CWLProcessingUnit(1, Decode_workflowDecoder(yaml_cwl))

    elif cls == "ExpressionTool":
        return CWLProcessingUnit(2, Decode_expressionToolDecoder(yaml_cwl))

    elif cls == "Operation":
        return CWLProcessingUnit(3, Decode_operationDecoder(yaml_cwl))

    else: 
        raise Exception(("Invalid or unsupported CWL class: " + cls) + "")



def _arrow971(value: YAMLElement) -> Array[WorkflowStep]:
    return Decode_stepArrayDecoderWithVersion("v1.2", value)


Decode_stepArrayDecoder: Callable[[YAMLElement], Array[WorkflowStep]] = _arrow971

Decode_stepsDecoder: Callable[[YAMLElement], Array[WorkflowStep]] = Decode_stepsDecoderWithVersion("v1.2")

def Decode_decodeCommandLineTool(cwl: str) -> CWLToolDescription:
    return Decode_commandLineToolDecoder(Decode_readSanitizedYaml(cwl))


def Decode_decodeWorkflow(cwl: str) -> CWLWorkflowDescription:
    return Decode_workflowDecoder(Decode_readSanitizedYaml(cwl))


def Decode_decodeExpressionTool(cwl: str) -> CWLExpressionToolDescription:
    return Decode_expressionToolDecoder(Decode_readSanitizedYaml(cwl))


def Decode_decodeOperation(cwl: str) -> CWLOperationDescription:
    return Decode_operationDecoder(Decode_readSanitizedYaml(cwl))


def Decode_decodeCWLProcessingUnit(cwl: str) -> CWLProcessingUnit:
    return Decode_decodeCWLProcessingUnitElement(Decode_readSanitizedYaml(cwl))


def DecodeParameters_cwlParameterReferenceDecoder(get: IGetters, key: str, y_ele: YAMLElement) -> CWLParameterReference:
    (pattern_matching_result, v, v1, v2, s) = (None, None, None, None, None)
    if y_ele.tag == 3:
        if not is_empty(y_ele.fields[0]):
            if head(y_ele.fields[0]).tag == 1:
                if is_empty(tail(y_ele.fields[0])):
                    pattern_matching_result = 0
                    v = head(y_ele.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 3


            elif head(y_ele.fields[0]).tag == 0:
                if head(y_ele.fields[0]).fields[1].tag == 3:
                    if not is_empty(head(y_ele.fields[0]).fields[1].fields[0]):
                        if head(head(y_ele.fields[0]).fields[1].fields[0]).tag == 1:
                            if is_empty(tail(head(y_ele.fields[0]).fields[1].fields[0])):
                                if not is_empty(tail(y_ele.fields[0])):
                                    if head(tail(y_ele.fields[0])).tag == 0:
                                        if head(tail(y_ele.fields[0])).fields[1].tag == 3:
                                            if not is_empty(head(tail(y_ele.fields[0])).fields[1].fields[0]):
                                                if head(head(tail(y_ele.fields[0])).fields[1].fields[0]).tag == 1:
                                                    if is_empty(tail(head(tail(y_ele.fields[0])).fields[1].fields[0])):
                                                        if is_empty(tail(tail(y_ele.fields[0]))):
                                                            pattern_matching_result = 1
                                                            v1 = head(head(y_ele.fields[0]).fields[1].fields[0]).fields[0]
                                                            v2 = head(head(tail(y_ele.fields[0])).fields[1].fields[0]).fields[0]

                                                        else: 
                                                            pattern_matching_result = 3


                                                    else: 
                                                        pattern_matching_result = 3


                                                else: 
                                                    pattern_matching_result = 3


                                            else: 
                                                pattern_matching_result = 3


                                        else: 
                                            pattern_matching_result = 3


                                    else: 
                                        pattern_matching_result = 3


                                else: 
                                    pattern_matching_result = 3


                            else: 
                                pattern_matching_result = 3


                        else: 
                            pattern_matching_result = 3


                    else: 
                        pattern_matching_result = 3


                else: 
                    pattern_matching_result = 3


            elif head(y_ele.fields[0]).tag == 2:
                if is_empty(tail(y_ele.fields[0])):
                    pattern_matching_result = 2
                    s = head(y_ele.fields[0]).fields[0]

                else: 
                    pattern_matching_result = 3


            else: 
                pattern_matching_result = 3


        else: 
            pattern_matching_result = 3


    else: 
        pattern_matching_result = 3

    if pattern_matching_result == 0:
        return CWLParameterReference(key, [v.Value])

    elif pattern_matching_result == 1:
        return CWLParameterReference(key, [v2.Value], Decode_cwlTypeStringMatcher(v1.Value, get)[0])

    elif pattern_matching_result == 2:
        match_value: YAMLElement | None = try_head(s)
        (pattern_matching_result_1, mappings) = (None, None)
        if match_value is not None:
            if match_value.tag == 3:
                pattern_matching_result_1 = 0
                mappings = match_value.fields[0]

            else: 
                pattern_matching_result_1 = 1


        else: 
            pattern_matching_result_1 = 1

        if pattern_matching_result_1 == 0:
            def predicate(_arg: YAMLElement, get: Any=get, key: Any=key, y_ele: Any=y_ele) -> bool:
                if _arg.tag == 0:
                    return True

                else: 
                    return False


            if not exists(predicate, mappings):
                def _arrow972(value: YAMLElement, get: Any=get, key: Any=key, y_ele: Any=y_ele) -> str:
                    return string(value)

                return CWLParameterReference(key, resizearray(_arrow972, YAMLElement(2, s)))

            else: 
                def predicate_1(_arg_1: YAMLElement, get: Any=get, key: Any=key, y_ele: Any=y_ele) -> bool:
                    (pattern_matching_result_2,) = (None,)
                    if _arg_1.tag == 0:
                        if _arg_1.fields[0].Value == "class":
                            pattern_matching_result_2 = 0

                        else: 
                            pattern_matching_result_2 = 1


                    else: 
                        pattern_matching_result_2 = 1

                    if pattern_matching_result_2 == 0:
                        return True

                    elif pattern_matching_result_2 == 1:
                        return False


                if exists(predicate_1, mappings):
                    paths: Array[str] = []
                    with get_enumerator(s) as enumerator:
                        while enumerator.System_Collections_IEnumerator_MoveNext():
                            item: YAMLElement = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
                            if item.tag == 3:
                                with get_enumerator(item.fields[0]) as enumerator_1:
                                    while enumerator_1.System_Collections_IEnumerator_MoveNext():
                                        mapping: YAMLElement = enumerator_1.System_Collections_Generic_IEnumerator_1_get_Current()
                                        (pattern_matching_result_3, k_3, v_2) = (None, None, None)
                                        if mapping.tag == 0:
                                            if mapping.fields[1].tag == 3:
                                                if not is_empty(mapping.fields[1].fields[0]):
                                                    if head(mapping.fields[1].fields[0]).tag == 1:
                                                        if is_empty(tail(mapping.fields[1].fields[0])):
                                                            if mapping.fields[0].Value == "path":
                                                                pattern_matching_result_3 = 0
                                                                k_3 = mapping.fields[0]
                                                                v_2 = head(mapping.fields[1].fields[0]).fields[0]

                                                            else: 
                                                                pattern_matching_result_3 = 1


                                                        else: 
                                                            pattern_matching_result_3 = 1


                                                    else: 
                                                        pattern_matching_result_3 = 1


                                                else: 
                                                    pattern_matching_result_3 = 1


                                            else: 
                                                pattern_matching_result_3 = 1


                                        else: 
                                            pattern_matching_result_3 = 1

                                        if pattern_matching_result_3 == 0:
                                            (paths.append(v_2.Value))


                    return CWLParameterReference(key, paths, CWLType(11, InputArraySchema(CWLType(0, FileInstance__ctor()), None, None, None)))

                else: 
                    return CWLParameterReference(key, [])



        elif pattern_matching_result_1 == 1:
            def _arrow973(value_1: YAMLElement, get: Any=get, key: Any=key, y_ele: Any=y_ele) -> str:
                return string(value_1)

            return CWLParameterReference(key, resizearray(_arrow973, YAMLElement(2, s)))


    elif pattern_matching_result == 3:
        raise Exception(to_text(interpolate("Unexpected YAMLElement format in cwlParameterReferenceDecoder: %A%P()", [y_ele])))



def _arrow976(value: YAMLElement) -> Array[CWLParameterReference]:
    def getter(get: IGetters) -> Array[CWLParameterReference]:
        dict_1: Any = get.Overflow.FieldList(empty())
        def _arrow975(__unit: None=None, get: Any=get) -> IEnumerable_1[CWLParameterReference]:
            def _arrow974(ele: Any) -> CWLParameterReference:
                return DecodeParameters_cwlParameterReferenceDecoder(get, ele[0], ele[1])

            return map_2(_arrow974, dict_1)

        return list(to_array(delay(_arrow975)))

    return object(getter, value)


DecodeParameters_cwlparameterReferenceArrayDecoder: Callable[[YAMLElement], Array[CWLParameterReference]] = _arrow976

def DecodeParameters_decodeYAMLParameterFile(yaml: str) -> Array[CWLParameterReference]:
    return DecodeParameters_cwlparameterReferenceArrayDecoder(read(yaml))


__all__ = ["ResizeArray_map", "Decode_normalizeYamlInput", "Decode_removeFullLineComments", "Decode_removeYamlComments", "Decode_isRecoverableDecodingError", "Decode_readSanitizedYaml", "Decode_overflowDecoder", "Decode_decodeSchemaSaladString", "Decode_decodeStringOrExpression", "Decode_outputBindingGlobDecoder", "Decode_outputBindingDecoder", "Decode_decodeStringArrayOrScalar", "Decode_outputSourceDecoder", "Decode_direntDecoder", "Decode_initialWorkDirEntryDecoder", "Decode_cwlSimpleTypeFromString", "Decode_parseArrayShorthand", "input_array_schema_decoder_0040261", "input_array_schema_decoder_0040261_002d1", "input_record_field_decoder_0040275", "input_record_field_decoder_0040275_002d1", "input_record_schema_decoder_0040314", "input_record_schema_decoder_0040314_002d1", "input_enum_schema_decoder_0040341", "input_enum_schema_decoder_0040341_002d1", "Decode_inputArraySchemaDecoder", "Decode_inputRecordFieldDecoder", "Decode_tryDecodeFieldsAsArray", "Decode_tryDecodeFieldsAsMap", "Decode_inputRecordSchemaDecoder", "Decode_inputEnumSchemaDecoder", "Decode_cwlTypeDecoder_0027", "Decode_cwlTypeStringMatcher", "Decode_cwlTypeDecoder", "Decode_outputArrayDecoder", "Decode_outputsDecoder", "Decode_dockerRequirementDecoder", "Decode_envVarRequirementDecoder", "Decode_softwareRequirementDecoder", "Decode_initialWorkDirRequirementDecoder", "Decode_loadListingRequirementDecoder", "Decode_decodeResourceScalar", "Decode_optionalResourceField", "Decode_resourceRequirementDecoder", "Decode_schemaDefRequirementTypeDecoder", "Decode_schemaDefRequirementDecoder", "Decode_tryDecodeBoolScalar", "Decode_workReuseRequirementDecoder", "Decode_networkAccessRequirementDecoder", "Decode_inplaceUpdateRequirementDecoder", "Decode_toolTimeLimitRequirementDecoder", "Decode_inlineJavascriptRequirementDecoder", "Decode_requirementFromTypeName", "Decode_requirementArrayDecoder", "Decode_tryDecodeKnownRequirementFromElement", "Decode_decodeHintElement", "Decode_hintArrayDecoder", "Decode_requirementsDecoder", "Decode_hintsDecoder", "Decode_inputBindingDecoder", "Decode_inputArrayDecoder", "Decode_inputsDecoder", "Decode_baseCommandDecoder", "Decode_versionDecoder", "Decode_classDecoder", "Decode_stringOptionFieldDecoder", "Decode_boolOptionFieldDecoder", "Decode_yamlElementOptionFieldDecoder", "Decode_stringFieldDecoder", "Decode_stringOrStringArrayDecoder", "Decode_sourceArrayFieldDecoder", "Decode_linkMergeFieldDecoder", "Decode_pickValueFieldDecoder", "Decode_scatterFieldDecoder", "Decode_scatterMethodFieldDecoder", "Decode_expressionStringOptionFieldDecoder", "Decode_decodeStepInputFromValue", "Decode_decodeStepInputsFromMap", "Decode_decodeStepInputFromArrayItem", "Decode_decodeStepInputsFromArray", "Decode_inputStepDecoder", "Decode_decodeStepOutputItem", "Decode_outputStepsDecoder", "Decode_docDecoder", "Decode_labelDecoder", "Decode_intentDecoder", "Decode_hasField", "Decode_withDefaultCwlVersion", "Decode_workflowStepRunDecoder", "Decode_decodeWorkflowStepFromValueWithId", "Decode_decodeWorkflowStepFromArrayItem", "Decode_stepArrayDecoderWithVersion", "Decode_stepsDecoderWithVersion", "Decode_commandLineToolDecoder", "Decode_expressionToolDecoder", "Decode_operationDecoder", "Decode_workflowDecoder", "Decode_decodeCWLProcessingUnitElement", "Decode_stepArrayDecoder", "Decode_stepsDecoder", "Decode_decodeCommandLineTool", "Decode_decodeWorkflow", "Decode_decodeExpressionTool", "Decode_decodeOperation", "Decode_decodeCWLProcessingUnit", "DecodeParameters_cwlParameterReferenceDecoder", "DecodeParameters_cwlparameterReferenceArrayDecoder", "DecodeParameters_decodeYAMLParameterFile"]

