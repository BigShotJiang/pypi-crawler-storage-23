from __future__ import annotations
from ..fable_modules.dynamic_obj.dynamic_obj import (DynamicObj, DynamicObj_reflection)
from ..fable_modules.fable_library.option import default_arg
from ..fable_modules.fable_library.reflection import (TypeInfo, class_type)
from ..fable_modules.fable_library.types import Array
from .inputs import CWLInput
from .outputs import CWLOutput
from .requirements import (Requirement, HintEntry)

def _expr771() -> TypeInfo:
    return class_type("ARCtrl.CWL.CWLOperationDescription", None, CWLOperationDescription, DynamicObj_reflection())


class CWLOperationDescription(DynamicObj):
    def __init__(self, inputs: Array[CWLInput], outputs: Array[CWLOutput], cwl_version: str | None=None, requirements: Array[Requirement] | None=None, hints: Array[HintEntry] | None=None, intent: Array[str] | None=None, metadata: DynamicObj | None=None, label: str | None=None, doc: str | None=None) -> None:
        super().__init__()
        self._cwlVersion: str = default_arg(cwl_version, "v1.2")
        self._inputs: Array[CWLInput] = inputs
        self._outputs: Array[CWLOutput] = outputs
        self._requirements: Array[Requirement] | None = requirements
        self._hints: Array[HintEntry] | None = hints
        self._intent: Array[str] | None = intent
        self._metadata: DynamicObj | None = metadata
        self._label: str | None = label
        self._doc: str | None = doc

    @property
    def CWLVersion(self, __unit: None=None) -> str:
        this: CWLOperationDescription = self
        return this._cwlVersion

    @CWLVersion.setter
    def CWLVersion(self, value: str) -> None:
        this: CWLOperationDescription = self
        this._cwlVersion = value

    @property
    def Inputs(self, __unit: None=None) -> Array[CWLInput]:
        this: CWLOperationDescription = self
        return this._inputs

    @Inputs.setter
    def Inputs(self, value: Array[CWLInput]) -> None:
        this: CWLOperationDescription = self
        this._inputs = value

    @property
    def Outputs(self, __unit: None=None) -> Array[CWLOutput]:
        this: CWLOperationDescription = self
        return this._outputs

    @Outputs.setter
    def Outputs(self, value: Array[CWLOutput]) -> None:
        this: CWLOperationDescription = self
        this._outputs = value

    @property
    def Requirements(self, __unit: None=None) -> Array[Requirement] | None:
        this: CWLOperationDescription = self
        return this._requirements

    @Requirements.setter
    def Requirements(self, value: Array[Requirement] | None=None) -> None:
        this: CWLOperationDescription = self
        this._requirements = value

    @property
    def Hints(self, __unit: None=None) -> Array[HintEntry] | None:
        this: CWLOperationDescription = self
        return this._hints

    @Hints.setter
    def Hints(self, value: Array[HintEntry] | None=None) -> None:
        this: CWLOperationDescription = self
        this._hints = value

    @property
    def Intent(self, __unit: None=None) -> Array[str] | None:
        this: CWLOperationDescription = self
        return this._intent

    @Intent.setter
    def Intent(self, value: Array[str] | None=None) -> None:
        this: CWLOperationDescription = self
        this._intent = value

    @property
    def Metadata(self, __unit: None=None) -> DynamicObj | None:
        this: CWLOperationDescription = self
        return this._metadata

    @Metadata.setter
    def Metadata(self, value: DynamicObj | None=None) -> None:
        this: CWLOperationDescription = self
        this._metadata = value

    @property
    def Label(self, __unit: None=None) -> str | None:
        this: CWLOperationDescription = self
        return this._label

    @Label.setter
    def Label(self, value: str | None=None) -> None:
        this: CWLOperationDescription = self
        this._label = value

    @property
    def Doc(self, __unit: None=None) -> str | None:
        this: CWLOperationDescription = self
        return this._doc

    @Doc.setter
    def Doc(self, value: str | None=None) -> None:
        this: CWLOperationDescription = self
        this._doc = value

    @staticmethod
    def get_inputs(operation: CWLOperationDescription) -> Array[CWLInput]:
        return operation.Inputs

    @staticmethod
    def get_outputs(operation: CWLOperationDescription) -> Array[CWLOutput]:
        return operation.Outputs

    @staticmethod
    def get_requirements_or_empty(operation: CWLOperationDescription) -> Array[Requirement]:
        return default_arg(operation.Requirements, [])

    @staticmethod
    def get_hints_or_empty(operation: CWLOperationDescription) -> Array[HintEntry]:
        return default_arg(operation.Hints, [])

    @staticmethod
    def get_intent_or_empty(operation: CWLOperationDescription) -> Array[str]:
        return default_arg(operation.Intent, [])

    @staticmethod
    def get_or_create_hints(operation: CWLOperationDescription) -> Array[HintEntry]:
        match_value: Array[HintEntry] | None = operation.Hints
        if match_value is None:
            hints_1: Array[HintEntry] = []
            operation.Hints = hints_1
            return hints_1

        else: 
            return match_value


    @staticmethod
    def get_or_create_intent(operation: CWLOperationDescription) -> Array[str]:
        match_value: Array[str] | None = operation.Intent
        if match_value is None:
            intent_1: Array[str] = []
            operation.Intent = intent_1
            return intent_1

        else: 
            return match_value



CWLOperationDescription_reflection = _expr771

def CWLOperationDescription__ctor_58E129C8(inputs: Array[CWLInput], outputs: Array[CWLOutput], cwl_version: str | None=None, requirements: Array[Requirement] | None=None, hints: Array[HintEntry] | None=None, intent: Array[str] | None=None, metadata: DynamicObj | None=None, label: str | None=None, doc: str | None=None) -> CWLOperationDescription:
    return CWLOperationDescription(inputs, outputs, cwl_version, requirements, hints, intent, metadata, label, doc)


__all__ = ["CWLOperationDescription_reflection"]

