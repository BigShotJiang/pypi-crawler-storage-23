from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from ..fable_modules.dynamic_obj.dynamic_obj import (DynamicObj, DynamicObj_reflection)
from ..fable_modules.dynamic_obj.dyn_obj import set_optional_property
from ..fable_modules.fable_library.long import from_integer
from ..fable_modules.fable_library.option import bind
from ..fable_modules.fable_library.reflection import (TypeInfo, string_type, option_type, record_type, union_type, bool_type, int64_type, class_type, array_type)
from ..fable_modules.fable_library.seq import map
from ..fable_modules.fable_library.types import (Record, Array, Union, FSharpRef, int64)
from ..fable_modules.yamlicious.yamlicious_types import (YAMLElement, YAMLElement_reflection)
from .cwltypes import (SchemaSaladString, SchemaSaladString_reflection, DirentInstance_reflection, FileInstance_reflection, DirectoryInstance_reflection, SchemaDefRequirementType_reflection, SoftwarePackage_reflection)

def _expr738() -> TypeInfo:
    return record_type("ARCtrl.CWL.DockerRequirement", [], DockerRequirement, lambda: [("DockerPull", option_type(string_type)), ("DockerFile", option_type(SchemaSaladString_reflection())), ("DockerImageId", option_type(string_type)), ("DockerLoad", option_type(string_type)), ("DockerImport", option_type(string_type)), ("DockerOutputDirectory", option_type(string_type))])


@dataclass(eq = False, repr = False, slots = True)
class DockerRequirement(Record):
    DockerPull: str | None
    DockerFile: SchemaSaladString | None
    DockerImageId: str | None
    DockerLoad: str | None
    DockerImport: str | None
    DockerOutputDirectory: str | None

DockerRequirement_reflection = _expr738

def DockerRequirement_create_Z14898805(docker_pull: str | None=None, docker_file: str | None=None, docker_file_reference: SchemaSaladString | None=None, docker_image_id: str | None=None, docker_load: str | None=None, docker_import: str | None=None, docker_output_directory: str | None=None) -> DockerRequirement:
    return DockerRequirement(docker_pull, (None if (docker_file is None) else SchemaSaladString(0, docker_file)) if (docker_file_reference is None) else docker_file_reference, docker_image_id, docker_load, docker_import, docker_output_directory)


def _expr739() -> TypeInfo:
    return record_type("ARCtrl.CWL.EnvironmentDef", [], EnvironmentDef, lambda: [("EnvName", string_type), ("EnvValue", string_type)])


@dataclass(eq = False, repr = False, slots = True)
class EnvironmentDef(Record):
    EnvName: str
    EnvValue: str

EnvironmentDef_reflection = _expr739

def _expr740() -> TypeInfo:
    return union_type("ARCtrl.CWL.LoadListingEnum", [], LoadListingEnum, lambda: [[], [], []])


class LoadListingEnum(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["NoListing", "ShallowListing", "DeepListing"]


LoadListingEnum_reflection = _expr740

def LoadListingEnum_get_toCwlString(__unit: None=None) -> Callable[[LoadListingEnum], str]:
    def _arrow741(_arg: LoadListingEnum) -> str:
        return "shallow_listing" if (_arg.tag == 1) else ("deep_listing" if (_arg.tag == 2) else "no_listing")

    return _arrow741


def LoadListingEnum_tryParse_Z721C83C5(value: str) -> LoadListingEnum | None:
    if value == "no_listing":
        return LoadListingEnum(0)

    elif value == "shallow_listing":
        return LoadListingEnum(1)

    elif value == "deep_listing":
        return LoadListingEnum(2)

    else: 
        return None



def _expr742() -> TypeInfo:
    return record_type("ARCtrl.CWL.LoadListingRequirementValue", [], LoadListingRequirementValue, lambda: [("LoadListing", LoadListingEnum_reflection())])


@dataclass(eq = False, repr = False, slots = True)
class LoadListingRequirementValue(Record):
    LoadListing: LoadListingEnum

LoadListingRequirementValue_reflection = _expr742

def LoadListingRequirementValue_get_defaultNoListing(__unit: None=None) -> LoadListingRequirementValue:
    return LoadListingRequirementValue(LoadListingEnum(0))


def _expr743() -> TypeInfo:
    return record_type("ARCtrl.CWL.WorkReuseRequirementValue", [], WorkReuseRequirementValue, lambda: [("EnableReuse", bool_type)])


@dataclass(eq = False, repr = False, slots = True)
class WorkReuseRequirementValue(Record):
    EnableReuse: bool

WorkReuseRequirementValue_reflection = _expr743

def WorkReuseRequirementValue_get_defaultEnabled(__unit: None=None) -> WorkReuseRequirementValue:
    return WorkReuseRequirementValue(True)


def _expr744() -> TypeInfo:
    return record_type("ARCtrl.CWL.NetworkAccessRequirementValue", [], NetworkAccessRequirementValue, lambda: [("NetworkAccess", bool_type)])


@dataclass(eq = False, repr = False, slots = True)
class NetworkAccessRequirementValue(Record):
    NetworkAccess: bool

NetworkAccessRequirementValue_reflection = _expr744

def NetworkAccessRequirementValue_get_defaultEnabled(__unit: None=None) -> NetworkAccessRequirementValue:
    return NetworkAccessRequirementValue(True)


def _expr745() -> TypeInfo:
    return record_type("ARCtrl.CWL.InplaceUpdateRequirementValue", [], InplaceUpdateRequirementValue, lambda: [("InplaceUpdate", bool_type)])


@dataclass(eq = False, repr = False, slots = True)
class InplaceUpdateRequirementValue(Record):
    InplaceUpdate: bool

InplaceUpdateRequirementValue_reflection = _expr745

def InplaceUpdateRequirementValue_get_defaultEnabled(__unit: None=None) -> InplaceUpdateRequirementValue:
    return InplaceUpdateRequirementValue(True)


def _expr746() -> TypeInfo:
    return union_type("ARCtrl.CWL.ToolTimeLimitValue", [], ToolTimeLimitValue, lambda: [[("Item", int64_type)], [("Item", string_type)]])


class ToolTimeLimitValue(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["ToolTimeLimitSeconds", "ToolTimeLimitExpression"]


ToolTimeLimitValue_reflection = _expr746

def _expr747() -> TypeInfo:
    return class_type("ARCtrl.CWL.ResourceRequirementInstance", None, ResourceRequirementInstance, DynamicObj_reflection())


class ResourceRequirementInstance(DynamicObj):
    def __init__(self, cores_min: Any | None=None, cores_max: Any | None=None, ram_min: Any | None=None, ram_max: Any | None=None, tmpdir_min: Any | None=None, tmpdir_max: Any | None=None, outdir_min: Any | None=None, outdir_max: Any | None=None) -> None:
        super().__init__()
        this: FSharpRef[ResourceRequirementInstance] = FSharpRef(None)
        this.contents = self
        self.init_004099: int = 1
        set_optional_property("coresMin", cores_min, this.contents)
        set_optional_property("coresMax", cores_max, this.contents)
        set_optional_property("ramMin", ram_min, this.contents)
        set_optional_property("ramMax", ram_max, this.contents)
        set_optional_property("tmpdirMin", tmpdir_min, this.contents)
        set_optional_property("tmpdirMax", tmpdir_max, this.contents)
        set_optional_property("outdirMin", outdir_min, this.contents)
        set_optional_property("outdirMax", outdir_max, this.contents)


ResourceRequirementInstance_reflection = _expr747

def ResourceRequirementInstance__ctor_D76FC00(cores_min: Any | None=None, cores_max: Any | None=None, ram_min: Any | None=None, ram_max: Any | None=None, tmpdir_min: Any | None=None, tmpdir_max: Any | None=None, outdir_min: Any | None=None, outdir_max: Any | None=None) -> ResourceRequirementInstance:
    return ResourceRequirementInstance(cores_min, cores_max, ram_min, ram_max, tmpdir_min, tmpdir_max, outdir_min, outdir_max)


def ResourceRequirementInstance__TryGetInt64_Z721C83C5(this: ResourceRequirementInstance, name: str) -> int64 | None:
    def binder_1(_arg_1: Any=None, this: Any=this, name: Any=name) -> int64 | None:
        if str(type(_arg_1)) == "<class \'fable_modules.fable_library.types.int64\'>":
            return _arg_1

        elif str(type(_arg_1)) == "<class \'int\'>":
            return from_integer(_arg_1, False, 2)

        else: 
            return None


    def binder(_arg: Any=None, this: Any=this, name: Any=name) -> Any | None:
        return _arg

    return bind(binder_1, bind(binder, this.TryGetPropertyValue(name)))


def ResourceRequirementInstance__TryGetFloat_Z721C83C5(this: ResourceRequirementInstance, name: str) -> float | None:
    def binder_1(_arg_1: Any=None, this: Any=this, name: Any=name) -> float | None:
        if str(type(_arg_1)) == "<class \'float\'>":
            return _arg_1

        else: 
            return None


    def binder(_arg: Any=None, this: Any=this, name: Any=name) -> Any | None:
        return _arg

    return bind(binder_1, bind(binder, this.TryGetPropertyValue(name)))


def ResourceRequirementInstance__TryGetExpression_Z721C83C5(this: ResourceRequirementInstance, name: str) -> str | None:
    def binder_1(_arg_1: Any=None, this: Any=this, name: Any=name) -> str | None:
        if str(type(_arg_1)) == "<class \'str\'>":
            return _arg_1

        else: 
            return None


    def binder(_arg: Any=None, this: Any=this, name: Any=name) -> Any | None:
        return _arg

    return bind(binder_1, bind(binder, this.TryGetPropertyValue(name)))


def _expr748() -> TypeInfo:
    return union_type("ARCtrl.CWL.InitialWorkDirEntry", [], InitialWorkDirEntry, lambda: [[("Item", DirentInstance_reflection())], [("Item", SchemaSaladString_reflection())], [("Item", FileInstance_reflection())], [("Item", DirectoryInstance_reflection())]])


class InitialWorkDirEntry(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["DirentEntry", "StringEntry", "FileEntry", "DirectoryEntry"]


InitialWorkDirEntry_reflection = _expr748

def _expr749() -> TypeInfo:
    return record_type("ARCtrl.CWL.InlineJavascriptRequirementValue", [], InlineJavascriptRequirementValue, lambda: [("ExpressionLib", option_type(array_type(string_type)))])


@dataclass(eq = False, repr = False, slots = True)
class InlineJavascriptRequirementValue(Record):
    ExpressionLib: Array[str] | None

InlineJavascriptRequirementValue_reflection = _expr749

def InlineJavascriptRequirementValue_get_defaultEmpty(__unit: None=None) -> InlineJavascriptRequirementValue:
    return InlineJavascriptRequirementValue(None)


def _expr750() -> TypeInfo:
    return record_type("ARCtrl.CWL.HintUnknownValue", [], HintUnknownValue, lambda: [("Class", option_type(string_type)), ("Raw", YAMLElement_reflection())])


@dataclass(eq = False, repr = False, slots = True)
class HintUnknownValue(Record):
    Class: str | None
    Raw: YAMLElement

HintUnknownValue_reflection = _expr750

def _expr751() -> TypeInfo:
    return union_type("ARCtrl.CWL.Requirement", [], Requirement, lambda: [[("Item", InlineJavascriptRequirementValue_reflection())], [("Item", array_type(SchemaDefRequirementType_reflection()))], [("Item", DockerRequirement_reflection())], [("Item", array_type(SoftwarePackage_reflection()))], [("Item", LoadListingRequirementValue_reflection())], [("Item", array_type(InitialWorkDirEntry_reflection()))], [("Item", array_type(EnvironmentDef_reflection()))], [], [("Item", ResourceRequirementInstance_reflection())], [("Item", WorkReuseRequirementValue_reflection())], [("Item", string_type)], [("Item", NetworkAccessRequirementValue_reflection())], [("Item", string_type)], [("Item", InplaceUpdateRequirementValue_reflection())], [("Item", ToolTimeLimitValue_reflection())], [], [], [], []])


class Requirement(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["InlineJavascriptRequirement", "SchemaDefRequirement", "DockerRequirement", "SoftwareRequirement", "LoadListingRequirement", "InitialWorkDirRequirement", "EnvVarRequirement", "ShellCommandRequirement", "ResourceRequirement", "WorkReuseRequirement", "WorkReuseExpressionRequirement", "NetworkAccessRequirement", "NetworkAccessExpressionRequirement", "InplaceUpdateRequirement", "ToolTimeLimitRequirement", "SubworkflowFeatureRequirement", "ScatterFeatureRequirement", "MultipleInputFeatureRequirement", "StepInputExpressionRequirement"]


Requirement_reflection = _expr751

def Requirement_get_defaultInlineJavascriptRequirement(__unit: None=None) -> Requirement:
    return Requirement(0, InlineJavascriptRequirementValue_get_defaultEmpty())


def Requirement_get_defaultLoadListingNoListing(__unit: None=None) -> Requirement:
    return Requirement(4, LoadListingRequirementValue_get_defaultNoListing())


def Requirement_get_defaultWorkReuseEnabled(__unit: None=None) -> Requirement:
    return Requirement(9, WorkReuseRequirementValue_get_defaultEnabled())


def Requirement_get_defaultNetworkAccessEnabled(__unit: None=None) -> Requirement:
    return Requirement(11, NetworkAccessRequirementValue_get_defaultEnabled())


def Requirement_get_defaultInplaceUpdateEnabled(__unit: None=None) -> Requirement:
    return Requirement(13, InplaceUpdateRequirementValue_get_defaultEnabled())


def Requirement_defaultToolTimeLimitSeconds_Z524259C1(seconds: int64) -> Requirement:
    return Requirement(14, ToolTimeLimitValue(0, seconds))


def _expr752() -> TypeInfo:
    return union_type("ARCtrl.CWL.HintEntry", [], HintEntry, lambda: [[("Item", Requirement_reflection())], [("Item", HintUnknownValue_reflection())]])


class HintEntry(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["KnownHint", "UnknownHint"]


HintEntry_reflection = _expr752

def HintEntry_ofRequirement_Z5074C2C8(requirement: Requirement) -> HintEntry:
    return HintEntry(0, requirement)


def HintEntry_ofRequirements_1F652241(requirements: Array[Requirement]) -> Array[HintEntry]:
    def mapping(Item: Requirement, requirements: Any=requirements) -> HintEntry:
        return HintEntry(0, Item)

    return list(map(mapping, requirements))


def HintEntry_get_tryAsRequirement(__unit: None=None) -> Callable[[HintEntry], Requirement | None]:
    def _arrow753(_arg: HintEntry) -> Requirement | None:
        return None if (_arg.tag == 1) else _arg.fields[0]

    return _arrow753


__all__ = ["DockerRequirement_reflection", "DockerRequirement_create_Z14898805", "EnvironmentDef_reflection", "LoadListingEnum_reflection", "LoadListingEnum_get_toCwlString", "LoadListingEnum_tryParse_Z721C83C5", "LoadListingRequirementValue_reflection", "LoadListingRequirementValue_get_defaultNoListing", "WorkReuseRequirementValue_reflection", "WorkReuseRequirementValue_get_defaultEnabled", "NetworkAccessRequirementValue_reflection", "NetworkAccessRequirementValue_get_defaultEnabled", "InplaceUpdateRequirementValue_reflection", "InplaceUpdateRequirementValue_get_defaultEnabled", "ToolTimeLimitValue_reflection", "ResourceRequirementInstance_reflection", "ResourceRequirementInstance__TryGetInt64_Z721C83C5", "ResourceRequirementInstance__TryGetFloat_Z721C83C5", "ResourceRequirementInstance__TryGetExpression_Z721C83C5", "InitialWorkDirEntry_reflection", "InlineJavascriptRequirementValue_reflection", "InlineJavascriptRequirementValue_get_defaultEmpty", "HintUnknownValue_reflection", "Requirement_reflection", "Requirement_get_defaultInlineJavascriptRequirement", "Requirement_get_defaultLoadListingNoListing", "Requirement_get_defaultWorkReuseEnabled", "Requirement_get_defaultNetworkAccessEnabled", "Requirement_get_defaultInplaceUpdateEnabled", "Requirement_defaultToolTimeLimitSeconds_Z524259C1", "HintEntry_reflection", "HintEntry_ofRequirement_Z5074C2C8", "HintEntry_ofRequirements_1F652241", "HintEntry_get_tryAsRequirement"]

