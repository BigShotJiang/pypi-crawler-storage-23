from __future__ import annotations
from typing import Any
from ..fable_modules.fable_library.reflection import (TypeInfo, union_type)
from ..fable_modules.fable_library.seq import choose
from ..fable_modules.fable_library.types import (Array, Union)
from ..fable_modules.fable_library.util import IEnumerable_1
from .expression_tool_description import (CWLExpressionToolDescription_reflection, CWLExpressionToolDescription)
from .inputs import CWLInput
from .operation_description import (CWLOperationDescription_reflection, CWLOperationDescription)
from .outputs import CWLOutput
from .requirements import (Requirement, HintEntry, HintEntry_get_tryAsRequirement)
from .tool_description import (CWLToolDescription_reflection, CWLToolDescription)
from .workflow_description import (CWLWorkflowDescription_reflection, CWLWorkflowDescription)
from .workflow_steps import WorkflowStepRun

def _expr772() -> TypeInfo:
    return union_type("ARCtrl.CWL.CWLProcessingUnit", [], CWLProcessingUnit, lambda: [[("Item", CWLToolDescription_reflection())], [("Item", CWLWorkflowDescription_reflection())], [("Item", CWLExpressionToolDescription_reflection())], [("Item", CWLOperationDescription_reflection())]])


class CWLProcessingUnit(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["CommandLineTool", "Workflow", "ExpressionTool", "Operation"]


CWLProcessingUnit_reflection = _expr772

def CWLProcessingUnit_getInputs_30922B92(processing_unit: CWLProcessingUnit) -> Array[CWLInput]:
    if processing_unit.tag == 1:
        return CWLWorkflowDescription.get_inputs(processing_unit.fields[0])

    elif processing_unit.tag == 2:
        return CWLExpressionToolDescription.get_inputs_or_empty(processing_unit.fields[0])

    elif processing_unit.tag == 3:
        return CWLOperationDescription.get_inputs(processing_unit.fields[0])

    else: 
        return CWLToolDescription.get_inputs_or_empty(processing_unit.fields[0])



def CWLProcessingUnit_getOutputs_30922B92(processing_unit: CWLProcessingUnit) -> Array[CWLOutput]:
    if processing_unit.tag == 1:
        return CWLWorkflowDescription.get_outputs(processing_unit.fields[0])

    elif processing_unit.tag == 2:
        return CWLExpressionToolDescription.get_outputs(processing_unit.fields[0])

    elif processing_unit.tag == 3:
        return CWLOperationDescription.get_outputs(processing_unit.fields[0])

    else: 
        return CWLToolDescription.get_outputs(processing_unit.fields[0])



def CWLProcessingUnit_getRequirements_30922B92(processing_unit: CWLProcessingUnit) -> Array[Requirement]:
    if processing_unit.tag == 1:
        return CWLWorkflowDescription.get_requirements_or_empty(processing_unit.fields[0])

    elif processing_unit.tag == 2:
        return CWLExpressionToolDescription.get_requirements_or_empty(processing_unit.fields[0])

    elif processing_unit.tag == 3:
        return CWLOperationDescription.get_requirements_or_empty(processing_unit.fields[0])

    else: 
        return CWLToolDescription.get_requirements_or_empty(processing_unit.fields[0])



def CWLProcessingUnit_getHints_30922B92(processing_unit: CWLProcessingUnit) -> Array[HintEntry]:
    if processing_unit.tag == 1:
        return CWLWorkflowDescription.get_hints_or_empty(processing_unit.fields[0])

    elif processing_unit.tag == 2:
        return CWLExpressionToolDescription.get_hints_or_empty(processing_unit.fields[0])

    elif processing_unit.tag == 3:
        return CWLOperationDescription.get_hints_or_empty(processing_unit.fields[0])

    else: 
        return CWLToolDescription.get_hints_or_empty(processing_unit.fields[0])



def CWLProcessingUnit_getIntent_30922B92(processing_unit: CWLProcessingUnit) -> Array[str]:
    if processing_unit.tag == 1:
        return CWLWorkflowDescription.get_intent_or_empty(processing_unit.fields[0])

    elif processing_unit.tag == 2:
        return CWLExpressionToolDescription.get_intent_or_empty(processing_unit.fields[0])

    elif processing_unit.tag == 3:
        return CWLOperationDescription.get_intent_or_empty(processing_unit.fields[0])

    else: 
        return CWLToolDescription.get_intent_or_empty(processing_unit.fields[0])



def CWLProcessingUnit_getKnownHints_30922B92(processing_unit: CWLProcessingUnit) -> Array[Requirement]:
    def _arrow773(__unit: None=None, processing_unit: Any=processing_unit) -> IEnumerable_1[Requirement]:
        source: Array[HintEntry] = CWLProcessingUnit_getHints_30922B92(processing_unit)
        return choose(HintEntry_get_tryAsRequirement(), source)

    return list(_arrow773())


def WorkflowStepRunOps_fromTool(tool: CWLToolDescription) -> WorkflowStepRun:
    return WorkflowStepRun(1, tool)


def WorkflowStepRunOps_fromWorkflow(workflow: CWLWorkflowDescription) -> WorkflowStepRun:
    return WorkflowStepRun(2, workflow)


def WorkflowStepRunOps_fromExpressionTool(expression_tool: CWLExpressionToolDescription) -> WorkflowStepRun:
    return WorkflowStepRun(3, expression_tool)


def WorkflowStepRunOps_fromOperation(operation: CWLOperationDescription) -> WorkflowStepRun:
    return WorkflowStepRun(4, operation)


def WorkflowStepRunOps_tryGetTool(run: WorkflowStepRun) -> CWLToolDescription | None:
    (pattern_matching_result, tool) = (None, None)
    if run.tag == 1:
        if isinstance(run.fields[0], CWLToolDescription):
            pattern_matching_result = 0
            tool = run.fields[0]

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return tool

    elif pattern_matching_result == 1:
        return None



def WorkflowStepRunOps_tryGetWorkflow(run: WorkflowStepRun) -> CWLWorkflowDescription | None:
    (pattern_matching_result, workflow) = (None, None)
    if run.tag == 2:
        if isinstance(run.fields[0], CWLWorkflowDescription):
            pattern_matching_result = 0
            workflow = run.fields[0]

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return workflow

    elif pattern_matching_result == 1:
        return None



def WorkflowStepRunOps_tryGetExpressionTool(run: WorkflowStepRun) -> CWLExpressionToolDescription | None:
    (pattern_matching_result, expression_tool) = (None, None)
    if run.tag == 3:
        if isinstance(run.fields[0], CWLExpressionToolDescription):
            pattern_matching_result = 0
            expression_tool = run.fields[0]

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return expression_tool

    elif pattern_matching_result == 1:
        return None



def WorkflowStepRunOps_tryGetOperation(run: WorkflowStepRun) -> CWLOperationDescription | None:
    (pattern_matching_result, operation) = (None, None)
    if run.tag == 4:
        if isinstance(run.fields[0], CWLOperationDescription):
            pattern_matching_result = 0
            operation = run.fields[0]

        else: 
            pattern_matching_result = 1


    else: 
        pattern_matching_result = 1

    if pattern_matching_result == 0:
        return operation

    elif pattern_matching_result == 1:
        return None



__all__ = ["CWLProcessingUnit_reflection", "CWLProcessingUnit_getInputs_30922B92", "CWLProcessingUnit_getOutputs_30922B92", "CWLProcessingUnit_getRequirements_30922B92", "CWLProcessingUnit_getHints_30922B92", "CWLProcessingUnit_getIntent_30922B92", "CWLProcessingUnit_getKnownHints_30922B92", "WorkflowStepRunOps_fromTool", "WorkflowStepRunOps_fromWorkflow", "WorkflowStepRunOps_fromExpressionTool", "WorkflowStepRunOps_fromOperation", "WorkflowStepRunOps_tryGetTool", "WorkflowStepRunOps_tryGetWorkflow", "WorkflowStepRunOps_tryGetExpressionTool", "WorkflowStepRunOps_tryGetOperation"]

