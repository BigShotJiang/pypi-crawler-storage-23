from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from ..fable_modules.dynamic_obj.dynamic_obj import (DynamicObj, DynamicObj_reflection)
from ..fable_modules.dynamic_obj.dyn_obj import (remove_property, set_property, set_optional_property)
from ..fable_modules.fable_library.option import value as value_1
from ..fable_modules.fable_library.reflection import (TypeInfo, string_type, option_type, record_type, array_type, union_type, class_type)
from ..fable_modules.fable_library.types import (Record, Array, Union, FSharpRef)
from .cwltypes import CWLType

def _expr754() -> TypeInfo:
    return record_type("ARCtrl.CWL.OutputBinding", [], OutputBinding, lambda: [("Glob", option_type(string_type))])


@dataclass(eq = False, repr = False, slots = True)
class OutputBinding(Record):
    Glob: str | None

OutputBinding_reflection = _expr754

def OutputBinding_create_6DFDD678(glob: str | None=None) -> OutputBinding:
    return OutputBinding(glob)


def _expr755() -> TypeInfo:
    return union_type("ARCtrl.CWL.OutputSource", [], OutputSource, lambda: [[("Item", string_type)], [("Item", array_type(string_type))]])


class OutputSource(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Single", "Multiple"]

    def AsValues(self, __unit: None=None) -> Array[str]:
        this: OutputSource = self
        return this.fields[0] if (this.tag == 1) else [this.fields[0]]


OutputSource_reflection = _expr755

def _expr756() -> TypeInfo:
    return class_type("ARCtrl.CWL.CWLOutput", None, CWLOutput, DynamicObj_reflection())


class CWLOutput(DynamicObj):
    def __init__(self, name: str, type_: CWLType | None=None, output_binding: OutputBinding | None=None, output_source: OutputSource | None=None) -> None:
        super().__init__()
        this: FSharpRef[CWLOutput] = FSharpRef(None)
        self.name: str = name
        this.contents = self
        self.init_004023: int = 1
        set_optional_property("type", type_, this.contents)
        set_optional_property("outputBinding", output_binding, this.contents)
        set_optional_property("outputSource", output_source, this.contents)

    @property
    def Name(self, __unit: None=None) -> str:
        this: CWLOutput = self
        return this.name

    @property
    def Type_(self, __unit: None=None) -> CWLType | None:
        this: CWLOutput = self
        match_value: Any | None = this.TryGetPropertyValue("type")
        if match_value is not None:
            o: Any = value_1(match_value)
            return o if isinstance(o, CWLType) else None

        else: 
            return None


    @Type_.setter
    def Type_(self, value: CWLType | None=None) -> None:
        this: CWLOutput = self
        if value is None:
            remove_property("type", this)

        else: 
            set_property("type", value, this)


    @property
    def OutputBinding(self, __unit: None=None) -> OutputBinding | None:
        this: CWLOutput = self
        match_value: Any | None = this.TryGetPropertyValue("outputBinding")
        if match_value is not None:
            o: Any = value_1(match_value)
            return o if isinstance(o, OutputBinding) else None

        else: 
            return None


    @OutputBinding.setter
    def OutputBinding(self, value: OutputBinding | None=None) -> None:
        this: CWLOutput = self
        if value is None:
            remove_property("outputBinding", this)

        else: 
            set_property("outputBinding", value, this)


    @property
    def OutputSource(self, __unit: None=None) -> OutputSource | None:
        this: CWLOutput = self
        match_value: Any | None = this.TryGetPropertyValue("outputSource")
        if match_value is not None:
            o: Any = value_1(match_value)
            return o if isinstance(o, OutputSource) else None

        else: 
            return None


    @OutputSource.setter
    def OutputSource(self, value: OutputSource | None=None) -> None:
        this: CWLOutput = self
        (pattern_matching_result, v) = (None, None)
        if value is None:
            pattern_matching_result = 2

        elif value.tag == 1:
            if len(value.fields[0]) == 0:
                pattern_matching_result = 0

            else: 
                pattern_matching_result = 1
                v = value


        else: 
            pattern_matching_result = 1
            v = value

        if pattern_matching_result == 0:
            remove_property("outputSource", this)

        elif pattern_matching_result == 1:
            set_property("outputSource", v, this)

        elif pattern_matching_result == 2:
            remove_property("outputSource", this)


    def GetOutputSources(self, __unit: None=None) -> Array[str]:
        this: CWLOutput = self
        match_value: OutputSource | None = this.OutputSource
        if match_value is not None:
            output_source: OutputSource = match_value
            return output_source.AsValues()

        else: 
            return []



CWLOutput_reflection = _expr756

def CWLOutput__ctor_2471CF63(name: str, type_: CWLType | None=None, output_binding: OutputBinding | None=None, output_source: OutputSource | None=None) -> CWLOutput:
    return CWLOutput(name, type_, output_binding, output_source)


__all__ = ["OutputBinding_reflection", "OutputBinding_create_6DFDD678", "OutputSource_reflection", "CWLOutput_reflection"]

