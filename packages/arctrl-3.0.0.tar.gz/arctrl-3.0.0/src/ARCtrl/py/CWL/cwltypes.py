from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from ..fable_modules.dynamic_obj.dynamic_obj import (DynamicObj, DynamicObj_reflection)
from ..fable_modules.fable_library.reflection import (TypeInfo, string_type, union_type, class_type, option_type, bool_type, record_type, array_type)
from ..fable_modules.fable_library.seq import (for_all2, to_list, map)
from ..fable_modules.fable_library.string_ import (to_text, printf)
from ..fable_modules.fable_library.types import (Array, Union, Record)
from ..fable_modules.fable_library.util import (identity_hash, equals, array_hash, safe_hash, number_hash)

def _expr726() -> TypeInfo:
    return union_type("ARCtrl.CWL.SchemaSaladString", [], SchemaSaladString, lambda: [[("Item", string_type)], [("Item", string_type)], [("Item", string_type)]])


class SchemaSaladString(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["Literal", "Include", "Import"]


SchemaSaladString_reflection = _expr726

def SchemaSaladString__get_Value(this: SchemaSaladString) -> str:
    (pattern_matching_result, value) = (None, None)
    if this.tag == 1:
        pattern_matching_result = 0
        value = this.fields[0]

    elif this.tag == 2:
        pattern_matching_result = 0
        value = this.fields[0]

    else: 
        pattern_matching_result = 0
        value = this.fields[0]

    if pattern_matching_result == 0:
        return value



def SchemaSaladString__get_AsDirectiveString(this: SchemaSaladString) -> str:
    if this.tag == 1:
        return to_text(printf("$include: %s"))(this.fields[0])

    elif this.tag == 2:
        return to_text(printf("$import: %s"))(this.fields[0])

    else: 
        return this.fields[0]



def SchemaSaladStringModule_literal(value: str) -> SchemaSaladString:
    return SchemaSaladString(0, value)


def SchemaSaladStringModule_includePath(value: str) -> SchemaSaladString:
    return SchemaSaladString(1, value)


def SchemaSaladStringModule_importPath(value: str) -> SchemaSaladString:
    return SchemaSaladString(2, value)


def SchemaSaladStringModule_value(salad_string: SchemaSaladString) -> str:
    return SchemaSaladString__get_Value(salad_string)


def SchemaSaladStringModule_toDirectiveString(salad_string: SchemaSaladString) -> str:
    return SchemaSaladString__get_AsDirectiveString(salad_string)


def _expr727() -> TypeInfo:
    return class_type("ARCtrl.CWL.FileInstance", None, FileInstance, DynamicObj_reflection())


class FileInstance(DynamicObj):
    def __init__(self, __unit: None=None) -> None:
        super().__init__()
        pass

    def __hash__(self, __unit: None=None) -> int:
        this: FileInstance = self
        return identity_hash(this.DeepCopyProperties())

    def __eq__(self, o: Any=None) -> bool:
        this: FileInstance = self
        return this.StructurallyEquals(o) if isinstance(o, FileInstance) else False


FileInstance_reflection = _expr727

def FileInstance__ctor(__unit: None=None) -> FileInstance:
    return FileInstance(__unit)


def _expr728() -> TypeInfo:
    return class_type("ARCtrl.CWL.DirectoryInstance", None, DirectoryInstance, DynamicObj_reflection())


class DirectoryInstance(DynamicObj):
    def __init__(self, __unit: None=None) -> None:
        super().__init__()
        pass

    def __eq__(self, o: Any=None) -> bool:
        this: DirectoryInstance = self
        return this.StructurallyEquals(o) if isinstance(o, DirectoryInstance) else False

    def __hash__(self, __unit: None=None) -> int:
        this: DirectoryInstance = self
        return identity_hash(this.DeepCopyProperties())


DirectoryInstance_reflection = _expr728

def DirectoryInstance__ctor(__unit: None=None) -> DirectoryInstance:
    return DirectoryInstance(__unit)


def _expr729() -> TypeInfo:
    return record_type("ARCtrl.CWL.DirentInstance", [], DirentInstance, lambda: [("Entry", SchemaSaladString_reflection()), ("Entryname", option_type(SchemaSaladString_reflection())), ("Writable", option_type(bool_type))])


@dataclass(eq = False, repr = False, slots = True)
class DirentInstance(Record):
    Entry: SchemaSaladString
    Entryname: SchemaSaladString | None
    Writable: bool | None

DirentInstance_reflection = _expr729

def _expr731() -> TypeInfo:
    return record_type("ARCtrl.CWL.InputEnumSchema", [], InputEnumSchema, lambda: [("Symbols", array_type(string_type)), ("Label", option_type(string_type)), ("Doc", option_type(string_type)), ("Name", option_type(string_type))])


@dataclass(eq = False, repr = False, slots = True)
class InputEnumSchema(Record):
    Symbols: Array[str]
    Label: str | None
    Doc: str | None
    Name: str | None
    def __eq__(self, o: Any=None) -> bool:
        this: InputEnumSchema = self
        def _arrow730(x: str, y: str) -> bool:
            return x == y

        return (for_all2(_arrow730, this.Symbols, o.Symbols) if ((len(this.Symbols) == len(o.Symbols)) if (equals(this.Name, o.Name) if (equals(this.Doc, o.Doc) if equals(this.Label, o.Label) else False) else False) else False) else False) if isinstance(o, InputEnumSchema) else False

    def __hash__(self, __unit: None=None) -> int:
        this: InputEnumSchema = self
        return array_hash((to_list(this.Symbols), this.Label, this.Doc, this.Name))


InputEnumSchema_reflection = _expr731

def _expr732() -> TypeInfo:
    return record_type("ARCtrl.CWL.InputRecordField", [], InputRecordField, lambda: [("Name", string_type), ("Type", CWLType_reflection()), ("Doc", option_type(string_type)), ("Label", option_type(string_type))])


@dataclass(eq = False, repr = False, slots = True)
class InputRecordField(Record):
    Name: str
    Type: CWLType
    Doc: str | None
    Label: str | None
    def __eq__(self, o: Any=None) -> bool:
        this: InputRecordField = self
        return (equals(this.Label, o.Label) if (equals(this.Doc, o.Doc) if (equals(this.Type, o.Type) if (this.Name == o.Name) else False) else False) else False) if isinstance(o, InputRecordField) else False

    def __hash__(self, __unit: None=None) -> int:
        this: InputRecordField = self
        return array_hash((this.Name, this.Type, this.Doc, this.Label))


InputRecordField_reflection = _expr732

def _expr733() -> TypeInfo:
    return record_type("ARCtrl.CWL.InputRecordSchema", [], InputRecordSchema, lambda: [("Fields", option_type(array_type(InputRecordField_reflection()))), ("Label", option_type(string_type)), ("Doc", option_type(string_type)), ("Name", option_type(string_type))])


@dataclass(eq = False, repr = False, slots = True)
class InputRecordSchema(Record):
    Fields: Array[InputRecordField] | None
    Label: str | None
    Doc: str | None
    Name: str | None
    def __eq__(self, o: Any=None) -> bool:
        this: InputRecordSchema = self
        if isinstance(o, InputRecordSchema):
            if equals(this.Name, o.Name) if (equals(this.Doc, o.Doc) if equals(this.Label, o.Label) else False) else False:
                match_value: Array[InputRecordField] | None = this.Fields
                match_value_1: Array[InputRecordField] | None = o.Fields
                (pattern_matching_result, f1, f2) = (None, None, None)
                if match_value is not None:
                    if match_value_1 is not None:
                        pattern_matching_result = 1
                        f1 = match_value
                        f2 = match_value_1

                    else: 
                        pattern_matching_result = 2


                elif match_value_1 is None:
                    pattern_matching_result = 0

                else: 
                    pattern_matching_result = 2

                if pattern_matching_result == 0:
                    return True

                elif pattern_matching_result == 1:
                    return for_all2(equals, f1, f2) if (len(f1) == len(f2)) else False

                elif pattern_matching_result == 2:
                    return False


            else: 
                return False


        else: 
            return False


    def __hash__(self, __unit: None=None) -> int:
        this: InputRecordSchema = self
        return array_hash((this.Fields, this.Label, this.Doc, this.Name))


InputRecordSchema_reflection = _expr733

def _expr734() -> TypeInfo:
    return record_type("ARCtrl.CWL.InputArraySchema", [], InputArraySchema, lambda: [("Items", CWLType_reflection()), ("Label", option_type(string_type)), ("Doc", option_type(string_type)), ("Name", option_type(string_type))])


@dataclass(eq = False, repr = False, slots = True)
class InputArraySchema(Record):
    Items: CWLType
    Label: str | None
    Doc: str | None
    Name: str | None
    def __eq__(self, o: Any=None) -> bool:
        this: InputArraySchema = self
        return (equals(this.Name, o.Name) if (equals(this.Doc, o.Doc) if (equals(this.Label, o.Label) if equals(this.Items, o.Items) else False) else False) else False) if isinstance(o, InputArraySchema) else False

    def __hash__(self, __unit: None=None) -> int:
        this: InputArraySchema = self
        return array_hash((this.Items, this.Label, this.Doc, this.Name))


InputArraySchema_reflection = _expr734

def _expr735() -> TypeInfo:
    return union_type("ARCtrl.CWL.CWLType", [], CWLType, lambda: [[("Item", FileInstance_reflection())], [("Item", DirectoryInstance_reflection())], [("Item", DirentInstance_reflection())], [], [], [], [], [], [], [], [], [("Item", InputArraySchema_reflection())], [("Item", InputRecordSchema_reflection())], [("Item", InputEnumSchema_reflection())], [("Item", array_type(CWLType_reflection()))]])


class CWLType(Union):
    def __init__(self, tag: int, *fields: Any) -> None:
        super().__init__()
        self.tag: int = tag or 0
        self.fields: Array[Any] = list(fields)

    @staticmethod
    def cases() -> list[str]:
        return ["File", "Directory", "Dirent", "String", "Int", "Long", "Float", "Double", "Boolean", "Stdout", "Null", "Array", "Record", "Enum", "Union"]

    def __eq__(self, o: Any=None) -> bool:
        this: CWLType = self
        return ((equals(this.fields[0], o.fields[0]) if (o.tag == 1) else False) if (this.tag == 1) else ((equals(this.fields[0], o.fields[0]) if (o.tag == 2) else False) if (this.tag == 2) else ((True if (o.tag == 3) else False) if (this.tag == 3) else ((True if (o.tag == 4) else False) if (this.tag == 4) else ((True if (o.tag == 5) else False) if (this.tag == 5) else ((True if (o.tag == 6) else False) if (this.tag == 6) else ((True if (o.tag == 7) else False) if (this.tag == 7) else ((True if (o.tag == 8) else False) if (this.tag == 8) else ((True if (o.tag == 9) else False) if (this.tag == 9) else ((True if (o.tag == 10) else False) if (this.tag == 10) else ((equals(this.fields[0], o.fields[0]) if (o.tag == 11) else False) if (this.tag == 11) else ((equals(this.fields[0], o.fields[0]) if (o.tag == 12) else False) if (this.tag == 12) else ((equals(this.fields[0], o.fields[0]) if (o.tag == 13) else False) if (this.tag == 13) else (((for_all2(equals, this.fields[0], o.fields[0]) if (len(this.fields[0]) == len(o.fields[0])) else False) if (o.tag == 14) else False) if (this.tag == 14) else (equals(this.fields[0], o.fields[0]) if (o.tag == 0) else False))))))))))))))) if isinstance(o, CWLType) else False

    def __hash__(self, __unit: None=None) -> int:
        this: CWLType = self
        if this.tag == 1:
            return array_hash((1, safe_hash(this.fields[0])))

        elif this.tag == 2:
            return array_hash((2, this.fields[0]))

        elif this.tag == 3:
            return number_hash(3)

        elif this.tag == 4:
            return number_hash(4)

        elif this.tag == 5:
            return number_hash(5)

        elif this.tag == 6:
            return number_hash(6)

        elif this.tag == 7:
            return number_hash(7)

        elif this.tag == 8:
            return number_hash(8)

        elif this.tag == 9:
            return number_hash(9)

        elif this.tag == 10:
            return number_hash(10)

        elif this.tag == 11:
            return array_hash((11, this.fields[0]))

        elif this.tag == 12:
            return array_hash((12, this.fields[0]))

        elif this.tag == 13:
            return array_hash((13, this.fields[0]))

        elif this.tag == 14:
            return array_hash((14, to_list(map(safe_hash, this.fields[0]))))

        else: 
            return array_hash((0, safe_hash(this.fields[0])))



CWLType_reflection = _expr735

def CWLType_file(__unit: None=None) -> CWLType:
    return CWLType(0, FileInstance__ctor())


def CWLType_directory(__unit: None=None) -> CWLType:
    return CWLType(1, DirectoryInstance__ctor())


def _expr736() -> TypeInfo:
    return record_type("ARCtrl.CWL.SchemaDefRequirementType", [], SchemaDefRequirementType, lambda: [("Name", string_type), ("Type_", CWLType_reflection())])


@dataclass(eq = False, repr = False, slots = True)
class SchemaDefRequirementType(Record):
    Name: str
    Type_: CWLType

SchemaDefRequirementType_reflection = _expr736

def _expr737() -> TypeInfo:
    return record_type("ARCtrl.CWL.SoftwarePackage", [], SoftwarePackage, lambda: [("Package", string_type), ("Version", option_type(array_type(string_type))), ("Specs", option_type(array_type(string_type)))])


@dataclass(eq = False, repr = False, slots = True)
class SoftwarePackage(Record):
    Package: str
    Version: Array[str] | None
    Specs: Array[str] | None

SoftwarePackage_reflection = _expr737

__all__ = ["SchemaSaladString_reflection", "SchemaSaladString__get_Value", "SchemaSaladString__get_AsDirectiveString", "SchemaSaladStringModule_literal", "SchemaSaladStringModule_includePath", "SchemaSaladStringModule_importPath", "SchemaSaladStringModule_value", "SchemaSaladStringModule_toDirectiveString", "FileInstance_reflection", "DirectoryInstance_reflection", "DirentInstance_reflection", "InputEnumSchema_reflection", "InputRecordField_reflection", "InputRecordSchema_reflection", "InputArraySchema_reflection", "CWLType_reflection", "CWLType_file", "CWLType_directory", "SchemaDefRequirementType_reflection", "SoftwarePackage_reflection"]

