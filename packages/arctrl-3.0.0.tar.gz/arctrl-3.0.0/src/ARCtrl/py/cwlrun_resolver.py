from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from .CWL.cwlprocessing_unit import (CWLProcessingUnit_reflection, CWLProcessingUnit, WorkflowStepRunOps_fromWorkflow, WorkflowStepRunOps_fromExpressionTool, WorkflowStepRunOps_fromOperation, WorkflowStepRunOps_fromTool, WorkflowStepRunOps_tryGetWorkflow)
from .CWL.workflow_description import CWLWorkflowDescription
from .CWL.workflow_steps import (WorkflowStepRun, WorkflowStep)
from .FileSystem.path import (normalize_path_key, normalize, resolve_path_from_file)
from .fable_modules.fable_library.array_ import (filter, map)
from .fable_modules.fable_library.map import (FSharpMap__Add, FSharpMap__TryFind, empty)
from .fable_modules.fable_library.reflection import (TypeInfo, string_type, class_type, record_type)
from .fable_modules.fable_library.seq2 import Array_distinct
from .fable_modules.fable_library.set import (FSharpSet__Contains, FSharpSet__Add, empty as empty_1)
from .fable_modules.fable_library.string_ import (is_null_or_white_space, ends_with)
from .fable_modules.fable_library.types import (Record, Array)
from .fable_modules.fable_library.util import (string_hash, get_enumerator, dispose, compare_primitives)

def path_key(path: str) -> str:
    return normalize_path_key(path)


def _expr4286() -> TypeInfo:
    return record_type("ARCtrl.CWLRunResolver.RunResolutionState", [], RunResolutionState, lambda: [("Cache", class_type("Microsoft.FSharp.Collections.FSharpMap`2", [string_type, CWLProcessingUnit_reflection()]))])


@dataclass(eq = False, repr = False, slots = True)
class RunResolutionState(Record):
    Cache: Any

RunResolutionState_reflection = _expr4286

def get_run_node_candidates(workflow_file_path: str, run_path: str) -> Array[str]:
    if is_null_or_white_space(run_path):
        return []

    else: 
        trimmed_run_path: str = run_path.strip()
        if not ends_with(trimmed_run_path, ".cwl", 5):
            return []

        else: 
            normalized_run_path: str = normalize(trimmed_run_path)
            run_path_in_workflow_directory: str = resolve_path_from_file(workflow_file_path, trimmed_run_path)
            def predicate(p: str, workflow_file_path: Any=workflow_file_path, run_path: Any=run_path) -> bool:
                return not is_null_or_white_space(p)

            class ObjectExpr4288:
                @property
                def Equals(self) -> Callable[[str, str], bool]:
                    def _arrow4287(x: str, y: str) -> bool:
                        return x == y

                    return _arrow4287

                @property
                def GetHashCode(self) -> Callable[[str], int]:
                    return string_hash

            return Array_distinct(filter(predicate, [trimmed_run_path, normalized_run_path, run_path_in_workflow_directory, normalize(run_path_in_workflow_directory)]), ObjectExpr4288())




def cache_resolved_processing_unit(state: RunResolutionState, candidate_keys: Array[str], processing_unit: CWLProcessingUnit) -> None:
    for idx in range(0, (len(candidate_keys) - 1) + 1, 1):
        key: str = candidate_keys[idx]
        state.Cache = FSharpMap__Add(state.Cache, key, processing_unit)


def run_from_processing_unit(processing_unit: CWLProcessingUnit) -> WorkflowStepRun:
    if processing_unit.tag == 1:
        return WorkflowStepRunOps_fromWorkflow(processing_unit.fields[0])

    elif processing_unit.tag == 2:
        return WorkflowStepRunOps_fromExpressionTool(processing_unit.fields[0])

    elif processing_unit.tag == 3:
        return WorkflowStepRunOps_fromOperation(processing_unit.fields[0])

    else: 
        return WorkflowStepRunOps_fromTool(processing_unit.fields[0])



def resolve_workflow_runs_recursive_with_resolver(workflow_file_path: str, active_path_keys: Any, state: RunResolutionState, workflow: CWLWorkflowDescription, try_resolve_run_path: Callable[[str], CWLProcessingUnit | None]) -> None:
    enumerator: Any = get_enumerator(workflow.Steps)
    try: 
        while enumerator.System_Collections_IEnumerator_MoveNext():
            step: WorkflowStep = enumerator.System_Collections_Generic_IEnumerator_1_get_Current()
            resolved_run: WorkflowStepRun = resolve_workflow_step_run_recursive_with_resolver(workflow_file_path, active_path_keys, state, step.Run, try_resolve_run_path)
            step.Run = resolved_run

    finally: 
        dispose(enumerator)



def resolve_workflow_step_run_recursive_with_resolver(workflow_file_path: str, active_path_keys: Any, state: RunResolutionState, run: WorkflowStepRun, try_resolve_run_path: Callable[[str], CWLProcessingUnit | None]) -> WorkflowStepRun:
    if run.tag == 2:
        match_value_2: CWLWorkflowDescription | None = WorkflowStepRunOps_tryGetWorkflow(run)
        if match_value_2 is None:
            return run

        else: 
            workflow_1: CWLWorkflowDescription = match_value_2
            resolve_workflow_runs_recursive_with_resolver(workflow_file_path, active_path_keys, state, workflow_1, try_resolve_run_path)
            return WorkflowStepRunOps_fromWorkflow(workflow_1)


    elif run.tag == 1:
        return run

    elif run.tag == 3:
        return run

    elif run.tag == 4:
        return run

    else: 
        run_path: str = run.fields[0]
        candidates: Array[str] = get_run_node_candidates(workflow_file_path, run_path)
        def _arrow4289(path: str, workflow_file_path: Any=workflow_file_path, active_path_keys: Any=active_path_keys, state: Any=state, run: Any=run, try_resolve_run_path: Any=try_resolve_run_path) -> str:
            return path_key(path)

        class ObjectExpr4291:
            @property
            def Equals(self) -> Callable[[str, str], bool]:
                def _arrow4290(x: str, y: str) -> bool:
                    return x == y

                return _arrow4290

            @property
            def GetHashCode(self) -> Callable[[str], int]:
                return string_hash

        candidate_keys: Array[str] = Array_distinct(map(_arrow4289, candidates, None), ObjectExpr4291())
        def try_resolve_candidate(index_mut: int, workflow_file_path: Any=workflow_file_path, active_path_keys: Any=active_path_keys, state: Any=state, run: Any=run, try_resolve_run_path: Any=try_resolve_run_path) -> WorkflowStepRun:
            while True:
                (index,) = (index_mut,)
                if index >= len(candidates):
                    return WorkflowStepRun(0, run_path)

                else: 
                    candidate: str = candidates[index]
                    key: str = path_key(candidate)
                    if FSharpSet__Contains(active_path_keys, key):
                        index_mut = index + 1
                        continue

                    else: 
                        match_value: CWLProcessingUnit | None = FSharpMap__TryFind(state.Cache, key)
                        if match_value is None:
                            match_value_1: CWLProcessingUnit | None = try_resolve_run_path(candidate)
                            if match_value_1 is None:
                                index_mut = index + 1
                                continue

                            elif match_value_1.tag == 1:
                                workflow: CWLWorkflowDescription = match_value_1.fields[0]
                                resolve_workflow_runs_recursive_with_resolver(candidate, FSharpSet__Add(active_path_keys, key), state, workflow, try_resolve_run_path)
                                resolved: CWLProcessingUnit = CWLProcessingUnit(1, workflow)
                                cache_resolved_processing_unit(state, candidate_keys, resolved)
                                return run_from_processing_unit(resolved)

                            else: 
                                processing_unit: CWLProcessingUnit = match_value_1
                                cache_resolved_processing_unit(state, candidate_keys, processing_unit)
                                return run_from_processing_unit(processing_unit)


                        else: 
                            return run_from_processing_unit(match_value)



                break

        try_resolve_candidate: Callable[[int], WorkflowStepRun] = try_resolve_candidate
        return try_resolve_candidate(0)



def resolve_run_references_from_lookup(workflow_file_path: str, processing_unit: CWLProcessingUnit, try_resolve_run_path: Callable[[str], CWLProcessingUnit | None]) -> CWLProcessingUnit:
    if processing_unit.tag == 0:
        return processing_unit

    elif processing_unit.tag == 2:
        return processing_unit

    elif processing_unit.tag == 3:
        return processing_unit

    else: 
        workflow: CWLWorkflowDescription = processing_unit.fields[0]
        class ObjectExpr4292:
            @property
            def Compare(self) -> Callable[[str, str], int]:
                return compare_primitives

        state: RunResolutionState = RunResolutionState(empty(ObjectExpr4292()))
        class ObjectExpr4293:
            @property
            def Compare(self) -> Callable[[str, str], int]:
                return compare_primitives

        resolve_workflow_runs_recursive_with_resolver(workflow_file_path, empty_1(ObjectExpr4293()), state, workflow, try_resolve_run_path)
        return CWLProcessingUnit(1, workflow)



def resolve_workflow_step_run_from_lookup(workflow_file_path: str, run: WorkflowStepRun, try_resolve_run_path: Callable[[str], CWLProcessingUnit | None]) -> WorkflowStepRun:
    class ObjectExpr4294:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    state: RunResolutionState = RunResolutionState(empty(ObjectExpr4294()))
    class ObjectExpr4295:
        @property
        def Compare(self) -> Callable[[str, str], int]:
            return compare_primitives

    return resolve_workflow_step_run_recursive_with_resolver(workflow_file_path, empty_1(ObjectExpr4295()), state, run, try_resolve_run_path)


__all__ = ["path_key", "RunResolutionState_reflection", "get_run_node_candidates", "cache_resolved_processing_unit", "run_from_processing_unit", "resolve_workflow_runs_recursive_with_resolver", "resolve_workflow_step_run_recursive_with_resolver", "resolve_run_references_from_lookup", "resolve_workflow_step_run_from_lookup"]

