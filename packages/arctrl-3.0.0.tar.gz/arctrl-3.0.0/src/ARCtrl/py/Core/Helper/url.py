from collections.abc import Callable
from typing import Any
from ...fable_modules.fable_library.util import to_enumerable
from .collections_ import (Dictionary_ofSeq, Dictionary_tryFind)

def OntobeeParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "http://purl.obolibrary.org/obo/") + "") + tsr) + "_") + local_tan) + ""


def BioregistryParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "https://bioregistry.io/") + "") + tsr) + ":") + local_tan) + ""


def OntobeeDPBOParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "http://purl.org/nfdi4plants/ontology/dpbo/") + "") + tsr) + "_") + local_tan) + ""


def MSParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "https://www.ebi.ac.uk/ols4/ontologies/ms/classes/http%253A%252F%252Fpurl.obolibrary.org%252Fobo%252F") + "") + tsr) + "_") + local_tan) + ""


def POParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "https://www.ebi.ac.uk/ols4/ontologies/po/classes/http%253A%252F%252Fpurl.obolibrary.org%252Fobo%252F") + "") + tsr) + "_") + local_tan) + ""


def ROParser(tsr: str, local_tan: str) -> str:
    return ((((("" + "https://www.ebi.ac.uk/ols4/ontologies/ro/classes/http%253A%252F%252Fpurl.obolibrary.org%252Fobo%252F") + "") + tsr) + "_") + local_tan) + ""


def _arrow777(tsr: str) -> Callable[[str], str]:
    def _arrow776(local_tan: str) -> str:
        return OntobeeDPBOParser(tsr, local_tan)

    return _arrow776


def _arrow779(tsr_1: str) -> Callable[[str], str]:
    def _arrow778(local_tan_1: str) -> str:
        return MSParser(tsr_1, local_tan_1)

    return _arrow778


def _arrow781(tsr_2: str) -> Callable[[str], str]:
    def _arrow780(local_tan_2: str) -> str:
        return POParser(tsr_2, local_tan_2)

    return _arrow780


def _arrow783(tsr_3: str) -> Callable[[str], str]:
    def _arrow782(local_tan_3: str) -> str:
        return ROParser(tsr_3, local_tan_3)

    return _arrow782


def _arrow785(tsr_4: str) -> Callable[[str], str]:
    def _arrow784(local_tan_4: str) -> str:
        return BioregistryParser(tsr_4, local_tan_4)

    return _arrow784


def _arrow787(tsr_5: str) -> Callable[[str], str]:
    def _arrow786(local_tan_5: str) -> str:
        return BioregistryParser(tsr_5, local_tan_5)

    return _arrow786


def _arrow789(tsr_6: str) -> Callable[[str], str]:
    def _arrow788(local_tan_6: str) -> str:
        return BioregistryParser(tsr_6, local_tan_6)

    return _arrow788


def _arrow791(tsr_7: str) -> Callable[[str], str]:
    def _arrow790(local_tan_7: str) -> str:
        return BioregistryParser(tsr_7, local_tan_7)

    return _arrow790


def _arrow793(tsr_8: str) -> Callable[[str], str]:
    def _arrow792(local_tan_8: str) -> str:
        return BioregistryParser(tsr_8, local_tan_8)

    return _arrow792


def _arrow795(tsr_9: str) -> Callable[[str], str]:
    def _arrow794(local_tan_9: str) -> str:
        return BioregistryParser(tsr_9, local_tan_9)

    return _arrow794


def _arrow797(tsr_10: str) -> Callable[[str], str]:
    def _arrow796(local_tan_10: str) -> str:
        return BioregistryParser(tsr_10, local_tan_10)

    return _arrow796


def _arrow799(tsr_11: str) -> Callable[[str], str]:
    def _arrow798(local_tan_11: str) -> str:
        return BioregistryParser(tsr_11, local_tan_11)

    return _arrow798


def _arrow801(tsr_12: str) -> Callable[[str], str]:
    def _arrow800(local_tan_12: str) -> str:
        return BioregistryParser(tsr_12, local_tan_12)

    return _arrow800


def _arrow803(tsr_13: str) -> Callable[[str], str]:
    def _arrow802(local_tan_13: str) -> str:
        return BioregistryParser(tsr_13, local_tan_13)

    return _arrow802


def _arrow805(tsr_14: str) -> Callable[[str], str]:
    def _arrow804(local_tan_14: str) -> str:
        return BioregistryParser(tsr_14, local_tan_14)

    return _arrow804


uri_parser_collection: Any = Dictionary_ofSeq(to_enumerable([("DPBO", _arrow777), ("MS", _arrow779), ("PO", _arrow781), ("RO", _arrow783), ("ENVO", _arrow785), ("CHEBI", _arrow787), ("GO", _arrow789), ("OBI", _arrow791), ("PATO", _arrow793), ("PECO", _arrow795), ("TO", _arrow797), ("UO", _arrow799), ("EFO", _arrow801), ("NCIT", _arrow803), ("OMP", _arrow805)]))

def create_oauri(tsr: str, local_tan: str) -> str:
    match_value: Callable[[str, str], str] | None = Dictionary_tryFind(tsr, uri_parser_collection)
    if match_value is None:
        return OntobeeParser(tsr, local_tan)

    else: 
        return match_value(tsr)(local_tan)



__all__ = ["OntobeeParser", "BioregistryParser", "OntobeeDPBOParser", "MSParser", "POParser", "ROParser", "uri_parser_collection", "create_oauri"]

