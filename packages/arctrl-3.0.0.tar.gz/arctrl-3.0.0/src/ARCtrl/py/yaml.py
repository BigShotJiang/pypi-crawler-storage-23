from __future__ import annotations
from typing import Any
from .CWL.cwlprocessing_unit import CWLProcessingUnit
from .CWL.decode import (Decode_decodeCWLProcessingUnit, DecodeParameters_decodeYAMLParameterFile)
from .CWL.encode import (encode_processing_unit, write_yaml, y_map)
from .CWL.parameter_reference import CWLParameterReference
from .fable_modules.fable_library.reflection import (TypeInfo, class_type)
from .fable_modules.fable_library.seq import (to_list, map)
from .fable_modules.fable_library.types import Array
from .fable_modules.yamlicious.encode import (string, seq)
from .fable_modules.yamlicious.yamlicious_types import YAMLElement

def _expr4516() -> TypeInfo:
    return class_type("ARCtrl.YamlHelper.ProcessingUnitYAML", None, YamlHelper_ProcessingUnitYAML)


class YamlHelper_ProcessingUnitYAML:
    def __init__(self, __unit: None=None) -> None:
        pass

    def from_yamlstring(self, s: str) -> CWLProcessingUnit:
        return Decode_decodeCWLProcessingUnit(s)

    def to_yamlstring(self, pu: CWLProcessingUnit) -> str:
        return encode_processing_unit(pu)


YamlHelper_ProcessingUnitYAML_reflection = _expr4516

def YamlHelper_ProcessingUnitYAML__ctor(__unit: None=None) -> YamlHelper_ProcessingUnitYAML:
    return YamlHelper_ProcessingUnitYAML(__unit)


def _expr4518() -> TypeInfo:
    return class_type("ARCtrl.YamlHelper.ParameterReferenceYAML", None, YamlHelper_ParameterReferenceYAML)


class YamlHelper_ParameterReferenceYAML:
    def __init__(self, __unit: None=None) -> None:
        pass

    def from_yamlstring(self, s: str) -> Array[CWLParameterReference]:
        return DecodeParameters_decodeYAMLParameterFile(s)

    def to_yamlstring(self, pr: Array[CWLParameterReference]) -> str:
        def mapping(p: CWLParameterReference) -> tuple[str, YAMLElement]:
            def _arrow4517(value: str, p: Any=p) -> YAMLElement:
                return string(value)

            values: YAMLElement = string(p.Values[0]) if (len(p.Values) == 1) else seq(_arrow4517, p.Values)
            return (p.Key, values)

        return write_yaml(y_map(to_list(map(mapping, pr))))


YamlHelper_ParameterReferenceYAML_reflection = _expr4518

def YamlHelper_ParameterReferenceYAML__ctor(__unit: None=None) -> YamlHelper_ParameterReferenceYAML:
    return YamlHelper_ParameterReferenceYAML(__unit)


def _expr4520() -> TypeInfo:
    return class_type("ARCtrl.YamlController", None, YamlController)


class YamlController:
    @staticmethod
    def ProcessingUnit() -> YamlHelper_ProcessingUnitYAML:
        return YamlHelper_ProcessingUnitYAML()

    @staticmethod
    def ParameterReference() -> YamlHelper_ParameterReferenceYAML:
        return YamlHelper_ParameterReferenceYAML()


YamlController_reflection = _expr4520

__all__ = ["YamlHelper_ProcessingUnitYAML_reflection", "YamlHelper_ParameterReferenceYAML_reflection", "YamlController_reflection"]

