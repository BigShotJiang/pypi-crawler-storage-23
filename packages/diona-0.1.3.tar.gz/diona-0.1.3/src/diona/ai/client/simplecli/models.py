"""Data models for the AI CLI client"""

from typing import Dict, Any, Optional, List


class Message:
    """Message data model"""
    
    def __init__(self, role: str, content: str):
        """Initialize a message
        
        Args:
            role: Message role (user, assistant, system)
            content: Message content
        """
        self.role = role
        self.content = content
    
    def to_dict(self) -> Dict[str, str]:
        """Convert to dictionary for API calls"""
        return {
            "role": self.role,
            "content": self.content
        }


class ChatResponse:
    """Chat response data model"""
    
    def __init__(self, content: str, model: str, finish_reason: str):
        """Initialize a chat response
        
        Args:
            content: Response content
            model: Model used for response
            finish_reason: Reason for finish
        """
        self.content = content
        self.model = model
        self.finish_reason = finish_reason


class ToolCall:
    """Tool call data model"""
    
    def __init__(self, tool_name: str, parameters: Dict[str, Any]):
        """Initialize a tool call
        
        Args:
            tool_name: Name of the tool to call
            parameters: Tool parameters
        """
        self.tool_name = tool_name
        self.parameters = parameters


class ToolResponse:
    """Tool response data model"""
    
    def __init__(self, tool_name: str, result: Any, error: Optional[str] = None):
        """Initialize a tool response
        
        Args:
            tool_name: Name of the tool that was called
            result: Tool execution result
            error: Error message if any
        """
        self.tool_name = tool_name
        self.result = result
        self.error = error
    
    def is_success(self) -> bool:
        """Check if tool execution was successful"""
        return self.error is None
