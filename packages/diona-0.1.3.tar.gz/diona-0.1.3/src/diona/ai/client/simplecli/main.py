"""Main entry point for the AI CLI client"""

import warnings
import typer
from diona.ai.client.simplecli.config import ConfigManager
from diona.ai.client.simplecli.providers.openai import ProviderManager
from diona.ai.client.simplecli.session.manager import SessionManager
from diona.ai.client.simplecli.tools.manager import ToolManager
from diona.ai.client.simplecli.agent.system import AIAgentSystem
from diona.ai.client.simplecli.ui.console import InterfaceManager
from diona.ai.client.simplecli.core.engine import REPLEngine

# Suppress Trio warning about custom sys.excepthook handler
warnings.filterwarnings("ignore", message="You seem to already have a custom sys.excepthook handler installed")

app = typer.Typer()


def initialize_components(model=None):
    """Initialize all components"""
    # Initialize config manager
    config_manager = ConfigManager()
    
    # Validate configuration
    if not config_manager.validate():
        typer.echo("Configuration validation failed. Exiting.")
        raise typer.Exit(code=1)
    
    # Get AI config
    ai_config = config_manager.get_ai_config()
    
    # Use provided model if available
    model_to_use = model if model else ai_config.get('model')
    
    # Initialize provider manager
    provider_manager = ProviderManager(
        ai_config.get('base-url'),
        ai_config.get('api-key'),
        model_to_use
    )
    
    # Initialize session manager
    session_manager = SessionManager()
    
    # Initialize tool manager
    tool_manager = ToolManager(config_manager.get_tools_config())
    
    # Initialize interface manager
    interface_manager = InterfaceManager()
    
    # Initialize AI agent system
    agent_system = AIAgentSystem(
        provider_manager,
        tool_manager,
        config_manager.get_agent_config()
    )
    
    # Initialize REPL engine
    repl_engine = REPLEngine(
        config_manager,
        provider_manager,
        session_manager,
        tool_manager,
        agent_system,
        interface_manager
    )
    
    return repl_engine


def interactive_chat(model=None, prompt=None, agent_mode=True):
    """Start interactive chat session or run single prompt"""
    # Initialize components
    repl_engine = initialize_components(model)
    
    # Set agent mode
    repl_engine.set_agent_mode(agent_mode)
    
    # Run single prompt if provided
    if prompt:
        response = repl_engine.run_single(prompt)
        print(response)
    else:
        # Start interactive mode
        repl_engine.start()


@app.command()
def main(
    prompt: str = typer.Option(None, "--prompt", help="Single prompt to run"),
    model: str = typer.Option(None, "--model", help="Model to use"),
    agent_mode: bool = typer.Option(True, "--agent", "--no-agent", help="Enable or disable agent mode")
):
    """Simple AI CLI Client"""
    # Initialize components
    repl_engine = initialize_components(model)
    
    # Set agent mode
    repl_engine.set_agent_mode(agent_mode)
    
    # Run single prompt if provided
    if prompt:
        response = repl_engine.run_single(prompt)
        typer.echo(response)
    else:
        # Start interactive mode
        repl_engine.start()


if __name__ == "__main__":
    app()


# Export the interactive function
__all__ = ['interactive_chat']
