"""Simple AI CLI Client"""

from .main import interactive_chat

__version__ = "1.0.0"
__all__ = ['interactive_chat']
