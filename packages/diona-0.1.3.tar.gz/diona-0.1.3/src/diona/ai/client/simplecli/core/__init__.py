"""Core REPL engine module"""
