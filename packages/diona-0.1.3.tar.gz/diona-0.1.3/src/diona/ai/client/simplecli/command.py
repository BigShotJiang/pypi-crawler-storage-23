"""Command model for simplecli"""

from diona.project.command import CommandModel, CommandParameter
from diona.ai.client.simplecli.main import interactive_chat


# Create CommandModel for simplecli
SimpleCLICommand = CommandModel(
    name="simplecli",
    description="Start the simple AI CLI client for interactive chat or single prompt execution",
    implementation=interactive_chat,
    parameters=[
        CommandParameter(
            name="model",
            type="str",
            description="AI model to use",
            required=False
        ),
        CommandParameter(
            name="prompt",
            type="str",
            description="Single prompt to run",
            required=False
        ),
        CommandParameter(
            name="agent_mode",
            type="bool",
            description="Enable or disable agent mode",
            required=False,
            default=True
        )
    ]
)
