from .message import ChatMessage

class BaseChatHistory:
    def __init__(self, max_messages=6):
        self.max_messages = max_messages
        self.messages = []
    
    def add_message(self, message):
        self.messages.append(message)
        if len(self.messages) > self.max_messages:
            self.messages.pop(0)
    
    def get_messages(self):
        return self.messages
    
    def get_chat_message(self):
        return ChatMessage(self.messages)
    
    def persist(self):
        # To be implemented by subclass
        pass