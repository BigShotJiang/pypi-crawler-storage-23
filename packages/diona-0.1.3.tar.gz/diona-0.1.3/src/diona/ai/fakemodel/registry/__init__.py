from .registry import FakeModelRegistry, FakeModelForFake

__all__ = ['FakeModelRegistry', 'FakeModelForFake']