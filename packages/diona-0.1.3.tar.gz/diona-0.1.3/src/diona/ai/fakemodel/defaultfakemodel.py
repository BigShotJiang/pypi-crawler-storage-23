# 默认注册的FAKE_MODEL_CONFIG包名
DEFAULT_FAKE_MODEL_PATH = [
    'diona.ai.fakemodel.models.default.fakemodelconfig',
    'diona.ai.fakemodel.models.Ganyu.fakemodelconfig',
    'diona.ai.fakemodel.models.Ganyu2.fakemodelconfig'
]

# 初始化默认注册
from .registry import FakeModelRegistry, FakeModelForFake

# 获取注册中心实例
registry = FakeModelRegistry()

# 注册默认模型
for config_package in DEFAULT_FAKE_MODEL_PATH:
    # 从包名中提取模型名称
    model_name = config_package.split('.')[-2]
    # 创建并注册模型
    model = FakeModelForFake(model_name, config_package)
    registry.register(model)