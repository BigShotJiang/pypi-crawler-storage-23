class ResponseGenerator:
    def __init__(self, corpus_manager):
        self.corpus_manager = corpus_manager
    
    def generate(self, intent):
        sentences = self.corpus_manager.get_sentences_by_intent(intent.name)
        sentence = self.corpus_manager.random_item(sentences)
        if sentence:
            return sentence.text
        else:
            # 当找不到对应意图的句子时，随机从所有现有句子中输出一句
            sentence = self.corpus_manager.random_item(self.corpus_manager.sentences)
            if sentence:
                return sentence.text
            else:
                # 如果没有任何句子，返回默认回复
                return '抱歉，我不太明白你的意思。'