import re
import jieba
import logging

# 禁用jieba的日志输出
jieba.setLogLevel(logging.INFO)

class InputProcessor:
    @staticmethod
    def process(text):
        text = text.strip()
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[\r\n]+', ' ', text)
        # 使用jieba分词器精确模式进行分词
        words = jieba.cut(text, cut_all=True)
        return ' '.join(words)