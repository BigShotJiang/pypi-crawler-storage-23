from .corpus.manager import CorpusManager
from .intent.classifier import IntentClassifier
from .generation.generator import ResponseGenerator
from .io.input_processor import InputProcessor
from .io.output_formatter import OutputFormatter
from .loader import Loader

class FakeModel:
    def __init__(self, corpus_manager, intent_classifier, response_generator, input_processor, output_formatter):
        self.corpus_manager = corpus_manager
        self.intent_classifier = intent_classifier
        self.response_generator = response_generator
        self.input_processor = input_processor
        self.output_formatter = output_formatter
    
    def chat(self, text):
        processed_text = self.input_processor.process(text)
        intent = self.intent_classifier.classify(processed_text)
        response = self.response_generator.generate(intent)
        formatted_response = self.output_formatter.format(response)
        return formatted_response
    
    def run(self):
        print("Fake Model 对话系统启动！输入 'exit' 退出。")
        while True:
            user_input = input("用户: ")
            if user_input.lower() == 'exit':
                print("再见！")
                break
            response = self.chat(user_input)
            print(f"Fake Model: {response}")
    
    @staticmethod
    def get_default(config_module=None):
        """获取默认构造的FakeModel实例
        
        Args:
            config_module: 配置模块，包含FAKE_MODEL_CONFIG
        """
        # 加载语料库
        corpus_manager = Loader.load_corpus(config_module=config_module)
        # 创建各个组件
        intent_classifier = IntentClassifier(config_module=config_module)
        response_generator = ResponseGenerator(corpus_manager)
        input_processor = InputProcessor()
        output_formatter = OutputFormatter()
        # 构造并返回FakeModel实例
        return FakeModel(
            corpus_manager=corpus_manager,
            intent_classifier=intent_classifier,
            response_generator=response_generator,
            input_processor=input_processor,
            output_formatter=output_formatter
        )

if __name__ == "__main__":
    model = FakeModel.get_default()
    model.run()