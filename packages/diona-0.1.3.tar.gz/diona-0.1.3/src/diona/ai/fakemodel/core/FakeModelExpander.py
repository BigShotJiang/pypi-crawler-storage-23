from .FakeModel import FakeModel
from typing import Generator
from .loader import Loader
from .intent.classifier import IntentClassifier
from .generation.generator import ResponseGenerator
from .io.input_processor import InputProcessor
from .io.output_formatter import OutputFormatter

class FakeModelExpander(FakeModel):
    """FakeModel扩展类，添加流式输出功能"""

    @staticmethod
    def get_default(config_module=None):
        """获取默认构造的FakeModelExpander实例
        
        Args:
            config_module: 配置模块，包含FAKE_MODEL_CONFIG
        """
        # 加载语料库
        corpus_manager = Loader.load_corpus(config_module=config_module)
        # 创建各个组件
        intent_classifier = IntentClassifier(config_module=config_module)
        response_generator = ResponseGenerator(corpus_manager)
        input_processor = InputProcessor()
        output_formatter = OutputFormatter()
        # 构造并返回FakeModelExpander实例
        return FakeModelExpander(
            corpus_manager=corpus_manager,
            intent_classifier=intent_classifier,
            response_generator=response_generator,
            input_processor=input_processor,
            output_formatter=output_formatter
        )

    def chat_stream(self, text: str) -> Generator[str, None, None]:
        """流式输出聊天回复
        
        Args:
            text: 用户输入文本
            
        Yields:
            回复的每个字符
        """
        # 先获取完整回复
        content = super().chat(text)
        
        import time
        # 模拟流式输出，每个字符之间增加300ms延时
        for char in content:
            yield char
            time.sleep(0.3)

    def run(self):
        """启动交互式对话，使用流式输出"""
        print("Fake Model 对话系统启动！输入 'exit' 退出。")
        while True:
            user_input = input("用户: ")
            if user_input.lower() == 'exit':
                print("再见！")
                break
            # 使用chat_stream获取流式输出
            print("Fake Model: ", end="", flush=True)
            for chunk in self.chat_stream(user_input):
                print(chunk, end="", flush=True)
            print()