# 定义全局配置变量
FAKE_MODEL_CONFIG = {
  "intents": [
    {
      "name": "greeting",
      "patterns": ["你好", "嗨", "早上好", "下午好", "晚上好", "哈喽", "嘿"],
      "slots": {}
    },
    {
      "name": "goodbye",
      "patterns": ["再见", "拜拜", "明天见", "回头见", "拜", "再会"],
      "slots": {}
    },
    {
      "name": "weather",
      "patterns": ["天气", "气温", "下雨", "下雪", "晴天", "预报", "热", "冷"],
      "slots": {
        "location": ["北京", "上海", "广州", "深圳", "杭州", "成都", "武汉"],
        "time": ["今天", "明天", "后天", "本周", "下周", "周末"]
      }
    },
    {
      "name": "time",
      "patterns": ["几点", "时间", "钟点", "现在几点了", "什么时间"],
      "slots": {}
    },
    {
      "name": "date",
      "patterns": ["日期", "今天几号", "星期几", "几月几日", "什么日子"],
      "slots": {}
    },
    {
      "name": "thanks",
      "patterns": ["谢谢", "感谢", "多谢", "谢了", "感激"],
      "slots": {}
    },
    {
      "name": "apology",
      "patterns": ["抱歉", "对不起", "不好意思", "道歉", "原谅"],
      "slots": {}
    },
    {
      "name": "help",
      "patterns": ["帮忙", "帮助", "能帮我", "请问", "求助", "帮个忙"],
      "slots": {
        "task": ["开门", "拿东西", "查信息", "搬东西", "解决问题"]
      }
    },
    {
      "name": "price",
      "patterns": ["多少钱", "价格", "怎么卖", "价位", "花费"],
      "slots": {
        "item": ["苹果", "电脑", "书", "衣服", "门票", "房子"]
      }
    },
    {
      "name": "order_food",
      "patterns": ["点餐", "要一份", "来一份", "我想吃", "点菜", "菜单"],
      "slots": {
        "food": ["披萨", "汉堡", "沙拉", "牛排", "面条", "寿司"],
        "drink": ["可乐", "咖啡", "茶", "果汁", "啤酒", "水"]
      }
    },
    {
      "name": "direction",
      "patterns": ["怎么走", "在哪里", "路线", "导航", "指路", "方向"],
      "slots": {
        "destination": ["车站", "医院", "超市", "学校", "公园", "机场"],
        "location": ["附近", "这里", "那里"]
      }
    },
    {
      "name": "like",
      "patterns": ["喜欢", "热爱", "欣赏", "喜爱", "钟意"],
      "slots": {
        "thing": ["音乐", "电影", "运动", "旅行", "美食", "读书"]
      }
    },
    {
      "name": "dislike",
      "patterns": ["不喜欢", "讨厌", "受不了", "反感", "厌恶"],
      "slots": {
        "thing": ["噪音", "排队", "辣", "等待", "拥挤"]
      }
    },
    {
      "name": "suggestion",
      "patterns": ["建议", "推荐", "你觉得怎么样", "不如", "提议", "应该"],
      "slots": {
        "activity": ["吃饭", "看电影", "跑步", "学习", "休息", "旅行"]
      }
    },
    {
      "name": "invitation",
      "patterns": ["邀请", "一起去", "来参加", "要不要", "有空吗", "聚聚"],
      "slots": {
        "event": ["聚会", "婚礼", "晚餐", "派对", "旅行", "咖啡"],
        "time": ["今晚", "明天", "周末", "下个月", "周五"]
      }
    },
    {
      "name": "personal_info",
      "patterns": ["你叫什么", "你几岁", "你的职业", "你来自哪里", "你住在哪里", "你的生日", "你结婚了吗"],
      "slots": {
        "info_type": ["name", "age", "job", "hometown", "address", "birthday", "marital_status"]
      }
    },
    {
      "name": "emotion",
      "patterns": ["高兴", "难过", "兴奋", "沮丧", "紧张", "担心", "生气", "惊喜", "疲惫"],
      "slots": {
        "emotion_type": ["快乐", "悲伤", "愤怒", "惊讶", "焦虑", "疲惫"]
      }
    },
    {
      "name": "hobby",
      "patterns": ["爱好", "兴趣", "空闲时间做什么", "喜欢做什么", "热衷"],
      "slots": {
        "hobby": ["读书", "旅行", "游戏", "摄影", "音乐", "运动"]
      }
    },
    {
      "name": "opinion",
      "patterns": ["你觉得", "你认为", "你的看法", "怎么样", "怎么看", "想法"],
      "slots": {
        "topic": ["电影", "天气", "工作", "计划", "建议", "方案"]
      }
    },
    {
      "name": "reminder",
      "patterns": ["提醒", "记住", "别忘了", "设定闹钟", "记着"],
      "slots": {
        "task": ["开会", "吃药", "生日", "打电话", "交报告", "买牛奶"],
        "time": ["8点", "明天", "下周", "晚上", "早上"]
      }
    }
  ],
  "sentences": [
    {
      "id": 1,
      "text": "你好！最近过得怎么样？",
      "intent_tags": ["greeting"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 2,
      "text": "早上好，今天天气不错。",
      "intent_tags": ["greeting", "weather"],
      "topic_tags": ["social", "weather"],
      "emotion": "positive"
    },
    {
      "id": 3,
      "text": "嗨，好久不见！",
      "intent_tags": ["greeting"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 4,
      "text": "下午好，你吃饭了吗？",
      "intent_tags": ["greeting"],
      "topic_tags": ["social", "food"],
      "emotion": "neutral"
    },
    {
      "id": 5,
      "text": "晚上好，今天工作累吗？",
      "intent_tags": ["greeting"],
      "topic_tags": ["social", "work"],
      "emotion": "concerned"
    },
    {
      "id": 6,
      "text": "你好，很高兴见到你。",
      "intent_tags": ["greeting"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 7,
      "text": "嘿，你来了！",
      "intent_tags": ["greeting"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 8,
      "text": "早安，昨晚睡得好吗？",
      "intent_tags": ["greeting"],
      "topic_tags": ["social", "health"],
      "emotion": "concerned"
    },
    {
      "id": 9,
      "text": "哈喽，有什么新鲜事吗？",
      "intent_tags": ["greeting"],
      "topic_tags": ["social"],
      "emotion": "curious"
    },
    {
      "id": 10,
      "text": "你好呀，今天有什么计划？",
      "intent_tags": ["greeting"],
      "topic_tags": ["social", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 11,
      "text": "再见，明天见！",
      "intent_tags": ["goodbye"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 12,
      "text": "拜拜，路上小心。",
      "intent_tags": ["goodbye"],
      "topic_tags": ["social"],
      "emotion": "concerned"
    },
    {
      "id": 13,
      "text": "我先走了，回头聊。",
      "intent_tags": ["goodbye"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 14,
      "text": "再见，祝你有个愉快的一天。",
      "intent_tags": ["goodbye"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 15,
      "text": "拜拜，记得联系我。",
      "intent_tags": ["goodbye", "reminder"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 16,
      "text": "明天见，别忘了我们的约定。",
      "intent_tags": ["goodbye", "reminder"],
      "topic_tags": ["social", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 17,
      "text": "我先撤了，你们玩得开心。",
      "intent_tags": ["goodbye"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 18,
      "text": "再见，保持联系。",
      "intent_tags": ["goodbye"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 19,
      "text": "拜拜，下次一起吃饭。",
      "intent_tags": ["goodbye", "invitation"],
      "topic_tags": ["social", "food"],
      "emotion": "positive"
    },
    {
      "id": 20,
      "text": "我先走了，晚安。",
      "intent_tags": ["goodbye"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 21,
      "text": "今天天气怎么样？",
      "intent_tags": ["weather"],
      "topic_tags": ["daily", "weather"],
      "emotion": "neutral"
    },
    {
      "id": 22,
      "text": "明天会下雨吗？",
      "intent_tags": ["weather"],
      "topic_tags": ["daily", "weather"],
      "emotion": "neutral"
    },
    {
      "id": 23,
      "text": "北京的气温多少度？",
      "intent_tags": ["weather"],
      "topic_tags": ["weather", "travel"],
      "emotion": "neutral"
    },
    {
      "id": 24,
      "text": "后天有雪吗？",
      "intent_tags": ["weather"],
      "topic_tags": ["weather"],
      "emotion": "neutral"
    },
    {
      "id": 25,
      "text": "今天很热啊。",
      "intent_tags": ["weather", "emotion"],
      "topic_tags": ["weather"],
      "emotion": "complaint"
    },
    {
      "id": 26,
      "text": "天气预报说周末晴天。",
      "intent_tags": ["weather"],
      "topic_tags": ["weather", "plan"],
      "emotion": "positive"
    },
    {
      "id": 27,
      "text": "上海现在天气如何？",
      "intent_tags": ["weather"],
      "topic_tags": ["weather"],
      "emotion": "neutral"
    },
    {
      "id": 28,
      "text": "下周会降温吗？",
      "intent_tags": ["weather"],
      "topic_tags": ["weather"],
      "emotion": "neutral"
    },
    {
      "id": 29,
      "text": "今天适合出门吗？",
      "intent_tags": ["weather", "opinion"],
      "topic_tags": ["weather", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 30,
      "text": "空气湿度大不大？",
      "intent_tags": ["weather"],
      "topic_tags": ["weather"],
      "emotion": "neutral"
    },
    {
      "id": 31,
      "text": "现在几点了？",
      "intent_tags": ["time"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 32,
      "text": "你能告诉我时间吗？",
      "intent_tags": ["time", "help"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 33,
      "text": "现在几点钟？",
      "intent_tags": ["time"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 34,
      "text": "还有多久到三点？",
      "intent_tags": ["time"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 35,
      "text": "你的手表几点了？",
      "intent_tags": ["time"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 36,
      "text": "现在是不是下午两点了？",
      "intent_tags": ["time"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 37,
      "text": "能告诉我准确时间吗？",
      "intent_tags": ["time", "help"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 38,
      "text": "现在几点？我手机没电了。",
      "intent_tags": ["time"],
      "topic_tags": ["daily"],
      "emotion": "urgent"
    },
    {
      "id": 39,
      "text": "距离会议开始还有多久？",
      "intent_tags": ["time"],
      "topic_tags": ["work"],
      "emotion": "neutral"
    },
    {
      "id": 40,
      "text": "现在几点？我约了人。",
      "intent_tags": ["time"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 41,
      "text": "今天几号？",
      "intent_tags": ["date"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 42,
      "text": "今天星期几？",
      "intent_tags": ["date"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 43,
      "text": "今天是几月几日？",
      "intent_tags": ["date"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 44,
      "text": "明天是周末吗？",
      "intent_tags": ["date"],
      "topic_tags": ["daily", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 45,
      "text": "这个月有多少天？",
      "intent_tags": ["date"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 46,
      "text": "今年是哪一年？",
      "intent_tags": ["date"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 47,
      "text": "国庆节是几号？",
      "intent_tags": ["date"],
      "topic_tags": ["holiday"],
      "emotion": "neutral"
    },
    {
      "id": 48,
      "text": "下周一是几号？",
      "intent_tags": ["date"],
      "topic_tags": ["work", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 49,
      "text": "今天农历几号？",
      "intent_tags": ["date"],
      "topic_tags": ["daily", "culture"],
      "emotion": "neutral"
    },
    {
      "id": 50,
      "text": "你的生日是几月几号？",
      "intent_tags": ["date", "personal_info"],
      "topic_tags": ["social", "personal"],
      "emotion": "neutral"
    },
    {
      "id": 51,
      "text": "谢谢你的帮助！",
      "intent_tags": ["thanks"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 52,
      "text": "非常感谢！",
      "intent_tags": ["thanks"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 53,
      "text": "多谢了！",
      "intent_tags": ["thanks"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 54,
      "text": "太感谢你了！",
      "intent_tags": ["thanks"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 55,
      "text": "谢谢你的礼物。",
      "intent_tags": ["thanks"],
      "topic_tags": ["social", "gift"],
      "emotion": "positive"
    },
    {
      "id": 56,
      "text": "感谢你的支持。",
      "intent_tags": ["thanks"],
      "topic_tags": ["work", "social"],
      "emotion": "positive"
    },
    {
      "id": 57,
      "text": "多亏了你，谢谢。",
      "intent_tags": ["thanks"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 58,
      "text": "谢谢你的耐心解答。",
      "intent_tags": ["thanks"],
      "topic_tags": ["education", "work"],
      "emotion": "positive"
    },
    {
      "id": 59,
      "text": "感激不尽！",
      "intent_tags": ["thanks"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 60,
      "text": "谢啦，你真好。",
      "intent_tags": ["thanks", "emotion"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 61,
      "text": "对不起，我迟到了。",
      "intent_tags": ["apology"],
      "topic_tags": ["work", "social"],
      "emotion": "negative"
    },
    {
      "id": 62,
      "text": "抱歉，我不是故意的。",
      "intent_tags": ["apology"],
      "topic_tags": ["social"],
      "emotion": "negative"
    },
    {
      "id": 63,
      "text": "不好意思，打扰一下。",
      "intent_tags": ["apology", "help"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 64,
      "text": "真的对不起，我错了。",
      "intent_tags": ["apology"],
      "topic_tags": ["social"],
      "emotion": "negative"
    },
    {
      "id": 65,
      "text": "请原谅我的疏忽。",
      "intent_tags": ["apology"],
      "topic_tags": ["work"],
      "emotion": "negative"
    },
    {
      "id": 66,
      "text": "抱歉，让你久等了。",
      "intent_tags": ["apology"],
      "topic_tags": ["social"],
      "emotion": "negative"
    },
    {
      "id": 67,
      "text": "对不起，我没听清楚。",
      "intent_tags": ["apology"],
      "topic_tags": ["communication"],
      "emotion": "neutral"
    },
    {
      "id": 68,
      "text": "不好意思，能再说一遍吗？",
      "intent_tags": ["apology", "help"],
      "topic_tags": ["communication"],
      "emotion": "neutral"
    },
    {
      "id": 69,
      "text": "抱歉，我忘了带东西。",
      "intent_tags": ["apology"],
      "topic_tags": ["daily"],
      "emotion": "negative"
    },
    {
      "id": 70,
      "text": "对不起，给你添麻烦了。",
      "intent_tags": ["apology"],
      "topic_tags": ["social"],
      "emotion": "negative"
    },
    {
      "id": 71,
      "text": "你能帮我个忙吗？",
      "intent_tags": ["help"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 72,
      "text": "我需要你的帮助。",
      "intent_tags": ["help"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 73,
      "text": "请问，能帮我一下吗？",
      "intent_tags": ["help"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 74,
      "text": "帮我拿一下东西好吗？",
      "intent_tags": ["help"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 75,
      "text": "你能教我怎么做吗？",
      "intent_tags": ["help", "education"],
      "topic_tags": ["education"],
      "emotion": "neutral"
    },
    {
      "id": 76,
      "text": "帮我开一下门。",
      "intent_tags": ["help"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    },
    {
      "id": 77,
      "text": "能帮我查个信息吗？",
      "intent_tags": ["help"],
      "topic_tags": ["work", "research"],
      "emotion": "neutral"
    },
    {
      "id": 78,
      "text": "我需要帮忙搬东西。",
      "intent_tags": ["help"],
      "topic_tags": ["daily", "work"],
      "emotion": "neutral"
    },
    {
      "id": 79,
      "text": "帮我个忙，好吗？",
      "intent_tags": ["help"],
      "topic_tags": ["social"],
      "emotion": "neutral"
    },
    {
      "id": 80,
      "text": "你能帮我解决这个问题吗？",
      "intent_tags": ["help"],
      "topic_tags": ["work", "problem"],
      "emotion": "neutral"
    },
    {
      "id": 81,
      "text": "这个多少钱？",
      "intent_tags": ["price"],
      "topic_tags": ["shopping"],
      "emotion": "neutral"
    },
    {
      "id": 82,
      "text": "苹果怎么卖？",
      "intent_tags": ["price"],
      "topic_tags": ["shopping", "food"],
      "emotion": "neutral"
    },
    {
      "id": 83,
      "text": "这本书的价格是多少？",
      "intent_tags": ["price"],
      "topic_tags": ["shopping", "education"],
      "emotion": "neutral"
    },
    {
      "id": 84,
      "text": "那件衣服多少钱？",
      "intent_tags": ["price"],
      "topic_tags": ["shopping", "fashion"],
      "emotion": "neutral"
    },
    {
      "id": 85,
      "text": "打折吗？",
      "intent_tags": ["price"],
      "topic_tags": ["shopping"],
      "emotion": "neutral"
    },
    {
      "id": 86,
      "text": "能便宜点吗？",
      "intent_tags": ["price", "suggestion"],
      "topic_tags": ["shopping"],
      "emotion": "neutral"
    },
    {
      "id": 87,
      "text": "这个套餐多少钱？",
      "intent_tags": ["price"],
      "topic_tags": ["food", "shopping"],
      "emotion": "neutral"
    },
    {
      "id": 88,
      "text": "房价多少？",
      "intent_tags": ["price"],
      "topic_tags": ["realestate"],
      "emotion": "neutral"
    },
    {
      "id": 89,
      "text": "门票价格是多少？",
      "intent_tags": ["price"],
      "topic_tags": ["travel", "entertainment"],
      "emotion": "neutral"
    },
    {
      "id": 90,
      "text": "这个服务收费吗？",
      "intent_tags": ["price"],
      "topic_tags": ["service"],
      "emotion": "neutral"
    },
    {
      "id": 91,
      "text": "我想点一份披萨。",
      "intent_tags": ["order_food"],
      "topic_tags": ["food", "restaurant"],
      "emotion": "neutral"
    },
    {
      "id": 92,
      "text": "来一杯咖啡。",
      "intent_tags": ["order_food"],
      "topic_tags": ["food", "cafe"],
      "emotion": "neutral"
    },
    {
      "id": 93,
      "text": "我要一份沙拉，谢谢。",
      "intent_tags": ["order_food", "thanks"],
      "topic_tags": ["food", "restaurant"],
      "emotion": "positive"
    },
    {
      "id": 94,
      "text": "你们这里有什么推荐？",
      "intent_tags": ["order_food", "suggestion"],
      "topic_tags": ["food", "restaurant"],
      "emotion": "neutral"
    },
    {
      "id": 95,
      "text": "请给我菜单。",
      "intent_tags": ["order_food"],
      "topic_tags": ["food", "restaurant"],
      "emotion": "neutral"
    },
    {
      "id": 96,
      "text": "我要一个汉堡和可乐。",
      "intent_tags": ["order_food"],
      "topic_tags": ["food", "fastfood"],
      "emotion": "neutral"
    },
    {
      "id": 97,
      "text": "点餐，可以点了吗？",
      "intent_tags": ["order_food"],
      "topic_tags": ["food", "restaurant"],
      "emotion": "neutral"
    },
    {
      "id": 98,
      "text": "来份牛排，七分熟。",
      "intent_tags": ["order_food"],
      "topic_tags": ["food", "restaurant"],
      "emotion": "neutral"
    },
    {
      "id": 99,
      "text": "你们有素食吗？",
      "intent_tags": ["order_food"],
      "topic_tags": ["food", "diet"],
      "emotion": "neutral"
    },
    {
      "id": 100,
      "text": "我要外带。",
      "intent_tags": ["order_food"],
      "topic_tags": ["food", "takeaway"],
      "emotion": "neutral"
    },
    {
      "id": 101,
      "text": "请问去车站怎么走？",
      "intent_tags": ["direction"],
      "topic_tags": ["travel", "navigation"],
      "emotion": "neutral"
    },
    {
      "id": 102,
      "text": "最近的医院在哪里？",
      "intent_tags": ["direction"],
      "topic_tags": ["health", "navigation"],
      "emotion": "neutral"
    },
    {
      "id": 103,
      "text": "超市怎么走？",
      "intent_tags": ["direction"],
      "topic_tags": ["shopping", "navigation"],
      "emotion": "neutral"
    },
    {
      "id": 104,
      "text": "能告诉我路线吗？",
      "intent_tags": ["direction", "help"],
      "topic_tags": ["navigation"],
      "emotion": "neutral"
    },
    {
      "id": 105,
      "text": "这里离地铁站远吗？",
      "intent_tags": ["direction"],
      "topic_tags": ["travel", "navigation"],
      "emotion": "neutral"
    },
    {
      "id": 106,
      "text": "去公园坐几路车？",
      "intent_tags": ["direction"],
      "topic_tags": ["travel", "navigation"],
      "emotion": "neutral"
    },
    {
      "id": 107,
      "text": "导航显示要左转吗？",
      "intent_tags": ["direction"],
      "topic_tags": ["navigation"],
      "emotion": "neutral"
    },
    {
      "id": 108,
      "text": "请问，这是去博物馆的路吗？",
      "intent_tags": ["direction"],
      "topic_tags": ["travel", "navigation"],
      "emotion": "neutral"
    },
    {
      "id": 109,
      "text": "你能给我指路吗？",
      "intent_tags": ["direction", "help"],
      "topic_tags": ["navigation"],
      "emotion": "neutral"
    },
    {
      "id": 110,
      "text": "从这到机场多久？",
      "intent_tags": ["direction", "time"],
      "topic_tags": ["travel"],
      "emotion": "neutral"
    },
    {
      "id": 111,
      "text": "我喜欢听音乐。",
      "intent_tags": ["like"],
      "topic_tags": ["hobby", "music"],
      "emotion": "positive"
    },
    {
      "id": 112,
      "text": "我非常热爱旅行。",
      "intent_tags": ["like"],
      "topic_tags": ["hobby", "travel"],
      "emotion": "positive"
    },
    {
      "id": 113,
      "text": "我很欣赏这部电影。",
      "intent_tags": ["like"],
      "topic_tags": ["entertainment", "movie"],
      "emotion": "positive"
    },
    {
      "id": 114,
      "text": "我喜欢吃巧克力。",
      "intent_tags": ["like"],
      "topic_tags": ["food", "hobby"],
      "emotion": "positive"
    },
    {
      "id": 115,
      "text": "我特别喜欢运动。",
      "intent_tags": ["like"],
      "topic_tags": ["sports", "hobby"],
      "emotion": "positive"
    },
    {
      "id": 116,
      "text": "我很喜欢这个颜色。",
      "intent_tags": ["like"],
      "topic_tags": ["fashion", "shopping"],
      "emotion": "positive"
    },
    {
      "id": 117,
      "text": "我喜欢和你聊天。",
      "intent_tags": ["like"],
      "topic_tags": ["social"],
      "emotion": "positive"
    },
    {
      "id": 118,
      "text": "我热爱我的工作。",
      "intent_tags": ["like"],
      "topic_tags": ["work", "career"],
      "emotion": "positive"
    },
    {
      "id": 119,
      "text": "我很喜欢小动物。",
      "intent_tags": ["like"],
      "topic_tags": ["pets", "hobby"],
      "emotion": "positive"
    },
    {
      "id": 120,
      "text": "我喜欢安静的环境。",
      "intent_tags": ["like"],
      "topic_tags": ["lifestyle"],
      "emotion": "positive"
    },
    {
      "id": 121,
      "text": "我不喜欢吃辣。",
      "intent_tags": ["dislike"],
      "topic_tags": ["food", "preference"],
      "emotion": "negative"
    },
    {
      "id": 122,
      "text": "我讨厌排队。",
      "intent_tags": ["dislike"],
      "topic_tags": ["daily", "complaint"],
      "emotion": "negative"
    },
    {
      "id": 123,
      "text": "我受不了噪音。",
      "intent_tags": ["dislike"],
      "topic_tags": ["environment", "complaint"],
      "emotion": "negative"
    },
    {
      "id": 124,
      "text": "我不喜欢阴雨天。",
      "intent_tags": ["dislike", "weather"],
      "topic_tags": ["weather", "preference"],
      "emotion": "negative"
    },
    {
      "id": 125,
      "text": "我很反感这种行为。",
      "intent_tags": ["dislike"],
      "topic_tags": ["social", "ethics"],
      "emotion": "negative"
    },
    {
      "id": 126,
      "text": "我不喜欢看恐怖片。",
      "intent_tags": ["dislike"],
      "topic_tags": ["entertainment", "movie"],
      "emotion": "negative"
    },
    {
      "id": 127,
      "text": "我讨厌等待。",
      "intent_tags": ["dislike"],
      "topic_tags": ["daily", "complaint"],
      "emotion": "negative"
    },
    {
      "id": 128,
      "text": "我不喜欢人多的地方。",
      "intent_tags": ["dislike"],
      "topic_tags": ["social", "environment"],
      "emotion": "negative"
    },
    {
      "id": 129,
      "text": "我受不了空调太冷。",
      "intent_tags": ["dislike"],
      "topic_tags": ["environment", "complaint"],
      "emotion": "negative"
    },
    {
      "id": 130,
      "text": "我不喜欢别人打扰我。",
      "intent_tags": ["dislike"],
      "topic_tags": ["social", "privacy"],
      "emotion": "negative"
    },
    {
      "id": 131,
      "text": "我建议你早点休息。",
      "intent_tags": ["suggestion"],
      "topic_tags": ["health", "daily"],
      "emotion": "concerned"
    },
    {
      "id": 132,
      "text": "不如我们去看电影吧？",
      "intent_tags": ["suggestion", "invitation"],
      "topic_tags": ["entertainment", "social"],
      "emotion": "positive"
    },
    {
      "id": 133,
      "text": "你觉得吃火锅怎么样？",
      "intent_tags": ["suggestion", "opinion"],
      "topic_tags": ["food", "social"],
      "emotion": "neutral"
    },
    {
      "id": 134,
      "text": "我推荐这家餐厅。",
      "intent_tags": ["suggestion"],
      "topic_tags": ["food", "recommendation"],
      "emotion": "positive"
    },
    {
      "id": 135,
      "text": "要不我们周末去爬山？",
      "intent_tags": ["suggestion", "invitation"],
      "topic_tags": ["outdoor", "social"],
      "emotion": "positive"
    },
    {
      "id": 136,
      "text": "建议你多运动。",
      "intent_tags": ["suggestion"],
      "topic_tags": ["health", "fitness"],
      "emotion": "advice"
    },
    {
      "id": 137,
      "text": "我觉得你应该试试这个。",
      "intent_tags": ["suggestion"],
      "topic_tags": ["advice"],
      "emotion": "neutral"
    },
    {
      "id": 138,
      "text": "不如先完成作业再玩。",
      "intent_tags": ["suggestion"],
      "topic_tags": ["education", "work"],
      "emotion": "advice"
    },
    {
      "id": 139,
      "text": "我提议一起聚餐。",
      "intent_tags": ["suggestion", "invitation"],
      "topic_tags": ["social", "food"],
      "emotion": "positive"
    },
    {
      "id": 140,
      "text": "建议你学习新技能。",
      "intent_tags": ["suggestion"],
      "topic_tags": ["education", "career"],
      "emotion": "advice"
    },
    {
      "id": 141,
      "text": "邀请你参加我的生日派对。",
      "intent_tags": ["invitation"],
      "topic_tags": ["social", "party"],
      "emotion": "positive"
    },
    {
      "id": 142,
      "text": "要不要一起去吃饭？",
      "intent_tags": ["invitation", "suggestion"],
      "topic_tags": ["social", "food"],
      "emotion": "positive"
    },
    {
      "id": 143,
      "text": "这周末有空吗？一起玩。",
      "intent_tags": ["invitation"],
      "topic_tags": ["social", "leisure"],
      "emotion": "positive"
    },
    {
      "id": 144,
      "text": "我邀请你来看我的演出。",
      "intent_tags": ["invitation"],
      "topic_tags": ["entertainment", "social"],
      "emotion": "positive"
    },
    {
      "id": 145,
      "text": "来参加我们的聚会吧。",
      "intent_tags": ["invitation"],
      "topic_tags": ["social", "party"],
      "emotion": "positive"
    },
    {
      "id": 146,
      "text": "一起去看电影怎么样？",
      "intent_tags": ["invitation", "suggestion"],
      "topic_tags": ["entertainment", "social"],
      "emotion": "positive"
    },
    {
      "id": 147,
      "text": "邀请你明天来我家。",
      "intent_tags": ["invitation"],
      "topic_tags": ["social", "home"],
      "emotion": "positive"
    },
    {
      "id": 148,
      "text": "有没有兴趣一起去旅行？",
      "intent_tags": ["invitation", "hobby"],
      "topic_tags": ["travel", "social"],
      "emotion": "positive"
    },
    {
      "id": 149,
      "text": "我们可以一起喝杯咖啡吗？",
      "intent_tags": ["invitation"],
      "topic_tags": ["social", "cafe"],
      "emotion": "positive"
    },
    {
      "id": 150,
      "text": "来参加我的婚礼吧。",
      "intent_tags": ["invitation"],
      "topic_tags": ["social", "wedding"],
      "emotion": "positive"
    },
    {
      "id": 151,
      "text": "你叫什么名字？",
      "intent_tags": ["personal_info"],
      "topic_tags": ["social", "introduction"],
      "emotion": "neutral"
    },
    {
      "id": 152,
      "text": "你今年多大了？",
      "intent_tags": ["personal_info"],
      "topic_tags": ["social", "personal"],
      "emotion": "neutral"
    },
    {
      "id": 153,
      "text": "你的职业是什么？",
      "intent_tags": ["personal_info"],
      "topic_tags": ["work", "social"],
      "emotion": "neutral"
    },
    {
      "id": 154,
      "text": "你来自哪里？",
      "intent_tags": ["personal_info"],
      "topic_tags": ["social", "culture"],
      "emotion": "neutral"
    },
    {
      "id": 155,
      "text": "你住在哪里？",
      "intent_tags": ["personal_info"],
      "topic_tags": ["social", "location"],
      "emotion": "neutral"
    },
    {
      "id": 156,
      "text": "你有兄弟姐妹吗？",
      "intent_tags": ["personal_info"],
      "topic_tags": ["family", "social"],
      "emotion": "neutral"
    },
    {
      "id": 157,
      "text": "你的生日是什么时候？",
      "intent_tags": ["personal_info", "date"],
      "topic_tags": ["social", "personal"],
      "emotion": "neutral"
    },
    {
      "id": 158,
      "text": "你结婚了吗？",
      "intent_tags": ["personal_info"],
      "topic_tags": ["social", "relationship"],
      "emotion": "neutral"
    },
    {
      "id": 159,
      "text": "你做什么工作？",
      "intent_tags": ["personal_info"],
      "topic_tags": ["work", "social"],
      "emotion": "neutral"
    },
    {
      "id": 160,
      "text": "你的兴趣爱好是什么？",
      "intent_tags": ["personal_info", "hobby"],
      "topic_tags": ["hobby", "social"],
      "emotion": "neutral"
    },
    {
      "id": 161,
      "text": "我今天很高兴！",
      "intent_tags": ["emotion"],
      "topic_tags": ["daily", "mood"],
      "emotion": "positive"
    },
    {
      "id": 162,
      "text": "我感到有点难过。",
      "intent_tags": ["emotion"],
      "topic_tags": ["daily", "mood"],
      "emotion": "sad"
    },
    {
      "id": 163,
      "text": "我兴奋极了！",
      "intent_tags": ["emotion"],
      "topic_tags": ["daily", "mood"],
      "emotion": "excited"
    },
    {
      "id": 164,
      "text": "我很沮丧，因为没考好。",
      "intent_tags": ["emotion"],
      "topic_tags": ["education", "mood"],
      "emotion": "sad"
    },
    {
      "id": 165,
      "text": "我有点紧张。",
      "intent_tags": ["emotion"],
      "topic_tags": ["daily", "mood"],
      "emotion": "anxious"
    },
    {
      "id": 166,
      "text": "我感到很满足。",
      "intent_tags": ["emotion"],
      "topic_tags": ["daily", "mood"],
      "emotion": "positive"
    },
    {
      "id": 167,
      "text": "我有点担心。",
      "intent_tags": ["emotion"],
      "topic_tags": ["daily", "mood"],
      "emotion": "anxious"
    },
    {
      "id": 168,
      "text": "我很生气。",
      "intent_tags": ["emotion"],
      "topic_tags": ["daily", "mood"],
      "emotion": "angry"
    },
    {
      "id": 169,
      "text": "我很惊喜！",
      "intent_tags": ["emotion"],
      "topic_tags": ["daily", "mood"],
      "emotion": "surprised"
    },
    {
      "id": 170,
      "text": "我感到疲惫。",
      "intent_tags": ["emotion"],
      "topic_tags": ["daily", "mood"],
      "emotion": "tired"
    },
    {
      "id": 171,
      "text": "你的爱好是什么？",
      "intent_tags": ["hobby", "personal_info"],
      "topic_tags": ["hobby", "social"],
      "emotion": "neutral"
    },
    {
      "id": 172,
      "text": "我喜欢在空闲时间读书。",
      "intent_tags": ["hobby", "like"],
      "topic_tags": ["hobby", "leisure"],
      "emotion": "positive"
    },
    {
      "id": 173,
      "text": "你周末喜欢做什么？",
      "intent_tags": ["hobby"],
      "topic_tags": ["hobby", "leisure"],
      "emotion": "neutral"
    },
    {
      "id": 174,
      "text": "我热衷于摄影。",
      "intent_tags": ["hobby", "like"],
      "topic_tags": ["hobby", "art"],
      "emotion": "positive"
    },
    {
      "id": 175,
      "text": "你有什么兴趣爱好？",
      "intent_tags": ["hobby", "personal_info"],
      "topic_tags": ["hobby", "social"],
      "emotion": "neutral"
    },
    {
      "id": 176,
      "text": "我喜欢打篮球。",
      "intent_tags": ["hobby", "like"],
      "topic_tags": ["sports", "hobby"],
      "emotion": "positive"
    },
    {
      "id": 177,
      "text": "我最近迷上了画画。",
      "intent_tags": ["hobby", "like"],
      "topic_tags": ["art", "hobby"],
      "emotion": "positive"
    },
    {
      "id": 178,
      "text": "你喜欢听什么音乐？",
      "intent_tags": ["hobby", "opinion"],
      "topic_tags": ["music", "hobby"],
      "emotion": "neutral"
    },
    {
      "id": 179,
      "text": "我的爱好是旅行和美食。",
      "intent_tags": ["hobby"],
      "topic_tags": ["travel", "food", "hobby"],
      "emotion": "positive"
    },
    {
      "id": 180,
      "text": "你喜欢运动吗？",
      "intent_tags": ["hobby", "opinion"],
      "topic_tags": ["sports", "hobby"],
      "emotion": "neutral"
    },
    {
      "id": 181,
      "text": "你觉得这部电影怎么样？",
      "intent_tags": ["opinion"],
      "topic_tags": ["entertainment", "movie"],
      "emotion": "neutral"
    },
    {
      "id": 182,
      "text": "你认为这个计划可行吗？",
      "intent_tags": ["opinion"],
      "topic_tags": ["work", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 183,
      "text": "你对这件事怎么看？",
      "intent_tags": ["opinion"],
      "topic_tags": ["social", "event"],
      "emotion": "neutral"
    },
    {
      "id": 184,
      "text": "你觉得天气如何？",
      "intent_tags": ["opinion", "weather"],
      "topic_tags": ["weather"],
      "emotion": "neutral"
    },
    {
      "id": 185,
      "text": "你认为我们应该怎么做？",
      "intent_tags": ["opinion", "suggestion"],
      "topic_tags": ["work", "decision"],
      "emotion": "neutral"
    },
    {
      "id": 186,
      "text": "你对新同事有什么看法？",
      "intent_tags": ["opinion"],
      "topic_tags": ["work", "social"],
      "emotion": "neutral"
    },
    {
      "id": 187,
      "text": "你觉得这件衣服好看吗？",
      "intent_tags": ["opinion"],
      "topic_tags": ["fashion", "shopping"],
      "emotion": "neutral"
    },
    {
      "id": 188,
      "text": "你认为这个建议如何？",
      "intent_tags": ["opinion", "suggestion"],
      "topic_tags": ["advice"],
      "emotion": "neutral"
    },
    {
      "id": 189,
      "text": "你对未来有什么想法？",
      "intent_tags": ["opinion"],
      "topic_tags": ["future", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 190,
      "text": "你觉得这个方案怎么样？",
      "intent_tags": ["opinion"],
      "topic_tags": ["work", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 191,
      "text": "提醒我明天开会。",
      "intent_tags": ["reminder"],
      "topic_tags": ["work", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 192,
      "text": "别忘了吃药。",
      "intent_tags": ["reminder"],
      "topic_tags": ["health"],
      "emotion": "concerned"
    },
    {
      "id": 193,
      "text": "记得给妈妈打电话。",
      "intent_tags": ["reminder"],
      "topic_tags": ["family", "social"],
      "emotion": "neutral"
    },
    {
      "id": 194,
      "text": "提醒我8点有重要电话。",
      "intent_tags": ["reminder"],
      "topic_tags": ["work", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 195,
      "text": "别忘了买牛奶。",
      "intent_tags": ["reminder"],
      "topic_tags": ["shopping", "daily"],
      "emotion": "neutral"
    },
    {
      "id": 196,
      "text": "提醒我下周交报告。",
      "intent_tags": ["reminder"],
      "topic_tags": ["work", "deadline"],
      "emotion": "neutral"
    },
    {
      "id": 197,
      "text": "设个闹钟，明天早起。",
      "intent_tags": ["reminder"],
      "topic_tags": ["daily", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 198,
      "text": "别忘了我们的约定。",
      "intent_tags": ["reminder"],
      "topic_tags": ["social", "plan"],
      "emotion": "neutral"
    },
    {
      "id": 199,
      "text": "提醒我检查邮件。",
      "intent_tags": ["reminder"],
      "topic_tags": ["work", "communication"],
      "emotion": "neutral"
    },
    {
      "id": 200,
      "text": "记得带钥匙。",
      "intent_tags": ["reminder"],
      "topic_tags": ["daily"],
      "emotion": "neutral"
    }
  ]
}