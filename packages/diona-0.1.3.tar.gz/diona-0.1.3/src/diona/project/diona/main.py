"""Main entry point for the diona command"""

import argparse
import sys
import os
from rich.console import Console
from rich.text import Text
from diona.project.command import CommandRegistry

# Initialize console
console = Console()

# Get banner path
banner_path = os.path.join(os.path.dirname(__file__), 'banner.txt')

# Print banner
def print_banner():
    """Print the banner"""
    if os.path.exists(banner_path):
        with open(banner_path, 'r', encoding='utf-8') as f:
            banner = f.read()
        # Create a gradient pink text for the banner
        banner_text = Text()
        # Define gradient colors from light white-pink to slightly deeper pink
        colors = ["#fffbfe", "#fce7f3", "#fbcfe8", "#f9a8d4", "#f472b6"]
        # Apply gradient to each character
        for i, char in enumerate(banner):
            color_index = i % len(colors)
            banner_text.append(char, style=f"bold {colors[color_index]}")
        console.print(banner_text)
        console.print()

# Initialize registry (commands will be registered only when needed)
registry = CommandRegistry()

def main():
    """Main function for the diona command"""
    # Print banner at the beginning
    print_banner()
    
    parser = argparse.ArgumentParser(
        prog='diona',
        description='Diona project command-line tool',
        epilog='For more information, visit https://diona.dev'
    )
    
    # Add global options
    parser.add_argument('--list-commands', action='store_true', help='List all registered commands')
    parser.add_argument('--command-detail', type=str, metavar='COMMAND', help='Show detailed information about a command')
    
    # Parse arguments with nargs='*' to allow subcommands
    args, remaining_args = parser.parse_known_args()
    
    # Only register commands when needed
    if args.list_commands or args.command_detail or len(remaining_args) > 0:
        # Register commands
        registry.register_commands()
        
    # Get command manager instance from registry
    command_manager = registry.get_command_manager()
    
    # Handle global options
    # --help is handled automatically by argparse
    
    if args.list_commands:
        commands = command_manager.list_commands()
        if not commands:
            console.print('No commands registered.', style="yellow")
            return
        
        console.print('Registered commands:', style="bold green")
        console.print('-' * 60, style="cyan")
        for name, command in commands.items():
            console.print(f'[bold]{name:<20}[/bold] {command.description}')
        console.print('-' * 60, style="cyan")
        return
    
    if args.command_detail:
        command = command_manager.get_command(args.command_detail)
        if not command:
            console.print(f'Command "{args.command_detail}" not found.', style="red")
            return
        
        console.print(f'Command: [bold]{command.name}[/bold]', style="green")
        console.print(f'Description: {command.description}')
        console.print('Parameters:')
        if not command.parameters:
            console.print('  No parameters')
        else:
            for param in command.parameters:
                required = ' (required)' if param.required else ''
                default = f' (default: {param.default})' if param.default is not None else ''
                console.print(f'  [bold]{param.name:<20}[/bold] {param.type:<10} {param.description}{required}{default}')
        return
    
    # Handle command execution
    if len(remaining_args) < 1:
        parser.print_help()
        return
    
    # Get command name and arguments
    command_name = remaining_args[0]
    command_args = remaining_args[1:]
    
    # Get command
    command = command_manager.get_command(command_name)
    if not command:
        console.print(f'Command "{command_name}" not found.', style="red")
        console.print('Use --list-commands to see available commands.')
        return
    
    # Execute command
    try:
        command.implementation(*command_args)
    except Exception as e:
        console.print(f'Error executing command: {e}', style="red")
        return


if __name__ == '__main__':
    main()
