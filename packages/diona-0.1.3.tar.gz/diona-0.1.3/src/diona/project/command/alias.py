"""Command aliases configuration"""

# Alias mapping: alias -> real command name
ALIAS_NAME = {
    "fd": "fakedelete",
    "fi": "fakeinstall"
}
