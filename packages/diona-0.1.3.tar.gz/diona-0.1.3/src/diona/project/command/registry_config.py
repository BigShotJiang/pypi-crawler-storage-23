"""Command registry configuration"""


class RegistryCommandConfig:
    """Registry command configuration class"""
    
    def __init__(self):
        """Initialize registry command configuration"""
        self._command_paths = []
    
    def add_command(self, command_path):
        """Add a command to the registry
        
        Args:
            command_path: Command model path in format 'module_path.ClassName'
        """
        if command_path not in self._command_paths:
            self._command_paths.append(command_path)
    
    def remove_command(self, command_path):
        """Remove a command from the registry
        
        Args:
            command_path: Command model path to remove
        """
        if command_path in self._command_paths:
            self._command_paths.remove(command_path)
    
    def get_commands(self):
        """Get all registered command paths
        
        Returns:
            List of command model paths
        """
        return self._command_paths
    
    def clear(self):
        """Clear all commands from the registry"""
        self._command_paths.clear()
