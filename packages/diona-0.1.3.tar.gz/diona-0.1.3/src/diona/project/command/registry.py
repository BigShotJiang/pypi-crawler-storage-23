"""Command registry center"""

from .command_manager import CommandManager
from .registry_config import RegistryCommandConfig


class CommandRegistry:
    """Command registry singleton for loading commands from registry configuration"""
    _instance = None
    
    def __new__(cls):
        """Create a singleton instance"""
        if cls._instance is None:
            cls._instance = super(CommandRegistry, cls).__new__(cls)
            cls._instance._command_manager = CommandManager()
            cls._instance._config = RegistryCommandConfig()
            # Add default commands
            cls._instance._add_default_commands()
            # Load aliases from alias.py
            cls._instance._load_aliases()
        return cls._instance
    
    def _load_aliases(self):
        """Load aliases from alias.py"""
        try:
            # Try to import alias.py from command directory
            from . import alias
            if hasattr(alias, 'ALIAS_NAME'):
                aliases = alias.ALIAS_NAME
                if isinstance(aliases, dict):
                    for alias_name, command_name in aliases.items():
                        self._command_manager.register_alias(alias_name, command_name)
        except ImportError:
            # alias.py not found, skip
            pass
    
    def _add_default_commands(self):
        """Add default commands to the registry"""
        # Add commands here (uncomment and modify as needed)

        # Add fakedelete command
        self.add_command("diona.tools.fakedelete.command.FakeDeleteCommand")
        # Add fakeinstall command
        self.add_command("diona.tools.fakeinstall.command.FakeInstallCommand") 
        # Add SimpleCli command
        self.add_command('diona.ai.client.simplecli.command.SimpleCLICommand')

        # registry.add_command('path.to.another.CommandModel')
    
    def add_command(self, command_path):
        """Add a command to the registry
        
        Args:
            command_path: Command model path in format 'module_path.ClassName'
        """
        self._config.add_command(command_path)
    
    def remove_command(self, command_path):
        """Remove a command from the registry
        
        Args:
            command_path: Command model path to remove
        """
        self._config.remove_command(command_path)
    
    def register_commands(self):
        """Register all commands from the configuration"""
        command_paths = self._config.get_commands()
        for command_path in command_paths:
            try:
                # Import the command model
                module_path, class_name = command_path.rsplit('.', 1)
                module = __import__(module_path, fromlist=[class_name])
                command_model = getattr(module, class_name)
                
                # Register the command
                if not self._command_manager.has_command(command_model.name):
                    self._command_manager.register_command(command_model)
                    # print(f"Registered command: {command_model.name}")
            except Exception as e:
                print(f"Error loading command from {command_path}: {e}")
    
    def get_command_manager(self):
        """Get the command manager instance
        
        Returns:
            CommandManager instance
        """
        return self._command_manager
    
    def get_config(self):
        """Get the registry configuration
        
        Returns:
            RegistryCommandConfig instance
        """
        return self._config
