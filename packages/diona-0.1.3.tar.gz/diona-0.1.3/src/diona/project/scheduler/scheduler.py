from typing import Dict, Optional
from .interfaces import SchedulerInterface, TaskModel
from .manager import TaskManager
from .executor import TaskExecutor

class Scheduler(SchedulerInterface):
    """Scheduler implementation."""
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Scheduler, cls).__new__(cls)
            cls._instance._initialize()
        return cls._instance
    
    def _initialize(self):
        """Initialize the scheduler."""
        self.task_manager = TaskManager()
        self.task_executor = TaskExecutor(self.task_manager)
    
    def register_task(self, task: TaskModel) -> bool:
        """Register a new task."""
        return self.task_manager.register_task(task)
    
    def get_task(self, task_name: str) -> Optional[TaskModel]:
        """Get task by name."""
        return self.task_manager.get_task(task_name)
    
    def list_tasks(self) -> Dict[str, TaskModel]:
        """List all tasks."""
        return self.task_manager.list_tasks()
    
    def unregister_task(self, task_name: str) -> bool:
        """Unregister a task."""
        return self.task_manager.unregister_task(task_name)
    
    def start(self) -> bool:
        """Start the scheduler."""
        return self.task_executor.start()
    
    def stop(self) -> bool:
        """Stop the scheduler."""
        return self.task_executor.stop()

# Singleton factory function
def get_scheduler_instance():
    """Get the singleton scheduler instance."""
    return Scheduler()
