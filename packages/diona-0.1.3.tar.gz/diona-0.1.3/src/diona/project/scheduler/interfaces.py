from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Callable
from datetime import datetime

class TaskModel(ABC):
    """Task model interface."""
    
    @abstractmethod
    def get_task_name(self) -> str:
        """Get task name."""
        pass
    
    @abstractmethod
    def get_trigger_time(self) -> datetime:
        """Get task trigger time."""
        pass
    
    @abstractmethod
    def get_execution_function(self) -> Callable:
        """Get task execution function."""
        pass
    
    @abstractmethod
    def get_parameters(self) -> Dict[str, Any]:
        """Get task parameters."""
        pass
    
    @abstractmethod
    def get_max_executions(self) -> int:
        """Get max execution times."""
        pass
    
    @abstractmethod
    def get_retry_count(self) -> int:
        """Get retry count."""
        pass
    
    @abstractmethod
    def get_retry_interval(self) -> int:
        """Get retry interval in seconds."""
        pass
    
    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Convert task to dictionary."""
        pass
    
    @classmethod
    @abstractmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TaskModel':
        """Create task from dictionary."""
        pass

class TaskManagerInterface(ABC):
    """Task manager interface."""
    
    @abstractmethod
    def register_task(self, task: TaskModel) -> bool:
        """Register a new task."""
        pass
    
    @abstractmethod
    def get_task(self, task_name: str) -> Optional[TaskModel]:
        """Get task by name."""
        pass
    
    @abstractmethod
    def list_tasks(self) -> Dict[str, TaskModel]:
        """List all tasks."""
        pass
    
    @abstractmethod
    def unregister_task(self, task_name: str) -> bool:
        """Unregister a task."""
        pass
    
    @abstractmethod
    def update_task(self, task: TaskModel) -> bool:
        """Update a task."""
        pass

class TaskExecutorInterface(ABC):
    """Task executor interface."""
    
    @abstractmethod
    def start(self) -> bool:
        """Start the executor."""
        pass
    
    @abstractmethod
    def stop(self) -> bool:
        """Stop the executor."""
        pass
    
    @abstractmethod
    def execute_task(self, task: TaskModel) -> bool:
        """Execute a task."""
        pass

class SchedulerInterface(ABC):
    """Scheduler interface."""
    
    @abstractmethod
    def register_task(self, task: TaskModel) -> bool:
        """Register a new task."""
        pass
    
    @abstractmethod
    def get_task(self, task_name: str) -> Optional[TaskModel]:
        """Get task by name."""
        pass
    
    @abstractmethod
    def list_tasks(self) -> Dict[str, TaskModel]:
        """List all tasks."""
        pass
    
    @abstractmethod
    def unregister_task(self, task_name: str) -> bool:
        """Unregister a task."""
        pass
    
    @abstractmethod
    def start(self) -> bool:
        """Start the scheduler."""
        pass
    
    @abstractmethod
    def stop(self) -> bool:
        """Stop the scheduler."""
        pass
