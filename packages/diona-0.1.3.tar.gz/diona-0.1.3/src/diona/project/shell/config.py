"""Configuration for shell commander"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass
class ShellConfig:
    """Shell commander configuration"""
    # Encoding settings
    encoding: str = "utf-8"
    
    # Command whitelist and blacklist
    command_whitelist: Optional[List[str]] = None
    command_blacklist: Optional[List[str]] = None
    
    # Working directory settings
    cwd: Optional[str] = None
    cwd_whitelist: Optional[List[str]] = None
    
    # Environment variables
    env: Optional[Dict[str, str]] = field(default_factory=dict)
    
    # Default timeout in seconds
    timeout: Optional[int] = None
