from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, Callable
from .message import Message

class MessageBusInterface(ABC):
    """Message bus interface."""
    
    @abstractmethod
    def publish(self, message: Message) -> bool:
        """Publish a message."""
        pass
    
    @abstractmethod
    def subscribe(self, topic: str, callback: Callable[[Message], None]) -> bool:
        """Subscribe to a topic."""
        pass
    
    @abstractmethod
    def unsubscribe(self, topic: str, callback: Callable[[Message], None]) -> bool:
        """Unsubscribe from a topic."""
        pass
    
    @abstractmethod
    def pull_message(self, topic: str) -> Optional[Message]:
        """Pull a message from the queue."""
        pass
    
    @abstractmethod
    def get_module_name(self) -> str:
        """Get the module name."""
        pass
