import os
import logging
from logging.handlers import RotatingFileHandler

class Logger:
    """Logger class implemented as a singleton."""
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Logger, cls).__new__(cls)
            cls._instance._initialize()
        return cls._instance
    
    def _initialize(self):
        """Initialize the logger."""
        # Get the user's home directory
        HOME_DIR = os.path.expanduser("~")
        # Define the log directory
        LOG_DIR = os.path.join(HOME_DIR, ".diona", "log")
        
        # Create the log directory if it doesn't exist
        os.makedirs(LOG_DIR, exist_ok=True)
        
        # Define the log file path
        LOG_FILE = os.path.join(LOG_DIR, "diona.log")
        
        # Configure the logging system
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                RotatingFileHandler(
                    LOG_FILE,
                    maxBytes=10*1024*1024,  # 10MB
                    backupCount=5,
                    encoding='utf-8'
                ),
                logging.StreamHandler()
            ]
        )
    
    def get_logger(self, name):
        """Get a logger with the specified name."""
        return logging.getLogger(name)

# Singleton factory function
def get_logger_instance():
    """Get the singleton logger instance."""
    return Logger()

# Example usage
if __name__ == "__main__":
    logger_instance = get_logger_instance()
    logger = logger_instance.get_logger(__name__)
    logger.info("Logger initialized successfully")
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")
