from abc import ABC, abstractmethod
from typing import Optional, Any

class StorageInterface(ABC):
    """Base storage interface."""
    
    @abstractmethod
    def get_path(self, module_name: str, relative_path: str) -> str:
        """Get the full path for a given module and relative path."""
        pass
    
    @abstractmethod
    def exists(self, module_name: str, relative_path: str) -> bool:
        """Check if a path exists."""
        pass
    
    @abstractmethod
    def create(self, module_name: str, relative_path: str) -> bool:
        """Create a file or directory."""
        pass
    
    @abstractmethod
    def read(self, module_name: str, relative_path: str, encoding: str = 'utf-8') -> Optional[str]:
        """Read content from a file."""
        pass
    
    @abstractmethod
    def write(self, module_name: str, relative_path: str, content: str, encoding: str = 'utf-8') -> bool:
        """Write content to a file."""
        pass
    
    @abstractmethod
    def delete(self, module_name: str, relative_path: str) -> bool:
        """Delete a file or directory."""
        pass
    
    @abstractmethod
    def update(self, module_name: str, relative_path: str, content: str, encoding: str = 'utf-8') -> bool:
        """Update content in a file."""
        pass

class CacheInterface(StorageInterface):
    """Cache storage interface."""
    
    @abstractmethod
    def set_cache(self, module_name: str, key: str, value: Any, expiration: int = 3600) -> bool:
        """Set a cache value with expiration."""
        pass
    
    @abstractmethod
    def get_cache(self, module_name: str, key: str) -> Optional[Any]:
        """Get a cache value."""
        pass
    
    @abstractmethod
    def delete_cache(self, module_name: str, key: str) -> bool:
        """Delete a cache value."""
        pass
    
    @abstractmethod
    def clear_cache(self, module_name: str) -> bool:
        """Clear all cache for a module."""
        pass
