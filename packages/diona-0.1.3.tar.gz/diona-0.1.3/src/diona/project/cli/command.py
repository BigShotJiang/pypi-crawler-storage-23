"""Command handling"""

from diona.project.command import CommandManager


class CommandHandler:
    """Command handler"""
    def __init__(self):
        """Initialize command handler"""
        self.command_manager = CommandManager()
    
    def execute_command(self, command_line: str):
        """Execute command
        
        Args:
            command_line: Command line
        """
        # Parse command line
        parts = command_line.split()
        if not parts:
            return
        
        command_name = parts[0]
        args = parts[1:]
        
        # Get command
        command = self.command_manager.get_command(command_name)
        if not command:
            print(f"Command '{command_name}' not found")
            return
        
        # Execute command
        try:
            command.implementation(*args)
        except Exception as e:
            print(f"Error executing command: {e}")
