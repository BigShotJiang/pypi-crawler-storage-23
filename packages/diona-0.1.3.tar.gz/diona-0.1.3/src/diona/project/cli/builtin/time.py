"""Time command"""

import datetime
from .base import BuiltinCommand


class TimeCommand(BuiltinCommand):
    """Time command"""
    name = "time"
    description = "Show current time"
    
    def execute(self, args):
        """Execute time command"""
        current_time = datetime.datetime.now().strftime("%H:%M:%S")
        print(f"Current time: {current_time}")
        return False


# Global instance
time_command = TimeCommand()
