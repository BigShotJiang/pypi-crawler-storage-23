"""Help command"""

from .base import BuiltinCommand


class HelpCommand(BuiltinCommand):
    """Help command"""
    name = "help"
    description = "Show help information"
    
    def execute(self, args):
        """Execute help command"""
        help_text = """
Built-in Commands:
    /exit      Exit CLI
    /help      Show this help information
    /time      Show current time
    /date      Show current date

Diona Commands:
    Use 'diona help' for more information
"""
        print(help_text)
        return False


# Global instance
help_command = HelpCommand()
