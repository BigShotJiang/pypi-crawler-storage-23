"""Date command"""

import datetime
from .base import BuiltinCommand


class DateCommand(BuiltinCommand):
    """Date command"""
    name = "date"
    description = "Show current date"
    
    def execute(self, args):
        """Execute date command"""
        current_date = datetime.datetime.now().strftime("%Y-%m-%d")
        print(f"Current date: {current_date}")
        return False


# Global instance
date_command = DateCommand()
