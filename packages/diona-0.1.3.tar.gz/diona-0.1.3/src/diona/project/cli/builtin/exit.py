"""Exit command"""

from .base import BuiltinCommand


class ExitCommand(BuiltinCommand):
    """Exit command"""
    name = "exit"
    description = "Exit CLI"
    
    def execute(self, args):
        """Execute exit command"""
        return True


# Global instance
exit_command = ExitCommand()
