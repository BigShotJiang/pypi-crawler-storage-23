"""Builtin command base class"""


class BuiltinCommand:
    """Builtin command base class"""
    name = ""
    description = ""
    
    def execute(self, args):
        """Execute command
        
        Args:
            args: Command arguments
        """
        pass
