"""UI design"""


class UI:
    """UI design class"""
    
    @staticmethod
    def display_prompt():
        """Display prompt"""
        print("<diona@UUU>", end=" ")
    
    @staticmethod
    def display_output(output):
        """Display output
        
        Args:
            output: Output to display
        """
        print(output)
    
    @staticmethod
    def display_error(error):
        """Display error
        
        Args:
            error: Error to display
        """
        print(f"[ERROR] {error}")
    
    @staticmethod
    def display_banner():
        """Display banner"""
        banner = """
========================================
        Diona CLI
========================================
Type /help for available commands
"""
        print(banner)
