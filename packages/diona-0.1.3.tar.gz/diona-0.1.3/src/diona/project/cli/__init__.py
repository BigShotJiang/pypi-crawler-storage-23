"""CLI module"""

from .core import run_cli

__all__ = ["run_cli"]
