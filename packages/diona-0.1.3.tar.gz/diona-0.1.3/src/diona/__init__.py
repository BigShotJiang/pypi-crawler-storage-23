__version__ = "0.1.0"

from diona.firstmeet import hello_diona

__all__ = ["hello_diona", "__version__"]
