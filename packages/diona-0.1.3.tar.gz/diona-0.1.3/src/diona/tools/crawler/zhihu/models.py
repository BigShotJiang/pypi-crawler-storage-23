from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class ZhihuParseResult:
    """知乎解析结果模型"""
    
    title: str
    """文章标题"""
    
    author: str
    """作者名称"""
    
    date_position: str
    """文章发布时间的位置信息"""
    
    content: str
    """文章内容（纯文本）"""
    
    images: List[str]
    """图片URL列表"""
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            'title': self.title,
            'author': self.author,
            'date_position': self.date_position,
            'content': self.content,
            'images': self.images
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ZhihuParseResult':
        """从字典创建实例"""
        return cls(
            title=data.get('title', ''),
            author=data.get('author', ''),
            date_position=data.get('date_position', ''),
            content=data.get('content', ''),
            images=data.get('images', [])
        )