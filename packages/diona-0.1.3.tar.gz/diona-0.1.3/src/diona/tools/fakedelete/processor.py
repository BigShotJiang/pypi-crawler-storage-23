"""File processor implementation"""

import threading
import time
from rich.console import Console

from .queue import ThreadSafeQueue


console = Console()


class FileProcessor:
    """File processor class"""
    
    def __init__(self, queue: ThreadSafeQueue):
        """Initialize file processor
        
        Args:
            queue: Thread-safe queue containing file paths
        """
        self.queue = queue
    
    def process_files(self):
        """Process files from the queue and output delete commands"""
        console.print("[bold cyan]🚀 Fake Delete Mode Started![/]")
        console.print("[dim]Scanning files...[/]")
        console.print("─" * 60)
        
        file_count = 0
        
        while not self.queue.stopped() or not self.queue.empty():
            file_path = self.queue.get(block=True, timeout=1.0)
            if file_path:
                file_count += 1
                # Output delete command for Windows
                delete_command = f"del /f /q \"{file_path}\""
                console.print(f"[yellow]DELETE:[/] {delete_command}")
                time.sleep(0.2)

        
        console.print("─" * 60)
        console.print(f"[bold green]✅ Scanning completed![/]")
        console.print(f"[dim]Found {file_count} files to delete[/]")
        console.print("[bold red]Note: No files were actually deleted![/]")
