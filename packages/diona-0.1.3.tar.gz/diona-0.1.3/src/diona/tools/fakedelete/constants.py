"""Constants for fake delete tool"""

# Default directories to scan
DEFAULT_DIRECTORIES = [
    "C:\\Windows",
    "C:\\Program Files",
    "C:\\Program Files (x86)"
]

# Maximum number of files to process
MAX_FILES = 250
