"""Command for fake delete tool"""

import threading
import time
from typing import List

from diona.project.command import CommandModel, CommandParameter
from .queue import ThreadSafeQueue
from .scanner import FileScanner
from .processor import FileProcessor, console
from .constants import DEFAULT_DIRECTORIES


class FakeDeleteCommand(CommandModel):
    """Fake delete command"""
    name = "fakedelete"
    description = "Scan directories and output delete commands without actually deleting files"
    parameters = [
        CommandParameter(
            name="directories",
            type="list",
            description="Directories to scan (comma-separated)",
            required=False,
            default=",".join(DEFAULT_DIRECTORIES)
        ),
    ]
    
    @staticmethod
    def implementation(*args):
        """Command implementation"""
        # Parse arguments
        if len(args) > 0:
            # Split directories by comma
            directories = [d.strip() for d in args[0].split(",")]
        else:
            directories = DEFAULT_DIRECTORIES
        
        # Create thread-safe queue
        queue = ThreadSafeQueue()
        
        # Create scanner and processor
        scanner = FileScanner(directories, queue)
        processor = FileProcessor(queue)
        
        # Start processor thread as daemon
        processor_thread = threading.Thread(target=processor.process_files, daemon=True)
        processor_thread.start()
        
        try:
            # Start scanning
            scanner.start_scanning()
            processor_thread.join()
        except KeyboardInterrupt:
            # Handle Ctrl+C gracefully
            console.print("\n[bold red]👋 Scan interrupted by user![/]")
        finally:
            # Stop the queue
            queue.stop()
            # Give processor thread a moment to process any remaining items
            time.sleep(0.5)
