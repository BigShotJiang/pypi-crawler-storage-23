"""Thread-safe queue implementation"""

import queue
import threading


class ThreadSafeQueue:
    """Thread-safe queue for storing file paths"""
    
    def __init__(self, maxsize: int = 0):
        """Initialize thread-safe queue
        
        Args:
            maxsize: Maximum size of the queue
        """
        self._queue = queue.Queue(maxsize)
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
    
    def put(self, item: str):
        """Put an item into the queue
        
        Args:
            item: Item to put into the queue
        """
        if not self._stop_event.is_set():
            with self._lock:
                self._queue.put(item)
    
    def get(self, block: bool = True, timeout: float = None) -> str:
        """Get an item from the queue
        
        Args:
            block: Whether to block if the queue is empty
            timeout: Timeout for blocking
        
        Returns:
            str: Item from the queue
        """
        try:
            return self._queue.get(block=block, timeout=timeout)
        except queue.Empty:
            return None
    
    def qsize(self) -> int:
        """Get the size of the queue
        
        Returns:
            int: Size of the queue
        """
        with self._lock:
            return self._queue.qsize()
    
    def empty(self) -> bool:
        """Check if the queue is empty
        
        Returns:
            bool: True if the queue is empty, False otherwise
        """
        with self._lock:
            return self._queue.empty()
    
    def stop(self):
        """Stop the queue"""
        self._stop_event.set()
    
    def stopped(self) -> bool:
        """Check if the queue is stopped
        
        Returns:
            bool: True if the queue is stopped, False otherwise
        """
        return self._stop_event.is_set()
