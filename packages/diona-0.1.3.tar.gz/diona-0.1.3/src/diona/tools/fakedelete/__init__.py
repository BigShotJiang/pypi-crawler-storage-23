"""Fake delete tool module"""

from .command import FakeDeleteCommand

__all__ = ['FakeDeleteCommand']
