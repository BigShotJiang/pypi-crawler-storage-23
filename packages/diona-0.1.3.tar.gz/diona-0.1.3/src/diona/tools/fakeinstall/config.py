"""Configuration for fake install tool"""

from .models import Instruction
from .constants import NPM_PACKAGES, PIP_PACKAGES, APT_PACKAGES, DOCKER_IMAGES


MANAGER_MODELS = {
    "npm": {
        "prefix": "npm install",
        "color": "cyan",
        "package_list": NPM_PACKAGES,
        "pre_instructions": [
            Instruction(type="log", level="INFO", template="Resolving dependencies..."),
            Instruction(type="log", level="INFO", template="Found {num} packages to install"),
        ],
        "progress_desc_template": "Installing {num} packages...",
        "item_template": "[cyan]Installing {pkg}@{ver}[/]",
        "item_success_template": "[green]✓[/] {pkg}@{ver} installed successfully",
        "post_instructions": [
            Instruction(type="log", level="SUCCESS", template="added {num} packages, and audited {audited} packages in {time}s"),
        ],
        "success_template": "[bold green]✅ Success! Installed {num} packages in {time}s[/]",
    },
    "yarn": {
        "prefix": "yarn add",
        "color": "blue",
        "package_list": NPM_PACKAGES,
        "pre_instructions": [
            Instruction(type="log", level="INFO", template="Resolving dependencies..."),
            Instruction(type="log", level="INFO", template="Found {num} packages to install"),
        ],
        "progress_desc_template": "Installing {num} packages...",
        "item_template": "[blue]Installing {pkg}@{ver}[/]",
        "item_success_template": "[green]✓[/] {pkg}@{ver} installed successfully",
        "post_instructions": [
            Instruction(type="log", level="SUCCESS", template="added {num} packages in {time}s"),
        ],
        "success_template": "[bold green]✅ Success! Installed {num} packages in {time}s[/]",
    },
    "pip": {
        "prefix": "pip install",
        "color": "green",
        "package_list": PIP_PACKAGES,
        "pre_instructions": [
            Instruction(type="log", level="INFO", template="Collecting packages..."),
        ],
        "progress_desc_template": "Installing {num} packages...",
        "item_template": "[green]Installing {pkg}=={ver}[/]",
        "item_success_template": "[green]Successfully installed {pkg}-{ver}[/]",
        "post_instructions": [
            Instruction(type="log", level="SUCCESS", template="Successfully installed {num} packages in {time}s"),
        ],
        "success_template": "[bold green]✅ Successfully installed {num} packages[/]",
    },
    "apt": {
        "prefix": "apt-get install -y",
        "color": "magenta",
        "package_list": APT_PACKAGES,
        "pre_instructions": [
            Instruction(type="log", level="INFO", template="Reading package lists..."),
            Instruction(type="log", level="INFO", template="Building dependency tree..."),
        ],
        "progress_desc_template": "Unpacking {num} packages...",
        "item_template": "[magenta]Preparing to unpack {pkg}[/]",
        "item_success_template": "[green]Unpacked {pkg}[/]",
        "post_instructions": [
            Instruction(type="log", level="SUCCESS", template="Done. {num} packages installed."),
        ],
        "success_template": "[bold green]✅ Done. {num} packages installed.[/]",
    },
    "docker": {
        "prefix": "docker pull",
        "color": "red",
        "image_list": DOCKER_IMAGES,
        "pre_instructions": [
            Instruction(type="log", level="INFO", template="Pulling image..."),
        ],
        "progress_desc_template": "Pulling {num} images...",
        "item_template": "[red]Pulling {image}[/]",
        "item_success_template": "[green]Status: Downloaded newer image for {image}[/]",
        "post_instructions": [
            Instruction(type="log", level="SUCCESS", template="Image pulled successfully"),
        ],
        "success_template": "[bold green]✅ Image pulled successfully[/]",
    },
}
