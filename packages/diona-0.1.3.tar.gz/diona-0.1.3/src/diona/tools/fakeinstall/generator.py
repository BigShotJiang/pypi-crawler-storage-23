"""Instruction generator for fake install tool"""

import random
from typing import List

from .models import Instruction
from .config import MANAGER_MODELS
from .utils import random_semver, random_audited, random_time


def generate_batch_instructions(manager: str, num_packages: int) -> List[Instruction]:
    """Generate a batch of instructions for fake install"""
    # Get manager configuration
    model = MANAGER_MODELS[manager]
    
    # Initialize instruction sequence
    sequence = []
    
    # Add prefix instruction
    sequence.append(Instruction(type="prefix", template=model["prefix"]))
    
    # Add pre-instructions
    for instr in model["pre_instructions"]:
        # Replace placeholders
        template = instr.template
        if "{num}" in template:
            template = template.format(num=num_packages)
        sequence.append(Instruction(
            type=instr.type,
            level=instr.level,
            template=template,
            data=instr.data
        ))
    
    # Generate install item instructions
    if manager == "docker":
        # Handle docker images
        image_list = model["image_list"]
        for _ in range(num_packages):
            image = random.choice(image_list)
            sequence.append(Instruction(
                type="install_item",
                template=model["item_template"],
                data={"image": image}
            ))
    else:
        # Handle regular packages
        package_list = model["package_list"]
        for _ in range(num_packages):
            pkg = random.choice(package_list)
            ver = random_semver()
            sequence.append(Instruction(
                type="install_item",
                template=model["item_template"],
                data={"pkg": pkg, "ver": ver}
            ))
    
    # Add post-instructions
    for instr in model.get("post_instructions", []):
        # Replace placeholders
        template = instr.template
        # Create a dictionary for placeholder replacement
        replacements = {}
        if "{num}" in template:
            replacements["num"] = num_packages
        if "{audited}" in template:
            replacements["audited"] = random_audited(num_packages)
        if "{time}" in template:
            replacements["time"] = random_time()
        # Format the template with all replacements
        template = template.format(**replacements)
        sequence.append(Instruction(
            type=instr.type,
            level=instr.level,
            template=template,
            data=instr.data
        ))
    
    # Add success instruction
    success_template = model["success_template"]
    # Create a dictionary for placeholder replacement
    success_replacements = {}
    if "{num}" in success_template:
        success_replacements["num"] = num_packages
    if "{time}" in success_template:
        success_replacements["time"] = random_time()
    # Format the template with all replacements
    success_template = success_template.format(**success_replacements)
    sequence.append(Instruction(
        type="success",
        template=success_template
    ))
    
    return sequence
