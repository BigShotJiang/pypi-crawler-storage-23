"""Utility functions for fake install tool"""

import random

from .constants import WARN_MESSAGES


def random_semver() -> str:
    """Generate a random semantic version string"""
    major = random.randint(0, 5)
    minor = random.randint(0, 20)
    patch = random.randint(0, 99)
    return f"{major}.{minor}.{patch}"


def random_audited(num: int) -> int:
    """Generate a random audited package count"""
    return num * random.randint(1, 3)


def random_time() -> str:
    """Generate a random time string"""
    time = random.uniform(0.5, 5.0)
    return f"{time:.2f}"


def random_warning_message() -> str:
    """Generate a random warning message"""
    return random.choice(WARN_MESSAGES)


def random_sleep(min_sec: float, max_sec: float, speed: float) -> float:
    """Generate a random sleep time adjusted by speed"""
    return random.uniform(min_sec, max_sec) / speed
