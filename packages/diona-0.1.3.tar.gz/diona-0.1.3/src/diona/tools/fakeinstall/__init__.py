"""Fake install tool"""

from .command import FakeInstallCommand

__all__ = ["FakeInstallCommand"]
