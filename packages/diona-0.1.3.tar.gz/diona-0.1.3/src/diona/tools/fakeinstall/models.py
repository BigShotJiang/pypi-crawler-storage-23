"""Data models for fake install tool"""

from dataclasses import dataclass
from typing import Optional, Dict, Any


@dataclass
class Instruction:
    """Instruction data class for fake install tool"""
    type: str                     # 指令类型：prefix / log / install_item / success
    level: Optional[str] = None   # 日志级别：INFO / WARN / SUCCESS（仅type=log时有效）
    template: Optional[str] = None # 带占位符的模板字符串
    data: Optional[Dict[str, Any]] = None  # 动态数据，如 {"pkg": "react", "ver": "18.2.0"}
