"""
LangGraph integration for Visibe.

Thin subclass of LangChainIntegration that sets framework to "langgraph".

Either import works:
    from visibe.integrations.langchain import LangChainIntegration
    from visibe.integrations.langgraph import LangGraphIntegration
"""
from .langchain import LangChainIntegration, LangGraphCallback


class LangGraphIntegration(LangChainIntegration):
    """LangGraph integration — reports framework as 'langgraph'."""

    def __init__(self, client):
        super().__init__(client)
        self._framework = "langgraph"
