"""
Framework and provider integrations for Visibe.

Available integrations:
- CrewAIIntegration: Track CrewAI crew executions
- LangChainIntegration: Track LangChain agent executions
- LangGraphIntegration: Track LangGraph graph executions
- AutoGenIntegration: Track AutoGen multi-agent conversations
- OpenAIIntegration: Track direct OpenAI API calls
- BedrockIntegration: Track AWS Bedrock converse() calls

Each integration only loads if its dependencies are installed.
Import directly from the submodule if you want a clear error:
    from visibe.integrations.openai import OpenAIIntegration
"""

__all__ = []

try:
    from .crewai import CrewAIIntegration
    __all__.append("CrewAIIntegration")
except Exception:
    pass

try:
    from .langchain import LangChainIntegration
    __all__.append("LangChainIntegration")
except Exception:
    pass

try:
    from .langgraph import LangGraphIntegration
    __all__.append("LangGraphIntegration")
except Exception:
    pass

try:
    from .autogen import AutoGenIntegration
    __all__.append("AutoGenIntegration")
except Exception:
    pass

try:
    from .openai import OpenAIIntegration
    __all__.append("OpenAIIntegration")
except Exception:
    pass

try:
    from .bedrock import BedrockIntegration
    __all__.append("BedrockIntegration")
except Exception:
    pass
