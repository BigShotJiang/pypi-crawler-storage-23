"""
Unit tests for visibe/utils.py — calculate_cost() and pricing logic.
No external dependencies required.
"""
from visibe.utils import calculate_cost


def test_known_model_positive_cost():
    cost = calculate_cost("gpt-4o-mini", 1000, 500)
    assert cost > 0


def test_gpt4o_mini_exact():
    # input: 1000/1000 * 0.00015 = 0.00015
    # output: 500/1000 * 0.0006 = 0.0003
    # total: 0.00045
    cost = calculate_cost("gpt-4o-mini", 1000, 500)
    assert abs(cost - 0.00045) < 1e-7


def test_gpt4_exact():
    # input: 1000/1000 * 0.03 = 0.03
    # output: 1000/1000 * 0.06 = 0.06
    # total: 0.09
    cost = calculate_cost("gpt-4", 1000, 1000)
    assert abs(cost - 0.09) < 1e-7


def test_unknown_model_returns_zero():
    cost = calculate_cost("some-unknown-model-v99", 1000, 500)
    assert cost == 0.0


def test_prefix_matching_mini_before_base():
    # "gpt-4o-mini" is longer prefix, must match before "gpt-4o"
    cost_mini = calculate_cost("gpt-4o-mini-2024-07-18", 1000, 1000)
    cost_base = calculate_cost("gpt-4o", 1000, 1000)
    # mini is cheaper — if prefix matching is wrong, mini would use gpt-4o pricing
    assert cost_mini < cost_base


def test_versioned_model_name_matches():
    # "gpt-4o-mini-2024-07-18" contains "gpt-4o-mini" — should still match
    cost = calculate_cost("gpt-4o-mini-2024-07-18", 1000, 0)
    assert cost > 0


def test_bedrock_anthropic_haiku():
    # input: 1000/1000 * 0.00025 = 0.00025
    # output: 500/1000 * 0.00125 = 0.000625
    # total: 0.000875
    cost = calculate_cost("anthropic.claude-3-haiku-20240307-v1:0", 1000, 500)
    assert abs(cost - 0.000875) < 1e-6


def test_bedrock_unknown_model_returns_zero():
    cost = calculate_cost("some.unknown-model-v1:0", 1000, 500)
    assert cost == 0.0


def test_zero_tokens_returns_zero():
    cost = calculate_cost("gpt-4o-mini", 0, 0)
    assert cost == 0.0


def test_cost_precision_six_decimals():
    # Result is rounded to 6 decimal places — should not be 0 for small usage
    cost = calculate_cost("gpt-4o-mini", 1, 1)
    # input: 1/1000 * 0.00015 = 0.00000015; output: 1/1000 * 0.0006 = 0.0000006
    # total: 0.00000075 → round to 6 decimals = 0.000001
    assert cost >= 0.000001


def test_case_insensitive_model():
    cost_lower = calculate_cost("gpt-4o-mini", 1000, 500)
    cost_upper = calculate_cost("GPT-4O-MINI", 1000, 500)
    assert cost_lower == cost_upper


def test_nova_micro_pricing():
    cost = calculate_cost("amazon.nova-micro-v1:0", 1000, 1000)
    assert cost > 0


def test_claude_3_sonnet_via_proxy():
    # Test that Anthropic proxy model names resolve (e.g. "claude-3-sonnet-20240229")
    cost = calculate_cost("claude-3-sonnet-20240229", 1000, 1000)
    assert cost > 0
