"""UCI parser and encoder library in python"""
__version__ = "0.3"

from .ucilark import UCI_msg
__all__ = ['UCI_msg']
