---
type: note
status: draft # draft | active | review | final
subtype: # idea | learning | research | meeting-notes | reference
name:
description:
project: # Link to Project
session: # Link to Session
related: []
relationships: []
created: "{{date}}"
tags: []
---

# {{title}}

## Related
![[related.base#All]]
