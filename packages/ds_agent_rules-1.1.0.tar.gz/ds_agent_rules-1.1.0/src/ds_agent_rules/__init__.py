"""ds-agent-rules: AI agent rules for DS/ML/AI Engineering."""

__version__ = "1.1.0"
