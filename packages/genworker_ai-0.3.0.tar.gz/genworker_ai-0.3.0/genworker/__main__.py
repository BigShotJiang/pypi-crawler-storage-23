"""Allow running genworker as a module: python -m genworker."""

from genworker.agent import main

main()
