"""Tool router — dispatches Claude tool calls to the correct handler."""

from genworker.tools.computer import execute_computer_action
from genworker.tools.shell import execute_bash
from genworker.tools.editor import execute_text_editor
from genworker.config import log


def execute_tool(block, monitor: dict) -> str:
    """Route a Claude tool_use block to the appropriate executor."""
    name = block.name
    inp  = block.input

    if name == "computer":
        return execute_computer_action(inp, monitor)
    elif name == "bash":
        return execute_bash(inp)
    elif name in ("str_replace_based_edit_tool", "str_replace_editor"):
        return execute_text_editor(inp)
    else:
        log.warning(f"Unknown tool: {name}")
        return f"Error: unknown tool '{name}'"
