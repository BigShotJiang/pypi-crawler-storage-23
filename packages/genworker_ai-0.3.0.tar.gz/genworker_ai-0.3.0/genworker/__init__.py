"""GenWorker - Desktop AI Agent powered by Claude Computer Use."""

__version__ = "0.3.0"
