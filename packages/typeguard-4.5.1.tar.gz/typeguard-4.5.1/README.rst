.. image:: https://github.com/agronholm/typeguard/actions/workflows/test.yml/badge.svg
  :target: https://github.com/agronholm/typeguard/actions/workflows/test.yml
  :alt: Build Status
.. image:: https://coveralls.io/repos/agronholm/typeguard/badge.svg?branch=master&service=github
  :target: https://coveralls.io/github/agronholm/typeguard?branch=master
  :alt: Code Coverage
.. image:: https://readthedocs.org/projects/typeguard/badge/?version=latest
  :target: https://typeguard.readthedocs.io/en/latest/?badge=latest
  :alt: Documentation
.. image:: https://tidelift.com/badges/package/pypi/typeguard
  :target: https://tidelift.com/subscription/pkg/pypi-typeguard
  :alt: Tidelift

This library provides run-time type checking for functions defined with
`PEP 484 <https://www.python.org/dev/peps/pep-0484/>`_ argument (and return) type
annotations, and any arbitrary objects. It can be used together with static type
checkers as an additional layer of type safety, to catch type violations that could only
be detected at run time.

Three principal ways to do type checking are provided, each with its pros and cons:

#. The ``check_type`` function:

   * like ``isinstance()``, but supports arbitrary type annotations (within limits)
   * can be used as a ``cast()`` replacement, but with actual checking of the value
#. The ``check_argument_types()`` and ``check_return_type()`` functions:

   * debugger friendly (except when running with the pydev debugger with the C extension installed)
   * does not work reliably with dynamically defined type hints (e.g. in nested functions)
#. Code instrumentation:

   * entire modules, or individual functions (via ``@typechecked``) are recompiled, with
     type checking code injected into them
   * automatically checks function arguments, return values and assignments to annotated
     local variables
   * for generator functions (regular and async), checks yield and send values
   * requires the original source code of the instrumented module(s) to be accessible

Two options are provided for code instrumentation:

#. the ``@typechecked`` function:

   * can be applied to functions individually
#. the import hook (``typeguard.install_import_hook()``):

   * automatically instruments targeted modules on import
   * no manual code changes required in the target modules
   * requires the import hook to be installed before the targeted modules are imported
   * may clash with other import hooks

See the documentation_ for further information.

.. _documentation: https://typeguard.readthedocs.io/en/latest/
