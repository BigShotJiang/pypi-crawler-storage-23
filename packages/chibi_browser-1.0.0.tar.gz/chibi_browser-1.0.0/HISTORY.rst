=======
History
=======

******************
1.0.0 (2026-03-01)
******************

* primera version funcional para controlar selenium

******************
0.0.1 (2026-02-28)
******************

* First release on PyPI.
