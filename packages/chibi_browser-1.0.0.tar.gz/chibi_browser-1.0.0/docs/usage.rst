=====
Usage
=====

To use chibi_browser in a project::

    import chibi_browser
