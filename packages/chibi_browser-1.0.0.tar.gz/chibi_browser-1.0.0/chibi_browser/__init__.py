# -*- coding: utf-8 -*-
__author__ = """dem4ply"""
__email__ = 'dem4ply@gmail.com'
__version__ = '1.0.0'


from .chibi_browser import Chibi_browser


__all__ = [ 'Chibi_browser' ]
