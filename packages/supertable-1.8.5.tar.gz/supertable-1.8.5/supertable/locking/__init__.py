from supertable.locking.locking import Locking

__all__ = ["Locking"]
