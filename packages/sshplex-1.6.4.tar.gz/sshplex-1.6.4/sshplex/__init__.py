"""SSHplex - SSH Connection Multiplexer"""
__version__ = "1.6.4"
__author__ = "MJAHED Sabri"
__email__ = "contact@sabrimjahed.com"
