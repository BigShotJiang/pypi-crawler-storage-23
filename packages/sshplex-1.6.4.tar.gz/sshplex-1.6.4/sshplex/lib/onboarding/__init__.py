"""Onboarding wizard for first-time SSHplex setup."""

from .wizard import OnboardingWizard

__all__ = ['OnboardingWizard']
