# Copyright (C) 2012 Andrea Cometa.
# Email: info@andreacometa.it
# Web site: http://www.andreacometa.it
# Copyright (C) 2012 Associazione OpenERP Italia
# (<http://www.odoo-italia.org>).
# Copyright (C) 2012-2017 Lorenzo Battistini - Agile Business Group
# Copyright (C) 2019 Sergio Zanchetta - Associazione PNLUG
# Copyright 2023 Simone Rubino - Aion Tech
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "ITA - Ricevute bancarie",
    "version": "18.0.1.2.0",
    "development_status": "Beta",
    "author": "Odoo Community Association (OCA)",
    "category": "Localization/Italy",
    "summary": "Ricevute bancarie",
    "website": "https://github.com/OCA/l10n-italy",
    "license": "AGPL-3",
    "excludes": ["l10n_it_riba"],
    "depends": [
        "account",
        "account_due_list",
        "base_iban",
        "l10n_it_abicab",
        "l10n_it_edi_related_document",
        "account_payment_term_extension",
    ],
    "data": [
        "data/riba_sequence.xml",
        "report/report.xml",
        "security/ir.model.access.csv",
        "security/riba_security.xml",
        "views/wizard_credit.xml",
        "views/wizard_past_due.xml",
        "views/riba_view.xml",
        "views/account_view.xml",
        "views/configuration_view.xml",
        "views/partner_view.xml",
        "views/wizard_riba_issue.xml",
        "views/wizard_riba_file_export.xml",
        "views/wizard_riba_payment_date.xml",
        "views/account_config_view.xml",
        "views/slip_report.xml",
        "views/riba_detail_view.xml",
        "views/wizard_presentation.xml",
        "views/wizard_due_date_settlement.xml",
        "wizard/wizard_riba_multiple_payment_views.xml",
    ],
    "demo": ["demo/riba_demo.xml"],
    "external_dependencies": {
        "python": [
            "openupgradelib",
            "unidecode",
        ],
    },
    "pre_init_hook": "pre_absorb_old_module",
    "installable": True,
}
