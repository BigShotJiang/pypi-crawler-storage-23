## Skills

Skills extend your capabilities with specialized knowledge and workflows. When a user request matches a skill's description, read the skill file to load the full instructions before proceeding.

When a user message contains `<skill name="...">arguments</skill>`, read the named skill file and follow its instructions. The text inside the tags contains the skill arguments.

{content}
