"""Bing Webmaster Tools resource for Agent Berlin SDK."""

from .._http import HTTPClient
from ..models.bing import (
    CrawlStats,
    PageStatsResponse,
    QueryStatsResponse,
    SiteInfo,
    TrafficStats,
)
from ..utils import get_project_domain


class BingResource:
    """Resource for Bing Webmaster Tools operations.

    Provides access to Bing Webmaster data through the Agent Berlin API.
    The site context is determined by the sandbox's PROJECT_DOMAIN environment
    variable, so methods don't require explicit siteUrl parameters.

    Example:
        # Get query stats
        result = client.bing_webmaster.get_query_stats()
        for row in result.rows:
            print(f"{row.query}: {row.clicks} clicks")

        # Get site info
        site = client.bing_webmaster.get_site()
        print(f"Site: {site.site_url}")

        # Get traffic stats
        traffic = client.bing_webmaster.get_traffic_stats()
        print(f"Impressions: {traffic.impressions}")

        # Get crawl stats
        crawl = client.bing_webmaster.get_crawl_stats()
        print(f"Crawled pages: {crawl.crawled_pages}")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def get_query_stats(self) -> QueryStatsResponse:
        """Get query statistics for the current site.

        Returns search query analytics including impressions, clicks,
        average position, and CTR.

        Returns:
            QueryStatsResponse with rows of query data.

        Raises:
            AgentBerlinAPIError: If the API returns an error.
        """
        project_domain = get_project_domain()
        data = self._http.post("/bing/querystats", json={"project_domain": project_domain})
        return QueryStatsResponse.model_validate(data)

    def get_page_stats(self) -> PageStatsResponse:
        """Get page statistics for the current site.

        Returns page-level analytics including impressions, clicks,
        average position, and CTR.

        Returns:
            PageStatsResponse with rows of page data.

        Raises:
            AgentBerlinAPIError: If the API returns an error.
        """
        project_domain = get_project_domain()
        data = self._http.post("/bing/pagestats", json={"project_domain": project_domain})
        return PageStatsResponse.model_validate(data)

    def get_traffic_stats(self) -> TrafficStats:
        """Get traffic statistics for the current site.

        Returns overall traffic metrics including impressions, clicks,
        CTR, and ranking data.

        Returns:
            TrafficStats with aggregate traffic metrics.

        Raises:
            AgentBerlinAPIError: If the API returns an error.
        """
        project_domain = get_project_domain()
        data = self._http.post("/bing/trafficstats", json={"project_domain": project_domain})
        return TrafficStats.model_validate(data)

    def get_crawl_stats(self) -> CrawlStats:
        """Get crawl statistics for the current site.

        Returns crawl metrics including pages crawled, errors,
        indexing status, and various crawl issues.

        Returns:
            CrawlStats with crawl metrics.

        Raises:
            AgentBerlinAPIError: If the API returns an error.
        """
        project_domain = get_project_domain()
        data = self._http.post("/bing/crawlstats", json={"project_domain": project_domain})
        return CrawlStats.model_validate(data)

    def get_site(self) -> SiteInfo:
        """Get information about the current site.

        Returns the site URL and verification status for the site
        associated with the current sandbox.

        Returns:
            SiteInfo with site URL and verification status.

        Raises:
            AgentBerlinAPIError: If the API returns an error.
        """
        project_domain = get_project_domain()
        data = self._http.post("/bing/site", json={"project_domain": project_domain})
        return SiteInfo.model_validate(data)
