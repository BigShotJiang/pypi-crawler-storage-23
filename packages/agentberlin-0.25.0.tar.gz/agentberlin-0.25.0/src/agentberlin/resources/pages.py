"""Pages resource for Agent Berlin SDK."""

from typing import Optional

from .._http import HTTPClient
from ..models.search import AdvancedPageSearchResponse, PageDetailResponse
from ..utils import get_project_domain


class PagesResource:
    """Resource for page operations.

    Example:
        # Search for similar pages by query
        results = client.pages.advanced_page_search(query="SEO best practices")

        # Find similar pages to an indexed page
        results = client.pages.advanced_page_search(
            url="https://example.com/blog/seo-guide",
            deep_search=True
        )

        # Get page details
        page = client.pages.get(url="https://example.com/blog/seo-tips")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def advanced_page_search(
        self,
        *,
        query: Optional[str] = None,
        url: Optional[str] = None,
        content: Optional[str] = None,
        deep_search: bool = False,
        count: Optional[int] = None,
        offset: Optional[int] = None,
        similarity_threshold: Optional[float] = None,
        domain: Optional[str] = None,
        own_only: bool = False,
        status_code: Optional[str] = None,
        topic: Optional[str] = None,
        page_type: Optional[str] = None,
    ) -> AdvancedPageSearchResponse:
        """Advanced page search with multiple input modes.

        This unified method supports three input modes (exactly one required):
        - query: Simple text query for semantic search across all pages
        - url: Find similar pages to an existing indexed page
        - content: Find similar pages to provided raw content

        The project domain is automatically populated.

        Args:
            query: Text query for semantic search (mutually exclusive with url/content).
            url: URL of an indexed page to find similar pages for (mutually exclusive with query/content).
            content: Raw content string to find similar pages for (mutually exclusive with query/url).
            deep_search: If True and url is provided, also include chunk-level analysis.
            count: Maximum recommendations to return (default: 10, max: 50).
            offset: Pagination offset (default: 0).
            similarity_threshold: Minimum similarity score 0-1 (default: 0.60).
            domain: Filter by domain (e.g., "competitor.com").
            own_only: If True, filter to only your own pages (excludes competitors).
            status_code: Filter by HTTP status code ("200", "404", "error", "redirect", "success").
            topic: Filter by topic name.
            page_type: Filter by page type ("pillar" or "landing").

        Returns:
            AdvancedPageSearchResponse with page_recommendations and optionally chunk_recommendations.

        Raises:
            AgentBerlinValidationError: If input validation fails (e.g., multiple inputs provided).

        Example:
            # Query mode
            results = client.pages.advanced_page_search(query="SEO tips")

            # URL mode with deep search
            results = client.pages.advanced_page_search(
                url="https://example.com/blog/guide",
                deep_search=True
            )

            # Content mode
            results = client.pages.advanced_page_search(
                content="This is my page content..."
            )

            # Query mode with filters
            results = client.pages.advanced_page_search(
                query="SEO guide",
                domain="example.com",
                status_code="200",
                page_type="pillar"
            )
        """
        payload: dict[str, object] = {
            "project_domain": get_project_domain(),
        }
        if query is not None:
            payload["query"] = query
        if url is not None:
            payload["url"] = url
        if content is not None:
            payload["content"] = content
        if deep_search:
            payload["deep_search"] = deep_search
        if count is not None:
            payload["count"] = count
        if offset is not None:
            payload["offset"] = offset
        if similarity_threshold is not None:
            payload["similarity_threshold"] = similarity_threshold
        if domain is not None:
            payload["domain"] = domain
        if own_only:
            payload["own_only"] = own_only
        if status_code is not None:
            payload["status_code"] = status_code
        if topic is not None:
            payload["topic"] = topic
        if page_type is not None:
            payload["page_type"] = page_type

        data = self._http.post("/pages/advanced-search", json=payload)
        return AdvancedPageSearchResponse.model_validate(data)

    def get(
        self,
        url: str,
        *,
        content_length: Optional[int] = None,
    ) -> PageDetailResponse:
        """Get detailed information about a specific page.

        The project domain is automatically populated.

        Args:
            url: The page URL to look up.
            content_length: Max characters of content to return (default: 0).

        Returns:
            PageDetailResponse with page metadata, links, and topic info.
        """
        payload: dict[str, object] = {
            "project_domain": get_project_domain(),
            "url": url,
        }
        if content_length is not None:
            payload["content_length"] = content_length

        data = self._http.post("/pages/get", json=payload)
        return PageDetailResponse.model_validate(data)
