"""BotGuard SDK client — wraps OpenAI to route requests through BotGuard Shield."""

from __future__ import annotations

import json
from typing import Any, Dict, Generator, Iterator, List, Optional, Union

import httpx
from openai import OpenAI, AsyncOpenAI
from openai.types.chat import ChatCompletion, ChatCompletionChunk

from .types import ShieldResult, ShieldVerdict, McpScanResult, RagChunkResult, RagScanResult

_DEFAULT_API_URL = "https://api.botguard.dev"


def _validate_shield_id(shield_id: str) -> None:
    if not shield_id or not isinstance(shield_id, str) or not shield_id.strip():
        raise ValueError(
            "BotGuard: shield_id is required.\n"
            "Get your free Shield ID at: https://botguard.dev → Sign up → Shield → Create Shield\n"
            'Then pass it as: BotGuard(shield_id="sh_your_shield_id")'
        )
    if not shield_id.startswith("sh_"):
        raise ValueError(
            f'BotGuard: Invalid shield_id "{shield_id}". Shield IDs start with "sh_" (e.g. "sh_2803733325433b6929281d5b").\n'
            "Get your Shield ID at: https://botguard.dev → Shield page"
        )


class BotGuard:
    """Synchronous BotGuard client.

    Usage:
        guard = BotGuard(
            shield_id="sh_abc123",
            api_key="sk-...",
        )
        result = guard.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
        )
        if result.blocked:
            print("Blocked:", result.shield.reason)
        else:
            print(result.content)
    """

    def __init__(
        self,
        *,
        shield_id: str,
        api_key: str = "",
        api_url: str = _DEFAULT_API_URL,
        timeout: float = 120.0,
        **openai_kwargs: Any,
    ):
        _validate_shield_id(shield_id)

        self.shield_id = shield_id
        self.api_url = api_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout

        base_url = f"{self.api_url}/api/gateway/{self.shield_id}/v1"

        self._client = OpenAI(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            **openai_kwargs,
        )

        self.chat = _ChatNamespace(self)

    @property
    def openai(self) -> OpenAI:
        """Access the underlying OpenAI client."""
        return self._client

    def scan_tool_response(
        self,
        tool_response: str,
        *,
        tool_name: Optional[str] = None,
    ) -> McpScanResult:
        """Scan an MCP tool response using your shield's config.

        Call this after mcpClient.call_tool(), before passing the result to your LLM.
        Uses the shield_id configured in the constructor.

        Example:
            result = guard.scan_tool_response(tool_output, tool_name="email_search")
            if result.blocked:
                raise ValueError(f"Injection detected: {result.reason}")
            return result.safe_response
        """
        url = f"{self.api_url}/api/mcp/proxy/{self.shield_id}"
        headers = {"Content-Type": "application/json"}
        body: Dict[str, Any] = {"toolResponse": tool_response}
        if tool_name:
            body["toolName"] = tool_name

        with httpx.Client(timeout=self._timeout) as http:
            resp = http.post(url, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        return McpScanResult(
            blocked=data.get("blocked", False),
            confidence=data.get("confidence", 0.0),
            safe_response=data.get("safeResponse"),
            tool_name=data.get("toolName"),
            reason=data.get("reason"),
            analysis_path=data.get("analysisPath"),
            matched_patterns=data.get("matchedPatterns"),
            pii_detections=data.get("piiDetections"),
        )

    def scan_chunks(
        self,
        chunks: List[str],
    ) -> RagScanResult:
        """Scan RAG document chunks using your shield's config.

        Call this after vector DB retrieval, before injecting chunks into context.
        Uses the shield_id configured in the constructor.

        Example:
            result = guard.scan_chunks(retrieved_chunks)
            safe_chunks = result.clean_chunks  # only pass these to your LLM
        """
        url = f"{self.api_url}/api/rag/proxy/{self.shield_id}"
        headers = {"Content-Type": "application/json"}
        body = {"chunks": chunks}

        with httpx.Client(timeout=self._timeout) as http:
            resp = http.post(url, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        results = [
            RagChunkResult(
                chunk=r["chunk"],
                blocked=r["blocked"],
                confidence=r.get("confidence", 0.0),
                reason=r.get("reason"),
                analysis_path=r.get("analysisPath"),
                matched_patterns=r.get("matchedPatterns"),
                pii_detections=r.get("piiDetections"),
            )
            for r in data.get("results", [])
        ]

        return RagScanResult(
            results=results,
            clean_chunks=data.get("cleanChunks", []),
            blocked_count=data.get("blockedCount", 0),
            total_count=data.get("totalCount", len(chunks)),
        )


class BotGuardAsync:
    """Asynchronous BotGuard client.

    Usage:
        guard = BotGuardAsync(
            shield_id="sh_abc123",
            api_key="sk-...",
        )
        result = await guard.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}],
        )
    """

    def __init__(
        self,
        *,
        shield_id: str,
        api_key: str = "",
        api_url: str = _DEFAULT_API_URL,
        timeout: float = 120.0,
        **openai_kwargs: Any,
    ):
        _validate_shield_id(shield_id)

        self.shield_id = shield_id
        self.api_url = api_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout

        base_url = f"{self.api_url}/api/gateway/{self.shield_id}/v1"

        self._client = AsyncOpenAI(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            **openai_kwargs,
        )

        self.chat = _AsyncChatNamespace(self)

    @property
    def openai(self) -> AsyncOpenAI:
        """Access the underlying AsyncOpenAI client."""
        return self._client

    async def scan_tool_response(
        self,
        tool_response: str,
        *,
        tool_name: Optional[str] = None,
    ) -> McpScanResult:
        """Async: scan an MCP tool response using your shield's config."""
        url = f"{self.api_url}/api/mcp/proxy/{self.shield_id}"
        headers = {"Content-Type": "application/json"}
        body: Dict[str, Any] = {"toolResponse": tool_response}
        if tool_name:
            body["toolName"] = tool_name

        async with httpx.AsyncClient(timeout=self._timeout) as http:
            resp = await http.post(url, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        return McpScanResult(
            blocked=data.get("blocked", False),
            confidence=data.get("confidence", 0.0),
            safe_response=data.get("safeResponse"),
            tool_name=data.get("toolName"),
            reason=data.get("reason"),
            analysis_path=data.get("analysisPath"),
            matched_patterns=data.get("matchedPatterns"),
            pii_detections=data.get("piiDetections"),
        )

    async def scan_chunks(
        self,
        chunks: List[str],
    ) -> RagScanResult:
        """Async: scan RAG document chunks using your shield's config."""
        url = f"{self.api_url}/api/rag/proxy/{self.shield_id}"
        headers = {"Content-Type": "application/json"}
        body = {"chunks": chunks}

        async with httpx.AsyncClient(timeout=self._timeout) as http:
            resp = await http.post(url, json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        results = [
            RagChunkResult(
                chunk=r["chunk"],
                blocked=r["blocked"],
                confidence=r.get("confidence", 0.0),
                reason=r.get("reason"),
                analysis_path=r.get("analysisPath"),
                matched_patterns=r.get("matchedPatterns"),
                pii_detections=r.get("piiDetections"),
            )
            for r in data.get("results", [])
        ]

        return RagScanResult(
            results=results,
            clean_chunks=data.get("cleanChunks", []),
            blocked_count=data.get("blockedCount", 0),
            total_count=data.get("totalCount", len(chunks)),
        )


def _extract_shield(data: dict) -> ShieldVerdict:
    """Parse _shield metadata from the API response."""
    meta = data.get("_shield", {})
    if not meta:
        return ShieldVerdict(action="allowed")

    return ShieldVerdict(
        action=meta.get("action", "allowed"),
        reason=meta.get("reason"),
        confidence=meta.get("confidence"),
        analysis_path=meta.get("analysisPath"),
        matched_patterns=meta.get("matchedPatterns"),
        pii_detections=meta.get("piiDetections"),
        guardrail_violation=meta.get("guardrailViolation"),
        policy_violation=meta.get("policyViolation"),
        latency_ms=meta.get("responseTimeMs"),
    )


class _Completions:
    """Synchronous chat.completions namespace."""

    def __init__(self, guard: BotGuard):
        self._guard = guard

    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ShieldResult, Iterator[ShieldResult]]:
        """Create a chat completion through BotGuard Shield.

        Returns a ShieldResult wrapping the response with shield metadata.
        When streaming, yields ShieldResult objects for each chunk.
        """
        if stream:
            return self._create_stream(model=model, messages=messages, **kwargs)

        base_url = str(self._guard._client.base_url).rstrip("/")
        url = f"{base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._guard._api_key}",
            "Content-Type": "application/json",
        }
        body = {"model": model, "messages": messages, "stream": False, **kwargs}

        with httpx.Client(timeout=self._guard._timeout) as http:
            resp = http.post(str(url), json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        shield = _extract_shield(data)
        return ShieldResult(response=data, shield=shield)

    def _create_stream(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        **kwargs: Any,
    ) -> Iterator[ShieldResult]:
        base_url = str(self._guard._client.base_url).rstrip("/")
        url = f"{base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._guard._api_key}",
            "Content-Type": "application/json",
        }
        body = {"model": model, "messages": messages, "stream": True, **kwargs}

        with httpx.Client(timeout=self._guard._timeout) as http:
            with http.stream("POST", str(url), json=body, headers=headers) as resp:
                resp.raise_for_status()
                shield_verdict = ShieldVerdict(action="allowed")
                for line in resp.iter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:]
                    if payload == "[DONE]":
                        break
                    try:
                        chunk_data = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    if "_shield" in chunk_data:
                        shield_verdict = _extract_shield(chunk_data)
                    yield ShieldResult(response=chunk_data, shield=shield_verdict)


class _ChatNamespace:
    def __init__(self, guard: BotGuard):
        self.completions = _Completions(guard)


class _AsyncCompletions:
    """Async chat.completions namespace."""

    def __init__(self, guard: BotGuardAsync):
        self._guard = guard

    async def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ShieldResult, Any]:
        """Create a chat completion through BotGuard Shield (async)."""
        if stream:
            return self._create_stream(model=model, messages=messages, **kwargs)

        base_url = str(self._guard._client.base_url).rstrip("/")
        url = f"{base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._guard._api_key}",
            "Content-Type": "application/json",
        }
        body = {"model": model, "messages": messages, "stream": False, **kwargs}

        async with httpx.AsyncClient(timeout=self._guard._timeout) as http:
            resp = await http.post(str(url), json=body, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        shield = _extract_shield(data)
        return ShieldResult(response=data, shield=shield)

    async def _create_stream(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        **kwargs: Any,
    ):
        base_url = str(self._guard._client.base_url).rstrip("/")
        url = f"{base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self._guard._api_key}",
            "Content-Type": "application/json",
        }
        body = {"model": model, "messages": messages, "stream": True, **kwargs}

        async with httpx.AsyncClient(timeout=self._guard._timeout) as http:
            async with http.stream("POST", str(url), json=body, headers=headers) as resp:
                resp.raise_for_status()
                shield_verdict = ShieldVerdict(action="allowed")
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:]
                    if payload == "[DONE]":
                        break
                    try:
                        chunk_data = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    if "_shield" in chunk_data:
                        shield_verdict = _extract_shield(chunk_data)
                    yield ShieldResult(response=chunk_data, shield=shield_verdict)


class _AsyncChatNamespace:
    def __init__(self, guard: BotGuardAsync):
        self.completions = _AsyncCompletions(guard)
