============
Installation
============

At the command line::

    $ pip install oslo.rootwrap

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv oslo.rootwrap
    $ pip install oslo.rootwrap