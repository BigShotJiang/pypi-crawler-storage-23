---
name: MongoDB Document Database Patterns
version: "1.0"
date: 2026-02-13
tags: [mongodb, nosql, document-db, aggregation, atlas, vector-search, sharding, transactions, replication]
---

# Skill: MongoDB Document Database Patterns

**Status**: Production Ready
**Last Updated**: 2026-02-13
**Scope**: MongoDB 8.x, Atlas, PyMongo, Motor, Mongoose, Native Node.js Driver

---


> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
