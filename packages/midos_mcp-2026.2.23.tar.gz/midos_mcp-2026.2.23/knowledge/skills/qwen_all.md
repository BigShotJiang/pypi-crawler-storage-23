---
id: qwen-all
name: Qwen Code CLI — Universal Skills
version: 1.0.0
status: active
date: 2026-02-19
authors: [Qwen Code, MidOS Team]
stack: [qwen, qwen-coder, cli, mcp, python]
compatibility:
  - qwen-code
  - qwen-coder
  - claude-code
  - cursor
  - windsurf
tags: [qwen, cli, mcp, agent, productivity, multi-model]
tier: universal
---

# Qwen Code CLI — Universal Skills

## WHY


> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
