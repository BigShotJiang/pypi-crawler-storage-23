---
name: Redis Caching & Real-Time Patterns
version: "8.4"
date: 2026-02-13
tags: [redis, caching, real-time, pub-sub, streams, rate-limiting, distributed-locking, sessions, vector-search]
status: stable
truth_validated: true
---

# Skill: Redis Caching & Real-Time Patterns

> **Stack**: Redis 8.4+ (GA November 2025)
> **Status**: Production-ready with AI/vector capabilities

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
