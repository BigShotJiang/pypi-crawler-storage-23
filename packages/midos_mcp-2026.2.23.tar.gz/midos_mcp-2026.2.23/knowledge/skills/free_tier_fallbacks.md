---
name: free_tier_fallbacks
version: 1.0.0
description: Tool fallbacks for free tier users - what to use when PRO tools unavailable
model: any-free-tier
created: 2026-02-18
tags: [free-tier, fallbacks, tools, opencode, efficiency]
---

# Free Tier Tool Fallbacks

> Don't fail silently. Know your alternatives.

## The Problem

MidOS has tiered tool access:

| Tier | Tools |
|------|-------|

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
