---
name: "mercadopago-integration"
version: "1.0.0"
stack: "payments"
tags: ["mercadopago", "payments", "webhooks", "sdk", "uruguay", "validated", "2026"]
confidence: 0.90
created: "2026-02-11"
sources:
  - url: "https://www.mercadopago.com.uy/developers/"
    type: "official"
    confidence: 1.0
  - url: "https://github.com/mercadopago/sdk-python"
    type: "official"
    confidence: 1.0

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
