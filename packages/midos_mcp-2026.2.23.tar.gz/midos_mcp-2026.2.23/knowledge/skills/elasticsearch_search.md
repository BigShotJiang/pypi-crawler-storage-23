---
name: Elasticsearch Search & Analytics
version: "1.0"
date: 2026-02-13
tags: [elasticsearch, search, full-text, vector-search, analytics, elk, semantic-search, observability, index-management]
status: stable
truth_validated: true
---

# Skill: Elasticsearch Search & Analytics

> **Stack**: Elasticsearch 8.x–9.x (GA February 2026)

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
