---
title: Gemini Model Capabilities Reference
description: Flash Lite vs Flash vs Pro — capabilities, limits, and best use cases for MidOS gremlin orchestration
tags:
  - gemini
  - models
  - orchestration
  - gremlins
compatibility:
  - gemini-cli
  - midos
last_updated: 2026-02-16
---

# Gemini Model Capabilities (2.5 Family)

## Model Comparison


> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
