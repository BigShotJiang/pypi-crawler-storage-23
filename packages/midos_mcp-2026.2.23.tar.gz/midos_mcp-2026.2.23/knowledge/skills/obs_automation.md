---
name: "obs-automation"
version: "1.0.0"
stack: "streaming"
tags: ["obs-studio", "obs-websocket", "automation", "scripting", "validated", "2026"]
confidence: 0.92
created: "2026-02-11"
sources:
  - url: "https://github.com/obsproject/obs-websocket/releases"
    type: "official"
    confidence: 1.0
  - url: "https://docs.obsproject.com/scripting"
    type: "official"
    confidence: 1.0

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
