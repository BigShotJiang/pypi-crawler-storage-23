# Google ADK + A2A Protocol: Multi-Agent IDP Generation

> **Knowledge Type**: Technical Implementation + Architecture Pattern
> **Created**: 2026-02-08
> **Source**: Video YT + Transcript
> **Video**: https://www.youtube.com/watch?v=wB0ZMerDxN4
> **Transcript**: `knowledge/inbox/video_ingest_wB0ZMerDxN4_20260208_122428.json`

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
