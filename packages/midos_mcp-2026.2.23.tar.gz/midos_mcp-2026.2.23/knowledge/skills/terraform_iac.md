---
name: Terraform Infrastructure as Code
version: "1.0"
date: 2026-02-13
tags: [terraform, iac, infrastructure, devops, cloud, opentofu, hcl, state-management, modules, providers]
research_date: 2026-02-13
sources: [HashiCorp Developer, DevOpsie, Spacelift, Firefly Academy, Infracost, GitHub]
---

# Skill: Terraform Infrastructure as Code

## Quick Reference: Essential Commands


> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
