# SKILL: Jina AI Perception (2026)

**Origin**: Research Task #493
**Status**: Proposal Draft

## 1. Capabilities Overview
Jina AI provides the "Sensory" layer for the Hive.

### A. Jina Reader (`r.jina.ai`)
- **Use Case**: Converting any web source (fitness papers, tech docs) into clean Markdown.
- **Implementation**: Prefix any URL with `https://r.jina.ai/`.


> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
