---
name: tool_selection_decision_tree
version: 1.0.0
description: Unified decision tree for selecting the right MidOS tool - works for all tiers
model: any
created: 2026-02-18
tags: [tools, decision-tree, efficiency, selection]
---

# Tool Selection Decision Tree

> Pick the right tool the first time. Save tokens.

## Master Decision Tree

```
USER REQUEST
     │
     ▼

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
