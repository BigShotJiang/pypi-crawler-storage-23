---
name: "avr-bare-metal-embedded"
version: "1.0.0"
stack: "avr"
tags: ["avr", "atmega328p", "bare-metal", "embedded", "register-level", "timer", "adc", "pwm", "fsm", "i2c", "lcd", "motor-control", "2026"]
confidence: 0.90
last_updated: "2026-02-11"
sources:
  - url: "https://www.microchip.com/en-us/product/ATmega328P"
    type: "official"
    confidence: 1.0

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
