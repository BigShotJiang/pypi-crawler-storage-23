# MidOS Tech Quick Reference

> **Para L2/L3**: Acceso rápido a standards técnicos cristalizados.
> **MidOS (L1)** = Biblioteca Científica de la Hive
> **Raphael (L0)** = Orchestrator (inactive, future)
> **Última actualización**: 2026-02-05

---

## 🗄️ Supabase

| Tema                  | Knowledge Item                                                                            |

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
