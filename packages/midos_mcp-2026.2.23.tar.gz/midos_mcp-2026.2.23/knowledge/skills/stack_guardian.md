---
name: "stack-guardian"
version: "1.0.0"
stack: "universal"
tags: ["guardrails", "security", "agents", "drift-detection", "validated", "2026"]
confidence: 0.92
created: "2026-02-10"
sources:
  - url: "https://github.com/wangbooth/Claude-Code-Guardrails"
    type: "community"
    confidence: 0.85
  - url: "https://github.com/thkt/claude-guardrails"
    type: "community"
    confidence: 0.85

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
