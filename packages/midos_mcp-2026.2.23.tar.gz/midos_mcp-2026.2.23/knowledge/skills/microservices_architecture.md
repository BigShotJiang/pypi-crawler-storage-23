---
name: Microservices Architecture Patterns
version: "1.0"
date: 2026-02-13
tags: [microservices, architecture, distributed-systems, patterns, resilience, DDD, CQRS, event-sourcing, api-gateway, service-mesh]
---

# Skill: Microservices Architecture Patterns

## Quick Reference: When to Use Microservices

| Scenario | Recommendation | Notes |
|----------|---|---|

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
