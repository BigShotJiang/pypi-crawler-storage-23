---
title: "MCP Prompts & Sampling — Technical Implementation Guide (2026)"
date: 2026-02-18
author: gemini-3-prev
status: RESEARCH_COMPLETE
tags: [mcp, prompts, sampling, implementation, agent-workflows]
type: research_chunk
---


[...content truncated — free tier preview]
