---
tier: premium
title: "MCP Auto-Discovery Endpoint"
category: "infrastructure"
created: "2026-02-15"
tags: ["mcp", "discovery", "well-known", "auto-discovery", "tools"]
backlink: "BL-060"
---

# MCP Auto-Discovery Endpoint (BL-060)

## Overview


[...content truncated — free tier preview]
