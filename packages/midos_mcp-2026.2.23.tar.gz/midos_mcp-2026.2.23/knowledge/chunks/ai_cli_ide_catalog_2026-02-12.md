---
tier: public
title: AI Coding CLIs and IDEs with MCP Support — 2026 Comprehensive Catalog
source: research
date: 2026-02-12
tags: [agent, claude, mcp, research]
confidence: 0.7
---


[...content truncated — free tier preview]
