---
tier: public
title: MCP Registry Aggregator -- Cross-Registry Search Tool
type: chunk
category: developer-tooling
created: 2026-02-15
author: V5 (R030)
confidence: HIGH
tags: [mcp, registry, tools, search, aggregator, developer-tooling]
---


[...content truncated — free tier preview]
