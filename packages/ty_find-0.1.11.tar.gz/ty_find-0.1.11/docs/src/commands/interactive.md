# interactive

Interactive REPL for exploring definitions

## Usage

```
ty-find interactive [FILE]
```

## Arguments

**`<file>`**
: 

## Examples

```bash
# Start interactive REPL
ty-find interactive

# Start with a file context
ty-find interactive main.py
```

## See also

- [Commands Overview](overview.md)
