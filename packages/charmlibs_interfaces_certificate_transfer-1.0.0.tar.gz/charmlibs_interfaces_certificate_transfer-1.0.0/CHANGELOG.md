# 1.0.0 - 6 February 2025

Migration of `certificate_transfer_interface.certificate_transfer` v1.15.
