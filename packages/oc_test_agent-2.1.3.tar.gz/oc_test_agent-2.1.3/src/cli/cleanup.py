import click
from datetime import datetime, timedelta

from ..db.database import Database
from ..core.result_service import ResultService


@click.command()
@click.option('--project', help='项目名')
@click.option('--before', help='清理此日期之前的记录 (YYYY-MM-DD)')
@click.option('--days', default=30, type=int, help='保留最近N天的记录')
def cleanup(project, before, days):
    """清理历史测试数据"""
    
    db = Database.get_instance()
    db.init_schema()
    
    if not before:
        before_date = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    else:
        before_date = before
    
    result_svc = ResultService()
    deleted = result_svc.cleanup(before_date, project)
    
    click.echo(f"Deleted {deleted} test records before {before_date}")
