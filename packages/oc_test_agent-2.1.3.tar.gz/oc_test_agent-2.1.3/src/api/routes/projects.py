"""Project management routes"""

from typing import Optional, List
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()

_projects_store = {}


class ProjectCreateRequest(BaseModel):
    project_id: str
    name: str
    config: Optional[dict] = None


@router.post("/projects")
async def create_project(request: ProjectCreateRequest):
    """Create project"""
    from datetime import datetime
    
    _projects_store[request.project_id] = {
        "project_id": request.project_id,
        "name": request.name,
        "config": request.config or {},
        "created_at": datetime.now().isoformat()
    }
    
    return _projects_store[request.project_id]


@router.get("/projects")
async def list_projects():
    """List projects"""
    return {
        "projects": list(_projects_store.values()),
        "total": len(_projects_store)
    }


@router.get("/projects/{project_id}")
async def get_project(project_id: str):
    """Get project detail"""
    if project_id not in _projects_store:
        raise HTTPException(status_code=404, detail=f"Project {project_id} not found")
    return _projects_store[project_id]


@router.delete("/projects/{project_id}")
async def delete_project(project_id: str):
    """Delete project"""
    if project_id not in _projects_store:
        raise HTTPException(status_code=404, detail=f"Project {project_id} not found")
    del _projects_store[project_id]
    return {"message": "Project deleted", "project_id": project_id}
