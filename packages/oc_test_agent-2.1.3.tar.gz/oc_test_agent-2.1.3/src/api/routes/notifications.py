"""
通知配置API路由
"""

import uuid
from typing import List, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ...core.notification.webhook import WebhookConfig, get_notification_manager

router = APIRouter()


class WebhookCreateRequest(BaseModel):
    """Webhook创建请求"""
    url: str
    events: List[str]
    timeout: int = 30
    secret: Optional[str] = None
    retry: Optional[dict] = None


class WebhookResponse(BaseModel):
    """Webhook响应"""
    id: str
    url: str
    events: List[str]
    timeout: int
    secret: Optional[str] = None
    created_at: str


@router.get("/notifications")
async def get_notifications():
    """获取通知配置"""
    manager = get_notification_manager()
    webhooks = manager.get_webhooks()
    
    return {
        "notifications": [
            {
                "id": wh.id,
                "url": wh.url,
                "events": wh.events,
                "timeout": wh.timeout,
                "secret": wh.secret,
                "created_at": wh.created_at
            }
            for wh in webhooks
        ],
        "total": len(webhooks)
    }


@router.post("/notifications/webhooks")
async def create_webhook(request: WebhookCreateRequest):
    """添加Webhook"""
    manager = get_notification_manager()
    
    webhook = WebhookConfig(
        id=f"webhook-{uuid.uuid4().hex[:8]}",
        url=request.url,
        events=request.events,
        timeout=request.timeout,
        secret=request.secret,
        retry_config=request.retry or {"max_attempts": 3, "interval": 5}
    )
    
    manager.add_webhook(webhook)
    
    return {
        "id": webhook.id,
        "url": webhook.url,
        "events": webhook.events,
        "timeout": webhook.timeout,
        "secret": webhook.secret,
        "created_at": webhook.created_at
    }


@router.delete("/notifications/webhooks/{webhook_id}")
async def delete_webhook(webhook_id: str):
    """删除Webhook"""
    manager = get_notification_manager()
    
    if not manager.remove_webhook(webhook_id):
        raise HTTPException(status_code=404, detail="Webhook not found")
    
    return {"message": "Webhook deleted", "id": webhook_id}
