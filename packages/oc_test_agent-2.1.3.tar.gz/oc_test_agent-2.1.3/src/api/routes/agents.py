"""Agent management routes"""

from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()

_agents_store = {}


class AgentCreateRequest(BaseModel):
    agent_id: str
    name: Optional[str] = None
    metadata: Optional[dict] = None


@router.post("/agents")
async def register_agent(request: AgentCreateRequest):
    """Register agent"""
    from datetime import datetime
    
    _agents_store[request.agent_id] = {
        "agent_id": request.agent_id,
        "name": request.name or request.agent_id,
        "status": "active",
        "created_at": datetime.now().isoformat()
    }
    
    return _agents_store[request.agent_id]


@router.get("/agents")
async def list_agents():
    """List agents"""
    return {
        "agents": list(_agents_store.values()),
        "total": len(_agents_store)
    }


@router.get("/agents/{agent_id}")
async def get_agent(agent_id: str):
    """Get agent status"""
    if agent_id not in _agents_store:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")
    return _agents_store[agent_id]


@router.delete("/agents/{agent_id}")
async def unregister_agent(agent_id: str):
    """Unregister agent"""
    if agent_id not in _agents_store:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")
    del _agents_store[agent_id]
    return {"message": "Agent unregistered", "agent_id": agent_id}
