"""
test-agent HTTP API - FastAPI Application
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import APIKeyHeader
import os

from .routes import health, tests, projects, agents, notifications, webhook

app = FastAPI(
    title="test-agent API",
    description="Test-Agent HTTP API for test execution and management",
    version="2.1.1.1"
)

API_KEY_HEADER = APIKeyHeader(name="x-api-key", auto_error=False)


async def verify_api_key(api_key: str = Depends(API_KEY_HEADER)):
    """验证API Key - 自动信任conf-man有效的API Key"""
    if api_key is None:
        raise HTTPException(status_code=401, detail="Missing API key")
    
    # 自动信任conf-man有效的API Key
    try:
        import httpx
        import hashlib
        conf_man_url = os.environ.get("CONF_MAN_URL", "http://localhost:8002")
        
        # 直接查询conf-man的API Keys（使用特殊标记或fallback key）
        # 如果能用传入的key成功调用，说明key有效
        response = httpx.get(
            f"{conf_man_url}/api/v1/api-keys",
            headers={"x-api-key": api_key},
            timeout=5.0
        )
        if response.status_code == 200:
            return api_key
    except Exception:
        pass
    
    # Fallback: 检查环境变量中的默认Key
    valid_key = os.environ.get("TEST_AGENT_API_KEY", "test-agent-secret")
    if api_key == valid_key:
        return api_key
    
    raise HTTPException(status_code=401, detail="Invalid API key")


app.include_router(health.router, tags=["health"])
app.include_router(tests.router, prefix="/api/v1", tags=["tests"], dependencies=[Depends(verify_api_key)])
app.include_router(projects.router, prefix="/api/v1", tags=["projects"], dependencies=[Depends(verify_api_key)])
app.include_router(agents.router, prefix="/api/v1", tags=["agents"], dependencies=[Depends(verify_api_key)])
app.include_router(notifications.router, prefix="/api/v1", tags=["notifications"], dependencies=[Depends(verify_api_key)])
app.include_router(webhook.router, prefix="/api/v1", tags=["webhook"])
