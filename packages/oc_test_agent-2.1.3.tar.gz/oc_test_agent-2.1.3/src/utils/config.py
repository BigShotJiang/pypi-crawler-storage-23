"""配置解析工具模块。"""

import yaml
from pathlib import Path
from typing import Any, Optional

from .errors import ValidationError, ConfigParseError


class ConfigManager:
    """配置管理器。"""
    
    @staticmethod
    def load_yaml(file_path: Path) -> dict:
        """加载YAML配置文件。
        
        Args:
            file_path: 配置文件路径
            
        Returns:
            配置字典
            
        Raises:
            ConfigParseError: 配置文件解析失败
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f) or {}
        except FileNotFoundError:
            return {}
        except yaml.YAMLError as e:
            raise ConfigParseError(f"YAML解析失败: {e}")
    
    @staticmethod
    def save_yaml(file_path: Path, data: dict) -> None:
        """保存YAML配置文件。
        
        Args:
            file_path: 配置文件路径
            data: 配置数据
        """
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)
    
    @staticmethod
    def validate_project_id(project_id: str) -> bool:
        """验证项目ID格式。
        
        Args:
            project_id: 项目ID
            
        Returns:
            是否有效
            
        Raises:
            ValidationError: 项目ID格式无效
        """
        if not project_id.startswith('test_'):
            raise ValidationError("T001: 项目ID必须以test_开头")
        return True
    
    @staticmethod
    def validate_agent_id(agent_id: str) -> bool:
        """验证Agent ID格式。
        
        Args:
            agent_id: Agent ID
            
        Returns:
            是否有效
            
        Raises:
            ValidationError: Agent ID格式无效
        """
        if not agent_id.startswith('test_'):
            raise ValidationError("T004: Agent ID必须以test_开头")
        return True
