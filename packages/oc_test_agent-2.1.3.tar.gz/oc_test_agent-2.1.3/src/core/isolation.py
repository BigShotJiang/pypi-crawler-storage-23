"""数据隔离模块。"""

import os
import sqlite3
import json
from pathlib import Path
from typing import Optional
from datetime import datetime

from ..utils.errors import DatabaseError

# 环境变量配置
OC_STATE_DIR = os.environ.get('OC_STATE_DIR', 'state')


class DatabaseManager:
    """测试数据库管理器 - 共享数据库 + namespace隔离方案。"""
    
    def __init__(self, base_path: str = None):
        base_path = base_path or OC_STATE_DIR
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        self.db_path = self.base_path / "todos_test.db"
        self._connection: Optional[sqlite3.Connection] = None
    
    def get_connection(self) -> sqlite3.Connection:
        """获取共享数据库连接。
        
        Returns:
            数据库连接
        """
        if self._connection is None:
            self._connection = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self._connection.row_factory = sqlite3.Row
            self.init_schema()
        return self._connection
    
    def init_schema(self) -> None:
        """初始化数据库Schema。"""
        conn = self.get_connection()
        
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS test_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT UNIQUE NOT NULL,
                project_id TEXT NOT NULL,
                agent_id TEXT,
                command TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                started_at TEXT,
                completed_at TEXT,
                result TEXT,
                output TEXT,
                error TEXT,
                namespace TEXT
            );
            
            CREATE TABLE IF NOT EXISTS test_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                result_id TEXT UNIQUE NOT NULL,
                task_id TEXT NOT NULL,
                test_suite TEXT,
                test_case TEXT,
                status TEXT,
                message TEXT,
                duration REAL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES test_tasks(task_id)
            );
            
            CREATE TABLE IF NOT EXISTS agent_heartbeats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                project_id TEXT,
                status TEXT,
                cpu_usage REAL,
                memory_usage REAL,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE INDEX IF NOT EXISTS idx_tasks_project ON test_tasks(project_id);
            CREATE INDEX IF NOT EXISTS idx_tasks_agent ON test_tasks(agent_id);
            CREATE INDEX IF NOT EXISTS idx_tasks_status ON test_tasks(status);
            CREATE INDEX IF NOT EXISTS idx_results_task ON test_results(task_id);
            CREATE INDEX IF NOT EXISTS idx_heartbeats_agent ON agent_heartbeats(agent_id);
        """)
        conn.commit()
    
    def create_task(self, namespace: str, task_id: str, project_id: str,
                    agent_id: str, command: str) -> None:
        """创建测试任务。
        
        Args:
            namespace: 命名空间
            task_id: 任务ID
            project_id: 项目ID
            agent_id: Agent ID
            command: 测试命令
        """
        conn = self.get_connection()
        conn.execute("""
            INSERT INTO test_tasks (task_id, project_id, agent_id, command, status, namespace)
            VALUES (?, ?, ?, ?, 'pending', ?)
        """, (task_id, project_id, agent_id, command, namespace))
        conn.commit()
    
    def update_task_status(self, namespace: str, task_id: str, 
                           status: str, result: Optional[str] = None,
                           output: Optional[str] = None, 
                           error: Optional[str] = None) -> None:
        """更新任务状态。
        
        Args:
            namespace: 命名空间
            task_id: 任务ID
            status: 新状态
            result: 测试结果
            output: 输出
            error: 错误信息
        """
        conn = self.get_connection()
        now = datetime.utcnow().isoformat()
        
        existing = self.get_task_field(namespace, task_id, "started_at")
        
        if status == "running" and not existing:
            conn.execute("""
                UPDATE test_tasks 
                SET status = ?, started_at = ?
                WHERE task_id = ? AND namespace = ?
            """, (status, now, task_id, namespace))
        elif status in ("completed", "failed", "error"):
            conn.execute("""
                UPDATE test_tasks 
                SET status = ?, completed_at = ?, result = ?, output = ?, error = ?
                WHERE task_id = ? AND namespace = ?
            """, (status, now, result, output, error, task_id, namespace))
        else:
            conn.execute("UPDATE test_tasks SET status = ? WHERE task_id = ? AND namespace = ?", 
                        (status, task_id, namespace))
        
        conn.commit()
    
    def get_task_field(self, namespace: str, task_id: str, field: str) -> Optional[str]:
        """获取任务字段。
        
        Args:
            namespace: 命名空间
            task_id: 任务ID
            field: 字段名
            
        Returns:
            字段值
        """
        conn = self.get_connection()
        cursor = conn.execute(f"SELECT {field} FROM test_tasks WHERE task_id = ? AND namespace = ?", 
                              (task_id, namespace))
        row = cursor.fetchone()
        return row[field] if row else None
    
    def get_tasks_by_project(self, namespace: str, project_id: str) -> list:
        """获取项目的所有任务。
        
        Args:
            namespace: 命名空间
            project_id: 项目ID
            
        Returns:
            任务列表
        """
        conn = self.get_connection()
        cursor = conn.execute("""
            SELECT * FROM test_tasks WHERE project_id = ? AND namespace = ? ORDER BY created_at DESC
        """, (project_id, namespace))
        return [dict(row) for row in cursor.fetchall()]
    
    def get_tasks_by_namespace(self, namespace: str) -> list:
        """获取命名空间的所有任务。
        
        Args:
            namespace: 命名空间
            
        Returns:
            任务列表
        """
        conn = self.get_connection()
        cursor = conn.execute("""
            SELECT * FROM test_tasks WHERE namespace = ? ORDER BY created_at DESC
        """, (namespace,))
        return [dict(row) for row in cursor.fetchall()]
    
    def record_heartbeat(self, namespace: str, agent_id: str, project_id: str,
                         status: str, cpu_usage: float = 0.0, 
                         memory_usage: float = 0.0) -> None:
        """记录Agent心跳。
        
        Args:
            namespace: 命名空间
            agent_id: Agent ID
            project_id: 项目ID
            status: Agent状态
            cpu_usage: CPU使用率
            memory_usage: 内存使用率
        """
        conn = self.get_connection()
        conn.execute("""
            INSERT INTO agent_heartbeats 
            (agent_id, project_id, status, cpu_usage, memory_usage, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (agent_id, project_id, status, cpu_usage, memory_usage, 
              datetime.utcnow().isoformat()))
        conn.commit()
    
    def close_all(self) -> None:
        """关闭连接。"""
        if self._connection is not None:
            self._connection.close()
            self._connection = None
    
    def cleanup_namespace(self, namespace: str) -> bool:
        """清理命名空间数据。
        
        Args:
            namespace: 命名空间ID
            
        Returns:
            是否成功
        """
        conn = self.get_connection()
        cursor = conn.execute("SELECT COUNT(*) FROM test_tasks WHERE namespace = ?", (namespace,))
        count = cursor.fetchone()[0]
        
        if count > 0:
            conn.execute("DELETE FROM test_tasks WHERE namespace = ?", (namespace,))
            conn.execute("DELETE FROM agent_heartbeats WHERE project_id IN (SELECT DISTINCT project_id FROM test_tasks WHERE namespace = ?)", (namespace,))
            conn.commit()
            return True
        return False
    
    def cleanup_project(self, project_id: str) -> bool:
        """清理项目数据。
        
        Args:
            project_id: 项目ID
            
        Returns:
            是否成功
        """
        conn = self.get_connection()
        cursor = conn.execute("SELECT COUNT(*) FROM test_tasks WHERE project_id = ?", (project_id,))
        count = cursor.fetchone()[0]
        
        if count > 0:
            conn.execute("DELETE FROM test_tasks WHERE project_id = ?", (project_id,))
            conn.execute("DELETE FROM agent_heartbeats WHERE project_id = ?", (project_id,))
            conn.commit()
            return True
        return False
