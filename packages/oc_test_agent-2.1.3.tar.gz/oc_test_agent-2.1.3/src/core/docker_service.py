import docker
from docker.errors import NotFound, APIError
import logging
from pathlib import Path
from typing import Optional, Dict
import time

logger = logging.getLogger(__name__)


class DockerService:
    """Docker 服务封装"""
    
    def __init__(self):
        self.client: Optional[docker.DockerClient] = None
        
    def _get_client(self) -> docker.DockerClient:
        """获取 Docker 客户端"""
        if self.client is None:
            self.client = docker.from_env()
        return self.client
    
    def is_available(self) -> bool:
        """检查 Docker 是否可用"""
        try:
            self._get_client().ping()
            return True
        except Exception as e:
            logger.error(f"Docker not available: {e}")
            return False
    
    def build_image(
        self,
        project_path: str,
        dockerfile: str = "Dockerfile.test",
        tag: str = "latest",
        nocache: bool = False
    ) -> bool:
        """构建 Docker 镜像"""
        try:
            client = self._get_client()
            project_path_obj = Path(project_path)
            
            logger.info(f"Building image: {tag} from {project_path}")
            
            image, build_log = client.images.build(
                path=str(project_path_obj),
                dockerfile=dockerfile,
                tag=tag,
                nocache=nocache,
                rm=True
            )
            
            for line in build_log:
                if 'stream' in line:
                    logger.debug(line['stream'].strip())
            
            logger.info(f"Image built successfully: {image.short_id}")
            return True
            
        except APIError as e:
            logger.error(f"Failed to build image: {e}")
            return False
    
    def image_exists(self, tag: str) -> bool:
        """检查镜像是否存在"""
        try:
            self._get_client().images.get(tag)
            return True
        except NotFound:
            return False
    
    def run_container(
        self,
        image: str,
        env: Optional[Dict[str, str]] = None,
        volumes: Optional[Dict[str, str]] = None,
        network: str = "none",
        mem_limit: str = "1g",
        cpu_quota: int = 50000,
        detach: bool = True,
        remove: bool = False
    ) -> Optional[str]:
        """运行容器"""
        try:
            client = self._get_client()
            
            container = client.containers.run(
                image,
                detach=detach,
                environment=env or {},
                volumes=volumes or {},
                network=network,
                mem_limit=mem_limit,
                cpu_quota=cpu_quota,
                remove=remove
            )
            
            logger.info(f"Container started: {container.short_id}")
            return container.id
            
        except APIError as e:
            logger.error(f"Failed to run container: {e}")
            return None
    
    def wait_container(self, container_id: str, timeout: int = 300) -> Dict:
        """等待容器执行完成"""
        import logging
        import sys
        logger = logging.getLogger(__name__)
        
        # 开始调试
        with open('/tmp/docker_service_debug.txt', 'a') as f:
            f.write(f"wait_container called: {container_id}\n")
        
        try:
            client = self._get_client()
            container = client.containers.get(container_id)
            
            result = container.wait(timeout=timeout)
            
            logs = container.logs(stdout=True, stderr=True).decode('utf-8')
            
            # 写入文件调试
            with open('/tmp/docker_service_debug.txt', 'a') as f:
                f.write(f"wait_container returning: status={result.get('StatusCode', -1)}, logs_len={len(logs)}\n")
            
            return_value = {
                "status_code": result.get("StatusCode", -1),
                "logs": logs
            }
            
            return return_value
            
        except Exception as e:
            logger.error(f"Failed to wait container: {e}")
            return {"status_code": -1, "logs": "", "error": str(e)}
    
    def stop_container(self, container_id: str) -> bool:
        """停止容器"""
        try:
            client = self._get_client()
            container = client.containers.get(container_id)
            container.stop(timeout=10)
            logger.info(f"Container stopped: {container_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to stop container: {e}")
            return False
    
    def remove_container(self, container_id: str) -> bool:
        """删除容器"""
        try:
            client = self._get_client()
            container = client.containers.get(container_id)
            container.remove(force=True)
            logger.info(f"Container removed: {container_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to remove container: {e}")
            return False
    
    def get_container_logs(self, container_id: str) -> str:
        """获取容器日志"""
        try:
            client = self._get_client()
            container = client.containers.get(container_id)
            return container.logs(stdout=True, stderr=True).decode('utf-8')
        except Exception as e:
            logger.error(f"Failed to get container logs: {e}")
            return ""
