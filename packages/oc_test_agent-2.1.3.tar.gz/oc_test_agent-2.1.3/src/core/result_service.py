from typing import List, Optional
import logging

from ..db.database import Database
from ..db.repositories.result_repo import ResultRepository
from ..models.test_result import TestResult, TestStatus

logger = logging.getLogger(__name__)


class ResultService:
    """测试结果服务"""
    
    def __init__(self):
        self.db = Database.get_instance()
        self.repo = ResultRepository(self.db)
    
    def save(self, result: TestResult) -> str:
        """保存测试结果"""
        self.repo.insert(result)
        return result.id
    
    def get(self, test_id: str) -> Optional[TestResult]:
        """获取测试结果"""
        return self.repo.find_by_id(test_id)
    
    def query(
        self,
        project: Optional[str] = None,
        version: Optional[str] = None,
        status: Optional[TestStatus] = None,
        limit: int = 10
    ) -> List[TestResult]:
        """查询测试结果"""
        return self.repo.find_all(project, version, status, limit)
    
    def delete(self, test_id: str) -> bool:
        """删除测试结果"""
        return self.repo.delete(test_id)
    
    def cleanup(self, before_date: str, project: Optional[str] = None) -> int:
        """清理测试结果"""
        return self.repo.delete_before(before_date, project)
