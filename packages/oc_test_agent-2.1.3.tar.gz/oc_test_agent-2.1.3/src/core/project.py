"""项目管理模块。"""

import os
import json
from pathlib import Path
from typing import Optional
from datetime import datetime

from ..utils.errors import (
    ValidationError, 
    ProjectExistsError, 
    ProjectNotFoundError
)
from ..utils.config import ConfigManager

# 环境变量配置
OC_STATE_DIR = os.environ.get('OC_STATE_DIR', 'state')
OC_PROJECTS_DIR = os.environ.get('OC_PROJECTS_DIR', os.path.join(OC_STATE_DIR, 'projects'))


class ProjectManager:
    """测试项目管理器。"""
    
    def __init__(self, base_path: str = None):
        base_path = base_path or OC_PROJECTS_DIR
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        self.config_manager = ConfigManager()
    
    def create(self, project_id: str, name: str, config: Optional[dict] = None) -> tuple[bool, str]:
        """创建测试项目。
        
        Args:
            project_id: 项目ID (带test_前缀)
            name: 项目名称
            config: 初始配置
            
        Returns:
            (成功标志, 消息)
        """
        self.config_manager.validate_project_id(project_id)
        
        project_dir = self.base_path / project_id
        if project_dir.exists():
            raise ProjectExistsError("T003: 项目已存在")
        
        project_dir.mkdir(parents=True, exist_ok=True)
        
        project_config = {
            "project_id": project_id,
            "name": name,
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat(),
            "config": config or {
                "max_agents": 5,
                "isolation_enabled": True,
                "cleanup_on_exit": False
            },
            "agents": []
        }
        
        config_file = project_dir / "config.yaml"
        self.config_manager.save_yaml(config_file, project_config)
        
        agents_file = project_dir / "agents.json"
        with open(agents_file, 'w', encoding='utf-8') as f:
            json.dump({"project_id": project_id, "agents": []}, f)
        
        return True, f"项目 {project_id} 创建成功"
    
    def get(self, project_id: str) -> dict:
        """获取项目配置。
        
        Args:
            project_id: 项目ID
            
        Returns:
            项目配置字典
            
        Raises:
            ProjectNotFoundError: 项目不存在
        """
        project_dir = self.base_path / project_id
        if not project_dir.exists():
            raise ProjectNotFoundError("T002: 项目不存在")
        
        config_file = project_dir / "config.yaml"
        return self.config_manager.load_yaml(config_file)
    
    def update(self, project_id: str, config: dict) -> tuple[bool, str]:
        """更新项目配置。
        
        Args:
            project_id: 项目ID
            config: 新配置
            
        Returns:
            (成功标志, 消息)
            
        Raises:
            ProjectNotFoundError: 项目不存在
        """
        project_config = self.get(project_id)
        project_config["config"].update(config)
        project_config["updated_at"] = datetime.utcnow().isoformat()
        
        config_file = self.base_path / project_id / "config.yaml"
        self.config_manager.save_yaml(config_file, project_config)
        
        return True, f"项目 {project_id} 更新成功"
    
    def delete(self, project_id: str) -> tuple[bool, str]:
        """删除项目。
        
        Args:
            project_id: 项目ID
            
        Returns:
            (成功标志, 消息)
            
        Raises:
            ProjectNotFoundError: 项目不存在
        """
        project_dir = self.base_path / project_id
        if not project_dir.exists():
            raise ProjectNotFoundError("T002: 项目不存在")
        
        import shutil
        shutil.rmtree(project_dir)
        
        return True, f"项目 {project_id} 删除成功"
    
    def list_all(self) -> list[dict]:
        """列出所有项目。
        
        Returns:
            项目配置列表
        """
        projects = []
        for project_dir in self.base_path.iterdir():
            if project_dir.is_dir():
                try:
                    config = self.get(project_dir.name)
                    projects.append(config)
                except Exception:
                    continue
        return projects
    
    def add_agent(self, project_id: str, agent_id: str) -> tuple[bool, str]:
        """添加Agent到项目。
        
        Args:
            project_id: 项目ID
            agent_id: Agent ID
            
        Returns:
            (成功标志, 消息)
            
        Raises:
            ProjectNotFoundError: 项目不存在
        """
        project_dir = self.base_path / project_id
        if not project_dir.exists():
            raise ProjectNotFoundError("T002: 项目不存在")
        
        agents_file = project_dir / "agents.json"
        with open(agents_file, 'r', encoding='utf-8') as f:
            agents_data = json.load(f)
        
        for agent in agents_data.get("agents", []):
            if agent["agent_id"] == agent_id:
                return True, f"Agent {agent_id} 已在项目中"
        
        agents_data.setdefault("agents", []).append({
            "agent_id": agent_id,
            "status": "idle",
            "assigned_at": datetime.utcnow().isoformat()
        })
        
        with open(agents_file, 'w', encoding='utf-8') as f:
            json.dump(agents_data, f, ensure_ascii=False, indent=2)
        
        return True, f"Agent {agent_id} 添加到项目 {project_id}"
    
    def remove_agent(self, project_id: str, agent_id: str) -> tuple[bool, str]:
        """从项目移除Agent。
        
        Args:
            project_id: 项目ID
            agent_id: Agent ID
            
        Returns:
            (成功标志, 消息)
        """
        project_dir = self.base_path / project_id
        if not project_dir.exists():
            raise ProjectNotFoundError("T002: 项目不存在")
        
        agents_file = project_dir / "agents.json"
        with open(agents_file, 'r', encoding='utf-8') as f:
            agents_data = json.load(f)
        
        agents = agents_data.get("agents", [])
        agents_data["agents"] = [a for a in agents if a["agent_id"] != agent_id]
        
        with open(agents_file, 'w', encoding='utf-8') as f:
            json.dump(agents_data, f, ensure_ascii=False, indent=2)
        
        return True, f"Agent {agent_id} 已从项目 {project_id} 移除"
