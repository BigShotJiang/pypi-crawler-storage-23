from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Optional, Any
from enum import Enum


class TestReportStatus(Enum):
    PASSED = "passed"
    FAILED = "failed"
    PARTIAL = "partial"


@dataclass
class TestReportResult:
    passed: int = 0
    failed: int = 0
    skipped: int = 0
    errors: int = 0
    
    def to_dict(self) -> dict:
        return {
            "passed": self.passed,
            "failed": self.failed,
            "skipped": self.skipped,
            "errors": self.errors
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'TestReportResult':
        return cls(
            passed=data.get("passed", 0),
            failed=data.get("failed", 0),
            skipped=data.get("skipped", 0),
            errors=data.get("errors", 0)
        )


@dataclass
class TestReport:
    version: str
    status: TestReportStatus
    timestamp: str
    results: Dict[str, TestReportResult] = field(default_factory=dict)
    coverage: Optional[int] = None
    project: Optional[str] = None
    test_type: str = "all"
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "status": self.status.value,
            "timestamp": self.timestamp,
            "results": {k: v.to_dict() for k, v in self.results.items()},
            "coverage": self.coverage,
            "project": self.project,
            "test_type": self.test_type,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'TestReport':
        results = {}
        if "results" in data:
            for k, v in data["results"].items():
                results[k] = TestReportResult.from_dict(v)
        
        return cls(
            version=data.get("version", "1.0.0"),
            status=TestReportStatus(data.get("status", "passed")),
            timestamp=data.get("timestamp", datetime.now().isoformat()),
            results=results,
            coverage=data.get("coverage"),
            project=data.get("project"),
            test_type=data.get("test_type", "all"),
            metadata=data.get("metadata", {})
        )
    
    def to_yaml_dict(self) -> dict:
        """Convert to YAML-compatible dict (replace enum with value)"""
        d = self.to_dict()
        d["status"] = self.status.value
        return d
    
    @classmethod
    def from_test_result(cls, test_result, project: str) -> 'TestReport':
        """Create TestReport from TestResult model"""
        timestamp = test_result.finished_at.isoformat() if test_result.finished_at else datetime.now().isoformat()
        
        results = {
            test_result.test_type: TestReportResult(
                passed=test_result.passed,
                failed=test_result.failed,
                errors=test_result.errors,
                skipped=test_result.total - test_result.passed - test_result.failed - test_result.errors
            )
        }
        
        status = TestReportStatus.PASSED
        if test_result.failed > 0 or test_result.errors > 0:
            status = TestReportStatus.FAILED
        
        return cls(
            version=test_result.version,
            status=status,
            timestamp=timestamp,
            results=results,
            project=project,
            test_type=test_result.test_type,
            metadata=test_result.metadata
        )
