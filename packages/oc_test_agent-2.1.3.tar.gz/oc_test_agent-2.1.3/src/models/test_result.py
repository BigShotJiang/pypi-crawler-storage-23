from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict, Any
from enum import Enum


class TestStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    PASSED = "passed"
    FAILED = "failed"
    ERROR = "error"
    CANCELLED = "cancelled"


@dataclass
class TestResult:
    id: str
    project: str
    version: str
    status: TestStatus
    test_type: str = "all"
    duration: Optional[float] = None
    passed: int = 0
    failed: int = 0
    errors: int = 0
    total: int = 0
    report_path: Optional[str] = None
    logs_path: Optional[str] = None
    container_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    finished_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "project": self.project,
            "version": self.version,
            "test_type": self.test_type,
            "status": self.status.value,
            "duration": self.duration,
            "passed": self.passed,
            "failed": self.failed,
            "errors": self.errors,
            "total": self.total,
            "report_path": self.report_path,
            "logs_path": self.logs_path,
            "container_id": self.container_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
            "metadata": self.metadata
        }

    @classmethod
    def from_row(cls, row: dict) -> 'TestResult':
        metadata = {}
        if row.get("metadata"):
            try:
                metadata = eval(row["metadata"]) if isinstance(row["metadata"], str) else row["metadata"]
            except Exception:
                pass
        
        created_at = None
        if row.get("created_at"):
            try:
                created_at = datetime.fromisoformat(row["created_at"])
            except Exception:
                pass
        
        finished_at = None
        if row.get("finished_at"):
            try:
                finished_at = datetime.fromisoformat(row["finished_at"])
            except Exception:
                pass
        
        return cls(
            id=row["id"],
            project=row["project"],
            version=row["version"],
            test_type=row.get("test_type", "all"),
            status=TestStatus(row["status"]),
            duration=row.get("duration"),
            passed=row.get("passed", 0),
            failed=row.get("failed", 0),
            errors=row.get("errors", 0),
            total=row.get("total", 0),
            report_path=row.get("report_path"),
            logs_path=row.get("logs_path"),
            container_id=row.get("container_id"),
            created_at=created_at,
            finished_at=finished_at,
            metadata=metadata
        )


@dataclass
class Dependency:
    test_id: str
    dependency_project: str
    dependency_path: str
    dependency_version: Optional[str] = None
