# Test-Agent v1.2

import sys
import os
from pathlib import Path

def _setup_local_path():
    """自动检测并添加项目本地路径到PYTHONPATH"""
    if 'src' in sys.modules:
        return
    
    current = Path(__file__).resolve().parent
    for parent in [current] + list(current.parents):
        if (parent / 'pyproject.toml').exists() or (parent / 'setup.py').exists():
            src_path = str(parent / 'src')
            if src_path not in sys.path:
                sys.path.insert(0, src_path)
                sys.path.insert(0, str(parent))
            break

_setup_local_path()
