"""Test-Agent Agent和执行引擎补充测试。"""

import pytest
import tempfile
import shutil
import json
import subprocess
from pathlib import Path
from unittest.mock import patch, MagicMock
import time

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.core.agent import AgentManager
from src.core.execution import ExecutionEngine
from src.core.isolation import DatabaseManager
from src.utils.errors import AgentNotFoundError


class TestAgentManagerExtended:
    """AgentManager 扩展测试类。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    @pytest.fixture
    def am(self, temp_dir):
        """创建AgentManager实例。"""
        return AgentManager(base_path=f"{temp_dir}/agents", max_workers=3)
    
    def test_unregister_running_agent(self, temp_dir):
        """TC-AME-001: 注销正在运行的Agent。"""
        am = AgentManager(base_path=f"{temp_dir}/agents", max_workers=3)
        am.register("test_agent_001", {})
        
        mock_process = MagicMock()
        am._running_agents["test_agent_001"] = mock_process
        
        success, message = am.unregister("test_agent_001")
        
        assert success is True
        assert "test_agent_001" not in am._running_agents
    
    def test_assign_and_release_process(self, temp_dir):
        """TC-AME-002: 分配和释放进程。"""
        am = AgentManager(base_path=f"{temp_dir}/agents", max_workers=3)
        am.register("test_agent_001", {})
        
        mock_process = MagicMock()
        am.assign_process("test_agent_001", mock_process)
        
        assert "test_agent_001" in am._running_agents
        assert am.get_status("test_agent_001") == "running"
        
        am.release_process("test_agent_001")
        
        assert "test_agent_001" not in am._running_agents
        assert am.get_status("test_agent_001") == "idle"
    
    def test_release_nonexistent_process(self, temp_dir):
        """TC-AME-003: 释放不存在的进程。"""
        am = AgentManager(base_path=f"{temp_dir}/agents", max_workers=3)
        am.register("test_agent_001", {})
        
        am.release_process("test_agent_001")
        
        assert am.get_status("test_agent_001") == "idle"
    
    def test_init_pool(self, temp_dir):
        """TC-AME-004: 初始化进程池。"""
        am = AgentManager(base_path=f"{temp_dir}/agents", max_workers=3)
        
        pool = am.init_pool()
        
        assert pool is not None
        assert am._agent_pool is not None
    
    def test_init_pool_twice(self, temp_dir):
        """TC-AME-005: 重复初始化进程池。"""
        am = AgentManager(base_path=f"{temp_dir}/agents", max_workers=3)
        
        pool1 = am.init_pool()
        pool2 = am.init_pool()
        
        assert pool1 is pool2
    
    def test_cleanup_pool(self, temp_dir):
        """TC-AME-006: 清理进程池。"""
        am = AgentManager(base_path=f"{temp_dir}/agents", max_workers=3)
        am.init_pool()
        
        am.cleanup()
        
        assert am._agent_pool is None
        assert len(am._running_agents) == 0
    
    def test_get_agent_info(self, temp_dir):
        """TC-AME-007: 获取Agent信息。"""
        am = AgentManager(base_path=f"{temp_dir}/agents", max_workers=3)
        am.register("test_agent_001", {"name": "Test Agent", "version": "1.0"})
        
        agent = am.get("test_agent_001")
        
        assert agent["agent_id"] == "test_agent_001"
        assert agent["metadata"]["name"] == "Test Agent"
    
    def test_update_status_with_project(self, temp_dir):
        """TC-AME-008: 更新Agent状态和项目。"""
        am = AgentManager(base_path=f"{temp_dir}/agents", max_workers=3)
        am.register("test_agent_001", {})
        
        am.update_status("test_agent_001", "running", "test_project")
        
        agent = am.get("test_agent_001")
        assert agent["status"] == "running"
        assert agent["current_project"] == "test_project"


class TestExecutionEngineEdgeCases:
    """ExecutionEngine 边界测试类。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    def test_execute_with_empty_command(self, temp_dir):
        """TC-EEB-001: 执行空命令。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        
        try:
            result = engine._execute_agent_test(
                "test_agent_empty",
                "",
                "test_project"
            )
            assert result is not None
        finally:
            engine.cleanup()
    
    def test_execute_with_long_output(self, temp_dir):
        """TC-EEB-002: 执行命令输出过长。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        
        try:
            long_output = "x" * 2000
            with patch('subprocess.run') as mock_run:
                mock_run.return_value = MagicMock(
                    returncode=0,
                    stdout=long_output,
                    stderr=""
                )
                
                result = engine._execute_agent_test(
                    "test_agent",
                    "echo test",
                    "test_project"
                )
                
                assert len(result["output"]) <= 1000
        finally:
            engine.cleanup()
    
    def test_execute_with_long_error(self, temp_dir):
        """TC-EEB-003: 执行命令错误输出过长。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        
        try:
            long_error = "y" * 1000
            with patch('subprocess.run') as mock_run:
                mock_run.return_value = MagicMock(
                    returncode=1,
                    stdout="",
                    stderr=long_error
                )
                
                result = engine._execute_agent_test(
                    "test_agent",
                    "echo test",
                    "test_project"
                )
                
                assert len(result.get("error", "")) <= 500
        finally:
            engine.cleanup()
    
    def test_execute_with_result_json(self, temp_dir):
        """TC-EEB-004: 执行并保存结果JSON。"""
        engine = ExecutionEngine("test_project", max_workers=5)
        result_file = None
        
        try:
            result = engine._execute_agent_test(
                "test_agent_result",
                "echo success",
                "test_project"
            )
            
            result_file = Path(f"state/test_logs/test_project/test_agent_result_result.json")
            if result_file.exists():
                with open(result_file, 'r') as f:
                    saved = json.load(f)
                    assert "status" in saved
        finally:
            engine.cleanup()
            if result_file and result_file.exists():
                result_file.unlink()
            import shutil
            if Path("state/test_logs/test_project").exists():
                shutil.rmtree("state/test_logs/test_project", ignore_errors=True)


class TestDatabaseManagerEdgeCases:
    """DatabaseManager 边界测试类 - 共享数据库方案。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    @pytest.fixture
    def dm(self, temp_dir):
        """创建DatabaseManager实例。"""
        return DatabaseManager(base_path=temp_dir)
    
    def test_get_task_field_not_found(self, dm):
        """TC-DBE-007: 获取不存在的任务字段。"""
        result = dm.get_task_field("test_ns", "nonexistent_task", "status")
        assert result is None
    
    def test_close_all_connections(self, dm):
        """TC-DBE-008: 关闭所有连接。"""
        dm.get_connection()
        dm.close_all()
        assert dm._connection is None
    
    def test_shared_db_namespace_data_integrity(self, dm):
        """TC-DBE-009: 共享数据库命名空间数据完整性。"""
        dm.create_task("ns_a", "task_a1", "proj_a", "agent_a", "cmd_a")
        dm.create_task("ns_a", "task_a2", "proj_a", "agent_a", "cmd_a2")
        dm.create_task("ns_b", "task_b1", "proj_b", "agent_b", "cmd_b")
        
        ns_a_tasks = dm.get_tasks_by_namespace("ns_a")
        ns_b_tasks = dm.get_tasks_by_namespace("ns_b")
        
        assert len(ns_a_tasks) == 2
        assert len(ns_b_tasks) == 1
        for task in ns_a_tasks:
            assert task["namespace"] == "ns_a"
        for task in ns_b_tasks:
            assert task["namespace"] == "ns_b"
    
    def test_cleanup_project_isolation(self, dm):
        """TC-DBE-010: 清理项目数据隔离验证。"""
        dm.create_task("ns1", "task1", "project1", "agent1", "cmd1")
        dm.create_task("ns1", "task2", "project2", "agent2", "cmd2")
        
        dm.cleanup_project("project1")
        
        tasks = dm.get_tasks_by_project("ns1", "project1")
        assert len(tasks) == 0
        
        tasks2 = dm.get_tasks_by_project("ns1", "project2")
        assert len(tasks2) == 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
