"""重构模块扩展测试 - todo_queue_manager, todo_sync_manager, todo_storage"""

import pytest
import tempfile
import os
from pathlib import Path
from unittest.mock import Mock
from datetime import datetime


class TestTodoQueueManagerCoverage:
    """测试 TodoQueueManager - 提高覆盖率"""
    
    def test_init_with_db_path(self):
        from src.core.todo_queue_manager import TodoQueueManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            assert manager.db_path == db_path
    
    def test_init_with_project_path(self):
        from src.core.todo_queue_manager import TodoQueueManager
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = TodoQueueManager(project_path=tmpdir)
            expected = os.path.join(tmpdir, "state", "todos.db")
            assert manager.db_path == expected
    
    def test_init_default(self):
        from src.core.todo_queue_manager import TodoQueueManager
        manager = TodoQueueManager()
        assert "todos.db" in manager.db_path
    
    def test_init_with_storage(self):
        from src.core.todo_queue_manager import TodoQueueManager
        mock_storage = Mock()
        manager = TodoQueueManager(storage=mock_storage)
        assert manager._storage == mock_storage
    
    def test_add_item(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            item = TodoQueueItem(
                id="TODO-1to2-001",
                content="Test TODO",
                from_agent="agent1",
                to_agent="agent2",
                priority="high",
                created_at=datetime.now().isoformat()
            )
            
            result = manager.add(item)
            assert result is True
    
    def test_get_unread(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            item = TodoQueueItem(
                id="TODO-1to2-002",
                content="Test TODO",
                from_agent="agent1",
                to_agent="agent2",
                priority="high",
                created_at=datetime.now().isoformat()
            )
            manager.add(item)
            
            unread = manager.get_unread(agent_id="agent2")
            assert isinstance(unread, list)
    
    def test_get_all(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            all_items = manager.get_all(agent_id="agent2")
            assert isinstance(all_items, list)
    
    def test_mark_read(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            item = TodoQueueItem(
                id="TODO-1to2-003",
                content="Test TODO",
                from_agent="agent1",
                to_agent="agent2",
                priority="low",
                created_at=datetime.now().isoformat()
            )
            manager.add(item)
            
            result = manager.mark_read("TODO-1to2-003")
            assert result is True
    
    def test_mark_all_read(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            count = manager.mark_all_read(agent_id="agent2")
            assert count >= 0
    
    def test_get_stats(self):
        from src.core.todo_queue_manager import TodoQueueManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            stats = manager.get_stats(agent_id="agent2")
            assert stats.total >= 0
            assert stats.unread >= 0
    
    def test_cleanup(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            item = TodoQueueItem(
                id="TODO-1to2-010",
                content="Test TODO",
                from_agent="agent1",
                to_agent="agent2",
                priority="high",
                created_at=datetime.now().isoformat(),
                read=True
            )
            manager.add(item)
            
            count = manager.cleanup(days=30)
            assert count >= 0
    
    def test_delete(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            item = TodoQueueItem(
                id="TODO-1to2-011",
                content="Test TODO",
                from_agent="agent1",
                to_agent="agent2",
                priority="medium",
                created_at=datetime.now().isoformat()
            )
            manager.add(item)
            
            result = manager.delete("TODO-1to2-011")
            assert result is True
    
    def test_clear(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            item = TodoQueueItem(
                id="TODO-1to2-012",
                content="Test TODO",
                from_agent="agent1",
                to_agent="agent2",
                priority="low",
                created_at=datetime.now().isoformat()
            )
            manager.add(item)
            
            count = manager.clear(agent_id="agent2")
            assert count >= 0
    
    def test_get_unread_with_priority_filter(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            item = TodoQueueItem(
                id="TODO-1to2-013",
                content="Test TODO",
                from_agent="agent1",
                to_agent="agent2",
                priority="high",
                created_at=datetime.now().isoformat()
            )
            manager.add(item)
            
            unread = manager.get_unread(agent_id="agent2", priority="high")
            assert isinstance(unread, list)
    
    def test_get_all_no_agent_filter(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            all_items = manager.get_all()
            assert isinstance(all_items, list)
    
    def test_add_duplicate_item(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            item = TodoQueueItem(
                id="TODO-1to2-014",
                content="Test TODO",
                from_agent="agent1",
                to_agent="agent2",
                priority="high",
                created_at=datetime.now().isoformat()
            )
            manager.add(item)
            
            result = manager.add(item)
            assert result is False
    
    def test_mark_read_nonexistent(self):
        from src.core.todo_queue_manager import TodoQueueManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            result = manager.mark_read("TODO-NONEXISTENT-001")
            assert result is False
    
    def test_delete_nonexistent(self):
        from src.core.todo_queue_manager import TodoQueueManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            result = manager.delete("TODO-NONEXISTENT-001")
            assert result is False
    
    def test_get_stats_no_agent(self):
        from src.core.todo_queue_manager import TodoQueueManager, TodoQueueItem
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            item = TodoQueueItem(
                id="TODO-1to2-015",
                content="Test TODO",
                from_agent="agent1",
                to_agent="agent2",
                priority="medium",
                created_at=datetime.now().isoformat()
            )
            manager.add(item)
            
            stats = manager.get_stats()
            assert stats.total >= 0
    
    def test_mark_all_read_empty(self):
        from src.core.todo_queue_manager import TodoQueueManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            count = manager.mark_all_read(agent_id="agent99")
            assert count == 0
    
    def test_clear_empty(self):
        from src.core.todo_queue_manager import TodoQueueManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            count = manager.clear(agent_id="agent99")
            assert count == 0
    
    def test_get_unread_empty(self):
        from src.core.todo_queue_manager import TodoQueueManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            unread = manager.get_unread(agent_id="agent99")
            assert unread == []
    
    def test_get_unread_exception_handling(self):
        from src.core.todo_queue_manager import TodoQueueManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoQueueManager(db_path=db_path)
            
            manager._storage = Mock()
            manager._storage.list.side_effect = Exception("Test error")
            
            unread = manager.get_unread()
            assert unread == []


class TestTodoSyncManagerCoverage:
    """测试 TodoSyncManager - 提高覆盖率"""
    
    def test_init_with_db_path(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            assert manager.db_path == db_path
    
    def test_init_with_project_path(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = TodoSyncManager(project_path=tmpdir)
            expected = os.path.join(tmpdir, "state", "todos.db")
            assert manager.db_path == expected
    
    def test_init_with_storage(self):
        from src.core.todo_sync_manager import TodoSyncManager
        mock_storage = Mock()
        manager = TodoSyncManager(storage=mock_storage)
        assert manager._storage == mock_storage
    
    def test_load_todos(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            state = manager.load_todos()
            assert state is not None
    
    def test_add_todo(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            result = manager.add_todo("Test TODO", agent_id=1)
            assert result is not None
    
    def test_update_todo(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            todo = manager.add_todo("Test TODO", agent_id=1)
            if todo:
                result = manager.update_todo(todo.id, content="Updated")
                assert result is not None
    
    def test_delete_todo(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            todo = manager.add_todo("Test TODO", agent_id=1)
            if todo:
                result = manager.delete_todo(todo.id)
                assert result is True
    
    def test_get_todo(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            todo = manager.add_todo("Test TODO", agent_id=1)
            if todo:
                result = manager.get_todo(todo.id)
                assert result is not None
    
    def test_list_todos(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            manager.add_todo("Test TODO 1", agent_id=1)
            manager.add_todo("Test TODO 2", agent_id=2)
            
            results = manager.list_todos()
            assert len(results) > 0
    
    def test_mark_read(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            todo = manager.add_todo("Test TODO", agent_id=1)
            if todo:
                result = manager.mark_read(todo.id)
                assert result is True
    
    def test_mark_unread(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            todo = manager.add_todo("Test TODO", agent_id=1)
            if todo:
                manager.mark_read(todo.id)
                result = manager.mark_unread(todo.id)
                assert result is True
    
    def test_count_unread(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            manager.add_todo("Test TODO", agent_id=1)
            
            count = manager.count_unread("1")
            assert count >= 0
    
    def test_get_todos_by_agent(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            manager.add_todo("Test TODO", agent_id=1)
            
            results = manager.get_todos_by_agent(agent_id=1)
            assert results is not None
    
    def test_sync_with_rollback(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            def test_func():
                return True
            
            result = manager.sync_with_rollback(test_func)
            assert result is True
    
    def test_create_backup(self):
        from src.core.todo_sync_manager import TodoSyncManager
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoSyncManager(db_path=db_path)
            
            todo = manager.add_todo("Test TODO", agent_id=1)
            if todo:
                backup_path = manager.create_backup()
                assert backup_path is not None or backup_path is None


class TestTodoStorageCoverage:
    """测试 TodoStorage - 提高覆盖率"""
    
    def test_init_default(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            assert storage.db_path == db_path
    
    def test_add_todo(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            todo = {
                'id': 'TODO-1to2-010',
                'content': 'Test content',
                'sender': '1',
                'receiver': '2',
                'priority': 'high',
                'status': 'pending'
            }
            
            success, msg = storage.add(todo)
            assert success is True
    
    def test_get_todo(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            todo = {
                'id': 'TODO-1to2-011',
                'content': 'Test content',
                'sender': '1',
                'receiver': '2',
                'priority': 'medium',
                'status': 'pending'
            }
            
            storage.add(todo)
            result = storage.get('TODO-1to2-011')
            assert result is not None
            assert result['id'] == 'TODO-1to2-011'
    
    def test_update_todo(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            todo = {
                'id': 'TODO-1to2-012',
                'content': 'Test content',
                'sender': '1',
                'receiver': '2',
                'priority': 'low',
                'status': 'pending'
            }
            
            storage.add(todo)
            success = storage.update('TODO-1to2-012', {'status': 'completed'})
            assert success is True
    
    def test_delete_todo(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            todo = {
                'id': 'TODO-1to2-013',
                'content': 'Test content',
                'sender': '1',
                'receiver': '2',
                'priority': 'high',
                'status': 'pending'
            }
            
            storage.add(todo)
            success = storage.delete('TODO-1to2-013')
            assert success is True
    
    def test_list_todos(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            todo = {
                'id': 'TODO-1to2-014',
                'content': 'Test content',
                'sender': '1',
                'receiver': '2',
                'priority': 'medium',
                'status': 'pending'
            }
            
            storage.add(todo)
            results = storage.list()
            assert len(results) > 0
    
    def test_list_with_filters(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            todo = {
                'id': 'TODO-1to2-015',
                'content': 'Test content',
                'sender': '1',
                'receiver': '2',
                'priority': 'high',
                'status': 'pending'
            }
            
            storage.add(todo)
            results = storage.list(receiver='2', status='pending')
            assert isinstance(results, list)
    
    def test_mark_read(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            todo = {
                'id': 'TODO-1to2-016',
                'content': 'Test content',
                'sender': '1',
                'receiver': '2',
                'priority': 'low',
                'status': 'pending'
            }
            
            storage.add(todo)
            result = storage.mark_read('TODO-1to2-016')
            assert result is True
    
    def test_mark_unread(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            todo = {
                'id': 'TODO-1to2-017',
                'content': 'Test content',
                'sender': '1',
                'receiver': '2',
                'priority': 'medium',
                'status': 'pending'
            }
            
            storage.add(todo)
            storage.mark_read('TODO-1to2-017')
            result = storage.mark_unread('TODO-1to2-017')
            assert result is True
    
    def test_count_unread(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            todo = {
                'id': 'TODO-1to2-018',
                'content': 'Test content',
                'sender': '1',
                'receiver': '2',
                'priority': 'high',
                'status': 'pending'
            }
            
            storage.add(todo)
            count = storage.count_unread('2')
            assert count >= 0
    
    def test_get_next_id(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            next_id = storage.get_next_id('2')
            assert next_id >= 1
    
    def test_close(self):
        from src.core.todo_storage import TodoStorage
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            storage = TodoStorage(db_path)
            
            storage.close()


class TestTodoQueueItem:
    """测试 TodoQueueItem 数据类"""
    
    def test_from_dict_basic(self):
        from src.core.todo_queue_manager import TodoQueueItem
        data = {
            'id': 'TODO-1to2-020',
            'content': 'Test',
            'sender': '1',
            'receiver': '2',
            'priority': 'high',
            'status': 'pending'
        }
        item = TodoQueueItem.from_dict(data)
        assert item.id == 'TODO-1to2-020'
        assert item.content == 'Test'
    
    def test_from_dict_with_parsed_agent(self):
        from src.core.todo_queue_manager import TodoQueueItem
        data = {
            'id': 'TODO-1to2-021',
            'content': 'Test',
            'priority': 'medium',
            'status': 'completed'
        }
        item = TodoQueueItem.from_dict(data)
        assert item.from_agent == 'agent1'
        assert item.to_agent == 'agent2'
        assert item.read is True
    
    def test_from_dict_no_id(self):
        from src.core.todo_queue_manager import TodoQueueItem
        data = {
            'content': 'Test',
            'from_agent': 'agent1',
            'to_agent': 'agent2',
            'priority': 'low',
            'status': 'pending'
        }
        item = TodoQueueItem.from_dict(data)
        assert item.content == 'Test'
