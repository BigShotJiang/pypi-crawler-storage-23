"""Test-Agent test_report模块测试。"""

import pytest
import tempfile
import shutil
import yaml
from pathlib import Path
from datetime import datetime

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.models.test_report import (
    TestReport, TestReportStatus, TestReportResult,
    TestReportResult
)
from src.models.test_result import TestResult, TestStatus


class TestTestReportResult:
    """TestReportResult 测试类。"""
    
    def test_default_values(self):
        """TC-TR-001: 默认值测试。"""
        result = TestReportResult()
        assert result.passed == 0
        assert result.failed == 0
        assert result.skipped == 0
        assert result.errors == 0
    
    def test_to_dict(self):
        """TC-TR-002: 转换为字典。"""
        result = TestReportResult(passed=10, failed=2, skipped=1, errors=0)
        d = result.to_dict()
        assert d["passed"] == 10
        assert d["failed"] == 2
        assert d["skipped"] == 1
    
    def test_from_dict(self):
        """TC-TR-003: 从字典创建。"""
        data = {"passed": 5, "failed": 1, "skipped": 2, "errors": 0}
        result = TestReportResult.from_dict(data)
        assert result.passed == 5
        assert result.failed == 1


class TestTestReport:
    """TestReport 测试类。"""
    
    def test_default_values(self):
        """TC-TR-010: 默认值测试。"""
        report = TestReport(
            version="1.0.0",
            status=TestReportStatus.PASSED,
            timestamp="2026-01-01T00:00:00"
        )
        assert report.version == "1.0.0"
        assert report.status == TestReportStatus.PASSED
        assert report.results == {}
        assert report.coverage is None
    
    def test_to_dict(self):
        """TC-TR-011: 转换为字典。"""
        report = TestReport(
            version="1.0.0",
            status=TestReportStatus.PASSED,
            timestamp="2026-01-01T00:00:00",
            results={"unit": TestReportResult(passed=10, failed=0)},
            coverage=95
        )
        d = report.to_dict()
        assert d["version"] == "1.0.0"
        assert d["status"] == "passed"
        assert d["coverage"] == 95
        assert "unit" in d["results"]
    
    def test_from_dict(self):
        """TC-TR-012: 从字典创建。"""
        data = {
            "version": "2.0.0",
            "status": "failed",
            "timestamp": "2026-01-01T00:00:00",
            "results": {
                "unit": {"passed": 5, "failed": 1, "skipped": 0, "errors": 0}
            },
            "coverage": 80
        }
        report = TestReport.from_dict(data)
        assert report.version == "2.0.0"
        assert report.status == TestReportStatus.FAILED
        assert report.coverage == 80
        assert "unit" in report.results
    
    def test_from_test_result_passed(self):
        """TC-TR-013: 从TestResult创建(通过)。"""
        test_result = TestResult(
            id="test-001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            test_type="unit",
            passed=10,
            failed=0,
            errors=0,
            total=10,
            duration=5.5
        )
        test_result.finished_at = datetime.now()
        
        report = TestReport.from_test_result(test_result, "test-project")
        
        assert report.version == "v1.0.0"
        assert report.status == TestReportStatus.PASSED
        assert report.project == "test-project"
        assert "unit" in report.results
    
    def test_from_test_result_failed(self):
        """TC-TR-014: 从TestResult创建(失败)。"""
        test_result = TestResult(
            id="test-002",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.FAILED,
            test_type="integration",
            passed=8,
            failed=2,
            errors=0,
            total=10,
            duration=10.0
        )
        test_result.finished_at = datetime.now()
        
        report = TestReport.from_test_result(test_result, "test-project")
        
        assert report.version == "v1.0.0"
        assert report.status == TestReportStatus.FAILED
    
    def test_to_yaml_dict(self):
        """TC-TR-015: 转换为YAML兼容字典。"""
        report = TestReport(
            version="1.0.0",
            status=TestReportStatus.PASSED,
            timestamp="2026-01-01T00:00:00"
        )
        d = report.to_yaml_dict()
        assert d["status"] == "passed"
        assert isinstance(d["status"], str)


class TestTestReportStatus:
    """TestReportStatus 枚举测试类。"""
    
    def test_enum_values(self):
        """TC-TR-020: 枚举值测试。"""
        assert TestReportStatus.PASSED.value == "passed"
        assert TestReportStatus.FAILED.value == "failed"
        assert TestReportStatus.PARTIAL.value == "partial"
