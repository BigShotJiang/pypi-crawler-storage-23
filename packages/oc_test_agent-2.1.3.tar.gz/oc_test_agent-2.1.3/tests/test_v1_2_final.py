"""Test-Agent v1.2 最终测试 - 提升覆盖率"""

import pytest
import tempfile
import os
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, MagicMock
import json

os.environ["TEST_ENV"] = "1"

from src.models.test_result import TestResult, TestStatus
from src.db.database import Database
from src.db.repositories.result_repo import ResultRepository


class TestDockerServiceFull:
    """完整测试DockerService"""
    
    @patch('src.core.docker_service.docker.from_env')
    def test_is_available_false(self, mock_docker):
        """测试Docker不可用"""
        mock_docker.side_effect = Exception("Docker not found")
        
        from src.core.docker_service import DockerService
        svc = DockerService()
        
        result = svc.is_available()
        
        assert result is False
    
    @patch('src.core.docker_service.docker.from_env')
    def test_image_not_exists(self, mock_docker):
        """测试镜像不存在"""
        from docker.errors import NotFound
        mock_client = MagicMock()
        mock_client.images.get.side_effect = NotFound("Not found")
        mock_docker.return_value = mock_client
        
        from src.core.docker_service import DockerService
        svc = DockerService()
        
        result = svc.image_exists("nonexistent:latest")
        
        assert result is False
    
    @patch('src.core.docker_service.docker.from_env')
    def test_wait_container_error(self, mock_docker):
        """测试等待容器出错"""
        mock_client = MagicMock()
        mock_client.containers.get.side_effect = Exception("Container not found")
        mock_docker.return_value = mock_client
        
        from src.core.docker_service import DockerService
        svc = DockerService()
        
        result = svc.wait_container("invalid")
        
        assert result["status_code"] == -1
    
    @patch('src.core.docker_service.docker.from_env')
    def test_stop_container_error(self, mock_docker):
        """测试停止容器出错"""
        mock_client = MagicMock()
        mock_client.containers.get.side_effect = Exception("Error")
        mock_docker.return_value = mock_client
        
        from src.core.docker_service import DockerService
        svc = DockerService()
        
        result = svc.stop_container("invalid")
        
        assert result is False
    
    @patch('src.core.docker_service.docker.from_env')
    def test_remove_container_error(self, mock_docker):
        """测试删除容器出错"""
        mock_client = MagicMock()
        mock_client.containers.get.side_effect = Exception("Error")
        mock_docker.return_value = mock_client
        
        from src.core.docker_service import DockerService
        svc = DockerService()
        
        result = svc.remove_container("invalid")
        
        assert result is False
    
    @patch('src.core.docker_service.docker.from_env')
    def test_get_logs_error(self, mock_docker):
        """测试获取日志出错"""
        mock_client = MagicMock()
        mock_client.containers.get.side_effect = Exception("Error")
        mock_docker.return_value = mock_client
        
        from src.core.docker_service import DockerService
        svc = DockerService()
        
        result = svc.get_container_logs("invalid")
        
        assert result == ""    
    @patch('src.core.docker_service.docker.from_env')
    def test_build_image_error(self, mock_docker):
        """测试构建镜像出错"""
        from docker.errors import APIError
        mock_client = MagicMock()
        mock_client.images.build.side_effect = APIError("Build failed")
        mock_docker.return_value = mock_client
        
        from src.core.docker_service import DockerService
        svc = DockerService()
        
        result = svc.build_image("/tmp")
        
        assert result is False
    
    @patch('src.core.docker_service.docker.from_env')
    def test_run_container_error(self, mock_docker):
        """测试运行容器出错"""
        from docker.errors import APIError
        mock_client = MagicMock()
        mock_client.containers.run.side_effect = APIError("Run failed")
        mock_docker.return_value = mock_client
        
        from src.core.docker_service import DockerService
        svc = DockerService()
        
        result = svc.run_container("test-image")
        
        assert result is None


class TestDependencyServiceFull:
    """完整测试DependencyService"""
    
    def test_resolve_version_from_pyproject(self):
        """测试从pyproject.toml解析版本"""
        import tempfile
        from pathlib import Path
        
        with tempfile.TemporaryDirectory() as tmpdir:
            proj_path = Path(tmpdir)
            pyproject = proj_path / "pyproject.toml"
            pyproject.write_text('[project]\nversion = "1.2.3"')
            
            from src.core.dependency_service import DependencyService
            svc = DependencyService()
            
            dep = {"name": "test", "path": tmpdir}
            version = svc.resolve_version(dep)
            
            assert version == "1.2.3"
    
    def test_resolve_version_default(self):
        """测试默认版本"""
        from src.core.dependency_service import DependencyService
        svc = DependencyService()
        
        dep = {"name": "test", "path": "/nonexistent"}
        version = svc.resolve_version(dep)
        
        assert version == "unknown"


class TestTestExecutorFull:
    """完整测试TestExecutor"""
    
    @pytest.fixture
    def temp_db(self):
        """创建临时数据库"""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = Database(db_path)
        db.init_schema()
        
        yield db
        
        db.close()
        os.unlink(db_path)
    
    def test_parse_pytest_no_match(self, temp_db):
        """测试无法解析pytest输出"""
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test",
            version="v1.0",
            project_path="/tmp"
        )
        
        logs = "some random output"
        passed, failed, errors, total = executor._parse_pytest_output(logs)
        
        assert passed == 0
        assert failed == 0
        assert errors == 0
        assert total == 0
    
    def test_save_logs(self, temp_db):
        """测试保存日志"""
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test",
            version="v1.0",
            project_path="/tmp"
        )
        
        with tempfile.NamedTemporaryFile(suffix='.log', delete=False) as f:
            log_path = f.name
        
        try:
            executor._save_logs(log_path, "test log content")
            
            with open(log_path) as f:
                content = f.read()
            
            assert content == "test log content"
        finally:
            os.unlink(log_path)
    
    @patch('src.core.test_executor.DockerService')
    def test_execute_exception(self, mock_docker, temp_db):
        """测试执行异常"""
        mock_ds = MagicMock()
        mock_ds.build_image.side_effect = Exception("Unknown error")
        mock_docker.return_value = mock_ds
        
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test",
            version="v1.0",
            project_path="/tmp",
            timeout=60
        )
        executor.docker = mock_ds
        
        result = executor.execute()
        
        assert result.status == TestStatus.ERROR
    
    def test_cancel_no_container(self, temp_db):
        """测试取消无容器"""
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test",
            version="v1.0",
            project_path="/tmp"
        )
        
        result = executor.cancel()
        
        assert result is False


class TestDatabaseFull:
    """完整测试Database"""
    
    def test_backup(self):
        """测试数据库备份"""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = Database(db_path)
        db.init_schema()
        
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as bf:
            backup_path = bf.name
        
        try:
            db.backup(backup_path)
            
            assert os.path.exists(backup_path)
        finally:
            os.unlink(db_path)
            if os.path.exists(backup_path):
                os.unlink(backup_path)
    
    def test_close(self):
        """测试关闭数据库"""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = Database(db_path)
        db.init_schema()
        
        db.close()
        
        assert db._connection is None


class TestResultRepoFull:
    """完整测试ResultRepository"""
    
    @pytest.fixture
    def temp_db(self):
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = Database(db_path)
        db.init_schema()
        
        yield db
        
        db.close()
        os.unlink(db_path)
    
    def test_update_container_id(self, temp_db):
        """测试更新容器ID"""
        repo = ResultRepository(temp_db)
        
        result = TestResult(
            id="test_001",
            project="test",
            version="v1.0",
            status=TestStatus.RUNNING,
            created_at=datetime.now()
        )
        repo.insert(result)
        
        repo.update_status("test_001", TestStatus.RUNNING, container_id="container123")
        
        updated = repo.find_by_id("test_001")
        
        assert updated.container_id == "container123"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
