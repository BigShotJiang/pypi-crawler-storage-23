"""Test-Agent 配置模块测试。"""

import pytest
import tempfile
import shutil
import yaml
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.utils.config import ConfigManager
from src.utils.errors import ValidationError, ConfigParseError


class TestConfigManager:
    """ConfigManager 测试类。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    @pytest.fixture
    def config_file(self, temp_dir):
        """创建配置文件。"""
        path = Path(temp_dir) / "config.yaml"
        data = {"key": "value", "number": 42}
        with open(path, 'w') as f:
            yaml.safe_dump(data, f)
        return path
    
    def test_load_yaml(self, config_file):
        """TC-CM-001: 加载YAML文件。"""
        data = ConfigManager.load_yaml(config_file)
        assert data["key"] == "value"
        assert data["number"] == 42
    
    def test_load_yaml_not_found(self, temp_dir):
        """TC-CM-002: 加载不存在的文件。"""
        data = ConfigManager.load_yaml(Path(temp_dir) / "nonexistent.yaml")
        assert data == {}
    
    def test_load_yaml_parse_error(self, temp_dir):
        """TC-CM-003: YAML解析错误。"""
        path = Path(temp_dir) / "invalid.yaml"
        with open(path, 'w') as f:
            f.write("invalid: yaml: content:")
        
        with pytest.raises(ConfigParseError):
            ConfigManager.load_yaml(path)
    
    def test_save_yaml(self, temp_dir):
        """TC-CM-004: 保存YAML文件。"""
        path = Path(temp_dir) / "output.yaml"
        data = {"test": "data", "nested": {"key": "value"}}
        
        ConfigManager.save_yaml(path, data)
        
        assert path.exists()
        
        with open(path, 'r') as f:
            loaded = yaml.safe_load(f)
            assert loaded["test"] == "data"
    
    def test_save_yaml_creates_directory(self, temp_dir):
        """TC-CM-005: 保存时自动创建目录。"""
        path = Path(temp_dir) / "subdir" / "config.yaml"
        ConfigManager.save_yaml(path, {"key": "value"})
        
        assert path.exists()
    
    def test_validate_project_id_valid(self):
        """TC-CM-006: 验证有效的项目ID。"""
        result = ConfigManager.validate_project_id("test_project")
        assert result is True
    
    def test_validate_project_id_invalid(self):
        """TC-CM-007: 验证无效的项目ID。"""
        with pytest.raises(ValidationError) as exc:
            ConfigManager.validate_project_id("invalid_project")
        assert "T001" in str(exc.value)
    
    def test_validate_project_id_empty(self):
        """TC-CM-008: 验证空项目ID。"""
        with pytest.raises(ValidationError):
            ConfigManager.validate_project_id("")
    
    def test_validate_agent_id_valid(self):
        """TC-CM-009: 验证有效的Agent ID。"""
        result = ConfigManager.validate_agent_id("test_agent_001")
        assert result is True
    
    def test_validate_agent_id_invalid(self):
        """TC-CM-010: 验证无效的Agent ID。"""
        with pytest.raises(ValidationError) as exc:
            ConfigManager.validate_agent_id("invalid_agent")
        assert "T004" in str(exc.value)
    
    def test_validate_agent_id_with_underscore(self):
        """TC-CM-011: 验证带下划线的Agent ID。"""
        result = ConfigManager.validate_agent_id("test_agent_001")
        assert result is True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
