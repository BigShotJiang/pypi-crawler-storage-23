"""
通知模块单元测试 - Webhook最终
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch
from src.core.notification.webhook import WebhookManager, WebhookConfig, WebhookPayload


class TestWebhookFinal:
    """Webhook最终测试"""
    
    @pytest.mark.asyncio
    async def test_retry_exponential_backoff(self):
        """测试指数退避重试"""
        manager = WebhookManager()
        
        mock_config = Mock()
        mock_config.retry_config = {"max_attempts": 3, "interval": 1}
        mock_config.timeout = 30
        
        mock_payload = Mock()
        
        with patch.object(manager, '_send_webhook', new_callable=AsyncMock) as mock_send:
            await manager._send_with_retry(mock_config, mock_payload)
    
    @pytest.mark.asyncio
    async def test_notify_catches_exception(self):
        """测试通知捕获异常"""
        manager = WebhookManager()
        manager._enabled = True
        
        mock_result = Mock()
        mock_result.id = "test_123"
        mock_result.project = "pm-agent"
        mock_result.version = "v1.0"
        mock_result.status = "passed"
        mock_result.passed = 10
        mock_result.failed = 0
        mock_result.errors = 0
        mock_result.duration = 5.0
        
        with patch.object(manager, '_send_notifications', new_callable=AsyncMock) as mock_send:
            mock_send.side_effect = Exception("Network error")
            
            await manager.notify(mock_result)
    
    def test_should_send_namespace_prefix(self):
        """测试命名空间前缀匹配"""
        manager = WebhookManager()
        config = WebhookConfig(
            id="test-1",
            url="http://example.com/webhook",
            events=["test.*"]
        )
        assert manager.should_send(config, "test.anything") is True
    
    def test_payload_build_all_statuses(self):
        """测试构建所有状态负载"""
        manager = WebhookManager()
        
        for status in ["passed", "failed", "error", "cancelled"]:
            mock_result = Mock()
            mock_result.id = f"test_{status}"
            mock_result.project = "pm-agent"
            mock_result.version = "v1.0"
            mock_result.status = status
            mock_result.passed = 10
            mock_result.failed = 0
            mock_result.errors = 0
            mock_result.duration = 5.0
            
            payload = manager.build_payload(mock_result)
            assert payload.event == f"test.{status}"
    
    def test_config_timeout_default(self):
        """测试默认超时"""
        config = WebhookConfig(
            id="test-1",
            url="http://example.com/webhook",
            events=["test.*"]
        )
        assert config.timeout == 30
