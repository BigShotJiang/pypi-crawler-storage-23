"""重构模块单元测试 - config, interfaces, factory, todo_id_generator"""

import pytest
import tempfile
import os
from pathlib import Path


class TestLocalConfigProvider:
    """测试 LocalConfigProvider"""
    
    def test_default_values(self):
        from src.core.config import LocalConfigProvider
        provider = LocalConfigProvider()
        
        assert provider.get_data_dir() == "state"
        assert provider.get_config_dir() == "config"
        assert provider.get_log_dir() == "logs"
        assert provider.get_temp_dir() == "tmp"
        assert provider.get_todo_db_path() == "todos.db"
        assert provider.get_state_file_path() == "project_state.yaml"
    
    def test_custom_project_path(self):
        from src.core.config import LocalConfigProvider
        with tempfile.TemporaryDirectory() as tmpdir:
            provider = LocalConfigProvider(Path(tmpdir))
            
            assert provider.project_path == Path(tmpdir)
    
    def test_get_full_path(self):
        from src.core.config import LocalConfigProvider
        with tempfile.TemporaryDirectory() as tmpdir:
            provider = LocalConfigProvider(Path(tmpdir))
            
            result = provider.get_full_path("state/todos.db")
            assert result == Path(tmpdir) / "state/todos.db"
    
    def test_get_todo_db_full_path(self):
        from src.core.config import LocalConfigProvider
        with tempfile.TemporaryDirectory() as tmpdir:
            provider = LocalConfigProvider(Path(tmpdir))
            
            result = provider.get_todo_db_full_path()
            assert result == Path(tmpdir) / "state/todos.db"


class TestAppConfig:
    """测试 AppConfig"""
    
    def test_default_init(self):
        from src.core.config import AppConfig
        config = AppConfig()
        
        assert config.project_path == Path.cwd()
        assert config.config_provider is not None
    
    def test_custom_project_path(self):
        from src.core.config import AppConfig
        with tempfile.TemporaryDirectory() as tmpdir:
            config = AppConfig(tmpdir)
            
            assert config.project_path == Path(tmpdir)
    
    def test_todo_db_path_property(self):
        from src.core.config import AppConfig
        with tempfile.TemporaryDirectory() as tmpdir:
            config = AppConfig(tmpdir)
            
            assert config.todo_db_path == Path(tmpdir) / "state/todos.db"
    
    def test_state_file_path_property(self):
        from src.core.config import AppConfig
        with tempfile.TemporaryDirectory() as tmpdir:
            config = AppConfig(tmpdir)
            
            assert config.state_file_path == Path(tmpdir) / "state/project_state.yaml"
    
    def test_get_lock_path(self):
        from src.core.config import AppConfig
        with tempfile.TemporaryDirectory() as tmpdir:
            config = AppConfig(tmpdir)
            
            assert config.get_lock_path("todo_id") == Path(tmpdir) / "state/.todo_id.lock"
    
    def test_get_path(self):
        from src.core.config import AppConfig
        with tempfile.TemporaryDirectory() as tmpdir:
            config = AppConfig(tmpdir)
            
            assert config.get_path("config/test.yaml") == Path(tmpdir) / "config/test.yaml"


class TestConfigFactory:
    """测试 ConfigFactory"""
    
    def test_create_local_config_provider(self):
        from src.core.todo.factory import ConfigFactory
        with tempfile.TemporaryDirectory() as tmpdir:
            provider = ConfigFactory.create_config_provider("local", tmpdir)
            
            assert provider.get_data_dir() == "state"
    
    def test_create_app_config(self):
        from src.core.todo.factory import ConfigFactory
        with tempfile.TemporaryDirectory() as tmpdir:
            config = ConfigFactory.create_app_config(tmpdir)
            
            assert config.project_path == Path(tmpdir)


class TestTodoModuleFactory:
    """测试 TodoModuleFactory"""
    
    def test_create_id_generator_default(self):
        from src.core.todo.factory import TodoModuleFactory
        gen = TodoModuleFactory.create_id_generator()
        
        assert gen.use_uuid is True
    
    def test_create_id_generator_with_agent(self):
        from src.core.todo.factory import TodoModuleFactory
        gen = TodoModuleFactory.create_id_generator(agent_id="1")
        
        assert gen.agent_id == "1"
    
    def test_create_id_generator_legacy_mode(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator(use_uuid=False)
        
        assert gen.use_uuid is False
    
    def test_create_storage_default(self):
        from src.core.todo.factory import TodoModuleFactory
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = TodoModuleFactory.create_storage(db_path=os.path.join(tmpdir, "test.db"))
            
            assert storage.db_path == os.path.join(tmpdir, "test.db")


class TestTodoIdGeneratorUUID:
    """测试 TodoIdGenerator UUID 方案"""
    
    def test_generate_uuid_format(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator(use_uuid=True)
        
        todo_id = gen.generate("1", "2")
        
        assert todo_id.startswith("TODO-1to2-")
        assert len(todo_id.split("-")) == 4
    
    def test_generate_unique_ids(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator(use_uuid=True)
        
        ids = [gen.generate("1", "2") for _ in range(100)]
        
        assert len(set(ids)) == 100
    
    def test_parse_uuid_format(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator(use_uuid=True)
        
        todo_id = gen.generate("1", "2")
        parsed = gen.parse(todo_id)
        
        assert parsed is not None
        assert parsed["creator"] == "1"
        assert parsed["receiver"] == "2"
        assert parsed["is_uuid"] is True
        assert parsed["is_legacy"] is False
    
    def test_is_valid_uuid(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator(use_uuid=True)
        
        todo_id = gen.generate("1", "2")
        
        assert gen.is_valid(todo_id) is True
        assert gen.is_uuid_format(todo_id) is True
        assert gen.is_legacy_format(todo_id) is False
    
    def test_generate_without_params(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator(use_uuid=True)
        
        todo_id = gen.generate()
        
        assert todo_id.startswith("TODO-xto")
    
    def test_parse_legacy_format(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator()
        
        parsed = gen.parse("TODO-1to2-001")
        
        assert parsed is not None
        assert parsed["creator"] == "1"
        assert parsed["receiver"] == "2"
        assert parsed["seq"] == 1
        assert parsed["is_legacy"] is True
    
    def test_parse_early_legacy_format(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator()
        
        parsed = gen.parse("TODO-1-001")
        
        assert parsed is not None
        assert parsed["creator"] == "1"
        assert parsed["is_legacy"] is True
    
    def test_invalid_format(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator()
        
        assert gen.is_valid("invalid-id") is False
        assert gen.parse("invalid-id") is None


class TestITodoStorage:
    """测试 ITodoStorage 接口"""
    
    def test_interface_exists(self):
        from src.core.todo.interfaces import ITodoStorage
        from src.core.todo_storage import TodoStorage
        
        assert hasattr(ITodoStorage, 'add')
        assert hasattr(ITodoStorage, 'get')
        assert hasattr(ITodoStorage, 'list')
        assert hasattr(ITodoStorage, 'update')
        assert hasattr(ITodoStorage, 'delete')
        assert hasattr(ITodoStorage, 'mark_read')


class TestITodoIdGenerator:
    """测试 ITodoIdGenerator 接口"""
    
    def test_interface_exists(self):
        from src.core.todo.interfaces import ITodoIdGenerator
        from src.core.todo_id_generator import TodoIdGenerator
        
        assert hasattr(ITodoIdGenerator, 'generate')
        assert hasattr(ITodoIdGenerator, 'parse')
        assert hasattr(ITodoIdGenerator, 'is_valid')


class TestTodoModuleFactoryCoverage:
    """测试 TodoModuleFactory 覆盖率"""
    
    def test_create_queue_manager_with_config(self):
        from src.core.todo.factory import TodoModuleFactory
        from src.core.config import AppConfig
        with tempfile.TemporaryDirectory() as tmpdir:
            config = AppConfig(tmpdir)
            manager = TodoModuleFactory.create_queue_manager(config=config)
            assert manager is not None
    
    def test_create_queue_manager_with_db_path(self):
        from src.core.todo.factory import TodoModuleFactory
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = os.path.join(tmpdir, "test.db")
            manager = TodoModuleFactory.create_queue_manager(db_path=db_path)
            assert manager is not None
    
    def test_create_queue_manager_default(self):
        from src.core.todo.factory import TodoModuleFactory
        manager = TodoModuleFactory.create_queue_manager()
        assert manager is not None
    
    def test_create_sync_manager_with_config(self):
        from src.core.todo.factory import TodoModuleFactory
        from src.core.config import AppConfig
        with tempfile.TemporaryDirectory() as tmpdir:
            config = AppConfig(tmpdir)
            manager = TodoModuleFactory.create_sync_manager(config=config)
            assert manager is not None
    
    def test_create_sync_manager_with_project_path(self):
        from src.core.todo.factory import TodoModuleFactory
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = TodoModuleFactory.create_sync_manager(project_path=tmpdir)
            assert manager is not None
    
    def test_create_sync_manager_default(self):
        from src.core.todo.factory import TodoModuleFactory
        manager = TodoModuleFactory.create_sync_manager()
        assert manager is not None


class TestTodoIdGeneratorCoverage:
    """测试 TodoIdGenerator 覆盖率"""
    
    def test_generate_legacy_with_counter(self):
        from src.core.todo_id_generator import TodoIdGenerator
        with tempfile.TemporaryDirectory() as tmpdir:
            state_file = os.path.join(tmpdir, "state.yaml")
            gen = TodoIdGenerator(use_uuid=False, state_file=state_file)
            
            id1 = gen.generate("1", "2")
            id2 = gen.generate("1", "2")
            
            assert id1 != id2
            assert "-001" in id1
            assert "-002" in id2
    
    def test_load_state_file_not_exists(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator(state_file="/nonexistent/path.yaml")
        
        state = gen._load_state()
        assert "todo_id_counters" in state
    
    def test_parse_invalid_id(self):
        from src.core.todo_id_generator import TodoIdGenerator
        gen = TodoIdGenerator()
        
        assert gen.parse("invalid") is None
        assert gen.parse("") is None
        assert gen.parse("TODO-") is None
