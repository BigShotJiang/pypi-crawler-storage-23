"""test-agent HTTP API E2E测试

测试test-agent API服务的完整功能：
- 健康检查
- 测试执行
- 测试查询
- 项目管理
- Agent管理

测试环境:
- BASE_URL: http://localhost:8004 (可通过环境变量TEST_AGENT_API_URL覆盖)
- API_KEY: test-secret (可通过环境变量TEST_AGENT_API_KEY覆盖)

用例ID规范: TC-TESTAGENT-HTTPAPI-{模块}-{序号}
"""

import pytest
import requests
import subprocess
import time
import os
import signal
import sqlite3
from pathlib import Path

BASE_URL = os.environ.get("TEST_AGENT_API_URL", "http://localhost:8004")
API_KEY = os.environ.get("TEST_AGENT_API_KEY", "test-agent-secret")
TIMEOUT = 30


class TestHealthEndpoint:
    """健康检查接口测试"""

    def test_health_without_auth(self):
        """TC-TESTAGENT-HTTPAPI-HEALTH-001: 测试健康检查无需认证"""
        response = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert "version" in data

    def test_health_response_format(self):
        """TC-TESTAGENT-HTTPAPI-HEALTH-002: 测试健康检查响应格式"""
        response = requests.get(f"{BASE_URL}/health", timeout=TIMEOUT)
        data = response.json()
        assert "status" in data
        assert "version" in data


class TestTestEndpoint:
    """测试执行接口测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        """设置测试环境"""
        self.headers = {"x-api-key": API_KEY}
        yield

    def test_execute_test_without_auth(self):
        """TC-TESTAGENT-HTTPAPI-TEST-001: 测试未授权无法执行"""
        response = requests.post(
            f"{BASE_URL}/api/v1/tests/execute",
            json={"project": "pm-agent", "version": "v1.3.0"},
            timeout=TIMEOUT
        )
        assert response.status_code == 401

    def test_execute_test(self):
        """TC-TESTAGENT-HTTPAPI-TEST-002: 测试正常执行"""
        response = requests.post(
            f"{BASE_URL}/api/v1/tests/execute",
            json={
                "project": "pm-agent",
                "version": "v1.3.0",
                "test_type": "unit"
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200
        data = response.json()
        assert "test_id" in data
        assert "status" in data

    def test_execute_test_missing_project(self):
        """TC-TESTAGENT-HTTPAPI-TEST-003: 测试缺少project参数"""
        response = requests.post(
            f"{BASE_URL}/api/v1/tests/execute",
            json={"version": "v1.3.0"},
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 422

    def test_query_tests(self):
        """TC-TESTAGENT-HTTPAPI-TEST-004: 测试查询测试列表"""
        response = requests.get(
            f"{BASE_URL}/api/v1/tests",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200
        data = response.json()
        assert "tests" in data
        assert "total" in data

    def test_query_tests_with_filters(self):
        """TC-TESTAGENT-HTTPAPI-TEST-005: 测试带过滤条件查询"""
        response = requests.get(
            f"{BASE_URL}/api/v1/tests?project=pm-agent&limit=5",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200
        data = response.json()
        assert "tests" in data
        assert isinstance(data["tests"], list)

    def test_get_test_detail_not_found(self):
        """TC-TESTAGENT-HTTPAPI-TEST-006: 测试获取不存在测试详情应返回404"""
        response = requests.get(
            f"{BASE_URL}/api/v1/tests/test_nonexistent_12345",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 404

    def test_cancel_test_not_found(self):
        """TC-TESTAGENT-HTTPAPI-TEST-007: 测试取消不存在测试应返回404"""
        response = requests.delete(
            f"{BASE_URL}/api/v1/tests/test_nonexistent_12345",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 404


class TestProjectEndpoint:
    """项目管理接口测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        """设置测试环境"""
        self.headers = {"x-api-key": API_KEY}
        self.test_project_id = f"test_project_{int(time.time())}"
        yield
        try:
            requests.delete(
                f"{BASE_URL}/api/v1/projects/{self.test_project_id}",
                headers=self.headers,
                timeout=TIMEOUT
            )
        except Exception:
            pass

    def test_create_project(self):
        """TC-TESTAGENT-HTTPAPI-PROJ-001: 测试创建项目"""
        response = requests.post(
            f"{BASE_URL}/api/v1/projects",
            json={
                "project_id": self.test_project_id,
                "name": "测试项目",
                "config": {}
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200
        data = response.json()
        assert data["project_id"] == self.test_project_id

    def test_list_projects(self):
        """TC-TESTAGENT-HTTPAPI-PROJ-002: 测试列出项目"""
        response = requests.get(
            f"{BASE_URL}/api/v1/projects",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200
        data = response.json()
        assert "projects" in data
        assert isinstance(data["projects"], list)

    def test_get_project_detail_not_found(self):
        """TC-TESTAGENT-HTTPAPI-PROJ-003: 测试获取不存在项目详情应返回404"""
        response = requests.get(
            f"{BASE_URL}/api/v1/projects/nonexistent_project_12345",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 404

    def test_delete_project(self):
        """TC-TESTAGENT-HTTPAPI-PROJ-004: 测试删除项目"""
        requests.post(
            f"{BASE_URL}/api/v1/projects",
            json={"project_id": self.test_project_id, "name": "测试"},
            headers=self.headers,
            timeout=TIMEOUT
        )
        response = requests.delete(
            f"{BASE_URL}/api/v1/projects/{self.test_project_id}",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200


class TestAgentEndpoint:
    """Agent管理接口测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        """设置测试环境"""
        self.headers = {"x-api-key": API_KEY}
        self.test_agent_id = f"test_agent_{int(time.time())}"
        yield
        try:
            requests.delete(
                f"{BASE_URL}/api/v1/agents/{self.test_agent_id}",
                headers=self.headers,
                timeout=TIMEOUT
            )
        except Exception:
            pass

    def test_register_agent(self):
        """TC-TESTAGENT-HTTPAPI-AGENT-001: 测试注册Agent"""
        response = requests.post(
            f"{BASE_URL}/api/v1/agents",
            json={
                "agent_id": self.test_agent_id,
                "name": "测试Agent",
                "metadata": {}
            },
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200

    def test_list_agents(self):
        """TC-TESTAGENT-HTTPAPI-AGENT-002: 测试列出Agent"""
        response = requests.get(
            f"{BASE_URL}/api/v1/agents",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200

    def test_get_agent_detail_not_found(self):
        """TC-TESTAGENT-HTTPAPI-AGENT-003: 测试获取不存在Agent详情应返回404"""
        response = requests.get(
            f"{BASE_URL}/api/v1/agents/nonexistent_agent_12345",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 404

    def test_unregister_agent(self):
        """TC-TESTAGENT-HTTPAPI-AGENT-004: 测试注销Agent"""
        requests.post(
            f"{BASE_URL}/api/v1/agents",
            json={"agent_id": self.test_agent_id, "name": "测试"},
            headers=self.headers,
            timeout=TIMEOUT
        )
        response = requests.delete(
            f"{BASE_URL}/api/v1/agents/{self.test_agent_id}",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200


class TestBoundaryConditions:
    """边界条件测试"""

    @pytest.fixture(autouse=True)
    def setup(self):
        """设置测试环境"""
        self.headers = {"x-api-key": API_KEY}
        yield

    def test_query_limit_zero(self):
        """TC-TESTAGENT-HTTPAPI-BOUND-001: 测试limit=0应返回空列表"""
        response = requests.get(
            f"{BASE_URL}/api/v1/tests?limit=0",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200
        data = response.json()
        assert "tests" in data

    def test_query_limit_negative(self):
        """TC-TESTAGENT-HTTPAPI-BOUND-002: 测试limit负数应忽略"""
        response = requests.get(
            f"{BASE_URL}/api/v1/tests?limit=-1",
            headers=self.headers,
            timeout=TIMEOUT
        )
        assert response.status_code == 200


class TestAuthentication:
    """认证机制测试"""

    def test_invalid_api_key(self):
        """TC-TESTAGENT-HTTPAPI-AUTH-001: 测试无效API Key"""
        response = requests.get(
            f"{BASE_URL}/api/v1/tests",
            headers={"x-api-key": "invalid-key-12345"},
            timeout=TIMEOUT
        )
        assert response.status_code == 401

    def test_missing_api_key(self):
        """TC-TESTAGENT-HTTPAPI-AUTH-002: 测试缺少API Key"""
        response = requests.get(f"{BASE_URL}/api/v1/tests", timeout=TIMEOUT)
        assert response.status_code == 401


class TestDatabaseIntegration:
    """数据库集成测试"""

    def test_cli_data_consistency(self):
        """TC-TESTAGENT-HTTPAPI-DB-001: 测试CLI数据一致性"""
        db_path = Path("state/test_results.db")
        if db_path.exists():
            conn = sqlite3.connect(str(db_path))
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            assert "test_results" in tables
            conn.close()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
