"""
新增测试场景 - 针对Agent5分析的问题

本文档包含以下测试场景:
1. 跨子系统测试 - 统一数据库路径
2. 失败场景测试 - .oc-collab.yaml不存在等
3. ID格式验证测试

基于 MEMO_todo_test_gap_analysis.md 的建议创建
"""

import pytest
import os
import tempfile
import shutil
import sqlite3
import yaml
import subprocess
from pathlib import Path
from unittest.mock import patch


@pytest.fixture
def shared_db_env():
    """创建共享数据库环境的fixture"""
    original_dir = os.getcwd()
    test_dir = tempfile.mkdtemp()
    
    os.chdir(test_dir)
    
    os.makedirs("state", exist_ok=True)
    os.makedirs("config", exist_ok=True)
    os.makedirs("skills", exist_ok=True)
    os.makedirs("docs/00-memos", exist_ok=True)
    
    db_path = Path("state/todos.db")
    conn = sqlite3.connect(str(db_path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS todos (
            id TEXT PRIMARY KEY,
            content TEXT,
            status TEXT DEFAULT 'pending',
            priority TEXT DEFAULT 'medium',
            sender TEXT,
            receiver TEXT,
            source TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_read INTEGER DEFAULT 0
        )
    """)
    conn.commit()
    conn.close()
    
    with open("config/agent_registry.yaml", 'w') as f:
        yaml.dump({
            "agents": [
                {"id": "1", "name": "Agent1", "role": "PM", "status": "active"},
                {"id": "2", "name": "Agent2", "role": "DEV", "status": "active"},
                {"id": "5", "name": "Agent5", "role": "HQ", "status": "active"}
            ]
        }, f)
    
    with open("state/project_state.yaml", 'w') as f:
        yaml.dump({
            "version": "2.4.0",
            "phase": "development",
            "current_agent": "agent1",
            "agents": {
                "1": {"name": "Agent1", "role": "PM"},
                "2": {"name": "Agent2", "role": "DEV"},
                "5": {"name": "Agent5", "role": "HQ"}
            }
        }, f)
    
    yield {
        "test_dir": test_dir,
        "db_path": db_path
    }
    
    os.chdir(original_dir)
    shutil.rmtree(test_dir, ignore_errors=True)


@pytest.fixture
def no_config_env():
    """创建无配置文件环境的fixture"""
    original_dir = os.getcwd()
    test_dir = tempfile.mkdtemp()
    
    os.chdir(test_dir)
    
    os.makedirs("state", exist_ok=True)
    os.makedirs("skills", exist_ok=True)
    
    db_path = Path("state/todos.db")
    conn = sqlite3.connect(str(db_path))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS todos (
            id TEXT PRIMARY KEY,
            content TEXT,
            status TEXT DEFAULT 'pending',
            priority TEXT DEFAULT 'medium',
            sender TEXT,
            receiver TEXT,
            source TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_read INTEGER DEFAULT 0
        )
    """)
    conn.commit()
    conn.close()
    
    yield {
        "test_dir": test_dir,
        "db_path": db_path
    }
    
    os.chdir(original_dir)
    shutil.rmtree(test_dir, ignore_errors=True)


class TestCrossSubsystemTodo:
    """跨子系统TODO测试 - 模拟agent5 → agent1 发送TODO"""
    
    def test_cross_subsystem_todo_creation(self, shared_db_env):
        """TC-CROSS-001: 跨子系统创建TODO (agent5 -> agent1)"""
        env = os.environ.copy()
        env["OC_AGENT_ID"] = "5"
        env["OC_PROJECT_PATH"] = shared_db_env["test_dir"]
        
        cmd = [
            "python3", "-m", "src.cli.main",
            "todowrite",
            "--content", "来自Agent5的跨系统任务",
            "--to", "1"
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env,
            cwd=shared_db_env["test_dir"],
            timeout=10
        )
        
        if result.returncode == 0:
            assert "TODO-5to1-" in result.stdout, "成功时应输出正确的TODO ID (包含发送者和接收者)"
        else:
            assert result.stderr, f"命令失败: {result.stderr}"
    
    def test_cross_subsystem_database_sharing(self, shared_db_env):
        """TC-CROSS-002: 跨子系统数据库共享验证"""
        db_path = shared_db_env["db_path"]
        
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO todos (id, content, sender, receiver, status)
            VALUES (?, ?, ?, ?, ?)
        """, ("TODO-5to1-test-001", "跨系统任务", "5", "1", "pending"))
        
        conn.commit()
        
        cursor.execute("SELECT id, sender, receiver FROM todos WHERE sender = ?", ("5",))
        rows = cursor.fetchall()
        conn.close()
        
        assert len(rows) > 0, "跨子系统数据应写入共享数据库"
        assert rows[0][1] == "5", "sender应为5"
        assert rows[0][2] == "1", "receiver应为1"
    
    def test_cross_subsystem_notification(self, shared_db_env):
        """TC-CROSS-003: 跨子系统通知验证"""
        env = os.environ.copy()
        env["OC_AGENT_ID"] = "5"
        env["OC_PROJECT_PATH"] = shared_db_env["test_dir"]
        
        db_path = shared_db_env["db_path"]
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO todos (id, content, sender, receiver, status, is_read)
            VALUES (?, ?, ?, ?, ?, ?)
        """, ("TODO-cross-notify-001", "跨系统通知测试", "5", "1", "pending", 0))
        conn.commit()
        conn.close()
        
        cmd = [
            "python3", "-m", "src.cli.main",
            "todolist",
            "--unread"
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env,
            cwd=shared_db_env["test_dir"],
            timeout=10
        )
        
        if result.returncode == 0:
            assert "TODO" in result.stdout or "未读" in result.stdout, "成功时应显示未读TODO"
        else:
            assert result.stderr, f"命令失败: {result.stderr}"
    
    def test_cross_subsystem_query_after_create(self, shared_db_env):
        """TC-CROSS-004: 跨子系统查询验证 - 创建后另一个进程查询"""
        import time
        
        db_path = shared_db_env["db_path"]
        
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        todo_id = f"TODO-cross-query-{os.urandom(4).hex()}"
        cursor.execute("""
            INSERT INTO todos (id, content, sender, receiver, status)
            VALUES (?, ?, ?, ?, ?)
        """, (todo_id, "跨系统查询测试", "5", "1", "pending"))
        conn.commit()
        conn.close()
        
        env1 = os.environ.copy()
        env1["OC_AGENT_ID"] = "1"
        env1["OC_PROJECT_PATH"] = shared_db_env["test_dir"]
        
        cmd = [
            "python3", "-m", "src.cli.main",
            "todo", "show", todo_id
        ]
        
        max_retries = 3
        result = None
        for attempt in range(max_retries):
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                env=env1,
                cwd=shared_db_env["test_dir"],
                timeout=10
            )
            
            if result.returncode == 0:
                break
            elif attempt < max_retries - 1:
                time.sleep(0.3)
        
        assert result is not None, "命令未执行"
        
        if result.returncode == 0:
            assert todo_id in result.stdout or "跨系统查询测试" in result.stdout, "成功时应显示TODO详情"
        else:
            assert "not found" in result.stdout.lower() or result.stderr, "未找到时应提示"


class TestFailureScenarios:
    """失败场景测试 - 配置文件缺失、数据库不存在等"""
    
    def test_no_config_file(self, no_config_env):
        """TC-FAIL-001: .oc-collab.yaml不存在时的行为"""
        env = os.environ.copy()
        env["OC_AGENT_ID"] = "1"
        env["OC_PROJECT_PATH"] = no_config_env["test_dir"]
        
        config_file = Path(no_config_env["test_dir"]) / ".oc-collab.yaml"
        if config_file.exists():
            config_file.unlink()
        
        cmd = [
            "python3", "-m", "src.cli.main",
            "todowrite",
            "--content", "测试无配置文件"
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env,
            cwd=no_config_env["test_dir"],
            timeout=10
        )
        
        if result.returncode == 0:
            assert "TODO-" in result.stdout, "成功时应输出TODO ID"
        else:
            assert result.stderr, f"失败时应输出错误信息: {result.stderr}"
    
    def test_no_database_path(self, no_config_env):
        """TC-FAIL-002: 数据库路径不存在时的创建"""
        env = os.environ.copy()
        env["OC_AGENT_ID"] = "1"
        env["OC_PROJECT_PATH"] = no_config_env["test_dir"]
        
        db_path = no_config_env["db_path"]
        if db_path.exists():
            db_path.unlink()
        
        state_dir = Path(no_config_env["test_dir"]) / "state"
        if state_dir.exists():
            shutil.rmtree(state_dir)
        
        cmd = [
            "python3", "-m", "src.cli.main",
            "todowrite",
            "--content", "测试自动创建数据库",
            "--to", "2"
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env,
            cwd=no_config_env["test_dir"],
            timeout=10
        )
        
        assert result.returncode == 0, f"应自动创建数据库: {result.stderr}"
        assert Path(no_config_env["test_dir"]).joinpath("state/todos.db").exists(), \
            "数据库应被自动创建"
    
    def test_unknown_agent_id(self, no_config_env):
        """TC-FAIL-003: Agent ID未知时的fallback"""
        env = os.environ.copy()
        env["OC_AGENT_ID"] = "unknown"
        env["OC_PROJECT_PATH"] = no_config_env["test_dir"]
        
        cmd = [
            "python3", "-m", "src.cli.main",
            "todowrite",
            "--content", "测试未知Agent"
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env,
            cwd=no_config_env["test_dir"],
            timeout=10
        )
        
        assert "TODO-" in result.stdout or result.returncode == 0, \
            f"未知Agent应有fallback处理: {result.stderr}"
    
    def test_invalid_receiver_agent(self, no_config_env):
        """TC-FAIL-004: 接收者Agent不存在"""
        env = os.environ.copy()
        env["OC_AGENT_ID"] = "1"
        env["OC_PROJECT_PATH"] = no_config_env["test_dir"]
        
        cmd = [
            "python3", "-m", "src.cli.main",
            "todowrite",
            "--content", "测试无效接收者",
            "--to", "999"
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env,
            cwd=no_config_env["test_dir"],
            timeout=10
        )
        
        if result.returncode == 0:
            assert "TODO-" in result.stdout, "成功时应输出TODO ID"
        else:
            assert "error" in result.stderr.lower() or result.stdout, "应优雅处理无效接收者"


class TestIdFormatValidation:
    """ID格式验证测试"""
    
    def test_id_format_uuid(self):
        """TC-ID-001: UUID格式ID验证"""
        from src.core.todo_id_generator import TodoIdGenerator
        
        generator = TodoIdGenerator(use_uuid=True)
        
        todo_id = generator.generate(creator="1", receiver="2")
        
        assert todo_id.startswith("TODO-"), f"ID应以TODO-开头: {todo_id}"
        assert "to" in todo_id, f"ID应包含to: {todo_id}"
        assert len(todo_id.split("-")) >= 3, f"ID格式不正确: {todo_id}"
    
    def test_id_format_with_only_sender(self):
        """TC-ID-002: 仅发送者ID格式"""
        from src.core.todo_id_generator import TodoIdGenerator
        
        generator = TodoIdGenerator(use_uuid=True)
        
        todo_id = generator.generate(creator="5")
        
        assert "5" in todo_id, f"ID应包含发送者: {todo_id}"
        assert "tox" in todo_id or "to" in todo_id, f"接收者应为x或空: {todo_id}"
    
    def test_id_format_no_sender_receiver(self):
        """TC-ID-003: 无发送者/接收者格式"""
        from src.core.todo_id_generator import TodoIdGenerator
        
        generator = TodoIdGenerator(use_uuid=True)
        
        todo_id = generator.generate()
        
        assert todo_id.startswith("TODO-"), f"ID应以TODO-开头: {todo_id}"
        assert "tox" in todo_id, f"默认应为tox: {todo_id}"
    
    def test_id_format_legacy(self):
        """TC-ID-004: 旧格式ID验证"""
        from src.core.todo_id_generator import TodoIdGenerator
        
        generator = TodoIdGenerator(use_uuid=False)
        
        todo_id = generator.generate(creator="1", receiver="2")
        
        assert todo_id.startswith("TODO-"), f"ID应以TODO-开头: {todo_id}"
        assert "to" in todo_id, f"ID应包含to: {todo_id}"
        parts = todo_id.split("-")
        assert len(parts) == 3, f"旧格式应有3部分: {todo_id}"
        assert parts[2].isdigit(), f"第三部分应为数字: {todo_id}"
    
    def test_id_uniqueness(self):
        """TC-ID-005: ID唯一性验证"""
        from src.core.todo_id_generator import TodoIdGenerator
        
        generator = TodoIdGenerator(use_uuid=True)
        
        ids = [generator.generate(creator="1", receiver="2") for _ in range(100)]
        
        assert len(set(ids)) == len(ids), "UUID格式应保证唯一性"


class TestTighterAssertions:
    """收紧断言的测试示例 - 修复 MEMO_todo_test_gap_analysis.md 指出的问题"""
    
    def test_todowrite_with_strict_assertion(self, no_config_env):
        """TC-STRICT-001: 严格验证returncode和输出"""
        env = os.environ.copy()
        env["OC_AGENT_ID"] = "1"
        env["OC_PROJECT_PATH"] = no_config_env["test_dir"]
        
        cmd = [
            "python3", "-m", "src.cli.main",
            "todowrite",
            "--content", "严格断言测试",
            "--to", "2"
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env,
            cwd=no_config_env["test_dir"],
            timeout=10
        )
        
        if result.returncode == 0:
            assert "TODO-" in result.stdout, "成功时应输出TODO ID"
        else:
            assert result.stderr, "失败时应输出错误信息"
    
    def test_todolist_verifies_output(self, no_config_env):
        """TC-STRICT-002: 验证todolist输出内容"""
        env = os.environ.copy()
        env["OC_AGENT_ID"] = "1"
        env["OC_PROJECT_PATH"] = no_config_env["test_dir"]
        
        db_path = no_config_env["db_path"]
        conn = sqlite3.connect(str(db_path))
        conn.execute("""
            INSERT INTO todos (id, content, status)
            VALUES (?, ?, ?)
        """, ("TODO-test-strict-001", "测试任务", "pending"))
        conn.commit()
        conn.close()
        
        cmd = [
            "python3", "-m", "src.cli.main",
            "todolist"
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            env=env,
            cwd=no_config_env["test_dir"],
            timeout=10
        )
        
        assert result.returncode == 0, f"命令应成功: {result.stderr}"
        assert "TODO-" in result.stdout or "test" in result.stdout.lower(), \
            "输出应包含TODO或任务内容"
