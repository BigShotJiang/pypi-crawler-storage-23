# Test-Agent 测试平台子系统

**版本**: v1.3.0  
**状态**: 开发中

---

## 一、项目定位

Test-Agent 是独立的测试平台子系统，为 oc-collab 和 PM-Agent 提供隔离的测试环境。

### 1.1 核心能力

| 能力 | 说明 |
|------|------|
| 独立测试数据库 | 隔离生产数据 |
| 多Agent互动测试 | 多进程真实Agent通信 |
| 动态测试项目 | 支持任意类型项目 |
| 测试场景管理 | 定义/执行/记录测试 |
| 前端测试 | 复用PM-Agent Vitest |

### 1.2 技术架构

| 组件 | 技术 |
|------|------|
| 测试执行 | Python CLI |
| 前端测试 | Vitest (复用) |
| 数据库 | SQLite |
| HTTP API客户端 | ConfManClient, OcCollabClient |

### 1.3 HTTP API 客户端

Test-Agent v1.3 提供 HTTP API 客户端，用于与各子系统通信：

| 客户端 | 用途 | 路径 |
|--------|------|------|
| ConfManClient | conf-man 版本管理 | `src/core/conf_man_client.py` |
| OcCollabClient | oc-collab 协作服务 | `src/core/oc_collab_client.py` |

### 1.4 环境变量配置

| 变量 | 说明 | 默认值 |
|------|------|--------|
| CONF_MAN_API_URL | conf-man API 地址 | http://localhost:8000 |
| OC_COLLAB_API_URL | oc-collab API 地址 | http://localhost:8080 |
| OC_PROJECT_PATH | 测试项目路径 | ./ |
| OC_AGENT_ID | Agent标识 | test-agent |

### 1.3 架构分层

```
L1: Test-Agent-core (测试执行框架)
L2: 测试场景编排
L3: 测试Agent管理
```

---

## 二、目录结构

```
test-agent/
├── backend/         # 测试执行后端
├── frontend/       # 测试管理前端 (如需要)
├── tests/          # 测试场景定义
├── docs/           # 项目文档
│   ├── 01-requirements/
│   ├── 02-design/
│   ├── 05-design/
│   ├── 06-roadmap/
│   └── 07-research/
├── state/          # 测试状态数据
└── config/         # 配置文件
```

---

## 三、快速开始

### 3.1 克隆项目

```bash
git clone https://gitee.com/zhang-xiuqin01/test-agent.git
cd test-agent
```

### 3.2 配置 OpenCode

每个项目根目录需要放置 Instruction 文件才能让 OpenCode 正确加载自定义规则：

```bash
# 复制 instruction 模板
cp config/instructions/TODO_NOTIFY.md ./
```

---

## 四、相关文档

- 需求文档: `docs/01-requirements/`
- 设计文档: `docs/02-design/`
- 路线图: `docs/06-roadmap/`
- 研究报告: `docs/07-research/`
- oc-collab主项目: `../dual-agent-collaboration-system`
- PM-Agent项目: `../pm-agent`

---

**作者**: oc-collab团队  
**创建日期**: 2026-02-18
