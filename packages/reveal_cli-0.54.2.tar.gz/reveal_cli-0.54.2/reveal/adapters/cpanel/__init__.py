"""cPanel adapter for inspecting cPanel user environments (cpanel://)."""

from .adapter import CpanelAdapter
from .renderer import CpanelRenderer
