"""ptuner API client – synchronous wrapper around httpx."""

from __future__ import annotations

from typing import Any

import httpx


class PtunerClient:
    """Synchronous client for the ptuner API.

    Authenticate with either a Firebase JWT token or an API key.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8080",
        *,
        api_key: str | None = None,
        token: str | None = None,
        timeout: float = 60.0,
    ) -> None:
        headers: dict[str, str] = {}
        if api_key:
            headers["X-API-Key"] = api_key
        elif token:
            headers["Authorization"] = f"Bearer {token}"

        self._http = httpx.Client(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "PtunerClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── helpers ────────────────────────────────────────────────────────────

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        resp = self._http.request(method, path, **kwargs)
        resp.raise_for_status()
        if resp.status_code == 204 or not resp.content:
            return None
        return resp.json()

    # ── User ───────────────────────────────────────────────────────────────

    def get_me(self) -> dict[str, Any]:
        return self._request("GET", "/me")

    def generate_api_key(self) -> dict[str, Any]:
        return self._request("POST", "/me/api-key")

    # ── Projects ───────────────────────────────────────────────────────────

    def list_projects(self) -> list[dict[str, Any]]:
        return self._request("GET", "/projects")

    def create_project(self, name: str, description: str = "") -> dict[str, Any]:
        return self._request(
            "POST", "/projects", json={"name": name, "description": description}
        )

    def get_project(self, project_id: str) -> dict[str, Any]:
        return self._request("GET", f"/projects/{project_id}")

    def list_members(self, project_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/projects/{project_id}/members")

    def add_member(
        self, project_id: str, email: str, role: str = "editor"
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/projects/{project_id}/members",
            json={"email": email, "role": role},
        )

    # ── Prompts ────────────────────────────────────────────────────────────

    def list_prompts(self, project_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/projects/{project_id}/prompts")

    def create_prompt(self, project_id: str, name: str, slug: str) -> dict[str, Any]:
        return self._request(
            "POST", f"/projects/{project_id}/prompts", json={"name": name, "slug": slug}
        )

    def list_versions(self, prompt_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/prompts/{prompt_id}/versions")

    def create_version(
        self,
        prompt_id: str,
        *,
        system_template: str | None = None,
        message_template: str | None = None,
        json_schema: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a prompt version.

        At least one of *system_template* or *message_template* must be provided.
        *json_schema* is an optional JSON Schema for structured output.
        """
        body: dict[str, Any] = {}
        if system_template is not None:
            body["system_template"] = system_template
        if message_template is not None:
            body["message_template"] = message_template
        if json_schema is not None:
            body["json_schema"] = json_schema
        return self._request(
            "POST",
            f"/prompts/{prompt_id}/versions",
            json=body,
        )

    # ── Datasets ───────────────────────────────────────────────────────────

    def list_datasets(self, project_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/projects/{project_id}/datasets")

    def create_dataset(self, project_id: str, name: str) -> dict[str, Any]:
        return self._request(
            "POST", f"/projects/{project_id}/datasets", json={"name": name}
        )

    def list_datapoints(self, dataset_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/datasets/{dataset_id}/datapoints")

    def create_datapoint(
        self,
        dataset_id: str,
        *,
        system_params: dict[str, Any] | None = None,
        message_params: list[dict[str, Any]] | None = None,
        exact_match_label: str | None = None,
        acceptance_criteria: str | None = None,
        labels: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a datapoint.

        *message_params* is a list of ``{"role": "…", "params": {…}}`` dicts.
        """
        body: dict[str, Any] = {}
        if system_params is not None:
            body["system_params"] = system_params
        if message_params is not None:
            body["message_params"] = message_params
        if exact_match_label is not None:
            body["exact_match_label"] = exact_match_label
        if acceptance_criteria is not None:
            body["acceptance_criteria"] = acceptance_criteria
        if labels is not None:
            body["labels"] = labels
        return self._request("POST", f"/datasets/{dataset_id}/datapoints", json=body)

    def update_datapoint(self, datapoint_id: str, **fields: Any) -> dict[str, Any]:
        return self._request("PUT", f"/datapoints/{datapoint_id}", json=fields)

    def delete_datapoint(self, datapoint_id: str) -> None:
        self._request("DELETE", f"/datapoints/{datapoint_id}")

    # ── LLM Credentials ───────────────────────────────────────────────────

    def list_credentials(self) -> list[dict[str, Any]]:
        return self._request("GET", "/llm-credentials")

    def create_credential(
        self,
        provider: str,
        api_key: str,
        *,
        project_id: str | None = None,
        display_label: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"provider": provider, "api_key": api_key}
        if project_id is not None:
            body["project_id"] = project_id
        if display_label is not None:
            body["display_label"] = display_label
        return self._request("POST", "/llm-credentials", json=body)

    def update_credential(self, credential_id: str, **fields: Any) -> dict[str, Any]:
        return self._request("PUT", f"/llm-credentials/{credential_id}", json=fields)

    def delete_credential(self, credential_id: str) -> None:
        self._request("DELETE", f"/llm-credentials/{credential_id}")

    def resolve_credential(self, project_id: str, provider: str) -> dict[str, Any]:
        return self._request(
            "GET",
            "/llm-credentials/resolve",
            params={"project_id": project_id, "provider": provider},
        )

    # ── Eval Runs ──────────────────────────────────────────────────────────

    def create_eval_run(
        self,
        project_id: str,
        prompt_version_id: str,
        dataset_id: str,
        *,
        model_config: dict[str, Any],
        judge_config: dict[str, Any] | None = None,
        iterations: int = 1,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "project_id": project_id,
            "prompt_version_id": prompt_version_id,
            "dataset_id": dataset_id,
            "model_config": model_config,
            "iterations": iterations,
        }
        if judge_config is not None:
            body["judge_config"] = judge_config
        return self._request("POST", "/eval/run", json=body)

    def get_eval_run(self, run_id: str) -> dict[str, Any]:
        return self._request("GET", f"/eval/runs/{run_id}")

    def list_eval_results(self, run_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/eval/runs/{run_id}/results")

    def list_project_runs(self, project_id: str) -> list[dict[str, Any]]:
        return self._request("GET", f"/projects/{project_id}/runs")
