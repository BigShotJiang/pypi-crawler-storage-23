"""Tests for ptuner using respx to mock httpx requests."""

import pytest
import respx
import httpx

from client.src.ptuner import PtunerClient


BASE = "http://localhost:8080"


@pytest.fixture
def client():
    with PtunerClient(base_url=BASE, api_key="test-key") as c:
        yield c


# ── User ───────────────────────────────────────────────────────────────────────


@respx.mock
def test_get_me(client: PtunerClient):
    respx.get(f"{BASE}/me").mock(
        return_value=httpx.Response(200, json={"id": "abc", "email": "a@b.com"})
    )
    result = client.get_me()
    assert result["email"] == "a@b.com"


@respx.mock
def test_generate_api_key(client: PtunerClient):
    respx.post(f"{BASE}/me/api-key").mock(
        return_value=httpx.Response(200, json={"api_key": "sk-new"})
    )
    result = client.generate_api_key()
    assert result["api_key"] == "sk-new"


# ── Projects ──────────────────────────────────────────────────────────────────


@respx.mock
def test_list_projects(client: PtunerClient):
    respx.get(f"{BASE}/projects").mock(
        return_value=httpx.Response(200, json=[{"id": "p1", "name": "Proj"}])
    )
    result = client.list_projects()
    assert len(result) == 1
    assert result[0]["name"] == "Proj"


@respx.mock
def test_create_project(client: PtunerClient):
    respx.post(f"{BASE}/projects").mock(
        return_value=httpx.Response(201, json={"id": "p1", "name": "New"})
    )
    result = client.create_project("New", "desc")
    assert result["name"] == "New"


@respx.mock
def test_get_project(client: PtunerClient):
    respx.get(f"{BASE}/projects/p1").mock(
        return_value=httpx.Response(200, json={"id": "p1", "name": "Proj"})
    )
    result = client.get_project("p1")
    assert result["id"] == "p1"


@respx.mock
def test_list_members(client: PtunerClient):
    respx.get(f"{BASE}/projects/p1/members").mock(
        return_value=httpx.Response(200, json=[])
    )
    assert client.list_members("p1") == []


@respx.mock
def test_add_member(client: PtunerClient):
    respx.post(f"{BASE}/projects/p1/members").mock(
        return_value=httpx.Response(200, json={"email": "b@b.com", "role": "editor"})
    )
    result = client.add_member("p1", "b@b.com")
    assert result["role"] == "editor"


# ── Prompts ────────────────────────────────────────────────────────────────────


@respx.mock
def test_list_prompts(client: PtunerClient):
    respx.get(f"{BASE}/projects/p1/prompts").mock(
        return_value=httpx.Response(200, json=[])
    )
    assert client.list_prompts("p1") == []


@respx.mock
def test_create_prompt(client: PtunerClient):
    respx.post(f"{BASE}/projects/p1/prompts").mock(
        return_value=httpx.Response(201, json={"id": "pr1", "slug": "classify"})
    )
    result = client.create_prompt("p1", "Classify", "classify")
    assert result["slug"] == "classify"


@respx.mock
def test_list_versions(client: PtunerClient):
    respx.get(f"{BASE}/prompts/pr1/versions").mock(
        return_value=httpx.Response(200, json=[])
    )
    assert client.list_versions("pr1") == []


@respx.mock
def test_create_version(client: PtunerClient):
    respx.post(f"{BASE}/prompts/pr1/versions").mock(
        return_value=httpx.Response(201, json={"id": "v1", "version_number": 1})
    )
    result = client.create_version(
        "pr1",
        system_template="You are a helper.",
        message_template="Hello {{ name }}",
    )
    assert result["version_number"] == 1


# ── Datasets ──────────────────────────────────────────────────────────────────


@respx.mock
def test_list_datasets(client: PtunerClient):
    respx.get(f"{BASE}/projects/p1/datasets").mock(
        return_value=httpx.Response(200, json=[])
    )
    assert client.list_datasets("p1") == []


@respx.mock
def test_create_dataset(client: PtunerClient):
    respx.post(f"{BASE}/projects/p1/datasets").mock(
        return_value=httpx.Response(201, json={"id": "d1", "name": "TestSet"})
    )
    result = client.create_dataset("p1", "TestSet")
    assert result["name"] == "TestSet"


@respx.mock
def test_list_datapoints(client: PtunerClient):
    respx.get(f"{BASE}/datasets/d1/datapoints").mock(
        return_value=httpx.Response(200, json=[])
    )
    assert client.list_datapoints("d1") == []


@respx.mock
def test_create_datapoint(client: PtunerClient):
    respx.post(f"{BASE}/datasets/d1/datapoints").mock(
        return_value=httpx.Response(201, json={"id": "dp1"})
    )
    result = client.create_datapoint(
        "d1",
        message_params=[{"role": "user", "params": {"text": "hi"}}],
        exact_match_label="hello",
    )
    assert result["id"] == "dp1"


@respx.mock
def test_update_datapoint(client: PtunerClient):
    respx.put(f"{BASE}/datapoints/dp1").mock(
        return_value=httpx.Response(200, json={"id": "dp1"})
    )
    result = client.update_datapoint("dp1", exact_match_label="new")
    assert result["id"] == "dp1"


@respx.mock
def test_delete_datapoint(client: PtunerClient):
    respx.delete(f"{BASE}/datapoints/dp1").mock(return_value=httpx.Response(204))
    client.delete_datapoint("dp1")  # should not raise


# ── Credentials ───────────────────────────────────────────────────────────────


@respx.mock
def test_list_credentials(client: PtunerClient):
    respx.get(f"{BASE}/llm-credentials").mock(return_value=httpx.Response(200, json=[]))
    assert client.list_credentials() == []


@respx.mock
def test_create_credential(client: PtunerClient):
    respx.post(f"{BASE}/llm-credentials").mock(
        return_value=httpx.Response(201, json={"id": "c1", "provider": "openai"})
    )
    result = client.create_credential("openai", "sk-test", display_label="My Key")
    assert result["provider"] == "openai"


@respx.mock
def test_update_credential(client: PtunerClient):
    respx.put(f"{BASE}/llm-credentials/c1").mock(
        return_value=httpx.Response(200, json={"id": "c1"})
    )
    result = client.update_credential("c1", display_label="Renamed")
    assert result["id"] == "c1"


@respx.mock
def test_delete_credential(client: PtunerClient):
    respx.delete(f"{BASE}/llm-credentials/c1").mock(return_value=httpx.Response(204))
    client.delete_credential("c1")


@respx.mock
def test_resolve_credential(client: PtunerClient):
    respx.get(f"{BASE}/llm-credentials/resolve").mock(
        return_value=httpx.Response(
            200, json={"provider": "openai", "masked_key": "sk-...abc"}
        )
    )
    result = client.resolve_credential("p1", "openai")
    assert result["masked_key"] == "sk-...abc"


# ── Eval Runs ─────────────────────────────────────────────────────────────────


@respx.mock
def test_create_eval_run(client: PtunerClient):
    respx.post(f"{BASE}/eval/run").mock(
        return_value=httpx.Response(201, json={"id": "r1", "status": "pending"})
    )
    result = client.create_eval_run(
        "p1",
        "v1",
        "d1",
        model_config={"model": "gpt-5-nano", "provider": "openai"},
        judge_config={"judge_model": "gpt-5-nano"},
        iterations=3,
    )
    assert result["status"] == "pending"


@respx.mock
def test_get_eval_run(client: PtunerClient):
    respx.get(f"{BASE}/eval/runs/r1").mock(
        return_value=httpx.Response(200, json={"id": "r1", "status": "completed"})
    )
    result = client.get_eval_run("r1")
    assert result["status"] == "completed"


@respx.mock
def test_list_eval_results(client: PtunerClient):
    respx.get(f"{BASE}/eval/runs/r1/results").mock(
        return_value=httpx.Response(200, json=[{"id": "res1", "judge_score": 0.9}])
    )
    results = client.list_eval_results("r1")
    assert len(results) == 1
    assert results[0]["judge_score"] == 0.9


@respx.mock
def test_list_project_runs(client: PtunerClient):
    respx.get(f"{BASE}/projects/p1/runs").mock(
        return_value=httpx.Response(200, json=[])
    )
    assert client.list_project_runs("p1") == []


# ── Auth Headers ──────────────────────────────────────────────────────────────


@respx.mock
def test_api_key_header():
    route = respx.get(f"{BASE}/me").mock(
        return_value=httpx.Response(200, json={"id": "u1"})
    )
    with PtunerClient(base_url=BASE, api_key="my-key") as c:
        c.get_me()
    assert route.calls[0].request.headers["x-api-key"] == "my-key"


@respx.mock
def test_bearer_token_header():
    route = respx.get(f"{BASE}/me").mock(
        return_value=httpx.Response(200, json={"id": "u1"})
    )
    with PtunerClient(base_url=BASE, token="jwt-token") as c:
        c.get_me()
    assert route.calls[0].request.headers["authorization"] == "Bearer jwt-token"


# ── Error Handling ────────────────────────────────────────────────────────────


@respx.mock
def test_http_error_raises():
    respx.get(f"{BASE}/me").mock(
        return_value=httpx.Response(401, json={"error": "unauthorized"})
    )
    with PtunerClient(base_url=BASE, api_key="bad") as c:
        with pytest.raises(httpx.HTTPStatusError):
            c.get_me()


# ── Context Manager ───────────────────────────────────────────────────────────


def test_context_manager():
    with PtunerClient(base_url=BASE, api_key="k") as c:
        assert isinstance(c, PtunerClient)
    # After exit, client should be closed (internal httpx client closed)
    assert c._http.is_closed
