#!/usr/bin/env python3
"""
Sentiment-classification benchmark for ptuner.

Runs a sentiment-classification evaluation against all configured providers
(Gemini, OpenAI) and compares results side-by-side, including a structured
JSON output test.

Prerequisites:
  1. pip install ptuner
  2. Have an account on https://prompts.church  (sign up via the UI)
  3. Generate an API key in the UI (Settings → Generate API Key)
  4. Set env vars:
       export PTUNER_API_KEY="sk_..."
       export PTUNER_GEMINI_API_KEY="..."     # one-time credential registration
       export PTUNER_OPENAI_API_KEY="..."     # one-time credential registration
     Only PTUNER_API_KEY is required every time. LLM keys are only needed
     once to register credentials — after that the server resolves them.

Usage:
  python benchmark_sentiment.py
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any

from ptuner import PtunerClient

# ── Configuration ────────────────────────────────────────────────────────────


@dataclass
class ModelConfig:
    name: str       # human-readable label, e.g. "Gemini Flash"
    model: str      # model id, e.g. "gemini-2.5-flash"
    provider: str   # provider key, e.g. "google"
    judge_model: str  # model to use as judge


def get_models() -> list[ModelConfig]:
    """Return all models to benchmark. Keys are resolved by the server at runtime."""
    return [
        ModelConfig(
            name="Gemini 2.5 Flash",
            model="gemini-2.5-flash",
            provider="google",
            judge_model="gemini-2.5-flash",
        ),
        ModelConfig(
            name="GPT-5 Nano",
            model="gpt-5-nano",
            provider="openai",
            judge_model="gpt-5-nano",
        ),
    ]


TEST_DATA = [
    # ── Positive (25 datapoints) ──────────────────────────────────────────
    {"text": "This product is absolutely amazing! Best purchase I've ever made.", "label": "positive"},
    {"text": "Exceeded all my expectations, truly wonderful!", "label": "positive"},
    {"text": "Five stars, would buy again in a heartbeat.", "label": "positive"},
    {"text": "The customer service team went above and beyond to help me.", "label": "positive"},
    {"text": "I'm thrilled with the quality — worth every penny.", "label": "positive"},
    {"text": "Incredible value for the price. Highly recommend!", "label": "positive"},
    {"text": "My kids absolutely love this toy, it's been a huge hit.", "label": "positive"},
    {"text": "Smooth checkout process and lightning-fast shipping.", "label": "positive"},
    {"text": "The new update made the app so much better.", "label": "positive"},
    {"text": "Beautifully crafted with attention to every detail.", "label": "positive"},
    {"text": "This restaurant never disappoints — the food was exquisite.", "label": "positive"},
    {"text": "I can't stop recommending this to all my friends.", "label": "positive"},
    {"text": "Perfect fit, perfect color, perfect everything.", "label": "positive"},
    {"text": "The sound quality on these headphones is outstanding.", "label": "positive"},
    {"text": "I've been using this for a year and it still works flawlessly.", "label": "positive"},
    {"text": "What a delightful surprise — exceeded the hype.", "label": "positive"},
    {"text": "The staff were incredibly welcoming and friendly.", "label": "positive"},
    {"text": "This is exactly what I was looking for. Love it!", "label": "positive"},
    {"text": "Great battery life, lasts all day without a charge.", "label": "positive"},
    {"text": "The flavors are rich and perfectly balanced.", "label": "positive"},
    {"text": "I'm genuinely impressed by how well this is built.", "label": "positive"},
    {"text": "Setup was a breeze — took less than five minutes.", "label": "positive"},
    {"text": "My productivity has doubled since I started using this tool.", "label": "positive"},
    {"text": "The view from our hotel room was absolutely breathtaking.", "label": "positive"},
    {"text": "Best birthday gift I've ever received!", "label": "positive"},
    # ── Negative (25 datapoints) ──────────────────────────────────────────
    {"text": "Terrible quality. Broke after one day of use.", "label": "negative"},
    {"text": "Worst purchase I've ever made. Complete waste of money.", "label": "negative"},
    {"text": "The delivery was two weeks late and the box was damaged.", "label": "negative"},
    {"text": "Customer support was rude and completely unhelpful.", "label": "negative"},
    {"text": "The product looks nothing like the photos. Very misleading.", "label": "negative"},
    {"text": "Stopped working after a week. Extremely disappointed.", "label": "negative"},
    {"text": "The food was cold, stale, and tasted awful.", "label": "negative"},
    {"text": "I returned it immediately — total junk.", "label": "negative"},
    {"text": "Overpriced for such low quality. Not worth a single cent.", "label": "negative"},
    {"text": "The app crashes constantly and is full of bugs.", "label": "negative"},
    {"text": "Horrible experience from start to finish.", "label": "negative"},
    {"text": "The stitching came apart after the first wash.", "label": "negative"},
    {"text": "I've never been so frustrated with a product before.", "label": "negative"},
    {"text": "The battery dies within an hour. Completely useless.", "label": "negative"},
    {"text": "Misleading advertising — this does not do what it claims.", "label": "negative"},
    {"text": "The instructions are incomprehensible and the parts don't fit.", "label": "negative"},
    {"text": "I waited 40 minutes for a table and the service was still slow.", "label": "negative"},
    {"text": "Paint started peeling off within days.", "label": "negative"},
    {"text": "The noise level is unbearable — much louder than advertised.", "label": "negative"},
    {"text": "Received the wrong item and still waiting for a replacement.", "label": "negative"},
    {"text": "It smells terrible and the smell won't go away.", "label": "negative"},
    {"text": "The screen has dead pixels right out of the box.", "label": "negative"},
    {"text": "This chair is incredibly uncomfortable for long sitting.", "label": "negative"},
    {"text": "The so-called 'premium' material feels cheap and flimsy.", "label": "negative"},
    {"text": "Refund process was a nightmare. Never ordering again.", "label": "negative"},
    # ── Neutral (25 datapoints) ───────────────────────────────────────────
    {"text": "The package arrived on Tuesday.", "label": "neutral"},
    {"text": "It comes in three sizes: small, medium, and large.", "label": "neutral"},
    {"text": "The product weighs approximately two kilograms.", "label": "neutral"},
    {"text": "Shipping takes five to seven business days.", "label": "neutral"},
    {"text": "The store is open from 9 AM to 6 PM on weekdays.", "label": "neutral"},
    {"text": "This model was released in January 2025.", "label": "neutral"},
    {"text": "The device uses a USB-C charging cable.", "label": "neutral"},
    {"text": "Returns must be initiated within 30 days of purchase.", "label": "neutral"},
    {"text": "The product is available in blue, red, and black.", "label": "neutral"},
    {"text": "Assembly requires a Phillips-head screwdriver.", "label": "neutral"},
    {"text": "The restaurant seats approximately 80 people.", "label": "neutral"},
    {"text": "It runs on two AA batteries, not included.", "label": "neutral"},
    {"text": "The warranty covers manufacturing defects for one year.", "label": "neutral"},
    {"text": "This coffee blend is sourced from Colombia and Ethiopia.", "label": "neutral"},
    {"text": "The bookshelf measures 180 cm tall by 90 cm wide.", "label": "neutral"},
    {"text": "Parking is available behind the building.", "label": "neutral"},
    {"text": "The software update was released last Thursday.", "label": "neutral"},
    {"text": "Each box contains 12 individually wrapped pieces.", "label": "neutral"},
    {"text": "The hotel is located three blocks from the train station.", "label": "neutral"},
    {"text": "This shirt is made of 100% organic cotton.", "label": "neutral"},
    {"text": "The meeting will be held in conference room B.", "label": "neutral"},
    {"text": "The subscription renews automatically each month.", "label": "neutral"},
    {"text": "The app is available on both iOS and Android.", "label": "neutral"},
    {"text": "The event starts at 7 PM and ends around 10 PM.", "label": "neutral"},
    {"text": "The menu includes vegetarian and gluten-free options.", "label": "neutral"},
    # ── Mixed (25 datapoints) ─────────────────────────────────────────────
    {"text": "I love the color but the size is completely wrong.", "label": "mixed"},
    {"text": "Great features but the battery life is terrible.", "label": "mixed"},
    {"text": "The food was delicious but the service was awful.", "label": "mixed"},
    {"text": "Beautiful design, but it broke after a week.", "label": "mixed"},
    {"text": "Loved the story but the ending was disappointing.", "label": "mixed"},
    {"text": "The hotel room was gorgeous, but the noise was unbearable.", "label": "mixed"},
    {"text": "Shipping was fast but the item arrived damaged.", "label": "mixed"},
    {"text": "The app is intuitive but crashes way too often.", "label": "mixed"},
    {"text": "Amazing camera quality, but the phone overheats constantly.", "label": "mixed"},
    {"text": "The taste is wonderful but the portions are tiny for the price.", "label": "mixed"},
    {"text": "Comfortable seats but the legroom is nonexistent.", "label": "mixed"},
    {"text": "The staff were friendly but the wait was over an hour.", "label": "mixed"},
    {"text": "Good sound quality but the microphone picks up everything.", "label": "mixed"},
    {"text": "The course content was excellent but the instructor was boring.", "label": "mixed"},
    {"text": "Nice fabric but the stitching is already coming apart.", "label": "mixed"},
    {"text": "The location is perfect but the rooms are outdated.", "label": "mixed"},
    {"text": "I like the concept but the execution is lacking.", "label": "mixed"},
    {"text": "Powerful engine but the fuel economy is atrocious.", "label": "mixed"},
    {"text": "The plot was gripping but full of historical inaccuracies.", "label": "mixed"},
    {"text": "Tastes great but gives me a headache every time.", "label": "mixed"},
    {"text": "The screen is gorgeous but the speakers are tinny.", "label": "mixed"},
    {"text": "Excellent build quality but the software is frustrating.", "label": "mixed"},
    {"text": "The gym has great equipment but the locker rooms are filthy.", "label": "mixed"},
    {"text": "Love the flavor selection but the packaging leaks.", "label": "mixed"},
    {"text": "The garden is beautiful but the parking situation is a nightmare.", "label": "mixed"},
]


# ── Setup ────────────────────────────────────────────────────────────────────


def create_project(client: PtunerClient) -> dict[str, Any]:
    project = client.create_project(
        name="Sentiment Benchmark", description="Created by benchmark_sentiment.py"
    )
    print(f"✓ Created project: {project['name']} ({project['id']})")
    return project


def create_prompt(client: PtunerClient, project_id: str) -> str:
    prompt = client.create_prompt(
        project_id, name="Sentiment Classifier", slug="sentiment-bench"
    )
    print(f"✓ Created prompt: {prompt['name']} (slug: {prompt['slug']})")
    return prompt["id"]


def create_version(client: PtunerClient, prompt_id: str, mc: ModelConfig) -> str:
    system_template = (
        "You are a sentiment analysis classifier. "
        "Respond with exactly one word: positive, negative, neutral, or mixed."
    )
    message_template = "Text: {{ text }}\n\nSentiment:"
    version = client.create_version(
        prompt_id,
        system_template=system_template,
        message_template=message_template,
    )
    print(f"  ✓ Version v{version['version_number']} → {mc.name} ({version['id']})")
    return version["id"]


def create_json_version(client: PtunerClient, prompt_id: str, mc: ModelConfig) -> str:
    """Create a prompt version that requests structured JSON output."""
    system_template = (
        "You are a sentiment analysis expert. "
        "Return a JSON object with sentiment and confidence."
    )
    message_template = "Text: {{ text }}"
    json_schema = {
        "type": "object",
        "properties": {
            "sentiment": {
                "type": "string",
                "enum": ["positive", "negative", "neutral", "mixed"],
            },
            "confidence": {
                "type": "number",
            },
        },
        "required": ["sentiment", "confidence"],
        "additionalProperties": False,
    }
    version = client.create_version(
        prompt_id,
        system_template=system_template,
        message_template=message_template,
        json_schema=json_schema,
    )
    print(
        f"  ✓ Version v{version['version_number']} → {mc.name} [JSON] ({version['id']})"
    )
    return version["id"]


def create_dataset_with_datapoints(client: PtunerClient, project_id: str) -> str:
    dataset = client.create_dataset(project_id, name="Sentiment Reviews (100)")
    dataset_id = dataset["id"]
    print(f"✓ Created dataset: {dataset['name']} ({dataset_id})")

    for item in TEST_DATA:
        client.create_datapoint(
            dataset_id,
            message_params=[{"role": "user", "params": {"text": item["text"]}}],
            exact_match_label=item["label"],
            acceptance_criteria=(
                "Must classify appropriately as positive, negative, neutral, or mixed "
                "based on the overall sentiment of the text."
            ),
        )

    count = len(client.list_datapoints(dataset_id))
    print(f"✓ Added {count} datapoints")
    return dataset_id


def store_credentials(client: PtunerClient) -> None:
    gemini_key = os.environ.get("PTUNER_GEMINI_API_KEY", "")
    openai_key = os.environ.get("PTUNER_OPENAI_API_KEY", "")

    if gemini_key:
        try:
            cred = client.create_credential(
                provider="google", api_key=gemini_key, display_label="Gemini Key"
            )
            print(f"✓ Stored Google credential ({cred['masked_key']})")
        except Exception as e:
            if "409" in str(e):
                print("  ℹ Google credential already stored — skipping")
            else:
                raise
    else:
        print(
            "  ℹ PTUNER_GEMINI_API_KEY not set — skipping (use UI or a previous run to register)"
        )

    if openai_key:
        try:
            cred = client.create_credential(
                provider="openai", api_key=openai_key, display_label="OpenAI Key"
            )
            print(f"✓ Stored OpenAI credential ({cred['masked_key']})")
        except Exception as e:
            if "409" in str(e):
                print("  ℹ OpenAI credential already stored — skipping")
            else:
                raise
    else:
        print(
            "  ℹ PTUNER_OPENAI_API_KEY not set — skipping (use UI or a previous run to register)"
        )


# ── Run & Results ────────────────────────────────────────────────────────────


def start_eval_run(
    client: PtunerClient,
    project_id: str,
    version_id: str,
    dataset_id: str,
    mc: ModelConfig,
    iterations: int = 2,
) -> str:
    model_config: dict[str, Any] = {
        "model": mc.model,
        "provider": mc.provider,
        "temperature": 0.0,
    }
    run = client.create_eval_run(
        project_id=project_id,
        prompt_version_id=version_id,
        dataset_id=dataset_id,
        model_config=model_config,
        judge_config={"judge_model": mc.judge_model},
        iterations=iterations,
    )
    print(f"✓ Started eval run for {mc.name}: {run['id']} (status: {run['status']})")
    return run["id"]


def wait_for_completion(
    client: PtunerClient, run_id: str, label: str, timeout_s: int = 300
) -> str:
    print(f"  [{label}] Waiting", end="", flush=True)
    deadline = time.time() + timeout_s
    status = "pending"
    while time.time() < deadline:
        time.sleep(2)
        status = client.get_eval_run(run_id)["status"]
        print(".", end="", flush=True)
        if status in ("completed", "failed"):
            break
    print()

    if status == "failed":
        print(f"✗ [{label}] Run failed!")
        raise SystemExit(1)
    if status != "completed":
        print(f"✗ [{label}] Run timed out (status: {status})")
        raise SystemExit(1)

    print(f"✓ [{label}] Completed!")
    return status


def collect_scores(results: list[dict[str, Any]]) -> tuple[list[float], list[float]]:
    exact: list[float] = []
    judge: list[float] = []
    for r in results:
        if r.get("exact_match_score") is not None:
            exact.append(r["exact_match_score"])
        if r.get("judge_score") is not None:
            judge.append(r["judge_score"])
    return exact, judge


def print_results(
    client: PtunerClient, run_id: str, label: str
) -> tuple[list[float], list[float]]:
    results = client.list_eval_results(run_id)
    num_results = len(results)

    print(f"\n{'=' * 70}")
    print(f"  [{label}] {num_results} result rows")
    print(f"{'=' * 70}\n")

    exact_scores, judge_scores = collect_scores(results)

    for r in results:
        output_preview = (r.get("llm_output") or "")[:60]
        print(
            f"  dp={str(r['datapoint_id'])[:8]}… iter={r['iteration_index']} | "
            f'output="{output_preview}" | '
            f"exact={r.get('exact_match_score')} judge={r.get('judge_score')} | "
            f"{r.get('latency_ms')}ms ${r.get('cost_usd')}"
        )

    print(f"\n{'─' * 70}")
    if exact_scores:
        avg = sum(exact_scores) / len(exact_scores)
        print(
            f"  Exact-match accuracy: {avg:.1%}  ({sum(int(s) for s in exact_scores)}/{len(exact_scores)})"
        )
    if judge_scores:
        avg = sum(judge_scores) / len(judge_scores)
        print(f"  Judge avg score:      {avg:.2f}")
    print(f"{'─' * 70}")

    return exact_scores, judge_scores


def print_comparison(
    results_by_model: dict[str, tuple[list[float], list[float]]],
) -> None:
    if len(results_by_model) < 2:
        return

    print(f"\n{'=' * 70}")
    print("  MODEL COMPARISON")
    print(f"{'=' * 70}\n")
    print(f"  {'Model':<25} {'Exact Match':>12} {'Judge Avg':>12}")
    print(f"  {'─' * 25} {'─' * 12} {'─' * 12}")

    for label, (exact, judge) in results_by_model.items():
        em_str = f"{sum(exact) / len(exact):.1%}" if exact else "—"
        js_str = f"{sum(judge) / len(judge):.2f}" if judge else "—"
        print(f"  {label:<25} {em_str:>12} {js_str:>12}")

    print(f"\n{'=' * 70}")


def print_summary(client: PtunerClient, project_id: str, base_url: str) -> None:
    all_runs = client.list_project_runs(project_id)
    print(f"\n✓ Total runs in project: {len(all_runs)}")
    for ar in all_runs:
        print(
            f"  → {ar['id']} | status={ar['status']} | iters={ar['iterations']} | {ar['created_at']}"
        )

    print(f"\n  UI: {base_url.replace('api.', '')}")


# ── Main ─────────────────────────────────────────────────────────────────────


def main() -> None:
    base_url = "https://api.prompts.church"
    api_key = os.environ.get("PTUNER_API_KEY", "")

    if not api_key:
        print("ERROR: Set PTUNER_API_KEY environment variable first.")
        print(
            "  → Log in at https://prompts.church, go to Settings, and generate an API key."
        )
        raise SystemExit(1)

    models = get_models()

    client = PtunerClient(base_url=base_url, api_key=api_key)

    me = client.get_me()
    print(f"✓ Authenticated as {me['email']}")
    print(f"  Models to test: {', '.join(m.name for m in models)}\n")

    # Shared setup
    project = create_project(client)
    prompt_id = create_prompt(client, project["id"])
    dataset_id = create_dataset_with_datapoints(client, project["id"])
    store_credentials(client)

    # Create a version + run for each model
    print("\n── Creating prompt versions ──")
    version_ids: dict[str, str] = {}
    for mc in models:
        version_ids[mc.name] = create_version(client, prompt_id, mc)

    print("\n── Starting eval runs ──")
    run_ids: dict[str, str] = {}
    for mc in models:
        run_ids[mc.name] = start_eval_run(
            client, project["id"], version_ids[mc.name], dataset_id, mc
        )

    # Wait for all runs
    print("\n── Waiting for completion ──")
    for mc in models:
        wait_for_completion(client, run_ids[mc.name], mc.name)

    # Print per-model results
    results_by_model: dict[str, tuple[list[float], list[float]]] = {}
    for mc in models:
        results_by_model[mc.name] = print_results(client, run_ids[mc.name], mc.name)

    # Side-by-side comparison
    print_comparison(results_by_model)

    # ── JSON Structured Output Test ──────────────────────────────────────
    print("\n" + "=" * 70)
    print("  JSON STRUCTURED OUTPUT TEST")
    print("=" * 70)

    json_prompt = client.create_prompt(
        project["id"], name="Sentiment JSON", slug="sentiment-json-bench"
    )
    json_prompt_id = json_prompt["id"]
    print(f"✓ Created JSON prompt: {json_prompt['name']}")

    # Use the first model for the JSON test
    json_mc = models[0]
    json_version_id = create_json_version(client, json_prompt_id, json_mc)

    json_run_id = start_eval_run(
        client,
        project["id"],
        json_version_id,
        dataset_id,
        json_mc,
        iterations=1,
    )
    wait_for_completion(client, json_run_id, f"{json_mc.name} JSON")

    json_results = client.list_eval_results(json_run_id)
    print(f"\n  JSON results ({len(json_results)} rows):")
    json_valid = 0
    for jr in json_results:
        output = jr.get("llm_output") or ""
        try:
            parsed = json.loads(output)
            has_sentiment = "sentiment" in parsed
            has_confidence = "confidence" in parsed
            ok = has_sentiment and has_confidence
            json_valid += int(ok)
            print(
                f"    dp={str(jr['datapoint_id'])[:8]}… "
                f"sentiment={parsed.get('sentiment')} "
                f"confidence={parsed.get('confidence')} "
                f"judge={jr.get('judge_score')} "
                f"valid={ok}"
            )
        except json.JSONDecodeError:
            print(f"    dp={str(jr['datapoint_id'])[:8]}… INVALID JSON: {output[:80]}")

    # Collect judge scores for JSON run
    json_judge_scores = [
        jr["judge_score"] for jr in json_results if jr.get("judge_score") is not None
    ]

    print(f"\n{'─' * 70}")
    print(f"  JSON validity:   {json_valid}/{len(json_results)}")
    if json_judge_scores:
        javg = sum(json_judge_scores) / len(json_judge_scores)
        print(f"  Judge avg score: {javg:.2f}")
    print(f"{'─' * 70}")
    if json_valid < len(json_results):
        print("  ⚠ Some outputs were not valid JSON!")
    else:
        print("  ✓ All outputs are valid structured JSON")
    print("=" * 70)

    print_summary(client, project["id"], base_url)

    client.close()


if __name__ == "__main__":
    main()
