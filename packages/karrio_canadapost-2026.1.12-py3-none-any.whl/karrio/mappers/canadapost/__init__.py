from karrio.mappers.canadapost.mapper import Mapper
from karrio.mappers.canadapost.proxy import Proxy
from karrio.mappers.canadapost.settings import Settings
