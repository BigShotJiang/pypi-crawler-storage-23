import pytest


def test_get_files(job_interface_with_data):
    """Check that the get_files method works as it should"""

    job = job_interface_with_data

    # get files associated with 1st job
    rows = job.get_files(0)
    assert rows == [(1, 14)]

    # get files associated with 2nd job
    rows = job.get_files(1)
    assert rows == [(0, 0), (1, 14)]


def test_get_filedata(job_interface_with_data):
    """Check that the get_file_data method works as it should"""

    job = job_interface_with_data

    # get file data
    df = job.get_filedata(0)

    expected = """  channel  deployment_id end_utc  file_id filename  num_samples relative_path  sample_rate start_utc  storage_id
0    [14]              0     NaT        1  abc.wav        40000                       4000       NaT           0"""
    answer = df[sorted(df.columns)].to_string()
    assert answer == expected
