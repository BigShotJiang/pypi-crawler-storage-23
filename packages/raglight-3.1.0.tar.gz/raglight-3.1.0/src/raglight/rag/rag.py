from __future__ import annotations

from ..cross_encoder.cross_encoder_model import CrossEncoderModel
from ..vectorstore.vector_store import VectorStore
from ..embeddings.embeddings_model import EmbeddingsModel
from ..llm.llm import LLM
from langgraph.graph import START, StateGraph
from typing_extensions import List, TypedDict, Dict
from langchain_core.documents import Document
from typing import Any
import logging

logger = logging.getLogger(__name__)


class State(TypedDict):
    """
    Represents the state of the RAG process.

    Attributes:
        question (str): The input question for the RAG process.
        context (List[Document]): A list of documents retrieved from the vector store as context.
        answer (str): The generated answer based on the input question and context.
        history (List[Dict[str, str]]): The history of the conversation.
    """

    question: str
    answer: str
    context: List[Document] = []
    history: List[Dict[str, str]] = []


class RAG:
    """
    Implementation of a Retrieval-Augmented Generation (RAG) pipeline.

    This class integrates embeddings, a vector store, and a large language model (LLM) to
    retrieve relevant documents and generate answers based on a user's query.

    Attributes:
        embeddings: The embedding model used for vectorization.
        vector_store (VectorStore): The vector store instance for document retrieval.
        llm (LLM): The large language model instance for answer generation.
        k (int, optional): The number of top documents to retrieve. Defaults to 5.
        graph (StateGraph): The state graph that manages the RAG process flow.
    """

    def __init__(
        self,
        embedding_model: EmbeddingsModel,
        vector_store: VectorStore,
        llm: LLM,
        k: int,
        cross_encoder_model: CrossEncoderModel = None,
        stream: bool = False,
    ) -> None:
        """
        Initializes the RAG pipeline.

        Args:
            embedding_model (EmbeddingsModel): The embedding model used for vectorization.
            vector_store (VectorStore): The vector store for retrieving relevant documents.
            llm (LLM): The language model for generating answers.
        """
        self.embeddings: EmbeddingsModel = embedding_model.get_model()
        self.cross_encoder: CrossEncoderModel = (
            cross_encoder_model if cross_encoder_model else None
        )
        self.vector_store: VectorStore = vector_store
        self.llm: LLM = llm
        self.k: int = k
        self.stream: bool = stream
        self.state: State = State(question="", answer="", context=[], history=[])
        self.graph: Any = (
            self._createGraph()
        )  # Here type is CompiledGraph but it's not exposed by https://github.com/langchain-ai/langgraph/blob/main/libs/langgraph/langgraph/graph/graph.py

    def _retrieve(self, state: State) -> Dict[str, List[Document]]:
        """
        Retrieves relevant documents based on the input question.

        Args:
            state (Dict[str, str]): A dictionary containing the input question under the key 'question'.

        Returns:
            Dict[str, List[Document]]: A dictionary containing the retrieved documents under the key 'context'.
        """
        retrieved_docs = self.vector_store.similarity_search(
            state["question"], k=self.k
        )
        return {"context": retrieved_docs, "question": state["question"]}

    def _generate_graph(self, state: Dict[str, List[Document]]) -> Dict[str, str]:
        """
        Generates an answer based on the input question and retrieved context.

        Args:
            state (Dict[str, List[Document]]): A dictionary containing:
                - 'question': The input question.
                - 'context': The list of retrieved documents.

        Returns:
            Dict[str, str]: A dictionary containing the generated answer under the key 'answer'.
        """
        docs_content = "\n\n".join(doc.page_content for doc in state["context"])
        prompt = f"""
            Here is the retrieved context (excerpts from the document):
            {docs_content}

            Here is the question:
            {state["question"]}


            FINAL ANSWER (based only on the context):
            """
        if self.stream:
            response = self.llm.generate_streaming(
                {"question": prompt, "history": state["history"]}
            )
        else:
            response = self.llm.generate(
                {"question": prompt, "history": state["history"]}
            )
            return {"answer": response}

    def _rerank(self, state: Dict[str, List[Document]]) -> Dict[str, List[Document]]:
        """
        Reranks the retrieved documents based on the cross-encoder model.

        Args:
            state (Dict[str, List[Document]]): A dictionary containing the list of retrieved documents under the key 'context'.

        Returns:
            Dict[str, List[Document]]: A dictionary containing the reranked documents under the key 'context'.
        """
        try:
            question = state["question"]
            docs = state["context"]
            doc_texts = [doc.page_content for doc in docs]

            ranked_texts = self.cross_encoder.predict(
                question, doc_texts, int(self.k / 4)
            )

            ranked_docs = [Document(page_content=text) for text in ranked_texts]

        except Exception as e:
            logger.warning(f"Reranking failed: {e}")
            ranked_docs = state["context"]

        return {"context": ranked_docs, "question": state["question"]}

    def _createGraph(self) -> Any:
        """
        Creates and compiles the state graph for the RAG pipeline.

        Returns:
            StateGraph: The compiled state graph for managing the RAG process flow.
        """
        if self.cross_encoder:
            graph_builder = StateGraph(State).add_sequence(
                [self._retrieve, self._rerank, self._generate_graph]
            )
            self.k = 4 * self.k  # Increase retrieval window for reranking
        else:
            graph_builder = StateGraph(State).add_sequence(
                [self._retrieve, self._generate_graph]
            )
        graph_builder.add_edge(START, "_retrieve")
        return graph_builder.compile()

    def generate(self, question: str) -> str:
        """
        Executes the RAG pipeline for a given question.

        Args:
            question (str): The input question.

        Returns:
            str: The generated answer from the pipeline.
        """
        self.state["question"] = question
        response = self.graph.invoke(self.state)
        answer = response["answer"]
        self.state["history"].extend(
            [
                {"role": "user", "content": question},
                {"role": "assistant", "content": answer},
            ]
        )
        return answer
