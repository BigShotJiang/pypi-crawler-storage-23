"""OpenHands evaluation result conversion."""
