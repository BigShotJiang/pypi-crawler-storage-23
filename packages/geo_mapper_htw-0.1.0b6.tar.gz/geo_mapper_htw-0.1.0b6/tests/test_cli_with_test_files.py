from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import pandas as pd
import pytest

from geo_mapper.pipeline.geodata_source import GeodataAsset


ROOT_DIR = Path(__file__).resolve().parent.parent
TEST_FILES_ROOT = ROOT_DIR / "test_files"


class _LocalGeodataRepository:
    """Test-only geodata repository reading from geo_mapper/geodata_clean."""

    def __init__(self, clean_root: Path) -> None:
        self.clean_root = clean_root
        self._temp_root = Path(tempfile.mkdtemp(prefix="geo_mapper_test_geodata_"))
        self._asset_by_source: dict[str, GeodataAsset] = {}

    def get_meta(self) -> dict[str, object]:
        return {
            "supported_types": ["nuts", "lau"],
            "available_types": ["nuts", "lau"],
            "available_formats": ["csv", "geojson"],
        }

    def get_all_nuts_versions(self, file_format: str = "csv") -> list[str]:
        root = self.clean_root / file_format / "NUTS_0"
        if not root.is_dir():
            return []
        return sorted(entry.name for entry in root.iterdir() if entry.is_dir())

    def get_all_lau_versions(self, file_format: str = "csv") -> list[str]:
        root = self.clean_root / file_format / "LAU"
        if not root.is_dir():
            return []
        return sorted(entry.name for entry in root.iterdir() if entry.is_dir())

    def get_nuts_levels(self, file_format: str = "csv") -> list[int]:
        root = self.clean_root / file_format
        levels: list[int] = []
        if not root.is_dir():
            return levels
        for entry in root.iterdir():
            if not entry.is_dir():
                continue
            name = entry.name.upper()
            if not name.startswith("NUTS_"):
                continue
            suffix = name.split("_", 1)[1]
            if suffix.isdigit():
                levels.append(int(suffix))
        return sorted(set(levels))

    def _resolve_source(
        self,
        dataset_type: str,
        file_format: str,
        version: str,
        *,
        level: int | None = None,
        filename: str | None = None,
    ) -> Path:
        ds = dataset_type.lower()
        fmt = file_format.lower()
        if ds == "lau":
            base = self.clean_root / fmt / "LAU" / str(version)
            if filename:
                return base / filename
            matches = sorted(base.glob("*.csv" if fmt == "csv" else "*.geojson"))
            if not matches:
                raise FileNotFoundError(f"No LAU {fmt} file for version {version}")
            return matches[0]

        if ds == "nuts":
            if level is None:
                raise ValueError("NUTS download requires level in tests.")
            base = self.clean_root / fmt / f"NUTS_{int(level)}" / str(version)
            if filename:
                return base / filename
            pattern = f"*level_{int(level)}.{ 'csv' if fmt == 'csv' else 'geojson'}"
            matches = sorted(base.glob(pattern))
            if not matches:
                raise FileNotFoundError(f"No NUTS {fmt} file for version {version} level {level}")
            return matches[0]

        raise ValueError(f"Unsupported dataset type: {dataset_type}")

    def download_data_file(
        self,
        dataset_type: str,
        file_format: str,
        version: str,
        *,
        level: int | None = None,
        filename: str | None = None,
    ) -> GeodataAsset:
        src = self._resolve_source(
            dataset_type,
            file_format,
            version,
            level=level,
            filename=filename,
        )
        ds = dataset_type.lower()
        fmt = file_format.lower()
        dst = self._temp_root / fmt / ds / str(version) / src.name
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        asset = GeodataAsset(
            dataset_type=ds,
            file_format=fmt,
            version=str(version),
            level=None if level is None else int(level),
            filename=src.name,
            local_path=dst,
        )
        self._asset_by_source[str(dst)] = asset
        return asset

    def download_equivalent_format(self, source_path: str | Path, file_format: str) -> GeodataAsset:
        source_asset = self.get_asset_for_local_path(source_path)
        if source_asset is None:
            raise ValueError(f"No source asset for path {source_path}")
        return self.download_data_file(
            source_asset.dataset_type,
            file_format,
            source_asset.version,
            level=source_asset.level,
        )

    def get_asset_for_local_path(self, source_path: str | Path) -> GeodataAsset | None:
        return self._asset_by_source.get(str(Path(source_path)))

    def cleanup_downloads(self) -> None:
        shutil.rmtree(self._temp_root, ignore_errors=True)
        self._asset_by_source.clear()


def _assert_frames_equal_pretty(expected_df: pd.DataFrame, generated_df: pd.DataFrame, label: str) -> None:
    """Assert that two DataFrames are equal, with a compact diff on failure.

    Prints only first differing row/column with expected vs. actual value.
    """
    try:
        pd.testing.assert_frame_equal(
            expected_df,
            generated_df,
            check_dtype=False,
            obj=label,
        )
        return
    except AssertionError:
        pass

    # Basic shape/column check first
    if expected_df.shape != generated_df.shape or list(expected_df.columns) != list(
        generated_df.columns
    ):
        raise AssertionError(
            f"{label}: shape/columns differ – "
            f"expected shape {expected_df.shape} with columns {list(expected_df.columns)}, "
            f"got shape {generated_df.shape} with columns {list(generated_df.columns)}"
        )

    # Find first differing cell (ignoring NaN == NaN)
    diff = expected_df.ne(generated_df)
    both_nan = expected_df.isna() & generated_df.isna()
    diff = diff & ~both_nan

    for row_idx in range(len(expected_df)):
        for col_idx, col_name in enumerate(expected_df.columns):
            if bool(diff.iat[row_idx, col_idx]):
                row_label = expected_df.index[row_idx]
                expected_val = expected_df.iat[row_idx, col_idx]
                actual_val = generated_df.iat[row_idx, col_idx]
                raise AssertionError(
                    f"{label}: first difference at row {row_idx} (index={row_label}), "
                    f"column '{col_name}': expected {expected_val!r}, got {actual_val!r}"
                )

    # Fallback: if we get here, re-raise a generic assertion
    raise AssertionError(f"{label}: DataFrames differ (no first difference located).")


def _discover_cases() -> list[tuple[str, Path, Path, Path]]:
    """Return (case_id, input_file, meta_file, expected_results_dir) for all cases."""
    cases: list[tuple[str, Path, Path, Path]] = []
    if not TEST_FILES_ROOT.is_dir():
        return cases

    # Test cases are stored under test_files/test_XX or test_files/text_XX.
    # Iterate over all subdirectories and filter by this naming convention.
    for test_dir in sorted(TEST_FILES_ROOT.iterdir()):
        if not test_dir.is_dir():
            continue
        if not (test_dir.name.startswith("test_") or test_dir.name.startswith("text_")):
            continue
        for variant_dir in sorted(test_dir.iterdir()):
            if not variant_dir.is_dir():
                continue
            meta_file = variant_dir / "meta.yaml"
            if not meta_file.is_file():
                continue

            input_files = [
                p
                for p in variant_dir.iterdir()
                if p.is_file()
                and p.name != "meta.yaml"
                and not p.name.startswith("results_")
                and p.suffix.lower() in {".csv", ".xlsx", ".xlsm", ".xls"}
            ]
            if not input_files:
                continue
            # Each test variant should have exactly one input file.
            if len(input_files) != 1:
                continue
            input_file = input_files[0]

            result_dirs = [
                p for p in variant_dir.iterdir() if p.is_dir() and p.name.startswith("results_")
            ]
            if len(result_dirs) != 1:
                continue
            expected_results_dir = result_dirs[0]

            case_id = f"{test_dir.name}/{variant_dir.name}"
            cases.append((case_id, input_file, meta_file, expected_results_dir))
    return cases


CASES = _discover_cases()


pytestmark = pytest.mark.filterwarnings(
    "ignore:Workbook contains no default style, apply openpyxl's default:UserWarning"
)


@pytest.mark.parametrize(
    "case_id,input_file,meta_file,expected_results_dir",
    CASES,
)
def test_cli_outputs_match_expected_results(
    case_id: str,
    input_file: Path,
    meta_file: Path,
    expected_results_dir: Path,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Run the CLI for each input/meta pair and compare CSV results."""
    # CLI: --data <input> --yaml <meta> --auto-export-source true
    # Results should be identical to the precomputed CSVs.
    from geo_mapper import cli
    from geo_mapper.pipeline import geodata_source as geodata_source_module
    from geo_mapper.pipeline import manual_mapping as mm  # type: ignore[attr-defined]

    # Patch: disable interactive manual-mapping UIs, but keep meta-based mappings.
    def _no_ui(
        dataframe,  # pd.DataFrame
        mapping_df,  # pd.DataFrame
        geodata_frame,
        source_path: str,
        source_col: str,
    ):
        return mapping_df

    monkeypatch.setattr(mm, "_run_curses_manual_mapping", _no_ui)
    monkeypatch.setattr(mm, "_run_questionary_manual_mapping", _no_ui)

    # Create a separate working copy under tmp_path for each case.
    case_tmp_dir = tmp_path / case_id.replace("/", "_")
    case_tmp_dir.mkdir(parents=True, exist_ok=True)

    tmp_input = case_tmp_dir / input_file.name
    tmp_meta = case_tmp_dir / meta_file.name
    shutil.copy2(input_file, tmp_input)
    shutil.copy2(meta_file, tmp_meta)

    # Use local fixture geodata via a test repository implementation.
    repo = _LocalGeodataRepository(ROOT_DIR / "geo_mapper" / "geodata_clean")
    geodata_source_module.set_geodata_repository(repo)
    try:
        # Call the CLI as the user would.
        argv = [
            "geo-mapper",
            "--data",
            str(tmp_input),
            "--yaml",
            str(tmp_meta),
            "--auto-export-source",
            "true",
        ]
        monkeypatch.setattr("sys.argv", argv)
        cli.main()
    finally:
        geodata_source_module.set_geodata_repository(None)

    # The CLI writes the results to <input_dir>/results_<stem>.
    generated_results_dir = case_tmp_dir / expected_results_dir.name
    assert generated_results_dir.is_dir(), (
        f"[{case_id}] Expected results directory {generated_results_dir} "
        f"to be created by CLI."
    )

    def _load_sorted_csv(path: Path) -> pd.DataFrame:
        df = pd.read_csv(path)
        if not df.columns.empty:
            df = df.sort_values(list(df.columns)).reset_index(drop=True)
        return df

    for filename in ("mapped_pairs.csv", "unmapped_geodata.csv", "unmapped_orginal.csv"):
        expected_path = expected_results_dir / filename
        generated_path = generated_results_dir / filename
        assert expected_path.is_file(), f"[{case_id}] Missing expected file: {expected_path}"
        assert generated_path.is_file(), f"[{case_id}] Missing generated file: {generated_path}"

        expected_df = _load_sorted_csv(expected_path)
        generated_df = _load_sorted_csv(generated_path)

        # Columns and values must match (data types may differ slightly).
        _assert_frames_equal_pretty(
            expected_df,
            generated_df,
            label=f"[{case_id}] {filename}",
        )
