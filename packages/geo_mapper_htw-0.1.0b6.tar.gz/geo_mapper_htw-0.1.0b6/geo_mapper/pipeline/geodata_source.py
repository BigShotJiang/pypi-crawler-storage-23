"""Geodata repository abstraction with a default HTTP API implementation.

The pipeline only talks to this module so the backend can be swapped later
without touching selection/loading/export logic.
"""

from __future__ import annotations

import atexit
import json
import logging
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


logger = logging.getLogger(__name__)

DEFAULT_GEODATA_API_BASE_URL = "http://188.68.48.40:8080"


@dataclass(frozen=True)
class GeodataAsset:
    """Description of one downloaded geodata file."""

    dataset_type: str
    file_format: str
    version: str
    level: int | None
    filename: str
    local_path: Path


class GeodataRepository:
    """Backend contract for geodata version discovery and file downloads."""

    def get_meta(self) -> dict[str, Any]:
        raise NotImplementedError

    def get_all_nuts_versions(self, file_format: str = "csv") -> list[str]:
        raise NotImplementedError

    def get_all_lau_versions(self, file_format: str = "csv") -> list[str]:
        raise NotImplementedError

    def get_nuts_levels(self, file_format: str = "csv") -> list[int]:
        raise NotImplementedError

    def download_data_file(
        self,
        dataset_type: str,
        file_format: str,
        version: str,
        *,
        level: int | None = None,
        filename: str | None = None,
    ) -> GeodataAsset:
        raise NotImplementedError

    def download_equivalent_format(self, source_path: str | Path, file_format: str) -> GeodataAsset:
        raise NotImplementedError

    def get_asset_for_local_path(self, source_path: str | Path) -> GeodataAsset | None:
        raise NotImplementedError

    def cleanup_downloads(self) -> None:
        raise NotImplementedError

    # CamelCase aliases for easier discoverability from external callers.
    def getAllNUTSVersions(self, file_format: str = "csv") -> list[str]:
        return self.get_all_nuts_versions(file_format=file_format)

    def getAllLAUVersions(self, file_format: str = "csv") -> list[str]:
        return self.get_all_lau_versions(file_format=file_format)

    def getNUTSLevels(self, file_format: str = "csv") -> list[int]:
        return self.get_nuts_levels(file_format=file_format)


class HttpGeodataRepository(GeodataRepository):
    """Default repository backed by the geo-mapper mock API."""

    def __init__(self, base_url: str | None = None, *, timeout_seconds: float = 30.0) -> None:
        self._base_url = (
            (base_url or os.getenv("GEO_MAPPER_API_BASE_URL") or DEFAULT_GEODATA_API_BASE_URL)
            .strip()
            .rstrip("/")
        )
        self._timeout_seconds = timeout_seconds
        self._meta_cache: dict[str, Any] | None = None
        self._versions_cache: Dict[Tuple[str, str], dict[str, Any]] = {}
        self._asset_cache: Dict[Tuple[str, str, str, int | None, str | None], GeodataAsset] = {}
        self._assets_by_source: Dict[str, GeodataAsset] = {}
        self._temp_root: Path | None = None
        atexit.register(self.cleanup_downloads)

    def _ensure_temp_root(self) -> Path:
        if self._temp_root is None:
            self._temp_root = Path(tempfile.mkdtemp(prefix="geo_mapper_geodata_"))
        return self._temp_root

    def _build_url(self, endpoint: str, query: dict[str, object] | None = None) -> str:
        endpoint_clean = endpoint if endpoint.startswith("/") else f"/{endpoint}"
        if not query:
            return f"{self._base_url}{endpoint_clean}"
        encoded = urlencode({k: v for k, v in query.items() if v is not None})
        return f"{self._base_url}{endpoint_clean}?{encoded}" if encoded else f"{self._base_url}{endpoint_clean}"

    def _request_json(self, endpoint: str, *, query: dict[str, object] | None = None) -> dict[str, Any]:
        url = self._build_url(endpoint, query)
        request = Request(url, method="GET", headers={"Accept": "application/json"})
        try:
            with urlopen(request, timeout=self._timeout_seconds) as response:
                payload = response.read()
        except HTTPError as exc:
            body = ""
            try:
                body = exc.read().decode("utf-8", errors="replace").strip()
            except Exception:
                body = ""
            message = body or str(exc)
            raise ValueError(f"Geodata API request failed ({exc.code}) for {url}: {message}") from exc
        except URLError as exc:
            raise ConnectionError(
                f"Could not reach geodata API at {self._base_url}: {exc.reason}"
            ) from exc

        try:
            decoded = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError(f"Invalid JSON response from geodata API: {url}") from exc
        if not isinstance(decoded, dict):
            raise ValueError(f"Unexpected geodata API response shape from {url}.")
        return decoded

    def _extract_filename(self, content_disposition: str | None) -> str | None:
        if not content_disposition:
            return None
        match = re.search(r"filename\*?=(?:UTF-8''|\"?)([^\";]+)", content_disposition, flags=re.IGNORECASE)
        if not match:
            return None
        filename = match.group(1).strip()
        filename = filename.strip("\"'")
        return filename or None

    def _download_binary(
        self,
        endpoint: str,
        *,
        query: dict[str, object] | None = None,
        default_filename: str,
    ) -> tuple[Path, str]:
        url = self._build_url(endpoint, query)
        request = Request(url, method="GET")
        try:
            with urlopen(request, timeout=self._timeout_seconds) as response:
                content = response.read()
                filename = self._extract_filename(response.headers.get("Content-Disposition")) or default_filename
        except HTTPError as exc:
            body = ""
            try:
                body = exc.read().decode("utf-8", errors="replace").strip()
            except Exception:
                body = ""
            message = body or str(exc)
            raise ValueError(f"Geodata file download failed ({exc.code}) for {url}: {message}") from exc
        except URLError as exc:
            raise ConnectionError(
                f"Could not download geodata from API at {self._base_url}: {exc.reason}"
            ) from exc

        safe_filename = Path(filename).name or Path(default_filename).name
        base = self._ensure_temp_root()
        target = base / safe_filename
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        return target, safe_filename

    def get_meta(self) -> dict[str, Any]:
        if self._meta_cache is None:
            self._meta_cache = self._request_json("/api/v1/meta")
        return self._meta_cache

    def _versions_payload(self, dataset_type: str, file_format: str) -> dict[str, Any]:
        key = (dataset_type.lower(), file_format.lower())
        if key not in self._versions_cache:
            self._versions_cache[key] = self._request_json(f"/api/v1/versions/{key[0]}/{key[1]}")
        return self._versions_cache[key]

    def get_all_nuts_versions(self, file_format: str = "csv") -> list[str]:
        payload = self._versions_payload("nuts", file_format)
        versions = payload.get("versions", [])
        if not isinstance(versions, list):
            return []
        return [str(v) for v in versions if str(v)]

    def get_all_lau_versions(self, file_format: str = "csv") -> list[str]:
        payload = self._versions_payload("lau", file_format)
        versions = payload.get("versions", [])
        if not isinstance(versions, list):
            return []
        return [str(v) for v in versions if str(v)]

    def get_nuts_levels(self, file_format: str = "csv") -> list[int]:
        payload = self._versions_payload("nuts", file_format)
        levels = payload.get("levels", [])
        if not isinstance(levels, list):
            return []
        normalized: list[int] = []
        for level in levels:
            try:
                normalized.append(int(level))
            except (TypeError, ValueError):
                continue
        return sorted(set(normalized))

    def download_data_file(
        self,
        dataset_type: str,
        file_format: str,
        version: str,
        *,
        level: int | None = None,
        filename: str | None = None,
    ) -> GeodataAsset:
        ds = dataset_type.lower().strip()
        fmt = file_format.lower().strip()
        version_str = str(version).strip()
        level_int = int(level) if level is not None else None
        key = (ds, fmt, version_str, level_int, filename)
        cached = self._asset_cache.get(key)
        if cached is not None and cached.local_path.is_file():
            return cached

        ext = "geojson" if fmt == "geojson" else "csv"
        default_name = filename or (
            f"{ds}_{version_str}_level_{level_int}.{ext}"
            if level_int is not None
            else f"{ds}_{version_str}.{ext}"
        )
        query = {"level": level_int, "filename": filename}
        local_path, resolved_name = self._download_binary(
            f"/api/v1/data/{ds}/{fmt}/{version_str}",
            query=query,
            default_filename=default_name,
        )
        asset = GeodataAsset(
            dataset_type=ds,
            file_format=fmt,
            version=version_str,
            level=level_int,
            filename=resolved_name,
            local_path=local_path,
        )
        self._asset_cache[key] = asset
        self._assets_by_source[str(local_path)] = asset
        logger.debug(
            "Downloaded geodata asset: type=%s format=%s version=%s level=%s file=%s",
            ds,
            fmt,
            version_str,
            level_int,
            local_path,
        )
        return asset

    def download_equivalent_format(self, source_path: str | Path, file_format: str) -> GeodataAsset:
        source_asset = self.get_asset_for_local_path(source_path)
        if source_asset is None:
            raise ValueError(f"No downloaded source metadata found for: {source_path}")
        return self.download_data_file(
            source_asset.dataset_type,
            file_format,
            source_asset.version,
            level=source_asset.level,
        )

    def get_asset_for_local_path(self, source_path: str | Path) -> GeodataAsset | None:
        return self._assets_by_source.get(str(Path(source_path)))

    def cleanup_downloads(self) -> None:
        temp_root = self._temp_root
        self._temp_root = None
        self._asset_cache.clear()
        self._assets_by_source.clear()
        if temp_root and temp_root.exists():
            shutil.rmtree(temp_root, ignore_errors=True)


_REPOSITORY: GeodataRepository | None = None


def get_geodata_repository() -> GeodataRepository:
    """Return the currently configured geodata repository."""
    global _REPOSITORY
    if _REPOSITORY is None:
        _REPOSITORY = HttpGeodataRepository()
    return _REPOSITORY


def set_geodata_repository(repository: GeodataRepository | None) -> None:
    """Replace the active repository (used for backend swaps and tests)."""
    global _REPOSITORY
    if _REPOSITORY is not None and _REPOSITORY is not repository:
        _REPOSITORY.cleanup_downloads()
    _REPOSITORY = repository


def cleanup_geodata_repository_downloads() -> None:
    """Delete all temporary geodata files downloaded during the run."""
    repo = _REPOSITORY
    if repo is None:
        return
    repo.cleanup_downloads()
