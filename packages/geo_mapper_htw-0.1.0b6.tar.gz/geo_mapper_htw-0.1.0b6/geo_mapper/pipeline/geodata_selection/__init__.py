"""Pipeline step that determines which geodata dataset to reference (interactive)."""

from __future__ import annotations

from typing import Optional, List

import pandas as pd
import questionary

from ..storage import (
    set_geodata_type,
    set_geodata_version,
    set_nuts_level,
    get_selections,
)
from ..constants import (
    UNKNOWN_OPTION,
    LEVEL_TITLES,
    LEVEL_VALUES,
    PROMPT_SELECT_GEODATA_LEVEL,
    PROMPT_SELECT_GEODATA_VERSION,
)
from ..geodata_source import get_geodata_repository
from ..utils.ui import DEFAULT_STYLE


def _available_levels() -> list[str]:
    """Return selectable levels based on API metadata/version information."""
    repo = get_geodata_repository()
    levels: list[str] = []
    meta = repo.get_meta()
    available_types_raw = meta.get("available_types", [])
    if isinstance(available_types_raw, list):
        available_types = {str(v).lower() for v in available_types_raw}
    else:
        available_types = {"nuts", "lau"}

    if "nuts" in available_types:
        for level in repo.get_nuts_levels("csv"):
            label = f"NUTS {level}"
            if label in LEVEL_VALUES:
                levels.append(label)
    if "lau" in available_types:
        levels.append("LAU")
    if not levels:
        return list(LEVEL_VALUES)
    return levels


def _available_versions(level_choice: str) -> List[str]:
    """List all available versions for the requested level via API."""
    if level_choice == UNKNOWN_OPTION:
        return []
    repo = get_geodata_repository()
    if level_choice == "LAU":
        return sorted(repo.get_all_lau_versions("csv"))
    if level_choice.startswith("NUTS "):
        try:
            _, level_raw = level_choice.split(" ", 1)
            selected_level = int(level_raw)
        except (TypeError, ValueError):
            return []
        available_nuts_levels = set(repo.get_nuts_levels("csv"))
        if selected_level not in available_nuts_levels:
            return []
        return sorted(repo.get_all_nuts_versions("csv"))
    return []


def _prompt_select(message: str, choices: list[str], default: str) -> str:
    """Ask the user to select one of the provided choices."""
    selection = questionary.select(
        message,
        choices=choices,
        default=default,
        style=DEFAULT_STYLE,
    ).ask()
    if not selection:
        raise SystemExit(f"No choice made for '{message}'.")
    return selection


def _with_unknown(choices: list[str]) -> list[str]:
    """Prepend the 'unknown' option and avoid duplicates."""
    seen = {UNKNOWN_OPTION}
    result = [UNKNOWN_OPTION]
    for choice in choices:
        if choice not in seen and choice:
            seen.add(choice)
            result.append(choice)
    return result


def select_geodata_step(dataframe: pd.DataFrame) -> pd.DataFrame:
    """Prompt the user for the geodata subset they want to use.

    Logic:
    1. Choose an administrative level (NUTS 0–3 or LAU).
    2. Choose the year/version for this level (derived from API metadata).
    """
    # First check whether a meta configuration from JSON already specifies a valid level and year.
    selections = get_selections()
    available_levels = _available_levels()
    meta = getattr(selections, "meta_config", None)
    if isinstance(meta, dict):
        # Support both new keys (geodata_level/geodata_year)
        # and legacy keys (level/year)
        meta_level = meta.get("geodata_level", meta.get("level"))
        meta_year = meta.get("geodata_year", meta.get("year"))
        if isinstance(meta_level, str):
            level_label = meta_level
            upper = level_label.upper().replace("_", " ").strip()
            level_choice_from_meta: Optional[str] = None
            if upper == "LAU":
                level_choice_from_meta = "LAU"
            elif upper.startswith("NUTS"):
                # Accept "NUTS 3", "NUTS3" or similar
                rest = upper.replace("NUTS", "").strip()
                if rest.isdigit():
                    level_choice_from_meta = f"NUTS {rest}"
            if level_choice_from_meta is not None:
                if level_choice_from_meta in available_levels:
                    # Take the level from meta configuration if the API exposes it.
                    if level_choice_from_meta == "LAU":
                        geodata_type = "LAU"
                        nuts_level = UNKNOWN_OPTION
                    else:
                        geodata_type = "NUTS"
                        _, lvl = level_choice_from_meta.split(" ", 1)
                        nuts_level = lvl
                    set_geodata_type(geodata_type)
                    set_nuts_level(nuts_level)

                    # If a valid year is given, use it and skip interactive prompts
                    if isinstance(meta_year, (str, int)):
                        year_str = str(meta_year)
                        available_versions = set(_available_versions(level_choice_from_meta))
                        if year_str in available_versions:
                            set_geodata_version(year_str)
                            return dataframe

                    # No or invalid year: level is fixed, year will be selected interactively.
                    version_choices_raw = _available_versions(level_choice_from_meta)
                    # Build labels that include level and year, e.g. "NUTS 3 2024"
                    label_to_year: dict[str, str] = {
                        f"{level_choice_from_meta} {year}": year for year in version_choices_raw
                    }
                    version_labels: list[str] = list(label_to_year.keys())
                    # First entry: 'unknown'; default ist immer der erste Eintrag
                    version_choices = [UNKNOWN_OPTION, *version_labels] if version_labels else [
                        UNKNOWN_OPTION
                    ]
                    version_default = UNKNOWN_OPTION
                    selected_label = _prompt_select(
                        PROMPT_SELECT_GEODATA_VERSION.format(level=level_choice_from_meta),
                        version_choices,
                        version_default,
                    )
                    if selected_label == UNKNOWN_OPTION:
                        set_geodata_version(UNKNOWN_OPTION)
                    else:
                        set_geodata_version(label_to_year.get(selected_label, UNKNOWN_OPTION))
                    return dataframe

    # Interactive selection of the level – with human-readable descriptions
    try:
        from questionary import Choice
    except ImportError:
        # Fallback without Choice helper: use descriptive labels and map back to internal values
        level_titles = LEVEL_TITLES
        level_values_fallback: List[str] = list(available_levels)
        # Build display labels including the human-readable description
        level_labels = [level_titles[v] for v in level_values_fallback]
        level_choices_fb = _with_unknown(level_labels)
        if "NUTS 3" in level_values_fallback:
            default_label = level_titles.get("NUTS 3", "NUTS 3")
        elif level_labels:
            default_label = level_labels[0]
        else:
            default_label = UNKNOWN_OPTION
        level_choice = _prompt_select(
            PROMPT_SELECT_GEODATA_LEVEL,
            level_choices_fb,
            default_label,
        )
    else:
        level_titles = LEVEL_TITLES
        level_values: List[str] = list(available_levels)
        level_choices = [Choice(title=UNKNOWN_OPTION, value=UNKNOWN_OPTION)]
        for value in level_values:
            title = level_titles.get(value, value)
            level_choices.append(Choice(title=title, value=value))
        # Default: first entry ('unknown')
        default_value = UNKNOWN_OPTION
        level_choice = questionary.select(
            PROMPT_SELECT_GEODATA_LEVEL,
            choices=level_choices,
            default=default_value,
            style=DEFAULT_STYLE,
        ).ask()

    # Map UI labels back to internal level values if needed
    label_to_value = {
        "NUTS 0 (Deutschland gesamt)": "NUTS 0",
        "NUTS 1 (Bundesländer)": "NUTS 1",
        "NUTS 2 (Regionen / Regierungsbezirke)": "NUTS 2",
        "NUTS 3 (Landkreise / kreisfreie Städte)": "NUTS 3",
        "LAU (Gemeinden)": "LAU",
    }
    if level_choice in label_to_value:
        level_choice = label_to_value[level_choice]

    if level_choice == UNKNOWN_OPTION:
        # No restriction: allow both NUTS and LAU and all levels/years
        set_geodata_type(UNKNOWN_OPTION)
        set_nuts_level(UNKNOWN_OPTION)
        set_geodata_version(UNKNOWN_OPTION)
        return dataframe

    if level_choice == "LAU":
        geodata_type = "LAU"
        nuts_level = UNKNOWN_OPTION
    else:
        geodata_type = "NUTS"
        # Expected format: "NUTS X"
        try:
            _, lvl = level_choice.split(" ", 1)
        except ValueError:
            lvl = UNKNOWN_OPTION
        nuts_level = lvl

    set_geodata_type(geodata_type)
    set_nuts_level(nuts_level)

    version_choices_raw = _available_versions(level_choice)
    # Build labels that include level and year, e.g. "NUTS 3 2024"
    label_to_year: dict[str, str] = {
        f"{level_choice} {year}": year for year in version_choices_raw
    }
    version_labels: list[str] = list(label_to_year.keys())
    version_choices = [UNKNOWN_OPTION, *version_labels] if version_labels else [UNKNOWN_OPTION]
    # Default: erster Eintrag ('unknown')
    version_default = UNKNOWN_OPTION
    selected_label = _prompt_select(
        PROMPT_SELECT_GEODATA_VERSION.format(level=level_choice),
        version_choices,
        version_default,
    )
    if selected_label == UNKNOWN_OPTION:
        set_geodata_version(UNKNOWN_OPTION)
    else:
        set_geodata_version(label_to_year.get(selected_label, UNKNOWN_OPTION))

    return dataframe
