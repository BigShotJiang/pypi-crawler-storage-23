"""Pipeline step that downloads and loads matching geodata CSV files."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import pandas as pd

from ..storage import get_selections, set_geodata_frames
from ..constants import (
    DATASET_CHOICES,
    UNKNOWN_OPTION,
    infer_dataset_family,
)
from ..geodata_source import GeodataAsset, get_geodata_repository

logger = logging.getLogger(__name__)


def _ensure_standard_id_column(csv_path: Path, frame: pd.DataFrame) -> pd.DataFrame:
    """Add a canonical 'id' column for datasets that renamed their identifier fields."""

    if "id" in frame.columns:
        return frame

    dataset = infer_dataset_family(csv_path)
    if dataset == "nuts":
        id_source = None
        if "id_nuts" in frame.columns:
            id_source = "id_nuts"
        elif "id_ars" in frame.columns:
            id_source = "id_ars"

        if id_source is not None:
            frame = frame.copy()
            if id_source == "id_nuts" and "id_ars" in frame.columns:
                combined = frame["id_nuts"].copy()
                combined = combined.fillna(frame["id_ars"])
                frame.loc[:, "id"] = combined
            else:
                frame.loc[:, "id"] = frame[id_source]
            logger.debug(
                "Normalized geodata IDs for %s using column '%s'",
                csv_path.name,
                id_source,
            )
    return frame


def _dataset_types_to_load(geodata_type: Optional[str]) -> list[str]:
    if not geodata_type or geodata_type == UNKNOWN_OPTION:
        return [choice.lower() for choice in DATASET_CHOICES]
    return [geodata_type.lower()]


def _versions_for_dataset(dataset: str, version_selection: Optional[str]) -> list[str]:
    repo = get_geodata_repository()
    if version_selection and version_selection != UNKNOWN_OPTION:
        return [version_selection]
    if dataset == "lau":
        return sorted(repo.get_all_lau_versions("csv"))
    if dataset == "nuts":
        return sorted(repo.get_all_nuts_versions("csv"))
    return []


def _nuts_levels_to_load(selection_level: Optional[str]) -> list[int]:
    repo = get_geodata_repository()
    if selection_level and selection_level != UNKNOWN_OPTION:
        try:
            return [int(selection_level)]
        except ValueError:
            return []
    return repo.get_nuts_levels("csv")


def _download_matching_csv_assets() -> list[GeodataAsset]:
    selections = get_selections()
    repo = get_geodata_repository()
    assets: list[GeodataAsset] = []
    seen: set[tuple[str, str, str, int | None]] = set()
    for dataset in _dataset_types_to_load(selections.geodata_type):
        versions = _versions_for_dataset(dataset, selections.geodata_version)
        if dataset == "lau":
            for version in versions:
                key = ("lau", "csv", version, None)
                if key in seen:
                    continue
                seen.add(key)
                assets.append(
                    repo.download_data_file(
                        "lau",
                        "csv",
                        version,
                    )
                )
        elif dataset == "nuts":
            levels = _nuts_levels_to_load(selections.nuts_level)
            for version in versions:
                for level in levels:
                    key = ("nuts", "csv", version, level)
                    if key in seen:
                        continue
                    seen.add(key)
                    assets.append(
                        repo.download_data_file(
                            "nuts",
                            "csv",
                            version,
                            level=level,
                        )
                    )
    return assets


def _report_loading(assets: list[GeodataAsset]) -> None:
    if not assets:
        logger.info("No geodata CSV files matched the selection.")
        return
    logger.info("Loading geodata CSV files from API cache:")

    for asset in assets:
        logger.info("%s", asset.filename)


def load_geodata_files_step(dataframe: pd.DataFrame) -> pd.DataFrame:
    """Load the matching geodata CSV files into memory."""
    assets = _download_matching_csv_assets()
    _report_loading(assets)
    frames: list[tuple[Path, pd.DataFrame]] = []
    for asset in assets:
        csv_path = asset.local_path
        try:
            frame = pd.read_csv(csv_path, dtype=str)
            frame = _ensure_standard_id_column(csv_path, frame)
            frames.append((csv_path, frame))
        except pd.errors.EmptyDataError:
            continue
    set_geodata_frames(frames)
    return dataframe
