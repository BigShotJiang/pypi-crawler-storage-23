"""TokenSense — AI orchestration engine."""

__version__ = "0.1.0"

from .cli import app

__all__ = ["app", "__version__"]
