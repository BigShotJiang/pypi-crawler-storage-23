"""Allow running Personaut CLI via ``python -m personaut``."""

from personaut.cli import main


if __name__ == "__main__":
    main()
