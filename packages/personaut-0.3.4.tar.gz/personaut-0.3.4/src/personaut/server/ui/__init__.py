"""Flask UI package placeholder."""

from __future__ import annotations


__all__: list[str] = []
