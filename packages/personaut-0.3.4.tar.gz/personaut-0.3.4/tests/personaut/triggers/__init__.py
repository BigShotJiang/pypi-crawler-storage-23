"""Tests for Personaut triggers module."""
