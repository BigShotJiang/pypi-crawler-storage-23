"""Tests for Personaut interfaces module."""
