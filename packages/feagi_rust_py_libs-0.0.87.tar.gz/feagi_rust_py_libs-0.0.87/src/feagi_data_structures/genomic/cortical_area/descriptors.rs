//region Cortical Indexing

// Not worth porting numbers

//endregion

//region Channels

// Not worth porting numbers

//endregion

//region Spatial

// TODO NeuronVoxelCoordinate CorticalAreaDimensions CorticalChannelDimensions

//endregion
