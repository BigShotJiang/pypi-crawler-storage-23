use crate::create_trait_parent_pyclass;
create_trait_parent_pyclass!("FeagiSerializable", PyFeagiSerializable);
