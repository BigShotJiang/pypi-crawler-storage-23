"""Packaged assets for Genrepo (e.g., sample YAML)."""
