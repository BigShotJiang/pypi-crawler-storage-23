"""Packaged templates for Genrepo."""
