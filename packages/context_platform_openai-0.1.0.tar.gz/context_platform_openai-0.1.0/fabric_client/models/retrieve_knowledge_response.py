from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.internal_knowledge_column_metadata import InternalKnowledgeColumnMetadata
    from ..models.internal_knowledge_table_metadata import InternalKnowledgeTableMetadata


T = TypeVar("T", bound="RetrieveKnowledgeResponse")


@_attrs_define
class RetrieveKnowledgeResponse:
    """
    Attributes:
        query (str):
        tables (list[InternalKnowledgeTableMetadata]):
        columns (list[InternalKnowledgeColumnMetadata]):
    """

    query: str
    tables: list[InternalKnowledgeTableMetadata]
    columns: list[InternalKnowledgeColumnMetadata]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        query = self.query

        tables = []
        for tables_item_data in self.tables:
            tables_item = tables_item_data.to_dict()
            tables.append(tables_item)

        columns = []
        for columns_item_data in self.columns:
            columns_item = columns_item_data.to_dict()
            columns.append(columns_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "query": query,
                "tables": tables,
                "columns": columns,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.internal_knowledge_column_metadata import InternalKnowledgeColumnMetadata
        from ..models.internal_knowledge_table_metadata import InternalKnowledgeTableMetadata

        d = dict(src_dict)
        query = d.pop("query")

        tables = []
        _tables = d.pop("tables")
        for tables_item_data in _tables:
            tables_item = InternalKnowledgeTableMetadata.from_dict(tables_item_data)

            tables.append(tables_item)

        columns = []
        _columns = d.pop("columns")
        for columns_item_data in _columns:
            columns_item = InternalKnowledgeColumnMetadata.from_dict(columns_item_data)

            columns.append(columns_item)

        retrieve_knowledge_response = cls(
            query=query,
            tables=tables,
            columns=columns,
        )

        retrieve_knowledge_response.additional_properties = d
        return retrieve_knowledge_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
