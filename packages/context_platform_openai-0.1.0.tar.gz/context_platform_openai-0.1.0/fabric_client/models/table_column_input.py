from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.table_column_input_join_hints_type_0 import TableColumnInputJoinHintsType0


T = TypeVar("T", bound="TableColumnInput")


@_attrs_define
class TableColumnInput:
    """
    Attributes:
        name (str):
        column_desc (None | str | Unset):
        column_type (None | str | Unset):
        column_tags (list[str] | Unset):
        join_hints (None | TableColumnInputJoinHintsType0 | Unset):
        is_partition (bool | Unset):  Default: False.
        column_usage_count (int | Unset):  Default: 0.
        column_deprecated (bool | Unset):  Default: False.
    """

    name: str
    column_desc: None | str | Unset = UNSET
    column_type: None | str | Unset = UNSET
    column_tags: list[str] | Unset = UNSET
    join_hints: None | TableColumnInputJoinHintsType0 | Unset = UNSET
    is_partition: bool | Unset = False
    column_usage_count: int | Unset = 0
    column_deprecated: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.table_column_input_join_hints_type_0 import TableColumnInputJoinHintsType0

        name = self.name

        column_desc: None | str | Unset
        if isinstance(self.column_desc, Unset):
            column_desc = UNSET
        else:
            column_desc = self.column_desc

        column_type: None | str | Unset
        if isinstance(self.column_type, Unset):
            column_type = UNSET
        else:
            column_type = self.column_type

        column_tags: list[str] | Unset = UNSET
        if not isinstance(self.column_tags, Unset):
            column_tags = self.column_tags

        join_hints: dict[str, Any] | None | Unset
        if isinstance(self.join_hints, Unset):
            join_hints = UNSET
        elif isinstance(self.join_hints, TableColumnInputJoinHintsType0):
            join_hints = self.join_hints.to_dict()
        else:
            join_hints = self.join_hints

        is_partition = self.is_partition

        column_usage_count = self.column_usage_count

        column_deprecated = self.column_deprecated

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if column_desc is not UNSET:
            field_dict["column_desc"] = column_desc
        if column_type is not UNSET:
            field_dict["column_type"] = column_type
        if column_tags is not UNSET:
            field_dict["column_tags"] = column_tags
        if join_hints is not UNSET:
            field_dict["join_hints"] = join_hints
        if is_partition is not UNSET:
            field_dict["is_partition"] = is_partition
        if column_usage_count is not UNSET:
            field_dict["column_usage_count"] = column_usage_count
        if column_deprecated is not UNSET:
            field_dict["column_deprecated"] = column_deprecated

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.table_column_input_join_hints_type_0 import TableColumnInputJoinHintsType0

        d = dict(src_dict)
        name = d.pop("name")

        def _parse_column_desc(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        column_desc = _parse_column_desc(d.pop("column_desc", UNSET))

        def _parse_column_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        column_type = _parse_column_type(d.pop("column_type", UNSET))

        column_tags = cast(list[str], d.pop("column_tags", UNSET))

        def _parse_join_hints(data: object) -> None | TableColumnInputJoinHintsType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                join_hints_type_0 = TableColumnInputJoinHintsType0.from_dict(data)

                return join_hints_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TableColumnInputJoinHintsType0 | Unset, data)

        join_hints = _parse_join_hints(d.pop("join_hints", UNSET))

        is_partition = d.pop("is_partition", UNSET)

        column_usage_count = d.pop("column_usage_count", UNSET)

        column_deprecated = d.pop("column_deprecated", UNSET)

        table_column_input = cls(
            name=name,
            column_desc=column_desc,
            column_type=column_type,
            column_tags=column_tags,
            join_hints=join_hints,
            is_partition=is_partition,
            column_usage_count=column_usage_count,
            column_deprecated=column_deprecated,
        )

        table_column_input.additional_properties = d
        return table_column_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
