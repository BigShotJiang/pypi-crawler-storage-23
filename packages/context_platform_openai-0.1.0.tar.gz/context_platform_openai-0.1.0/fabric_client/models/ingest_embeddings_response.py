from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="IngestEmbeddingsResponse")


@_attrs_define
class IngestEmbeddingsResponse:
    """
    Attributes:
        status (str):
        source (str):
        documents_indexed (int):
    """

    status: str
    source: str
    documents_indexed: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        status = self.status

        source = self.source

        documents_indexed = self.documents_indexed

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
                "source": source,
                "documents_indexed": documents_indexed,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = d.pop("status")

        source = d.pop("source")

        documents_indexed = d.pop("documents_indexed")

        ingest_embeddings_response = cls(
            status=status,
            source=source,
            documents_indexed=documents_indexed,
        )

        ingest_embeddings_response.additional_properties = d
        return ingest_embeddings_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
