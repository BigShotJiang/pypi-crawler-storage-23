from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.unstructured_file_input_metadata_type_0 import UnstructuredFileInputMetadataType0


T = TypeVar("T", bound="UnstructuredFileInput")


@_attrs_define
class UnstructuredFileInput:
    """
    Attributes:
        file_id (str):
        source (None | str | Unset):
        relative_path (None | str | Unset):
        title (None | str | Unset):
        summary (None | str | Unset):
        vector_id (None | str | Unset):
        tags (list[str] | Unset):
        metadata (None | Unset | UnstructuredFileInputMetadataType0):
        content_excerpt (None | str | Unset):
    """

    file_id: str
    source: None | str | Unset = UNSET
    relative_path: None | str | Unset = UNSET
    title: None | str | Unset = UNSET
    summary: None | str | Unset = UNSET
    vector_id: None | str | Unset = UNSET
    tags: list[str] | Unset = UNSET
    metadata: None | Unset | UnstructuredFileInputMetadataType0 = UNSET
    content_excerpt: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.unstructured_file_input_metadata_type_0 import UnstructuredFileInputMetadataType0

        file_id = self.file_id

        source: None | str | Unset
        if isinstance(self.source, Unset):
            source = UNSET
        else:
            source = self.source

        relative_path: None | str | Unset
        if isinstance(self.relative_path, Unset):
            relative_path = UNSET
        else:
            relative_path = self.relative_path

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        summary: None | str | Unset
        if isinstance(self.summary, Unset):
            summary = UNSET
        else:
            summary = self.summary

        vector_id: None | str | Unset
        if isinstance(self.vector_id, Unset):
            vector_id = UNSET
        else:
            vector_id = self.vector_id

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, UnstructuredFileInputMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        content_excerpt: None | str | Unset
        if isinstance(self.content_excerpt, Unset):
            content_excerpt = UNSET
        else:
            content_excerpt = self.content_excerpt

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "file_id": file_id,
            }
        )
        if source is not UNSET:
            field_dict["source"] = source
        if relative_path is not UNSET:
            field_dict["relative_path"] = relative_path
        if title is not UNSET:
            field_dict["title"] = title
        if summary is not UNSET:
            field_dict["summary"] = summary
        if vector_id is not UNSET:
            field_dict["vector_id"] = vector_id
        if tags is not UNSET:
            field_dict["tags"] = tags
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if content_excerpt is not UNSET:
            field_dict["content_excerpt"] = content_excerpt

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.unstructured_file_input_metadata_type_0 import UnstructuredFileInputMetadataType0

        d = dict(src_dict)
        file_id = d.pop("file_id")

        def _parse_source(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source = _parse_source(d.pop("source", UNSET))

        def _parse_relative_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        relative_path = _parse_relative_path(d.pop("relative_path", UNSET))

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_summary(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        summary = _parse_summary(d.pop("summary", UNSET))

        def _parse_vector_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        vector_id = _parse_vector_id(d.pop("vector_id", UNSET))

        tags = cast(list[str], d.pop("tags", UNSET))

        def _parse_metadata(data: object) -> None | Unset | UnstructuredFileInputMetadataType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = UnstructuredFileInputMetadataType0.from_dict(data)

                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UnstructuredFileInputMetadataType0, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        def _parse_content_excerpt(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content_excerpt = _parse_content_excerpt(d.pop("content_excerpt", UNSET))

        unstructured_file_input = cls(
            file_id=file_id,
            source=source,
            relative_path=relative_path,
            title=title,
            summary=summary,
            vector_id=vector_id,
            tags=tags,
            metadata=metadata,
            content_excerpt=content_excerpt,
        )

        unstructured_file_input.additional_properties = d
        return unstructured_file_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
