from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="InternalKnowledgeTableMetadata")


@_attrs_define
class InternalKnowledgeTableMetadata:
    """
    Attributes:
        fully_qualified_name (str):
        table_desc (None | str | Unset):
        table_type (None | str | Unset):
        table_tags (list[str] | Unset):
        table_usage_count (int | Unset):  Default: 0.
        table_deprecated (bool | Unset):  Default: False.
    """

    fully_qualified_name: str
    table_desc: None | str | Unset = UNSET
    table_type: None | str | Unset = UNSET
    table_tags: list[str] | Unset = UNSET
    table_usage_count: int | Unset = 0
    table_deprecated: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        fully_qualified_name = self.fully_qualified_name

        table_desc: None | str | Unset
        if isinstance(self.table_desc, Unset):
            table_desc = UNSET
        else:
            table_desc = self.table_desc

        table_type: None | str | Unset
        if isinstance(self.table_type, Unset):
            table_type = UNSET
        else:
            table_type = self.table_type

        table_tags: list[str] | Unset = UNSET
        if not isinstance(self.table_tags, Unset):
            table_tags = self.table_tags

        table_usage_count = self.table_usage_count

        table_deprecated = self.table_deprecated

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "fully_qualified_name": fully_qualified_name,
            }
        )
        if table_desc is not UNSET:
            field_dict["table_desc"] = table_desc
        if table_type is not UNSET:
            field_dict["table_type"] = table_type
        if table_tags is not UNSET:
            field_dict["table_tags"] = table_tags
        if table_usage_count is not UNSET:
            field_dict["table_usage_count"] = table_usage_count
        if table_deprecated is not UNSET:
            field_dict["table_deprecated"] = table_deprecated

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        fully_qualified_name = d.pop("fully_qualified_name")

        def _parse_table_desc(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        table_desc = _parse_table_desc(d.pop("table_desc", UNSET))

        def _parse_table_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        table_type = _parse_table_type(d.pop("table_type", UNSET))

        table_tags = cast(list[str], d.pop("table_tags", UNSET))

        table_usage_count = d.pop("table_usage_count", UNSET)

        table_deprecated = d.pop("table_deprecated", UNSET)

        internal_knowledge_table_metadata = cls(
            fully_qualified_name=fully_qualified_name,
            table_desc=table_desc,
            table_type=table_type,
            table_tags=table_tags,
            table_usage_count=table_usage_count,
            table_deprecated=table_deprecated,
        )

        internal_knowledge_table_metadata.additional_properties = d
        return internal_knowledge_table_metadata

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
