from typing import TypeVar


ExpectedType = TypeVar('ExpectedType')
