"""Unit tests for LanceDB store — DB operations use a real in-memory/tmp table."""
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from alaya.index.embedder import Chunk, chunk_note
from alaya.index.store import upsert_note, delete_note_from_index, hybrid_search, VaultStore, get_store, reset_store, _sq, _sq_like


def _make_chunks(path: str, text: str = "Some content about kubernetes and helm.") -> list[Chunk]:
    return [
        Chunk(
            path=path,
            title=path.split("/")[-1].replace(".md", ""),
            tags=["test"],
            directory=path.split("/")[0],
            modified_date="2026-02-01",
            chunk_index=0,
            text=text,
        )
    ]


def _fake_embeddings(chunks: list[Chunk]) -> list[np.ndarray]:
    return [np.random.rand(768).astype(np.float32) for _ in chunks]


class TestUpsertNote:
    def test_note_indexed_and_retrievable(self, vault: Path, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        chunks = _make_chunks("resources/kubernetes-notes.md")
        embeddings = _fake_embeddings(chunks)
        upsert_note("resources/kubernetes-notes.md", chunks, embeddings, store)
        assert store.count() == 1

    def test_upsert_replaces_existing_chunks(self, vault: Path, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        chunks_v1 = _make_chunks("resources/kubernetes-notes.md", "Version 1 content.")
        chunks_v2 = _make_chunks("resources/kubernetes-notes.md", "Version 2 content.")

        upsert_note("resources/kubernetes-notes.md", chunks_v1, _fake_embeddings(chunks_v1), store)
        upsert_note("resources/kubernetes-notes.md", chunks_v2, _fake_embeddings(chunks_v2), store)

        assert store.count() == 1  # replaced, not doubled

    def test_multiple_notes_indexed(self, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        for path in ["projects/second-brain.md", "resources/kubernetes-notes.md"]:
            chunks = _make_chunks(path)
            upsert_note(path, chunks, _fake_embeddings(chunks), store)
        assert store.count() == 2


class TestDeleteNoteFromIndex:
    def test_removes_chunks_for_path(self, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        chunks = _make_chunks("ideas/voice-capture.md")
        upsert_note("ideas/voice-capture.md", chunks, _fake_embeddings(chunks), store)
        assert store.count() == 1

        delete_note_from_index("ideas/voice-capture.md", store)
        assert store.count() == 0

    def test_delete_nonexistent_is_noop(self, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        # should not raise
        delete_note_from_index("ideas/ghost.md", store)

    def test_path_with_single_quote_does_not_crash(self, tmp_path: Path) -> None:
        # Single quotes in paths must be escaped to avoid malformed filter expressions.
        store = VaultStore(tmp_path / "lance")
        path = "ideas/it's-complicated.md"
        chunks = _make_chunks(path)
        upsert_note(path, chunks, _fake_embeddings(chunks), store)
        assert store.count() == 1
        # Must not raise or leave ghost entries
        delete_note_from_index(path, store)
        assert store.count() == 0


class TestHybridSearch:
    def test_returns_results(self, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        chunks = _make_chunks("resources/kubernetes-notes.md", "kubernetes helm charts argocd")
        embeddings = _fake_embeddings(chunks)
        upsert_note("resources/kubernetes-notes.md", chunks, embeddings, store)

        query_embedding = np.random.rand(768).astype(np.float32)
        results = hybrid_search("kubernetes", query_embedding, store, limit=5)
        assert isinstance(results, list)

    def test_empty_index_returns_empty(self, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        query_embedding = np.random.rand(768).astype(np.float32)
        results = hybrid_search("anything", query_embedding, store, limit=5)
        assert results == []

    def test_directory_filter_applied(self, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        for path, text in [
            ("resources/kubernetes-notes.md", "kubernetes content"),
            ("projects/second-brain.md", "project content"),
        ]:
            chunks = _make_chunks(path, text)
            upsert_note(path, chunks, _fake_embeddings(chunks), store)

        query_embedding = np.random.rand(768).astype(np.float32)
        results = hybrid_search("content", query_embedding, store, directory="resources", limit=5)
        for r in results:
            assert r["directory"] == "resources"

    def test_tags_filter_excludes_non_matching(self, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        # kubernetes note has tag 'kubernetes'; project note has tag 'project'
        k_chunks = [Chunk(
            path="resources/kubernetes-notes.md",
            title="kubernetes-notes",
            tags=["kubernetes", "reference"],
            directory="resources",
            modified_date="2026-02-01",
            chunk_index=0,
            text="kubernetes helm charts",
        )]
        p_chunks = [Chunk(
            path="projects/second-brain.md",
            title="second-brain",
            tags=["project"],
            directory="projects",
            modified_date="2026-02-23",
            chunk_index=0,
            text="project planning content",
        )]
        upsert_note("resources/kubernetes-notes.md", k_chunks, _fake_embeddings(k_chunks), store)
        upsert_note("projects/second-brain.md", p_chunks, _fake_embeddings(p_chunks), store)

        query_embedding = np.random.rand(768).astype(np.float32)
        results = hybrid_search("content", query_embedding, store, tags=["kubernetes"], limit=5)
        # every result should come from the kubernetes note (tag filter applied)
        for r in results:
            assert "kubernetes" in r["path"]


class TestGetStore:
    def test_returns_same_instance_for_same_vault(self, tmp_path: Path) -> None:
        reset_store()
        s1 = get_store(tmp_path)
        s2 = get_store(tmp_path)
        assert s1 is s2

    def test_returns_different_instance_for_different_vault(self, tmp_path: Path) -> None:
        reset_store()
        vault_a = tmp_path / "vault_a"
        vault_b = tmp_path / "vault_b"
        vault_a.mkdir()
        vault_b.mkdir()
        s1 = get_store(vault_a)
        s2 = get_store(vault_b)
        assert s1 is not s2

    def test_reset_store_clears_cache(self, tmp_path: Path) -> None:
        reset_store()
        s1 = get_store(tmp_path)
        reset_store()
        s2 = get_store(tmp_path)
        assert s1 is not s2


class TestSqlEscape:
    """Verify _sq centralises SQL filter escaping correctly."""

    def test_plain_string_unchanged(self):
        assert _sq("projects/foo.md") == "projects/foo.md"

    def test_single_quote_doubled(self):
        assert _sq("it's/note.md") == "it''s/note.md"

    def test_multiple_single_quotes(self):
        assert _sq("a'b'c") == "a''b''c"

    def test_double_quote_untouched(self):
        # double quotes are not special in SQL string literals
        assert _sq('say "hello"') == 'say "hello"'

    def test_unicode_apostrophe_not_confused(self):
        # U+2019 RIGHT SINGLE QUOTATION MARK — not the same as ASCII '
        assert _sq("it\u2019s") == "it\u2019s"

    def test_empty_string(self):
        assert _sq("") == ""

    def test_backslash_untouched(self):
        assert _sq("path\\to\\file") == "path\\to\\file"


class TestSqlLikeEscape:
    """_sq_like must escape LIKE wildcards in addition to single quotes."""

    def test_plain_string_unchanged(self):
        assert _sq_like("kubernetes") == "kubernetes"

    def test_percent_escaped(self):
        assert _sq_like("%") == "\\%"

    def test_underscore_escaped(self):
        assert _sq_like("_") == "\\_"

    def test_single_quote_doubled(self):
        assert _sq_like("it's") == "it''s"

    def test_combined_wildcards_and_quote(self):
        assert _sq_like("%_it's_%") == "\\%\\_it''s\\_\\%"

    def test_empty_string(self):
        assert _sq_like("") == ""

    def test_normal_tag_unchanged(self):
        assert _sq_like("kubernetes") == "kubernetes"


class TestSchemaMigration:
    """VaultStore drops and recreates the table on schema mismatch, then sets needs_reindex."""

    def test_schema_mismatch_raises_value_error_drops_and_recreates(self, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        fake_table = MagicMock()
        fake_db = MagicMock()

        call_count = {"n": 0}

        def create_table_side_effect(*args, **kwargs):
            call_count["n"] += 1
            if call_count["n"] == 1:
                raise ValueError("Schema mismatch")
            return fake_table

        fake_db.create_table.side_effect = create_table_side_effect

        with patch.object(store, "_connect", return_value=fake_db):
            table = store._get_table()

        fake_db.drop_table.assert_called_once_with("notes")
        assert call_count["n"] == 2
        assert table is fake_table
        assert store.take_needs_reindex() is True

    def test_take_needs_reindex_clears_flag(self, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        fake_table = MagicMock()
        fake_db = MagicMock()

        call_count = {"n": 0}

        def create_table_side_effect(*args, **kwargs):
            call_count["n"] += 1
            if call_count["n"] == 1:
                raise ValueError("Schema mismatch")
            return fake_table

        fake_db.create_table.side_effect = create_table_side_effect

        with patch.object(store, "_connect", return_value=fake_db):
            store._get_table()

        assert store.take_needs_reindex() is True
        assert store.take_needs_reindex() is False

    def test_no_mismatch_needs_reindex_false(self, tmp_path: Path) -> None:
        store = VaultStore(tmp_path / "lance")
        fake_table = MagicMock()
        fake_db = MagicMock()
        fake_db.create_table.return_value = fake_table

        with patch.object(store, "_connect", return_value=fake_db):
            store._get_table()

        assert store.take_needs_reindex() is False


class TestGetStoreConcurrency:
    """get_store() must return the same instance under concurrent first-time calls."""

    def test_concurrent_get_store_returns_same_instance(self, tmp_path):
        import threading
        from alaya.index.store import get_store, reset_store

        reset_store()
        results = []
        errors = []
        barrier = threading.Barrier(10)

        def fetch():
            try:
                barrier.wait()
                results.append(get_store(tmp_path))
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=fetch) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        # All threads must have received the exact same instance
        assert len(results) == 10
        assert all(s is results[0] for s in results), "Multiple VaultStore instances created"
