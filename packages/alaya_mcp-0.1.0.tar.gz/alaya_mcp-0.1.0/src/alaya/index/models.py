"""Embedding model registry for alaya."""
from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class EmbeddingModelConfig:
    key: str  # unique registry key used for identity comparisons
    name: str  # HuggingFace model name passed to fastembed
    file_name: str | None
    dimensions: int
    search_prefix: str
    document_prefix: str
    supports_late_chunking: bool = False  # model supports contextual chunk embeddings


MODELS: dict[str, EmbeddingModelConfig] = {
    "nomic-v1.5": EmbeddingModelConfig(
        key="nomic-v1.5",
        name="nomic-ai/nomic-embed-text-v1.5",
        file_name=None,  # fastembed default (model.onnx)
        dimensions=768,
        search_prefix="search_query: ",
        document_prefix="search_document: ",
    ),
    "nomic-v1.5-q4": EmbeddingModelConfig(
        key="nomic-v1.5-q4",
        name="nomic-ai/nomic-embed-text-v1.5",
        file_name="onnx/model_q4.onnx",
        dimensions=768,
        search_prefix="search_query: ",
        document_prefix="search_document: ",
    ),
    "jina-v3": EmbeddingModelConfig(
        key="jina-v3",
        name="jinaai/jina-embeddings-v3",
        file_name=None,
        dimensions=1024,
        search_prefix="",
        document_prefix="",
        supports_late_chunking=True,
    ),
}

DEFAULT_MODEL_KEY = "nomic-v1.5"


def get_active_model() -> EmbeddingModelConfig:
    """Return the active model config from ALAYA_EMBEDDING_MODEL env var, or the default."""
    key = os.environ.get("ALAYA_EMBEDDING_MODEL", DEFAULT_MODEL_KEY)
    if key not in MODELS:
        raise ValueError(f"Unknown embedding model {key!r}. Available: {sorted(MODELS)}")
    return MODELS[key]
