"""
GEO Optimizer Web Demo — FastAPI micro-servizio.

Punto di ingresso zero-attrito per audit GEO senza installazione.

Avvio:
    pip install geo-optimizer-skill[web]
    geo-web
    # oppure: uvicorn geo_optimizer.web.app:app --reload
"""
