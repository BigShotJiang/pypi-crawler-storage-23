import time
import sys
import os
import threading

_SPINNER_FRAMES = ['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏']

class spinner_context:
    def __init__(self, text, printer):
        self.text    = text
        self.printer = printer
        self._idx    = 0
        self.running = False
        self.thread  = None

    def __enter__(self):
        self.running = True
        self.thread  = threading.Thread(target=self._spin, daemon=True)
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.running = False
        if self.thread:
            self.thread.join()
        sys.stdout.write('\r' + ' ' * (len(self.text) + 4) + '\r')
        sys.stdout.flush()

    def _spin(self):
        while self.running:
            frame = _SPINNER_FRAMES[self._idx % len(_SPINNER_FRAMES)]
            sys.stdout.write(f'\r{frame} {self.text}')
            sys.stdout.flush()
            self._idx += 1
            time.sleep(0.1)


def _term_cols():
    try:
        return os.get_terminal_size().columns
    except Exception:
        return 80


class progress_bar:
    def __init__(self, iterable, desc, printer):
        self.iterable = iterable
        self.desc     = desc
        self.printer  = printer
        self.total    = len(iterable) if hasattr(iterable, '__len__') else None

    def __iter__(self):
        width = max(20, _term_cols() - len(self.desc) - 20)

        if self.total:
            for i, item in enumerate(self.iterable):
                pct  = (i+1) / self.total
                done = int(pct * width)
                bar  = '█' * done + '░' * (width - done)
                sys.stdout.write(f'\r{self.desc}: [{bar}] {pct*100:.1f}%')
                sys.stdout.flush()
                yield item
            sys.stdout.write('\n')
            sys.stdout.flush()
        else:
            for i, item in enumerate(self.iterable):
                sys.stdout.write(f'\r{self.desc}: {i+1}')
                sys.stdout.flush()
                yield item
            sys.stdout.write('\n')
            sys.stdout.flush()


def typewrite(text: str, delay: float = 0.05, end: str = '\n'):
    for ch in text:
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(delay)
    sys.stdout.write(end)
    sys.stdout.flush()


def countdown(n: int, prefix: str = '', end_msg: str = 'Готово!'):
    for i in range(n, 0, -1):
        sys.stdout.write(f'\r{prefix}{i}  ')
        sys.stdout.flush()
        time.sleep(1)
    sys.stdout.write(f'\r{prefix}{end_msg}   \n')
    sys.stdout.flush()


def clear_line():
    sys.stdout.write('\r\033[K')
    sys.stdout.flush()


def clear_screen():
    sys.stdout.write('\033[2J\033[H')
    sys.stdout.flush()


def animate(text, frames=None, printer=None):
    if frames is None:
        frames = ['◴','◷','◶','◵']
    _p = printer or (lambda s, end='\n': (sys.stdout.write(s+end), sys.stdout.flush()))
    for frame in frames:
        _p(f'\r{frame} {text}', end='')
        time.sleep(0.1)
    _p('')


spinner  = spinner_context
progress = progress_bar
