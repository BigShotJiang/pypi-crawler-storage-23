import os
import sys

def _term_width():
    try:
        cols = os.get_terminal_size().columns
        return cols
    except Exception:
        return 80

def _write_csv(data, filename: str):
    with open(filename, 'w', encoding='utf-8', newline='') as f:
        for row in data:
            line = ','.join(
                '"' + str(cell).replace('"', '""') + '"'
                for cell in row
            )
            f.write(line + '\n')

def format_table(data, title=None, align=None, row_colors=True, sort_by=None) -> str:
    if not data:
        return ''

    rows = [list(map(str, row)) for row in data]
    header = rows[0]
    body   = rows[1:]

    if sort_by is not None and 0 <= sort_by < len(header):
        try:
            body.sort(key=lambda r: float(r[sort_by]) if sort_by < len(r) else 0)
        except ValueError:
            body.sort(key=lambda r: r[sort_by] if sort_by < len(r) else '')

    all_rows = [header] + body
    cols = len(header)

    col_widths = []
    for c in range(cols):
        mx = max((len(r[c]) if c < len(r) else 0) for r in all_rows)
        col_widths.append(min(mx + 2, 40))

    total_w = sum(col_widths) + cols + 1
    term_w  = _term_width()
    if total_w > term_w:
        scale = term_w / total_w
        col_widths = [max(3, int(w * scale)) for w in col_widths]
        total_w = sum(col_widths) + cols + 1

    if align is None:
        align = ['left'] * cols

    def _cell(text, width, a):
        text = text[:width-1] if len(text) > width-1 else text
        if a == 'right':   return f' {text:>{width-1}}'
        if a == 'center':  return f' {text:^{width-1}}'
        return f' {text:<{width-1}}'

    sep   = '+' + '+'.join('-' * w for w in col_widths) + '+'
    DIM   = '\033[2m'
    RESET = '\033[0m'
    lines = [sep]

    if title:
        inner = total_w - 3
        lines.append(f'| {title:^{inner}} |')
        lines.append(sep)

    cells = [_cell(header[c] if c < len(header) else '', col_widths[c],
                   align[c] if c < len(align) else 'left') for c in range(cols)]
    lines.append('|' + '|'.join(cells) + '|')
    lines.append(sep)

    for i, row in enumerate(body):
        cells = [_cell(row[c] if c < len(row) else '', col_widths[c],
                       align[c] if c < len(align) else 'left') for c in range(cols)]
        line = '|' + '|'.join(cells) + '|'
        if row_colors and i % 2 == 1:
            line = DIM + line + RESET
        lines.append(line)

    lines.append(sep)
    return '\n'.join(lines)


def export_csv(data, filename: str):
    _write_csv(data, filename)


def format_box(text, title=None) -> str:
    lines = text.split('\n')
    width = max(len(line) for line in lines)
    width = min(width, _term_width() - 4)

    result = []
    if title:
        dashes = max(0, width - len(title) - 2)
        result.append(f'┌─ {title} ─{"─" * dashes}┐')
    else:
        result.append('┌' + '─' * (width + 2) + '┐')

    for line in lines:
        if len(line) > width:
            line = line[:width-3] + '...'
        result.append(f'│ {line:<{width}} │')

    result.append('└' + '─' * (width + 2) + '┘')
    return '\n'.join(result)


table = format_table
box   = format_box
