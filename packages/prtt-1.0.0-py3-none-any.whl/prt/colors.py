import platform
import os
import sys

def _supports_color():
    if os.environ.get('NO_COLOR') or os.environ.get('PRT_NO_COLOR'):
        return False
    if not hasattr(sys.stdout, 'isatty'):
        return False
    if not sys.stdout.isatty():
        term = os.environ.get('TERM_PROGRAM', '') + os.environ.get('PYCHARM_HOSTED', '')
        if not term:
            return False
    return True

_COLOR_ENABLED = _supports_color()

def set_no_color(value: bool):
    global _COLOR_ENABLED
    _COLOR_ENABLED = not value

class Style:
    RESET     = '\033[0m'
    BOLD      = '\033[1m'
    DIM       = '\033[2m'
    ITALIC    = '\033[3m'
    UNDERLINE = '\033[4m'
    BLINK     = '\033[5m'
    REVERSE   = '\033[7m'
    HIDDEN    = '\033[8m'
    STRIKE    = '\033[9m'

class Fore:
    BLACK        = '\033[30m'; RED          = '\033[31m'; GREEN        = '\033[32m'
    YELLOW       = '\033[33m'; BLUE         = '\033[34m'; MAGENTA      = '\033[35m'
    CYAN         = '\033[36m'; WHITE        = '\033[37m'; RESET        = '\033[39m'
    LIGHTBLACK   = '\033[90m'; LIGHTRED     = '\033[91m'; LIGHTGREEN   = '\033[92m'
    LIGHTYELLOW  = '\033[93m'; LIGHTBLUE    = '\033[94m'; LIGHTMAGENTA = '\033[95m'
    LIGHTCYAN    = '\033[96m'; LIGHTWHITE   = '\033[97m'

class Back:
    BLACK        = '\033[40m';  RED          = '\033[41m';  GREEN        = '\033[42m'
    YELLOW       = '\033[43m';  BLUE         = '\033[44m';  MAGENTA      = '\033[45m'
    CYAN         = '\033[46m';  WHITE        = '\033[47m';  RESET        = '\033[49m'
    LIGHTBLACK   = '\033[100m'; LIGHTRED     = '\033[101m'; LIGHTGREEN   = '\033[102m'
    LIGHTYELLOW  = '\033[103m'; LIGHTBLUE    = '\033[104m'; LIGHTMAGENTA = '\033[105m'
    LIGHTCYAN    = '\033[106m'; LIGHTWHITE   = '\033[107m'

_NAMED_COLORS = {
    'red':(255,0,0),'green':(0,200,0),'blue':(0,0,255),'yellow':(255,220,0),
    'cyan':(0,220,220),'magenta':(220,0,220),'white':(255,255,255),'black':(0,0,0),
    'orange':(255,140,0),'pink':(255,105,180),'purple':(148,0,211),'lime':(0,255,0),
    'teal':(0,128,128),'gold':(255,215,0),'coral':(255,127,80),'indigo':(75,0,130),
    'violet':(238,130,238),'brown':(139,69,19),'gray':(128,128,128),'grey':(128,128,128),
    'silver':(192,192,192),'navy':(0,0,128),'olive':(128,128,0),'maroon':(128,0,0),
}

_THEMES = {
    'default':  {'success':(50,205,50),'error':(220,50,50),'warning':(255,193,7),'info':(30,144,255),'debug':(128,128,128)},
    'dark':     {'success':(0,255,127),'error':(255,69,58),'warning':(255,214,10),'info':(100,210,255),'debug':(160,160,160)},
    'light':    {'success':(0,128,0),'error':(180,0,0),'warning':(184,134,11),'info':(0,0,205),'debug':(80,80,80)},
    'monokai':  {'success':(166,226,46),'error':(249,38,114),'warning':(230,219,116),'info':(102,217,239),'debug':(117,113,94)},
    'solarized':{'success':(133,153,0),'error':(220,50,47),'warning':(181,137,0),'info':(38,139,210),'debug':(101,123,131)},
}

_current_theme = 'default'

def set_theme(name: str):
    global _current_theme
    if name not in _THEMES:
        raise ValueError(f"Неизвестная тема '{name}'. Доступны: {', '.join(_THEMES)}")
    _current_theme = name

def get_theme_color(role: str):
    return _THEMES[_current_theme].get(role, (255,255,255))

def _parse_color(c) -> tuple:
    if isinstance(c, tuple):
        return c
    if isinstance(c, str):
        c = c.strip()
        if c.startswith('#'):
            h = c[1:]
            if len(h) == 3:
                h = h[0]*2 + h[1]*2 + h[2]*2
            if len(h) == 6:
                return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16))
        low = c.lower()
        if low in _NAMED_COLORS:
            return _NAMED_COLORS[low]
    return (255,255,255)

def _rgb_fg(r,g,b): return f'\033[38;2;{r};{g};{b}m'
def _rgb_bg(r,g,b): return f'\033[48;2;{r};{g};{b}m'

class ColorString:
    __slots__ = ('text','styles')

    def __init__(self, text):
        self.text   = str(text)
        self.styles = []

    def _c(self, code):
        self.styles.append(code)
        return self

    def __str__(self):
        if not _COLOR_ENABLED or not self.styles:
            return self.text
        return ''.join(self.styles) + self.text + Style.RESET

    def __repr__(self): return self.__str__()

    def red(self):          return self._c(Fore.RED)
    def green(self):        return self._c(Fore.GREEN)
    def blue(self):         return self._c(Fore.BLUE)
    def yellow(self):       return self._c(Fore.YELLOW)
    def cyan(self):         return self._c(Fore.CYAN)
    def magenta(self):      return self._c(Fore.MAGENTA)
    def white(self):        return self._c(Fore.WHITE)
    def black(self):        return self._c(Fore.BLACK)
    def lightred(self):     return self._c(Fore.LIGHTRED)
    def lightgreen(self):   return self._c(Fore.LIGHTGREEN)
    def lightblue(self):    return self._c(Fore.LIGHTBLUE)
    def lightyellow(self):  return self._c(Fore.LIGHTYELLOW)
    def lightcyan(self):    return self._c(Fore.LIGHTCYAN)
    def lightmagenta(self): return self._c(Fore.LIGHTMAGENTA)

    def hex(self, code):
        r,g,b = _parse_color(code)
        return self._c(_rgb_fg(r,g,b))

    def rgb(self, r, g, b):
        return self._c(_rgb_fg(int(r),int(g),int(b)))

    def bg_hex(self, code):
        r,g,b = _parse_color(code)
        return self._c(_rgb_bg(r,g,b))

    def bg_rgb(self, r, g, b):
        return self._c(_rgb_bg(int(r),int(g),int(b)))

    def bg_red(self):     return self._c(Back.RED)
    def bg_green(self):   return self._c(Back.GREEN)
    def bg_blue(self):    return self._c(Back.BLUE)
    def bg_yellow(self):  return self._c(Back.YELLOW)
    def bg_cyan(self):    return self._c(Back.CYAN)
    def bg_magenta(self): return self._c(Back.MAGENTA)
    def bg_white(self):   return self._c(Back.WHITE)
    def bg_black(self):   return self._c(Back.BLACK)

    def bold(self):      return self._c(Style.BOLD)
    def dim(self):       return self._c(Style.DIM)
    def italic(self):    return self._c(Style.ITALIC)
    def underline(self): return self._c(Style.UNDERLINE)
    def blink(self):     return self._c(Style.BLINK)
    def reverse(self):   return self._c(Style.REVERSE)
    def strike(self):    return self._c(Style.STRIKE)

    def theme(self, role):
        r,g,b = get_theme_color(role)
        return self._c(_rgb_fg(r,g,b))


def color(text, fg=None, bg=None, style=None) -> ColorString:
    cs = ColorString(text)
    if fg:
        if isinstance(fg, tuple):
            cs.rgb(*fg)
        elif fg.startswith('#'):
            cs.hex(fg)
        else:
            m = fg.lower()
            if hasattr(cs, m): getattr(cs, m)()
    if bg:
        if isinstance(bg, tuple):
            cs.bg_rgb(*bg)
        elif bg.startswith('#'):
            cs.bg_hex(bg)
        else:
            m = 'bg_' + bg.lower()
            if hasattr(cs, m): getattr(cs, m)()
    if style:
        for s in style.split('+'):
            m = s.strip().lower()
            if hasattr(cs, m): getattr(cs, m)()
    return cs


def gradient(text: str, from_color, to_color) -> str:
    if not _COLOR_ENABLED:
        return text
    r1,g1,b1 = _parse_color(from_color)
    r2,g2,b2 = _parse_color(to_color)
    chars = list(text)
    n = max(len(chars)-1, 1)
    out = []
    for i,ch in enumerate(chars):
        t = i/n
        r = int(r1+(r2-r1)*t)
        g = int(g1+(g2-g1)*t)
        b = int(b1+(b2-b1)*t)
        out.append(f'\033[38;2;{r};{g};{b}m{ch}')
    return ''.join(out) + Style.RESET


def rainbow(text: str) -> str:
    if not _COLOR_ENABLED:
        return text
    _cols = [(255,0,0),(255,127,0),(255,255,0),(0,255,0),(0,0,255),(75,0,130),(148,0,211)]
    out = []
    for i,ch in enumerate(text):
        r,g,b = _cols[i % len(_cols)]
        out.append(f'\033[38;2;{r};{g};{b}m{ch}')
    return ''.join(out) + Style.RESET


def _init_windows():
    if platform.system() == 'Windows':
        try:
            import ctypes
            k = ctypes.WinDLL('kernel32')
            k.SetConsoleMode(k.GetStdHandle(-11), 7)
        except Exception:
            pass

_init_windows()
