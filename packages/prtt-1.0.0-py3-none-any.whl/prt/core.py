import sys
import time
import threading
import os

from .colors import (ColorString, Style, Fore, gradient, rainbow,
                     get_theme_color, set_theme, set_no_color, _parse_color, _rgb_fg, _rgb_bg)
from .effects import spinner_context, progress_bar, typewrite, countdown, clear_line, clear_screen
from .tables import format_table, format_box, export_csv
from .logging import _log_message, set_loglevel, set_json_logs

_print_lock = threading.Lock()

_SYNTAX_COLORS = {
    'keyword': '\033[38;2;249;38;114m',
    'string':  '\033[38;2;230;219;116m',
    'comment': '\033[38;2;117;113;94m',
    'number':  '\033[38;2;174;129;255m',
    'func':    '\033[38;2;166;226;46m',
    'builtin': '\033[38;2;102;217;239m',
    'reset':   '\033[0m',
}

_PY_KEYWORDS = {
    'False','None','True','and','as','assert','async','await',
    'break','class','continue','def','del','elif','else','except',
    'finally','for','from','global','if','import','in','is',
    'lambda','nonlocal','not','or','pass','raise','return',
    'try','while','with','yield',
}

_PY_BUILTINS = {
    'print','len','range','type','int','str','float','list','dict',
    'tuple','set','bool','open','input','super','self','cls',
    'enumerate','zip','map','filter','sorted','reversed',
    'isinstance','hasattr','getattr','setattr','staticmethod','classmethod',
}


def _highlight_python(code: str) -> str:
    R = _SYNTAX_COLORS
    lines = code.split('\n')
    result = []
    for line in lines:
        out = []
        i   = 0
        while i < len(line):
            ch = line[i]

            if ch == '#':
                out.append(R['comment'] + line[i:] + R['reset'])
                break

            if ch in ('"', "'"):
                q  = ch
                j  = i+1
                if line[j:j+2] == q+q:
                    q3 = q*3
                    end = line.find(q3, i+3)
                    if end == -1:
                        tok = line[i:]
                        i   = len(line)
                    else:
                        tok = line[i:end+3]
                        i   = end+3
                else:
                    j = i+1
                    while j < len(line) and line[j] != q:
                        if line[j] == '\\': j += 1
                        j += 1
                    tok = line[i:j+1]
                    i   = j+1
                out.append(R['string'] + tok + R['reset'])
                continue

            if ch.isdigit() or (ch == '-' and i+1 < len(line) and line[i+1].isdigit()):
                j = i+1
                while j < len(line) and (line[j].isdigit() or line[j] in '.eExX_abcdefABCDEF'):
                    j += 1
                out.append(R['number'] + line[i:j] + R['reset'])
                i = j
                continue

            if ch.isalpha() or ch == '_':
                j = i+1
                while j < len(line) and (line[j].isalnum() or line[j] == '_'):
                    j += 1
                word = line[i:j]
                after = line[j:j+1]
                if word in _PY_KEYWORDS:
                    out.append(R['keyword'] + word + R['reset'])
                elif word in _PY_BUILTINS:
                    out.append(R['builtin'] + word + R['reset'])
                elif after == '(':
                    out.append(R['func'] + word + R['reset'])
                else:
                    out.append(word)
                i = j
                continue

            out.append(ch)
            i += 1

        result.append(''.join(out))
    return '\n'.join(result)


def _term_cols():
    try:
        return os.get_terminal_size().columns
    except Exception:
        return 80


class Prt:
    def __init__(self):
        self.output       = sys.stdout
        self.filter_func  = None
        self.indent_level = 0
        self._lock        = _print_lock
        self._history     = []

    def __call__(self, *objects, sep=' ', end='\n', color=None, style=None, file=None) -> ColorString:
        text = sep.join(str(o) for o in objects)

        if self.filter_func and not self.filter_func(text):
            return ColorString(text)

        cs = ColorString(text)
        if color:
            if isinstance(color, tuple):
                cs.rgb(*color)
            elif color.startswith('#'):
                cs.hex(color)
            elif hasattr(cs, color.lower()):
                getattr(cs, color.lower())()
        if style:
            for s in style.split('+'):
                m = s.strip().lower()
                if hasattr(cs, m): getattr(cs, m)()

        indent = ' ' * self.indent_level
        out    = file or self.output
        rendered = indent + str(cs) + end
        with self._lock:
            out.write(rendered)
            out.flush()
            self._history.append(text)
        return cs

    def _themed(self, icon, text, role):
        r,g,b = get_theme_color(role)
        cs = ColorString(f'{icon} {text}')
        cs.rgb(r,g,b)
        indent = ' ' * self.indent_level
        with self._lock:
            self.output.write(indent + str(cs) + '\n')
            self.output.flush()
            self._history.append(f'{icon} {text}')
        return cs

    def success(self, text): return self._themed('✔', text, 'success')
    def error(self, text):   return self._themed('✘', text, 'error')
    def warning(self, text): return self._themed('⚠', text, 'warning')
    def info(self, text):    return self._themed('ℹ', text, 'info')
    def debug(self, text):   return self._themed('…', text, 'debug')

    def table(self, data, title=None, align=None, row_colors=True, sort_by=None):
        self(format_table(data, title=title, align=align, row_colors=row_colors, sort_by=sort_by))

    def box(self, text, title=None):
        self(format_box(text, title))

    def export_csv(self, data, filename: str):
        export_csv(data, filename)
        self.success(f'CSV сохранён: {filename}')

    def gradient(self, text, from_color='red', to_color='blue'):
        with self._lock:
            self.output.write(' ' * self.indent_level + gradient(text, from_color, to_color) + '\n')
            self.output.flush()

    def rainbow(self, text):
        with self._lock:
            self.output.write(' ' * self.indent_level + rainbow(text) + '\n')
            self.output.flush()

    def progress(self, iterable, desc=''):
        return progress_bar(iterable, desc, self)

    def spinner(self, text=''):
        return spinner_context(text, self)

    def typewrite(self, text: str, delay: float = 0.05):
        typewrite(' ' * self.indent_level + text, delay=delay)

    def countdown(self, n: int, prefix: str = '', end_msg: str = 'Готово!'):
        countdown(n, prefix=prefix, end_msg=end_msg)

    def clear_line(self):
        clear_line()

    def clear(self):
        clear_screen()

    def hr(self, char='─', color=None):
        width = _term_cols()
        line  = char * width
        if color:
            cs = ColorString(line)
            if isinstance(color, tuple):
                cs.rgb(*color)
            elif color.startswith('#'):
                cs.hex(color)
            elif hasattr(cs, color):
                getattr(cs, color)()
            line = str(cs)
        with self._lock:
            self.output.write(line + '\n')
            self.output.flush()

    def center(self, text: str, fill=' '):
        width  = _term_cols()
        cs     = ColorString(text)
        pad    = max(0, (width - len(text)) // 2)
        with self._lock:
            self.output.write(fill * pad + str(cs) + '\n')
            self.output.flush()

    def ask(self, prompt: str, color='cyan') -> str:
        cs = ColorString(f'  ❯ {prompt}: ')
        if hasattr(cs, color): getattr(cs, color)()
        cs.bold()
        sys.stdout.write(str(cs))
        sys.stdout.flush()
        return input()

    def multiline(self, lines: list, **kwargs):
        for line in lines:
            self(line, **kwargs)

    def echo_if(self, condition: bool, text: str, **kwargs):
        if condition:
            self(text, **kwargs)

    def num(self, value, decimals: int = 2, color='cyan') -> ColorString:
        if isinstance(value, int):
            formatted = f'{value:,}'.replace(',', ' ')
        else:
            formatted = f'{value:,.{decimals}f}'.replace(',', ' ')
        cs = ColorString(formatted)
        if hasattr(cs, color): getattr(cs, color)()
        with self._lock:
            self.output.write(' ' * self.indent_level + str(cs) + '\n')
            self.output.flush()
        return cs

    def tree(self, data, _prefix='', _last=True):
        if isinstance(data, dict):
            keys = list(data.keys())
            for i, key in enumerate(keys):
                is_last = (i == len(keys) - 1)
                connector = '└── ' if is_last else '├── '
                cs = ColorString(str(key))
                cs.cyan().bold()
                with self._lock:
                    self.output.write(_prefix + connector + str(cs) + '\n')
                    self.output.flush()
                extension = '    ' if is_last else '│   '
                self.tree(data[key], _prefix + extension, is_last)
        elif isinstance(data, (list, tuple)):
            for i, item in enumerate(data):
                is_last = (i == len(data) - 1)
                connector = '└── ' if is_last else '├── '
                cs = ColorString(str(item))
                cs.white()
                with self._lock:
                    self.output.write(_prefix + connector + str(cs) + '\n')
                    self.output.flush()
        elif data is not None:
            cs = ColorString(str(data))
            cs.yellow()
            with self._lock:
                self.output.write(_prefix + '    ' + str(cs) + '\n')
                self.output.flush()

    def code(self, source: str, lang: str = 'python', title: str = None):
        width = min(_term_cols(), 100)
        top_char = '─'
        header = f'┌─ {title or lang} ─' + top_char * max(0, width - len(title or lang) - 5) + '┐'
        footer = '└' + top_char * (width - 2) + '┘'

        with self._lock:
            self.output.write('\033[38;2;80;80;80m' + header + '\033[0m\n')

            if lang == 'python':
                highlighted = _highlight_python(source)
            else:
                highlighted = source

            for line in highlighted.split('\n'):
                self.output.write('\033[38;2;80;80;80m│\033[0m ' + line + '\n')

            self.output.write('\033[38;2;80;80;80m' + footer + '\033[0m\n')
            self.output.flush()

    def bench(self, func, n: int = 1000, label: str = None):
        name  = label or getattr(func, '__name__', 'func')
        times = []
        for _ in range(n):
            t0 = time.perf_counter()
            func()
            times.append(time.perf_counter() - t0)
        times.sort()
        avg  = sum(times) / len(times)
        mn   = times[0]
        mx   = times[-1]
        med  = times[len(times)//2]
        p95  = times[int(len(times)*0.95)]
        data = [
            ['Метрика', 'Значение'],
            ['Функция',  name],
            ['Итераций', str(n)],
            ['Среднее',  f'{avg*1000:.4f} ms'],
            ['Медиана',  f'{med*1000:.4f} ms'],
            ['Мин',      f'{mn*1000:.4f} ms'],
            ['Макс',     f'{mx*1000:.4f} ms'],
            ['p95',      f'{p95*1000:.4f} ms'],
        ]
        self.table(data, title=f'Benchmark: {name}')

    def history(self):
        self.box('\n'.join(self._history[-20:]) if self._history else '(пусто)', title='История вывода')

    def notify(self, text: str, title: str = 'prt'):
        import platform
        import subprocess
        system = platform.system()
        try:
            if system == 'Windows':
                ps = (
                    f'[Windows.UI.Notifications.ToastNotificationManager,'
                    f'Windows.UI.Notifications,ContentType=WindowsRuntime]|Out-Null;'
                    f'$t=[Windows.UI.Notifications.ToastTemplateType]::ToastText02;'
                    f'$x=[Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent($t);'
                    f'$x.GetElementsByTagName("text")[0].AppendChild($x.CreateTextNode("{title}"))|Out-Null;'
                    f'$x.GetElementsByTagName("text")[1].AppendChild($x.CreateTextNode("{text}"))|Out-Null;'
                    f'$n=[Windows.UI.Notifications.ToastNotification]::new($x);'
                    f'[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("prt").Show($n)'
                )
                subprocess.Popen(['powershell','-Command',ps],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif system == 'Darwin':
                subprocess.Popen(['osascript','-e',
                                  f'display notification "{text}" with title "{title}"'],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif system == 'Linux':
                subprocess.Popen(['notify-send', title, text],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
        self.info(f'[notify] {title}: {text}')

    def log(self, text: str, level: str = 'INFO'):
        _log_message(text, level)
        lvl = level.upper()
        if lvl == 'ERROR':         self.error(text)
        elif lvl == 'WARNING':     self.warning(text)
        elif lvl == 'SUCCESS':     self.success(text)
        elif lvl == 'DEBUG':       self.debug(text)
        else:                      self.info(text)

    def set_filter(self, func):
        self.filter_func = func

    def redirect_to(self, filename: str):
        _self = self
        class _R:
            def __enter__(self):
                self._old = _self.output
                _self.output = open(filename, 'w', encoding='utf-8')
            def __exit__(self, *a):
                _self.output.close()
                _self.output = self._old
        return _R()

    def indent(self, level: int = 2):
        _self = self
        class _I:
            def __enter__(self):  _self.indent_level += level
            def __exit__(self, *a): _self.indent_level -= level
        return _I()

    def timer(self, label: str = 'Операция'):
        _self = self
        class _T:
            def __enter__(self):
                self._s = time.perf_counter()
            def __exit__(self, *a):
                _self.info(f'{label}: {time.perf_counter()-self._s:.3f}s')
        return _T()

    def set_theme(self, name: str):       set_theme(name)
    def set_no_color(self, v: bool=True): set_no_color(v)
    def set_loglevel(self, level):        set_loglevel(level)
    def set_json_logs(self, v: bool):     set_json_logs(v)

    def async_write(self, text: str):
        threading.Thread(target=lambda: self(text), daemon=True).start()


prt = Prt()
