import os
import threading

def _now_str():
    import time
    t = time.localtime()
    return f'{t.tm_year}-{t.tm_mon:02d}-{t.tm_mday:02d} {t.tm_hour:02d}:{t.tm_min:02d}:{t.tm_sec:02d}'

def _to_json(obj: dict) -> str:
    parts = []
    for k, v in obj.items():
        key   = '"' + str(k).replace('"','\\"') + '"'
        val   = '"' + str(v).replace('\\','\\\\').replace('"','\\"') + '"'
        parts.append(f'{key}:{val}')
    return '{' + ','.join(parts) + '}'


class LogLevel:
    DEBUG   = 10
    INFO    = 20
    SUCCESS = 25
    WARNING = 30
    ERROR   = 40

    _names    = {10:'DEBUG',20:'INFO',25:'SUCCESS',30:'WARNING',40:'ERROR'}
    _from_str = {'DEBUG':10,'INFO':20,'SUCCESS':25,'WARNING':30,'ERROR':40}

    @classmethod
    def from_str(cls, s: str) -> int:
        return cls._from_str.get(s.upper(), 20)

    @classmethod
    def to_str(cls, n: int) -> str:
        return cls._names.get(n, 'INFO')


class LogFile:
    def __init__(self, filename, rotate='size', max_size=10*1024*1024):
        self.filename  = filename
        self.rotate    = rotate
        self.max_size  = max_size
        self._size     = 0
        self._lock     = threading.Lock()
        self._file     = None
        self._day      = self._today()
        self._open()

    def _today(self):
        import time
        return time.localtime().tm_mday

    def _open(self):
        mode = 'a' if os.path.exists(self.filename) else 'w'
        self._file = open(self.filename, mode, encoding='utf-8')
        self._size = os.path.getsize(self.filename) if os.path.exists(self.filename) else 0

    def _rotate(self):
        self._file.close()
        import time
        t = time.localtime()
        ts = f'{t.tm_year}{t.tm_mon:02d}{t.tm_mday:02d}_{t.tm_hour:02d}{t.tm_min:02d}{t.tm_sec:02d}'
        os.rename(self.filename, f'{self.filename}.{ts}')
        self._open()

    def write(self, text: str):
        with self._lock:
            self._file.write(text + '\n')
            self._file.flush()
            self._size += len(text) + 1
            if self.rotate == 'size' and self._size > self.max_size:
                self._rotate()
            elif self.rotate == 'daily':
                today = self._today()
                if today != self._day:
                    self._rotate()
                    self._day = today


_log_file  = None
_log_level = LogLevel.DEBUG
_use_json  = False
_file_lock = threading.Lock()


def set_logfile(filename, rotate='size', max_size=10*1024*1024):
    global _log_file
    with _file_lock:
        _log_file = LogFile(filename, rotate, max_size)


def set_loglevel(level):
    global _log_level
    if isinstance(level, str):
        _log_level = LogLevel.from_str(level)
    else:
        _log_level = level


def set_json_logs(enabled: bool):
    global _use_json
    _use_json = enabled


def _log_message(text: str, level: str = 'INFO'):
    global _log_file, _log_level, _use_json
    lvl_num = LogLevel.from_str(level)
    if lvl_num < _log_level:
        return
    if _log_file:
        ts = _now_str()
        if _use_json:
            entry = _to_json({'time': ts, 'level': level, 'message': text})
        else:
            entry = f'[{ts}] [{level}] {text}'
        _log_file.write(entry)


def log(text: str, level: str = 'INFO'):
    _log_message(text, level)

def debug(text):   _log_message(text, 'DEBUG')
def info(text):    _log_message(text, 'INFO')
def warning(text): _log_message(text, 'WARNING')
def error(text):   _log_message(text, 'ERROR')
def success(text): _log_message(text, 'SUCCESS')
