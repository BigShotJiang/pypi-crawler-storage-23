# Specific AI Python SDK

This SDK supports two main workflows:

* **Platform automation**: manage Tasks, Assets (datasets/benchmarks), Trainings, and Models
* **Inference**: run inference on deployed Specific AI models

For copy‑paste‑ready deep dives, see `optune-sdk/examples/platform/`.

## Installation

```bash
pip install specific-ai
```

## Authentication & configuration

Set these environment variables:

* `SPECIFIC_AI_API_KEY`: API key / bearer token for the platform backend
* `SPECIFIC_AI_BASE_URL`: platform backend base URL (default in examples: `https://platform.specific.ai/`)

Optional:

* `SPECIFIC_AI_TASK_ID`: current task id. You can create a new task or see the current task\_id in the platform url. for example - the following url: https://platform.specific.ai/model-setup?usecaseId=68bedd42667aca8d3086e536 the task\_id is '68bedd42667aca8d3086e536'
* `SPECIFIC_AI_TASK_TYPE`: task type string (e.g. `ClassificationResponse`)

## 5-line quickstart (platform)

```python
import os
from specific_ai import SpecificAIClient

client = SpecificAIClient(base_url=os.getenv("SPECIFIC_AI_BASE_URL", "http://localhost:8000"), api_key=os.environ["SPECIFIC_AI_API_KEY"])
task_id = client.tasks.list()[0].iter_tasks()[0].task_id
print(client.models.get_metrics(task_id=task_id).versions)
```

## Deep dive examples

Located in `optune-sdk/examples/platform/`:

* `01_task_management.py`
* `02_asset_management.py`
* `03_training_workflows.py`
* `04_model_deployment.py`

## Support

Contact `support@specific.ai`.
