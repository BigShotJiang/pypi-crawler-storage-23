from __future__ import annotations

from specific_ai.platform.base_client import BaseClient
from specific_ai.platform.constants import DEFAULT_CLIENT_ID
from specific_ai.platform.resources import (
    AssetsManager,
    ModelManager,
    TaskManager,
    TrainingManager,
)


class SpecificAIPlatformClient:
    """
    High-level client for managing tasks, datasets, trainings, and models.

    Example:
        client = SpecificAIPlatformClient(base_url="https://app.specific.ai", api_key="...")
        groups = client.tasks.list()
    """

    def __init__(self, http: BaseClient):
        self._http = http
        self._client_id = DEFAULT_CLIENT_ID
        self.tasks = TaskManager(http, client_id=self._client_id)
        self.assets = AssetsManager(http, client_id=self._client_id)
        # Backwards-compatible alias: model setup is a task concern.
        self.setup = self.tasks
        self.trainings = TrainingManager(http, client_id=self._client_id)
        self.models = ModelManager(http, client_id=self._client_id)

    @property
    def http(self) -> BaseClient:
        """Access to the underlying HTTP client (advanced usage)."""
        return self._http

    @property
    def client_id(self) -> str:
        """Internal tenant identifier used for all platform API calls."""
        return self._client_id
