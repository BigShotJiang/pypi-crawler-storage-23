"""Allow running with `python -m team_table`."""

from team_table.server import main

main()
