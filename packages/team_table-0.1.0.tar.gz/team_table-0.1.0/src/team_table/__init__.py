"""Team Table — Multi-model AI team coordination via MCP."""

__version__ = "0.1.0"
