# litcoin/__init__.py
"""
LITCOIN — Proof-of-Comprehension Mining SDK for AI Agents

Usage:
    from litcoin import Miner

    # With Bankr wallet (smart contract wallet)
    miner = Miner(wallet_key="bk_YOUR_BANKR_KEY")
    miner.mine()

    # With private key (EOA)
    miner = Miner(wallet_key="0xYOUR_PRIVATE_KEY")
    miner.mine()

    # Step by step
    miner.bootstrap()     # claim from faucet if balance < 5M
    miner.mine(rounds=10) # mine 10 rounds
    miner.claim()          # claim rewards on-chain
    miner.earnings()       # check earnings/claimed status

Learn more: https://litcoiin.xyz/docs
"""

__version__ = "1.0.0"

from .miner import Miner
from .config import COORDINATOR_URL, CHAIN_ID, LITCOIN_TOKEN

__all__ = ["Miner", "COORDINATOR_URL", "CHAIN_ID", "LITCOIN_TOKEN"]
