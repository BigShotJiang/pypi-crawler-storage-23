# litcoin/config.py
"""LITCOIN protocol configuration."""

COORDINATOR_URL = "https://api.litcoiin.xyz"
CHAIN_ID = 8453

# Contract addresses (Base mainnet)
LITCOIN_TOKEN = "0x316ffb9c875f900AdCF04889E415cC86b564EBa3"
CLAIMS_CONTRACT = "0xF703DcF2E88C0673F776870fdb12A453927C6A5e"
FAUCET_CONTRACT = ""  # Set after deployment
STAKING_CONTRACT = "0xC9584Ce1591E8EB38EdF15C28f2FDcca97A3d3B7"

# Function selectors
CLAIM_SELECTOR = "38926b6d"        # claim(uint256,bytes)
FAUCET_CLAIM_SELECTOR = ""         # Set after deployment

# Mining defaults
MIN_BALANCE = 5_000_000
FAUCET_DRIP = 5_000_000

# Base RPC endpoints
RPC_URLS = [
    "https://mainnet.base.org",
    "https://base.llamarpc.com",
    "https://1rpc.io/base",
    "https://base.drpc.org",
]
