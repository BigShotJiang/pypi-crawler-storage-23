# Velar Python SDK

Deploy ML models to GPUs with one command.

## Installation

```bash
pip install velar-sdk
```

## Authentication

```bash
velar login
```

This opens your browser, signs you in, and saves an API key to `~/.velar/token` automatically.

## Quick Start

```python
import velar

app = velar.App("my-model")

image = velar.Image.from_registry("pytorch/pytorch:2.1.0-cuda12.1-cudnn8-runtime")
image = image.pip_install("transformers", "accelerate")

@app.function(gpu="A100", image=image)
def run_inference(prompt: str) -> str:
    from transformers import pipeline
    pipe = pipeline("text-generation", model="gpt2")
    return pipe(prompt)[0]["generated_text"]

@app.local_entrypoint()
def main():
    result = run_inference.remote("Hello, world!")
    print(result)
```

**Deploy:**

```bash
velar deploy app:app
```

**Run locally (calls the remote GPU):**

```bash
velar run app:app
```

## GPU Types

| Name | VRAM | Price/hr |
|------|------|----------|
| `L4` | 24 GB | $0.59 |
| `RTX4090` | 24 GB | $0.89 |
| `L40S` | 48 GB | $1.29 |
| `A100` | 80 GB | $2.09 |
| `H100` | 80 GB | $3.59 |
| `H100-SXM` | 80 GB | $4.04 |
| `H200` | 141 GB | $5.39 |

Prices are approximate. Use `velar.VelarClient().get_gpu_prices()` for live pricing.

## Image Builder

```python
image = (
    velar.Image.from_registry("python:3.11-slim")
    .pip_install("torch", "transformers")
    .run_commands("apt-get update && apt-get install -y ffmpeg")
    .env(HF_HOME="/tmp/hf")
)
```

## CLI Reference

```bash
velar login              # Authenticate via browser
velar deploy app:app     # Deploy to GPU cloud
velar run app:app        # Run local entrypoint
velar status             # List deployments
velar balance            # Show credit balance
velar cancel <id>        # Cancel a deployment
velar token set <key>    # Set API key manually
velar whoami             # Show current user
```

## Links

- [velar.run](https://velar.run)
- [Dashboard](https://velar.run/dashboard)
