"""Thin wrapper around ``httpx.Response`` for ``requests``-compatible interface.

The wrapper delegates everything to the underlying ``httpx.Response`` but
exposes a few properties/methods that ``requests.Response`` users expect:

- ``.ok`` — ``True`` when ``status_code < 400``
- ``.text`` — decoded body (property)
- ``.json()`` — parsed JSON (method)
- ``.content`` — raw bytes
- ``.status_code``
- ``.headers``
- ``.raise_for_status()``
"""

from __future__ import annotations

from typing import Any

import httpx


class Response:
    """``requests.Response``-compatible wrapper around ``httpx.Response``."""

    def __init__(self, httpx_response: httpx.Response) -> None:
        self._response = httpx_response

    @property
    def status_code(self) -> int:
        return self._response.status_code

    @property
    def ok(self) -> bool:
        return self._response.is_success

    @property
    def headers(self) -> httpx.Headers:
        return self._response.headers

    @property
    def text(self) -> str:
        return self._response.text

    @property
    def content(self) -> bytes:
        return self._response.content

    @property
    def encoding(self) -> str | None:
        return self._response.encoding

    @property
    def url(self) -> str:
        return str(self._response.url)

    def json(self, **kwargs: Any) -> Any:
        return self._response.json()

    def raise_for_status(self) -> None:
        self._response.raise_for_status()

    def iter_lines(self) -> Any:
        return self._response.iter_lines()

    def __repr__(self) -> str:
        return f"<Response [{self.status_code}]>"
