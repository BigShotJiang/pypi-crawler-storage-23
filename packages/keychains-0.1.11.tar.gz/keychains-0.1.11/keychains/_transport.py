"""Custom httpx transport that rewrites URLs and injects the proxy token."""

from __future__ import annotations

import os

import httpx
from dotenv import find_dotenv, load_dotenv

from .exceptions import ApprovalRequired, MissingTokenError

load_dotenv(find_dotenv(usecwd=True))

PROXY_BASE = "https://keychains.dev"

_KNOWN_SCOPE_ERRORS = frozenset(
    {
        "insufficient_scope",
        "scope_refused",
        "scope_not_approved",
        "permission_needs_revalidation",
        "permission_denied",
    }
)


def _resolve_token(token: str | None) -> str:
    resolved = token or os.environ.get("KEYCHAINS_TOKEN")
    if not resolved:
        raise MissingTokenError()
    return resolved


def _rewrite_url(url: httpx.URL) -> httpx.URL:
    """Rewrite ``https://api.github.com/path`` to ``https://keychains.dev/api.github.com/path``."""
    new_path = f"/{url.host}{url.raw_path.decode('ascii')}"
    return httpx.URL(f"{PROXY_BASE}{new_path}")


def _check_approval_error(response: httpx.Response) -> None:
    """If the response is a 403 with an approval URL, raise ``ApprovalRequired``."""
    if response.status_code != 403:
        return

    try:
        body = response.json()
    except Exception:
        return

    approval_url: str | None = body.get("approval_url") or body.get("authorizationUrl")
    error_code: str | None = body.get("error")

    if not (approval_url or error_code in _KNOWN_SCOPE_ERRORS):
        return

    if error_code == "scope_refused":
        message = f"Scopes refused: {', '.join(body.get('refused_scopes', []))}"
    elif body.get("message"):
        message = body["message"]
    elif body.get("missing_scopes"):
        message = f"Insufficient scopes: {', '.join(body['missing_scopes'])}"
    else:
        message = "Missing required credentials"

    raise ApprovalRequired(
        message=message,
        code=error_code or "permission_denied",
        approval_url=approval_url,
        missing_scopes=body.get("missing_scopes"),
        refused_scopes=body.get("refused_scopes"),
    )


class KeychainsTransport(httpx.BaseTransport):
    """Sync transport that proxies requests through Keychains.

    Wraps an underlying ``httpx.BaseTransport`` — rewrites target URLs
    and injects the ``X-Proxy-Authorization`` header.
    """

    def __init__(
        self,
        *,
        token: str | None = None,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self._token = _resolve_token(token)
        self._transport = transport or httpx.HTTPTransport()

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        request.url = _rewrite_url(request.url)
        request.headers["host"] = request.url.host
        request.headers["X-Proxy-Authorization"] = f"Bearer {self._token}"

        response = self._transport.handle_request(request)

        response.read()
        _check_approval_error(response)

        return response

    def close(self) -> None:
        self._transport.close()


class AsyncKeychainsTransport(httpx.AsyncBaseTransport):
    """Async transport that proxies requests through Keychains.

    Wraps an underlying ``httpx.AsyncBaseTransport`` — rewrites target URLs
    and injects the ``X-Proxy-Authorization`` header.
    """

    def __init__(
        self,
        *,
        token: str | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._token = _resolve_token(token)
        self._transport = transport or httpx.AsyncHTTPTransport()

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        request.url = _rewrite_url(request.url)
        request.headers["host"] = request.url.host
        request.headers["X-Proxy-Authorization"] = f"Bearer {self._token}"

        response = await self._transport.handle_async_request(request)

        await response.aread()
        _check_approval_error(response)

        return response

    async def aclose(self) -> None:
        await self._transport.aclose()
