"""keychains — Python SDK for Keychains.dev

Drop-in replacement for ``requests.get()`` / ``requests.post()`` with
credential proxying handled transparently.

Usage::

    import keychains

    response = keychains.get("https://api.github.com/user/repos")
    print(response.json())
"""

from __future__ import annotations

from typing import Any

import httpx

import sys

from ._client import AsyncClient, Session
from ._response import Response
from ._transport import KeychainsTransport
from ._version import __version__
from .exceptions import ApprovalRequired, KeychainsError, MissingTokenError

_original_excepthook = sys.excepthook


def _keychains_excepthook(
    exc_type: type[BaseException],
    exc_value: BaseException,
    exc_tb: Any,
) -> None:
    """Print KeychainsError subclasses cleanly — no traceback."""
    if isinstance(exc_value, KeychainsError):
        print(f"\n{exc_type.__name__}: {exc_value}", file=sys.stderr)
    else:
        _original_excepthook(exc_type, exc_value, exc_tb)


sys.excepthook = _keychains_excepthook

__all__ = [
    "__version__",
    "ApprovalRequired",
    "AsyncClient",
    "KeychainsError",
    "MissingTokenError",
    "Response",
    "Session",
    "delete",
    "get",
    "head",
    "options",
    "patch",
    "post",
    "put",
]


def get(
    url: str,
    *,
    token: str | None = None,
    params: Any = None,
    headers: Any = None,
    cookies: Any = None,
    auth: Any = None,
    timeout: Any = None,
    allow_redirects: bool = True,
    verify: bool = True,
    **kwargs: Any,
) -> Response:
    """Send a GET request through the Keychains proxy.

    Mirrors ``requests.get()`` — same arguments, same return shape.
    """
    return _request(
        "GET",
        url,
        token=token,
        params=params,
        headers=headers,
        cookies=cookies,
        auth=auth,
        timeout=timeout,
        follow_redirects=allow_redirects,
        verify=verify,
        **kwargs,
    )


def post(
    url: str,
    *,
    data: Any = None,
    json: Any = None,
    token: str | None = None,
    params: Any = None,
    headers: Any = None,
    cookies: Any = None,
    auth: Any = None,
    timeout: Any = None,
    allow_redirects: bool = True,
    verify: bool = True,
    **kwargs: Any,
) -> Response:
    """Send a POST request through the Keychains proxy."""
    return _request(
        "POST",
        url,
        data=data,
        json=json,
        token=token,
        params=params,
        headers=headers,
        cookies=cookies,
        auth=auth,
        timeout=timeout,
        follow_redirects=allow_redirects,
        verify=verify,
        **kwargs,
    )


def put(
    url: str,
    *,
    data: Any = None,
    json: Any = None,
    token: str | None = None,
    params: Any = None,
    headers: Any = None,
    cookies: Any = None,
    auth: Any = None,
    timeout: Any = None,
    allow_redirects: bool = True,
    verify: bool = True,
    **kwargs: Any,
) -> Response:
    """Send a PUT request through the Keychains proxy."""
    return _request(
        "PUT",
        url,
        data=data,
        json=json,
        token=token,
        params=params,
        headers=headers,
        cookies=cookies,
        auth=auth,
        timeout=timeout,
        follow_redirects=allow_redirects,
        verify=verify,
        **kwargs,
    )


def patch(
    url: str,
    *,
    data: Any = None,
    json: Any = None,
    token: str | None = None,
    params: Any = None,
    headers: Any = None,
    cookies: Any = None,
    auth: Any = None,
    timeout: Any = None,
    allow_redirects: bool = True,
    verify: bool = True,
    **kwargs: Any,
) -> Response:
    """Send a PATCH request through the Keychains proxy."""
    return _request(
        "PATCH",
        url,
        data=data,
        json=json,
        token=token,
        params=params,
        headers=headers,
        cookies=cookies,
        auth=auth,
        timeout=timeout,
        follow_redirects=allow_redirects,
        verify=verify,
        **kwargs,
    )


def delete(
    url: str,
    *,
    token: str | None = None,
    params: Any = None,
    headers: Any = None,
    cookies: Any = None,
    auth: Any = None,
    timeout: Any = None,
    allow_redirects: bool = True,
    verify: bool = True,
    **kwargs: Any,
) -> Response:
    """Send a DELETE request through the Keychains proxy."""
    return _request(
        "DELETE",
        url,
        token=token,
        params=params,
        headers=headers,
        cookies=cookies,
        auth=auth,
        timeout=timeout,
        follow_redirects=allow_redirects,
        verify=verify,
        **kwargs,
    )


def head(
    url: str,
    *,
    token: str | None = None,
    params: Any = None,
    headers: Any = None,
    cookies: Any = None,
    auth: Any = None,
    timeout: Any = None,
    allow_redirects: bool = False,
    verify: bool = True,
    **kwargs: Any,
) -> Response:
    """Send a HEAD request through the Keychains proxy."""
    return _request(
        "HEAD",
        url,
        token=token,
        params=params,
        headers=headers,
        cookies=cookies,
        auth=auth,
        timeout=timeout,
        follow_redirects=allow_redirects,
        verify=verify,
        **kwargs,
    )


def options(
    url: str,
    *,
    token: str | None = None,
    params: Any = None,
    headers: Any = None,
    cookies: Any = None,
    auth: Any = None,
    timeout: Any = None,
    allow_redirects: bool = True,
    verify: bool = True,
    **kwargs: Any,
) -> Response:
    """Send an OPTIONS request through the Keychains proxy."""
    return _request(
        "OPTIONS",
        url,
        token=token,
        params=params,
        headers=headers,
        cookies=cookies,
        auth=auth,
        timeout=timeout,
        follow_redirects=allow_redirects,
        verify=verify,
        **kwargs,
    )


def _request(
    method: str,
    url: str,
    *,
    token: str | None = None,
    data: Any = None,
    json: Any = None,
    params: Any = None,
    headers: Any = None,
    cookies: Any = None,
    auth: Any = None,
    timeout: Any = None,
    follow_redirects: bool = True,
    verify: bool = True,
    **kwargs: Any,
) -> Response:
    transport = KeychainsTransport(token=token)
    with httpx.Client(transport=transport, verify=verify) as client:
        response = client.request(
            method,
            url,
            data=data,
            json=json,
            params=params,
            headers=headers,
            cookies=cookies,
            auth=auth,
            timeout=timeout,
            follow_redirects=follow_redirects,
            **kwargs,
        )
    return Response(response)
