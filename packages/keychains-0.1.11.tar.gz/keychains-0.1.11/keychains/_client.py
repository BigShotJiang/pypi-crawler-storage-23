"""Session and AsyncClient — connection-pooling wrappers with proxy support."""

from __future__ import annotations

from typing import Any

import httpx

from ._response import Response
from ._transport import AsyncKeychainsTransport, KeychainsTransport


class Session:
    """Sync session with connection pooling — mirrors ``requests.Session``.

    Usage::

        with keychains.Session() as s:
            s.headers.update({"Authorization": "Bearer {{OAUTH2_ACCESS_TOKEN}}"})
            repos = s.get("https://api.github.com/user/repos")
    """

    def __init__(
        self,
        *,
        token: str | None = None,
        **client_kwargs: Any,
    ) -> None:
        transport = KeychainsTransport(token=token)
        self._client = httpx.Client(transport=transport, **client_kwargs)

    @property
    def headers(self) -> httpx.Headers:
        return self._client.headers

    def get(self, url: str, **kwargs: Any) -> Response:
        return Response(self._client.get(url, **kwargs))

    def post(self, url: str, **kwargs: Any) -> Response:
        return Response(self._client.post(url, **kwargs))

    def put(self, url: str, **kwargs: Any) -> Response:
        return Response(self._client.put(url, **kwargs))

    def patch(self, url: str, **kwargs: Any) -> Response:
        return Response(self._client.patch(url, **kwargs))

    def delete(self, url: str, **kwargs: Any) -> Response:
        return Response(self._client.delete(url, **kwargs))

    def head(self, url: str, **kwargs: Any) -> Response:
        return Response(self._client.head(url, **kwargs))

    def options(self, url: str, **kwargs: Any) -> Response:
        return Response(self._client.options(url, **kwargs))

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> Session:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncClient:
    """Async client — mirrors ``httpx.AsyncClient``.

    Usage::

        async with keychains.AsyncClient() as client:
            response = await client.get("https://api.github.com/user/repos")
    """

    def __init__(
        self,
        *,
        token: str | None = None,
        **client_kwargs: Any,
    ) -> None:
        transport = AsyncKeychainsTransport(token=token)
        self._client = httpx.AsyncClient(transport=transport, **client_kwargs)

    @property
    def headers(self) -> httpx.Headers:
        return self._client.headers

    async def get(self, url: str, **kwargs: Any) -> Response:
        return Response(await self._client.get(url, **kwargs))

    async def post(self, url: str, **kwargs: Any) -> Response:
        return Response(await self._client.post(url, **kwargs))

    async def put(self, url: str, **kwargs: Any) -> Response:
        return Response(await self._client.put(url, **kwargs))

    async def patch(self, url: str, **kwargs: Any) -> Response:
        return Response(await self._client.patch(url, **kwargs))

    async def delete(self, url: str, **kwargs: Any) -> Response:
        return Response(await self._client.delete(url, **kwargs))

    async def head(self, url: str, **kwargs: Any) -> Response:
        return Response(await self._client.head(url, **kwargs))

    async def options(self, url: str, **kwargs: Any) -> Response:
        return Response(await self._client.options(url, **kwargs))

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()
