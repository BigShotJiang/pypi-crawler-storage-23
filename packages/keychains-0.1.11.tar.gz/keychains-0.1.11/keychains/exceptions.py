"""Keychains SDK exceptions."""

from __future__ import annotations


class KeychainsError(Exception):
    """Base exception for all Keychains SDK errors."""


class MissingTokenError(KeychainsError):
    """Raised when no KEYCHAINS_TOKEN is available."""

    def __init__(self) -> None:
        super().__init__(
            "No token available. Set KEYCHAINS_TOKEN or run: "
            "KEYCHAINS_TOKEN=$(npx -y keychains token) python your_script.py"
        )


class ApprovalRequired(KeychainsError):
    """Raised when the proxy returns 403 with an approval URL.

    The ``approval_url`` should be shown to the user so they can
    approve the required scopes.
    """

    approval_url: str | None
    missing_scopes: list[str] | None
    refused_scopes: list[str] | None
    code: str

    def __init__(
        self,
        *,
        message: str,
        code: str,
        approval_url: str | None = None,
        missing_scopes: list[str] | None = None,
        refused_scopes: list[str] | None = None,
    ) -> None:
        self.code = code
        self.approval_url = approval_url
        self.missing_scopes = missing_scopes
        self.refused_scopes = refused_scopes

        parts = [message]
        if approval_url:
            parts.append(f"\n\n  Approve access: {approval_url}\n")
        if missing_scopes:
            parts.append(f"  Missing scopes: {', '.join(missing_scopes)}")
        if refused_scopes:
            parts.append(f"  Refused scopes: {', '.join(refused_scopes)}")

        super().__init__("\n".join(parts))
