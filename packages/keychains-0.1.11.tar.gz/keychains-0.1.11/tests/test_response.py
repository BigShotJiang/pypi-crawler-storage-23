"""Tests for the Response wrapper."""

from __future__ import annotations

import httpx

from keychains._response import Response


class TestResponse:
    def _make_response(self, status_code: int = 200, json_body: dict | None = None) -> Response:
        httpx_resp = httpx.Response(
            status_code=status_code,
            json=json_body or {"key": "value"},
            request=httpx.Request("GET", "https://example.com"),
        )
        return Response(httpx_resp)

    def test_status_code(self) -> None:
        resp = self._make_response(200)
        assert resp.status_code == 200

    def test_ok_success(self) -> None:
        resp = self._make_response(200)
        assert resp.ok is True

    def test_ok_failure(self) -> None:
        resp = self._make_response(404)
        assert resp.ok is False

    def test_json(self) -> None:
        resp = self._make_response(json_body={"hello": "world"})
        assert resp.json() == {"hello": "world"}

    def test_text(self) -> None:
        resp = self._make_response(json_body={"hello": "world"})
        assert '"hello"' in resp.text

    def test_content_is_bytes(self) -> None:
        resp = self._make_response()
        assert isinstance(resp.content, bytes)

    def test_headers(self) -> None:
        resp = self._make_response()
        assert isinstance(resp.headers, httpx.Headers)

    def test_repr(self) -> None:
        resp = self._make_response(201)
        assert repr(resp) == "<Response [201]>"

    def test_raise_for_status_ok(self) -> None:
        resp = self._make_response(200)
        resp.raise_for_status()  # should not raise

    def test_raise_for_status_error(self) -> None:
        resp = self._make_response(500)
        try:
            resp.raise_for_status()
            assert False, "Should have raised"
        except httpx.HTTPStatusError:
            pass
