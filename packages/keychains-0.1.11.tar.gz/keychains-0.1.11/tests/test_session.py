"""Tests for keychains.Session."""

from __future__ import annotations

import httpx
import pytest

import keychains
from keychains._transport import KeychainsTransport


def _echo_handler(request: httpx.Request) -> httpx.Response:
    return httpx.Response(
        200,
        json={
            "url": str(request.url),
            "method": request.method,
            "headers": dict(request.headers),
        },
    )


class TestSession:
    def test_session_rewrites_urls(self) -> None:
        transport = KeychainsTransport(
            token="test-token",
            transport=httpx.MockTransport(_echo_handler),
        )
        with httpx.Client(transport=transport) as client:
            resp = client.get("https://api.github.com/user/repos")
            body = resp.json()
            assert "keychains.dev/api.github.com" in body["url"]

    def test_session_shares_headers(self) -> None:
        transport = KeychainsTransport(
            token="test-token",
            transport=httpx.MockTransport(_echo_handler),
        )
        with httpx.Client(transport=transport) as client:
            client.headers["Authorization"] = "Bearer {{OAUTH2_ACCESS_TOKEN}}"
            resp = client.get("https://api.github.com/user")
            body = resp.json()
            assert body["headers"]["authorization"] == "Bearer {{OAUTH2_ACCESS_TOKEN}}"

    def test_session_all_methods(self) -> None:
        transport = KeychainsTransport(
            token="test-token",
            transport=httpx.MockTransport(_echo_handler),
        )
        with httpx.Client(transport=transport) as client:
            for method in ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]:
                resp = client.request(method, "https://api.example.com/test")
                if method != "HEAD":
                    body = resp.json()
                    assert body["method"] == method
