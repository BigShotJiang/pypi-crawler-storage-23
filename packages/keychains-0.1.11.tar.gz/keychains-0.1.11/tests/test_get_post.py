"""Tests for top-level keychains.get / keychains.post / etc."""

from __future__ import annotations

import json
from typing import Any

import httpx
import pytest

import keychains
from keychains._transport import KeychainsTransport
from keychains.exceptions import ApprovalRequired


def _mock_handler(request: httpx.Request) -> httpx.Response:
    """Echo back request details so tests can inspect what was sent."""
    body = {
        "url": str(request.url),
        "method": request.method,
        "headers": dict(request.headers),
    }
    return httpx.Response(200, json=body)


def _make_transport(token: str = "test-token") -> KeychainsTransport:
    return KeychainsTransport(
        token=token,
        transport=httpx.MockTransport(_mock_handler),
    )


class TestTopLevelFunctions:
    def test_get_rewrites_url(self) -> None:
        transport = _make_transport()
        with httpx.Client(transport=transport) as client:
            resp = client.get("https://api.github.com/user/repos")

        body = resp.json()
        assert "keychains.dev/api.github.com/user/repos" in body["url"]

    def test_get_injects_proxy_auth_header(self) -> None:
        transport = _make_transport(token="my-secret-token")
        with httpx.Client(transport=transport) as client:
            resp = client.get("https://api.github.com/user")

        body = resp.json()
        assert body["headers"]["x-proxy-authorization"] == "Bearer my-secret-token"

    def test_post_sends_correct_method(self) -> None:
        transport = _make_transport()
        with httpx.Client(transport=transport) as client:
            resp = client.post("https://api.stripe.com/v1/charges")

        body = resp.json()
        assert body["method"] == "POST"

    def test_put_sends_correct_method(self) -> None:
        transport = _make_transport()
        with httpx.Client(transport=transport) as client:
            resp = client.put("https://api.example.com/resource")

        assert resp.json()["method"] == "PUT"

    def test_patch_sends_correct_method(self) -> None:
        transport = _make_transport()
        with httpx.Client(transport=transport) as client:
            resp = client.patch("https://api.example.com/resource")

        assert resp.json()["method"] == "PATCH"

    def test_delete_sends_correct_method(self) -> None:
        transport = _make_transport()
        with httpx.Client(transport=transport) as client:
            resp = client.delete("https://api.example.com/resource")

        assert resp.json()["method"] == "DELETE"

    def test_preserves_user_headers(self) -> None:
        transport = _make_transport()
        with httpx.Client(transport=transport) as client:
            resp = client.get(
                "https://api.github.com/user",
                headers={"Authorization": "Bearer {{OAUTH2_ACCESS_TOKEN}}"},
            )

        body = resp.json()
        assert body["headers"]["authorization"] == "Bearer {{OAUTH2_ACCESS_TOKEN}}"

    def test_preserves_query_params(self) -> None:
        transport = _make_transport()
        with httpx.Client(transport=transport) as client:
            resp = client.get(
                "https://api.github.com/user/repos",
                params={"page": "2", "per_page": "50"},
            )

        body = resp.json()
        assert "page=2" in body["url"]
        assert "per_page=50" in body["url"]


class TestApprovalErrorIntegration:
    def test_403_with_approval_url_raises(self) -> None:
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(
                403,
                json={
                    "error": "insufficient_scope",
                    "approval_url": "https://keychains.dev/approve/abc",
                    "missing_scopes": ["repo"],
                },
            )

        transport = KeychainsTransport(
            token="test-token",
            transport=httpx.MockTransport(handler),
        )
        with httpx.Client(transport=transport) as client:
            with pytest.raises(ApprovalRequired) as exc_info:
                client.get("https://api.github.com/user/repos")

        assert exc_info.value.approval_url == "https://keychains.dev/approve/abc"
        assert exc_info.value.missing_scopes == ["repo"]

    def test_403_without_scope_error_passes_through(self) -> None:
        def handler(req: httpx.Request) -> httpx.Response:
            return httpx.Response(403, json={"error": "forbidden"})

        transport = KeychainsTransport(
            token="test-token",
            transport=httpx.MockTransport(handler),
        )
        with httpx.Client(transport=transport) as client:
            resp = client.get("https://api.github.com/user")

        assert resp.status_code == 403
