"""Tests for URL rewriting and header injection."""

from __future__ import annotations

import json

import httpx
import pytest

from keychains._transport import (
    PROXY_BASE,
    KeychainsTransport,
    _check_approval_error,
    _rewrite_url,
)
from keychains.exceptions import ApprovalRequired, MissingTokenError


class TestRewriteUrl:
    def test_basic_rewrite(self) -> None:
        url = httpx.URL("https://api.github.com/user/repos")
        result = _rewrite_url(url)
        assert str(result) == "https://keychains.dev/api.github.com/user/repos"

    def test_rewrite_with_query_params(self) -> None:
        url = httpx.URL("https://api.github.com/user/repos?page=1&per_page=10")
        result = _rewrite_url(url)
        assert (
            str(result)
            == "https://keychains.dev/api.github.com/user/repos?page=1&per_page=10"
        )

    def test_rewrite_with_deep_path(self) -> None:
        url = httpx.URL("https://api.stripe.com/v1/charges")
        result = _rewrite_url(url)
        assert str(result) == "https://keychains.dev/api.stripe.com/v1/charges"

    def test_rewrite_root_path(self) -> None:
        url = httpx.URL("https://api.github.com/")
        result = _rewrite_url(url)
        assert str(result) == "https://keychains.dev/api.github.com/"

    def test_proxy_base_is_keychains_dev(self) -> None:
        assert PROXY_BASE == "https://keychains.dev"


class TestCheckApprovalError:
    def _make_response(self, status_code: int, body: dict) -> httpx.Response:
        return httpx.Response(
            status_code=status_code,
            json=body,
        )

    def test_non_403_passes_through(self) -> None:
        response = self._make_response(200, {"ok": True})
        _check_approval_error(response)  # should not raise

    def test_403_without_approval_url_passes_through(self) -> None:
        response = self._make_response(403, {"error": "forbidden"})
        _check_approval_error(response)  # should not raise

    def test_403_with_approval_url_raises(self) -> None:
        response = self._make_response(
            403,
            {
                "error": "insufficient_scope",
                "approval_url": "https://keychains.dev/approve/123",
                "missing_scopes": ["repo", "user"],
            },
        )
        with pytest.raises(ApprovalRequired) as exc_info:
            _check_approval_error(response)

        err = exc_info.value
        assert err.approval_url == "https://keychains.dev/approve/123"
        assert err.missing_scopes == ["repo", "user"]
        assert err.code == "insufficient_scope"

    def test_403_scope_refused(self) -> None:
        response = self._make_response(
            403,
            {
                "error": "scope_refused",
                "refused_scopes": ["admin"],
            },
        )
        with pytest.raises(ApprovalRequired) as exc_info:
            _check_approval_error(response)

        err = exc_info.value
        assert err.code == "scope_refused"
        assert err.refused_scopes == ["admin"]
        assert "admin" in str(err)

    def test_403_with_authorization_url_key(self) -> None:
        response = self._make_response(
            403,
            {"authorizationUrl": "https://keychains.dev/approve/456"},
        )
        with pytest.raises(ApprovalRequired) as exc_info:
            _check_approval_error(response)

        assert exc_info.value.approval_url == "https://keychains.dev/approve/456"


class TestMissingToken:
    def test_missing_token_raises(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("KEYCHAINS_TOKEN", raising=False)
        with pytest.raises(MissingTokenError):
            KeychainsTransport(token=None)

    def test_explicit_token_works(self) -> None:
        transport = KeychainsTransport(
            token="test-token",
            transport=httpx.MockTransport(lambda req: httpx.Response(200)),
        )
        assert transport._token == "test-token"

    def test_env_token_works(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("KEYCHAINS_TOKEN", "env-token")
        transport = KeychainsTransport(
            transport=httpx.MockTransport(lambda req: httpx.Response(200)),
        )
        assert transport._token == "env-token"
