"""Tests for keychains.AsyncClient."""

from __future__ import annotations

import httpx
import pytest

from keychains._transport import AsyncKeychainsTransport


async def _echo_handler(request: httpx.Request) -> httpx.Response:
    return httpx.Response(
        200,
        json={
            "url": str(request.url),
            "method": request.method,
            "headers": dict(request.headers),
        },
    )


@pytest.mark.anyio
async def test_async_client_rewrites_url() -> None:
    transport = AsyncKeychainsTransport(
        token="test-token",
        transport=httpx.MockTransport(_echo_handler),
    )
    async with httpx.AsyncClient(transport=transport) as client:
        resp = await client.get("https://api.github.com/user/repos")
        body = resp.json()
        assert "keychains.dev/api.github.com" in body["url"]


@pytest.mark.anyio
async def test_async_client_injects_header() -> None:
    transport = AsyncKeychainsTransport(
        token="my-async-token",
        transport=httpx.MockTransport(_echo_handler),
    )
    async with httpx.AsyncClient(transport=transport) as client:
        resp = await client.get("https://api.github.com/user")
        body = resp.json()
        assert body["headers"]["x-proxy-authorization"] == "Bearer my-async-token"


@pytest.mark.anyio
async def test_async_client_post() -> None:
    transport = AsyncKeychainsTransport(
        token="test-token",
        transport=httpx.MockTransport(_echo_handler),
    )
    async with httpx.AsyncClient(transport=transport) as client:
        resp = await client.post("https://api.stripe.com/v1/charges")
        body = resp.json()
        assert body["method"] == "POST"
        assert "keychains.dev/api.stripe.com" in body["url"]
