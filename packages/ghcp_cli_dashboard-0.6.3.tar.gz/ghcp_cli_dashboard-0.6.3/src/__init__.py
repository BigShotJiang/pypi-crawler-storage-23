"""Copilot Dashboard — monitor all your GitHub Copilot CLI sessions."""

from .__version__ import __repository__, __version__

__all__ = ["__repository__", "__version__"]
