"""Version information for Copilot Dashboard."""

__version__ = "0.6.3"
__repository__ = "https://github.com/JeffSteinbok/ghcpCliDashboard"
