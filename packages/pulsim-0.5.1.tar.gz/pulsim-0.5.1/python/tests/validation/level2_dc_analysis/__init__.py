"""Level 2: DC analysis validation tests."""
