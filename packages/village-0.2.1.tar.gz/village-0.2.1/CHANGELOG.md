# Changelog

## 0.2.1 (2026-02-24)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/village-dev/village-python/compare/v0.2.0...v0.2.1)

### Bug Fixes

* **api:** manual updates ([3278696](https://github.com/village-dev/village-python/commit/3278696d5bd0c65d369e63d5f8aa6391936df3db))


### Chores

* **internal:** add request options to SSE classes ([86a4c4b](https://github.com/village-dev/village-python/commit/86a4c4be0f4ed2004bb983e33e257832342b6b8d))
* **internal:** make `test_proxy_environment_variables` more resilient ([f53452c](https://github.com/village-dev/village-python/commit/f53452cb9a74c630a6a740993cb246255923bc73))

## 0.2.0 (2026-02-20)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/village-dev/village-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** add edgar/quartr list endpoints, date filters to company.quartr events ([f524d2c](https://github.com/village-dev/village-python/commit/f524d2ce3046fd3ae1dc5861494eebefbd513aa2))


### Chores

* update SDK settings ([fd77be8](https://github.com/village-dev/village-python/commit/fd77be8bab9bb6f93db7f94a7823d7d8e1eb48f4))
* update SDK settings ([41312a1](https://github.com/village-dev/village-python/commit/41312a1f1b9b34bbde1294065fe6623fd8c7cf9e))
* update SDK settings ([e34b019](https://github.com/village-dev/village-python/commit/e34b0195cec19c1453e24e611ab8dfc584694d18))
* update SDK settings ([09c0156](https://github.com/village-dev/village-python/commit/09c0156da34a54b1ccef91bf48a59c3d4a5cb548))
* update SDK settings ([0a9a51f](https://github.com/village-dev/village-python/commit/0a9a51f402d246199b0d91d3be6f6da42aa447e5))
* update SDK settings ([bd6ed76](https://github.com/village-dev/village-python/commit/bd6ed76b0ba3fd5d869c77219b6e62086ba5710b))

## 0.1.0 (2026-02-20)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/village-dev/village-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** add company lookup/text endpoints, remove search APIs, restructure to ticker-based ([2b7215b](https://github.com/village-dev/village-python/commit/2b7215b3706c499cccd3ab1631c9bb6d37d91095))
* **api:** manual updates ([76d47c2](https://github.com/village-dev/village-python/commit/76d47c20773d4146cd9542e36c61ea6798f4cafb))
* **api:** manual updates ([37378e6](https://github.com/village-dev/village-python/commit/37378e6db961c0086182f146d43f974d6e3cac37))
* **api:** manual updates ([98770f7](https://github.com/village-dev/village-python/commit/98770f76a6f47c0d7d8eaeb29f072bc3ecb4c79c))
* **api:** manual updates ([9616c14](https://github.com/village-dev/village-python/commit/9616c144d751ce303821b574816622296252aeb3))


### Bug Fixes

* **api:** rename ticker to qualified_ticker in company endpoints ([a2f57eb](https://github.com/village-dev/village-python/commit/a2f57eb48654f770c1724dd8060b4c1c975a6fcc))
* **types:** make company/event fields required in quartr document/event types ([2f876a7](https://github.com/village-dev/village-python/commit/2f876a7670084c0afd3de4b5389d867309a82224))


### Chores

* **internal:** remove mock server code ([463a4d4](https://github.com/village-dev/village-python/commit/463a4d4672bd2f830b51a60976f5d673de607d46))
* sync repo ([ffc8534](https://github.com/village-dev/village-python/commit/ffc8534f83456b87fb441ecf949009d374bf15a7))
* update mock server docs ([1d8787d](https://github.com/village-dev/village-python/commit/1d8787d599fd8675d5f4de13449fc49cb0a7ad15))
* update SDK settings ([2941e7e](https://github.com/village-dev/village-python/commit/2941e7ef759d2084ec195eb2454edfe334f8f849))
* update SDK settings ([0824ef6](https://github.com/village-dev/village-python/commit/0824ef6cc1e7678ced4e1acb1e477e0cda8ad8e9))
* update SDK settings ([726caa2](https://github.com/village-dev/village-python/commit/726caa2e7220e250b67bb20b5450c8f242d1d34a))
* update SDK settings ([e0c11aa](https://github.com/village-dev/village-python/commit/e0c11aa433a9d8d8e4b084081d769aaddc62a6d0))
