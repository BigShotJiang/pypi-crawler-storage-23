# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import httpx
import pytest
from respx import MockRouter

from village import Village, AsyncVillage
from tests.utils import assert_matches_type
from village._response import (
    BinaryAPIResponse,
    AsyncBinaryAPIResponse,
    StreamedBinaryAPIResponse,
    AsyncStreamedBinaryAPIResponse,
)
from village.types.quartr import DocumentRetrieveResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestDocument:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Village) -> None:
        document = client.quartr.document.retrieve(
            789012,
        )
        assert_matches_type(DocumentRetrieveResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Village) -> None:
        response = client.quartr.document.with_raw_response.retrieve(
            789012,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert_matches_type(DocumentRetrieveResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Village) -> None:
        with client.quartr.document.with_streaming_response.retrieve(
            789012,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert_matches_type(DocumentRetrieveResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_download_pdf(self, client: Village, respx_mock: MockRouter) -> None:
        respx_mock.get("/quartr/document/789012/pdf").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        document = client.quartr.document.download_pdf(
            789012,
        )
        assert document.is_closed
        assert document.json() == {"foo": "bar"}
        assert cast(Any, document.is_closed) is True
        assert isinstance(document, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_download_pdf(self, client: Village, respx_mock: MockRouter) -> None:
        respx_mock.get("/quartr/document/789012/pdf").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        document = client.quartr.document.with_raw_response.download_pdf(
            789012,
        )

        assert document.is_closed is True
        assert document.http_request.headers.get("X-Stainless-Lang") == "python"
        assert document.json() == {"foo": "bar"}
        assert isinstance(document, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_download_pdf(self, client: Village, respx_mock: MockRouter) -> None:
        respx_mock.get("/quartr/document/789012/pdf").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.quartr.document.with_streaming_response.download_pdf(
            789012,
        ) as document:
            assert not document.is_closed
            assert document.http_request.headers.get("X-Stainless-Lang") == "python"

            assert document.json() == {"foo": "bar"}
            assert cast(Any, document.is_closed) is True
            assert isinstance(document, StreamedBinaryAPIResponse)

        assert cast(Any, document.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_text(self, client: Village) -> None:
        document = client.quartr.document.get_text(
            789012,
        )
        assert_matches_type(str, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get_text(self, client: Village) -> None:
        response = client.quartr.document.with_raw_response.get_text(
            789012,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = response.parse()
        assert_matches_type(str, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get_text(self, client: Village) -> None:
        with client.quartr.document.with_streaming_response.get_text(
            789012,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = response.parse()
            assert_matches_type(str, document, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncDocument:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncVillage) -> None:
        document = await async_client.quartr.document.retrieve(
            789012,
        )
        assert_matches_type(DocumentRetrieveResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncVillage) -> None:
        response = await async_client.quartr.document.with_raw_response.retrieve(
            789012,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert_matches_type(DocumentRetrieveResponse, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncVillage) -> None:
        async with async_client.quartr.document.with_streaming_response.retrieve(
            789012,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert_matches_type(DocumentRetrieveResponse, document, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_download_pdf(self, async_client: AsyncVillage, respx_mock: MockRouter) -> None:
        respx_mock.get("/quartr/document/789012/pdf").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        document = await async_client.quartr.document.download_pdf(
            789012,
        )
        assert document.is_closed
        assert await document.json() == {"foo": "bar"}
        assert cast(Any, document.is_closed) is True
        assert isinstance(document, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_download_pdf(self, async_client: AsyncVillage, respx_mock: MockRouter) -> None:
        respx_mock.get("/quartr/document/789012/pdf").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        document = await async_client.quartr.document.with_raw_response.download_pdf(
            789012,
        )

        assert document.is_closed is True
        assert document.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await document.json() == {"foo": "bar"}
        assert isinstance(document, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_download_pdf(self, async_client: AsyncVillage, respx_mock: MockRouter) -> None:
        respx_mock.get("/quartr/document/789012/pdf").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.quartr.document.with_streaming_response.download_pdf(
            789012,
        ) as document:
            assert not document.is_closed
            assert document.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await document.json() == {"foo": "bar"}
            assert cast(Any, document.is_closed) is True
            assert isinstance(document, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, document.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_text(self, async_client: AsyncVillage) -> None:
        document = await async_client.quartr.document.get_text(
            789012,
        )
        assert_matches_type(str, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get_text(self, async_client: AsyncVillage) -> None:
        response = await async_client.quartr.document.with_raw_response.get_text(
            789012,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        document = await response.parse()
        assert_matches_type(str, document, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get_text(self, async_client: AsyncVillage) -> None:
        async with async_client.quartr.document.with_streaming_response.get_text(
            789012,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            document = await response.parse()
            assert_matches_type(str, document, path=["response"])

        assert cast(Any, response.is_closed) is True
