# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from village import Village, AsyncVillage
from tests.utils import assert_matches_type
from village._utils import parse_date
from village.pagination import SyncPageNumber, AsyncPageNumber
from village.types.company import (
    QuartrListEventsResponse,
    QuartrListDocumentsResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestQuartr:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_documents(self, client: Village) -> None:
        quartr = client.company.quartr.list_documents(
            qualified_ticker="AAPL:NASDAQ",
        )
        assert_matches_type(SyncPageNumber[QuartrListDocumentsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_documents_with_all_params(self, client: Village) -> None:
        quartr = client.company.quartr.list_documents(
            qualified_ticker="AAPL:NASDAQ",
            earliest_date=parse_date("2019-12-27"),
            latest_date=parse_date("2019-12-27"),
            page=1,
            page_size=1,
            type_ids=[0],
        )
        assert_matches_type(SyncPageNumber[QuartrListDocumentsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_documents(self, client: Village) -> None:
        response = client.company.quartr.with_raw_response.list_documents(
            qualified_ticker="AAPL:NASDAQ",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quartr = response.parse()
        assert_matches_type(SyncPageNumber[QuartrListDocumentsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_documents(self, client: Village) -> None:
        with client.company.quartr.with_streaming_response.list_documents(
            qualified_ticker="AAPL:NASDAQ",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quartr = response.parse()
            assert_matches_type(SyncPageNumber[QuartrListDocumentsResponse], quartr, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_list_documents(self, client: Village) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `qualified_ticker` but received ''"):
            client.company.quartr.with_raw_response.list_documents(
                qualified_ticker="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_events(self, client: Village) -> None:
        quartr = client.company.quartr.list_events(
            qualified_ticker="AAPL:NASDAQ",
        )
        assert_matches_type(SyncPageNumber[QuartrListEventsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_events_with_all_params(self, client: Village) -> None:
        quartr = client.company.quartr.list_events(
            qualified_ticker="AAPL:NASDAQ",
            earliest_date=parse_date("2019-12-27"),
            latest_date=parse_date("2019-12-27"),
            page=1,
            page_size=1,
        )
        assert_matches_type(SyncPageNumber[QuartrListEventsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_events(self, client: Village) -> None:
        response = client.company.quartr.with_raw_response.list_events(
            qualified_ticker="AAPL:NASDAQ",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quartr = response.parse()
        assert_matches_type(SyncPageNumber[QuartrListEventsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_events(self, client: Village) -> None:
        with client.company.quartr.with_streaming_response.list_events(
            qualified_ticker="AAPL:NASDAQ",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quartr = response.parse()
            assert_matches_type(SyncPageNumber[QuartrListEventsResponse], quartr, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_list_events(self, client: Village) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `qualified_ticker` but received ''"):
            client.company.quartr.with_raw_response.list_events(
                qualified_ticker="",
            )


class TestAsyncQuartr:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_documents(self, async_client: AsyncVillage) -> None:
        quartr = await async_client.company.quartr.list_documents(
            qualified_ticker="AAPL:NASDAQ",
        )
        assert_matches_type(AsyncPageNumber[QuartrListDocumentsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_documents_with_all_params(self, async_client: AsyncVillage) -> None:
        quartr = await async_client.company.quartr.list_documents(
            qualified_ticker="AAPL:NASDAQ",
            earliest_date=parse_date("2019-12-27"),
            latest_date=parse_date("2019-12-27"),
            page=1,
            page_size=1,
            type_ids=[0],
        )
        assert_matches_type(AsyncPageNumber[QuartrListDocumentsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_documents(self, async_client: AsyncVillage) -> None:
        response = await async_client.company.quartr.with_raw_response.list_documents(
            qualified_ticker="AAPL:NASDAQ",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quartr = await response.parse()
        assert_matches_type(AsyncPageNumber[QuartrListDocumentsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_documents(self, async_client: AsyncVillage) -> None:
        async with async_client.company.quartr.with_streaming_response.list_documents(
            qualified_ticker="AAPL:NASDAQ",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quartr = await response.parse()
            assert_matches_type(AsyncPageNumber[QuartrListDocumentsResponse], quartr, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_list_documents(self, async_client: AsyncVillage) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `qualified_ticker` but received ''"):
            await async_client.company.quartr.with_raw_response.list_documents(
                qualified_ticker="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_events(self, async_client: AsyncVillage) -> None:
        quartr = await async_client.company.quartr.list_events(
            qualified_ticker="AAPL:NASDAQ",
        )
        assert_matches_type(AsyncPageNumber[QuartrListEventsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_events_with_all_params(self, async_client: AsyncVillage) -> None:
        quartr = await async_client.company.quartr.list_events(
            qualified_ticker="AAPL:NASDAQ",
            earliest_date=parse_date("2019-12-27"),
            latest_date=parse_date("2019-12-27"),
            page=1,
            page_size=1,
        )
        assert_matches_type(AsyncPageNumber[QuartrListEventsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_events(self, async_client: AsyncVillage) -> None:
        response = await async_client.company.quartr.with_raw_response.list_events(
            qualified_ticker="AAPL:NASDAQ",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quartr = await response.parse()
        assert_matches_type(AsyncPageNumber[QuartrListEventsResponse], quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_events(self, async_client: AsyncVillage) -> None:
        async with async_client.company.quartr.with_streaming_response.list_events(
            qualified_ticker="AAPL:NASDAQ",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quartr = await response.parse()
            assert_matches_type(AsyncPageNumber[QuartrListEventsResponse], quartr, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_list_events(self, async_client: AsyncVillage) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `qualified_ticker` but received ''"):
            await async_client.company.quartr.with_raw_response.list_events(
                qualified_ticker="",
            )
