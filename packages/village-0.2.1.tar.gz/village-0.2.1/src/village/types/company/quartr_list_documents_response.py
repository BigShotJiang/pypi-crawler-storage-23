# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..quartr_event import QuartrEvent
from ..quartr.quartr_document import QuartrDocument

__all__ = ["QuartrListDocumentsResponse"]


class QuartrListDocumentsResponse(QuartrDocument):
    """A Quartr document with its associated event."""

    event: QuartrEvent
    """The event associated with this document."""
