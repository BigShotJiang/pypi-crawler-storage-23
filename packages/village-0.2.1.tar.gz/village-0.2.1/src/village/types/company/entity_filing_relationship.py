# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["EntityFilingRelationship"]

EntityFilingRelationship: TypeAlias = Literal[
    "filer",
    "reporting_owner",
    "issuer",
    "issuing_entity",
    "subject_company",
    "serial_company",
    "filed_by",
    "depositor",
    "securitizer",
    "filed_for",
    "underwriter",
]
