# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ..quartr_event import QuartrEvent
from ..quartr.quartr_document import QuartrDocument

__all__ = ["QuartrListEventsResponse"]


class QuartrListEventsResponse(QuartrEvent):
    """An event with its associated documents (deduplicated by type)."""

    documents: List[QuartrDocument]
    """Documents associated with this event, deduplicated by document type."""
