# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import date
from typing_extensions import Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["QuartrListDocumentsParams"]


class QuartrListDocumentsParams(TypedDict, total=False):
    earliest_date: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Only include documents with an event date on or after this date (inclusive)."""

    latest_date: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Only include documents with an event date on or before this date (inclusive)."""

    page: int
    """Page number (1-based)."""

    page_size: int
    """Number of documents per page."""

    type_ids: Iterable[int]
    """Document type IDs to filter by."""
