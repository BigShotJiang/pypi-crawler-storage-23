# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import date
from typing_extensions import Annotated, TypedDict

from ..._types import SequenceNotStr
from ..._utils import PropertyInfo

__all__ = ["EdgarListFilingsParams"]


class EdgarListFilingsParams(TypedDict, total=False):
    earliest_date: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Only include filings with a filing date on or after this date (inclusive).

    This filters on the SEC filing date, not the period of report.
    """

    form_categories: SequenceNotStr[str]
    """Form categories to filter by."""

    form_types: SequenceNotStr[str]
    """Form types to filter by."""

    latest_date: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Only include filings with a filing date on or before this date (inclusive).

    This filters on the SEC filing date, not the period of report.
    """

    page: int
    """Page number (1-based)."""

    page_size: int
    """Number of filings per page."""
