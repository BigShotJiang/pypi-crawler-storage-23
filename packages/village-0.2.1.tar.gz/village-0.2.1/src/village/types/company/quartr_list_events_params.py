# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import date
from typing_extensions import Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["QuartrListEventsParams"]


class QuartrListEventsParams(TypedDict, total=False):
    earliest_date: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Only include events with a date on or after this date (inclusive)."""

    latest_date: Annotated[Union[str, date, None], PropertyInfo(format="iso8601")]
    """Only include events with a date on or before this date (inclusive)."""

    page: int
    """Page number (1-based)."""

    page_size: int
    """Number of events per page."""
