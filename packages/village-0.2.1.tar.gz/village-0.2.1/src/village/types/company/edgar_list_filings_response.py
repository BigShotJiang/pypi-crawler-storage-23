# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..edgar.edgar_filing import EdgarFiling
from .entity_filing_relationship import EntityFilingRelationship

__all__ = ["EdgarListFilingsResponse"]


class EdgarListFilingsResponse(EdgarFiling):
    """An SEC filing paired with its relationship to a specific entity."""

    relationship: EntityFilingRelationship
    """The type of relationship between the entity and this filing (e.g.

    filer, reporting owner).
    """
