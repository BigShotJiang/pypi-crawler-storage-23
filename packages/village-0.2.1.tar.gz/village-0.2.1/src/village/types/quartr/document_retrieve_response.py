# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..quartr_event import QuartrEvent
from .quartr_document import QuartrDocument
from ..quartr_company_resource import QuartrCompanyResource

__all__ = ["DocumentRetrieveResponse"]


class DocumentRetrieveResponse(QuartrDocument):
    """A Quartr document with its parent company and associated event."""

    company: QuartrCompanyResource
    """The company that published this document."""

    event: QuartrEvent
    """The event associated with this document."""
