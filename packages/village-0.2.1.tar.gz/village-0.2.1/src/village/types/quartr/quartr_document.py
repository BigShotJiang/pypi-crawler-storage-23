# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from ..._models import BaseModel

__all__ = ["QuartrDocument"]


class QuartrDocument(BaseModel):
    """An investor relations document from Quartr (e.g.

    transcript, slides, press release).
    """

    id: int
    """The unique Quartr document identifier."""

    company_id: int
    """The Quartr company ID associated with this document."""

    created_at: datetime
    """When the document was first added to Quartr.

    Note: this is the ingestion timestamp, not the original publication date.
    """

    date_published: datetime
    """The publication date of the document, derived from the associated event's date."""

    event_id: int
    """The Quartr event ID associated with this document."""

    file_url: str
    """The URL of the original document file."""

    page_count: int
    """The total number of pages in the document."""

    title: Optional[str] = None
    """The title of the document, if available."""

    type_id: int
    """The document type identifier (e.g. 1 for transcript, 2 for slides)."""

    updated_at: datetime
    """When the document record was last updated."""

    word_count: int
    """The total number of words in the document."""
