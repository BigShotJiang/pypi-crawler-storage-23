# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .._models import BaseModel

__all__ = ["EdgarListFormCategoriesResponse", "EdgarListFormCategoriesResponseItem"]


class EdgarListFormCategoriesResponseItem(BaseModel):
    """An EDGAR form category with its member forms."""

    description: str
    """A description of the form category."""

    forms: List[str]
    """The SEC form types in this category."""

    key: str
    """The unique key for this form category."""

    title: str
    """The display title of the form category."""


EdgarListFormCategoriesResponse: TypeAlias = List[EdgarListFormCategoriesResponseItem]
