# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .quartr_event import QuartrEvent
from .quartr.quartr_document import QuartrDocument
from .quartr_company_resource import QuartrCompanyResource

__all__ = ["QuartrRetrieveEventResponse"]


class QuartrRetrieveEventResponse(QuartrEvent):
    """A Quartr event with its parent company and all associated documents."""

    company: QuartrCompanyResource
    """The company that hosted this event."""

    documents: List[QuartrDocument]
    """All documents associated with this event."""
