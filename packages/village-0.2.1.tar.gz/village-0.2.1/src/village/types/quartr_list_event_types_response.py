# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import TypeAlias

from .._models import BaseModel

__all__ = ["QuartrListEventTypesResponse", "QuartrListEventTypesResponseItem"]


class QuartrListEventTypesResponseItem(BaseModel):
    """A Quartr event type."""

    id: int
    """The unique identifier of the event type."""

    name: str
    """The name of the event type."""

    parent: Optional[str] = None
    """The parent category of the event type."""


QuartrListEventTypesResponse: TypeAlias = List[QuartrListEventTypesResponseItem]
