# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import TypeAlias

from .._models import BaseModel

__all__ = ["QuartrListDocumentTypesResponse", "QuartrListDocumentTypesResponseItem"]


class QuartrListDocumentTypesResponseItem(BaseModel):
    """A Quartr document type."""

    id: int
    """The unique identifier of the document type."""

    category: str
    """The category this document type belongs to."""

    description: str
    """A description of the document type."""

    form: Optional[str] = None
    """The SEC form type, if applicable."""

    name: str
    """The name of the document type."""


QuartrListDocumentTypesResponse: TypeAlias = List[QuartrListDocumentTypesResponseItem]
