# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["QuartrEvent"]


class QuartrEvent(BaseModel):
    """An investor relations event from Quartr (e.g. earnings call, investor day)."""

    id: int
    """The unique Quartr event identifier."""

    backlink_url: str
    """URL to the event's page on Quartr."""

    company_id: int
    """The Quartr company ID that hosted this event."""

    created_at: datetime
    """When the event was first added."""

    date: datetime
    """The date and time of the event."""

    fiscal_period: Optional[str] = None
    """The fiscal period this event relates to (e.g. 'Q1', 'Q2', 'FY')."""

    fiscal_year: Optional[int] = None
    """The fiscal year this event relates to, if applicable."""

    title: str
    """The title of the event (e.g. 'Q3 2024 Earnings Call')."""

    type_id: int
    """The event type identifier (e.g. 1 for earnings calls)."""

    updated_at: datetime
    """When the event record was last updated."""
