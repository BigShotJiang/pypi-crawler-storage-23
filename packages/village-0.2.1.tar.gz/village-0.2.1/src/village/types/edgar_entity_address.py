# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel

__all__ = ["EdgarEntityAddress"]


class EdgarEntityAddress(BaseModel):
    """A mailing or business address on file with the SEC."""

    city: Optional[str] = None
    """City name."""

    phone: Optional[str] = None
    """Phone number."""

    state: Optional[str] = None
    """State or province code."""

    street1: Optional[str] = None
    """Primary street address line."""

    street2: Optional[str] = None
    """Secondary street address line."""

    zip: Optional[str] = None
    """ZIP or postal code."""
