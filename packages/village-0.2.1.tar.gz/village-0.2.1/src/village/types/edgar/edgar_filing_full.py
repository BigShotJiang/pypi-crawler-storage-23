# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ..._models import BaseModel
from .edgar_filing import EdgarFiling
from .edgar_document import EdgarDocument
from ..edgar_entity_resource import EdgarEntityResource
from ..company.entity_filing_relationship import EntityFilingRelationship

__all__ = ["EdgarFilingFull", "EdgarFilingFullEntityRelationship", "EdgarFilingFullEntityRelationshipRelationship"]


class EdgarFilingFullEntityRelationshipRelationship(BaseModel):
    """The entity-filing relationship record, including the entity's CIK and its role."""

    accession_number: str
    """The accession number of the related filing."""

    entity_cik: str
    """The CIK of the related entity."""

    relationship: EntityFilingRelationship
    """The type of relationship between the entity and the filing."""


class EdgarFilingFullEntityRelationship(BaseModel):
    """An entity paired with its relationship to a specific filing."""

    entity: EdgarEntityResource
    """The entity metadata."""

    relationship: EdgarFilingFullEntityRelationshipRelationship
    """The entity-filing relationship record, including the entity's CIK and its role."""


class EdgarFilingFull(EdgarFiling):
    """An SEC filing with its documents and related entities."""

    documents: List[EdgarDocument]
    """All documents contained in this filing."""

    entity_relationships: List[EdgarFilingFullEntityRelationship]
    """Entities associated with this filing and their relationship types (e.g.

    filer, reporting owner).
    """
