# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ...._models import BaseModel
from ..edgar_document import EdgarDocument
from ..edgar_filing_full import EdgarFilingFull

__all__ = ["DocumentRetrieveResponse", "DocumentRetrieveResponseToc"]


class DocumentRetrieveResponseToc(BaseModel):
    """A section of the table of contents."""

    heading_level: int

    page_idx: int

    title: str


class DocumentRetrieveResponse(EdgarDocument):
    """An EDGAR document with the full parent filing attached."""

    filing: EdgarFilingFull
    """The parent filing that contains this document."""

    toc: List[DocumentRetrieveResponseToc]
    """The table of contents of the document."""
