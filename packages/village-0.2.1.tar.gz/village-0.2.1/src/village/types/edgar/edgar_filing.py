# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import date, datetime

from ..._models import BaseModel

__all__ = ["EdgarFiling"]


class EdgarFiling(BaseModel):
    """An SEC EDGAR filing."""

    accession_number: str
    """The SEC accession number uniquely identifying this filing (e.g.

    '0000320193-23-000077').
    """

    action_date: Optional[date] = None
    """The grant or issue date, for Orders or Notices."""

    correction: bool
    """Whether this filing is a correction to a prior filing."""

    date_as_of_change: Optional[date] = None
    """The date associated with the filing's change, if applicable."""

    deletion: bool
    """Whether this filing is a deletion."""

    depositor_file_number: Optional[str] = None
    """The depositor file number for ABS-related filings."""

    filing_date: date
    """The date the filing was submitted to the SEC."""

    form: str
    """The filing form type as submitted (e.g. '10-K', '10-Q/A')."""

    is_amendment: bool
    """Whether this filing is an amendment to a prior filing."""

    normalized_form: str
    """The filing form type without amendment suffixes (e.g.

    '10-K' for both '10-K' and '10-K/A').
    """

    period_of_report_end: Optional[date] = None
    """The end date of the reporting period covered by this filing."""

    received_date: Optional[date] = None
    """The received date, for Orders or Notices."""

    securitizer_file_number: Optional[str] = None
    """The file number identifying an asset-backed security (ABS) filing."""

    timestamp: Optional[datetime] = None
    """The dissemination timestamp for post-acceptance corrections."""
