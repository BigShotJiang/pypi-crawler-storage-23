# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["EdgarDocument"]


class EdgarDocument(BaseModel):
    """A document from an SEC EDGAR filing."""

    accession_number: str
    """The accession number of the parent filing."""

    description: str
    """A short description of the document's contents."""

    document_id: str
    """Unique document identifier in '{accession_number}.{sequence}' format."""

    filename: str
    """The filename of the document as submitted to EDGAR."""

    page_count: int
    """The total number of pages in the document."""

    sequence: int
    """The document's position within the filing, starting from 1."""

    word_count: int
    """The total number of words in the document."""
