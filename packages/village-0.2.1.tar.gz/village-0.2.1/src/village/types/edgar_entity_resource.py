# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import date

from .._models import BaseModel
from .edgar_entity_address import EdgarEntityAddress

__all__ = ["EdgarEntityResource", "FormerName", "Ticker"]


class FormerName(BaseModel):
    """A previous legal name of an SEC EDGAR entity."""

    date_changed: date
    """The date when the name was changed."""

    former_name: str
    """The entity's previous legal name."""


class Ticker(BaseModel):
    """A stock ticker symbol associated with an SEC EDGAR entity."""

    exchange: str
    """The exchange the ticker is listed on (e.g. 'NASDAQ')."""

    qualified_ticker: str
    """The ticker qualified with exchange in '{ticker}:{exchange}' format (e.g.

    'AAPL:NASDAQ').
    """

    ticker: str
    """The ticker symbol (e.g. 'AAPL')."""


class EdgarEntityResource(BaseModel):
    """An SEC EDGAR entity (company or individual)."""

    business_address: Optional[EdgarEntityAddress] = None
    """A mailing or business address on file with the SEC."""

    cik: str
    """
    The 10-digit zero-padded Central Index Key (CIK) uniquely identifying this
    entity on EDGAR.
    """

    filing_date: Optional[date] = None
    """The date of the most recent filing that updated this entity's information."""

    fiscal_year_end: Optional[str] = None
    """The entity's fiscal year end in MMDD format (e.g. '1231' for December 31)."""

    former_names: List[FormerName]
    """Previous legal names of the entity, with the dates they were changed."""

    irs_number: Optional[str] = None
    """The IRS Employer Identification Number (EIN)."""

    mailing_address: Optional[EdgarEntityAddress] = None
    """A mailing or business address on file with the SEC."""

    name: str
    """The entity's current legal name as registered with the SEC."""

    phone_number: Optional[str] = None
    """The entity's phone number on file with the SEC."""

    sic: Optional[str] = None
    """
    The Standard Industrial Classification (SIC) code indicating the entity's
    primary business.
    """

    state_of_incorporation: Optional[str] = None
    """The U.S. state or foreign country of incorporation."""

    tickers: List[Ticker]
    """Stock ticker symbols associated with this entity."""
