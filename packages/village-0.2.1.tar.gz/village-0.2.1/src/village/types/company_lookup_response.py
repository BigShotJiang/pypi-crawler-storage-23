# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import date

from .._models import BaseModel
from .edgar_entity_resource import EdgarEntityResource
from .quartr_company_resource import QuartrCompanyResource

__all__ = ["CompanyLookupResponse", "CompanyProfile"]


class CompanyProfile(BaseModel):
    """Company profile summary from Financial Modeling Prep."""

    address: Optional[str] = None
    """The company's street address."""

    average_volume: Optional[float] = None
    """The average daily trading volume."""

    beta: Optional[float] = None
    """The stock's beta coefficient, measuring volatility relative to the market."""

    ceo: Optional[str] = None
    """The name of the company's CEO."""

    change: Optional[float] = None
    """The absolute price change from the previous close."""

    change_percentage: Optional[float] = None
    """The percentage price change from the previous close."""

    cik: Optional[str] = None
    """The SEC Central Index Key (CIK)."""

    city: Optional[str] = None
    """The city of the company's headquarters."""

    company_name: Optional[str] = None
    """The company's full name."""

    country: Optional[str] = None
    """The company's country of domicile."""

    currency: Optional[str] = None
    """The currency the stock is traded in (e.g. 'USD')."""

    cusip: Optional[str] = None
    """The CUSIP number."""

    default_image: Optional[bool] = None
    """Whether the logo image is a default placeholder."""

    description: Optional[str] = None
    """A brief description of the company's business."""

    exchange: Optional[str] = None
    """The stock exchange abbreviation (e.g. 'NASDAQ')."""

    exchange_full_name: Optional[str] = None
    """The full name of the stock exchange."""

    full_time_employees: Optional[str] = None
    """The number of full-time employees."""

    image: Optional[str] = None
    """URL to the company's logo image."""

    industry: Optional[str] = None
    """The company's industry classification."""

    ipo_date: Optional[date] = None
    """The date of the company's initial public offering."""

    is_actively_trading: Optional[bool] = None
    """Whether the stock is currently actively traded."""

    is_adr: Optional[bool] = None
    """Whether this is an American Depositary Receipt."""

    is_etf: Optional[bool] = None
    """Whether this entity is an Exchange-Traded Fund."""

    is_fund: Optional[bool] = None
    """Whether this entity is a fund."""

    isin: Optional[str] = None
    """The International Securities Identification Number."""

    last_dividend: Optional[float] = None
    """The most recent dividend payment per share."""

    market_cap: Optional[float] = None
    """The company's market capitalization in USD."""

    phone: Optional[str] = None
    """The company's phone number."""

    price: Optional[float] = None
    """The current stock price."""

    range: Optional[str] = None
    """The 52-week price range (e.g. '124.17-198.23')."""

    sector: Optional[str] = None
    """The company's sector classification."""

    state: Optional[str] = None
    """The state of the company's headquarters."""

    symbol: Optional[str] = None
    """The stock ticker symbol."""

    volume: Optional[int] = None
    """The current trading volume."""

    website: Optional[str] = None
    """The company's website URL."""

    zip: Optional[str] = None
    """The ZIP code of the company's headquarters."""


class CompanyLookupResponse(BaseModel):
    """Result of looking up a company by qualified ticker."""

    qualified_ticker: str
    """The normalized qualified ticker that was looked up."""

    company_profile: Optional[CompanyProfile] = None
    """Company profile summary from Financial Modeling Prep."""

    edgar_entity: Optional[EdgarEntityResource] = None
    """An SEC EDGAR entity (company or individual)."""

    quartr_company: Optional[QuartrCompanyResource] = None
    """A company from Quartr's investor relations database."""
