# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["QuartrCompanyResource", "Ticker"]


class Ticker(BaseModel):
    """A stock ticker symbol associated with a Quartr company."""

    exchange: str
    """The exchange the ticker is listed on (e.g. 'NASDAQ')."""

    qualified_ticker: str
    """The ticker qualified with exchange in '{ticker}:{exchange}' format (e.g.

    'AAPL:NASDAQ').
    """

    ticker: str
    """The ticker symbol (e.g. 'AAPL')."""


class QuartrCompanyResource(BaseModel):
    """A company from Quartr's investor relations database."""

    id: int
    """The unique Quartr company identifier."""

    backlink_url: str
    """URL to the company's page on Quartr."""

    country: str
    """The company's country of domicile."""

    created_at: datetime
    """When the company was first added."""

    display_name: Optional[str] = None
    """The company's display name, if different from the legal name."""

    isins: List[str]
    """International Securities Identification Numbers (ISINs) for this company."""

    name: str
    """The company's legal name."""

    tickers: List[Ticker]
    """Stock ticker symbols associated with this company."""

    updated_at: datetime
    """When the company record was last updated."""
