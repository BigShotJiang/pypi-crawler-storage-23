# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from .document import (
    DocumentResource,
    AsyncDocumentResource,
    DocumentResourceWithRawResponse,
    AsyncDocumentResourceWithRawResponse,
    DocumentResourceWithStreamingResponse,
    AsyncDocumentResourceWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.quartr_retrieve_event_response import QuartrRetrieveEventResponse
from ...types.quartr_list_event_types_response import QuartrListEventTypesResponse
from ...types.quartr_list_document_types_response import QuartrListDocumentTypesResponse

__all__ = ["QuartrResource", "AsyncQuartrResource"]


class QuartrResource(SyncAPIResource):
    @cached_property
    def document(self) -> DocumentResource:
        return DocumentResource(self._client)

    @cached_property
    def with_raw_response(self) -> QuartrResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return QuartrResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> QuartrResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return QuartrResourceWithStreamingResponse(self)

    def list_document_types(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuartrListDocumentTypesResponse:
        """
        List all available Quartr document types.

        Returns the full set of document types that can be used to filter documents via
        the `type_ids` parameter.
        """
        return self._get(
            "/quartr/document-types",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuartrListDocumentTypesResponse,
        )

    def list_event_types(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuartrListEventTypesResponse:
        """
        List all available Quartr event types.

        Returns the full set of event types used to categorize Quartr events.
        """
        return self._get(
            "/quartr/event-types",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuartrListEventTypesResponse,
        )

    def retrieve_event(
        self,
        event_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuartrRetrieveEventResponse:
        """
        Retrieve a Quartr event by its ID, including the parent company and all
        associated documents (e.g. transcript, slides, press release).

        Args:
          event_id: The Quartr event ID.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            f"/quartr/event/{event_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuartrRetrieveEventResponse,
        )


class AsyncQuartrResource(AsyncAPIResource):
    @cached_property
    def document(self) -> AsyncDocumentResource:
        return AsyncDocumentResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncQuartrResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return AsyncQuartrResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncQuartrResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return AsyncQuartrResourceWithStreamingResponse(self)

    async def list_document_types(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuartrListDocumentTypesResponse:
        """
        List all available Quartr document types.

        Returns the full set of document types that can be used to filter documents via
        the `type_ids` parameter.
        """
        return await self._get(
            "/quartr/document-types",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuartrListDocumentTypesResponse,
        )

    async def list_event_types(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuartrListEventTypesResponse:
        """
        List all available Quartr event types.

        Returns the full set of event types used to categorize Quartr events.
        """
        return await self._get(
            "/quartr/event-types",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuartrListEventTypesResponse,
        )

    async def retrieve_event(
        self,
        event_id: int,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuartrRetrieveEventResponse:
        """
        Retrieve a Quartr event by its ID, including the parent company and all
        associated documents (e.g. transcript, slides, press release).

        Args:
          event_id: The Quartr event ID.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            f"/quartr/event/{event_id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuartrRetrieveEventResponse,
        )


class QuartrResourceWithRawResponse:
    def __init__(self, quartr: QuartrResource) -> None:
        self._quartr = quartr

        self.list_document_types = to_raw_response_wrapper(
            quartr.list_document_types,
        )
        self.list_event_types = to_raw_response_wrapper(
            quartr.list_event_types,
        )
        self.retrieve_event = to_raw_response_wrapper(
            quartr.retrieve_event,
        )

    @cached_property
    def document(self) -> DocumentResourceWithRawResponse:
        return DocumentResourceWithRawResponse(self._quartr.document)


class AsyncQuartrResourceWithRawResponse:
    def __init__(self, quartr: AsyncQuartrResource) -> None:
        self._quartr = quartr

        self.list_document_types = async_to_raw_response_wrapper(
            quartr.list_document_types,
        )
        self.list_event_types = async_to_raw_response_wrapper(
            quartr.list_event_types,
        )
        self.retrieve_event = async_to_raw_response_wrapper(
            quartr.retrieve_event,
        )

    @cached_property
    def document(self) -> AsyncDocumentResourceWithRawResponse:
        return AsyncDocumentResourceWithRawResponse(self._quartr.document)


class QuartrResourceWithStreamingResponse:
    def __init__(self, quartr: QuartrResource) -> None:
        self._quartr = quartr

        self.list_document_types = to_streamed_response_wrapper(
            quartr.list_document_types,
        )
        self.list_event_types = to_streamed_response_wrapper(
            quartr.list_event_types,
        )
        self.retrieve_event = to_streamed_response_wrapper(
            quartr.retrieve_event,
        )

    @cached_property
    def document(self) -> DocumentResourceWithStreamingResponse:
        return DocumentResourceWithStreamingResponse(self._quartr.document)


class AsyncQuartrResourceWithStreamingResponse:
    def __init__(self, quartr: AsyncQuartrResource) -> None:
        self._quartr = quartr

        self.list_document_types = async_to_streamed_response_wrapper(
            quartr.list_document_types,
        )
        self.list_event_types = async_to_streamed_response_wrapper(
            quartr.list_event_types,
        )
        self.retrieve_event = async_to_streamed_response_wrapper(
            quartr.retrieve_event,
        )

    @cached_property
    def document(self) -> AsyncDocumentResourceWithStreamingResponse:
        return AsyncDocumentResourceWithStreamingResponse(self._quartr.document)
