# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .filing.filing import (
    FilingResource,
    AsyncFilingResource,
    FilingResourceWithRawResponse,
    AsyncFilingResourceWithRawResponse,
    FilingResourceWithStreamingResponse,
    AsyncFilingResourceWithStreamingResponse,
)
from ..._base_client import make_request_options
from ...types.edgar_list_form_categories_response import EdgarListFormCategoriesResponse

__all__ = ["EdgarResource", "AsyncEdgarResource"]


class EdgarResource(SyncAPIResource):
    @cached_property
    def filing(self) -> FilingResource:
        return FilingResource(self._client)

    @cached_property
    def with_raw_response(self) -> EdgarResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return EdgarResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EdgarResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return EdgarResourceWithStreamingResponse(self)

    def list_form_categories(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EdgarListFormCategoriesResponse:
        """
        List all available EDGAR form categories.

        Each category groups related SEC form types together (e.g. annual reports,
        quarterly reports, insider transactions).
        """
        return self._get(
            "/edgar/form-categories",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EdgarListFormCategoriesResponse,
        )


class AsyncEdgarResource(AsyncAPIResource):
    @cached_property
    def filing(self) -> AsyncFilingResource:
        return AsyncFilingResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncEdgarResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return AsyncEdgarResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEdgarResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return AsyncEdgarResourceWithStreamingResponse(self)

    async def list_form_categories(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EdgarListFormCategoriesResponse:
        """
        List all available EDGAR form categories.

        Each category groups related SEC form types together (e.g. annual reports,
        quarterly reports, insider transactions).
        """
        return await self._get(
            "/edgar/form-categories",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EdgarListFormCategoriesResponse,
        )


class EdgarResourceWithRawResponse:
    def __init__(self, edgar: EdgarResource) -> None:
        self._edgar = edgar

        self.list_form_categories = to_raw_response_wrapper(
            edgar.list_form_categories,
        )

    @cached_property
    def filing(self) -> FilingResourceWithRawResponse:
        return FilingResourceWithRawResponse(self._edgar.filing)


class AsyncEdgarResourceWithRawResponse:
    def __init__(self, edgar: AsyncEdgarResource) -> None:
        self._edgar = edgar

        self.list_form_categories = async_to_raw_response_wrapper(
            edgar.list_form_categories,
        )

    @cached_property
    def filing(self) -> AsyncFilingResourceWithRawResponse:
        return AsyncFilingResourceWithRawResponse(self._edgar.filing)


class EdgarResourceWithStreamingResponse:
    def __init__(self, edgar: EdgarResource) -> None:
        self._edgar = edgar

        self.list_form_categories = to_streamed_response_wrapper(
            edgar.list_form_categories,
        )

    @cached_property
    def filing(self) -> FilingResourceWithStreamingResponse:
        return FilingResourceWithStreamingResponse(self._edgar.filing)


class AsyncEdgarResourceWithStreamingResponse:
    def __init__(self, edgar: AsyncEdgarResource) -> None:
        self._edgar = edgar

        self.list_form_categories = async_to_streamed_response_wrapper(
            edgar.list_form_categories,
        )

    @cached_property
    def filing(self) -> AsyncFilingResourceWithStreamingResponse:
        return AsyncFilingResourceWithStreamingResponse(self._edgar.filing)
