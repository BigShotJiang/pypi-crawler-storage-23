# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from datetime import date

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncPageNumber, AsyncPageNumber
from ..._base_client import AsyncPaginator, make_request_options
from ...types.company import quartr_list_events_params, quartr_list_documents_params
from ...types.company.quartr_list_events_response import QuartrListEventsResponse
from ...types.company.quartr_list_documents_response import QuartrListDocumentsResponse

__all__ = ["QuartrResource", "AsyncQuartrResource"]


class QuartrResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> QuartrResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return QuartrResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> QuartrResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return QuartrResourceWithStreamingResponse(self)

    def list_documents(
        self,
        qualified_ticker: str,
        *,
        earliest_date: Union[str, date, None] | Omit = omit,
        latest_date: Union[str, date, None] | Omit = omit,
        page: int | Omit = omit,
        page_size: int | Omit = omit,
        type_ids: Iterable[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncPageNumber[QuartrListDocumentsResponse]:
        """
        List IR documents for a company identified by ticker, with pagination and
        filtering.

        Accepts a qualified ticker in SYMBOL:EXCHANGE format (e.g. 'AAPL:NASDAQ'). An
        unqualified symbol (e.g. 'AAPL') is also accepted.

        Resolves the ticker to a Quartr company, then returns documents ordered by event
        date. Each document includes its associated event. Use `type_ids` to filter by
        document type, and `earliest_date` / `latest_date` to restrict by event date.

        Args:
          qualified_ticker: A ticker symbol qualified with the exchange in SYMBOL:EXCHANGE format (e.g.
              'AAPL:NASDAQ').

          earliest_date: Only include documents with an event date on or after this date (inclusive).

          latest_date: Only include documents with an event date on or before this date (inclusive).

          page: Page number (1-based).

          page_size: Number of documents per page.

          type_ids: Document type IDs to filter by.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not qualified_ticker:
            raise ValueError(f"Expected a non-empty value for `qualified_ticker` but received {qualified_ticker!r}")
        return self._get_api_list(
            f"/company/{qualified_ticker}/quartr/documents",
            page=SyncPageNumber[QuartrListDocumentsResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "earliest_date": earliest_date,
                        "latest_date": latest_date,
                        "page": page,
                        "page_size": page_size,
                        "type_ids": type_ids,
                    },
                    quartr_list_documents_params.QuartrListDocumentsParams,
                ),
            ),
            model=QuartrListDocumentsResponse,
        )

    def list_events(
        self,
        qualified_ticker: str,
        *,
        earliest_date: Union[str, date, None] | Omit = omit,
        latest_date: Union[str, date, None] | Omit = omit,
        page: int | Omit = omit,
        page_size: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncPageNumber[QuartrListEventsResponse]:
        """
        List events for a company identified by ticker, with pagination and date
        filtering.

        Accepts a qualified ticker in SYMBOL:EXCHANGE format (e.g. 'AAPL:NASDAQ'). An
        unqualified symbol (e.g. 'AAPL') is also accepted.

        Resolves the ticker to a Quartr company, then returns events in reverse
        chronological order. Each event includes its associated documents, deduplicated
        by document type. Only events that have at least one document are included. Use
        `earliest_date` / `latest_date` to restrict by event date.

        Args:
          qualified_ticker: A ticker symbol qualified with the exchange in SYMBOL:EXCHANGE format (e.g.
              'AAPL:NASDAQ').

          earliest_date: Only include events with a date on or after this date (inclusive).

          latest_date: Only include events with a date on or before this date (inclusive).

          page: Page number (1-based).

          page_size: Number of events per page.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not qualified_ticker:
            raise ValueError(f"Expected a non-empty value for `qualified_ticker` but received {qualified_ticker!r}")
        return self._get_api_list(
            f"/company/{qualified_ticker}/quartr/events",
            page=SyncPageNumber[QuartrListEventsResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "earliest_date": earliest_date,
                        "latest_date": latest_date,
                        "page": page,
                        "page_size": page_size,
                    },
                    quartr_list_events_params.QuartrListEventsParams,
                ),
            ),
            model=QuartrListEventsResponse,
        )


class AsyncQuartrResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncQuartrResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return AsyncQuartrResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncQuartrResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return AsyncQuartrResourceWithStreamingResponse(self)

    def list_documents(
        self,
        qualified_ticker: str,
        *,
        earliest_date: Union[str, date, None] | Omit = omit,
        latest_date: Union[str, date, None] | Omit = omit,
        page: int | Omit = omit,
        page_size: int | Omit = omit,
        type_ids: Iterable[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[QuartrListDocumentsResponse, AsyncPageNumber[QuartrListDocumentsResponse]]:
        """
        List IR documents for a company identified by ticker, with pagination and
        filtering.

        Accepts a qualified ticker in SYMBOL:EXCHANGE format (e.g. 'AAPL:NASDAQ'). An
        unqualified symbol (e.g. 'AAPL') is also accepted.

        Resolves the ticker to a Quartr company, then returns documents ordered by event
        date. Each document includes its associated event. Use `type_ids` to filter by
        document type, and `earliest_date` / `latest_date` to restrict by event date.

        Args:
          qualified_ticker: A ticker symbol qualified with the exchange in SYMBOL:EXCHANGE format (e.g.
              'AAPL:NASDAQ').

          earliest_date: Only include documents with an event date on or after this date (inclusive).

          latest_date: Only include documents with an event date on or before this date (inclusive).

          page: Page number (1-based).

          page_size: Number of documents per page.

          type_ids: Document type IDs to filter by.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not qualified_ticker:
            raise ValueError(f"Expected a non-empty value for `qualified_ticker` but received {qualified_ticker!r}")
        return self._get_api_list(
            f"/company/{qualified_ticker}/quartr/documents",
            page=AsyncPageNumber[QuartrListDocumentsResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "earliest_date": earliest_date,
                        "latest_date": latest_date,
                        "page": page,
                        "page_size": page_size,
                        "type_ids": type_ids,
                    },
                    quartr_list_documents_params.QuartrListDocumentsParams,
                ),
            ),
            model=QuartrListDocumentsResponse,
        )

    def list_events(
        self,
        qualified_ticker: str,
        *,
        earliest_date: Union[str, date, None] | Omit = omit,
        latest_date: Union[str, date, None] | Omit = omit,
        page: int | Omit = omit,
        page_size: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[QuartrListEventsResponse, AsyncPageNumber[QuartrListEventsResponse]]:
        """
        List events for a company identified by ticker, with pagination and date
        filtering.

        Accepts a qualified ticker in SYMBOL:EXCHANGE format (e.g. 'AAPL:NASDAQ'). An
        unqualified symbol (e.g. 'AAPL') is also accepted.

        Resolves the ticker to a Quartr company, then returns events in reverse
        chronological order. Each event includes its associated documents, deduplicated
        by document type. Only events that have at least one document are included. Use
        `earliest_date` / `latest_date` to restrict by event date.

        Args:
          qualified_ticker: A ticker symbol qualified with the exchange in SYMBOL:EXCHANGE format (e.g.
              'AAPL:NASDAQ').

          earliest_date: Only include events with a date on or after this date (inclusive).

          latest_date: Only include events with a date on or before this date (inclusive).

          page: Page number (1-based).

          page_size: Number of events per page.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not qualified_ticker:
            raise ValueError(f"Expected a non-empty value for `qualified_ticker` but received {qualified_ticker!r}")
        return self._get_api_list(
            f"/company/{qualified_ticker}/quartr/events",
            page=AsyncPageNumber[QuartrListEventsResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "earliest_date": earliest_date,
                        "latest_date": latest_date,
                        "page": page,
                        "page_size": page_size,
                    },
                    quartr_list_events_params.QuartrListEventsParams,
                ),
            ),
            model=QuartrListEventsResponse,
        )


class QuartrResourceWithRawResponse:
    def __init__(self, quartr: QuartrResource) -> None:
        self._quartr = quartr

        self.list_documents = to_raw_response_wrapper(
            quartr.list_documents,
        )
        self.list_events = to_raw_response_wrapper(
            quartr.list_events,
        )


class AsyncQuartrResourceWithRawResponse:
    def __init__(self, quartr: AsyncQuartrResource) -> None:
        self._quartr = quartr

        self.list_documents = async_to_raw_response_wrapper(
            quartr.list_documents,
        )
        self.list_events = async_to_raw_response_wrapper(
            quartr.list_events,
        )


class QuartrResourceWithStreamingResponse:
    def __init__(self, quartr: QuartrResource) -> None:
        self._quartr = quartr

        self.list_documents = to_streamed_response_wrapper(
            quartr.list_documents,
        )
        self.list_events = to_streamed_response_wrapper(
            quartr.list_events,
        )


class AsyncQuartrResourceWithStreamingResponse:
    def __init__(self, quartr: AsyncQuartrResource) -> None:
        self._quartr = quartr

        self.list_documents = async_to_streamed_response_wrapper(
            quartr.list_documents,
        )
        self.list_events = async_to_streamed_response_wrapper(
            quartr.list_events,
        )
