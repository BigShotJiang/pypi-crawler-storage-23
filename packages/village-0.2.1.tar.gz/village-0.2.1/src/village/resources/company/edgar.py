# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import date

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...pagination import SyncPageNumber, AsyncPageNumber
from ..._base_client import AsyncPaginator, make_request_options
from ...types.company import edgar_list_filings_params
from ...types.company.edgar_list_filings_response import EdgarListFilingsResponse

__all__ = ["EdgarResource", "AsyncEdgarResource"]


class EdgarResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> EdgarResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return EdgarResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EdgarResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return EdgarResourceWithStreamingResponse(self)

    def list_filings(
        self,
        qualified_ticker: str,
        *,
        earliest_date: Union[str, date, None] | Omit = omit,
        form_categories: SequenceNotStr[str] | Omit = omit,
        form_types: SequenceNotStr[str] | Omit = omit,
        latest_date: Union[str, date, None] | Omit = omit,
        page: int | Omit = omit,
        page_size: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncPageNumber[EdgarListFilingsResponse]:
        """
        List SEC filings for a company identified by ticker, with pagination and
        filtering.

        Accepts a qualified ticker in SYMBOL:EXCHANGE format (e.g. 'AAPL:NASDAQ'). An
        unqualified symbol (e.g. 'AAPL') is also accepted.

        Resolves the ticker to an EDGAR entity, then returns filings in reverse
        chronological order. Each filing is annotated with the entity's relationship to
        it (e.g. filer, reporting owner). Use `form_types` and `form_categories` to
        narrow results by filing type, and `earliest_date` / `latest_date` to restrict
        by filing date.

        Args:
          qualified_ticker: A ticker symbol qualified with the exchange in SYMBOL:EXCHANGE format (e.g.
              'AAPL:NASDAQ').

          earliest_date: Only include filings with a filing date on or after this date (inclusive). This
              filters on the SEC filing date, not the period of report.

          form_categories: Form categories to filter by.

          form_types: Form types to filter by.

          latest_date: Only include filings with a filing date on or before this date (inclusive). This
              filters on the SEC filing date, not the period of report.

          page: Page number (1-based).

          page_size: Number of filings per page.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not qualified_ticker:
            raise ValueError(f"Expected a non-empty value for `qualified_ticker` but received {qualified_ticker!r}")
        return self._get_api_list(
            f"/company/{qualified_ticker}/edgar/filings",
            page=SyncPageNumber[EdgarListFilingsResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "earliest_date": earliest_date,
                        "form_categories": form_categories,
                        "form_types": form_types,
                        "latest_date": latest_date,
                        "page": page,
                        "page_size": page_size,
                    },
                    edgar_list_filings_params.EdgarListFilingsParams,
                ),
            ),
            model=EdgarListFilingsResponse,
        )


class AsyncEdgarResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncEdgarResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return AsyncEdgarResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEdgarResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return AsyncEdgarResourceWithStreamingResponse(self)

    def list_filings(
        self,
        qualified_ticker: str,
        *,
        earliest_date: Union[str, date, None] | Omit = omit,
        form_categories: SequenceNotStr[str] | Omit = omit,
        form_types: SequenceNotStr[str] | Omit = omit,
        latest_date: Union[str, date, None] | Omit = omit,
        page: int | Omit = omit,
        page_size: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[EdgarListFilingsResponse, AsyncPageNumber[EdgarListFilingsResponse]]:
        """
        List SEC filings for a company identified by ticker, with pagination and
        filtering.

        Accepts a qualified ticker in SYMBOL:EXCHANGE format (e.g. 'AAPL:NASDAQ'). An
        unqualified symbol (e.g. 'AAPL') is also accepted.

        Resolves the ticker to an EDGAR entity, then returns filings in reverse
        chronological order. Each filing is annotated with the entity's relationship to
        it (e.g. filer, reporting owner). Use `form_types` and `form_categories` to
        narrow results by filing type, and `earliest_date` / `latest_date` to restrict
        by filing date.

        Args:
          qualified_ticker: A ticker symbol qualified with the exchange in SYMBOL:EXCHANGE format (e.g.
              'AAPL:NASDAQ').

          earliest_date: Only include filings with a filing date on or after this date (inclusive). This
              filters on the SEC filing date, not the period of report.

          form_categories: Form categories to filter by.

          form_types: Form types to filter by.

          latest_date: Only include filings with a filing date on or before this date (inclusive). This
              filters on the SEC filing date, not the period of report.

          page: Page number (1-based).

          page_size: Number of filings per page.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not qualified_ticker:
            raise ValueError(f"Expected a non-empty value for `qualified_ticker` but received {qualified_ticker!r}")
        return self._get_api_list(
            f"/company/{qualified_ticker}/edgar/filings",
            page=AsyncPageNumber[EdgarListFilingsResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "earliest_date": earliest_date,
                        "form_categories": form_categories,
                        "form_types": form_types,
                        "latest_date": latest_date,
                        "page": page,
                        "page_size": page_size,
                    },
                    edgar_list_filings_params.EdgarListFilingsParams,
                ),
            ),
            model=EdgarListFilingsResponse,
        )


class EdgarResourceWithRawResponse:
    def __init__(self, edgar: EdgarResource) -> None:
        self._edgar = edgar

        self.list_filings = to_raw_response_wrapper(
            edgar.list_filings,
        )


class AsyncEdgarResourceWithRawResponse:
    def __init__(self, edgar: AsyncEdgarResource) -> None:
        self._edgar = edgar

        self.list_filings = async_to_raw_response_wrapper(
            edgar.list_filings,
        )


class EdgarResourceWithStreamingResponse:
    def __init__(self, edgar: EdgarResource) -> None:
        self._edgar = edgar

        self.list_filings = to_streamed_response_wrapper(
            edgar.list_filings,
        )


class AsyncEdgarResourceWithStreamingResponse:
    def __init__(self, edgar: AsyncEdgarResource) -> None:
        self._edgar = edgar

        self.list_filings = async_to_streamed_response_wrapper(
            edgar.list_filings,
        )
