# Company

Types:

```python
from village.types import (
    EdgarEntityAddress,
    EdgarEntityResource,
    QuartrCompanyResource,
    CompanyLookupResponse,
)
```

Methods:

- <code title="get /company/{qualified_ticker}">client.company.<a href="./src/village/resources/company/company.py">lookup</a>(qualified_ticker) -> <a href="./src/village/types/company_lookup_response.py">CompanyLookupResponse</a></code>

## Edgar

Types:

```python
from village.types.company import EntityFilingRelationship, EdgarListFilingsResponse
```

Methods:

- <code title="get /company/{qualified_ticker}/edgar/filings">client.company.edgar.<a href="./src/village/resources/company/edgar.py">list_filings</a>(qualified_ticker, \*\*<a href="src/village/types/company/edgar_list_filings_params.py">params</a>) -> <a href="./src/village/types/company/edgar_list_filings_response.py">SyncPageNumber[EdgarListFilingsResponse]</a></code>

## Quartr

Types:

```python
from village.types.company import QuartrListDocumentsResponse, QuartrListEventsResponse
```

Methods:

- <code title="get /company/{qualified_ticker}/quartr/documents">client.company.quartr.<a href="./src/village/resources/company/quartr.py">list_documents</a>(qualified_ticker, \*\*<a href="src/village/types/company/quartr_list_documents_params.py">params</a>) -> <a href="./src/village/types/company/quartr_list_documents_response.py">SyncPageNumber[QuartrListDocumentsResponse]</a></code>
- <code title="get /company/{qualified_ticker}/quartr/events">client.company.quartr.<a href="./src/village/resources/company/quartr.py">list_events</a>(qualified_ticker, \*\*<a href="src/village/types/company/quartr_list_events_params.py">params</a>) -> <a href="./src/village/types/company/quartr_list_events_response.py">SyncPageNumber[QuartrListEventsResponse]</a></code>

# Edgar

Types:

```python
from village.types import EdgarListFormCategoriesResponse
```

Methods:

- <code title="get /edgar/form-categories">client.edgar.<a href="./src/village/resources/edgar/edgar.py">list_form_categories</a>() -> <a href="./src/village/types/edgar_list_form_categories_response.py">EdgarListFormCategoriesResponse</a></code>

## Filing

Types:

```python
from village.types.edgar import EdgarDocument, EdgarFiling, EdgarFilingFull
```

Methods:

- <code title="get /edgar/filing/{accession_number}">client.edgar.filing.<a href="./src/village/resources/edgar/filing/filing.py">retrieve</a>(accession_number) -> <a href="./src/village/types/edgar/edgar_filing_full.py">EdgarFilingFull</a></code>

### Document

Types:

```python
from village.types.edgar.filing import DocumentRetrieveResponse, DocumentGetTextResponse
```

Methods:

- <code title="get /edgar/filing/{accession_number}/document/{sequence}">client.edgar.filing.document.<a href="./src/village/resources/edgar/filing/document.py">retrieve</a>(sequence, \*, accession_number) -> <a href="./src/village/types/edgar/filing/document_retrieve_response.py">DocumentRetrieveResponse</a></code>
- <code title="get /edgar/filing/{accession_number}/document/{sequence}/pdf">client.edgar.filing.document.<a href="./src/village/resources/edgar/filing/document.py">download_pdf</a>(sequence, \*, accession_number) -> BinaryAPIResponse</code>
- <code title="get /edgar/filing/{accession_number}/document/{sequence}/text">client.edgar.filing.document.<a href="./src/village/resources/edgar/filing/document.py">get_text</a>(sequence, \*, accession_number) -> str</code>

# Quartr

Types:

```python
from village.types import (
    QuartrEvent,
    QuartrListDocumentTypesResponse,
    QuartrListEventTypesResponse,
    QuartrRetrieveEventResponse,
)
```

Methods:

- <code title="get /quartr/document-types">client.quartr.<a href="./src/village/resources/quartr/quartr.py">list_document_types</a>() -> <a href="./src/village/types/quartr_list_document_types_response.py">QuartrListDocumentTypesResponse</a></code>
- <code title="get /quartr/event-types">client.quartr.<a href="./src/village/resources/quartr/quartr.py">list_event_types</a>() -> <a href="./src/village/types/quartr_list_event_types_response.py">QuartrListEventTypesResponse</a></code>
- <code title="get /quartr/event/{event_id}">client.quartr.<a href="./src/village/resources/quartr/quartr.py">retrieve_event</a>(event_id) -> <a href="./src/village/types/quartr_retrieve_event_response.py">QuartrRetrieveEventResponse</a></code>

## Document

Types:

```python
from village.types.quartr import QuartrDocument, DocumentRetrieveResponse, DocumentGetTextResponse
```

Methods:

- <code title="get /quartr/document/{document_id}">client.quartr.document.<a href="./src/village/resources/quartr/document.py">retrieve</a>(document_id) -> <a href="./src/village/types/quartr/document_retrieve_response.py">DocumentRetrieveResponse</a></code>
- <code title="get /quartr/document/{document_id}/pdf">client.quartr.document.<a href="./src/village/resources/quartr/document.py">download_pdf</a>(document_id) -> BinaryAPIResponse</code>
- <code title="get /quartr/document/{document_id}/text">client.quartr.document.<a href="./src/village/resources/quartr/document.py">get_text</a>(document_id) -> str</code>
