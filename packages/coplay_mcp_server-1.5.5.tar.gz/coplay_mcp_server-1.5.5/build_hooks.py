"""Build hooks for Hatchling to run code generation before building."""

import logging
import sys
from pathlib import Path
from hatchling.builders.hooks.plugin.interface import BuildHookInterface


class CustomBuildHook(BuildHookInterface):
    """Custom build hook to run code generation before building."""
    
    PLUGIN_NAME = 'custom'
    
    def initialize(self, version, build_data):
        """Initialize build hook - run code generation before building."""
        print("Running MCP tool code generation as pre-build step...")
        
        try:
            # Import and run the code generator
            sys.path.insert(0, str(Path(__file__).parent))
            from coplay_mcp_server.code_generator import MCPToolCodeGenerator

            # Set up logging for the build process
            logging.basicConfig(level=logging.INFO, format="[BUILD] %(message)s")

            generator = MCPToolCodeGenerator()

            # Only regenerate when the Backend schema directory is available.
            # When `python -m build` builds the wheel from the sdist, the sdist
            # does not contain the Backend directory, so code generation would
            # fail and delete the pre-generated files before raising. Skipping
            # generation in that case preserves the files that were included in
            # the sdist by the first (sdist) build hook invocation.
            schemas_path = generator.backend_path / "coplay" / "tool_schemas"
            if schemas_path.exists():
                generator.generate_all_tools()
                print("MCP tool code generation completed successfully!")
            else:
                print("Backend schemas not available, using pre-generated tool files.")

        except Exception as e:
            print(f"Error during code generation: {e}")
            # Don't fail the build if code generation fails, just warn
            print("Warning: Code generation failed, using existing generated files if available")

        # Force-include the generated files in the build artifact.
        # This runs regardless of whether generation succeeded or was skipped,
        # so pre-generated files from the sdist are always picked up when
        # building the wheel from an sdist (where Backend/ is unavailable).
        # The generated_tools/*.py files are gitignored, so hatchling would
        # exclude them by default.
        generated_tools_dir = Path(__file__).parent / "coplay_mcp_server" / "generated_tools"
        for tool_file in generated_tools_dir.glob("*_tools.py"):
            rel_path = tool_file.relative_to(Path(__file__).parent).as_posix()
            build_data["force_include"][rel_path] = rel_path
    
    def finalize(self, version, build_data, artifact_path):
        """Finalize build hook - cleanup if needed."""
        pass
