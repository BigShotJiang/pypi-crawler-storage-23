"""Main entry point for Coplay MCP Server using FastMCP."""

import logging
import logging.handlers
import os
import sys
import importlib
from pathlib import Path

from typing import Any, Optional, Annotated

from pydantic import Field
from coplay_mcp_server.process_discovery import discover_unity_project_roots
from fastmcp import FastMCP

from coplay_mcp_server.unity_client import UnityRpcClient

# Set binary mode for stdin/stdout/stderr on Windows
# This is necessary for proper MCP protocol communication on Windows
if sys.platform == 'win32':
    import msvcrt
    msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
    msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)
    msvcrt.setmode(sys.stderr.fileno(), os.O_BINARY)


def _get_default_log_dir() -> str:
    """Get the default log directory path based on the platform."""
    if sys.platform == "win32":
        base = os.getenv("LOCALAPPDATA", os.path.expanduser("~"))
        return os.path.join(base, "Coplay", "Logs")
    elif sys.platform == "darwin":
        return os.path.expanduser("~/Library/Logs/Coplay")
    else:
        return os.path.expanduser("~/.local/share/coplay/logs")


def _cleanup_old_log_files(log_dir: str, max_age_days: int = 3) -> None:
    """Remove log files older than *max_age_days* from *log_dir*.

    Cleans up stale per-instance logs (and their rotated backups) that
    ``TimedRotatingFileHandler`` cannot manage because they belong to
    previous, now-dead processes.
    """
    import glob
    import time as _time

    cutoff = _time.time() - max_age_days * 86400
    for path in glob.glob(os.path.join(log_dir, "coplay_mcp_*.log*")):
        try:
            if os.path.getmtime(path) < cutoff:
                os.remove(path)
        except OSError:
            pass


def setup_logging() -> None:
    """Set up logging configuration with file logging and configurable log level via environment variables.

    Logs are always written to a file. By default the log file is placed in a
    platform-specific directory (e.g. %LOCALAPPDATA%/Coplay/Logs on Windows).
    Each process gets its own log file (``coplay_mcp_<pid>.log``) so that
    multiple instances don't clobber each other.

    Environment variables:
    - COPLAY_LOG_FILE: Override the default log file path.
    - COPLAY_LOG_LEVEL: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL). Defaults to WARNING.
    - COPLAY_FILE_LOG_LEVEL: Separate log level for the file handler. Defaults to DEBUG so
      that detailed diagnostics are always captured on disk regardless of the stderr level.
    """

    # Get log levels from environment variables
    log_level_str = os.getenv("COPLAY_LOG_LEVEL", "WARNING").upper()
    log_level = getattr(logging, log_level_str, logging.WARNING)

    file_log_level_str = os.getenv("COPLAY_FILE_LOG_LEVEL", "DEBUG").upper()
    file_log_level = getattr(logging, file_log_level_str, logging.DEBUG)

    # Determine log file path: explicit env var > default per-PID path
    log_file = os.getenv("COPLAY_LOG_FILE")
    if not log_file:
        log_dir = _get_default_log_dir()
        log_file = os.path.join(log_dir, f"coplay_mcp_{os.getpid()}.log")
    else:
        log_dir = os.path.dirname(log_file)

    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    # Create handlers list – stderr handler uses the user-configured level
    stderr_handler = logging.StreamHandler(sys.stderr)
    stderr_handler.setLevel(log_level)
    stderr_handler.setFormatter(logging.Formatter(log_format))
    handlers: list[logging.Handler] = [stderr_handler]

    # Always set up the file handler
    try:
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)

        # Clean up stale log files from previous instances on startup
        if log_dir:
            _cleanup_old_log_files(log_dir)

        file_handler = logging.handlers.TimedRotatingFileHandler(
            log_file, when='midnight', backupCount=3, encoding='utf-8',
        )
        file_handler.setLevel(file_log_level)
        file_handler.setFormatter(logging.Formatter(log_format))
        handlers.append(file_handler)

        sys.stderr.write(f"File logging enabled: {log_file} (level={file_log_level_str}, rotation=daily, retention=3 days)\n")
    except Exception as e:
        sys.stderr.write(f"Failed to set up file logging to {log_file}: {e}\n")

    # Configure root logger at the lowest level so both handlers receive messages
    logging.basicConfig(
        level=min(log_level, file_log_level),
        format=log_format,
        handlers=handlers,
    )

    # Set specific log levels for noisy libraries
    logging.getLogger("watchdog").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)


setup_logging()


# Initialize FastMCP server
mcp = FastMCP(name="coplay-mcp-server")

# Global Unity client instance
unity_client = UnityRpcClient()

logger = logging.getLogger(__name__)


def load_tool_modules() -> list:
    """Dynamically discover and load all tool modules from generated_tools directory.
    
    Returns:
        List of loaded tool modules that have a register_tools function.
    """
    generated_tools_dir = Path(__file__).parent / "generated_tools"
    tool_modules = []
    
    # Find all *_tools.py files in the generated_tools directory
    for tool_file in generated_tools_dir.glob("*_tools.py"):
        module_name = tool_file.stem  # Get filename without extension
        try:
            # Dynamically import the module
            module = importlib.import_module(f"coplay_mcp_server.generated_tools.{module_name}")
            
            # Verify the module has a register_tools function
            if hasattr(module, "register_tools"):
                tool_modules.append(module)
                logger.debug(f"Loaded tool module: {module_name}")
            else:
                logger.warning(f"Module {module_name} does not have a register_tools function, skipping")
        except Exception as e:
            logger.error(f"Failed to load tool module {module_name}: {e}")
            # Continue loading other modules even if one fails
            continue
    
    logger.info(f"Discovered {len(tool_modules)} tool modules")
    return tool_modules


@mcp.tool()
async def set_unity_project_root(
    unity_project_root: str
) -> str:
    """Set the Unity project root path for the MCP server instance. This tool should be called before using any other Unity tools."""
    try:
        logger.info(f"Setting Unity project root to: {unity_project_root}")

        if not unity_project_root or not unity_project_root.strip():
            raise ValueError("Unity project root cannot be empty")

        # Set the Unity project root in the RPC client
        unity_client.set_unity_project_root(unity_project_root)

        result = f"Unity project root set to: {unity_project_root}"
        logger.info("Unity project root set successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to set Unity project root: {e}")
        raise


@mcp.tool()
async def list_unity_project_roots() -> Any:
    """List all project roots of currently open Unity instances. This tool discovers all running Unity Editor instances and returns their project root directories."""
    try:
        logger.info("Discovering Unity project roots...")

        project_roots = discover_unity_project_roots()
        return {
            "count": len(project_roots),
            "projectRoots": [
                {
                    "projectRoot": root,
                    "projectName": Path(root).name,
                }
                for root in project_roots
            ],
        }
    except Exception as e:
        logger.error(f"Failed to list Unity project roots: {e}")
        raise


@mcp.tool()
async def create_coplay_task(
    prompt: Annotated[
        str,
        Field(description="The task prompt to submit"),
    ],
    file_paths: Annotated[
        Optional[str],
        Field(description="Optional comma-separated file paths to attach as context"),
    ] = None,
    model: Annotated[
        Optional[str],
        Field(description="Optional AI model to use for this task"),
    ] = None,
) -> Any:
    """Creates a new task in the Unity Editor with the specified prompt and optional file attachments.

    Args:
        prompt: The task prompt to submit
        file_paths: Optional comma-separated file paths to attach as context
        model: Optional AI model to use for this task
    """
    try:
        logger.info(f"Creating task with prompt: {prompt[:10000]}...")

        params = {"prompt": prompt}
        if file_paths:
            params["file_paths"] = file_paths
        if model:
            params["model"] = model

        # Always wait for completion
        params["wait_for_completion"] = "true"

        # Use a longer timeout (610 seconds) to accommodate Unity's default 600-second timeout
        result = await unity_client.execute_request(
            "create_task", params, timeout=610.0
        )
        return result
    except Exception as e:
        logger.error(f"Failed to create task: {e}")
        raise


def main():
    """Initialize MCP server with generated tools and start serving."""
    try:
        logger.info("Initializing Coplay MCP Server...")

        # Dynamically load all tool modules
        tool_modules = load_tool_modules()

        # Register all discovered tool modules
        total_tools = 0
        for module in tool_modules:
            try:
                module.register_tools(mcp, unity_client)
                # Count tools by checking for functions with @mcp.tool decorator
                module_tools = [
                    name
                    for name in dir(module)
                    if not name.startswith("_") and name != "register_tools"
                ]
                total_tools += len(module_tools)
                logger.info(f"Registered tools from {module.__name__}")
            except Exception as e:
                logger.error(f"Failed to register tools from {module.__name__}: {e}")
                # Continue registering other modules even if one fails
                continue

        logger.info(f"Total generated tools registered: {total_tools}")
        logger.info("Coplay MCP Server initialized successfully")

        # Start the MCP server
        mcp.run()

    except Exception as e:
        logger.error(f"Failed to initialize MCP server: {e}")
        raise


if __name__ == "__main__":
    main()
