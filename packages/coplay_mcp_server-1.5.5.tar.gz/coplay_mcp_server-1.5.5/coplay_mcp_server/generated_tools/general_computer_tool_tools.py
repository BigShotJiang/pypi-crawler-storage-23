"""Generated MCP tools from general_computer_tool_schema.json"""

import logging
from typing import Annotated, Optional, Any, Dict, Literal
from pydantic import Field
from fastmcp import FastMCP
from ..unity_client import UnityRpcClient

logger = logging.getLogger(__name__)

# Global references to be set by register_tools
_mcp: Optional[FastMCP] = None
_unity_client: Optional[UnityRpcClient] = None


async def read_file(
    path: Annotated[
        str,
        Field(
            description="""The path of the file to read (relative to the project root)"""
        ),
    ],
    max_lines: Annotated[
        int | None,
        Field(
            description="""Optional maximum number of lines to read. Defaults to 5000 if not provided or invalid. Use this to limit the number of lines returned, useful for large files."""
        ),
    ] = None,
    lines_to_skip: Annotated[
        int | None,
        Field(
            description="""Optional number of lines to skip at the beginning of the file. Defaults to 0 if not provided or invalid. Use this to skip the first n lines of the file."""
        ),
    ] = None,
) -> Any:
    """Request to read the contents of a file at the specified path. Use this when you need to examine the contents of an existing file you do not know the contents of, for example to analyze code, review text files, or extract information from configuration files. Automatically extracts raw text from PDF and DOCX files. May not be suitable for other types of binary files, as it returns the raw content as a string."""
    try:
        logger.debug(f"Executing read_file with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if path is not None:
            params['path'] = str(path)
        if max_lines is not None:
            params['max_lines'] = str(max_lines)
        if lines_to_skip is not None:
            params['lines_to_skip'] = str(lines_to_skip)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('read_file', params)
        logger.debug(f"read_file completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute read_file: {e}")
        raise RuntimeError(f"Tool execution failed for read_file: {e}")


async def search_files(
    path: Annotated[
        str,
        Field(
            description="""The absolute or relative path of the directory or file to search in (the current working directory is the project root). This directory will be recursively searched."""
        ),
    ],
    regex: Annotated[
        str,
        Field(
            description="""The regular expression pattern to search for. Uses .NET regex syntax."""
        ),
    ],
    file_pattern: Annotated[
        str | None,
        Field(
            description="""Glob pattern to filter files (e.g., '*.cs' for C# files). If not provided, it will search all files (*). Use this to narrow down the search to a specific type of file, otherwise the search will be slow and return a lot of results."""
        ),
    ] = None,
    max_results: Annotated[
        int | None,
        Field(
            description="""Optional maximum number of search results to return. Defaults to 100 if not provided or invalid. Use more smaller and specific searches for better results. Max 300."""
        ),
    ] = None,
    max_line_length: Annotated[
        int | None,
        Field(
            description="""Optional maximum length for any line in the output. Lines longer than this will be truncated with an indicator showing the total length. Defaults to 500 if not provided or invalid. Use this to prevent very long lines (like base64 encoded images) from overwhelming the context."""
        ),
    ] = None,
) -> Any:
    """Request to perform a regex search across files in a specified directory, providing context-rich results. This tool searches for patterns or specific content across multiple files, displaying each match with encapsulating context."""
    try:
        logger.debug(f"Executing search_files with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if path is not None:
            params['path'] = str(path)
        if regex is not None:
            params['regex'] = str(regex)
        if file_pattern is not None:
            params['file_pattern'] = str(file_pattern)
        if max_results is not None:
            params['max_results'] = str(max_results)
        if max_line_length is not None:
            params['max_line_length'] = str(max_line_length)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('search_files', params)
        logger.debug(f"search_files completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute search_files: {e}")
        raise RuntimeError(f"Tool execution failed for search_files: {e}")


async def list_code_definition_names(
    path: Annotated[
        str,
        Field(
            description="""The path of the directory (relative to the project root) to list C# code definitions for."""
        ),
    ],
) -> Any:
    """Request to list definition names (classes, interfaces, enums, structs, and methods) in C# source code files at the top level of the specified directory. This tool provides insights into the Unity C# codebase structure and important constructs, helping to understand the overall architecture. Common Unity lifecycle methods like Start, Update, Awake, etc. are automatically filtered out to reduce noise."""
    try:
        logger.debug(f"Executing list_code_definition_names with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if path is not None:
            params['path'] = str(path)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('list_code_definition_names', params)
        logger.debug(f"list_code_definition_names completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute list_code_definition_names: {e}")
        raise RuntimeError(f"Tool execution failed for list_code_definition_names: {e}")


async def list_files(
    path: Annotated[
        str,
        Field(
            description="""The path of the directory to list contents for (relative to the project root)"""
        ),
    ],
    recursive: Annotated[
        bool | None,
        Field(
            description="""Whether to list files recursively. Use true for recursive listing, false or omit for top-level only. If true, it will ignore any files that are gitignored."""
        ),
    ] = None,
    file_pattern: Annotated[
        str | None,
        Field(
            description="""Glob pattern to filter files (e.g., '*.cs' for C# files). If not provided, it will search all files (*). Use this to narrow down the search to a specific type of file, otherwise the search will be slow and return a lot of results."""
        ),
    ] = None,
    limit: Annotated[
        int | None,
        Field(
            description="""Maximum number of results to return. Defaults to 200."""
        ),
    ] = None,
    ignore_meta_files: Annotated[
        bool | None,
        Field(
            description="""Whether to ignore meta files. Defaults to true."""
        ),
    ] = None,
) -> Any:
    """Request to list files and directories within the specified directory. If recursive is true, it will list all files and directories recursively using a breadth-first search (BFS). If recursive is false or not provided, it will only list the top-level contents. Do not use this tool to confirm the existence of files you may have created, as the user will let you know if the files were created successfully or not."""
    try:
        logger.debug(f"Executing list_files with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if path is not None:
            params['path'] = str(path)
        if recursive is not None:
            params['recursive'] = str(recursive)
        if file_pattern is not None:
            params['file_pattern'] = str(file_pattern)
        if limit is not None:
            params['limit'] = str(limit)
        if ignore_meta_files is not None:
            params['ignore_meta_files'] = str(ignore_meta_files)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('list_files', params)
        logger.debug(f"list_files completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute list_files: {e}")
        raise RuntimeError(f"Tool execution failed for list_files: {e}")


def register_tools(mcp: FastMCP, unity_client: UnityRpcClient) -> None:
    """Register all tools from general_computer_tool_schema with the MCP server."""
    global _mcp, _unity_client
    _mcp = mcp
    _unity_client = unity_client

    # Register read_file
    mcp.tool()(read_file)
    # Register search_files
    mcp.tool()(search_files)
    # Register list_code_definition_names
    mcp.tool()(list_code_definition_names)
    # Register list_files
    mcp.tool()(list_files)
