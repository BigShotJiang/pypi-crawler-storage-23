"""Generated MCP tools from sound_tool_schema.json"""

import logging
from typing import Annotated, Optional, Any, Dict, Literal
from pydantic import Field
from fastmcp import FastMCP
from ..unity_client import UnityRpcClient

logger = logging.getLogger(__name__)

# Global references to be set by register_tools
_mcp: Optional[FastMCP] = None
_unity_client: Optional[UnityRpcClient] = None


async def generate_sfx(
    prompt: Annotated[
        str,
        Field(
            description="""Text prompt describing the sound effect to generate. Be specific and detailed about the sound characteristics (e.g., 'explosion with echo', 'footsteps on gravel', 'sword swing whoosh')."""
        ),
    ],
    duration: Annotated[
        float,
        Field(
            description="""Duration of the sound effect in seconds. Must be between 0.5 and 30 seconds."""
        ),
    ],
    save_path: Annotated[
        str,
        Field(
            description="""File path to save the generated audio. Should be relative to the Unity project Assets folder (e.g., 'Audio/explosion.wav'). The .wav extension will be added automatically if not present."""
        ),
    ],
    loop: Annotated[
        bool | None,
        Field(
            description="""Whether the sound effect should be optimized for seamless looping. Set to true for sounds that need to repeat continuously (e.g., ambient sounds, engine noises). Defaults to false."""
        ),
    ] = None,
    format: Annotated[
        Literal['wav', 'mp3'] | None,
        Field(
            description="""Output audio format. Use 'wav' for uncompressed high-quality audio or 'mp3' for compressed audio. Defaults to 'wav'."""
        ),
    ] = None,
) -> Any:
    """Generate sound effects from text prompts using AI. Creates audio files in wav format."""
    try:
        logger.debug(f"Executing generate_sfx with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if prompt is not None:
            params['prompt'] = str(prompt)
        if duration is not None:
            params['duration'] = str(duration)
        if save_path is not None:
            params['save_path'] = str(save_path)
        if loop is not None:
            params['loop'] = str(loop)
        if format is not None:
            params['format'] = str(format)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('generate_sfx', params)
        logger.debug(f"generate_sfx completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute generate_sfx: {e}")
        raise RuntimeError(f"Tool execution failed for generate_sfx: {e}")


async def search_tts_voice_id(
    search: Annotated[
        str,
        Field(
            description="""Search term for voice name or description (e.g., 'male british accent', 'female young energetic', 'deep narrator voice')."""
        ),
    ],
) -> Any:
    """Search for a text-to-speech voice by name or description. Returns the voice_id that can be used with generate_tts."""
    try:
        logger.debug(f"Executing search_tts_voice_id with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if search is not None:
            params['search'] = str(search)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('search_tts_voice_id', params)
        logger.debug(f"search_tts_voice_id completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute search_tts_voice_id: {e}")
        raise RuntimeError(f"Tool execution failed for search_tts_voice_id: {e}")


async def generate_tts(
    prompt: Annotated[
        str,
        Field(
            description="""The text to convert to speech. Can be dialogue, narration, or any text content that needs to be spoken."""
        ),
    ],
    save_path: Annotated[
        str,
        Field(
            description="""File path to save the generated audio. Should be relative to the Unity project Assets folder (e.g., 'Audio/dialogue.mp3'). The .mp3 extension will be added automatically if not present."""
        ),
    ],
    voice_id: Annotated[
        str,
        Field(
            description="""Required voice ID to use for speech generation. Use search_tts_voice_id to find available voices."""
        ),
    ],
) -> Any:
    """Generate text-to-speech audio from text using AI. Creates audio files in MP3 format with natural-sounding voices."""
    try:
        logger.debug(f"Executing generate_tts with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if prompt is not None:
            params['prompt'] = str(prompt)
        if save_path is not None:
            params['save_path'] = str(save_path)
        if voice_id is not None:
            params['voice_id'] = str(voice_id)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('generate_tts', params)
        logger.debug(f"generate_tts completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute generate_tts: {e}")
        raise RuntimeError(f"Tool execution failed for generate_tts: {e}")


async def generate_music(
    prompt: Annotated[
        str,
        Field(
            description="""Text prompt describing the music to generate. Be specific about genre, mood, instruments, tempo, and style (e.g., 'upbeat electronic dance music with synths', 'calm piano melody for menu screen', 'epic orchestral battle theme')."""
        ),
    ],
    duration: Annotated[
        float,
        Field(
            description="""Duration of the music in seconds. Must be between 0.5 and 180 seconds."""
        ),
    ],
    save_path: Annotated[
        str,
        Field(
            description="""File path to save the generated audio. Should be relative to the Unity project Assets folder (e.g., 'Audio/background_music.mp3'). The .mp3 extension will be added automatically if not present."""
        ),
    ],
) -> Any:
    """Generate music from text prompts using AI. Creates audio files in MP3 format suitable for background music, themes, and soundtracks."""
    try:
        logger.debug(f"Executing generate_music with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if prompt is not None:
            params['prompt'] = str(prompt)
        if duration is not None:
            params['duration'] = str(duration)
        if save_path is not None:
            params['save_path'] = str(save_path)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('generate_music', params)
        logger.debug(f"generate_music completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute generate_music: {e}")
        raise RuntimeError(f"Tool execution failed for generate_music: {e}")


def register_tools(mcp: FastMCP, unity_client: UnityRpcClient) -> None:
    """Register all tools from sound_tool_schema with the MCP server."""
    global _mcp, _unity_client
    _mcp = mcp
    _unity_client = unity_client

    # Register generate_sfx
    mcp.tool()(generate_sfx)
    # Register search_tts_voice_id
    mcp.tool()(search_tts_voice_id)
    # Register generate_tts
    mcp.tool()(generate_tts)
    # Register generate_music
    mcp.tool()(generate_music)
