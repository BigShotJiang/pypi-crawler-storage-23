"""Generated MCP tools from generate_3d_model_functions_schema.json"""

import logging
from typing import Annotated, Optional, Any, Dict, Literal
from pydantic import Field
from fastmcp import FastMCP
from ..unity_client import UnityRpcClient

logger = logging.getLogger(__name__)

# Global references to be set by register_tools
_mcp: Optional[FastMCP] = None
_unity_client: Optional[UnityRpcClient] = None


async def generate_3d_model_from_image(
    image_url: Annotated[
        str,
        Field(
            description="""URL of the input image to generate the 3D model from. Accepts .jpg, .jpeg, .png formats."""
        ),
    ],
    output_path: Annotated[
        str,
        Field(
            description="""The file path where the generated model will be saved. The file extension should be .glb."""
        ),
    ],
    provider: Annotated[
        Literal['Meshy5', 'Meshy6'] | None,
        Field(
            description="""Optional. The AI provider to use for 3D model generation. 'Meshy5' (default) or 'Meshy6' (latest model)."""
        ),
    ] = None,
    provider_options: Annotated[
        str | None,
        Field(
            description="""Optional. JSON string containing Meshy provider options for image-to-3D: {"model_type": "standard/lowpoly", "topology": "triangle/quad", "target_polycount": 30000, "symmetry_mode": "off/auto/on", "should_remesh": true/false, "save_pre_remeshed_model": true/false, "should_texture": true/false, "enable_pbr": true/false, "texture_prompt": "description", "texture_image_url": "url", "pose_mode": "a-pose/t-pose", "moderation": true/false}. Defaults: target_polycount=30000, should_remesh=true."""
        ),
    ] = None,
) -> Any:
    """Generates a 3D model from an input image using Meshy AI. Supports Meshy-5 and Meshy-6 models with various mesh and texture options.  Use pose_mode a-pose as default fot character generation."""
    try:
        logger.debug(f"Executing generate_3d_model_from_image with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if image_url is not None:
            params['image_url'] = str(image_url)
        if output_path is not None:
            params['output_path'] = str(output_path)
        if provider is not None:
            params['provider'] = str(provider)
        if provider_options is not None:
            params['provider_options'] = str(provider_options)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('generate_3d_model_from_image', params)
        logger.debug(f"generate_3d_model_from_image completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute generate_3d_model_from_image: {e}")
        raise RuntimeError(f"Tool execution failed for generate_3d_model_from_image: {e}")


async def generate_3d_model_texture(
    model_path: Annotated[
        str,
        Field(
            description="""Path to the 3D model to retexture. Supports .glb, .gltf, .obj, .fbx, .stl formats."""
        ),
    ],
    output_path: Annotated[
        str,
        Field(
            description="""The file path where the retextured model will be saved."""
        ),
    ],
    style_prompt: Annotated[
        str,
        Field(
            description="""Text description of desired texture appearance (max 600 characters). Used if style_image_url is not provided."""
        ),
    ],
    style_image_url: Annotated[
        str | None,
        Field(
            description="""Optional. URL or data URI of a 2D reference image to guide texture generation. Accepts .jpg, .jpeg, .png. Takes precedence over style_prompt if both provided."""
        ),
    ] = None,
    enable_original_uv: Annotated[
        bool | None,
        Field(
            description="""Preserve existing model UVs and textures. Defaults to true."""
        ),
    ] = None,
    enable_pbr: Annotated[
        bool | None,
        Field(
            description="""Generate PBR maps (metallic, roughness, normal). Defaults to false."""
        ),
    ] = None,
) -> Any:
    """Retextures an existing 3D model using Meshy AI. Generates new textures based on a text description or reference image. Before calling this function, ensure that you know where the existing model is located in the project."""
    try:
        logger.debug(f"Executing generate_3d_model_texture with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if model_path is not None:
            params['model_path'] = str(model_path)
        if output_path is not None:
            params['output_path'] = str(output_path)
        if style_prompt is not None:
            params['style_prompt'] = str(style_prompt)
        if style_image_url is not None:
            params['style_image_url'] = str(style_image_url)
        if enable_original_uv is not None:
            params['enable_original_uv'] = str(enable_original_uv)
        if enable_pbr is not None:
            params['enable_pbr'] = str(enable_pbr)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('generate_3d_model_texture', params)
        logger.debug(f"generate_3d_model_texture completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute generate_3d_model_texture: {e}")
        raise RuntimeError(f"Tool execution failed for generate_3d_model_texture: {e}")


async def generate_3d_model_from_text(
    prompt: Annotated[
        str,
        Field(
            description="""The text prompt describing the 3D model to generate (max 600 characters)."""
        ),
    ],
    output_path: Annotated[
        str,
        Field(
            description="""The file path where the generated model will be saved. The file extension should be .glb."""
        ),
    ],
    provider: Annotated[
        Literal['Meshy5', 'Meshy6'] | None,
        Field(
            description="""Optional. The AI provider to use. 'Meshy5' (default) or 'Meshy6' (latest model)."""
        ),
    ] = None,
    provider_options: Annotated[
        str | None,
        Field(
            description="""Optional. JSON string containing Meshy provider options for text-to-3D: {"art_style": "realistic/sculpture", "topology": "triangle/quad", "target_polycount": 20000, "symmetry_mode": "off/auto/on", "should_remesh": true/false, "pose_mode": "a-pose/t-pose", "enable_refinement": true/false, "enable_pbr": true/false, "texture_prompt": "description", "texture_image_url": "url", "moderation": true/false}. Defaults: target_polycount=30000, should_remesh=true."""
        ),
    ] = None,
) -> Any:
    """Generates a 3D model from a text prompt using Meshy AI. Supports text-to-3D generation with mesh and texture options. Use pose_mode a-pose as default fot character generation."""
    try:
        logger.debug(f"Executing generate_3d_model_from_text with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if prompt is not None:
            params['prompt'] = str(prompt)
        if output_path is not None:
            params['output_path'] = str(output_path)
        if provider is not None:
            params['provider'] = str(provider)
        if provider_options is not None:
            params['provider_options'] = str(provider_options)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('generate_3d_model_from_text', params)
        logger.debug(f"generate_3d_model_from_text completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute generate_3d_model_from_text: {e}")
        raise RuntimeError(f"Tool execution failed for generate_3d_model_from_text: {e}")


async def auto_rig_3d_model(
    model_path: Annotated[
        str,
        Field(
            description="""Path to the humanoid 3D model to rig. Must be a textured GLB file with clearly defined limbs."""
        ),
    ],
    output_path: Annotated[
        str,
        Field(
            description="""The file path where the rigged model will be saved. The file extension should be .glb"""
        ),
    ],
    height_meters: Annotated[
        float | None,
        Field(
            description="""Optional. The character's height in meters for accurate rigging. Defaults to 1.7 meters."""
        ),
    ] = None,
) -> Any:
    """Automatically rigs a humanoid 3D model using Meshy AI. Adds a skeleton and generates walking/running animations. The input model must be a textured humanoid GLB with clearly defined limbs (bipedal character). Returns rigged model files (GLB, FBX) and basic locomotion animations."""
    try:
        logger.debug(f"Executing auto_rig_3d_model with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if model_path is not None:
            params['model_path'] = str(model_path)
        if output_path is not None:
            params['output_path'] = str(output_path)
        if height_meters is not None:
            params['height_meters'] = str(height_meters)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('auto_rig_3d_model', params)
        logger.debug(f"auto_rig_3d_model completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute auto_rig_3d_model: {e}")
        raise RuntimeError(f"Tool execution failed for auto_rig_3d_model: {e}")


async def apply_animation_to_rigged_model(
    model_path: Annotated[
        str,
        Field(
            description="""Path to the rigged 3D model. Must be a model that was previously rigged using auto_rig_3d_model. The function will read the .meshy.info file next to the model to get the rig_task_id."""
        ),
    ],
    output_path: Annotated[
        str,
        Field(
            description="""The file path where the animated model will be saved. The file extension should be .glb"""
        ),
    ],
    action_id: Annotated[
        int,
        Field(
            description="""The animation action ID from Meshy's animation library (0-586). Examples: idle variations, walking/running styles, combat moves, acrobatics, dancing. See Meshy animation library for complete list."""
        ),
    ],
) -> Any:
    """Applies a specific animation action to a previously rigged character using Meshy AI. Use search_animation_library to find animation IDs by description (e.g., 'walking', 'attack', 'dance'). The model must have been rigged using the auto_rig_3d_model function. The rig_task_id is automatically read from the .meshy.info file next to the model. Available categories: DailyActions, WalkAndRun, Fighting, BodyMovements, Dancing. Action IDs range from 0 to 686."""
    try:
        logger.debug(f"Executing apply_animation_to_rigged_model with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if model_path is not None:
            params['model_path'] = str(model_path)
        if output_path is not None:
            params['output_path'] = str(output_path)
        if action_id is not None:
            params['action_id'] = str(action_id)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('apply_animation_to_rigged_model', params)
        logger.debug(f"apply_animation_to_rigged_model completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute apply_animation_to_rigged_model: {e}")
        raise RuntimeError(f"Tool execution failed for apply_animation_to_rigged_model: {e}")


async def search_animation_library(
    query: Annotated[
        str,
        Field(
            description="""Search terms describing the desired animation (e.g., "walking", "attack", "funny dance")."""
        ),
    ],
    max_results: Annotated[
        int | None,
        Field(
            description="""Maximum number of matching animations to return (default: 5, max: 20)."""
        ),
    ] = None,
) -> Any:
    """Searches Meshy animation library for action IDs by description or keywords. Use this to find animation IDs for apply_animation_to_rigged_model."""
    try:
        logger.debug(f"Executing search_animation_library with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if query is not None:
            params['query'] = str(query)
        if max_results is not None:
            params['max_results'] = str(max_results)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('search_animation_library', params)
        logger.debug(f"search_animation_library completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute search_animation_library: {e}")
        raise RuntimeError(f"Tool execution failed for search_animation_library: {e}")


def register_tools(mcp: FastMCP, unity_client: UnityRpcClient) -> None:
    """Register all tools from generate_3d_model_functions_schema with the MCP server."""
    global _mcp, _unity_client
    _mcp = mcp
    _unity_client = unity_client

    # Register generate_3d_model_from_image
    mcp.tool()(generate_3d_model_from_image)
    # Register generate_3d_model_texture
    mcp.tool()(generate_3d_model_texture)
    # Register generate_3d_model_from_text
    mcp.tool()(generate_3d_model_from_text)
    # Register auto_rig_3d_model
    mcp.tool()(auto_rig_3d_model)
    # Register apply_animation_to_rigged_model
    mcp.tool()(apply_animation_to_rigged_model)
    # Register search_animation_library
    mcp.tool()(search_animation_library)
