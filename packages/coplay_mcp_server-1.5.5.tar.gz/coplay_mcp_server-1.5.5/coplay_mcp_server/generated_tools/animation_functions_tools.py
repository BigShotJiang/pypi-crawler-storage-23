"""Generated MCP tools from animation_functions_schema.json"""

import logging
from typing import Annotated, Optional, Any, Dict, Literal
from pydantic import Field
from fastmcp import FastMCP
from ..unity_client import UnityRpcClient

logger = logging.getLogger(__name__)

# Global references to be set by register_tools
_mcp: Optional[FastMCP] = None
_unity_client: Optional[UnityRpcClient] = None


async def create_animation_clip(
    clip_name: Annotated[
        str,
        Field(
            description="""Name of the animation clip (e.g., 'Idle', 'Walk', 'Jump')."""
        ),
    ],
    save_path: Annotated[
        str,
        Field(
            description="""Asset path to save the clip. Must start with 'Assets/' and end with '.anim' (e.g., 'Assets/Animations/Walk.anim')."""
        ),
    ],
    frame_rate: Annotated[
        float | None,
        Field(
            description="""Optional. Samples per second (default: 60). Common values: 12 for 2D sprite animation, 30 or 60 for 3D."""
        ),
    ] = None,
    wrap_mode: Annotated[
        Literal['Default', 'Once', 'Loop', 'PingPong', 'ClampForever'] | None,
        Field(
            description="""Optional. How the animation behaves when it reaches the end. Defaults to 'Default'."""
        ),
    ] = None,
    is_looping: Annotated[
        bool | None,
        Field(
            description="""Optional. Whether the animation should loop. Defaults to false."""
        ),
    ] = None,
) -> Any:
    """Creates a new AnimationClip (.anim) asset file in the Unity project. Optionally sets frame rate, wrap mode, and looping."""
    try:
        logger.debug(f"Executing create_animation_clip with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if clip_name is not None:
            params['clip_name'] = str(clip_name)
        if save_path is not None:
            params['save_path'] = str(save_path)
        if frame_rate is not None:
            params['frame_rate'] = str(frame_rate)
        if wrap_mode is not None:
            params['wrap_mode'] = str(wrap_mode)
        if is_looping is not None:
            params['is_looping'] = str(is_looping)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('create_animation_clip', params)
        logger.debug(f"create_animation_clip completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute create_animation_clip: {e}")
        raise RuntimeError(f"Tool execution failed for create_animation_clip: {e}")


async def get_animation_clip_data(
    clip_path: Annotated[
        str,
        Field(
            description="""Asset path to the .anim file (e.g., 'Assets/Animations/Walk.anim')."""
        ),
    ],
    max_keyframes_per_curve: Annotated[
        int | None,
        Field(
            description="""Optional. Maximum number of keyframes to return per curve. Use to limit output size for clips with many keyframes. Returns all keyframes if not specified."""
        ),
    ] = None,
) -> Any:
    """Reads comprehensive data from an existing AnimationClip asset, including metadata, all curve bindings, and actual keyframe values. Use this to inspect animations before modifying them."""
    try:
        logger.debug(f"Executing get_animation_clip_data with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if clip_path is not None:
            params['clip_path'] = str(clip_path)
        if max_keyframes_per_curve is not None:
            params['max_keyframes_per_curve'] = str(max_keyframes_per_curve)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('get_animation_clip_data', params)
        logger.debug(f"get_animation_clip_data completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute get_animation_clip_data: {e}")
        raise RuntimeError(f"Tool execution failed for get_animation_clip_data: {e}")


async def set_animation_curves(
    clip_path: Annotated[
        str,
        Field(
            description="""Asset path to the .anim file (e.g., 'Assets/Animations/Walk.anim')."""
        ),
    ],
    curves: Annotated[
        str,
        Field(
            description="""JSON array of curve definitions. Each curve: {"component_type": "Transform", "property_name": "localPosition.x", "relative_path": "", "keyframes": [{"time": 0, "value": 0, "in_tangent": 0, "out_tangent": 0}, ...]}. relative_path is the path to the child GameObject (empty string for the root). in_tangent and out_tangent are optional (default 0). Common component types: Transform, SpriteRenderer, MeshRenderer, Light, Camera, AudioSource. Common property names for Transform: localPosition.x/y/z, localRotation.x/y/z/w, localScale.x/y/z, localEulerAnglesRaw.x/y/z."""
        ),
    ],
) -> Any:
    """Sets one or more float animation curves on an AnimationClip. Each curve defines keyframes for a specific property (e.g., Transform.localPosition.x). Use this for 3D transform animations, component property animations, and any float-based curves."""
    try:
        logger.debug(f"Executing set_animation_curves with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if clip_path is not None:
            params['clip_path'] = str(clip_path)
        if curves is not None:
            params['curves'] = str(curves)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('set_animation_curves', params)
        logger.debug(f"set_animation_curves completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute set_animation_curves: {e}")
        raise RuntimeError(f"Tool execution failed for set_animation_curves: {e}")


async def set_sprite_animation_curve(
    clip_path: Annotated[
        str,
        Field(
            description="""Asset path to the .anim file (e.g., 'Assets/Animations/WalkCycle.anim')."""
        ),
    ],
    keyframes: Annotated[
        str,
        Field(
            description="""JSON array of sprite keyframes. Each keyframe: {"time": 0, "sprite_path": "Assets/Sprites/frame_0.png"}. The sprite_path should point to a texture asset with sprite import settings. For sprite sheets, use the sub-sprite name: "Assets/Sprites/Sheet.png/sprite_name"."""
        ),
    ],
    relative_path: Annotated[
        str | None,
        Field(
            description="""Optional. Path to the child GameObject with the SpriteRenderer (empty string or null for the root object)."""
        ),
    ] = None,
    component_type: Annotated[
        str | None,
        Field(
            description="""Optional. Component type that owns the sprite property (default: SpriteRenderer). Common values: SpriteRenderer, UnityEngine.UI.Image."""
        ),
    ] = None,
    property_name: Annotated[
        str | None,
        Field(
            description="""Optional. Property name for the sprite reference (default: m_Sprite)."""
        ),
    ] = None,
) -> Any:
    """Sets a sprite swap animation curve on an AnimationClip for 2D animation. Each keyframe assigns a different sprite at a specific time, creating frame-by-frame animation."""
    try:
        logger.debug(f"Executing set_sprite_animation_curve with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if clip_path is not None:
            params['clip_path'] = str(clip_path)
        if relative_path is not None:
            params['relative_path'] = str(relative_path)
        if component_type is not None:
            params['component_type'] = str(component_type)
        if property_name is not None:
            params['property_name'] = str(property_name)
        if keyframes is not None:
            params['keyframes'] = str(keyframes)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('set_sprite_animation_curve', params)
        logger.debug(f"set_sprite_animation_curve completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute set_sprite_animation_curve: {e}")
        raise RuntimeError(f"Tool execution failed for set_sprite_animation_curve: {e}")


async def set_animation_clip_settings(
    clip_path: Annotated[
        str,
        Field(
            description="""Asset path to the .anim file (e.g., 'Assets/Animations/Walk.anim')."""
        ),
    ],
    frame_rate: Annotated[
        float | None,
        Field(
            description="""Optional. New samples per second."""
        ),
    ] = None,
    wrap_mode: Annotated[
        Literal['Default', 'Once', 'Loop', 'PingPong', 'ClampForever'] | None,
        Field(
            description="""Optional. New wrap mode."""
        ),
    ] = None,
    is_looping: Annotated[
        bool | None,
        Field(
            description="""Optional. Whether the animation should loop."""
        ),
    ] = None,
    clear_curves: Annotated[
        bool | None,
        Field(
            description="""Optional. Set to true to remove ALL curves from the clip."""
        ),
    ] = None,
    clear_events: Annotated[
        bool | None,
        Field(
            description="""Optional. Set to true to remove ALL animation events from the clip."""
        ),
    ] = None,
) -> Any:
    """Modifies settings on an existing AnimationClip. Can change frame rate, wrap mode, looping, or clear all curves/events."""
    try:
        logger.debug(f"Executing set_animation_clip_settings with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if clip_path is not None:
            params['clip_path'] = str(clip_path)
        if frame_rate is not None:
            params['frame_rate'] = str(frame_rate)
        if wrap_mode is not None:
            params['wrap_mode'] = str(wrap_mode)
        if is_looping is not None:
            params['is_looping'] = str(is_looping)
        if clear_curves is not None:
            params['clear_curves'] = str(clear_curves)
        if clear_events is not None:
            params['clear_events'] = str(clear_events)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('set_animation_clip_settings', params)
        logger.debug(f"set_animation_clip_settings completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute set_animation_clip_settings: {e}")
        raise RuntimeError(f"Tool execution failed for set_animation_clip_settings: {e}")


async def create_animator_controller(
    controller_name: Annotated[
        str,
        Field(
            description="""Name of the animator controller (e.g., 'PlayerController', 'EnemyAI')."""
        ),
    ],
    save_path: Annotated[
        str,
        Field(
            description="""Asset path to save the controller. Must start with 'Assets/' and end with '.controller' (e.g., 'Assets/Animations/PlayerController.controller')."""
        ),
    ],
) -> Any:
    """Creates a new AnimatorController (.controller) asset file. The controller is created with a default 'Base Layer' and can be configured with modify_animator_controller."""
    try:
        logger.debug(f"Executing create_animator_controller with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if controller_name is not None:
            params['controller_name'] = str(controller_name)
        if save_path is not None:
            params['save_path'] = str(save_path)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('create_animator_controller', params)
        logger.debug(f"create_animator_controller completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute create_animator_controller: {e}")
        raise RuntimeError(f"Tool execution failed for create_animator_controller: {e}")


async def get_animator_controller_data(
    controller_path: Annotated[
        str,
        Field(
            description="""Asset path to the .controller file (e.g., 'Assets/Animations/PlayerController.controller')."""
        ),
    ],
) -> Any:
    """Reads the full structure of an AnimatorController asset, including parameters, layers, states, transitions, and conditions. Use this to inspect a controller before modifying it."""
    try:
        logger.debug(f"Executing get_animator_controller_data with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if controller_path is not None:
            params['controller_path'] = str(controller_path)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('get_animator_controller_data', params)
        logger.debug(f"get_animator_controller_data completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute get_animator_controller_data: {e}")
        raise RuntimeError(f"Tool execution failed for get_animator_controller_data: {e}")


async def modify_animator_controller(
    controller_path: Annotated[
        str,
        Field(
            description="""Asset path to the .controller file (e.g., 'Assets/Animations/PlayerController.controller')."""
        ),
    ],
    modifications: Annotated[
        str,
        Field(
            description="""JSON array of modification objects. Each must have a 'type' field. Types and their fields:
- add_parameter: {parameter_name, parameter_type (Float|Int|Bool|Trigger), default_value (optional)}
- remove_parameter: {parameter_name}
- add_layer: {layer_name}
- add_state: {layer_name, state_name, motion_clip_path (optional, path to .anim file)}
- remove_state: {layer_name, state_name}
- set_default_state: {layer_name, state_name}
- add_transition: {layer_name, source_state, destination_state, has_exit_time (bool, optional), exit_time (float, optional), transition_duration (float, optional), conditions (array of {parameter, mode (Greater|Less|Equals|NotEqual|If|IfNot), threshold (float)}, optional)}
- remove_transition: {layer_name, source_state, destination_state}
- set_state_motion: {layer_name, state_name, motion_clip_path}
- set_state_speed: {layer_name, state_name, speed (float)}"""
        ),
    ],
) -> Any:
    """Applies a batch of modifications to an existing AnimatorController. Modifications are applied sequentially so order matters (e.g., add a state before adding a transition from it). Supported modification types: add_parameter, remove_parameter, add_layer, add_state, remove_state, set_default_state, add_transition, remove_transition, set_state_motion, set_state_speed. add_transition/remove_transition support AnyState (source_state="AnyState") and Exit (destination_state="Exit")."""
    try:
        logger.debug(f"Executing modify_animator_controller with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if controller_path is not None:
            params['controller_path'] = str(controller_path)
        if modifications is not None:
            params['modifications'] = str(modifications)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('modify_animator_controller', params)
        logger.debug(f"modify_animator_controller completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute modify_animator_controller: {e}")
        raise RuntimeError(f"Tool execution failed for modify_animator_controller: {e}")


async def create_blend_tree_state(
    controller_path: Annotated[
        str,
        Field(
            description="""Asset path to the .controller file (e.g., 'Assets/Animations/Player.controller')."""
        ),
    ],
    layer_name: Annotated[
        str,
        Field(
            description="""Animator layer name to add the blend tree state into."""
        ),
    ],
    state_name: Annotated[
        str,
        Field(
            description="""Name of the new state to create (e.g., 'Locomotion')."""
        ),
    ],
    blend_type: Annotated[
        Literal['1D', '2D'],
        Field(
            description="""Blend tree type. Use '1D' for speed-based blending or '2D' for directional blending."""
        ),
    ],
    children: Annotated[
        str,
        Field(
            description="""JSON array of child motions. Each child: {"motion_clip_path": "Assets/Animations/Walk.anim", "threshold": 0.5} for 1D, or {"motion_clip_path": "Assets/Models/Character.fbx::Walk", "position_x": 0, "position_y": 1} for 2D. Use '::' to reference model sub-assets."""
        ),
    ],
    blend_parameter: Annotated[
        str | None,
        Field(
            description="""Required for 1D blend trees. Name of the float parameter (e.g., 'Speed')."""
        ),
    ] = None,
    blend_parameter_x: Annotated[
        str | None,
        Field(
            description="""Required for 2D blend trees. Name of the X-axis parameter (e.g., 'MoveX')."""
        ),
    ] = None,
    blend_parameter_y: Annotated[
        str | None,
        Field(
            description="""Required for 2D blend trees. Name of the Y-axis parameter (e.g., 'MoveY' or 'MoveZ')."""
        ),
    ] = None,
    blend_2d_type: Annotated[
        Literal['SimpleDirectional', 'FreeformDirectional', 'FreeformCartesian'] | None,
        Field(
            description="""Optional. 2D blend tree mode (default: FreeformDirectional)."""
        ),
    ] = None,
    set_as_default: Annotated[
        bool | None,
        Field(
            description="""Optional. If true, set this state as the default for the layer."""
        ),
    ] = None,
) -> Any:
    """Creates a new Animator state backed by a BlendTree (1D or 2D) in the specified controller layer. Use this for walk/run and directional locomotion blending."""
    try:
        logger.debug(f"Executing create_blend_tree_state with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if controller_path is not None:
            params['controller_path'] = str(controller_path)
        if layer_name is not None:
            params['layer_name'] = str(layer_name)
        if state_name is not None:
            params['state_name'] = str(state_name)
        if blend_type is not None:
            params['blend_type'] = str(blend_type)
        if blend_parameter is not None:
            params['blend_parameter'] = str(blend_parameter)
        if blend_parameter_x is not None:
            params['blend_parameter_x'] = str(blend_parameter_x)
        if blend_parameter_y is not None:
            params['blend_parameter_y'] = str(blend_parameter_y)
        if blend_2d_type is not None:
            params['blend_2d_type'] = str(blend_2d_type)
        if children is not None:
            params['children'] = str(children)
        if set_as_default is not None:
            params['set_as_default'] = str(set_as_default)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('create_blend_tree_state', params)
        logger.debug(f"create_blend_tree_state completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute create_blend_tree_state: {e}")
        raise RuntimeError(f"Tool execution failed for create_blend_tree_state: {e}")


async def get_blend_tree_state_data(
    controller_path: Annotated[
        str,
        Field(
            description="""Asset path to the .controller file (e.g., 'Assets/Animations/Player.controller')."""
        ),
    ],
    layer_name: Annotated[
        str,
        Field(
            description="""Animator layer name containing the state."""
        ),
    ],
    state_name: Annotated[
        str,
        Field(
            description="""Blend tree state name to read."""
        ),
    ],
) -> Any:
    """Returns a compact summary of a blend tree state (blend type, parameters, and child thresholds/positions) to validate configuration without large outputs."""
    try:
        logger.debug(f"Executing get_blend_tree_state_data with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if controller_path is not None:
            params['controller_path'] = str(controller_path)
        if layer_name is not None:
            params['layer_name'] = str(layer_name)
        if state_name is not None:
            params['state_name'] = str(state_name)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('get_blend_tree_state_data', params)
        logger.debug(f"get_blend_tree_state_data completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute get_blend_tree_state_data: {e}")
        raise RuntimeError(f"Tool execution failed for get_blend_tree_state_data: {e}")


async def list_model_animation_clips(
    model_path: Annotated[
        str,
        Field(
            description="""Asset path to the model (e.g., 'Assets/Models/Character.fbx')."""
        ),
    ],
) -> Any:
    """Lists AnimationClips embedded in a model asset (e.g., FBX) and returns their sub-asset paths for use in blend trees or state motions."""
    try:
        logger.debug(f"Executing list_model_animation_clips with parameters: {locals()}")

        # Prepare parameters for Unity RPC call
        params = {}
        if model_path is not None:
            params['model_path'] = str(model_path)

        # Execute Unity RPC call
        result = await _unity_client.execute_request('list_model_animation_clips', params)
        logger.debug(f"list_model_animation_clips completed successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to execute list_model_animation_clips: {e}")
        raise RuntimeError(f"Tool execution failed for list_model_animation_clips: {e}")


def register_tools(mcp: FastMCP, unity_client: UnityRpcClient) -> None:
    """Register all tools from animation_functions_schema with the MCP server."""
    global _mcp, _unity_client
    _mcp = mcp
    _unity_client = unity_client

    # Register create_animation_clip
    mcp.tool()(create_animation_clip)
    # Register get_animation_clip_data
    mcp.tool()(get_animation_clip_data)
    # Register set_animation_curves
    mcp.tool()(set_animation_curves)
    # Register set_sprite_animation_curve
    mcp.tool()(set_sprite_animation_curve)
    # Register set_animation_clip_settings
    mcp.tool()(set_animation_clip_settings)
    # Register create_animator_controller
    mcp.tool()(create_animator_controller)
    # Register get_animator_controller_data
    mcp.tool()(get_animator_controller_data)
    # Register modify_animator_controller
    mcp.tool()(modify_animator_controller)
    # Register create_blend_tree_state
    mcp.tool()(create_blend_tree_state)
    # Register get_blend_tree_state_data
    mcp.tool()(get_blend_tree_state_data)
    # Register list_model_animation_clips
    mcp.tool()(list_model_animation_clips)
