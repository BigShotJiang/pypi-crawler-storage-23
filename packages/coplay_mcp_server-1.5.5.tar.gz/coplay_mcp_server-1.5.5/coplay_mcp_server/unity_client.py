"""Unity RPC client for file-based communication with Unity Editor."""

import asyncio
import json
import logging
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional
import concurrent.futures

import aiofiles
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from fastmcp.utilities.types import Image

logger = logging.getLogger(__name__)


class UnityProjectRootError(Exception):
    """Base exception for Unity project root related errors."""
    pass


class NoUnityInstancesError(UnityProjectRootError):
    """Raised when no Unity Editor instances are found."""
    pass


class MultipleUnityInstancesError(UnityProjectRootError):
    """Raised when multiple Unity Editor instances are found and auto-detection cannot proceed."""
    
    def __init__(self, message: str, project_roots: list[str]):
        super().__init__(message)
        self.project_roots = project_roots


def discover_unity_project_roots():
    """Import and call the discover_unity_project_roots function."""
    from coplay_mcp_server.process_discovery import discover_unity_project_roots as _discover
    return _discover()


class UnityRpcClient:
    """Client for communicating with Unity Editor via file-based RPC."""

    def __init__(self) -> None:
        self._unity_project_root: Optional[str] = None
        self._pending_requests: Dict[str, concurrent.futures.Future[Any]] = {}
        self._observer: Optional[Observer] = None
        self._response_handler: Optional[ResponseFileHandler] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def set_unity_project_root(self, project_root: str) -> None:
        """Set the Unity project root and start watching for responses."""
        logger.debug(f"set_unity_project_root called with: {project_root}")
        if self._unity_project_root == project_root:
            logger.debug("Project root unchanged, skipping reconfiguration")
            return

        # Stop existing watcher if any
        if self._unity_project_root:
            logger.debug(f"Switching project root from {self._unity_project_root} to {project_root}")
        self._stop_file_watcher()

        self._unity_project_root = project_root
        self._start_file_watcher()
        logger.info(f"Unity project root set to: {project_root}")

    def auto_detect_unity_project_root(self) -> bool:
        """
        Automatically detect and set Unity project root if exactly one Unity instance is running.
        
        Returns:
            bool: True if successfully auto-detected and set, False otherwise.
        """
        try:
            project_roots = discover_unity_project_roots()
            
            if len(project_roots) == 1:
                # Exactly one Unity instance found - auto-set it
                project_root = project_roots[0]
                self.set_unity_project_root(project_root)
                logger.info(f"Auto-detected Unity project root: {project_root}")
                return True
            elif len(project_roots) == 0:
                logger.warning("No Unity instances found for auto-detection")
                return False
            else:
                logger.warning(f"Multiple Unity instances found ({len(project_roots)}), cannot auto-detect. Available projects: {project_roots}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to auto-detect Unity project root: {e}")
            return False

    def _start_file_watcher(self) -> None:
        """Start watching for response files."""
        logger.debug("_start_file_watcher called")
        if not self._unity_project_root:
            logger.debug("No unity project root set, skipping file watcher setup")
            return

        requests_dir = (
            Path(self._unity_project_root) / "Temp" / "Coplay" / "MCPRequests"
        )
        logger.debug(f"Checking requests directory: {requests_dir}")
        if not requests_dir.exists():
            logger.warning(f"Unity requests directory does not exist: {requests_dir}")
            return

        # Store the current event loop for thread-safe communication
        try:
            self._loop = asyncio.get_running_loop()
            logger.debug(f"Captured event loop: {self._loop}")
        except RuntimeError:
            logger.warning(
                "No running event loop found, file watching may not work properly"
            )
            return

        self._response_handler = ResponseFileHandler(
            self._handle_response_file_sync, self._loop
        )
        self._observer = Observer()
        self._observer.schedule(
            self._response_handler, str(requests_dir), recursive=False
        )
        self._observer.start()
        logger.info(f"Started watching for responses in: {requests_dir}")

    def _stop_file_watcher(self) -> None:
        """Stop watching for response files."""
        if self._observer:
            logger.debug("Stopping file watcher")
            self._observer.stop()
            self._observer.join()
            self._observer = None
            self._response_handler = None
            logger.debug("File watcher stopped")
        else:
            logger.debug("No active file watcher to stop")

    def _handle_response_file_sync(self, file_path: Path) -> None:
        """Handle a response file from Unity (synchronous version for thread safety)."""
        try:
            logger.debug(f"Handling file change: {file_path} (name={file_path.name})")

            if not file_path.name.startswith(
                "response_"
            ) or not file_path.name.endswith(".json"):
                logger.debug(f"Ignoring non-response file: {file_path.name}")
                return

            # Read response file synchronously
            read_start = time.perf_counter()
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    response_json = f.read()
                read_elapsed = time.perf_counter() - read_start
                logger.debug(
                    f"Read response file {file_path.name} "
                    f"({len(response_json)} bytes, {read_elapsed:.3f}s)"
                )
            except Exception as e:
                logger.error(f"Failed to read response file {file_path}: {e}")
                return

            response_data = json.loads(response_json)
            request_id = response_data.get("id")
            logger.debug(
                f"Parsed response – id={request_id}, "
                f"has_error={'error' in response_data and bool(response_data.get('error'))}, "
                f"has_result={'result' in response_data}, "
                f"pending_ids={list(self._pending_requests.keys())}"
            )

            # Use atomic pop to safely handle concurrent calls (watchdog + polling)
            future = self._pending_requests.pop(request_id, None)
            if future is None:
                logger.debug(
                    f"No pending request for response id={request_id} "
                    f"(already handled or unknown). "
                    f"Pending request ids: {list(self._pending_requests.keys())}"
                )
                return

            logger.debug(f"Matched response id={request_id} to pending request")

            # Guard against setting result on an already-completed future.
            # This can happen if close() cancelled the future while the
            # watchdog thread was mid-flight processing the same response.
            if future.done():
                logger.debug(
                    f"Future for id={request_id} already completed "
                    f"(state={future._state}), skipping late response"
                )
                return

            if "error" in response_data and response_data["error"]:
                error_msg = response_data["error"]
                if isinstance(error_msg, dict):
                    error_msg = error_msg.get("message", str(error_msg))
                logger.debug(f"Response id={request_id} completed with error: {error_msg}")
                future.set_exception(Exception(str(error_msg)))
            else:
                result = response_data.get("result")
                result_preview = str(result)[:500] if result is not None else "None"
                logger.debug(f"Response id={request_id} completed successfully, result preview: {result_preview}")
                future.set_result(result)

            # Clean up response file
            try:
                file_path.unlink()
                logger.debug(f"Deleted response file: {file_path}")
            except Exception as e:
                logger.warning(f"Failed to delete response file {file_path}: {e}")

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse JSON from response file {file_path}: {e}")
        except Exception as e:
            logger.error(f"Error handling response file {file_path}: {e}", exc_info=True)

    def _is_image_function(self, method: str) -> bool:
        """Check if this is a function that returns images."""
        image_functions = {
            "capture_scene_object",
            "capture_ui_canvas",
        }
        return method in image_functions

    def _process_image_response(self, response: Any) -> Any:
        """Convert ImagePath to FastMCP Image object for proper MCP compatibility."""
        if isinstance(response, dict) and "ImagePath" in response:
            image_path = response["ImagePath"]
            if image_path and isinstance(image_path, str):
                logger.debug(f"Processing image response with path: {image_path}")
                try:
                    # Create FastMCP Image object from the file path
                    return Image(path=image_path)
                except Exception as e:
                    logger.warning(
                        f"Failed to create FastMCP Image from path {image_path}: {e}"
                    )
        return response

    async def execute_request(
        self,
        method: str,
        params: Optional[Dict[str, Any]] = None,
        timeout: float = 60.0,
    ) -> Any:
        """Execute an RPC request to Unity Editor."""
        logger.debug(f"execute_request called – method={method}, timeout={timeout}s")
        logger.debug(f"Request params: {params}")

        if not self._unity_project_root:
            logger.debug("No project root set, attempting auto-detection")
            # Try to auto-detect Unity project root
            if not self.auto_detect_unity_project_root():
                # Auto-detection failed, provide helpful error message
                try:
                    project_roots = discover_unity_project_roots()
                    if len(project_roots) == 0:
                        raise NoUnityInstancesError(
                            "No Unity Editor instances found. Please start Unity Editor and call set_unity_project_root with the project path."
                        )
                    else:
                        project_list = "\n".join([f"  - {root}" for root in project_roots])
                        raise MultipleUnityInstancesError(
                            f"Multiple Unity Editor instances found. Please call set_unity_project_root with one of these project paths:\n{project_list}",
                            project_roots
                        )
                except UnityProjectRootError:
                    # Re-raise our custom exceptions as-is
                    raise
                except Exception as e:
                    raise RuntimeError(
                        "Unity project root is not set and auto-detection failed. Call set_unity_project_root first."
                    ) from e

        requests_dir = (
            Path(self._unity_project_root) / "Temp" / "Coplay" / "MCPRequests"
        )
        if not requests_dir.exists():
            logger.error(f"Requests directory missing: {requests_dir}")
            raise RuntimeError(
                "Unity Editor is not running at the specified project root"
            )

        request_id = str(uuid.uuid4())
        request_file = requests_dir / f"req_{request_id}.json"

        # Create request data
        request_data = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params or {},
        }

        logger.debug(f"Prepared request – id={request_id}, file={request_file}")

        # Create concurrent.futures.Future for thread-safe completion
        future: concurrent.futures.Future[Any] = concurrent.futures.Future()
        self._pending_requests[request_id] = future
        logger.debug(
            f"Registered pending request id={request_id}, "
            f"total pending={len(self._pending_requests)}"
        )

        request_start = time.perf_counter()
        try:
            # Write request file
            request_json = json.dumps(request_data, indent=2)
            write_start = time.perf_counter()
            async with aiofiles.open(request_file, "w", encoding="utf-8") as f:
                await f.write(request_json)
            write_elapsed = time.perf_counter() - write_start

            logger.debug(
                f"Wrote request file: {request_file} "
                f"({len(request_json)} bytes, {write_elapsed:.3f}s)"
            )

            # Wait for response using watchdog with a polling fallback.
            # Watchdog (ReadDirectoryChangesW on Windows) can silently miss
            # events, so we periodically check for the response file directly.
            response_file = requests_dir / f"response_{request_id}.json"
            poll_interval = 1.0
            wrapped_future = asyncio.wrap_future(future)

            try:
                logger.debug(
                    f"Waiting for response to id={request_id} (method={method}, timeout={timeout}s)"
                )

                while True:
                    remaining = timeout - (time.perf_counter() - request_start)
                    if remaining <= 0:
                        raise asyncio.TimeoutError()

                    # Wait for the watchdog to resolve the future, but wake up
                    # periodically to poll.  asyncio.wait does NOT cancel the
                    # future on timeout (unlike wait_for), which is what we need.
                    done, _ = await asyncio.wait(
                        [wrapped_future],
                        timeout=min(poll_interval, remaining),
                    )

                    if done:
                        # Resolved by watchdog (or by a previous polling iteration)
                        result = wrapped_future.result()
                        total_elapsed = time.perf_counter() - request_start
                        logger.debug(
                            f"Received response for id={request_id} (method={method}) "
                            f"in {total_elapsed:.3f}s"
                        )
                        break

                    # --- Polling fallback ---
                    elapsed = time.perf_counter() - request_start
                    if response_file.exists():
                        logger.info(
                            f"Polling fallback detected response file for id={request_id} "
                            f"(method={method}) after {elapsed:.1f}s – "
                            f"file watcher may have missed the event"
                        )
                        self._handle_response_file_sync(response_file)
                        # _handle_response_file_sync sets the concurrent future,
                        # which triggers call_soon_threadsafe to resolve
                        # wrapped_future.  On the next loop iteration asyncio.wait
                        # will return it immediately.
                        continue

                    logger.debug(
                        f"Still waiting for response id={request_id} "
                        f"(method={method}), elapsed={elapsed:.1f}s"
                    )

                    # Observer health check
                    if self._observer and not self._observer.is_alive():
                        logger.warning(
                            f"File watcher thread died while waiting for "
                            f"id={request_id} – relying on polling fallback"
                        )

                # Post-process response for image functions
                if self._is_image_function(method):
                    logger.debug(f"Post-processing image response for method={method}")
                    result = self._process_image_response(result)

                return result
            except asyncio.TimeoutError:
                total_elapsed = time.perf_counter() - request_start
                # Check one final time before giving up
                if response_file.exists():
                    logger.info(
                        f"Last-chance poll found response file for id={request_id} "
                        f"at timeout boundary ({total_elapsed:.3f}s)"
                    )
                    self._handle_response_file_sync(response_file)
                    if future.done():
                        result = future.result()
                        if self._is_image_function(method):
                            result = self._process_image_response(result)
                        return result
                logger.error(
                    f"Request id={request_id} (method={method}) timed out "
                    f"after {total_elapsed:.3f}s (limit={timeout}s). "
                    f"Remaining pending requests: {list(self._pending_requests.keys())}"
                )
                raise TimeoutError(
                    f"Request {method} timed out after {timeout} seconds"
                )

        except Exception as e:
            # Clean up on error
            self._pending_requests.pop(request_id, None)
            try:
                if request_file.exists():
                    request_file.unlink()
                    logger.debug(f"Cleaned up request file after error: {request_file}")
            except Exception:
                pass
            if not isinstance(e, TimeoutError):
                logger.error(
                    f"execute_request failed for id={request_id} (method={method}): {e}",
                    exc_info=True,
                )
            raise e

    def close(self) -> None:
        """Close the Unity RPC client and clean up resources."""
        logger.debug("Closing UnityRpcClient")
        self._stop_file_watcher()

        # Cancel any pending requests
        pending_count = len(self._pending_requests)
        if pending_count:
            logger.debug(f"Cancelling {pending_count} pending requests: {list(self._pending_requests.keys())}")
        for request_id, future in self._pending_requests.items():
            if not future.done():
                logger.debug(f"Cancelling pending request id={request_id}")
                future.cancel()
        self._pending_requests.clear()
        logger.debug("UnityRpcClient closed")


class ResponseFileHandler(FileSystemEventHandler):
    """File system event handler for Unity response files."""

    def __init__(
        self, callback, loop: Optional[asyncio.AbstractEventLoop] = None
    ) -> None:
        super().__init__()
        self._callback = callback
        self._loop = loop
        self._processed_files: set[str] = set()
        self._executor = concurrent.futures.ThreadPoolExecutor(max_workers=2)

    def on_created(self, event) -> None:
        """Handle file creation events."""
        if event.is_directory:
            return

        file_path = Path(event.src_path)
        logger.debug(f"FileWatcher on_created: {file_path.name}")
        if file_path.name.startswith("response_") and file_path.name.endswith(".json"):
            logger.debug(f"FileWatcher detected new response file: {file_path.name}")
            self._process_file_threadsafe(file_path)

    def on_modified(self, event) -> None:
        """Handle file modification events."""
        if event.is_directory:
            return

        file_path = Path(event.src_path)
        logger.debug(f"FileWatcher on_modified: {file_path.name}")
        if file_path.name.startswith("response_") and file_path.name.endswith(".json"):
            # Avoid processing the same file multiple times
            if str(file_path) not in self._processed_files:
                self._processed_files.add(str(file_path))
                logger.debug(f"FileWatcher scheduling modified response file: {file_path.name}")
                self._process_file_threadsafe(file_path)
            else:
                logger.debug(f"FileWatcher skipping already-processed file: {file_path.name}")

    def _process_file_threadsafe(self, file_path: Path) -> None:
        """Process a response file in a thread-safe manner."""
        logger.debug(f"Submitting response file to thread pool: {file_path.name}")

        def process_with_delay():
            # Small delay to ensure file is fully written
            time.sleep(0.1)

            if file_path.exists():
                logger.debug(f"Processing response file after delay: {file_path.name}")
                self._callback(file_path)
            else:
                logger.debug(f"Response file no longer exists after delay: {file_path.name}")

        # Submit to thread pool to avoid blocking the file watcher
        self._executor.submit(process_with_delay)
