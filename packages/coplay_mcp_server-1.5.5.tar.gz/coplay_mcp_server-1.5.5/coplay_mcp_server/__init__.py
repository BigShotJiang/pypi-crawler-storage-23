"""Coplay MCP Server - Unity Editor integration via MCP protocol."""

__version__ = "1.5.5"
