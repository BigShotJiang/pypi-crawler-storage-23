from queryservice_client.protobuf.rdbms.query_pb2 import QueryResultObject

from queryservice_client.stream.delimitedstream import DelimitedStream
from queryservice_client.stream.peekable import Peekable

class RowStream(Peekable):

    @staticmethod
    def check(obj: QueryResultObject):
        return obj.HasField("endOfRow")

    def __init__(self, stream):
        self.stream = DelimitedStream(stream, RowStream.check)

    def has_next(self):
        return self.stream.has_next()

    def __next__(self):
        return next(self.stream).data.rowData

    def peek(self):
        return self.stream.peek().data.rowData

    def __iter__(self):
        return self