from queryservice_client.stream.segments.column import Column

class Metadata:
    def __init__(self):
        self.by_ordinality = {}
        self.by_name = {}

    def get_columns(self):
        return sorted(self.by_ordinality.values(), key=lambda col: col.ordinality)
    
    def get_columns_name(self):
        return [name for name in self.by_name.keys()]

    def get_index(self, index):
        return self.by_ordinality.get(index)

    def get_name(self, name):
        return self.by_name.get(name)

    def add(self, projection):
        self.add_column(Column.from_projection(projection))
        return self

    def add_column(self, column):
        self.by_ordinality[column.ordinality] = column
        self.by_name[column.name] = column
        return self

    def size(self):
        return len(self.by_ordinality)

    def __eq__(self, other):
        if isinstance(other, Metadata):
            return self.by_ordinality == other.by_ordinality and self.by_name == other.by_name
        return False

    def __hash__(self):
        return hash((frozenset(self.by_ordinality.items()), frozenset(self.by_name.items())))