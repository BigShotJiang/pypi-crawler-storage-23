class Column:
    def __init__(self, name, label, type, ordinality, dtype):
        self.name = name
        self.label = label
        self.type = type
        self.ordinality = ordinality
        self.dtype = dtype

    @classmethod
    def from_projection(cls, projection):
        return cls(projection.name, projection.label, projection.type, projection.ordinality, projection.dtype)

    def __str__(self):
        return f"Column(name='{self.name}', label='{self.label}', type='{self.type}', ordinality={self.ordinality}, dtype={self.dtype})"

    def __eq__(self, other):
        if isinstance(other, Column):
            return (self.name == other.name and self.label == other.label and
                    self.type == other.type and self.ordinality == other.ordinality and
                    self.dtype == other.dtype)
        return False

    def __hash__(self):
        return hash((self.name, self.label, self.type, self.ordinality, self.dtype))