class Row(list):
    def __init__(self, size: int = 0):
        super().__init__([None] * size)