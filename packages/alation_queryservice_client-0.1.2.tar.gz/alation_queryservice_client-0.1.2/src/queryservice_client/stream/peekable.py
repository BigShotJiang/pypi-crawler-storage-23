class Peekable:
    def peek(self):
        raise NotImplementedError