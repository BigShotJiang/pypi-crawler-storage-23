class ImmutableList:
    def __init__(self):
        self.set([])

    def is_empty(self):
        return self.pointer == len(self.inner)

    def pop(self):
        value = self.inner[self.pointer]
        self.pointer += 1
        return value

    def set(self, inner):
        self.inner = inner
        self.pointer = 0
        return self