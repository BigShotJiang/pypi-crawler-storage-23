"""Unit tests for the SignalPot Python SDK using respx to mock HTTP."""

from __future__ import annotations

import pytest
import respx
import httpx

from signalpot import SignalPotClient, AsyncSignalPotClient
from signalpot import AuthError, NotFoundError, RateLimitError, ValidationError


BASE_URL = "https://www.signalpot.dev"
API_KEY = "sp_live_test123"

AGENT_FIXTURE = {
    "id": "agent-uuid-1",
    "owner_id": "user-uuid-1",
    "name": "Web Search",
    "slug": "web-search",
    "description": "Searches the web",
    "auth_type": "none",
    "rate_type": "per_call",
    "rate_amount": 0.01,
    "status": "active",
    "trust_score": 0.95,
    "tags": ["search"],
    "created_at": "2025-01-01T00:00:00Z",
    "updated_at": "2025-01-01T00:00:00Z",
}

JOB_FIXTURE = {
    "id": "job-uuid-1",
    "provider_agent_id": "agent-uuid-1",
    "status": "pending",
    "capability_used": "search",
    "created_at": "2025-01-01T00:00:00Z",
}

KEY_FIXTURE = {
    "id": "key-uuid-1",
    "profile_id": "user-uuid-1",
    "name": "my-key",
    "key_prefix": "sp_live_",
    "scopes": [],
    "rate_limit_rpm": 60,
    "revoked": False,
    "created_at": "2025-01-01T00:00:00Z",
}


# ---------------------------------------------------------------------------
# Sync client tests
# ---------------------------------------------------------------------------


@respx.mock
def test_agents_list() -> None:
    payload = {"agents": [AGENT_FIXTURE], "total": 1, "limit": 20, "offset": 0}
    respx.get(f"{BASE_URL}/api/agents").mock(return_value=httpx.Response(200, json=payload))

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    result = client.agents.list()
    assert result["total"] == 1
    assert result["agents"][0]["slug"] == "web-search"


@respx.mock
def test_agents_list_with_filters() -> None:
    payload = {"agents": [], "total": 0, "limit": 10, "offset": 0}
    route = respx.get(f"{BASE_URL}/api/agents").mock(
        return_value=httpx.Response(200, json=payload)
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    client.agents.list(tags=["search", "ai"], trust_min=0.8, limit=10)

    request = route.calls[0].request
    assert "tags=search%2Cai" in str(request.url) or "tags=search,ai" in str(request.url)
    assert "trust_min=0.8" in str(request.url)


@respx.mock
def test_agents_get() -> None:
    detail = {**AGENT_FIXTURE, "trust_in": [], "trust_out": []}
    respx.get(f"{BASE_URL}/api/agents/web-search").mock(
        return_value=httpx.Response(200, json=detail)
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    agent = client.agents.get("web-search")
    assert agent["slug"] == "web-search"
    assert "trust_in" in agent


@respx.mock
def test_agents_create() -> None:
    respx.post(f"{BASE_URL}/api/agents").mock(
        return_value=httpx.Response(201, json=AGENT_FIXTURE)
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    agent = client.agents.create(
        name="Web Search",
        slug="web-search",
        rate_type="per_call",
        rate_amount=0.01,
        tags=["search"],
    )
    assert agent["slug"] == "web-search"


@respx.mock
def test_agents_update() -> None:
    updated = {**AGENT_FIXTURE, "status": "inactive"}
    respx.patch(f"{BASE_URL}/api/agents/web-search").mock(
        return_value=httpx.Response(200, json=updated)
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    agent = client.agents.update("web-search", status="inactive")
    assert agent["status"] == "inactive"


@respx.mock
def test_jobs_create() -> None:
    respx.post(f"{BASE_URL}/api/jobs").mock(
        return_value=httpx.Response(201, json=JOB_FIXTURE)
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    job = client.jobs.create(
        provider_agent_id="agent-uuid-1",
        capability_used="search",
        input_data={"query": "hello"},
    )
    assert job["id"] == "job-uuid-1"
    assert job["status"] == "pending"


@respx.mock
def test_jobs_get() -> None:
    respx.get(f"{BASE_URL}/api/jobs/job-uuid-1").mock(
        return_value=httpx.Response(200, json=JOB_FIXTURE)
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    job = client.jobs.get("job-uuid-1")
    assert job["id"] == "job-uuid-1"


@respx.mock
def test_jobs_update() -> None:
    completed = {**JOB_FIXTURE, "status": "completed", "duration_ms": 120}
    respx.patch(f"{BASE_URL}/api/jobs/job-uuid-1").mock(
        return_value=httpx.Response(200, json=completed)
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    job = client.jobs.update("job-uuid-1", status="completed", duration_ms=120)
    assert job["status"] == "completed"


@respx.mock
def test_keys_list() -> None:
    respx.get(f"{BASE_URL}/api/keys").mock(
        return_value=httpx.Response(200, json=[KEY_FIXTURE])
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    keys = client.keys.list()
    assert len(keys) == 1
    assert keys[0]["name"] == "my-key"


@respx.mock
def test_keys_create() -> None:
    created = {**KEY_FIXTURE, "key": "sp_live_abcdef1234567890"}
    respx.post(f"{BASE_URL}/api/keys").mock(
        return_value=httpx.Response(201, json=created)
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    key = client.keys.create(name="my-key")
    assert "key" in key
    assert key["key"].startswith("sp_live_")


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


@respx.mock
def test_auth_error() -> None:
    respx.get(f"{BASE_URL}/api/agents").mock(
        return_value=httpx.Response(401, json={"error": "Invalid API key"})
    )

    client = SignalPotClient(api_key="bad_key", base_url=BASE_URL)
    with pytest.raises(AuthError) as exc_info:
        client.agents.list()
    assert exc_info.value.status_code == 401


@respx.mock
def test_not_found_error() -> None:
    respx.get(f"{BASE_URL}/api/agents/nonexistent").mock(
        return_value=httpx.Response(404, json={"error": "Not found"})
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    with pytest.raises(NotFoundError):
        client.agents.get("nonexistent")


@respx.mock
def test_rate_limit_error() -> None:
    respx.get(f"{BASE_URL}/api/agents").mock(
        return_value=httpx.Response(
            429,
            json={"error": "Rate limit exceeded"},
            headers={"retry-after": "10"},
        )
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    with pytest.raises(RateLimitError) as exc_info:
        client.agents.list()
    assert exc_info.value.retry_after == 10


@respx.mock
def test_validation_error() -> None:
    respx.post(f"{BASE_URL}/api/agents").mock(
        return_value=httpx.Response(422, json={"error": "slug must be lowercase"})
    )

    client = SignalPotClient(api_key=API_KEY, base_url=BASE_URL)
    with pytest.raises(ValidationError):
        client.agents.create(name="Bad Slug", slug="Bad_Slug")


# ---------------------------------------------------------------------------
# Async client tests
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_async_agents_list() -> None:
    payload = {"agents": [AGENT_FIXTURE], "total": 1, "limit": 20, "offset": 0}
    respx.get(f"{BASE_URL}/api/agents").mock(return_value=httpx.Response(200, json=payload))

    async with AsyncSignalPotClient(api_key=API_KEY, base_url=BASE_URL) as client:
        result = await client.agents.list()
    assert result["total"] == 1


@respx.mock
@pytest.mark.asyncio
async def test_async_jobs_create() -> None:
    respx.post(f"{BASE_URL}/api/jobs").mock(
        return_value=httpx.Response(201, json=JOB_FIXTURE)
    )

    async with AsyncSignalPotClient(api_key=API_KEY, base_url=BASE_URL) as client:
        job = await client.jobs.create(provider_agent_id="agent-uuid-1")
    assert job["status"] == "pending"


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------


@respx.mock
def test_context_manager() -> None:
    payload = {"agents": [], "total": 0, "limit": 20, "offset": 0}
    respx.get(f"{BASE_URL}/api/agents").mock(return_value=httpx.Response(200, json=payload))

    with SignalPotClient(api_key=API_KEY, base_url=BASE_URL) as client:
        result = client.agents.list()
    assert result["total"] == 0
