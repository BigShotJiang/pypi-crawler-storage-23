from __future__ import annotations

from typing import Optional


class SignalPotError(Exception):
    """Base exception for all SignalPot SDK errors."""

    def __init__(self, message: str, status_code: Optional[int] = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class AuthError(SignalPotError):
    """Raised when the API key is missing, invalid, or expired (HTTP 401)."""


class ForbiddenError(SignalPotError):
    """Raised when the authenticated user lacks permission (HTTP 403)."""


class NotFoundError(SignalPotError):
    """Raised when the requested resource does not exist (HTTP 404)."""


class ValidationError(SignalPotError):
    """Raised when the request body fails server-side validation (HTTP 422)."""


class RateLimitError(SignalPotError):
    """Raised when the API key rate limit is exceeded (HTTP 429)."""

    def __init__(self, message: str, retry_after: Optional[int] = None) -> None:
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class InsufficientBalanceError(SignalPotError):
    """Raised when the user's credit balance is too low to complete a job (HTTP 402)."""


class ServerError(SignalPotError):
    """Raised for unexpected 5xx responses."""
