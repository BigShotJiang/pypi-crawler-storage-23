from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional

from .._models import Agent, AgentDetail, AgentList

if TYPE_CHECKING:
    from .._client import SignalPotClient, AsyncSignalPotClient


class AgentsResource:
    def __init__(self, client: "SignalPotClient") -> None:
        self._client = client

    def list(
        self,
        *,
        q: Optional[str] = None,
        capability: Optional[str] = None,
        tags: Optional[List[str]] = None,
        trust_min: Optional[float] = None,
        rate_max: Optional[float] = None,
        status: Optional[Literal["active", "inactive", "deprecated"]] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> AgentList:
        """List agents with optional filtering and pagination."""
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if q is not None:
            params["q"] = q
        if capability is not None:
            params["capability"] = capability
        if tags is not None:
            params["tags"] = ",".join(tags)
        if trust_min is not None:
            params["trust_min"] = trust_min
        if rate_max is not None:
            params["rate_max"] = rate_max
        if status is not None:
            params["status"] = status
        return self._client._request("GET", "/api/agents", params=params)  # type: ignore[return-value]

    def get(self, slug: str) -> AgentDetail:
        """Get a single agent by slug, including its trust graph neighbors."""
        return self._client._request("GET", f"/api/agents/{slug}")  # type: ignore[return-value]

    def create(
        self,
        *,
        name: str,
        slug: str,
        description: Optional[str] = None,
        endpoint_url: Optional[str] = None,
        auth_type: Literal["none", "bearer", "api_key", "oauth2"] = "none",
        auth_config: Optional[Dict[str, Any]] = None,
        capability_schema: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        rate_type: Literal["free", "per_call", "per_token"] = "free",
        rate_amount: Optional[float] = None,
        status: Literal["active", "inactive"] = "active",
    ) -> Agent:
        """Register a new agent. Requires authentication."""
        body: Dict[str, Any] = {
            "name": name,
            "slug": slug,
            "auth_type": auth_type,
            "rate_type": rate_type,
            "status": status,
        }
        if description is not None:
            body["description"] = description
        if endpoint_url is not None:
            body["endpoint_url"] = endpoint_url
        if auth_config is not None:
            body["auth_config"] = auth_config
        if capability_schema is not None:
            body["capability_schema"] = capability_schema
        if tags is not None:
            body["tags"] = tags
        if rate_amount is not None:
            body["rate_amount"] = rate_amount
        return self._client._request("POST", "/api/agents", json=body)  # type: ignore[return-value]

    def update(
        self,
        slug: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        endpoint_url: Optional[str] = None,
        auth_type: Optional[Literal["none", "bearer", "api_key", "oauth2"]] = None,
        auth_config: Optional[Dict[str, Any]] = None,
        capability_schema: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        rate_type: Optional[Literal["free", "per_call", "per_token"]] = None,
        rate_amount: Optional[float] = None,
        status: Optional[Literal["active", "inactive"]] = None,
    ) -> Agent:
        """Update an existing agent (owner only). Requires authentication."""
        body: Dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if endpoint_url is not None:
            body["endpoint_url"] = endpoint_url
        if auth_type is not None:
            body["auth_type"] = auth_type
        if auth_config is not None:
            body["auth_config"] = auth_config
        if capability_schema is not None:
            body["capability_schema"] = capability_schema
        if tags is not None:
            body["tags"] = tags
        if rate_type is not None:
            body["rate_type"] = rate_type
        if rate_amount is not None:
            body["rate_amount"] = rate_amount
        if status is not None:
            body["status"] = status
        return self._client._request("PATCH", f"/api/agents/{slug}", json=body)  # type: ignore[return-value]


class AsyncAgentsResource:
    def __init__(self, client: "AsyncSignalPotClient") -> None:
        self._client = client

    async def list(
        self,
        *,
        q: Optional[str] = None,
        capability: Optional[str] = None,
        tags: Optional[List[str]] = None,
        trust_min: Optional[float] = None,
        rate_max: Optional[float] = None,
        status: Optional[Literal["active", "inactive", "deprecated"]] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> AgentList:
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if q is not None:
            params["q"] = q
        if capability is not None:
            params["capability"] = capability
        if tags is not None:
            params["tags"] = ",".join(tags)
        if trust_min is not None:
            params["trust_min"] = trust_min
        if rate_max is not None:
            params["rate_max"] = rate_max
        if status is not None:
            params["status"] = status
        return await self._client._request("GET", "/api/agents", params=params)  # type: ignore[return-value]

    async def get(self, slug: str) -> AgentDetail:
        return await self._client._request("GET", f"/api/agents/{slug}")  # type: ignore[return-value]

    async def create(
        self,
        *,
        name: str,
        slug: str,
        description: Optional[str] = None,
        endpoint_url: Optional[str] = None,
        auth_type: Literal["none", "bearer", "api_key", "oauth2"] = "none",
        auth_config: Optional[Dict[str, Any]] = None,
        capability_schema: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        rate_type: Literal["free", "per_call", "per_token"] = "free",
        rate_amount: Optional[float] = None,
        status: Literal["active", "inactive"] = "active",
    ) -> Agent:
        body: Dict[str, Any] = {
            "name": name,
            "slug": slug,
            "auth_type": auth_type,
            "rate_type": rate_type,
            "status": status,
        }
        if description is not None:
            body["description"] = description
        if endpoint_url is not None:
            body["endpoint_url"] = endpoint_url
        if auth_config is not None:
            body["auth_config"] = auth_config
        if capability_schema is not None:
            body["capability_schema"] = capability_schema
        if tags is not None:
            body["tags"] = tags
        if rate_amount is not None:
            body["rate_amount"] = rate_amount
        return await self._client._request("POST", "/api/agents", json=body)  # type: ignore[return-value]

    async def update(
        self,
        slug: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        endpoint_url: Optional[str] = None,
        auth_type: Optional[Literal["none", "bearer", "api_key", "oauth2"]] = None,
        auth_config: Optional[Dict[str, Any]] = None,
        capability_schema: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        rate_type: Optional[Literal["free", "per_call", "per_token"]] = None,
        rate_amount: Optional[float] = None,
        status: Optional[Literal["active", "inactive"]] = None,
    ) -> Agent:
        body: Dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if endpoint_url is not None:
            body["endpoint_url"] = endpoint_url
        if auth_type is not None:
            body["auth_type"] = auth_type
        if auth_config is not None:
            body["auth_config"] = auth_config
        if capability_schema is not None:
            body["capability_schema"] = capability_schema
        if tags is not None:
            body["tags"] = tags
        if rate_type is not None:
            body["rate_type"] = rate_type
        if rate_amount is not None:
            body["rate_amount"] = rate_amount
        if status is not None:
            body["status"] = status
        return await self._client._request("PATCH", f"/api/agents/{slug}", json=body)  # type: ignore[return-value]
