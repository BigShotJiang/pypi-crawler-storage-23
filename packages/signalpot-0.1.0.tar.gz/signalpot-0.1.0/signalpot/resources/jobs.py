from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, Literal, Optional

from .._models import Job

if TYPE_CHECKING:
    from .._client import SignalPotClient, AsyncSignalPotClient


class JobsResource:
    def __init__(self, client: "SignalPotClient") -> None:
        self._client = client

    def create(
        self,
        *,
        provider_agent_id: str,
        requester_agent_id: Optional[str] = None,
        capability_used: Optional[str] = None,
        input_data: Optional[Dict[str, Any]] = None,
        cost: Optional[float] = None,
    ) -> Job:
        """Record a new job against a provider agent. Requires authentication."""
        body: Dict[str, Any] = {"provider_agent_id": provider_agent_id}
        if requester_agent_id is not None:
            body["requester_agent_id"] = requester_agent_id
        if capability_used is not None:
            body["capability_used"] = capability_used
        if input_data is not None:
            body["input_data"] = input_data
        if cost is not None:
            body["cost"] = cost
        return self._client._request("POST", "/api/jobs", json=body)  # type: ignore[return-value]

    def get(self, job_id: str) -> Job:
        """Get a job by ID."""
        return self._client._request("GET", f"/api/jobs/{job_id}")  # type: ignore[return-value]

    def update(
        self,
        job_id: str,
        *,
        status: Literal["running", "completed", "failed"],
        output_data: Optional[Dict[str, Any]] = None,
        error_message: Optional[str] = None,
        duration_ms: Optional[int] = None,
    ) -> Job:
        """Update a job's status (provider agent owner only). Requires authentication.

        Valid transitions:
          pending  → running | failed
          running  → completed | failed
        """
        body: Dict[str, Any] = {"status": status}
        if output_data is not None:
            body["output_data"] = output_data
        if error_message is not None:
            body["error_message"] = error_message
        if duration_ms is not None:
            body["duration_ms"] = duration_ms
        return self._client._request("PATCH", f"/api/jobs/{job_id}", json=body)  # type: ignore[return-value]


class AsyncJobsResource:
    def __init__(self, client: "AsyncSignalPotClient") -> None:
        self._client = client

    async def create(
        self,
        *,
        provider_agent_id: str,
        requester_agent_id: Optional[str] = None,
        capability_used: Optional[str] = None,
        input_data: Optional[Dict[str, Any]] = None,
        cost: Optional[float] = None,
    ) -> Job:
        body: Dict[str, Any] = {"provider_agent_id": provider_agent_id}
        if requester_agent_id is not None:
            body["requester_agent_id"] = requester_agent_id
        if capability_used is not None:
            body["capability_used"] = capability_used
        if input_data is not None:
            body["input_data"] = input_data
        if cost is not None:
            body["cost"] = cost
        return await self._client._request("POST", "/api/jobs", json=body)  # type: ignore[return-value]

    async def get(self, job_id: str) -> Job:
        return await self._client._request("GET", f"/api/jobs/{job_id}")  # type: ignore[return-value]

    async def update(
        self,
        job_id: str,
        *,
        status: Literal["running", "completed", "failed"],
        output_data: Optional[Dict[str, Any]] = None,
        error_message: Optional[str] = None,
        duration_ms: Optional[int] = None,
    ) -> Job:
        body: Dict[str, Any] = {"status": status}
        if output_data is not None:
            body["output_data"] = output_data
        if error_message is not None:
            body["error_message"] = error_message
        if duration_ms is not None:
            body["duration_ms"] = duration_ms
        return await self._client._request("PATCH", f"/api/jobs/{job_id}", json=body)  # type: ignore[return-value]
