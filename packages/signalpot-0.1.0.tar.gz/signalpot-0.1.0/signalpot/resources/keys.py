from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from .._models import ApiKey, CreatedApiKey

if TYPE_CHECKING:
    from .._client import SignalPotClient, AsyncSignalPotClient


class KeysResource:
    def __init__(self, client: "SignalPotClient") -> None:
        self._client = client

    def list(self) -> List[ApiKey]:
        """List all API keys for the current user. Session auth only."""
        return self._client._request("GET", "/api/keys")  # type: ignore[return-value]

    def create(
        self,
        *,
        name: str,
        scopes: Optional[List[str]] = None,
        expires_at: Optional[str] = None,
    ) -> CreatedApiKey:
        """Create a new API key. Returns the full key *once* — store it securely.

        Session auth only (you cannot create API keys using an API key).
        The rate limit is automatically derived from the user's current plan.
        """
        body: Dict[str, Any] = {"name": name, "scopes": scopes or []}
        if expires_at is not None:
            body["expires_at"] = expires_at
        return self._client._request("POST", "/api/keys", json=body)  # type: ignore[return-value]


class AsyncKeysResource:
    def __init__(self, client: "AsyncSignalPotClient") -> None:
        self._client = client

    async def list(self) -> List[ApiKey]:
        return await self._client._request("GET", "/api/keys")  # type: ignore[return-value]

    async def create(
        self,
        *,
        name: str,
        scopes: Optional[List[str]] = None,
        expires_at: Optional[str] = None,
    ) -> CreatedApiKey:
        body: Dict[str, Any] = {"name": name, "scopes": scopes or []}
        if expires_at is not None:
            body["expires_at"] = expires_at
        return await self._client._request("POST", "/api/keys", json=body)  # type: ignore[return-value]
