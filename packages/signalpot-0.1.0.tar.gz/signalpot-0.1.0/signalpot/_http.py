"""Shared HTTP logic: request dispatch, error mapping."""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from ._exceptions import (
    AuthError,
    ForbiddenError,
    InsufficientBalanceError,
    NotFoundError,
    RateLimitError,
    ServerError,
    SignalPotError,
    ValidationError,
)
from ._version import __version__

_DEFAULT_BASE_URL = "https://www.signalpot.dev"
_DEFAULT_TIMEOUT = 30.0

_USER_AGENT = f"signalpot-python/{__version__}"


def _raise_for_status(response: httpx.Response) -> None:
    if response.is_success:
        return

    try:
        body = response.json()
        message = body.get("error") or body.get("message") or response.text
    except Exception:
        message = response.text or f"HTTP {response.status_code}"

    status = response.status_code

    if status == 401:
        raise AuthError(message, status_code=status)
    if status == 402:
        raise InsufficientBalanceError(message, status_code=status)
    if status == 403:
        raise ForbiddenError(message, status_code=status)
    if status == 404:
        raise NotFoundError(message, status_code=status)
    if status == 422:
        raise ValidationError(message, status_code=status)
    if status == 429:
        retry_after: Optional[int] = None
        raw = response.headers.get("retry-after")
        if raw and raw.isdigit():
            retry_after = int(raw)
        raise RateLimitError(message, retry_after=retry_after)
    if status >= 500:
        raise ServerError(message, status_code=status)

    raise SignalPotError(message, status_code=status)


def _build_headers(api_key: str) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {api_key}",
        "User-Agent": _USER_AGENT,
        "Accept": "application/json",
    }


class SyncTransport:
    def __init__(self, api_key: str, base_url: str, timeout: float) -> None:
        self._client = httpx.Client(
            base_url=base_url,
            headers=_build_headers(api_key),
            timeout=timeout,
        )

    def request(self, method: str, path: str, **kwargs: Any) -> Any:
        response = self._client.request(method, path, **kwargs)
        _raise_for_status(response)
        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "SyncTransport":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncTransport:
    def __init__(self, api_key: str, base_url: str, timeout: float) -> None:
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers=_build_headers(api_key),
            timeout=timeout,
        )

    async def request(self, method: str, path: str, **kwargs: Any) -> Any:
        response = await self._client.request(method, path, **kwargs)
        _raise_for_status(response)
        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncTransport":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()
