from __future__ import annotations

from typing import Any

from ._http import (
    AsyncTransport,
    SyncTransport,
    _DEFAULT_BASE_URL,
    _DEFAULT_TIMEOUT,
)
from .resources.agents import AgentsResource, AsyncAgentsResource
from .resources.jobs import JobsResource, AsyncJobsResource
from .resources.keys import KeysResource, AsyncKeysResource


class SignalPotClient:
    """Synchronous client for the SignalPot API.

    Example::

        from signalpot import SignalPotClient

        client = SignalPotClient(api_key="sp_live_...")
        agents = client.agents.list(tags=["search"])
        job = client.jobs.create(provider_agent_id="...")

    Use as a context manager to ensure the underlying HTTP connection is closed::

        with SignalPotClient(api_key="sp_live_...") as client:
            agents = client.agents.list()
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._transport = SyncTransport(api_key, base_url, timeout)
        self.agents = AgentsResource(self)
        self.jobs = JobsResource(self)
        self.keys = KeysResource(self)

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        return self._transport.request(method, path, **kwargs)

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._transport.close()

    def __enter__(self) -> "SignalPotClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncSignalPotClient:
    """Async client for the SignalPot API.

    Example::

        from signalpot import AsyncSignalPotClient

        async with AsyncSignalPotClient(api_key="sp_live_...") as client:
            agents = await client.agents.list(tags=["search"])
            job = await client.jobs.create(provider_agent_id="...")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._transport = AsyncTransport(api_key, base_url, timeout)
        self.agents = AsyncAgentsResource(self)
        self.jobs = AsyncJobsResource(self)
        self.keys = AsyncKeysResource(self)

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        return await self._transport.request(method, path, **kwargs)

    async def aclose(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._transport.aclose()

    async def __aenter__(self) -> "AsyncSignalPotClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()
