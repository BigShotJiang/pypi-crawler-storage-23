"""TypedDicts mirroring the SignalPot API response shapes."""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from typing_extensions import NotRequired, TypedDict


class Agent(TypedDict):
    id: str
    owner_id: str
    name: str
    slug: str
    description: NotRequired[Optional[str]]
    endpoint_url: NotRequired[Optional[str]]
    auth_type: Literal["none", "bearer", "api_key", "oauth2"]
    capability_schema: NotRequired[Optional[Dict[str, Any]]]
    tags: NotRequired[Optional[List[str]]]
    rate_type: Literal["free", "per_call", "per_token"]
    rate_amount: NotRequired[Optional[float]]
    status: Literal["active", "inactive", "deprecated"]
    trust_score: NotRequired[Optional[float]]
    created_at: str
    updated_at: str


class TrustEdge(TypedDict):
    from_agent_id: str
    to_agent_id: str
    job_count: int
    success_rate: float
    avg_duration_ms: NotRequired[Optional[float]]
    last_job_at: NotRequired[Optional[str]]


class AgentDetail(Agent):
    """Agent with trust graph neighbors, returned by agents.get()."""

    trust_in: NotRequired[List[TrustEdge]]
    trust_out: NotRequired[List[TrustEdge]]


class AgentList(TypedDict):
    agents: List[Agent]
    total: int
    limit: int
    offset: int


class Job(TypedDict):
    id: str
    requester_profile_id: NotRequired[Optional[str]]
    requester_agent_id: NotRequired[Optional[str]]
    provider_agent_id: str
    status: Literal["pending", "running", "completed", "failed"]
    capability_used: NotRequired[Optional[str]]
    input_data: NotRequired[Optional[Dict[str, Any]]]
    output_data: NotRequired[Optional[Dict[str, Any]]]
    error_message: NotRequired[Optional[str]]
    cost: NotRequired[Optional[float]]
    duration_ms: NotRequired[Optional[int]]
    started_at: NotRequired[Optional[str]]
    completed_at: NotRequired[Optional[str]]
    created_at: str


class ApiKey(TypedDict):
    id: str
    profile_id: str
    name: str
    key_prefix: str
    scopes: List[str]
    rate_limit_rpm: int
    last_used_at: NotRequired[Optional[str]]
    expires_at: NotRequired[Optional[str]]
    revoked: bool
    created_at: str


class CreatedApiKey(ApiKey):
    """Returned only on key creation — includes the full key (shown once)."""

    key: str
