"""
MemorySystem — Production-ready memory system with sharding, BM25 search, and concurrency safety.

Features:
- Sharded storage for scalability (10K+ memories)
- BM25-inspired search with IDF weighting and field boosting
- File locking and optimistic conflict detection
- Fast indexes (full-text, tags, dates)
- Schema migration with backward compatibility

Usage:
    from antaris_memory import MemorySystem

    mem = MemorySystem("./workspace")
    mem.load()
    mem.ingest("Key decision", source="meeting", category="strategic")
    results = mem.search("decision")
    mem.save()  # Saves to sharded format
"""

import json
import os
import re
import time
from collections import defaultdict

# v4.6.6 — Pre-ingest metadata junk filter
# Rejects lines that look like raw JSON key-value pairs (from Discord metadata
# blocks that slipped through the plugin's stripContextPacket) or structural
# JSON tokens. These are never meaningful memories.
#   Matches:  "message_id": "1234"
#             "conversation_label": "Guild #..."
#             "sender_id": "276...",
#             { / } / [ / ]  standing alone
_METADATA_LINE_RE = re.compile(
    r'^[{\[\]},]$'                                     # bare JSON structural tokens
    r'|^\s*"[a-z_]{2,40}"\s*:\s*'                     # JSON key-value lines "key": ...
    r'|^<!--.*-->$'                                     # HTML comment markers
    r'|^\s*```[a-z]*\s*$'                              # fenced code block delimiters
    r'|^\s*\*\(from:\s*[\w:]+\)\*\s*$'                # context packet source tags
    r'|^Packet built \d{4}-\d{2}-\d{2}'               # context packet timestamp lines
    r'|^\[Queued messages while agent was busy\]\s*$'  # OpenClaw queued message banner
    r'|^Queued #\d+\s*$'                               # queued message index lines
    r'|^\s*-{3,}\s*$'                                  # horizontal rule separators
    r'|^\[System Message\]'                             # system message lines
    r'|^Reasoning:\s*$',                               # bare reasoning labels
    re.IGNORECASE
)
import copy
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from .entry import MemoryEntry
from .decay import DecayEngine
from .sentiment import SentimentTagger
from .temporal import TemporalEngine
from .confidence import ConfidenceEngine
from .compression import CompressionEngine
from .forgetting import ForgettingEngine
from .consolidation import ConsolidationEngine
from .gating import InputGate
from .synthesis import KnowledgeSynthesizer
from .sharding import ShardManager
from .migration import MigrationManager
# v4.6.0: Incremental Index Loading + Time-Window Shard Splitting
from .wal import WALWriter, WALReader
from .shards import ShardManager as TimeShardManager
from .migrate import migrate_to_shards as _migrate_to_shards
from .indexing import IndexManager
from .search import SearchEngine, SearchResult
from .context_packet import ContextPacket, ContextPacketBuilder
from .namespace import NamespaceManager
from .memory_types import (
    MEMORY_TYPE_CONFIGS, DEFAULT_TYPE, get_type_config,
    format_mistake_content, SEVERITY_LEVELS,
)
from .utils import atomic_write_json
from .performance import ReadCache, WALManager, PerformanceMonitor, AccessTracker
from .shared import SharedMemoryPool
from .category_tagger import CategoryTagger

# Module-level CategoryTagger singleton — shared across all ingest paths
_ct = CategoryTagger()

# Default tags to auto-extract
_DEFAULT_TAG_TERMS = [
    "web3", "ethereum", "postgresql", "optimization", "cost",
    "revenue", "security", "deployment", "production", "testing",
]


class MemorySystemV4(NamespaceManager):
    """Production-ready memory system with sharding and indexing.

    Parameters
    ----------
    workspace : str
        Root directory. Shards and indexes are stored here.
    half_life : float
        Decay half-life in days (default 7).
    tag_terms : list[str] | None
        Custom terms to auto-tag. Merged with built-in defaults.
    use_sharding : bool
        Whether to use sharded storage (default True for v0.4).
    use_indexing : bool
        Whether to build search indexes (default True for v0.4).
    """

    def __init__(
        self,
        workspace: str = ".",
        half_life: float = 7.0,
        tag_terms: List[str] = None,
        use_sharding: bool = True,
        use_indexing: bool = True,
        enable_read_cache: bool = True,
        cache_max_entries: int = 1000,
        agent_name: Optional[str] = None,
        # v4.6.0: time-window shard splitting + incremental index loading
        sharding: bool = True,
        # v4.6.5: LLM-enriched indexing — any callable(str) -> dict
        enricher: Optional[Callable[[str], dict]] = None,
        # v4.7.0: tiered storage — load hot tier only on startup
        tiered_storage: bool = True,
        # v4.8.0: graph intelligence — entity extraction + relationship-aware search
        graph_intelligence: bool = True,
        # v4.9.0: quality routing — follow-up pattern detection + outcome tracking
        quality_routing: bool = True,
    ):
        self.workspace = os.path.abspath(workspace)
        self.agent_name = agent_name
        if agent_name is None:
            import warnings
            warnings.warn(
                "[antaris-memory] agent_name not set. Memories will not be agent-scoped. "
                "Pass agent_name='your-agent-name' to MemorySystem() to enable per-agent "
                "isolation and correct cross-instance context restore.",
                UserWarning,
                stacklevel=2,
            )
        self.use_sharding = use_sharding
        self.use_indexing = use_indexing

        # Backward compatibility paths
        self.legacy_metadata_path = os.path.join(self.workspace, "memory_metadata.json")
        self.audit_path = os.path.join(self.workspace, "memory_audit.json")

        # v0.4 managers
        self.migration_manager = MigrationManager(workspace)
        self.shard_manager = ShardManager(workspace) if use_sharding else None
        self.index_manager = IndexManager(workspace) if use_indexing else None

        # Engines (same as v0.3)
        self.decay = DecayEngine(half_life=half_life)
        self.sentiment = SentimentTagger()
        self.temporal = TemporalEngine()
        self.confidence = ConfidenceEngine()
        self.compression = CompressionEngine()
        self.forgetting = ForgettingEngine()
        self.consolidation = ConsolidationEngine(decay=self.decay)
        self.gating = InputGate()
        self.synthesis = KnowledgeSynthesizer()
        self.search_engine = SearchEngine()

        # Tag terms
        self._tag_terms = list(set(_DEFAULT_TAG_TERMS + (tag_terms or [])))

        # Memory store (in-memory cache)
        self.memories: List[MemoryEntry] = []
        self._hashes: set = set()

        # Sprint 11 — performance subsystem
        self._read_cache: Optional[ReadCache] = (
            ReadCache(cache_max_entries) if enable_read_cache else None
        )
        self._enable_read_cache = enable_read_cache
        self._wal = WALManager(self.workspace)
        self._perf = PerformanceMonitor()
        self._access_tracker = AccessTracker(self.workspace)

        # Sprint 3 — pluggable embedding for hybrid semantic search
        self._embedding_fn: Optional[Callable[[str], List[float]]] = None
        self._embedding_cache: Dict[str, List[float]] = {}  # key -> vector, bounded to 1000

        # v4.6.5 — LLM enricher (any callable: str -> {tags, summary, keywords})
        self._enricher: Optional[Callable[[str], dict]] = enricher
        # v4.6.5 — Enrichment counter (lifetime, resets on get_enrichment_count(reset=True))
        self._enrichment_count: int = 0

        # v3.2 — Instrumentation + Co-occurrence (Tier 1 Semantic)
        from .instrumentation import SearchContext
        from .cooccurrence import CooccurrenceIndex
        self._cooccurrence = CooccurrenceIndex(self.workspace)
        self._cooccurrence.load()
        self._instrumentation_log_path = os.path.join(self.workspace, ".instrumentation_log.jsonl")
        self._usage_signals_path = os.path.join(self.workspace, ".usage_signals.jsonl")
        self.opt_in_to_aggregation: bool = False  # Must explicitly opt in
        self._shared_pool: Optional["SharedMemoryPool"] = None
        self._shared_agent_id: Optional[str] = None

        # ── v4.6.0: Time-Window Shard Splitting ─────────────────────────────
        # ``sharding`` controls the NEW weekly shard system (shards.py).
        # It is only active when ``use_sharding=False`` so the enterprise
        # sharding system (sharding.py) takes priority when enabled.
        self._v46_sharding: bool = sharding
        self._v46_shards: Optional[TimeShardManager] = (
            TimeShardManager(self.workspace) if sharding else None
        )

        # ── v4.7.0: Tiered Storage ───────────────────────────────────────────
        # When tiered_storage=True and the v4.6 shard system is active, only
        # the hot tier (0-3 days) is loaded into self.memories on startup.
        # Warm-tier shards (3-14 days) are loaded on-demand when a search
        # returns fewer than WARM_FALLBACK_THRESHOLD results.
        self._tiered_storage: bool = tiered_storage and sharding and not use_sharding
        if self._tiered_storage:
            from .tiers import TierManager
            self._tier_manager: Optional["TierManager"] = TierManager(self.workspace)
        else:
            self._tier_manager = None
        # Warm shard names populated during _load_v46_shards(); used by search()
        self._warm_shard_names: List[str] = []
        self._cold_shard_names: List[str] = []

        # ── v4.9.0: Graph Intelligence ───────────────────────────────────────
        # Entity extraction + relationship-aware search boost.
        # Disabled when graph_intelligence=False (zero overhead).
        self._graph_enabled: bool = graph_intelligence
        if self._graph_enabled:
            try:
                from .graph import MemoryGraph
                self._graph: Optional["MemoryGraph"] = MemoryGraph(self.workspace)
            except Exception:
                self._graph_enabled = False
                self._graph = None
        else:
            self._graph = None

        # ── v4.9.0: Quality Routing ──────────────────────────────────────────
        # Follow-up search pattern detection + outcome-based importance scoring.
        self._quality_routing_enabled: bool = quality_routing
        if self._quality_routing_enabled:
            try:
                from .quality_router import QualityRouter
                self._quality_router: Optional["QualityRouter"] = QualityRouter(self.workspace)
            except Exception:
                self._quality_routing_enabled = False
                self._quality_router = None
        else:
            self._quality_router = None

        # ── v4.6.0: Incremental Index Loading ───────────────────────────────
        self._index_path: str = os.path.join(self.workspace, ".antaris_index.json")
        self._index_wal_path: str = os.path.join(self.workspace, ".antaris_wal.jsonl")
        self._index_wal_writer: WALWriter = WALWriter()
        self._index_wal_writer.open(self._index_wal_path)
        self._index_wal_entry_count: int = 0  # entries written since last flush

        # Initialize system
        self._initialize()

    def _initialize(self):
        """Initialize the memory system, handling migrations if needed."""
        import logging  # Bug fix: moved to top of method — was inside success branch only
        _log = logging.getLogger("antaris_memory")
        # Check if migration is needed
        if self.migration_manager.needs_migration():
            migration_result = self.migration_manager.migrate()
            if migration_result["status"] == "success":
                _log.info(
                    f"Migrated from {migration_result['from_version']} to {migration_result['to_version']}")
            elif migration_result["status"] == "error":
                _log.error(
                    f"Migration failed: {migration_result['message']}")
                # Fall back to legacy format
                self.use_sharding = False
                self.use_indexing = False

        # Sprint 8 — namespace manager
        self._init_namespace_manager()

        # Load existing data
        self.load()

        # v4.6.0: Set up incremental index (after memories are loaded)
        self._setup_v46_index()

    # ── persistence ─────────────────────────────────────────────────────

    def save(self) -> str:
        """Save memory state to disk using the appropriate format."""
        # v4.9.0: persist graph alongside memories
        if self._graph_enabled and self._graph is not None:
            try:
                self._graph.save()
            except Exception:
                pass
        if self.use_sharding and self.shard_manager:
            return self._save_sharded()
        else:
            return self._save_legacy()
    
    def _save_sharded(self) -> str:
        """Save using v0.4 sharded format."""
        if not self.shard_manager:
            return self._save_legacy()
        
        # Group memories by shard
        shard_groups = self.shard_manager.shard_memories(self.memories)
        
        # Save each shard
        for shard_key, shard_memories in shard_groups.items():
            self.shard_manager.save_shard(shard_key, shard_memories)
            self.shard_manager.index.add_shard(shard_key, shard_memories)
        
        # Save shard index
        self.shard_manager.index.save_index()
        
        # Update search indexes
        if self.use_indexing and self.index_manager:
            self.index_manager.rebuild_indexes(self.memories)
            self.index_manager.save_all_indexes()
        
        shard_dir = os.path.join(self.workspace, "shards")
        return shard_dir
    
    def _save_legacy(self) -> str:
        """Save using v0.2/v0.3 legacy single-file format."""
        from . import __version__ as _pkg_version  # Bug fix: distinguish format vs pkg version
        data = {
            "version": "0.4.0",           # storage schema version (used by migration logic)
            "package_version": _pkg_version,  # antaris-memory package version
            "saved_at": datetime.now(timezone.utc).isoformat(),
            "count": len(self.memories),
            "format": "legacy",
            "memories": [m.to_dict() for m in self.memories],
        }
        atomic_write_json(self.legacy_metadata_path, data)
        return self.legacy_metadata_path

    # ── WAL flush / close ─────────────────────────────────────────────────

    def flush(self) -> Dict:
        """Compact the WAL into permanent shard/legacy storage.

        Called automatically after ``WALManager.flush_interval`` writes or
        when the WAL exceeds 1 MB.  Also called by ``close()``.

        Returns:
            ``{"flushed_entries": N, "wal_cleared": True}``
        """
        pending_before = self._wal.pending_count()

        # Persist current in-memory state (includes WAL-replayed entries)
        self.save()

        # Persist access counts alongside the flush
        self._access_tracker.save()

        # Persist co-occurrence index (deferred from ingest for bulk-write perf)
        self._cooccurrence.save()

        # WAL has been safely persisted to shards — clear it
        self._wal.clear()

        # Invalidate read-cache (data on disk changed)
        if self._read_cache is not None:
            self._read_cache.invalidate()

        self._perf.record_compaction()

        return {"flushed_entries": pending_before, "wal_cleared": True}

    def close(self) -> None:
        """Flush WAL and release resources.  Call before process exit."""
        self.flush()

    def load(self) -> int:
        """Load memory state from disk, auto-detecting format.

        Sprint 11: after loading from shards/legacy, replays any pending WAL
        entries so that a crash between ingest and flush loses no data.

        v4.6.0: When ``use_sharding=False`` and ``sharding=True``, loads from
        the time-window shard files (``memories_YYYY-WXX.jsonl``).  Also
        auto-migrates ``memories.jsonl`` → weekly shards if the flat file
        exists but no shard files are present.
        """
        if self.use_sharding and self.shard_manager:
            count = self._load_sharded()
            if count > 0:
                self._replay_wal()
                return len(self.memories)

        # v4.6.0: time-window shard load path (only when enterprise sharding off)
        if not self.use_sharding and self._v46_sharding and self._v46_shards:
            self._v46_auto_migrate()
            count = self._load_v46_shards()
            if count > 0:
                self._replay_wal()
                return len(self.memories)

        # Fall back to legacy flat format (memories.jsonl or memory_metadata.json)
        result = self._load_legacy()
        self._replay_wal()
        return len(self.memories)

    def _replay_wal(self) -> int:
        """Replay pending WAL entries that were not yet compacted to shards.

        This is called automatically on ``load()`` and is safe to call even
        when the WAL is empty or doesn't exist.

        Returns:
            Number of entries replayed.
        """
        pending = self._wal.load_pending()
        if not pending:
            return 0

        replayed = 0
        for entry_dict in pending:
            try:
                entry = MemoryEntry.from_dict(entry_dict)
            except Exception:
                continue   # corrupted entry — skip

            if entry.hash in self._hashes:
                continue   # already in memory (e.g. flushed before crash)

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            replayed += 1

        if replayed:
            self.search_engine.mark_dirty()

        return replayed

    def _load_sharded(self) -> int:
        """Load from v0.4 sharded format."""
        if not self.shard_manager:
            return 0

        # Load all memories from shards (careful with memory usage)
        _LOAD_LIMIT = 10000
        self.memories = self.shard_manager.get_all_memories(limit=_LOAD_LIMIT)
        # Bug fix: warn when the safety limit is hit so users know data was truncated
        if len(self.memories) >= _LOAD_LIMIT:
            import warnings
            warnings.warn(
                f"antaris-memory: loaded {_LOAD_LIMIT} memories (safety limit). "
                "Some older memories may not be in the active set. "
                "Consider calling forget() or archiving old shards.",
                UserWarning,
                stacklevel=3,
            )
        self._hashes = {m.hash for m in self.memories}
        if self.memories:
            self.search_engine.build_index(self.memories)
        return len(self.memories)

    def _load_legacy(self) -> int:
        """Load from v0.2/v0.3 legacy single-file format."""
        if not os.path.exists(self.legacy_metadata_path):
            return 0

        with open(self.legacy_metadata_path) as f:
            data = json.load(f)

        self.memories = [MemoryEntry.from_dict(d) for d in data.get("memories", [])]
        self._hashes = {m.hash for m in self.memories}
        if self.memories:
            self.search_engine.build_index(self.memories)
        return len(self.memories)

    # ── v4.6.0: Time-Window Sharding helpers ────────────────────────────────

    def _v46_auto_migrate(self) -> None:
        """Auto-migrate memories.jsonl → weekly shards if flat file exists
        but no shard files are present yet (first-run migration).

        Emits a UserWarning so callers are aware the migration happened.
        """
        if self._v46_shards is None:
            return

        flat_path = os.path.join(self.workspace, "memories.jsonl")
        existing_shards = self._v46_shards.list_shards()

        if os.path.exists(flat_path) and not existing_shards:
            import warnings
            warnings.warn(
                "[antaris-memory v4.6] Auto-migrating memories.jsonl to "
                "time-window shard files (memories_YYYY-WXX.jsonl). "
                "Original backed up as memories.jsonl.bak.",
                UserWarning,
                stacklevel=5,
            )
            _migrate_to_shards(self.workspace)

    def _load_v46_shards(self) -> int:
        """Load memories from the active time-window shards (v4.6/v4.7 path).

        v4.6: Loads current week + previous 2 weeks (~3-week window).
        v4.7: When tiered_storage=True, classifies all shards into hot/warm/cold
        and loads only the hot tier into self.memories.  Warm shard names are
        stored in self._warm_shard_names for on-demand search fallback.
        """
        if not self._v46_shards:
            return 0

        if self._tiered_storage and self._tier_manager is not None:
            # v4.7: hot-only load
            all_shards = self._v46_shards.list_shards()
            hot, warm, cold = self._tier_manager.classify_shards(all_shards)
            self._warm_shard_names = warm
            self._cold_shard_names = cold

            # Load hot shards only
            hot_entries: List[MemoryEntry] = []
            seen: set = set()
            for shard_name in hot:
                for entry in self._tier_manager._load_shard(shard_name):
                    if entry.hash not in seen:
                        hot_entries.append(entry)
                        seen.add(entry.hash)

            self.memories = hot_entries
            self._hashes = {m.hash for m in self.memories}
            if self.memories:
                self.search_engine.build_index(self.memories)

            # Snapshot shard hashes for incremental sync
            self._tier_manager.save_hashes(all_shards)
            return len(self.memories)

        # v4.6 fallback: load current + 2 prior weeks
        self.memories = self._v46_shards.load_active_shards(weeks=2)
        self._hashes = {m.hash for m in self.memories}
        if self.memories:
            self.search_engine.build_index(self.memories)
        return len(self.memories)

    # ── v4.7.0: Tiered search helpers ─────────────────────────────────────

    def _warm_search_fallback(
        self,
        query: str,
        limit: int,
        category,
        min_confidence: float,
        decay_fn,
        session_id: str,
        effective_agent_id,
        memory_type,
        existing_hashes: set,
    ) -> list:
        """Load warm shards on-demand and search them.

        Called when the hot-tier search returns fewer than
        WARM_FALLBACK_THRESHOLD results. Results already present in the hot
        tier (by hash) are excluded to avoid duplicates.

        Returns a list of SearchResult objects (may be empty on any failure).
        """
        try:
            warm_entries = self._tier_manager.load_warm(self._warm_shard_names)
            if not warm_entries:
                return []
            # Build a temporary search engine scoped to warm entries
            from .search import SearchEngine
            warm_engine = SearchEngine()
            warm_engine.build_index(warm_entries)
            warm_results = warm_engine.search(
                query=query,
                memories=warm_entries,
                limit=limit * 5,
                category=category,
                min_score=min_confidence,
                decay_fn=decay_fn,
                session_id=session_id,
                agent_id=effective_agent_id,
            )
            # Filter memory_type and already-seen hashes
            if memory_type is not None:
                warm_results = [
                    r for r in warm_results
                    if getattr(r.entry, "memory_type", "episodic") == memory_type
                ]
            warm_results = [
                r for r in warm_results if r.entry.hash not in existing_hashes
            ]
            return warm_results[:limit]
        except Exception:
            return []  # non-fatal — always fall through to hot-tier results

    def _cold_search(
        self,
        query: str,
        limit: int,
        decay_fn,
        effective_agent_id,
        existing_hashes: set,
    ) -> list:
        """Load cold shards on-demand and search them (explicit opt-in only).

        Returns a list of SearchResult objects (may be empty on any failure).
        """
        try:
            if not self._tier_manager or not self._cold_shard_names:
                return []
            cold_entries = self._tier_manager.load_warm(self._cold_shard_names)
            if not cold_entries:
                return []
            from .search import SearchEngine
            cold_engine = SearchEngine()
            cold_engine.build_index(cold_entries)
            cold_results = cold_engine.search(
                query=query,
                memories=cold_entries,
                limit=limit * 5,
                decay_fn=decay_fn,
                agent_id=effective_agent_id,
            )
            return [r for r in cold_results if r.entry.hash not in existing_hashes][:limit]
        except Exception:
            return []  # non-fatal

    # ── v4.6.0: Incremental Index Loading helpers ─────────────────────────

    def _setup_v46_index(self) -> None:
        """Set up the BM25 index for fast restarts (v4.6 feature).

        Strategy:
        1. Try to load a saved index from ``.antaris_index.json``.
        2. On failure (missing / corrupt), do a full ``build_index()`` (if
           memories exist) and save the result.  An empty-corpus save is
           written when there are no memories so the file always exists
           after init — enabling WAL delta application on the next restart.
        3. Apply any pending WAL entries from ``.antaris_wal.jsonl`` to
           fold in memories ingested since the last save.
        """
        loaded = self.search_engine.load_index(self._index_path)

        if not loaded:
            # Full rebuild from current memories (or empty corpus)
            if self.memories:
                self.search_engine.build_index(self.memories)
            self.search_engine.save_index(self._index_path)
        else:
            # Index loaded OK — apply WAL delta to catch up
            reader = WALReader()
            reader.open(self._index_wal_path)
            wal_dicts = reader.read_all()
            if wal_dicts:
                from .entry import MemoryEntry as _ME
                wal_entries = []
                for d in wal_dicts:
                    try:
                        wal_entries.append(_ME.from_dict(d))
                    except Exception:
                        pass
                if wal_entries:
                    self.search_engine.apply_wal_entries(wal_entries)

    def _flush_v46_index(self) -> None:
        """Rebuild the full index, save it, and clear the index WAL.

        Called automatically when the index WAL reaches 500 entries.
        """
        self.search_engine.build_index(self.memories)
        self.search_engine.save_index(self._index_path)
        # Clear the WAL file
        reader = WALReader()
        reader.open(self._index_wal_path)
        reader.clear()
        # Reopen the writer on the (now empty) file
        self._index_wal_writer.close()
        self._index_wal_writer = WALWriter()
        self._index_wal_writer.open(self._index_wal_path)
        self._index_wal_entry_count = 0

    # ── Sprint 3: embedding interface ────────────────────────────────────

    def set_embedding_fn(self, fn: Callable[[str], List[float]]) -> None:
        """Set a custom embedding function for semantic search.

        When set, search() uses hybrid BM25 + cosine similarity scoring.
        When not set, pure BM25 is used (default, zero-dependency behavior).

        Example::

            import openai
            client = openai.Client()
            def embed(text):
                return client.embeddings.create(
                    input=text, model="text-embedding-3-small"
                ).data[0].embedding
            mem.set_embedding_fn(embed)
        """
        self._embedding_fn = fn
        self._embedding_cache.clear()  # invalidate embedding cache on fn change
        if self._read_cache is not None:
            self._read_cache.invalidate()  # invalidate search result cache

    def _get_embedding(self, text: str) -> Optional[List[float]]:
        """Get embedding with caching. Returns None if no embedding fn set."""
        if self._embedding_fn is None:
            return None
        key = text[:200]  # cache key
        if key not in self._embedding_cache:
            if len(self._embedding_cache) >= 1000:
                # Evict oldest (first inserted key in Python 3.7+ dict)
                del self._embedding_cache[next(iter(self._embedding_cache))]
            try:
                self._embedding_cache[key] = self._embedding_fn(text)
            except Exception:
                return None
        return self._embedding_cache.get(key)

    # ── search with indexing ───────────────────────────────────────────

    def search(
        self,
        query: str,
        limit: int = 20,
        tags: Optional[List[str]] = None,
        tag_mode: str = "any",
        date_range: Optional[Tuple[str, str]] = None,
        use_decay: bool = True,
        category: str = None,
        min_confidence: float = 0.0,
        sentiment_filter: str = None,
        memory_type: Optional[str] = None,    # Sprint 2
        explain: bool = False,
        session_id: str = "*",               # v4.1: session isolation; "*" = all sessions
        agent_id: Optional[str] = None,      # v4.5.4: agent-scoped search
        include_cold: bool = False,          # v4.7.0: include cold-tier shards
    ) -> list:
        """Search memories using BM25-inspired ranking with optional fast indexes.

        Sprint 11: results are served from the LRU read-cache when the query
        signature matches a previously seen search.  On a cache miss the full
        BM25 pipeline runs and the result-set is cached for future calls.
        Access counts are incremented for every returned entry so that hot
        memories receive a relevance boost in future searches.

        Bug fix: BM25 IDF is always computed over the full corpus (self.memories)
        so that type/sentiment filters do not corrupt IDF weights.  Filters are
        applied AFTER scoring.

        Feature: recall_priority from MEMORY_TYPE_CONFIGS is applied to each
        scored entry so that e.g. mistake memories (recall_priority=1.0) float
        to the top.

        Args:
            query: Search query string.
            limit: Maximum results.
            memory_type: Optional filter — only return entries of this type.
            explain: If True, return SearchResult objects with score explanations.
        """
        _t0 = time.monotonic()

        # ── cache key ───────────────────────────────────────────────────
        # v4.1: include session_id in cache key so sessions don't share results
        # v4.5.4: effective_agent_id — use explicitly passed agent_id, else fall
        # back to the MemorySystem's own identity (self.agent_name).  None means
        # no scoping (shared pool visible to all).
        effective_agent_id = agent_id if agent_id is not None else self.agent_name

        cache_key = json.dumps(
            [query, limit, tags, tag_mode, date_range, use_decay,
             category, min_confidence, sentiment_filter, memory_type, explain,
             session_id, effective_agent_id],
            sort_keys=True, default=str,
        )

        if self._read_cache is not None:
            cached = self._read_cache.get(cache_key)
            if cached is not None:
                self._perf.record_search((time.monotonic() - _t0) * 1000)
                return cached

        # ── full search pipeline ─────────────────────────────────────────
        # Bug fix (Bug 2): always build the BM25 index from the FULL corpus
        # so that IDF weights are never corrupted by a filtered subset.
        if self.search_engine._doc_count != len(self.memories):
            self.search_engine.build_index(self.memories)

        decay_fn = self.decay.score if use_decay else None

        # Fetch a generous pool from the full corpus, then filter & trim.
        # Using limit * 10 (min 200) ensures filters don't starve results.
        fetch_limit = max(limit * 10, 200)
        search_results = self.search_engine.search(
            query=query,
            memories=self.memories,
            limit=fetch_limit,
            category=category,
            min_score=min_confidence,
            decay_fn=decay_fn,
            session_id=session_id,
            agent_id=effective_agent_id,   # v4.5.4: pre-filter by agent
        )

        # ── post-scoring filters (Bug 2 fix: applied AFTER BM25 scoring) ──
        if sentiment_filter:
            search_results = [
                r for r in search_results
                if hasattr(r.entry, "sentiment")
                and r.entry.sentiment
                and sentiment_filter in r.entry.sentiment
            ]
        if memory_type is not None:
            search_results = [
                r for r in search_results
                if getattr(r.entry, "memory_type", "episodic") == memory_type
            ]

        # ── Sprint 3: hybrid BM25 + semantic scoring ──────────────────────
        if self._embedding_fn is not None:
            query_vec = self._get_embedding(query)
            if query_vec is not None:
                from .utils import cosine_similarity
                bm25_weight = 0.4
                semantic_weight = 0.6
                hybrid_results = []
                for result in search_results:
                    entry_vec = self._get_embedding(result.entry.content[:500])
                    if entry_vec is not None:
                        sem_score = cosine_similarity(query_vec, entry_vec)
                        hybrid_score = bm25_weight * result.relevance + semantic_weight * sem_score
                        hybrid_results.append(SearchResult(
                            entry=result.entry,
                            score=hybrid_score,
                            relevance=hybrid_score,
                            matched_terms=result.matched_terms,
                            explanation=result.explanation + f" [hybrid: bm25={result.relevance:.3f} sem={sem_score:.3f}]",
                        ))
                    else:
                        hybrid_results.append(result)
                search_results = sorted(hybrid_results, key=lambda r: r.score, reverse=True)

        # ── Feature 1: recall_priority boost ─────────────────────────────
        for r in search_results:
            priority = MEMORY_TYPE_CONFIGS.get(
                getattr(r.entry, "memory_type", "episodic"), {}
            ).get("recall_priority", 1.0)
            r.score *= priority

        # Re-sort after recall_priority adjustment
        search_results.sort(key=lambda r: r.score, reverse=True)
        search_results = search_results[:limit]

        # ── v4.7.0: Warm-tier fallback ────────────────────────────────────
        # If hot-tier search returned fewer than WARM_FALLBACK_THRESHOLD
        # results AND warm shards exist, load them on-demand and merge.
        if (
            self._tiered_storage
            and self._tier_manager is not None
            and self._warm_shard_names
            and len(search_results) < 3
        ):
            warm_extra = self._warm_search_fallback(
                query=query,
                limit=limit,
                category=category,
                min_confidence=min_confidence,
                decay_fn=decay_fn,
                session_id=session_id,
                effective_agent_id=effective_agent_id,
                memory_type=memory_type,
                existing_hashes={r.entry.hash for r in search_results},
            )
            if warm_extra:
                search_results = sorted(
                    search_results + warm_extra,
                    key=lambda r: r.score,
                    reverse=True,
                )[:limit]

        # ── v4.7.0: Cold-tier search (explicit opt-in only) ───────────────
        if include_cold and self._tiered_storage and self._cold_shard_names and self._tier_manager:
            cold_extra = self._cold_search(
                query=query,
                limit=limit,
                decay_fn=decay_fn,
                effective_agent_id=effective_agent_id,
                existing_hashes={r.entry.hash for r in search_results},
            )
            if cold_extra:
                search_results = sorted(
                    search_results + cold_extra,
                    key=lambda r: r.score,
                    reverse=True,
                )[:limit]

        # Reinforce accessed memories & record access counts
        for r in search_results:
            self.decay.reinforce(r.entry)
            self._record_access(r.entry.hash)   # Sprint 11 access tracking

        # Apply access-count boost and re-sort (Sprint 11)
        if search_results:
            boosted = []
            for r in search_results:
                boost = self._access_tracker.boost_score(r.entry.hash)
                boosted.append((r, r.score * boost))
            boosted.sort(key=lambda x: x[1], reverse=True)
            search_results = [r for r, _ in boosted]

        # ── v4.9.0: Graph-based relevance boost ───────────────────────────
        # Apply graph boost only when graph is enabled AND has been built.
        # This re-ranks results using entity relationship signals without
        # changing which entries are returned (no cold/warm tier loading).
        if (self._graph_enabled and self._graph is not None
                and search_results and not include_cold):
            try:
                search_results = self._graph.boost_results(query, search_results)
            except Exception:
                pass  # non-fatal — fall through to original ordering

        # ── v4.9.0: Quality Routing — observe search patterns ─────────────
        if self._quality_routing_enabled and self._quality_router is not None and search_results:
            try:
                self._quality_router.observe_search(
                    query=query,
                    results=search_results,
                    session_id=str(session_id) if session_id else "",
                    agent_id=str(self.agent_name or ""),
                )
            except Exception:
                pass  # non-fatal

        if explain:
            self._perf.record_search((time.monotonic() - _t0) * 1000)
            if self._read_cache is not None:
                self._read_cache.put(cache_key, search_results)
            return search_results

        # Backward compat: return MemoryEntry with search-time confidence
        # Uses copy to avoid mutating the canonical entry in the index
        entries = []
        for r in search_results:
            entry_copy = copy.copy(r.entry)
            entry_copy.confidence = r.relevance
            entries.append(entry_copy)

        elapsed_ms = (time.monotonic() - _t0) * 1000
        self._perf.record_search(elapsed_ms)
        if self._read_cache is not None:
            self._read_cache.put(cache_key, entries)
        return entries
    
    def _search_indexed(self, 
                       query: str,
                       limit: int,
                       tags: Optional[List[str]],
                       tag_mode: str,
                       date_range: Optional[Tuple[str, str]],
                       use_decay: bool) -> List[MemoryEntry]:
        """Fast search using indexes."""
        
        # Get results from indexes
        indexed_results = self.index_manager.search(
            query=query,
            tags=tags,
            tag_mode=tag_mode,
            date_range=date_range,
            limit=limit * 2  # Get more for decay scoring
        )
        
        if not indexed_results:
            return []
        
        # Convert hash results to memory objects
        hash_to_memory = {m.hash: m for m in self.memories}
        results = []
        
        for memory_hash, base_score in indexed_results:
            if memory_hash in hash_to_memory:
                memory = hash_to_memory[memory_hash]
                
                # Apply decay scoring if requested
                if use_decay:
                    decay_score = self.decay.score(memory)
                    final_score = base_score * (0.5 + decay_score)
                    # Reinforce memory (simulate access)
                    self.decay.reinforce(memory)
                else:
                    final_score = base_score
                
                results.append((memory, final_score))
        
        # Sort by final score and return
        results.sort(key=lambda x: x[1], reverse=True)
        return [memory for memory, score in results[:limit]]
    
    def _search_legacy(self, query: str, limit: int, use_decay: bool) -> List[MemoryEntry]:
        """Fallback to legacy search method."""
        import re
        
        query_lower = query.lower()
        results = []
        
        for memory in self.memories:
            content_lower = memory.content.lower()
            
            # Simple text matching
            if query_lower in content_lower:
                if use_decay:
                    decay_score = self.decay.score(memory)
                    self.decay.reinforce(memory)
                    score = decay_score
                else:
                    score = 1.0
                
                results.append((memory, score))
        
        # Sort by score
        results.sort(key=lambda x: x[1], reverse=True)
        return [memory for memory, score in results[:limit]]

    def recent(
        self,
        limit: int = 10,
        agent_id: Optional[str] = None,
        include_shared: bool = True,
    ) -> list:
        """Return the N most recently accessed memories for this agent.

        Unlike search(), this method does NOT use BM25 — it is a pure
        timestamp sort.  Guaranteed to return results as long as any
        memories exist.  Use this for session restore where you want
        "what was I working on?" rather than keyword matching.

        v4.5.4: added for recency-first session restore.

        Args:
            limit: Maximum number of entries to return.
            agent_id: Filter to this agent.  Defaults to self.agent_name.
                      Entries with no agent_id are the shared pool and are
                      always included when include_shared=True.
            include_shared: Include memories with no agent_id (shared pool).

        Returns:
            List of MemoryEntry objects, newest first.
        """
        effective_agent_id = agent_id if agent_id is not None else self.agent_name

        if effective_agent_id:
            filtered = [
                m for m in self.memories
                if getattr(m, "agent_id", None) == effective_agent_id
                or (include_shared and not getattr(m, "agent_id", None))
            ]
        else:
            filtered = list(self.memories)

        # Sort by last_accessed desc, fall back to created_at
        def _sort_key(m):
            ts = getattr(m, "last_accessed", None) or getattr(m, "created_at", None) or ""
            return ts

        filtered.sort(key=_sort_key, reverse=True)
        return filtered[:limit]

    # ── ingestion ───────────────────────────────────────────────────────

    def ingest(
        self,
        content: str,
        source: str = "inline",
        category: str = "general",
        memory_type: str = DEFAULT_TYPE,
        type_config: Optional[Dict] = None,
        tags: Optional[List[str]] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        channel_id: Optional[str] = None,
        source_url: Optional[str] = None,
        content_hash: Optional[str] = None,
    ) -> int:
        """Ingest raw text. Returns count of new memories added.

        Sprint 2: accepts optional *memory_type* and *type_config* to attach
        structured type information to each entry.  Backward-compatible —
        existing callers that don't pass these get episodic defaults.

        Args:
            content: Raw text to ingest (multi-line supported).
            source: Source label (file path, "inline", etc.).
            category: Category label (general, strategic, etc.).
            memory_type: One of the canonical types or a custom string.
                Defaults to "episodic".
            type_config: For custom types, a dict with optional keys
                decay_multiplier, importance_boost, recall_priority.
            tags: Optional explicit tags to merge with auto-extracted tags.
        """
        cfg = get_type_config(memory_type, type_config)
        count = 0
        for i, line in enumerate(content.split("\n")):
            stripped = line.strip()
            if len(stripped) < 15 or stripped.startswith("```") or stripped == "---":
                continue
            # v4.6.6: reject raw JSON metadata lines (conversation_label, sender_id etc.)
            if _METADATA_LINE_RE.match(stripped):
                continue

            entry = MemoryEntry(stripped, source, i + 1, category,
                                memory_type=memory_type,
                                agent_id=agent_id or self.agent_name,
                                session_id=session_id or "")
            # v4.7.0: stamp ingestion provenance
            if source_url is not None:
                entry.source_url = source_url
            if content_hash is not None:
                entry.content_hash = content_hash
            if entry.hash in self._hashes:
                continue

            # Process through gating system
            gate_priority = self.gating.classify(stripped)
            if gate_priority == "P3":  # Skip noise
                continue

            entry.tags = self._extract_tags(stripped)
            # Merge caller-supplied tags with auto-extracted tags (Bug fix #12)
            if tags:
                entry.tags = sorted(set(entry.tags) | set(tags))

            # Layer 2 — CategoryTagger auto-tag + auto-categorise on ingest
            cat_tags = _ct.tag(stripped)
            for ct_tag in cat_tags:
                if ct_tag not in entry.tags:
                    entry.tags.append(ct_tag)
            # Only overwrite category if caller left it at default "general"
            if entry.category == "general" and cat_tags:
                entry.category = _ct.primary_category(stripped)

            entry.sentiment = self.sentiment.analyze(stripped)

            # v4.6.5 — LLM enrichment (non-fatal, optional)
            if self._enricher is not None:
                try:
                    enrichment = self._enricher(stripped)
                    if enrichment and isinstance(enrichment, dict):
                        if enrichment.get("tags"):
                            entry.tags = sorted(
                                set(entry.tags) | {t.lower() for t in enrichment["tags"]}
                            )
                        if enrichment.get("summary"):
                            entry.enriched_summary = str(enrichment["summary"])
                        if enrichment.get("keywords"):
                            entry.search_keywords = [
                                str(k).lower() for k in enrichment["keywords"]
                            ]
                        # Feed enrichment relationships into co-occurrence index
                        self._feed_cooccurrence_from_enrichment(stripped, enrichment)
                        self._enrichment_count += 1
                except Exception:
                    pass  # Enrichment is non-fatal — fall back to raw text

            # Apply type importance boost
            boost = cfg.get("importance_boost", 1.0)
            if boost != 1.0:
                entry.importance = min(entry.importance * boost, self.decay.max_score)

            # Store type_config for custom types
            if type_config:
                entry.type_metadata["_type_config"] = type_config

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            self.search_engine.mark_dirty()

            if self.use_indexing and self.index_manager:
                self.index_manager.add_memory(entry)

            # Sprint 11 — WAL append
            self._wal.append(entry.to_dict())

            # v4.9.0 — Index into memory graph (non-fatal)
            if self._graph_enabled and self._graph is not None:
                try:
                    self._graph.index_entry(entry.hash, entry.content)
                except Exception:
                    pass

            # v4.6.0 — Write to time-window shard (when enterprise sharding off)
            if not self.use_sharding and self._v46_sharding and self._v46_shards:
                self._v46_shards.write_entry(entry)

            # v4.6.0 — Append to index WAL for incremental index tracking
            try:
                self._index_wal_writer.append(entry.to_dict())
                self._index_wal_entry_count += 1
            except Exception:
                pass  # non-fatal: index will be rebuilt on next startup

            # v3.2 — Update local co-occurrence index (Tier 1 semantic)
            self._update_cooccurrence(stripped)

            count += 1

        # Invalidate read-cache on write
        if count and self._read_cache is not None:
            self._read_cache.invalidate()

        # Auto-flush if WAL threshold is reached
        if self._wal.should_flush():
            self.flush()

        # v4.6.0 — Flush index WAL when it reaches 500 entries
        if self._index_wal_entry_count >= 500:
            self._flush_v46_index()

        return count

    def ingest_file(self, file_path: str, category: str = "tactical") -> int:
        """Ingest a single file."""
        if not os.path.exists(file_path):
            return 0
        
        try:
            with open(file_path, encoding="utf-8") as f:
                content = f.read()
            return self.ingest(content, source=file_path, category=category)
        except (OSError, UnicodeDecodeError):
            return 0

    def ingest_directory(self, dir_path: str, category: str = "tactical",
                        pattern: str = "*.md") -> int:
        """Ingest all matching files in a directory."""
        if not os.path.exists(dir_path):
            return 0
        
        total = 0
        for path in Path(dir_path).glob(pattern):
            if path.is_file():
                total += self.ingest_file(str(path), category)
        return total

    # ── Sprint 2: typed ingest methods ──────────────────────────────────

    def ingest_mistake(
        self,
        what_happened: str,
        correction: str,
        root_cause: Optional[str] = None,
        severity: str = "medium",
        tags: Optional[List[str]] = None,
        source: str = "mistake",
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Optional[MemoryEntry]:
        """Ingest a structured mistake memory.

        Mistakes receive 2× importance, 10× half-life, and are surfaced
        proactively in context packets via the "Known Pitfalls" section.

        Args:
            what_happened: Brief description of what went wrong.
            correction: What should be done instead.
            root_cause: Why it happened (optional but strongly recommended).
            severity: "high", "medium", or "low" (default "medium").
            tags: Extra tags to attach.
            source: Source label (default "mistake").

        Returns:
            The created MemoryEntry, or None if duplicate.
        """
        if severity not in SEVERITY_LEVELS:
            severity = "medium"

        content = format_mistake_content(what_happened, correction, root_cause, severity)
        cfg = MEMORY_TYPE_CONFIGS["mistake"]

        entry = MemoryEntry(content, source, 0, "mistake", memory_type="mistake",
                            agent_id=agent_id or self.agent_name,
                            session_id=session_id or "")
        if entry.hash in self._hashes:
            return None

        entry.importance = min(1.0 * cfg["importance_boost"], self.decay.max_score)
        entry.tags = list(set(["mistake", f"severity:{severity}"] + (tags or [])))
        entry.sentiment = self.sentiment.analyze(content)
        entry.type_metadata = {
            "what_happened": what_happened,
            "correction": correction,
            "root_cause": root_cause,
            "severity": severity,
        }

        self.memories.append(entry)
        self._hashes.add(entry.hash)
        self.search_engine.mark_dirty()

        if self.use_indexing and self.index_manager:
            self.index_manager.add_memory(entry)

        # Sprint 11 — WAL
        self._wal.append(entry.to_dict())
        if self._read_cache is not None:
            self._read_cache.invalidate()
        if self._wal.should_flush():
            self.flush()

        return entry

    def ingest_fact(
        self,
        content: str,
        source: str = "fact",
        tags: Optional[List[str]] = None,
        category: str = "general",
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> int:
        """Ingest a fact-type memory (normal decay, high recall priority)."""
        return self._ingest_typed(
            content, source, category, "fact", tags=tags,
            agent_id=agent_id, session_id=session_id,
        )

    def ingest_preference(
        self,
        content: str,
        source: str = "preference",
        tags: Optional[List[str]] = None,
        category: str = "general",
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> int:
        """Ingest a preference-type memory (3x slower decay, high context-matched recall)."""
        return self._ingest_typed(
            content, source, category, "preference", tags=tags,
            agent_id=agent_id, session_id=session_id,
        )

    def ingest_procedure(
        self,
        content: str,
        source: str = "procedure",
        tags: Optional[List[str]] = None,
        category: str = "general",
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> int:
        """Ingest a procedure-type memory (3x slower decay, high task-matched recall)."""
        return self._ingest_typed(
            content, source, category, "procedure", tags=tags,
            agent_id=agent_id, session_id=session_id,
        )

    def _ingest_typed(
        self,
        content: str,
        source: str,
        category: str,
        memory_type: str,
        tags: Optional[List[str]] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> int:
        """Helper: ingest one or more lines with a specific memory type.

        Feature 2 fix: applies the same P0-P3 input gating that ``ingest()``
        uses so that P3 (ephemeral) content is never silently stored via the
        typed-ingest helpers.
        """
        cfg = get_type_config(memory_type)
        count = 0
        for i, line in enumerate(content.split("\n")):
            stripped = line.strip()
            if len(stripped) < 15 or stripped.startswith("```") or stripped == "---":
                continue
            # v4.6.6: reject raw JSON metadata lines
            if _METADATA_LINE_RE.match(stripped):
                continue

            # Feature 2: apply gating — drop P3 noise
            if not self.gating.should_store(stripped):
                continue

            entry = MemoryEntry(stripped, source, i + 1, category,
                                memory_type=memory_type,
                                agent_id=agent_id or self.agent_name,
                                session_id=session_id or "")
            if entry.hash in self._hashes:
                continue

            entry.importance = min(1.0 * cfg.get("importance_boost", 1.0),
                                   self.decay.max_score)
            entry.tags = list(set([memory_type] + self._extract_tags(stripped) + (tags or [])))

            # Layer 2 — CategoryTagger auto-tag + auto-categorise on ingest
            cat_tags = _ct.tag(stripped)
            for ct_tag in cat_tags:
                if ct_tag not in entry.tags:
                    entry.tags.append(ct_tag)
            if entry.category == "general" and cat_tags:
                entry.category = _ct.primary_category(stripped)

            entry.sentiment = self.sentiment.analyze(stripped)

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            self.search_engine.mark_dirty()

            if self.use_indexing and self.index_manager:
                self.index_manager.add_memory(entry)

            # Sprint 11 — WAL
            self._wal.append(entry.to_dict())
            count += 1

        if count:
            if self._read_cache is not None:
                self._read_cache.invalidate()
            if self._wal.should_flush():
                self.flush()

        return count

    # ── analysis & synthesis ────────────────────────────────────────────

    def analyze(self, query: str, limit: int = 10) -> Dict:
        """Analyze memories related to a query."""
        memories = self.search(query, limit=limit)
        if not memories:
            return {"status": "no_results", "query": query}
        
        # Basic analysis (can be enhanced)
        categories = defaultdict(int)
        sentiment_scores = []
        date_range = []
        
        for memory in memories:
            if memory.category:
                categories[memory.category] += 1
            if memory.sentiment and 'compound' in memory.sentiment:
                sentiment_scores.append(memory.sentiment['compound'])
            date_range.append(memory.created[:10])
        
        return {
            "status": "success",
            "query": query,
            "total_memories": len(memories),
            "categories": dict(categories),
            "avg_sentiment": sum(sentiment_scores) / len(sentiment_scores) if sentiment_scores else 0,
            "date_range": [min(date_range), max(date_range)] if date_range else [],
            "sample_memories": [m.content[:100] for m in memories[:3]]
        }

    def synthesize_knowledge(self, topic: str, limit: int = 20) -> Optional[str]:
        """Generate knowledge synthesis using the KnowledgeSynthesizer."""
        memories = self.search(topic, limit=limit)
        if not memories:
            return None
        
        memory_texts = [m.content for m in memories]
        return self.synthesis.synthesize(memory_texts, topic)

    # ── context packets ──────────────────────────────────────────────────

    def build_context_packet(
        self,
        task: str,
        tags: Optional[List[str]] = None,
        category: str = None,
        environment: Optional[Dict[str, str]] = None,
        instructions: Optional[List[str]] = None,
        max_memories: int = 15,
        max_tokens: int = 4000,
        min_relevance: float = 0.1,
        include_mistakes: bool = True,     # Sprint 2
        max_pitfalls: int = 5,             # Sprint 2
    ) -> "ContextPacket":
        """Build a context packet for sub-agent spawning.

        Searches the memory store for relevant context and packages it
        into a structured ContextPacket that can be injected into a
        sub-agent's prompt at spawn time.

        Solves the "cold spawn" problem: sub-agents start with zero
        context, leading to confident mistakes based on incomplete
        information. A context packet gives them relevant onboarding.

        Args:
            task: Description of the sub-agent's task (used as search query).
            tags: Optional tag filters to narrow search.
            category: Optional category filter.
            environment: Key-value pairs (e.g. {"venv": "venv-svi", "python": "3.11"}).
            instructions: Explicit constraints for the sub-agent.
            max_memories: Maximum memories to include (default 15).
            max_tokens: Token budget for rendered output (default 4000).
            min_relevance: Minimum relevance score (default 0.1).

        Returns:
            ContextPacket with .render(), .to_dict(), .trim() methods.

        Example::

            packet = mem.build_context_packet(
                task="Verify antaris-guard installation",
                environment={"venv": "venv-svi"},
                instructions=["Check the venv, not global pip"],
            )
            prompt = f"{packet.render()}\\n\\nYOUR TASK: verify installation"
        """
        builder = ContextPacketBuilder(self)
        return builder.build(
            task=task,
            tags=tags,
            category=category,
            environment=environment,
            instructions=instructions,
            max_memories=max_memories,
            max_tokens=max_tokens,
            min_relevance=min_relevance,
            include_mistakes=include_mistakes,
            max_pitfalls=max_pitfalls,
        )

    def build_context_packet_multi(
        self,
        task: str,
        queries: List[str],
        environment: Optional[Dict[str, str]] = None,
        instructions: Optional[List[str]] = None,
        max_memories: int = 15,
        max_tokens: int = 4000,
        min_relevance: float = 0.1,
    ) -> "ContextPacket":
        """Build a context packet from multiple search queries.

        Useful when a task spans multiple topics. Deduplicates results
        across queries and merges into a single packet.

        Args:
            task: Overall task description.
            queries: List of search queries to run.
            environment: Optional environment context.
            instructions: Optional constraints.
            max_memories: Max total memories.
            max_tokens: Token budget.
            min_relevance: Minimum relevance threshold.

        Returns:
            Merged ContextPacket with deduplicated results.
        """
        builder = ContextPacketBuilder(self)
        return builder.build_multi(
            task=task,
            queries=queries,
            environment=environment,
            instructions=instructions,
            max_memories=max_memories,
            max_tokens=max_tokens,
            min_relevance=min_relevance,
        )

    # ── utility methods ─────────────────────────────────────────────────

    # ── Sprint 11: access pattern learning ──────────────────────────────

    def _record_access(self, entry_id: str) -> None:
        """Increment the access count for a memory entry.

        Called automatically by ``search()`` for every returned result.
        Persisted to ``access_counts.json`` on the next ``flush()``.
        """
        self._access_tracker.record_access(entry_id)

    def get_hot_entries(self, top_n: int = 10) -> List[MemoryEntry]:
        """Return the *top_n* most frequently accessed memory entries.

        Useful for pre-loading important context into packets.

        Args:
            top_n: Number of hot entries to return.

        Returns:
            List of MemoryEntry objects, ordered by access count descending.
        """
        top_ids = self._access_tracker.get_top(top_n)
        hash_to_entry = {m.hash: m for m in self.memories}
        result = []
        for entry_id, _count in top_ids:
            if entry_id in hash_to_entry:
                result.append(hash_to_entry[entry_id])
        return result

    def _extract_tags(self, content: str) -> List[str]:
        """Extract tags from content."""
        tags = []
        content_lower = content.lower()
        
        # Extract explicit tags (@tag format)
        explicit_tags = re.findall(r'@([a-zA-Z][a-zA-Z0-9_-]*)', content)
        tags.extend(explicit_tags)
        
        # Auto-tag based on terms
        for term in self._tag_terms:
            if term.lower() in content_lower:
                tags.append(term)
        
        return list(set(tags))  # Remove duplicates

    def compact(self) -> Dict:
        """Compact memory storage: remove duplicates, expire stale entries, save.

        Sprint 11: returns a richer result dict with shard counts and timing.

        Returns::

            {
                "shards_before": int,
                "shards_after": int,
                "entries_before": int,
                "entries_after": int,
                "space_freed_mb": float,
                "duration_ms": float,
                # backward-compat keys still present:
                "original_count": int,
                "final_count": int,
                "removed_count": int,
            }
        """
        _t0 = time.monotonic()

        # Snapshot shard count and disk usage before compaction
        shards_before = 0
        disk_before = 0.0
        if self.use_sharding and self.shard_manager:
            shards_dir = os.path.join(self.workspace, "shards")
            if os.path.isdir(shards_dir):
                shards_before = len([
                    f for f in os.listdir(shards_dir) if f.endswith(".json")
                ])
                disk_before = sum(
                    os.path.getsize(os.path.join(shards_dir, f))
                    for f in os.listdir(shards_dir) if f.endswith(".json")
                ) / (1024 * 1024)

        entries_before = len(self.memories)

        # Remove exact duplicates (by hash)
        seen_hashes: set = set()
        unique_memories = []
        for memory in self.memories:
            if memory.hash not in seen_hashes:
                unique_memories.append(memory)
                seen_hashes.add(memory.hash)

        # Apply decay-based forgetting: drop entries whose decay score is 0
        # (effectively dead entries that will never be recalled)
        retained_memories = [
            m for m in unique_memories
            if self.decay.score(m) > 0.0
        ]

        # Use consolidation to detect near-duplicate pairs; keep the
        # higher-confidence entry from each pair.
        dup_pairs = self.consolidation.find_duplicates(retained_memories)
        hashes_to_drop: set = set()
        for mem_a, mem_b in dup_pairs:
            # Drop whichever has lower confidence (or the second if tied)
            loser = mem_b if mem_a.confidence >= mem_b.confidence else mem_a
            hashes_to_drop.add(loser.hash)
        consolidated_memories = [
            m for m in retained_memories if m.hash not in hashes_to_drop
        ]

        self.memories = consolidated_memories
        self._hashes = {m.hash for m in self.memories}
        self.search_engine.mark_dirty()

        # Invalidate cache — data has changed
        if self._read_cache is not None:
            self._read_cache.invalidate()

        # Rebuild indexes after compaction
        if self.use_indexing and self.index_manager:
            self.index_manager.rebuild_indexes(self.memories)

        # Flush to disk so shards reflect compacted state
        self.save()
        self._wal.clear()   # WAL is also stale now
        self._perf.record_compaction()

        # Snapshot shard count and disk usage after compaction
        shards_after = 0
        disk_after = 0.0
        if self.use_sharding and self.shard_manager:
            shards_dir = os.path.join(self.workspace, "shards")
            if os.path.isdir(shards_dir):
                shards_after = len([
                    f for f in os.listdir(shards_dir) if f.endswith(".json")
                ])
                disk_after = sum(
                    os.path.getsize(os.path.join(shards_dir, f))
                    for f in os.listdir(shards_dir) if f.endswith(".json")
                ) / (1024 * 1024)

        entries_after = len(self.memories)
        duration_ms = round((time.monotonic() - _t0) * 1000, 1)

        return {
            # Sprint 11 spec keys
            "shards_before": shards_before,
            "shards_after": shards_after,
            "entries_before": entries_before,
            "entries_after": entries_after,
            "space_freed_mb": round(max(disk_before - disk_after, 0.0), 3),
            "duration_ms": duration_ms,
            # Backward-compatible keys
            "original_count": entries_before,
            "final_count": entries_after,
            "removed_count": entries_before - entries_after,
        }

    # ── system management ───────────────────────────────────────────────

    def get_stats(self) -> Dict:
        """Get comprehensive system statistics."""
        from . import __version__ as _pkg_version  # Bug fix: add package version to stats
        stats = {
            "schema_version": "0.4.0",    # storage format version (used by migration logic)
            "package_version": _pkg_version,  # antaris-memory package version
            "total_memories": len(self.memories),
            "workspace": self.workspace,
            "features": {
                "sharding": self.use_sharding,
                "indexing": self.use_indexing
            }
        }
        
        if self.use_sharding and self.shard_manager:
            stats["sharding"] = self.shard_manager.index.get_stats()
        
        if self.use_indexing and self.index_manager:
            stats["indexing"] = self.index_manager.get_combined_stats()
        
        # Memory distribution by category
        categories = defaultdict(int)
        for memory in self.memories:
            categories[memory.category or "uncategorized"] += 1
        stats["categories"] = dict(categories)
        
        return stats

    def migrate_to_v4(self) -> Dict:
        """Manually trigger migration to v0.4 format."""
        return self.migration_manager.migrate("0.4.0")
    
    def rollback_migration(self) -> Dict:
        """Rollback the most recent migration."""
        return self.migration_manager.rollback()
    
    def validate_data(self) -> Dict:
        """Validate the current data schema."""
        return self.migration_manager.validate_schema()
    
    def rebuild_indexes(self):
        """Rebuild all search indexes from current memories."""
        if self.use_indexing and self.index_manager:
            self.index_manager.rebuild_indexes(self.memories)
            self.index_manager.save_all_indexes()
    
    def get_migration_history(self) -> List[Dict]:
        """Get history of applied migrations."""
        return self.migration_manager.get_migration_history()

    # ── Backward-compatible methods from v0.3 ──────────────────────

    def stats(self) -> Dict:
        """System statistics including Sprint 11 performance metrics.

        Backward-compatible — all v0.3/v0.4 keys are preserved.  New Sprint 11
        keys are added under their own names.

        Returns::

            {
                # v0.3 compat keys
                "total": int,
                "avg_score": float,
                "archive_candidates": int,
                "sentiments": dict,
                "avg_confidence": float,
                "categories": dict,
                # Sprint 11 performance keys
                "total_entries": int,
                "total_shards": int,
                "search_count": int,
                "avg_search_time_ms": float,
                "cache_hit_rate": float,
                "wal_pending_entries": int,
                "last_compaction": str | None,
                "disk_usage_mb": float,
                "memory_usage_mb": float,
            }
        """
        s = self.get_stats()
        now = datetime.now(timezone.utc)
        scores = [self.decay.score(m, now) for m in self.memories]
        sentiments: Dict[str, int] = defaultdict(int)
        for m in self.memories:
            dom = self.sentiment.dominant(m.sentiment)
            if dom:
                sentiments[dom] += 1
        # v0.3 compat
        s["total"] = len(self.memories)
        s["avg_score"] = round(sum(scores) / max(len(scores), 1), 4)
        s["archive_candidates"] = sum(1 for sc in scores if sc < self.decay.archive_threshold)
        s["sentiments"] = dict(sentiments)
        s["avg_confidence"] = round(
            sum(m.confidence for m in self.memories) / max(len(self.memories), 1), 4
        )

        # Sprint 11 performance metrics
        shards_count = 0
        disk_mb = 0.0
        if self.use_sharding and self.shard_manager:
            shards_dir = os.path.join(self.workspace, "shards")
            if os.path.isdir(shards_dir):
                shard_files = [
                    os.path.join(shards_dir, f)
                    for f in os.listdir(shards_dir) if f.endswith(".json")
                ]
                shards_count = len(shard_files)
                disk_mb = sum(os.path.getsize(p) for p in shard_files) / (1024 * 1024)

        import sys
        mem_mb = sys.getsizeof(self.memories) / (1024 * 1024)

        s["total_entries"] = len(self.memories)
        s["total_shards"] = shards_count
        s["search_count"] = self._perf.search_count
        s["avg_search_time_ms"] = self._perf.avg_search_time_ms
        s["cache_hit_rate"] = (
            round(self._read_cache.hit_rate, 4) if self._read_cache is not None else 0.0
        )
        s["wal_pending_entries"] = self._wal.pending_count()
        s["last_compaction"] = self._perf.last_compaction
        s["disk_usage_mb"] = round(disk_mb, 3)
        s["memory_usage_mb"] = round(mem_mb, 3)
        s["enrichment_count"] = self._enrichment_count

        # v4.9.0 additions
        try:
            import antaris_memory as _am
            s["version"] = getattr(_am, "__version__", "unknown")
        except Exception:
            s["version"] = "unknown"
        s["hot_entries"] = len(self.memories)
        s["warm_entries"] = len(getattr(self, '_warm_shard_names', []))
        s["cold_entries"] = len(getattr(self, '_cold_shard_names', []))
        s["wal_size"] = s["wal_pending_entries"]
        s["workspace"] = self.workspace
        s["agent_name"] = self.agent_name
        try:
            s["cooccurrence_pairs"] = len(self._cooccurrence._index) if hasattr(
                self._cooccurrence, '_index') else 0
        except Exception:
            s["cooccurrence_pairs"] = 0
        try:
            s["cache_size"] = len(self._read_cache._cache) if (
                self._read_cache and hasattr(self._read_cache, '_cache')) else 0
        except Exception:
            s["cache_size"] = 0
        try:
            import json as _json
            cost_path = os.path.join(self.workspace, "memory", "enrichment_costs.json")
            if os.path.exists(cost_path):
                with open(cost_path) as _f:
                    _cost = _json.load(_f)
                s["enrichment_cost_usd"] = round(_cost.get("lifetime_usd", 0.0), 6)
            else:
                s["enrichment_cost_usd"] = round(self._enrichment_count * 0.00005, 6)
        except Exception:
            s["enrichment_cost_usd"] = 0.0
        try:
            _gstats = self.get_graph_stats()
            s["graph_enabled"] = _gstats.get("graph_enabled", False)
            s["graph_nodes"] = _gstats.get("node_count", 0)
            s["graph_edges"] = _gstats.get("edge_count", 0)
        except Exception:
            s["graph_enabled"] = False
            s["graph_nodes"] = 0
            s["graph_edges"] = 0

        return s

    def get_enrichment_count(self, reset: bool = False) -> int:
        """Return the number of enrichments performed since last reset.

        v4.6.5 — Used by the plugin to track cumulative enrichment costs.

        Args:
            reset: If True, resets the counter to 0 after reading.

        Returns:
            Count of enrichments since last reset (or since startup).
        """
        count = self._enrichment_count
        if reset:
            self._enrichment_count = 0
        return count

    def ingest_with_gating(self, content: str, source: str = "inline",
                           context: Dict = None) -> int:
        """Ingest with P0-P3 input classification. P3 content is dropped.
        
        Multi-line content is split and each line classified independently.
        """
        count = 0
        for i, line in enumerate(content.split("\n")):
            stripped = line.strip()
            # Bug fix: align minimum length with ingest() (was 5, now 15)
            if len(stripped) < 15:
                continue
            gate_context = context or {}
            gate_context.update({"source": source, "line": i + 1})
            routing = self.gating.route(stripped, gate_context)
            if not routing["store"]:
                continue
            category = routing.get("category", "tactical")
            count += self.ingest(stripped, source=source, category=category)
        return count

    def on_date(self, date: str) -> List[MemoryEntry]:
        """Get memories from a specific date."""
        return self.temporal.on_date(self.memories, date)

    def between(self, start: str, end: str) -> List[MemoryEntry]:
        """Get memories between two dates."""
        return self.temporal.between(self.memories, start, end)

    def narrative(self, topic: str = None) -> str:
        """Build a narrative from memories, optionally filtered by topic."""
        return self.temporal.narrative(self.memories, topic=topic)

    def forget(self, topic: str = None, entity: str = None,
               before_date: str = None) -> Dict:
        """Selectively forget memories with audit trail.

        Bug fix (Bug 1): ForgettingEngine has no ``forget()`` method; instead
        it exposes ``forget_topic()``, ``forget_entity()``, and
        ``forget_before()``.  This method now delegates correctly and supports
        combining multiple criteria (applied in sequence).

        Args:
            topic: Remove all memories containing this topic string.
            entity: Remove all memories mentioning this entity.
            before_date: Remove all memories created before this date (YYYY-MM-DD).

        Returns:
            Dict with keys ``removed`` (list[MemoryEntry]) and ``audit`` (dict).
        """
        if topic is None and entity is None and before_date is None:
            return {"removed": [], "audit": self.forgetting.audit_log([])}

        current = list(self.memories)
        all_forgotten: List = []

        if topic is not None:
            current, forgotten = self.forgetting.forget_topic(current, topic)
            all_forgotten.extend(forgotten)

        if entity is not None:
            current, forgotten = self.forgetting.forget_entity(current, entity)
            all_forgotten.extend(forgotten)

        if before_date is not None:
            current, forgotten = self.forgetting.forget_before(current, before_date)
            all_forgotten.extend(forgotten)

        # Deduplicate (a memory might match multiple criteria)
        seen: set = set()
        unique_forgotten = []
        for m in all_forgotten:
            if m.hash not in seen:
                unique_forgotten.append(m)
                seen.add(m.hash)

        result = {
            "removed": unique_forgotten,
            "audit": self.forgetting.audit_log(unique_forgotten),
        }

        if unique_forgotten:
            removed_set = {m.hash for m in unique_forgotten}
            # Bug fix: `current` is already the post-forget filtered list from
            # forget_topic/forget_entity/forget_before — no need to re-filter.
            self.memories = current
            self._hashes -= removed_set
            self.search_engine.mark_dirty()
            if self._read_cache is not None:
                self._read_cache.invalidate()
            # Log to audit
            for m in unique_forgotten:
                self._append_audit({"action": "forget", "hash": m.hash,
                                    "content_preview": m.content[:50],
                                    "timestamp": datetime.now(timezone.utc).isoformat()})

        return result

    def reindex(self) -> None:
        """Force a full search index rebuild."""
        self.search_engine.reindex(self.memories)

    def consolidate(self) -> Dict:
        """Run consolidation: dedup, clustering, contradiction detection."""
        return self.consolidation.run(self.memories)

    def compress_old(self, days: int = 7) -> list:
        """Compress memories older than N days."""
        mem_dir = os.path.join(self.workspace, "memory")
        return self.compression.compress_old_files(mem_dir, days)

    def synthesize(self, research_results: Dict = None) -> Dict:
        """Integrate research findings into memory."""
        report = self.synthesis.run_cycle(self.memories, research_results=research_results)
        # Add synthesized entries to memory store
        if report.get("synthesized_entries", 0) > 0 and "new_entries" in report:
            for entry_dict in report["new_entries"]:
                entry = MemoryEntry.from_dict(entry_dict)
                if "synthesis" not in entry.tags:
                    entry.tags.append("synthesis")
                self.memories.append(entry)
                if self.use_indexing and self.index_manager:
                    self.index_manager.add_memory(entry)
        return report

    def research_suggestions(self, limit: int = 5) -> List[Dict]:
        """Get suggestions for knowledge gaps."""
        return self.synthesis.suggest_research_topics(self.memories, limit=limit)

    # ── Feature 3: Export / Import API ─────────────────────────────────

    def export(self, output_path: str, include_metadata: bool = True) -> int:
        """Export all memories to a JSON file.

        Args:
            output_path: Destination file path.
            include_metadata: When True (default), includes full metadata
                (workspace path, export timestamp, version tag).  When False,
                only the ``entries`` list is included (useful for data portability).

        Returns:
            Count of exported entries.

        Format::

            {
                "version": "4.2",
                "exported_at": "<ISO 8601>",
                "workspace": "<path>",
                "entries": [
                    {
                        "content": str,
                        "source": str,
                        "category": str,
                        "memory_type": str,
                        "timestamp": str,
                        "score": float
                    },
                    ...
                ]
            }
        """
        now = datetime.now(timezone.utc)
        entries = []
        for m in self.memories:
            entry_dict = {
                "content": m.content,
                "source": getattr(m, "source", ""),
                "category": m.category or "general",
                "memory_type": getattr(m, "memory_type", "episodic"),
                "timestamp": m.created,
                "score": self.decay.score(m, now),
            }
            entries.append(entry_dict)

        # Always augment entries with hash so import_from() can deduplicate correctly
        for m, e in zip(self.memories, entries):
            e["_hash"] = m.hash

        if include_metadata:
            data: dict = {
                "version": "4.2",
                "exported_at": now.isoformat(),
                "workspace": self.workspace,
                "entries": entries,
            }
        else:
            data = {"entries": entries}

        atomic_write_json(output_path, data)
        return len(entries)

    def import_from(self, input_path: str, merge: bool = True) -> int:
        """Import memories from a JSON file exported by :meth:`export`.

        Args:
            input_path: Path to the JSON file produced by ``export()``.
            merge: When ``True`` (default) imported entries are *added* to the
                existing store — duplicates (same content hash) are skipped.
                When ``False`` the existing store is **replaced** with the
                imported entries.

        Returns:
            Count of imported entries (after deduplication when merge=True).
        """
        with open(input_path, encoding="utf-8") as fh:
            raw = json.load(fh)

        # Support both the versioned envelope {"entries": [...]} and a raw list
        if isinstance(raw, dict):
            entries_data = raw.get("entries", [])
        elif isinstance(raw, list):
            entries_data = raw
        else:
            return 0

        if not merge:
            # Replace mode: wipe existing store first
            self.memories = []
            self._hashes = set()
            self.search_engine.mark_dirty()
            if self._read_cache is not None:
                self._read_cache.invalidate()

        count = 0
        for entry_dict in entries_data:
            if not isinstance(entry_dict, dict):
                continue
            try:
                # Build a MemoryEntry from the compact export format
                content = entry_dict.get("content", "")
                source = entry_dict.get("source", "import")
                category = entry_dict.get("category", "general")
                memory_type = entry_dict.get("memory_type", "episodic")

                entry = MemoryEntry(content, source, 0, category,
                                    memory_type=memory_type)

                # Restore original hash if present (exported by export()).
                # This ensures deduplication by content hash works correctly
                # even when the source/line combo differs on reimport.
                if "_hash" in entry_dict:
                    entry.hash = entry_dict["_hash"]

                # Restore timestamp if present
                if "timestamp" in entry_dict:
                    entry.created = entry_dict["timestamp"]
                    entry.last_accessed = entry_dict["timestamp"]
            except Exception:
                continue  # skip malformed entries

            if entry.hash in self._hashes:
                continue  # deduplicate

            self.memories.append(entry)
            self._hashes.add(entry.hash)
            count += 1

        if count:
            self.search_engine.mark_dirty()
            if self._read_cache is not None:
                self._read_cache.invalidate()

        return count

    def import_memories(self, path: str) -> int:
        """Backward-compat alias for :meth:`import_from` with merge=True.

        Args:
            path: Path to the JSON array file produced by ``export()``.

        Returns:
            Number of new entries added.
        """
        return self.import_from(path, merge=True)

    # ── shared pool integration ──────────────────────────────────────────

    def enable_shared_pool(
        self,
        pool_dir: str,
        pool_name: str = "default",
        agent_id: str = None,
        role: str = "write",
        load_existing: bool = True,
    ) -> "SharedMemoryPool":
        """Attach a SharedMemoryPool to this MemorySystem instance.

        Enables multi-agent memory sharing. The pool is created (or loaded)
        at pool_dir. This agent is registered with the given role.

        Args:
            pool_dir: Directory for the shared pool files.
            pool_name: Pool identifier (default "default").
            agent_id: This agent's ID in the pool. Defaults to the workspace basename.
            role: Access role — "read", "write", or "admin" (default "write").
            load_existing: If True, load an existing pool from disk (default True).

        Returns:
            The attached SharedMemoryPool instance.
        """
        if agent_id is None:
            agent_id = os.path.basename(self.workspace.rstrip("/"))

        pool = SharedMemoryPool(pool_dir, pool_name)
        if load_existing:
            pool.load()

        # Register if not already registered
        if agent_id not in pool.permissions:
            pool.register_agent(agent_id, role)

        self._shared_pool = pool
        self._shared_agent_id = agent_id
        return pool

    def get_shared_pool(self) -> Optional["SharedMemoryPool"]:
        """Return the attached SharedMemoryPool, or None if not enabled."""
        return self._shared_pool

    def shared_write(
        self,
        content: str,
        namespace: str = "shared",
        category: str = "general",
        metadata: dict = None,
    ) -> Optional[object]:
        """Write a memory to the attached shared pool.

        Raises RuntimeError if no shared pool is attached (call enable_shared_pool first).
        """
        if self._shared_pool is None:
            raise RuntimeError("No shared pool attached. Call enable_shared_pool() first.")
        return self._shared_pool.write(
            self._shared_agent_id, content, namespace, category, metadata
        )

    def shared_search(
        self,
        query: str,
        namespace: str = None,
        limit: int = 20,
        instrumentation_context=None,
    ) -> list:
        """Search the attached shared pool.

        If instrumentation_context is provided (a SearchContext), populates
        retrieved_memory_ids for later mark_used() calls.

        Raises RuntimeError if no shared pool is attached.
        """
        if self._shared_pool is None:
            raise RuntimeError("No shared pool attached. Call enable_shared_pool() first.")

        if hasattr(self._shared_pool, 'search_with_context') and instrumentation_context is not None:
            results, _ = self._shared_pool.search_with_context(
                self._shared_agent_id, query, instrumentation_context, limit, namespace
            )
        else:
            results = self._shared_pool.read(
                self._shared_agent_id, query, namespace, limit
            )
        return results

    def shared_mark_used(
        self,
        memory_ids: list,
        boost_factor: float = 1.3,
    ) -> int:
        """Signal that retrieved shared memories were used in a response.

        Triggers cross-agent relevance boosting for memories written by other agents.

        Returns:
            Number of memories boosted.
        """
        if self._shared_pool is None:
            raise RuntimeError("No shared pool attached.")
        return self._shared_pool.mark_used_batch(
            self._shared_agent_id, memory_ids, boost_factor
        )

    def _append_audit(self, entry: Dict) -> None:
        """Append an entry to the audit log."""
        audit = []
        if os.path.exists(self.audit_path):
            with open(self.audit_path) as f:
                audit = json.load(f)
        audit.append(entry)
        atomic_write_json(self.audit_path, audit)

    # ── v3.2 Instrumentation ──────────────────────────────────────────────────

    def mark_retrieved(self, memory_ids: List[str], context) -> None:
        """Record that a set of memories were retrieved for a query.

        Called automatically when instrumentation_context is passed to search().
        Logs the retrieval event to the instrumentation log for later analysis.

        Args:
            memory_ids: List of memory hashes that were retrieved.
            context: SearchContext object for this search request.
        """
        context.retrieved_memory_ids = list(memory_ids)
        event = {
            "event": "retrieved",
            "request_id": context.request_id,
            "query": context.query,
            "memory_ids": memory_ids,
            "count": len(memory_ids),
            "timestamp": context.timestamp,
            "context_id": context.context_id,
        }
        try:
            with open(self._instrumentation_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")
        except OSError:
            pass  # Instrumentation failures are non-fatal

    def mark_used(self, memory_ids: List[str], context=None) -> int:
        """Signal that specific memories were used in the agent's response.

        Boosts the relevance of used memories and resets their decay age.
        Optionally logs a usage signal if opt_in_to_aggregation is True.

        Args:
            memory_ids: List of memory hashes that appeared in the response.
            context: Optional SearchContext for linking to the retrieval event.

        Returns:
            Number of memories successfully boosted.
        """
        if context is not None:
            context.used_memory_ids = list(memory_ids)

        boosted = 0
        for memory_id in memory_ids:
            if self.boost_relevance(memory_id):
                boosted += 1

        # Log usage event
        event = {
            "event": "used",
            "memory_ids": memory_ids,
            "count": len(memory_ids),
            "timestamp": time.time(),
            "request_id": context.request_id if context else None,
        }
        try:
            with open(self._instrumentation_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")
        except OSError:
            pass

        # Log to audit logger if available
        if context is not None and hasattr(context, 'audit_logger') and context.audit_logger is not None:
            try:
                for memory_id in memory_ids:
                    context.audit_logger.log("recall", {
                        "memory_id": memory_id,
                        "context_id": context.context_id,
                        "request_id": context.request_id,
                        "session_id": context.session_id,
                    })
            except Exception:
                # Audit logging failures are non-fatal
                pass

        # Report anonymized signal if user opted in
        if self.opt_in_to_aggregation and context is not None:
            from .instrumentation import build_usage_signal
            self.report_usage_signal(build_usage_signal(context))

        # Invalidate cache so boosted memories rank higher on next search
        if boosted and self._read_cache is not None:
            self._read_cache.invalidate()

        return boosted

    def boost_relevance(self, memory_id: str, multiplier: float = 1.5) -> bool:
        """Boost the importance/relevance of a memory by ID.

        Increases the memory's importance score and resets its decay age,
        making it surface higher in future searches.

        Args:
            memory_id: The memory hash to boost.
            multiplier: Importance multiplier (default 1.5 = 50% boost).

        Returns:
            True if the memory was found and boosted, False otherwise.
        """
        for entry in self.memories:
            if entry.hash == memory_id:
                entry.importance = min(entry.importance * multiplier, 10.0)
                # Reset decay: freshen the memory as if it was just accessed
                entry.last_accessed = datetime.now(timezone.utc).isoformat()
                entry.access_count += 1
                self.search_engine.mark_dirty()
                return True
        return False

    def report_usage_signal(self, data: Dict) -> None:
        """Append an anonymized usage signal for crowdsourced PPMI training.

        Only writes when opt_in_to_aggregation is True. Data contains only
        statistical information — never actual memory content.

        Args:
            data: Anonymized signal dict from build_usage_signal().
        """
        if not self.opt_in_to_aggregation:
            return
        try:
            with open(self._usage_signals_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(data) + "\n")
        except OSError:
            pass

    # ── v3.2 Co-occurrence Semantic Boost ──────────────────────────────────────

    def search_with_context(
        self,
        query: str,
        limit: int = 20,
        instrumentation_context=None,
        cooccurrence_boost: bool = True,
        **kwargs,
    ) -> tuple:
        """Search memories with optional instrumentation and co-occurrence boost.

        Returns (results, SearchContext) for use with mark_used().

        Args:
            query: Search query string.
            limit: Maximum results to return.
            instrumentation_context: Optional pre-built SearchContext.
                If None, one is created automatically.
            cooccurrence_boost: Whether to apply local co-occurrence re-ranking.
            **kwargs: Additional args forwarded to search() (explain, category, etc.)

        Returns:
            Tuple of (results, SearchContext).
        """
        from .instrumentation import SearchContext

        ctx = instrumentation_context or SearchContext(query=query)

        # Run BM25 search (fetch extra for re-ranking)
        fetch_limit = limit * 2 if cooccurrence_boost else limit
        results = self.search(query, limit=fetch_limit, explain=True, **kwargs)

        # Co-occurrence re-ranking (Tier 1 semantic boost)
        if cooccurrence_boost and self._cooccurrence.vocab_size > 0:
            for r in results:
                boost = self._cooccurrence.boost_score(query, r.entry.content)
                r.score += boost

            results.sort(key=lambda r: r.score, reverse=True)

        results = results[:limit]

        # Record retrieval for instrumentation
        retrieved_ids = [r.entry.hash for r in results]
        self.mark_retrieved(retrieved_ids, ctx)

        # Return plain entries by default (backward compat), explain if needed
        if kwargs.get("explain"):
            return results, ctx

        entries = []
        for r in results:
            entry_copy = copy.copy(r.entry)
            entry_copy.confidence = r.relevance
            entries.append(entry_copy)
        return entries, ctx

    def _update_cooccurrence(self, content: str) -> None:
        """Update the local co-occurrence index when a memory is stored.

        Note: does NOT save to disk on every call — deferred to flush() to
        avoid O(n) disk writes during bulk ingestion (e.g. ingest_directory).
        """
        self._cooccurrence.update_from_memory(content)

    def _feed_cooccurrence_from_enrichment(self, original: str, enrichment: dict) -> None:
        """Feed enrichment-derived semantic relationships into the co-occurrence index.

        Constructs a virtual sentence from enrichment tags + keywords + original
        terms, then passes it through update_from_memory so all semantic pairs
        are captured. This bootstraps the co-occurrence matrix with high-quality
        LLM-derived relationships even before natural conversational data accumulates.

        v4.6.5 — runs on every enriched ingest, non-fatal.
        """
        try:
            parts = []
            # Add original content tokens
            parts.append(original.lower())
            # Add enrichment tags (normalised to words)
            for tag in enrichment.get("tags", []):
                parts.append(tag.lower().replace("_", " "))
            # Add enrichment keywords
            for kw in enrichment.get("keywords", []):
                parts.append(str(kw).lower().replace("_", " "))
            # Add enriched summary if present
            if enrichment.get("summary"):
                parts.append(enrichment["summary"].lower())
            virtual_sentence = " ".join(parts)
            self._cooccurrence.update_from_memory(virtual_sentence)
        except Exception:
            pass  # Non-fatal

    def re_enrich(
        self,
        batch_size: int = 50,
        progress_fn=None,
        overwrite: bool = False,
    ) -> int:
        """Re-enrich all existing memories through the configured enricher.

        Processes entries in batch_size chunks. Skips already-enriched entries
        unless overwrite=True. Rebuilds the search index after completion and
        saves all shards.

        v4.6.5 — bootstraps the co-occurrence matrix with 90K+ word pairs
        when run against an existing ~9,000 entry memory store.

        Args:
            batch_size: Progress callback fired every N enriched entries.
            progress_fn: Optional callable(enriched_count, total_count).
            overwrite: If True, re-enrich even entries that already have
                       an enriched_summary. Default False (idempotent).

        Returns:
            Count of entries enriched.
        """
        if self._enricher is None:
            return 0

        count = 0
        total = len(self.memories)

        for entry in self.memories:
            if not overwrite and getattr(entry, "enriched_summary", ""):
                continue  # Already enriched — skip unless overwrite requested

            try:
                enrichment = self._enricher(entry.content)
                if enrichment and isinstance(enrichment, dict):
                    if enrichment.get("tags"):
                        entry.tags = sorted(
                            set(entry.tags) | {t.lower() for t in enrichment["tags"]}
                        )
                    if enrichment.get("summary"):
                        entry.enriched_summary = str(enrichment["summary"])
                    if enrichment.get("keywords"):
                        entry.search_keywords = [
                            str(k).lower() for k in enrichment["keywords"]
                        ]
                    self._feed_cooccurrence_from_enrichment(entry.content, enrichment)
                    self._enrichment_count += 1
                    count += 1
            except Exception:
                pass  # Non-fatal — leave entry as-is

            if progress_fn and (count % batch_size == 0) and count > 0:
                progress_fn(count, total)

        if count:
            # Rebuild search index with enriched content
            self.search_engine.mark_dirty()
            # Save all shards with updated entries
            try:
                self.save()
            except Exception:
                pass
            # Save co-occurrence index
            try:
                self._cooccurrence.save()
            except Exception:
                pass

        return count


    # ── v4.7.0: Knowledge Ingestion methods ────────────────────────────────

    def ingest_url(self, url: str, depth: int = 1, incremental: bool = True) -> dict:
        """Ingest content from a URL into the memory system.

        Args:
            url: Web URL to crawl.
            depth: Link depth to follow (1 = single page).
            incremental: Skip chunks already known from previous crawls.

        Returns:
            {"ingested": N, "skipped_duplicates": M, "source_url": url}
        """
        try:
            from .ingest_web import WebCrawler
            from .ingest_manifest import IngestManifest

            crawler = WebCrawler()
            manifest = IngestManifest(self.workspace)

            known_hashes = manifest.get_known_hashes(url) if incremental else set()
            chunks = crawler.crawl(url, depth=depth)

            ingested = 0
            skipped = 0
            entry_ids = []

            for chunk in chunks:
                if chunk["content_hash"] in known_hashes:
                    skipped += 1
                    continue
                count = self.ingest(
                    chunk["text"],
                    source=url,
                    source_url=chunk["source_url"],
                    content_hash=chunk["content_hash"],
                )
                if count > 0:
                    ingested += count
                    entry_ids.append(chunk["content_hash"])
                else:
                    skipped += 1

            if entry_ids:
                manifest.update(url, entry_ids[-1], entry_ids)
                manifest.save()

            return {"ingested": ingested, "skipped_duplicates": skipped, "source_url": url}
        except Exception as e:
            import logging
            logging.getLogger("antaris_memory").error("ingest_url failed: %s", e)
            return {"ingested": 0, "skipped_duplicates": 0, "source_url": url, "error": str(e)}

    def ingest_data_file(self, path: str, format: str = "auto", **kwargs) -> dict:
        """Ingest structured data from a file (CSV, JSON, SQLite).

        Args:
            path: Path to the data file.
            format: "csv", "json", "sqlite", or "auto" (detect by extension).
            **kwargs: Extra args (text_columns for CSV, query for SQLite).

        Returns:
            {"ingested": N, "skipped_duplicates": M, "source_url": path}
        """
        try:
            from .ingest_structured import StructuredIngester
            from .ingest_manifest import IngestManifest

            ingester = StructuredIngester()
            manifest = IngestManifest(self.workspace)

            if format == "auto":
                ext = os.path.splitext(path)[1].lower()
                format = {".csv": "csv", ".json": "json", ".sqlite": "sqlite",
                          ".db": "sqlite", ".sqlite3": "sqlite"}.get(ext, "json")

            if format == "csv":
                chunks = ingester.from_csv(path, text_columns=kwargs.get("text_columns"))
            elif format == "json":
                chunks = ingester.from_json(path)
            elif format == "sqlite":
                query = kwargs.get("query", "SELECT * FROM sqlite_master")
                chunks = ingester.from_sqlite(path, query)
            else:
                return {"ingested": 0, "skipped_duplicates": 0, "source_url": path,
                        "error": f"Unknown format: {format}"}

            source_url = f"file://{os.path.abspath(path)}"
            known_hashes = manifest.get_known_hashes(source_url)

            ingested = 0
            skipped = 0
            entry_ids = []

            for chunk in chunks:
                if chunk["content_hash"] in known_hashes:
                    skipped += 1
                    continue
                count = self.ingest(
                    chunk["text"],
                    source=path,
                    source_url=chunk["source_url"],
                    content_hash=chunk["content_hash"],
                )
                if count > 0:
                    ingested += count
                    entry_ids.append(chunk["content_hash"])
                else:
                    skipped += 1

            if entry_ids:
                manifest.update(source_url, entry_ids[-1], entry_ids)
                manifest.save()

            return {"ingested": ingested, "skipped_duplicates": skipped, "source_url": path}
        except Exception as e:
            import logging
            logging.getLogger("antaris_memory").error("ingest_data_file failed: %s", e)
            return {"ingested": 0, "skipped_duplicates": 0, "source_url": path, "error": str(e)}

    def ingest_sql(self, db_path: str, query: str) -> dict:
        """Ingest data from a SQLite query.

        Args:
            db_path: Path to the SQLite database.
            query: SQL SELECT query.

        Returns:
            {"ingested": N, "skipped_duplicates": M, "source_url": db_path}
        """
        return self.ingest_data_file(db_path, format="sqlite", query=query)

    def delete_source(self, source_url: str) -> dict:
        """Remove all memories originating from a specific source URL.

        Args:
            source_url: The source_url to match against.

        Returns:
            {"deleted": N, "source_url": source_url}
        """
        try:
            from .ingest_manifest import IngestManifest

            to_remove = [m for m in self.memories
                         if getattr(m, "source_url", None) == source_url]
            removed_hashes = {m.hash for m in to_remove}

            self.memories = [m for m in self.memories if m.hash not in removed_hashes]
            self._hashes -= removed_hashes

            if to_remove:
                self.search_engine.mark_dirty()
                if self._read_cache is not None:
                    self._read_cache.invalidate()

            # Clean manifest
            try:
                manifest = IngestManifest(self.workspace)
                manifest.remove(source_url)
                manifest.save()
            except Exception:
                pass

            return {"deleted": len(to_remove), "source_url": source_url}
        except Exception as e:
            import logging
            logging.getLogger("antaris_memory").error("delete_source failed: %s", e)
            return {"deleted": 0, "source_url": source_url, "error": str(e)}


    # ── v4.9.0: Graph Intelligence public API ────────────────────────────────

    def graph_search(
        self,
        subject: str,
        relation: str = None,
        obj: str = None,
    ) -> list:
        """
        Relationship-aware graph search.

        Examples:
          mem.graph_search("moro")                   → all relationships involving moro
          mem.graph_search("moro", "created_by")     → what did moro create?
          mem.graph_search("moro", obj="antaris")    → how are moro and antaris related?

        Returns list of (source, relation, target, entry_ids) tuples.
        Returns empty list if graph is disabled or entity not found.
        """
        try:
            if not self._graph_enabled or self._graph is None:
                return []
            return self._graph.relationship_search(subject, relation, obj)
        except Exception:
            return []

    def entity_path(self, source: str, target: str, max_hops: int = 3) -> list:
        """
        Find the relationship path between two entities in the memory graph.

        Returns list of entity canonicals from source → target (inclusive),
        or empty list if no path exists or graph is disabled.

        Example:
          mem.entity_path("moro", "antaris-memory")
          → ["moro", "created_by", "antaris-memory"]  (if path exists)
        """
        try:
            if not self._graph_enabled or self._graph is None:
                return []
            result = self._graph.find_path(source, target, max_hops=max_hops)
            return result or []
        except Exception:
            return []

    def get_entity(self, canonical: str) -> dict:
        """
        Get information about a specific entity in the memory graph.

        Returns dict with entity info or empty dict if not found.
        """
        try:
            if not self._graph_enabled or self._graph is None:
                return {}
            node = self._graph.get_node(canonical)
            if node is None:
                return {}
            from dataclasses import asdict
            return asdict(node)
        except Exception:
            return {}

    def get_health(self) -> dict:
        """
        Simple readiness check for monitoring / health endpoints.

        Returns:
          {"status": "ok", "checks": {<name>: True/False, ...}}

        Status is "ok" only when all checks pass.
        Non-fatal: any check that throws is marked False.
        """
        checks = {}

        # Workspace is accessible
        try:
            checks["workspace_accessible"] = os.path.isdir(self.workspace)
        except Exception:
            checks["workspace_accessible"] = False

        # Memory store has entries loaded
        try:
            checks["memories_loaded"] = len(self.memories) >= 0  # always true, 0 is fine
        except Exception:
            checks["memories_loaded"] = False

        # WAL is functional
        try:
            checks["wal_ok"] = self._wal is not None
        except Exception:
            checks["wal_ok"] = False

        # Search engine is responsive
        try:
            self.search("__health_check__", limit=1)
            checks["search_ok"] = True
        except Exception:
            checks["search_ok"] = False

        # Graph (if enabled)
        try:
            if self._graph_enabled:
                checks["graph_ok"] = self._graph is not None
            else:
                checks["graph_ok"] = True  # disabled = not a failure
        except Exception:
            checks["graph_ok"] = False

        status = "ok" if all(checks.values()) else "degraded"
        return {"status": status, "checks": checks}

    def get_graph_stats(self) -> dict:
        """Return memory graph statistics (node count, edge count, top entities)."""
        try:
            if not self._graph_enabled or self._graph is None:
                return {"graph_enabled": False}
            return {**self._graph.get_stats(), "graph_enabled": True}
        except Exception:
            return {"graph_enabled": False}

    def rebuild_graph(self) -> int:
        """
        Rebuild the memory graph from scratch by re-indexing all loaded memories.

        Useful after bulk ingestion or when the graph file is stale/missing.
        Returns number of entries indexed. Non-fatal.
        """
        try:
            if not self._graph_enabled or self._graph is None:
                return 0
            # Reset the graph
            self._graph._nodes.clear()
            self._graph._edges.clear()
            self._graph._loaded = True
            count = 0
            for entry in self.memories:
                n = self._graph.index_entry(entry.hash, entry.content)
                if n > 0:
                    count += 1
            self._graph.save()
            return count
        except Exception:
            return 0


# Backward compatibility alias
MemorySystem = MemorySystemV4