"""
Antaris Memory MCP Server

MCP (Model Context Protocol) server exposing antaris-memory functionality via JSON-RPC 2.0 over stdio.
This is enterprise table stakes in 2026.

Protocol: JSON-RPC 2.0 over stdio (one JSON object per line, newline-delimited)

Usage:
    python -m antaris_memory.mcp_server --workspace /path/to/memory --agent-name my-agent
"""

import json
import sys
import os
import argparse
from typing import Dict, List, Any, Optional

try:
    from antaris_memory.core_v4 import MemorySystemV4 as MemorySystem
except ImportError:
    # Fallback for development
    MemorySystem = None


class AntarisMCPServer:
    """MCP Server for antaris-memory using JSON-RPC 2.0 over stdio."""
    
    SERVER_NAME = "antaris-memory"
    SERVER_VERSION = "4.9.0"
    PROTOCOL_VERSION = "2024-11-05"
    
    def __init__(self, workspace: str = ".", agent_name: str = "mcp-agent", agent_id: str = None):
        """Initialize the MCP server.
        
        Args:
            workspace: Memory workspace path
            agent_name: Agent name for memory scoping
            agent_id: Agent ID (defaults to agent_name if not provided)
        """
        self._workspace = workspace
        self._agent_name = agent_name
        self._agent_id = agent_id or agent_name
        self._memory: Optional[MemorySystem] = None
    
    def _get_memory(self) -> MemorySystem:
        """Lazy initialization of MemorySystem. Raises on failure."""
        if self._memory is None:
            if MemorySystem is None:
                raise ImportError("MemorySystemV4 not available")
            try:
                self._memory = MemorySystem(
                    workspace=self._workspace,
                    agent_name=self._agent_name
                )
                self._memory.load()
            except Exception as e:
                raise RuntimeError(f"Failed to initialize MemorySystem: {e}")
        return self._memory
    
    def _create_error_response(self, request_id: Any, code: int, message: str, data: Any = None) -> Dict:
        """Create a JSON-RPC error response."""
        error = {
            "code": code,
            "message": message
        }
        if data is not None:
            error["data"] = data
        
        response = {
            "jsonrpc": "2.0",
            "error": error,
            "id": request_id
        }
        
        return response
    
    def _create_success_response(self, request_id: Any, result: Any) -> Dict:
        """Create a JSON-RPC success response."""
        response = {
            "jsonrpc": "2.0",
            "result": result,
            "id": request_id
        }
        
        return response
    
    def _handle_initialize(self, params: Dict, request_id: Any) -> Dict:
        """Handle initialize method."""
        result = {
            "protocolVersion": self.PROTOCOL_VERSION,
            "capabilities": {
                "tools": {}
            },
            "serverInfo": {
                "name": self.SERVER_NAME,
                "version": self.SERVER_VERSION
            }
        }
        return self._create_success_response(request_id, result)
    
    def _handle_tools_list(self, params: Dict, request_id: Any) -> Dict:
        """Handle tools/list method."""
        tools = [
            {
                "name": "search_memory",
                "description": "Search the memory store for relevant entries",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"},
                        "limit": {"type": "integer", "description": "Max results", "default": 5},
                        "agent_id": {"type": "string", "description": "Agent scope filter"}
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "ingest_memory",
                "description": "Ingest new content into memory",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "content": {"type": "string", "description": "Content to store"},
                        "category": {"type": "string", "description": "Memory category", "default": "tactical"},
                        "agent_id": {"type": "string", "description": "Agent scope"},
                        "session_id": {"type": "string", "description": "Session identifier"}
                    },
                    "required": ["content"]
                }
            },
            {
                "name": "get_stats",
                "description": "Get memory system statistics",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "workspace": {"type": "string", "description": "Workspace path"}
                    },
                    "required": []
                }
            },
            {
                "name": "graph_search",
                "description": "Search memory graph relationships",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "subject": {"type": "string", "description": "Subject entity"},
                        "relation": {"type": "string", "description": "Relationship type"},
                        "obj": {"type": "string", "description": "Object entity"},
                        "agent_id": {"type": "string", "description": "Agent scope filter"}
                    },
                    "required": ["subject"]
                }
            },
            {
                "name": "get_entity",
                "description": "Get information about a specific entity",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "canonical": {"type": "string", "description": "Canonical entity name"}
                    },
                    "required": ["canonical"]
                }
            }
        ]
        
        result = {"tools": tools}
        return self._create_success_response(request_id, result)
    
    def _handle_tool_call(self, params: Dict, request_id: Any) -> Dict:
        """Handle tools/call method."""
        if "name" not in params:
            return self._create_error_response(request_id, -32602, "Missing tool name")
        
        tool_name = params["name"]
        arguments = params.get("arguments", {})
        
        try:
            if tool_name == "search_memory":
                result = self._tool_search_memory(**arguments)
            elif tool_name == "ingest_memory":
                result = self._tool_ingest_memory(**arguments)
            elif tool_name == "get_stats":
                result = self._tool_get_stats(**arguments)
            elif tool_name == "graph_search":
                result = self._tool_graph_search(**arguments)
            elif tool_name == "get_entity":
                result = self._tool_get_entity(**arguments)
            else:
                return self._create_error_response(request_id, -32602, f"Unknown tool: {tool_name}")
            
            # Format result according to MCP spec
            content = [{"type": "text", "text": json.dumps(result)}]
            mcp_result = {
                "content": content,
                "isError": False
            }
            
            return self._create_success_response(request_id, mcp_result)
            
        except TypeError as e:
            return self._create_error_response(request_id, -32602, f"Invalid parameters: {e}")
        except Exception as e:
            return self._create_error_response(request_id, -32603, f"Internal error: {e}")
    
    def _tool_search_memory(self, query: str, limit: int = 5, agent_id: str = None) -> Dict:
        """Search memory tool implementation."""
        memory = self._get_memory()
        
        # Use provided agent_id or default to server's agent_id
        search_agent_id = agent_id or self._agent_id
        
        results = memory.search(
            query=query,
            limit=limit,
            use_decay=True
        )
        
        # Convert results to serializable format
        formatted_results = []
        for entry in results:
            formatted_results.append({
                "content": getattr(entry, "content", ""),
                "score": round(float(getattr(entry, "importance", 0.0)), 4),
                "category": getattr(entry, "category", "general"),
                "hash": getattr(entry, "hash", "")
            })
        
        return {"results": formatted_results}
    
    def _tool_ingest_memory(self, content: str, category: str = "tactical", 
                           agent_id: str = None, session_id: str = None) -> Dict:
        """Ingest memory tool implementation."""
        memory = self._get_memory()
        
        # Use provided agent_id or default to server's agent_id
        ingest_agent_id = agent_id or self._agent_id
        
        try:
            added_count = memory.ingest(
                content=content,
                category=category,
                agent_id=ingest_agent_id,
                session_id=session_id
            )
            memory.save()
            
            # Get the hash of the most recently added entry
            entry_hash = ""
            if memory.memories:
                entry_hash = getattr(memory.memories[-1], "hash", "")
            
            return {
                "ok": added_count > 0,
                "hash": entry_hash
            }
        except Exception as e:
            return {
                "ok": False,
                "hash": "",
                "error": str(e)
            }
    
    def _tool_get_stats(self, workspace: str = None) -> Dict:
        """Get stats tool implementation."""
        memory = self._get_memory()
        
        stats = memory.stats()
        
        # Ensure we return the expected keys
        return {
            "total_entries": stats.get("total", stats.get("total_entries", 0)),
            "hot_entries": stats.get("hot_entries", 0),
            "warm_entries": stats.get("warm_entries", 0),
            "cold_entries": stats.get("cold_entries", 0),
            "node_count": stats.get("node_count", 0),
            "edge_count": stats.get("edge_count", 0),
            "version": stats.get("version", self.SERVER_VERSION)
        }
    
    def _tool_graph_search(self, subject: str, relation: str = None, 
                          obj: str = None, agent_id: str = None) -> Dict:
        """Graph search tool implementation."""
        memory = self._get_memory()
        
        try:
            results = memory.graph_search(
                subject=subject,
                relation=relation,
                obj=obj
            )
            
            # Convert results to serializable format
            formatted_results = []
            for result in results:
                if isinstance(result, dict):
                    formatted_results.append({
                        "source": result.get("source", subject),
                        "relation": result.get("relation", relation or ""),
                        "target": result.get("target", obj or "")
                    })
                else:
                    # Handle other result formats
                    formatted_results.append({
                        "source": subject,
                        "relation": relation or "",
                        "target": str(result)
                    })
            
            return {"results": formatted_results}
            
        except Exception:
            # If graph search fails, return empty results
            return {"results": []}
    
    def _tool_get_entity(self, canonical: str) -> Dict:
        """Get entity tool implementation."""
        memory = self._get_memory()
        
        try:
            entity = memory.get_entity(canonical)
            
            if entity:
                return {
                    "canonical": entity.get("canonical", canonical),
                    "display": entity.get("display", canonical),
                    "entity_type": entity.get("entity_type", "unknown"),
                    "mention_count": entity.get("mention_count", 0),
                    "entry_ids": entity.get("entry_ids", [])
                }
            else:
                return {
                    "canonical": canonical,
                    "display": canonical,
                    "entity_type": "unknown",
                    "mention_count": 0,
                    "entry_ids": []
                }
        except Exception:
            return {}
    
    def handle_request(self, request: dict) -> dict:
        """
        Dispatch a single JSON-RPC request dict.
        Returns a JSON-RPC response dict.
        Never raises — errors return proper JSON-RPC error responses.
        """
        try:
            # Validate basic JSON-RPC structure
            if not isinstance(request, dict):
                return self._create_error_response(None, -32600, "Invalid request format")
            
            if request.get("jsonrpc") != "2.0":
                return self._create_error_response(request.get("id"), -32600, "Invalid jsonrpc version")
            
            if "method" not in request:
                return self._create_error_response(request.get("id"), -32600, "Missing method")
            
            method = request["method"]
            params = request.get("params", {})
            request_id = request.get("id")
            
            # Handle notifications (requests without id)
            # Note: id=null is still a request, not a notification
            if "id" not in request:
                # Notifications don't get responses
                return None
            
            # Dispatch to method handlers
            if method == "initialize":
                return self._handle_initialize(params, request_id)
            elif method == "tools/list":
                return self._handle_tools_list(params, request_id)
            elif method == "tools/call":
                return self._handle_tool_call(params, request_id)
            else:
                return self._create_error_response(request_id, -32601, f"Method not found: {method}")
                
        except json.JSONDecodeError:
            return self._create_error_response(None, -32700, "Parse error")
        except Exception as e:
            return self._create_error_response(request.get("id"), -32603, f"Internal error: {e}")
    
    def run_stdio(self) -> None:
        """
        Read newline-delimited JSON from stdin, write responses to stdout.
        Loop until stdin closes (EOF).
        Each line: parse JSON → handle_request → serialize response → print.
        Non-fatal: skip malformed lines.
        """
        try:
            for line in sys.stdin:
                line = line.strip()
                
                # Skip empty lines
                if not line:
                    continue
                
                try:
                    # Parse JSON request
                    request = json.loads(line)
                    
                    # Handle request
                    response = self.handle_request(request)
                    
                    # Send response if not a notification
                    if response is not None:
                        response_json = json.dumps(response)
                        print(response_json, flush=True)
                        
                except json.JSONDecodeError:
                    # Skip malformed lines (non-fatal)
                    continue
                except Exception:
                    # Skip other errors (non-fatal)
                    continue
                    
        except EOFError:
            # Expected when stdin closes
            pass
        except KeyboardInterrupt:
            # Clean shutdown on Ctrl+C
            pass


def main():
    """Entry point for `python -m antaris_memory.mcp_server`"""
    parser = argparse.ArgumentParser(description="antaris-memory MCP server")
    parser.add_argument("--workspace", default=".", help="Memory workspace path")
    parser.add_argument("--agent-name", default="mcp-agent", help="Agent name for memory scoping")
    args = parser.parse_args()
    
    server = AntarisMCPServer(workspace=args.workspace, agent_name=args.agent_name)
    server.run_stdio()


if __name__ == "__main__":
    main()