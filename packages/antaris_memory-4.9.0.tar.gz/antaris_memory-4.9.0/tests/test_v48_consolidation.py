"""
Test suite for antaris-memory v4.9.0 Nightly Consolidation feature.

Tests the ConsolidationRunner class and TF-IDF extractive summarization.
Covers all consolidation scenarios including agent scoping, dry runs,
audit logging, and edge cases.
"""

import json
import os
import shutil
import tempfile
from datetime import datetime, timedelta, timezone
from unittest import TestCase

from antaris_memory.consolidation_runner import ConsolidationRunner, ConsolidationReport
from antaris_memory.entry import MemoryEntry
from antaris_memory.shards import ShardManager


class TestConsolidationRunner(TestCase):
    """Test suite for ConsolidationRunner."""

    def setUp(self):
        """Set up test environment with temporary workspace."""
        self.temp_dir = tempfile.mkdtemp()
        self.runner = ConsolidationRunner(self.temp_dir, dry_run=False)
        self.shard_manager = ShardManager(self.temp_dir)
    
    def tearDown(self):
        """Clean up temporary workspace."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def _create_cold_shard(self, week_offset: int, entries: list):
        """Helper to create a cold shard file with given entries."""
        # Create datetime for cold tier (>14 days old)
        old_date = datetime.now(timezone.utc) - timedelta(weeks=week_offset + 3)  # Ensure cold
        year, week, _ = old_date.isocalendar()
        shard_name = f"memories_{year}-W{week:02d}.jsonl"
        shard_path = os.path.join(self.temp_dir, shard_name)
        
        with open(shard_path, 'w', encoding='utf-8') as f:
            for entry in entries:
                entry.created = old_date.isoformat()
                f.write(json.dumps(entry.to_dict()) + '\n')
        
        return shard_name
    
    def _create_warm_shard(self, entries: list):
        """Helper to create a warm shard file with given entries."""
        # Create datetime for warm tier (3-14 days old)
        warm_date = datetime.now(timezone.utc) - timedelta(days=7)
        year, week, _ = warm_date.isocalendar()
        shard_name = f"memories_{year}-W{week:02d}.jsonl"
        shard_path = os.path.join(self.temp_dir, shard_name)
        
        with open(shard_path, 'w', encoding='utf-8') as f:
            for entry in entries:
                entry.created = warm_date.isoformat()
                f.write(json.dumps(entry.to_dict()) + '\n')
        
        return shard_name
    
    def _create_hot_shard(self, entries: list):
        """Helper to create a hot shard file with given entries."""
        # Create datetime for hot tier (<3 days old)
        hot_date = datetime.now(timezone.utc) - timedelta(days=1)
        year, week, _ = hot_date.isocalendar()
        shard_name = f"memories_{year}-W{week:02d}.jsonl"
        shard_path = os.path.join(self.temp_dir, shard_name)
        
        with open(shard_path, 'w', encoding='utf-8') as f:
            for entry in entries:
                entry.created = hot_date.isoformat()
                f.write(json.dumps(entry.to_dict()) + '\n')
        
        return shard_name

    # ── Basic TF-IDF extraction tests ─────────────────────────────────────────
    
    def test_extract_summary_returns_max_sentences(self):
        """extract_summary returns <= max_sentences."""
        entries = [
            MemoryEntry("Sentence one. Sentence two. Sentence three. Sentence four.", category="test"),
            MemoryEntry("Another sentence. Yet another sentence. And one more.", category="test")
        ]
        
        summary = self.runner.extract_summary(entries, max_sentences=2)
        sentence_count = len([s for s in summary.split('.') if s.strip()])
        self.assertLessEqual(sentence_count, 2)
    
    def test_extract_summary_single_entry_returns_content(self):
        """extract_summary on single entry returns that entry's content."""
        entry = MemoryEntry("This is a single test entry.", category="test")
        summary = self.runner.extract_summary([entry])
        self.assertEqual(summary, "This is a single test entry.")
    
    def test_extract_summary_empty_entries(self):
        """extract_summary handles empty entry list."""
        summary = self.runner.extract_summary([])
        self.assertEqual(summary, "")
    
    def test_extract_summary_tfidf_ranking(self):
        """extract_summary uses TF-IDF scoring to rank sentences."""
        entries = [
            MemoryEntry("Machine learning algorithms process data efficiently. Data science requires statistical knowledge.", category="tech"),
            MemoryEntry("Data processing algorithms handle machine learning tasks. Statistical methods analyze data patterns.", category="tech"),
        ]
        
        # Should contain key terms like "data", "machine", "learning"
        summary = self.runner.extract_summary(entries, max_sentences=2)
        self.assertIn("data", summary.lower())
        self.assertTrue(len(summary) > 0)

    # ── Grouping tests ──────────────────────────────────────────────────────
    
    def test_group_entries_same_category_together(self):
        """group_entries groups same-category entries together."""
        entries = [
            MemoryEntry("Tech content one", category="technology"),
            MemoryEntry("Business content one", category="business"),
            MemoryEntry("Tech content two", category="technology"),
            MemoryEntry("Business content two", category="business")
        ]
        
        groups = self.runner.group_entries(entries)
        
        # Should have separate groups for different categories
        tech_groups = [g for g in groups if g[0].category == "technology"]
        business_groups = [g for g in groups if g[0].category == "business"]
        
        self.assertTrue(len(tech_groups) > 0)
        self.assertTrue(len(business_groups) > 0)
    
    def test_group_entries_minimum_group_size(self):
        """group_entries does not group if < 3 entries in category."""
        entries = [
            MemoryEntry("Content one", category="small"),
            MemoryEntry("Content two", category="small")  # Only 2 entries
        ]
        
        groups = self.runner.group_entries(entries)
        
        # Should have 2 individual groups, not one consolidated group
        self.assertEqual(len(groups), 2)
        self.assertEqual(len(groups[0]), 1)
        self.assertEqual(len(groups[1]), 1)
    
    def test_group_entries_similarity_grouping(self):
        """group_entries groups similar entries within same category."""
        entries = [
            MemoryEntry("Python programming language syntax", category="tech"),
            MemoryEntry("Java programming language features", category="tech"), 
            MemoryEntry("Python syntax and programming", category="tech"),
            MemoryEntry("Database system architecture", category="tech"),
            MemoryEntry("SQL database query language", category="tech")
        ]
        
        groups = self.runner.group_entries(entries)
        
        # Should group Python-related entries together and database entries together
        python_group = None
        for group in groups:
            if any("python" in entry.content.lower() for entry in group):
                python_group = group
                break
        
        self.assertIsNotNone(python_group)
        self.assertGreaterEqual(len(python_group), 2)  # Should group similar Python entries

    # ── Full consolidation run tests ────────────────────────────────────────
    
    def test_run_empty_store_returns_zeros(self):
        """run() on empty store returns report with zeros."""
        report = self.runner.run()
        
        self.assertEqual(report.entries_before, 0)
        self.assertEqual(report.entries_after, 0)
        self.assertEqual(report.groups_consolidated, 0)
        self.assertEqual(report.bytes_saved, 0)
        self.assertFalse(report.dry_run)
    
    def test_run_consolidates_cold_entries(self):
        """run() consolidates cold entries and reduces count."""
        # Create cold entries that should be consolidated
        entries = [
            MemoryEntry("Machine learning model training", category="tech", agent_id="test"),
            MemoryEntry("Model training with machine learning", category="tech", agent_id="test"),
            MemoryEntry("Training machine learning algorithms", category="tech", agent_id="test"),
            MemoryEntry("Deep learning neural networks", category="tech", agent_id="test")
        ]
        
        self._create_cold_shard(4, entries)
        
        report = self.runner.run()
        
        self.assertEqual(report.entries_before, 4)
        self.assertLess(report.entries_after, 4)  # Should be consolidated
        self.assertGreater(report.groups_consolidated, 0)
    
    def test_run_leaves_hot_entries_untouched(self):
        """run() leaves hot-tier entries untouched."""
        hot_entries = [
            MemoryEntry("Recent content one", category="recent", agent_id="test"),
            MemoryEntry("Recent content two", category="recent", agent_id="test")
        ]
        
        self._create_hot_shard(hot_entries)
        
        # Also add cold entries to ensure consolidation runs
        cold_entries = [
            MemoryEntry("Old content one", category="old", agent_id="test"),
            MemoryEntry("Old content two", category="old", agent_id="test"),
            MemoryEntry("Old content three", category="old", agent_id="test")
        ]
        self._create_cold_shard(4, cold_entries)
        
        # Check hot shard exists before
        hot_shards_before = [f for f in os.listdir(self.temp_dir) if "W" in f]
        hot_count_before = len(hot_shards_before)
        
        report = self.runner.run()
        
        # Hot entries should remain (count includes new consolidated entries)
        self.assertGreater(report.entries_after, 0)
    
    def test_run_leaves_warm_entries_untouched(self):
        """run() leaves warm-tier entries untouched."""
        warm_entries = [
            MemoryEntry("Warm content one", category="warm", agent_id="test"),
            MemoryEntry("Warm content two", category="warm", agent_id="test")
        ]
        
        self._create_warm_shard(warm_entries)
        
        # Add cold entries too
        cold_entries = [
            MemoryEntry("Old content one", category="old", agent_id="test"),
            MemoryEntry("Old content two", category="old", agent_id="test"), 
            MemoryEntry("Old content three", category="old", agent_id="test")
        ]
        self._create_cold_shard(4, cold_entries)
        
        report = self.runner.run()
        
        # Should only process cold entries
        self.assertEqual(report.entries_before, 3)  # Only cold entries counted
    
    def test_run_dry_run_makes_no_changes(self):
        """run(dry_run=True) makes no changes to files."""
        entries = [
            MemoryEntry("Test content one", category="test", agent_id="test"),
            MemoryEntry("Test content two", category="test", agent_id="test"),
            MemoryEntry("Test content three", category="test", agent_id="test")
        ]
        
        shard_name = self._create_cold_shard(4, entries)
        original_content = open(os.path.join(self.temp_dir, shard_name)).read()
        
        dry_runner = ConsolidationRunner(self.temp_dir, dry_run=True)
        report = dry_runner.run()
        
        # File should be unchanged
        current_content = open(os.path.join(self.temp_dir, shard_name)).read()
        self.assertEqual(original_content, current_content)
        self.assertTrue(report.dry_run)
        
        # No archive directory should be created
        consolidated_dir = os.path.join(self.temp_dir, ".consolidated")
        self.assertFalse(os.path.exists(consolidated_dir))

    # ── Audit log tests ──────────────────────────────────────────────────────
    
    def test_audit_log_append_only(self):
        """Audit log is append-only (second run adds, doesn't replace)."""
        entries = [
            MemoryEntry("Content one", category="test", agent_id="test"),
            MemoryEntry("Content two", category="test", agent_id="test"),
            MemoryEntry("Content three", category="test", agent_id="test")
        ]
        
        self._create_cold_shard(4, entries)
        
        # First run
        self.runner.run()
        first_log = self.runner.get_audit_log()
        
        # Second run with different data
        entries2 = [
            MemoryEntry("New content one", category="test2", agent_id="test"),
            MemoryEntry("New content two", category="test2", agent_id="test"),
            MemoryEntry("New content three", category="test2", agent_id="test")
        ]
        self._create_cold_shard(5, entries2)
        
        self.runner.run()
        second_log = self.runner.get_audit_log()
        
        # Should have more entries after second run
        self.assertGreater(len(second_log), len(first_log))
        self.assertGreaterEqual(len(second_log), 2)
    
    def test_get_audit_log_returns_list(self):
        """get_audit_log() returns proper list structure."""
        # Run with no data to create an empty log entry
        report = self.runner.run()
        
        audit_log = self.runner.get_audit_log()
        self.assertIsInstance(audit_log, list)
        if audit_log:  # If there are entries
            self.assertIn("ts", audit_log[0])
            self.assertIn("report", audit_log[0])

    # ── Undo functionality tests ─────────────────────────────────────────────
    
    def test_undo_last_restores_entries(self):
        """undo_last() restores entries."""
        entries = [
            MemoryEntry("Restore content one", category="test", agent_id="test"),
            MemoryEntry("Restore content two", category="test", agent_id="test"),
            MemoryEntry("Restore content three", category="test", agent_id="test")
        ]
        
        shard_name = self._create_cold_shard(4, entries)
        original_path = os.path.join(self.temp_dir, shard_name)
        
        # Verify original exists
        self.assertTrue(os.path.exists(original_path))
        
        # Run consolidation (archives original)
        self.runner.run()
        
        # Original should be archived/removed
        # Now restore
        success = self.runner.undo_last()
        self.assertTrue(success)
        
        # Original should be restored
        self.assertTrue(os.path.exists(original_path))
    
    def test_undo_last_no_archive_returns_false(self):
        """undo_last() returns False when no archive exists."""
        success = self.runner.undo_last()
        self.assertFalse(success)

    # ── Agent scoping tests ───────────────────────────────────────────────────
    
    def test_agent_scoping_only_touches_agent_entries(self):
        """Agent scoping: run(agent_id="moro") only touches moro's entries."""
        entries = [
            MemoryEntry("Moro content one", category="test", agent_id="moro"),
            MemoryEntry("Moro content two", category="test", agent_id="moro"),
            MemoryEntry("Moro content three", category="test", agent_id="moro"),
            MemoryEntry("Alice content one", category="test", agent_id="alice"),
            MemoryEntry("Alice content two", category="test", agent_id="alice")
        ]
        
        self._create_cold_shard(4, entries)
        
        # Run consolidation for moro only
        report = self.runner.run(agent_id="moro")
        
        # Should only count moro's entries
        self.assertEqual(report.entries_before, 3)
        
        # Alice's entries should still exist in original shard
        # Load the shard and check
        shard_files = [f for f in os.listdir(self.temp_dir) if f.startswith("memories_")]
        alice_entries_found = False
        for shard_file in shard_files:
            with open(os.path.join(self.temp_dir, shard_file)) as f:
                for line in f:
                    entry_data = json.loads(line)
                    if entry_data.get("agent_id") == "alice":
                        alice_entries_found = True
                        break
        
        self.assertTrue(alice_entries_found, "Alice's entries should remain untouched")

    # ── Searchability tests ───────────────────────────────────────────────────
    
    def test_consolidated_summaries_are_searchable(self):
        """Consolidated summaries are searchable (they're normal MemoryEntry objects)."""
        entries = [
            MemoryEntry("Python programming language", category="tech", agent_id="test"),
            MemoryEntry("Python scripting and coding", category="tech", agent_id="test"),
            MemoryEntry("Programming with Python syntax", category="tech", agent_id="test")
        ]
        
        self._create_cold_shard(4, entries)
        
        report = self.runner.run()
        
        # Check that consolidated entries are proper MemoryEntry objects
        # Load all current shard files and verify structure
        shard_files = [f for f in os.listdir(self.temp_dir) if f.startswith("memories_")]
        consolidated_found = False
        
        for shard_file in shard_files:
            entries = self.shard_manager._load_shard(shard_file)
            for entry in entries:
                if entry.memory_type == "consolidated":
                    consolidated_found = True
                    # Verify it has all required MemoryEntry fields
                    self.assertIsInstance(entry, MemoryEntry)
                    self.assertTrue(hasattr(entry, 'hash'))
                    self.assertTrue(hasattr(entry, 'content'))
                    self.assertTrue(hasattr(entry, 'category'))
                    break
        
        if report.groups_consolidated > 0:
            self.assertTrue(consolidated_found, "Should find consolidated MemoryEntry objects")
    
    def test_multiple_categories_consolidated_independently(self):
        """Cold entries from multiple categories consolidated independently."""
        entries = [
            # Tech category group
            MemoryEntry("Machine learning algorithms", category="tech", agent_id="test"),
            MemoryEntry("Algorithm machine learning", category="tech", agent_id="test"), 
            MemoryEntry("Learning machine algorithms", category="tech", agent_id="test"),
            # Business category group  
            MemoryEntry("Business strategy planning", category="business", agent_id="test"),
            MemoryEntry("Strategic business planning", category="business", agent_id="test"),
            MemoryEntry("Planning business strategies", category="business", agent_id="test")
        ]
        
        self._create_cold_shard(4, entries)
        
        report = self.runner.run()
        
        # Should find details for both categories
        categories_in_details = [detail["category"] for detail in report.details]
        self.assertIn("tech", categories_in_details)
        self.assertIn("business", categories_in_details)
    
    def test_report_contains_accurate_bytes_saved(self):
        """Report contains accurate bytes_saved count."""
        entries = [
            MemoryEntry("This is some longer content for testing bytes calculation", category="test", agent_id="test"),
            MemoryEntry("Another piece of longer content for bytes measurement", category="test", agent_id="test"),
            MemoryEntry("Third entry with substantial content for bytes testing", category="test", agent_id="test")
        ]
        
        # Calculate original size
        original_size = sum(len(json.dumps(entry.to_dict())) for entry in entries)
        
        self._create_cold_shard(4, entries)
        
        report = self.runner.run()
        
        # bytes_saved should be reasonable (not zero if consolidation happened)
        if report.groups_consolidated > 0:
            self.assertGreater(report.bytes_saved, 0)
        else:
            self.assertEqual(report.bytes_saved, 0)
    
    def test_consolidation_handles_edge_cases(self):
        """Consolidation handles various edge cases gracefully."""
        # Test with empty content entries
        entries = [
            MemoryEntry("", category="test", agent_id="test"),
            MemoryEntry("   ", category="test", agent_id="test"),  # Whitespace only
            MemoryEntry("Valid content", category="test", agent_id="test")
        ]
        
        self._create_cold_shard(4, entries)
        
        # Should not crash
        report = self.runner.run()
        self.assertIsInstance(report, ConsolidationReport)
    
    def test_no_consolidation_when_insufficient_similarity(self):
        """No consolidation occurs when entries lack sufficient similarity."""
        entries = [
            MemoryEntry("Apple fruit nutrition", category="food", agent_id="test"),
            MemoryEntry("Car engine mechanics", category="automotive", agent_id="test"),
            MemoryEntry("Weather forecast rain", category="weather", agent_id="test")
        ]
        
        self._create_cold_shard(4, entries)
        
        report = self.runner.run()
        
        # Different categories and no shared terms = no consolidation
        self.assertEqual(report.groups_consolidated, 0)
        self.assertEqual(report.entries_before, report.entries_after)

    # ── Performance and robustness tests ──────────────────────────────────────
    
    def test_large_group_consolidation(self):
        """Test consolidation with larger groups of similar entries."""
        # Create a larger group of similar entries
        entries = []
        for i in range(10):
            entries.append(MemoryEntry(f"Python programming language tutorial {i}", category="tech", agent_id="test"))
        
        self._create_cold_shard(4, entries)
        
        report = self.runner.run()
        
        self.assertEqual(report.entries_before, 10)
        self.assertLess(report.entries_after, 10)  # Should be consolidated
        self.assertGreater(report.groups_consolidated, 0)
    
    def test_mixed_consolidatable_and_individual_entries(self):
        """Test mix of consolidatable groups and individual entries."""
        entries = [
            # Consolidatable group
            MemoryEntry("Database query optimization", category="tech", agent_id="test"),
            MemoryEntry("Query database optimization", category="tech", agent_id="test"),
            MemoryEntry("Optimization database queries", category="tech", agent_id="test"),
            # Individual entries (different categories)
            MemoryEntry("Weather is sunny today", category="weather", agent_id="test"),
            MemoryEntry("Cooking recipe ingredients", category="food", agent_id="test")
        ]
        
        self._create_cold_shard(4, entries)
        
        report = self.runner.run()
        
        # Should consolidate the tech group but leave weather and food separate
        self.assertEqual(report.entries_before, 5)
        self.assertEqual(report.entries_after, 3)  # 1 consolidated + 2 individual
        self.assertEqual(report.groups_consolidated, 1)


if __name__ == '__main__':
    import unittest
    unittest.main()