"""
Comprehensive tests for Quality Routing feature (antaris-memory v4.9.0)

Tests OutcomeTracker and QualityRouter classes.
"""

import json
import os
import tempfile
import time
import unittest
from dataclasses import dataclass
from typing import List, Any
from unittest.mock import Mock, patch

# Import the classes we're testing
import sys
import tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from antaris_memory.quality_router import (
    QualitySignal, OutcomeTracker, QualityRouter, _STOPWORDS
)


@dataclass
class MockMemoryEntry:
    """Mock memory entry for testing."""
    hash: str
    importance: float
    content: str = ""


@dataclass
class MockSearchResult:
    """Mock search result for testing."""
    entry: MockMemoryEntry
    score: float = 1.0


class TestQualitySignal(unittest.TestCase):
    """Test QualitySignal dataclass."""
    
    def test_quality_signal_creation(self):
        """Test QualitySignal can be created with required fields."""
        signal = QualitySignal(
            entry_hash="test_hash",
            query="test query",
            signal_type="useful",
            timestamp=1234567890.0
        )
        self.assertEqual(signal.entry_hash, "test_hash")
        self.assertEqual(signal.query, "test query")
        self.assertEqual(signal.signal_type, "useful")
        self.assertEqual(signal.timestamp, 1234567890.0)
        self.assertEqual(signal.session_id, "")
        self.assertEqual(signal.agent_id, "")
    
    def test_quality_signal_with_optional_fields(self):
        """Test QualitySignal with optional session_id and agent_id."""
        signal = QualitySignal(
            entry_hash="test_hash",
            query="test query", 
            signal_type="stale",
            timestamp=1234567890.0,
            session_id="session123",
            agent_id="agent456"
        )
        self.assertEqual(signal.session_id, "session123")
        self.assertEqual(signal.agent_id, "agent456")


class TestOutcomeTracker(unittest.TestCase):
    """Test OutcomeTracker functionality."""
    
    def setUp(self):
        """Set up test environment with temporary workspace."""
        self.temp_dir = tempfile.mkdtemp()
        self.tracker = OutcomeTracker(self.temp_dir)
        self.signals_path = os.path.join(self.temp_dir, OutcomeTracker.SIGNALS_FILE)
    
    def tearDown(self):
        """Clean up test environment."""
        # Clean up temp files
        try:
            if os.path.exists(self.signals_path):
                os.remove(self.signals_path)
            os.rmdir(self.temp_dir)
        except:
            pass
    
    def test_tracker_initialization(self):
        """Test OutcomeTracker initializes correctly."""
        self.assertEqual(self.tracker.workspace, self.temp_dir)
        self.assertEqual(self.tracker.signals_path, self.signals_path)
    
    def test_tracker_initialization_fallback(self):
        """Test OutcomeTracker handles bad workspace gracefully."""
        # Use non-existent parent directory
        bad_workspace = "/nonexistent/path/workspace"
        tracker = OutcomeTracker(bad_workspace)
        # Should fallback to current directory
        self.assertEqual(tracker.workspace, ".")
        self.assertEqual(tracker.signals_path, OutcomeTracker.SIGNALS_FILE)
    
    def test_record_useful_signal(self):
        """Test recording useful signals."""
        self.tracker.record_useful("hash123", "test query", "session1", "agent1")
        
        # Check signal was written to file
        self.assertTrue(os.path.exists(self.signals_path))
        
        with open(self.signals_path, 'r') as f:
            line = f.readline().strip()
            data = json.loads(line)
            
        self.assertEqual(data['entry_hash'], "hash123")
        self.assertEqual(data['query'], "test query")
        self.assertEqual(data['signal_type'], "useful")
        self.assertEqual(data['session_id'], "session1")
        self.assertEqual(data['agent_id'], "agent1")
        self.assertIsInstance(data['timestamp'], (int, float))
    
    def test_record_stale_signal(self):
        """Test recording stale signals."""
        self.tracker.record_stale("hash456", "old query")
        
        # Check signal was written to file
        self.assertTrue(os.path.exists(self.signals_path))
        
        with open(self.signals_path, 'r') as f:
            line = f.readline().strip()
            data = json.loads(line)
            
        self.assertEqual(data['entry_hash'], "hash456")
        self.assertEqual(data['query'], "old query")
        self.assertEqual(data['signal_type'], "stale")
    
    def test_get_signal_counts_empty(self):
        """Test get_signal_counts returns zeros for non-existent entry."""
        counts = self.tracker.get_signal_counts("nonexistent")
        self.assertEqual(counts, {"useful": 0, "stale": 0})
    
    def test_get_signal_counts_with_signals(self):
        """Test get_signal_counts returns correct counts."""
        # Record multiple signals for same entry
        self.tracker.record_useful("hash123", "query1")
        self.tracker.record_useful("hash123", "query2")
        self.tracker.record_stale("hash123", "query3")
        self.tracker.record_useful("hash456", "query4")  # different hash
        
        counts = self.tracker.get_signal_counts("hash123")
        self.assertEqual(counts["useful"], 2)
        self.assertEqual(counts["stale"], 1)
        
        counts_other = self.tracker.get_signal_counts("hash456")
        self.assertEqual(counts_other["useful"], 1)
        self.assertEqual(counts_other["stale"], 0)
    
    def test_get_top_entries_empty(self):
        """Test get_top_entries returns empty list when no signals."""
        top = self.tracker.get_top_entries()
        self.assertEqual(top, [])
    
    def test_get_top_entries_with_signals(self):
        """Test get_top_entries returns correctly sorted list."""
        # Record different numbers of useful signals
        self.tracker.record_useful("hash1", "query1")
        self.tracker.record_useful("hash2", "query2")
        self.tracker.record_useful("hash2", "query3")
        self.tracker.record_useful("hash3", "query4")
        self.tracker.record_useful("hash3", "query5")
        self.tracker.record_useful("hash3", "query6")
        self.tracker.record_stale("hash1", "query7")  # stale signals shouldn't count
        
        top = self.tracker.get_top_entries(2)
        self.assertEqual(len(top), 2)
        self.assertEqual(top[0], ("hash3", 3))  # highest count first
        self.assertEqual(top[1], ("hash2", 2))  # second highest
    
    def test_get_top_entries_limit(self):
        """Test get_top_entries respects the limit parameter."""
        for i in range(5):
            self.tracker.record_useful(f"hash{i}", f"query{i}")
        
        top = self.tracker.get_top_entries(3)
        self.assertEqual(len(top), 3)
    
    def test_flush_to_scores_boosts_useful(self):
        """Test flush_to_scores boosts importance for entries with useful signals."""
        # Create mock memories
        memory1 = MockMemoryEntry(hash="hash1", importance=0.5)
        memory2 = MockMemoryEntry(hash="hash2", importance=0.3)
        memory3 = MockMemoryEntry(hash="hash3", importance=0.8)
        memories = [memory1, memory2, memory3]
        
        # Record useful signals
        self.tracker.record_useful("hash1", "query1")
        self.tracker.record_useful("hash1", "query2")  # 2 useful signals
        self.tracker.record_useful("hash2", "query3")  # 1 useful signal
        # hash3 has no signals
        
        updated_count = self.tracker.flush_to_scores(memories, boost_factor=0.2)
        
        # Check updated count
        self.assertEqual(updated_count, 2)
        
        # Check boosted importance (original * (1 + boost_factor * useful_count))
        self.assertAlmostEqual(memory1.importance, 0.5 * (1 + 0.2 * 2), places=5)  # 0.5 * 1.4 = 0.7
        self.assertAlmostEqual(memory2.importance, 0.3 * (1 + 0.2 * 1), places=5)  # 0.3 * 1.2 = 0.36
        self.assertEqual(memory3.importance, 0.8)  # unchanged
    
    def test_flush_to_scores_decays_stale(self):
        """Test flush_to_scores decays importance for entries with only stale signals."""
        # Create mock memories
        memory1 = MockMemoryEntry(hash="hash1", importance=0.6)
        memory2 = MockMemoryEntry(hash="hash2", importance=0.4)
        memories = [memory1, memory2]
        
        # Record stale signals (no useful signals)
        self.tracker.record_stale("hash1", "query1")
        self.tracker.record_stale("hash2", "query2")
        
        updated_count = self.tracker.flush_to_scores(memories, decay_factor=0.1)
        
        # Check updated count
        self.assertEqual(updated_count, 2)
        
        # Check decayed importance (original * (1 - decay_factor))
        self.assertAlmostEqual(memory1.importance, 0.6 * (1 - 0.1), places=5)  # 0.6 * 0.9 = 0.54
        self.assertAlmostEqual(memory2.importance, 0.4 * (1 - 0.1), places=5)  # 0.4 * 0.9 = 0.36
    
    def test_flush_to_scores_useful_overrides_stale(self):
        """Test that useful signals override stale signals (no decay if useful present)."""
        memory = MockMemoryEntry(hash="hash1", importance=0.5)
        memories = [memory]
        
        # Record both useful and stale signals for same entry
        self.tracker.record_useful("hash1", "query1")
        self.tracker.record_stale("hash1", "query2")
        
        updated_count = self.tracker.flush_to_scores(memories, boost_factor=0.15, decay_factor=0.05)
        
        # Should boost (not decay) because useful signals present
        self.assertEqual(updated_count, 1)
        expected_importance = 0.5 * (1 + 0.15 * 1)  # boost, not decay
        self.assertAlmostEqual(memory.importance, expected_importance, places=5)
    
    def test_flush_to_scores_caps_at_one(self):
        """Test flush_to_scores caps importance at 1.0."""
        memory = MockMemoryEntry(hash="hash1", importance=0.9)
        memories = [memory]
        
        # Record many useful signals to push over 1.0
        for i in range(5):
            self.tracker.record_useful("hash1", f"query{i}")
        
        self.tracker.flush_to_scores(memories, boost_factor=0.5)
        
        # Should be capped at 1.0
        self.assertEqual(memory.importance, 1.0)
    
    def test_flush_to_scores_handles_missing_attributes(self):
        """Test flush_to_scores handles memories without hash or importance attributes."""
        # Mock object without required attributes
        bad_memory = Mock()
        bad_memory.hash = None
        good_memory = MockMemoryEntry(hash="hash1", importance=0.5)
        memories = [bad_memory, good_memory]
        
        self.tracker.record_useful("hash1", "query1")
        
        # Should handle bad memory gracefully
        updated_count = self.tracker.flush_to_scores(memories)
        self.assertEqual(updated_count, 1)  # Only good memory updated
    
    def test_clear_signals_truncates_file(self):
        """Test clear_signals truncates the signals file."""
        # Record some signals
        self.tracker.record_useful("hash1", "query1")
        self.tracker.record_stale("hash2", "query2")
        
        # Verify file has content
        self.assertTrue(os.path.exists(self.signals_path))
        with open(self.signals_path, 'r') as f:
            content = f.read()
        self.assertTrue(len(content) > 0)
        
        # Clear signals
        self.tracker.clear_signals()
        
        # Verify file is empty
        with open(self.signals_path, 'r') as f:
            content = f.read()
        self.assertEqual(content, "")
    
    def test_persistence_across_instances(self):
        """Test signals persist across OutcomeTracker instances."""
        # Record signal with first instance
        self.tracker.record_useful("hash1", "query1")
        
        # Create new instance with same workspace
        new_tracker = OutcomeTracker(self.temp_dir)
        
        # Should be able to read signal from first instance
        counts = new_tracker.get_signal_counts("hash1")
        self.assertEqual(counts["useful"], 1)
        self.assertEqual(counts["stale"], 0)
    
    def test_non_fatal_on_corrupt_file(self):
        """Test OutcomeTracker handles corrupt signals file gracefully."""
        # Write corrupt JSON to signals file
        with open(self.signals_path, 'w') as f:
            f.write("invalid json line 1\n")
            f.write('{"valid": "json"}\n')
            f.write("another invalid line\n")
        
        # Should handle gracefully and return zeros
        counts = self.tracker.get_signal_counts("any_hash")
        self.assertEqual(counts, {"useful": 0, "stale": 0})
        
        top = self.tracker.get_top_entries()
        self.assertEqual(top, [])


class TestQualityRouter(unittest.TestCase):
    """Test QualityRouter functionality."""
    
    def setUp(self):
        """Set up test environment with temporary workspace."""
        self.temp_dir = tempfile.mkdtemp()
        self.router = QualityRouter(self.temp_dir)
    
    def tearDown(self):
        """Clean up test environment."""
        # Clean up temp files
        try:
            signals_path = os.path.join(self.temp_dir, OutcomeTracker.SIGNALS_FILE)
            if os.path.exists(signals_path):
                os.remove(signals_path)
            os.rmdir(self.temp_dir)
        except:
            pass
    
    def test_router_initialization(self):
        """Test QualityRouter initializes correctly."""
        self.assertIsNotNone(self.router.tracker)
        self.assertEqual(self.router._session_state, {})
    
    def test_router_initialization_fallback(self):
        """Test QualityRouter handles initialization errors gracefully."""
        with patch('antaris_memory.quality_router.OutcomeTracker') as mock_tracker:
            mock_tracker.side_effect = Exception("Init error")
            router = QualityRouter("bad_path")
            self.assertIsNone(router.tracker)
    
    def test_tokenize_query(self):
        """Test query tokenization removes stopwords."""
        query = "the quick brown fox jumps over the lazy dog"
        tokens = self.router._tokenize_query(query)
        
        # Should remove stopwords like "the" but keep content words including "over"
        expected_tokens = {"quick", "brown", "fox", "jumps", "over", "lazy", "dog"}
        self.assertEqual(tokens, expected_tokens)
    
    def test_tokenize_query_empty(self):
        """Test tokenization handles empty query."""
        tokens = self.router._tokenize_query("")
        self.assertEqual(tokens, set())
    
    def test_tokenize_query_only_stopwords(self):
        """Test tokenization handles query with only stopwords."""
        tokens = self.router._tokenize_query("the and or but")
        self.assertEqual(tokens, set())
    
    def test_queries_related_sufficient_overlap(self):
        """Test queries are considered related with sufficient token overlap."""
        query1 = "machine learning algorithms"
        query2 = "deep learning algorithms"  # shares "learning" and "algorithms"
        
        self.assertTrue(self.router._queries_related(query1, query2))
    
    def test_queries_related_insufficient_overlap(self):
        """Test queries are not considered related with insufficient overlap."""
        query1 = "machine learning algorithms"
        query2 = "database optimization"  # no meaningful overlap
        
        self.assertFalse(self.router._queries_related(query1, query2))
    
    def test_queries_related_exactly_min_overlap(self):
        """Test queries with exactly minimum overlap are considered related."""
        # MIN_TOKEN_OVERLAP = 2
        query1 = "python programming"
        query2 = "python scripting"  # shares "python" (1 token) + need 1 more
        
        # Add one more shared token
        query2 = "python programming language"  # shares "python" and "programming"
        self.assertTrue(self.router._queries_related(query1, query2))
    
    def test_observe_search_no_prior_search(self):
        """Test observe_search returns 0 when no prior search in session."""
        # Create mock results
        result1 = MockSearchResult(MockMemoryEntry("hash1", 0.5))
        result2 = MockSearchResult(MockMemoryEntry("hash2", 0.3))
        results = [result1, result2]
        
        # First search in session
        signals = self.router.observe_search("test query", results, "session1", "agent1")
        
        # Should return 0 (no prior search to compare)
        self.assertEqual(signals, 0)
        
        # Session state should be updated
        self.assertIn("session1", self.router._session_state)
        state = self.router._session_state["session1"]
        self.assertEqual(state["query"], "test query")
        self.assertEqual(state["result_hashes"], {"hash1", "hash2"})
    
    def test_observe_search_records_signals_on_related_followup(self):
        """Test observe_search records signals for related follow-up queries."""
        # First search
        result1 = MockSearchResult(MockMemoryEntry("hash1", 0.5))
        result2 = MockSearchResult(MockMemoryEntry("hash2", 0.3))
        results1 = [result1, result2]
        
        self.router.observe_search("machine learning algorithms", results1, "session1")
        
        # Second search with overlapping results and related query (shares "learning" and "algorithms")
        result3 = MockSearchResult(MockMemoryEntry("hash1", 0.6))  # same as first
        result4 = MockSearchResult(MockMemoryEntry("hash3", 0.4))  # new
        results2 = [result3, result4]
        
        signals = self.router.observe_search("deep learning algorithms", results2, "session1")
        
        # Should record 1 signal for hash1 (appeared in both searches)
        self.assertEqual(signals, 1)
    
    def test_observe_search_unrelated_queries(self):
        """Test observe_search returns 0 for unrelated queries."""
        # First search
        result1 = MockSearchResult(MockMemoryEntry("hash1", 0.5))
        results1 = [result1]
        
        self.router.observe_search("machine learning", results1, "session1")
        
        # Second search with completely unrelated query
        result2 = MockSearchResult(MockMemoryEntry("hash1", 0.5))  # same entry
        results2 = [result2]
        
        signals = self.router.observe_search("database optimization", results2, "session1")
        
        # Should return 0 (queries not related)
        self.assertEqual(signals, 0)
    
    def test_observe_search_respects_time_window(self):
        """Test observe_search respects OVERLAP_WINDOW_SECONDS."""
        # First search
        result1 = MockSearchResult(MockMemoryEntry("hash1", 0.5))
        results1 = [result1]
        
        self.router.observe_search("machine learning", results1, "session1")
        
        # Mock time to simulate old search
        old_time = time.time() - self.router.OVERLAP_WINDOW_SECONDS - 10  # 10 seconds past window
        self.router._session_state["session1"]["timestamp"] = old_time
        
        # Second search with same entry and related query
        result2 = MockSearchResult(MockMemoryEntry("hash1", 0.5))
        results2 = [result2]
        
        signals = self.router.observe_search("deep learning", results2, "session1")
        
        # Should return 0 (outside time window)
        self.assertEqual(signals, 0)
    
    def test_observe_search_different_sessions_isolated(self):
        """Test different sessions don't interfere with each other."""
        # Search in session1
        result1 = MockSearchResult(MockMemoryEntry("hash1", 0.5))
        results1 = [result1]
        self.router.observe_search("machine learning", results1, "session1")
        
        # Search in session2 with related query and same entry
        result2 = MockSearchResult(MockMemoryEntry("hash1", 0.5))
        results2 = [result2]
        signals = self.router.observe_search("deep learning", results2, "session2")
        
        # Should return 0 (different session, no prior search in session2)
        self.assertEqual(signals, 0)
        
        # Both sessions should have separate state
        self.assertIn("session1", self.router._session_state)
        self.assertIn("session2", self.router._session_state)
    
    def test_observe_search_multiple_overlapping_entries(self):
        """Test observe_search handles multiple overlapping entries."""
        # First search with 3 results
        results1 = [
            MockSearchResult(MockMemoryEntry("hash1", 0.5)),
            MockSearchResult(MockMemoryEntry("hash2", 0.4)),
            MockSearchResult(MockMemoryEntry("hash3", 0.3))
        ]
        self.router.observe_search("machine learning algorithms", results1, "session1")
        
        # Second search overlapping with 2 of the 3 entries (shares "learning" and "algorithms")
        results2 = [
            MockSearchResult(MockMemoryEntry("hash1", 0.6)),  # overlap
            MockSearchResult(MockMemoryEntry("hash2", 0.5)),  # overlap
            MockSearchResult(MockMemoryEntry("hash4", 0.4))   # new
        ]
        signals = self.router.observe_search("deep learning algorithms", results2, "session1")
        
        # Should record 2 signals (for hash1 and hash2)
        self.assertEqual(signals, 2)
    
    def test_get_tracker_returns_tracker(self):
        """Test get_tracker returns OutcomeTracker instance."""
        tracker = self.router.get_tracker()
        self.assertIsInstance(tracker, OutcomeTracker)
        self.assertEqual(tracker, self.router.tracker)
    
    def test_observe_search_handles_bad_results(self):
        """Test observe_search handles malformed results gracefully."""
        # Mix of good and bad results
        good_result = MockSearchResult(MockMemoryEntry("hash1", 0.5))
        bad_result = Mock()  # No .entry.hash attribute
        # Make sure the bad result doesn't have the required attributes
        del bad_result.entry
        results = [good_result, bad_result]
        
        # Should handle gracefully
        signals = self.router.observe_search("test query", results, "session1")
        self.assertEqual(signals, 0)  # No prior search
        
        # Should extract hash from good result only
        state = self.router._session_state["session1"]
        self.assertEqual(state["result_hashes"], {"hash1"})
    
    def test_observe_search_empty_session_id(self):
        """Test observe_search returns 0 for empty session_id."""
        result = MockSearchResult(MockMemoryEntry("hash1", 0.5))
        results = [result]
        
        signals = self.router.observe_search("test query", results, "")
        self.assertEqual(signals, 0)
    
    def test_observe_search_non_fatal_on_exception(self):
        """Test observe_search is non-fatal when exceptions occur."""
        # Mock tracker to raise exception
        with patch.object(self.router.tracker, 'record_useful', side_effect=Exception("Test error")):
            result = MockSearchResult(MockMemoryEntry("hash1", 0.5))
            results = [result]
            
            # First search
            self.router.observe_search("machine learning", results, "session1")
            
            # Second search should not crash even if record_useful fails
            signals = self.router.observe_search("deep learning", results, "session1")
            # Should return 0 due to exception in record_useful
            self.assertEqual(signals, 0)


class TestStopwords(unittest.TestCase):
    """Test stopwords functionality."""
    
    def test_stopwords_set_contains_common_words(self):
        """Test that _STOPWORDS contains common English stopwords."""
        common_stopwords = {"the", "and", "or", "but", "in", "on", "at", "to", "for", "of"}
        self.assertTrue(common_stopwords.issubset(_STOPWORDS))
    
    def test_stopwords_set_is_frozenset(self):
        """Test that _STOPWORDS is a frozenset (immutable)."""
        self.assertIsInstance(_STOPWORDS, frozenset)


if __name__ == '__main__':
    unittest.main()