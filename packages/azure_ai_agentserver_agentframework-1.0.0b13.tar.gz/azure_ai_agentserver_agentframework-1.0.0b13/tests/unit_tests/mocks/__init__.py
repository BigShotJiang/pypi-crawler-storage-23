# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Mock implementations for testing."""

from .mock_checkpoint_client import MockFoundryCheckpointClient

__all__ = ["MockFoundryCheckpointClient"]
