---
title: Rockgarden
---

A Python static site generator that works with Obsidian vaults and plain markdown directories.

## Documentation

- [[Architecture]] - Build pipeline and module structure
- [[Deployment]] - Hosting and CI/CD
- [[Markdown Support]] - Supported syntax reference
- [[Vision]] - Goals and design philosophy
