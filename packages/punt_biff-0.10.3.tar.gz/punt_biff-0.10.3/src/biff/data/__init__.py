"""Bundled data files for biff (demo credentials, etc.)."""
