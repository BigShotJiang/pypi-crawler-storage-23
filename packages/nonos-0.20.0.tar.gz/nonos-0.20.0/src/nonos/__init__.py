from importlib.metadata import version

__version__ = version("nonos")
del version
