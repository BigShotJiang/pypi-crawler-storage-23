from regula.documentreader.webclient.gen import *
from regula.documentreader.webclient.ext import *
