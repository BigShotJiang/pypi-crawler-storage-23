# pyopu: Organoid Processing Unit Framework

`pyopu` is a Python framework for simulating and executing combinatorial optimization tasks on biological wetware (Brain Organoids) using the **Holographic Tensorial Paradigm**.

## Features
- **Agnostic Math Engine:** Compile NP-Hard problems into Rank-2 and Rank-3 Tensors.
- **Interchangeable Backends:** Run problems on virtual MEAs (Microelectrode Arrays) or advanced Dual-Opsin Optogenetic interfaces.
- **Observer Telemetry:** Extract spikes, opsin kinetics, and energy dynamics cleanly without cluttering the engine.

## Quickstart
Check the `examples/` directory for full implementations of the Max-Cut and 3-SAT problems.
