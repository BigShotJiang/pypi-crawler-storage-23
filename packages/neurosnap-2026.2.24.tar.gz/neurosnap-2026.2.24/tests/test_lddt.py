"""
Tests for the neurosnap.algos.lddt module.
"""

from pathlib import Path

import numpy as np
import pytest

from neurosnap.algos.lddt import calc_lddt
from neurosnap.protein import Protein

HERE = Path(__file__).resolve().parent
FILES = HERE / "files"


@pytest.fixture(scope="module")
def rank1_protein():
  return Protein(str(FILES / "4AOW_af2_rank_1.pdb"))


@pytest.fixture(scope="module")
def rank2_protein():
  return Protein(str(FILES / "4AOW_af2_rank_2.pdb"))


@pytest.fixture(scope="module")
def rna_model_one():
  return Protein(str(FILES / "rna_monomer_1.cif"))


@pytest.fixture(scope="module")
def rna_model_two():
  return Protein(str(FILES / "rna_monomer_2.cif"))


def test_calc_lddt_identical_proteins_returns_one(rank1_protein):
  score = calc_lddt(rank1_protein, rank1_protein)
  assert score == 1.0


def test_calc_lddt_variant_models_close_but_not_identical(rank1_protein, rank2_protein):
  score = calc_lddt(rank1_protein, rank2_protein)
  assert score < 1.0
  assert score == pytest.approx(0.982843137254902, rel=1e-6)


def test_calc_lddt_distance_map_shape_mismatch_raises():
  reference = np.zeros((2, 2))
  prediction = np.zeros((3, 3))
  with pytest.raises(ValueError):
    calc_lddt(reference, prediction)


def test_calc_lddt_mixed_input_types_raises(rank1_protein):
  with pytest.raises(TypeError):
    calc_lddt(rank1_protein, np.zeros((1, 1)))


def test_calc_lddt_identical_nucleic_acids_returns_one(rna_model_one):
  score = calc_lddt(rna_model_one, rna_model_one)
  assert score == 1.0


def test_calc_lddt_nucleic_acids_not_nan(rna_model_one, rna_model_two):
  score = calc_lddt(rna_model_one, rna_model_two)
  assert not np.isnan(score)
