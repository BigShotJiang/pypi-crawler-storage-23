import json
from pathlib import Path

import numpy as np
import pandas as pd
import time

from neurosnap import chemicals, conformers
from neurosnap.algos.ec_interface import compute_ec
from neurosnap.algos.ipsae import calculate_ipSAE, extract_interchain_metrics
from neurosnap.algos.lddt import calc_lddt
from neurosnap.msa import *
from neurosnap.protein import *
from neurosnap.rendering import animate_frames, render_protein_pseudo3D
from neurosnap.algos.evoef2 import *
# from neurosnap.algos.clusterprot import ClusterProt, animate_results, create_figure_plotly


data = calculate_stability("tests/files/dimer_af2.pdb")
assert "total" in data
assert np.isfinite(data["total"])
print("EvoEF2 stability total:", data["total"])
# Implement a direct comparison helper to diff each term vs. EvoEF2 output. <--- IMPLEMENT HERE
EVOEF2_REFERENCE_DIMER_AF2 = {
  "reference_ALA": -4.08,
  "reference_CYS": -0.0,
  "reference_ASP": -3.21,
  "reference_GLU": -17.15,
  "reference_PHE": 1.36,
  "reference_GLY": -20.93,
  "reference_HIS": -1.18,
  "reference_ILE": 37.28,
  "reference_LYS": -7.5,
  "reference_LEU": 16.13,
  "reference_MET": 1.52,
  "reference_ASN": -0.0,
  "reference_PRO": -2.59,
  "reference_GLN": -7.74,
  "reference_ARG": -10.58,
  "reference_SER": -23.74,
  "reference_THR": -2.5,
  "reference_VAL": 10.2,
  "reference_TRP": 0.0,
  "reference_TYR": 0.0,
  "intraR_vdwatt": -21.04,
  "intraR_vdwrep": 5.0,
  "intraR_electr": -0.26,
  "intraR_deslvP": 0.0,
  "intraR_deslvH": -2.8,
  "intraR_hbscbb_dis": -1.66,
  "intraR_hbscbb_the": -0.32,
  "intraR_hbscbb_phi": -0.0,
  "aapropensity": -11.36,
  "ramachandran": 268.22,
  "dunbrack": 46.69,
  "interS_vdwatt": -553.25,
  "interS_vdwrep": 84.96,
  "interS_electr": -35.97,
  "interS_deslvP": 368.03,
  "interS_deslvH": -251.21,
  "interS_ssbond": 0.0,
  "interS_hbbbbb_dis": -66.43,
  "interS_hbbbbb_the": -58.44,
  "interS_hbbbbb_phi": -66.84,
  "interS_hbscbb_dis": -3.26,
  "interS_hbscbb_the": -3.43,
  "interS_hbscbb_phi": -0.76,
  "interS_hbscsc_dis": -2.98,
  "interS_hbscsc_the": -1.07,
  "interS_hbscsc_phi": -0.0,
  "interD_vdwatt": -47.03,
  "interD_vdwrep": 1.97,
  "interD_electr": -2.8,
  "interD_deslvP": 28.44,
  "interD_deslvH": -43.48,
  "interD_ssbond": 0.0,
  "interD_hbbbbb_dis": -5.68,
  "interD_hbbbbb_the": -4.72,
  "interD_hbbbbb_phi": -5.77,
  "interD_hbscbb_dis": -0.06,
  "interD_hbscbb_the": -0.67,
  "interD_hbscbb_phi": -0.42,
  "interD_hbscsc_dis": 0.0,
  "interD_hbscsc_the": 0.0,
  "interD_hbscsc_phi": 0.0,
  "total": -423.11,
}


def _compare_terms(actual, expected, *, abs_tol=0.1, rel_tol=0.01, max_rows=50):
  rows = []
  for key, exp in expected.items():
    if key not in actual:
      rows.append((key, exp, None, None, None))
      continue
    act = float(actual[key])
    delta = act - exp
    rel = (delta / exp) if abs(exp) > 1e-8 else None
    rows.append((key, exp, act, delta, rel))
  rows.sort(key=lambda r: abs(r[3]) if r[3] is not None else float("inf"), reverse=True)
  print("\nTerm-by-term diff vs EvoEF2 reference:")
  print(f"{'term':<24} {'expected':>10} {'actual':>10} {'delta':>10} {'rel':>9}")
  for key, exp, act, delta, rel in rows[:max_rows]:
    if act is None:
      print(f"{key:<24} {exp:>10.3f} {'(missing)':>10} {'-':>10} {'-':>9}")
      continue
    rel_str = f"{rel:>8.3f}" if rel is not None else "   n/a"
    print(f"{key:<24} {exp:>10.3f} {act:>10.3f} {delta:>10.3f} {rel_str:>9}")
  bad = [key for key, exp, act, delta, _ in rows if act is not None and (abs(delta) > abs_tol and (abs(exp) < 1e-8 or abs(delta / exp) > rel_tol))]
  if bad:
    print(f"\nPercentage Bad: {len(bad)}/{len(rows)}")
    print(f"Sum of deltas: {sum(delta for key, exp, act, delta, rel in rows[:max_rows])}")
    print(f"Terms outside tolerances (abs>{abs_tol}, rel>{rel_tol}): {', '.join(bad)}")


# _compare_terms(data, EVOEF2_REFERENCE_DIMER_AF2)

# Additional stability comparison for 4AOW_af2_rank_1.pdb
data_4aow = calculate_stability("tests/files/4AOW_af2_rank_1.pdb")
assert "total" in data_4aow
assert np.isfinite(data_4aow["total"])
print("\nEvoEF2 stability total (4AOW):", data_4aow["total"])
EVOEF2_REFERENCE_4AOW_AF2 = {
  "reference_ALA": -6.12,
  "reference_CYS": -0.89,
  "reference_ASP": -16.84,
  "reference_GLU": -11.03,
  "reference_PHE": 5.43,
  "reference_GLY": -54.42,
  "reference_HIS": -2.36,
  "reference_ILE": 41.94,
  "reference_LYS": -20.0,
  "reference_LEU": 45.16,
  "reference_MET": 3.04,
  "reference_ASN": -30.17,
  "reference_PRO": -6.47,
  "reference_GLN": -23.23,
  "reference_ARG": -17.19,
  "reference_SER": -53.41,
  "reference_THR": -11.65,
  "reference_VAL": 35.7,
  "reference_TRP": 26.05,
  "reference_TYR": 4.2,
  "intraR_vdwatt": -55.12,
  "intraR_vdwrep": 10.39,
  "intraR_electr": -0.51,
  "intraR_deslvP": 0.0,
  "intraR_deslvH": -5.7,
  "intraR_hbscbb_dis": -9.12,
  "intraR_hbscbb_the": -0.26,
  "intraR_hbscbb_phi": -0.0,
  "aapropensity": -47.4,
  "ramachandran": 675.73,
  "dunbrack": 124.34,
  "interS_vdwatt": -1939.27,
  "interS_vdwrep": 196.76,
  "interS_electr": -87.9,
  "interS_deslvP": 1182.12,
  "interS_deslvH": -805.85,
  "interS_ssbond": 0.0,
  "interS_hbbbbb_dis": -148.31,
  "interS_hbbbbb_the": -115.7,
  "interS_hbbbbb_phi": -163.12,
  "interS_hbscbb_dis": -44.66,
  "interS_hbscbb_the": -32.2,
  "interS_hbscbb_phi": -9.7,
  "interS_hbscsc_dis": -40.52,
  "interS_hbscsc_the": -13.68,
  "interS_hbscsc_phi": -0.0,
  "interD_vdwatt": 0.0,
  "interD_vdwrep": 0.0,
  "interD_electr": 0.0,
  "interD_deslvP": 0.0,
  "interD_deslvH": 0.0,
  "interD_ssbond": 0.0,
  "interD_hbbbbb_dis": 0.0,
  "interD_hbbbbb_the": 0.0,
  "interD_hbbbbb_phi": 0.0,
  "interD_hbscbb_dis": 0.0,
  "interD_hbscbb_the": 0.0,
  "interD_hbscbb_phi": 0.0,
  "interD_hbscsc_dis": 0.0,
  "interD_hbscsc_the": 0.0,
  "interD_hbscsc_phi": 0.0,
  "total": -1421.94,
}

# _compare_terms(data_4aow, EVOEF2_REFERENCE_4AOW_AF2)

import timeit
print()
data_stab = calculate_stability("tests/files/dimer_af2.pdb")
data_inten = calculate_interface_energy("tests/files/dimer_af2.pdb", split1="A", split2="B")
data_binding = calculate_binding("tests/files/dimer_af2.pdb", split1="A", split2="B")
print(data_stab["total"])
print(data_inten["total"])

num_iters = 1
# execution_time = timeit.timeit(lambda: calculate_stability("tests/files/dimer_af2.pdb"), number=num_iters)
# execution_time = timeit.timeit(lambda: calculate_interface_energy("tests/files/dimer_af2.pdb", split1="A", split2="B"), number=num_iters)
execution_time = timeit.timeit(lambda: calculate_binding("tests/files/dimer_af2.pdb", split1="A", split2="B"), number=num_iters)
print()
print(f"Execution time (best of runs) for {num_iters:,} iterations: {execution_time:.4} seconds")

print("\nOthers")
data_binding = calculate_binding("tests/files/1nkp_mycmax_with_hydrogens.pdb", split1="H", split2="J") # DNA-DNA
print(data_binding["interface"]["total"])

data_binding = calculate_binding("tests/files/1nkp_mycmax_with_hydrogens.pdb", split1="D", split2="J") # Protein-DNA
print(data_binding["interface"]["total"])

data_binding = calculate_binding("tests/files/1nkp_mycmax_with_hydrogens.pdb", split1="D", split2="J") # Protein-DNA
print(data_binding["interface"]["total"])

data_stab = calculate_stability("tests/files/rna_monomer_1.cif")
print(data_stab["total"])

# for k, v in data.items():
#   print(f"- {k:.<22}: {float(v):.3f}")


# # def test_evoef2_binding_smoke():
# res = calculate_binding("tests/files/dimer_af2.pdb", split1=["A"], split2=["B"])
# assert "interface" in res and "dg_bind" in res
# assert np.isfinite(res["interface"]["total"])
# assert np.isfinite(res["dg_bind"]["total"])
# print("EvoEF2 interface total:", res["interface"]["total"])
# print("EvoEF2 DG_bind total:", res["dg_bind"]["total"])


# # def test_evoef2_rebuild_missing_atoms_smoke():
# evo_struct = rebuild_missing_atoms("tests/files/1nkp_mycmax.pdb")
# atoms_valid = sum(
#   1 for chain in evo_struct.chains for res in chain.residues for atom in res.atoms.values() if atom.is_xyz_valid
# )
# assert atoms_valid > 0
# print("EvoEF2 rebuilt atoms (valid):", atoms_valid)


# tmp_path = Path("tmp")
# tmp_path.mkdir(parents=True, exist_ok=True)
# prot = Protein("tests/files/dimer_af2.pdb")
# # prot = Protein("tests/files/1BTL.pdb")
# start = time.perf_counter()
# img = render_protein_pseudo3D(
#   prot,
#   # style="chain_id",
#   # style="pLDDT",
#   # style="b-factor",
#   # style="residue_type",
#   use_radii=True,
#   image_size=(576, 432),
#   padding=20,
#   upsample=2,
#   chainbreak=5,
#   shadow=0.95,
# )
# img.save(tmp_path / "pseudo3d_new.png")
# render_time = time.perf_counter() - start

# print(f"render_protein_pseudo3D compute time: {render_time:.4f}s")

# # get memory size
# channels = len(img.getbands())
# img_mem_bytes = img.size[0] * img.size[1] * channels
# print(f"render_protein_pseudo3D image memory: {img_mem_bytes:,} bytes ({img.mode})")


# cluster_dir = Path("tests/files/proteins_clustering")
# frames = []
# frame_labels = []
# for pdb_path in sorted(cluster_dir.glob("*.pdb")):
#   protein = Protein(pdb_path)
#   frames.append(
#     render_protein_pseudo3D(
#       protein,
#       # style="chain_id",
#       image_size=(320, 240),
#       padding=12,
#       upsample=1,
#       chainbreak=4,
#       shadow=0.9,
#     )
#   )
#   frame_labels.append(pdb_path.name)

# animate_frames(
#   frames,
#   tmp_path / "proteins_clustering.gif",
#   title="proteins_clustering",
#   subtitles=frame_labels,
#   interval=120,
#   repeat=True,
# )


# prot = Protein("tests/files/dimer_af2.pdb")

# # patches = prot.find_non_interface_hydrophobic_patches([("A", "B")])
# patches = prot.find_non_interface_hydrophobic_patches([("A", "B")], "A")
# print(len(patches))
# print(patches)

# from pymol import cmd

# cmd.load("tests/files/dimer_af2.pdb", "prot")

# # Show surface and color everything green first
# cmd.show("surface", "prot")
# cmd.color("green", "prot")

# # Colors for patches
# colors = ["red", "orange", "yellow", "cyan", "blue", "magenta", "salmon"]

# for i, residue_set in enumerate(patches, start=1):
#   color = colors[(i - 1) % len(colors)]
#   sel_name = f"set{i}"

#   # Extract chain + residue number from Biopython Residue objects
#   # get_id() returns (hetfield, resseq, icode)
#   parts = []
#   for res in residue_set:
#     chain_id = res.get_parent().id  # residue → chain
#     resi_num = res.get_id()[1]  # residue number
#     parts.append(f"chain {chain_id} and resi {resi_num}")

#   # Build a PyMOL OR selection string for this patch
#   selection = " or ".join(parts)

#   cmd.select(sel_name, f"prot and ({selection})")
#   cmd.color(color, sel_name)


# data = compute_ec(
#   Protein("tests/files/dimer_af2.pdb"),
#   "A",
#   "B",
# )

# results = {}
# for file in Path("/home/a/NeuroBind-evaluation/eval_designs/neurobind/peptide/").iterdir():
#   if file.suffix == ".pdb":
#     data = compute_ec(
#       Protein(file),
#       "B",
#       "A",
#     )
#     results[file.name] = data[0]

# sorted([(k,v) for k,v in results.items()], key=lambda x: x[1])


# with open("tests/files/dimer_af2.json") as f:
#   score = json.load(f)

# prot = Protein("tests/files/dimer_af2.pdb")
# pLDDT = np.asarray(score["plddt"])
# pae = np.asarray(score["pae"])
# res = calculate_ipSAE(prot, plddt=pLDDT, pae_matrix=pae)
# print("ipSAE", res["min"]["ipsae_d0res"]["A"]["B"])
# print("pDockQ", res["scores"]["pDockQ"]["A"]["B"])
# print("pDockQ2", res["scores"]["pDockQ2"]["A"]["B"])
# print("LIS", res["scores"]["LIS"]["A"]["B"])
# print(extract_interchain_metrics(res))


# with open("tests/files/orf1_boltz1.json") as f:
#   score = json.load(f)

# prot = Protein("tests/files/orf1_boltz1.cif")
# pLDDT = np.asarray(score["plddt"])
# pae = np.asarray(score["pae"])
# res = calculate_ipSAE(prot, plddt=pLDDT, pae_matrix=pae)
# print("ipSAE", res["min"]["ipsae_d0res"]["A"]["B"])
# print("pDockQ", res["scores"]["pDockQ"]["A"]["B"])
# print("pDockQ2", res["scores"]["pDockQ2"]["A"]["B"])
# print("LIS", res["scores"]["LIS"]["A"]["B"])


# prot = Protein("nanobody_7rnn.pdb")
# print(prot.select_residues("A"))
# print(prot.select_residues("A", True))
# print(prot.select_residues("A5-10"))
# print(prot.select_residues("A5-10", True))


# prot1=Protein("tests/files/4AOW_af2_rank_1.pdb")
# prot2=Protein("tests/files/4AOW_af2_rank_2.pdb")
# print(calc_lddt(prot1, prot1))
# print(calc_lddt(prot1, prot2))
# prot1.align(prot2)
# print(calc_lddt(prot1, prot2))

# prot2.center()
# prot2.save("center.pdb")


# prot1 = Protein("tests/files/rna_monomer_1.cif")
# prot2 = Protein("tests/files/rna_monomer_2.cif")
# prot1.align(prot2)
# print(calc_lddt(prot1, prot1))
# print(calc_lddt(prot1, prot2))
# prot1.align(prot2)
# print(calc_lddt(prot1, prot2))

# print(molecular_weight("QVQLVESGGGLVQPRGSLRLSCAASGFTFSRAAMSWYRQAPGKEREMVSTIGSFGVSTNYSDSVKGRFTISRDNAKNTVYLHMNSLKPEDTAVYYCNARYRSSYPWGQGTQVTVSS"))


# seq = "MKWVTFISLLFLFSSAYSRGVFRRDTHKSEIAHRFKDLGE"
# print(f"Estimated pI: {isoelectric_point(seq):.3f}")

# seq = "QVQLVESGGGLVQPRGSLRLSCAASGFTFSRAAMSWYRQAPGKEREMVSTIGSFGVSTNYSDSVKGRFTISRDNAKNTVYLHMNSLKPEDTAVYYCNARYRSSYPWGQGTQVTVSS"
# print(f"Estimated pI: {isoelectric_point(seq):.3f}")
# print(f"Estimated pI: {isoelectric_point(seq, pH_low=7.4, pH_high=7.4):.3f}")


# from neurosnap.algos.pdockq import calculate_pDockQ
# print(calculate_pDockQ("P61244_MAX_HUMAN__P01106_MYC_HUMAN_rank_1.pdb", "A", "B", dist_thresh=8))
# print(calculate_pDockQ("P61244_MAX_HUMAN__P01106_MYC_HUMAN_rank_1.pdb", dist_thresh=8))
# print(calculate_pDockQ("P61244_MAX_HUMAN__P01106_MYC_HUMAN_rank_1.pdb", dist_thresh=5))


# query_seq = "VQLVESGGDLVQAGGSLRLSCAVSGGTSSNYGMGWFRQAPGKEREFVSSISWSGSRTLYSDSVKGRFTISRDNAKNTVDLQMNSLKPEDTAVYYCTAVREYRDYPQRDNFDYWGQGTQVTVS"
# a3m_lines, templates = run_mmseqs2(query_seq, "MSA1", database="mmseqs2_uniref_env", use_templates=True)

# names, seqs = read_msa("MSA1/uniref.a3m", size=1000, allow_chars="-X")
# names, seqs = read_msa("MSA1/bfd.mgnify30.metaeuk30.smag30.a3m", size=1000, allow_chars="-X")
# seqs = pad_seqs(seqs, truncate=True)
# alignment = np.stack([np.frombuffer(seq.encode("ascii"), dtype="S1") for seq in seqs])
# query_alignment = alignment[0]
# non_gap_counts = (alignment != b"-").sum(axis=0)
# match_counts = ((alignment == query_alignment) & (alignment != b"-")).sum(axis=0)
# conservation = np.divide(match_counts, non_gap_counts, out=np.zeros_like(match_counts, dtype=float), where=non_gap_counts > 0)
# conserved_positions = (np.nonzero((query_alignment != b"-") & (conservation > 0.5))[0] + 1).tolist()
# non_conserved_positions = (np.nonzero((query_alignment != b"-") & (conservation <= 0.5))[0] + 1).tolist()
# print(len(conserved_positions)/len(query_alignment))
# print(len(non_conserved_positions)/len(query_alignment))


# seq1="MRPSGTAGAALLALLAALCPASRALEEKKVCQGTSNKLTQLGTFEDHFLSLQRMFNNCEVVLGNLEITYVQRNYDLSFLKTIQEVAGYVLIALNTVERIPLENLQIIRGNMYYENSYALAVLSNYDANKTGLKELPMRNLQEILHGAVRFSNNPALCNVESIQWRDIVSSDFLSNMSMDFQNHLGSCQ"
# seq2="MQRSPLEKASVVSKLFFSWTRPILRKGYRQRLELSDIYQIPSVDSADNLSEKLEREWDRELASKKNPKLINALRRCFFWRFMFYGIFLYLGEVTKAVQPLLLGRIIASYDPDNKEERSIAIYLGIGLCLLFIVRTLLLHPAIFGLHHIGMQMRIAMFSLIYKKTLKLSSRVLDKISIGQLVSLLSNNLNKFDEGLALAHFVWIAPLQVALLMGLIWELLQASAFCGLGFLIVLALFQAGLGRMMMKYRDSKPQIAALKEETEEEVQDTRL"
# a3m_lines, templates = run_mmseqs2(seq1, "MSA1", database="mmseqs2_uniref_env", use_templates=True)
# a3m_lines, templates = run_mmseqs2(seq2, "MSA2", database="mmseqs2_uniref_env", use_templates=True)


hisH_hisF = [
    # HisH — Imidazole glycerol phosphate synthase glutamine amidotransferase subunit (196 aa)
    "MNVVILDTGCANLNSVKSAIARHGYEPKVSRDPDVVLLADKLFLPGVGTAQAAMDQVRERELFDLIKACTQPVLGICLGMQLLGRRSEESNGVDLLGIIDEDVPKMTDFGLPLPHMGWNRVYPQAGNRLFFVHSYAMPVNPWTIAQCNYGEPFTAAVQKDNFYGVQFHPERSGAAGAKLLKNFLEM",
    # HisF — Imidazole glycerol phosphate synthase cyclase subunit (~252 aa)
    "MLSRRIIPCLDVRNGRVVKGVKFHDHIDMGDIVELALRYRAQGADELVFYDIGASPEGRSVDYTWVERVARLIDIPFCVAGGIGDVETARAVLHAGADKISINSPALGRPQLISELADAFGVQCVVVGIDSIREDDGQWRVRRYTGDPSKTQALPMRTLDWVAEAQRLGAGEIVLNCMDNDGVRRGYDIAQLRQVRALCHVPLIASGGAGEMQHFADVFDQADVDGALAASVFHSGAIPIPELKQFLRAQQIEVRDGQ"
]

a3m_lines, templates = run_mmseqs2(hisH_hisF, "MSA1", database="mmseqs2_uniref_env", pairing="greedy")


# prot = Protein("/home/a/Downloads/0_frame_1001.pdb")

# print(prot.calculate_rog())

# chemicals.move_ligand_to_center("/home/a/Downloads/poo.sdf", "/home/a/Downloads/0_frame_1001.pdb", "shieet.sdf")
# chemicals.move_ligand_to_center("/home/a/Downloads/poo.sdf", "/home/a/Downloads/0_frame_1001.pdb", "shieet.sdf")

# seq1="MRPSGTAGAALLALLAALCPASRALEEKKVCQGTSNKLTQLGTFEDHFLSLQRMFNNCEVVLGNLEITYVQRNYDLSFLKTIQEVAGYVLIALNTVERIPLENLQIIRGNMYYENSYALAVLSNYDANKTGLKELPMRNLQEILHGAVRFSNNPALCNVESIQWRDIVSSDFLSNMSMDFQNHLGSCQKCDPSCPNGSCWGAGEENCQKLTKIICAQQCSGRCRGKSPSDCCHNQCAAGCTGPRESDCLVCRKFRDEATCKDTCPPLMLYNPTTYQMDVNPEGKYSFGATCVKKCPRNYVVTDHGSCVRACGADSYEMEEDGVRKCKKCEGPCRKVCNGIGIGEFKDSLSINATNIKHFKNCTSISGDLHILPVAFRGDSFTHTPPLDPQELDILKTVKEITGFLLIQAWPENRTDLHAFENLEIIRGRTKQHGQFSLAVVSLNITSLGLRSLKEISDGDVIISGNKNLCYANTINWKKLFGTSGQKTKIISNRGENSCKATGQVCHALCSPEGCWGPEPRDCVSCRNVSRGRECVDKCNLLEGEPREFVENSECIQCHPECLPQAMNITCTGRGPDNCIQCAHYIDGPHCVKTCPAGVMGENNTLVWKYADAGHVCHLCHPNCTYGCTGPGLEGCPTNGPKIPSIATGMVGALLLLLVVALGIGLFMRRRHIVRKRTLRRLLQERELVEPLTPSGEAPNQALLRILKETEFKKIKVLGSGAFGTVYKGLWIPEGEKVKIPVAIKELREATSPKANKEILDEAYVMASVDNPHVCRLLGICLTSTVQLIMQLMPFGCLLDYVREHKDNIGSQYLLNWCVQIAKGMNYLEDRRLVHRDLAARNVLVKTPQHVKITDFGRAKLLGAEEKEYHAEGGKVPIKWMALESILHRIYTHQSDVWSYGVTVWELMTFGSKPYDGIPASEISSILEKGERLPQPPICTIDVYMIMVKCWMIDADSRPKFRELIIEFSKMARDPQRYLVIQGDERMHLPSPTDSNFYRALMDEEDMDDVVDADEYLIPQQGFFSSPSTSRTPLLSSLSATSNNSTVACIDRNGLQSCPIKEDSFLQRYSSDPTGALTEDSIDDTFLPVPEYINQSVPKRPAGSVQNPVYHNQPLNPAPSRDPHYQDPHSTAVGNPEYLNTVQPTCVNSTFDSPAHWAQKGSHQISLDNPDYQQDFFPKEAKPNGIFKGSTAENAEYLRVAPQSSEFIGA"
# seq2="MQRSPLEKASVVSKLFFSWTRPILRKGYRQRLELSDIYQIPSVDSADNLSEKLEREWDRELASKKNPKLINALRRCFFWRFMFYGIFLYLGEVTKAVQPLLLGRIIASYDPDNKEERSIAIYLGIGLCLLFIVRTLLLHPAIFGLHHIGMQMRIAMFSLIYKKTLKLSSRVLDKISIGQLVSLLSNNLNKFDEGLALAHFVWIAPLQVALLMGLIWELLQASAFCGLGFLIVLALFQAGLGRMMMKYRDQRAGKISERLVITSEMIENIQSVKAYCWEEAMEKMIENLRQTELKLTRKAAYVRYFNSSAFFFSGFFVVFLSVLPYALIKGIILRKIFTTISFCIVLRMAVTRQFPWAVQTWYDSLGAINKIQDFLQKQEYKTLEYNLTTTEVVMENVTAFWEEGFGELFEKAKQNNNNRKTSNGDDSLFFSNFSLLGTPVLKDINFKIERGQLLAVAGSTGAGKTSLLMVIMGELEPSEGKIKHSGRISFCSQFSWIMPGTIKENIIFGVSYDEYRYRSVIKACQLEEDISKFAEKDNIVLGEGGITLSGGQRARISLARAVYKDADLYLLDSPFGYLDVLTEKEIFESCVCKLMANKTRILVTSKMEHLKKADKILILHEGSSYFYGTFSELQNLQPDFSSKLMGCDSFDQFSAERRNSILTETLHRFSLEGDAPVSWTETKKQSFKQTGEFGEKRKNSILNPINSIRKFSIVQKTPLQMNGIEEDSDEPLERRLSLVPDSEQGEAILPRISVISTGPTLQARRRQSVLNLMTHSVNQGQNIHRKTTASTRKVSLAPQANLTELDIYSRRLSQETGLEISEEINEEDLKECFFDDMESIPAVTTWNTYLRYITVHKSLIFVLIWCLVIFLAEVAASLVVLWLLGNTPLQDKGNSTHSRNNSYAVIITSTSSYYVFYIYVGVADTLLAMGFFRGLPLVHTLITVSKILHHKMLHSVLQAPMSTLNTLKAGGILNRFSKDIAILDDLLPLTIFDFIQLLLIVIGAIAVVAVLQPYIFVATVPVIVAFIMLRAYFLQTSQQLKQLESEGRSPIFTHLVTSLKGLWTLRAFGRQPYFETLFHKALNLHTANWFLYLSTLRWFQMRIEMIFVIFFIAVTFISILTTGEGEGRVGIILTLAMNIMSTLQWAVNSSIDVDSLMRSVSRVFKFIDMPTEGKPTKSTKPYKNGQLSKVMIIENSHVKKDDIWPSGGQMTVKDLTAKYTEGGNAILENISFSISPGQRVGLLGRTGSGKSTLLSAFLRLLNTEGEIQIDGVSWDSITLQQWRKAFGVIPQKVFIFSGTFRKNLDPYEQWSDQEIWKVADEVGLRSVIEQFPGKLDFVLVDGGCVLSHGHKQLMCLARSVLSKAKILLLDEPSAHLDPVTYQIIRRTLKQAFADCTVILCEHRIEAMLECQQFLVIEENKVRQYDSIQKLLNERSLFRQAISPSDRVKLFPHRNSSKCKSKPQIAALKEETEEEVQDTRL"
# seq3="LCLYTHIGRNIYYGSYLYSETWNTGIMLLLITMATAFMGYVLPWGQMSFWGAT"

# a3m_lines, templates = run_mmseqs2([seq1], "MSA3", database="mmseqs2_uniref_env", use_templates=True)
# a3m_lines, templates = run_mmseqs2([seq1, seq2], "MSA3", database="mmseqs2_uniref_env", use_templates=True, pairing="complete")
# a3m_lines, templates = run_mmseqs2([seq1, seq2], "MSA3", database="mmseqs2_uniref_env")
# a3m_lines, templates = run_mmseqs2(seq3, "MSA", database="mmseqs2_uniref_env")
# with open("MSA3/shit.a3m", "w") as f:
#   for line in a3m_lines:
#     f.write(line)


# prot = Protein("test_files/4AOW_biological_assembly_1_rank_1.pdb")
# print(prot.chains())
# print(prot.get_backbone())
# print(prot.get_backbone(prot.chains()))
# com = prot.calculate_center_of_mass()
# distances_from_com = prot.distances_from_com()
# rog = prot.calculate_rog()
# print(rog)
# distances_from_com = prot.distances_from_com(com=com)
# rog = prot.calculate_rog(distances_from_com=distances_from_com)
# print(rog)


# accs = {
#   "P56704": "MAPLGYFLLLCSLKQALGSYPIWWSLAVGPQYSSLGSQPILCASIPGLVPKQLRFCRNYVEIMPSVAEGIKIGIQECQHQFRGRRWNCTTVHDSLAIFGPVLDKATRESAFVHAIASAGVAFAVTRSCAEGTAAICGCSSRHQGSPGKGWKWGGCSEDIEFGGMVSREFADARENRPDARSAMNRHNNEAGRQAIASHMHLKCKCHGLSGSCEVKTCWWSQPDFRAIGDFLKDKYDSASEMVVEKHRESRGWVETLRPRYTYFKVPTERDLVYYEASPNFCEPNPETGSFGTRDRTCNVSSHGIDGCDLLCCGRGHNARAERRREKCRCVFHWCCYVSCQECTRVYDVHTCK",
#   "Q91029": "MRGPALLLALRALCALSALRGTARAVNNSGRWWGIINVASSTNLLTDSGSVQLVLEPGLQLLSRKQRRLIRQNPGILHSVSAGLQSAVRECQWQFRNRRWNCPTSQGPNIFGKIVNRGCRETAFIFAITSAGVTHSVARSCSEGSIESCTCDYRRRGPGGPDWHWGGCSDNIDFGRLFGREFVDSSEKGRDLRFLMNLHNNEAGRMTVFSEMRQECKCHGMSGSCTVRTCWMRLPTFRAVGDVLKDRFDGASRVIYGNKGSNRASRVELHHLEPENPAHKPPSPHDLVYFEKSPNFCTYSGKMGTAGTAGRACNSSSPGLDGCELLCCGRGFRTRTQRVTERCNCTFHWCCHVSCLNCTNTQVLHECL",
#   "P27467": "MAPLGYLLVLCSLKQALGSYPIWWSLAVGPQYSSLSTQPILCASIPGLVPKQLRFCRNYVEIMPSVAEGVKAGIQECQHQFRGRRWNCTTVSNSLAIFGPVLDKATRESAFVHAIASAGVAFAVTRSCAEGSAAICGCSSRLQGSPGEGWKWGGCSEDIEFGGMVSREFADARENRPDARSAMNRHNNEAGRQAIASHMHLKCKCHGLSGSCEVKTCWWSQPDFRTIGDFLKDKYDSASEMVVEKHRESRGWVETLRPRYTYFKVPTERDLVYYEASPNFCEPNPETGSFGTRDRTCNVSSHGIDGCDLLCCGRGHNARTERRREKCHCVFHWCCYVSCQECTRVYDVHTCK",
#   "O00755": "MNRKARRCLGHLFLSLGMVYLRIGGFSSVVALGASIICNKIPGLAPRQRAICQSRPDAIIVIGEGSQMGLDECQFQFRNGRWNCSALGERTVFGKELKVGSREAAFTYAIIAAGVAHAITAACTQGNLSDCGCDKEKQGQYHRDEGWKWGGCSADIRYGIGFAKVFVDAREIKQNARTLMNLHNNEAGRKILEENMKLECKCHGVSGSCTTKTCWTTLPQFRELGYVLKDKYNEAVHVEPVRASRNKRPTFLKIKKPLSYRKPMDTDLVYIEKSPNYCEEDPVTGSVGTQGRACNKTAPQASGCDLMCCGRGYNTHQYARVWQCNCKFHWCCYVKCNTCSERTEMYTCK",
#   "Q2LMP1": "MASFGYFLFLCGLSQALSSYPIWWSLAIGHQYSSLGTQPILCGSIPGLVPKQLRFCRNYVEIMPSVAEGVKIGIQECQHQFRGRRWNCTTVNDSLAIFGPVLDKATRESAFVHAIASAGVAFAVTRSCAEGSATICGCDTRHKGSPGEGWKWGGCSEDVEFGSMVSREFADARENRPDARSAMNRHNNEAGRTSIIELMHLKCKCHGLSGSCEVKTCWWSQPDFRVIGDYLKDKYDSASEMVVEKHRESRGWVETLRPKYNFFKAPTEKDLVYYENSPNFCEPNPETGSFGTRDRICNVTSHGIDGCDLLCCGRGHNTRTEKRKEKCHCIFHWCCYVRCQECIRVYDVHTCK",
#   "P28026": "MQNTTLFILATLLIFCPFFTASAWSVNNFLMTGPKAYLTYSASVAVGAQNGIEECKYQFAWERWNCPESTLQLATHNGLRSATRETSFVHAISSAGVMYTLTRNCSMGDFDNCGCDDSRNGRIGGRGWVWGGCSDNAEFGERISKLFVDGLETGQDARALMNLHNNEAGRLAVKETMKRTCKCHGISGSCSIQTCWLQLAEFRDIGNHLKIKHDQALKLEMDKRKMRSGNSADNRGAIADAFSSVAGSELIFLEDSPDYCLKNISLGLQGTEGRECLQSGKNLSQWERRSCKRLCTDCGLRVEEKKTEIISSCNCKFHWCCTVKCEQCKQVVIKHFCARRERDSNMLNTKRKNRGHRR",
# }
# for acc, sequence in fetch_accessions(accs).items():
#   print(acc, sequence == accs[acc], sequence)


# run_mmseqs2("STLRLLISDSHDPWFNLAVEECIFRQMPATQRVLFLVRNADTVVIGRNQNPWKECNIRRMEEDNVRLARRSSGGGAVFHDLGNTCFTFMAGKPEYDKTISTSIVLNALNALGVSAEASGRNDLVVKTVEGDRKVSGSAYRETKDRGLHHGTLLLNADLSRLANYLNPDKKKLAAKGITSVRSRVTNLTELLPGITHEQVCEAITEAFFAHYGERVEAEIISPNETPDLPNFAETFARQSSWEWNFGQSPAFSHLLDERFTWGGVELRFDVEKGHITRAQVFTDSLNPAPLEALAGRLQGCLYRADELQQECEALLVDFPEQEKELRELSAWMAGAVR", "MSA")

# names, seqs = read_msa("test_files/test.fasta", name_allow_all_chars=True)
# for name, seq in zip(names, seqs):
#   print(name, seq)

# prot = Protein("/home/a/Downloads/9ayg_CaV3.2.pdb")
# for chain in prot.chains():
#   print(prot.get_aas(chain))
#   print(len(prot.get_aas(chain)))
#   print(sum(len(prot.get_aas(chain)) for chain in prot.chains()))

# print(fetch_uniprot("P61247"))

# chemicals.fetch_ccd("NMM", "NMM.sdf")
# print(chemicals.sdf_to_smiles("NMM.sdf"))


# df = conformers.generate("test_files/ChEBI_60344.sdf", output_name="TEST", num_confs=100)


# import os
# proteins = [f"test_files/proteins_clustering/{path}" for path in os.listdir("test_files/proteins_clustering/")]
# cp_results = ClusterProt(proteins)

# create_figure_plotly(cp_results)
# animate_results(cp_results, animation_fpath="cluster_prot.gif")
