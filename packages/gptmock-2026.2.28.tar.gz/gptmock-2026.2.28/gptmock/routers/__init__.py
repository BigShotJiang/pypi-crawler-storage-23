from __future__ import annotations

from .openai import router as openai_router

__all__ = ["openai_router"]
