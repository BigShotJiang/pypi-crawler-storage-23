"""Infrastructure layer for gptmock."""
from __future__ import annotations
