#!/bin/bash
exec cloak hook prompt-guard
