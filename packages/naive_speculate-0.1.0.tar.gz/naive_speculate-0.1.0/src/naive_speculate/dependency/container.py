"""Provide `DependencyContainer`, as dependency provider for speculative decoding components."""

from functools import cached_property
from typing import TYPE_CHECKING

from transformers import AutoTokenizer, PreTrainedTokenizerFast

from naive_speculate.utils.tokenizer import Tokenizer

from .maker import make_autoregressive_decoder, make_speculative_decoder

if TYPE_CHECKING:
    from naive_speculate.autoregress import AutoregressiveDecoder
    from naive_speculate.config.internal import SpeculateConfig
    from naive_speculate.speculate import SpeculativeDecoder

__all__ = ["DependencyContainer"]


class DependencyContainer:
    """Centralized container for initializing and managing all necessary dependencies.

    Specifically, it handles the initialization of the tokenizer, the speculative decoder,
    and the autoregressive decoder, based on the provided configurations.

    Attributes:
        config (SpeculateConfig): Configurations used for initializing dependencies.
    """

    def __init__(self, config: SpeculateConfig) -> None:
        self.config = config

    @cached_property
    def tokenizer(self) -> Tokenizer:
        """The initialized tokenizer instance."""
        hf_tokenizer: PreTrainedTokenizerFast = AutoTokenizer.from_pretrained(
            self.config.draft.infer.model_name,
        )
        return Tokenizer(tokenizer=hf_tokenizer)

    @cached_property
    def speculative_decoder(self) -> SpeculativeDecoder:
        """The initialized speculative decoder instance."""
        return make_speculative_decoder(config=self.config)

    @cached_property
    def autoregressive_decoder(self) -> AutoregressiveDecoder:
        """The initialized autoregressive decoder instance."""
        return make_autoregressive_decoder(config=self.config)
