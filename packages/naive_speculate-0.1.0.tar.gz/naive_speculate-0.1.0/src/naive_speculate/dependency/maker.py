"""Provide factory functions to conduct creation of various components."""

# ruff: noqa: PLC0415

from typing import TYPE_CHECKING

from naive_speculate.autoregress.decoder import AutoregressiveDecoder
from naive_speculate.config.registry import InferencerType, KVCacheType, LanguageModelType
from naive_speculate.speculate.decoder import SpeculativeDecoder
from naive_speculate.speculate.drafter import Drafter
from naive_speculate.speculate.scorer import Scorer

if TYPE_CHECKING:
    from naive_speculate.config.internal import SpeculateConfig
    from naive_speculate.infer import Inferencer, KVCache, LanguageModel

__all__ = [
    "make_autoregressive_decoder",
    "make_drafter",
    "make_inferencer",
    "make_kvcache",
    "make_lm",
    "make_scorer",
    "make_speculative_decoder",
]


def make_lm(model_name: str) -> LanguageModel:
    """Return a `LanguageModel` instance based on the provided model name."""
    family_name = model_name.split("/", maxsplit=1)[0]
    match LanguageModelType(family_name):
        case LanguageModelType.QWEN:
            import naive_speculate.infer.lm.qwen3 as impl_module

    lm_class = impl_module.LanguageModelImpl
    return lm_class(model_name=model_name)


def make_inferencer(language_model: LanguageModel, inferencer_type: InferencerType) -> Inferencer:
    """Return an `Inferencer` instance based on the provided `LanguageModel` and `InferencerType`."""
    match inferencer_type:
        case InferencerType.BASIC:
            import naive_speculate.infer.inferencer.basic as impl_module
        case InferencerType.CHUNKWISE:
            import naive_speculate.infer.inferencer.chunkwise as impl_module

    inferencer_class = impl_module.InferencerImpl
    return inferencer_class(language_model=language_model)


def make_drafter(inferencer: Inferencer) -> Drafter:
    """Return a `Drafter` instance based on the provided `Inferencer`."""
    return Drafter(inferencer=inferencer)


def make_scorer(language_model: LanguageModel) -> Scorer:
    """Return a `Scorer` instance based on the provided `LanguageModel`."""
    return Scorer(language_model=language_model)


def make_kvcache(kvcache_type: KVCacheType) -> KVCache:
    """Return a `KVCache` instance based on the provided `KVCacheType`."""
    match kvcache_type:
        case KVCacheType.DYNAMIC:
            import naive_speculate.infer.kvcache.dynamic as impl_module
        case KVCacheType.DYNAMIC_NO_UPDATE:
            import naive_speculate.infer.kvcache.dynamic_no_update as impl_module

    kvcache_class = impl_module.KVCacheImpl
    return kvcache_class()


def make_speculative_decoder(config: SpeculateConfig) -> SpeculativeDecoder:
    """Return a `SpeculativeDecoder` instance based on the provided `SpeculateConfig`."""
    draft_lm = make_lm(model_name=config.draft.infer.model_name)
    draft_inferencer = make_inferencer(
        language_model=draft_lm,
        inferencer_type=config.draft.infer.inferencer_type,
    )
    drafter = make_drafter(inferencer=draft_inferencer)
    drafter_kvcache = make_kvcache(kvcache_type=config.draft.infer.kvcache_type)

    score_lm = make_lm(model_name=config.verify.infer.model_name)
    scorer = make_scorer(language_model=score_lm)
    scorer_kvcache = make_kvcache(kvcache_type=config.verify.infer.kvcache_type)

    return SpeculativeDecoder(
        drafter=drafter,
        scorer=scorer,
        drafter_kvcache=drafter_kvcache,
        scorer_kvcache=scorer_kvcache,
    )


def make_autoregressive_decoder(config: SpeculateConfig) -> AutoregressiveDecoder:
    """Return an `AutoregressiveDecoder` instance based on the provided `SpeculateConfig`."""
    lm = make_lm(model_name=config.verify.infer.model_name)
    inferencer = make_inferencer(
        language_model=lm,
        inferencer_type=config.verify.infer.inferencer_type,
    )
    drafter = make_drafter(inferencer=inferencer)
    kvcache = make_kvcache(kvcache_type=config.verify.infer.kvcache_type)

    return AutoregressiveDecoder(drafter=drafter, drafter_kvcache=kvcache)
