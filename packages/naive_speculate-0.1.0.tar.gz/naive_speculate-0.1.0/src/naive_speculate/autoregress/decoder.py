"""Define `AutoregressiveDecoder`, performing autoregressive decoding using a drafter."""

from typing import TYPE_CHECKING, NamedTuple

if TYPE_CHECKING:
    import torch

    from naive_speculate.config.strategy import SampleStrategy
    from naive_speculate.infer.interface import KVCache
    from naive_speculate.speculate.drafter import Drafter

__all__ = ["AutoregressiveDecodeOut", "AutoregressiveDecoder"]


class AutoregressiveDecodeOut(NamedTuple):
    """The output of `AutoregressiveDecoder.decode` method.

    Attributes:
        token_ids: The generated token ids. Shape: `[batch_size, num_generated_tokens]`,
            where `num_generated_tokens <= max_new_tokens`.
    """

    token_ids: torch.Tensor


class AutoregressiveDecoder:
    """Performs autoregressive decoding.

    AutoregressiveDecoder essentially wraps `Drafter`, since `Drafter` already
    implements the functionality of autoregressive decoding.

    Attributes:
        drafter (Drafter): The drafter used for generating tokens.
        drafter_kvcache (KVCache): The key-value cache for the drafter.
    """

    drafter: Drafter
    drafter_kvcache: KVCache

    def __init__(self, drafter: Drafter, drafter_kvcache: KVCache) -> None:
        self.drafter = drafter
        self.drafter_kvcache = drafter_kvcache

    def decode(
        self,
        query_token_ids: torch.Tensor,
        max_new_tokens: int,
        sample_strategy: SampleStrategy,
    ) -> AutoregressiveDecodeOut:
        """Perform autoregressive decoding using underlying `Drafter`.

        Currently supports `batch_size=1` only.

        Decoding stops when `<eos>` is generated, or when the number of returned tokens
        would exceed `max_new_tokens`.

        Args:
            query_token_ids (torch.Tensor): Ids of the query tokens. Shape: `[batch_size, num_query_tokens]`.
            max_new_tokens (int): The maximum number of new tokens to generate.
            sample_strategy (SampleStrategy): Sampling strategy for drafting tokens.

        Returns:
            AutoregressiveDecodeOut: The output of autoregressive decoding.
        """
        draft_out = self.drafter.draft(
            query_token_ids=query_token_ids,
            kv_cache=self.drafter_kvcache,
            num_draft_tokens=max_new_tokens,
            sample_strategy=sample_strategy,
        )

        return AutoregressiveDecodeOut(token_ids=draft_out.token_ids)
