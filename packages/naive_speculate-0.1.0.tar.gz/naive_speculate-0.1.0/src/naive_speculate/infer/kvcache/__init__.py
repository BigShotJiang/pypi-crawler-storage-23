"""Implementations for `KVCache` protocol."""
