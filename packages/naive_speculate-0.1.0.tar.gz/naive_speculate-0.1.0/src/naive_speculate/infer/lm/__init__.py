"""Implementations for `LanguageModel` protocol."""
