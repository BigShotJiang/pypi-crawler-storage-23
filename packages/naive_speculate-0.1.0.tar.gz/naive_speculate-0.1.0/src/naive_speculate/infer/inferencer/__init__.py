"""Implementations for `Inferencer` protocol."""
