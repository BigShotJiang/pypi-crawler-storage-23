"""Speculative decoding implementations based on Drafter and Scorer interfaces.

Exports:
    SpeculativeDecoder: Entry class for speculative decoding.
    SpeculativeDecodeOut: The output of `SpeculativeDecoder.decode` method.
"""

from .decoder import SpeculativeDecodeOut, SpeculativeDecoder

__all__ = ["SpeculativeDecodeOut", "SpeculativeDecoder"]
