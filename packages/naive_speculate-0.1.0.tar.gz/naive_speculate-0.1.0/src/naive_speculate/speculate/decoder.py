"""Define `SpeculativeDecoder`, performing speculative decoding using a drafter and a scorer."""

from typing import TYPE_CHECKING, NamedTuple

import torch

from naive_speculate.config.strategy import VerifyStrategy

from .utils import greedy_match, speculative_sampling

if TYPE_CHECKING:
    from naive_speculate.config.strategy import SampleStrategy
    from naive_speculate.infer import KVCache

    from .drafter import Drafter
    from .scorer import Scorer

__all__ = ["SpeculativeDecodeOut", "SpeculativeDecoder"]


class SpeculativeDecodeOut(NamedTuple):
    """The output of `SpeculativeDecoder.speculative_decode` method.

    Attributes:
        token_ids: The generated token ids. Shape: `[batch_size, num_generated_tokens]`,
            where `num_generated_tokens <= num_draft_tokens + 1`.
        num_accepted_tokens: The number of accepted drafted tokens.
    """

    token_ids: torch.Tensor
    num_accepted_tokens: int


class SpeculativeDecoder:
    """Performs speculative decoding using a drafter and a scorer.

    Attributes:
        drafter (Drafter): The drafter used for drafting tokens.
        scorer (Scorer): The scorer used for scoring tokens.
        drafter_kvcache (KVCache): The key-value cache used for the drafter.
        scorer_kvcache (KVCache): The key-value cache used for the scorer.
    """

    drafter: Drafter
    scorer: Scorer
    drafter_kvcache: KVCache
    scorer_kvcache: KVCache

    def __init__(
        self,
        drafter: Drafter,
        scorer: Scorer,
        drafter_kvcache: KVCache,
        scorer_kvcache: KVCache,
    ) -> None:
        self.drafter = drafter
        self.scorer = scorer
        self.drafter_kvcache = drafter_kvcache
        self.scorer_kvcache = scorer_kvcache

    def decode(
        self,
        query_token_ids: torch.Tensor,
        num_draft_tokens: int,
        sample_strategy: SampleStrategy,
        verify_strategy: VerifyStrategy,
    ) -> SpeculativeDecodeOut:
        """Perform speculative decoding.

        Currently supports `batch_size=1` only.

        Decoding stops when `<eos>` is generated, or when the number of returned tokens
        (accepted draft tokens plus one resampled token) would exceed `num_draft_tokens + 1`.

        `sample_strategy` defines how the drafter samples draft tokens.
        `verify_strategy` defines how the drafted tokens are verified.

        The `GREEDY_MATCH` verification strategy is legal to combine with any drafter sampling strategy.

        However, to achieve real speedup, it is suggested to use `SPECULATIVE_SAMPLING` verification
        strategy in favor of `GREEDY_MATCH`, because the latter normally leads to more rejections,
        since it requires exact matches between the drafter's greedy tokens and the target model's greedy tokens.

        Also, greedy decoding normally performs worse than random sampling decoding in terms of generation quality.

        The `SPECULATIVE_SAMPLING` verification strategy is legal to combine with any drafter
        sampling strategy in definition, as long as the sampling strategy defines a valid proposal distribution.

        However, to achieve real speedup, it is suggested to **not** use `SPECULATIVE_SAMPLING` verification with
        drafter greedy sampling.

        The reason is: If the drafter uses greedy sampling, speculative sampling for verification will
        not be a legal option, because in this case the drafter's distribution is always a delta distribution,
        which makes the acceptance probability ill-defined. In this case, rejection always happens for
        each draft token, and the speculative decoding degenerates to modified auto-regressive decoding,
        with the drafted token being removed from the vocabulary in sampling.

        For consecutive call of speculative decoding, special attention should be paid to the drafter's kvcache,
        and the input query token for draft in the next round.
        Here we discuss it in three situation:
        1. If no token is accepted
            The scorer and the drafter both cached the input query tokens. In next round, the drafter's input
            query token is the newly resampled token by speculative decoder.
        2. If all tokens are accepted
            The scorer's kvcache will be one token longer than the drafter's kvcache, because the drafter does
            not have the last drafted token's kvcache. In next round, the drafter's input query tokens should
            be the concatenation of the last drafted token and the newly sampled token by speculative decoder.
        3. if some but not all tokens are accepted
            For example, one token is accepted, the length of scorer's and drafter's kvcache is consistent. In
            the next round, the drafter's input query token is the newly resampled token by speculative decoder.

        Therefore, the caller should pay attention to the `num_accepted_tokens` field in the output of `decode` method,
        and construct the right input query token for the next round accordingly, otherwise the kvcache of the drafter
        will be wrong, which may lead to wrong generation results or even errors.

        Args:
            query_token_ids (torch.Tensor): Ids of the query tokens. Shape: `[batch_size, num_query_tokens]`.
            num_draft_tokens (int): Number of tokens to draft.
            sample_strategy (SampleStrategy): Sampling strategy for drafting tokens.
            verify_strategy (VerifyStrategy): Verification strategy for drafted tokens.

        Returns:
            SpeculativeDecodeOut: Include generated token ids and number of accepted drafted tokens.
        """
        # 1. Draft
        draft_out = self.drafter.draft(
            query_token_ids=query_token_ids,
            kv_cache=self.drafter_kvcache,
            num_draft_tokens=num_draft_tokens,
            sample_strategy=sample_strategy,
        )

        # 2. Score
        context_token_ids = torch.cat([query_token_ids, draft_out.token_ids], dim=1)
        score_out = self.scorer.score(
            query_token_ids=context_token_ids, kv_cache=self.scorer_kvcache
        )

        num_drafted_tokens = draft_out.token_ids.size(1)
        token_scores = score_out.token_logits[:, -(num_drafted_tokens + 1) :, :]

        # 3. Verify (accept and optional resample)
        proposal_dists = torch.softmax(draft_out.token_logits, dim=-1)
        target_dists = torch.softmax(token_scores, dim=-1)

        match verify_strategy:
            case VerifyStrategy.SPECULATIVE_SAMPLING:
                rejected_idx, resampled_token = speculative_sampling(
                    target_dists=target_dists.squeeze(0),
                    proposal_dists=proposal_dists.squeeze(0),
                    candidate_tokens=draft_out.token_ids.squeeze(0),
                )
            case VerifyStrategy.GREEDY_MATCH:
                rejected_idx, resampled_token = greedy_match(
                    target_dists=target_dists.squeeze(0),
                    candidate_tokens=draft_out.token_ids.squeeze(0),
                )

        # 4. Crop
        num_tokens_accept = int(rejected_idx.item())
        num_tokens_crop = num_drafted_tokens - num_tokens_accept
        if num_tokens_crop == 0:
            # If all accept, align the kvcache length of drafter and scorer
            # This do make next scorer prefill re-process one additional token,
            # but makes the implementation simpler, and the efficiency loss should be negligible.
            self.scorer_kvcache.crop(1)
        else:
            self.drafter_kvcache.crop(num_tokens_crop - 1)
            self.scorer_kvcache.crop(num_tokens_crop)

        # 5. Output
        accepted_tokens = draft_out.token_ids[:, :num_tokens_accept]
        generated_tokens = torch.cat([accepted_tokens, resampled_token.view(1, 1)], dim=1)

        return SpeculativeDecodeOut(
            token_ids=generated_tokens, num_accepted_tokens=num_tokens_accept
        )
