from typing import TYPE_CHECKING

import pytest
import torch

from naive_speculate.config.strategy import SampleStrategy, VerifyStrategy

if TYPE_CHECKING:
    from naive_speculate.speculate.drafter import DraftOut

    from .scenario import DraftScenario, SpeculativeDecodeScenario

__all__ = ["DraftContractTests", "SpeculativeDecodeContractTests"]


class DraftContractTests:
    """Contract tests for `Drafter` implementations.

    Essentially, `Drafter` is a normally implemented token decoder, as compared
    to the speculative decoder.
    """

    def draft_test(
        self,
        scenario: DraftScenario,
        num_draft_tokens: int,
        sample_strategy: SampleStrategy,
    ) -> None:
        drafter = scenario.drafter
        kv_cache = scenario.kv_cache

        def test_one_round(query_token_ids: torch.Tensor) -> DraftOut:
            cache_len_before = kv_cache.get_num_tokens()
            draft_out = drafter.draft(
                query_token_ids=query_token_ids,
                kv_cache=kv_cache,
                num_draft_tokens=num_draft_tokens,
                sample_strategy=sample_strategy,
            )
            cache_len_after = kv_cache.get_num_tokens()

            num_query_tokens = query_token_ids.size(1)
            num_generated_tokens = draft_out.token_ids.size(1)

            assert num_generated_tokens <= num_draft_tokens
            assert cache_len_after - cache_len_before == num_generated_tokens + num_query_tokens - 1
            if sample_strategy == SampleStrategy.GREEDY:
                greedy_token_ids = torch.argmax(draft_out.token_logits, dim=-1)
                assert torch.equal(greedy_token_ids, draft_out.token_ids)

            return draft_out

        query_token_ids = scenario.query_token_ids
        for _ in range(3):
            draft_out = test_one_round(query_token_ids=query_token_ids)
            query_token_ids = draft_out.token_ids[:, -1:]


class SpeculativeDecodeContractTests:
    """Contract tests for `SpeculativeDecoder` implementations."""

    @pytest.fixture
    def verify_strategy(self) -> VerifyStrategy:
        return VerifyStrategy.GREEDY_MATCH  # only test greedy match for now

    def speculative_decode_test(
        self,
        scenario: SpeculativeDecodeScenario,
        num_draft_tokens: int,
        sample_strategy: SampleStrategy,
        verify_strategy: VerifyStrategy,
        num_tokens_to_generate: int,
    ) -> None:
        speculative_decoder = scenario.speculative_decoder
        autoregressive_decoder = scenario.autoregressive_decoder

        def speculative_decode() -> torch.Tensor:
            num_generated_tokens = 0
            generated_token_ids = []
            query_token_ids = scenario.query_token_ids

            while num_generated_tokens < num_tokens_to_generate:
                out = speculative_decoder.decode(
                    query_token_ids=query_token_ids,
                    num_draft_tokens=num_draft_tokens,
                    sample_strategy=sample_strategy,
                    verify_strategy=verify_strategy,
                )
                num_generated_tokens += out.token_ids.size(1)
                generated_token_ids.append(out.token_ids)
                is_all_accepted = out.num_accepted_tokens == num_draft_tokens
                query_token_ids = (
                    out.token_ids[:, -2:] if is_all_accepted else out.token_ids[:, -1:]
                )

            return torch.cat(generated_token_ids, dim=1)

        def autoregressive_decode(max_new_tokens: int) -> torch.Tensor:
            query_token_ids = scenario.query_token_ids
            out = autoregressive_decoder.decode(
                query_token_ids=query_token_ids,
                max_new_tokens=max_new_tokens,
                sample_strategy=SampleStrategy.GREEDY,
            )
            return out.token_ids

        result_tokens = speculative_decode()
        expected_tokens = autoregressive_decode(num_draft_tokens)
        len_prefix = min(result_tokens.size(1), expected_tokens.size(1))
        assert torch.equal(result_tokens[:, :len_prefix], expected_tokens[:, :len_prefix])
