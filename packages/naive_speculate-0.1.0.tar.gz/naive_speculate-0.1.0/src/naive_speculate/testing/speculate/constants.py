from typing import NamedTuple

from naive_speculate.testing.infer.lm.fake import FakeLMConfig

__all__ = ["LM_CONFIGS", "NUM_DRAFT_TOKENS", "QUERY_SHAPES", "QueryShape"]

_DRAFT_LM_CONFIGS = (
    FakeLMConfig(eos_token_id=0, vocab_size=2, num_layers=1, num_heads=2, embed_dim=4),
    FakeLMConfig(eos_token_id=1, vocab_size=5, num_layers=2, num_heads=4, embed_dim=8),
    FakeLMConfig(eos_token_id=2, vocab_size=8, num_layers=3, num_heads=6, embed_dim=12),
)

_SCORE_LM_CONFIGS = (
    FakeLMConfig(eos_token_id=0, vocab_size=2, num_layers=2, num_heads=2, embed_dim=4),
    FakeLMConfig(eos_token_id=1, vocab_size=5, num_layers=4, num_heads=4, embed_dim=8),
    FakeLMConfig(eos_token_id=2, vocab_size=8, num_layers=6, num_heads=6, embed_dim=12),
)

LM_CONFIGS = tuple(zip(_DRAFT_LM_CONFIGS, _SCORE_LM_CONFIGS, strict=True))


class QueryShape(NamedTuple):
    batch_size: int
    num_query_tokens: int


QUERY_SHAPES = (
    QueryShape(batch_size=1, num_query_tokens=9),
    QueryShape(batch_size=1, num_query_tokens=6),
    QueryShape(batch_size=1, num_query_tokens=3),
)

NUM_DRAFT_TOKENS = (1, 3, 6)
