from typing import TYPE_CHECKING, NamedTuple

import pytest
import torch

from naive_speculate.autoregress.decoder import AutoregressiveDecoder
from naive_speculate.infer.inferencer.basic import BasicInferencer
from naive_speculate.infer.kvcache.dynamic import DynamicCache
from naive_speculate.speculate.decoder import SpeculativeDecoder
from naive_speculate.speculate.drafter import Drafter
from naive_speculate.speculate.scorer import Scorer
from naive_speculate.testing.infer.lm.fake import FakeLanguageModel, FakeLMConfig

from .constants import LM_CONFIGS, QUERY_SHAPES

if TYPE_CHECKING:
    from .constants import QueryShape

__all__ = [
    "DraftScenario",
    "DraftScenarioFixtures",
    "SpeculativeDecodeScenario",
    "SpeculativeDecodeScenarioFixtures",
]


class DraftScenario(NamedTuple):
    query_token_ids: torch.Tensor
    drafter: Drafter
    kv_cache: DynamicCache


class DraftScenarioFixtures:
    @pytest.fixture(params=QUERY_SHAPES)
    def query_shape(self, request: pytest.FixtureRequest) -> QueryShape:
        return request.param

    @pytest.fixture(params=LM_CONFIGS)
    def lm_config(self, request: pytest.FixtureRequest) -> FakeLMConfig:
        draft_lm_config, _ = request.param
        return draft_lm_config

    @pytest.fixture
    def scenario(self, query_shape: QueryShape, lm_config: FakeLMConfig) -> DraftScenario:
        query_token_ids = torch.randint(low=0, high=lm_config.vocab_size, size=query_shape)

        lm = FakeLanguageModel(config=lm_config)
        inferencer = BasicInferencer(language_model=lm)
        drafter = Drafter(inferencer=inferencer)
        kv_cache = DynamicCache()

        return DraftScenario(query_token_ids=query_token_ids, drafter=drafter, kv_cache=kv_cache)


class SpeculativeDecodeScenario(NamedTuple):
    query_token_ids: torch.Tensor
    speculative_decoder: SpeculativeDecoder
    autoregressive_decoder: AutoregressiveDecoder


class SpeculativeDecodeScenarioFixtures:
    @pytest.fixture(params=QUERY_SHAPES)
    def query_shape(self, request: pytest.FixtureRequest) -> QueryShape:
        return request.param

    @pytest.fixture(params=LM_CONFIGS)
    def lm_configs(self, request: pytest.FixtureRequest) -> tuple[FakeLMConfig, FakeLMConfig]:
        return request.param

    @pytest.fixture
    def scenario(
        self, query_shape: QueryShape, lm_configs: tuple[FakeLMConfig, FakeLMConfig]
    ) -> SpeculativeDecodeScenario:
        draft_lm_config, score_lm_config = lm_configs
        assert draft_lm_config.vocab_size == score_lm_config.vocab_size
        assert draft_lm_config.eos_token_id == score_lm_config.eos_token_id

        query_token_ids = torch.randint(low=0, high=draft_lm_config.vocab_size, size=query_shape)

        draft_lm = FakeLanguageModel(config=draft_lm_config)
        draft_inferencer = BasicInferencer(language_model=draft_lm)
        drafter = Drafter(inferencer=draft_inferencer)

        score_lm = FakeLanguageModel(config=score_lm_config)
        scorer = Scorer(language_model=score_lm)

        speculative_decoder = SpeculativeDecoder(
            drafter=drafter,
            scorer=scorer,
            drafter_kvcache=DynamicCache(),
            scorer_kvcache=DynamicCache(),
        )

        verify_inferencer = BasicInferencer(language_model=score_lm)
        verify_drafter = Drafter(inferencer=verify_inferencer)
        autoregressive_decoder = AutoregressiveDecoder(
            drafter=verify_drafter, drafter_kvcache=DynamicCache()
        )

        return SpeculativeDecodeScenario(
            query_token_ids=query_token_ids,
            speculative_decoder=speculative_decoder,
            autoregressive_decoder=autoregressive_decoder,
        )
