"""Provide `FakeLanguageModel` and its configuration `FakeLMConfig`."""

from typing import TYPE_CHECKING, NamedTuple, override

from naive_speculate.infer import LanguageModel

from .transformer import Transformer

if TYPE_CHECKING:
    import torch

    from naive_speculate.infer import KVCache

__all__ = ["FakeLMConfig", "FakeLanguageModel"]


class FakeLMConfig(NamedTuple):
    """Configuration parameters for `FakeLanguageModel`.

    Attributes:
        eos_token_id (int): End-of-sequence token id.
        vocab_size (int): Number of tokens in the vocabulary.
        num_layers (int): Number of transformer layers.
        num_heads (int): Number of attention heads for multi-head attention.
        embed_dim (int): Dimension of the token embeddings.
    """

    eos_token_id: int
    vocab_size: int
    embed_dim: int
    num_heads: int
    num_layers: int


class FakeLanguageModel(LanguageModel):
    """Lightweight fake implementation of `LanguageModel`.

    Contains minimal logic to simulate the behavior of a real language model.

    Attributes:
        config (FakeLMConfig): Configuration parameters for the fake language model.
        transformer (Transformer): Underlying transformer model to generate token logits.
    """

    config: FakeLMConfig
    transformer: Transformer

    def __init__(self, config: FakeLMConfig) -> None:
        self.config = config

        self.transformer = Transformer(
            vocab_size=config.vocab_size,
            num_blocks=config.num_layers,
            embed_dim=config.embed_dim,
            num_heads=config.num_heads,
        )

    @property
    @override
    def eos_token_id(self) -> int:
        return self.config.eos_token_id

    @override
    def forward(self, query_token_ids: torch.Tensor, kv_cache: KVCache) -> torch.Tensor:
        """Perform a forward pass through the fake language model."""
        return self.transformer(query_token_ids, kv_cache)
