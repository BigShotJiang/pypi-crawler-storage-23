"""Define `InferenceScenario` and `InferenceScenarioFixtures` for environment setup of inference tests."""

from typing import TYPE_CHECKING, NamedTuple

import pytest
import torch

from naive_speculate.infer.kvcache.dynamic import DynamicCache
from naive_speculate.testing.infer.lm.fake import FakeLanguageModel

from .constants import FAKE_LM_CONFIGS, QUERY_SHAPES

if TYPE_CHECKING:
    from naive_speculate.testing.infer.lm.fake import FakeLMConfig

    from .constants import QueryShape

__all__ = ["InferenceScenario", "InferenceScenarioFixtures"]


class InferenceScenario(NamedTuple):
    query_token_ids: torch.Tensor
    fake_lm: FakeLanguageModel
    kv_cache: DynamicCache


class InferenceScenarioFixtures:
    @pytest.fixture(params=QUERY_SHAPES)
    def query_shape(self, request: pytest.FixtureRequest) -> QueryShape:
        return request.param

    @pytest.fixture(params=FAKE_LM_CONFIGS)
    def lm_config(self, request: pytest.FixtureRequest) -> FakeLMConfig:
        return request.param

    @pytest.fixture
    def scenario(self, query_shape: QueryShape, lm_config: FakeLMConfig) -> InferenceScenario:
        query_token_ids = torch.randint(low=0, high=lm_config.vocab_size, size=query_shape)
        fake_lm = FakeLanguageModel(config=lm_config)
        kv_cache = DynamicCache()

        return InferenceScenario(
            query_token_ids=query_token_ids, fake_lm=fake_lm, kv_cache=kv_cache
        )
