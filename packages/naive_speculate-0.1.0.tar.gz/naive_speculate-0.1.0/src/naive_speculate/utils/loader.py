import json
import tomllib
from pathlib import Path
from typing import Any

__all__ = ["load_config", "load_context"]


def load_config(config_path: str) -> dict[str, Any]:
    """Load configuration from specified file path."""
    with Path(config_path).open("rb") as f:
        return tomllib.load(f)


def load_context(context_path: str) -> list[dict[str, str]]:
    """Load context from specified file path."""
    with Path(context_path).open("r", encoding="utf-8") as f:
        return json.load(f)
