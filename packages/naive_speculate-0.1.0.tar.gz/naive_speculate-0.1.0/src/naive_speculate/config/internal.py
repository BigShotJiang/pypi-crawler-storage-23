"""Framework facing interface, defining internal configuration options for dependency manager."""

from typing import TYPE_CHECKING

from pydantic import BaseModel

from naive_speculate.config.strategy import SampleStrategy, VerifyStrategy  # noqa: TC001

from .registry import InferencerType, KVCacheType

if TYPE_CHECKING:
    from .external import UserSpeculateConfig

__all__ = [
    "DraftConfig",
    "InferenceConfig",
    "SpeculateConfig",
    "VerifyConfig",
    "internalize_config",
]


class InferenceConfig(BaseModel):
    """Configuration for assembling an inferencer.

    Attributes:
        model_name (str): HuggingFace model name.
        kvcache_type (KVCacheType): The type of key-value cache to be used.
        inferencer_type (InferencerType): The type of inferencer to be used.
    """

    model_name: str
    kvcache_type: KVCacheType
    inferencer_type: InferencerType


class DraftConfig(BaseModel):
    """Configuration for setting up a drafter.

    Attributes:
        sample_strategy (SampleStrategy): The sampling strategy for drafting.
        num_draft_tokens (int): Number of tokens to draft in each iteration.
        infer (InferenceConfig): Configuration about inference.
    """

    sample_strategy: SampleStrategy
    num_draft_tokens: int
    infer: InferenceConfig


class VerifyConfig(BaseModel):
    """Configuration for setting up a verifier.

    Attributes:
        verify_strategy (VerifyStrategy): The verification strategy.
        infer (InferenceConfig): Configuration about inference.
    """

    verify_strategy: VerifyStrategy
    infer: InferenceConfig


class SpeculateConfig(BaseModel):
    """Configuration for setting up a speculative decoder.

    Attributes:
        draft (DraftConfig): Configuration for the drafter.
        verify (VerifyConfig): Configuration for the verifier.
    """

    draft: DraftConfig
    verify: VerifyConfig


def internalize_config(user_config: UserSpeculateConfig) -> SpeculateConfig:
    """Translate external user specified configuration into `SpeculateConfig`.

    Args:
        user_config (UserSpeculateConfig): User specified configuration.

    Returns:
        SpeculateConfig: Specific configuration for internal use.
    """

    def make_infer_config(model_name: str) -> InferenceConfig:
        return InferenceConfig(
            model_name=model_name,
            kvcache_type=KVCacheType.DYNAMIC_NO_UPDATE,  # hardcoded for now
            inferencer_type=InferencerType.BASIC,  # hardcoded for now
        )

    draft_config = DraftConfig(
        sample_strategy=user_config.draft.sample_strategy,
        num_draft_tokens=user_config.draft.num_draft_tokens,
        infer=make_infer_config(user_config.draft.model_name),
    )

    verify_config = VerifyConfig(
        verify_strategy=user_config.verify.verify_strategy,
        infer=make_infer_config(user_config.verify.model_name),
    )

    return SpeculateConfig(draft=draft_config, verify=verify_config)
