import argparse
import json
import logging
from typing import TYPE_CHECKING

import torch

from .config.external import UserSpeculateConfig
from .config.internal import internalize_config
from .dependency import DependencyContainer
from .utils.loader import load_config, load_context
from .utils.timer import Timer

if TYPE_CHECKING:
    from naive_speculate.autoregress import AutoregressiveDecoder
    from naive_speculate.config.internal import SpeculateConfig
    from naive_speculate.speculate import SpeculativeDecoder
    from naive_speculate.utils.tokenizer import Tokenizer

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="A naive implementation of speculative decoding.")
    parser.add_argument("config_file", type=str, help="Path to the configuration file.")
    parser.add_argument("context_file", type=str, help="Path to the context file.")
    parser.add_argument(
        "-r",
        "--rounds",
        type=int,
        default=10,
        help="Number of rounds to run the speculative decoding step.",
    )
    parser.add_argument(
        "--verbose", action="store_true", help="Whether to print detailed logs during decoding."
    )

    return parser.parse_args()


def get_config(config_path: str) -> SpeculateConfig:
    user_config = UserSpeculateConfig.from_dict(load_config(config_path=config_path))
    speculate_config = internalize_config(user_config=user_config)

    logger.info("Loaded configuration from %s", config_path)
    logger.info("Configuration:\n%s", speculate_config.model_dump_json(indent=2))
    return speculate_config


def get_context(context_path: str) -> list[dict[str, str]]:
    context = load_context(context_path=context_path)

    logger.info("Loaded context from %s", context_path)
    logger.info("Context is:\n%s", json.dumps(context, indent=2))
    return context


def get_input(tokenizer: Tokenizer, context: list[dict[str, str]]) -> tuple[str, torch.Tensor]:
    input_text = tokenizer.apply_chat_template(messages=context)
    input_ids, _attention_mask = tokenizer.tokenize(input_texts=[input_text])
    return input_text, input_ids


def speculative_decode(
    speculative_decoder: SpeculativeDecoder,
    speculate_config: SpeculateConfig,
    input_ids: torch.Tensor,
    rounds: int,
) -> torch.Tensor:
    num_draft_tokens = speculate_config.draft.num_draft_tokens
    sample_strategy = speculate_config.draft.sample_strategy
    verify_strategy = speculate_config.verify.verify_strategy

    num_total_accepted = 0
    query_token_ids = input_ids
    output_ids = torch.empty(0, dtype=torch.long)

    logger.info("Starting speculative decoding for %d rounds...", rounds)

    with Timer(name="Speculative Decoding") as timer:
        for idx in range(rounds):
            logger.debug("Round %d/%d", idx + 1, rounds)

            decode_out = speculative_decoder.decode(
                query_token_ids=query_token_ids,
                num_draft_tokens=num_draft_tokens,
                sample_strategy=sample_strategy,
                verify_strategy=verify_strategy,
            )
            output_ids = torch.cat([output_ids, decode_out.token_ids], dim=1)
            num_total_accepted += decode_out.num_accepted_tokens

            is_all_accepted = decode_out.num_accepted_tokens == num_draft_tokens
            query_token_ids = output_ids[:, -2:] if is_all_accepted else output_ids[:, -1:]

            logger.debug("Round %d generated token ids: %s", idx + 1, decode_out.token_ids)

    logger.info("Finished speculative decoding. Time taken: %.2f seconds", timer.elapsed)

    num_total_drafted = rounds * num_draft_tokens
    acceptance_rate = num_total_accepted / num_total_drafted
    logger.info(
        "Total drafted tokens: %d, Total accepted tokens: %d, Acceptance rate: %.2f",
        num_total_drafted,
        num_total_accepted,
        acceptance_rate,
    )

    return output_ids


def autoregressive_decode(
    autoregressive_decoder: AutoregressiveDecoder,
    speculate_config: SpeculateConfig,
    input_ids: torch.Tensor,
    max_new_tokens: int,
) -> torch.Tensor:
    sample_strategy = speculate_config.draft.sample_strategy

    output_ids = torch.empty(0, dtype=torch.long)

    logger.info("Starting autoregressive decoding, with max_new_tokens=%d...", max_new_tokens)

    with Timer(name="Autoregressive Decoding") as timer:
        output_ids = autoregressive_decoder.decode(
            query_token_ids=input_ids,
            max_new_tokens=max_new_tokens,
            sample_strategy=sample_strategy,
        ).token_ids

    logger.info("Finished autoregressive decoding. Time taken: %.2f seconds", timer.elapsed)

    return output_ids


def main() -> int:
    args = parse_args()
    if args.verbose:
        logger.setLevel(logging.DEBUG)

    speculate_config = get_config(config_path=args.config_file)
    context = get_context(context_path=args.context_file)

    # Initialize
    logger.info("Initializing dependencies...")

    dependencies = DependencyContainer(config=speculate_config)
    tokenizer = dependencies.tokenizer
    speculative_decoder = dependencies.speculative_decoder
    autoregressive_decoder = dependencies.autoregressive_decoder

    logger.info("Initialized dependencies based on the loaded configuration.")

    # Tokenize
    logger.info("Tokenizing input context...")

    input_text, input_ids = get_input(tokenizer=tokenizer, context=context)

    logger.info("Tokenized input ids: %s", input_ids)
    logger.info("Input text after applying chat template: %s", input_text)

    # Speculative Decode
    output_ids = speculative_decode(
        speculative_decoder=speculative_decoder,
        speculate_config=speculate_config,
        input_ids=input_ids,
        rounds=args.rounds,
    )
    logger.info("The number of generated tokens is %d", output_ids.size(1))
    logger.info("The detokenized output is:\n%s", tokenizer.detokenize(output_ids)[0])

    # Autoregressive Decode
    output_ids = autoregressive_decode(
        autoregressive_decoder=autoregressive_decoder,
        speculate_config=speculate_config,
        input_ids=input_ids,
        max_new_tokens=output_ids.size(1),
    )
    logger.info("The number of generated tokens is %d", output_ids.size(1))
    logger.info("The autoregressive output is:\n%s", tokenizer.detokenize(output_ids)[0])

    return 0
