.. _index:
.. include:: ../README.rst


.. toctree::
   :maxdepth: 3
   :caption: Contents

   install
   usage
