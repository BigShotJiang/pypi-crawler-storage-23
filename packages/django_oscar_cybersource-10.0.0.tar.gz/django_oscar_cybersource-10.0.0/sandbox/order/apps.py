from oscar.apps.order import apps


class OrderConfig(apps.OrderConfig):
    name = "sandbox.order"
