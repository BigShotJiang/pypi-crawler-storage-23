from __future__ import annotations

import shutil
from pathlib import Path
from shlex import join
from typing import TYPE_CHECKING, assert_never

import utilities.subprocess
from utilities.constants import FILE_SYSTEM_ROOT, HOME
from utilities.core import (
    Permissions,
    PermissionsLike,
    ReadTextError,
    always_iterable,
    normalize_str,
    read_text,
    to_logger,
    write_text,
)
from utilities.pydantic import extract_secret
from utilities.subprocess import BASH_LS, uv_tool_run_cmd
from utilities.types import MaybeSequenceStr, PathLike, SecretLike

from installer._constants import SHELL

if TYPE_CHECKING:
    from collections.abc import Callable

    from utilities.shellingham import Shell
    from utilities.types import (
        Group,
        MaybeSequenceStr,
        Owner,
        PathLike,
        Retry,
        SecretLike,
    )

    from installer._types import SSH, SSHType


_LOGGER = to_logger(__name__)


##


def ensure_line_or_lines(
    path: PathLike,
    line_or_lines: MaybeSequenceStr,
    /,
    *,
    perms: PermissionsLike | None = None,
    owner: Owner | None = None,
    group: Group | None = None,
) -> None:
    text = normalize_str("\n".join(always_iterable(line_or_lines)))
    try:
        contents = read_text(path)
    except ReadTextError:
        write_text(path, text, perms=perms, owner=owner, group=group)
        return
    if text not in contents:
        with Path(path).open(mode="a") as fh:
            _ = fh.write(f"\n\n{text}")


##


def get_home(*, home: PathLike | None = None) -> Path:
    """Get the home."""
    return HOME if home is None else Path(home)


##


def get_root(*, root: PathLike | None = None) -> Path:
    """Get the file system root."""
    return FILE_SYSTEM_ROOT if root is None else Path(root)


##


def set_up_local_or_ssh(
    app_and_cmd: str | tuple[str, str],
    set_up_local: Callable[[], None],
    ssh_type: SSHType,
    /,
    *ssh_cmds: list[str],
    ssh: SSH | None = None,
    force: bool = False,
    etc: bool = False,
    group: Group | None = None,
    home: PathLike | None = None,
    owner: Owner | None = None,
    path_binaries: PathLike | None = None,
    perms: PermissionsLike | None = None,
    perms_binary: PermissionsLike | None = None,
    perms_config: PermissionsLike | None = None,
    repo: str | None = None,
    root: PathLike | None = None,
    shell: Shell | None = None,
    starship_toml: PathLike | None = None,
    sudo: bool = False,
    token: SecretLike | None = None,
    user: str | None = None,
    retry: Retry | None = None,
) -> None:
    match app_and_cmd:
        case str():
            app = cmd = app_and_cmd
        case str() as app, str() as cmd:
            ...
        case never:
            assert_never(never)
    match ssh, ssh_type:
        case None, _:
            if (shutil.which(app) is None) or force:
                _LOGGER.info("Setting up %r...", app)
                set_up_local()
            else:
                _LOGGER.info("%r is already set up", app)
        case (ssh_user, ssh_hostname), "bash-ls":
            _LOGGER.info("Setting up %r on %r...", app, ssh_hostname)
            if ssh_cmds is None:
                input_ = None
            else:
                input_ = normalize_str("\n".join(map(join, ssh_cmds)))
            utilities.subprocess.ssh(
                ssh_user,
                ssh_hostname,
                *BASH_LS,
                input=input_,
                retry=retry,
                logger=_LOGGER,
            )
        case (ssh_user, ssh_hostname), "uv-tool":
            _LOGGER.info("Setting up %r on %r...", app, ssh_hostname)
            args: list[str] = []
            if etc:
                args.append("--etc")
            if force:
                args.append("--force")
            if group is not None:
                args.extend(["--group", str(group)])
            if home is not None:
                args.extend(["--home", str(home)])
            if owner is not None:
                args.extend(["--owner", str(owner)])
            if path_binaries is not None:
                args.extend(["--path-binaries", str(path_binaries)])
            if perms is not None:
                args.extend(["--perms", str(Permissions.new(perms))])
            if perms_binary is not None:
                args.extend(["--perms-binary", str(Permissions.new(perms_binary))])
            if perms_config is not None:
                args.extend(["--perms-config", str(Permissions.new(perms_config))])
            if repo is not None:
                args.extend(["--repo", repo])
            if root is not None:
                args.extend(["--root", str(root)])
            if shell is not None:
                args.extend(["--shell", shell])
            if starship_toml is not None:
                args.extend(["--starship-toml", str(starship_toml)])
            if sudo:
                args.append("--sudo")
            if token is not None:
                args.extend(["--token", extract_secret(token)])
            if user is not None:
                args.extend(["--user", user])
            utilities.subprocess.ssh(
                ssh_user,
                ssh_hostname,
                *uv_tool_run_cmd(
                    "cli", cmd, *args, from_="dycw-installer[cli]", latest=True
                ),
                retry=retry,
                logger=_LOGGER,
            )
        case never:
            assert_never(never)


##


def set_up_shell_config(
    bash: MaybeSequenceStr,
    zsh: MaybeSequenceStr,
    fish: MaybeSequenceStr,
    /,
    *,
    etc: str | None = None,
    shell: Shell = SHELL,
    home: PathLike | None = None,
    perms: PermissionsLike | None = None,
    owner: Owner | None = None,
    group: Group | None = None,
    root: PathLike | None = None,
) -> None:
    match etc, shell:
        case None, "bash" | "posix" | "sh":
            path = get_home(home=home) / ".bashrc"
            ensure_line_or_lines(path, bash, perms=perms, owner=owner, group=group)
        case None, "zsh":
            path = get_home(home=home) / ".zshrc"
            ensure_line_or_lines(path, zsh, perms=perms, owner=owner, group=group)
        case None, "fish":
            path = get_home(home=home) / ".config/fish/config.fish"
            ensure_line_or_lines(path, fish, perms=perms, owner=owner, group=group)
        case str(), "bash" | "posix" | "sh":
            path = get_root(root=root) / f"etc/profile.d/{etc}.sh"
            lines = ["#!/usr/bin/env sh", "", *always_iterable(bash)]
            text = normalize_str("\n".join(always_iterable(lines)))
            write_text(
                path, text, overwrite=True, perms=perms, owner=owner, group=group
            )
        case str(), _:
            msg = f"Invalid shell for 'etc': {shell!r}"
            raise ValueError(msg)
        case never:
            assert_never(never)


__all__ = ["ensure_line_or_lines", "get_home", "get_root", "set_up_shell_config"]
