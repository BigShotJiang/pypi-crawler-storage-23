from __future__ import annotations

from typing import Literal

type SSH = tuple[str, str]
type SSHType = Literal["bash-ls", "uv-tool"]
type System = Literal["Darwin", "Linux"]


__all__ = ["SSH", "SSHType", "System"]
