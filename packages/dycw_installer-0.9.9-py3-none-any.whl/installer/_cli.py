from __future__ import annotations

from click import group, version_option
from utilities.click import CONTEXT_SETTINGS

from installer import __version__
from installer.cli._apps import (
    make_age_cmd,
    make_apt_cmd,
    make_bat_cmd,
    make_bottom_cmd,
    make_build_essential_cmd,
    make_curl_cmd,
    make_delta_cmd,
    make_direnv_cmd,
    make_docker_cmd,
    make_dust_cmd,
    make_eza_cmd,
    make_fd_cmd,
    make_fzf_cmd,
    make_git_cmd,
    make_jq_cmd,
    make_just_cmd,
    make_neovim_cmd,
    make_pgbackrest_cmd,
    make_postgres_cmd,
    make_pve_cmd,
    make_restic_cmd,
    make_ripgrep_cmd,
    make_rsync_cmd,
    make_ruff_cmd,
    make_sd_cmd,
    make_shellcheck_cmd,
    make_shfmt_cmd,
    make_sops_cmd,
    make_sqlite3_cmd,
    make_starship_cmd,
    make_stylua_cmd,
    make_taplo_cmd,
    make_uv_cmd,
    make_watchexec_cmd,
    make_yq_cmd,
    make_zoxide_cmd,
)
from installer.cli._git_clone import make_git_clone_cmd
from installer.cli._ssh import make_keys_cmd, make_ssh_cmd, make_sshd_cmd

git_clone_cli = make_git_clone_cmd()

set_up_age_cli = make_age_cmd()
set_up_apt_cli = make_apt_cmd()
set_up_bat_cli = make_bat_cmd()
set_up_bottom_cli = make_bottom_cmd()
set_up_build_essential_cli = make_build_essential_cmd()
set_up_curl_cli = make_curl_cmd()
set_up_delta_cli = make_delta_cmd()
set_up_direnv_cli = make_direnv_cmd()
set_up_docker_cli = make_docker_cmd()
set_up_dust_cli = make_dust_cmd()
set_up_eza_cli = make_eza_cmd()
set_up_fd_cli = make_fd_cmd()
set_up_fzf_cli = make_fzf_cmd()
set_up_git_cli = make_git_cmd()
set_up_jq_cli = make_jq_cmd()
set_up_just_cli = make_just_cmd()
set_up_neovim_cli = make_neovim_cmd()
set_up_pgbackrest_cli = make_pgbackrest_cmd()
set_up_postgres_cli = make_postgres_cmd()
set_up_pve_cli = make_pve_cmd()
set_up_restic_cli = make_restic_cmd()
set_up_ripgrep_cli = make_ripgrep_cmd()
set_up_rsync_cli = make_rsync_cmd()
set_up_ruff_cli = make_ruff_cmd()
set_up_sd_cli = make_sd_cmd()
set_up_shellcheck_cli = make_shellcheck_cmd()
set_up_shfmt_cli = make_shfmt_cmd()
set_up_sops_cli = make_sops_cmd()
set_up_sqlite3_cli = make_sqlite3_cmd()
set_up_starship_cli = make_starship_cmd()
set_up_stylua_cli = make_stylua_cmd()
set_up_taplo_cli = make_taplo_cmd()
set_up_uv_cli = make_uv_cmd()
set_up_watchexec_cli = make_watchexec_cmd()
set_up_yq_cli = make_yq_cmd()
set_up_zoxide_cli = make_zoxide_cmd()

set_up_keys_cli = make_keys_cmd()
set_up_ssh_cli = make_ssh_cmd()
set_up_sshd_cli = make_sshd_cmd()


@group(**CONTEXT_SETTINGS)
@version_option(version=__version__)
def group_cli() -> None: ...


_ = make_age_cmd(cli=group_cli.command, name="age")
_ = make_apt_cmd(cli=group_cli.command, name="apt")
_ = make_bat_cmd(cli=group_cli.command, name="bat")
_ = make_bottom_cmd(cli=group_cli.command, name="bottom")
_ = make_build_essential_cmd(cli=group_cli.command, name="build-essential")
_ = make_curl_cmd(cli=group_cli.command, name="curl")
_ = make_delta_cmd(cli=group_cli.command, name="delta")
_ = make_direnv_cmd(cli=group_cli.command, name="direnv")
_ = make_docker_cmd(cli=group_cli.command, name="docker")
_ = make_dust_cmd(cli=group_cli.command, name="dust")
_ = make_eza_cmd(cli=group_cli.command, name="eza")
_ = make_fd_cmd(cli=group_cli.command, name="fd")
_ = make_fzf_cmd(cli=group_cli.command, name="fzf")
_ = make_git_cmd(cli=group_cli.command, name="git")
_ = make_jq_cmd(cli=group_cli.command, name="jq")
_ = make_just_cmd(cli=group_cli.command, name="just")
_ = make_neovim_cmd(cli=group_cli.command, name="neovim")
_ = make_pgbackrest_cmd(cli=group_cli.command, name="pgbackrest")
_ = make_postgres_cmd(cli=group_cli.command, name="postgres")
_ = make_pve_cmd(cli=group_cli.command, name="pve")
_ = make_restic_cmd(cli=group_cli.command, name="restic")
_ = make_ripgrep_cmd(cli=group_cli.command, name="ripgrep")
_ = make_rsync_cmd(cli=group_cli.command, name="rsync")
_ = make_ruff_cmd(cli=group_cli.command, name="ruff")
_ = make_sd_cmd(cli=group_cli.command, name="sd")
_ = make_shellcheck_cmd(cli=group_cli.command, name="shellcheck")
_ = make_shfmt_cmd(cli=group_cli.command, name="shfmt")
_ = make_sops_cmd(cli=group_cli.command, name="sops")
_ = make_sqlite3_cmd(cli=group_cli.command, name="sqlite3")
_ = make_starship_cmd(cli=group_cli.command, name="starship")
_ = make_stylua_cmd(cli=group_cli.command, name="stylua")
_ = make_taplo_cmd(cli=group_cli.command, name="taplo")
_ = make_uv_cmd(cli=group_cli.command, name="uv")
_ = make_watchexec_cmd(cli=group_cli.command, name="watchexec")
_ = make_yq_cmd(cli=group_cli.command, name="yq")
_ = make_zoxide_cmd(cli=group_cli.command, name="zoxide")

_ = make_git_clone_cmd(cli=group_cli.command, name="git-clone")

_ = make_keys_cmd(cli=group_cli.command, name="keys")
_ = make_ssh_cmd(cli=group_cli.command, name="ssh")
_ = make_sshd_cmd(cli=group_cli.command, name="sshd")

__all__ = [
    "git_clone_cli",
    "group_cli",
    "set_up_age_cli",
    "set_up_apt_cli",
    "set_up_bat_cli",
    "set_up_bottom_cli",
    "set_up_build_essential_cli",
    "set_up_curl_cli",
    "set_up_delta_cli",
    "set_up_direnv_cli",
    "set_up_docker_cli",
    "set_up_dust_cli",
    "set_up_eza_cli",
    "set_up_fd_cli",
    "set_up_fzf_cli",
    "set_up_git_cli",
    "set_up_jq_cli",
    "set_up_just_cli",
    "set_up_keys_cli",
    "set_up_neovim_cli",
    "set_up_pgbackrest_cli",
    "set_up_postgres_cli",
    "set_up_pve_cli",
    "set_up_restic_cli",
    "set_up_ripgrep_cli",
    "set_up_rsync_cli",
    "set_up_ruff_cli",
    "set_up_sd_cli",
    "set_up_shellcheck_cli",
    "set_up_shfmt_cli",
    "set_up_sops_cli",
    "set_up_sqlite3_cli",
    "set_up_ssh_cli",
    "set_up_sshd_cli",
    "set_up_starship_cli",
    "set_up_stylua_cli",
    "set_up_taplo_cli",
    "set_up_uv_cli",
    "set_up_watchexec_cli",
    "set_up_yq_cli",
    "set_up_zoxide_cli",
]
