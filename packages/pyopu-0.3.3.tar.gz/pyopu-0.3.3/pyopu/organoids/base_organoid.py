from abc import ABC, abstractmethod

class BaseOrganoid(ABC):
    @abstractmethod
    def run_step(self, dt_ms): pass
