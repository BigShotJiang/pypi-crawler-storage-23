import{e as Me,a as Ae,g as Je,s as We,h as Ge,i as Ke,j as He}from"./index-DJs38nb7.js";import{B as ke,h as Xe,U as Ye,R as we,j as Qe,r as Ze,M as en,o as u,e as f,w as Q,c as h,m as V,a as O,d as H,H as nn,f as sn,g as T,N as an,T as on,u as tn,av as rn,q as g,ay as ln,E as un,t as I,b as j,l as pe,F as ge,G as ve,aw as cn,C as x,ax as X,y as dn,P as Y}from"./index-WzCL-nzV.js";import{b as mn,s as pn}from"./index-Cy4fw_D3.js";var gn=`
    .p-message {
        display: grid;
        grid-template-rows: 1fr;
        border-radius: dt('message.border.radius');
        outline-width: dt('message.border.width');
        outline-style: solid;
    }

    .p-message-content-wrapper {
        min-height: 0;
    }

    .p-message-content {
        display: flex;
        align-items: center;
        padding: dt('message.content.padding');
        gap: dt('message.content.gap');
    }

    .p-message-icon {
        flex-shrink: 0;
    }

    .p-message-close-button {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        margin-inline-start: auto;
        overflow: hidden;
        position: relative;
        width: dt('message.close.button.width');
        height: dt('message.close.button.height');
        border-radius: dt('message.close.button.border.radius');
        background: transparent;
        transition:
            background dt('message.transition.duration'),
            color dt('message.transition.duration'),
            outline-color dt('message.transition.duration'),
            box-shadow dt('message.transition.duration'),
            opacity 0.3s;
        outline-color: transparent;
        color: inherit;
        padding: 0;
        border: none;
        cursor: pointer;
        user-select: none;
    }

    .p-message-close-icon {
        font-size: dt('message.close.icon.size');
        width: dt('message.close.icon.size');
        height: dt('message.close.icon.size');
    }

    .p-message-close-button:focus-visible {
        outline-width: dt('message.close.button.focus.ring.width');
        outline-style: dt('message.close.button.focus.ring.style');
        outline-offset: dt('message.close.button.focus.ring.offset');
    }

    .p-message-info {
        background: dt('message.info.background');
        outline-color: dt('message.info.border.color');
        color: dt('message.info.color');
        box-shadow: dt('message.info.shadow');
    }

    .p-message-info .p-message-close-button:focus-visible {
        outline-color: dt('message.info.close.button.focus.ring.color');
        box-shadow: dt('message.info.close.button.focus.ring.shadow');
    }

    .p-message-info .p-message-close-button:hover {
        background: dt('message.info.close.button.hover.background');
    }

    .p-message-info.p-message-outlined {
        color: dt('message.info.outlined.color');
        outline-color: dt('message.info.outlined.border.color');
    }

    .p-message-info.p-message-simple {
        color: dt('message.info.simple.color');
    }

    .p-message-success {
        background: dt('message.success.background');
        outline-color: dt('message.success.border.color');
        color: dt('message.success.color');
        box-shadow: dt('message.success.shadow');
    }

    .p-message-success .p-message-close-button:focus-visible {
        outline-color: dt('message.success.close.button.focus.ring.color');
        box-shadow: dt('message.success.close.button.focus.ring.shadow');
    }

    .p-message-success .p-message-close-button:hover {
        background: dt('message.success.close.button.hover.background');
    }

    .p-message-success.p-message-outlined {
        color: dt('message.success.outlined.color');
        outline-color: dt('message.success.outlined.border.color');
    }

    .p-message-success.p-message-simple {
        color: dt('message.success.simple.color');
    }

    .p-message-warn {
        background: dt('message.warn.background');
        outline-color: dt('message.warn.border.color');
        color: dt('message.warn.color');
        box-shadow: dt('message.warn.shadow');
    }

    .p-message-warn .p-message-close-button:focus-visible {
        outline-color: dt('message.warn.close.button.focus.ring.color');
        box-shadow: dt('message.warn.close.button.focus.ring.shadow');
    }

    .p-message-warn .p-message-close-button:hover {
        background: dt('message.warn.close.button.hover.background');
    }

    .p-message-warn.p-message-outlined {
        color: dt('message.warn.outlined.color');
        outline-color: dt('message.warn.outlined.border.color');
    }

    .p-message-warn.p-message-simple {
        color: dt('message.warn.simple.color');
    }

    .p-message-error {
        background: dt('message.error.background');
        outline-color: dt('message.error.border.color');
        color: dt('message.error.color');
        box-shadow: dt('message.error.shadow');
    }

    .p-message-error .p-message-close-button:focus-visible {
        outline-color: dt('message.error.close.button.focus.ring.color');
        box-shadow: dt('message.error.close.button.focus.ring.shadow');
    }

    .p-message-error .p-message-close-button:hover {
        background: dt('message.error.close.button.hover.background');
    }

    .p-message-error.p-message-outlined {
        color: dt('message.error.outlined.color');
        outline-color: dt('message.error.outlined.border.color');
    }

    .p-message-error.p-message-simple {
        color: dt('message.error.simple.color');
    }

    .p-message-secondary {
        background: dt('message.secondary.background');
        outline-color: dt('message.secondary.border.color');
        color: dt('message.secondary.color');
        box-shadow: dt('message.secondary.shadow');
    }

    .p-message-secondary .p-message-close-button:focus-visible {
        outline-color: dt('message.secondary.close.button.focus.ring.color');
        box-shadow: dt('message.secondary.close.button.focus.ring.shadow');
    }

    .p-message-secondary .p-message-close-button:hover {
        background: dt('message.secondary.close.button.hover.background');
    }

    .p-message-secondary.p-message-outlined {
        color: dt('message.secondary.outlined.color');
        outline-color: dt('message.secondary.outlined.border.color');
    }

    .p-message-secondary.p-message-simple {
        color: dt('message.secondary.simple.color');
    }

    .p-message-contrast {
        background: dt('message.contrast.background');
        outline-color: dt('message.contrast.border.color');
        color: dt('message.contrast.color');
        box-shadow: dt('message.contrast.shadow');
    }

    .p-message-contrast .p-message-close-button:focus-visible {
        outline-color: dt('message.contrast.close.button.focus.ring.color');
        box-shadow: dt('message.contrast.close.button.focus.ring.shadow');
    }

    .p-message-contrast .p-message-close-button:hover {
        background: dt('message.contrast.close.button.hover.background');
    }

    .p-message-contrast.p-message-outlined {
        color: dt('message.contrast.outlined.color');
        outline-color: dt('message.contrast.outlined.border.color');
    }

    .p-message-contrast.p-message-simple {
        color: dt('message.contrast.simple.color');
    }

    .p-message-text {
        font-size: dt('message.text.font.size');
        font-weight: dt('message.text.font.weight');
    }

    .p-message-icon {
        font-size: dt('message.icon.size');
        width: dt('message.icon.size');
        height: dt('message.icon.size');
    }

    .p-message-sm .p-message-content {
        padding: dt('message.content.sm.padding');
    }

    .p-message-sm .p-message-text {
        font-size: dt('message.text.sm.font.size');
    }

    .p-message-sm .p-message-icon {
        font-size: dt('message.icon.sm.size');
        width: dt('message.icon.sm.size');
        height: dt('message.icon.sm.size');
    }

    .p-message-sm .p-message-close-icon {
        font-size: dt('message.close.icon.sm.size');
        width: dt('message.close.icon.sm.size');
        height: dt('message.close.icon.sm.size');
    }

    .p-message-lg .p-message-content {
        padding: dt('message.content.lg.padding');
    }

    .p-message-lg .p-message-text {
        font-size: dt('message.text.lg.font.size');
    }

    .p-message-lg .p-message-icon {
        font-size: dt('message.icon.lg.size');
        width: dt('message.icon.lg.size');
        height: dt('message.icon.lg.size');
    }

    .p-message-lg .p-message-close-icon {
        font-size: dt('message.close.icon.lg.size');
        width: dt('message.close.icon.lg.size');
        height: dt('message.close.icon.lg.size');
    }

    .p-message-outlined {
        background: transparent;
        outline-width: dt('message.outlined.border.width');
    }

    .p-message-simple {
        background: transparent;
        outline-color: transparent;
        box-shadow: none;
    }

    .p-message-simple .p-message-content {
        padding: dt('message.simple.content.padding');
    }

    .p-message-outlined .p-message-close-button:hover,
    .p-message-simple .p-message-close-button:hover {
        background: transparent;
    }

    .p-message-enter-active {
        animation: p-animate-message-enter 0.3s ease-out forwards;
        overflow: hidden;
    }

    .p-message-leave-active {
        animation: p-animate-message-leave 0.15s ease-in forwards;
        overflow: hidden;
    }

    @keyframes p-animate-message-enter {
        from {
            opacity: 0;
            grid-template-rows: 0fr;
        }
        to {
            opacity: 1;
            grid-template-rows: 1fr;
        }
    }

    @keyframes p-animate-message-leave {
        from {
            opacity: 1;
            grid-template-rows: 1fr;
        }
        to {
            opacity: 0;
            margin: 0;
            grid-template-rows: 0fr;
        }
    }
`,vn={root:function(a){var l=a.props;return["p-message p-component p-message-"+l.severity,{"p-message-outlined":l.variant==="outlined","p-message-simple":l.variant==="simple","p-message-sm":l.size==="small","p-message-lg":l.size==="large"}]},contentWrapper:"p-message-content-wrapper",content:"p-message-content",icon:"p-message-icon",text:"p-message-text",closeButton:"p-message-close-button",closeIcon:"p-message-close-icon"},fn=ke.extend({name:"message",style:gn,classes:vn}),yn={name:"BaseMessage",extends:we,props:{severity:{type:String,default:"info"},closable:{type:Boolean,default:!1},life:{type:Number,default:null},icon:{type:String,default:void 0},closeIcon:{type:String,default:void 0},closeButtonProps:{type:null,default:null},size:{type:String,default:null},variant:{type:String,default:null}},style:fn,provide:function(){return{$pcMessage:this,$parentInstance:this}}};function L(n){"@babel/helpers - typeof";return L=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(a){return typeof a}:function(a){return a&&typeof Symbol=="function"&&a.constructor===Symbol&&a!==Symbol.prototype?"symbol":typeof a},L(n)}function fe(n,a,l){return(a=bn(a))in n?Object.defineProperty(n,a,{value:l,enumerable:!0,configurable:!0,writable:!0}):n[a]=l,n}function bn(n){var a=hn(n,"string");return L(a)=="symbol"?a:a+""}function hn(n,a){if(L(n)!="object"||!n)return n;var l=n[Symbol.toPrimitive];if(l!==void 0){var d=l.call(n,a);if(L(d)!="object")return d;throw new TypeError("@@toPrimitive must return a primitive value.")}return(a==="string"?String:Number)(n)}var $e={name:"Message",extends:yn,inheritAttrs:!1,emits:["close","life-end"],timeout:null,data:function(){return{visible:!0}},mounted:function(){var a=this;this.life&&setTimeout(function(){a.visible=!1,a.$emit("life-end")},this.life)},methods:{close:function(a){this.visible=!1,this.$emit("close",a)}},computed:{closeAriaLabel:function(){return this.$primevue.config.locale.aria?this.$primevue.config.locale.aria.close:void 0},dataP:function(){return Qe(fe(fe({outlined:this.variant==="outlined",simple:this.variant==="simple"},this.severity,this.severity),this.size,this.size))}},directives:{ripple:Ye},components:{TimesIcon:Xe}};function E(n){"@babel/helpers - typeof";return E=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(a){return typeof a}:function(a){return a&&typeof Symbol=="function"&&a.constructor===Symbol&&a!==Symbol.prototype?"symbol":typeof a},E(n)}function ye(n,a){var l=Object.keys(n);if(Object.getOwnPropertySymbols){var d=Object.getOwnPropertySymbols(n);a&&(d=d.filter(function(N){return Object.getOwnPropertyDescriptor(n,N).enumerable})),l.push.apply(l,d)}return l}function be(n){for(var a=1;a<arguments.length;a++){var l=arguments[a]!=null?arguments[a]:{};a%2?ye(Object(l),!0).forEach(function(d){kn(n,d,l[d])}):Object.getOwnPropertyDescriptors?Object.defineProperties(n,Object.getOwnPropertyDescriptors(l)):ye(Object(l)).forEach(function(d){Object.defineProperty(n,d,Object.getOwnPropertyDescriptor(l,d))})}return n}function kn(n,a,l){return(a=wn(a))in n?Object.defineProperty(n,a,{value:l,enumerable:!0,configurable:!0,writable:!0}):n[a]=l,n}function wn(n){var a=$n(n,"string");return E(a)=="symbol"?a:a+""}function $n(n,a){if(E(n)!="object"||!n)return n;var l=n[Symbol.toPrimitive];if(l!==void 0){var d=l.call(n,a);if(E(d)!="object")return d;throw new TypeError("@@toPrimitive must return a primitive value.")}return(a==="string"?String:Number)(n)}var Sn=["data-p"],xn=["data-p"],Vn=["data-p"],Pn=["aria-label","data-p"],jn=["data-p"];function On(n,a,l,d,N,m){var F=Ze("TimesIcon"),w=en("ripple");return u(),f(on,V({name:"p-message",appear:""},n.ptmi("transition")),{default:Q(function(){return[N.visible?(u(),h("div",V({key:0,class:n.cx("root"),role:"alert","aria-live":"assertive","aria-atomic":"true","data-p":m.dataP},n.ptm("root")),[O("div",V({class:n.cx("contentWrapper")},n.ptm("contentWrapper")),[n.$slots.container?H(n.$slots,"container",{key:0,closeCallback:m.close}):(u(),h("div",V({key:1,class:n.cx("content"),"data-p":m.dataP},n.ptm("content")),[H(n.$slots,"icon",{class:nn(n.cx("icon"))},function(){return[(u(),f(sn(n.icon?"span":null),V({class:[n.cx("icon"),n.icon],"data-p":m.dataP},n.ptm("icon")),null,16,["class","data-p"]))]}),n.$slots.default?(u(),h("div",V({key:0,class:n.cx("text"),"data-p":m.dataP},n.ptm("text")),[H(n.$slots,"default")],16,Vn)):T("",!0),n.closable?an((u(),h("button",V({key:1,class:n.cx("closeButton"),"aria-label":m.closeAriaLabel,type:"button",onClick:a[0]||(a[0]=function(_){return m.close(_)}),"data-p":m.dataP},be(be({},n.closeButtonProps),n.ptm("closeButton"))),[H(n.$slots,"closeicon",{},function(){return[n.closeIcon?(u(),h("i",V({key:0,class:[n.cx("closeIcon"),n.closeIcon],"data-p":m.dataP},n.ptm("closeIcon")),null,16,jn)):(u(),f(F,V({key:1,class:[n.cx("closeIcon"),n.closeIcon],"data-p":m.dataP},n.ptm("closeIcon")),null,16,["class","data-p"]))]})],16,Pn)),[[w]]):T("",!0)],16,xn))],16)],16,Sn)):T("",!0)]}),_:3},16)}$e.render=On;var zn=`
    .p-progressspinner {
        position: relative;
        margin: 0 auto;
        width: 100px;
        height: 100px;
        display: inline-block;
    }

    .p-progressspinner::before {
        content: '';
        display: block;
        padding-top: 100%;
    }

    .p-progressspinner-spin {
        height: 100%;
        transform-origin: center center;
        width: 100%;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        animation: p-progressspinner-rotate 2s linear infinite;
    }

    .p-progressspinner-circle {
        stroke-dasharray: 89, 200;
        stroke-dashoffset: 0;
        stroke: dt('progressspinner.colorOne');
        animation:
            p-progressspinner-dash 1.5s ease-in-out infinite,
            p-progressspinner-color 6s ease-in-out infinite;
        stroke-linecap: round;
    }

    @keyframes p-progressspinner-rotate {
        100% {
            transform: rotate(360deg);
        }
    }
    @keyframes p-progressspinner-dash {
        0% {
            stroke-dasharray: 1, 200;
            stroke-dashoffset: 0;
        }
        50% {
            stroke-dasharray: 89, 200;
            stroke-dashoffset: -35px;
        }
        100% {
            stroke-dasharray: 89, 200;
            stroke-dashoffset: -124px;
        }
    }
    @keyframes p-progressspinner-color {
        100%,
        0% {
            stroke: dt('progressspinner.color.one');
        }
        40% {
            stroke: dt('progressspinner.color.two');
        }
        66% {
            stroke: dt('progressspinner.color.three');
        }
        80%,
        90% {
            stroke: dt('progressspinner.color.four');
        }
    }
`,_n={root:"p-progressspinner",spin:"p-progressspinner-spin",circle:"p-progressspinner-circle"},Cn=ke.extend({name:"progressspinner",style:zn,classes:_n}),Un={name:"BaseProgressSpinner",extends:we,props:{strokeWidth:{type:String,default:"2"},fill:{type:String,default:"none"},animationDuration:{type:String,default:"2s"}},style:Cn,provide:function(){return{$pcProgressSpinner:this,$parentInstance:this}}},Se={name:"ProgressSpinner",extends:Un,inheritAttrs:!1,computed:{svgStyle:function(){return{"animation-duration":this.animationDuration}}}},Tn=["fill","stroke-width"];function Fn(n,a,l,d,N,m){return u(),h("div",V({class:n.cx("root"),role:"progressbar"},n.ptmi("root")),[(u(),h("svg",V({class:n.cx("spin"),viewBox:"25 25 50 50",style:m.svgStyle},n.ptm("spin")),[O("circle",V({class:n.cx("circle"),cx:"50",cy:"50",r:"20",fill:n.fill,"stroke-width":n.strokeWidth,strokeMiterlimit:"10"},n.ptm("circle")),null,16,Tn)],16))],16)}Se.render=Fn;function he(n,a){const l=a.find(d=>d.isPk);return l?n[l.name]:null}const Rn={class:"grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6 items-start"},Dn={class:"card"},Nn={class:"flex justify-between items-center mb-4"},In={class:"text-xl font-semibold"},Bn={key:0,class:"flex justify-center p-8"},Ln=["for"],En={key:0,class:"text-red-500"},qn={key:0,class:"flex gap-2 items-center"},Mn={class:"card lg:sticky lg:top-24"},An={class:"flex flex-col gap-3"},Jn=["for"],Wn={key:0,class:"text-red-500"},Gn={class:"flex justify-end gap-2 mt-2"},Yn={__name:"ModelDetail",setup(n){const a=cn(),l=dn(),d=tn(),N=rn(),m=g(a.params.model),F=g(a.params.pk),w=X(()=>!F.value),_=g(null),C=g([]),p=g({}),q=g(null),P=g({}),M=g({}),re=g({}),le=g([]),Z=g(!1),A=g(!1),ee=g(!1),B=g(!1),ne=g(null),J=g(null),R=g([]),b=g({}),$=g({}),se=g({}),W=g(!1);function xe(s){if(s.type)return s.type;if(s.anyOf){const o=s.anyOf.find(t=>t.type&&t.type!=="null");if(o)return o.type}return"string"}function ie(s){return s.$ref?!0:s.anyOf?s.anyOf.some(o=>o.$ref):!1}function Ve(s){const o={},t=s.properties||{};for(const[,r]of Object.entries(t)){if(!ie(r))continue;const i=r["x-db-foreign-key"],y=r["x-db-column"];i&&y&&(o[y]=i)}return o}function Pe(s){if(s.format)return s.format;if(s.anyOf){const o=s.anyOf.find(t=>t.format);if(o)return o.format}return null}function ue(s,o,t){const r=s.properties||{},i=new Set(s.required||[]),y=new Set(t||[]),U=Ve(s),z=[];for(const[v,k]of Object.entries(r)){if(ie(k))continue;const D=U[v]||null;z.push({name:v,label:o&&o[v]||k.title||v,type:xe(k),format:Pe(k),dbType:k["x-db-type"]||null,isPk:!!k["x-db-primary-key"],isReadonly:!!k["x-db-readonly"]||y.has(v),isRequired:i.has(v),default:k.default??null,maxLength:k.maxLength||k["x-db-max-length"]||null,fk:D})}return z}const je=X(()=>C.value.filter(s=>!(s.isPk&&w.value))),ae=X(()=>w.value?!0:q.value?JSON.stringify(p.value)!==JSON.stringify(q.value):!1),Oe=X(()=>R.value.filter(s=>!s.isPk));function S(s){return s.fk?"select":s.type==="boolean"?"boolean":s.type==="integer"||s.type==="number"?"number":s.format==="date-time"?"datetime":s.format==="date"?"date":s.type==="string"&&!s.maxLength&&(!s.dbType||s.dbType.toUpperCase()==="TEXT")?"textarea":"text"}function oe(s,o){const t={};for(const r of s){let i=o?o[r.name]??r.default:r.default;i&&(r.format==="date-time"||r.format==="date")&&(i=new Date(i)),t[r.name]=i}return t}function ce(s,o){const t={};for(const r of s)if(r.isRequired&&!r.isPk&&!r.isReadonly){const i=o[r.name];(i==null||i==="")&&(t[r.name]="This field is required")}return t}function ze(){const s={};for(const o of C.value){if(o.isReadonly||o.isPk&&w.value)continue;let t=p.value[o.name];t instanceof Date&&(t=t.toISOString()),s[o.name]=t}return s}async function _e(){const[s,o]=await Promise.all([x(`/api/${m.value}/schema`),x("/api/models")]);_.value=await s.json();const r=(await o.json()).find(i=>i.name===m.value);re.value=r?.column_labels||{},le.value=r?.readonly_fields||[],C.value=ue(_.value,re.value,le.value)}async function Ce(){const o=C.value.filter(t=>t.fk).map(async t=>{let r=`/api/${t.fk.model}/options`;const i=p.value?.[t.name];i!=null&&(r+=`?include=${encodeURIComponent(i)}`);const y=await x(r);M.value[t.name]=await y.json()});await Promise.all(o)}let de=null;function Ue(s,o){clearTimeout(de);const t=o.value;de=setTimeout(async()=>{const r=t?`/api/${s.fk.model}/options?search=${encodeURIComponent(t)}`:`/api/${s.fk.model}/options`,i=await x(r);M.value[s.name]=await i.json()},300)}async function Te(){Z.value=!0;try{const s=await x(`/api/${m.value}/${F.value}`);p.value=oe(C.value,await s.json()),q.value=JSON.parse(JSON.stringify(p.value))}finally{Z.value=!1}}async function te(s=!1){const o=ce(C.value,p.value);if(Object.keys(o).length>0){P.value=o;return}A.value=!0,P.value={};try{const t=w.value?`/api/${m.value}`:`/api/${m.value}/${F.value}`,r=await x(t,{method:w.value?"POST":"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(ze())});if(r.status===422){De(await r.json());return}if(!r.ok){const y=await r.json();d.add({severity:"error",summary:"Error",detail:y.detail||"Unknown error",life:5e3});return}const i=await r.json();if(d.add({severity:"success",summary:"Saved",detail:`${_.value.title} saved`,life:3e3}),G.value=!0,w.value){const y=he(i,C.value);y!==null&&(s?l.replace(`/${m.value}/${y}`):l.push(`/${m.value}`))}else s?(q.value=JSON.parse(JSON.stringify(p.value)),G.value=!1):l.push(`/${m.value}`)}finally{A.value=!1}}function Fe(){N.require({message:`Are you sure you want to delete this ${_.value?.title||"record"}?`,header:"Confirm Delete",icon:"pi pi-exclamation-triangle",rejectLabel:"Cancel",rejectProps:{severity:"secondary",text:!0},acceptLabel:"Delete",acceptProps:{severity:"danger"},accept:Re})}async function Re(){ee.value=!0;try{const s=await x(`/api/${m.value}/${F.value}`,{method:"DELETE"});if(!s.ok){const o=await s.json();d.add({severity:"error",summary:"Error",detail:o.detail||"Delete failed",life:5e3});return}d.add({severity:"success",summary:"Deleted",detail:`${_.value.title} deleted`,life:3e3}),G.value=!0,l.push(`/${m.value}`)}finally{ee.value=!1}}function De(s){if(!Array.isArray(s.detail))return;const o={};for(const t of s.detail){const r=t.loc||[],i=r[r.length-1];i&&(o[i]=t.msg)}P.value=o}function Ne(){window.history.state?.back?l.back():l.push(`/${m.value}`)}function Ie(s){l.push(`/${s.fk.model}/${p.value[s.name]}`)}async function Be(s){ne.value=s,$.value={},W.value=!1;const o=await x(`/api/${s.fk.model}/schema`);J.value=await o.json(),R.value=ue(J.value),b.value=oe(R.value,null);const t=R.value.filter(i=>i.fk),r={};await Promise.all(t.map(async i=>{const y=await x(`/api/${i.fk.model}/options`);r[i.name]=await y.json()})),se.value=r,B.value=!0}let me=null;function Le(s,o){clearTimeout(me);const t=o.value;me=setTimeout(async()=>{const r=t?`/api/${s.fk.model}/options?search=${encodeURIComponent(t)}`:`/api/${s.fk.model}/options`,i=await x(r);se.value[s.name]=await i.json()},300)}async function Ee(){const s=ce(R.value,b.value);if(Object.keys(s).length>0){$.value=s;return}W.value=!0,$.value={};try{const o=ne.value.fk.model,t={};for(const v of R.value)v.isReadonly||v.isPk||(t[v.name]=b.value[v.name]);const r=await x(`/api/${o}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(t)});if(r.status===422){const v=await r.json();if(Array.isArray(v.detail)){const k={};for(const D of v.detail){const K=D.loc||[];k[K[K.length-1]]=D.msg}$.value=k}return}if(!r.ok){const v=await r.json();d.add({severity:"error",summary:"Error",detail:v.detail||"Create failed",life:5e3});return}const i=await r.json();d.add({severity:"success",summary:"Created",detail:`${J.value.title} created`,life:3e3});const y=he(i,R.value),U=ne.value,z=await x(`/api/${U.fk.model}/options`);M.value[U.name]=await z.json(),p.value[U.name]=y,B.value=!1}finally{W.value=!1}}const G=g(!1);return ln(()=>G.value||!ae.value||w.value?!0:window.confirm("You have unsaved changes. Leave this page?")),un(async()=>{await _e(),w.value?p.value=oe(C.value,null):await Te(),await Ce()}),(s,o)=>{const t=mn,r=Se,i=Ae,y=Je,U=We,z=Ge,v=Ke,k=pn,D=$e,K=Me,qe=He;return u(),h("div",Rn,[O("div",Dn,[O("div",Nn,[O("div",In,I(_.value?.title||m.value)+" "+I(w.value?"Create":`#${F.value}`),1),j(t,{label:"Back",icon:"pi pi-arrow-left",text:"",onClick:Ne})]),Z.value?(u(),h("div",Bn,[j(r)])):(u(),h("form",{key:1,onSubmit:o[0]||(o[0]=pe(e=>te(!1),["prevent"])),class:"flex flex-col gap-4"},[(u(!0),h(ge,null,ve(je.value,e=>(u(),h("div",{key:e.name,class:"flex flex-col gap-1"},[O("label",{for:e.name,class:"font-semibold"},[Y(I(e.label)+" ",1),e.isRequired?(u(),h("span",En,"*")):T("",!0)],8,Ln),S(e)==="select"?(u(),h("div",qn,[j(i,{id:e.name,modelValue:p.value[e.name],"onUpdate:modelValue":c=>p.value[e.name]=c,options:M.value[e.name]||[],optionLabel:"label",optionValue:"value",showClear:!e.isRequired,placeholder:"Select...",filter:"",onFilter:c=>Ue(e,c),invalid:!!P.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","options","showClear","onFilter","invalid"]),j(t,{icon:"pi pi-arrow-up-right",severity:"secondary",text:"",size:"small",disabled:p.value[e.name]==null,onClick:c=>Ie(e),"aria-label":"Open record"},null,8,["disabled","onClick"]),j(t,{icon:"pi pi-plus",severity:"secondary",text:"",size:"small",onClick:c=>Be(e),"aria-label":"Create new"},null,8,["onClick"])])):S(e)==="boolean"?(u(),f(y,{key:1,id:e.name,modelValue:p.value[e.name],"onUpdate:modelValue":c=>p.value[e.name]=c,disabled:e.isReadonly},null,8,["id","modelValue","onUpdate:modelValue","disabled"])):S(e)==="number"?(u(),f(U,{key:2,id:e.name,modelValue:p.value[e.name],"onUpdate:modelValue":c=>p.value[e.name]=c,disabled:e.isReadonly,useGrouping:!1,invalid:!!P.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","disabled","invalid"])):S(e)==="datetime"?(u(),f(z,{key:3,id:e.name,modelValue:p.value[e.name],"onUpdate:modelValue":c=>p.value[e.name]=c,disabled:e.isReadonly,showTime:"",hourFormat:"24",dateFormat:"yy-mm-dd",invalid:!!P.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","disabled","invalid"])):S(e)==="date"?(u(),f(z,{key:4,id:e.name,modelValue:p.value[e.name],"onUpdate:modelValue":c=>p.value[e.name]=c,disabled:e.isReadonly,dateFormat:"yy-mm-dd",invalid:!!P.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","disabled","invalid"])):S(e)==="textarea"?(u(),f(v,{key:5,id:e.name,modelValue:p.value[e.name],"onUpdate:modelValue":c=>p.value[e.name]=c,disabled:e.isReadonly,invalid:!!P.value[e.name],rows:"5",autoResize:"",fluid:""},null,8,["id","modelValue","onUpdate:modelValue","disabled","invalid"])):(u(),f(k,{key:6,id:e.name,modelValue:p.value[e.name],"onUpdate:modelValue":c=>p.value[e.name]=c,disabled:e.isReadonly,maxlength:e.maxLength,invalid:!!P.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","disabled","maxlength","invalid"])),P.value[e.name]?(u(),f(D,{key:7,severity:"error",size:"small",variant:"simple"},{default:Q(()=>[Y(I(P.value[e.name]),1)]),_:2},1024)):T("",!0)]))),128))],32))]),O("div",Mn,[O("div",An,[j(t,{label:w.value?"Create":"Save",icon:"pi pi-check",loading:A.value,disabled:!ae.value,onClick:o[1]||(o[1]=e=>te(!1))},null,8,["label","loading","disabled"]),j(t,{label:w.value?"Create & continue":"Save & continue",icon:"pi pi-save",severity:"secondary",loading:A.value,disabled:!ae.value,onClick:o[2]||(o[2]=e=>te(!0))},null,8,["label","loading","disabled"]),w.value?T("",!0):(u(),f(t,{key:0,label:"Delete",icon:"pi pi-trash",severity:"danger",outlined:"",loading:ee.value,onClick:Fe},null,8,["loading"]))])]),j(K,{visible:B.value,"onUpdate:visible":o[4]||(o[4]=e=>B.value=e),header:"Create "+(J.value?.title||""),modal:"",style:{width:"32rem"}},{default:Q(()=>[O("form",{onSubmit:pe(Ee,["prevent"]),class:"flex flex-col gap-4"},[(u(!0),h(ge,null,ve(Oe.value,e=>(u(),h("div",{key:e.name,class:"flex flex-col gap-1"},[O("label",{for:"dlg-"+e.name,class:"font-semibold"},[Y(I(e.label)+" ",1),e.isRequired?(u(),h("span",Wn,"*")):T("",!0)],8,Jn),S(e)==="select"?(u(),f(i,{key:0,id:"dlg-"+e.name,modelValue:b.value[e.name],"onUpdate:modelValue":c=>b.value[e.name]=c,options:se.value[e.name]||[],optionLabel:"label",optionValue:"value",showClear:!e.isRequired,placeholder:"Select...",filter:"",onFilter:c=>Le(e,c),invalid:!!$.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","options","showClear","onFilter","invalid"])):S(e)==="boolean"?(u(),f(y,{key:1,id:"dlg-"+e.name,modelValue:b.value[e.name],"onUpdate:modelValue":c=>b.value[e.name]=c},null,8,["id","modelValue","onUpdate:modelValue"])):S(e)==="number"?(u(),f(U,{key:2,id:"dlg-"+e.name,modelValue:b.value[e.name],"onUpdate:modelValue":c=>b.value[e.name]=c,useGrouping:!1,invalid:!!$.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","invalid"])):S(e)==="datetime"?(u(),f(z,{key:3,id:"dlg-"+e.name,modelValue:b.value[e.name],"onUpdate:modelValue":c=>b.value[e.name]=c,showTime:"",hourFormat:"24",dateFormat:"yy-mm-dd",invalid:!!$.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","invalid"])):S(e)==="date"?(u(),f(z,{key:4,id:"dlg-"+e.name,modelValue:b.value[e.name],"onUpdate:modelValue":c=>b.value[e.name]=c,dateFormat:"yy-mm-dd",invalid:!!$.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","invalid"])):S(e)==="textarea"?(u(),f(v,{key:5,id:"dlg-"+e.name,modelValue:b.value[e.name],"onUpdate:modelValue":c=>b.value[e.name]=c,invalid:!!$.value[e.name],rows:"5",autoResize:"",fluid:""},null,8,["id","modelValue","onUpdate:modelValue","invalid"])):(u(),f(k,{key:6,id:"dlg-"+e.name,modelValue:b.value[e.name],"onUpdate:modelValue":c=>b.value[e.name]=c,maxlength:e.maxLength,invalid:!!$.value[e.name],fluid:""},null,8,["id","modelValue","onUpdate:modelValue","maxlength","invalid"])),$.value[e.name]?(u(),f(D,{key:7,severity:"error",size:"small",variant:"simple"},{default:Q(()=>[Y(I($.value[e.name]),1)]),_:2},1024)):T("",!0)]))),128)),O("div",Gn,[j(t,{label:"Cancel",severity:"secondary",text:"",onClick:o[3]||(o[3]=e=>B.value=!1)}),j(t,{type:"submit",label:"Create",icon:"pi pi-check",loading:W.value},null,8,["loading"])])],32)]),_:1},8,["visible","header"]),j(qe)])}}};export{Yn as default};
