"""
Series domain module.

Sections:
1. Domain Events
2. Agent Runners
3. Public Entrypoint
4. Resolution
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable
from dataclasses import dataclass
from typing import Protocol

from typing_extensions import override

from claude_agent_sdk import ResultMessage

from .agents import run_agent
from .agents.series import (
    SERIES_ANALYST,
    SERIES_EXTRACTOR,
    SeriesAnalystInput,
    SeriesAnalystOutput,
    SeriesExtractorInput,
)
from .agents.observability import observe
from .events import Event, event, log_events, publish
from .files import FileResult, resolve_files
from .file_schemas import (
    FILES_MANIFEST,
    SERIES_MANIFEST,
    FilesManifestEntry,
    SeriesManifestEntry,
)
from .models import File, FileAggregation, Series
from .runs import with_run_context
from .sandbox import create_agent_sandbox_dir
from .storage import materialize, stage_files_to_sandbox
from .ui import require_confirmation
from .utils import DEFAULT_SERIES_TO_EXTRACT, DEFAULT_TARGET

# ============================================
# 1. DOMAIN EVENTS
# ============================================


@event
class SeriesAnalysisStarted(Event, frozen=True):
    """Emitted when the Series Analyst agent begins analyzing files."""

    files: list[File]
    target: str

    @override
    def message(self) -> str:
        return f"Getting ready to forecast {self.target}, reading {len(self.files)} files"


@event
class SeriesAnalysisCompleted(Event, frozen=True):
    """Emitted when the Series Analyst agent finishes analysis."""

    aggregation: FileAggregation

    @override
    def message(self) -> str:
        return ""


@event
class SeriesAnalysisFailed(Event, frozen=True):
    """Emitted when series analysis fails."""

    files: list[File]
    error: str

    @override
    def message(self) -> str:
        return f"Series analysis failed: {self.error}"

    @override
    def level(self) -> int:
        return logging.ERROR


@event
class SeriesExtractionStarted(Event, frozen=True):
    """Emitted when the Series Extractor agent begins extracting series."""

    aggregation: FileAggregation
    limit: int

    @override
    def message(self) -> str:
        return f"Finding {self.limit} {self.aggregation}-level series to forecast"


@event
class SeriesExtractionCompleted(Event, frozen=True):
    """Emitted when the Series Extractor agent finishes extraction."""

    series: list[Series]
    preview: bool = False

    @override
    def message(self) -> str:
        if self.preview:
            return ""
        lines = [f"Found {len(self.series)} series to forecast"]
        lines.extend(_series_table(self.series))
        return "\n".join(lines)


@event
class SeriesExtractionFailed(Event, frozen=True):
    """Emitted when series extraction fails."""

    files: list[File]
    error: str

    @override
    def message(self) -> str:
        return f"Series extraction failed: {self.error}"

    @override
    def level(self) -> int:
        return logging.ERROR


# ============================================
# 2. AGENT RUNNERS
# ============================================


class SeriesAnalystRunner(Protocol):
    def __call__(
        self,
        files: list[File],
        /,
        *,
        model: str | None = None,
        trace: bool = True,
    ) -> Awaitable[SeriesAnalystOutput]: ...


@dataclass(frozen=True)
class SeriesExtractorResult:
    """Output from a series extractor run."""

    series: list[Series]
    manifest: FileResult
    result: ResultMessage


class SeriesExtractorRunner(Protocol):
    def __call__(
        self,
        files: list[File],
        aggregation: FileAggregation,
        limit: int | None,
        /,
        *,
        extracted_entries: list[SeriesManifestEntry] | None = None,
        model: str | None = None,
        trace: bool = True,
    ) -> Awaitable[SeriesExtractorResult]: ...


@observe(name="series_analyst")
async def _run_series_analyst(
    files: list[File],
    /,
    *,
    model: str | None = None,
    trace: bool = True,
) -> SeriesAnalystOutput:
    """Run the Series Analyst agent and return the inferred aggregation."""
    if not files:
        raise ValueError("files required")

    with create_agent_sandbox_dir() as sandbox_dir:
        staged_files = stage_files_to_sandbox(files, sandbox_dir)
        entries = [FilesManifestEntry.from_model(f, sandbox_dir) for f in staged_files]
        files_manifest_path = FILES_MANIFEST.dump(sandbox_dir, entries)

        agent_input = SeriesAnalystInput(
            files_manifest_path=files_manifest_path,
        )

        return await run_agent(SERIES_ANALYST, agent_input, sandbox_dir, model=model, trace=trace)


@observe(name="series_extractor")
async def _run_series_extractor(
    files: list[File],
    aggregation: FileAggregation,
    limit: int | None,
    /,
    *,
    extracted_entries: list[SeriesManifestEntry] | None = None,
    model: str | None = None,
    trace: bool = True,
) -> SeriesExtractorResult:
    """Run the Series Extractor agent and parse the resulting series manifest."""
    if not files:
        raise ValueError("files required")

    with create_agent_sandbox_dir() as sandbox_dir:
        staged_files = stage_files_to_sandbox(files, sandbox_dir)
        entries = [FilesManifestEntry.from_model(f, sandbox_dir) for f in staged_files]
        files_manifest_path = FILES_MANIFEST.dump(sandbox_dir, entries)

        # Write series manifest — may include previously extracted entries for the agent to build on.
        series_manifest_path = SERIES_MANIFEST.dump(sandbox_dir, extracted_entries or [])

        agent_input = SeriesExtractorInput(
            files_manifest_path=files_manifest_path,
            series_manifest_path=series_manifest_path,
            aggregation=aggregation,
            limit=limit,
        )

        result_message = await run_agent(
            SERIES_EXTRACTOR, agent_input, sandbox_dir, model=model, trace=trace
        )

        # Validate agent output in sandbox
        series_manifest_validation_result = SERIES_MANIFEST.validate_file(sandbox_dir)

        # Persist agent output to durable storage (audit artifact)
        series_manifest = materialize(SERIES_MANIFEST, sandbox_dir, agent_name="series_extractor")

        series_manifest_entries = SERIES_MANIFEST.load(sandbox_dir)

    return SeriesExtractorResult(
        series=[entry.to_model() for entry in series_manifest_entries],
        manifest=FileResult(file=series_manifest, issues=series_manifest_validation_result.issues),
        result=result_message,
    )


# ============================================
# 3. PUBLIC ENTRYPOINT
# ============================================


def _series_table(series: list[Series]) -> list[str]:
    """Format series as aligned table rows (Name, IDs)."""
    headers = ("Name", "IDs")
    rows: list[tuple[str, ...]] = []
    for s in series:
        rows.append((s.name, s.identifiers_summary or "—"))
    widths = [max(len(h), *(len(r[i]) for r in rows)) + 2 for i, h in enumerate(headers)]
    lines: list[str] = []
    lines.append("  " + "".join(h.ljust(w) for h, w in zip(headers, widths)))
    for row in rows:
        lines.append("  " + "".join(cell.ljust(w) for cell, w in zip(row, widths)))
    return lines


def preview_series_message(series: list[Series]) -> str:
    """Format extracted series for the confirmation prompt."""
    lines = ["Confirm: correct type of series to forecast?"]
    lines.extend(_series_table(series))
    return "\n".join(lines)


async def resolve_series_preview(
    files: list[File],
    *,
    model: str | None = None,
    trace: bool = True,
) -> list[Series]:
    """Gate 1: extract one preview series and confirm with the user.

    Shared by all three public entrypoints (series, forecast_models, forecasts)
    to handle the "no series provided" preview path consistently.

    Returns the confirmed preview series list (length 0 or 1).
    """
    preview = await resolve_series(files, limit=1, preview=True, model=model, trace=trace)
    if not preview:
        return []
    require_confirmation(preview_series_message(preview))
    return preview


@log_events
async def series(
    files: File | list[File] | None = None,
    series: Series | list[Series] | None = None,
    *,
    model: str | None = None,
    trace: bool = True,
) -> list[Series]:
    """
    Public entrypoint: extract series from files.

    Files are auto-discovered and classified when omitted. Series
    are auto-extracted when omitted (with confirmation of the first
    series before continuing). When seed series are provided, they
    are enriched and used to discover additional series up to the
    default limit.

    Args:
        files: Input data files. Accepts a single File, a list, or None
            to auto-discover from the default data directory.
        series: Seed series. Accepts a single Series, a list, or None
            to auto-extract from files.
        model: LLM model override for agent calls.
        trace: Whether to enable tracing for agent calls.

    Returns:
        Extracted series.
    """
    with with_run_context():
        # Discover (if None) and classify (if unclassified)
        input_files = [files] if isinstance(files, File) else files
        classified_files = await resolve_files(input_files, model=model, trace=trace)

        # Normalize series
        input_series = [series] if isinstance(series, Series) else series

        # Seeds provided — single resolve call, no confirm
        if input_series:
            return await resolve_series(classified_files, input_series, model=model, trace=trace)

        # No seeds — extract 1, confirm, then extract remaining seeded with confirmed series
        preview = await resolve_series_preview(classified_files, model=model, trace=trace)
        if not preview:
            return []

        return await resolve_series(classified_files, preview, model=model, trace=trace)


# ============================================
# 4. RESOLUTION
# ============================================


async def resolve_series(
    files: list[File],
    series: list[Series] | None = None,
    analyst_runner: SeriesAnalystRunner = _run_series_analyst,
    extractor_runner: SeriesExtractorRunner = _run_series_extractor,
    /,
    *,
    limit: int = DEFAULT_SERIES_TO_EXTRACT,
    preview: bool = False,
    model: str | None = None,
    trace: bool = True,
) -> list[Series]:
    """
    Resolve series from classified files using a two-agent pipeline.

    1. Analyst — infers the aggregation level from the files.
    2. Extractor — extracts series names, identifiers, and preferences.

    When ``series`` is provided, step 1 is skipped (aggregation is
    taken from the seeds) and the seeds are written into the extractor
    manifest so they get enriched while the extractor discovers
    additional series up to ``limit``.

    .. note::
        Currently batch-in/batch-out — all series are returned together.
        TODO: stream/yield series as they are resolved so callers can
        start downstream work (model training) before the full batch
        completes.

    Args:
        files: Classified files to extract series from.
        analyst_runner: Infers the aggregation level.
        extractor_runner: Extracts series at that level.
        limit: Maximum total series to extract.
        series: Seed series to enrich and extend. Skips analyst.
        preview: When True, silences the extraction completed message
            (the confirmation prompt handles display instead).

    Returns:
        All extracted series (seeds enriched + newly discovered).

    Raises:
        ValueError: If files is empty.
    """
    if not files:
        raise ValueError("files required")

    # Resolve aggregation — skip analyst when series are already provided.
    if not series:
        publish(SeriesAnalysisStarted(files=files, target=DEFAULT_TARGET))
        try:
            analyst_result = await analyst_runner(files, model=model, trace=trace)
        except Exception as exc:
            publish(SeriesAnalysisFailed(files=files, error=str(exc)))
            raise
        aggregation = analyst_result.aggregation
        publish(SeriesAnalysisCompleted(aggregation=aggregation))
    else:
        # TODO: Assumes all provided series share the same aggregation level.
        # Support mixed aggregations when multi-level forecasting is needed.
        aggregation = series[0].aggregation

    # Seed manifest with provided series.
    seed_entries = [SeriesManifestEntry.from_model(s) for s in series] if series else None

    publish(SeriesExtractionStarted(aggregation=aggregation, limit=limit))
    try:
        extractor_result = await extractor_runner(
            files, aggregation, limit, extracted_entries=seed_entries, model=model, trace=trace
        )
    except Exception as exc:
        publish(SeriesExtractionFailed(files=files, error=str(exc)))
        raise

    result = extractor_result.series
    publish(SeriesExtractionCompleted(series=result, preview=preview))

    return result
