from __future__ import annotations

import logging
from typing_extensions import override

from ..events import Event, event


@event
class AgentRunStarted(Event, frozen=True):
    """Emitted when an agent run begins."""

    agent_name: str
    trace_url: str | None = None

    @override
    def message(self) -> str:
        trace = f" (trace: {self.trace_url})" if self.trace_url else ""
        return f"Agent {self.agent_name} started{trace}"


@event
class AgentRunCompleted(Event, frozen=True):
    """Emitted when an agent run completes successfully."""

    agent_name: str
    trace_url: str | None = None
    summary: str | None = None

    @override
    def message(self) -> str:
        parts = [f"Agent {self.agent_name} completed"]
        if self.summary:
            parts.append(f"({self.summary})")
        if self.trace_url:
            parts.append(f"(trace: {self.trace_url})")
        return " ".join(parts)


@event
class AgentRunFailed(Event, frozen=True):
    """Emitted when an agent run fails."""

    agent_name: str
    trace_url: str | None = None
    summary: str | None = None

    @override
    def message(self) -> str:
        parts = [f"Agent {self.agent_name} failed"]
        if self.summary:
            parts.append(f"({self.summary})")
        if self.trace_url:
            parts.append(f"(trace: {self.trace_url})")
        return " ".join(parts)

    @override
    def level(self) -> int:
        return logging.ERROR
