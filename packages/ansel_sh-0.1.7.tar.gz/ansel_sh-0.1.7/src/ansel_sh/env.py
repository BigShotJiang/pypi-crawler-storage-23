"""Authentication detection and environment loading."""

from __future__ import annotations

import json
import logging
import os
import subprocess
from enum import Enum
from pathlib import Path

logger = logging.getLogger("ansel")


class AuthMethod(Enum):
    API_KEY = "api_key"
    FOUNDRY = "foundry"
    SUBSCRIPTION = "subscription"


def detect_auth_method() -> AuthMethod:
    """Detect authentication method. Logs at DEBUG level.

    Priority: ANTHROPIC_API_KEY -> Foundry -> subscription.
    """
    if os.getenv("ANTHROPIC_API_KEY"):
        logger.debug("Authentication: Anthropic API key")
        return AuthMethod.API_KEY
    if os.getenv("CLAUDE_CODE_USE_FOUNDRY"):
        resource = os.getenv("ANTHROPIC_FOUNDRY_RESOURCE") or os.getenv(
            "ANTHROPIC_FOUNDRY_BASE_URL"
        )
        logger.debug("Authentication: Foundry (%s)", resource)
        return AuthMethod.FOUNDRY
    logger.debug("Authentication: Claude subscription")
    return AuthMethod.SUBSCRIPTION


def has_api_key_auth() -> bool:
    """True if explicit API key auth is configured (direct or Foundry)."""
    return detect_auth_method() != AuthMethod.SUBSCRIPTION


def check_subscription() -> dict[str, object] | None:
    """Check Claude CLI subscription status. Returns parsed JSON or None on failure."""
    try:
        result = subprocess.run(
            ["claude", "auth", "status"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None
        return json.loads(result.stdout)  # pyright: ignore[reportAny]
    except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
        return None


def has_credentials() -> bool:
    """True if any auth method is available (API key, Foundry, or subscription)."""
    if has_api_key_auth():
        return True
    status = check_subscription()
    return status is not None and status.get("loggedIn") is True


def load_env_file(path: Path) -> None:
    """Load key=value pairs into os.environ (doesn't override existing)."""
    if not path.exists():
        return

    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        key = key.strip()
        value = value.strip()
        if key and key not in os.environ:
            os.environ[key] = value
