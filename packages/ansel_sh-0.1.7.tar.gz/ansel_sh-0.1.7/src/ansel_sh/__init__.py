"""
Ansel — Demand forecasting API for AIs.

Auditable demand forecasts from raw data for operational planning.

Quick start:

    from ansel_sh import forecasts

    # User-provided data files are auto-discovered
    result = forecasts()

    # Custom client with configuration
    from ansel_sh import Ansel
    client = Ansel(verbose=True)
    result = client.forecasts()
"""

from __future__ import annotations

from .client import Ansel
from .files import files as files_async
from .forecast_models import ForecastModel
from .forecast_models import forecast_models as forecast_models_async
from .forecasts import Forecast
from .forecasts import forecasts as forecasts_async
from .models import File, ForecastSettings, Series
from .series import series as series_async

_default_client: Ansel | None = None


def _get_default() -> Ansel:
    global _default_client
    if _default_client is None:
        _default_client = Ansel()
    return _default_client


def forecasts(
    files: File | list[File] | None = None,
    series: Series | list[Series] | None = None,
    *,
    data_dir: str | None = None,
) -> list[Forecast]:
    """Generate forecasts. Sync wrapper around forecasts_async."""
    return _get_default().forecasts(files=files, series=series, data_dir=data_dir)


def models(
    files: File | list[File] | None = None,
    series: Series | list[Series] | None = None,
) -> list[ForecastModel]:
    """Train forecast models. Sync wrapper around forecast_models_async."""
    return _get_default().models(files=files, series=series)


def series(
    files: File | list[File] | None = None,
    series: Series | list[Series] | None = None,
) -> list[Series]:
    """Extract series from files. Sync wrapper around series_async."""
    return _get_default().series(files=files, series=series)


def files(files: File | list[File] | None = None, *, data_dir: str | None = None) -> list[File]:
    """Resolve and classify files. Sync wrapper around files_async."""
    return _get_default().files(files=files, data_dir=data_dir)


__all__ = [
    # Client
    "Ansel",
    # Data types
    "File",
    "Forecast",
    "ForecastModel",
    "ForecastSettings",
    "Series",
    # Sync API (default)
    "forecasts",
    "models",
    "series",
    "files",
    # Async API
    "forecasts_async",
    "forecast_models_async",
    "series_async",
    "files_async",
]
