import asyncio

from ansel_sh.agents.observability import init_laminar
from ansel_sh.files import files

init_laminar()


async def main() -> None:
    # _ = await series()
    _ = await files()


if __name__ == "__main__":
    asyncio.run(main())
