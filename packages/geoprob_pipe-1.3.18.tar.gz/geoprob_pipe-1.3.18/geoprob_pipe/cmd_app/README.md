Run command line tool with the following command:

```python -m geoprob_pipe.cmd_app.cmd startup_geoprob_pipe```