from __future__ import annotations
from pandas import DataFrame, concat
from probabilistic_library import DesignPoint, Alpha
from typing import TYPE_CHECKING, Dict, List, Union, cast
import numpy as np

from geoprob_pipe.calculations.systems.mappers.calculation_mapper import CALCULATION_MAPPER

if TYPE_CHECKING:
    from geoprob_pipe import GeoProbPipe
    from geoprob_pipe.calculations.systems.base_objects.system_calculation import (
        SystemCalculation)
    from geoprob_pipe.calculations.systems.build_and_run import CalcResult


def collect_stochast_values(calc: SystemCalculation
                            ) -> DataFrame:
    """ Collects all Alphas, Influence factors and Physical values of
    the stochast input parameters. """

    # Create
    def create_df_rows_for_design_point(
            dp: DesignPoint, calculation: SystemCalculation
    ) -> List[Dict[str, Union[str, float]]]:
        rows_from_dp = []
        for alpha in dp.alphas:
            alpha: Alpha
            rows_from_dp.append({
                "uittredepunt_id": calculation.metadata['uittredepunt_id'],
                "ondergrondscenario_id": calculation.metadata['ondergrondscenario_naam'],
                "vak_id": calculation.metadata['vak_id'],
                "design_point": dp.identifier,
                "variable": alpha.identifier,
                "distribution_type": alpha.variable.distribution.value,
                "alpha": alpha.alpha,
                "influence_factor": alpha.alpha * alpha.alpha,
                "physical_value": alpha.x
            })
        return rows_from_dp

    # Gather data
    rows = []
    for design_point in calc.model_design_points:
        rows.extend(create_df_rows_for_design_point(dp=design_point, calculation=calc))
    sdp = cast(DesignPoint, calc.system_design_point)
    rows.extend(create_df_rows_for_design_point(dp=sdp, calculation=calc))

    # Generate df from rows
    df = DataFrame(rows)

    return df


def _combine_stochast_values(calc_results: List[CalcResult])  -> DataFrame:
    df = concat((result.df_stochast for result in calc_results), ignore_index=True)
    return df


def calculate_derived_values(df_scenarios: DataFrame,
                             geohydrologisch_model: str):
    """ Re-calculates all derived physical values, i.e. intermediate values that were calculated inside the limit state
    functions. These are not returned by the probabilistic library, hence we need to re-calculate them.
    """

    # Get kwargs per calculation
    df = df_scenarios.copy(deep=True)
    df['physical_values'] = df['system_calculation'].apply(
        lambda sc: {alpha.variable.name: alpha.x for alpha in sc.system_design_point.alphas}
    )

    # Calculate the derived values
    def derived_values_single_calculation(model_naam: str, **kwargs):

        return_keys: List[str] = CALCULATION_MAPPER[model_naam]["system_return_parameter_keys"]
        system_limit_state_function = CALCULATION_MAPPER[model_naam]["limit_state_function"]
        derived_values = {key: value for key, value in zip(return_keys, system_limit_state_function(**kwargs))}

        return {**derived_values}

    df['derived_physical_values'] = df['physical_values'].apply(
        lambda kwargs: derived_values_single_calculation(
            model_naam=geohydrologisch_model, **kwargs)
    )

    # Create df with row per derived physical value
    df_new = df[["uittredepunt_id", "ondergrondscenario_id", "vak_id", "derived_physical_values"]].copy(deep=True)
    df_new['design_point'] = "system"
    df_new['distribution_type'] = "derived"
    df_new['alpha'] = np.nan
    df_new['influence_factor'] = np.nan

    # Expand dictionary to new rows
    df_new = concat([
        DataFrame({
            **row.drop('derived_physical_values'),
            'variable': list(row['derived_physical_values'].keys()),
            'physical_value': list(row['derived_physical_values'].values())
        })
        for _, row in df_new.iterrows()
    ], ignore_index=True)

    return df_new


def _combine_derived_values(calc_results: List[CalcResult]) -> DataFrame:
    df = concat((result.df_derived for result in calc_results),
                ignore_index=True)
    return df


def construct_df(geoprob_pipe: GeoProbPipe):

    # Merge derived and stochast values
    df = concat([
        _combine_stochast_values(geoprob_pipe.calc_results),
        _combine_derived_values(geoprob_pipe.calc_results)
    ])

    # Sort
    df = df.sort_values(by=["vak_id", "uittredepunt_id", "ondergrondscenario_id", "design_point", "variable"])
    return df.reset_index(drop=True)
    # TODO Later Could Klein: Bespreken of we de physical values willen afronden? Af wellicht afrondden in de export.
