from geoprob_pipe.cmd_app.cmd import startup_geoprob_pipe

if __name__ == "__main__":
    startup_geoprob_pipe()
