"""Chaos: Under-Merge.

Proving: "Same person with variations is correctly merged via combined signals."
Requires native extension with reconcile_local.
"""
from __future__ import annotations

import pytest

from tests.contract.conftest import (
    SINGLE_SOURCE_SPEC,
    make_source,
    make_spec,
    requires_reconcile,
)

pytestmark = requires_reconcile


# ---------------------------------------------------------------------------
# Under-merge tests
# ---------------------------------------------------------------------------


class TestUnderMerge:
    def test_name_typo_plus_exact_email_merges(self, tmp_path):
        """'Alic Smith' vs 'Alice Smith', same email → merged."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "alice.smith@example.com", "first_name": "Alic",
             "last_name": "Smith", "phone": "555-0001"},
            {"id": "2", "email": "alice.smith@example.com", "first_name": "Alice",
             "last_name": "Smith", "phone": "555-0002"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count == 1

    def test_email_change_with_same_phone(self, tmp_path):
        """Old email + new email, but same phone → merged via phone."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "alice.old@example.com", "first_name": "Alice",
             "last_name": "Smith", "phone": "555-0001"},
            {"id": "2", "email": "alice.new@example.com", "first_name": "Alice",
             "last_name": "Smith", "phone": "555-0001"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count == 1

    def test_abbreviated_name_plus_email(self, tmp_path):
        """'Bob' vs 'Robert', same email → merged (email wins)."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "bob@example.com", "first_name": "Bob",
             "last_name": "Smith", "phone": "555-0001"},
            {"id": "2", "email": "bob@example.com", "first_name": "Robert",
             "last_name": "Smith", "phone": "555-0002"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count == 1

    def test_multiple_signals_compensate(self, tmp_path):
        """No single exact match on email, but same phone → merged."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "alice1@example.com", "first_name": "Alice",
             "last_name": "Smith", "phone": "555-0001"},
            {"id": "2", "email": "alice2@example.com", "first_name": "Alice",
             "last_name": "Smith", "phone": "555-0001"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count == 1
