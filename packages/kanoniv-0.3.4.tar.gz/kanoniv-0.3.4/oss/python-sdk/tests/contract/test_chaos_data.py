"""Chaos: Dirty Data.

Proving: "Dirty input does not cause crashes, silent corruption, or over-merge."
Requires native extension with reconcile_local.
"""
from __future__ import annotations

import pytest

from tests.contract.conftest import (
    SINGLE_SOURCE_SPEC,
    make_source,
    make_spec,
    requires_reconcile,
)

pytestmark = requires_reconcile


# ---------------------------------------------------------------------------
# Dirty data resilience
# ---------------------------------------------------------------------------


class TestDirtyDataResilience:
    def test_all_nulls_no_crash(self, tmp_path):
        """Records with every field empty → runs, 0 merges."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "", "first_name": "", "last_name": "", "phone": ""},
            {"id": "2", "email": "", "first_name": "", "last_name": "", "phone": ""},
            {"id": "3", "email": "", "first_name": "", "last_name": "", "phone": ""},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count >= 1

    def test_unicode_names_handled(self, tmp_path):
        """Unicode names → no crash."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "jose@example.com", "first_name": "José",
             "last_name": "García", "phone": "555-0001"},
            {"id": "2", "email": "muller@example.com", "first_name": "Müller",
             "last_name": "Schmidt", "phone": "555-0002"},
            {"id": "3", "email": "tanaka@example.com", "first_name": "田中",
             "last_name": "太郎", "phone": "555-0003"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count == 3

    def test_truncated_emails(self, tmp_path):
        """'alice@' and '@example.com' → not matched as valid email."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "alice@", "first_name": "Alice",
             "last_name": "Smith", "phone": "555-0001"},
            {"id": "2", "email": "@example.com", "first_name": "Bob",
             "last_name": "Jones", "phone": "555-0002"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count == 2

    def test_mixed_case_emails(self, tmp_path):
        """'ALICE@EXAMPLE.COM' vs 'alice@example.com' → consistent behavior."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "ALICE@EXAMPLE.COM", "first_name": "Alice",
             "last_name": "Smith", "phone": "555-0001"},
            {"id": "2", "email": "alice@example.com", "first_name": "Alice",
             "last_name": "Smith", "phone": "555-0002"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count in (1, 2)

    def test_extra_whitespace_in_fields(self, tmp_path):
        """' alice@example.com ' → handled gracefully."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "  alice@example.com  ", "first_name": " Alice ",
             "last_name": "Smith", "phone": "555-0001"},
            {"id": "2", "email": "alice@example.com", "first_name": "Alice",
             "last_name": "Smith", "phone": "555-0002"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count in (1, 2)

    def test_very_long_field_values(self, tmp_path):
        """10KB string → no crash, no match with short string."""
        from kanoniv.reconcile import reconcile

        long_name = "A" * 10_000
        rows = [
            {"id": "1", "email": "long@example.com", "first_name": long_name,
             "last_name": "Smith", "phone": "555-0001"},
            {"id": "2", "email": "short@example.com", "first_name": "Bob",
             "last_name": "Jones", "phone": "555-0002"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count == 2

    def test_special_characters(self, tmp_path):
        """O'Brien, Smith-Jones, Jr. → no crash."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "obrien@example.com", "first_name": "O'Brien",
             "last_name": "Smith-Jones", "phone": "555-0001"},
            {"id": "2", "email": "jr@example.com", "first_name": "Jr.",
             "last_name": "Davis", "phone": "555-0002"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count == 2

    def test_numeric_strings_in_name_fields(self, tmp_path):
        """'12345' as name → no crash."""
        from kanoniv.reconcile import reconcile

        rows = [
            {"id": "1", "email": "num@example.com", "first_name": "12345",
             "last_name": "67890", "phone": "555-0001"},
            {"id": "2", "email": "other@example.com", "first_name": "Alice",
             "last_name": "Smith", "phone": "555-0002"},
        ]
        src = make_source(tmp_path, "main", rows)
        spec = make_spec(SINGLE_SOURCE_SPEC)
        result = reconcile([src], spec)
        assert result.cluster_count == 2
