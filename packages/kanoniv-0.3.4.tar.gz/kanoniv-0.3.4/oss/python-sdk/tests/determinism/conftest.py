"""Fixtures for system-level determinism tests."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

# Ensure the tests directory is importable so `from determinism.helpers import ...` works
_tests_dir = str(Path(__file__).parents[1])
if _tests_dir not in sys.path:
    sys.path.insert(0, _tests_dir)

from determinism.helpers import (  # noqa: E402
    SF_CSV_PATH,
    SPEC_PATH,
    STRIPE_CSV_PATH,
    identity_fingerprint,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def production_spec():
    """Load customer-spec.yaml via Spec.from_file()."""
    from kanoniv.spec import Spec

    return Spec.from_file(str(SPEC_PATH))


@pytest.fixture
def production_sources():
    """Return (sf_source, stripe_source) loaded from test-dataset/ CSVs.

    Function-scoped because Source.to_entities() generates new UUIDs each call,
    and we want fresh Source objects per test to avoid state leakage.
    """
    from kanoniv.source import Source

    sf = Source.from_csv("salesforce", str(SF_CSV_PATH), primary_key="sf_id")
    stripe = Source.from_csv("stripe", str(STRIPE_CSV_PATH), primary_key="cus_id")
    return sf, stripe


@pytest.fixture(scope="session")
def baseline_fingerprint(production_spec):
    """Run reconcile once and return the identity_fingerprint string."""
    from kanoniv.reconcile import reconcile
    from kanoniv.source import Source

    sf = Source.from_csv("salesforce", str(SF_CSV_PATH), primary_key="sf_id")
    stripe = Source.from_csv("stripe", str(STRIPE_CSV_PATH), primary_key="cus_id")
    result = reconcile([sf, stripe], production_spec)
    return identity_fingerprint(result)
