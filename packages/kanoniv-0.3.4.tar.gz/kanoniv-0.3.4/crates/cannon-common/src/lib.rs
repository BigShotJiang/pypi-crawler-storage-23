#[cfg(feature = "server")]
pub mod error;
#[cfg(feature = "server")]
pub mod config;
#[cfg(feature = "server")]
pub mod models;
#[cfg(feature = "server")]
pub mod repositories;
#[cfg(feature = "server")]
pub mod kms;
#[cfg(feature = "server")]
pub mod spec_validation;
#[cfg(feature = "server")]
pub mod field_profiler;
#[cfg(feature = "server")]
pub mod operations;

pub mod spec;
pub mod ir;
pub mod observability;
pub mod relationship;
pub mod graph;

#[cfg(feature = "server")]
pub use error::{CannonError, Result};
#[cfg(feature = "server")]
pub use config::AppConfig;
pub use spec::IdentitySpec;
#[cfg(feature = "server")]
pub use spec_validation::{SpecValidator, ValidationError, validate_plan_tier};
