//! Graph types and algorithms for identity graph intelligence.
//! Shared between cannon-api (cached in-memory graphs) and cannon-worker (agent analytics).

pub mod algorithms;
#[cfg(feature = "server")]
pub mod materializer;
pub mod model;
#[cfg(feature = "server")]
pub mod registry;

use std::collections::HashMap;
use petgraph::graph::NodeIndex;
use uuid::Uuid;

/// Edge metadata in the tenant graph.
#[derive(Debug, Clone)]
pub struct EdgeData {
    pub weight: f64,
    pub edge_type: String, // "identity" or "relationship"
    pub attributes: Option<serde_json::Value>,
}

/// Risk scores for a single entity.
#[derive(Debug, Clone, serde::Serialize)]
pub struct RiskScores {
    pub churn_risk: f64,
    pub contagion_risk: f64,
    pub merge_risk: f64,
}

/// In-memory tenant graph for Transitive Intelligence and Graph Intelligence.
/// Wraps a petgraph with both hard (identity) and soft (relationship) edges.
/// Pre-computed analytics are calculated during graph build and cached alongside.
pub struct TenantGraph {
    pub graph: petgraph::Graph<Uuid, EdgeData, petgraph::Undirected>,
    pub node_map: HashMap<Uuid, NodeIndex>,
    // --- Graph Intelligence analytics (computed on build) ---
    pub pagerank: HashMap<Uuid, f64>,
    pub betweenness: HashMap<Uuid, f64>,
    pub bridge_scores: HashMap<Uuid, f64>,
    pub components: Vec<Vec<Uuid>>,
    pub node_component: HashMap<Uuid, usize>,
    pub risk_scores: HashMap<Uuid, RiskScores>,
}
