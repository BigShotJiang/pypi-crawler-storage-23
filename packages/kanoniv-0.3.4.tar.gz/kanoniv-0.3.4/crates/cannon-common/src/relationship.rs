use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// A single shared attribute contributing to a relationship edge weight.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SharedAttribute {
    pub field: String,
    pub value: String,
    pub frequency: usize,
    pub contribution: f64,
}

/// A soft edge between two entities in different merge clusters,
/// weighted by inverse frequency of shared attribute values.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RelationshipEdge {
    pub entity_a_id: Uuid,
    pub entity_b_id: Uuid,
    pub canonical_a_id: Uuid,
    pub canonical_b_id: Uuid,
    pub weight: f64,
    pub attributes: Vec<SharedAttribute>,
}

/// Configuration for relationship edge computation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RelationshipConfig {
    /// Minimum total edge weight to emit (default 0.5)
    pub min_edge_weight: f64,
    /// Maximum number of edges to keep (default 50000)
    pub max_edges: usize,
    /// Skip field values more common than this (default 1000) - edge explosion guard
    pub max_value_frequency: usize,
}

impl Default for RelationshipConfig {
    fn default() -> Self {
        Self {
            min_edge_weight: 0.5,
            max_edges: 50_000,
            max_value_frequency: 1_000,
        }
    }
}
