use serde::{Deserialize, Serialize};
use std::collections::HashMap;

// ============================================================================
// PLAN.SUMMARY — static analysis of a compiled identity plan
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlanSummary {
    pub plan_hash: String,
    pub api_version: String,
    pub entity: String,
    pub spec_version: String,

    pub sources: SourcesSummary,
    pub matching: MatchingSummary,
    pub blocking: BlockingSummary,
    pub survivorship: Vec<SurvivorshipFieldSummary>,
    pub execution_graph: ExecutionGraph,
    pub scale_estimate: ScaleEstimate,
    pub risk_analysis: RiskAnalysis,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SourcesSummary {
    pub count: usize,
    pub list: Vec<SourceDetail>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SourceDetail {
    pub name: String,
    pub table: String,
    pub key: String,
    pub fields: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MatchingSummary {
    pub rules: RulesSummary,
    pub rules_detail: Vec<RuleDetail>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub probability_model: Option<FsPlanSummary>,
}

/// Summary of a Fellegi-Sunter probability model in the plan.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FsPlanSummary {
    pub fields_configured: usize,
    pub independence_assumption: bool,
    pub max_possible_log_likelihood: f64,
    pub min_possible_log_likelihood: f64,
    pub match_threshold: f64,
    pub possible_threshold: f64,
    pub non_match_threshold: f64,
    pub field_weights: Vec<FsFieldWeight>,
}

/// Per-field weight summary for Fellegi-Sunter plan observability.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FsFieldWeight {
    pub name: String,
    pub w_agree: f64,
    pub w_disagree: f64,
    /// This field's w_agree as percentage of total max composite
    pub dominance_pct: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RulesSummary {
    pub total: usize,
    pub by_type: HashMap<String, usize>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleDetail {
    pub name: String,
    #[serde(rename = "type")]
    pub rule_type: String,
    pub field: Option<String>,
    pub algorithm: Option<String>,
    pub threshold: Option<f64>,
    pub weight: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BlockingSummary {
    pub enabled: bool,
    pub strategy: String,
    pub keys: Vec<Vec<String>>,
    pub estimated_reduction_factor: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SurvivorshipFieldSummary {
    pub field: String,
    pub strategy: String,
    pub source_priority: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionGraph {
    pub stages: Vec<String>,
    pub dag_depth: usize,
    pub parallelizable_stages: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScaleEstimate {
    pub estimated_comparisons: String,
    pub complexity_class: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskAnalysis {
    pub flags: Vec<RiskFlag>,
    pub overall_risk_score: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskFlag {
    pub code: String,
    pub severity: String,
    pub description: String,
}

// ============================================================================
// IDENTITY.SUMMARY — post-reconciliation metrics
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdentitySummary {
    pub run_id: String,
    pub plan_hash: String,
    pub entity: String,
    pub timestamp: String,

    /// Plain-english summary for display to non-technical users.
    #[serde(default)]
    pub headline: HeadlineSummary,

    pub input: InputSummary,
    pub output: OutputSummary,
    pub clustering: ClusteringSummary,
    pub match_quality: MatchQualitySummary,
    pub survivorship: SurvivorshipSummary,
    pub stability: StabilitySummary,
    pub health_flags: Vec<HealthFlag>,
}

/// User-friendly summary with counts that make sense to non-technical users.
/// All numbers refer to records (not pairwise comparisons).
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct HeadlineSummary {
    /// Total records ingested across all sources.
    pub total_records: usize,
    /// Unique identities produced.
    pub unique_identities: usize,
    /// Records identified as duplicates (total_records - unique_identities).
    pub duplicates_found: usize,
    /// Records that need human review before merge/split decision.
    pub needs_review: usize,
    /// Merge rate as a user-friendly percentage string (e.g. "74%").
    pub merge_rate_pct: String,
    /// One-line summary (e.g. "2,833 records resolved into 733 unique people (74% were duplicates). 25 need review.").
    pub summary: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InputSummary {
    pub total_source_records: usize,
    pub by_source: HashMap<String, usize>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutputSummary {
    pub canonical_identities: usize,
    pub merge_rate: f64,
    pub singleton_rate: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClusteringSummary {
    pub average_cluster_size: f64,
    pub max_cluster_size: usize,
    pub clusters_by_size: HashMap<String, usize>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MatchQualitySummary {
    pub accepted_matches: usize,
    pub rejected_matches: usize,
    pub ambiguous_matches: usize,
    pub average_match_score: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SurvivorshipSummary {
    pub fields_resolved: usize,
    pub conflicts_detected: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StabilitySummary {
    pub deterministic_merges: usize,
    pub fuzzy_merges: usize,
    pub fuzzy_merge_ratio: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HealthFlag {
    pub code: String,
    pub severity: String,
    pub message: String,
}

// ============================================================================
// CONFIDENCE DISTRIBUTION — post-reconciliation confidence analysis (A14)
// ============================================================================

/// Bucketed confidence distribution with percentiles and bimodality measure.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConfidenceDistribution {
    pub histogram: Vec<ConfidenceBucket>,
    pub percentiles: ConfidencePercentiles,
    /// 0 = unimodal, 1 = perfectly bimodal. Good FS models produce bimodal distributions.
    pub bimodality_score: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConfidenceBucket {
    pub range_start: f64,
    pub range_end: f64,
    pub count: usize,
    pub pct: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConfidencePercentiles {
    pub p5: f64,
    pub p25: f64,
    pub p50: f64,
    pub p75: f64,
    pub p95: f64,
}

impl ConfidenceDistribution {
    /// Compute confidence distribution from a set of confidence scores.
    pub fn from_scores(scores: &[f64]) -> Self {
        if scores.is_empty() {
            return Self {
                histogram: vec![],
                percentiles: ConfidencePercentiles { p5: 0.0, p25: 0.0, p50: 0.0, p75: 0.0, p95: 0.0 },
                bimodality_score: 0.0,
            };
        }

        let mut sorted = scores.to_vec();
        sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let n = sorted.len();

        // Percentiles
        let percentile = |p: f64| -> f64 {
            let idx = ((p / 100.0) * (n - 1) as f64).round() as usize;
            sorted[idx.min(n - 1)]
        };
        let percentiles = ConfidencePercentiles {
            p5: percentile(5.0),
            p25: percentile(25.0),
            p50: percentile(50.0),
            p75: percentile(75.0),
            p95: percentile(95.0),
        };

        // Histogram: determine range from data
        let min_score = sorted[0];
        let max_score = sorted[n - 1];
        let bucket_width = 0.5_f64;

        let mut histogram = Vec::new();
        if (max_score - min_score).abs() < f64::EPSILON {
            // All scores are the same
            histogram.push(ConfidenceBucket {
                range_start: min_score,
                range_end: min_score + bucket_width,
                count: n,
                pct: 100.0,
            });
        } else {
            let num_buckets = ((max_score - min_score) / bucket_width).ceil() as usize + 1;
            let start = (min_score / bucket_width).floor() * bucket_width;

            for i in 0..num_buckets {
                let range_start = start + (i as f64) * bucket_width;
                let range_end = range_start + bucket_width;
                let count = sorted.iter()
                    .filter(|&&s| s >= range_start && s < range_end)
                    .count();
                histogram.push(ConfidenceBucket {
                    range_start,
                    range_end,
                    count,
                    pct: (count as f64 / n as f64) * 100.0,
                });
            }
        }

        // Bimodality coefficient (Sarle's coefficient)
        // BC = (skewness² + 1) / (kurtosis + 3 * (n-1)²/((n-2)(n-3)))
        // Simplified: measure how far the distribution is from uniform
        let mean: f64 = sorted.iter().sum::<f64>() / n as f64;
        let variance: f64 = sorted.iter().map(|s| (s - mean).powi(2)).sum::<f64>() / n as f64;
        let std_dev = variance.sqrt();

        let bimodality_score = if std_dev > 1e-10 && n > 3 {
            let skewness: f64 = sorted.iter()
                .map(|s| ((s - mean) / std_dev).powi(3))
                .sum::<f64>() / n as f64;
            let kurtosis: f64 = sorted.iter()
                .map(|s| ((s - mean) / std_dev).powi(4))
                .sum::<f64>() / n as f64;

            // Bimodality coefficient: higher = more bimodal
            let bc = (skewness.powi(2) + 1.0) / kurtosis;
            bc.clamp(0.0, 1.0)
        } else {
            0.0
        };

        Self { histogram, percentiles, bimodality_score }
    }
}

// ============================================================================
// RULE TELEMETRY — per-rule metrics collected during reconciliation
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleTelemetry {
    pub rule_name: String,
    pub evaluated: usize,
    pub matched: usize,
    pub skipped: usize,
    pub skip_reason: Option<String>,
    pub avg_score: f64,
}

// ============================================================================
// RECONCILIATION TELEMETRY — aggregate metrics from a reconciliation run
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ReconciliationTelemetry {
    pub rule_telemetry: Vec<RuleTelemetry>,
    pub blocking_groups: usize,
    pub pairs_evaluated: usize,
    pub decisions_by_type: HashMap<String, usize>,
    /// Scoring method used (e.g., "weighted_sum" or "fellegi_sunter").
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub scoring_method: Option<String>,
    /// Merge threshold applied for match decisions.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub merge_threshold: Option<f64>,
    /// Number of blocking groups that exceeded max_block_size and were skipped.
    #[serde(default, skip_serializing_if = "is_zero")]
    pub oversized_blocking_groups: usize,
}

fn is_zero(v: &usize) -> bool { *v == 0 }

// ============================================================================
// RUN HEALTH — derived health status from identity summary + telemetry
// ============================================================================

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RunHealth {
    pub status: HealthStatus,
    pub signals: Vec<HealthSignal>,
    pub recommendations: Vec<String>,
    pub rule_telemetry: Vec<RuleTelemetry>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum HealthStatus {
    Healthy,
    Degraded,
    Unhealthy,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HealthSignal {
    pub id: String,
    pub severity: String,
    pub message: String,
    pub likely_causes: Vec<String>,
}

impl RunHealth {
    pub fn derive(summary: &IdentitySummary, telemetry: &ReconciliationTelemetry) -> Self {
        let mut signals = Vec::new();
        let mut recommendations = Vec::new();

        if summary.output.canonical_identities == 0 && summary.input.total_source_records > 0 {
            signals.push(HealthSignal {
                id: "zero_matches".to_string(),
                severity: "critical".to_string(),
                message: format!(
                    "No canonical identities created from {} source records",
                    summary.input.total_source_records
                ),
                likely_causes: vec![
                    "Blocking keys too restrictive — no entity pairs formed".to_string(),
                    "Match thresholds too high for the data".to_string(),
                    "Field mappings incorrect — matching fields are empty".to_string(),
                ],
            });
            recommendations.push("Review blocking key configuration and verify field mappings populate matching fields".to_string());
        }

        if summary.output.merge_rate == 0.0 && summary.input.total_source_records > 1 {
            signals.push(HealthSignal {
                id: "zero_merges".to_string(),
                severity: "high".to_string(),
                message: "No records were merged — every record became its own canonical identity".to_string(),
                likely_causes: vec![
                    "No overlapping values across sources for matching fields".to_string(),
                    "Match threshold too high".to_string(),
                    "Blocking keys preventing candidate pair formation".to_string(),
                ],
            });
            recommendations.push("Lower match thresholds or add fuzzy matching rules".to_string());
        }

        if summary.clustering.max_cluster_size <= 1 && summary.input.total_source_records > 1 {
            signals.push(HealthSignal {
                id: "all_singletons".to_string(),
                severity: "high".to_string(),
                message: "All clusters contain only a single record".to_string(),
                likely_causes: vec![
                    "Blocking strategy prevents pair formation".to_string(),
                    "Match rules are too strict".to_string(),
                ],
            });
            recommendations.push("Consider broadening blocking keys or adding composite rules".to_string());
        }

        if telemetry.oversized_blocking_groups > 0 {
            signals.push(HealthSignal {
                id: "oversized_blocking_groups".to_string(),
                severity: "high".to_string(),
                message: format!(
                    "{} blocking group(s) exceeded max_block_size and were skipped during matching",
                    telemetry.oversized_blocking_groups
                ),
                likely_causes: vec![
                    "A blocking key has very low cardinality (e.g., blocking on 'country' puts thousands of records in one group)".to_string(),
                    "Data quality issue - many records share the same blocking key value".to_string(),
                ],
            });
            recommendations.push("Use more selective blocking keys or add composite blocking keys to reduce group sizes".to_string());
        }

        if summary.clustering.max_cluster_size > 10 {
            signals.push(HealthSignal {
                id: "large_cluster".to_string(),
                severity: "medium".to_string(),
                message: format!(
                    "Largest cluster contains {} records — possible over-merging",
                    summary.clustering.max_cluster_size
                ),
                likely_causes: vec![
                    "Fuzzy threshold too low, causing transitive merges".to_string(),
                    "Common values in matching fields (e.g., generic names)".to_string(),
                ],
            });
            recommendations.push("Add reference identifiers or tighten fuzzy thresholds to reduce cluster size".to_string());
        }

        for rt in &telemetry.rule_telemetry {
            if rt.evaluated > 0 && rt.matched == 0 {
                signals.push(HealthSignal {
                    id: "rules_never_triggered".to_string(),
                    severity: "medium".to_string(),
                    message: format!(
                        "Rule '{}' was evaluated {} times but never matched",
                        rt.rule_name, rt.evaluated
                    ),
                    likely_causes: vec![
                        "Threshold too high for the data distribution".to_string(),
                        "Field values never overlap across sources".to_string(),
                    ],
                });
            }
        }

        for rt in &telemetry.rule_telemetry {
            if rt.evaluated == 0 {
                signals.push(HealthSignal {
                    id: "rules_never_evaluated".to_string(),
                    severity: "medium".to_string(),
                    message: format!("Rule '{}' was never evaluated", rt.rule_name),
                    likely_causes: vec![
                        "Blocking strategy excludes all pairs for this rule's field".to_string(),
                        "No entity pairs were formed".to_string(),
                    ],
                });
            }
        }

        if summary.stability.fuzzy_merge_ratio > 0.5 {
            signals.push(HealthSignal {
                id: "high_fuzzy_ratio".to_string(),
                severity: "low".to_string(),
                message: format!(
                    "{:.0}% of merges rely on fuzzy matching — results may vary with data changes",
                    summary.stability.fuzzy_merge_ratio * 100.0
                ),
                likely_causes: vec![
                    "Few exact-match fields available".to_string(),
                    "Data quality requires fuzzy matching".to_string(),
                ],
            });
            recommendations.push("Add exact matching rules (email, phone, SSN) where possible to improve stability".to_string());
        }

        if summary.match_quality.average_match_score < 0.7 && summary.match_quality.accepted_matches > 0 {
            signals.push(HealthSignal {
                id: "low_avg_confidence".to_string(),
                severity: "medium".to_string(),
                message: format!(
                    "Average match confidence is {:.2} — below 0.70 threshold",
                    summary.match_quality.average_match_score
                ),
                likely_causes: vec![
                    "Fuzzy thresholds are close to the merge threshold".to_string(),
                    "Low-quality or incomplete source data".to_string(),
                ],
            });
            recommendations.push("Consider increasing match thresholds or improving data quality upstream".to_string());
        }

        let status = if signals.iter().any(|s| s.severity == "critical") {
            HealthStatus::Unhealthy
        } else if signals.iter().any(|s| s.severity == "high") {
            HealthStatus::Degraded
        } else {
            HealthStatus::Healthy
        };

        RunHealth {
            status,
            signals,
            recommendations,
            rule_telemetry: telemetry.rule_telemetry.clone(),
        }
    }
}

// ============================================================================
// Telemetry Collector — accumulates per-rule counters during reconciliation
// ============================================================================

#[derive(Debug, Default)]
pub struct TelemetryCollector {
    pub rule_stats: HashMap<String, RuleStats>,
    pub pairs_evaluated: usize,
    pub blocking_groups: usize,
    pub decisions: HashMap<String, usize>,
    pub oversized_blocking_groups: usize,
}

#[derive(Debug, Default, Clone)]
pub struct RuleStats {
    pub evaluated: usize,
    pub matched: usize,
    pub skipped: usize,
    pub scores: Vec<f64>,
}

impl TelemetryCollector {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn record_pair(&mut self, rule_results: &[super::types::RuleResult], decision_type: &str) {
        self.pairs_evaluated += 1;
        *self.decisions.entry(decision_type.to_string()).or_insert(0) += 1;

        for rr in rule_results {
            let stats = self.rule_stats.entry(rr.rule_name.clone()).or_default();
            stats.evaluated += 1;
            stats.scores.push(rr.score);
            if rr.matched {
                stats.matched += 1;
            }
        }
    }

    pub fn into_telemetry(self) -> ReconciliationTelemetry {
        let mut rule_telemetry: Vec<RuleTelemetry> = self.rule_stats.into_iter().map(|(name, mut stats)| {
            // Sort scores before summing for deterministic floating-point accumulation
            // regardless of parallel execution order
            stats.scores.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
            let total_score: f64 = stats.scores.iter().sum();
            RuleTelemetry {
                rule_name: name,
                evaluated: stats.evaluated,
                matched: stats.matched,
                skipped: stats.skipped,
                skip_reason: None,
                avg_score: if stats.evaluated > 0 {
                    total_score / stats.evaluated as f64
                } else {
                    0.0
                },
            }
        }).collect();

        // Sort by rule_name for deterministic ordering
        rule_telemetry.sort_by(|a, b| a.rule_name.cmp(&b.rule_name));

        ReconciliationTelemetry {
            rule_telemetry,
            blocking_groups: self.blocking_groups,
            pairs_evaluated: self.pairs_evaluated,
            decisions_by_type: self.decisions,
            scoring_method: None,
            merge_threshold: None,
            oversized_blocking_groups: self.oversized_blocking_groups,
        }
    }
}
