use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use uuid::Uuid;

/// A cluster of entities with aggregate confidence metrics.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClusterWithConfidence {
    pub members: Vec<Uuid>,
    pub avg_confidence: f64,
    pub min_confidence: f64,
    pub max_confidence: f64,
    pub pair_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NormalizedEntity {
    pub id: Uuid,
    pub tenant_id: Uuid,
    pub external_id: String,
    pub entity_type: String,
    pub data: HashMap<String, String>,
    pub source_name: String,
    pub valid_from: Option<chrono::DateTime<chrono::Utc>>,
    pub valid_to: Option<chrono::DateTime<chrono::Utc>>,
    pub last_updated: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum Decision {
    Merge,
    Review,
    NoMerge,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleResult {
    pub rule_name: String,
    pub score: f64,
    pub weight: f64,
    pub matched: bool,
    pub explanation: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MatchDecision {
    pub entity_a_id: Uuid,
    pub entity_b_id: Uuid,
    pub decision: Decision,
    pub confidence: f64,
    /// P(match|data) — posterior probability derived from log-likelihood (FS only)
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub posterior_probability: Option<f64>,
    pub rule_results: Vec<RuleResult>,
    pub matched_on: Vec<String>,
    pub blocking_key: Option<String>,
    pub temporal_adjustment: Option<f64>,
}
