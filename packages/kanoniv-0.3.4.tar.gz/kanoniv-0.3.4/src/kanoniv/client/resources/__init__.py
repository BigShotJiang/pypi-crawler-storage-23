"""Resource sub-clients for the Kanoniv API."""
