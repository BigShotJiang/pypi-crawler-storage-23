"""Allow ``python -m kanoniv.cli``."""
from __future__ import annotations

from kanoniv.cli.main import main

main()
