# coding=utf-8
"""
run the test from the src/invesytoolbox directory:
pytest ../tests/test_html.py -v
"""
import json
from pathlib import Path

from bs4 import BeautifulSoup
from invesytoolbox.itb_html import change_h_tags, prettify_html

TESTDATA = Path(__file__).parent / 'testdata'
with open(TESTDATA / 'html_samples.json') as f:
    _data = json.load(f)

html_raw = _data['html_raw']
h_tag_changed = _data['h_tag_changed']
html_pretty = _data['html_pretty']


def test_prettify_html() -> str:
    html_prettified = prettify_html(html_raw)
    assert html_prettified.strip() == html_pretty.strip()


def test_change_h_tags() -> str:
    """
    Prettifying is needed to compare the results
    (we could have compared the soups as well)
    """
    html = prettify_html(html_raw)
    for i in (1, 2):
        html_h_changed = change_h_tags(
            html=html_raw,
            change=i,
            returning='pretty'
        )
        assert html_h_changed == prettify_html(h_tag_changed[str(i)])
