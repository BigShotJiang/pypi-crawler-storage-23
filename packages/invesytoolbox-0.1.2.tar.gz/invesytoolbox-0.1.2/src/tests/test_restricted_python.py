# coding=utf-8
"""
run the test from the src/invesytoolbox directory:
pytest ../tests/test_restricted_python.py -v
"""

from invesytoolbox.itb_restricted_python import contains_all, contains_any, remove_duplicates


def test_contains_all():
    assert contains_all([1, 2, 3, 4, 5], [1, 2, 3]) is True
    assert contains_all([1, 2, 3, 4, 5], [1, 5]) is True
    assert contains_all([1, 2, 3, 4, 5], [6]) is False
    assert contains_all([1, 2, 3], [1, 2, 3, 4]) is False
    assert contains_all(['a', 'b', 'c'], ['a', 'c']) is True
    assert contains_all(['a', 'b', 'c'], ['a', 'd']) is False
    assert contains_all([1, 2, 3], []) is True
    assert contains_all([], []) is True
    assert contains_all([], [1]) is False


def test_contains_any():
    assert contains_any([1, 2, 3, 4, 5], [1, 6, 7]) is True
    assert contains_any([1, 2, 3, 4, 5], [6, 7, 8]) is False
    assert contains_any([1, 2, 3], [3, 4, 5]) is True
    assert contains_any(['a', 'b', 'c'], ['d', 'e']) is False
    assert contains_any(['a', 'b', 'c'], ['c', 'd']) is True
    assert contains_any([1, 2, 3], []) is False
    assert contains_any([], [1]) is False
    assert contains_any([], []) is False


def test_remove_duplicates():
    result = remove_duplicates([1, 2, 2, 3, 3, 3])
    assert sorted(result) == [1, 2, 3]

    result = remove_duplicates([1, 2, 3])
    assert sorted(result) == [1, 2, 3]

    result = remove_duplicates([])
    assert result == []

    result = remove_duplicates(['a', 'b', 'a', 'c', 'b'])
    assert sorted(result) == ['a', 'b', 'c']

    result = remove_duplicates([1])
    assert result == [1]
