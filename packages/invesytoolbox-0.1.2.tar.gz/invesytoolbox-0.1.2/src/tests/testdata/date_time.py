# coding=utf-8
"""Test data for test_date_time.py

Contains datetime/DateTime/pendulum objects, so this must be a Python file.
"""

import datetime
from zoneinfo import ZoneInfo

import DateTime

get_dateformat_error_str_part = ' is not a valid date or datetime string.'

_TZ_VIENNA = ZoneInfo('Europe/Vienna')


def _DT(*args):
    """Create a Zope DateTime with Europe/Vienna timezone, matching str_to_DT behavior."""
    dt = datetime.datetime(*args, tzinfo=_TZ_VIENNA)
    return DateTime.DateTime(dt)

dates_for_checking = {
    # --- European format dd.mm.yyyy ---
    '2.4.2020': {
        'is_valid': True,
        'convert_fmt': '%d.%m.%Y',
        'datetime': datetime.datetime(2020, 4, 2),
        'date': datetime.date(2020, 4, 2),
        'DateTime': _DT(2020, 4, 2),
        'Date': _DT(2020, 4, 2, 12),
        'week': 14,
        'dow_number': 4,
        'monday': datetime.date(2020, 3, 30),
        'sunday': datetime.date(2020, 4, 5),
        'isocalendar': (2020, 14, 4),
        'last_week': 53,
        'datetime_notime': datetime.datetime(2020, 4, 2),
        'DateTime_notime': _DT(2020, 4, 2)
    },
    '21.5.1980': {
        'is_valid': True,
        'convert_fmt': '%d.%m.%Y',
        'datetime': datetime.datetime(1980, 5, 21),
        'date': datetime.date(1980, 5, 21),
        'DateTime': _DT(1980, 5, 21),
        'Date': _DT(1980, 5, 21, 12),
        'week': 21,
        'dow_number': 3,
        'monday': datetime.date(1980, 5, 19),
        'sunday': datetime.date(1980, 5, 25),
        'isocalendar': (1980, 21, 3),
        'last_week': 52,
        'datetime_notime': datetime.datetime(1980, 5, 21),
        'DateTime_notime': _DT(1980, 5, 21)
    },
    '05.05.2001': {
        'is_valid': True,
        'convert_fmt': '%d.%m.%Y',
        'datetime': datetime.datetime(2001, 5, 5),
        'date': datetime.date(2001, 5, 5),
        'DateTime': _DT(2001, 5, 5),
        'Date': _DT(2001, 5, 5, 12),
        'week': 18,
        'dow_number': 6,
        'monday': datetime.date(2001, 4, 30),
        'sunday': datetime.date(2001, 5, 6),
        'isocalendar': (2001, 18, 6),
        'last_week': 52,
        'datetime_notime': datetime.datetime(2001, 5, 5),
        'DateTime_notime': _DT(2001, 5, 5)
    },
    # --- yyyy/mm/dd format ---
    '2000/5/6': {
        'is_valid': True,
        'convert_fmt': '%Y/%m/%d',
        'datetime': datetime.datetime(2000, 5, 6),
        'date': datetime.date(2000, 5, 6),
        'DateTime': _DT(2000, 5, 6),
        'Date': _DT(2000, 5, 6, 12),
        'week': 18,
        'dow_number': 6,
        'monday': datetime.date(2000, 5, 1),
        'sunday': datetime.date(2000, 5, 7),
        'isocalendar': (2000, 18, 6),
        'last_week': 52,
        'datetime_notime': datetime.datetime(2000, 5, 6),
        'DateTime_notime': _DT(2000, 5, 6)
    },
    # --- US format mm/dd/yyyy ---
    '3/4/1970': {  # US format: March 4, 1970
        'is_valid': True,
        'convert_fmt': '%m/%d/%Y',
        'datetime': datetime.datetime(1970, 3, 4),
        'date': datetime.date(1970, 3, 4),
        'DateTime': _DT(1970, 3, 4),
        'Date': _DT(1970, 3, 4, 12),
        'week': 10,
        'dow_number': 3,
        'monday': datetime.date(1970, 3, 2),
        'sunday': datetime.date(1970, 3, 8),
        'isocalendar': (1970, 10, 3),
        'last_week': 53,
        'datetime_notime': datetime.datetime(1970, 3, 4),
        'DateTime_notime': _DT(1970, 3, 4)
    },
    # --- ISO format yyyy-mm-dd ---
    '2022-05-31': {
        'is_valid': True,
        'convert_fmt': '%Y-%m-%d',
        'datetime': datetime.datetime(2022, 5, 31),
        'date': datetime.date(2022, 5, 31),
        'DateTime': _DT(2022, 5, 31),
        'Date': _DT(2022, 5, 31, 12),
        'week': 22,
        'dow_number': 2,
        'monday': datetime.date(2022, 5, 30),
        'sunday': datetime.date(2022, 6, 5),
        'isocalendar': (2022, 22, 2),
        'last_week': 52,
        'datetime_notime': datetime.datetime(2022, 5, 31),
        'DateTime_notime': _DT(2022, 5, 31)
    },
    # --- Invalid formats ---
    '31-05-2022': {
        'is_valid': False,
        'convert_fmt': '31-05-2022' + get_dateformat_error_str_part,
        'datetime': None,
        'date': None,
        'DateTime': None,
        'Date': None,
        'week': None,
        'dow_number': None,
        'monday': None,
        'sunday': None,
        'isocalendar': None,
        'last_week': None,
        'datetime_notime': None,
        'DateTime_notime': None
    },
    '13/7/2000': {
        'is_valid': False,
        'convert_fmt': '13/7/2000' + get_dateformat_error_str_part,
        'datetime': None,
        'date': None,
        'DateTime': None,
        'Date': None,
        'dow_number': None,
        'monday': None,
        'sunday': None,
        'isocalendar': None,
        'last_week': None,
        'datetime_notime': None,
        'DateTime_notime': None
    },
    # --- Date with time ---
    '06.05.2001 14:56': {
        'is_valid': True,
        'convert_fmt': '%d.%m.%Y %H:%M',
        'datetime': datetime.datetime(2001, 5, 6, 14, 56),
        'date': datetime.date(2001, 5, 6),
        'DateTime': _DT(2001, 5, 6, 14, 56),
        'Date': _DT(2001, 5, 6, 12),
        'week': 18,
        'dow_number': 7,
        'monday': datetime.date(2001, 4, 30),
        'sunday': datetime.date(2001, 5, 6),
        'isocalendar': (2001, 18, 7),
        'last_week': 52,
        'datetime_notime': datetime.datetime(2001, 5, 6),
        'DateTime_notime': _DT(2001, 5, 6)
    },
    # --- Additional: leap year date ---
    '29.2.2024': {
        'is_valid': True,
        'convert_fmt': '%d.%m.%Y',
        'datetime': datetime.datetime(2024, 2, 29),
        'date': datetime.date(2024, 2, 29),
        'DateTime': _DT(2024, 2, 29),
        'Date': _DT(2024, 2, 29, 12),
        'week': 9,
        'dow_number': 4,
        'monday': datetime.date(2024, 2, 26),
        'sunday': datetime.date(2024, 3, 3),
        'isocalendar': (2024, 9, 4),
        'last_week': 52,
        'datetime_notime': datetime.datetime(2024, 2, 29),
        'DateTime_notime': _DT(2024, 2, 29)
    },
    # --- Additional: new year's day (week 1 boundary) ---
    '1.1.2024': {
        'is_valid': True,
        'convert_fmt': '%d.%m.%Y',
        'datetime': datetime.datetime(2024, 1, 1),
        'date': datetime.date(2024, 1, 1),
        'DateTime': _DT(2024, 1, 1),
        'Date': _DT(2024, 1, 1, 12),
        'week': 1,
        'dow_number': 1,
        'monday': datetime.date(2024, 1, 1),
        'sunday': datetime.date(2024, 1, 7),
        'isocalendar': (2024, 1, 1),
        'last_week': 52,
        'datetime_notime': datetime.datetime(2024, 1, 1),
        'DateTime_notime': _DT(2024, 1, 1)
    },
    # --- Additional: year-end (ISO week belongs to next year) ---
    '31.12.2020': {
        'is_valid': True,
        'convert_fmt': '%d.%m.%Y',
        'datetime': datetime.datetime(2020, 12, 31),
        'date': datetime.date(2020, 12, 31),
        'DateTime': _DT(2020, 12, 31),
        'Date': _DT(2020, 12, 31, 12),
        'week': 53,
        'dow_number': 4,
        'monday': datetime.date(2020, 12, 28),
        'sunday': datetime.date(2021, 1, 3),
        'isocalendar': (2020, 53, 4),
        'last_week': 53,
        'datetime_notime': datetime.datetime(2020, 12, 31),
        'DateTime_notime': _DT(2020, 12, 31)
    },
    # --- Additional: midnight time ---
    '15.03.2023 00:00': {
        'is_valid': True,
        'convert_fmt': '%d.%m.%Y %H:%M',
        'datetime': datetime.datetime(2023, 3, 15, 0, 0),
        'date': datetime.date(2023, 3, 15),
        'DateTime': _DT(2023, 3, 15, 0, 0),
        'Date': _DT(2023, 3, 15, 12),
        'week': 11,
        'dow_number': 3,
        'monday': datetime.date(2023, 3, 13),
        'sunday': datetime.date(2023, 3, 19),
        'isocalendar': (2023, 11, 3),
        'last_week': 52,
        'datetime_notime': datetime.datetime(2023, 3, 15),
        'DateTime_notime': _DT(2023, 3, 15)
    },
    # --- Additional: time with seconds ---
    '15.05.2023 14:30:45': {
        'is_valid': True,
        'convert_fmt': '%d.%m.%Y %H:%M:%S',
        'datetime': datetime.datetime(2023, 5, 15, 14, 30, 45),
        'date': datetime.date(2023, 5, 15),
        'DateTime': _DT(2023, 5, 15, 14, 30, 45),
        'Date': _DT(2023, 5, 15, 12),
        'week': 20,
        'dow_number': 1,
        'monday': datetime.date(2023, 5, 15),
        'sunday': datetime.date(2023, 5, 21),
        'isocalendar': (2023, 20, 1),
        'last_week': 52,
        'datetime_notime': datetime.datetime(2023, 5, 15),
        'DateTime_notime': _DT(2023, 5, 15)
    },
}

durations = {
    '5T23:04:17': {
        'list': [5, 23, 4, 17, 0],
        'dictionary': {
            'days': 5,
            'hours': 23,
            'minutes': 4,
            'seconds': 17,
            'milliseconds': 0
        }
    },
    '45:3:18:1500': {
        'list': [1, 21, 3, 19, 500],
        'dictionary': {
            'days': 1,
            'hours': 21,
            'minutes': 3,
            'seconds': 19,
            'milliseconds': 500
        }
    },
    '4T58:68:17': {
        'list': [6, 11, 8, 17, 0],
        'dictionary': {
            'days': 6,
            'hours': 11,
            'minutes': 8,
            'seconds': 17,
            'milliseconds': 0
        }
    },
    # Additional: zero duration
    '0T00:00:00': {
        'list': [0, 0, 0, 0, 0],
        'dictionary': {
            'days': 0,
            'hours': 0,
            'minutes': 0,
            'seconds': 0,
            'milliseconds': 0
        }
    },
    # Additional: large overflow in hours
    '0T99:00:00': {
        'list': [4, 3, 0, 0, 0],
        'dictionary': {
            'days': 4,
            'hours': 3,
            'minutes': 0,
            'seconds': 0,
            'milliseconds': 0
        }
    },
    # Additional: milliseconds only
    '0T00:00:00:5000': {
        'list': [0, 0, 0, 5, 0],
        'dictionary': {
            'days': 0,
            'hours': 0,
            'minutes': 0,
            'seconds': 5,
            'milliseconds': 0
        }
    },
}

iso8601_tests = {
    # without seconds
    '2023-05-15T14:30': True,
    '2023-05-15T14:30Z': True,
    '2023-05-15T14:30+02:00': True,
    '2023-05-15T14:30+0200': True,
    # with seconds
    '2023-05-15T14:30:00': True,
    '2023-05-15T14:30:00Z': True,
    '2023-05-15T14:30:00+02:00': True,
    '2023-05-15T14:30:00+0200': True,
    # with milliseconds
    '2023-05-15T14:30:00.123': True,
    '2023-05-15T14:30:00.123Z': True,
    '2023-05-15T14:30:00.123+02:00': True,
    '2023-05-15T14:30:00.123+0200': True,
    # with microseconds
    '2023-05-15T14:30:00.123456': True,
    '2023-05-15T14:30:00.123456Z': True,
    # negative offset
    '2023-05-15T14:30:00-05:00': True,
    '2023-05-15T14:30:00-0500': True,
    # invalid ISO8601
    'not-a-dateT99:99:99': False,
    '2023-13-15T14:30:00': False,
    '2023-05-32T14:30:00': False,
    # Additional: midnight
    '2023-05-15T00:00:00': True,
    '2023-05-15T00:00:00Z': True,
    # Additional: end of day
    '2023-05-15T23:59:59': True,
    # Additional: date only (valid date, but not ISO8601 datetime with T)
    '2023-05-15': True,
}
