# coding=utf-8
"""Test data for test_locales.py — datetime-dependent objects.

Contains datetime/DateTime objects, so this must be a Python file.
"""

import datetime

import DateTime

days_and_holidays = {
    # String dates
    '1.4.2020': False,
    '2022-05-01': True,
    '6.1.2023': True,
    '2023/6/1': False,
    '01/06/2023': True,
    '1/6/2023': True,
    '13.8.2022': False,
    # datetime.date
    datetime.date(2022, 5, 1): True,
    datetime.date(2022, 12, 11): False,
    # datetime.datetime
    datetime.datetime(2023, 1, 6): True,
    datetime.datetime(2023, 1, 11): False,
    # DateTime.DateTime
    DateTime.DateTime(2023, 1, 6): True,
    DateTime.DateTime(2023, 1, 11): False,
    # Additional: Christmas and New Year
    datetime.date(2023, 12, 25): True,
    datetime.date(2023, 12, 26): True,
    datetime.date(2024, 1, 1): True,
    # Additional: regular workdays
    datetime.date(2023, 3, 15): False,
    datetime.date(2024, 7, 10): False,
    # Additional: Austrian National Day
    datetime.date(2023, 10, 26): True,
    '26.10.2022': True,
}

feiertage_2022_2023 = {
    datetime.date(2022, 1, 1): 'Neujahr',
    datetime.date(2022, 1, 6): 'Heilige Drei Könige',
    datetime.date(2022, 4, 18): 'Ostermontag',
    datetime.date(2022, 5, 1): 'Staatsfeiertag',
    datetime.date(2022, 5, 26): 'Christi Himmelfahrt',
    datetime.date(2022, 6, 6): 'Pfingstmontag',
    datetime.date(2022, 6, 16): 'Fronleichnam',
    datetime.date(2022, 8, 15): 'Mariä Himmelfahrt',
    datetime.date(2022, 10, 26): 'Nationalfeiertag',
    datetime.date(2022, 11, 1): 'Allerheiligen',
    datetime.date(2022, 12, 8): 'Mariä Empfängnis',
    datetime.date(2022, 12, 25): 'Christtag',
    datetime.date(2022, 12, 26): 'Stefanitag',
    datetime.date(2023, 1, 1): 'Neujahr',
    datetime.date(2023, 1, 6): 'Heilige Drei Könige',
    datetime.date(2023, 4, 10): 'Ostermontag',
    datetime.date(2023, 5, 1): 'Staatsfeiertag',
    datetime.date(2023, 5, 18): 'Christi Himmelfahrt',
    datetime.date(2023, 5, 29): 'Pfingstmontag',
    datetime.date(2023, 6, 8): 'Fronleichnam',
    datetime.date(2023, 8, 15): 'Mariä Himmelfahrt',
    datetime.date(2023, 10, 26): 'Nationalfeiertag',
    datetime.date(2023, 11, 1): 'Allerheiligen',
    datetime.date(2023, 12, 8): 'Mariä Empfängnis',
    datetime.date(2023, 12, 25): 'Christtag',
    datetime.date(2023, 12, 26): 'Stefanitag',
    datetime.date(2024, 1, 1): 'Neujahr',
    datetime.date(2024, 1, 6): 'Heilige Drei Könige',
    datetime.date(2024, 4, 1): 'Ostermontag',
    datetime.date(2024, 5, 1): 'Staatsfeiertag',
    datetime.date(2024, 5, 9): 'Christi Himmelfahrt',
    datetime.date(2024, 5, 20): 'Pfingstmontag',
    datetime.date(2024, 5, 30): 'Fronleichnam',
    datetime.date(2024, 8, 15): 'Mariä Himmelfahrt',
    datetime.date(2024, 10, 26): 'Nationalfeiertag',
    datetime.date(2024, 11, 1): 'Allerheiligen',
    datetime.date(2024, 12, 8): 'Mariä Empfängnis',
    datetime.date(2024, 12, 25): 'Christtag',
    datetime.date(2024, 12, 26): 'Stefanitag'
}
