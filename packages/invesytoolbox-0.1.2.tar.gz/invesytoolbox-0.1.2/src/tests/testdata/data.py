# coding=utf-8
"""Test data for test_data.py

Contains datetime/DateTime objects and bytes literals, so this must be a Python file.
"""

import datetime
from zoneinfo import ZoneInfo

import DateTime
from dateutil.parser import parse

dict_list = [
    {'a': 1, 'b': 2, 'c': 5},
    {'a': 2, 'b': 3, 'c': 4},
    {'a': 3, 'b': 4, 'c': 3}
]

dict_list_sorted_by_c = [
    {'a': 3, 'b': 4, 'c': 3},
    {'a': 2, 'b': 3, 'c': 4},
    {'a': 1, 'b': 2, 'c': 5}
]

dicts_from_dict_list = [
    {
        1: {'b': 2, 'c': 5},
        2: {'b': 3, 'c': 4},
        3: {'b': 4, 'c': 3}
    },
    {
        1: {'a': 1, 'b': 2, 'c': 5},
        2: {'a': 2, 'b': 3, 'c': 4},
        3: {'a': 3, 'b': 4, 'c': 3}
    },
    {
        1: 2,
        2: 3,
        3: 4
    },
    {
        1: 5,
        2: 4,
        3: 3
    }
]

test_boolean = {
    True: True,
    False: False,
    1: True,
    '2': True,
    2: True,
    0: False,
    '0': False,
    b'0': False,
    'False': False,
    'True': True,
    b'False': False,
    b'True': True,
    'xyz': True,
    # Additional test cases
    'false': False,
    'true': True,
    'yes': True,
    'YES': True,
    b'false': False,
    b'true': True,
    '': False,
    b'': False,
    None: False,
    '1': True,
    b'1': True,
}

dict_for_testing = {
    1: 'test one',
    '2': b'test two',
    b'3': 'test three',
    True: 'test four',  # overrides 1
    'five': 5,
    b'six': True,
    b'7.0': ['1', b'2'],
    8.0: {'a': b'xy'},
    '9.0': 'False',
    b'False': b'True',
    'x': '01.04.2022',
    'y': '10:32'
}

dict_for_testing_unicoded = {
    1: 'test four',
    '2': 'test two',
    '3': 'test three',
    'five': 5,
    'six': True,
    '7.0': ['1', b'2'],
    8.0: {'a': b'xy'},
    '9.0': 'False',
    'False': 'True',
    'x': '01.04.2022',
    'y': '10:32'
}

dict_for_testing_datatyped = {
    1: 'test four',
    2: b'test two',
    3: 'test three',
    'five': 5,
    b'six': True,
    7.0: ['1', b'2'],
    8.0: {'a': b'xy'},
    9.0: False,
    False: True,
    'x': datetime.date(2022, 4, 1),
    'y': parse('10:32').time()
}

dict_for_testing_datatyped_unicoded = {
    1: 'test four',
    2: 'test two',
    3: 'test three',
    'five': 5,
    'six': True,
    7.0: ['1', b'2'],
    8.0: {'a': b'xy'},
    9.0: False,
    False: True,
    'x': DateTime.DateTime(datetime.datetime(2022, 4, 1, tzinfo=ZoneInfo('Europe/Vienna'))),
    'y': '10:32'
}

vcard_data = {
    'prename': 'Georg',
    'surname': 'Tester',
    'email': 'georg.tester@test.at',
    'phone': '+43 699 123123123',
    'street': 'Teststraße 34',
    'city': 'Völkermarkt',
    'zipcode': '4321',
    'country': 'Österreich',
    'note': 'Eine hinzugefügte Notiz: Mit colon!'
}

sample_vcard = """BEGIN:VCARD
VERSION:3.0
ADR;TYPE=HOME,pref:;;Teststraße 34;Völkermarkt;;4321;Österreich
EMAIL;TYPE=INTERNET:georg.tester@test.at
FN:Georg Tester
N:Tester;Georg;;;
NOTE:Eine hinzugefügte Notiz: Mit colon!
TEL;TYPE=CELL,VOICE:+43 699 123123123
END:VCARD
"""

kwargs_list = [
    {
        'dict_list': dict_list,
        'key': 'a',
        'single_value': None,
        'include_key': False
    },
    {
        'dict_list': dict_list,
        'key': 'a',
        'single_value': None,
        'include_key': True
    },
    {
        'dict_list': dict_list,
        'key': 'a',
        'single_value': 'b'
    },
    {
        'dict_list': dict_list,
        'key': 'a',
        'single_value': 'c',
        'include_key': True
    }
]
