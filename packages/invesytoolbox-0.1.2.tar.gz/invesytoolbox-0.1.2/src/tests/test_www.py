# coding=utf-8
"""
run the test from the src/invesytoolbox directory:
pytest ../tests/test_www.py -v
"""
import json
from pathlib import Path

import pytest

from invesytoolbox.itb_www import change_query_string

TESTDATA = Path(__file__).parent / 'testdata'
with open(TESTDATA / 'www.json') as f:
    _data = json.load(f)

change_query_string_data = _data['change_query_string_data']


def test_change_query_string():
    for datum in change_query_string_data:
        new_url = change_query_string(
            url=datum.get('url'),
            params=datum.get('params'),
            returning='url'
        )
        assert new_url == datum.get('new_url')

        new_url = change_query_string(
            url=datum.get('url'),
            params=datum.get('params'),
            returning='url',
            delete_remaining=True
        )
        assert new_url == datum.get('new_url_fresh')

        new_query = change_query_string(
            query_string=datum.get('query'),
            params=datum.get('params'),
            returning='query_string'
        )
        assert new_query == datum.get('new_query')

        new_query = change_query_string(
            query_string=datum.get('query'),
            params=datum.get('params'),
            returning='query_string',
            delete_remaining=True
        )
        assert new_query == datum.get('new_query_fresh')

        new_query = change_query_string(
            url=datum.get('url'),
            params=datum.get('params'),
            returning='query_string'
        )
        assert new_query == datum.get('new_query')

        new_query = change_query_string(
            url=datum.get('url'),
            params=datum.get('params'),
            returning='query_string',
            delete_remaining=True
        )
        assert new_query == datum.get('new_query_fresh')

        with pytest.raises(ValueError):
            change_query_string(
                query_string=datum.get('query'),
                params=datum.get('params'),
                returning='url'
            )


def test_change_query_string_auto():
    """Test returning='auto' mode"""
    # auto with url -> returns url
    result = change_query_string(
        url='http://example.com/page?a=1',
        params={'b': '2'}
    )
    assert result == 'http://example.com/page?a=1&b=2'

    # auto with query_string -> returns query_string
    result = change_query_string(
        query_string='a=1',
        params={'b': '2'}
    )
    assert result == 'a=1&b=2'


def test_change_query_string_no_args():
    """Test TypeError when neither url nor query_string is provided"""
    with pytest.raises(TypeError):
        change_query_string(params={'a': '1'})


def test_change_query_string_zope_types():
    """Test that Zope data types are correctly unescaped"""
    result = change_query_string(
        query_string='name=test',
        params={'age:int': '25', 'active:boolean': 'True'},
        returning='query_string'
    )
    assert 'age:int=25' in result
    assert 'active:boolean=True' in result
    assert '%3A' not in result
