import importlib
from pathlib import Path

_package_dir = Path(__file__).resolve().parent

for _file in sorted(_package_dir.glob('itb_*.py')):
    _module = importlib.import_module(f'.{_file.stem}', package=__name__)
    _module_all = getattr(_module, '__all__', None)
    _names = _module_all if _module_all is not None else [
        name for name in dir(_module) if not name.startswith('_')
    ]
    for _name in _names:
        globals()[_name] = getattr(_module, _name)
