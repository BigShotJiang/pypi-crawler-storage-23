"""Allow ``python -m omega`` to invoke the CLI."""

from omega.cli import main

main()
