import re

def server_name_to_package(server_name: str) -> str:
    return server_name.replace("-", "_").lower()

def server_name_to_prefix(server_name: str) -> str:
    known_suffixes = set(["mcp", "server"])

    name_without_suffix = "_".join([word for word in server_name.split("-") if word not in known_suffixes])

    if name_without_suffix == "":
        return server_name_to_package(server_name)
    
    return name_without_suffix

def validate_server_name(server_name: str) -> tuple[bool, str | None]:
    valid_name_pattern = "^[a-z][a-z0-9]*(-[a-z0-9]+)*$"
    if re.search(valid_name_pattern, server_name):
        return (True, None)
    else:
        return (False, "Not a valid server name")
