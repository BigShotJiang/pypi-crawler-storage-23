from rich.console import Console
from rich.markup import escape

console = Console()

def success(message: str):
    console.print(f"[bold green]✓[/] {escape(message)}")

def error(message: str):
    console.print(f"[bold red]✗[/] {escape(message)}")

def warning(message: str):
    console.print(f"[bold yellow]⚠[/] {escape(message)}")

def info(message: str):
    console.print(f"[bold blue]ℹ[/] {escape(message)}")

def step(message: str):
    console.print(f"[bold]→[/] {escape(message)}")
