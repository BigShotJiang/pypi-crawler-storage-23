"""Workspace detection and path resolution for HatchDX projects."""

from __future__ import annotations

from pathlib import Path

WORKSPACE_MARKER = "hdx-workspace.toml"


def find_workspace(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default: CWD) looking for hdx-workspace.toml.

    Returns the directory containing the marker, or None if not found.
    """
    current = (start or Path.cwd()).resolve()

    for parent in [current, *current.parents]:
        if (parent / WORKSPACE_MARKER).is_file():
            return parent
    return None


def detect_output_dir(entity_type: str) -> Path:
    """Return the appropriate output directory for a server or agent.

    If inside a workspace, returns ``workspace/servers/`` or ``workspace/agents/``.
    Otherwise returns CWD.
    """
    workspace = find_workspace()
    if workspace is None:
        return Path.cwd()

    if entity_type == "server":
        target = workspace / "servers"
    elif entity_type == "agent":
        target = workspace / "agents"
    else:
        return Path.cwd()

    target.mkdir(exist_ok=True)
    return target
