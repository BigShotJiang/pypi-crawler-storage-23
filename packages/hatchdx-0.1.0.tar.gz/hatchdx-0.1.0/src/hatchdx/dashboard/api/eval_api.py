"""Eval API endpoints — reads from existing SQLite eval storage."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from aiohttp import web

eval_routes = web.RouteTableDef()

DB_FILENAME = ".hdx/eval_results.db"


def _get_db_path() -> Path:
    return Path.cwd() / DB_FILENAME


def _get_conn() -> sqlite3.Connection | None:
    """Return a read-only connection to the eval DB, or None if it doesn't exist."""
    db_path = _get_db_path()
    if not db_path.exists():
        return None
    conn = sqlite3.connect(str(db_path), timeout=5)
    conn.row_factory = sqlite3.Row
    return conn


def _get_recent_runs(limit: int = 10) -> list[dict[str, Any]]:
    """Get recent eval runs with summary stats. Used by overview endpoint too."""
    conn = _get_conn()
    if conn is None:
        return []

    try:
        cursor = conn.execute(
            """
            SELECT
                r.run_id,
                r.started_at,
                r.finished_at,
                COUNT(e.id) as total_cases,
                SUM(CASE WHEN e.passed = 1 THEN 1 ELSE 0 END) as passed,
                SUM(CASE WHEN e.passed = 0 THEN 1 ELSE 0 END) as failed
            FROM eval_runs r
            LEFT JOIN eval_results e ON r.run_id = e.run_id
            GROUP BY r.run_id
            ORDER BY r.started_at DESC
            LIMIT ?
            """,
            (limit,),
        )
        runs = []
        for row in cursor.fetchall():
            runs.append({
                "run_id": row["run_id"],
                "started_at": row["started_at"],
                "finished_at": row["finished_at"],
                "total_cases": row["total_cases"],
                "passed": row["passed"] or 0,
                "failed": row["failed"] or 0,
            })
        return runs
    finally:
        conn.close()


@eval_routes.get("/api/eval/runs")
async def list_runs(request: web.Request) -> web.Response:
    limit = int(request.query.get("limit", "50"))
    offset = int(request.query.get("offset", "0"))
    suite = request.query.get("suite")

    conn = _get_conn()
    if conn is None:
        return web.json_response({"runs": [], "total": 0})

    try:
        # Build query with optional suite filter
        where = ""
        params: list[Any] = []
        if suite:
            where = "HAVING GROUP_CONCAT(DISTINCT e.suite_name) LIKE ?"
            params.append(f"%{suite}%")

        count_cursor = conn.execute(
            f"""
            SELECT COUNT(*) FROM (
                SELECT r.run_id
                FROM eval_runs r
                LEFT JOIN eval_results e ON r.run_id = e.run_id
                GROUP BY r.run_id
                {where}
            )
            """,
            params,
        )
        total = count_cursor.fetchone()[0]

        cursor = conn.execute(
            f"""
            SELECT
                r.run_id,
                r.started_at,
                r.finished_at,
                COUNT(e.id) as total_cases,
                SUM(CASE WHEN e.passed = 1 THEN 1 ELSE 0 END) as passed,
                SUM(CASE WHEN e.passed = 0 THEN 1 ELSE 0 END) as failed,
                GROUP_CONCAT(DISTINCT e.suite_name) as suites
            FROM eval_runs r
            LEFT JOIN eval_results e ON r.run_id = e.run_id
            GROUP BY r.run_id
            {where}
            ORDER BY r.started_at DESC
            LIMIT ? OFFSET ?
            """,
            [*params, limit, offset],
        )

        runs = []
        for row in cursor.fetchall():
            suites_str = row["suites"] or ""
            runs.append({
                "run_id": row["run_id"],
                "started_at": row["started_at"],
                "finished_at": row["finished_at"],
                "total_cases": row["total_cases"],
                "passed": row["passed"] or 0,
                "failed": row["failed"] or 0,
                "suites": [s for s in suites_str.split(",") if s],
            })

        return web.json_response({"runs": runs, "total": total})
    finally:
        conn.close()


@eval_routes.get("/api/eval/runs/{run_id}")
async def get_run(request: web.Request) -> web.Response:
    run_id = request.match_info["run_id"]
    conn = _get_conn()
    if conn is None:
        return web.json_response({"error": "No eval database found"}, status=404)

    try:
        cursor = conn.execute(
            "SELECT run_id, started_at, finished_at FROM eval_runs WHERE run_id = ?",
            (run_id,),
        )
        row = cursor.fetchone()
        if row is None:
            return web.json_response({"error": f"Run {run_id} not found"}, status=404)

        # Get summary stats
        stats = conn.execute(
            """
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN passed = 1 THEN 1 ELSE 0 END) as passed,
                SUM(CASE WHEN passed = 0 THEN 1 ELSE 0 END) as failed,
                AVG(latency_ms) as avg_latency,
                GROUP_CONCAT(DISTINCT suite_name) as suites
            FROM eval_results WHERE run_id = ?
            """,
            (run_id,),
        ).fetchone()

        suites_str = stats["suites"] or ""
        return web.json_response({
            "run_id": row["run_id"],
            "started_at": row["started_at"],
            "finished_at": row["finished_at"],
            "total_cases": stats["total"],
            "passed": stats["passed"] or 0,
            "failed": stats["failed"] or 0,
            "avg_latency_ms": round(stats["avg_latency"] or 0, 1),
            "suites": [s for s in suites_str.split(",") if s],
        })
    finally:
        conn.close()


@eval_routes.get("/api/eval/runs/{run_id}/cases")
async def get_run_cases(request: web.Request) -> web.Response:
    run_id = request.match_info["run_id"]
    conn = _get_conn()
    if conn is None:
        return web.json_response({"run_id": run_id, "cases": []})

    try:
        cursor = conn.execute(
            """
            SELECT id, suite_name, eval_name, passed, latency_ms, timestamp, assertion_details
            FROM eval_results
            WHERE run_id = ?
            ORDER BY suite_name, eval_name
            """,
            (run_id,),
        )

        cases = []
        for row in cursor.fetchall():
            cases.append({
                "id": row["id"],
                "suite_name": row["suite_name"],
                "eval_name": row["eval_name"],
                "passed": bool(row["passed"]),
                "latency_ms": row["latency_ms"],
                "timestamp": row["timestamp"],
                "assertion_details": json.loads(row["assertion_details"]),
            })

        return web.json_response({"run_id": run_id, "cases": cases})
    finally:
        conn.close()


@eval_routes.get("/api/eval/compare/{id1}/{id2}")
async def compare_runs(request: web.Request) -> web.Response:
    id1 = request.match_info["id1"]
    id2 = request.match_info["id2"]
    conn = _get_conn()
    if conn is None:
        return web.json_response({"error": "No eval database found"}, status=404)

    try:
        def _get_results(rid: str) -> dict[str, dict[str, Any]]:
            cursor = conn.execute(
                """
                SELECT eval_name, suite_name, passed, latency_ms, assertion_details
                FROM eval_results WHERE run_id = ?
                """,
                (rid,),
            )
            return {
                row["eval_name"]: {
                    "suite_name": row["suite_name"],
                    "eval_name": row["eval_name"],
                    "passed": bool(row["passed"]),
                    "latency_ms": row["latency_ms"],
                    "assertion_details": json.loads(row["assertion_details"]),
                }
                for row in cursor.fetchall()
            }

        results_a = _get_results(id1)
        results_b = _get_results(id2)

        all_names = set(results_a) | set(results_b)
        regressions = []
        fixes = []
        unchanged = []

        for name in sorted(all_names):
            a = results_a.get(name)
            b = results_b.get(name)
            if a and b:
                if a["passed"] and not b["passed"]:
                    regressions.append({"eval_name": name, "run_a": a, "run_b": b})
                elif not a["passed"] and b["passed"]:
                    fixes.append({"eval_name": name, "run_a": a, "run_b": b})
                else:
                    unchanged.append({"eval_name": name, "run_a": a, "run_b": b})

        return web.json_response({
            "run_a": id1,
            "run_b": id2,
            "regressions": regressions,
            "fixes": fixes,
            "unchanged": unchanged,
        })
    finally:
        conn.close()


@eval_routes.get("/api/eval/trends")
async def get_trends(request: web.Request) -> web.Response:
    days = int(request.query.get("days", "30"))
    conn = _get_conn()
    if conn is None:
        return web.json_response({"trends": []})

    try:
        cursor = conn.execute(
            """
            SELECT
                DATE(r.started_at) as date,
                e.suite_name,
                COUNT(*) as total,
                SUM(CASE WHEN e.passed = 1 THEN 1 ELSE 0 END) as passed,
                AVG(e.latency_ms) as avg_latency
            FROM eval_results e
            JOIN eval_runs r ON e.run_id = r.run_id
            WHERE r.started_at >= datetime('now', ?)
            GROUP BY DATE(r.started_at), e.suite_name
            ORDER BY date
            """,
            (f"-{days} days",),
        )

        trends = []
        for row in cursor.fetchall():
            total = row["total"]
            passed = row["passed"] or 0
            trends.append({
                "date": row["date"],
                "suite": row["suite_name"],
                "total": total,
                "passed": passed,
                "pass_rate": passed / total if total > 0 else 0,
                "avg_latency_ms": round(row["avg_latency"] or 0, 1),
            })

        return web.json_response({"trends": trends})
    finally:
        conn.close()
