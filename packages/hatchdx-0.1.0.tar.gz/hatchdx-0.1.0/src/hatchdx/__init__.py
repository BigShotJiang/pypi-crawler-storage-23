__version__ = "0.1.0"


class HdxError(Exception):
    """Base exception for all hatchdx errors."""


# Backwards compatibility alias
McpdxError = HdxError


__all__ = ["HdxError", "McpdxError", "__version__"]
