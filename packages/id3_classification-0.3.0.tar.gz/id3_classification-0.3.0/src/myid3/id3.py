import numpy as np
import math
import matplotlib.pyplot as plt


class ID3Classifier:

    def __init__(self):

        self.tree = None
        self.target = None
        self.features = None
        self.majority_class = None


    # ==========================
    # ENTROPY
    # ==========================
    def entropy(self, data):

        values, counts = np.unique(data, return_counts=True)

        ent = 0

        for count in counts:

            prob = count / sum(counts)

            if prob > 0:
                ent -= prob * math.log2(prob)

        return ent


    # ==========================
    # INFORMATION GAIN
    # ==========================
    def information_gain(self, df, feature):

        total_entropy = self.entropy(df[self.target])

        values, counts = np.unique(df[feature], return_counts=True)

        weighted_entropy = 0

        for i in range(len(values)):

            subset = df[df[feature] == values[i]]

            subset_entropy = self.entropy(subset[self.target])

            weight = counts[i] / sum(counts)

            weighted_entropy += weight * subset_entropy

        return total_entropy - weighted_entropy


    # ==========================
    # BUILD TREE
    # ==========================
    def _id3(self, data, features):

        if len(np.unique(data[self.target])) == 1:

            return np.unique(data[self.target])[0]

        if len(features) == 0:

            return data[self.target].mode()[0]


        igs = [self.information_gain(data, f) for f in features]

        best = features[np.argmax(igs)]

        tree = {best: {}}

        remaining = [f for f in features if f != best]


        for value in np.unique(data[best]):

            subset = data[data[best] == value]

            if len(subset) == 0:

                tree[best][value] = data[self.target].mode()[0]

            else:

                tree[best][value] = self._id3(subset, remaining)

        return tree


    # ==========================
    # FIT
    # ==========================
    def fit(self, df, features, target):

        self.target = target
        self.features = features

        # fallback prediction
        self.majority_class = df[target].mode()[0]

        self.tree = self._id3(df, features)


    # ==========================
    # PRINT TREE
    # ==========================
    def print_tree(self, tree=None, indent=""):

        if tree is None:
            tree = self.tree

        if not isinstance(tree, dict):

            print(indent + "→", tree)

            return

        for key in tree:

            print(indent + key)

            for value in tree[key]:

                print(indent + " ├─", value)

                self.print_tree(
                    tree[key][value],
                    indent + " │   "
                )


    # ==========================
    # TREE GRAPH (MATPLOTLIB)
    # ==========================
    def plot_tree(self):

        fig, ax = plt.subplots(figsize=(14,9))

        ax.axis('off')

        level_gap = 0.15


        def draw_node(node, x, y, dx):

            # Leaf
            if not isinstance(node, dict):

                ax.text(
                    x,
                    y,
                    str(node),
                    ha='center',
                    bbox=dict(
                        boxstyle="round",
                        fc="lightblue",
                        ec="black"
                    )
                )
                return


            root = list(node.keys())[0]

            ax.text(
                x,
                y,
                root,
                ha='center',
                bbox=dict(
                    boxstyle="round",
                    fc="lightgreen",
                    ec="black"
                )
            )

            children = list(node[root].items())

            n = len(children)

            start_x = x - dx*(n-1)/2


            for i,(value, subtree) in enumerate(children):

                child_x = start_x + i*dx

                child_y = y - level_gap


                ax.plot(
                    [x, child_x],
                    [y-0.02, child_y+0.02],
                    'k'
                )

                ax.text(
                    (x+child_x)/2,
                    (y+child_y)/2,
                    str(value),
                    ha='center'
                )

                draw_node(
                    subtree,
                    child_x,
                    child_y,
                    dx/1.8
                )


        draw_node(self.tree, 0.5, 1.0, 0.4)

        plt.show()


    # ==========================
    # SINGLE PREDICT
    # ==========================
    def _predict(self, tree, sample):

        if not isinstance(tree, dict):

            return tree

        root = list(tree.keys())[0]

        value = sample[root]

        if value not in tree[root]:

            return self.majority_class

        return self._predict(tree[root][value], sample)


    # ==========================
    # MULTIPLE PREDICT
    # ==========================
    def predict(self, df):

        preds = []

        for _, row in df.iterrows():

            preds.append(self._predict(self.tree, row))

        return np.array(preds)