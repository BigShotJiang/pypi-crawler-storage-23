# 设备生命周期状态机: Added -> Booting -> Identified -> Active -> Panic

from enum import Enum, auto
from typing import Optional, Set, Callable, Any


class DeviceState(Enum):
    """设备状态枚举。"""
    Added = auto()      # 已加入，未上电/未握手
    Booting = auto()    # 正在启动（串口监听中，等待 login: 等）
    Identified = auto() # 已识别（拿到 Serial，可生成 MAC）
    Active = auto()     # 已激活（网络已配置，Telnet 可用，有 IP）
    Panic = auto()      # Kernel Panic 等异常


# 允许的转移（from_state -> set of to_states）
TRANSITIONS: dict[DeviceState, Set[DeviceState]] = {
    DeviceState.Added: {DeviceState.Booting, DeviceState.Panic},
    DeviceState.Booting: {DeviceState.Identified, DeviceState.Panic},
    DeviceState.Identified: {DeviceState.Active, DeviceState.Booting, DeviceState.Panic},
    DeviceState.Active: {DeviceState.Booting, DeviceState.Identified, DeviceState.Panic},
    DeviceState.Panic: {DeviceState.Booting, DeviceState.Added},
}


def can_transition(current: DeviceState, next_state: DeviceState) -> bool:
    """判断是否允许从 current 转移到 next_state。"""
    return next_state in TRANSITIONS.get(current, set())


def transition(
    current: DeviceState,
    next_state: DeviceState,
    on_invalid: Optional[Callable[[DeviceState, DeviceState], Any]] = None,
) -> DeviceState:
    """
    执行状态转移。若不允许转移则调用 on_invalid(current, next_state)（若提供），
    并返回原状态；否则返回 next_state。
    """
    if can_transition(current, next_state):
        return next_state
    if on_invalid is not None:
        on_invalid(current, next_state)
    return current
