# Registry: Host:Name -> MAC/IP/Status 持久化（JSON）

import json
import os
from typing import Any, Optional

DEFAULT_REGISTRY_PATH = os.path.expanduser("~/.khala/registry.json")


def _ensure_dir(path: str) -> None:
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)


def load(path: str = DEFAULT_REGISTRY_PATH) -> list[dict[str, Any]]:
    """加载 Registry，返回设备列表。"""
    return _get_meta(path).get("devices", [])


def save(devices: list[dict[str, Any]], path: str = DEFAULT_REGISTRY_PATH) -> None:
    """保存设备列表到 Registry（保留 active_stack）。"""
    _ensure_dir(path)
    meta = _get_meta(path)
    meta["devices"] = devices
    if "active_stack" not in meta:
        meta["active_stack"] = []
    with open(path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)


def key(host: str, name: str) -> str:
    return f"{host}:{name}"


def get(host: str, name: str, path: str = DEFAULT_REGISTRY_PATH) -> Optional[dict[str, Any]]:
    """按 host、name 查找一条记录。"""
    devices = load(path)
    k = key(host, name)
    for d in devices:
        if key(d.get("host", ""), d.get("name", "")) == k:
            return d
    return None


def set_entry(
    host: str,
    name: str,
    *,
    port: Optional[str] = None,
    mac: Optional[str] = None,
    ip: Optional[str] = None,
    state: Optional[str] = None,
    owner: Optional[str] = None,
    path: str = DEFAULT_REGISTRY_PATH,
) -> None:
    """新增或更新一条记录（以 host+name 为键）。owner 表示由谁 activate。"""
    devices = load(path)
    k = key(host, name)
    for d in devices:
        if key(d.get("host", ""), d.get("name", "")) == k:
            if port is not None:
                d["port"] = port
            if mac is not None:
                d["mac"] = mac
            if ip is not None:
                d["ip"] = ip
            if state is not None:
                d["state"] = state
            if owner is not None:
                d["owner"] = owner
            save(devices, path)
            return
    devices.append({
        "host": host,
        "name": name,
        "port": port or "",
        "mac": mac or "",
        "ip": ip or "",
        "state": state or "Added",
        "owner": owner or "",
    })
    save(devices, path)


def list_all(path: str = DEFAULT_REGISTRY_PATH) -> list[dict[str, Any]]:
    """返回所有设备列表。"""
    return load(path)


def clear(path: str = DEFAULT_REGISTRY_PATH) -> None:
    """清空设备缓存（devices + active_stack）。"""
    _ensure_dir(path)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"devices": [], "active_stack": []}, f, indent=2, ensure_ascii=False)


def _get_meta(path: str) -> dict[str, Any]:
    """读取完整 JSON（devices + active_stack）。"""
    if not os.path.isfile(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_active_stack(path: str = DEFAULT_REGISTRY_PATH) -> list[str]:
    """返回本地激活栈（host:name 列表，最后激活的在末尾）。"""
    meta = _get_meta(path)
    return meta.get("active_stack", [])


def push_activated(host: str, name: str, path: str = DEFAULT_REGISTRY_PATH) -> None:
    """将 host:name 压入激活栈。"""
    meta = _get_meta(path)
    devices = meta.get("devices", [])
    stack = meta.get("active_stack", [])
    k = key(host, name)
    if k in stack:
        stack.remove(k)
    stack.append(k)
    meta["active_stack"] = stack
    _ensure_dir(path)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"devices": devices, "active_stack": stack}, f, indent=2, ensure_ascii=False)


def pop_activated(path: str = DEFAULT_REGISTRY_PATH) -> Optional[str]:
    """弹出并返回最后一个激活的 host:name；栈空返回 None。"""
    meta = _get_meta(path)
    devices = meta.get("devices", [])
    stack = meta.get("active_stack", [])
    if not stack:
        return None
    k = stack.pop()
    meta["active_stack"] = stack
    _ensure_dir(path)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"devices": devices, "active_stack": stack}, f, indent=2, ensure_ascii=False)
    return k


def remove_from_activated(host: str, name: str, path: str = DEFAULT_REGISTRY_PATH) -> bool:
    """从激活栈中移除指定 host:name（若存在）。返回是否曾存在。"""
    meta = _get_meta(path)
    devices = meta.get("devices", [])
    stack = meta.get("active_stack", [])
    k = key(host, name)
    if k not in stack:
        return False
    stack = [x for x in stack if x != k]
    _ensure_dir(path)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"devices": devices, "active_stack": stack}, f, indent=2, ensure_ascii=False)
    return True


def pop_all_activated_by_host(host: str, path: str = DEFAULT_REGISTRY_PATH) -> list[str]:
    """移除激活栈中所有由指定 host 激活的项，返回被移除的 host:name 列表。"""
    meta = _get_meta(path)
    devices = meta.get("devices", [])
    stack = meta.get("active_stack", [])
    removed = [k for k in stack if k.split(":", 1)[0] == host]
    new_stack = [k for k in stack if k not in removed]
    if not removed:
        return []
    meta["active_stack"] = new_stack
    _ensure_dir(path)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"devices": devices, "active_stack": new_stack}, f, indent=2, ensure_ascii=False)
    return removed
