# IP 追踪：从 ip addr show eth0 输出解析 IPv4

import re
from typing import Optional

INET_RE = re.compile(r"\binet\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/")


def parse_ip_from_addr_output(text: str | list[str]) -> Optional[str]:
    """从 `ip addr show eth0` 的输出中解析第一个 IPv4 地址。"""
    if isinstance(text, str):
        text = text.splitlines()
    for line in text:
        m = INET_RE.search(line)
        if m:
            return m.group(1)
    return None
