# SPDX-License-Identifier: BSD-2-Clause
# Copyright releng-tool

from releng_tool.__main__ import main
import sys

if __name__ == '__main__':
    sys.exit(main())
