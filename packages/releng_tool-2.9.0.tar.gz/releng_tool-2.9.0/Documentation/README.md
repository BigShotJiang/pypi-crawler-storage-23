# Documentation

Complete documentation is maintained in the following repository:

> releng-tool — Documentation \
> https://github.com/releng-tool/releng-tool-docs

This folder also hosts the man page for releng-tool aimed to support
package distributions.

