# Lint Playground

Testing area for developers to sanity check various linting operations.

```
python -m releng-tool --root-dir tests/lint-playground/ lint
```
