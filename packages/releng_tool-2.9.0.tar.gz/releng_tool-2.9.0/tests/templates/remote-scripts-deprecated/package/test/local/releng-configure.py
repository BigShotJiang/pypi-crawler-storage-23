file_flag = TARGET_DIR / 'configure-remote'
releng_touch(file_flag)
