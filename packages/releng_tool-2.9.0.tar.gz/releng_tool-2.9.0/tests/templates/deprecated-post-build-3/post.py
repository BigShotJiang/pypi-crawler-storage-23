file_flag = OUTPUT_DIR / 'invoked-post'
releng_touch(file_flag)
