#include "mylib/mylib.h"
#include <iostream>

void process() {
    std::cout << "process\n";
}
