#include "mylib/mylib.h"

int main() {
    process();

    return 0;
}
