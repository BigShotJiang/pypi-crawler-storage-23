file_flag = TARGET_DIR / 'invoked-post'
releng_touch(file_flag)
