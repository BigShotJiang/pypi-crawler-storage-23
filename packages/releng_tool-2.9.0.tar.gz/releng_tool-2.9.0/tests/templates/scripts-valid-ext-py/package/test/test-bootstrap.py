file_flag = TARGET_DIR / 'invoked-bootstrap'
releng_touch(file_flag)
