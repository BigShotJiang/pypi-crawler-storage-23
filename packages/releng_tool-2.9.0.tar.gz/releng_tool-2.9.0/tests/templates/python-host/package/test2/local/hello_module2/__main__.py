from hello_module2 import hello_world2

def main():
    hello_world2()

if __name__ == "__main__":
    main()
