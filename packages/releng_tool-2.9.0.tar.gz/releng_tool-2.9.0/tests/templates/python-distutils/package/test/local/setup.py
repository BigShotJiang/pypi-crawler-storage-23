from distutils.core import setup

setup(
    description='hello world description',
    name='hello world',
    packages=['hello_module'],
    version='1.0',
)
