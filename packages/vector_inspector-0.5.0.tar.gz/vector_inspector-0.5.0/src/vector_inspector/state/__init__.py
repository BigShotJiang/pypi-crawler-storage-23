"""Application state management."""

from vector_inspector.state.app_state import AppState

__all__ = ["AppState"]
