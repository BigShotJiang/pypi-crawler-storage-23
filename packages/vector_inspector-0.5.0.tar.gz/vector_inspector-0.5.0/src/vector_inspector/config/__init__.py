"""Data package for Vector Inspector.

Contains static data files like the model registry.
"""
