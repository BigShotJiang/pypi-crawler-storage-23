"""UI services for dialog management and utilities."""
