#!/usr/bin/env python
"""Template: Read enriched Delta Lake -> Enrich -> Interactive Dashboard.

Reads the base + forward tables produced by enrich_to_delta.py, computes
derived columns lazily (mid, spread, return, near/far touch, markout),
pivots horizons to wide format, and launches an interactive Panel dashboard.

Key design: all enrichment uses plain Polars expressions on the semi-wide
table (horizons as rows) — no loops needed. Derived columns are NOT stored
in Delta Lake; they are computed on-the-fly here.

Column naming convention:
  - Raw forward ref_cols: {ref_col}_forward_{suffix}  (e.g. bid_px0_forward_60s)
  - Derived ref_cols:     {ref_col}_{suffix}           (e.g. mid_60s, markout_60s)
  - Future multi-origin:  {ref_col}_{time_col}_forward_{suffix}

To use this template:
  1. Copy: vf.templates.copy_template("explore_dashboard.py", "my_dashboard.py")
  2. Produce enriched data first (see enrich_to_delta.py template)
  3. Edit CONFIG section: ENRICHED_DIR, HORIZONS
  4. Edit ENRICH section: add custom derived columns
  5. Edit DASHBOARD CONFIG: AXIS_COLS, REF_COLS
  6. Run: python my_dashboard.py

Requires: pip install vizflow[explore]
"""
from __future__ import annotations

from pathlib import Path

import polars as pl
import vizflow as vf

vf.set_config(vf.Config(market="CN"))


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your environment
# ═══════════════════════════════════════════════════════════════
ENRICHED_DIR = Path("./enriched")
HORIZONS = [-10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600]
RAW_REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]


# ═══════════════════════════════════════════════════════════════
# READ (lazy)
# ═══════════════════════════════════════════════════════════════
print(f"Reading enriched data from {ENRICHED_DIR}...")
lf_base = pl.scan_delta(str(ENRICHED_DIR / "base"))
lf_fwd = pl.scan_delta(str(ENRICHED_DIR / "forward"))
print(f"  base schema: {len(lf_base.columns)} columns")
print(f"  forward schema: {len(lf_fwd.columns)} columns")


# ═══════════════════════════════════════════════════════════════
# SEMI-PIVOT: long -> (trade, horizon, ref_cols as columns)
# Raw forward cols get "{ref_col}_forward" naming so pivot produces
# e.g. bid_px0_forward_60s. Derived cols (mid, markout, ...) stay as-is.
# ═══════════════════════════════════════════════════════════════
group_cols = [c for c in lf_fwd.columns if c not in ("ref_col", "forward_value")]
lf_semi = lf_fwd.group_by(group_cols).agg([
    pl.col("forward_value").filter(pl.col("ref_col") == rc).first().alias(f"{rc}_forward")
    for rc in RAW_REF_COLS
])

# Join with base for trade-level columns
lf = lf_base.join(lf_semi, on=["seq", "data_date"])
print("  semi-pivot + join: done (lazy)")


# ═══════════════════════════════════════════════════════════════
# ENRICH — plain Polars expressions, no loops!
# ═══════════════════════════════════════════════════════════════
is_buy = pl.col("order_side") == "Buy"

# Phase 1: mid, spread, side-aware touch/size
lf = lf.with_columns([
    ((pl.col("bid_px0_forward") + pl.col("ask_px0_forward")) / 2).alias("mid"),
    ((pl.col("ask_px0_forward") - pl.col("bid_px0_forward"))
     / ((pl.col("bid_px0_forward") + pl.col("ask_px0_forward")) / 2) * 10000).alias("spread_bps"),
    pl.when(is_buy).then(pl.col("ask_px0_forward")).otherwise(pl.col("bid_px0_forward")).alias("near_touch"),
    pl.when(is_buy).then(pl.col("bid_px0_forward")).otherwise(pl.col("ask_px0_forward")).alias("far_touch"),
    pl.when(is_buy).then(pl.col("ask_size0_forward")).otherwise(pl.col("bid_size0_forward")).alias("near_touch_size"),
    pl.when(is_buy).then(pl.col("bid_size0_forward")).otherwise(pl.col("ask_size0_forward")).alias("far_touch_size"),
])

# Phase 2: markout (forward mid - fill price), fill_to_near_touch
lf = lf.with_columns([
    (pl.col("mid") / pl.col("fill_price") - 1).alias("markout"),
    (pl.col("fill_price") / pl.col("near_touch") - 1).alias("fill_to_near_touch"),
])

# Phase 3: return (cross-horizon: mid_h vs mid_0)
mid_0 = (
    lf.filter(pl.col("horizon_ms") == 0)
    .select(["seq", "data_date", pl.col("mid").alias("mid_0")])
)
lf = lf.join(mid_0, on=["seq", "data_date"])
lf = lf.with_columns(
    ((pl.col("mid") - pl.col("mid_0")) / pl.col("mid_0")).alias("return")
).drop("mid_0")

# Phase 4: sign_by_side (positive = favorable for that side)
lf = vf.sign_by_side(lf, cols=["return", "markout"])
print("  enrichment: done (lazy)")


# ┌─────────────────────────────────────────────────────────────┐
# │  USER ENRICHMENT ZONE (lazy)                                │
# │                                                             │
# │  Add custom columns here using plain pl.col() expressions.  │
# │  They apply to all horizons automatically.                  │
# │  Register scalar columns in AXIS_COLS below.                │
# └─────────────────────────────────────────────────────────────┘
lf = lf.with_columns([
    # elapsed time in minutes (easier to read on axis)
    (pl.col("elapsed_update_exchange_ts") / 60_000).alias("elapsed_minutes"),
])


# ═══════════════════════════════════════════════════════════════
# DASHBOARD CONFIG — edit to control what appears in the UI
# ═══════════════════════════════════════════════════════════════
# Scalar columns for X/Y/Weight axis dropdowns.
# Order matters: 1st = default X, 2nd = default Y, 3rd = default Weight.
AXIS_COLS = [
    "elapsed_update_exchange_ts",
    "elapsed_minutes",
    "mid",
    "spread_bps",
    "fill_qty",
    "fill_notional",
    "fill_price",
    "x_10s",
    "x_60s",
    "x_3m",
    "x_30m",
]

# Horizon-level value types for the Value dropdown + horizon curve.
# Each entry is a column prefix; the dashboard combines with horizons.
REF_COLS = [
    "return", "mid", "spread_bps",
    "near_touch", "far_touch",
    "near_touch_size", "far_touch_size",
    "markout", "fill_to_near_touch",
]

# All ref_cols for pivot: raw forward ({ref_col}_forward) + derived
FORWARD_REF_COLS = [f"{rc}_forward" for rc in RAW_REF_COLS]
ALL_REF_COLS = FORWARD_REF_COLS + REF_COLS


# ═══════════════════════════════════════════════════════════════
# PREPARE — pivot horizons to wide + collect (separate from server)
# ═══════════════════════════════════════════════════════════════
print("Preparing dashboard data...")
df = vf.pivot_horizons(lf, ref_cols=ALL_REF_COLS, horizons=HORIZONS)
print(f"  Dashboard data: {len(df)} rows, {len(df.columns)} columns")


# ═══════════════════════════════════════════════════════════════
# LAUNCH
# ═══════════════════════════════════════════════════════════════
PORT = 5100

server = vf.viz.dashboard(
    df,
    ref_cols=REF_COLS,
    horizons=HORIZONS,
    axis_cols=AXIS_COLS,
    port=PORT,
    show=True,
)

print(f"Dashboard running at http://localhost:{PORT}/app")
print("Press Ctrl+C to stop.\n")

# Keep alive until Stop Server button is clicked in the dashboard
import time
while server.is_alive:
    time.sleep(1)
print("Server stopped.")