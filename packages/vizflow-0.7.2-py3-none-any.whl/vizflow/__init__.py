"""
VizFlow - TB-scale data analysis and visualization library.

Usage:
    import vizflow as vf
"""

__version__ = "0.7.2"

from .config import Config, get_config, set_config
from .io import (
    load_calendar,
    scan_alpha,
    scan_alphas,
    scan_quote,
    scan_quotes,
    scan_trade,
    scan_trades,
    scan_univ,
    scan_univs,
)
from .market import CN, CRYPTO, Market, Session
from .ops import (
    aggregate,
    bin,
    forward_return,
    horizon_cols,
    horizon_ms,
    horizon_suffix,
    mark_to_close,
    melt_forward,
    merge_forward,
    parse_time,
    pivot_horizons,
    sign_by_side,
)
from .utils import add_tod
from . import viz
from .schema_evolution import (
    JYAO_V20251114,
    SCHEMAS,
    STOCK_SORTED_T5OB,
    YLIN_V20251204,
    ColumnSpec,
    SchemaEvolution,
    get_schema,
)
