"""Time-series analysis visualization.

This module provides line plots for analyzing metrics across time horizons,
such as markout curves and return profiles.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from .core import _prepare_data, _wmean_scalar

if TYPE_CHECKING:
    import holoviews as hv


def horizon_curve(
    df: pl.LazyFrame | pl.DataFrame,
    horizons: list[float],
    value_cols: list[str],
    weight: str | None = None,
    *,
    agg: str = "wmean",
    width: int = 400,
    height: int = 300,
    title: str | None = None,
    xlabel: str = "Horizon (s)",
    ylabel: str = "Value",
) -> "hv.Curve | hv.Overlay":
    """Line plot: x=horizon, y=aggregated metric.

    For time-series analysis such as markout curves and return profiles.
    Each point on the curve represents the aggregated value at that horizon.

    Args:
        df: Polars LazyFrame or DataFrame with data
        horizons: List of horizon values (seconds) for x-axis.
            Must match length of value_cols.
        value_cols: Columns to plot, one per horizon.
            e.g., ["markout_60s", "markout_3m", "markout_5m"]
        weight: Weight column for weighted aggregation. Required if agg="wmean".
        agg: Aggregation method:
            - "wmean": weighted mean (requires weight)
            - "mean": simple mean
            - "sum": sum
        width: Plot width in pixels
        height: Plot height in pixels
        title: Plot title
        xlabel: X-axis label
        ylabel: Y-axis label

    Returns:
        HoloViews Curve (single series) or Overlay (multiple series)

    Example:
        >>> curve = vf.viz.horizon_curve(
        ...     df,
        ...     horizons=[60, 180, 300, 600, 1800],
        ...     value_cols=["markout_60s", "markout_3m", "markout_5m",
        ...                 "markout_10m", "markout_30m"],
        ...     weight="qty",
        ... )
        >>> curve  # Display in notebook
    """
    import holoviews as hv

    if len(horizons) != len(value_cols):
        raise ValueError(
            f"Length mismatch: horizons has {len(horizons)} elements, "
            f"value_cols has {len(value_cols)} elements"
        )

    if agg == "wmean" and weight is None:
        raise ValueError("weight is required when agg='wmean'")

    # Prepare columns to load
    cols_to_load = list(value_cols)
    if weight and weight not in cols_to_load:
        cols_to_load.append(weight)

    # Convert to pandas
    pdf = _prepare_data(df, columns=cols_to_load)

    # Compute aggregated values for each horizon
    points = []
    for h, col in zip(horizons, value_cols):
        if agg == "wmean":
            y = _wmean_scalar(pdf, col, weight)
        elif agg == "sum":
            y = pdf[col].sum()
        elif agg == "mean":
            y = pdf[col].mean()
        else:
            raise ValueError(f"Unknown agg method: {agg}")
        points.append((h, y))

    # Create curve
    curve = hv.Curve(points, kdims=[xlabel], vdims=[ylabel])

    # Apply options
    opts = {
        "width": width,
        "height": height,
        "tools": ["hover"],
    }
    if title:
        opts["title"] = title

    return curve.opts(**opts)


def horizon_curves(
    df: pl.LazyFrame | pl.DataFrame,
    horizons: list[float],
    series_dict: dict[str, list[str]],
    weight: str | None = None,
    *,
    agg: str = "wmean",
    width: int = 400,
    height: int = 300,
    title: str | None = None,
    xlabel: str = "Horizon (s)",
    ylabel: str = "Value",
) -> "hv.Overlay":
    """Multiple horizon curves overlaid.

    Similar to horizon_curve but plots multiple series (e.g., markout vs return).

    Args:
        df: Polars LazyFrame or DataFrame with data
        horizons: List of horizon values (seconds) for x-axis
        series_dict: Mapping of series_name -> list of value columns
            e.g., {"Markout": ["markout_60s", "markout_3m"],
                   "Return": ["return_60s", "return_3m"]}
        weight: Weight column for weighted aggregation
        agg: Aggregation method ("wmean", "mean", "sum")
        width: Plot width in pixels
        height: Plot height in pixels
        title: Plot title
        xlabel: X-axis label
        ylabel: Y-axis label

    Returns:
        HoloViews Overlay of multiple curves

    Example:
        >>> curves = vf.viz.horizon_curves(
        ...     df,
        ...     horizons=[60, 180, 600],
        ...     series_dict={
        ...         "Markout": ["markout_60s", "markout_3m", "markout_10m"],
        ...         "Return": ["return_60s", "return_3m", "return_10m"],
        ...     },
        ...     weight="qty",
        ... )
    """
    import holoviews as hv

    if agg == "wmean" and weight is None:
        raise ValueError("weight is required when agg='wmean'")

    # Collect all columns
    all_cols = []
    for cols in series_dict.values():
        all_cols.extend(cols)
    if weight and weight not in all_cols:
        all_cols.append(weight)

    # Convert to pandas
    pdf = _prepare_data(df, columns=list(set(all_cols)))

    # Create curves for each series
    curves = []
    for series_name, value_cols in series_dict.items():
        if len(horizons) != len(value_cols):
            raise ValueError(
                f"Length mismatch for series '{series_name}': "
                f"horizons has {len(horizons)}, value_cols has {len(value_cols)}"
            )

        points = []
        for h, col in zip(horizons, value_cols):
            if agg == "wmean":
                y = _wmean_scalar(pdf, col, weight)
            elif agg == "sum":
                y = pdf[col].sum()
            elif agg == "mean":
                y = pdf[col].mean()
            else:
                raise ValueError(f"Unknown agg method: {agg}")
            points.append((h, y))

        curve = hv.Curve(points, kdims=[xlabel], vdims=[ylabel], label=series_name)
        curves.append(curve)

    # Overlay all curves
    overlay = hv.Overlay(curves)

    # Apply options
    opts = {
        "width": width,
        "height": height,
        "tools": ["hover"],
        "legend_position": "right",
    }
    if title:
        opts["title"] = title

    return overlay.opts(**opts)
