"""Core utilities for interactive visualization."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl

if TYPE_CHECKING:
    import pandas as pd


def _prepare_data(
    df: pl.LazyFrame | pl.DataFrame,
    columns: list[str] | None = None,
) -> "pd.DataFrame":
    """Convert Polars DataFrame to Pandas for datashader.

    Uses zero-copy conversion when possible (numeric columns with PyArrow backend).

    Args:
        df: Polars LazyFrame or DataFrame
        columns: Columns to select. If None, select all columns.

    Returns:
        Pandas DataFrame ready for datashader
    """
    if isinstance(df, pl.LazyFrame):
        if columns:
            df = df.select(columns).collect()
        else:
            df = df.collect()
    elif columns:
        df = df.select(columns)

    return df.to_pandas()


def _wmean_scalar(pdf: "pd.DataFrame", value_col: str, weight_col: str) -> float:
    """Compute weighted mean for a single column.

    Args:
        pdf: Pandas DataFrame
        value_col: Column with values
        weight_col: Column with weights

    Returns:
        Weighted mean value
    """
    total_weight = pdf[weight_col].sum()
    if total_weight == 0:
        return np.nan
    return (pdf[value_col] * pdf[weight_col]).sum() / total_weight
