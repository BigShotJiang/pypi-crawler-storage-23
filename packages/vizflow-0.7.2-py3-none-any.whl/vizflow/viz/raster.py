"""Rasterization aggregators for datashader Canvas operations.

This module provides aggregation functions for use with heatmap().
All functions return a callable that operates on (DataFrame, Canvas, x, y).

Usage:
    >>> import vizflow as vf
    >>> heatmap(df, "x", "y", agg=vf.viz.raster.wmean("value", "weight"))
    >>> heatmap(df, "x", "y", agg=vf.viz.raster.mean("value"))
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import numpy as np

if TYPE_CHECKING:
    import datashader as dsh
    import pandas as pd
    import xarray as xr

# Type alias for aggregation function
AggFunc = Callable[["pd.DataFrame", "dsh.Canvas", str, str], "xr.DataArray"]


def wmean(value: str, weight: str) -> AggFunc:
    """Weighted mean: sum(value * weight) / sum(weight).

    Args:
        value: Column name for values to aggregate
        weight: Column name for weights

    Returns:
        Aggregation function for use with heatmap()

    Example:
        >>> heatmap(df, "x", "y", agg=vf.viz.raster.wmean("return", "notional"))
    """
    import datashader as dsh
    import xarray as xr

    def _agg(sub: "pd.DataFrame", cvs: "dsh.Canvas", x: str, y: str) -> "xr.DataArray":
        sub = sub.copy()
        sub["_wv"] = sub[value] * sub[weight]
        sum_wv = cvs.points(sub, x, y, agg=dsh.sum("_wv"))
        sum_w = cvs.points(sub, x, y, agg=dsh.sum(weight))
        return xr.where(sum_w > 0, sum_wv / sum_w, np.nan)

    return _agg


def mean(col: str) -> AggFunc:
    """Simple mean.

    Args:
        col: Column name to aggregate

    Returns:
        Aggregation function for use with heatmap()

    Example:
        >>> heatmap(df, "x", "y", agg=vf.viz.raster.mean("value"))
    """
    import datashader as dsh

    def _agg(sub: "pd.DataFrame", cvs: "dsh.Canvas", x: str, y: str) -> "xr.DataArray":
        return cvs.points(sub, x, y, agg=dsh.mean(col))

    return _agg


def sum(col: str) -> AggFunc:
    """Sum aggregation.

    Args:
        col: Column name to aggregate

    Returns:
        Aggregation function for use with heatmap()

    Example:
        >>> heatmap(df, "x", "y", agg=vf.viz.raster.sum("quantity"))
    """
    import datashader as dsh

    def _agg(sub: "pd.DataFrame", cvs: "dsh.Canvas", x: str, y: str) -> "xr.DataArray":
        return cvs.points(sub, x, y, agg=dsh.sum(col))

    return _agg


def count() -> AggFunc:
    """Point count.

    Returns:
        Aggregation function for use with heatmap()

    Example:
        >>> heatmap(df, "x", "y", agg=vf.viz.raster.count())
    """
    import datashader as dsh

    def _agg(sub: "pd.DataFrame", cvs: "dsh.Canvas", x: str, y: str) -> "xr.DataArray":
        return cvs.points(sub, x, y, agg=dsh.count())

    return _agg


def std(col: str) -> AggFunc:
    """Standard deviation.

    Args:
        col: Column name to aggregate

    Returns:
        Aggregation function for use with heatmap()

    Example:
        >>> heatmap(df, "x", "y", agg=vf.viz.raster.std("value"))
    """
    import datashader as dsh

    def _agg(sub: "pd.DataFrame", cvs: "dsh.Canvas", x: str, y: str) -> "xr.DataArray":
        return cvs.points(sub, x, y, agg=dsh.std(col))

    return _agg


def var(col: str) -> AggFunc:
    """Variance.

    Args:
        col: Column name to aggregate

    Returns:
        Aggregation function for use with heatmap()

    Example:
        >>> heatmap(df, "x", "y", agg=vf.viz.raster.var("value"))
    """
    import datashader as dsh

    def _agg(sub: "pd.DataFrame", cvs: "dsh.Canvas", x: str, y: str) -> "xr.DataArray":
        return cvs.points(sub, x, y, agg=dsh.var(col))

    return _agg


def min(col: str) -> AggFunc:
    """Minimum value.

    Args:
        col: Column name to aggregate

    Returns:
        Aggregation function for use with heatmap()

    Example:
        >>> heatmap(df, "x", "y", agg=vf.viz.raster.min("value"))
    """
    import datashader as dsh

    def _agg(sub: "pd.DataFrame", cvs: "dsh.Canvas", x: str, y: str) -> "xr.DataArray":
        return cvs.points(sub, x, y, agg=dsh.min(col))

    return _agg


def max(col: str) -> AggFunc:
    """Maximum value.

    Args:
        col: Column name to aggregate

    Returns:
        Aggregation function for use with heatmap()

    Example:
        >>> heatmap(df, "x", "y", agg=vf.viz.raster.max("value"))
    """
    import datashader as dsh

    def _agg(sub: "pd.DataFrame", cvs: "dsh.Canvas", x: str, y: str) -> "xr.DataArray":
        return cvs.points(sub, x, y, agg=dsh.max(col))

    return _agg
