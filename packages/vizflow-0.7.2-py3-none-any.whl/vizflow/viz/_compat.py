"""Optional dependency checks for explore features."""

HAS_EXPLORE = False
_EXPLORE_ERROR = None

try:
    import holoviews  # noqa: F401
    import datashader  # noqa: F401
    import panel  # noqa: F401
    import bokeh  # noqa: F401

    HAS_EXPLORE = True
except ImportError as e:
    _EXPLORE_ERROR = e


def require_explore():
    """Raise ImportError if explore dependencies are not installed."""
    if not HAS_EXPLORE:
        raise ImportError(
            "Explore features require additional dependencies. "
            "Install with: pip install vizflow[explore]\n"
            "Required packages: holoviews, datashader, panel, bokeh\n"
            f"Original error: {_EXPLORE_ERROR}"
        )
