"""Core operations for data transformation."""

from __future__ import annotations

import polars as pl

from .config import get_config


def parse_time(
    df: pl.LazyFrame,
    timestamp_col: str = "ticktime",
) -> pl.LazyFrame:
    """Parse HHMMSSMMM timestamp to elapsed milliseconds.

    Adds one column:
    - elapsed_{timestamp_col}: pl.Int64 (milliseconds since market open)

    For time-of-day column (pl.Time) for plotting, use vf.add_tod() separately.

    Args:
        df: Input LazyFrame
        timestamp_col: Column with integer HHMMSSMMM format timestamps
            e.g., 93012145 = 09:30:12.145, 142058425 = 14:20:58.425

    Returns:
        LazyFrame with elapsed column added

    Raises:
        RuntimeError: If config not set via set_config()
        NotImplementedError: If market is not CN

    Example:
        >>> config = vf.Config(market="CN", input_dir=".", output_dir=".")
        >>> vf.set_config(config)
        >>> df = vf.parse_time(df, "ticktime")
        >>> # Creates: elapsed_ticktime (pl.Int64)
    """
    config = get_config()

    if config.market != "CN":
        raise NotImplementedError(f"Market {config.market} not supported yet")

    # Parse HHMMSSMMM to components
    df = df.with_columns([
        (pl.col(timestamp_col) // 10000000).alias("_hour"),
        (pl.col(timestamp_col) // 100000 % 100).alias("_minute"),
        (pl.col(timestamp_col) // 1000 % 100).alias("_second"),
        (pl.col(timestamp_col) % 1000).alias("_ms"),
    ])

    # Add elapsed milliseconds (int)
    # CN market: 09:30-11:30 (morning), 13:00-15:00 (afternoon)
    elapsed_ms = (
        pl.when(pl.col("_hour") < 12)
        .then(
            # Morning session: from 09:30:00.000
            (
                (pl.col("_hour") - 9) * 3600
                + (pl.col("_minute") - 30) * 60
                + pl.col("_second")
            )
            * 1000
            + pl.col("_ms")
        )
        .otherwise(
            # Afternoon session: 2 hours of morning + time since 13:00
            (
                2 * 3600 + (pl.col("_hour") - 13) * 3600 + pl.col("_minute") * 60 + pl.col("_second")
            )
            * 1000
            + pl.col("_ms")
        )
    )
    df = df.with_columns(elapsed_ms.cast(pl.Int64).alias(f"elapsed_{timestamp_col}"))

    # Drop temporary columns
    df = df.drop(["_hour", "_minute", "_second", "_ms"])

    return df


def bin(df: pl.LazyFrame, widths: dict[str, float]) -> pl.LazyFrame:
    """Add bin columns for specified columns.

    Args:
        df: Input LazyFrame
        widths: Column name to bin width mapping

    Returns:
        LazyFrame with {col}_bin columns added

    Formula:
        bin_value = round(raw_value / binwidth)
        actual_value = bin_value * binwidth  # To recover
    """
    exprs = [
        (pl.col(col) / width).round().cast(pl.Int64).alias(f"{col}_bin")
        for col, width in widths.items()
    ]
    return df.with_columns(exprs)


def aggregate(
    df: pl.LazyFrame,
    group_by: list[str],
    metrics: dict[str, pl.Expr],
) -> pl.LazyFrame:
    """Aggregate data with custom metrics.

    Args:
        df: Input LazyFrame
        group_by: Columns to group by
        metrics: Name to Polars expression mapping

    Returns:
        Aggregated LazyFrame

    Example:
        metrics = {
            "count": pl.len(),
            "total_qty": pl.col("quantity").sum(),
            "vwap": pl.col("notional").sum() / pl.col("quantity").sum(),
        }
    """
    agg_exprs = [expr.alias(name) for name, expr in metrics.items()]
    return df.group_by(group_by).agg(agg_exprs)


def horizon_suffix(h: float) -> str:
    """Convert horizon (seconds) to human-readable suffix.

    Tries largest unit first, falls back if not cleanly divisible:
    hours → minutes → seconds → milliseconds

    Examples:
        >>> horizon_suffix(0)
        '0s'
        >>> horizon_suffix(60)
        '1m'
        >>> horizon_suffix(90)
        '90s'
        >>> horizon_suffix(180)
        '3m'
        >>> horizon_suffix(3600)
        '1h'
        >>> horizon_suffix(1.5)
        '1500ms'
        >>> horizon_suffix(0.013)
        '13ms'
        >>> horizon_suffix(-60)
        '-1m'
    """
    if h == 0:
        return "0s"

    ms = int(abs(h) * 1000)

    for divisor, unit in [(3600000, "h"), (60000, "m"), (1000, "s")]:
        if ms >= divisor and ms % divisor == 0:
            suffix = f"{ms // divisor}{unit}"
            return f"-{suffix}" if h < 0 else suffix

    suffix = f"{ms}ms"
    return f"-{suffix}" if h < 0 else suffix


def horizon_ms(h: float) -> int:
    """Convert horizon (seconds) to milliseconds (int).

    Preserves sign for negative horizons.

    Examples:
        >>> horizon_ms(60)
        60000
        >>> horizon_ms(-60)
        -60000
        >>> horizon_ms(0.013)
        13
    """
    return int(h * 1000)


def horizon_cols(prefix: str, horizons: list[float]) -> list[str]:
    """Generate column names for horizons.

    Examples:
        >>> horizon_cols("mid", [60, 180, 1800])
        ['mid_1m', 'mid_3m', 'mid_30m']
        >>> horizon_cols("mid", [0.013, 0.5])
        ['mid_13ms', 'mid_500ms']
        >>> horizon_cols("y", [30, 60, 90])
        ['y_30s', 'y_1m', 'y_90s']
    """
    return [f"{prefix}_{horizon_suffix(h)}" for h in horizons]


def _horizon_to_suffix(horizon_seconds: int) -> str:
    """Convert horizon in seconds to column name suffix.

    Rule: ≤60s → use seconds (60s), >60s → use minutes (3m, 30m)
    """
    if horizon_seconds <= 60:
        return f"{horizon_seconds}s"
    else:
        minutes = horizon_seconds // 60
        return f"{minutes}m"


def forward_return(
    df_trade: pl.LazyFrame,
    df_alpha: pl.LazyFrame,
    horizons: list[int],
    trade_time_col: str = "elapsed_alpha_ts",
    alpha_time_col: str = "elapsed_ticktime",
    price_col: str = "mid",
    symbol_col: str = "ukey",
    tolerance_ms: int = 5000,
) -> pl.LazyFrame:
    """Merge alpha's future price to trade and calculate forward returns.

    For each trade row:
    1. Look up alpha price at trade_time + horizon
    2. Add forward_{price_col}_{horizon} column (the future price)
    3. Calculate y_{horizon} = (forward_price - current_price) / current_price

    Output column names follow the convention:
    - ≤60s → forward_mid_60s, y_60s
    - >60s → forward_mid_3m, y_3m

    Args:
        df_trade: Trade LazyFrame with trade_time_col and price_col
        df_alpha: Alpha LazyFrame with alpha_time_col and price_col
        horizons: List of horizon in seconds, e.g., [60, 180, 1800]
        trade_time_col: Time column in trade df (default: "elapsed_alpha_ts")
        alpha_time_col: Time column in alpha df (default: "elapsed_ticktime")
        price_col: Column name for price in both dfs (default: "mid")
        symbol_col: Symbol column for grouping (default: "ukey")
        tolerance_ms: Max time difference in ms for asof join (default: 5000)

    Returns:
        Trade LazyFrame with forward_* and y_* columns added

    Example:
        >>> df_trade = vf.parse_time(vf.scan_trade(date), "alpha_ts")
        >>> df_alpha = vf.parse_time(vf.scan_alpha(date), "ticktime")
        >>> df = vf.forward_return(df_trade, df_alpha, horizons=[60, 180, 1800])
        >>> # Creates: forward_mid_60s, forward_mid_3m, forward_mid_30m
        >>> #          y_60s, y_3m, y_30m
    """
    # Collect for asof join
    trade = df_trade.collect()
    alpha = df_alpha.collect()

    # Prepare alpha lookup table: (symbol, time) -> price
    alpha_lookup = alpha.select([
        pl.col(symbol_col),
        pl.col(alpha_time_col),
        pl.col(price_col),
    ]).sort([symbol_col, alpha_time_col])

    for horizon in horizons:
        suffix = _horizon_to_suffix(horizon)
        horizon_ms = horizon * 1000
        forward_col = f"forward_{price_col}_{suffix}"
        return_col = f"y_{suffix}"

        # Add target time column for this horizon
        trade = trade.with_columns(
            (pl.col(trade_time_col) + horizon_ms).alias("_forward_time")
        )

        # Sort by join columns (required for asof join)
        trade = trade.sort([symbol_col, "_forward_time"])

        # Asof join: find alpha price at forward_time
        joined = trade.join_asof(
            alpha_lookup.rename({alpha_time_col: "_alpha_time", price_col: "_forward_price"}),
            left_on="_forward_time",
            right_on="_alpha_time",
            by=symbol_col,
            strategy="nearest",
            tolerance=tolerance_ms,
        )

        # Add forward price and calculate return (guard against zero price)
        # Explicitly cast to Float64 to ensure consistent schema across dates
        trade = joined.with_columns([
            pl.col("_forward_price").cast(pl.Float64).alias(forward_col),
            pl.when(pl.col(price_col) != 0)
            .then((pl.col("_forward_price") - pl.col(price_col)) / pl.col(price_col))
            .otherwise(pl.lit(None, dtype=pl.Float64))
            .alias(return_col),
        ]).drop(["_forward_time", "_alpha_time", "_forward_price"])

    return trade.lazy()


def mark_to_close(
    df_trade: pl.LazyFrame,
    df_univ: pl.LazyFrame,
    mid_col: str = "mid",
    close_col: str = "close",
    symbol_col: str = "ukey",
) -> pl.LazyFrame:
    """Add mark-to-close return column.

    Joins trade with universe data to get close price, then calculates:
    y_close = (close - mid) / mid

    Args:
        df_trade: Trade LazyFrame with mid_col and symbol_col
        df_univ: Universe LazyFrame with close_col and symbol_col
        mid_col: Column name for mid price in trade df (default: "mid")
        close_col: Column name for close price in univ df (default: "close")
        symbol_col: Symbol column for joining (default: "ukey")

    Returns:
        Trade LazyFrame with y_close column added

    Example:
        >>> df_trade = vf.scan_trade(date)
        >>> df_univ = vf.scan_univ(date)
        >>> df = vf.mark_to_close(df_trade, df_univ)
        >>> # Creates: y_close
    """
    # Select only needed columns from univ to avoid column conflicts
    univ_cols = [symbol_col, close_col]
    # Check if data_date exists in both for multi-day joining
    trade_schema = df_trade.collect_schema()
    univ_schema = df_univ.collect_schema()

    if "data_date" in trade_schema.names() and "data_date" in univ_schema.names():
        # Multi-day case: join on symbol and date
        join_cols = [symbol_col, "data_date"]
        univ_cols.append("data_date")
    else:
        # Single-day case: join on symbol only
        join_cols = [symbol_col]

    # Join with univ to get close price
    df = df_trade.join(
        df_univ.select(univ_cols),
        on=join_cols,
        how="left",
    )

    # Calculate return (guard against zero mid)
    df = df.with_columns(
        pl.when(pl.col(mid_col) != 0)
        .then((pl.col(close_col) - pl.col(mid_col)) / pl.col(mid_col))
        .otherwise(pl.lit(None))
        .alias("y_close")
    )

    return df


def sign_by_side(
    df: pl.LazyFrame,
    cols: list[str],
    side_col: str = "order_side",
) -> pl.LazyFrame:
    """Sign return columns by order side.

    For Buy trades: keep sign as-is (price going up = positive = good)
    For Sell trades: negate sign (price going down = positive = good)

    This makes all returns have consistent interpretation:
    positive = favorable price move for that order side

    Args:
        df: LazyFrame with return columns
        cols: List of column names to sign (e.g., ["y_10m", "y_30m", "y_close"])
        side_col: Column containing order side (default: "order_side")
            Expected values: "Buy" or "Sell"

    Returns:
        LazyFrame with signed return columns

    Example:
        >>> df = vf.sign_by_side(df, cols=["y_10m", "y_30m", "y_close"])
        >>> # All y_* columns now have positive = favorable for that side
    """
    signed_exprs = []
    for col in cols:
        signed = (
            pl.when(pl.col(side_col) == "Sell")
            .then(-pl.col(col))
            .otherwise(pl.col(col))
            .alias(col)
        )
        signed_exprs.append(signed)

    return df.with_columns(signed_exprs)


def _merge_forward_loop(
    df_trade: pl.DataFrame | pl.LazyFrame,
    df_ref: pl.DataFrame | pl.LazyFrame,
    ref_cols: list[str],
    horizons: list[float],
    trade_time_col: str,
    ref_time_col: str,
    symbol_col: str = "ukey",
    strategy: str = "backward",
    tolerance_ms: int | None = None,
) -> pl.DataFrame:
    """Original loop implementation of merge_forward (kept for testing)."""
    if isinstance(df_trade, pl.LazyFrame):
        df_trade = df_trade.collect()
    if isinstance(df_ref, pl.LazyFrame):
        df_ref = df_ref.select([symbol_col, ref_time_col] + ref_cols).collect()

    result = df_trade

    for h in horizons:
        h_ms = horizon_ms(h)
        suffix = horizon_suffix(h)

        df_trade_shifted = result.with_columns(
            (pl.col(trade_time_col) + h_ms).alias("_forward_time")
        )

        ref_select = [symbol_col, ref_time_col] + ref_cols

        join_kwargs = {
            "left_on": "_forward_time",
            "right_on": ref_time_col,
            "by": symbol_col,
            "strategy": strategy,
        }
        if tolerance_ms is not None:
            join_kwargs["tolerance"] = tolerance_ms

        df_joined = (
            df_trade_shifted
            .sort([symbol_col, "_forward_time"])
            .join_asof(
                df_ref.select(ref_select).sort([symbol_col, ref_time_col]),
                **join_kwargs,
            )
        )

        rename_map = {col: f"{col}_{suffix}" for col in ref_cols}
        df_joined = df_joined.rename(rename_map)

        cols_to_drop = ["_forward_time"]
        if f"{ref_time_col}_right" in df_joined.columns:
            cols_to_drop.append(f"{ref_time_col}_right")
        elif ref_time_col in df_joined.columns and ref_time_col not in df_trade.columns:
            cols_to_drop.append(ref_time_col)
        result = df_joined.drop(cols_to_drop)

    return result


def merge_forward(
    df_trade: pl.DataFrame | pl.LazyFrame,
    df_ref: pl.DataFrame | pl.LazyFrame,
    ref_cols: list[str],
    horizons: list[float],
    trade_time_col: str,
    ref_time_col: str,
    symbol_col: str = "ukey",
    strategy: str = "backward",
    tolerance_ms: int | None = None,
) -> pl.DataFrame:
    """Merge forward values from reference DataFrame at specified horizons.

    More flexible than forward_return:
    - Doesn't calculate return (user does that)
    - Supports multiple ref_cols
    - Horizons in seconds (float), sub-second supported

    Time columns must be in milliseconds (int).
    Horizons are in seconds (float) - converted to ms internally.

    For each (ref_col, horizon), adds column: {col}_{suffix}
        - mid + 60 -> mid_1m (clean division)
        - mid + 90 -> mid_90s (90 % 60 != 0)
        - mid + 180 -> mid_3m
        - mid + 0.013 -> mid_13ms

    Args:
        df_trade: Trade DataFrame with trade_time_col
        df_ref: Reference DataFrame with ref_time_col and ref_cols
        ref_cols: Columns to bring forward (e.g., ["mid", "bid_px0"])
        horizons: Horizons in seconds (float), e.g., [60, 180, 1800, 0.013]
        trade_time_col: Time column in trade df (in ms)
        ref_time_col: Time column in ref df (in ms)
        symbol_col: Symbol column for grouping (default: "ukey")
        strategy: asof join strategy (default: "backward")
        tolerance_ms: Optional tolerance in ms for asof join

    Returns:
        DataFrame with forward columns added

    Example:
        >>> df = vf.merge_forward(
        ...     df_trade, df_alpha,
        ...     ref_cols=["mid", "bid_px0"],
        ...     horizons=[60, 180, 1800],
        ...     trade_time_col="elapsed_fill_ts",
        ...     ref_time_col="elapsed_ticktime",
        ... )
        >>> # Adds: mid_1m, mid_3m, mid_30m, bid_px0_1m, bid_px0_3m, bid_px0_30m
    """
    # Collect with projection pushdown for ref
    if isinstance(df_trade, pl.LazyFrame):
        df_trade = df_trade.collect()
    if isinstance(df_ref, pl.LazyFrame):
        df_ref = df_ref.select([symbol_col, ref_time_col] + ref_cols).collect()

    # Sort ref once (not per-horizon)
    df_ref_sorted = df_ref.sort([symbol_col, ref_time_col])

    # Build horizons table
    df_horizons = pl.DataFrame({
        "_h_ms": [horizon_ms(h) for h in horizons],
        "_suffix": [horizon_suffix(h) for h in horizons],
    })

    # Cross join: trade × horizons (thousands × N_horizons = still small)
    df_trade_indexed = df_trade.with_row_index("_row_idx")
    df_exploded = (
        df_trade_indexed
        .join(df_horizons, how="cross")
        .with_columns(
            (pl.col(trade_time_col) + pl.col("_h_ms")).alias("_forward_time")
        )
        .sort([symbol_col, "_forward_time"])
    )

    # Single asof join — ref scanned once instead of N_horizons times
    join_kwargs = {
        "left_on": "_forward_time",
        "right_on": ref_time_col,
        "by": symbol_col,
        "strategy": strategy,
    }
    if tolerance_ms is not None:
        join_kwargs["tolerance"] = tolerance_ms

    df_joined = df_exploded.join_asof(df_ref_sorted, **join_kwargs)

    # Pivot: one row per trade, {ref_col}_{suffix} columns
    df_wide = df_joined.pivot(
        on="_suffix",
        index="_row_idx",
        values=ref_cols,
    )

    # Polars pivot with single value col creates "{suffix}" columns,
    # but with multiple value cols creates "{value}_{suffix}" columns.
    # Normalize to always use "{ref_col}_{suffix}" naming.
    if len(ref_cols) == 1:
        suffixes = [horizon_suffix(h) for h in horizons]
        rename_map = {s: f"{ref_cols[0]}_{s}" for s in suffixes if s in df_wide.columns}
        df_wide = df_wide.rename(rename_map)

    # Rejoin with original trade columns, preserving original row order
    result = df_trade_indexed.join(df_wide, on="_row_idx").drop("_row_idx")
    return result


def melt_forward(
    df: pl.DataFrame,
    ref_cols: list[str],
    horizons: list[float],
    id_cols: list[str] | None = None,
) -> pl.DataFrame:
    """Convert wide forward columns to long format for Delta Lake storage.

    Transforms columns like bid_px0_0s, bid_px0_1m, ask_px0_0s, ask_px0_1m
    into long format with: id_cols, ref_col, horizon_ms, forward_value.

    Enables TRUE incremental append - new (ref_col, horizon) combinations
    become new partitions without touching existing data.

    Args:
        df: DataFrame with wide forward columns ({ref_col}_{suffix})
        ref_cols: List of ref_cols that were merged (e.g., ["bid_px0", "ask_px0"])
        horizons: List of horizons in seconds that were merged (e.g., [0, 60, 180])
        id_cols: Columns to keep as identifiers (default: ["seq", "data_date"]).
            All columns are kept with their original names.

    Returns:
        Long format DataFrame with columns:
        - id_cols as-is (e.g., seq, data_date)
        - ref_col: "bid_px0", "ask_px0", etc.
        - horizon_ms: 0, 60000, 180000, etc.
        - forward_value: the price value

    Example:
        >>> df_long = vf.melt_forward(df, ref_cols=["bid_px0", "ask_px0"], horizons=[0, 60],
        ...                           id_cols=["seq", "data_date"])
        >>> # Output: seq, data_date, ref_col, horizon_ms, forward_value
    """
    if id_cols is None:
        id_cols = ["seq", "data_date"]

    records = []

    for ref_col in ref_cols:
        for h in horizons:
            suffix = horizon_suffix(h)
            col_name = f"{ref_col}_{suffix}"

            if col_name not in df.columns:
                continue

            # Build select expressions — id_cols kept with original names
            select_exprs = [
                pl.col(id_cols[0]),
            ]
            for extra_col in id_cols[1:]:
                if extra_col in df.columns:
                    select_exprs.append(pl.col(extra_col))

            select_exprs.extend([
                pl.lit(ref_col).alias("ref_col"),
                pl.lit(horizon_ms(h)).alias("horizon_ms"),
                pl.col(col_name).alias("forward_value"),
            ])

            records.append(df.select(select_exprs))

    if not records:
        return pl.DataFrame()

    return pl.concat(records)


def pivot_horizons(
    df: pl.LazyFrame | pl.DataFrame,
    ref_cols: list[str],
    horizons: list[float],
    *,
    horizon_col: str = "horizon_ms",
) -> pl.DataFrame:
    """Pivot semi-wide table (horizons as rows) to wide format.

    Converts a table where each row is (trade, horizon) with ref_cols as columns
    into a table where each row is a trade with {ref_col}_{suffix} columns.

    Collects internally since pivot is inherently eager.

    Args:
        df: Semi-wide LazyFrame/DataFrame with horizon_col + ref_col columns.
            Non-ref, non-horizon columns are kept as-is (trade-level columns).
        ref_cols: Columns to pivot (e.g., ["bid_px0", "mid", "markout"]).
            Each becomes {col}_{suffix} in the output.
        horizons: Horizons in seconds. Used for column naming via horizon_suffix().
        horizon_col: Column containing horizon values in ms (default: "horizon_ms").

    Returns:
        Wide DataFrame with trade-level columns + {ref_col}_{suffix} columns.

    Example:
        >>> # Input: trade_id | horizon_ms | bid_px0 | mid
        >>> # Output: trade_id | bid_px0_0s | bid_px0_1m | mid_0s | mid_1m | ...
        >>> df_wide = vf.pivot_horizons(lf, ref_cols=["bid_px0", "mid"], horizons=[0, 60])
    """
    if isinstance(df, pl.LazyFrame):
        df = df.collect()

    # Identify trade-level columns (everything except horizon_col and ref_cols)
    trade_cols = [c for c in df.columns if c != horizon_col and c not in ref_cols]

    # Pivot: horizon_ms values become column name suffixes
    df_wide = df.pivot(
        on=horizon_col,
        index=trade_cols,
        values=ref_cols,
    )

    # Rename columns: {ref_col}_{horizon_ms_value} → {ref_col}_{suffix}
    rename_map = {}
    for rc in ref_cols:
        for h in horizons:
            h_ms = horizon_ms(h)
            old_name = f"{rc}_{h_ms}"
            new_name = f"{rc}_{horizon_suffix(h)}"
            if old_name in df_wide.columns:
                rename_map[old_name] = new_name

    if rename_map:
        df_wide = df_wide.rename(rename_map)

    return df_wide
