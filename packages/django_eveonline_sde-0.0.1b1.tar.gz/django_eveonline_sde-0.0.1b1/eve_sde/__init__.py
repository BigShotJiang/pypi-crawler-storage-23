"""Django EvE SDE Models"""

__version__ = "0.0.1b1"
__title__ = "DjangoEvEOnlineSDE"
__url__ = "https://github.com/Solar-Helix-Independent-Transport/django-eveonline-sde"
