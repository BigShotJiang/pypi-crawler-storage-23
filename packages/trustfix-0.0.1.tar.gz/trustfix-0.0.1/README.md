# TrustFix

**Automated NHI governance and IAM remediation for engineering teams.**

TrustFix finds your IAM misconfigurations and fixes them automatically via GitHub PRs — before they become incidents.

## Coming Soon

Full release at [trustfix.dev](https://trustfix.dev)

## What TrustFix Does

- Audits AWS IAM OIDC trust policies for misconfigurations
- Detects over-privileged machine identities
- Finds long-lived access keys and stale credentials
- Automatically opens GitHub PRs with least-privilege fixes
- Generates SOC2 compliance evidence from your CI/CD pipeline

## Stay Updated

- Website: [trustfix.dev](https://trustfix.dev)
- GitHub: [github.com/trustfix](https://github.com/trustfix)
