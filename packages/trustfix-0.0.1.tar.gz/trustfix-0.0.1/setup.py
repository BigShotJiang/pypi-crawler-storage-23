from setuptools import setup

setup(
    name="trustfix",
    version="0.0.1",
    description="TrustFix — Automated NHI governance and IAM remediation. Finds your IAM misconfigurations and fixes them automatically via GitHub PRs.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="TrustFix",
    author_email="hello@trustfix.dev",
    url="https://trustfix.dev",
    project_urls={
        "Homepage": "https://trustfix.dev",
        "GitHub": "https://github.com/trustfix/trustfix-core",
    },
    license="MIT",
    keywords=[
        "iam", "aws", "security", "oidc", "nhi",
        "non-human-identity", "github-actions",
        "terraform", "devsecops", "remediation"
    ],
    python_requires=">=3.9",
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
