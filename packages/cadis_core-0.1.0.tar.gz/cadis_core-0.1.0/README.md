# cadis-core

`cadis-core` is the country-agnostic structural engine used by Cadis runtimes.

Public API:

```python
from cadis_core import AdminEngineCore
```
