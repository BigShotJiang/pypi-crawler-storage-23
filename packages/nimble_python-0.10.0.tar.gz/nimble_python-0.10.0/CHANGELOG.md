# Changelog

## 0.10.0 (2026-02-25)

Full Changelog: [v0.9.1...v0.10.0](https://github.com/Nimbleway/nimble-python/compare/v0.9.1...v0.10.0)

### Features

* **api:** api update ([65920db](https://github.com/Nimbleway/nimble-python/commit/65920dbd45b01c4e1df31d4961c290a9a885d768))


### Chores

* **internal:** add request options to SSE classes ([4c227e5](https://github.com/Nimbleway/nimble-python/commit/4c227e566299f0e680c96d929582b929b04a7b6a))
* **internal:** make `test_proxy_environment_variables` more resilient ([812a0bc](https://github.com/Nimbleway/nimble-python/commit/812a0bc7beee87efd2d4aadb7b6c9d2848bfc12b))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([87829ce](https://github.com/Nimbleway/nimble-python/commit/87829ce5f3c87c5d1385755034c9b5b48174e8c7))

## 0.9.1 (2026-02-22)

Full Changelog: [v0.9.0...v0.9.1](https://github.com/Nimbleway/nimble-python/compare/v0.9.0...v0.9.1)

### Chores

* remove custom code ([1ddc742](https://github.com/Nimbleway/nimble-python/commit/1ddc74209b4d8032cf13955cec400f5a6ab84a97))

## 0.9.0 (2026-02-22)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/Nimbleway/nimble-python/compare/v0.8.0...v0.9.0)

### Features

* **api:** align `extract_async` ([ac6b389](https://github.com/Nimbleway/nimble-python/commit/ac6b389c6ed67b3e67b6b71dc74e049521541efe))
* **api:** Align new endpoints ([d1e53f1](https://github.com/Nimbleway/nimble-python/commit/d1e53f1955caa3c2e27f5b41f2b626602b29cb42))
* **api:** api update ([d99c196](https://github.com/Nimbleway/nimble-python/commit/d99c19697c3ed0bedddc900009a40b5da9a17297))
* **api:** manual test ([02f4d0b](https://github.com/Nimbleway/nimble-python/commit/02f4d0b004e11537a52740ffc645331851628d6f))
* **api:** manual updates ([78b99fb](https://github.com/Nimbleway/nimble-python/commit/78b99fbb76deb4d36c323af9893e4fa3c8bfb82c))
* **api:** Move /agent to /agents/run ([1b5ad7b](https://github.com/Nimbleway/nimble-python/commit/1b5ad7bd6e119d641be13f4856f593e73504a578))
* **api:** re-add extract ([739f8e2](https://github.com/Nimbleway/nimble-python/commit/739f8e25c84c80fc0831210cf9d63582fc18b406))


### Chores

* **internal:** remove mock server code ([7bb3c98](https://github.com/Nimbleway/nimble-python/commit/7bb3c98569bfbea5b274489f89377e0ca432e601))
* update mock server docs ([0ff079b](https://github.com/Nimbleway/nimble-python/commit/0ff079b128f3d6e0f9506bb5427a000c0372c49f))

## 0.8.0 (2026-02-17)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/Nimbleway/nimble-python/compare/v0.7.0...v0.8.0)

### Features

* **api:** api update ([d89a46f](https://github.com/Nimbleway/nimble-python/commit/d89a46fdb87ac1bc68f4279f2b168c4dca4616e0))

## 0.7.0 (2026-02-15)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/Nimbleway/nimble-python/compare/v0.6.0...v0.7.0)

### Features

* **api:** re-add search ([072bc34](https://github.com/Nimbleway/nimble-python/commit/072bc340f7aa7fc719c7778de6bd47ee3812e567))

## 0.6.0 (2026-02-15)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/Nimbleway/nimble-python/compare/v0.5.0...v0.6.0)

### Features

* **api:** manual updates ([a26613e](https://github.com/Nimbleway/nimble-python/commit/a26613e7fd71242e524a5a0b8e34b066cad16119))
* **api:** manual updates ([6f547e1](https://github.com/Nimbleway/nimble-python/commit/6f547e1967faf0a3cd819882d5acc1259bd7a5bd))
* **api:** manual updates ([65b6c51](https://github.com/Nimbleway/nimble-python/commit/65b6c51e5c34c7bed2904894e8881cda5dbc4ae8))


### Chores

* format all `api.md` files ([6d888ec](https://github.com/Nimbleway/nimble-python/commit/6d888ec6d27d748df0200e9205d14debfa4fb135))

## 0.5.0 (2026-02-12)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/Nimbleway/nimble-python/compare/v0.4.0...v0.5.0)

### Features

* **api:** add browser_actions, remove search method, update extract parameters ([ae29531](https://github.com/Nimbleway/nimble-python/commit/ae29531f5882f6344327a1fec38a211b33042cfd))
* **api:** api update ([07bfd54](https://github.com/Nimbleway/nimble-python/commit/07bfd5493c461ca377118d15d48c2f03fc74fadf))
* **api:** api update ([691e98f](https://github.com/Nimbleway/nimble-python/commit/691e98f9bbec60505e6503c21cd1e7beca100089))
* **api:** api update ([c28dfc0](https://github.com/Nimbleway/nimble-python/commit/c28dfc06a0541b9a34e1a9720fe17912e14d4510))
* **api:** api update ([5a03bb6](https://github.com/Nimbleway/nimble-python/commit/5a03bb6b343d89f88ba90e37e05115edd22e10a0))
* **api:** manual updates ([ea9b017](https://github.com/Nimbleway/nimble-python/commit/ea9b017da698c9003d7d8705d74b6464d574b5ee))
* **api:** manual updates ([5ff9f95](https://github.com/Nimbleway/nimble-python/commit/5ff9f959dfd96319f5d9a5774642928a40e403fb))
* **api:** manual updates ([f92a797](https://github.com/Nimbleway/nimble-python/commit/f92a797664b06b49848f8d75a9f860792e7402be))


### Chores

* **internal:** bump dependencies ([fbd9597](https://github.com/Nimbleway/nimble-python/commit/fbd9597337a8423aa11675f1a3d0f1c8d45ef502))
* **internal:** fix lint error on Python 3.14 ([48e9753](https://github.com/Nimbleway/nimble-python/commit/48e97535c899d49463dcca47af04d99383d414d6))

## 0.4.0 (2026-02-09)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/Nimbleway/nimble-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** Add agents and rename agent ([a72d77b](https://github.com/Nimbleway/nimble-python/commit/a72d77b446b25b5f685066254ff0bdfb05918bad))
* **api:** api update ([6f67725](https://github.com/Nimbleway/nimble-python/commit/6f67725ba6f96018e072780ae22d38cfd1ba0ad8))
* **api:** Move crawl to client ([118165a](https://github.com/Nimbleway/nimble-python/commit/118165ab63206ae7e6435b8486c25f5bf71f55a5))
* **api:** To sdk.nimbleway.com ([3dc176d](https://github.com/Nimbleway/nimble-python/commit/3dc176de8a29d3df6bfb6385d941a7881a8f56cd))


### Chores

* configure new SDK language ([1034102](https://github.com/Nimbleway/nimble-python/commit/103410232991048870d008a98e1a6a8baf8977d6))

## 0.3.0 (2026-02-03)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/Nimbleway/nimble-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** Increase default timeout ([bb00c82](https://github.com/Nimbleway/nimble-python/commit/bb00c82062da9d9e812383364adf8c5b31f3c787))
* **api:** manual updates ([fc70a1c](https://github.com/Nimbleway/nimble-python/commit/fc70a1cbc9dd6651de1ee8a564dfebb34f98af79))
* trigger new release ([e1af702](https://github.com/Nimbleway/nimble-python/commit/e1af702364372e7140b4ed647bf63181272eb7be))


### Chores

* **api:** remove staging environment ([3788e48](https://github.com/Nimbleway/nimble-python/commit/3788e48dce4f59c8ecff201fc69078dc17a8d6e9))
* **api:** Rename to nimble ([0dcaeda](https://github.com/Nimbleway/nimble-python/commit/0dcaedab384eddc0202a3228f3e013fc97c8a398))
* remove custom code ([25cdd8b](https://github.com/Nimbleway/nimble-python/commit/25cdd8b57e91a4d1269ffc16de8ffb450560b425))
* trigger release ([15b0fdb](https://github.com/Nimbleway/nimble-python/commit/15b0fdba8e7cfefa23871a1f65e0e45d8d786cff))
* update SDK settings ([1eca32d](https://github.com/Nimbleway/nimble-python/commit/1eca32d03bf29acf16cd1c95a3bdf1fc8aa736e6))
* update SDK settings ([e5719fa](https://github.com/Nimbleway/nimble-python/commit/e5719fa5eb38f4d9559642824225e991fdfe78c4))
* update SDK settings ([b5717bf](https://github.com/Nimbleway/nimble-python/commit/b5717bf9aa3c3bae35331356817f4fcabc7914da))

## 0.2.0 (2026-02-03)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/Nimbleway/nimble-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** manual updates ([dbbb503](https://github.com/Nimbleway/nimble-python/commit/dbbb503d1ba49d48f7159cf792e41a5fbcaf0461))


### Chores

* **api:** Revert to gateway.webit.live ([45b8b23](https://github.com/Nimbleway/nimble-python/commit/45b8b23f99cc5215d298eedb5457bca62ecc8da7))
* update SDK settings ([785c2e1](https://github.com/Nimbleway/nimble-python/commit/785c2e1efa3922961dd8dc6130eb8e122a2eec1e))

## 0.1.0 (2026-02-03)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/Nimbleway/nimble-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** Added crawl and search routes ([6ae9c2b](https://github.com/Nimbleway/nimble-python/commit/6ae9c2bb6c386576b4dabfac80916a65046ba7f4))
* **api:** api update ([7a9c7a0](https://github.com/Nimbleway/nimble-python/commit/7a9c7a0c88bac0d9e51eb1341bf313f74666ef64))
* **api:** api update ([ed8b3ce](https://github.com/Nimbleway/nimble-python/commit/ed8b3cec45c7b4f4a31d0ae3c130164177739090))
* **api:** api update ([91fa485](https://github.com/Nimbleway/nimble-python/commit/91fa485a630438e7f775b9f095e40e64f82cd471))
* **api:** change production repos ([fabdd1c](https://github.com/Nimbleway/nimble-python/commit/fabdd1cd0f2da3c536c5cbe120907997dc4ef7ed))
* **api:** Fix crawl list ([53c0306](https://github.com/Nimbleway/nimble-python/commit/53c0306af88fc091fc40a7dca2d8e972f15721db))
* **api:** manual updates ([1550c73](https://github.com/Nimbleway/nimble-python/commit/1550c73a62d7461f8a08d66ab5977fe577189b91))
* **api:** manual updates ([de3048b](https://github.com/Nimbleway/nimble-python/commit/de3048b0cd5bba2577532a597308d6fd7eed712b))
* **api:** manual updates ([c93bfbc](https://github.com/Nimbleway/nimble-python/commit/c93bfbcdec7ba2d71fa0922a9a264f9bf0ab980a))
* **api:** manual updates ([268a8dd](https://github.com/Nimbleway/nimble-python/commit/268a8dd90af8e7722218de397e86490dff1dd430))
* **api:** manual updates ([5d3e12d](https://github.com/Nimbleway/nimble-python/commit/5d3e12d51174a27e949b65f269855288a7869a78))
* **api:** manual updates ([6d58060](https://github.com/Nimbleway/nimble-python/commit/6d580603098ead860cea4f3790768db0c2628996))
* **api:** manual updates ([71037e2](https://github.com/Nimbleway/nimble-python/commit/71037e222770b25faf46c1edc79202741733b693))
* **api:** manual updates ([3b5f9b9](https://github.com/Nimbleway/nimble-python/commit/3b5f9b906b853fd8b1a6da3b4b3d87de55b606e4))
* **api:** manual updates ([20efc2b](https://github.com/Nimbleway/nimble-python/commit/20efc2b30d4eb49b3c8ee0b77b7e5b88bf704b77))
* **api:** manual updates ([370fd61](https://github.com/Nimbleway/nimble-python/commit/370fd6180ea064ffd79dc881f5ebb6c9614e532b))
* **api:** Manually add prod gateway ([0822c9c](https://github.com/Nimbleway/nimble-python/commit/0822c9c4a0ce2df18c872ab51d2edcd6362842c2))
* **client:** add custom JSON encoder for extended type support ([fcf7a01](https://github.com/Nimbleway/nimble-python/commit/fcf7a01624d3511fbf8aedfccc1872b8cc74cd4a))
* **client:** add support for binary request streaming ([f84b07d](https://github.com/Nimbleway/nimble-python/commit/f84b07d2b681bf66a0fec4e6f096c8fa4a3d09a6))


### Bug Fixes

* **client:** loosen auth header validation ([e1d22e8](https://github.com/Nimbleway/nimble-python/commit/e1d22e8bc03a178defe0f14935a45005abd9554c))
* **docs:** fix mcp installation instructions for remote servers ([68206c1](https://github.com/Nimbleway/nimble-python/commit/68206c1b0b26b6b2b856a379d08de7b374d14e53))


### Chores

* **api:** Update to sdk.nimbleway.com ([54c3202](https://github.com/Nimbleway/nimble-python/commit/54c32021750f42cab117d3db00aa3cdb136ecd7e))
* **ci:** upgrade `actions/github-script` ([57ac5a1](https://github.com/Nimbleway/nimble-python/commit/57ac5a1a8c6f34b6d12e407fdfefd7f089b5f64e))
* configure new SDK language ([b940e66](https://github.com/Nimbleway/nimble-python/commit/b940e660e94187c57a75e400057566ceefdc2dc3))
* **internal:** update `actions/checkout` version ([4528b9f](https://github.com/Nimbleway/nimble-python/commit/4528b9f4f749db6c213a3d978739f1b80004bbdc))
* update SDK settings ([d5ae8a7](https://github.com/Nimbleway/nimble-python/commit/d5ae8a7ca72b9efc8e6fb41af9b36e96579a6ff5))
* update SDK settings ([59e2707](https://github.com/Nimbleway/nimble-python/commit/59e27072c13f890fc1205e6c4e87407802710c3e))
