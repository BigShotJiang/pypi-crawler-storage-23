# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Union, Optional
from typing_extensions import Literal, TypeAlias

from ..._models import BaseModel

__all__ = ["WaitForNavigationAction", "WaitForNavigation", "WaitForNavigationUnionMember1"]


class WaitForNavigationUnionMember1(BaseModel):
    navigation: Literal["load", "domcontentloaded", "networkidle0", "networkidle2"]

    required: Union[Literal["true", "false"], bool, None] = None
    """Whether this action is required.

    If true, pipeline stops on failure. Accepts boolean or string "true"/"false".
    Default: true.
    """

    skip: Union[Literal["true", "false"], bool, None] = None
    """Whether to skip this action.

    Accepts boolean or string "true"/"false". Default: false.
    """

    timeout: Optional[float] = None
    """Timeout in milliseconds.

    Set to 0 for infinite timeout (no timeout). Default: 15000ms.
    """


WaitForNavigation: TypeAlias = Union[
    Literal["load", "domcontentloaded", "networkidle0", "networkidle2"], WaitForNavigationUnionMember1
]


class WaitForNavigationAction(BaseModel):
    """Wait for page navigation to complete"""

    wait_for_navigation: WaitForNavigation
