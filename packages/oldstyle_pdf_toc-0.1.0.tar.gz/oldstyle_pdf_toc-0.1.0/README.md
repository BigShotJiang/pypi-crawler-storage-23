# Oldstyle PDF ToC

## Install

```shell
pip install oldstyle-pdf-toc
```

## Usage

### 1. Create the `toc.txt`

The file must be nammed `toc.txt`


```txt
# Lines that begin with # are ignored, empty lines are alis ignored

# Set page number to Uppercase roman number (I, II, III, ...)
\pageLabel{1}{1}{UppercaseRomanNumerals}

# Copy origin ToC of the book

Schrifttum 11

# Change page number from to decimal arabic number, reset it to 1 but physical page numer is now 13
\pageLabel{13}{1}{DecimalArabicNumerals}

# Copy other parts of the ToC of the Book

I. Abbildungsverfahren 1
1. Aufgabe der Darstellenden Geometrie 1
2. Zentralprojektion 4
3. Parallelprojektion 6

II. Parallelprojektion und perspektive Affinität 8
4. Invarianten der Parallelprojektion 8
5. Der Satz von DESARGUES 11
6. Perspektive Affinität 12
7. Analytische Darstellung einer ebenen perspektiven Affinität 14
8. Das Rechtwinkelpaar einer ebenen perspektiven Affinität 17
9. Die Ellipse als affines Bild des Kreises 19
10. Affine Eigenschaften der Ellipse 21
11. Ellipsenkonstruktionen 23

# .... others entries
Namen- und Sachverzeichnis 339
```

The complete example `toc.txt` can be found in this project repository.

### 2. Call the python script

```shell
oldstyle-pdf-toc > pdftk.toc.txt
```

### 3. Call the pdftk

```shell
pdftk Strubecker.pdf update_info_utf8 pdftk.toc.txt output Strubecker.pdf-toc.pdf
```

That's it!


## Development

This Project uses `uv` to manage dependencies and tasks during development and deployment

```shell
uv python install               # Install a copy of python to this directory
uv venv                         # Creat a virtual python environment
source .venv/bin/activate       # Activate venv
uv pip install -e .             # Install this project as a python package into the virtual environment
uv build
```

## Deploy in PyPi

See: https://packaging.python.org/en/latest/guides/distributing-packages-using-setuptools/#create-an-account

Prinzipial:

```shell
uv build
```
