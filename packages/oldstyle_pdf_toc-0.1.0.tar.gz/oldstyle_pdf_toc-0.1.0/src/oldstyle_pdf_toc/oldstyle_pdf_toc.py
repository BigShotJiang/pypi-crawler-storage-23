import re
import sys
from dataclasses import dataclass

# TODO:
# * make page-offset for begin
# * print pdftk command to stderr

@dataclass
class Chapter:
    idx: str
    """
        Chapter Index: I, II, III, IV, ect
    """

    title: str
    """
        Title of the Chapter e.g. Grundlage,
    """

    page: int
    """
        physical page begin with 1
    """

    level: int = 1
    """
        ToC-Lelve 1 = chapter
    """


    def __str__(self):
        idx = self.idx.strip()
        if len(idx) > 0:
            idx = f"{idx} "
        return f"""BookmarkBegin
BookmarkTitle: {idx}{self.title.strip()}
BookmarkLevel: {self.level}
BookmarkPageNumber: {self.page}
"""

@dataclass
class Section(Chapter):
    level:int = 2


@dataclass
class PageLabel:
    physical_page_counter: int
    """
        page numer from cover to cover
    """
    logical_page_counter: int
    """
        logical page numer for each parts of the Book: Vorwort, Hauptteil, ...
    """
    num_style: str
    """
        Style from pdftk. One of "NoNumber", "LowercaseRomanNumerals", "UpercaseRomanNumerals"
    """

    def __str__(self):
        return f"""PageLabelBegin
PageLabelStart: {self.logical_page_counter}
PageLabelNewIndex: {self.physical_page_counter}
PageLabelNumStyle: {self.num_style}
"""





def parse_toc_entry(idx, line, offset) -> tuple[str,str, str]:
    line = line.strip()
    # chapter
    chapter = r"""(^[IVX]+\.)(\s+)(.+[^\d$])(\d+)$"""
    chapter_pattern = re.compile(chapter, re.MULTILINE|re.UNICODE)
    # section
    section = r"""(^[\d]+\.)(\s+)(.+[^\d$])(\d+)$"""
    section_pattern = re.compile(section, re.MULTILINE|re.UNICODE)
    # else
    none_idx_chapter = r"(.+[^\d$])(\d+)$"
    none_idx_chapter_pattern = re.compile(none_idx_chapter, re.MULTILINE|re.UNICODE)
    # do the job (very ineffectiv but readable)
    chapter_head = chapter_pattern.match(line)
    section_head = section_pattern.match(line)
    other_head = none_idx_chapter_pattern.match(line)
    if chapter_head:
        return Chapter(chapter_head[1], chapter_head[3], int(chapter_head[4]) + offset)
    elif section_head:
        return Section(section_head[1], section_head[3], int(section_head[4]) + offset)
    elif other_head:
        return Chapter("", other_head[1], int(other_head[2]) + offset)
    else:
        return ValueError(f">{line}< is not a ToC-entry")


def parse_manual_info(idx, line, page_offset):
    page_label = r"(^\\pageLabel){(\d+)}{(\d+)}{([a-z]+)}"
    page_label_pattern = re.compile(page_label, re.IGNORECASE|re.UNICODE)
    allowed_label_style = {"UppercaseRomanNumerals",
                           "DecimalArabicNumerals",
                           "LowercaseRomanNumerals",
                           "NoNumber"}
    match = page_label_pattern.match(line)
    if match:
        style = match[4]
        if style in allowed_label_style:
            return PageLabel(
                int(match[2]), # physical_page_counter
                int(match[3]), # logical_page_counter
                style
            )
        else:
            raise ValueError(f">{style}< is not allowed")
    else:
        raise ValueError(f">{line}< is not a pageLabel")


def is_informative(line):
    return len(line) > 0 and not line.startswith('#')


def parse_toc_file(tocfilename, out=sys.stdout):
    page_offset = 0
    with open(tocfilename, 'r') as toc:
        toc_line_nr = 0
        for line in toc:
            toc_line_nr = toc_line_nr + 1
            line = line.strip()
            try:
                if is_informative(line):
                    x = None
                    if line.startswith( '\\' ):
                        x = parse_manual_info(toc_line_nr, line, page_offset)
                        page_offset = x.physical_page_counter - 1
                    else:
                        x = parse_toc_entry(toc_line_nr, line, page_offset)
                    print(x, file=out, end="")
            except ValueError as ex:
                raise ValueError(f"{toc_line_nr} : {repr(ex)}") from ex


if __name__ == "__main__":
    OFFSET = 12
    with open("toc.txt") as toc:
        idx = 0
        for line in toc:
            idx = idx + 1
            x = parse_toc_entry(idx, line, OFFSET)
            if x:
                print(x, end="")




































