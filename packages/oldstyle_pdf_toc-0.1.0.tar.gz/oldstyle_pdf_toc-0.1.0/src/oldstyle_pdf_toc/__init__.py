from .oldstyle_pdf_toc import *

def main() -> None:
    parse_toc_file("toc.txt")

