"""Allow running as: python -m blackletter"""

from blackletter.cli import main

main()
