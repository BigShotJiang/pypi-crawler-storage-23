"""
Shared pytest fixtures for SafeConfig test suite.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from pysafeconfigx.core.crypto import generate_master_key


@pytest.fixture()
def master_key() -> str:
    """Return a freshly generated master key for each test."""
    return generate_master_key()


@pytest.fixture()
def env_file(tmp_path: Path) -> Path:
    """Return a temporary .env file path (does not create the file)."""
    return tmp_path / ".env"


@pytest.fixture()
def populated_env_file(tmp_path: Path) -> Path:
    """Write a minimal .env file and return its path."""
    p = tmp_path / ".env"
    p.write_text(
        "DATABASE_URL=postgres://localhost/testdb\n"
        "API_KEY=test_api_key_12345\n"
        "DEBUG=true\n"
        "MAX_WORKERS=4\n",
        encoding="utf-8",
    )
    return p


@pytest.fixture()
def master_key_env(master_key: str, monkeypatch: pytest.MonkeyPatch) -> str:
    """Set SAFECONFIG_MASTER_KEY in the environment and return the key value."""
    monkeypatch.setenv("SAFECONFIG_MASTER_KEY", master_key)
    return master_key
