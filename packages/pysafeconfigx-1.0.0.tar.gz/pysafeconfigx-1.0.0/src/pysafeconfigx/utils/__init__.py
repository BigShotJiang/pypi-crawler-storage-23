"""SafeConfig utility modules."""
