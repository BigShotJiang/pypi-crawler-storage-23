"""SafeConfig CLI package."""
