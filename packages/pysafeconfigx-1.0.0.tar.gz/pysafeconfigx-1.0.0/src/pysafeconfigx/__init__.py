"""
SafeConfig — Secure API key and configuration management for Python developers.

Example usage::

    from pysafeconfigx import SafeConfig

    config = SafeConfig(environment="production", required_keys=["DATABASE_URL", "API_KEY"])
    config.load()

    db_url = config.get("DATABASE_URL")
    api_key = config.get("API_KEY", decrypt=True)
"""

from pysafeconfigx.core.config import SafeConfig
from pysafeconfigx.core.exceptions import (
    ConfigurationError,
    DecryptionError,
    EncryptionError,
    ExposedKeyWarning,
    KeyNotFoundError,
    MissingRequiredKeyError,
)

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "you@example.com"
__license__ = "MIT"

__all__ = [
    "SafeConfig",
    "ConfigurationError",
    "KeyNotFoundError",
    "MissingRequiredKeyError",
    "EncryptionError",
    "DecryptionError",
    "ExposedKeyWarning",
    "__version__",
]
