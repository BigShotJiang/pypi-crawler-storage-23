"""SafeConfig core package."""
