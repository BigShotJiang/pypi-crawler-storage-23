"""Allow running as: python -m grafeo_memory"""

from grafeo_memory.cli import main

main()
