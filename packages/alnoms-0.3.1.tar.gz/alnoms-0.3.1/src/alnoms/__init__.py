"""
Alnoms: Industrial-Grade Algorithms and Data Structures.
"""

from alnoms.utils.profiler import Profiler

# Re-exporting for top-level access
__all__ = ["Profiler"]
