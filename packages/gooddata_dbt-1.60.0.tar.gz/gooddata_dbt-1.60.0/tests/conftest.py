# (C) 2023 GoodData Corporation
# from pathlib import Path
#
# import pytest
# import yaml
