python -m pip install --upgrade --editable ".[all]"
