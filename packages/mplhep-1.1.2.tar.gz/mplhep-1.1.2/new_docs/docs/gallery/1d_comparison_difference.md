---
title: 1D Comparison Difference
---

![1D Comparison Difference](../baseline/1d_comparison_difference.png)

??? imports "Imports"
    ```python
    --8<--
    examples/1d_histograms/1d_comparison_difference.py:imports
    --8<--
    ```

??? setup "Setup"
    ```python
    --8<--
    examples/1d_histograms/1d_comparison_difference.py:setup
    --8<--
    ```

!!! tip "Code"
    ```python
    --8<--
    examples/1d_histograms/1d_comparison_difference.py:plot_body
    --8<--
    ```

??? code "Full code"
    ```python
    --8<--
    examples/1d_histograms/1d_comparison_difference.py:full_code
    --8<--
    ```
