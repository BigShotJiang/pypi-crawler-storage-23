# `perfuse`

Perfusion of tissue/cell culture systems with XCaliburD syringes.


## Disclaimer

With the first public release, `0.1.0`, development of this package is considered complete and will
not undergo major changes moving forward. The software has been tested in our fluidics system and is
robust/stable enough for our use-case in an academic research setting.

Note that this release is for documentation purposes only; use at your own risk.


## Installation

The `perfuse` package relies on a long-unmaintained dependency which is not listed in PyPI, to
interface with XCaliburD syringe pumps from Tecan, `tecancavro`. Therefore, attempting a direct
installation from PyPI will lead to failed dependency resolution.

Two workarounds exist:

- Clone this repository and install it locally with `uv`; the `pyproject.toml` includes all sources.
- If adding `perfuse` as a project dependency via `uv`, manually declare the
[source](https://github.com/benpruitt/tecancavro) for the `tecancavro` package.

The recommended approach to install the `perfuse` CLI locally is running:

```{bash}
uv tool install perfuse --with git+https://github.com/benpruitt/tecancavro
```
