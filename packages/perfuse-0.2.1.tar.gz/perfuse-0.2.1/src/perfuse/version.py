"""Module `perfuse.version`."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Final, LiteralString


VERSION: Final[LiteralString] = "0.2.1"
