"""Module `perfuse.syringe.constants`."""

from typing import TYPE_CHECKING

from perfuse.syringe.quantities import Volume
from perfuse.syringe.valve import Port

if TYPE_CHECKING:
    from typing import Final, LiteralString


__all__: Final[list[LiteralString]] = [
    "ETHANOL_PORT",
    "DEAD_VOLUME_PUMP",
    "DEAD_VOLUME_STOCK",
    "MEDIA_PORT",
    "WASTE_PORT",
    "WATER_PORT",
]

ETHANOL_PORT: Final[Port] = Port.P2
MEDIA_PORT: Final[Port] = Port.P3
WASTE_PORT: Final[Port] = Port.P9
WATER_PORT: Final[Port] = Port.P1

DEAD_VOLUME_PUMP: Final[Volume] = Volume.from_microliters(700)
DEAD_VOLUME_STOCK: Final[Volume] = Volume.from_microliters(1200)
