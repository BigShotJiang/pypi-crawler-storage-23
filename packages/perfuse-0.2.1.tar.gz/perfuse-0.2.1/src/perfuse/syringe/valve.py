"""Module `perfuse.syringe.valve`."""

from enum import IntEnum, StrEnum
from typing import TYPE_CHECKING, final

if TYPE_CHECKING:
    from typing import Final, LiteralString


__all__: Final[list[LiteralString]] = [
    "Direction",
    "Port",
]


@final
class Port(IntEnum):
    """Numeric identifier of valve ports."""

    P0 = 0
    P1 = 1
    P2 = 2
    P3 = 3
    P4 = 4
    P5 = 5
    P6 = 6
    P7 = 7
    P8 = 8
    P9 = 9


@final
class Direction(StrEnum):
    """Valve's direction of rotation."""

    CW = "CW"
    CCW = "CCW"
