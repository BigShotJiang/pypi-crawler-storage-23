"""Module `perfuse`."""

from perfuse.cli import Cli
from perfuse.version import VERSION


def main() -> None:
    """Script entry point."""

    return Cli().execute()  # pyrefly: ignore[missing-attribute]
