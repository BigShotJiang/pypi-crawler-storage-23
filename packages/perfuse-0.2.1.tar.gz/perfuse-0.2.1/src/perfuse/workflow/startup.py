"""Module `perfuse.workflow.startup`."""

import functools as ft
import logging
import sys
from typing import TYPE_CHECKING

from tecancavro.transport import TecanAPISerial

from perfuse.syringe.controller import Controller
from perfuse.syringe.quantities import Speed, Volume
from perfuse.syringe.valve import Direction, Port

if TYPE_CHECKING:
    from collections.abc import Callable
    from logging import Formatter, StreamHandler
    from typing import Any, Concatenate, Final, LiteralString

    from tecancavro.models import XCaliburD


__all__: Final[list[LiteralString]] = [
    "intercept_interrupt",
    "prepare_logger",
    "start_controller",
]


def get_comlink() -> TecanAPISerial:
    """Extract pump's COM port and connect."""

    com_port, _, _ = TecanAPISerial.findSerialPumps().pop()

    return TecanAPISerial(0, com_port, 9600)


def get_controller() -> Controller[XCaliburD]:
    """Construct controller wrapper around connected pump."""

    return Controller.from_xcaliburd(
        com_link=get_comlink(),
        init_force=Speed.from_code(16),
        syringe_volume=Volume.from_microliters(5000),
        direction=Direction.CW,
    )


def start_controller[R: Any, **P](
    f: Callable[Concatenate[Controller[XCaliburD], P], R],
    /,
) -> Callable[P, R]:
    """Construct and initialize controller before workflow."""

    @ft.wraps(f)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        """Connect to pump and initialize before execution."""

        controller: Controller[XCaliburD] = get_controller()
        verbose: bool = (
            v
            if isinstance((v := kwargs.get("verbose", False)), bool)
            else False
        )

        controller.init(
            direction=Direction.CW,
            out_port=Port.P9,
            verbose=verbose,
        )

        return f(controller, *args, **kwargs)

    return wrapper  # ty: ignore[invalid-return-type]


def prepare_logger[R: Any, **P](
    f: Callable[Concatenate[Controller[XCaliburD], P], R],
    /,
) -> Callable[Concatenate[Controller[XCaliburD], P], R]:
    """Set logging to standard output."""

    @ft.wraps(f)
    def wrapper(
        controller: Controller[XCaliburD], *args: P.args, **kwargs: P.kwargs
    ) -> R:
        """Connect to pump and initialize before execution."""

        formatter: Formatter = logging.Formatter(
            "[{asctime}][{caller_name:<19}][{levelname:<8}]: {message}",
            datefmt="%Y-%m-%d %H:%M:%S",
            style="{",
            defaults={"caller_name": controller.__class__.__name__},
        )
        handler: StreamHandler = logging.StreamHandler(sys.stdout)

        handler.setFormatter(formatter)

        controller.__class__._logger.setLevel(logging.DEBUG)
        controller.__class__._logger.addHandler(handler)

        return f(controller, *args, **kwargs)

    return wrapper


def intercept_interrupt[R: Any, **P](
    f: Callable[Concatenate[Controller[XCaliburD], P], R],
    /,
) -> Callable[Concatenate[Controller[XCaliburD], P], R]:
    """Intercept keyboard interrupts and abort execution."""

    @ft.wraps(f)
    def wrapper(
        controller: Controller[XCaliburD], *args: P.args, **kwargs: P.kwargs
    ) -> R:
        """Connect to pump and initialize before execution."""

        try:
            return f(controller, *args, **kwargs)
        except KeyboardInterrupt:
            controller.log_critical(
                "Keyboard interrupt; waiting for last command's completion."
            )

            controller.pump.sendRcv("T")
            controller.pump.waitReady()

            controller.log_critical("Last command completed.")

            raise KeyboardInterrupt()

    return wrapper
