"""Module `perfuse.cli`."""

import sys
from argparse import ArgumentParser
from enum import StrEnum
from typing import TYPE_CHECKING, TypedDict, cast, final

from pint.errors import UndefinedUnitError
from pint.facets.plain import PlainQuantity

from perfuse.syringe import Port, Time, Volume
from perfuse.version import VERSION
from perfuse.workflow import clean_system, start_timelapse

if TYPE_CHECKING:
    from argparse import Namespace
    from typing import Any, ClassVar, Self


@final
class _Singleton(type):
    """Implementation of the singleton pattern."""

    _instances: ClassVar[dict[_Singleton, _Singleton]] = {}

    def __call__(cls: _Singleton, *args: Any, **kwargs: Any) -> _Singleton:
        """Instantiate class once or retrieve singleton."""

        if cls not in cls._instances:
            cls._instances[cls] = super(_Singleton, cls).__call__(
                *args, **kwargs
            )

        return cls._instances[cls]


@final
class Workflow(StrEnum):
    """Available fluidics workflows."""

    START_TIMELAPSE = "start-timelapse"
    CLEAN_SYSTEM = "clean-system"


def _parse_time(time_string: str, /) -> Time:
    """Parse time string into quantity."""

    try:
        quantity: PlainQuantity[Any] = PlainQuantity(time_string)
    except UndefinedUnitError as e:
        raise ValueError(f"Unrecognized units: `{e.unit_names!s}`.")

    if str(quantity.units) == "dimensionless":
        raise ValueError("Time units not provided.")

    return Time(quantity)


@final
class Cli(metaclass=_Singleton):
    """Command line interface singleton class."""

    def __init__(self: Self) -> None:
        """Instantiate CLI once."""

        epilog_string: str = "Authors: Camiel Mannens, David Fernández-García."

        # Main command:
        main_command: ArgumentParser = ArgumentParser(
            prog="perfuse",
            description=(
                "Perfusion of tissue/cell culture systems with XCaliburD "
                "syringes."
            ),
            epilog=epilog_string,
        )
        main_command.add_argument(
            "-v",
            "--version",
            action="store_true",
            help="Retrieve package version and exit.",
        )

        # Start timelapse and system cleaning subcommands:
        subparsers = main_command.add_subparsers(
            title=Workflow.__name__ + "s",
            description=Workflow.__doc__,
            dest=Workflow.__name__.lower(),
        )

        timelapse_command: ArgumentParser = subparsers.add_parser(
            Workflow.START_TIMELAPSE,
            description=start_timelapse.__doc__,
            epilog=epilog_string,
        )
        clean_command: ArgumentParser = subparsers.add_parser(
            Workflow.CLEAN_SYSTEM,
            description=clean_system.__doc__,
            epilog=epilog_string,
        )

        # Common options:
        for command in [timelapse_command, clean_command]:
            command.add_argument(
                "-v",
                "--verbose",
                action="store_true",
                help="Toggle verbose logging.",
            )
            command.add_argument(
                "--dry-run",
                action="store_true",
                help="Perform a dry run.",
            )
            required_group = command.add_argument_group(
                "Port setup (required)",
                description="Dispensing and suction ports.",
            )
            required_group.add_argument(
                "-d",
                "--dispensing-ports",
                nargs="+",
                type=lambda p: Port(int(p)),
                required=True,
                help="Connected valve ports to dispense media from.",
            )
            required_group.add_argument(
                "-s",
                "--suction-ports",
                nargs="+",
                type=lambda p: Port(int(p)),
                required=True,
                help="Connected valve ports to remove media from.",
            )

            optional_group = command.add_argument_group(
                "Fluidic modifiers (optional)",
                description="Optional arguments with defaults.",
            )
            optional_group.add_argument(
                "--flush-volume",
                type=lambda v: Volume.from_microliters(int(v)),
                default=Volume.from_milliliters(1),
                help="Microliters to flush the system with.",
            )

            command_name: Workflow = Workflow(command.prog.split().pop())

            # Additional options for starting timelapse:
            if command_name == Workflow.START_TIMELAPSE:
                optional_group.add_argument(
                    "--dispensing-volume",
                    type=lambda v: Volume.from_microliters(int(v)),
                    default=Volume.from_microliters(100),
                    help="Microliters to be dispensed in each round.",
                )
                optional_group.add_argument(
                    "--dead-volume",
                    type=lambda v: Volume.from_microliters(int(v)),
                    default=Volume.from_microliters(700),
                    help="Microliters of dead volume in the system.",
                )
                optional_group.add_argument(
                    "--interval-time",
                    type=_parse_time,
                    default=Time.from_hours(4),
                    help="Time between each perfusion round.",
                )
                optional_group.add_argument(
                    "--iteration-number",
                    type=int,
                    default=1000,
                    help="Number of perfusion rounds.",
                )
                optional_group.add_argument(
                    "--wash-time",
                    type=_parse_time,
                    default=Time.from_seconds(600),
                    help="Time to wash the system for between rounds.",
                )
                optional_group.add_argument(
                    "--flush-first",
                    action="store_true",
                    help="Whether to flush the system before perfusion.",
                )

            # Additioal options for system cleaning:
            elif command_name == Workflow.CLEAN_SYSTEM:
                optional_group.add_argument(
                    "--flush-rounds",
                    type=int,
                    default=5,
                    help="Number of washes.",
                )

        self._parser: ArgumentParser = main_command

    def execute(self: Self, /) -> None:
        """Parse arguments from standard input and execute workflow."""

        namespace: Namespace = self._parser.parse_args(sys.argv[1:])

        if namespace.version:
            self._parser.exit(0, VERSION)

        try:
            if namespace.workflow == Workflow.START_TIMELAPSE:
                start_timelapse(
                    dispensing_ports=namespace.dispensing_ports,
                    suction_ports=namespace.suction_ports,
                    dispensing_volume=namespace.dispensing_volume,
                    dead_volume_pump=namespace.dead_volume,
                    flush_volume=namespace.flush_volume,
                    flush_first=namespace.flush_first,
                    interval_time=namespace.interval_time,
                    iteration_number=namespace.iteration_number,
                    wash_time=namespace.wash_time,
                    verbose=namespace.verbose,
                    dry_run=namespace.dry_run,
                )  # ty: ignore[missing-argument]
            elif namespace.workflow == Workflow.CLEAN_SYSTEM:
                clean_system(
                    dispensing_ports=namespace.dispensing_ports,
                    suction_ports=namespace.suction_ports,
                    flush_volume=namespace.flush_volume,
                    flush_rounds=namespace.flush_rounds,
                    verbose=namespace.verbose,
                    dry_run=namespace.dry_run,
                )  # ty: ignore[missing-argument]
            else:
                self._parser.exit(
                    1, f"Invalid workflow `{namespace.workflow!s}`."
                )

        except KeyboardInterrupt:
            self._parser.exit(1, "Workflow execution aborted by user.")

        self._parser.exit(0, f"Workflow `{namespace.workflow!s}` completed.")
