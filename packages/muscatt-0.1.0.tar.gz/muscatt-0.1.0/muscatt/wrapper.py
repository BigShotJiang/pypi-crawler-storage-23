#!/bin/python3
import ctypes
import sys
import os

def MuscattSlim(ifile, ofile, lowQ, bkg, lambda_cm, d):
    lib = ctypes.CDLL('./libmuscatt.so')
    lib.MuScattSlim.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double]

    lib.MuScattSlim.restype = ctypes.c_int

    if (len(bytes(ifile, 'utf-8'))==0):
        raise Exception("Empty input filename")

    if (len(bytes(ofile, 'utf-8'))==0):
        raise Exception("Empty output filename")

    try:
        os.path.isfile(bytes(ifile, 'utf-8'))
    except Exception as error:
        raise Exception("input file does not exist on the server")


    lib.MuScattSlim(
        ctypes.c_char_p(bytes(ifile, 'utf-8')),
        ctypes.c_char_p(bytes(ofile, 'utf-8')),
        ctypes.c_int(int(lowQ)),
        ctypes.c_double(float(bkg)),
        ctypes.c_double(float(lambda_cm)),
        ctypes.c_double(float(d))
    )

def MuscattFull(ifile: str, ofile:str, lowQ:int, bkg:float, lambda_cm:float, d:float, transm:float, sigmia:float, hgqmod:int, hgqcut:float, resmod:int, dlfwhm:float, detlen:float, sampap:float, collen:float, entrap:float, reswdt:float, thkmod:int):
    lib = ctypes.CDLL('./libmuscatt.so')
    lib.MuScatt.argtypes = [
        ctypes.c_char_p,
        ctypes.c_char_p,
        ctypes.c_int,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double, # d
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_int,
        ctypes.c_double,
        ctypes.c_int,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_double,
        ctypes.c_int#18
        ]

    """
    lib.MuScatt.restype = ctypes.c_int
    if (len(bytes(ifile, 'utf-8'))==0):
        raise Exception("Empty input filename")

    if (len(bytes(ofile, 'utf-8'))==0):
        raise Exception("Empty output filename")

    try:
        os.path.isfile(bytes(ifile, 'utf-8'))
    except Exception as error:
        raise Exception("input file does not exist on the server")
    """

    try:
        lib.MuScatt(
            ctypes.c_char_p(bytes(ifile, 'utf-8')),
            ctypes.c_char_p(bytes(ofile, 'utf-8')),
            ctypes.c_int(int(lowQ)),
            ctypes.c_double(float(bkg)),
            ctypes.c_double(float(lambda_cm)),
            ctypes.c_double(float(d)),
            ctypes.c_double(float(transm)),
            ctypes.c_double(float(sigmia)),
            ctypes.c_int(int(hgqmod)),#9
            ctypes.c_double(float(hgqcut)),
            ctypes.c_int(int(resmod)),
            ctypes.c_double(float(dlfwhm)),
            ctypes.c_double(float(detlen)),
            ctypes.c_double(float(sampap)),
            ctypes.c_double(float(collen)),
            ctypes.c_double(float(entrap)),
            ctypes.c_double(float(reswdt)),
            ctypes.c_int(int(thkmod))#18
        )
    except Exception as e:
        print(e)


if __name__ == "__main__":
    if sys.argv[1] == "s":
        if len(sys.argv) != 8:
            print ("usage application <full/slim> <input file path> <outpath file path> <lowQ> <bkg> <lambda> <d>")
            raise Exception("invalid syntax")
        MuscattSlim(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6], sys.argv[7])
    elif sys.argv[1] == "f":
        print("**dbg", len(sys.argv))
        """
        MuscattFull(
                sys.argv[2], #1
                sys.argv[3],
                sys.argv[4],
                sys.argv[5],
                sys.argv[6],
                sys.argv[7],
                sys.argv[8],
                sys.argv[9],
                sys.argv[10],
                sys.argv[11], #10
                sys.argv[12],
                sys.argv[13],
                sys.argv[14],
                sys.argv[15],
                sys.argv[17],
                sys.argv[18],
                sys.argv[19],
                sys.argv[20] #18
                )
            """
    else:
        raise Exception("first param needs to be either slim or full")
