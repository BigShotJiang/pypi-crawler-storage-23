# muscatt

**muscatt** is a Python package providing a **Mu**ltiple **Scatt**ering Program for **Small Angle Scattering (SANS) Data**.

It is designed to handle the complex corrections required for high-precision neutron and X-ray scattering experiments. The package utilizes a high-performance C++ backend interfaced via `ctypes` to ensure that intensive scattering calculations are performed with maximum efficiency.

---

## 🚀 Features

* **SANS-Specific Corrections**: Tailored for Small Angle Neutron Scattering data analysis.
* **C++ Acceleration**: Core multiple scattering algorithms implemented in C++ for speed.
* **Pythonic Interface**: Easy-to-use Python wrapper for seamless integration into data reduction pipelines.
* **Cross-Platform**: Distributed with pre-compiled shared libraries for rapid deployment.

## 📦 Installation

Install the package directly via pip:

```bash
pip install muscatt