"""API Modules

This package contains all API route handlers organized by resource type.
"""
