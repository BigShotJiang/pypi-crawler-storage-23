-- Drop events table and sequence
DROP TABLE IF EXISTS events;
DROP SEQUENCE IF EXISTS events_id_seq;
