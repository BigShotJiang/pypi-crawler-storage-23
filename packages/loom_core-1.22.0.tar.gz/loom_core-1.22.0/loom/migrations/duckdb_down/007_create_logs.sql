-- Drop logs table and sequence
DROP TABLE IF EXISTS logs;
DROP SEQUENCE IF EXISTS logs_id_seq;
