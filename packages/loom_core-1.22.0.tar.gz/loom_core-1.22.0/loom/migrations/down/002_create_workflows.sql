-- Drop workflows table

DROP TABLE IF EXISTS workflows;