# Test that Jupytext markdown comments are preserved before fmt:off/on blocks
# %% [markdown]

# fmt: off
# fmt: on

# Also test with other comments
# Some comment
# %% [markdown]
# Another comment

# fmt: off
x = 1
# fmt: on

# Test multiple markdown comments
# %% [markdown]
# First markdown
# %% [code]
# Code cell

# fmt: off
y = 2
# fmt: on
