def foo():
    pass


# comment 1  # fmt: skip
# comment 2

[
    (1, 2),
    # # fmt: off
    # (3,
    #    4),
    # # fmt: on
    (5, 6),
]

[
    (1, 2),
    # # fmt: off
    # (3,
    #    4),
    # fmt: on
    (5, 6),
]


[
    (1, 2),
    # fmt: off
    # (3,
    #    4),
    # # fmt: on
    (5, 6),
]


[
    (1, 2),
    # fmt: off
    # (3,
    #    4),
    # fmt: on
    (5, 6),
]

[
    (1, 2),
    # # fmt: off
    (3,
       4),
    # # fmt: on
    (5, 6),
]

[
    (1, 2),
    # # fmt: off
    (3,
       4),
    # fmt: on
    (5, 6),
]


[
    (1, 2),
    # fmt: off
    (3,
       4),
    # # fmt: on
    (5, 6),
]


[
    (1, 2),
    # fmt: off
    (3,
       4),
    # fmt: on
    (5, 6),
]


if False:
    # fmt: off # some other comment
    pass
