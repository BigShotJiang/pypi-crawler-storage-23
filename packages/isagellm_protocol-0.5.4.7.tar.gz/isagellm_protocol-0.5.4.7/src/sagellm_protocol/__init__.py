"""sageLLM Protocol v0.1 类型定义。

本包提供 sageLLM 的公共契约类型，包括：
- 请求/响应类型
- Stream 事件类型
- 指标和错误类型
- Backend 能力类型（DType, KernelKind, CapabilityDescriptor）
- KV 生命周期钩子类型
- OpenAI 兼容类型（供 Gateway 使用）
- 算子映射类型（LogicalOperator, PhysicalOperator, OperatorMapping）
- 通信层类型（CommGroupInfo, CollectiveRequest, P2PSendRequest 等）（issue #16/#17）
- KV 钩子扩展类型（KVPriority, KVHookEvent, KVHookPayload 等）（issue #18/#19）
- 压缩层类型（CompressionConfig, QuantizationConfig, SparseConfig 等）（issue #20/#21）
- 协议版本工具（ProtocolVersion, negotiate_version 等）（issue #15）

所有类型定义严格遵循 Protocol v0.1 规范。
"""

from __future__ import annotations

from sagellm_protocol._version import __version__
from sagellm_protocol.backend_types import (
    DEVICE_TYPE_ASCEND,
    DEVICE_TYPE_CPU,
    DEVICE_TYPE_CUDA,
    DEVICE_TYPE_NPU,
    DEVICE_TYPE_ROCM,
    DEVICE_TYPE_XPU,
    CapabilityDescriptor,
    DeviceStr,
    DType,
    KernelKind,
    format_device_str,
    parse_device_str,
)

# 通信层扩展类型 (issue #16/#17)
from sagellm_protocol.comm_types import (
    CollectiveOp,
    CollectiveRequest,
    CollectiveResponse,
    CommBackendType,
    CommGroupInfo,
    CommOperationMetrics,
    CommStatus,
    CommTopologyDescriptor,
    P2PRecvRequest,
    P2PRecvResponse,
    P2PSendRequest,
    P2PSendResponse,
    ReduceOp,
    TopologyType,
)

# 压缩层扩展类型 (issue #20/#21)
from sagellm_protocol.compression_types import (
    CompressionConfig,
    CompressionMetrics,
    FusionConfig,
    FusionLevel,
    QuantizationConfig,
    QuantizationGranularity,
    QuantizationScheme,
    SparseConfig,
    SparseFormat,
    SparsityPattern,
    SpeculativeDecodingConfig,
    SpeculativeStrategy,
)
from sagellm_protocol.errors import Error, ErrorCode
from sagellm_protocol.kv_hooks import (
    KVAllocateParams,
    KVDType,
    KVEvictParams,
    KVEvictReason,
    KVFreeParams,
    KVHandle,
    KVHookEvent,
    KVHookPayload,
    KVLayout,
    KVMigrateParams,
    KVPrefetchParams,
    KVPriority,
    KVQoSPolicy,
)
from sagellm_protocol.openai_types import (
    ChatCompletionChoice,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionStreamChoice,
    ChatCompletionStreamDelta,
    ChatCompletionStreamResponse,
    ChatCompletionUsage,
    ChatMessage,
    EmbeddingData,
    EmbeddingRequest,
    EmbeddingResponse,
    EmbeddingUsage,
    ModelInfo,
    ModelListResponse,
    OpenAIError,
    OpenAIErrorResponse,
)
from sagellm_protocol.operator_mapping import (
    LogicalOperator,
    OperatorConstraint,
    OperatorMapping,
    OperatorRegistryEntry,
    OperatorRegistryQuery,
    OperatorRegistrySnapshot,
    OperatorType,
    PhysicalOperator,
)

# 协议版本工具 (issue #15)
from sagellm_protocol.protocol_version import (
    BACKWARD_COMPATIBLE_SINCE,
    CURRENT_VERSION,
    FROZEN_INTERFACES,
    PROTOCOL_VERSION,
    ProtocolVersion,
    get_interface_since_version,
    is_interface_frozen,
    negotiate_version,
)
from sagellm_protocol.sampling import (
    DEFAULT_SAMPLING_PARAMS,
    DecodingStrategy,
    SamplingParams,
    SamplingPreset,
)
from sagellm_protocol.timestamps import Timestamps
from sagellm_protocol.types import (
    Metrics,
    Request,
    Response,
    StreamEvent,
    StreamEventDelta,
    StreamEventEnd,
    StreamEventStart,
)

# 别名，用于向后兼容
StartEvent = StreamEventStart
DeltaEvent = StreamEventDelta
EndEvent = StreamEventEnd

__all__ = [
    # Version
    "__version__",
    # Core types
    "ChatMessage",
    "Request",
    "Response",
    "Metrics",
    # Streaming
    "StreamEvent",
    "StreamEventStart",
    "StreamEventDelta",
    "StreamEventEnd",
    # Streaming aliases
    "StartEvent",
    "DeltaEvent",
    "EndEvent",
    # Errors
    "Error",
    "ErrorCode",
    # Observability
    "Timestamps",
    # Backend types
    "DType",
    "KernelKind",
    "CapabilityDescriptor",
    "DeviceStr",
    "parse_device_str",
    "format_device_str",
    # Device type constants
    "DEVICE_TYPE_CPU",
    "DEVICE_TYPE_CUDA",
    "DEVICE_TYPE_NPU",
    "DEVICE_TYPE_ASCEND",
    "DEVICE_TYPE_ROCM",
    "DEVICE_TYPE_XPU",
    # KV hooks (original)
    "KVDType",
    "KVLayout",
    "KVAllocateParams",
    "KVHandle",
    "KVEvictReason",
    "KVMigrateParams",
    # KV hooks extension (issue #18/#19)
    "KVPriority",
    "KVQoSPolicy",
    "KVHookEvent",
    "KVHookPayload",
    "KVFreeParams",
    "KVEvictParams",
    "KVPrefetchParams",
    # Sampling
    "DecodingStrategy",
    "SamplingParams",
    "SamplingPreset",
    "DEFAULT_SAMPLING_PARAMS",
    # Operator Mapping (issue #34)
    "OperatorType",
    "OperatorConstraint",
    "LogicalOperator",
    "PhysicalOperator",
    "OperatorMapping",
    "OperatorRegistryEntry",
    "OperatorRegistryQuery",
    "OperatorRegistrySnapshot",
    # OpenAI-compatible types (for Gateway)
    "ChatCompletionRequest",
    "ChatCompletionResponse",
    "ChatCompletionChoice",
    "ChatCompletionUsage",
    "ChatCompletionStreamResponse",
    "ChatCompletionStreamChoice",
    "ChatCompletionStreamDelta",
    "EmbeddingRequest",
    "EmbeddingResponse",
    "EmbeddingData",
    "EmbeddingUsage",
    "ModelInfo",
    "ModelListResponse",
    "OpenAIError",
    "OpenAIErrorResponse",
    # Comm types (issue #16/#17)
    "CommBackendType",
    "ReduceOp",
    "CollectiveOp",
    "CommStatus",
    "TopologyType",
    "CommGroupInfo",
    "CollectiveRequest",
    "CollectiveResponse",
    "P2PSendRequest",
    "P2PSendResponse",
    "P2PRecvRequest",
    "P2PRecvResponse",
    "CommOperationMetrics",
    "CommTopologyDescriptor",
    # Compression types (issue #20/#21)
    "QuantizationScheme",
    "QuantizationGranularity",
    "SparseFormat",
    "SparsityPattern",
    "SpeculativeStrategy",
    "FusionLevel",
    "QuantizationConfig",
    "SparseConfig",
    "SpeculativeDecodingConfig",
    "FusionConfig",
    "CompressionConfig",
    "CompressionMetrics",
    # Protocol version (issue #15)
    "PROTOCOL_VERSION",
    "CURRENT_VERSION",
    "BACKWARD_COMPATIBLE_SINCE",
    "FROZEN_INTERFACES",
    "ProtocolVersion",
    "negotiate_version",
    "is_interface_frozen",
    "get_interface_since_version",
]
