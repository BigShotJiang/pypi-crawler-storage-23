from poser.models.gconv_origin import ConvTemporalGraphical
from poser.models.graph import Graph
