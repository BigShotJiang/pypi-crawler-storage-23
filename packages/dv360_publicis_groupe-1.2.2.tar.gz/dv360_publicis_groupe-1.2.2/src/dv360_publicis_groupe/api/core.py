def message():
    print("Hello from the core module! 👍🏼")