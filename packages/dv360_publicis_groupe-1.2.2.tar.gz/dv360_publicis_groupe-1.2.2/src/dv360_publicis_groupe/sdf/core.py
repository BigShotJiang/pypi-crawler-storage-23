def test():
    print("test done 👍🏼")

def main():
    print("main done 👍🏼")

class SDF:
    def __init__(self):
        print("SDF class initialized 👍🏼")