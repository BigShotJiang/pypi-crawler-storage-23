"""
DV360 Publicis Groupe - DV360 utility code for publicis
"""

__version__ = "0.1.0"

# Make submodules accessible
try:
    from . import api, sdf
except ImportError as e:
    print(f"Warning: Could not import submodules: {e}")
