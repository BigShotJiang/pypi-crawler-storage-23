# dv360-publicis-groupe
A dedicated python package for dv360 API

```
        > python -m venv venv
        > source ./venv/bin/activate
(venv)  > pip install -r requirements.txt
(venv)  > python -m build
(venv)  > twine upload dist/*
```

```
(venv)  > git add .
(venv)  > git commit -m "Changed Something"
(venv)  > git tag v1.1.0
(venv)  > git push origin master
(venv)  > git push --tags
```