# Compatibility shim — real code lives in trajectly.core.events
from trajectly.core.events import *  # noqa: F403
