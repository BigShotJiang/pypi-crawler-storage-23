# Compatibility shim — real code lives in trajectly.core.errors
from trajectly.core.errors import *  # noqa: F403
