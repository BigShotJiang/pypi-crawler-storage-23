# Compatibility shim — real code lives in trajectly.core.canonical
from trajectly.core.canonical import *  # noqa: F403
