# Compatibility shim — real code lives in trajectly.cli.benchmark
from trajectly.cli.benchmark import *  # noqa: F403
