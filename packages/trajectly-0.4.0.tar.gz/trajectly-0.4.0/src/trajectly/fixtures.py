# Compatibility shim — real code lives in trajectly.core.fixtures
from trajectly.core.fixtures import *  # noqa: F403
