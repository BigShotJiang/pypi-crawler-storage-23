# Compatibility shim — real code lives in trajectly.core.abstraction
from trajectly.core.abstraction import *  # noqa: F403
