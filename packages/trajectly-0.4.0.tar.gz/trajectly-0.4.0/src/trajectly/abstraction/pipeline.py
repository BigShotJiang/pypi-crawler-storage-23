# Compatibility shim — real code lives in trajectly.core.abstraction.pipeline
from trajectly.core.abstraction.pipeline import *  # noqa: F403
