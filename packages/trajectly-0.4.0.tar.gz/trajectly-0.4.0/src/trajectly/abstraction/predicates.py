# Compatibility shim — real code lives in trajectly.core.abstraction.predicates
from trajectly.core.abstraction.predicates import *  # noqa: F403
