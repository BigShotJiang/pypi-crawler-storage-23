from __future__ import annotations

from trajectly.cli.commands import app

app()
