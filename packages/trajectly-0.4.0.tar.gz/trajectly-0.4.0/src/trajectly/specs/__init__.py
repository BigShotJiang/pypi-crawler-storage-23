# Compatibility shim — real code lives in trajectly.core.specs
from trajectly.core.specs import *  # noqa: F403
