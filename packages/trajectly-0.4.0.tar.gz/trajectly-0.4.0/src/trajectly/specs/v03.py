# Compatibility shim — real code lives in trajectly.core.specs.v03
from trajectly.core.specs.v03 import *  # noqa: F403
