# Compatibility shim — real code lives in trajectly.core.specs.migrate
from trajectly.core.specs.migrate import *  # noqa: F403
