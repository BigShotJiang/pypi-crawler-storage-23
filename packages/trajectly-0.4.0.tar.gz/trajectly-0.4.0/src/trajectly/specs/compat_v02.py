# Compatibility shim — real code lives in trajectly.core.specs.compat_v02
from trajectly.core.specs.compat_v02 import *  # noqa: F403
