# Compatibility shim — real code lives in trajectly.core.contracts
from trajectly.core.contracts import *  # noqa: F403
