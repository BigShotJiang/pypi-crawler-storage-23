# Compatibility shim — real code lives in trajectly.core.trace
from trajectly.core.trace import *  # noqa: F403
