# Compatibility shim — real code lives in trajectly.core.trace.validate
from trajectly.core.trace.validate import *  # noqa: F403
