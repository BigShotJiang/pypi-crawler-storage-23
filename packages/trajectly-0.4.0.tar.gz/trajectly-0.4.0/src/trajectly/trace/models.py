# Compatibility shim — real code lives in trajectly.core.trace.models
from trajectly.core.trace.models import *  # noqa: F403
