# Compatibility shim — real code lives in trajectly.core.trace.io
from trajectly.core.trace.io import *  # noqa: F403
