# Compatibility shim — real code lives in trajectly.core.trace.meta
from trajectly.core.trace.meta import *  # noqa: F403
