# Compatibility shim — real code lives in trajectly.core.redaction
from trajectly.core.redaction import *  # noqa: F403
