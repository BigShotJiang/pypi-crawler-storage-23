# Compatibility shim — real code lives in trajectly.core.normalize.canonical
from trajectly.core.normalize.canonical import *  # noqa: F403
