# Compatibility shim — real code lives in trajectly.core.normalize
from trajectly.core.normalize import *  # noqa: F403
