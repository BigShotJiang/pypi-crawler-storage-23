# Compatibility shim — real code lives in trajectly.core.normalize.version
from trajectly.core.normalize.version import *  # noqa: F403
