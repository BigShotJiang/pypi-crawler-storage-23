# Compatibility shim — real code lives in trajectly.core.diff.engine
from trajectly.core.diff.engine import *  # noqa: F403
