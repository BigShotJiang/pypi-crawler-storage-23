# Compatibility shim — real code lives in trajectly.core.diff.structural
from trajectly.core.diff.structural import *  # noqa: F403
