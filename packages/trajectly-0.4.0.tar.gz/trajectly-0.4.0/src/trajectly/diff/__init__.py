# Compatibility shim — real code lives in trajectly.core.diff
from trajectly.core.diff import *  # noqa: F403
