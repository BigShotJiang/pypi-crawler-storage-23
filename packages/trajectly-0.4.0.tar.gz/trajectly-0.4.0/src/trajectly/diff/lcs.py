# Compatibility shim — real code lives in trajectly.core.diff.lcs
from trajectly.core.diff.lcs import *  # noqa: F403
