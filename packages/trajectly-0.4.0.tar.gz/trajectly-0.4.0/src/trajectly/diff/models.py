# Compatibility shim — real code lives in trajectly.core.diff.models
from trajectly.core.diff.models import *  # noqa: F403
