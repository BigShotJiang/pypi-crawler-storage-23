# Compatibility shim — real code lives in trajectly.core.constants
from trajectly.core.constants import *  # noqa: F403
