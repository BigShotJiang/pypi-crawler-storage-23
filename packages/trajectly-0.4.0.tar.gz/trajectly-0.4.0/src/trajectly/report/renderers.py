# Compatibility shim — real code lives in trajectly.cli.report.renderers
from trajectly.cli.report.renderers import *  # noqa: F403
