# Compatibility shim — real code lives in trajectly.core.report.schema
from trajectly.core.report.schema import *  # noqa: F403
