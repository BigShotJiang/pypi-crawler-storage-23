# Compatibility shim — real code lives in trajectly.core.trt.runner
from trajectly.core.trt.runner import *  # noqa: F403
from trajectly.core.trt.runner import _event_index_from_finding  # noqa: F401
