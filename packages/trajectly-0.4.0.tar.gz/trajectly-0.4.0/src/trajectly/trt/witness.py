# Compatibility shim — real code lives in trajectly.core.trt.witness
from trajectly.core.trt.witness import *  # noqa: F403
