# Compatibility shim — real code lives in trajectly.core.trt
from trajectly.core.trt import *  # noqa: F403
