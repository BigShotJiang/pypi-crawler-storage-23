from trajectly.core.shrink.ddmin import ShrinkResult, ddmin_shrink

__all__ = ["ShrinkResult", "ddmin_shrink"]
