# Compatibility shim — real code lives in trajectly.core.refinement.skeleton
from trajectly.core.refinement.skeleton import *  # noqa: F403
