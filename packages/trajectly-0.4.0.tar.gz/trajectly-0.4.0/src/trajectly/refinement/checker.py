# Compatibility shim — real code lives in trajectly.core.refinement.checker
from trajectly.core.refinement.checker import *  # noqa: F403
