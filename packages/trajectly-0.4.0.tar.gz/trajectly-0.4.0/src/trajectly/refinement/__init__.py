# Compatibility shim — real code lives in trajectly.core.refinement
from trajectly.core.refinement import *  # noqa: F403
