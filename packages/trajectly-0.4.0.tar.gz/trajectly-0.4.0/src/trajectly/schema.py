# Compatibility shim — real code lives in trajectly.core.schema
from trajectly.core.schema import *  # noqa: F403
