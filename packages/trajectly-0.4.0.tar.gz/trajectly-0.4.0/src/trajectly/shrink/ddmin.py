# Compatibility shim — real code lives in trajectly.core.shrink.ddmin
from trajectly.core.shrink.ddmin import *  # noqa: F403
