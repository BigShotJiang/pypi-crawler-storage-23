# Compatibility shim — real code lives in trajectly.core.shrink
from trajectly.core.shrink import *  # noqa: F403
