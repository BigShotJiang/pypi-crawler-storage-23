# mutouplotlib

[![PyPI - Version](https://img.shields.io/pypi/v/mutouplotlib.svg)](https://pypi.org/project/mutouplotlib)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/mutouplotlib.svg)](https://pypi.org/project/mutouplotlib)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install mutouplotlib
```

## License

`mutouplotlib` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
