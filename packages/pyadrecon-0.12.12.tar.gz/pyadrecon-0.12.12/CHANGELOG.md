## [0.12.12](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.11...v0.12.12) (2026-02-21)


### Bug Fixes

* add --generate-dashboard-from support ([e4905ce](https://github.com/l4rm4nd/PyADRecon/commit/e4905ce55616ea13e480f9c3c299542f07c3d312))

## [0.12.11](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.10...v0.12.11) (2026-02-21)


### Bug Fixes

* update footer ([a60f604](https://github.com/l4rm4nd/PyADRecon/commit/a60f604a82ea0c5f0c8b7889c0a87af901256d75))

## [0.12.10](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.9...v0.12.10) (2026-02-21)


### Bug Fixes

* make dashboard more mobile friendly ([75d0609](https://github.com/l4rm4nd/PyADRecon/commit/75d060947d8101958e3e1d93017415c0a941c51a))

## [0.12.9](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.8...v0.12.9) (2026-02-21)


### Bug Fixes

* refactor ESC9 detection ([9a58455](https://github.com/l4rm4nd/PyADRecon/commit/9a584559bbf4fac26e71264b2c4126af6fee6670))

## [0.12.8](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.7...v0.12.8) (2026-02-21)


### Bug Fixes

* add manager approval to dashboard ([1716844](https://github.com/l4rm4nd/PyADRecon/commit/17168444a95083828ddcf8e605f398f345562f9a))

