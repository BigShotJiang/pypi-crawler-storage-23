from mcp_filesysutils_server import main
main()