import subprocess
import json
def format_size(bytes_size: int) -> str:
    """将字节数转换为B, KB, MB, GB"""
    if bytes_size < 1024:
        return f"{bytes_size} B"
    elif bytes_size < 1024 ** 2:
        return f"{bytes_size / 1024:.2f} KB"
    elif bytes_size < 1024 ** 3:
        return f"{bytes_size / (1024 ** 2):.2f} MB"
    else:
        return f"{bytes_size / (1024 ** 3):.2f} GB"
def get_installed_programs():
    """从 Windows 注册表获取所有已安装程序（名称 + 卸载命令）"""
    try:
        ps_script = r"""
        $programs = @()
        $paths = @(
            'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
            'HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
        )
        foreach ($path in $paths) {
            if (Test-Path $path) {
                $items = Get-ItemProperty $path -ErrorAction SilentlyContinue |
                    Where-Object { $_.DisplayName -and $_.UninstallString } |
                    Select-Object DisplayName, UninstallString
                if ($items) {
                    $programs += $items
                }
            }
        }
        $programs | ConvertTo-Json -Compress
        """
        result = subprocess.run(
            ["powershell", "-Command", ps_script],
            capture_output=True,
            text=True,
            timeout=45
        )

        if result.returncode != 0 or not result.stdout.strip():
            return []

        data = json.loads(result.stdout)
        if isinstance(data, dict):
            data = [data]

        programs = []
        for item in data:
            name = item.get("DisplayName", "").strip()
            uninstall_str = item.get("UninstallString", "").strip()
            if name and uninstall_str:
                programs.append((name, uninstall_str))
        return programs

    except Exception as e:
        print(f"获取程序列表失败: {e}")
        return []