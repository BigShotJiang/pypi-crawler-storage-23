"""Shared constants for the Airbyte Agent MCP CLI."""

PACKAGE_PREFIXES = ("airbyte-agent-", "airbyte_agent_")

LOGIN_HINT = "Run [bold]adp login <organization-id>[/bold] to configure your credentials."
