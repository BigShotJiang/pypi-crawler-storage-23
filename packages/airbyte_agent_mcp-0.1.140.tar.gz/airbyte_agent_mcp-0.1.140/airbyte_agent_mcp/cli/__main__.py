from airbyte_agent_mcp.cli import main

main()
