from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_file_file_meta import DeMittwaldV1FileFileMeta
from ...models.file_get_file_meta_response_429 import FileGetFileMetaResponse429
from ...types import UNSET, Response, Unset


def _get_kwargs(
    file_id: str,
    *,
    token_query: str | Unset = UNSET,
    token_header: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(token_header, Unset):
        headers["Token"] = token_header

    params: dict[str, Any] = {}

    params["token"] = token_query

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/files/{file_id}/meta".format(
            file_id=quote(str(file_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileGetFileMetaResponse429
):
    if response.status_code == 200:
        response_200 = DeMittwaldV1FileFileMeta.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = FileGetFileMetaResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileGetFileMetaResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    file_id: str,
    *,
    client: AuthenticatedClient | Client,
    token_query: str | Unset = UNSET,
    token_header: str | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileGetFileMetaResponse429
]:
    """Get a File's meta.

    Args:
        file_id (str):
        token_query (str | Unset):  Example: jwt.
        token_header (str | Unset):  Example: jwt.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileMeta | FileGetFileMetaResponse429]
    """

    kwargs = _get_kwargs(
        file_id=file_id,
        token_query=token_query,
        token_header=token_header,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    file_id: str,
    *,
    client: AuthenticatedClient | Client,
    token_query: str | Unset = UNSET,
    token_header: str | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileGetFileMetaResponse429
    | None
):
    """Get a File's meta.

    Args:
        file_id (str):
        token_query (str | Unset):  Example: jwt.
        token_header (str | Unset):  Example: jwt.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileMeta | FileGetFileMetaResponse429
    """

    return sync_detailed(
        file_id=file_id,
        client=client,
        token_query=token_query,
        token_header=token_header,
    ).parsed


async def asyncio_detailed(
    file_id: str,
    *,
    client: AuthenticatedClient | Client,
    token_query: str | Unset = UNSET,
    token_header: str | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileGetFileMetaResponse429
]:
    """Get a File's meta.

    Args:
        file_id (str):
        token_query (str | Unset):  Example: jwt.
        token_header (str | Unset):  Example: jwt.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileMeta | FileGetFileMetaResponse429]
    """

    kwargs = _get_kwargs(
        file_id=file_id,
        token_query=token_query,
        token_header=token_header,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    file_id: str,
    *,
    client: AuthenticatedClient | Client,
    token_query: str | Unset = UNSET,
    token_header: str | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileGetFileMetaResponse429
    | None
):
    """Get a File's meta.

    Args:
        file_id (str):
        token_query (str | Unset):  Example: jwt.
        token_header (str | Unset):  Example: jwt.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileMeta | FileGetFileMetaResponse429
    """

    return (
        await asyncio_detailed(
            file_id=file_id,
            client=client,
            token_query=token_query,
            token_header=token_header,
        )
    ).parsed
