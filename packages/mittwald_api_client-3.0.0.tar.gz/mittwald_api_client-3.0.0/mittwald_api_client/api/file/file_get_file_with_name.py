from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.file_get_file_with_name_accept import FileGetFileWithNameAccept
from ...models.file_get_file_with_name_content_disposition import FileGetFileWithNameContentDisposition
from ...models.file_get_file_with_name_response_429 import FileGetFileWithNameResponse429
from ...types import UNSET, Response, Unset


def _get_kwargs(
    file_id: str,
    file_name: str,
    *,
    accept_query: FileGetFileWithNameAccept | Unset = FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM,
    content_disposition_query: FileGetFileWithNameContentDisposition
    | Unset = FileGetFileWithNameContentDisposition.INLINE,
    token_query: str | Unset = UNSET,
    accept_header: FileGetFileWithNameAccept | Unset = FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM,
    content_disposition_header: FileGetFileWithNameContentDisposition
    | Unset = FileGetFileWithNameContentDisposition.INLINE,
    token_header: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(accept_header, Unset):
        headers["Accept"] = str(accept_header)

    if not isinstance(content_disposition_header, Unset):
        headers["Content-Disposition"] = str(content_disposition_header)

    if not isinstance(token_header, Unset):
        headers["Token"] = token_header

    params: dict[str, Any] = {}

    json_accept_query: str | Unset = UNSET
    if not isinstance(accept_query, Unset):
        json_accept_query = accept_query.value

    params["accept"] = json_accept_query

    json_content_disposition_query: str | Unset = UNSET
    if not isinstance(content_disposition_query, Unset):
        json_content_disposition_query = content_disposition_query.value

    params["content-disposition"] = json_content_disposition_query

    params["token"] = token_query

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/files/{file_id}/{file_name}".format(
            file_id=quote(str(file_id), safe=""),
            file_name=quote(str(file_name), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | FileGetFileWithNameResponse429 | str:
    if response.status_code == 200:
        response_200 = cast(str, response.content)
        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = FileGetFileWithNameResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | FileGetFileWithNameResponse429 | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    file_id: str,
    file_name: str,
    *,
    client: AuthenticatedClient | Client,
    accept_query: FileGetFileWithNameAccept | Unset = FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM,
    content_disposition_query: FileGetFileWithNameContentDisposition
    | Unset = FileGetFileWithNameContentDisposition.INLINE,
    token_query: str | Unset = UNSET,
    accept_header: FileGetFileWithNameAccept | Unset = FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM,
    content_disposition_header: FileGetFileWithNameContentDisposition
    | Unset = FileGetFileWithNameContentDisposition.INLINE,
    token_header: str | Unset = UNSET,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | FileGetFileWithNameResponse429 | str]:
    """Get a File with user-friendly url.

    Args:
        file_id (str):
        file_name (str):  Example: me.jpeg.
        accept_query (FileGetFileWithNameAccept | Unset):  Default:
            FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM. Example: application/octet-stream.
        content_disposition_query (FileGetFileWithNameContentDisposition | Unset):  Default:
            FileGetFileWithNameContentDisposition.INLINE. Example: inline.
        token_query (str | Unset):  Example: jwt.
        accept_header (FileGetFileWithNameAccept | Unset):  Default:
            FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM. Example: application/octet-stream.
        content_disposition_header (FileGetFileWithNameContentDisposition | Unset):  Default:
            FileGetFileWithNameContentDisposition.INLINE. Example: inline.
        token_header (str | Unset):  Example: jwt.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | FileGetFileWithNameResponse429 | str]
    """

    kwargs = _get_kwargs(
        file_id=file_id,
        file_name=file_name,
        accept_query=accept_query,
        content_disposition_query=content_disposition_query,
        token_query=token_query,
        accept_header=accept_header,
        content_disposition_header=content_disposition_header,
        token_header=token_header,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    file_id: str,
    file_name: str,
    *,
    client: AuthenticatedClient | Client,
    accept_query: FileGetFileWithNameAccept | Unset = FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM,
    content_disposition_query: FileGetFileWithNameContentDisposition
    | Unset = FileGetFileWithNameContentDisposition.INLINE,
    token_query: str | Unset = UNSET,
    accept_header: FileGetFileWithNameAccept | Unset = FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM,
    content_disposition_header: FileGetFileWithNameContentDisposition
    | Unset = FileGetFileWithNameContentDisposition.INLINE,
    token_header: str | Unset = UNSET,
) -> DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | FileGetFileWithNameResponse429 | str | None:
    """Get a File with user-friendly url.

    Args:
        file_id (str):
        file_name (str):  Example: me.jpeg.
        accept_query (FileGetFileWithNameAccept | Unset):  Default:
            FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM. Example: application/octet-stream.
        content_disposition_query (FileGetFileWithNameContentDisposition | Unset):  Default:
            FileGetFileWithNameContentDisposition.INLINE. Example: inline.
        token_query (str | Unset):  Example: jwt.
        accept_header (FileGetFileWithNameAccept | Unset):  Default:
            FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM. Example: application/octet-stream.
        content_disposition_header (FileGetFileWithNameContentDisposition | Unset):  Default:
            FileGetFileWithNameContentDisposition.INLINE. Example: inline.
        token_header (str | Unset):  Example: jwt.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | FileGetFileWithNameResponse429 | str
    """

    return sync_detailed(
        file_id=file_id,
        file_name=file_name,
        client=client,
        accept_query=accept_query,
        content_disposition_query=content_disposition_query,
        token_query=token_query,
        accept_header=accept_header,
        content_disposition_header=content_disposition_header,
        token_header=token_header,
    ).parsed


async def asyncio_detailed(
    file_id: str,
    file_name: str,
    *,
    client: AuthenticatedClient | Client,
    accept_query: FileGetFileWithNameAccept | Unset = FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM,
    content_disposition_query: FileGetFileWithNameContentDisposition
    | Unset = FileGetFileWithNameContentDisposition.INLINE,
    token_query: str | Unset = UNSET,
    accept_header: FileGetFileWithNameAccept | Unset = FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM,
    content_disposition_header: FileGetFileWithNameContentDisposition
    | Unset = FileGetFileWithNameContentDisposition.INLINE,
    token_header: str | Unset = UNSET,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | FileGetFileWithNameResponse429 | str]:
    """Get a File with user-friendly url.

    Args:
        file_id (str):
        file_name (str):  Example: me.jpeg.
        accept_query (FileGetFileWithNameAccept | Unset):  Default:
            FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM. Example: application/octet-stream.
        content_disposition_query (FileGetFileWithNameContentDisposition | Unset):  Default:
            FileGetFileWithNameContentDisposition.INLINE. Example: inline.
        token_query (str | Unset):  Example: jwt.
        accept_header (FileGetFileWithNameAccept | Unset):  Default:
            FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM. Example: application/octet-stream.
        content_disposition_header (FileGetFileWithNameContentDisposition | Unset):  Default:
            FileGetFileWithNameContentDisposition.INLINE. Example: inline.
        token_header (str | Unset):  Example: jwt.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | FileGetFileWithNameResponse429 | str]
    """

    kwargs = _get_kwargs(
        file_id=file_id,
        file_name=file_name,
        accept_query=accept_query,
        content_disposition_query=content_disposition_query,
        token_query=token_query,
        accept_header=accept_header,
        content_disposition_header=content_disposition_header,
        token_header=token_header,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    file_id: str,
    file_name: str,
    *,
    client: AuthenticatedClient | Client,
    accept_query: FileGetFileWithNameAccept | Unset = FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM,
    content_disposition_query: FileGetFileWithNameContentDisposition
    | Unset = FileGetFileWithNameContentDisposition.INLINE,
    token_query: str | Unset = UNSET,
    accept_header: FileGetFileWithNameAccept | Unset = FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM,
    content_disposition_header: FileGetFileWithNameContentDisposition
    | Unset = FileGetFileWithNameContentDisposition.INLINE,
    token_header: str | Unset = UNSET,
) -> DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | FileGetFileWithNameResponse429 | str | None:
    """Get a File with user-friendly url.

    Args:
        file_id (str):
        file_name (str):  Example: me.jpeg.
        accept_query (FileGetFileWithNameAccept | Unset):  Default:
            FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM. Example: application/octet-stream.
        content_disposition_query (FileGetFileWithNameContentDisposition | Unset):  Default:
            FileGetFileWithNameContentDisposition.INLINE. Example: inline.
        token_query (str | Unset):  Example: jwt.
        accept_header (FileGetFileWithNameAccept | Unset):  Default:
            FileGetFileWithNameAccept.APPLICATIONOCTET_STREAM. Example: application/octet-stream.
        content_disposition_header (FileGetFileWithNameContentDisposition | Unset):  Default:
            FileGetFileWithNameContentDisposition.INLINE. Example: inline.
        token_header (str | Unset):  Example: jwt.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | FileGetFileWithNameResponse429 | str
    """

    return (
        await asyncio_detailed(
            file_id=file_id,
            file_name=file_name,
            client=client,
            accept_query=accept_query,
            content_disposition_query=content_disposition_query,
            token_query=token_query,
            accept_header=accept_header,
            content_disposition_header=content_disposition_header,
            token_header=token_header,
        )
    ).parsed
