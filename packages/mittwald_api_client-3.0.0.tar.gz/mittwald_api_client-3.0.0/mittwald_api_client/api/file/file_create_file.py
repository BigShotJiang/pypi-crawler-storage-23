from http import HTTPStatus
from typing import Any
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_file_file_meta import DeMittwaldV1FileFileMeta
from ...models.file_create_file_body import FileCreateFileBody
from ...models.file_create_file_response_429 import FileCreateFileResponse429
from ...types import Response


def _get_kwargs(
    *,
    body: FileCreateFileBody,
    token: UUID,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["Token"] = token

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/files",
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileCreateFileResponse429
):
    if response.status_code == 201:
        response_201 = DeMittwaldV1FileFileMeta.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_401

    if response.status_code == 406:
        response_406 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_406

    if response.status_code == 422:
        response_422 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = FileCreateFileResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileCreateFileResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: FileCreateFileBody,
    token: UUID,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileCreateFileResponse429
]:
    """Create a File.

    Args:
        token (UUID):  Example: 3fa85f64-5717-4562-b3fc-2c963f66afa6.
        body (FileCreateFileBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileMeta | FileCreateFileResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
        token=token,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: FileCreateFileBody,
    token: UUID,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileCreateFileResponse429
    | None
):
    """Create a File.

    Args:
        token (UUID):  Example: 3fa85f64-5717-4562-b3fc-2c963f66afa6.
        body (FileCreateFileBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileMeta | FileCreateFileResponse429
    """

    return sync_detailed(
        client=client,
        body=body,
        token=token,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: FileCreateFileBody,
    token: UUID,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileCreateFileResponse429
]:
    """Create a File.

    Args:
        token (UUID):  Example: 3fa85f64-5717-4562-b3fc-2c963f66afa6.
        body (FileCreateFileBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileMeta | FileCreateFileResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
        token=token,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: FileCreateFileBody,
    token: UUID,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileMeta
    | FileCreateFileResponse429
    | None
):
    """Create a File.

    Args:
        token (UUID):  Example: 3fa85f64-5717-4562-b3fc-2c963f66afa6.
        body (FileCreateFileBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileMeta | FileCreateFileResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            token=token,
        )
    ).parsed
