from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_file_file_upload_rules import DeMittwaldV1FileFileUploadRules
from ...models.file_get_file_upload_type_rules_file_upload_type import FileGetFileUploadTypeRulesFileUploadType
from ...types import Response


def _get_kwargs(
    file_upload_type: FileGetFileUploadTypeRulesFileUploadType,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/file-upload-types/{file_upload_type}/rules".format(
            file_upload_type=quote(str(file_upload_type), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules:
    if response.status_code == 200:
        response_200 = DeMittwaldV1FileFileUploadRules.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    file_upload_type: FileGetFileUploadTypeRulesFileUploadType,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules]:
    """Get a FileUploadType's rules.

    Args:
        file_upload_type (FileGetFileUploadTypeRulesFileUploadType):  Example: avatar.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules]
    """

    kwargs = _get_kwargs(
        file_upload_type=file_upload_type,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    file_upload_type: FileGetFileUploadTypeRulesFileUploadType,
    *,
    client: AuthenticatedClient | Client,
) -> DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules | None:
    """Get a FileUploadType's rules.

    Args:
        file_upload_type (FileGetFileUploadTypeRulesFileUploadType):  Example: avatar.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules
    """

    return sync_detailed(
        file_upload_type=file_upload_type,
        client=client,
    ).parsed


async def asyncio_detailed(
    file_upload_type: FileGetFileUploadTypeRulesFileUploadType,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules]:
    """Get a FileUploadType's rules.

    Args:
        file_upload_type (FileGetFileUploadTypeRulesFileUploadType):  Example: avatar.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules]
    """

    kwargs = _get_kwargs(
        file_upload_type=file_upload_type,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    file_upload_type: FileGetFileUploadTypeRulesFileUploadType,
    *,
    client: AuthenticatedClient | Client,
) -> DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules | None:
    """Get a FileUploadType's rules.

    Args:
        file_upload_type (FileGetFileUploadTypeRulesFileUploadType):  Example: avatar.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules
    """

    return (
        await asyncio_detailed(
            file_upload_type=file_upload_type,
            client=client,
        )
    ).parsed
