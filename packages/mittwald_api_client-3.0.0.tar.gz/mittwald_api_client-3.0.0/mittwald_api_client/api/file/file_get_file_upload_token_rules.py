from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_file_file_upload_rules import DeMittwaldV1FileFileUploadRules
from ...models.file_get_file_upload_token_rules_response_429 import FileGetFileUploadTokenRulesResponse429
from ...types import Response


def _get_kwargs(
    file_upload_token: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/file-upload-tokens/{file_upload_token}/rules".format(
            file_upload_token=quote(str(file_upload_token), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileUploadRules
    | FileGetFileUploadTokenRulesResponse429
):
    if response.status_code == 200:
        response_200 = DeMittwaldV1FileFileUploadRules.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = FileGetFileUploadTokenRulesResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileUploadRules
    | FileGetFileUploadTokenRulesResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    file_upload_token: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileUploadRules
    | FileGetFileUploadTokenRulesResponse429
]:
    """Get a FileUploadToken's rules.

    Args:
        file_upload_token (UUID):  Example: 3fa85f64-5717-4562-b3fc-2c963f66afa6.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules | FileGetFileUploadTokenRulesResponse429]
    """

    kwargs = _get_kwargs(
        file_upload_token=file_upload_token,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    file_upload_token: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileUploadRules
    | FileGetFileUploadTokenRulesResponse429
    | None
):
    """Get a FileUploadToken's rules.

    Args:
        file_upload_token (UUID):  Example: 3fa85f64-5717-4562-b3fc-2c963f66afa6.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules | FileGetFileUploadTokenRulesResponse429
    """

    return sync_detailed(
        file_upload_token=file_upload_token,
        client=client,
    ).parsed


async def asyncio_detailed(
    file_upload_token: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileUploadRules
    | FileGetFileUploadTokenRulesResponse429
]:
    """Get a FileUploadToken's rules.

    Args:
        file_upload_token (UUID):  Example: 3fa85f64-5717-4562-b3fc-2c963f66afa6.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules | FileGetFileUploadTokenRulesResponse429]
    """

    kwargs = _get_kwargs(
        file_upload_token=file_upload_token,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    file_upload_token: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1FileFileUploadRules
    | FileGetFileUploadTokenRulesResponse429
    | None
):
    """Get a FileUploadToken's rules.

    Args:
        file_upload_token (UUID):  Example: 3fa85f64-5717-4562-b3fc-2c963f66afa6.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1FileFileUploadRules | FileGetFileUploadTokenRulesResponse429
    """

    return (
        await asyncio_detailed(
            file_upload_token=file_upload_token,
            client=client,
        )
    ).parsed
