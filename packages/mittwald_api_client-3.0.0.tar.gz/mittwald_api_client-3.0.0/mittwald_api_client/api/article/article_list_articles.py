from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.article_list_articles_orderable_item import ArticleListArticlesOrderableItem
from ...models.article_list_articles_response_429 import ArticleListArticlesResponse429
from ...models.de_mittwald_v1_article_readable_article import DeMittwaldV1ArticleReadableArticle
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    customer_id: str | Unset = UNSET,
    tags: list[str] | Unset = UNSET,
    template_names: list[str] | Unset = UNSET,
    article_ids: list[str] | Unset = UNSET,
    orderable: list[ArticleListArticlesOrderableItem] | Unset = UNSET,
    name: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["customerId"] = customer_id

    json_tags: list[str] | Unset = UNSET
    if not isinstance(tags, Unset):
        json_tags = tags

    params["tags"] = json_tags

    json_template_names: list[str] | Unset = UNSET
    if not isinstance(template_names, Unset):
        json_template_names = template_names

    params["templateNames"] = json_template_names

    json_article_ids: list[str] | Unset = UNSET
    if not isinstance(article_ids, Unset):
        json_article_ids = article_ids

    params["articleIds"] = json_article_ids

    json_orderable: list[str] | Unset = UNSET
    if not isinstance(orderable, Unset):
        json_orderable = []
        for orderable_item_data in orderable:
            orderable_item = orderable_item_data.value
            json_orderable.append(orderable_item)

    params["orderable"] = json_orderable

    params["name"] = name

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/articles",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ArticleListArticlesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ArticleReadableArticle]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1ArticleReadableArticle.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = ArticleListArticlesResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ArticleListArticlesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ArticleReadableArticle]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    customer_id: str | Unset = UNSET,
    tags: list[str] | Unset = UNSET,
    template_names: list[str] | Unset = UNSET,
    article_ids: list[str] | Unset = UNSET,
    orderable: list[ArticleListArticlesOrderableItem] | Unset = UNSET,
    name: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[ArticleListArticlesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ArticleReadableArticle]]:
    """List Articles.

    Args:
        customer_id (str | Unset):
        tags (list[str] | Unset):
        template_names (list[str] | Unset):
        article_ids (list[str] | Unset):
        orderable (list[ArticleListArticlesOrderableItem] | Unset):
        name (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ArticleListArticlesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ArticleReadableArticle]]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        tags=tags,
        template_names=template_names,
        article_ids=article_ids,
        orderable=orderable,
        name=name,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    customer_id: str | Unset = UNSET,
    tags: list[str] | Unset = UNSET,
    template_names: list[str] | Unset = UNSET,
    article_ids: list[str] | Unset = UNSET,
    orderable: list[ArticleListArticlesOrderableItem] | Unset = UNSET,
    name: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> ArticleListArticlesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ArticleReadableArticle] | None:
    """List Articles.

    Args:
        customer_id (str | Unset):
        tags (list[str] | Unset):
        template_names (list[str] | Unset):
        article_ids (list[str] | Unset):
        orderable (list[ArticleListArticlesOrderableItem] | Unset):
        name (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ArticleListArticlesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ArticleReadableArticle]
    """

    return sync_detailed(
        client=client,
        customer_id=customer_id,
        tags=tags,
        template_names=template_names,
        article_ids=article_ids,
        orderable=orderable,
        name=name,
        limit=limit,
        skip=skip,
        page=page,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    customer_id: str | Unset = UNSET,
    tags: list[str] | Unset = UNSET,
    template_names: list[str] | Unset = UNSET,
    article_ids: list[str] | Unset = UNSET,
    orderable: list[ArticleListArticlesOrderableItem] | Unset = UNSET,
    name: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[ArticleListArticlesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ArticleReadableArticle]]:
    """List Articles.

    Args:
        customer_id (str | Unset):
        tags (list[str] | Unset):
        template_names (list[str] | Unset):
        article_ids (list[str] | Unset):
        orderable (list[ArticleListArticlesOrderableItem] | Unset):
        name (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ArticleListArticlesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ArticleReadableArticle]]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        tags=tags,
        template_names=template_names,
        article_ids=article_ids,
        orderable=orderable,
        name=name,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    customer_id: str | Unset = UNSET,
    tags: list[str] | Unset = UNSET,
    template_names: list[str] | Unset = UNSET,
    article_ids: list[str] | Unset = UNSET,
    orderable: list[ArticleListArticlesOrderableItem] | Unset = UNSET,
    name: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> ArticleListArticlesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ArticleReadableArticle] | None:
    """List Articles.

    Args:
        customer_id (str | Unset):
        tags (list[str] | Unset):
        template_names (list[str] | Unset):
        article_ids (list[str] | Unset):
        orderable (list[ArticleListArticlesOrderableItem] | Unset):
        name (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ArticleListArticlesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ArticleReadableArticle]
    """

    return (
        await asyncio_detailed(
            client=client,
            customer_id=customer_id,
            tags=tags,
            template_names=template_names,
            article_ids=article_ids,
            orderable=orderable,
            name=name,
            limit=limit,
            skip=skip,
            page=page,
        )
    ).parsed
