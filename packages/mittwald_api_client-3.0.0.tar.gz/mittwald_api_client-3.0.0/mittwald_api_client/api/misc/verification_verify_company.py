from http import HTTPStatus
from typing import Any, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.verification_verify_company_body import VerificationVerifyCompanyBody
from ...models.verification_verify_company_response_200 import VerificationVerifyCompanyResponse200
from ...models.verification_verify_company_response_429 import VerificationVerifyCompanyResponse429
from ...types import Response


def _get_kwargs(
    *,
    body: VerificationVerifyCompanyBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/actions/verify-company",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | DeMittwaldV1CommonsError | VerificationVerifyCompanyResponse200 | VerificationVerifyCompanyResponse429:
    if response.status_code == 200:
        response_200 = VerificationVerifyCompanyResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 412:
        response_412 = cast(Any, None)
        return response_412

    if response.status_code == 429:
        response_429 = VerificationVerifyCompanyResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any | DeMittwaldV1CommonsError | VerificationVerifyCompanyResponse200 | VerificationVerifyCompanyResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: VerificationVerifyCompanyBody,
) -> Response[
    Any | DeMittwaldV1CommonsError | VerificationVerifyCompanyResponse200 | VerificationVerifyCompanyResponse429
]:
    """Check if a company exists.

     Only companies registered in the German company register are currently supported.

    Args:
        body (VerificationVerifyCompanyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | VerificationVerifyCompanyResponse200 | VerificationVerifyCompanyResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: VerificationVerifyCompanyBody,
) -> (
    Any | DeMittwaldV1CommonsError | VerificationVerifyCompanyResponse200 | VerificationVerifyCompanyResponse429 | None
):
    """Check if a company exists.

     Only companies registered in the German company register are currently supported.

    Args:
        body (VerificationVerifyCompanyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | VerificationVerifyCompanyResponse200 | VerificationVerifyCompanyResponse429
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: VerificationVerifyCompanyBody,
) -> Response[
    Any | DeMittwaldV1CommonsError | VerificationVerifyCompanyResponse200 | VerificationVerifyCompanyResponse429
]:
    """Check if a company exists.

     Only companies registered in the German company register are currently supported.

    Args:
        body (VerificationVerifyCompanyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | VerificationVerifyCompanyResponse200 | VerificationVerifyCompanyResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: VerificationVerifyCompanyBody,
) -> (
    Any | DeMittwaldV1CommonsError | VerificationVerifyCompanyResponse200 | VerificationVerifyCompanyResponse429 | None
):
    """Check if a company exists.

     Only companies registered in the German company register are currently supported.

    Args:
        body (VerificationVerifyCompanyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | VerificationVerifyCompanyResponse200 | VerificationVerifyCompanyResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
