from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.database_get_mysql_user_php_my_admin_url_response_429 import DatabaseGetMysqlUserPhpMyAdminUrlResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_database_php_my_admin_url import DeMittwaldV1DatabasePhpMyAdminURL
from ...types import Response


def _get_kwargs(
    mysql_user_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/mysql-users/{mysql_user_id}/php-my-admin-url".format(
            mysql_user_id=quote(str(mysql_user_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DatabaseGetMysqlUserPhpMyAdminUrlResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabasePhpMyAdminURL
):
    if response.status_code == 200:
        response_200 = DeMittwaldV1DatabasePhpMyAdminURL.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = DatabaseGetMysqlUserPhpMyAdminUrlResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DatabaseGetMysqlUserPhpMyAdminUrlResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabasePhpMyAdminURL
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    mysql_user_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[
    DatabaseGetMysqlUserPhpMyAdminUrlResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabasePhpMyAdminURL
]:
    """Get a MySQLUser's PhpMyAdmin-URL.

    Args:
        mysql_user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseGetMysqlUserPhpMyAdminUrlResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DatabasePhpMyAdminURL]
    """

    kwargs = _get_kwargs(
        mysql_user_id=mysql_user_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    mysql_user_id: str,
    *,
    client: AuthenticatedClient,
) -> (
    DatabaseGetMysqlUserPhpMyAdminUrlResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabasePhpMyAdminURL
    | None
):
    """Get a MySQLUser's PhpMyAdmin-URL.

    Args:
        mysql_user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseGetMysqlUserPhpMyAdminUrlResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DatabasePhpMyAdminURL
    """

    return sync_detailed(
        mysql_user_id=mysql_user_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    mysql_user_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[
    DatabaseGetMysqlUserPhpMyAdminUrlResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabasePhpMyAdminURL
]:
    """Get a MySQLUser's PhpMyAdmin-URL.

    Args:
        mysql_user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseGetMysqlUserPhpMyAdminUrlResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DatabasePhpMyAdminURL]
    """

    kwargs = _get_kwargs(
        mysql_user_id=mysql_user_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    mysql_user_id: str,
    *,
    client: AuthenticatedClient,
) -> (
    DatabaseGetMysqlUserPhpMyAdminUrlResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabasePhpMyAdminURL
    | None
):
    """Get a MySQLUser's PhpMyAdmin-URL.

    Args:
        mysql_user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseGetMysqlUserPhpMyAdminUrlResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DatabasePhpMyAdminURL
    """

    return (
        await asyncio_detailed(
            mysql_user_id=mysql_user_id,
            client=client,
        )
    ).parsed
