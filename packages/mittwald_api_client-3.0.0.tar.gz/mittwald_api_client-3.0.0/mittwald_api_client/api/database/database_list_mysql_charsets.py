from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.database_list_mysql_charsets_response_429 import DatabaseListMysqlCharsetsResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_database_my_sql_character_settings import DeMittwaldV1DatabaseMySqlCharacterSettings
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    version: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["version"] = version

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/mysql-charsets",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DatabaseListMysqlCharsetsResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1DatabaseMySqlCharacterSettings]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1DatabaseMySqlCharacterSettings.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = DatabaseListMysqlCharsetsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DatabaseListMysqlCharsetsResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1DatabaseMySqlCharacterSettings]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = UNSET,
) -> Response[
    DatabaseListMysqlCharsetsResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1DatabaseMySqlCharacterSettings]
]:
    """List available MySQL character sets and collations, optionally filtered by a MySQLVersion.

    Args:
        version (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseListMysqlCharsetsResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1DatabaseMySqlCharacterSettings]]
    """

    kwargs = _get_kwargs(
        version=version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = UNSET,
) -> (
    DatabaseListMysqlCharsetsResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1DatabaseMySqlCharacterSettings]
    | None
):
    """List available MySQL character sets and collations, optionally filtered by a MySQLVersion.

    Args:
        version (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseListMysqlCharsetsResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1DatabaseMySqlCharacterSettings]
    """

    return sync_detailed(
        client=client,
        version=version,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = UNSET,
) -> Response[
    DatabaseListMysqlCharsetsResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1DatabaseMySqlCharacterSettings]
]:
    """List available MySQL character sets and collations, optionally filtered by a MySQLVersion.

    Args:
        version (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseListMysqlCharsetsResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1DatabaseMySqlCharacterSettings]]
    """

    kwargs = _get_kwargs(
        version=version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = UNSET,
) -> (
    DatabaseListMysqlCharsetsResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1DatabaseMySqlCharacterSettings]
    | None
):
    """List available MySQL character sets and collations, optionally filtered by a MySQLVersion.

    Args:
        version (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseListMysqlCharsetsResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1DatabaseMySqlCharacterSettings]
    """

    return (
        await asyncio_detailed(
            client=client,
            version=version,
        )
    ).parsed
