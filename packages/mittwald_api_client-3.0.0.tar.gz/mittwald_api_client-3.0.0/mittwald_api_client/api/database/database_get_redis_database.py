from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.database_get_redis_database_response_429 import DatabaseGetRedisDatabaseResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_database_redis_database import DeMittwaldV1DatabaseRedisDatabase
from ...types import Response


def _get_kwargs(
    redis_database_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/redis-databases/{redis_database_id}".format(
            redis_database_id=quote(str(redis_database_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DatabaseGetRedisDatabaseResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabaseRedisDatabase
):
    if response.status_code == 200:
        response_200 = DeMittwaldV1DatabaseRedisDatabase.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = DatabaseGetRedisDatabaseResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DatabaseGetRedisDatabaseResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabaseRedisDatabase
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    redis_database_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[
    DatabaseGetRedisDatabaseResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabaseRedisDatabase
]:
    """Get a RedisDatabase.

    Args:
        redis_database_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseGetRedisDatabaseResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DatabaseRedisDatabase]
    """

    kwargs = _get_kwargs(
        redis_database_id=redis_database_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    redis_database_id: str,
    *,
    client: AuthenticatedClient,
) -> (
    DatabaseGetRedisDatabaseResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabaseRedisDatabase
    | None
):
    """Get a RedisDatabase.

    Args:
        redis_database_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseGetRedisDatabaseResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DatabaseRedisDatabase
    """

    return sync_detailed(
        redis_database_id=redis_database_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    redis_database_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[
    DatabaseGetRedisDatabaseResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabaseRedisDatabase
]:
    """Get a RedisDatabase.

    Args:
        redis_database_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatabaseGetRedisDatabaseResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DatabaseRedisDatabase]
    """

    kwargs = _get_kwargs(
        redis_database_id=redis_database_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    redis_database_id: str,
    *,
    client: AuthenticatedClient,
) -> (
    DatabaseGetRedisDatabaseResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DatabaseRedisDatabase
    | None
):
    """Get a RedisDatabase.

    Args:
        redis_database_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatabaseGetRedisDatabaseResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DatabaseRedisDatabase
    """

    return (
        await asyncio_detailed(
            redis_database_id=redis_database_id,
            client=client,
        )
    ).parsed
