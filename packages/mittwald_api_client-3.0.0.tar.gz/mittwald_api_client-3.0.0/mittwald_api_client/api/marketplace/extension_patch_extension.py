from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_marketplace_own_extension import DeMittwaldV1MarketplaceOwnExtension
from ...models.extension_patch_extension_body import ExtensionPatchExtensionBody
from ...models.extension_patch_extension_response_429 import ExtensionPatchExtensionResponse429
from ...types import Response


def _get_kwargs(
    contributor_id: str,
    extension_id: UUID,
    *,
    body: ExtensionPatchExtensionBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v2/contributors/{contributor_id}/extensions/{extension_id}".format(
            contributor_id=quote(str(contributor_id), safe=""),
            extension_id=quote(str(extension_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1MarketplaceOwnExtension
    | ExtensionPatchExtensionResponse429
):
    if response.status_code == 200:
        response_200 = DeMittwaldV1MarketplaceOwnExtension.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_409

    if response.status_code == 429:
        response_429 = ExtensionPatchExtensionResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1MarketplaceOwnExtension
    | ExtensionPatchExtensionResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    contributor_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionPatchExtensionBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1MarketplaceOwnExtension
    | ExtensionPatchExtensionResponse429
]:
    """Patch Extension.

    Args:
        contributor_id (str):
        extension_id (UUID):
        body (ExtensionPatchExtensionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1MarketplaceOwnExtension | ExtensionPatchExtensionResponse429]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        extension_id=extension_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    contributor_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionPatchExtensionBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1MarketplaceOwnExtension
    | ExtensionPatchExtensionResponse429
    | None
):
    """Patch Extension.

    Args:
        contributor_id (str):
        extension_id (UUID):
        body (ExtensionPatchExtensionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1MarketplaceOwnExtension | ExtensionPatchExtensionResponse429
    """

    return sync_detailed(
        contributor_id=contributor_id,
        extension_id=extension_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    contributor_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionPatchExtensionBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1MarketplaceOwnExtension
    | ExtensionPatchExtensionResponse429
]:
    """Patch Extension.

    Args:
        contributor_id (str):
        extension_id (UUID):
        body (ExtensionPatchExtensionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1MarketplaceOwnExtension | ExtensionPatchExtensionResponse429]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        extension_id=extension_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    contributor_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionPatchExtensionBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1MarketplaceOwnExtension
    | ExtensionPatchExtensionResponse429
    | None
):
    """Patch Extension.

    Args:
        contributor_id (str):
        extension_id (UUID):
        body (ExtensionPatchExtensionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1MarketplaceOwnExtension | ExtensionPatchExtensionResponse429
    """

    return (
        await asyncio_detailed(
            contributor_id=contributor_id,
            extension_id=extension_id,
            client=client,
            body=body,
        )
    ).parsed
