from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_marketplace_extension import DeMittwaldV1MarketplaceExtension
from ...models.de_mittwald_v1_marketplace_unpublished_extension import DeMittwaldV1MarketplaceUnpublishedExtension
from ...models.extension_get_extension_response_429 import ExtensionGetExtensionResponse429
from ...types import Response


def _get_kwargs(
    extension_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/extensions/{extension_id}".format(
            extension_id=quote(str(extension_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtension
    | DeMittwaldV1MarketplaceUnpublishedExtension
    | ExtensionGetExtensionResponse429
):
    if response.status_code == 200:

        def _parse_response_200(
            data: object,
        ) -> DeMittwaldV1MarketplaceExtension | DeMittwaldV1MarketplaceUnpublishedExtension:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_0 = DeMittwaldV1MarketplaceExtension.from_dict(data)

                return response_200_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_200_type_1 = DeMittwaldV1MarketplaceUnpublishedExtension.from_dict(data)

            return response_200_type_1

        response_200 = _parse_response_200(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ExtensionGetExtensionResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtension
    | DeMittwaldV1MarketplaceUnpublishedExtension
    | ExtensionGetExtensionResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    extension_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtension
    | DeMittwaldV1MarketplaceUnpublishedExtension
    | ExtensionGetExtensionResponse429
]:
    """Get an Extension.

    Args:
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtension | DeMittwaldV1MarketplaceUnpublishedExtension | ExtensionGetExtensionResponse429]
    """

    kwargs = _get_kwargs(
        extension_id=extension_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    extension_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtension
    | DeMittwaldV1MarketplaceUnpublishedExtension
    | ExtensionGetExtensionResponse429
    | None
):
    """Get an Extension.

    Args:
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtension | DeMittwaldV1MarketplaceUnpublishedExtension | ExtensionGetExtensionResponse429
    """

    return sync_detailed(
        extension_id=extension_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    extension_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtension
    | DeMittwaldV1MarketplaceUnpublishedExtension
    | ExtensionGetExtensionResponse429
]:
    """Get an Extension.

    Args:
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtension | DeMittwaldV1MarketplaceUnpublishedExtension | ExtensionGetExtensionResponse429]
    """

    kwargs = _get_kwargs(
        extension_id=extension_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    extension_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtension
    | DeMittwaldV1MarketplaceUnpublishedExtension
    | ExtensionGetExtensionResponse429
    | None
):
    """Get an Extension.

    Args:
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtension | DeMittwaldV1MarketplaceUnpublishedExtension | ExtensionGetExtensionResponse429
    """

    return (
        await asyncio_detailed(
            extension_id=extension_id,
            client=client,
        )
    ).parsed
