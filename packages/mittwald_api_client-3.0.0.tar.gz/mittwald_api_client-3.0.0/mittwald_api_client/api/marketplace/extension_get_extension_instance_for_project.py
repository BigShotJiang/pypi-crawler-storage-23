from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_marketplace_extension_instance import DeMittwaldV1MarketplaceExtensionInstance
from ...models.extension_get_extension_instance_for_project_response_429 import (
    ExtensionGetExtensionInstanceForProjectResponse429,
)
from ...types import Response


def _get_kwargs(
    project_id: UUID,
    extension_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects/{project_id}/extensions/{extension_id}".format(
            project_id=quote(str(project_id), safe=""),
            extension_id=quote(str(extension_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForProjectResponse429
):
    if response.status_code == 200:
        response_200 = DeMittwaldV1MarketplaceExtensionInstance.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ExtensionGetExtensionInstanceForProjectResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForProjectResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: UUID,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForProjectResponse429
]:
    """Get the ExtensionInstance of a specific project and extension, if existing.

    Args:
        project_id (UUID):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtensionInstance | ExtensionGetExtensionInstanceForProjectResponse429]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        extension_id=extension_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: UUID,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForProjectResponse429
    | None
):
    """Get the ExtensionInstance of a specific project and extension, if existing.

    Args:
        project_id (UUID):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtensionInstance | ExtensionGetExtensionInstanceForProjectResponse429
    """

    return sync_detailed(
        project_id=project_id,
        extension_id=extension_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    project_id: UUID,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForProjectResponse429
]:
    """Get the ExtensionInstance of a specific project and extension, if existing.

    Args:
        project_id (UUID):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtensionInstance | ExtensionGetExtensionInstanceForProjectResponse429]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        extension_id=extension_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: UUID,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForProjectResponse429
    | None
):
    """Get the ExtensionInstance of a specific project and extension, if existing.

    Args:
        project_id (UUID):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtensionInstance | ExtensionGetExtensionInstanceForProjectResponse429
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            extension_id=extension_id,
            client=client,
        )
    ).parsed
