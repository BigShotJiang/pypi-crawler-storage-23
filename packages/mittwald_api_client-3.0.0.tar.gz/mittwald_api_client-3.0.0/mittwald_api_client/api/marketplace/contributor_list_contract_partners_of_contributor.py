from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.contributor_list_contract_partners_of_contributor_response_429 import (
    ContributorListContractPartnersOfContributorResponse429,
)
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_marketplace_contract_partner import DeMittwaldV1MarketplaceContractPartner
from ...types import UNSET, Response, Unset


def _get_kwargs(
    contributor_id: str,
    *,
    extension_id: UUID | Unset = UNSET,
    extension_instance_id: UUID | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_extension_id: str | Unset = UNSET
    if not isinstance(extension_id, Unset):
        json_extension_id = str(extension_id)
    params["extensionId"] = json_extension_id

    json_extension_instance_id: str | Unset = UNSET
    if not isinstance(extension_instance_id, Unset):
        json_extension_instance_id = str(extension_instance_id)
    params["extensionInstanceId"] = json_extension_instance_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/contributors/{contributor_id}/contract-partners".format(
            contributor_id=quote(str(contributor_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ContributorListContractPartnersOfContributorResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MarketplaceContractPartner]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1MarketplaceContractPartner.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = ContributorListContractPartnersOfContributorResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ContributorListContractPartnersOfContributorResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MarketplaceContractPartner]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
    extension_id: UUID | Unset = UNSET,
    extension_instance_id: UUID | Unset = UNSET,
) -> Response[
    ContributorListContractPartnersOfContributorResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MarketplaceContractPartner]
]:
    """List ContractPartners of the contributor.

    Args:
        contributor_id (str):
        extension_id (UUID | Unset):
        extension_instance_id (UUID | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContributorListContractPartnersOfContributorResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1MarketplaceContractPartner]]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        extension_id=extension_id,
        extension_instance_id=extension_instance_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
    extension_id: UUID | Unset = UNSET,
    extension_instance_id: UUID | Unset = UNSET,
) -> (
    ContributorListContractPartnersOfContributorResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MarketplaceContractPartner]
    | None
):
    """List ContractPartners of the contributor.

    Args:
        contributor_id (str):
        extension_id (UUID | Unset):
        extension_instance_id (UUID | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContributorListContractPartnersOfContributorResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1MarketplaceContractPartner]
    """

    return sync_detailed(
        contributor_id=contributor_id,
        client=client,
        extension_id=extension_id,
        extension_instance_id=extension_instance_id,
    ).parsed


async def asyncio_detailed(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
    extension_id: UUID | Unset = UNSET,
    extension_instance_id: UUID | Unset = UNSET,
) -> Response[
    ContributorListContractPartnersOfContributorResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MarketplaceContractPartner]
]:
    """List ContractPartners of the contributor.

    Args:
        contributor_id (str):
        extension_id (UUID | Unset):
        extension_instance_id (UUID | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContributorListContractPartnersOfContributorResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1MarketplaceContractPartner]]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        extension_id=extension_id,
        extension_instance_id=extension_instance_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
    extension_id: UUID | Unset = UNSET,
    extension_instance_id: UUID | Unset = UNSET,
) -> (
    ContributorListContractPartnersOfContributorResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MarketplaceContractPartner]
    | None
):
    """List ContractPartners of the contributor.

    Args:
        contributor_id (str):
        extension_id (UUID | Unset):
        extension_instance_id (UUID | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContributorListContractPartnersOfContributorResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1MarketplaceContractPartner]
    """

    return (
        await asyncio_detailed(
            contributor_id=contributor_id,
            client=client,
            extension_id=extension_id,
            extension_instance_id=extension_instance_id,
        )
    ).parsed
