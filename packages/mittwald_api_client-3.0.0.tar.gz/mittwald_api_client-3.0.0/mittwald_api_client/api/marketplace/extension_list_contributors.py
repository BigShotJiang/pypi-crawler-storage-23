from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_marketplace_contributor import DeMittwaldV1MarketplaceContributor
from ...models.extension_list_contributors_order import ExtensionListContributorsOrder
from ...models.extension_list_contributors_response_429 import ExtensionListContributorsResponse429
from ...models.extension_list_contributors_sort import ExtensionListContributorsSort
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ExtensionListContributorsSort | Unset = ExtensionListContributorsSort.NAME,
    order: ExtensionListContributorsOrder | Unset = ExtensionListContributorsOrder.ASC,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    json_sort: str | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = sort.value

    params["sort"] = json_sort

    json_order: str | Unset = UNSET
    if not isinstance(order, Unset):
        json_order = order.value

    params["order"] = json_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/contributors",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | ExtensionListContributorsResponse429 | list[DeMittwaldV1MarketplaceContributor]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1MarketplaceContributor.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = ExtensionListContributorsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError | ExtensionListContributorsResponse429 | list[DeMittwaldV1MarketplaceContributor]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ExtensionListContributorsSort | Unset = ExtensionListContributorsSort.NAME,
    order: ExtensionListContributorsOrder | Unset = ExtensionListContributorsOrder.ASC,
) -> Response[
    DeMittwaldV1CommonsError | ExtensionListContributorsResponse429 | list[DeMittwaldV1MarketplaceContributor]
]:
    """List Contributors.

    Args:
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ExtensionListContributorsSort | Unset):  Default:
            ExtensionListContributorsSort.NAME.
        order (ExtensionListContributorsOrder | Unset):  Default:
            ExtensionListContributorsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | ExtensionListContributorsResponse429 | list[DeMittwaldV1MarketplaceContributor]]
    """

    kwargs = _get_kwargs(
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ExtensionListContributorsSort | Unset = ExtensionListContributorsSort.NAME,
    order: ExtensionListContributorsOrder | Unset = ExtensionListContributorsOrder.ASC,
) -> DeMittwaldV1CommonsError | ExtensionListContributorsResponse429 | list[DeMittwaldV1MarketplaceContributor] | None:
    """List Contributors.

    Args:
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ExtensionListContributorsSort | Unset):  Default:
            ExtensionListContributorsSort.NAME.
        order (ExtensionListContributorsOrder | Unset):  Default:
            ExtensionListContributorsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | ExtensionListContributorsResponse429 | list[DeMittwaldV1MarketplaceContributor]
    """

    return sync_detailed(
        client=client,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ExtensionListContributorsSort | Unset = ExtensionListContributorsSort.NAME,
    order: ExtensionListContributorsOrder | Unset = ExtensionListContributorsOrder.ASC,
) -> Response[
    DeMittwaldV1CommonsError | ExtensionListContributorsResponse429 | list[DeMittwaldV1MarketplaceContributor]
]:
    """List Contributors.

    Args:
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ExtensionListContributorsSort | Unset):  Default:
            ExtensionListContributorsSort.NAME.
        order (ExtensionListContributorsOrder | Unset):  Default:
            ExtensionListContributorsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | ExtensionListContributorsResponse429 | list[DeMittwaldV1MarketplaceContributor]]
    """

    kwargs = _get_kwargs(
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ExtensionListContributorsSort | Unset = ExtensionListContributorsSort.NAME,
    order: ExtensionListContributorsOrder | Unset = ExtensionListContributorsOrder.ASC,
) -> DeMittwaldV1CommonsError | ExtensionListContributorsResponse429 | list[DeMittwaldV1MarketplaceContributor] | None:
    """List Contributors.

    Args:
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ExtensionListContributorsSort | Unset):  Default:
            ExtensionListContributorsSort.NAME.
        order (ExtensionListContributorsOrder | Unset):  Default:
            ExtensionListContributorsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | ExtensionListContributorsResponse429 | list[DeMittwaldV1MarketplaceContributor]
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            skip=skip,
            page=page,
            sort=sort,
            order=order,
        )
    ).parsed
