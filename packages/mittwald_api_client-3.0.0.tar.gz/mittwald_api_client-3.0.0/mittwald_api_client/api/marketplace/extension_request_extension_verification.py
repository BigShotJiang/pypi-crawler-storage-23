from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.extension_request_extension_verification_response_204 import (
    ExtensionRequestExtensionVerificationResponse204,
)
from ...models.extension_request_extension_verification_response_429 import (
    ExtensionRequestExtensionVerificationResponse429,
)
from ...types import Response


def _get_kwargs(
    contributor_id: str,
    extension_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/contributors/{contributor_id}/extensions/{extension_id}/verification-process".format(
            contributor_id=quote(str(contributor_id), safe=""),
            extension_id=quote(str(extension_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionRequestExtensionVerificationResponse204
    | ExtensionRequestExtensionVerificationResponse429
):
    if response.status_code == 204:
        response_204 = ExtensionRequestExtensionVerificationResponse204.from_dict(response.json())

        return response_204

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 429:
        response_429 = ExtensionRequestExtensionVerificationResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionRequestExtensionVerificationResponse204
    | ExtensionRequestExtensionVerificationResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    contributor_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionRequestExtensionVerificationResponse204
    | ExtensionRequestExtensionVerificationResponse429
]:
    """Start the verification process of an Extension.

    Args:
        contributor_id (str):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionRequestExtensionVerificationResponse204 | ExtensionRequestExtensionVerificationResponse429]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        extension_id=extension_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    contributor_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionRequestExtensionVerificationResponse204
    | ExtensionRequestExtensionVerificationResponse429
    | None
):
    """Start the verification process of an Extension.

    Args:
        contributor_id (str):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionRequestExtensionVerificationResponse204 | ExtensionRequestExtensionVerificationResponse429
    """

    return sync_detailed(
        contributor_id=contributor_id,
        extension_id=extension_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    contributor_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionRequestExtensionVerificationResponse204
    | ExtensionRequestExtensionVerificationResponse429
]:
    """Start the verification process of an Extension.

    Args:
        contributor_id (str):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionRequestExtensionVerificationResponse204 | ExtensionRequestExtensionVerificationResponse429]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        extension_id=extension_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    contributor_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionRequestExtensionVerificationResponse204
    | ExtensionRequestExtensionVerificationResponse429
    | None
):
    """Start the verification process of an Extension.

    Args:
        contributor_id (str):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionRequestExtensionVerificationResponse204 | ExtensionRequestExtensionVerificationResponse429
    """

    return (
        await asyncio_detailed(
            contributor_id=contributor_id,
            extension_id=extension_id,
            client=client,
        )
    ).parsed
