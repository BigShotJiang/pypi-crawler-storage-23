from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.extension_cancel_extension_termination_body import ExtensionCancelExtensionTerminationBody
from ...models.extension_cancel_extension_termination_response_200 import ExtensionCancelExtensionTerminationResponse200
from ...models.extension_cancel_extension_termination_response_429 import ExtensionCancelExtensionTerminationResponse429
from ...types import UNSET, Response, Unset


def _get_kwargs(
    extension_instance_id: UUID,
    *,
    body: ExtensionCancelExtensionTerminationBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v2/extension-instances/{extension_instance_id}/termination".format(
            extension_instance_id=quote(str(extension_instance_id), safe=""),
        ),
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionCancelExtensionTerminationResponse200
    | ExtensionCancelExtensionTerminationResponse429
):
    if response.status_code == 200:
        response_200 = ExtensionCancelExtensionTerminationResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ExtensionCancelExtensionTerminationResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionCancelExtensionTerminationResponse200
    | ExtensionCancelExtensionTerminationResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    extension_instance_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionCancelExtensionTerminationBody | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionCancelExtensionTerminationResponse200
    | ExtensionCancelExtensionTerminationResponse429
]:
    """Cancel an Extension Instance Termination.

    Args:
        extension_instance_id (UUID):
        body (ExtensionCancelExtensionTerminationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionCancelExtensionTerminationResponse200 | ExtensionCancelExtensionTerminationResponse429]
    """

    kwargs = _get_kwargs(
        extension_instance_id=extension_instance_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    extension_instance_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionCancelExtensionTerminationBody | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionCancelExtensionTerminationResponse200
    | ExtensionCancelExtensionTerminationResponse429
    | None
):
    """Cancel an Extension Instance Termination.

    Args:
        extension_instance_id (UUID):
        body (ExtensionCancelExtensionTerminationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionCancelExtensionTerminationResponse200 | ExtensionCancelExtensionTerminationResponse429
    """

    return sync_detailed(
        extension_instance_id=extension_instance_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    extension_instance_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionCancelExtensionTerminationBody | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionCancelExtensionTerminationResponse200
    | ExtensionCancelExtensionTerminationResponse429
]:
    """Cancel an Extension Instance Termination.

    Args:
        extension_instance_id (UUID):
        body (ExtensionCancelExtensionTerminationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionCancelExtensionTerminationResponse200 | ExtensionCancelExtensionTerminationResponse429]
    """

    kwargs = _get_kwargs(
        extension_instance_id=extension_instance_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    extension_instance_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionCancelExtensionTerminationBody | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionCancelExtensionTerminationResponse200
    | ExtensionCancelExtensionTerminationResponse429
    | None
):
    """Cancel an Extension Instance Termination.

    Args:
        extension_instance_id (UUID):
        body (ExtensionCancelExtensionTerminationBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionCancelExtensionTerminationResponse200 | ExtensionCancelExtensionTerminationResponse429
    """

    return (
        await asyncio_detailed(
            extension_instance_id=extension_instance_id,
            client=client,
            body=body,
        )
    ).parsed
