from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.contributor_list_incoming_invoices_order_item import ContributorListIncomingInvoicesOrderItem
from ...models.contributor_list_incoming_invoices_response_200_item import (
    ContributorListIncomingInvoicesResponse200Item,
)
from ...models.contributor_list_incoming_invoices_response_429 import ContributorListIncomingInvoicesResponse429
from ...models.contributor_list_incoming_invoices_sort_item import ContributorListIncomingInvoicesSortItem
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...types import UNSET, Response, Unset


def _get_kwargs(
    contributor_id: str,
    *,
    search: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[ContributorListIncomingInvoicesSortItem] | Unset = UNSET,
    order: list[ContributorListIncomingInvoicesOrderItem] | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["search"] = search

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    json_sort: list[str] | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = []
        for sort_item_data in sort:
            sort_item = sort_item_data.value
            json_sort.append(sort_item)

    params["sort"] = json_sort

    json_order: list[str] | Unset = UNSET
    if not isinstance(order, Unset):
        json_order = []
        for order_item_data in order:
            order_item = order_item_data.value
            json_order.append(order_item)

    params["order"] = json_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/contributors/{contributor_id}/invoices/incoming".format(
            contributor_id=quote(str(contributor_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ContributorListIncomingInvoicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[ContributorListIncomingInvoicesResponse200Item]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ContributorListIncomingInvoicesResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ContributorListIncomingInvoicesResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ContributorListIncomingInvoicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[ContributorListIncomingInvoicesResponse200Item]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[ContributorListIncomingInvoicesSortItem] | Unset = UNSET,
    order: list[ContributorListIncomingInvoicesOrderItem] | Unset = UNSET,
) -> Response[
    ContributorListIncomingInvoicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[ContributorListIncomingInvoicesResponse200Item]
]:
    """List incoming Invoices of a Contributor.

    Args:
        contributor_id (str):
        search (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[ContributorListIncomingInvoicesSortItem] | Unset):
        order (list[ContributorListIncomingInvoicesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContributorListIncomingInvoicesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[ContributorListIncomingInvoicesResponse200Item]]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        search=search,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[ContributorListIncomingInvoicesSortItem] | Unset = UNSET,
    order: list[ContributorListIncomingInvoicesOrderItem] | Unset = UNSET,
) -> (
    ContributorListIncomingInvoicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[ContributorListIncomingInvoicesResponse200Item]
    | None
):
    """List incoming Invoices of a Contributor.

    Args:
        contributor_id (str):
        search (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[ContributorListIncomingInvoicesSortItem] | Unset):
        order (list[ContributorListIncomingInvoicesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContributorListIncomingInvoicesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[ContributorListIncomingInvoicesResponse200Item]
    """

    return sync_detailed(
        contributor_id=contributor_id,
        client=client,
        search=search,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    ).parsed


async def asyncio_detailed(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[ContributorListIncomingInvoicesSortItem] | Unset = UNSET,
    order: list[ContributorListIncomingInvoicesOrderItem] | Unset = UNSET,
) -> Response[
    ContributorListIncomingInvoicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[ContributorListIncomingInvoicesResponse200Item]
]:
    """List incoming Invoices of a Contributor.

    Args:
        contributor_id (str):
        search (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[ContributorListIncomingInvoicesSortItem] | Unset):
        order (list[ContributorListIncomingInvoicesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContributorListIncomingInvoicesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[ContributorListIncomingInvoicesResponse200Item]]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        search=search,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[ContributorListIncomingInvoicesSortItem] | Unset = UNSET,
    order: list[ContributorListIncomingInvoicesOrderItem] | Unset = UNSET,
) -> (
    ContributorListIncomingInvoicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[ContributorListIncomingInvoicesResponse200Item]
    | None
):
    """List incoming Invoices of a Contributor.

    Args:
        contributor_id (str):
        search (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[ContributorListIncomingInvoicesSortItem] | Unset):
        order (list[ContributorListIncomingInvoicesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContributorListIncomingInvoicesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[ContributorListIncomingInvoicesResponse200Item]
    """

    return (
        await asyncio_detailed(
            contributor_id=contributor_id,
            client=client,
            search=search,
            limit=limit,
            skip=skip,
            page=page,
            sort=sort,
            order=order,
        )
    ).parsed
