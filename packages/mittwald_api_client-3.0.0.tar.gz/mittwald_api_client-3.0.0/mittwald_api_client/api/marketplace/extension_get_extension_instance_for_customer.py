from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_marketplace_extension_instance import DeMittwaldV1MarketplaceExtensionInstance
from ...models.extension_get_extension_instance_for_customer_response_429 import (
    ExtensionGetExtensionInstanceForCustomerResponse429,
)
from ...types import Response


def _get_kwargs(
    customer_id: str,
    extension_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/customers/{customer_id}/extensions/{extension_id}".format(
            customer_id=quote(str(customer_id), safe=""),
            extension_id=quote(str(extension_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForCustomerResponse429
):
    if response.status_code == 200:
        response_200 = DeMittwaldV1MarketplaceExtensionInstance.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ExtensionGetExtensionInstanceForCustomerResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForCustomerResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    customer_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForCustomerResponse429
]:
    """Get the ExtensionInstance of a specific customer and extension, if existing.

    Args:
        customer_id (str):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtensionInstance | ExtensionGetExtensionInstanceForCustomerResponse429]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        extension_id=extension_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    customer_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForCustomerResponse429
    | None
):
    """Get the ExtensionInstance of a specific customer and extension, if existing.

    Args:
        customer_id (str):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtensionInstance | ExtensionGetExtensionInstanceForCustomerResponse429
    """

    return sync_detailed(
        customer_id=customer_id,
        extension_id=extension_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    customer_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForCustomerResponse429
]:
    """Get the ExtensionInstance of a specific customer and extension, if existing.

    Args:
        customer_id (str):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtensionInstance | ExtensionGetExtensionInstanceForCustomerResponse429]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        extension_id=extension_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    customer_id: str,
    extension_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1MarketplaceExtensionInstance
    | ExtensionGetExtensionInstanceForCustomerResponse429
    | None
):
    """Get the ExtensionInstance of a specific customer and extension, if existing.

    Args:
        customer_id (str):
        extension_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1MarketplaceExtensionInstance | ExtensionGetExtensionInstanceForCustomerResponse429
    """

    return (
        await asyncio_detailed(
            customer_id=customer_id,
            extension_id=extension_id,
            client=client,
        )
    ).parsed
