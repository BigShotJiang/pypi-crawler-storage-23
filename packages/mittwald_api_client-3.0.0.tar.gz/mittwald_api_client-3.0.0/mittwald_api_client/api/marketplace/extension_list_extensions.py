from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_marketplace_context import DeMittwaldV1MarketplaceContext
from ...models.de_mittwald_v1_marketplace_extension import DeMittwaldV1MarketplaceExtension
from ...models.extension_list_extensions_order import ExtensionListExtensionsOrder
from ...models.extension_list_extensions_response_429 import ExtensionListExtensionsResponse429
from ...models.extension_list_extensions_sort import ExtensionListExtensionsSort
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    context: DeMittwaldV1MarketplaceContext | Unset = UNSET,
    search_term: str | Unset = UNSET,
    include_deprecated: bool | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ExtensionListExtensionsSort | Unset = ExtensionListExtensionsSort.NAME,
    order: ExtensionListExtensionsOrder | Unset = ExtensionListExtensionsOrder.ASC,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_context: str | Unset = UNSET
    if not isinstance(context, Unset):
        json_context = context.value

    params["context"] = json_context

    params["searchTerm"] = search_term

    params["includeDeprecated"] = include_deprecated

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    json_sort: str | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = sort.value

    params["sort"] = json_sort

    json_order: str | Unset = UNSET
    if not isinstance(order, Unset):
        json_order = order.value

    params["order"] = json_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/extensions",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | ExtensionListExtensionsResponse429 | list[DeMittwaldV1MarketplaceExtension]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1MarketplaceExtension.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = ExtensionListExtensionsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | ExtensionListExtensionsResponse429 | list[DeMittwaldV1MarketplaceExtension]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    context: DeMittwaldV1MarketplaceContext | Unset = UNSET,
    search_term: str | Unset = UNSET,
    include_deprecated: bool | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ExtensionListExtensionsSort | Unset = ExtensionListExtensionsSort.NAME,
    order: ExtensionListExtensionsOrder | Unset = ExtensionListExtensionsOrder.ASC,
) -> Response[DeMittwaldV1CommonsError | ExtensionListExtensionsResponse429 | list[DeMittwaldV1MarketplaceExtension]]:
    """List Extensions.

    Args:
        context (DeMittwaldV1MarketplaceContext | Unset):
        search_term (str | Unset):
        include_deprecated (bool | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ExtensionListExtensionsSort | Unset):  Default: ExtensionListExtensionsSort.NAME.
        order (ExtensionListExtensionsOrder | Unset):  Default: ExtensionListExtensionsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | ExtensionListExtensionsResponse429 | list[DeMittwaldV1MarketplaceExtension]]
    """

    kwargs = _get_kwargs(
        context=context,
        search_term=search_term,
        include_deprecated=include_deprecated,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    context: DeMittwaldV1MarketplaceContext | Unset = UNSET,
    search_term: str | Unset = UNSET,
    include_deprecated: bool | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ExtensionListExtensionsSort | Unset = ExtensionListExtensionsSort.NAME,
    order: ExtensionListExtensionsOrder | Unset = ExtensionListExtensionsOrder.ASC,
) -> DeMittwaldV1CommonsError | ExtensionListExtensionsResponse429 | list[DeMittwaldV1MarketplaceExtension] | None:
    """List Extensions.

    Args:
        context (DeMittwaldV1MarketplaceContext | Unset):
        search_term (str | Unset):
        include_deprecated (bool | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ExtensionListExtensionsSort | Unset):  Default: ExtensionListExtensionsSort.NAME.
        order (ExtensionListExtensionsOrder | Unset):  Default: ExtensionListExtensionsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | ExtensionListExtensionsResponse429 | list[DeMittwaldV1MarketplaceExtension]
    """

    return sync_detailed(
        client=client,
        context=context,
        search_term=search_term,
        include_deprecated=include_deprecated,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    context: DeMittwaldV1MarketplaceContext | Unset = UNSET,
    search_term: str | Unset = UNSET,
    include_deprecated: bool | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ExtensionListExtensionsSort | Unset = ExtensionListExtensionsSort.NAME,
    order: ExtensionListExtensionsOrder | Unset = ExtensionListExtensionsOrder.ASC,
) -> Response[DeMittwaldV1CommonsError | ExtensionListExtensionsResponse429 | list[DeMittwaldV1MarketplaceExtension]]:
    """List Extensions.

    Args:
        context (DeMittwaldV1MarketplaceContext | Unset):
        search_term (str | Unset):
        include_deprecated (bool | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ExtensionListExtensionsSort | Unset):  Default: ExtensionListExtensionsSort.NAME.
        order (ExtensionListExtensionsOrder | Unset):  Default: ExtensionListExtensionsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | ExtensionListExtensionsResponse429 | list[DeMittwaldV1MarketplaceExtension]]
    """

    kwargs = _get_kwargs(
        context=context,
        search_term=search_term,
        include_deprecated=include_deprecated,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    context: DeMittwaldV1MarketplaceContext | Unset = UNSET,
    search_term: str | Unset = UNSET,
    include_deprecated: bool | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ExtensionListExtensionsSort | Unset = ExtensionListExtensionsSort.NAME,
    order: ExtensionListExtensionsOrder | Unset = ExtensionListExtensionsOrder.ASC,
) -> DeMittwaldV1CommonsError | ExtensionListExtensionsResponse429 | list[DeMittwaldV1MarketplaceExtension] | None:
    """List Extensions.

    Args:
        context (DeMittwaldV1MarketplaceContext | Unset):
        search_term (str | Unset):
        include_deprecated (bool | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ExtensionListExtensionsSort | Unset):  Default: ExtensionListExtensionsSort.NAME.
        order (ExtensionListExtensionsOrder | Unset):  Default: ExtensionListExtensionsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | ExtensionListExtensionsResponse429 | list[DeMittwaldV1MarketplaceExtension]
    """

    return (
        await asyncio_detailed(
            client=client,
            context=context,
            search_term=search_term,
            include_deprecated=include_deprecated,
            limit=limit,
            skip=skip,
            page=page,
            sort=sort,
            order=order,
        )
    ).parsed
