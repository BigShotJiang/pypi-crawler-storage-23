from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.extension_consent_to_extension_scopes_body import ExtensionConsentToExtensionScopesBody
from ...models.extension_consent_to_extension_scopes_response_429 import ExtensionConsentToExtensionScopesResponse429
from ...types import Response


def _get_kwargs(
    extension_instance_id: UUID,
    *,
    body: ExtensionConsentToExtensionScopesBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v2/extension-instances/{extension_instance_id}/scopes".format(
            extension_instance_id=quote(str(extension_instance_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionConsentToExtensionScopesResponse429
):
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 429:
        response_429 = ExtensionConsentToExtensionScopesResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionConsentToExtensionScopesResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    extension_instance_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionConsentToExtensionScopesBody,
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionConsentToExtensionScopesResponse429
]:
    """Consent to extension scopes.

    Args:
        extension_instance_id (UUID):
        body (ExtensionConsentToExtensionScopesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionConsentToExtensionScopesResponse429]
    """

    kwargs = _get_kwargs(
        extension_instance_id=extension_instance_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    extension_instance_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionConsentToExtensionScopesBody,
) -> (
    Any
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionConsentToExtensionScopesResponse429
    | None
):
    """Consent to extension scopes.

    Args:
        extension_instance_id (UUID):
        body (ExtensionConsentToExtensionScopesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionConsentToExtensionScopesResponse429
    """

    return sync_detailed(
        extension_instance_id=extension_instance_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    extension_instance_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionConsentToExtensionScopesBody,
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionConsentToExtensionScopesResponse429
]:
    """Consent to extension scopes.

    Args:
        extension_instance_id (UUID):
        body (ExtensionConsentToExtensionScopesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionConsentToExtensionScopesResponse429]
    """

    kwargs = _get_kwargs(
        extension_instance_id=extension_instance_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    extension_instance_id: UUID,
    *,
    client: AuthenticatedClient,
    body: ExtensionConsentToExtensionScopesBody,
) -> (
    Any
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionConsentToExtensionScopesResponse429
    | None
):
    """Consent to extension scopes.

    Args:
        extension_instance_id (UUID):
        body (ExtensionConsentToExtensionScopesBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionConsentToExtensionScopesResponse429
    """

    return (
        await asyncio_detailed(
            extension_instance_id=extension_instance_id,
            client=client,
            body=body,
        )
    ).parsed
