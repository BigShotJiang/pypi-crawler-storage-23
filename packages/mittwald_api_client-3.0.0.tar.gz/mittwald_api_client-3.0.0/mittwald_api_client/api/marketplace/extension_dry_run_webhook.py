import datetime
from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_marketplace_webhook_kind import DeMittwaldV1MarketplaceWebhookKind
from ...models.extension_dry_run_webhook_response_200 import ExtensionDryRunWebhookResponse200
from ...models.extension_dry_run_webhook_response_429 import ExtensionDryRunWebhookResponse429
from ...types import UNSET, Response, Unset


def _get_kwargs(
    contributor_id: str,
    extension_id: UUID,
    extension_instance_id: UUID,
    webhook_kind: DeMittwaldV1MarketplaceWebhookKind,
    *,
    context_id: str | Unset = UNSET,
    scopes: list[str] | Unset = UNSET,
    instance_disabled: bool | Unset = UNSET,
    created_at: datetime.datetime | Unset = UNSET,
    secret: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["contextId"] = context_id

    json_scopes: list[str] | Unset = UNSET
    if not isinstance(scopes, Unset):
        json_scopes = scopes

    params["scopes"] = json_scopes

    params["instanceDisabled"] = instance_disabled

    json_created_at: str | Unset = UNSET
    if not isinstance(created_at, Unset):
        json_created_at = created_at.isoformat()
    params["createdAt"] = json_created_at

    params["secret"] = secret

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/contributors/{contributor_id}/extensions/{extension_id}/extension-instances/{extension_instance_id}/actions/dry-run/{webhook_kind}".format(
            contributor_id=quote(str(contributor_id), safe=""),
            extension_id=quote(str(extension_id), safe=""),
            extension_instance_id=quote(str(extension_instance_id), safe=""),
            webhook_kind=quote(str(webhook_kind), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionDryRunWebhookResponse200
    | ExtensionDryRunWebhookResponse429
):
    if response.status_code == 200:
        response_200 = ExtensionDryRunWebhookResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 429:
        response_429 = ExtensionDryRunWebhookResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionDryRunWebhookResponse200
    | ExtensionDryRunWebhookResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    contributor_id: str,
    extension_id: UUID,
    extension_instance_id: UUID,
    webhook_kind: DeMittwaldV1MarketplaceWebhookKind,
    *,
    client: AuthenticatedClient,
    context_id: str | Unset = UNSET,
    scopes: list[str] | Unset = UNSET,
    instance_disabled: bool | Unset = UNSET,
    created_at: datetime.datetime | Unset = UNSET,
    secret: str | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionDryRunWebhookResponse200
    | ExtensionDryRunWebhookResponse429
]:
    """Dry run a webhook with random or given values.

    Args:
        contributor_id (str):
        extension_id (UUID):
        extension_instance_id (UUID):
        webhook_kind (DeMittwaldV1MarketplaceWebhookKind):
        context_id (str | Unset):
        scopes (list[str] | Unset):
        instance_disabled (bool | Unset):
        created_at (datetime.datetime | Unset):
        secret (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionDryRunWebhookResponse200 | ExtensionDryRunWebhookResponse429]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        extension_id=extension_id,
        extension_instance_id=extension_instance_id,
        webhook_kind=webhook_kind,
        context_id=context_id,
        scopes=scopes,
        instance_disabled=instance_disabled,
        created_at=created_at,
        secret=secret,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    contributor_id: str,
    extension_id: UUID,
    extension_instance_id: UUID,
    webhook_kind: DeMittwaldV1MarketplaceWebhookKind,
    *,
    client: AuthenticatedClient,
    context_id: str | Unset = UNSET,
    scopes: list[str] | Unset = UNSET,
    instance_disabled: bool | Unset = UNSET,
    created_at: datetime.datetime | Unset = UNSET,
    secret: str | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionDryRunWebhookResponse200
    | ExtensionDryRunWebhookResponse429
    | None
):
    """Dry run a webhook with random or given values.

    Args:
        contributor_id (str):
        extension_id (UUID):
        extension_instance_id (UUID):
        webhook_kind (DeMittwaldV1MarketplaceWebhookKind):
        context_id (str | Unset):
        scopes (list[str] | Unset):
        instance_disabled (bool | Unset):
        created_at (datetime.datetime | Unset):
        secret (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionDryRunWebhookResponse200 | ExtensionDryRunWebhookResponse429
    """

    return sync_detailed(
        contributor_id=contributor_id,
        extension_id=extension_id,
        extension_instance_id=extension_instance_id,
        webhook_kind=webhook_kind,
        client=client,
        context_id=context_id,
        scopes=scopes,
        instance_disabled=instance_disabled,
        created_at=created_at,
        secret=secret,
    ).parsed


async def asyncio_detailed(
    contributor_id: str,
    extension_id: UUID,
    extension_instance_id: UUID,
    webhook_kind: DeMittwaldV1MarketplaceWebhookKind,
    *,
    client: AuthenticatedClient,
    context_id: str | Unset = UNSET,
    scopes: list[str] | Unset = UNSET,
    instance_disabled: bool | Unset = UNSET,
    created_at: datetime.datetime | Unset = UNSET,
    secret: str | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionDryRunWebhookResponse200
    | ExtensionDryRunWebhookResponse429
]:
    """Dry run a webhook with random or given values.

    Args:
        contributor_id (str):
        extension_id (UUID):
        extension_instance_id (UUID):
        webhook_kind (DeMittwaldV1MarketplaceWebhookKind):
        context_id (str | Unset):
        scopes (list[str] | Unset):
        instance_disabled (bool | Unset):
        created_at (datetime.datetime | Unset):
        secret (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionDryRunWebhookResponse200 | ExtensionDryRunWebhookResponse429]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        extension_id=extension_id,
        extension_instance_id=extension_instance_id,
        webhook_kind=webhook_kind,
        context_id=context_id,
        scopes=scopes,
        instance_disabled=instance_disabled,
        created_at=created_at,
        secret=secret,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    contributor_id: str,
    extension_id: UUID,
    extension_instance_id: UUID,
    webhook_kind: DeMittwaldV1MarketplaceWebhookKind,
    *,
    client: AuthenticatedClient,
    context_id: str | Unset = UNSET,
    scopes: list[str] | Unset = UNSET,
    instance_disabled: bool | Unset = UNSET,
    created_at: datetime.datetime | Unset = UNSET,
    secret: str | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionDryRunWebhookResponse200
    | ExtensionDryRunWebhookResponse429
    | None
):
    """Dry run a webhook with random or given values.

    Args:
        contributor_id (str):
        extension_id (UUID):
        extension_instance_id (UUID):
        webhook_kind (DeMittwaldV1MarketplaceWebhookKind):
        context_id (str | Unset):
        scopes (list[str] | Unset):
        instance_disabled (bool | Unset):
        created_at (datetime.datetime | Unset):
        secret (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionDryRunWebhookResponse200 | ExtensionDryRunWebhookResponse429
    """

    return (
        await asyncio_detailed(
            contributor_id=contributor_id,
            extension_id=extension_id,
            extension_instance_id=extension_instance_id,
            webhook_kind=webhook_kind,
            client=client,
            context_id=context_id,
            scopes=scopes,
            instance_disabled=instance_disabled,
            created_at=created_at,
            secret=secret,
        )
    ).parsed
