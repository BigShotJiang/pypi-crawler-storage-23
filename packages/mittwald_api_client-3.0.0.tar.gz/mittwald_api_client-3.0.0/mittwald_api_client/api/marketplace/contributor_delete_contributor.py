from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.contributor_delete_contributor_response_429 import ContributorDeleteContributorResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import Response


def _get_kwargs(
    contributor_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v2/contributors/{contributor_id}".format(
            contributor_id=quote(str(contributor_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | ContributorDeleteContributorResponse429 | DeMittwaldV1CommonsError:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 412:
        response_412 = cast(Any, None)
        return response_412

    if response.status_code == 429:
        response_429 = ContributorDeleteContributorResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | ContributorDeleteContributorResponse429 | DeMittwaldV1CommonsError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | ContributorDeleteContributorResponse429 | DeMittwaldV1CommonsError]:
    """Delete a Contributor.

    Args:
        contributor_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ContributorDeleteContributorResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
) -> Any | ContributorDeleteContributorResponse429 | DeMittwaldV1CommonsError | None:
    """Delete a Contributor.

    Args:
        contributor_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ContributorDeleteContributorResponse429 | DeMittwaldV1CommonsError
    """

    return sync_detailed(
        contributor_id=contributor_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | ContributorDeleteContributorResponse429 | DeMittwaldV1CommonsError]:
    """Delete a Contributor.

    Args:
        contributor_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ContributorDeleteContributorResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    contributor_id: str,
    *,
    client: AuthenticatedClient,
) -> Any | ContributorDeleteContributorResponse429 | DeMittwaldV1CommonsError | None:
    """Delete a Contributor.

    Args:
        contributor_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ContributorDeleteContributorResponse429 | DeMittwaldV1CommonsError
    """

    return (
        await asyncio_detailed(
            contributor_id=contributor_id,
            client=client,
        )
    ).parsed
