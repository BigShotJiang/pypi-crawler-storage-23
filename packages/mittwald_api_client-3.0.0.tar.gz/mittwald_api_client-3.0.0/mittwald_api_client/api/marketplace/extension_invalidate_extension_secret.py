from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.extension_invalidate_extension_secret_response_429 import ExtensionInvalidateExtensionSecretResponse429
from ...types import Response


def _get_kwargs(
    contributor_id: str,
    extension_id: UUID,
    extension_secret_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v2/contributors/{contributor_id}/extensions/{extension_id}/secret/{extension_secret_id}".format(
            contributor_id=quote(str(contributor_id), safe=""),
            extension_id=quote(str(extension_id), safe=""),
            extension_secret_id=quote(str(extension_secret_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionInvalidateExtensionSecretResponse429
):
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 412:
        response_412 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_412

    if response.status_code == 429:
        response_429 = ExtensionInvalidateExtensionSecretResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionInvalidateExtensionSecretResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    contributor_id: str,
    extension_id: UUID,
    extension_secret_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionInvalidateExtensionSecretResponse429
]:
    """Invalidate the given Extension secret immediately.

    Args:
        contributor_id (str):
        extension_id (UUID):
        extension_secret_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionInvalidateExtensionSecretResponse429]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        extension_id=extension_id,
        extension_secret_id=extension_secret_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    contributor_id: str,
    extension_id: UUID,
    extension_secret_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    Any
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionInvalidateExtensionSecretResponse429
    | None
):
    """Invalidate the given Extension secret immediately.

    Args:
        contributor_id (str):
        extension_id (UUID):
        extension_secret_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionInvalidateExtensionSecretResponse429
    """

    return sync_detailed(
        contributor_id=contributor_id,
        extension_id=extension_id,
        extension_secret_id=extension_secret_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    contributor_id: str,
    extension_id: UUID,
    extension_secret_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionInvalidateExtensionSecretResponse429
]:
    """Invalidate the given Extension secret immediately.

    Args:
        contributor_id (str):
        extension_id (UUID):
        extension_secret_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionInvalidateExtensionSecretResponse429]
    """

    kwargs = _get_kwargs(
        contributor_id=contributor_id,
        extension_id=extension_id,
        extension_secret_id=extension_secret_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    contributor_id: str,
    extension_id: UUID,
    extension_secret_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    Any
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ExtensionInvalidateExtensionSecretResponse429
    | None
):
    """Invalidate the given Extension secret immediately.

    Args:
        contributor_id (str):
        extension_id (UUID):
        extension_secret_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ExtensionInvalidateExtensionSecretResponse429
    """

    return (
        await asyncio_detailed(
            contributor_id=contributor_id,
            extension_id=extension_id,
            extension_secret_id=extension_secret_id,
            client=client,
        )
    ).parsed
