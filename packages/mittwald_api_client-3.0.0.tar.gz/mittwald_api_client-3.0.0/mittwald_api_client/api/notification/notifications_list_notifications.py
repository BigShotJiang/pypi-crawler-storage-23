from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_messaging_notification import DeMittwaldV1MessagingNotification
from ...models.notifications_list_notifications_response_429 import NotificationsListNotificationsResponse429
from ...models.notifications_list_notifications_severity_item import NotificationsListNotificationsSeverityItem
from ...models.notifications_list_notifications_status import NotificationsListNotificationsStatus
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    status: NotificationsListNotificationsStatus | Unset = UNSET,
    severity: list[NotificationsListNotificationsSeverityItem] | Unset = UNSET,
    type_: list[str] | Unset = UNSET,
    type_not: list[str] | Unset = UNSET,
    limit: int | Unset = 500,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_status: str | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = status.value

    params["status"] = json_status

    json_severity: list[str] | Unset = UNSET
    if not isinstance(severity, Unset):
        json_severity = []
        for severity_item_data in severity:
            severity_item = severity_item_data.value
            json_severity.append(severity_item)

    params["severity"] = json_severity

    json_type_: list[str] | Unset = UNSET
    if not isinstance(type_, Unset):
        json_type_ = type_

    params["type"] = json_type_

    json_type_not: list[str] | Unset = UNSET
    if not isinstance(type_not, Unset):
        json_type_not = type_not

    params["type-not"] = json_type_not

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/notifications",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | NotificationsListNotificationsResponse429 | list[DeMittwaldV1MessagingNotification]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1MessagingNotification.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = NotificationsListNotificationsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError | NotificationsListNotificationsResponse429 | list[DeMittwaldV1MessagingNotification]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    status: NotificationsListNotificationsStatus | Unset = UNSET,
    severity: list[NotificationsListNotificationsSeverityItem] | Unset = UNSET,
    type_: list[str] | Unset = UNSET,
    type_not: list[str] | Unset = UNSET,
    limit: int | Unset = 500,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError | NotificationsListNotificationsResponse429 | list[DeMittwaldV1MessagingNotification]
]:
    """List all unread notifications.

    Args:
        status (NotificationsListNotificationsStatus | Unset):
        severity (list[NotificationsListNotificationsSeverityItem] | Unset):
        type_ (list[str] | Unset):
        type_not (list[str] | Unset):
        limit (int | Unset):  Default: 500.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | NotificationsListNotificationsResponse429 | list[DeMittwaldV1MessagingNotification]]
    """

    kwargs = _get_kwargs(
        status=status,
        severity=severity,
        type_=type_,
        type_not=type_not,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    status: NotificationsListNotificationsStatus | Unset = UNSET,
    severity: list[NotificationsListNotificationsSeverityItem] | Unset = UNSET,
    type_: list[str] | Unset = UNSET,
    type_not: list[str] | Unset = UNSET,
    limit: int | Unset = 500,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | NotificationsListNotificationsResponse429
    | list[DeMittwaldV1MessagingNotification]
    | None
):
    """List all unread notifications.

    Args:
        status (NotificationsListNotificationsStatus | Unset):
        severity (list[NotificationsListNotificationsSeverityItem] | Unset):
        type_ (list[str] | Unset):
        type_not (list[str] | Unset):
        limit (int | Unset):  Default: 500.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | NotificationsListNotificationsResponse429 | list[DeMittwaldV1MessagingNotification]
    """

    return sync_detailed(
        client=client,
        status=status,
        severity=severity,
        type_=type_,
        type_not=type_not,
        limit=limit,
        skip=skip,
        page=page,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    status: NotificationsListNotificationsStatus | Unset = UNSET,
    severity: list[NotificationsListNotificationsSeverityItem] | Unset = UNSET,
    type_: list[str] | Unset = UNSET,
    type_not: list[str] | Unset = UNSET,
    limit: int | Unset = 500,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError | NotificationsListNotificationsResponse429 | list[DeMittwaldV1MessagingNotification]
]:
    """List all unread notifications.

    Args:
        status (NotificationsListNotificationsStatus | Unset):
        severity (list[NotificationsListNotificationsSeverityItem] | Unset):
        type_ (list[str] | Unset):
        type_not (list[str] | Unset):
        limit (int | Unset):  Default: 500.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | NotificationsListNotificationsResponse429 | list[DeMittwaldV1MessagingNotification]]
    """

    kwargs = _get_kwargs(
        status=status,
        severity=severity,
        type_=type_,
        type_not=type_not,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    status: NotificationsListNotificationsStatus | Unset = UNSET,
    severity: list[NotificationsListNotificationsSeverityItem] | Unset = UNSET,
    type_: list[str] | Unset = UNSET,
    type_not: list[str] | Unset = UNSET,
    limit: int | Unset = 500,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | NotificationsListNotificationsResponse429
    | list[DeMittwaldV1MessagingNotification]
    | None
):
    """List all unread notifications.

    Args:
        status (NotificationsListNotificationsStatus | Unset):
        severity (list[NotificationsListNotificationsSeverityItem] | Unset):
        type_ (list[str] | Unset):
        type_not (list[str] | Unset):
        limit (int | Unset):  Default: 500.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | NotificationsListNotificationsResponse429 | list[DeMittwaldV1MessagingNotification]
    """

    return (
        await asyncio_detailed(
            client=client,
            status=status,
            severity=severity,
            type_=type_,
            type_not=type_not,
            limit=limit,
            skip=skip,
            page=page,
        )
    ).parsed
