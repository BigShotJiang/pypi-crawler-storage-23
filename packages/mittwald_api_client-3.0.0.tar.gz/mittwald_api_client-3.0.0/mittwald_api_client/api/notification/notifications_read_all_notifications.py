from http import HTTPStatus
from typing import Any
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.notifications_read_all_notifications_body import NotificationsReadAllNotificationsBody
from ...models.notifications_read_all_notifications_response_200 import NotificationsReadAllNotificationsResponse200
from ...models.notifications_read_all_notifications_response_429 import NotificationsReadAllNotificationsResponse429
from ...models.notifications_read_all_notifications_severities_item import (
    NotificationsReadAllNotificationsSeveritiesItem,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: NotificationsReadAllNotificationsBody | Unset = UNSET,
    severities: list[NotificationsReadAllNotificationsSeveritiesItem] | Unset = UNSET,
    reference_id: UUID | Unset = UNSET,
    reference_aggregate: str | Unset = UNSET,
    reference_domain: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_severities: list[str] | Unset = UNSET
    if not isinstance(severities, Unset):
        json_severities = []
        for severities_item_data in severities:
            severities_item = severities_item_data.value
            json_severities.append(severities_item)

    params["severities"] = json_severities

    json_reference_id: str | Unset = UNSET
    if not isinstance(reference_id, Unset):
        json_reference_id = str(reference_id)
    params["referenceId"] = json_reference_id

    params["referenceAggregate"] = reference_aggregate

    params["referenceDomain"] = reference_domain

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/notifications/actions/read-all",
        "params": params,
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | NotificationsReadAllNotificationsResponse200
    | NotificationsReadAllNotificationsResponse429
):
    if response.status_code == 200:
        response_200 = NotificationsReadAllNotificationsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 429:
        response_429 = NotificationsReadAllNotificationsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | NotificationsReadAllNotificationsResponse200
    | NotificationsReadAllNotificationsResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: NotificationsReadAllNotificationsBody | Unset = UNSET,
    severities: list[NotificationsReadAllNotificationsSeveritiesItem] | Unset = UNSET,
    reference_id: UUID | Unset = UNSET,
    reference_aggregate: str | Unset = UNSET,
    reference_domain: str | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | NotificationsReadAllNotificationsResponse200
    | NotificationsReadAllNotificationsResponse429
]:
    """Mark all notifications as read.

     Mark all notifications for the authenticated user as read.

    Args:
        severities (list[NotificationsReadAllNotificationsSeveritiesItem] | Unset):
        reference_id (UUID | Unset):
        reference_aggregate (str | Unset):
        reference_domain (str | Unset):
        body (NotificationsReadAllNotificationsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | NotificationsReadAllNotificationsResponse200 | NotificationsReadAllNotificationsResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
        severities=severities,
        reference_id=reference_id,
        reference_aggregate=reference_aggregate,
        reference_domain=reference_domain,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: NotificationsReadAllNotificationsBody | Unset = UNSET,
    severities: list[NotificationsReadAllNotificationsSeveritiesItem] | Unset = UNSET,
    reference_id: UUID | Unset = UNSET,
    reference_aggregate: str | Unset = UNSET,
    reference_domain: str | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | NotificationsReadAllNotificationsResponse200
    | NotificationsReadAllNotificationsResponse429
    | None
):
    """Mark all notifications as read.

     Mark all notifications for the authenticated user as read.

    Args:
        severities (list[NotificationsReadAllNotificationsSeveritiesItem] | Unset):
        reference_id (UUID | Unset):
        reference_aggregate (str | Unset):
        reference_domain (str | Unset):
        body (NotificationsReadAllNotificationsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | NotificationsReadAllNotificationsResponse200 | NotificationsReadAllNotificationsResponse429
    """

    return sync_detailed(
        client=client,
        body=body,
        severities=severities,
        reference_id=reference_id,
        reference_aggregate=reference_aggregate,
        reference_domain=reference_domain,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: NotificationsReadAllNotificationsBody | Unset = UNSET,
    severities: list[NotificationsReadAllNotificationsSeveritiesItem] | Unset = UNSET,
    reference_id: UUID | Unset = UNSET,
    reference_aggregate: str | Unset = UNSET,
    reference_domain: str | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | NotificationsReadAllNotificationsResponse200
    | NotificationsReadAllNotificationsResponse429
]:
    """Mark all notifications as read.

     Mark all notifications for the authenticated user as read.

    Args:
        severities (list[NotificationsReadAllNotificationsSeveritiesItem] | Unset):
        reference_id (UUID | Unset):
        reference_aggregate (str | Unset):
        reference_domain (str | Unset):
        body (NotificationsReadAllNotificationsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | NotificationsReadAllNotificationsResponse200 | NotificationsReadAllNotificationsResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
        severities=severities,
        reference_id=reference_id,
        reference_aggregate=reference_aggregate,
        reference_domain=reference_domain,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: NotificationsReadAllNotificationsBody | Unset = UNSET,
    severities: list[NotificationsReadAllNotificationsSeveritiesItem] | Unset = UNSET,
    reference_id: UUID | Unset = UNSET,
    reference_aggregate: str | Unset = UNSET,
    reference_domain: str | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | NotificationsReadAllNotificationsResponse200
    | NotificationsReadAllNotificationsResponse429
    | None
):
    """Mark all notifications as read.

     Mark all notifications for the authenticated user as read.

    Args:
        severities (list[NotificationsReadAllNotificationsSeveritiesItem] | Unset):
        reference_id (UUID | Unset):
        reference_aggregate (str | Unset):
        reference_domain (str | Unset):
        body (NotificationsReadAllNotificationsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | NotificationsReadAllNotificationsResponse200 | NotificationsReadAllNotificationsResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            severities=severities,
            reference_id=reference_id,
            reference_aggregate=reference_aggregate,
            reference_domain=reference_domain,
        )
    ).parsed
