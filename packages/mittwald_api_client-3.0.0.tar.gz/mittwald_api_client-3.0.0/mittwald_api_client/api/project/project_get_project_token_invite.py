from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_membership_project_invite import DeMittwaldV1MembershipProjectInvite
from ...models.project_get_project_token_invite_response_429 import ProjectGetProjectTokenInviteResponse429
from ...types import Response


def _get_kwargs(
    *,
    token: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["token"] = token

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/project-token-invite",
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | DeMittwaldV1MembershipProjectInvite | ProjectGetProjectTokenInviteResponse429:
    if response.status_code == 200:
        response_200 = DeMittwaldV1MembershipProjectInvite.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ProjectGetProjectTokenInviteResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1MembershipProjectInvite | ProjectGetProjectTokenInviteResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    token: str,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1MembershipProjectInvite | ProjectGetProjectTokenInviteResponse429]:
    """Get a ProjectInvite by token.

    Args:
        token (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1MembershipProjectInvite | ProjectGetProjectTokenInviteResponse429]
    """

    kwargs = _get_kwargs(
        token=token,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    token: str,
) -> DeMittwaldV1CommonsError | DeMittwaldV1MembershipProjectInvite | ProjectGetProjectTokenInviteResponse429 | None:
    """Get a ProjectInvite by token.

    Args:
        token (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1MembershipProjectInvite | ProjectGetProjectTokenInviteResponse429
    """

    return sync_detailed(
        client=client,
        token=token,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    token: str,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1MembershipProjectInvite | ProjectGetProjectTokenInviteResponse429]:
    """Get a ProjectInvite by token.

    Args:
        token (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1MembershipProjectInvite | ProjectGetProjectTokenInviteResponse429]
    """

    kwargs = _get_kwargs(
        token=token,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    token: str,
) -> DeMittwaldV1CommonsError | DeMittwaldV1MembershipProjectInvite | ProjectGetProjectTokenInviteResponse429 | None:
    """Get a ProjectInvite by token.

    Args:
        token (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1MembershipProjectInvite | ProjectGetProjectTokenInviteResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            token=token,
        )
    ).parsed
