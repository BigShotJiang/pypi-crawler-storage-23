from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_project_server import DeMittwaldV1ProjectServer
from ...models.project_list_servers_order import ProjectListServersOrder
from ...models.project_list_servers_response_429 import ProjectListServersResponse429
from ...models.project_list_servers_sort import ProjectListServersSort
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    customer_id: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ProjectListServersSort | Unset = ProjectListServersSort.CREATEDAT,
    order: ProjectListServersOrder | Unset = ProjectListServersOrder.ASC,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["customerId"] = customer_id

    params["searchTerm"] = search_term

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    json_sort: str | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = sort.value

    params["sort"] = json_sort

    json_order: str | Unset = UNSET
    if not isinstance(order, Unset):
        json_order = order.value

    params["order"] = json_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/servers",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | ProjectListServersResponse429 | list[DeMittwaldV1ProjectServer]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1ProjectServer.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 429:
        response_429 = ProjectListServersResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | ProjectListServersResponse429 | list[DeMittwaldV1ProjectServer]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    customer_id: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ProjectListServersSort | Unset = ProjectListServersSort.CREATEDAT,
    order: ProjectListServersOrder | Unset = ProjectListServersOrder.ASC,
) -> Response[DeMittwaldV1CommonsError | ProjectListServersResponse429 | list[DeMittwaldV1ProjectServer]]:
    """List Servers belonging to the executing user.

    Args:
        customer_id (str | Unset):
        search_term (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ProjectListServersSort | Unset):  Default: ProjectListServersSort.CREATEDAT.
        order (ProjectListServersOrder | Unset):  Default: ProjectListServersOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | ProjectListServersResponse429 | list[DeMittwaldV1ProjectServer]]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    customer_id: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ProjectListServersSort | Unset = ProjectListServersSort.CREATEDAT,
    order: ProjectListServersOrder | Unset = ProjectListServersOrder.ASC,
) -> DeMittwaldV1CommonsError | ProjectListServersResponse429 | list[DeMittwaldV1ProjectServer] | None:
    """List Servers belonging to the executing user.

    Args:
        customer_id (str | Unset):
        search_term (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ProjectListServersSort | Unset):  Default: ProjectListServersSort.CREATEDAT.
        order (ProjectListServersOrder | Unset):  Default: ProjectListServersOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | ProjectListServersResponse429 | list[DeMittwaldV1ProjectServer]
    """

    return sync_detailed(
        client=client,
        customer_id=customer_id,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    customer_id: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ProjectListServersSort | Unset = ProjectListServersSort.CREATEDAT,
    order: ProjectListServersOrder | Unset = ProjectListServersOrder.ASC,
) -> Response[DeMittwaldV1CommonsError | ProjectListServersResponse429 | list[DeMittwaldV1ProjectServer]]:
    """List Servers belonging to the executing user.

    Args:
        customer_id (str | Unset):
        search_term (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ProjectListServersSort | Unset):  Default: ProjectListServersSort.CREATEDAT.
        order (ProjectListServersOrder | Unset):  Default: ProjectListServersOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | ProjectListServersResponse429 | list[DeMittwaldV1ProjectServer]]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    customer_id: str | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ProjectListServersSort | Unset = ProjectListServersSort.CREATEDAT,
    order: ProjectListServersOrder | Unset = ProjectListServersOrder.ASC,
) -> DeMittwaldV1CommonsError | ProjectListServersResponse429 | list[DeMittwaldV1ProjectServer] | None:
    """List Servers belonging to the executing user.

    Args:
        customer_id (str | Unset):
        search_term (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ProjectListServersSort | Unset):  Default: ProjectListServersSort.CREATEDAT.
        order (ProjectListServersOrder | Unset):  Default: ProjectListServersOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | ProjectListServersResponse429 | list[DeMittwaldV1ProjectServer]
    """

    return (
        await asyncio_detailed(
            client=client,
            customer_id=customer_id,
            search_term=search_term,
            limit=limit,
            skip=skip,
            page=page,
            sort=sort,
            order=order,
        )
    ).parsed
