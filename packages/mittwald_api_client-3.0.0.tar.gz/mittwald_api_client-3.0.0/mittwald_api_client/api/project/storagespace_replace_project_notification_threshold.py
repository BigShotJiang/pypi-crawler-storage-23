from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.storagespace_replace_project_notification_threshold_body import (
    StoragespaceReplaceProjectNotificationThresholdBody,
)
from ...models.storagespace_replace_project_notification_threshold_response_429 import (
    StoragespaceReplaceProjectNotificationThresholdResponse429,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    project_id: str,
    *,
    body: StoragespaceReplaceProjectNotificationThresholdBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v2/projects/{project_id}/storage-space-notification-threshold".format(
            project_id=quote(str(project_id), safe=""),
        ),
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | DeMittwaldV1CommonsError | StoragespaceReplaceProjectNotificationThresholdResponse429:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 429:
        response_429 = StoragespaceReplaceProjectNotificationThresholdResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | DeMittwaldV1CommonsError | StoragespaceReplaceProjectNotificationThresholdResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: StoragespaceReplaceProjectNotificationThresholdBody | Unset = UNSET,
) -> Response[Any | DeMittwaldV1CommonsError | StoragespaceReplaceProjectNotificationThresholdResponse429]:
    """Update a Project's storage space notification threshold.

    Args:
        project_id (str):
        body (StoragespaceReplaceProjectNotificationThresholdBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | StoragespaceReplaceProjectNotificationThresholdResponse429]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: StoragespaceReplaceProjectNotificationThresholdBody | Unset = UNSET,
) -> Any | DeMittwaldV1CommonsError | StoragespaceReplaceProjectNotificationThresholdResponse429 | None:
    """Update a Project's storage space notification threshold.

    Args:
        project_id (str):
        body (StoragespaceReplaceProjectNotificationThresholdBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | StoragespaceReplaceProjectNotificationThresholdResponse429
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: StoragespaceReplaceProjectNotificationThresholdBody | Unset = UNSET,
) -> Response[Any | DeMittwaldV1CommonsError | StoragespaceReplaceProjectNotificationThresholdResponse429]:
    """Update a Project's storage space notification threshold.

    Args:
        project_id (str):
        body (StoragespaceReplaceProjectNotificationThresholdBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | StoragespaceReplaceProjectNotificationThresholdResponse429]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: StoragespaceReplaceProjectNotificationThresholdBody | Unset = UNSET,
) -> Any | DeMittwaldV1CommonsError | StoragespaceReplaceProjectNotificationThresholdResponse429 | None:
    """Update a Project's storage space notification threshold.

    Args:
        project_id (str):
        body (StoragespaceReplaceProjectNotificationThresholdBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | StoragespaceReplaceProjectNotificationThresholdResponse429
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            body=body,
        )
    ).parsed
