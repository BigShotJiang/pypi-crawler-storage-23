from http import HTTPStatus
from typing import Any
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.project_list_projects_order import ProjectListProjectsOrder
from ...models.project_list_projects_response_200_item import ProjectListProjectsResponse200Item
from ...models.project_list_projects_response_429 import ProjectListProjectsResponse429
from ...models.project_list_projects_sort import ProjectListProjectsSort
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    customer_id: str | Unset = UNSET,
    server_id: UUID | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ProjectListProjectsSort | Unset = ProjectListProjectsSort.CREATEDAT,
    order: ProjectListProjectsOrder | Unset = ProjectListProjectsOrder.ASC,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["customerId"] = customer_id

    json_server_id: str | Unset = UNSET
    if not isinstance(server_id, Unset):
        json_server_id = str(server_id)
    params["serverId"] = json_server_id

    params["searchTerm"] = search_term

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    json_sort: str | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = sort.value

    params["sort"] = json_sort

    json_order: str | Unset = UNSET
    if not isinstance(order, Unset):
        json_order = order.value

    params["order"] = json_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ProjectListProjectsResponse429
    | list[ProjectListProjectsResponse200Item]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ProjectListProjectsResponse200Item.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 429:
        response_429 = ProjectListProjectsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ProjectListProjectsResponse429
    | list[ProjectListProjectsResponse200Item]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    customer_id: str | Unset = UNSET,
    server_id: UUID | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ProjectListProjectsSort | Unset = ProjectListProjectsSort.CREATEDAT,
    order: ProjectListProjectsOrder | Unset = ProjectListProjectsOrder.ASC,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ProjectListProjectsResponse429
    | list[ProjectListProjectsResponse200Item]
]:
    """List Projects belonging to the executing user.

    Args:
        customer_id (str | Unset):  Example: 15b8a787-8d46-43b0-907e-01af35032c0a.
        server_id (UUID | Unset):
        search_term (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ProjectListProjectsSort | Unset):  Default: ProjectListProjectsSort.CREATEDAT.
        order (ProjectListProjectsOrder | Unset):  Default: ProjectListProjectsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectListProjectsResponse429 | list[ProjectListProjectsResponse200Item]]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        server_id=server_id,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    customer_id: str | Unset = UNSET,
    server_id: UUID | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ProjectListProjectsSort | Unset = ProjectListProjectsSort.CREATEDAT,
    order: ProjectListProjectsOrder | Unset = ProjectListProjectsOrder.ASC,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ProjectListProjectsResponse429
    | list[ProjectListProjectsResponse200Item]
    | None
):
    """List Projects belonging to the executing user.

    Args:
        customer_id (str | Unset):  Example: 15b8a787-8d46-43b0-907e-01af35032c0a.
        server_id (UUID | Unset):
        search_term (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ProjectListProjectsSort | Unset):  Default: ProjectListProjectsSort.CREATEDAT.
        order (ProjectListProjectsOrder | Unset):  Default: ProjectListProjectsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectListProjectsResponse429 | list[ProjectListProjectsResponse200Item]
    """

    return sync_detailed(
        client=client,
        customer_id=customer_id,
        server_id=server_id,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    customer_id: str | Unset = UNSET,
    server_id: UUID | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ProjectListProjectsSort | Unset = ProjectListProjectsSort.CREATEDAT,
    order: ProjectListProjectsOrder | Unset = ProjectListProjectsOrder.ASC,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ProjectListProjectsResponse429
    | list[ProjectListProjectsResponse200Item]
]:
    """List Projects belonging to the executing user.

    Args:
        customer_id (str | Unset):  Example: 15b8a787-8d46-43b0-907e-01af35032c0a.
        server_id (UUID | Unset):
        search_term (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ProjectListProjectsSort | Unset):  Default: ProjectListProjectsSort.CREATEDAT.
        order (ProjectListProjectsOrder | Unset):  Default: ProjectListProjectsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectListProjectsResponse429 | list[ProjectListProjectsResponse200Item]]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        server_id=server_id,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    customer_id: str | Unset = UNSET,
    server_id: UUID | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: ProjectListProjectsSort | Unset = ProjectListProjectsSort.CREATEDAT,
    order: ProjectListProjectsOrder | Unset = ProjectListProjectsOrder.ASC,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ProjectListProjectsResponse429
    | list[ProjectListProjectsResponse200Item]
    | None
):
    """List Projects belonging to the executing user.

    Args:
        customer_id (str | Unset):  Example: 15b8a787-8d46-43b0-907e-01af35032c0a.
        server_id (UUID | Unset):
        search_term (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (ProjectListProjectsSort | Unset):  Default: ProjectListProjectsSort.CREATEDAT.
        order (ProjectListProjectsOrder | Unset):  Default: ProjectListProjectsOrder.ASC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectListProjectsResponse429 | list[ProjectListProjectsResponse200Item]
    """

    return (
        await asyncio_detailed(
            client=client,
            customer_id=customer_id,
            server_id=server_id,
            search_term=search_term,
            limit=limit,
            skip=skip,
            page=page,
            sort=sort,
            order=order,
        )
    ).parsed
