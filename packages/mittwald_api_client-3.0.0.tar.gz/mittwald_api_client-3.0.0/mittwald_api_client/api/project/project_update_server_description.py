from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.project_update_server_description_body import ProjectUpdateServerDescriptionBody
from ...models.project_update_server_description_response_429 import ProjectUpdateServerDescriptionResponse429
from ...types import Response


def _get_kwargs(
    server_id: str,
    *,
    body: ProjectUpdateServerDescriptionBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v2/servers/{server_id}/description".format(
            server_id=quote(str(server_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectUpdateServerDescriptionResponse429:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 429:
        response_429 = ProjectUpdateServerDescriptionResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectUpdateServerDescriptionResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    server_id: str,
    *,
    client: AuthenticatedClient,
    body: ProjectUpdateServerDescriptionBody,
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectUpdateServerDescriptionResponse429
]:
    """Update a Servers's description.

    Args:
        server_id (str):
        body (ProjectUpdateServerDescriptionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectUpdateServerDescriptionResponse429]
    """

    kwargs = _get_kwargs(
        server_id=server_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    server_id: str,
    *,
    client: AuthenticatedClient,
    body: ProjectUpdateServerDescriptionBody,
) -> (
    Any
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ProjectUpdateServerDescriptionResponse429
    | None
):
    """Update a Servers's description.

    Args:
        server_id (str):
        body (ProjectUpdateServerDescriptionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectUpdateServerDescriptionResponse429
    """

    return sync_detailed(
        server_id=server_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    server_id: str,
    *,
    client: AuthenticatedClient,
    body: ProjectUpdateServerDescriptionBody,
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectUpdateServerDescriptionResponse429
]:
    """Update a Servers's description.

    Args:
        server_id (str):
        body (ProjectUpdateServerDescriptionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectUpdateServerDescriptionResponse429]
    """

    kwargs = _get_kwargs(
        server_id=server_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    server_id: str,
    *,
    client: AuthenticatedClient,
    body: ProjectUpdateServerDescriptionBody,
) -> (
    Any
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | ProjectUpdateServerDescriptionResponse429
    | None
):
    """Update a Servers's description.

    Args:
        server_id (str):
        body (ProjectUpdateServerDescriptionBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | ProjectUpdateServerDescriptionResponse429
    """

    return (
        await asyncio_detailed(
            server_id=server_id,
            client=client,
            body=body,
        )
    ).parsed
