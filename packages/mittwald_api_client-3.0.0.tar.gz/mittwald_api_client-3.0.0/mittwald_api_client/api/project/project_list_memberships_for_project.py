from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_membership_project_membership import DeMittwaldV1MembershipProjectMembership
from ...models.de_mittwald_v1_membership_project_roles import DeMittwaldV1MembershipProjectRoles
from ...models.project_list_memberships_for_project_response_429 import ProjectListMembershipsForProjectResponse429
from ...types import UNSET, Response, Unset


def _get_kwargs(
    project_id: str,
    *,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    has_expiry: bool | Unset = UNSET,
    is_inherited: bool | Unset = UNSET,
    role: DeMittwaldV1MembershipProjectRoles | Unset = UNSET,
    has_mfa: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["skip"] = skip

    params["hasExpiry"] = has_expiry

    params["isInherited"] = is_inherited

    json_role: str | Unset = UNSET
    if not isinstance(role, Unset):
        json_role = role.value

    params["role"] = json_role

    params["hasMfa"] = has_mfa

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects/{project_id}/memberships".format(
            project_id=quote(str(project_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | ProjectListMembershipsForProjectResponse429
    | list[DeMittwaldV1MembershipProjectMembership]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1MembershipProjectMembership.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ProjectListMembershipsForProjectResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | ProjectListMembershipsForProjectResponse429
    | list[DeMittwaldV1MembershipProjectMembership]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    has_expiry: bool | Unset = UNSET,
    is_inherited: bool | Unset = UNSET,
    role: DeMittwaldV1MembershipProjectRoles | Unset = UNSET,
    has_mfa: bool | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | ProjectListMembershipsForProjectResponse429
    | list[DeMittwaldV1MembershipProjectMembership]
]:
    """List Memberships belonging to a Project.

    Args:
        project_id (str):
        limit (int | Unset):
        skip (int | Unset):
        has_expiry (bool | Unset):
        is_inherited (bool | Unset):
        role (DeMittwaldV1MembershipProjectRoles | Unset):
        has_mfa (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | ProjectListMembershipsForProjectResponse429 | list[DeMittwaldV1MembershipProjectMembership]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        limit=limit,
        skip=skip,
        has_expiry=has_expiry,
        is_inherited=is_inherited,
        role=role,
        has_mfa=has_mfa,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    has_expiry: bool | Unset = UNSET,
    is_inherited: bool | Unset = UNSET,
    role: DeMittwaldV1MembershipProjectRoles | Unset = UNSET,
    has_mfa: bool | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | ProjectListMembershipsForProjectResponse429
    | list[DeMittwaldV1MembershipProjectMembership]
    | None
):
    """List Memberships belonging to a Project.

    Args:
        project_id (str):
        limit (int | Unset):
        skip (int | Unset):
        has_expiry (bool | Unset):
        is_inherited (bool | Unset):
        role (DeMittwaldV1MembershipProjectRoles | Unset):
        has_mfa (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | ProjectListMembershipsForProjectResponse429 | list[DeMittwaldV1MembershipProjectMembership]
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        limit=limit,
        skip=skip,
        has_expiry=has_expiry,
        is_inherited=is_inherited,
        role=role,
        has_mfa=has_mfa,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    has_expiry: bool | Unset = UNSET,
    is_inherited: bool | Unset = UNSET,
    role: DeMittwaldV1MembershipProjectRoles | Unset = UNSET,
    has_mfa: bool | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | ProjectListMembershipsForProjectResponse429
    | list[DeMittwaldV1MembershipProjectMembership]
]:
    """List Memberships belonging to a Project.

    Args:
        project_id (str):
        limit (int | Unset):
        skip (int | Unset):
        has_expiry (bool | Unset):
        is_inherited (bool | Unset):
        role (DeMittwaldV1MembershipProjectRoles | Unset):
        has_mfa (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | ProjectListMembershipsForProjectResponse429 | list[DeMittwaldV1MembershipProjectMembership]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        limit=limit,
        skip=skip,
        has_expiry=has_expiry,
        is_inherited=is_inherited,
        role=role,
        has_mfa=has_mfa,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    has_expiry: bool | Unset = UNSET,
    is_inherited: bool | Unset = UNSET,
    role: DeMittwaldV1MembershipProjectRoles | Unset = UNSET,
    has_mfa: bool | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | ProjectListMembershipsForProjectResponse429
    | list[DeMittwaldV1MembershipProjectMembership]
    | None
):
    """List Memberships belonging to a Project.

    Args:
        project_id (str):
        limit (int | Unset):
        skip (int | Unset):
        has_expiry (bool | Unset):
        is_inherited (bool | Unset):
        role (DeMittwaldV1MembershipProjectRoles | Unset):
        has_mfa (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | ProjectListMembershipsForProjectResponse429 | list[DeMittwaldV1MembershipProjectMembership]
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            limit=limit,
            skip=skip,
            has_expiry=has_expiry,
            is_inherited=is_inherited,
            role=role,
            has_mfa=has_mfa,
        )
    ).parsed
