from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.project_delete_project_invite_response_429 import ProjectDeleteProjectInviteResponse429
from ...types import Response


def _get_kwargs(
    project_invite_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v2/project-invites/{project_invite_id}".format(
            project_invite_id=quote(str(project_invite_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | DeMittwaldV1CommonsError | ProjectDeleteProjectInviteResponse429:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 429:
        response_429 = ProjectDeleteProjectInviteResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | DeMittwaldV1CommonsError | ProjectDeleteProjectInviteResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_invite_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[Any | DeMittwaldV1CommonsError | ProjectDeleteProjectInviteResponse429]:
    """Delete a ProjectInvite.

    Args:
        project_invite_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | ProjectDeleteProjectInviteResponse429]
    """

    kwargs = _get_kwargs(
        project_invite_id=project_invite_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_invite_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Any | DeMittwaldV1CommonsError | ProjectDeleteProjectInviteResponse429 | None:
    """Delete a ProjectInvite.

    Args:
        project_invite_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | ProjectDeleteProjectInviteResponse429
    """

    return sync_detailed(
        project_invite_id=project_invite_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    project_invite_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[Any | DeMittwaldV1CommonsError | ProjectDeleteProjectInviteResponse429]:
    """Delete a ProjectInvite.

    Args:
        project_invite_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | ProjectDeleteProjectInviteResponse429]
    """

    kwargs = _get_kwargs(
        project_invite_id=project_invite_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_invite_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Any | DeMittwaldV1CommonsError | ProjectDeleteProjectInviteResponse429 | None:
    """Delete a ProjectInvite.

    Args:
        project_invite_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | ProjectDeleteProjectInviteResponse429
    """

    return (
        await asyncio_detailed(
            project_invite_id=project_invite_id,
            client=client,
        )
    ).parsed
