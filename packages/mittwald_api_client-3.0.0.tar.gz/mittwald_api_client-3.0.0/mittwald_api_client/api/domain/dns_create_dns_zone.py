from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.dns_create_dns_zone_body import DnsCreateDnsZoneBody
from ...models.dns_create_dns_zone_response_201 import DnsCreateDnsZoneResponse201
from ...models.dns_create_dns_zone_response_429 import DnsCreateDnsZoneResponse429
from ...types import Response


def _get_kwargs(
    *,
    body: DnsCreateDnsZoneBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/dns-zones",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsCreateDnsZoneResponse201
    | DnsCreateDnsZoneResponse429
):
    if response.status_code == 201:
        response_201 = DnsCreateDnsZoneResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 409:
        response_409 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_409

    if response.status_code == 429:
        response_429 = DnsCreateDnsZoneResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsCreateDnsZoneResponse201
    | DnsCreateDnsZoneResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: DnsCreateDnsZoneBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsCreateDnsZoneResponse201
    | DnsCreateDnsZoneResponse429
]:
    """Create a DNSZone.

    Args:
        body (DnsCreateDnsZoneBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsCreateDnsZoneResponse201 | DnsCreateDnsZoneResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: DnsCreateDnsZoneBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsCreateDnsZoneResponse201
    | DnsCreateDnsZoneResponse429
    | None
):
    """Create a DNSZone.

    Args:
        body (DnsCreateDnsZoneBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsCreateDnsZoneResponse201 | DnsCreateDnsZoneResponse429
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: DnsCreateDnsZoneBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsCreateDnsZoneResponse201
    | DnsCreateDnsZoneResponse429
]:
    """Create a DNSZone.

    Args:
        body (DnsCreateDnsZoneBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsCreateDnsZoneResponse201 | DnsCreateDnsZoneResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: DnsCreateDnsZoneBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsCreateDnsZoneResponse201
    | DnsCreateDnsZoneResponse429
    | None
):
    """Create a DNSZone.

    Args:
        body (DnsCreateDnsZoneBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsCreateDnsZoneResponse201 | DnsCreateDnsZoneResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
