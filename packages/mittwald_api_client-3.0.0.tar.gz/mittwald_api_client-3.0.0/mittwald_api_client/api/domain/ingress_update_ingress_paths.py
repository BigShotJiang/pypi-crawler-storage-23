from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_ingress_path import DeMittwaldV1IngressPath
from ...models.ingress_update_ingress_paths_response_429 import IngressUpdateIngressPathsResponse429
from ...types import Response


def _get_kwargs(
    ingress_id: UUID,
    *,
    body: list[DeMittwaldV1IngressPath],
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v2/ingresses/{ingress_id}/paths".format(
            ingress_id=quote(str(ingress_id), safe=""),
        ),
    }

    _kwargs["json"] = []
    for body_item_data in body:
        body_item = body_item_data.to_dict()
        _kwargs["json"].append(body_item)

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | DeMittwaldV1CommonsError | IngressUpdateIngressPathsResponse429:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = IngressUpdateIngressPathsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | DeMittwaldV1CommonsError | IngressUpdateIngressPathsResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    ingress_id: UUID,
    *,
    client: AuthenticatedClient,
    body: list[DeMittwaldV1IngressPath],
) -> Response[Any | DeMittwaldV1CommonsError | IngressUpdateIngressPathsResponse429]:
    """Update the paths of an Ingress.

    Args:
        ingress_id (UUID):
        body (list[DeMittwaldV1IngressPath]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | IngressUpdateIngressPathsResponse429]
    """

    kwargs = _get_kwargs(
        ingress_id=ingress_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    ingress_id: UUID,
    *,
    client: AuthenticatedClient,
    body: list[DeMittwaldV1IngressPath],
) -> Any | DeMittwaldV1CommonsError | IngressUpdateIngressPathsResponse429 | None:
    """Update the paths of an Ingress.

    Args:
        ingress_id (UUID):
        body (list[DeMittwaldV1IngressPath]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | IngressUpdateIngressPathsResponse429
    """

    return sync_detailed(
        ingress_id=ingress_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    ingress_id: UUID,
    *,
    client: AuthenticatedClient,
    body: list[DeMittwaldV1IngressPath],
) -> Response[Any | DeMittwaldV1CommonsError | IngressUpdateIngressPathsResponse429]:
    """Update the paths of an Ingress.

    Args:
        ingress_id (UUID):
        body (list[DeMittwaldV1IngressPath]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | IngressUpdateIngressPathsResponse429]
    """

    kwargs = _get_kwargs(
        ingress_id=ingress_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    ingress_id: UUID,
    *,
    client: AuthenticatedClient,
    body: list[DeMittwaldV1IngressPath],
) -> Any | DeMittwaldV1CommonsError | IngressUpdateIngressPathsResponse429 | None:
    """Update the paths of an Ingress.

    Args:
        ingress_id (UUID):
        body (list[DeMittwaldV1IngressPath]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | IngressUpdateIngressPathsResponse429
    """

    return (
        await asyncio_detailed(
            ingress_id=ingress_id,
            client=client,
            body=body,
        )
    ).parsed
