from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_ssl_certificate_error import DeMittwaldV1SslCertificateError
from ...models.ssl_replace_certificate_body import SslReplaceCertificateBody
from ...models.ssl_replace_certificate_response_429 import SslReplaceCertificateResponse429
from ...types import Response


def _get_kwargs(
    certificate_id: UUID,
    *,
    body: SslReplaceCertificateBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v2/certificates/{certificate_id}".format(
            certificate_id=quote(str(certificate_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | DeMittwaldV1CommonsError | DeMittwaldV1SslCertificateError | SslReplaceCertificateResponse429:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = DeMittwaldV1SslCertificateError.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = SslReplaceCertificateResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1SslCertificateError | SslReplaceCertificateResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    certificate_id: UUID,
    *,
    client: AuthenticatedClient,
    body: SslReplaceCertificateBody,
) -> Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1SslCertificateError | SslReplaceCertificateResponse429]:
    """Update a Certificate.

    Args:
        certificate_id (UUID):
        body (SslReplaceCertificateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1SslCertificateError | SslReplaceCertificateResponse429]
    """

    kwargs = _get_kwargs(
        certificate_id=certificate_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    certificate_id: UUID,
    *,
    client: AuthenticatedClient,
    body: SslReplaceCertificateBody,
) -> Any | DeMittwaldV1CommonsError | DeMittwaldV1SslCertificateError | SslReplaceCertificateResponse429 | None:
    """Update a Certificate.

    Args:
        certificate_id (UUID):
        body (SslReplaceCertificateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1SslCertificateError | SslReplaceCertificateResponse429
    """

    return sync_detailed(
        certificate_id=certificate_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    certificate_id: UUID,
    *,
    client: AuthenticatedClient,
    body: SslReplaceCertificateBody,
) -> Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1SslCertificateError | SslReplaceCertificateResponse429]:
    """Update a Certificate.

    Args:
        certificate_id (UUID):
        body (SslReplaceCertificateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1SslCertificateError | SslReplaceCertificateResponse429]
    """

    kwargs = _get_kwargs(
        certificate_id=certificate_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    certificate_id: UUID,
    *,
    client: AuthenticatedClient,
    body: SslReplaceCertificateBody,
) -> Any | DeMittwaldV1CommonsError | DeMittwaldV1SslCertificateError | SslReplaceCertificateResponse429 | None:
    """Update a Certificate.

    Args:
        certificate_id (UUID):
        body (SslReplaceCertificateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1SslCertificateError | SslReplaceCertificateResponse429
    """

    return (
        await asyncio_detailed(
            certificate_id=certificate_id,
            client=client,
            body=body,
        )
    ).parsed
