from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_domain_suggested_domains import DeMittwaldV1DomainSuggestedDomains
from ...models.domain_suggest_response_429 import DomainSuggestResponse429
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    prompt: str,
    domain_count: int | Unset = 6,
    tlds: list[str] | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["prompt"] = prompt

    params["domainCount"] = domain_count

    json_tlds: list[str] | Unset = UNSET
    if not isinstance(tlds, Unset):
        json_tlds = tlds

    params["tlds"] = json_tlds

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/domain-suggestions",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DomainSuggestedDomains
    | DomainSuggestResponse429
):
    if response.status_code == 200:
        response_200 = DeMittwaldV1DomainSuggestedDomains.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 412:
        response_412 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_412

    if response.status_code == 429:
        response_429 = DomainSuggestResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DomainSuggestedDomains
    | DomainSuggestResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    prompt: str,
    domain_count: int | Unset = 6,
    tlds: list[str] | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DomainSuggestedDomains
    | DomainSuggestResponse429
]:
    """Suggest a list of domains based on a prompt using AI.

    Args:
        prompt (str):
        domain_count (int | Unset):  Default: 6.
        tlds (list[str] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DomainSuggestedDomains | DomainSuggestResponse429]
    """

    kwargs = _get_kwargs(
        prompt=prompt,
        domain_count=domain_count,
        tlds=tlds,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    prompt: str,
    domain_count: int | Unset = 6,
    tlds: list[str] | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DomainSuggestedDomains
    | DomainSuggestResponse429
    | None
):
    """Suggest a list of domains based on a prompt using AI.

    Args:
        prompt (str):
        domain_count (int | Unset):  Default: 6.
        tlds (list[str] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DomainSuggestedDomains | DomainSuggestResponse429
    """

    return sync_detailed(
        client=client,
        prompt=prompt,
        domain_count=domain_count,
        tlds=tlds,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    prompt: str,
    domain_count: int | Unset = 6,
    tlds: list[str] | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DomainSuggestedDomains
    | DomainSuggestResponse429
]:
    """Suggest a list of domains based on a prompt using AI.

    Args:
        prompt (str):
        domain_count (int | Unset):  Default: 6.
        tlds (list[str] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DomainSuggestedDomains | DomainSuggestResponse429]
    """

    kwargs = _get_kwargs(
        prompt=prompt,
        domain_count=domain_count,
        tlds=tlds,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    prompt: str,
    domain_count: int | Unset = 6,
    tlds: list[str] | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1DomainSuggestedDomains
    | DomainSuggestResponse429
    | None
):
    """Suggest a list of domains based on a prompt using AI.

    Args:
        prompt (str):
        domain_count (int | Unset):  Default: 6.
        tlds (list[str] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1DomainSuggestedDomains | DomainSuggestResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            prompt=prompt,
            domain_count=domain_count,
            tlds=tlds,
        )
    ).parsed
