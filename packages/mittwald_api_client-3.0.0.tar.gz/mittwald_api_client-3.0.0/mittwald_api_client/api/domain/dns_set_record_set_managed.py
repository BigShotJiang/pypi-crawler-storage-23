from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.dns_set_record_set_managed_body import DnsSetRecordSetManagedBody
from ...models.dns_set_record_set_managed_record_set import DnsSetRecordSetManagedRecordSet
from ...models.dns_set_record_set_managed_response_200 import DnsSetRecordSetManagedResponse200
from ...models.dns_set_record_set_managed_response_429 import DnsSetRecordSetManagedResponse429
from ...types import Response


def _get_kwargs(
    dns_zone_id: UUID,
    record_set: DnsSetRecordSetManagedRecordSet,
    *,
    body: DnsSetRecordSetManagedBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/dns-zones/{dns_zone_id}/record-sets/{record_set}/actions/set-managed".format(
            dns_zone_id=quote(str(dns_zone_id), safe=""),
            record_set=quote(str(record_set), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsSetRecordSetManagedResponse200
    | DnsSetRecordSetManagedResponse429
):
    if response.status_code == 200:
        response_200 = DnsSetRecordSetManagedResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 412:
        response_412 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_412

    if response.status_code == 429:
        response_429 = DnsSetRecordSetManagedResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsSetRecordSetManagedResponse200
    | DnsSetRecordSetManagedResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    dns_zone_id: UUID,
    record_set: DnsSetRecordSetManagedRecordSet,
    *,
    client: AuthenticatedClient,
    body: DnsSetRecordSetManagedBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsSetRecordSetManagedResponse200
    | DnsSetRecordSetManagedResponse429
]:
    """Set a record set on a DNSZone to managed.

    Args:
        dns_zone_id (UUID):
        record_set (DnsSetRecordSetManagedRecordSet):
        body (DnsSetRecordSetManagedBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsSetRecordSetManagedResponse200 | DnsSetRecordSetManagedResponse429]
    """

    kwargs = _get_kwargs(
        dns_zone_id=dns_zone_id,
        record_set=record_set,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    dns_zone_id: UUID,
    record_set: DnsSetRecordSetManagedRecordSet,
    *,
    client: AuthenticatedClient,
    body: DnsSetRecordSetManagedBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsSetRecordSetManagedResponse200
    | DnsSetRecordSetManagedResponse429
    | None
):
    """Set a record set on a DNSZone to managed.

    Args:
        dns_zone_id (UUID):
        record_set (DnsSetRecordSetManagedRecordSet):
        body (DnsSetRecordSetManagedBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsSetRecordSetManagedResponse200 | DnsSetRecordSetManagedResponse429
    """

    return sync_detailed(
        dns_zone_id=dns_zone_id,
        record_set=record_set,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    dns_zone_id: UUID,
    record_set: DnsSetRecordSetManagedRecordSet,
    *,
    client: AuthenticatedClient,
    body: DnsSetRecordSetManagedBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsSetRecordSetManagedResponse200
    | DnsSetRecordSetManagedResponse429
]:
    """Set a record set on a DNSZone to managed.

    Args:
        dns_zone_id (UUID):
        record_set (DnsSetRecordSetManagedRecordSet):
        body (DnsSetRecordSetManagedBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsSetRecordSetManagedResponse200 | DnsSetRecordSetManagedResponse429]
    """

    kwargs = _get_kwargs(
        dns_zone_id=dns_zone_id,
        record_set=record_set,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    dns_zone_id: UUID,
    record_set: DnsSetRecordSetManagedRecordSet,
    *,
    client: AuthenticatedClient,
    body: DnsSetRecordSetManagedBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DnsSetRecordSetManagedResponse200
    | DnsSetRecordSetManagedResponse429
    | None
):
    """Set a record set on a DNSZone to managed.

    Args:
        dns_zone_id (UUID):
        record_set (DnsSetRecordSetManagedRecordSet):
        body (DnsSetRecordSetManagedBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsSetRecordSetManagedResponse200 | DnsSetRecordSetManagedResponse429
    """

    return (
        await asyncio_detailed(
            dns_zone_id=dns_zone_id,
            record_set=record_set,
            client=client,
            body=body,
        )
    ).parsed
