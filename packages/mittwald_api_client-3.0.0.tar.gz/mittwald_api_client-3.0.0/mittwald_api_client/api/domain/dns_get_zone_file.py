from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.dns_get_zone_file_response_429 import DnsGetZoneFileResponse429
from ...types import Response


def _get_kwargs(
    dns_zone_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/dns-zones/{dns_zone_id}/zone-file".format(
            dns_zone_id=quote(str(dns_zone_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsGetZoneFileResponse429 | str:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 429:
        response_429 = DnsGetZoneFileResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsGetZoneFileResponse429 | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    dns_zone_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsGetZoneFileResponse429 | str]:
    """Get a zone file for a DNSZone.

     Returns a BIND-compliant DNS zone file per RFC 1035 for the specified dnsZoneId, including all sub
    zone information. Entering the dnsZoneId of a sub zone will result in an error.

    Args:
        dns_zone_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsGetZoneFileResponse429 | str]
    """

    kwargs = _get_kwargs(
        dns_zone_id=dns_zone_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    dns_zone_id: UUID,
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsGetZoneFileResponse429 | str | None:
    """Get a zone file for a DNSZone.

     Returns a BIND-compliant DNS zone file per RFC 1035 for the specified dnsZoneId, including all sub
    zone information. Entering the dnsZoneId of a sub zone will result in an error.

    Args:
        dns_zone_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsGetZoneFileResponse429 | str
    """

    return sync_detailed(
        dns_zone_id=dns_zone_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    dns_zone_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsGetZoneFileResponse429 | str]:
    """Get a zone file for a DNSZone.

     Returns a BIND-compliant DNS zone file per RFC 1035 for the specified dnsZoneId, including all sub
    zone information. Entering the dnsZoneId of a sub zone will result in an error.

    Args:
        dns_zone_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsGetZoneFileResponse429 | str]
    """

    kwargs = _get_kwargs(
        dns_zone_id=dns_zone_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    dns_zone_id: UUID,
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsGetZoneFileResponse429 | str | None:
    """Get a zone file for a DNSZone.

     Returns a BIND-compliant DNS zone file per RFC 1035 for the specified dnsZoneId, including all sub
    zone information. Entering the dnsZoneId of a sub zone will result in an error.

    Args:
        dns_zone_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DnsGetZoneFileResponse429 | str
    """

    return (
        await asyncio_detailed(
            dns_zone_id=dns_zone_id,
            client=client,
        )
    ).parsed
