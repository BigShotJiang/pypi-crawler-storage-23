from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.domain_update_domain_auth_code_body import DomainUpdateDomainAuthCodeBody
from ...models.domain_update_domain_auth_code_response_200 import DomainUpdateDomainAuthCodeResponse200
from ...models.domain_update_domain_auth_code_response_429 import DomainUpdateDomainAuthCodeResponse429
from ...types import Response


def _get_kwargs(
    domain_id: str,
    *,
    body: DomainUpdateDomainAuthCodeBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v2/domains/{domain_id}/auth-code".format(
            domain_id=quote(str(domain_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DomainUpdateDomainAuthCodeResponse200
    | DomainUpdateDomainAuthCodeResponse429
):
    if response.status_code == 200:
        response_200 = DomainUpdateDomainAuthCodeResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = DomainUpdateDomainAuthCodeResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DomainUpdateDomainAuthCodeResponse200
    | DomainUpdateDomainAuthCodeResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    domain_id: str,
    *,
    client: AuthenticatedClient,
    body: DomainUpdateDomainAuthCodeBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DomainUpdateDomainAuthCodeResponse200
    | DomainUpdateDomainAuthCodeResponse429
]:
    """Update the auth code of a Domain.

     Update an incorrect auth code of an ongoing/failed Domain transfer. This route will also restart the
    transfer itself.

    Args:
        domain_id (str):
        body (DomainUpdateDomainAuthCodeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DomainUpdateDomainAuthCodeResponse200 | DomainUpdateDomainAuthCodeResponse429]
    """

    kwargs = _get_kwargs(
        domain_id=domain_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    domain_id: str,
    *,
    client: AuthenticatedClient,
    body: DomainUpdateDomainAuthCodeBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DomainUpdateDomainAuthCodeResponse200
    | DomainUpdateDomainAuthCodeResponse429
    | None
):
    """Update the auth code of a Domain.

     Update an incorrect auth code of an ongoing/failed Domain transfer. This route will also restart the
    transfer itself.

    Args:
        domain_id (str):
        body (DomainUpdateDomainAuthCodeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DomainUpdateDomainAuthCodeResponse200 | DomainUpdateDomainAuthCodeResponse429
    """

    return sync_detailed(
        domain_id=domain_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    domain_id: str,
    *,
    client: AuthenticatedClient,
    body: DomainUpdateDomainAuthCodeBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DomainUpdateDomainAuthCodeResponse200
    | DomainUpdateDomainAuthCodeResponse429
]:
    """Update the auth code of a Domain.

     Update an incorrect auth code of an ongoing/failed Domain transfer. This route will also restart the
    transfer itself.

    Args:
        domain_id (str):
        body (DomainUpdateDomainAuthCodeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DomainUpdateDomainAuthCodeResponse200 | DomainUpdateDomainAuthCodeResponse429]
    """

    kwargs = _get_kwargs(
        domain_id=domain_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    domain_id: str,
    *,
    client: AuthenticatedClient,
    body: DomainUpdateDomainAuthCodeBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DomainUpdateDomainAuthCodeResponse200
    | DomainUpdateDomainAuthCodeResponse429
    | None
):
    """Update the auth code of a Domain.

     Update an incorrect auth code of an ongoing/failed Domain transfer. This route will also restart the
    transfer itself.

    Args:
        domain_id (str):
        body (DomainUpdateDomainAuthCodeBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DomainUpdateDomainAuthCodeResponse200 | DomainUpdateDomainAuthCodeResponse429
    """

    return (
        await asyncio_detailed(
            domain_id=domain_id,
            client=client,
            body=body,
        )
    ).parsed
