from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_ssl_check_replace_certificate_response import (
    DeMittwaldV1SslCheckReplaceCertificateResponse,
)
from ...models.ssl_check_replace_certificate_body import SslCheckReplaceCertificateBody
from ...models.ssl_check_replace_certificate_response_429 import SslCheckReplaceCertificateResponse429
from ...types import Response


def _get_kwargs(
    certificate_id: UUID,
    *,
    body: SslCheckReplaceCertificateBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/certificates/{certificate_id}/actions/check-replace-certificate".format(
            certificate_id=quote(str(certificate_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | DeMittwaldV1SslCheckReplaceCertificateResponse | SslCheckReplaceCertificateResponse429:
    if response.status_code == 200:
        response_200 = DeMittwaldV1SslCheckReplaceCertificateResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = SslCheckReplaceCertificateResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError | DeMittwaldV1SslCheckReplaceCertificateResponse | SslCheckReplaceCertificateResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    certificate_id: UUID,
    *,
    client: AuthenticatedClient,
    body: SslCheckReplaceCertificateBody,
) -> Response[
    DeMittwaldV1CommonsError | DeMittwaldV1SslCheckReplaceCertificateResponse | SslCheckReplaceCertificateResponse429
]:
    """Check the replacement of a Certificate.

     Checks the replacement of a Certificate and shows differences between the current and the new
    Certificate.

    Args:
        certificate_id (UUID):
        body (SslCheckReplaceCertificateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1SslCheckReplaceCertificateResponse | SslCheckReplaceCertificateResponse429]
    """

    kwargs = _get_kwargs(
        certificate_id=certificate_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    certificate_id: UUID,
    *,
    client: AuthenticatedClient,
    body: SslCheckReplaceCertificateBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1SslCheckReplaceCertificateResponse
    | SslCheckReplaceCertificateResponse429
    | None
):
    """Check the replacement of a Certificate.

     Checks the replacement of a Certificate and shows differences between the current and the new
    Certificate.

    Args:
        certificate_id (UUID):
        body (SslCheckReplaceCertificateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1SslCheckReplaceCertificateResponse | SslCheckReplaceCertificateResponse429
    """

    return sync_detailed(
        certificate_id=certificate_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    certificate_id: UUID,
    *,
    client: AuthenticatedClient,
    body: SslCheckReplaceCertificateBody,
) -> Response[
    DeMittwaldV1CommonsError | DeMittwaldV1SslCheckReplaceCertificateResponse | SslCheckReplaceCertificateResponse429
]:
    """Check the replacement of a Certificate.

     Checks the replacement of a Certificate and shows differences between the current and the new
    Certificate.

    Args:
        certificate_id (UUID):
        body (SslCheckReplaceCertificateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1SslCheckReplaceCertificateResponse | SslCheckReplaceCertificateResponse429]
    """

    kwargs = _get_kwargs(
        certificate_id=certificate_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    certificate_id: UUID,
    *,
    client: AuthenticatedClient,
    body: SslCheckReplaceCertificateBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1SslCheckReplaceCertificateResponse
    | SslCheckReplaceCertificateResponse429
    | None
):
    """Check the replacement of a Certificate.

     Checks the replacement of a Certificate and shows differences between the current and the new
    Certificate.

    Args:
        certificate_id (UUID):
        body (SslCheckReplaceCertificateBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1SslCheckReplaceCertificateResponse | SslCheckReplaceCertificateResponse429
    """

    return (
        await asyncio_detailed(
            certificate_id=certificate_id,
            client=client,
            body=body,
        )
    ).parsed
