from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.ingress_update_ingress_tls_body_type_0 import IngressUpdateIngressTlsBodyType0
from ...models.ingress_update_ingress_tls_body_type_1 import IngressUpdateIngressTlsBodyType1
from ...models.ingress_update_ingress_tls_response_200 import IngressUpdateIngressTlsResponse200
from ...models.ingress_update_ingress_tls_response_429 import IngressUpdateIngressTlsResponse429
from ...types import Response


def _get_kwargs(
    ingress_id: UUID,
    *,
    body: IngressUpdateIngressTlsBodyType0 | IngressUpdateIngressTlsBodyType1,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v2/ingresses/{ingress_id}/tls".format(
            ingress_id=quote(str(ingress_id), safe=""),
        ),
    }

    if isinstance(body, IngressUpdateIngressTlsBodyType0):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | IngressUpdateIngressTlsResponse200 | IngressUpdateIngressTlsResponse429:
    if response.status_code == 200:
        response_200 = IngressUpdateIngressTlsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 412:
        response_412 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_412

    if response.status_code == 429:
        response_429 = IngressUpdateIngressTlsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | IngressUpdateIngressTlsResponse200 | IngressUpdateIngressTlsResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    ingress_id: UUID,
    *,
    client: AuthenticatedClient,
    body: IngressUpdateIngressTlsBodyType0 | IngressUpdateIngressTlsBodyType1,
) -> Response[DeMittwaldV1CommonsError | IngressUpdateIngressTlsResponse200 | IngressUpdateIngressTlsResponse429]:
    """Update the tls settings of an Ingress.

    Args:
        ingress_id (UUID):
        body (IngressUpdateIngressTlsBodyType0 | IngressUpdateIngressTlsBodyType1):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | IngressUpdateIngressTlsResponse200 | IngressUpdateIngressTlsResponse429]
    """

    kwargs = _get_kwargs(
        ingress_id=ingress_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    ingress_id: UUID,
    *,
    client: AuthenticatedClient,
    body: IngressUpdateIngressTlsBodyType0 | IngressUpdateIngressTlsBodyType1,
) -> DeMittwaldV1CommonsError | IngressUpdateIngressTlsResponse200 | IngressUpdateIngressTlsResponse429 | None:
    """Update the tls settings of an Ingress.

    Args:
        ingress_id (UUID):
        body (IngressUpdateIngressTlsBodyType0 | IngressUpdateIngressTlsBodyType1):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | IngressUpdateIngressTlsResponse200 | IngressUpdateIngressTlsResponse429
    """

    return sync_detailed(
        ingress_id=ingress_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    ingress_id: UUID,
    *,
    client: AuthenticatedClient,
    body: IngressUpdateIngressTlsBodyType0 | IngressUpdateIngressTlsBodyType1,
) -> Response[DeMittwaldV1CommonsError | IngressUpdateIngressTlsResponse200 | IngressUpdateIngressTlsResponse429]:
    """Update the tls settings of an Ingress.

    Args:
        ingress_id (UUID):
        body (IngressUpdateIngressTlsBodyType0 | IngressUpdateIngressTlsBodyType1):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | IngressUpdateIngressTlsResponse200 | IngressUpdateIngressTlsResponse429]
    """

    kwargs = _get_kwargs(
        ingress_id=ingress_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    ingress_id: UUID,
    *,
    client: AuthenticatedClient,
    body: IngressUpdateIngressTlsBodyType0 | IngressUpdateIngressTlsBodyType1,
) -> DeMittwaldV1CommonsError | IngressUpdateIngressTlsResponse200 | IngressUpdateIngressTlsResponse429 | None:
    """Update the tls settings of an Ingress.

    Args:
        ingress_id (UUID):
        body (IngressUpdateIngressTlsBodyType0 | IngressUpdateIngressTlsBodyType1):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | IngressUpdateIngressTlsResponse200 | IngressUpdateIngressTlsResponse429
    """

    return (
        await asyncio_detailed(
            ingress_id=ingress_id,
            client=client,
            body=body,
        )
    ).parsed
