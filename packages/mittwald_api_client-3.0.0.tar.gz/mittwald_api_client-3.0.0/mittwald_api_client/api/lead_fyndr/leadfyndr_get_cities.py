from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_leadfyndr_city import DeMittwaldV1LeadfyndrCity
from ...models.leadfyndr_get_cities_response_429 import LeadfyndrGetCitiesResponse429
from ...types import UNSET, Response


def _get_kwargs(
    *,
    input_: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["input"] = input_

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/cities",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrGetCitiesResponse429
    | list[DeMittwaldV1LeadfyndrCity]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1LeadfyndrCity.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = LeadfyndrGetCitiesResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrGetCitiesResponse429
    | list[DeMittwaldV1LeadfyndrCity]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    input_: str,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrGetCitiesResponse429
    | list[DeMittwaldV1LeadfyndrCity]
]:
    """Get cities in DACH.

    Args:
        input_ (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | LeadfyndrGetCitiesResponse429 | list[DeMittwaldV1LeadfyndrCity]]
    """

    kwargs = _get_kwargs(
        input_=input_,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    input_: str,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrGetCitiesResponse429
    | list[DeMittwaldV1LeadfyndrCity]
    | None
):
    """Get cities in DACH.

    Args:
        input_ (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | LeadfyndrGetCitiesResponse429 | list[DeMittwaldV1LeadfyndrCity]
    """

    return sync_detailed(
        client=client,
        input_=input_,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    input_: str,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrGetCitiesResponse429
    | list[DeMittwaldV1LeadfyndrCity]
]:
    """Get cities in DACH.

    Args:
        input_ (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | LeadfyndrGetCitiesResponse429 | list[DeMittwaldV1LeadfyndrCity]]
    """

    kwargs = _get_kwargs(
        input_=input_,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    input_: str,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrGetCitiesResponse429
    | list[DeMittwaldV1LeadfyndrCity]
    | None
):
    """Get cities in DACH.

    Args:
        input_ (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | LeadfyndrGetCitiesResponse429 | list[DeMittwaldV1LeadfyndrCity]
    """

    return (
        await asyncio_detailed(
            client=client,
            input_=input_,
        )
    ).parsed
