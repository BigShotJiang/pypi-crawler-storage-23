from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.leadfyndr_list_unlocked_leads_order import LeadfyndrListUnlockedLeadsOrder
from ...models.leadfyndr_list_unlocked_leads_response_200 import LeadfyndrListUnlockedLeadsResponse200
from ...models.leadfyndr_list_unlocked_leads_response_429 import LeadfyndrListUnlockedLeadsResponse429
from ...models.leadfyndr_list_unlocked_leads_sort import LeadfyndrListUnlockedLeadsSort
from ...models.leadfyndr_list_unlocked_leads_technologies_item_type_1 import (
    LeadfyndrListUnlockedLeadsTechnologiesItemType1,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    customer_id: str,
    *,
    potential_range_min: float | Unset = UNSET,
    potential_range_max: float | Unset = UNSET,
    employee_count_min: int | Unset = UNSET,
    employee_count_max: int | Unset = UNSET,
    sales_volume_min: int | Unset = UNSET,
    sales_volume_max: int | Unset = UNSET,
    technologies: list[LeadfyndrListUnlockedLeadsTechnologiesItemType1 | str] | Unset = UNSET,
    business_fields: list[str] | Unset = UNSET,
    location_city: str | Unset = UNSET,
    location_post_code: str | Unset = UNSET,
    location_radius_in_km: float | Unset = UNSET,
    basictime_to_first_byte_msmin: float | Unset = UNSET,
    basictime_to_first_byte_msmax: float | Unset = UNSET,
    basicdesktopperformancemin: float | Unset = UNSET,
    basicdesktopperformancemax: float | Unset = UNSET,
    basicmobileperformancemin: float | Unset = UNSET,
    basicmobileperformancemax: float | Unset = UNSET,
    reserved: bool | Unset = UNSET,
    limit: int | Unset = 10,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: LeadfyndrListUnlockedLeadsSort | Unset = LeadfyndrListUnlockedLeadsSort.RELEVANCE,
    order: LeadfyndrListUnlockedLeadsOrder | Unset = LeadfyndrListUnlockedLeadsOrder.DESC,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["potentialRangeMin"] = potential_range_min

    params["potentialRangeMax"] = potential_range_max

    params["employeeCountMin"] = employee_count_min

    params["employeeCountMax"] = employee_count_max

    params["salesVolumeMin"] = sales_volume_min

    params["salesVolumeMax"] = sales_volume_max

    json_technologies: list[str] | Unset = UNSET
    if not isinstance(technologies, Unset):
        json_technologies = []
        for technologies_item_data in technologies:
            technologies_item: str
            if isinstance(technologies_item_data, LeadfyndrListUnlockedLeadsTechnologiesItemType1):
                technologies_item = technologies_item_data.value
            else:
                technologies_item = technologies_item_data
            json_technologies.append(technologies_item)

    params["technologies"] = json_technologies

    json_business_fields: list[str] | Unset = UNSET
    if not isinstance(business_fields, Unset):
        json_business_fields = business_fields

    params["businessFields"] = json_business_fields

    params["locationCity"] = location_city

    params["locationPostCode"] = location_post_code

    params["locationRadiusInKm"] = location_radius_in_km

    params["basic:timeToFirstByteMs:min"] = basictime_to_first_byte_msmin

    params["basic:timeToFirstByteMs:max"] = basictime_to_first_byte_msmax

    params["basic:desktop:performance:min"] = basicdesktopperformancemin

    params["basic:desktop:performance:max"] = basicdesktopperformancemax

    params["basic:mobile:performance:min"] = basicmobileperformancemin

    params["basic:mobile:performance:max"] = basicmobileperformancemax

    params["reserved"] = reserved

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    json_sort: str | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = sort.value

    params["sort"] = json_sort

    json_order: str | Unset = UNSET
    if not isinstance(order, Unset):
        json_order = order.value

    params["order"] = json_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/customers/{customer_id}/unlocked-leads".format(
            customer_id=quote(str(customer_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrListUnlockedLeadsResponse200
    | LeadfyndrListUnlockedLeadsResponse429
):
    if response.status_code == 200:
        response_200 = LeadfyndrListUnlockedLeadsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = LeadfyndrListUnlockedLeadsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrListUnlockedLeadsResponse200
    | LeadfyndrListUnlockedLeadsResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    customer_id: str,
    *,
    client: AuthenticatedClient | Client,
    potential_range_min: float | Unset = UNSET,
    potential_range_max: float | Unset = UNSET,
    employee_count_min: int | Unset = UNSET,
    employee_count_max: int | Unset = UNSET,
    sales_volume_min: int | Unset = UNSET,
    sales_volume_max: int | Unset = UNSET,
    technologies: list[LeadfyndrListUnlockedLeadsTechnologiesItemType1 | str] | Unset = UNSET,
    business_fields: list[str] | Unset = UNSET,
    location_city: str | Unset = UNSET,
    location_post_code: str | Unset = UNSET,
    location_radius_in_km: float | Unset = UNSET,
    basictime_to_first_byte_msmin: float | Unset = UNSET,
    basictime_to_first_byte_msmax: float | Unset = UNSET,
    basicdesktopperformancemin: float | Unset = UNSET,
    basicdesktopperformancemax: float | Unset = UNSET,
    basicmobileperformancemin: float | Unset = UNSET,
    basicmobileperformancemax: float | Unset = UNSET,
    reserved: bool | Unset = UNSET,
    limit: int | Unset = 10,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: LeadfyndrListUnlockedLeadsSort | Unset = LeadfyndrListUnlockedLeadsSort.RELEVANCE,
    order: LeadfyndrListUnlockedLeadsOrder | Unset = LeadfyndrListUnlockedLeadsOrder.DESC,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrListUnlockedLeadsResponse200
    | LeadfyndrListUnlockedLeadsResponse429
]:
    """Get all unlocked leads. Organisation can unlock leads.

    Args:
        customer_id (str):
        potential_range_min (float | Unset):
        potential_range_max (float | Unset):
        employee_count_min (int | Unset):
        employee_count_max (int | Unset):
        sales_volume_min (int | Unset):
        sales_volume_max (int | Unset):
        technologies (list[LeadfyndrListUnlockedLeadsTechnologiesItemType1 | str] | Unset):
        business_fields (list[str] | Unset):
        location_city (str | Unset):
        location_post_code (str | Unset):
        location_radius_in_km (float | Unset):
        basictime_to_first_byte_msmin (float | Unset):
        basictime_to_first_byte_msmax (float | Unset):
        basicdesktopperformancemin (float | Unset):
        basicdesktopperformancemax (float | Unset):
        basicmobileperformancemin (float | Unset):
        basicmobileperformancemax (float | Unset):
        reserved (bool | Unset):
        limit (int | Unset):  Default: 10.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (LeadfyndrListUnlockedLeadsSort | Unset):  Default:
            LeadfyndrListUnlockedLeadsSort.RELEVANCE.
        order (LeadfyndrListUnlockedLeadsOrder | Unset):  Default:
            LeadfyndrListUnlockedLeadsOrder.DESC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | LeadfyndrListUnlockedLeadsResponse200 | LeadfyndrListUnlockedLeadsResponse429]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        potential_range_min=potential_range_min,
        potential_range_max=potential_range_max,
        employee_count_min=employee_count_min,
        employee_count_max=employee_count_max,
        sales_volume_min=sales_volume_min,
        sales_volume_max=sales_volume_max,
        technologies=technologies,
        business_fields=business_fields,
        location_city=location_city,
        location_post_code=location_post_code,
        location_radius_in_km=location_radius_in_km,
        basictime_to_first_byte_msmin=basictime_to_first_byte_msmin,
        basictime_to_first_byte_msmax=basictime_to_first_byte_msmax,
        basicdesktopperformancemin=basicdesktopperformancemin,
        basicdesktopperformancemax=basicdesktopperformancemax,
        basicmobileperformancemin=basicmobileperformancemin,
        basicmobileperformancemax=basicmobileperformancemax,
        reserved=reserved,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    customer_id: str,
    *,
    client: AuthenticatedClient | Client,
    potential_range_min: float | Unset = UNSET,
    potential_range_max: float | Unset = UNSET,
    employee_count_min: int | Unset = UNSET,
    employee_count_max: int | Unset = UNSET,
    sales_volume_min: int | Unset = UNSET,
    sales_volume_max: int | Unset = UNSET,
    technologies: list[LeadfyndrListUnlockedLeadsTechnologiesItemType1 | str] | Unset = UNSET,
    business_fields: list[str] | Unset = UNSET,
    location_city: str | Unset = UNSET,
    location_post_code: str | Unset = UNSET,
    location_radius_in_km: float | Unset = UNSET,
    basictime_to_first_byte_msmin: float | Unset = UNSET,
    basictime_to_first_byte_msmax: float | Unset = UNSET,
    basicdesktopperformancemin: float | Unset = UNSET,
    basicdesktopperformancemax: float | Unset = UNSET,
    basicmobileperformancemin: float | Unset = UNSET,
    basicmobileperformancemax: float | Unset = UNSET,
    reserved: bool | Unset = UNSET,
    limit: int | Unset = 10,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: LeadfyndrListUnlockedLeadsSort | Unset = LeadfyndrListUnlockedLeadsSort.RELEVANCE,
    order: LeadfyndrListUnlockedLeadsOrder | Unset = LeadfyndrListUnlockedLeadsOrder.DESC,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrListUnlockedLeadsResponse200
    | LeadfyndrListUnlockedLeadsResponse429
    | None
):
    """Get all unlocked leads. Organisation can unlock leads.

    Args:
        customer_id (str):
        potential_range_min (float | Unset):
        potential_range_max (float | Unset):
        employee_count_min (int | Unset):
        employee_count_max (int | Unset):
        sales_volume_min (int | Unset):
        sales_volume_max (int | Unset):
        technologies (list[LeadfyndrListUnlockedLeadsTechnologiesItemType1 | str] | Unset):
        business_fields (list[str] | Unset):
        location_city (str | Unset):
        location_post_code (str | Unset):
        location_radius_in_km (float | Unset):
        basictime_to_first_byte_msmin (float | Unset):
        basictime_to_first_byte_msmax (float | Unset):
        basicdesktopperformancemin (float | Unset):
        basicdesktopperformancemax (float | Unset):
        basicmobileperformancemin (float | Unset):
        basicmobileperformancemax (float | Unset):
        reserved (bool | Unset):
        limit (int | Unset):  Default: 10.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (LeadfyndrListUnlockedLeadsSort | Unset):  Default:
            LeadfyndrListUnlockedLeadsSort.RELEVANCE.
        order (LeadfyndrListUnlockedLeadsOrder | Unset):  Default:
            LeadfyndrListUnlockedLeadsOrder.DESC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | LeadfyndrListUnlockedLeadsResponse200 | LeadfyndrListUnlockedLeadsResponse429
    """

    return sync_detailed(
        customer_id=customer_id,
        client=client,
        potential_range_min=potential_range_min,
        potential_range_max=potential_range_max,
        employee_count_min=employee_count_min,
        employee_count_max=employee_count_max,
        sales_volume_min=sales_volume_min,
        sales_volume_max=sales_volume_max,
        technologies=technologies,
        business_fields=business_fields,
        location_city=location_city,
        location_post_code=location_post_code,
        location_radius_in_km=location_radius_in_km,
        basictime_to_first_byte_msmin=basictime_to_first_byte_msmin,
        basictime_to_first_byte_msmax=basictime_to_first_byte_msmax,
        basicdesktopperformancemin=basicdesktopperformancemin,
        basicdesktopperformancemax=basicdesktopperformancemax,
        basicmobileperformancemin=basicmobileperformancemin,
        basicmobileperformancemax=basicmobileperformancemax,
        reserved=reserved,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    ).parsed


async def asyncio_detailed(
    customer_id: str,
    *,
    client: AuthenticatedClient | Client,
    potential_range_min: float | Unset = UNSET,
    potential_range_max: float | Unset = UNSET,
    employee_count_min: int | Unset = UNSET,
    employee_count_max: int | Unset = UNSET,
    sales_volume_min: int | Unset = UNSET,
    sales_volume_max: int | Unset = UNSET,
    technologies: list[LeadfyndrListUnlockedLeadsTechnologiesItemType1 | str] | Unset = UNSET,
    business_fields: list[str] | Unset = UNSET,
    location_city: str | Unset = UNSET,
    location_post_code: str | Unset = UNSET,
    location_radius_in_km: float | Unset = UNSET,
    basictime_to_first_byte_msmin: float | Unset = UNSET,
    basictime_to_first_byte_msmax: float | Unset = UNSET,
    basicdesktopperformancemin: float | Unset = UNSET,
    basicdesktopperformancemax: float | Unset = UNSET,
    basicmobileperformancemin: float | Unset = UNSET,
    basicmobileperformancemax: float | Unset = UNSET,
    reserved: bool | Unset = UNSET,
    limit: int | Unset = 10,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: LeadfyndrListUnlockedLeadsSort | Unset = LeadfyndrListUnlockedLeadsSort.RELEVANCE,
    order: LeadfyndrListUnlockedLeadsOrder | Unset = LeadfyndrListUnlockedLeadsOrder.DESC,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrListUnlockedLeadsResponse200
    | LeadfyndrListUnlockedLeadsResponse429
]:
    """Get all unlocked leads. Organisation can unlock leads.

    Args:
        customer_id (str):
        potential_range_min (float | Unset):
        potential_range_max (float | Unset):
        employee_count_min (int | Unset):
        employee_count_max (int | Unset):
        sales_volume_min (int | Unset):
        sales_volume_max (int | Unset):
        technologies (list[LeadfyndrListUnlockedLeadsTechnologiesItemType1 | str] | Unset):
        business_fields (list[str] | Unset):
        location_city (str | Unset):
        location_post_code (str | Unset):
        location_radius_in_km (float | Unset):
        basictime_to_first_byte_msmin (float | Unset):
        basictime_to_first_byte_msmax (float | Unset):
        basicdesktopperformancemin (float | Unset):
        basicdesktopperformancemax (float | Unset):
        basicmobileperformancemin (float | Unset):
        basicmobileperformancemax (float | Unset):
        reserved (bool | Unset):
        limit (int | Unset):  Default: 10.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (LeadfyndrListUnlockedLeadsSort | Unset):  Default:
            LeadfyndrListUnlockedLeadsSort.RELEVANCE.
        order (LeadfyndrListUnlockedLeadsOrder | Unset):  Default:
            LeadfyndrListUnlockedLeadsOrder.DESC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | LeadfyndrListUnlockedLeadsResponse200 | LeadfyndrListUnlockedLeadsResponse429]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        potential_range_min=potential_range_min,
        potential_range_max=potential_range_max,
        employee_count_min=employee_count_min,
        employee_count_max=employee_count_max,
        sales_volume_min=sales_volume_min,
        sales_volume_max=sales_volume_max,
        technologies=technologies,
        business_fields=business_fields,
        location_city=location_city,
        location_post_code=location_post_code,
        location_radius_in_km=location_radius_in_km,
        basictime_to_first_byte_msmin=basictime_to_first_byte_msmin,
        basictime_to_first_byte_msmax=basictime_to_first_byte_msmax,
        basicdesktopperformancemin=basicdesktopperformancemin,
        basicdesktopperformancemax=basicdesktopperformancemax,
        basicmobileperformancemin=basicmobileperformancemin,
        basicmobileperformancemax=basicmobileperformancemax,
        reserved=reserved,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    customer_id: str,
    *,
    client: AuthenticatedClient | Client,
    potential_range_min: float | Unset = UNSET,
    potential_range_max: float | Unset = UNSET,
    employee_count_min: int | Unset = UNSET,
    employee_count_max: int | Unset = UNSET,
    sales_volume_min: int | Unset = UNSET,
    sales_volume_max: int | Unset = UNSET,
    technologies: list[LeadfyndrListUnlockedLeadsTechnologiesItemType1 | str] | Unset = UNSET,
    business_fields: list[str] | Unset = UNSET,
    location_city: str | Unset = UNSET,
    location_post_code: str | Unset = UNSET,
    location_radius_in_km: float | Unset = UNSET,
    basictime_to_first_byte_msmin: float | Unset = UNSET,
    basictime_to_first_byte_msmax: float | Unset = UNSET,
    basicdesktopperformancemin: float | Unset = UNSET,
    basicdesktopperformancemax: float | Unset = UNSET,
    basicmobileperformancemin: float | Unset = UNSET,
    basicmobileperformancemax: float | Unset = UNSET,
    reserved: bool | Unset = UNSET,
    limit: int | Unset = 10,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: LeadfyndrListUnlockedLeadsSort | Unset = LeadfyndrListUnlockedLeadsSort.RELEVANCE,
    order: LeadfyndrListUnlockedLeadsOrder | Unset = LeadfyndrListUnlockedLeadsOrder.DESC,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | LeadfyndrListUnlockedLeadsResponse200
    | LeadfyndrListUnlockedLeadsResponse429
    | None
):
    """Get all unlocked leads. Organisation can unlock leads.

    Args:
        customer_id (str):
        potential_range_min (float | Unset):
        potential_range_max (float | Unset):
        employee_count_min (int | Unset):
        employee_count_max (int | Unset):
        sales_volume_min (int | Unset):
        sales_volume_max (int | Unset):
        technologies (list[LeadfyndrListUnlockedLeadsTechnologiesItemType1 | str] | Unset):
        business_fields (list[str] | Unset):
        location_city (str | Unset):
        location_post_code (str | Unset):
        location_radius_in_km (float | Unset):
        basictime_to_first_byte_msmin (float | Unset):
        basictime_to_first_byte_msmax (float | Unset):
        basicdesktopperformancemin (float | Unset):
        basicdesktopperformancemax (float | Unset):
        basicmobileperformancemin (float | Unset):
        basicmobileperformancemax (float | Unset):
        reserved (bool | Unset):
        limit (int | Unset):  Default: 10.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (LeadfyndrListUnlockedLeadsSort | Unset):  Default:
            LeadfyndrListUnlockedLeadsSort.RELEVANCE.
        order (LeadfyndrListUnlockedLeadsOrder | Unset):  Default:
            LeadfyndrListUnlockedLeadsOrder.DESC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | LeadfyndrListUnlockedLeadsResponse200 | LeadfyndrListUnlockedLeadsResponse429
    """

    return (
        await asyncio_detailed(
            customer_id=customer_id,
            client=client,
            potential_range_min=potential_range_min,
            potential_range_max=potential_range_max,
            employee_count_min=employee_count_min,
            employee_count_max=employee_count_max,
            sales_volume_min=sales_volume_min,
            sales_volume_max=sales_volume_max,
            technologies=technologies,
            business_fields=business_fields,
            location_city=location_city,
            location_post_code=location_post_code,
            location_radius_in_km=location_radius_in_km,
            basictime_to_first_byte_msmin=basictime_to_first_byte_msmin,
            basictime_to_first_byte_msmax=basictime_to_first_byte_msmax,
            basicdesktopperformancemin=basicdesktopperformancemin,
            basicdesktopperformancemax=basicdesktopperformancemax,
            basicmobileperformancemin=basicmobileperformancemin,
            basicmobileperformancemax=basicmobileperformancemax,
            reserved=reserved,
            limit=limit,
            skip=skip,
            page=page,
            sort=sort,
            order=order,
        )
    ).parsed
