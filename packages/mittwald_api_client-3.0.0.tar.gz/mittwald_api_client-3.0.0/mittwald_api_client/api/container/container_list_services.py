from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.container_list_services_response_429 import ContainerListServicesResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_container_service_response import DeMittwaldV1ContainerServiceResponse
from ...models.de_mittwald_v1_container_service_sort_order import DeMittwaldV1ContainerServiceSortOrder
from ...models.de_mittwald_v1_container_service_status import DeMittwaldV1ContainerServiceStatus
from ...types import UNSET, Response, Unset


def _get_kwargs(
    project_id: str,
    *,
    stack_id: UUID | Unset = UNSET,
    status: DeMittwaldV1ContainerServiceStatus | Unset = UNSET,
    requires_recreate: bool | Unset = UNSET,
    search_term: str | Unset = UNSET,
    sort_order: DeMittwaldV1ContainerServiceSortOrder | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_stack_id: str | Unset = UNSET
    if not isinstance(stack_id, Unset):
        json_stack_id = str(stack_id)
    params["stackId"] = json_stack_id

    json_status: str | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = status.value

    params["status"] = json_status

    params["requiresRecreate"] = requires_recreate

    params["searchTerm"] = search_term

    json_sort_order: str | Unset = UNSET
    if not isinstance(sort_order, Unset):
        json_sort_order = sort_order.value

    params["sortOrder"] = json_sort_order

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects/{project_id}/services".format(
            project_id=quote(str(project_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ContainerListServicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerServiceResponse]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1ContainerServiceResponse.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 412:
        response_412 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_412

    if response.status_code == 429:
        response_429 = ContainerListServicesResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ContainerListServicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerServiceResponse]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    stack_id: UUID | Unset = UNSET,
    status: DeMittwaldV1ContainerServiceStatus | Unset = UNSET,
    requires_recreate: bool | Unset = UNSET,
    search_term: str | Unset = UNSET,
    sort_order: DeMittwaldV1ContainerServiceSortOrder | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[
    ContainerListServicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerServiceResponse]
]:
    """List Services belonging to a Project.

    Args:
        project_id (str):
        stack_id (UUID | Unset):
        status (DeMittwaldV1ContainerServiceStatus | Unset):
        requires_recreate (bool | Unset):
        search_term (str | Unset):
        sort_order (DeMittwaldV1ContainerServiceSortOrder | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContainerListServicesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ContainerServiceResponse]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        stack_id=stack_id,
        status=status,
        requires_recreate=requires_recreate,
        search_term=search_term,
        sort_order=sort_order,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    stack_id: UUID | Unset = UNSET,
    status: DeMittwaldV1ContainerServiceStatus | Unset = UNSET,
    requires_recreate: bool | Unset = UNSET,
    search_term: str | Unset = UNSET,
    sort_order: DeMittwaldV1ContainerServiceSortOrder | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> (
    ContainerListServicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerServiceResponse]
    | None
):
    """List Services belonging to a Project.

    Args:
        project_id (str):
        stack_id (UUID | Unset):
        status (DeMittwaldV1ContainerServiceStatus | Unset):
        requires_recreate (bool | Unset):
        search_term (str | Unset):
        sort_order (DeMittwaldV1ContainerServiceSortOrder | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContainerListServicesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ContainerServiceResponse]
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        stack_id=stack_id,
        status=status,
        requires_recreate=requires_recreate,
        search_term=search_term,
        sort_order=sort_order,
        limit=limit,
        skip=skip,
        page=page,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    stack_id: UUID | Unset = UNSET,
    status: DeMittwaldV1ContainerServiceStatus | Unset = UNSET,
    requires_recreate: bool | Unset = UNSET,
    search_term: str | Unset = UNSET,
    sort_order: DeMittwaldV1ContainerServiceSortOrder | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[
    ContainerListServicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerServiceResponse]
]:
    """List Services belonging to a Project.

    Args:
        project_id (str):
        stack_id (UUID | Unset):
        status (DeMittwaldV1ContainerServiceStatus | Unset):
        requires_recreate (bool | Unset):
        search_term (str | Unset):
        sort_order (DeMittwaldV1ContainerServiceSortOrder | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContainerListServicesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ContainerServiceResponse]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        stack_id=stack_id,
        status=status,
        requires_recreate=requires_recreate,
        search_term=search_term,
        sort_order=sort_order,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    stack_id: UUID | Unset = UNSET,
    status: DeMittwaldV1ContainerServiceStatus | Unset = UNSET,
    requires_recreate: bool | Unset = UNSET,
    search_term: str | Unset = UNSET,
    sort_order: DeMittwaldV1ContainerServiceSortOrder | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> (
    ContainerListServicesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerServiceResponse]
    | None
):
    """List Services belonging to a Project.

    Args:
        project_id (str):
        stack_id (UUID | Unset):
        status (DeMittwaldV1ContainerServiceStatus | Unset):
        requires_recreate (bool | Unset):
        search_term (str | Unset):
        sort_order (DeMittwaldV1ContainerServiceSortOrder | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContainerListServicesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ContainerServiceResponse]
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            stack_id=stack_id,
            status=status,
            requires_recreate=requires_recreate,
            search_term=search_term,
            sort_order=sort_order,
            limit=limit,
            skip=skip,
            page=page,
        )
    ).parsed
