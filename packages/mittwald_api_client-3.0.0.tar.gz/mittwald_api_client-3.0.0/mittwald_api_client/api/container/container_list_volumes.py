from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.container_list_volumes_response_429 import ContainerListVolumesResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_container_volume_response import DeMittwaldV1ContainerVolumeResponse
from ...models.de_mittwald_v1_container_volume_sort_order import DeMittwaldV1ContainerVolumeSortOrder
from ...types import UNSET, Response, Unset


def _get_kwargs(
    project_id: str,
    *,
    stack_id: UUID | Unset = UNSET,
    search_term: str | Unset = UNSET,
    sort_order: DeMittwaldV1ContainerVolumeSortOrder | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_stack_id: str | Unset = UNSET
    if not isinstance(stack_id, Unset):
        json_stack_id = str(stack_id)
    params["stackId"] = json_stack_id

    params["searchTerm"] = search_term

    json_sort_order: str | Unset = UNSET
    if not isinstance(sort_order, Unset):
        json_sort_order = sort_order.value

    params["sortOrder"] = json_sort_order

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects/{project_id}/volumes".format(
            project_id=quote(str(project_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ContainerListVolumesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerVolumeResponse]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1ContainerVolumeResponse.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 429:
        response_429 = ContainerListVolumesResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ContainerListVolumesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerVolumeResponse]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    stack_id: UUID | Unset = UNSET,
    search_term: str | Unset = UNSET,
    sort_order: DeMittwaldV1ContainerVolumeSortOrder | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[
    ContainerListVolumesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerVolumeResponse]
]:
    """List Volumes belonging to a Project.

    Args:
        project_id (str):
        stack_id (UUID | Unset):
        search_term (str | Unset):
        sort_order (DeMittwaldV1ContainerVolumeSortOrder | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContainerListVolumesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ContainerVolumeResponse]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        stack_id=stack_id,
        search_term=search_term,
        sort_order=sort_order,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    stack_id: UUID | Unset = UNSET,
    search_term: str | Unset = UNSET,
    sort_order: DeMittwaldV1ContainerVolumeSortOrder | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> (
    ContainerListVolumesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerVolumeResponse]
    | None
):
    """List Volumes belonging to a Project.

    Args:
        project_id (str):
        stack_id (UUID | Unset):
        search_term (str | Unset):
        sort_order (DeMittwaldV1ContainerVolumeSortOrder | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContainerListVolumesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ContainerVolumeResponse]
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        stack_id=stack_id,
        search_term=search_term,
        sort_order=sort_order,
        limit=limit,
        skip=skip,
        page=page,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    stack_id: UUID | Unset = UNSET,
    search_term: str | Unset = UNSET,
    sort_order: DeMittwaldV1ContainerVolumeSortOrder | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[
    ContainerListVolumesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerVolumeResponse]
]:
    """List Volumes belonging to a Project.

    Args:
        project_id (str):
        stack_id (UUID | Unset):
        search_term (str | Unset):
        sort_order (DeMittwaldV1ContainerVolumeSortOrder | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContainerListVolumesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ContainerVolumeResponse]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        stack_id=stack_id,
        search_term=search_term,
        sort_order=sort_order,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    stack_id: UUID | Unset = UNSET,
    search_term: str | Unset = UNSET,
    sort_order: DeMittwaldV1ContainerVolumeSortOrder | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> (
    ContainerListVolumesResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ContainerVolumeResponse]
    | None
):
    """List Volumes belonging to a Project.

    Args:
        project_id (str):
        stack_id (UUID | Unset):
        search_term (str | Unset):
        sort_order (DeMittwaldV1ContainerVolumeSortOrder | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContainerListVolumesResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ContainerVolumeResponse]
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            stack_id=stack_id,
            search_term=search_term,
            sort_order=sort_order,
            limit=limit,
            skip=skip,
            page=page,
        )
    ).parsed
