from http import HTTPStatus
from typing import Any
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.container_get_container_image_config_response_429 import ContainerGetContainerImageConfigResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_container_container_image_config import DeMittwaldV1ContainerContainerImageConfig
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    image_reference: str,
    use_credentials_for_project_id: UUID | Unset = UNSET,
    use_credentials_for_registry_id: UUID | Unset = UNSET,
    generate_ai_data: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["imageReference"] = image_reference

    json_use_credentials_for_project_id: str | Unset = UNSET
    if not isinstance(use_credentials_for_project_id, Unset):
        json_use_credentials_for_project_id = str(use_credentials_for_project_id)
    params["useCredentialsForProjectId"] = json_use_credentials_for_project_id

    json_use_credentials_for_registry_id: str | Unset = UNSET
    if not isinstance(use_credentials_for_registry_id, Unset):
        json_use_credentials_for_registry_id = str(use_credentials_for_registry_id)
    params["useCredentialsForRegistryId"] = json_use_credentials_for_registry_id

    params["generateAiData"] = generate_ai_data

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/container-image-config",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ContainerGetContainerImageConfigResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerContainerImageConfig
):
    if response.status_code == 200:
        response_200 = DeMittwaldV1ContainerContainerImageConfig.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 412:
        response_412 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_412

    if response.status_code == 429:
        response_429 = ContainerGetContainerImageConfigResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ContainerGetContainerImageConfigResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerContainerImageConfig
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    image_reference: str,
    use_credentials_for_project_id: UUID | Unset = UNSET,
    use_credentials_for_registry_id: UUID | Unset = UNSET,
    generate_ai_data: bool | Unset = UNSET,
) -> Response[
    ContainerGetContainerImageConfigResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerContainerImageConfig
]:
    """Get a ContainerImageConfig.

    Args:
        image_reference (str):  Example: mysql.
        use_credentials_for_project_id (UUID | Unset):
        use_credentials_for_registry_id (UUID | Unset):
        generate_ai_data (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContainerGetContainerImageConfigResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1ContainerContainerImageConfig]
    """

    kwargs = _get_kwargs(
        image_reference=image_reference,
        use_credentials_for_project_id=use_credentials_for_project_id,
        use_credentials_for_registry_id=use_credentials_for_registry_id,
        generate_ai_data=generate_ai_data,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    image_reference: str,
    use_credentials_for_project_id: UUID | Unset = UNSET,
    use_credentials_for_registry_id: UUID | Unset = UNSET,
    generate_ai_data: bool | Unset = UNSET,
) -> (
    ContainerGetContainerImageConfigResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerContainerImageConfig
    | None
):
    """Get a ContainerImageConfig.

    Args:
        image_reference (str):  Example: mysql.
        use_credentials_for_project_id (UUID | Unset):
        use_credentials_for_registry_id (UUID | Unset):
        generate_ai_data (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContainerGetContainerImageConfigResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1ContainerContainerImageConfig
    """

    return sync_detailed(
        client=client,
        image_reference=image_reference,
        use_credentials_for_project_id=use_credentials_for_project_id,
        use_credentials_for_registry_id=use_credentials_for_registry_id,
        generate_ai_data=generate_ai_data,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    image_reference: str,
    use_credentials_for_project_id: UUID | Unset = UNSET,
    use_credentials_for_registry_id: UUID | Unset = UNSET,
    generate_ai_data: bool | Unset = UNSET,
) -> Response[
    ContainerGetContainerImageConfigResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerContainerImageConfig
]:
    """Get a ContainerImageConfig.

    Args:
        image_reference (str):  Example: mysql.
        use_credentials_for_project_id (UUID | Unset):
        use_credentials_for_registry_id (UUID | Unset):
        generate_ai_data (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContainerGetContainerImageConfigResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1ContainerContainerImageConfig]
    """

    kwargs = _get_kwargs(
        image_reference=image_reference,
        use_credentials_for_project_id=use_credentials_for_project_id,
        use_credentials_for_registry_id=use_credentials_for_registry_id,
        generate_ai_data=generate_ai_data,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    image_reference: str,
    use_credentials_for_project_id: UUID | Unset = UNSET,
    use_credentials_for_registry_id: UUID | Unset = UNSET,
    generate_ai_data: bool | Unset = UNSET,
) -> (
    ContainerGetContainerImageConfigResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerContainerImageConfig
    | None
):
    """Get a ContainerImageConfig.

    Args:
        image_reference (str):  Example: mysql.
        use_credentials_for_project_id (UUID | Unset):
        use_credentials_for_registry_id (UUID | Unset):
        generate_ai_data (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContainerGetContainerImageConfigResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1ContainerContainerImageConfig
    """

    return (
        await asyncio_detailed(
            client=client,
            image_reference=image_reference,
            use_credentials_for_project_id=use_credentials_for_project_id,
            use_credentials_for_registry_id=use_credentials_for_registry_id,
            generate_ai_data=generate_ai_data,
        )
    ).parsed
