from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.container_get_service_logs_response_429 import ContainerGetServiceLogsResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    stack_id: UUID,
    service_id: str,
    *,
    tail: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["tail"] = tail

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/stacks/{stack_id}/services/{service_id}/logs".format(
            stack_id=quote(str(stack_id), safe=""),
            service_id=quote(str(service_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ContainerGetServiceLogsResponse429 | DeMittwaldV1CommonsError | str:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ContainerGetServiceLogsResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_503

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ContainerGetServiceLogsResponse429 | DeMittwaldV1CommonsError | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    stack_id: UUID,
    service_id: str,
    *,
    client: AuthenticatedClient,
    tail: int | Unset = UNSET,
) -> Response[ContainerGetServiceLogsResponse429 | DeMittwaldV1CommonsError | str]:
    """Get logs belonging to a Service.

    Args:
        stack_id (UUID):
        service_id (str):
        tail (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContainerGetServiceLogsResponse429 | DeMittwaldV1CommonsError | str]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
        service_id=service_id,
        tail=tail,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    stack_id: UUID,
    service_id: str,
    *,
    client: AuthenticatedClient,
    tail: int | Unset = UNSET,
) -> ContainerGetServiceLogsResponse429 | DeMittwaldV1CommonsError | str | None:
    """Get logs belonging to a Service.

    Args:
        stack_id (UUID):
        service_id (str):
        tail (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContainerGetServiceLogsResponse429 | DeMittwaldV1CommonsError | str
    """

    return sync_detailed(
        stack_id=stack_id,
        service_id=service_id,
        client=client,
        tail=tail,
    ).parsed


async def asyncio_detailed(
    stack_id: UUID,
    service_id: str,
    *,
    client: AuthenticatedClient,
    tail: int | Unset = UNSET,
) -> Response[ContainerGetServiceLogsResponse429 | DeMittwaldV1CommonsError | str]:
    """Get logs belonging to a Service.

    Args:
        stack_id (UUID):
        service_id (str):
        tail (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContainerGetServiceLogsResponse429 | DeMittwaldV1CommonsError | str]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
        service_id=service_id,
        tail=tail,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    stack_id: UUID,
    service_id: str,
    *,
    client: AuthenticatedClient,
    tail: int | Unset = UNSET,
) -> ContainerGetServiceLogsResponse429 | DeMittwaldV1CommonsError | str | None:
    """Get logs belonging to a Service.

    Args:
        stack_id (UUID):
        service_id (str):
        tail (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContainerGetServiceLogsResponse429 | DeMittwaldV1CommonsError | str
    """

    return (
        await asyncio_detailed(
            stack_id=stack_id,
            service_id=service_id,
            client=client,
            tail=tail,
        )
    ).parsed
