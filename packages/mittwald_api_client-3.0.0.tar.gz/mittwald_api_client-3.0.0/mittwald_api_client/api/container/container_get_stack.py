from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.container_get_stack_response_429 import ContainerGetStackResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_container_stack_response import DeMittwaldV1ContainerStackResponse
from ...types import Response


def _get_kwargs(
    stack_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/stacks/{stack_id}".format(
            stack_id=quote(str(stack_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ContainerGetStackResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerStackResponse
):
    if response.status_code == 200:
        response_200 = DeMittwaldV1ContainerStackResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 429:
        response_429 = ContainerGetStackResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ContainerGetStackResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerStackResponse
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    stack_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    ContainerGetStackResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerStackResponse
]:
    """Get a Stack.

    Args:
        stack_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContainerGetStackResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1ContainerStackResponse]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    stack_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    ContainerGetStackResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerStackResponse
    | None
):
    """Get a Stack.

    Args:
        stack_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContainerGetStackResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1ContainerStackResponse
    """

    return sync_detailed(
        stack_id=stack_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    stack_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    ContainerGetStackResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerStackResponse
]:
    """Get a Stack.

    Args:
        stack_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContainerGetStackResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1ContainerStackResponse]
    """

    kwargs = _get_kwargs(
        stack_id=stack_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    stack_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    ContainerGetStackResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1ContainerStackResponse
    | None
):
    """Get a Stack.

    Args:
        stack_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContainerGetStackResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1ContainerStackResponse
    """

    return (
        await asyncio_detailed(
            stack_id=stack_id,
            client=client,
        )
    ).parsed
