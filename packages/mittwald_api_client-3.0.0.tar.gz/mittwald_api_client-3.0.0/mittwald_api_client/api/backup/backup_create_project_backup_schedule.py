from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.backup_create_project_backup_schedule_body import BackupCreateProjectBackupScheduleBody
from ...models.backup_create_project_backup_schedule_response_429 import BackupCreateProjectBackupScheduleResponse429
from ...models.de_mittwald_v1_backup_project_backup_schedule import DeMittwaldV1BackupProjectBackupSchedule
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...types import Response


def _get_kwargs(
    project_id: str,
    *,
    body: BackupCreateProjectBackupScheduleBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/projects/{project_id}/backup-schedules".format(
            project_id=quote(str(project_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    BackupCreateProjectBackupScheduleResponse429
    | DeMittwaldV1BackupProjectBackupSchedule
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
):
    if response.status_code == 201:
        response_201 = DeMittwaldV1BackupProjectBackupSchedule.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = BackupCreateProjectBackupScheduleResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    BackupCreateProjectBackupScheduleResponse429
    | DeMittwaldV1BackupProjectBackupSchedule
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: BackupCreateProjectBackupScheduleBody,
) -> Response[
    BackupCreateProjectBackupScheduleResponse429
    | DeMittwaldV1BackupProjectBackupSchedule
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
]:
    """Create a BackupSchedule for a Project.

    Args:
        project_id (str):
        body (BackupCreateProjectBackupScheduleBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BackupCreateProjectBackupScheduleResponse429 | DeMittwaldV1BackupProjectBackupSchedule | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: BackupCreateProjectBackupScheduleBody,
) -> (
    BackupCreateProjectBackupScheduleResponse429
    | DeMittwaldV1BackupProjectBackupSchedule
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | None
):
    """Create a BackupSchedule for a Project.

    Args:
        project_id (str):
        body (BackupCreateProjectBackupScheduleBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BackupCreateProjectBackupScheduleResponse429 | DeMittwaldV1BackupProjectBackupSchedule | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: BackupCreateProjectBackupScheduleBody,
) -> Response[
    BackupCreateProjectBackupScheduleResponse429
    | DeMittwaldV1BackupProjectBackupSchedule
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
]:
    """Create a BackupSchedule for a Project.

    Args:
        project_id (str):
        body (BackupCreateProjectBackupScheduleBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BackupCreateProjectBackupScheduleResponse429 | DeMittwaldV1BackupProjectBackupSchedule | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: BackupCreateProjectBackupScheduleBody,
) -> (
    BackupCreateProjectBackupScheduleResponse429
    | DeMittwaldV1BackupProjectBackupSchedule
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | None
):
    """Create a BackupSchedule for a Project.

    Args:
        project_id (str):
        body (BackupCreateProjectBackupScheduleBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BackupCreateProjectBackupScheduleResponse429 | DeMittwaldV1BackupProjectBackupSchedule | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            body=body,
        )
    ).parsed
