from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.backup_delete_project_backup_export_response_429 import BackupDeleteProjectBackupExportResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import Response


def _get_kwargs(
    project_backup_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v2/project-backups/{project_backup_id}/export".format(
            project_backup_id=quote(str(project_backup_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | BackupDeleteProjectBackupExportResponse429 | DeMittwaldV1CommonsError:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = BackupDeleteProjectBackupExportResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | BackupDeleteProjectBackupExportResponse429 | DeMittwaldV1CommonsError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_backup_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | BackupDeleteProjectBackupExportResponse429 | DeMittwaldV1CommonsError]:
    """Delete a ProjectBackupExport.

    Args:
        project_backup_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | BackupDeleteProjectBackupExportResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        project_backup_id=project_backup_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_backup_id: str,
    *,
    client: AuthenticatedClient,
) -> Any | BackupDeleteProjectBackupExportResponse429 | DeMittwaldV1CommonsError | None:
    """Delete a ProjectBackupExport.

    Args:
        project_backup_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | BackupDeleteProjectBackupExportResponse429 | DeMittwaldV1CommonsError
    """

    return sync_detailed(
        project_backup_id=project_backup_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    project_backup_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | BackupDeleteProjectBackupExportResponse429 | DeMittwaldV1CommonsError]:
    """Delete a ProjectBackupExport.

    Args:
        project_backup_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | BackupDeleteProjectBackupExportResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        project_backup_id=project_backup_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_backup_id: str,
    *,
    client: AuthenticatedClient,
) -> Any | BackupDeleteProjectBackupExportResponse429 | DeMittwaldV1CommonsError | None:
    """Delete a ProjectBackupExport.

    Args:
        project_backup_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | BackupDeleteProjectBackupExportResponse429 | DeMittwaldV1CommonsError
    """

    return (
        await asyncio_detailed(
            project_backup_id=project_backup_id,
            client=client,
        )
    ).parsed
