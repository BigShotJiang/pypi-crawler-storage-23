from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.backup_list_project_backups_response_429 import BackupListProjectBackupsResponse429
from ...models.de_mittwald_v1_backup_backup_sort_order import DeMittwaldV1BackupBackupSortOrder
from ...models.de_mittwald_v1_backup_project_backup import DeMittwaldV1BackupProjectBackup
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    project_id: str,
    *,
    search_term: str | Unset = UNSET,
    with_exports_only: bool | Unset = UNSET,
    sort_order: DeMittwaldV1BackupBackupSortOrder | Unset = UNSET,
    running_restores_only: bool | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["searchTerm"] = search_term

    params["withExportsOnly"] = with_exports_only

    json_sort_order: str | Unset = UNSET
    if not isinstance(sort_order, Unset):
        json_sort_order = sort_order.value

    params["sortOrder"] = json_sort_order

    params["runningRestoresOnly"] = running_restores_only

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects/{project_id}/backups".format(
            project_id=quote(str(project_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BackupListProjectBackupsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1BackupProjectBackup]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1BackupProjectBackup.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = BackupListProjectBackupsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BackupListProjectBackupsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1BackupProjectBackup]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search_term: str | Unset = UNSET,
    with_exports_only: bool | Unset = UNSET,
    sort_order: DeMittwaldV1BackupBackupSortOrder | Unset = UNSET,
    running_restores_only: bool | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[BackupListProjectBackupsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1BackupProjectBackup]]:
    """List Backups belonging to a Project.

    Args:
        project_id (str):
        search_term (str | Unset):
        with_exports_only (bool | Unset):
        sort_order (DeMittwaldV1BackupBackupSortOrder | Unset):
        running_restores_only (bool | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BackupListProjectBackupsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1BackupProjectBackup]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        search_term=search_term,
        with_exports_only=with_exports_only,
        sort_order=sort_order,
        running_restores_only=running_restores_only,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search_term: str | Unset = UNSET,
    with_exports_only: bool | Unset = UNSET,
    sort_order: DeMittwaldV1BackupBackupSortOrder | Unset = UNSET,
    running_restores_only: bool | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> BackupListProjectBackupsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1BackupProjectBackup] | None:
    """List Backups belonging to a Project.

    Args:
        project_id (str):
        search_term (str | Unset):
        with_exports_only (bool | Unset):
        sort_order (DeMittwaldV1BackupBackupSortOrder | Unset):
        running_restores_only (bool | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BackupListProjectBackupsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1BackupProjectBackup]
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        search_term=search_term,
        with_exports_only=with_exports_only,
        sort_order=sort_order,
        running_restores_only=running_restores_only,
        limit=limit,
        skip=skip,
        page=page,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search_term: str | Unset = UNSET,
    with_exports_only: bool | Unset = UNSET,
    sort_order: DeMittwaldV1BackupBackupSortOrder | Unset = UNSET,
    running_restores_only: bool | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[BackupListProjectBackupsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1BackupProjectBackup]]:
    """List Backups belonging to a Project.

    Args:
        project_id (str):
        search_term (str | Unset):
        with_exports_only (bool | Unset):
        sort_order (DeMittwaldV1BackupBackupSortOrder | Unset):
        running_restores_only (bool | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BackupListProjectBackupsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1BackupProjectBackup]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        search_term=search_term,
        with_exports_only=with_exports_only,
        sort_order=sort_order,
        running_restores_only=running_restores_only,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search_term: str | Unset = UNSET,
    with_exports_only: bool | Unset = UNSET,
    sort_order: DeMittwaldV1BackupBackupSortOrder | Unset = UNSET,
    running_restores_only: bool | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> BackupListProjectBackupsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1BackupProjectBackup] | None:
    """List Backups belonging to a Project.

    Args:
        project_id (str):
        search_term (str | Unset):
        with_exports_only (bool | Unset):
        sort_order (DeMittwaldV1BackupBackupSortOrder | Unset):
        running_restores_only (bool | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BackupListProjectBackupsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1BackupProjectBackup]
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            search_term=search_term,
            with_exports_only=with_exports_only,
            sort_order=sort_order,
            running_restores_only=running_restores_only,
            limit=limit,
            skip=skip,
            page=page,
        )
    ).parsed
