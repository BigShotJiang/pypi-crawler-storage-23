from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.backup_get_project_backup_directories_response_429 import BackupGetProjectBackupDirectoriesResponse429
from ...models.de_mittwald_v1_backup_project_backup_path import DeMittwaldV1BackupProjectBackupPath
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    project_backup_id: str,
    *,
    directory: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["directory"] = directory

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/project-backups/{project_backup_id}/path".format(
            project_backup_id=quote(str(project_backup_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BackupGetProjectBackupDirectoriesResponse429 | DeMittwaldV1BackupProjectBackupPath | DeMittwaldV1CommonsError:
    if response.status_code == 200:
        response_200 = DeMittwaldV1BackupProjectBackupPath.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = BackupGetProjectBackupDirectoriesResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 502:
        response_502 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_502

    if response.status_code == 503:
        response_503 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_503

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    BackupGetProjectBackupDirectoriesResponse429 | DeMittwaldV1BackupProjectBackupPath | DeMittwaldV1CommonsError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_backup_id: str,
    *,
    client: AuthenticatedClient,
    directory: str | Unset = UNSET,
) -> Response[
    BackupGetProjectBackupDirectoriesResponse429 | DeMittwaldV1BackupProjectBackupPath | DeMittwaldV1CommonsError
]:
    """List paths for a ProjectBackup.

    Args:
        project_backup_id (str):
        directory (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BackupGetProjectBackupDirectoriesResponse429 | DeMittwaldV1BackupProjectBackupPath | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        project_backup_id=project_backup_id,
        directory=directory,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_backup_id: str,
    *,
    client: AuthenticatedClient,
    directory: str | Unset = UNSET,
) -> (
    BackupGetProjectBackupDirectoriesResponse429 | DeMittwaldV1BackupProjectBackupPath | DeMittwaldV1CommonsError | None
):
    """List paths for a ProjectBackup.

    Args:
        project_backup_id (str):
        directory (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BackupGetProjectBackupDirectoriesResponse429 | DeMittwaldV1BackupProjectBackupPath | DeMittwaldV1CommonsError
    """

    return sync_detailed(
        project_backup_id=project_backup_id,
        client=client,
        directory=directory,
    ).parsed


async def asyncio_detailed(
    project_backup_id: str,
    *,
    client: AuthenticatedClient,
    directory: str | Unset = UNSET,
) -> Response[
    BackupGetProjectBackupDirectoriesResponse429 | DeMittwaldV1BackupProjectBackupPath | DeMittwaldV1CommonsError
]:
    """List paths for a ProjectBackup.

    Args:
        project_backup_id (str):
        directory (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BackupGetProjectBackupDirectoriesResponse429 | DeMittwaldV1BackupProjectBackupPath | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        project_backup_id=project_backup_id,
        directory=directory,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_backup_id: str,
    *,
    client: AuthenticatedClient,
    directory: str | Unset = UNSET,
) -> (
    BackupGetProjectBackupDirectoriesResponse429 | DeMittwaldV1BackupProjectBackupPath | DeMittwaldV1CommonsError | None
):
    """List paths for a ProjectBackup.

    Args:
        project_backup_id (str):
        directory (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BackupGetProjectBackupDirectoriesResponse429 | DeMittwaldV1BackupProjectBackupPath | DeMittwaldV1CommonsError
    """

    return (
        await asyncio_detailed(
            project_backup_id=project_backup_id,
            client=client,
            directory=directory,
        )
    ).parsed
