from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.user_get_ssh_key_response_200 import UserGetSshKeyResponse200
from ...models.user_get_ssh_key_response_429 import UserGetSshKeyResponse429
from ...types import Response


def _get_kwargs(
    ssh_key_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/users/self/ssh-keys/{ssh_key_id}".format(
            ssh_key_id=quote(str(ssh_key_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | UserGetSshKeyResponse200 | UserGetSshKeyResponse429:
    if response.status_code == 200:
        response_200 = UserGetSshKeyResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = UserGetSshKeyResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | UserGetSshKeyResponse200 | UserGetSshKeyResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    ssh_key_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | UserGetSshKeyResponse200 | UserGetSshKeyResponse429]:
    """Get a specific stored ssh-key.

    Args:
        ssh_key_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | UserGetSshKeyResponse200 | UserGetSshKeyResponse429]
    """

    kwargs = _get_kwargs(
        ssh_key_id=ssh_key_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    ssh_key_id: UUID,
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | UserGetSshKeyResponse200 | UserGetSshKeyResponse429 | None:
    """Get a specific stored ssh-key.

    Args:
        ssh_key_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | UserGetSshKeyResponse200 | UserGetSshKeyResponse429
    """

    return sync_detailed(
        ssh_key_id=ssh_key_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    ssh_key_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | UserGetSshKeyResponse200 | UserGetSshKeyResponse429]:
    """Get a specific stored ssh-key.

    Args:
        ssh_key_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | UserGetSshKeyResponse200 | UserGetSshKeyResponse429]
    """

    kwargs = _get_kwargs(
        ssh_key_id=ssh_key_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    ssh_key_id: UUID,
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | UserGetSshKeyResponse200 | UserGetSshKeyResponse429 | None:
    """Get a specific stored ssh-key.

    Args:
        ssh_key_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | UserGetSshKeyResponse200 | UserGetSshKeyResponse429
    """

    return (
        await asyncio_detailed(
            ssh_key_id=ssh_key_id,
            client=client,
        )
    ).parsed
