from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.password_validation_get_password_policy_response_429 import (
    PasswordValidationGetPasswordPolicyResponse429,
)
from ...types import Response


def _get_kwargs(
    password_policy: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/password-policies/{password_policy}".format(
            password_policy=quote(str(password_policy), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | PasswordValidationGetPasswordPolicyResponse429 | str:
    if response.status_code == 200:
        response_200 = cast(str, response.json())
        return response_200

    if response.status_code == 429:
        response_429 = PasswordValidationGetPasswordPolicyResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | PasswordValidationGetPasswordPolicyResponse429 | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    password_policy: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeMittwaldV1CommonsError | PasswordValidationGetPasswordPolicyResponse429 | str]:
    """Get a PasswordPolicy.

    Args:
        password_policy (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | PasswordValidationGetPasswordPolicyResponse429 | str]
    """

    kwargs = _get_kwargs(
        password_policy=password_policy,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    password_policy: str,
    *,
    client: AuthenticatedClient | Client,
) -> DeMittwaldV1CommonsError | PasswordValidationGetPasswordPolicyResponse429 | str | None:
    """Get a PasswordPolicy.

    Args:
        password_policy (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | PasswordValidationGetPasswordPolicyResponse429 | str
    """

    return sync_detailed(
        password_policy=password_policy,
        client=client,
    ).parsed


async def asyncio_detailed(
    password_policy: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeMittwaldV1CommonsError | PasswordValidationGetPasswordPolicyResponse429 | str]:
    """Get a PasswordPolicy.

    Args:
        password_policy (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | PasswordValidationGetPasswordPolicyResponse429 | str]
    """

    kwargs = _get_kwargs(
        password_policy=password_policy,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    password_policy: str,
    *,
    client: AuthenticatedClient | Client,
) -> DeMittwaldV1CommonsError | PasswordValidationGetPasswordPolicyResponse429 | str | None:
    """Get a PasswordPolicy.

    Args:
        password_policy (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | PasswordValidationGetPasswordPolicyResponse429 | str
    """

    return (
        await asyncio_detailed(
            password_policy=password_policy,
            client=client,
        )
    ).parsed
