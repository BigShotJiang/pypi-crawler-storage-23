from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.user_support_code_request_response_200 import UserSupportCodeRequestResponse200
from ...models.user_support_code_request_response_429 import UserSupportCodeRequestResponse429
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    force_recreate: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["forceRecreate"] = force_recreate

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/users/self/credentials/support-code",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | UserSupportCodeRequestResponse200 | UserSupportCodeRequestResponse429:
    if response.status_code == 200:
        response_200 = UserSupportCodeRequestResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 429:
        response_429 = UserSupportCodeRequestResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | UserSupportCodeRequestResponse200 | UserSupportCodeRequestResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    force_recreate: bool | Unset = UNSET,
) -> Response[DeMittwaldV1CommonsError | UserSupportCodeRequestResponse200 | UserSupportCodeRequestResponse429]:
    """Request a support code.

    Args:
        force_recreate (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | UserSupportCodeRequestResponse200 | UserSupportCodeRequestResponse429]
    """

    kwargs = _get_kwargs(
        force_recreate=force_recreate,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    force_recreate: bool | Unset = UNSET,
) -> DeMittwaldV1CommonsError | UserSupportCodeRequestResponse200 | UserSupportCodeRequestResponse429 | None:
    """Request a support code.

    Args:
        force_recreate (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | UserSupportCodeRequestResponse200 | UserSupportCodeRequestResponse429
    """

    return sync_detailed(
        client=client,
        force_recreate=force_recreate,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    force_recreate: bool | Unset = UNSET,
) -> Response[DeMittwaldV1CommonsError | UserSupportCodeRequestResponse200 | UserSupportCodeRequestResponse429]:
    """Request a support code.

    Args:
        force_recreate (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | UserSupportCodeRequestResponse200 | UserSupportCodeRequestResponse429]
    """

    kwargs = _get_kwargs(
        force_recreate=force_recreate,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    force_recreate: bool | Unset = UNSET,
) -> DeMittwaldV1CommonsError | UserSupportCodeRequestResponse200 | UserSupportCodeRequestResponse429 | None:
    """Request a support code.

    Args:
        force_recreate (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | UserSupportCodeRequestResponse200 | UserSupportCodeRequestResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            force_recreate=force_recreate,
        )
    ).parsed
