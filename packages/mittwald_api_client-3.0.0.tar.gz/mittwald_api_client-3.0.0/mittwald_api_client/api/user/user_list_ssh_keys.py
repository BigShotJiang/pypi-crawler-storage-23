from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.user_list_ssh_keys_response_200 import UserListSshKeysResponse200
from ...models.user_list_ssh_keys_response_429 import UserListSshKeysResponse429
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/users/self/ssh-keys",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | UserListSshKeysResponse200 | UserListSshKeysResponse429:
    if response.status_code == 200:
        response_200 = UserListSshKeysResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 429:
        response_429 = UserListSshKeysResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | UserListSshKeysResponse200 | UserListSshKeysResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[DeMittwaldV1CommonsError | UserListSshKeysResponse200 | UserListSshKeysResponse429]:
    """Get your stored ssh-keys.

    Args:
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | UserListSshKeysResponse200 | UserListSshKeysResponse429]
    """

    kwargs = _get_kwargs(
        limit=limit,
        skip=skip,
        page=page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> DeMittwaldV1CommonsError | UserListSshKeysResponse200 | UserListSshKeysResponse429 | None:
    """Get your stored ssh-keys.

    Args:
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | UserListSshKeysResponse200 | UserListSshKeysResponse429
    """

    return sync_detailed(
        client=client,
        limit=limit,
        skip=skip,
        page=page,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[DeMittwaldV1CommonsError | UserListSshKeysResponse200 | UserListSshKeysResponse429]:
    """Get your stored ssh-keys.

    Args:
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | UserListSshKeysResponse200 | UserListSshKeysResponse429]
    """

    kwargs = _get_kwargs(
        limit=limit,
        skip=skip,
        page=page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> DeMittwaldV1CommonsError | UserListSshKeysResponse200 | UserListSshKeysResponse429 | None:
    """Get your stored ssh-keys.

    Args:
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | UserListSshKeysResponse200 | UserListSshKeysResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            skip=skip,
            page=page,
        )
    ).parsed
