from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.user_change_password_body import UserChangePasswordBody
from ...models.user_change_password_response_200 import UserChangePasswordResponse200
from ...models.user_change_password_response_202 import UserChangePasswordResponse202
from ...models.user_change_password_response_429 import UserChangePasswordResponse429
from ...types import Response


def _get_kwargs(
    *,
    body: UserChangePasswordBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v2/users/self/credentials/password",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | UserChangePasswordResponse200
    | UserChangePasswordResponse202
    | UserChangePasswordResponse429
):
    if response.status_code == 200:
        response_200 = UserChangePasswordResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 202:
        response_202 = UserChangePasswordResponse202.from_dict(response.json())

        return response_202

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 429:
        response_429 = UserChangePasswordResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | UserChangePasswordResponse200
    | UserChangePasswordResponse202
    | UserChangePasswordResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: UserChangePasswordBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | UserChangePasswordResponse200
    | UserChangePasswordResponse202
    | UserChangePasswordResponse429
]:
    """Change your password.

    Args:
        body (UserChangePasswordBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserChangePasswordResponse200 | UserChangePasswordResponse202 | UserChangePasswordResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: UserChangePasswordBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | UserChangePasswordResponse200
    | UserChangePasswordResponse202
    | UserChangePasswordResponse429
    | None
):
    """Change your password.

    Args:
        body (UserChangePasswordBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserChangePasswordResponse200 | UserChangePasswordResponse202 | UserChangePasswordResponse429
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: UserChangePasswordBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | UserChangePasswordResponse200
    | UserChangePasswordResponse202
    | UserChangePasswordResponse429
]:
    """Change your password.

    Args:
        body (UserChangePasswordBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserChangePasswordResponse200 | UserChangePasswordResponse202 | UserChangePasswordResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: UserChangePasswordBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | UserChangePasswordResponse200
    | UserChangePasswordResponse202
    | UserChangePasswordResponse429
    | None
):
    """Change your password.

    Args:
        body (UserChangePasswordBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserChangePasswordResponse200 | UserChangePasswordResponse202 | UserChangePasswordResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
