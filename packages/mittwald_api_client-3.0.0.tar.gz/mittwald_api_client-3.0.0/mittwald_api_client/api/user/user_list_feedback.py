from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_user_user_feedback import DeMittwaldV1UserUserFeedback
from ...models.user_list_feedback_response_429 import UserListFeedbackResponse429
from ...types import UNSET, Response, Unset


def _get_kwargs(
    user_id: str,
    *,
    subject: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["subject"] = subject

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/users/{user_id}/feedback".format(
            user_id=quote(str(user_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | UserListFeedbackResponse429 | list[DeMittwaldV1UserUserFeedback]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1UserUserFeedback.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = UserListFeedbackResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | UserListFeedbackResponse429 | list[DeMittwaldV1UserUserFeedback]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    user_id: str,
    *,
    client: AuthenticatedClient,
    subject: str | Unset = UNSET,
) -> Response[DeMittwaldV1CommonsError | UserListFeedbackResponse429 | list[DeMittwaldV1UserUserFeedback]]:
    """Submitted feedback of the given user.

    Args:
        user_id (str):
        subject (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | UserListFeedbackResponse429 | list[DeMittwaldV1UserUserFeedback]]
    """

    kwargs = _get_kwargs(
        user_id=user_id,
        subject=subject,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    user_id: str,
    *,
    client: AuthenticatedClient,
    subject: str | Unset = UNSET,
) -> DeMittwaldV1CommonsError | UserListFeedbackResponse429 | list[DeMittwaldV1UserUserFeedback] | None:
    """Submitted feedback of the given user.

    Args:
        user_id (str):
        subject (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | UserListFeedbackResponse429 | list[DeMittwaldV1UserUserFeedback]
    """

    return sync_detailed(
        user_id=user_id,
        client=client,
        subject=subject,
    ).parsed


async def asyncio_detailed(
    user_id: str,
    *,
    client: AuthenticatedClient,
    subject: str | Unset = UNSET,
) -> Response[DeMittwaldV1CommonsError | UserListFeedbackResponse429 | list[DeMittwaldV1UserUserFeedback]]:
    """Submitted feedback of the given user.

    Args:
        user_id (str):
        subject (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | UserListFeedbackResponse429 | list[DeMittwaldV1UserUserFeedback]]
    """

    kwargs = _get_kwargs(
        user_id=user_id,
        subject=subject,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    user_id: str,
    *,
    client: AuthenticatedClient,
    subject: str | Unset = UNSET,
) -> DeMittwaldV1CommonsError | UserListFeedbackResponse429 | list[DeMittwaldV1UserUserFeedback] | None:
    """Submitted feedback of the given user.

    Args:
        user_id (str):
        subject (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | UserListFeedbackResponse429 | list[DeMittwaldV1UserUserFeedback]
    """

    return (
        await asyncio_detailed(
            user_id=user_id,
            client=client,
            subject=subject,
        )
    ).parsed
