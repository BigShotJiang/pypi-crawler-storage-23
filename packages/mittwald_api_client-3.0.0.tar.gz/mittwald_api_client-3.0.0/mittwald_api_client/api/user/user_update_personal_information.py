from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.user_update_personal_information_body import UserUpdatePersonalInformationBody
from ...models.user_update_personal_information_response_429 import UserUpdatePersonalInformationResponse429
from ...types import Response


def _get_kwargs(
    user_id: str,
    *,
    body: UserUpdatePersonalInformationBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v2/users/{user_id}".format(
            user_id=quote(str(user_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserUpdatePersonalInformationResponse429:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 429:
        response_429 = UserUpdatePersonalInformationResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserUpdatePersonalInformationResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    user_id: str,
    *,
    client: AuthenticatedClient,
    body: UserUpdatePersonalInformationBody,
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserUpdatePersonalInformationResponse429
]:
    """Change personal information.

    Args:
        user_id (str):
        body (UserUpdatePersonalInformationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserUpdatePersonalInformationResponse429]
    """

    kwargs = _get_kwargs(
        user_id=user_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    user_id: str,
    *,
    client: AuthenticatedClient,
    body: UserUpdatePersonalInformationBody,
) -> (
    Any
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | UserUpdatePersonalInformationResponse429
    | None
):
    """Change personal information.

    Args:
        user_id (str):
        body (UserUpdatePersonalInformationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserUpdatePersonalInformationResponse429
    """

    return sync_detailed(
        user_id=user_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    user_id: str,
    *,
    client: AuthenticatedClient,
    body: UserUpdatePersonalInformationBody,
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserUpdatePersonalInformationResponse429
]:
    """Change personal information.

    Args:
        user_id (str):
        body (UserUpdatePersonalInformationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserUpdatePersonalInformationResponse429]
    """

    kwargs = _get_kwargs(
        user_id=user_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    user_id: str,
    *,
    client: AuthenticatedClient,
    body: UserUpdatePersonalInformationBody,
) -> (
    Any
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | UserUpdatePersonalInformationResponse429
    | None
):
    """Change personal information.

    Args:
        user_id (str):
        body (UserUpdatePersonalInformationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | UserUpdatePersonalInformationResponse429
    """

    return (
        await asyncio_detailed(
            user_id=user_id,
            client=client,
            body=body,
        )
    ).parsed
