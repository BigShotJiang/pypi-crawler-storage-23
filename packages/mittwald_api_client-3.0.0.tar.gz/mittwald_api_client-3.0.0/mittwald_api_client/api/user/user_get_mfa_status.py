from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.user_get_mfa_status_response_200 import UserGetMfaStatusResponse200
from ...models.user_get_mfa_status_response_429 import UserGetMfaStatusResponse429
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/users/self/credentials/mfa",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | UserGetMfaStatusResponse200 | UserGetMfaStatusResponse429:
    if response.status_code == 200:
        response_200 = UserGetMfaStatusResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 429:
        response_429 = UserGetMfaStatusResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | UserGetMfaStatusResponse200 | UserGetMfaStatusResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | UserGetMfaStatusResponse200 | UserGetMfaStatusResponse429]:
    """Get your current multi factor auth status.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | UserGetMfaStatusResponse200 | UserGetMfaStatusResponse429]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | UserGetMfaStatusResponse200 | UserGetMfaStatusResponse429 | None:
    """Get your current multi factor auth status.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | UserGetMfaStatusResponse200 | UserGetMfaStatusResponse429
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | UserGetMfaStatusResponse200 | UserGetMfaStatusResponse429]:
    """Get your current multi factor auth status.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | UserGetMfaStatusResponse200 | UserGetMfaStatusResponse429]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | UserGetMfaStatusResponse200 | UserGetMfaStatusResponse429 | None:
    """Get your current multi factor auth status.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | UserGetMfaStatusResponse200 | UserGetMfaStatusResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
