from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.customer_list_customer_memberships_response_429 import CustomerListCustomerMembershipsResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_membership_customer_membership import DeMittwaldV1MembershipCustomerMembership
from ...models.de_mittwald_v1_membership_customer_roles import DeMittwaldV1MembershipCustomerRoles
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    page: int | Unset = UNSET,
    has_expiry: bool | Unset = UNSET,
    role: DeMittwaldV1MembershipCustomerRoles | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    params["hasExpiry"] = has_expiry

    json_role: str | Unset = UNSET
    if not isinstance(role, Unset):
        json_role = role.value

    params["role"] = json_role

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/customer-memberships",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    CustomerListCustomerMembershipsResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MembershipCustomerMembership]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1MembershipCustomerMembership.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = CustomerListCustomerMembershipsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    CustomerListCustomerMembershipsResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MembershipCustomerMembership]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    page: int | Unset = UNSET,
    has_expiry: bool | Unset = UNSET,
    role: DeMittwaldV1MembershipCustomerRoles | Unset = UNSET,
) -> Response[
    CustomerListCustomerMembershipsResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MembershipCustomerMembership]
]:
    """List CustomerMemberships belonging to the executing user.

    Args:
        limit (int | Unset):
        skip (int | Unset):
        page (int | Unset):
        has_expiry (bool | Unset):
        role (DeMittwaldV1MembershipCustomerRoles | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CustomerListCustomerMembershipsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1MembershipCustomerMembership]]
    """

    kwargs = _get_kwargs(
        limit=limit,
        skip=skip,
        page=page,
        has_expiry=has_expiry,
        role=role,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    page: int | Unset = UNSET,
    has_expiry: bool | Unset = UNSET,
    role: DeMittwaldV1MembershipCustomerRoles | Unset = UNSET,
) -> (
    CustomerListCustomerMembershipsResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MembershipCustomerMembership]
    | None
):
    """List CustomerMemberships belonging to the executing user.

    Args:
        limit (int | Unset):
        skip (int | Unset):
        page (int | Unset):
        has_expiry (bool | Unset):
        role (DeMittwaldV1MembershipCustomerRoles | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CustomerListCustomerMembershipsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1MembershipCustomerMembership]
    """

    return sync_detailed(
        client=client,
        limit=limit,
        skip=skip,
        page=page,
        has_expiry=has_expiry,
        role=role,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    page: int | Unset = UNSET,
    has_expiry: bool | Unset = UNSET,
    role: DeMittwaldV1MembershipCustomerRoles | Unset = UNSET,
) -> Response[
    CustomerListCustomerMembershipsResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MembershipCustomerMembership]
]:
    """List CustomerMemberships belonging to the executing user.

    Args:
        limit (int | Unset):
        skip (int | Unset):
        page (int | Unset):
        has_expiry (bool | Unset):
        role (DeMittwaldV1MembershipCustomerRoles | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CustomerListCustomerMembershipsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1MembershipCustomerMembership]]
    """

    kwargs = _get_kwargs(
        limit=limit,
        skip=skip,
        page=page,
        has_expiry=has_expiry,
        role=role,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    page: int | Unset = UNSET,
    has_expiry: bool | Unset = UNSET,
    role: DeMittwaldV1MembershipCustomerRoles | Unset = UNSET,
) -> (
    CustomerListCustomerMembershipsResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1MembershipCustomerMembership]
    | None
):
    """List CustomerMemberships belonging to the executing user.

    Args:
        limit (int | Unset):
        skip (int | Unset):
        page (int | Unset):
        has_expiry (bool | Unset):
        role (DeMittwaldV1MembershipCustomerRoles | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CustomerListCustomerMembershipsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1MembershipCustomerMembership]
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            skip=skip,
            page=page,
            has_expiry=has_expiry,
            role=role,
        )
    ).parsed
