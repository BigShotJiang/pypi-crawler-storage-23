from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.customer_update_customer_membership_body import CustomerUpdateCustomerMembershipBody
from ...models.customer_update_customer_membership_response_429 import CustomerUpdateCustomerMembershipResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import Response


def _get_kwargs(
    customer_membership_id: UUID,
    *,
    body: CustomerUpdateCustomerMembershipBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v2/customer-memberships/{customer_membership_id}".format(
            customer_membership_id=quote(str(customer_membership_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | CustomerUpdateCustomerMembershipResponse429 | DeMittwaldV1CommonsError:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 429:
        response_429 = CustomerUpdateCustomerMembershipResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | CustomerUpdateCustomerMembershipResponse429 | DeMittwaldV1CommonsError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    customer_membership_id: UUID,
    *,
    client: AuthenticatedClient,
    body: CustomerUpdateCustomerMembershipBody,
) -> Response[Any | CustomerUpdateCustomerMembershipResponse429 | DeMittwaldV1CommonsError]:
    """Update a CustomerMembership.

    Args:
        customer_membership_id (UUID):
        body (CustomerUpdateCustomerMembershipBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CustomerUpdateCustomerMembershipResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        customer_membership_id=customer_membership_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    customer_membership_id: UUID,
    *,
    client: AuthenticatedClient,
    body: CustomerUpdateCustomerMembershipBody,
) -> Any | CustomerUpdateCustomerMembershipResponse429 | DeMittwaldV1CommonsError | None:
    """Update a CustomerMembership.

    Args:
        customer_membership_id (UUID):
        body (CustomerUpdateCustomerMembershipBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CustomerUpdateCustomerMembershipResponse429 | DeMittwaldV1CommonsError
    """

    return sync_detailed(
        customer_membership_id=customer_membership_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    customer_membership_id: UUID,
    *,
    client: AuthenticatedClient,
    body: CustomerUpdateCustomerMembershipBody,
) -> Response[Any | CustomerUpdateCustomerMembershipResponse429 | DeMittwaldV1CommonsError]:
    """Update a CustomerMembership.

    Args:
        customer_membership_id (UUID):
        body (CustomerUpdateCustomerMembershipBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CustomerUpdateCustomerMembershipResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        customer_membership_id=customer_membership_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    customer_membership_id: UUID,
    *,
    client: AuthenticatedClient,
    body: CustomerUpdateCustomerMembershipBody,
) -> Any | CustomerUpdateCustomerMembershipResponse429 | DeMittwaldV1CommonsError | None:
    """Update a CustomerMembership.

    Args:
        customer_membership_id (UUID):
        body (CustomerUpdateCustomerMembershipBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CustomerUpdateCustomerMembershipResponse429 | DeMittwaldV1CommonsError
    """

    return (
        await asyncio_detailed(
            customer_membership_id=customer_membership_id,
            client=client,
            body=body,
        )
    ).parsed
