from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.customer_request_avatar_upload_body import CustomerRequestAvatarUploadBody
from ...models.customer_request_avatar_upload_response_200 import CustomerRequestAvatarUploadResponse200
from ...models.customer_request_avatar_upload_response_401 import CustomerRequestAvatarUploadResponse401
from ...models.customer_request_avatar_upload_response_429 import CustomerRequestAvatarUploadResponse429
from ...models.customer_request_avatar_upload_response_500 import CustomerRequestAvatarUploadResponse500
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...types import UNSET, Response, Unset


def _get_kwargs(
    customer_id: str,
    *,
    body: CustomerRequestAvatarUploadBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/customers/{customer_id}/avatar".format(
            customer_id=quote(str(customer_id), safe=""),
        ),
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    CustomerRequestAvatarUploadResponse200
    | CustomerRequestAvatarUploadResponse401
    | CustomerRequestAvatarUploadResponse429
    | CustomerRequestAvatarUploadResponse500
    | DeMittwaldV1CommonsValidationErrors
    | None
):
    if response.status_code == 200:
        response_200 = CustomerRequestAvatarUploadResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = CustomerRequestAvatarUploadResponse401.from_dict(response.json())

        return response_401

    if response.status_code == 429:
        response_429 = CustomerRequestAvatarUploadResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = CustomerRequestAvatarUploadResponse500.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    CustomerRequestAvatarUploadResponse200
    | CustomerRequestAvatarUploadResponse401
    | CustomerRequestAvatarUploadResponse429
    | CustomerRequestAvatarUploadResponse500
    | DeMittwaldV1CommonsValidationErrors
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    customer_id: str,
    *,
    client: AuthenticatedClient,
    body: CustomerRequestAvatarUploadBody | Unset = UNSET,
) -> Response[
    CustomerRequestAvatarUploadResponse200
    | CustomerRequestAvatarUploadResponse401
    | CustomerRequestAvatarUploadResponse429
    | CustomerRequestAvatarUploadResponse500
    | DeMittwaldV1CommonsValidationErrors
]:
    """Request a new avatar upload for the customer profile.

    Args:
        customer_id (str):
        body (CustomerRequestAvatarUploadBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CustomerRequestAvatarUploadResponse200 | CustomerRequestAvatarUploadResponse401 | CustomerRequestAvatarUploadResponse429 | CustomerRequestAvatarUploadResponse500 | DeMittwaldV1CommonsValidationErrors]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    customer_id: str,
    *,
    client: AuthenticatedClient,
    body: CustomerRequestAvatarUploadBody | Unset = UNSET,
) -> (
    CustomerRequestAvatarUploadResponse200
    | CustomerRequestAvatarUploadResponse401
    | CustomerRequestAvatarUploadResponse429
    | CustomerRequestAvatarUploadResponse500
    | DeMittwaldV1CommonsValidationErrors
    | None
):
    """Request a new avatar upload for the customer profile.

    Args:
        customer_id (str):
        body (CustomerRequestAvatarUploadBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CustomerRequestAvatarUploadResponse200 | CustomerRequestAvatarUploadResponse401 | CustomerRequestAvatarUploadResponse429 | CustomerRequestAvatarUploadResponse500 | DeMittwaldV1CommonsValidationErrors
    """

    return sync_detailed(
        customer_id=customer_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    customer_id: str,
    *,
    client: AuthenticatedClient,
    body: CustomerRequestAvatarUploadBody | Unset = UNSET,
) -> Response[
    CustomerRequestAvatarUploadResponse200
    | CustomerRequestAvatarUploadResponse401
    | CustomerRequestAvatarUploadResponse429
    | CustomerRequestAvatarUploadResponse500
    | DeMittwaldV1CommonsValidationErrors
]:
    """Request a new avatar upload for the customer profile.

    Args:
        customer_id (str):
        body (CustomerRequestAvatarUploadBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CustomerRequestAvatarUploadResponse200 | CustomerRequestAvatarUploadResponse401 | CustomerRequestAvatarUploadResponse429 | CustomerRequestAvatarUploadResponse500 | DeMittwaldV1CommonsValidationErrors]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    customer_id: str,
    *,
    client: AuthenticatedClient,
    body: CustomerRequestAvatarUploadBody | Unset = UNSET,
) -> (
    CustomerRequestAvatarUploadResponse200
    | CustomerRequestAvatarUploadResponse401
    | CustomerRequestAvatarUploadResponse429
    | CustomerRequestAvatarUploadResponse500
    | DeMittwaldV1CommonsValidationErrors
    | None
):
    """Request a new avatar upload for the customer profile.

    Args:
        customer_id (str):
        body (CustomerRequestAvatarUploadBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CustomerRequestAvatarUploadResponse200 | CustomerRequestAvatarUploadResponse401 | CustomerRequestAvatarUploadResponse429 | CustomerRequestAvatarUploadResponse500 | DeMittwaldV1CommonsValidationErrors
    """

    return (
        await asyncio_detailed(
            customer_id=customer_id,
            client=client,
            body=body,
        )
    ).parsed
