from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.app_get_appversion_response_429 import AppGetAppversionResponse429
from ...models.de_mittwald_v1_app_app_version import DeMittwaldV1AppAppVersion
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import Response


def _get_kwargs(
    app_id: UUID,
    app_version_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/apps/{app_id}/versions/{app_version_id}".format(
            app_id=quote(str(app_id), safe=""),
            app_version_id=quote(str(app_version_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AppGetAppversionResponse429 | DeMittwaldV1AppAppVersion | DeMittwaldV1CommonsError:
    if response.status_code == 200:
        response_200 = DeMittwaldV1AppAppVersion.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = AppGetAppversionResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AppGetAppversionResponse429 | DeMittwaldV1AppAppVersion | DeMittwaldV1CommonsError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: UUID,
    app_version_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[AppGetAppversionResponse429 | DeMittwaldV1AppAppVersion | DeMittwaldV1CommonsError]:
    """Get an AppVersion.

    Args:
        app_id (UUID):
        app_version_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppGetAppversionResponse429 | DeMittwaldV1AppAppVersion | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        app_version_id=app_version_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: UUID,
    app_version_id: UUID,
    *,
    client: AuthenticatedClient,
) -> AppGetAppversionResponse429 | DeMittwaldV1AppAppVersion | DeMittwaldV1CommonsError | None:
    """Get an AppVersion.

    Args:
        app_id (UUID):
        app_version_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppGetAppversionResponse429 | DeMittwaldV1AppAppVersion | DeMittwaldV1CommonsError
    """

    return sync_detailed(
        app_id=app_id,
        app_version_id=app_version_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    app_id: UUID,
    app_version_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[AppGetAppversionResponse429 | DeMittwaldV1AppAppVersion | DeMittwaldV1CommonsError]:
    """Get an AppVersion.

    Args:
        app_id (UUID):
        app_version_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppGetAppversionResponse429 | DeMittwaldV1AppAppVersion | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        app_version_id=app_version_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: UUID,
    app_version_id: UUID,
    *,
    client: AuthenticatedClient,
) -> AppGetAppversionResponse429 | DeMittwaldV1AppAppVersion | DeMittwaldV1CommonsError | None:
    """Get an AppVersion.

    Args:
        app_id (UUID):
        app_version_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppGetAppversionResponse429 | DeMittwaldV1AppAppVersion | DeMittwaldV1CommonsError
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            app_version_id=app_version_id,
            client=client,
        )
    ).parsed
