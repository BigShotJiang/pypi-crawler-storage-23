from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.app_list_appinstallations_response_429 import AppListAppinstallationsResponse429
from ...models.de_mittwald_v1_app_app_installation import DeMittwaldV1AppAppInstallation
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    project_id: str,
    *,
    app_ids: list[UUID] | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_app_ids: list[str] | Unset = UNSET
    if not isinstance(app_ids, Unset):
        json_app_ids = []
        for app_ids_item_data in app_ids:
            app_ids_item = str(app_ids_item_data)
            json_app_ids.append(app_ids_item)

    params["appIds"] = json_app_ids

    params["searchTerm"] = search_term

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects/{project_id}/app-installations".format(
            project_id=quote(str(project_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AppListAppinstallationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1AppAppInstallation.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = AppListAppinstallationsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AppListAppinstallationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    app_ids: list[UUID] | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[AppListAppinstallationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]]:
    """List AppInstallations belonging to a Project.

    Args:
        project_id (str):
        app_ids (list[UUID] | Unset):
        search_term (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppListAppinstallationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        app_ids=app_ids,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    app_ids: list[UUID] | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> AppListAppinstallationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation] | None:
    """List AppInstallations belonging to a Project.

    Args:
        project_id (str):
        app_ids (list[UUID] | Unset):
        search_term (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppListAppinstallationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        app_ids=app_ids,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    app_ids: list[UUID] | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[AppListAppinstallationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]]:
    """List AppInstallations belonging to a Project.

    Args:
        project_id (str):
        app_ids (list[UUID] | Unset):
        search_term (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppListAppinstallationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        app_ids=app_ids,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    app_ids: list[UUID] | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> AppListAppinstallationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation] | None:
    """List AppInstallations belonging to a Project.

    Args:
        project_id (str):
        app_ids (list[UUID] | Unset):
        search_term (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppListAppinstallationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            app_ids=app_ids,
            search_term=search_term,
            limit=limit,
            skip=skip,
            page=page,
        )
    ).parsed
