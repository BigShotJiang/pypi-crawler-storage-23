from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.app_get_missing_dependencies_for_appinstallation_response_200 import (
    AppGetMissingDependenciesForAppinstallationResponse200,
)
from ...models.app_get_missing_dependencies_for_appinstallation_response_429 import (
    AppGetMissingDependenciesForAppinstallationResponse429,
)
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import UNSET, Response


def _get_kwargs(
    app_installation_id: str,
    *,
    target_app_version_id: UUID,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_target_app_version_id = str(target_app_version_id)
    params["targetAppVersionID"] = json_target_app_version_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/app-installations/{app_installation_id}/missing-dependencies".format(
            app_installation_id=quote(str(app_installation_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    AppGetMissingDependenciesForAppinstallationResponse200
    | AppGetMissingDependenciesForAppinstallationResponse429
    | DeMittwaldV1CommonsError
):
    if response.status_code == 200:
        response_200 = AppGetMissingDependenciesForAppinstallationResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = AppGetMissingDependenciesForAppinstallationResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    AppGetMissingDependenciesForAppinstallationResponse200
    | AppGetMissingDependenciesForAppinstallationResponse429
    | DeMittwaldV1CommonsError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_installation_id: str,
    *,
    client: AuthenticatedClient,
    target_app_version_id: UUID,
) -> Response[
    AppGetMissingDependenciesForAppinstallationResponse200
    | AppGetMissingDependenciesForAppinstallationResponse429
    | DeMittwaldV1CommonsError
]:
    """Get the missing requirements of an appInstallation for a specific target AppVersion.

    Args:
        app_installation_id (str):
        target_app_version_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppGetMissingDependenciesForAppinstallationResponse200 | AppGetMissingDependenciesForAppinstallationResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        app_installation_id=app_installation_id,
        target_app_version_id=target_app_version_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_installation_id: str,
    *,
    client: AuthenticatedClient,
    target_app_version_id: UUID,
) -> (
    AppGetMissingDependenciesForAppinstallationResponse200
    | AppGetMissingDependenciesForAppinstallationResponse429
    | DeMittwaldV1CommonsError
    | None
):
    """Get the missing requirements of an appInstallation for a specific target AppVersion.

    Args:
        app_installation_id (str):
        target_app_version_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppGetMissingDependenciesForAppinstallationResponse200 | AppGetMissingDependenciesForAppinstallationResponse429 | DeMittwaldV1CommonsError
    """

    return sync_detailed(
        app_installation_id=app_installation_id,
        client=client,
        target_app_version_id=target_app_version_id,
    ).parsed


async def asyncio_detailed(
    app_installation_id: str,
    *,
    client: AuthenticatedClient,
    target_app_version_id: UUID,
) -> Response[
    AppGetMissingDependenciesForAppinstallationResponse200
    | AppGetMissingDependenciesForAppinstallationResponse429
    | DeMittwaldV1CommonsError
]:
    """Get the missing requirements of an appInstallation for a specific target AppVersion.

    Args:
        app_installation_id (str):
        target_app_version_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppGetMissingDependenciesForAppinstallationResponse200 | AppGetMissingDependenciesForAppinstallationResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        app_installation_id=app_installation_id,
        target_app_version_id=target_app_version_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_installation_id: str,
    *,
    client: AuthenticatedClient,
    target_app_version_id: UUID,
) -> (
    AppGetMissingDependenciesForAppinstallationResponse200
    | AppGetMissingDependenciesForAppinstallationResponse429
    | DeMittwaldV1CommonsError
    | None
):
    """Get the missing requirements of an appInstallation for a specific target AppVersion.

    Args:
        app_installation_id (str):
        target_app_version_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppGetMissingDependenciesForAppinstallationResponse200 | AppGetMissingDependenciesForAppinstallationResponse429 | DeMittwaldV1CommonsError
    """

    return (
        await asyncio_detailed(
            app_installation_id=app_installation_id,
            client=client,
            target_app_version_id=target_app_version_id,
        )
    ).parsed
