from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.app_list_systemsoftwareversions_response_429 import AppListSystemsoftwareversionsResponse429
from ...models.de_mittwald_v1_app_system_software_version import DeMittwaldV1AppSystemSoftwareVersion
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    system_software_id: UUID,
    *,
    version_range: str | Unset = UNSET,
    recommended: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["versionRange"] = version_range

    params["recommended"] = recommended

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/system-softwares/{system_software_id}/versions".format(
            system_software_id=quote(str(system_software_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AppListSystemsoftwareversionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftwareVersion]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1AppSystemSoftwareVersion.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = AppListSystemsoftwareversionsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    AppListSystemsoftwareversionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftwareVersion]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    system_software_id: UUID,
    *,
    client: AuthenticatedClient,
    version_range: str | Unset = UNSET,
    recommended: bool | Unset = UNSET,
) -> Response[
    AppListSystemsoftwareversionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftwareVersion]
]:
    """List SystemSoftwareVersions belonging to a SystemSoftware.

    Args:
        system_software_id (UUID):
        version_range (str | Unset):
        recommended (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppListSystemsoftwareversionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftwareVersion]]
    """

    kwargs = _get_kwargs(
        system_software_id=system_software_id,
        version_range=version_range,
        recommended=recommended,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    system_software_id: UUID,
    *,
    client: AuthenticatedClient,
    version_range: str | Unset = UNSET,
    recommended: bool | Unset = UNSET,
) -> (
    AppListSystemsoftwareversionsResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1AppSystemSoftwareVersion]
    | None
):
    """List SystemSoftwareVersions belonging to a SystemSoftware.

    Args:
        system_software_id (UUID):
        version_range (str | Unset):
        recommended (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppListSystemsoftwareversionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftwareVersion]
    """

    return sync_detailed(
        system_software_id=system_software_id,
        client=client,
        version_range=version_range,
        recommended=recommended,
    ).parsed


async def asyncio_detailed(
    system_software_id: UUID,
    *,
    client: AuthenticatedClient,
    version_range: str | Unset = UNSET,
    recommended: bool | Unset = UNSET,
) -> Response[
    AppListSystemsoftwareversionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftwareVersion]
]:
    """List SystemSoftwareVersions belonging to a SystemSoftware.

    Args:
        system_software_id (UUID):
        version_range (str | Unset):
        recommended (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppListSystemsoftwareversionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftwareVersion]]
    """

    kwargs = _get_kwargs(
        system_software_id=system_software_id,
        version_range=version_range,
        recommended=recommended,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    system_software_id: UUID,
    *,
    client: AuthenticatedClient,
    version_range: str | Unset = UNSET,
    recommended: bool | Unset = UNSET,
) -> (
    AppListSystemsoftwareversionsResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1AppSystemSoftwareVersion]
    | None
):
    """List SystemSoftwareVersions belonging to a SystemSoftware.

    Args:
        system_software_id (UUID):
        version_range (str | Unset):
        recommended (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppListSystemsoftwareversionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftwareVersion]
    """

    return (
        await asyncio_detailed(
            system_software_id=system_software_id,
            client=client,
            version_range=version_range,
            recommended=recommended,
        )
    ).parsed
