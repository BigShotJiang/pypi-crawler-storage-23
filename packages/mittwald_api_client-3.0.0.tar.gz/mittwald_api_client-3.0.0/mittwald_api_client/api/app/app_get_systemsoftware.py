from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.app_get_systemsoftware_response_429 import AppGetSystemsoftwareResponse429
from ...models.de_mittwald_v1_app_system_software import DeMittwaldV1AppSystemSoftware
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import Response


def _get_kwargs(
    system_software_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/system-softwares/{system_software_id}".format(
            system_software_id=quote(str(system_software_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AppGetSystemsoftwareResponse429 | DeMittwaldV1AppSystemSoftware | DeMittwaldV1CommonsError:
    if response.status_code == 200:
        response_200 = DeMittwaldV1AppSystemSoftware.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = AppGetSystemsoftwareResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AppGetSystemsoftwareResponse429 | DeMittwaldV1AppSystemSoftware | DeMittwaldV1CommonsError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    system_software_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[AppGetSystemsoftwareResponse429 | DeMittwaldV1AppSystemSoftware | DeMittwaldV1CommonsError]:
    """Get a SystemSoftware.

    Args:
        system_software_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppGetSystemsoftwareResponse429 | DeMittwaldV1AppSystemSoftware | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        system_software_id=system_software_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    system_software_id: UUID,
    *,
    client: AuthenticatedClient,
) -> AppGetSystemsoftwareResponse429 | DeMittwaldV1AppSystemSoftware | DeMittwaldV1CommonsError | None:
    """Get a SystemSoftware.

    Args:
        system_software_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppGetSystemsoftwareResponse429 | DeMittwaldV1AppSystemSoftware | DeMittwaldV1CommonsError
    """

    return sync_detailed(
        system_software_id=system_software_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    system_software_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[AppGetSystemsoftwareResponse429 | DeMittwaldV1AppSystemSoftware | DeMittwaldV1CommonsError]:
    """Get a SystemSoftware.

    Args:
        system_software_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppGetSystemsoftwareResponse429 | DeMittwaldV1AppSystemSoftware | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        system_software_id=system_software_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    system_software_id: UUID,
    *,
    client: AuthenticatedClient,
) -> AppGetSystemsoftwareResponse429 | DeMittwaldV1AppSystemSoftware | DeMittwaldV1CommonsError | None:
    """Get a SystemSoftware.

    Args:
        system_software_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppGetSystemsoftwareResponse429 | DeMittwaldV1AppSystemSoftware | DeMittwaldV1CommonsError
    """

    return (
        await asyncio_detailed(
            system_software_id=system_software_id,
            client=client,
        )
    ).parsed
