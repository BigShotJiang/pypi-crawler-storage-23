from http import HTTPStatus
from typing import Any
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.app_list_appinstallations_for_user_response_429 import AppListAppinstallationsForUserResponse429
from ...models.de_mittwald_v1_app_app_installation import DeMittwaldV1AppAppInstallation
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    app_ids: list[UUID] | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_app_ids: list[str] | Unset = UNSET
    if not isinstance(app_ids, Unset):
        json_app_ids = []
        for app_ids_item_data in app_ids:
            app_ids_item = str(app_ids_item_data)
            json_app_ids.append(app_ids_item)

    params["appIds"] = json_app_ids

    params["searchTerm"] = search_term

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/app-installations",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AppListAppinstallationsForUserResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1AppAppInstallation.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = AppListAppinstallationsForUserResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    AppListAppinstallationsForUserResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    app_ids: list[UUID] | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[
    AppListAppinstallationsForUserResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]
]:
    """List AppInstallations that a user has access to.

    Args:
        app_ids (list[UUID] | Unset):
        search_term (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppListAppinstallationsForUserResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]]
    """

    kwargs = _get_kwargs(
        app_ids=app_ids,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    app_ids: list[UUID] | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> AppListAppinstallationsForUserResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation] | None:
    """List AppInstallations that a user has access to.

    Args:
        app_ids (list[UUID] | Unset):
        search_term (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppListAppinstallationsForUserResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]
    """

    return sync_detailed(
        client=client,
        app_ids=app_ids,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    app_ids: list[UUID] | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[
    AppListAppinstallationsForUserResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]
]:
    """List AppInstallations that a user has access to.

    Args:
        app_ids (list[UUID] | Unset):
        search_term (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppListAppinstallationsForUserResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]]
    """

    kwargs = _get_kwargs(
        app_ids=app_ids,
        search_term=search_term,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    app_ids: list[UUID] | Unset = UNSET,
    search_term: str | Unset = UNSET,
    limit: int | Unset = UNSET,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> AppListAppinstallationsForUserResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation] | None:
    """List AppInstallations that a user has access to.

    Args:
        app_ids (list[UUID] | Unset):
        search_term (str | Unset):
        limit (int | Unset):
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppListAppinstallationsForUserResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppAppInstallation]
    """

    return (
        await asyncio_detailed(
            client=client,
            app_ids=app_ids,
            search_term=search_term,
            limit=limit,
            skip=skip,
            page=page,
        )
    ).parsed
