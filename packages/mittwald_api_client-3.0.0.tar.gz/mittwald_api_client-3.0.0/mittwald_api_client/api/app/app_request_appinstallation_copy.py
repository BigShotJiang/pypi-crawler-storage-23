from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.app_request_appinstallation_copy_body import AppRequestAppinstallationCopyBody
from ...models.app_request_appinstallation_copy_response_201 import AppRequestAppinstallationCopyResponse201
from ...models.app_request_appinstallation_copy_response_429 import AppRequestAppinstallationCopyResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import Response


def _get_kwargs(
    app_installation_id: UUID,
    *,
    body: AppRequestAppinstallationCopyBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/app-installations/{app_installation_id}/actions/copy".format(
            app_installation_id=quote(str(app_installation_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AppRequestAppinstallationCopyResponse201 | AppRequestAppinstallationCopyResponse429 | DeMittwaldV1CommonsError:
    if response.status_code == 201:
        response_201 = AppRequestAppinstallationCopyResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = AppRequestAppinstallationCopyResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    AppRequestAppinstallationCopyResponse201 | AppRequestAppinstallationCopyResponse429 | DeMittwaldV1CommonsError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_installation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AppRequestAppinstallationCopyBody,
) -> Response[
    AppRequestAppinstallationCopyResponse201 | AppRequestAppinstallationCopyResponse429 | DeMittwaldV1CommonsError
]:
    """Request a copy of an AppInstallation.

    Args:
        app_installation_id (UUID):
        body (AppRequestAppinstallationCopyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppRequestAppinstallationCopyResponse201 | AppRequestAppinstallationCopyResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        app_installation_id=app_installation_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_installation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AppRequestAppinstallationCopyBody,
) -> (
    AppRequestAppinstallationCopyResponse201
    | AppRequestAppinstallationCopyResponse429
    | DeMittwaldV1CommonsError
    | None
):
    """Request a copy of an AppInstallation.

    Args:
        app_installation_id (UUID):
        body (AppRequestAppinstallationCopyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppRequestAppinstallationCopyResponse201 | AppRequestAppinstallationCopyResponse429 | DeMittwaldV1CommonsError
    """

    return sync_detailed(
        app_installation_id=app_installation_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    app_installation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AppRequestAppinstallationCopyBody,
) -> Response[
    AppRequestAppinstallationCopyResponse201 | AppRequestAppinstallationCopyResponse429 | DeMittwaldV1CommonsError
]:
    """Request a copy of an AppInstallation.

    Args:
        app_installation_id (UUID):
        body (AppRequestAppinstallationCopyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppRequestAppinstallationCopyResponse201 | AppRequestAppinstallationCopyResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        app_installation_id=app_installation_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_installation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: AppRequestAppinstallationCopyBody,
) -> (
    AppRequestAppinstallationCopyResponse201
    | AppRequestAppinstallationCopyResponse429
    | DeMittwaldV1CommonsError
    | None
):
    """Request a copy of an AppInstallation.

    Args:
        app_installation_id (UUID):
        body (AppRequestAppinstallationCopyBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppRequestAppinstallationCopyResponse201 | AppRequestAppinstallationCopyResponse429 | DeMittwaldV1CommonsError
    """

    return (
        await asyncio_detailed(
            app_installation_id=app_installation_id,
            client=client,
            body=body,
        )
    ).parsed
