from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.app_get_installed_systemsoftware_for_appinstallation_response_429 import (
    AppGetInstalledSystemsoftwareForAppinstallationResponse429,
)
from ...models.de_mittwald_v1_app_system_software import DeMittwaldV1AppSystemSoftware
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_installation_id: str,
    *,
    tag_filter: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["tagFilter"] = tag_filter

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/app-installations/{app_installation_id}/systemSoftware".format(
            app_installation_id=quote(str(app_installation_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    AppGetInstalledSystemsoftwareForAppinstallationResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1AppSystemSoftware]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1AppSystemSoftware.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = AppGetInstalledSystemsoftwareForAppinstallationResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    AppGetInstalledSystemsoftwareForAppinstallationResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1AppSystemSoftware]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_installation_id: str,
    *,
    client: AuthenticatedClient,
    tag_filter: str | Unset = UNSET,
) -> Response[
    AppGetInstalledSystemsoftwareForAppinstallationResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1AppSystemSoftware]
]:
    """Get the installed `SystemSoftware' for a specific `AppInstallation`.

    Args:
        app_installation_id (str):
        tag_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppGetInstalledSystemsoftwareForAppinstallationResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftware]]
    """

    kwargs = _get_kwargs(
        app_installation_id=app_installation_id,
        tag_filter=tag_filter,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_installation_id: str,
    *,
    client: AuthenticatedClient,
    tag_filter: str | Unset = UNSET,
) -> (
    AppGetInstalledSystemsoftwareForAppinstallationResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1AppSystemSoftware]
    | None
):
    """Get the installed `SystemSoftware' for a specific `AppInstallation`.

    Args:
        app_installation_id (str):
        tag_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppGetInstalledSystemsoftwareForAppinstallationResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftware]
    """

    return sync_detailed(
        app_installation_id=app_installation_id,
        client=client,
        tag_filter=tag_filter,
    ).parsed


async def asyncio_detailed(
    app_installation_id: str,
    *,
    client: AuthenticatedClient,
    tag_filter: str | Unset = UNSET,
) -> Response[
    AppGetInstalledSystemsoftwareForAppinstallationResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1AppSystemSoftware]
]:
    """Get the installed `SystemSoftware' for a specific `AppInstallation`.

    Args:
        app_installation_id (str):
        tag_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppGetInstalledSystemsoftwareForAppinstallationResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftware]]
    """

    kwargs = _get_kwargs(
        app_installation_id=app_installation_id,
        tag_filter=tag_filter,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_installation_id: str,
    *,
    client: AuthenticatedClient,
    tag_filter: str | Unset = UNSET,
) -> (
    AppGetInstalledSystemsoftwareForAppinstallationResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1AppSystemSoftware]
    | None
):
    """Get the installed `SystemSoftware' for a specific `AppInstallation`.

    Args:
        app_installation_id (str):
        tag_filter (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppGetInstalledSystemsoftwareForAppinstallationResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1AppSystemSoftware]
    """

    return (
        await asyncio_detailed(
            app_installation_id=app_installation_id,
            client=client,
            tag_filter=tag_filter,
        )
    ).parsed
