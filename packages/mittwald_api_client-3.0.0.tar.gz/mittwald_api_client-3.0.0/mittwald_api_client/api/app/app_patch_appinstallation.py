from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.app_patch_appinstallation_body import AppPatchAppinstallationBody
from ...models.app_patch_appinstallation_response_429 import AppPatchAppinstallationResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import Response


def _get_kwargs(
    app_installation_id: str,
    *,
    body: AppPatchAppinstallationBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v2/app-installations/{app_installation_id}".format(
            app_installation_id=quote(str(app_installation_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | AppPatchAppinstallationResponse429 | DeMittwaldV1CommonsError:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = AppPatchAppinstallationResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | AppPatchAppinstallationResponse429 | DeMittwaldV1CommonsError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_installation_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: AppPatchAppinstallationBody,
) -> Response[Any | AppPatchAppinstallationResponse429 | DeMittwaldV1CommonsError]:
    """Update properties belonging to an AppInstallation.

    Args:
        app_installation_id (str):
        body (AppPatchAppinstallationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AppPatchAppinstallationResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        app_installation_id=app_installation_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_installation_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: AppPatchAppinstallationBody,
) -> Any | AppPatchAppinstallationResponse429 | DeMittwaldV1CommonsError | None:
    """Update properties belonging to an AppInstallation.

    Args:
        app_installation_id (str):
        body (AppPatchAppinstallationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AppPatchAppinstallationResponse429 | DeMittwaldV1CommonsError
    """

    return sync_detailed(
        app_installation_id=app_installation_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    app_installation_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: AppPatchAppinstallationBody,
) -> Response[Any | AppPatchAppinstallationResponse429 | DeMittwaldV1CommonsError]:
    """Update properties belonging to an AppInstallation.

    Args:
        app_installation_id (str):
        body (AppPatchAppinstallationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AppPatchAppinstallationResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        app_installation_id=app_installation_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_installation_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: AppPatchAppinstallationBody,
) -> Any | AppPatchAppinstallationResponse429 | DeMittwaldV1CommonsError | None:
    """Update properties belonging to an AppInstallation.

    Args:
        app_installation_id (str):
        body (AppPatchAppinstallationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | AppPatchAppinstallationResponse429 | DeMittwaldV1CommonsError
    """

    return (
        await asyncio_detailed(
            app_installation_id=app_installation_id,
            client=client,
            body=body,
        )
    ).parsed
