from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.conversation_list_messages_by_conversation_response_429 import (
    ConversationListMessagesByConversationResponse429,
)
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_conversation_message import DeMittwaldV1ConversationMessage
from ...models.de_mittwald_v1_conversation_service_request import DeMittwaldV1ConversationServiceRequest
from ...models.de_mittwald_v1_conversation_status_update import DeMittwaldV1ConversationStatusUpdate
from ...types import Response


def _get_kwargs(
    conversation_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/conversations/{conversation_id}/messages".format(
            conversation_id=quote(str(conversation_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ConversationListMessagesByConversationResponse429
    | DeMittwaldV1CommonsError
    | list[
        DeMittwaldV1ConversationMessage | DeMittwaldV1ConversationServiceRequest | DeMittwaldV1ConversationStatusUpdate
    ]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:

            def _parse_response_200_item(
                data: object,
            ) -> (
                DeMittwaldV1ConversationMessage
                | DeMittwaldV1ConversationServiceRequest
                | DeMittwaldV1ConversationStatusUpdate
            ):
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    response_200_item_type_0 = DeMittwaldV1ConversationMessage.from_dict(data)

                    return response_200_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    response_200_item_type_1 = DeMittwaldV1ConversationStatusUpdate.from_dict(data)

                    return response_200_item_type_1
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_item_type_2 = DeMittwaldV1ConversationServiceRequest.from_dict(data)

                return response_200_item_type_2

            response_200_item = _parse_response_200_item(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ConversationListMessagesByConversationResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ConversationListMessagesByConversationResponse429
    | DeMittwaldV1CommonsError
    | list[
        DeMittwaldV1ConversationMessage | DeMittwaldV1ConversationServiceRequest | DeMittwaldV1ConversationStatusUpdate
    ]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[
    ConversationListMessagesByConversationResponse429
    | DeMittwaldV1CommonsError
    | list[
        DeMittwaldV1ConversationMessage | DeMittwaldV1ConversationServiceRequest | DeMittwaldV1ConversationStatusUpdate
    ]
]:
    """Get all message of the conversation.

    Args:
        conversation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationListMessagesByConversationResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationMessage | DeMittwaldV1ConversationServiceRequest | DeMittwaldV1ConversationStatusUpdate]]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> (
    ConversationListMessagesByConversationResponse429
    | DeMittwaldV1CommonsError
    | list[
        DeMittwaldV1ConversationMessage | DeMittwaldV1ConversationServiceRequest | DeMittwaldV1ConversationStatusUpdate
    ]
    | None
):
    """Get all message of the conversation.

    Args:
        conversation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationListMessagesByConversationResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationMessage | DeMittwaldV1ConversationServiceRequest | DeMittwaldV1ConversationStatusUpdate]
    """

    return sync_detailed(
        conversation_id=conversation_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[
    ConversationListMessagesByConversationResponse429
    | DeMittwaldV1CommonsError
    | list[
        DeMittwaldV1ConversationMessage | DeMittwaldV1ConversationServiceRequest | DeMittwaldV1ConversationStatusUpdate
    ]
]:
    """Get all message of the conversation.

    Args:
        conversation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationListMessagesByConversationResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationMessage | DeMittwaldV1ConversationServiceRequest | DeMittwaldV1ConversationStatusUpdate]]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> (
    ConversationListMessagesByConversationResponse429
    | DeMittwaldV1CommonsError
    | list[
        DeMittwaldV1ConversationMessage | DeMittwaldV1ConversationServiceRequest | DeMittwaldV1ConversationStatusUpdate
    ]
    | None
):
    """Get all message of the conversation.

    Args:
        conversation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationListMessagesByConversationResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationMessage | DeMittwaldV1ConversationServiceRequest | DeMittwaldV1ConversationStatusUpdate]
    """

    return (
        await asyncio_detailed(
            conversation_id=conversation_id,
            client=client,
        )
    ).parsed
