from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.conversation_list_conversations_order_item import ConversationListConversationsOrderItem
from ...models.conversation_list_conversations_response_429 import ConversationListConversationsResponse429
from ...models.conversation_list_conversations_sort_item import ConversationListConversationsSortItem
from ...models.conversation_list_conversations_status_item import ConversationListConversationsStatusItem
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_conversation_conversation import DeMittwaldV1ConversationConversation
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    full_text_search: str | Unset = UNSET,
    status: list[ConversationListConversationsStatusItem] | Unset = UNSET,
    limit: int | Unset = 100,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[ConversationListConversationsSortItem] | Unset = UNSET,
    order: list[ConversationListConversationsOrderItem] | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["fullTextSearch"] = full_text_search

    json_status: list[str] | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = []
        for status_item_data in status:
            status_item = status_item_data.value
            json_status.append(status_item)

    params["status"] = json_status

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    json_sort: list[str] | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = []
        for sort_item_data in sort:
            sort_item = sort_item_data.value
            json_sort.append(sort_item)

    params["sort"] = json_sort

    json_order: list[str] | Unset = UNSET
    if not isinstance(order, Unset):
        json_order = []
        for order_item_data in order:
            order_item = order_item_data.value
            json_order.append(order_item)

    params["order"] = json_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/conversations",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ConversationListConversationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationConversation]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1ConversationConversation.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = ConversationListConversationsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ConversationListConversationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationConversation]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    full_text_search: str | Unset = UNSET,
    status: list[ConversationListConversationsStatusItem] | Unset = UNSET,
    limit: int | Unset = 100,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[ConversationListConversationsSortItem] | Unset = UNSET,
    order: list[ConversationListConversationsOrderItem] | Unset = UNSET,
) -> Response[
    ConversationListConversationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationConversation]
]:
    """Get all conversation the authenticated user has created or has access to.

    Args:
        full_text_search (str | Unset):
        status (list[ConversationListConversationsStatusItem] | Unset):
        limit (int | Unset):  Default: 100.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[ConversationListConversationsSortItem] | Unset):
        order (list[ConversationListConversationsOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationListConversationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationConversation]]
    """

    kwargs = _get_kwargs(
        full_text_search=full_text_search,
        status=status,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    full_text_search: str | Unset = UNSET,
    status: list[ConversationListConversationsStatusItem] | Unset = UNSET,
    limit: int | Unset = 100,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[ConversationListConversationsSortItem] | Unset = UNSET,
    order: list[ConversationListConversationsOrderItem] | Unset = UNSET,
) -> (
    ConversationListConversationsResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1ConversationConversation]
    | None
):
    """Get all conversation the authenticated user has created or has access to.

    Args:
        full_text_search (str | Unset):
        status (list[ConversationListConversationsStatusItem] | Unset):
        limit (int | Unset):  Default: 100.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[ConversationListConversationsSortItem] | Unset):
        order (list[ConversationListConversationsOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationListConversationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationConversation]
    """

    return sync_detailed(
        client=client,
        full_text_search=full_text_search,
        status=status,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    full_text_search: str | Unset = UNSET,
    status: list[ConversationListConversationsStatusItem] | Unset = UNSET,
    limit: int | Unset = 100,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[ConversationListConversationsSortItem] | Unset = UNSET,
    order: list[ConversationListConversationsOrderItem] | Unset = UNSET,
) -> Response[
    ConversationListConversationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationConversation]
]:
    """Get all conversation the authenticated user has created or has access to.

    Args:
        full_text_search (str | Unset):
        status (list[ConversationListConversationsStatusItem] | Unset):
        limit (int | Unset):  Default: 100.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[ConversationListConversationsSortItem] | Unset):
        order (list[ConversationListConversationsOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationListConversationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationConversation]]
    """

    kwargs = _get_kwargs(
        full_text_search=full_text_search,
        status=status,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    full_text_search: str | Unset = UNSET,
    status: list[ConversationListConversationsStatusItem] | Unset = UNSET,
    limit: int | Unset = 100,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[ConversationListConversationsSortItem] | Unset = UNSET,
    order: list[ConversationListConversationsOrderItem] | Unset = UNSET,
) -> (
    ConversationListConversationsResponse429
    | DeMittwaldV1CommonsError
    | list[DeMittwaldV1ConversationConversation]
    | None
):
    """Get all conversation the authenticated user has created or has access to.

    Args:
        full_text_search (str | Unset):
        status (list[ConversationListConversationsStatusItem] | Unset):
        limit (int | Unset):  Default: 100.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[ConversationListConversationsSortItem] | Unset):
        order (list[ConversationListConversationsOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationListConversationsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationConversation]
    """

    return (
        await asyncio_detailed(
            client=client,
            full_text_search=full_text_search,
            status=status,
            limit=limit,
            skip=skip,
            page=page,
            sort=sort,
            order=order,
        )
    ).parsed
