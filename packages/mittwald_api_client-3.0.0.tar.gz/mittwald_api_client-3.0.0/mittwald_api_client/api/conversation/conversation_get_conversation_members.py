from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.conversation_get_conversation_members_response_429 import ConversationGetConversationMembersResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_conversation_conversation_members_item import (
    DeMittwaldV1ConversationConversationMembersItem,
)
from ...types import Response


def _get_kwargs(
    conversation_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/conversations/{conversation_id}/members".format(
            conversation_id=quote(str(conversation_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ConversationGetConversationMembersResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ConversationConversationMembersItem]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for componentsschemasde_mittwald_v_1_conversation_conversation_members_item_data in _response_200:
            componentsschemasde_mittwald_v_1_conversation_conversation_members_item = (
                DeMittwaldV1ConversationConversationMembersItem.from_dict(
                    componentsschemasde_mittwald_v_1_conversation_conversation_members_item_data
                )
            )

            response_200.append(componentsschemasde_mittwald_v_1_conversation_conversation_members_item)

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ConversationGetConversationMembersResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ConversationGetConversationMembersResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ConversationConversationMembersItem]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[
    ConversationGetConversationMembersResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ConversationConversationMembersItem]
]:
    """Get members of a support conversation.

    Args:
        conversation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationGetConversationMembersResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ConversationConversationMembersItem]]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> (
    ConversationGetConversationMembersResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ConversationConversationMembersItem]
    | None
):
    """Get members of a support conversation.

    Args:
        conversation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationGetConversationMembersResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ConversationConversationMembersItem]
    """

    return sync_detailed(
        conversation_id=conversation_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[
    ConversationGetConversationMembersResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ConversationConversationMembersItem]
]:
    """Get members of a support conversation.

    Args:
        conversation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationGetConversationMembersResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ConversationConversationMembersItem]]
    """

    kwargs = _get_kwargs(
        conversation_id=conversation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    conversation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> (
    ConversationGetConversationMembersResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | list[DeMittwaldV1ConversationConversationMembersItem]
    | None
):
    """Get members of a support conversation.

    Args:
        conversation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationGetConversationMembersResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | list[DeMittwaldV1ConversationConversationMembersItem]
    """

    return (
        await asyncio_detailed(
            conversation_id=conversation_id,
            client=client,
        )
    ).parsed
