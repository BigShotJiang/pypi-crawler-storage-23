from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.conversation_list_categories_response_429 import ConversationListCategoriesResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_conversation_category import DeMittwaldV1ConversationCategory
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/conversation-categories",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ConversationListCategoriesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationCategory]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1ConversationCategory.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = ConversationListCategoriesResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ConversationListCategoriesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationCategory]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[
    ConversationListCategoriesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationCategory]
]:
    """Get all conversation categories.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationListCategoriesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationCategory]]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
) -> ConversationListCategoriesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationCategory] | None:
    """Get all conversation categories.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationListCategoriesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationCategory]
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[
    ConversationListCategoriesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationCategory]
]:
    """Get all conversation categories.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConversationListCategoriesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationCategory]]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
) -> ConversationListCategoriesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationCategory] | None:
    """Get all conversation categories.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConversationListCategoriesResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1ConversationCategory]
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
