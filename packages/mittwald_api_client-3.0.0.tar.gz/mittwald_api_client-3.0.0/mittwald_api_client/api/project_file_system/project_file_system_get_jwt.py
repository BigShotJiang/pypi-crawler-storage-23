from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_project_fs_api_jwt import DeMittwaldV1ProjectFsApiJwt
from ...models.project_file_system_get_jwt_response_429 import ProjectFileSystemGetJwtResponse429
from ...types import Response


def _get_kwargs(
    project_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects/{project_id}/jwt".format(
            project_id=quote(str(project_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | DeMittwaldV1ProjectFsApiJwt | ProjectFileSystemGetJwtResponse429 | None:
    if response.status_code == 200:
        response_200 = DeMittwaldV1ProjectFsApiJwt.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ProjectFileSystemGetJwtResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 502:
        response_502 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_502

    if response.status_code == 503:
        response_503 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1ProjectFsApiJwt | ProjectFileSystemGetJwtResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1ProjectFsApiJwt | ProjectFileSystemGetJwtResponse429]:
    """Get a Project's file/filesystem authorization token.

    Args:
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1ProjectFsApiJwt | ProjectFileSystemGetJwtResponse429]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | DeMittwaldV1ProjectFsApiJwt | ProjectFileSystemGetJwtResponse429 | None:
    """Get a Project's file/filesystem authorization token.

    Args:
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1ProjectFsApiJwt | ProjectFileSystemGetJwtResponse429
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1ProjectFsApiJwt | ProjectFileSystemGetJwtResponse429]:
    """Get a Project's file/filesystem authorization token.

    Args:
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1ProjectFsApiJwt | ProjectFileSystemGetJwtResponse429]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | DeMittwaldV1ProjectFsApiJwt | ProjectFileSystemGetJwtResponse429 | None:
    """Get a Project's file/filesystem authorization token.

    Args:
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1ProjectFsApiJwt | ProjectFileSystemGetJwtResponse429
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
        )
    ).parsed
