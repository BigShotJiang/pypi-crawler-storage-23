from http import HTTPStatus
from io import BytesIO
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.project_file_system_get_file_content_response_429 import ProjectFileSystemGetFileContentResponse429
from ...types import UNSET, File, Response, Unset


def _get_kwargs(
    project_id: str,
    *,
    file: str | Unset = UNSET,
    inline: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["file"] = file

    params["inline"] = inline

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects/{project_id}/filesystem-file-content".format(
            project_id=quote(str(project_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | File | ProjectFileSystemGetFileContentResponse429:
    if response.status_code == 200:
        response_200 = File(payload=BytesIO(response.content))

        return response_200

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ProjectFileSystemGetFileContentResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 502:
        response_502 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_502

    if response.status_code == 503:
        response_503 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_503

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | File | ProjectFileSystemGetFileContentResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    file: str | Unset = UNSET,
    inline: bool | Unset = UNSET,
) -> Response[DeMittwaldV1CommonsError | File | ProjectFileSystemGetFileContentResponse429]:
    """Get a Project file's content.

    Args:
        project_id (str):
        file (str | Unset):  Example: /home/example.log.
        inline (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | File | ProjectFileSystemGetFileContentResponse429]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        file=file,
        inline=inline,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    file: str | Unset = UNSET,
    inline: bool | Unset = UNSET,
) -> DeMittwaldV1CommonsError | File | ProjectFileSystemGetFileContentResponse429 | None:
    """Get a Project file's content.

    Args:
        project_id (str):
        file (str | Unset):  Example: /home/example.log.
        inline (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | File | ProjectFileSystemGetFileContentResponse429
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        file=file,
        inline=inline,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    file: str | Unset = UNSET,
    inline: bool | Unset = UNSET,
) -> Response[DeMittwaldV1CommonsError | File | ProjectFileSystemGetFileContentResponse429]:
    """Get a Project file's content.

    Args:
        project_id (str):
        file (str | Unset):  Example: /home/example.log.
        inline (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | File | ProjectFileSystemGetFileContentResponse429]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        file=file,
        inline=inline,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    file: str | Unset = UNSET,
    inline: bool | Unset = UNSET,
) -> DeMittwaldV1CommonsError | File | ProjectFileSystemGetFileContentResponse429 | None:
    """Get a Project file's content.

    Args:
        project_id (str):
        file (str | Unset):  Example: /home/example.log.
        inline (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | File | ProjectFileSystemGetFileContentResponse429
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            file=file,
            inline=inline,
        )
    ).parsed
