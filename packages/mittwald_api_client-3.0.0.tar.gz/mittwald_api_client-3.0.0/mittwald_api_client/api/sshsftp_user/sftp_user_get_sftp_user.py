from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_sshuser_sftp_user import DeMittwaldV1SshuserSftpUser
from ...models.sftp_user_get_sftp_user_response_429 import SftpUserGetSftpUserResponse429
from ...types import Response


def _get_kwargs(
    sftp_user_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/sftp-users/{sftp_user_id}".format(
            sftp_user_id=quote(str(sftp_user_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | DeMittwaldV1SshuserSftpUser | SftpUserGetSftpUserResponse429:
    if response.status_code == 200:
        response_200 = DeMittwaldV1SshuserSftpUser.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = SftpUserGetSftpUserResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1SshuserSftpUser | SftpUserGetSftpUserResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    sftp_user_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1SshuserSftpUser | SftpUserGetSftpUserResponse429]:
    """Get an SFTPUser.

    Args:
        sftp_user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1SshuserSftpUser | SftpUserGetSftpUserResponse429]
    """

    kwargs = _get_kwargs(
        sftp_user_id=sftp_user_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    sftp_user_id: str,
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | DeMittwaldV1SshuserSftpUser | SftpUserGetSftpUserResponse429 | None:
    """Get an SFTPUser.

    Args:
        sftp_user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1SshuserSftpUser | SftpUserGetSftpUserResponse429
    """

    return sync_detailed(
        sftp_user_id=sftp_user_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    sftp_user_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1SshuserSftpUser | SftpUserGetSftpUserResponse429]:
    """Get an SFTPUser.

    Args:
        sftp_user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1SshuserSftpUser | SftpUserGetSftpUserResponse429]
    """

    kwargs = _get_kwargs(
        sftp_user_id=sftp_user_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    sftp_user_id: str,
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | DeMittwaldV1SshuserSftpUser | SftpUserGetSftpUserResponse429 | None:
    """Get an SFTPUser.

    Args:
        sftp_user_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1SshuserSftpUser | SftpUserGetSftpUserResponse429
    """

    return (
        await asyncio_detailed(
            sftp_user_id=sftp_user_id,
            client=client,
        )
    ).parsed
