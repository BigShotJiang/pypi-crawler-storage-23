from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_mail_mail_address import DeMittwaldV1MailMailAddress
from ...models.mail_list_mail_addresses_order_item import MailListMailAddressesOrderItem
from ...models.mail_list_mail_addresses_response_429 import MailListMailAddressesResponse429
from ...models.mail_list_mail_addresses_sort_item import MailListMailAddressesSortItem
from ...types import UNSET, Response, Unset


def _get_kwargs(
    project_id: str,
    *,
    search: str | Unset = UNSET,
    forward_address: bool | Unset = UNSET,
    catch_all: bool | Unset = UNSET,
    auto_responder: bool | Unset = UNSET,
    mail_archive: bool | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[MailListMailAddressesSortItem] | Unset = UNSET,
    order: list[MailListMailAddressesOrderItem] | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["search"] = search

    params["forwardAddress"] = forward_address

    params["catchAll"] = catch_all

    params["autoResponder"] = auto_responder

    params["mailArchive"] = mail_archive

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    json_sort: list[str] | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = []
        for sort_item_data in sort:
            sort_item = sort_item_data.value
            json_sort.append(sort_item)

    params["sort"] = json_sort

    json_order: list[str] | Unset = UNSET
    if not isinstance(order, Unset):
        json_order = []
        for order_item_data in order:
            order_item = order_item_data.value
            json_order.append(order_item)

    params["order"] = json_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects/{project_id}/mail-addresses".format(
            project_id=quote(str(project_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListMailAddressesResponse429
    | list[DeMittwaldV1MailMailAddress]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1MailMailAddress.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = MailListMailAddressesResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_503

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListMailAddressesResponse429
    | list[DeMittwaldV1MailMailAddress]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    forward_address: bool | Unset = UNSET,
    catch_all: bool | Unset = UNSET,
    auto_responder: bool | Unset = UNSET,
    mail_archive: bool | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[MailListMailAddressesSortItem] | Unset = UNSET,
    order: list[MailListMailAddressesOrderItem] | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListMailAddressesResponse429
    | list[DeMittwaldV1MailMailAddress]
]:
    """List MailAddresses belonging to a Project.

    Args:
        project_id (str):
        search (str | Unset):
        forward_address (bool | Unset):
        catch_all (bool | Unset):
        auto_responder (bool | Unset):
        mail_archive (bool | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[MailListMailAddressesSortItem] | Unset):
        order (list[MailListMailAddressesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailListMailAddressesResponse429 | list[DeMittwaldV1MailMailAddress]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        search=search,
        forward_address=forward_address,
        catch_all=catch_all,
        auto_responder=auto_responder,
        mail_archive=mail_archive,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    forward_address: bool | Unset = UNSET,
    catch_all: bool | Unset = UNSET,
    auto_responder: bool | Unset = UNSET,
    mail_archive: bool | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[MailListMailAddressesSortItem] | Unset = UNSET,
    order: list[MailListMailAddressesOrderItem] | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListMailAddressesResponse429
    | list[DeMittwaldV1MailMailAddress]
    | None
):
    """List MailAddresses belonging to a Project.

    Args:
        project_id (str):
        search (str | Unset):
        forward_address (bool | Unset):
        catch_all (bool | Unset):
        auto_responder (bool | Unset):
        mail_archive (bool | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[MailListMailAddressesSortItem] | Unset):
        order (list[MailListMailAddressesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailListMailAddressesResponse429 | list[DeMittwaldV1MailMailAddress]
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        search=search,
        forward_address=forward_address,
        catch_all=catch_all,
        auto_responder=auto_responder,
        mail_archive=mail_archive,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    forward_address: bool | Unset = UNSET,
    catch_all: bool | Unset = UNSET,
    auto_responder: bool | Unset = UNSET,
    mail_archive: bool | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[MailListMailAddressesSortItem] | Unset = UNSET,
    order: list[MailListMailAddressesOrderItem] | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListMailAddressesResponse429
    | list[DeMittwaldV1MailMailAddress]
]:
    """List MailAddresses belonging to a Project.

    Args:
        project_id (str):
        search (str | Unset):
        forward_address (bool | Unset):
        catch_all (bool | Unset):
        auto_responder (bool | Unset):
        mail_archive (bool | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[MailListMailAddressesSortItem] | Unset):
        order (list[MailListMailAddressesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailListMailAddressesResponse429 | list[DeMittwaldV1MailMailAddress]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        search=search,
        forward_address=forward_address,
        catch_all=catch_all,
        auto_responder=auto_responder,
        mail_archive=mail_archive,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    forward_address: bool | Unset = UNSET,
    catch_all: bool | Unset = UNSET,
    auto_responder: bool | Unset = UNSET,
    mail_archive: bool | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[MailListMailAddressesSortItem] | Unset = UNSET,
    order: list[MailListMailAddressesOrderItem] | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListMailAddressesResponse429
    | list[DeMittwaldV1MailMailAddress]
    | None
):
    """List MailAddresses belonging to a Project.

    Args:
        project_id (str):
        search (str | Unset):
        forward_address (bool | Unset):
        catch_all (bool | Unset):
        auto_responder (bool | Unset):
        mail_archive (bool | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[MailListMailAddressesSortItem] | Unset):
        order (list[MailListMailAddressesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailListMailAddressesResponse429 | list[DeMittwaldV1MailMailAddress]
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            search=search,
            forward_address=forward_address,
            catch_all=catch_all,
            auto_responder=auto_responder,
            mail_archive=mail_archive,
            limit=limit,
            skip=skip,
            page=page,
            sort=sort,
            order=order,
        )
    ).parsed
