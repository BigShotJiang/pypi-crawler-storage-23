from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_mail_create_forward_address import DeMittwaldV1MailCreateForwardAddress
from ...models.de_mittwald_v1_mail_create_mail_address import DeMittwaldV1MailCreateMailAddress
from ...models.mail_create_mail_address_response_201 import MailCreateMailAddressResponse201
from ...models.mail_create_mail_address_response_429 import MailCreateMailAddressResponse429
from ...types import Response


def _get_kwargs(
    project_id: str,
    *,
    body: DeMittwaldV1MailCreateForwardAddress | DeMittwaldV1MailCreateMailAddress,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/projects/{project_id}/mail-addresses".format(
            project_id=quote(str(project_id), safe=""),
        ),
    }

    if isinstance(body, DeMittwaldV1MailCreateForwardAddress):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailCreateMailAddressResponse201
    | MailCreateMailAddressResponse429
):
    if response.status_code == 201:
        response_201 = MailCreateMailAddressResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = MailCreateMailAddressResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_503

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailCreateMailAddressResponse201
    | MailCreateMailAddressResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: DeMittwaldV1MailCreateForwardAddress | DeMittwaldV1MailCreateMailAddress,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailCreateMailAddressResponse201
    | MailCreateMailAddressResponse429
]:
    """Create a MailAddress.

    Args:
        project_id (str):
        body (DeMittwaldV1MailCreateForwardAddress | DeMittwaldV1MailCreateMailAddress):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailCreateMailAddressResponse201 | MailCreateMailAddressResponse429]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: DeMittwaldV1MailCreateForwardAddress | DeMittwaldV1MailCreateMailAddress,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailCreateMailAddressResponse201
    | MailCreateMailAddressResponse429
    | None
):
    """Create a MailAddress.

    Args:
        project_id (str):
        body (DeMittwaldV1MailCreateForwardAddress | DeMittwaldV1MailCreateMailAddress):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailCreateMailAddressResponse201 | MailCreateMailAddressResponse429
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: DeMittwaldV1MailCreateForwardAddress | DeMittwaldV1MailCreateMailAddress,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailCreateMailAddressResponse201
    | MailCreateMailAddressResponse429
]:
    """Create a MailAddress.

    Args:
        project_id (str):
        body (DeMittwaldV1MailCreateForwardAddress | DeMittwaldV1MailCreateMailAddress):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailCreateMailAddressResponse201 | MailCreateMailAddressResponse429]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: DeMittwaldV1MailCreateForwardAddress | DeMittwaldV1MailCreateMailAddress,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailCreateMailAddressResponse201
    | MailCreateMailAddressResponse429
    | None
):
    """Create a MailAddress.

    Args:
        project_id (str):
        body (DeMittwaldV1MailCreateForwardAddress | DeMittwaldV1MailCreateMailAddress):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailCreateMailAddressResponse201 | MailCreateMailAddressResponse429
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            body=body,
        )
    ).parsed
