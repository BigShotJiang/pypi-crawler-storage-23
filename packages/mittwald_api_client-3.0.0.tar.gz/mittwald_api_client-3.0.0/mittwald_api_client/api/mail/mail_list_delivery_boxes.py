from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_mail_deliverybox import DeMittwaldV1MailDeliverybox
from ...models.mail_list_delivery_boxes_response_429 import MailListDeliveryBoxesResponse429
from ...types import UNSET, Response, Unset


def _get_kwargs(
    project_id: str,
    *,
    search: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["search"] = search

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/projects/{project_id}/delivery-boxes".format(
            project_id=quote(str(project_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListDeliveryBoxesResponse429
    | list[DeMittwaldV1MailDeliverybox]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1MailDeliverybox.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = MailListDeliveryBoxesResponse429.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_503

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListDeliveryBoxesResponse429
    | list[DeMittwaldV1MailDeliverybox]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListDeliveryBoxesResponse429
    | list[DeMittwaldV1MailDeliverybox]
]:
    """List DeliveryBoxes belonging to a Project.

    Args:
        project_id (str):
        search (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailListDeliveryBoxesResponse429 | list[DeMittwaldV1MailDeliverybox]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        search=search,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListDeliveryBoxesResponse429
    | list[DeMittwaldV1MailDeliverybox]
    | None
):
    """List DeliveryBoxes belonging to a Project.

    Args:
        project_id (str):
        search (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailListDeliveryBoxesResponse429 | list[DeMittwaldV1MailDeliverybox]
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        search=search,
        limit=limit,
        skip=skip,
        page=page,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListDeliveryBoxesResponse429
    | list[DeMittwaldV1MailDeliverybox]
]:
    """List DeliveryBoxes belonging to a Project.

    Args:
        project_id (str):
        search (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailListDeliveryBoxesResponse429 | list[DeMittwaldV1MailDeliverybox]]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        search=search,
        limit=limit,
        skip=skip,
        page=page,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    search: str | Unset = UNSET,
    limit: int | Unset = 10000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | MailListDeliveryBoxesResponse429
    | list[DeMittwaldV1MailDeliverybox]
    | None
):
    """List DeliveryBoxes belonging to a Project.

    Args:
        project_id (str):
        search (str | Unset):
        limit (int | Unset):  Default: 10000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | MailListDeliveryBoxesResponse429 | list[DeMittwaldV1MailDeliverybox]
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            search=search,
            limit=limit,
            skip=skip,
            page=page,
        )
    ).parsed
