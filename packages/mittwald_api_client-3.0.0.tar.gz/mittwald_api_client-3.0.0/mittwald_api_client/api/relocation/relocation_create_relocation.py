from http import HTTPStatus
from typing import Any, cast

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.relocation_create_relocation_body import RelocationCreateRelocationBody
from ...models.relocation_create_relocation_response_429 import RelocationCreateRelocationResponse429
from ...types import Response


def _get_kwargs(
    *,
    body: RelocationCreateRelocationBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/relocation",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | RelocationCreateRelocationResponse429:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 429:
        response_429 = RelocationCreateRelocationResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | RelocationCreateRelocationResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RelocationCreateRelocationBody,
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | RelocationCreateRelocationResponse429
]:
    """Relocate an external Project to mittwald.

     Give mittwald access to your Provider and let them move your Project to mittwald.

    Args:
        body (RelocationCreateRelocationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | RelocationCreateRelocationResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: RelocationCreateRelocationBody,
) -> (
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | RelocationCreateRelocationResponse429 | None
):
    """Relocate an external Project to mittwald.

     Give mittwald access to your Provider and let them move your Project to mittwald.

    Args:
        body (RelocationCreateRelocationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | RelocationCreateRelocationResponse429
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RelocationCreateRelocationBody,
) -> Response[
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | RelocationCreateRelocationResponse429
]:
    """Relocate an external Project to mittwald.

     Give mittwald access to your Provider and let them move your Project to mittwald.

    Args:
        body (RelocationCreateRelocationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | RelocationCreateRelocationResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: RelocationCreateRelocationBody,
) -> (
    Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | RelocationCreateRelocationResponse429 | None
):
    """Relocate an external Project to mittwald.

     Give mittwald access to your Provider and let them move your Project to mittwald.

    Args:
        body (RelocationCreateRelocationBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | RelocationCreateRelocationResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
