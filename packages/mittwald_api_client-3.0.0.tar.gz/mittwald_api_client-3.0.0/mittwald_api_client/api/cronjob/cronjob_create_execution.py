from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.cronjob_create_execution_response_201 import CronjobCreateExecutionResponse201
from ...models.cronjob_create_execution_response_429 import CronjobCreateExecutionResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...types import Response


def _get_kwargs(
    cronjob_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/cronjobs/{cronjob_id}/executions".format(
            cronjob_id=quote(str(cronjob_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CronjobCreateExecutionResponse201 | CronjobCreateExecutionResponse429 | DeMittwaldV1CommonsError:
    if response.status_code == 201:
        response_201 = CronjobCreateExecutionResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 412:
        response_412 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_412

    if response.status_code == 429:
        response_429 = CronjobCreateExecutionResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CronjobCreateExecutionResponse201 | CronjobCreateExecutionResponse429 | DeMittwaldV1CommonsError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[CronjobCreateExecutionResponse201 | CronjobCreateExecutionResponse429 | DeMittwaldV1CommonsError]:
    """Trigger a Cronjob.

    Args:
        cronjob_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CronjobCreateExecutionResponse201 | CronjobCreateExecutionResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        cronjob_id=cronjob_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
) -> CronjobCreateExecutionResponse201 | CronjobCreateExecutionResponse429 | DeMittwaldV1CommonsError | None:
    """Trigger a Cronjob.

    Args:
        cronjob_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CronjobCreateExecutionResponse201 | CronjobCreateExecutionResponse429 | DeMittwaldV1CommonsError
    """

    return sync_detailed(
        cronjob_id=cronjob_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[CronjobCreateExecutionResponse201 | CronjobCreateExecutionResponse429 | DeMittwaldV1CommonsError]:
    """Trigger a Cronjob.

    Args:
        cronjob_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CronjobCreateExecutionResponse201 | CronjobCreateExecutionResponse429 | DeMittwaldV1CommonsError]
    """

    kwargs = _get_kwargs(
        cronjob_id=cronjob_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
) -> CronjobCreateExecutionResponse201 | CronjobCreateExecutionResponse429 | DeMittwaldV1CommonsError | None:
    """Trigger a Cronjob.

    Args:
        cronjob_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CronjobCreateExecutionResponse201 | CronjobCreateExecutionResponse429 | DeMittwaldV1CommonsError
    """

    return (
        await asyncio_detailed(
            cronjob_id=cronjob_id,
            client=client,
        )
    ).parsed
