from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.cronjob_update_cronjob_body import CronjobUpdateCronjobBody
from ...models.cronjob_update_cronjob_response_429 import CronjobUpdateCronjobResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...types import UNSET, Response, Unset


def _get_kwargs(
    cronjob_id: str,
    *,
    body: CronjobUpdateCronjobBody | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v2/cronjobs/{cronjob_id}".format(
            cronjob_id=quote(str(cronjob_id), safe=""),
        ),
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | CronjobUpdateCronjobResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 412:
        response_412 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_412

    if response.status_code == 429:
        response_429 = CronjobUpdateCronjobResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | CronjobUpdateCronjobResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
    body: CronjobUpdateCronjobBody | Unset = UNSET,
) -> Response[Any | CronjobUpdateCronjobResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors]:
    """Update a Cronjob.

    Args:
        cronjob_id (str):
        body (CronjobUpdateCronjobBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CronjobUpdateCronjobResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors]
    """

    kwargs = _get_kwargs(
        cronjob_id=cronjob_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
    body: CronjobUpdateCronjobBody | Unset = UNSET,
) -> Any | CronjobUpdateCronjobResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | None:
    """Update a Cronjob.

    Args:
        cronjob_id (str):
        body (CronjobUpdateCronjobBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CronjobUpdateCronjobResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors
    """

    return sync_detailed(
        cronjob_id=cronjob_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
    body: CronjobUpdateCronjobBody | Unset = UNSET,
) -> Response[Any | CronjobUpdateCronjobResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors]:
    """Update a Cronjob.

    Args:
        cronjob_id (str):
        body (CronjobUpdateCronjobBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CronjobUpdateCronjobResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors]
    """

    kwargs = _get_kwargs(
        cronjob_id=cronjob_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
    body: CronjobUpdateCronjobBody | Unset = UNSET,
) -> Any | CronjobUpdateCronjobResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | None:
    """Update a Cronjob.

    Args:
        cronjob_id (str):
        body (CronjobUpdateCronjobBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CronjobUpdateCronjobResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors
    """

    return (
        await asyncio_detailed(
            cronjob_id=cronjob_id,
            client=client,
            body=body,
        )
    ).parsed
