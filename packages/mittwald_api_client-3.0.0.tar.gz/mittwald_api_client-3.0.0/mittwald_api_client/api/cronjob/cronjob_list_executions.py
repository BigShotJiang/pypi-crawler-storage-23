import datetime
from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.cronjob_list_executions_response_429 import CronjobListExecutionsResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_cronjob_cronjob_execution import DeMittwaldV1CronjobCronjobExecution
from ...models.de_mittwald_v1_cronjob_cronjob_execution_sort_order import DeMittwaldV1CronjobCronjobExecutionSortOrder
from ...types import UNSET, Response, Unset


def _get_kwargs(
    cronjob_id: str,
    *,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    page: int | Unset = UNSET,
    since: datetime.datetime | Unset = UNSET,
    until: datetime.datetime | Unset = UNSET,
    status: str | Unset = UNSET,
    triggered_by_user: bool | Unset = UNSET,
    sort_order: DeMittwaldV1CronjobCronjobExecutionSortOrder | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    json_since: str | Unset = UNSET
    if not isinstance(since, Unset):
        json_since = since.isoformat()
    params["since"] = json_since

    json_until: str | Unset = UNSET
    if not isinstance(until, Unset):
        json_until = until.isoformat()
    params["until"] = json_until

    params["status"] = status

    params["triggeredByUser"] = triggered_by_user

    json_sort_order: str | Unset = UNSET
    if not isinstance(sort_order, Unset):
        json_sort_order = sort_order.value

    params["sortOrder"] = json_sort_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/cronjobs/{cronjob_id}/executions".format(
            cronjob_id=quote(str(cronjob_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CronjobListExecutionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1CronjobCronjobExecution]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1CronjobCronjobExecution.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 429:
        response_429 = CronjobListExecutionsResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CronjobListExecutionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1CronjobCronjobExecution]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    page: int | Unset = UNSET,
    since: datetime.datetime | Unset = UNSET,
    until: datetime.datetime | Unset = UNSET,
    status: str | Unset = UNSET,
    triggered_by_user: bool | Unset = UNSET,
    sort_order: DeMittwaldV1CronjobCronjobExecutionSortOrder | Unset = UNSET,
) -> Response[CronjobListExecutionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1CronjobCronjobExecution]]:
    """List CronjobExecutions belonging to a Cronjob.

    Args:
        cronjob_id (str):
        limit (int | Unset):
        skip (int | Unset):
        page (int | Unset):
        since (datetime.datetime | Unset):
        until (datetime.datetime | Unset):
        status (str | Unset):  Example: Complete.
        triggered_by_user (bool | Unset):
        sort_order (DeMittwaldV1CronjobCronjobExecutionSortOrder | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CronjobListExecutionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1CronjobCronjobExecution]]
    """

    kwargs = _get_kwargs(
        cronjob_id=cronjob_id,
        limit=limit,
        skip=skip,
        page=page,
        since=since,
        until=until,
        status=status,
        triggered_by_user=triggered_by_user,
        sort_order=sort_order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    page: int | Unset = UNSET,
    since: datetime.datetime | Unset = UNSET,
    until: datetime.datetime | Unset = UNSET,
    status: str | Unset = UNSET,
    triggered_by_user: bool | Unset = UNSET,
    sort_order: DeMittwaldV1CronjobCronjobExecutionSortOrder | Unset = UNSET,
) -> CronjobListExecutionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1CronjobCronjobExecution] | None:
    """List CronjobExecutions belonging to a Cronjob.

    Args:
        cronjob_id (str):
        limit (int | Unset):
        skip (int | Unset):
        page (int | Unset):
        since (datetime.datetime | Unset):
        until (datetime.datetime | Unset):
        status (str | Unset):  Example: Complete.
        triggered_by_user (bool | Unset):
        sort_order (DeMittwaldV1CronjobCronjobExecutionSortOrder | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CronjobListExecutionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1CronjobCronjobExecution]
    """

    return sync_detailed(
        cronjob_id=cronjob_id,
        client=client,
        limit=limit,
        skip=skip,
        page=page,
        since=since,
        until=until,
        status=status,
        triggered_by_user=triggered_by_user,
        sort_order=sort_order,
    ).parsed


async def asyncio_detailed(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    page: int | Unset = UNSET,
    since: datetime.datetime | Unset = UNSET,
    until: datetime.datetime | Unset = UNSET,
    status: str | Unset = UNSET,
    triggered_by_user: bool | Unset = UNSET,
    sort_order: DeMittwaldV1CronjobCronjobExecutionSortOrder | Unset = UNSET,
) -> Response[CronjobListExecutionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1CronjobCronjobExecution]]:
    """List CronjobExecutions belonging to a Cronjob.

    Args:
        cronjob_id (str):
        limit (int | Unset):
        skip (int | Unset):
        page (int | Unset):
        since (datetime.datetime | Unset):
        until (datetime.datetime | Unset):
        status (str | Unset):  Example: Complete.
        triggered_by_user (bool | Unset):
        sort_order (DeMittwaldV1CronjobCronjobExecutionSortOrder | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CronjobListExecutionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1CronjobCronjobExecution]]
    """

    kwargs = _get_kwargs(
        cronjob_id=cronjob_id,
        limit=limit,
        skip=skip,
        page=page,
        since=since,
        until=until,
        status=status,
        triggered_by_user=triggered_by_user,
        sort_order=sort_order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    cronjob_id: str,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = UNSET,
    skip: int | Unset = UNSET,
    page: int | Unset = UNSET,
    since: datetime.datetime | Unset = UNSET,
    until: datetime.datetime | Unset = UNSET,
    status: str | Unset = UNSET,
    triggered_by_user: bool | Unset = UNSET,
    sort_order: DeMittwaldV1CronjobCronjobExecutionSortOrder | Unset = UNSET,
) -> CronjobListExecutionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1CronjobCronjobExecution] | None:
    """List CronjobExecutions belonging to a Cronjob.

    Args:
        cronjob_id (str):
        limit (int | Unset):
        skip (int | Unset):
        page (int | Unset):
        since (datetime.datetime | Unset):
        until (datetime.datetime | Unset):
        status (str | Unset):  Example: Complete.
        triggered_by_user (bool | Unset):
        sort_order (DeMittwaldV1CronjobCronjobExecutionSortOrder | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CronjobListExecutionsResponse429 | DeMittwaldV1CommonsError | list[DeMittwaldV1CronjobCronjobExecution]
    """

    return (
        await asyncio_detailed(
            cronjob_id=cronjob_id,
            client=client,
            limit=limit,
            skip=skip,
            page=page,
            since=since,
            until=until,
            status=status,
            triggered_by_user=triggered_by_user,
            sort_order=sort_order,
        )
    ).parsed
