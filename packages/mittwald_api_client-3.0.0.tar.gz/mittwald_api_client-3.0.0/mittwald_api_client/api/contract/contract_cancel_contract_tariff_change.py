from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ...client import AuthenticatedClient, Client
from ...models.contract_cancel_contract_tariff_change_response_200 import ContractCancelContractTariffChangeResponse200
from ...models.contract_cancel_contract_tariff_change_response_429 import ContractCancelContractTariffChangeResponse429
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...types import Response


def _get_kwargs(
    contract_id: str,
    contract_item_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v2/contracts/{contract_id}/items/{contract_item_id}/tariff-change".format(
            contract_id=quote(str(contract_id), safe=""),
            contract_item_id=quote(str(contract_item_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ContractCancelContractTariffChangeResponse200
    | ContractCancelContractTariffChangeResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
):
    if response.status_code == 200:
        response_200 = ContractCancelContractTariffChangeResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = ContractCancelContractTariffChangeResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ContractCancelContractTariffChangeResponse200
    | ContractCancelContractTariffChangeResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    contract_id: str,
    contract_item_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    ContractCancelContractTariffChangeResponse200
    | ContractCancelContractTariffChangeResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
]:
    """Cancel the TariffChange for the referred ContractItem.

    Args:
        contract_id (str):
        contract_item_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContractCancelContractTariffChangeResponse200 | ContractCancelContractTariffChangeResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors]
    """

    kwargs = _get_kwargs(
        contract_id=contract_id,
        contract_item_id=contract_item_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    contract_id: str,
    contract_item_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    ContractCancelContractTariffChangeResponse200
    | ContractCancelContractTariffChangeResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | None
):
    """Cancel the TariffChange for the referred ContractItem.

    Args:
        contract_id (str):
        contract_item_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContractCancelContractTariffChangeResponse200 | ContractCancelContractTariffChangeResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors
    """

    return sync_detailed(
        contract_id=contract_id,
        contract_item_id=contract_item_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    contract_id: str,
    contract_item_id: UUID,
    *,
    client: AuthenticatedClient,
) -> Response[
    ContractCancelContractTariffChangeResponse200
    | ContractCancelContractTariffChangeResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
]:
    """Cancel the TariffChange for the referred ContractItem.

    Args:
        contract_id (str):
        contract_item_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ContractCancelContractTariffChangeResponse200 | ContractCancelContractTariffChangeResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors]
    """

    kwargs = _get_kwargs(
        contract_id=contract_id,
        contract_item_id=contract_item_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    contract_id: str,
    contract_item_id: UUID,
    *,
    client: AuthenticatedClient,
) -> (
    ContractCancelContractTariffChangeResponse200
    | ContractCancelContractTariffChangeResponse429
    | DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | None
):
    """Cancel the TariffChange for the referred ContractItem.

    Args:
        contract_id (str):
        contract_item_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ContractCancelContractTariffChangeResponse200 | ContractCancelContractTariffChangeResponse429 | DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors
    """

    return (
        await asyncio_detailed(
            contract_id=contract_id,
            contract_item_id=contract_item_id,
            client=client,
        )
    ).parsed
