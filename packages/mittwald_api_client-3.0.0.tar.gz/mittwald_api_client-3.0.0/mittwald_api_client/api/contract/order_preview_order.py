from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_order_ai_hosting_order_preview_response import (
    DeMittwaldV1OrderAIHostingOrderPreviewResponse,
)
from ...models.de_mittwald_v1_order_domain_order_preview_response import DeMittwaldV1OrderDomainOrderPreviewResponse
from ...models.de_mittwald_v1_order_external_certificate_order_preview_response import (
    DeMittwaldV1OrderExternalCertificateOrderPreviewResponse,
)
from ...models.de_mittwald_v1_order_hosting_order_preview_response import DeMittwaldV1OrderHostingOrderPreviewResponse
from ...models.de_mittwald_v1_order_lead_fyndr_order_preview_response import (
    DeMittwaldV1OrderLeadFyndrOrderPreviewResponse,
)
from ...models.de_mittwald_v1_order_mail_archive_order_preview_response import (
    DeMittwaldV1OrderMailArchiveOrderPreviewResponse,
)
from ...models.order_preview_order_body import OrderPreviewOrderBody
from ...models.order_preview_order_response_422 import OrderPreviewOrderResponse422
from ...models.order_preview_order_response_429 import OrderPreviewOrderResponse429
from ...types import Response


def _get_kwargs(
    *,
    body: OrderPreviewOrderBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/order-previews",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1OrderAIHostingOrderPreviewResponse
    | DeMittwaldV1OrderDomainOrderPreviewResponse
    | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse
    | DeMittwaldV1OrderHostingOrderPreviewResponse
    | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse
    | DeMittwaldV1OrderMailArchiveOrderPreviewResponse
    | OrderPreviewOrderResponse422
    | OrderPreviewOrderResponse429
):
    if response.status_code == 200:

        def _parse_response_200(
            data: object,
        ) -> (
            DeMittwaldV1OrderAIHostingOrderPreviewResponse
            | DeMittwaldV1OrderDomainOrderPreviewResponse
            | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse
            | DeMittwaldV1OrderHostingOrderPreviewResponse
            | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse
            | DeMittwaldV1OrderMailArchiveOrderPreviewResponse
        ):
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_0 = DeMittwaldV1OrderHostingOrderPreviewResponse.from_dict(data)

                return response_200_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_1 = DeMittwaldV1OrderDomainOrderPreviewResponse.from_dict(data)

                return response_200_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_2 = DeMittwaldV1OrderExternalCertificateOrderPreviewResponse.from_dict(data)

                return response_200_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_3 = DeMittwaldV1OrderLeadFyndrOrderPreviewResponse.from_dict(data)

                return response_200_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_4 = DeMittwaldV1OrderMailArchiveOrderPreviewResponse.from_dict(data)

                return response_200_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_200_type_5 = DeMittwaldV1OrderAIHostingOrderPreviewResponse.from_dict(data)

            return response_200_type_5

        response_200 = _parse_response_200(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 422:
        response_422 = OrderPreviewOrderResponse422.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = OrderPreviewOrderResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1OrderAIHostingOrderPreviewResponse
    | DeMittwaldV1OrderDomainOrderPreviewResponse
    | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse
    | DeMittwaldV1OrderHostingOrderPreviewResponse
    | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse
    | DeMittwaldV1OrderMailArchiveOrderPreviewResponse
    | OrderPreviewOrderResponse422
    | OrderPreviewOrderResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: OrderPreviewOrderBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1OrderAIHostingOrderPreviewResponse
    | DeMittwaldV1OrderDomainOrderPreviewResponse
    | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse
    | DeMittwaldV1OrderHostingOrderPreviewResponse
    | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse
    | DeMittwaldV1OrderMailArchiveOrderPreviewResponse
    | OrderPreviewOrderResponse422
    | OrderPreviewOrderResponse429
]:
    """Preview Order.

    Args:
        body (OrderPreviewOrderBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1OrderAIHostingOrderPreviewResponse | DeMittwaldV1OrderDomainOrderPreviewResponse | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse | DeMittwaldV1OrderHostingOrderPreviewResponse | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse | DeMittwaldV1OrderMailArchiveOrderPreviewResponse | OrderPreviewOrderResponse422 | OrderPreviewOrderResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: OrderPreviewOrderBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1OrderAIHostingOrderPreviewResponse
    | DeMittwaldV1OrderDomainOrderPreviewResponse
    | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse
    | DeMittwaldV1OrderHostingOrderPreviewResponse
    | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse
    | DeMittwaldV1OrderMailArchiveOrderPreviewResponse
    | OrderPreviewOrderResponse422
    | OrderPreviewOrderResponse429
    | None
):
    """Preview Order.

    Args:
        body (OrderPreviewOrderBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1OrderAIHostingOrderPreviewResponse | DeMittwaldV1OrderDomainOrderPreviewResponse | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse | DeMittwaldV1OrderHostingOrderPreviewResponse | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse | DeMittwaldV1OrderMailArchiveOrderPreviewResponse | OrderPreviewOrderResponse422 | OrderPreviewOrderResponse429
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: OrderPreviewOrderBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1OrderAIHostingOrderPreviewResponse
    | DeMittwaldV1OrderDomainOrderPreviewResponse
    | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse
    | DeMittwaldV1OrderHostingOrderPreviewResponse
    | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse
    | DeMittwaldV1OrderMailArchiveOrderPreviewResponse
    | OrderPreviewOrderResponse422
    | OrderPreviewOrderResponse429
]:
    """Preview Order.

    Args:
        body (OrderPreviewOrderBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1OrderAIHostingOrderPreviewResponse | DeMittwaldV1OrderDomainOrderPreviewResponse | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse | DeMittwaldV1OrderHostingOrderPreviewResponse | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse | DeMittwaldV1OrderMailArchiveOrderPreviewResponse | OrderPreviewOrderResponse422 | OrderPreviewOrderResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: OrderPreviewOrderBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | DeMittwaldV1OrderAIHostingOrderPreviewResponse
    | DeMittwaldV1OrderDomainOrderPreviewResponse
    | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse
    | DeMittwaldV1OrderHostingOrderPreviewResponse
    | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse
    | DeMittwaldV1OrderMailArchiveOrderPreviewResponse
    | OrderPreviewOrderResponse422
    | OrderPreviewOrderResponse429
    | None
):
    """Preview Order.

    Args:
        body (OrderPreviewOrderBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | DeMittwaldV1OrderAIHostingOrderPreviewResponse | DeMittwaldV1OrderDomainOrderPreviewResponse | DeMittwaldV1OrderExternalCertificateOrderPreviewResponse | DeMittwaldV1OrderHostingOrderPreviewResponse | DeMittwaldV1OrderLeadFyndrOrderPreviewResponse | DeMittwaldV1OrderMailArchiveOrderPreviewResponse | OrderPreviewOrderResponse422 | OrderPreviewOrderResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
