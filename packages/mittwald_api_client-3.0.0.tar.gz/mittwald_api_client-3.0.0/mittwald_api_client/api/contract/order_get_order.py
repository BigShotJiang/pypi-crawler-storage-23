from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_order_customer_order import DeMittwaldV1OrderCustomerOrder
from ...models.order_get_order_response_429 import OrderGetOrderResponse429
from ...types import Response


def _get_kwargs(
    order_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/orders/{order_id}".format(
            order_id=quote(str(order_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeMittwaldV1CommonsError | DeMittwaldV1OrderCustomerOrder | OrderGetOrderResponse429:
    if response.status_code == 200:
        response_200 = DeMittwaldV1OrderCustomerOrder.from_dict(response.json())

        return response_200

    if response.status_code == 429:
        response_429 = OrderGetOrderResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1OrderCustomerOrder | OrderGetOrderResponse429]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    order_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1OrderCustomerOrder | OrderGetOrderResponse429]:
    """Get Order for Customer.

     Get details of a single Order, User must have access to the Order/Customer.

    Args:
        order_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1OrderCustomerOrder | OrderGetOrderResponse429]
    """

    kwargs = _get_kwargs(
        order_id=order_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    order_id: str,
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | DeMittwaldV1OrderCustomerOrder | OrderGetOrderResponse429 | None:
    """Get Order for Customer.

     Get details of a single Order, User must have access to the Order/Customer.

    Args:
        order_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1OrderCustomerOrder | OrderGetOrderResponse429
    """

    return sync_detailed(
        order_id=order_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    order_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeMittwaldV1CommonsError | DeMittwaldV1OrderCustomerOrder | OrderGetOrderResponse429]:
    """Get Order for Customer.

     Get details of a single Order, User must have access to the Order/Customer.

    Args:
        order_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1OrderCustomerOrder | OrderGetOrderResponse429]
    """

    kwargs = _get_kwargs(
        order_id=order_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    order_id: str,
    *,
    client: AuthenticatedClient,
) -> DeMittwaldV1CommonsError | DeMittwaldV1OrderCustomerOrder | OrderGetOrderResponse429 | None:
    """Get Order for Customer.

     Get details of a single Order, User must have access to the Order/Customer.

    Args:
        order_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1OrderCustomerOrder | OrderGetOrderResponse429
    """

    return (
        await asyncio_detailed(
            order_id=order_id,
            client=client,
        )
    ).parsed
