from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.de_mittwald_v1_invoice_invoice import DeMittwaldV1InvoiceInvoice
from ...models.invoice_list_customer_invoices_invoice_types_item import InvoiceListCustomerInvoicesInvoiceTypesItem
from ...models.invoice_list_customer_invoices_order_item import InvoiceListCustomerInvoicesOrderItem
from ...models.invoice_list_customer_invoices_response_429 import InvoiceListCustomerInvoicesResponse429
from ...models.invoice_list_customer_invoices_sort_item import InvoiceListCustomerInvoicesSortItem
from ...models.invoice_list_customer_invoices_status_item import InvoiceListCustomerInvoicesStatusItem
from ...types import UNSET, Response, Unset


def _get_kwargs(
    customer_id: str,
    *,
    invoice_types: list[InvoiceListCustomerInvoicesInvoiceTypesItem] | Unset = UNSET,
    status: list[InvoiceListCustomerInvoicesStatusItem] | Unset = UNSET,
    search: str | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[InvoiceListCustomerInvoicesSortItem] | Unset = UNSET,
    order: list[InvoiceListCustomerInvoicesOrderItem] | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_invoice_types: list[str] | Unset = UNSET
    if not isinstance(invoice_types, Unset):
        json_invoice_types = []
        for invoice_types_item_data in invoice_types:
            invoice_types_item = invoice_types_item_data.value
            json_invoice_types.append(invoice_types_item)

    params["invoiceTypes"] = json_invoice_types

    json_status: list[str] | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = []
        for status_item_data in status:
            status_item = status_item_data.value
            json_status.append(status_item)

    params["status"] = json_status

    params["search"] = search

    params["limit"] = limit

    params["skip"] = skip

    params["page"] = page

    json_sort: list[str] | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = []
        for sort_item_data in sort:
            sort_item = sort_item_data.value
            json_sort.append(sort_item)

    params["sort"] = json_sort

    json_order: list[str] | Unset = UNSET
    if not isinstance(order, Unset):
        json_order = []
        for order_item_data in order:
            order_item = order_item_data.value
            json_order.append(order_item)

    params["order"] = json_order

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/customers/{customer_id}/invoices".format(
            customer_id=quote(str(customer_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | InvoiceListCustomerInvoicesResponse429
    | list[DeMittwaldV1InvoiceInvoice]
):
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = DeMittwaldV1InvoiceInvoice.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = DeMittwaldV1CommonsError.from_dict(response.json())

        return response_404

    if response.status_code == 429:
        response_429 = InvoiceListCustomerInvoicesResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | InvoiceListCustomerInvoicesResponse429
    | list[DeMittwaldV1InvoiceInvoice]
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    customer_id: str,
    *,
    client: AuthenticatedClient,
    invoice_types: list[InvoiceListCustomerInvoicesInvoiceTypesItem] | Unset = UNSET,
    status: list[InvoiceListCustomerInvoicesStatusItem] | Unset = UNSET,
    search: str | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[InvoiceListCustomerInvoicesSortItem] | Unset = UNSET,
    order: list[InvoiceListCustomerInvoicesOrderItem] | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | InvoiceListCustomerInvoicesResponse429
    | list[DeMittwaldV1InvoiceInvoice]
]:
    """List Invoices of a Customer.

    Args:
        customer_id (str):
        invoice_types (list[InvoiceListCustomerInvoicesInvoiceTypesItem] | Unset):
        status (list[InvoiceListCustomerInvoicesStatusItem] | Unset):
        search (str | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[InvoiceListCustomerInvoicesSortItem] | Unset):
        order (list[InvoiceListCustomerInvoicesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | InvoiceListCustomerInvoicesResponse429 | list[DeMittwaldV1InvoiceInvoice]]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        invoice_types=invoice_types,
        status=status,
        search=search,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    customer_id: str,
    *,
    client: AuthenticatedClient,
    invoice_types: list[InvoiceListCustomerInvoicesInvoiceTypesItem] | Unset = UNSET,
    status: list[InvoiceListCustomerInvoicesStatusItem] | Unset = UNSET,
    search: str | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[InvoiceListCustomerInvoicesSortItem] | Unset = UNSET,
    order: list[InvoiceListCustomerInvoicesOrderItem] | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | InvoiceListCustomerInvoicesResponse429
    | list[DeMittwaldV1InvoiceInvoice]
    | None
):
    """List Invoices of a Customer.

    Args:
        customer_id (str):
        invoice_types (list[InvoiceListCustomerInvoicesInvoiceTypesItem] | Unset):
        status (list[InvoiceListCustomerInvoicesStatusItem] | Unset):
        search (str | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[InvoiceListCustomerInvoicesSortItem] | Unset):
        order (list[InvoiceListCustomerInvoicesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | InvoiceListCustomerInvoicesResponse429 | list[DeMittwaldV1InvoiceInvoice]
    """

    return sync_detailed(
        customer_id=customer_id,
        client=client,
        invoice_types=invoice_types,
        status=status,
        search=search,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    ).parsed


async def asyncio_detailed(
    customer_id: str,
    *,
    client: AuthenticatedClient,
    invoice_types: list[InvoiceListCustomerInvoicesInvoiceTypesItem] | Unset = UNSET,
    status: list[InvoiceListCustomerInvoicesStatusItem] | Unset = UNSET,
    search: str | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[InvoiceListCustomerInvoicesSortItem] | Unset = UNSET,
    order: list[InvoiceListCustomerInvoicesOrderItem] | Unset = UNSET,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | InvoiceListCustomerInvoicesResponse429
    | list[DeMittwaldV1InvoiceInvoice]
]:
    """List Invoices of a Customer.

    Args:
        customer_id (str):
        invoice_types (list[InvoiceListCustomerInvoicesInvoiceTypesItem] | Unset):
        status (list[InvoiceListCustomerInvoicesStatusItem] | Unset):
        search (str | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[InvoiceListCustomerInvoicesSortItem] | Unset):
        order (list[InvoiceListCustomerInvoicesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | InvoiceListCustomerInvoicesResponse429 | list[DeMittwaldV1InvoiceInvoice]]
    """

    kwargs = _get_kwargs(
        customer_id=customer_id,
        invoice_types=invoice_types,
        status=status,
        search=search,
        limit=limit,
        skip=skip,
        page=page,
        sort=sort,
        order=order,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    customer_id: str,
    *,
    client: AuthenticatedClient,
    invoice_types: list[InvoiceListCustomerInvoicesInvoiceTypesItem] | Unset = UNSET,
    status: list[InvoiceListCustomerInvoicesStatusItem] | Unset = UNSET,
    search: str | Unset = UNSET,
    limit: int | Unset = 1000,
    skip: int | Unset = 0,
    page: int | Unset = UNSET,
    sort: list[InvoiceListCustomerInvoicesSortItem] | Unset = UNSET,
    order: list[InvoiceListCustomerInvoicesOrderItem] | Unset = UNSET,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | InvoiceListCustomerInvoicesResponse429
    | list[DeMittwaldV1InvoiceInvoice]
    | None
):
    """List Invoices of a Customer.

    Args:
        customer_id (str):
        invoice_types (list[InvoiceListCustomerInvoicesInvoiceTypesItem] | Unset):
        status (list[InvoiceListCustomerInvoicesStatusItem] | Unset):
        search (str | Unset):
        limit (int | Unset):  Default: 1000.
        skip (int | Unset):  Default: 0.
        page (int | Unset):
        sort (list[InvoiceListCustomerInvoicesSortItem] | Unset):
        order (list[InvoiceListCustomerInvoicesOrderItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | InvoiceListCustomerInvoicesResponse429 | list[DeMittwaldV1InvoiceInvoice]
    """

    return (
        await asyncio_detailed(
            customer_id=customer_id,
            client=client,
            invoice_types=invoice_types,
            status=status,
            search=search,
            limit=limit,
            skip=skip,
            page=page,
            sort=sort,
            order=order,
        )
    ).parsed
