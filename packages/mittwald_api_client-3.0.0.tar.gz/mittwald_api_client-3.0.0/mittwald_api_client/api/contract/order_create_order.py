from http import HTTPStatus
from typing import Any

import httpx

from ...client import AuthenticatedClient, Client
from ...models.de_mittwald_v1_commons_error import DeMittwaldV1CommonsError
from ...models.de_mittwald_v1_commons_validation_errors import DeMittwaldV1CommonsValidationErrors
from ...models.order_create_order_body import OrderCreateOrderBody
from ...models.order_create_order_response_201 import OrderCreateOrderResponse201
from ...models.order_create_order_response_422 import OrderCreateOrderResponse422
from ...models.order_create_order_response_429 import OrderCreateOrderResponse429
from ...types import Response


def _get_kwargs(
    *,
    body: OrderCreateOrderBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v2/orders",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | OrderCreateOrderResponse201
    | OrderCreateOrderResponse422
    | OrderCreateOrderResponse429
):
    if response.status_code == 201:
        response_201 = OrderCreateOrderResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = DeMittwaldV1CommonsValidationErrors.from_dict(response.json())

        return response_400

    if response.status_code == 422:
        response_422 = OrderCreateOrderResponse422.from_dict(response.json())

        return response_422

    if response.status_code == 429:
        response_429 = OrderCreateOrderResponse429.from_dict(response.json())

        return response_429

    response_default = DeMittwaldV1CommonsError.from_dict(response.json())

    return response_default


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | OrderCreateOrderResponse201
    | OrderCreateOrderResponse422
    | OrderCreateOrderResponse429
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: OrderCreateOrderBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | OrderCreateOrderResponse201
    | OrderCreateOrderResponse422
    | OrderCreateOrderResponse429
]:
    """Create an Order.

    Args:
        body (OrderCreateOrderBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | OrderCreateOrderResponse201 | OrderCreateOrderResponse422 | OrderCreateOrderResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: OrderCreateOrderBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | OrderCreateOrderResponse201
    | OrderCreateOrderResponse422
    | OrderCreateOrderResponse429
    | None
):
    """Create an Order.

    Args:
        body (OrderCreateOrderBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | OrderCreateOrderResponse201 | OrderCreateOrderResponse422 | OrderCreateOrderResponse429
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: OrderCreateOrderBody,
) -> Response[
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | OrderCreateOrderResponse201
    | OrderCreateOrderResponse422
    | OrderCreateOrderResponse429
]:
    """Create an Order.

    Args:
        body (OrderCreateOrderBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | OrderCreateOrderResponse201 | OrderCreateOrderResponse422 | OrderCreateOrderResponse429]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: OrderCreateOrderBody,
) -> (
    DeMittwaldV1CommonsError
    | DeMittwaldV1CommonsValidationErrors
    | OrderCreateOrderResponse201
    | OrderCreateOrderResponse422
    | OrderCreateOrderResponse429
    | None
):
    """Create an Order.

    Args:
        body (OrderCreateOrderBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeMittwaldV1CommonsError | DeMittwaldV1CommonsValidationErrors | OrderCreateOrderResponse201 | OrderCreateOrderResponse422 | OrderCreateOrderResponse429
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
