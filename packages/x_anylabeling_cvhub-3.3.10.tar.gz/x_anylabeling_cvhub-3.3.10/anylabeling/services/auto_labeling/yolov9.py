from .__base__.yolo import YOLO


class YOLOv9(YOLO):
    pass
