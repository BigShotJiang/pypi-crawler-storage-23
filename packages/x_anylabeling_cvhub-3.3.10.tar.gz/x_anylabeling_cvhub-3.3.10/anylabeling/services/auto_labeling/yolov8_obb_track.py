from .__base__.yolo import YOLO


class YOLOv8_Obb_Tracker(YOLO):
    pass
