from .__base__.yolo import YOLO


class YOLOv6(YOLO):
    pass
