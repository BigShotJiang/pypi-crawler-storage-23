from .__base__.yolo import YOLO


class YOLOv8(YOLO):
    pass
