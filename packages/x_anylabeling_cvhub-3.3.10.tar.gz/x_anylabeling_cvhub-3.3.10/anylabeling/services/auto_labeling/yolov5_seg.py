from .__base__.yolo import YOLO


class YOLOv5_Seg(YOLO):
    pass
