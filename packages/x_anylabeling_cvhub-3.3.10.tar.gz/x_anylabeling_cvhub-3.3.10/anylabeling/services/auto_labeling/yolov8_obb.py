from .__base__.yolo import YOLO


class YOLOv8_OBB(YOLO):
    pass
