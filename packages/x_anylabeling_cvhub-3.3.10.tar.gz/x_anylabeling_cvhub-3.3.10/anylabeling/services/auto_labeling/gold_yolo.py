from .__base__.yolo import YOLO


class Gold_YOLO(YOLO):
    pass
