from .grounding_dino import GroundingDINOBase

__all__ = ["GroundingDINOBase"]
