from .ppocr_v4 import PPOCRv4


class PPOCRv5(PPOCRv4):
    pass
