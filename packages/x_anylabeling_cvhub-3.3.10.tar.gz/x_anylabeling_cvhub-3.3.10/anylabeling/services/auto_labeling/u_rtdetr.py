from .__base__.yolo import YOLO


class U_RTDETR(YOLO):
    pass
