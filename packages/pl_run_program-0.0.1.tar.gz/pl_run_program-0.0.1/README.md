# pl-run-program

A simple interface for running programs.

## License

Licensed under the Apache License 2.0. See [LICENSE](./LICENSE).
