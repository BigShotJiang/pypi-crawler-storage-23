from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="brocodeai",
    version="0.1.0",
    author="Michael Nkomo",
    author_email="michaelmlungisinkomo@gmail.com",
    description="The official Python client for the Brocode AI unified API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Kedarcv/brocodeai-python",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "httpx>=0.23.0",
    ],
)
