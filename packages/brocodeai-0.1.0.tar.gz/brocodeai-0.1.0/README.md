# Brocode AI Python SDK

The official Python library for the Brocode AI unified API. Access over 100+ frontier AI models via a single standardized interface.

## Installation

```bash
pip install brocodeai
```

## Usage

You need a Brocode AI API key. Get yours at the [Brocode AI Dashboard](https://brocodeai-rho.vercel.app).

```python
import os
from brocodeai import BrocodeAI

# Initialize the client. It will automatically look for the BROCODEAI_API_KEY environment variable.
client = BrocodeAI(
    api_key=os.environ.get("BROCODEAI_API_KEY"),
)

# Chat Completions
chat_completion = client.chat.completions.create(
    messages=[
        {
            "role": "user",
            "content": "Say this is a test",
        }
    ],
    model="meta/llama-3.1-70b-instruct",
)

print(chat_completion.choices[0].message.content)

# Embeddings
embedding = client.embeddings.create(
    input="Convert this text to an embedding.",
    model="nvidia/nv-embedqa-e5-v5"
)
print(embedding.data[0].embedding)
```
