import os
import httpx
from typing import List, Dict, Any, Optional

class Struct:
    """A convenient class to access dictionary keys as attributes."""
    def __init__(self, **entries):
        for k, v in entries.items():
            if isinstance(v, dict):
                self.__dict__[k] = Struct(**v)
            elif isinstance(v, list):
                self.__dict__[k] = [Struct(**item) if isinstance(item, dict) else item for item in v]
            else:
                self.__dict__[k] = v

class Completions:
    def __init__(self, client: httpx.Client):
        self._client = client

    def create(self, model: str, messages: List[Dict[str, Any]], **kwargs) -> Any:
        payload = {"model": model, "messages": messages, **kwargs}
        response = self._client.post("/models/chat/completions", json=payload)
        response.raise_for_status()
        return Struct(**response.json())

class Chat:
    def __init__(self, client: httpx.Client):
        self.completions = Completions(client)

class Embeddings:
    def __init__(self, client: httpx.Client):
        self._client = client

    def create(self, model: str, input: str, **kwargs) -> Any:
        payload = {"model": model, "input": input, "input_type": "query", **kwargs}
        response = self._client.post("/models/embeddings", json=payload)
        response.raise_for_status()
        return Struct(**response.json())

class Models:
    def __init__(self, client: httpx.Client):
        self._client = client

    def list(self) -> Any:
        response = self._client.get("/models")
        response.raise_for_status()
        return Struct(**response.json())

class BrocodeAI:
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        self.api_key = api_key or os.environ.get("BROCODEAI_API_KEY")
        if not self.api_key:
            raise ValueError("The api_key client option must be set either by passing api_key to the client or by setting the BROCODEAI_API_KEY environment variable")
        
        self.base_url = base_url or "https://brocodeai-api.vercel.app/v1"
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=60.0
        )
        
        self.chat = Chat(self._client)
        self.embeddings = Embeddings(self._client)
        self.models = Models(self._client)
