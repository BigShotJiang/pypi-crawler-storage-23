"""Database models reflected from PostgreSQL schema."""

from sqlalchemy import Integer, String, Numeric, Boolean, Text, Time, JSON, func, ForeignKey
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from datetime import datetime
from decimal import Decimal
from typing import Optional, List


class Base(DeclarativeBase):
    """Base class for all ORM models."""
    pass

class SchemaVersion(Base):
    __tablename__ = "schema_version"
    version: Mapped[str] = mapped_column(primary_key=True)

    applied_at: Mapped[datetime] = mapped_column(Time,
        server_default=func.now()
    )

class Agents(Base):
    __tablename__ = "agents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    type: Mapped[str] = mapped_column(String)
    
    # Relationships
    generated_analyses: Mapped[List["GeneratedAnalyses"]] = relationship("GeneratedAnalyses", back_populates="agent")
    agents_sources: Mapped[List["AgentsSources"]] = relationship("AgentsSources", back_populates="agent")


class AgentsSources(Base):
    __tablename__ = "agents_sources"

    agent_id: Mapped[int] = mapped_column(Integer, ForeignKey("agents.id"), primary_key=True, nullable=False)
    news_source_id: Mapped[int] = mapped_column(Integer, ForeignKey("news_sources.id"), primary_key=True, nullable=False)
    reliability_score: Mapped[Decimal] = mapped_column(Numeric)
    
    # Relationships
    agent: Mapped["Agents"] = relationship("Agents", back_populates="agents_sources")
    source: Mapped["NewsSources"] = relationship("NewsSources", back_populates="agents_sources")


class AlembicVersion(Base):
    __tablename__ = "alembic_version"

    version_num: Mapped[str] = mapped_column(String(32), primary_key=True, nullable=False)


class Alerts(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), nullable=False)
    type: Mapped[str] = mapped_column(String(9))
    
    # Relationships
    user: Mapped["Users"] = relationship("Users", back_populates="alerts")
    assets_alerts: Mapped[List["AssetsAlerts"]] = relationship("AssetsAlerts", back_populates="alert")
    publication_alerts: Mapped[List["PublicationAlerts"]] = relationship("PublicationAlerts", back_populates="alert")


class AnalysisArtifacts(Base):
    __tablename__ = "analysis_artifacts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(Integer, ForeignKey("generated_analyses.id"), nullable=False)
    artifact_type: Mapped[str] = mapped_column(String(8))
    uri: Mapped[str] = mapped_column(String)
    checksum: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    analysis: Mapped["GeneratedAnalyses"] = relationship("GeneratedAnalyses", back_populates="analysis_artifacts")


class AnalysisAssets(Base):
    __tablename__ = "analysis_assets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(Integer, ForeignKey("generated_analyses.id"), nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, ForeignKey("assets.id"), nullable=False)
    bias: Mapped[str] = mapped_column(String(7))
    expected_move_pct: Mapped[Decimal] = mapped_column(Numeric)
    expected_price_low: Mapped[Decimal] = mapped_column(Numeric)
    expected_price_high: Mapped[Decimal] = mapped_column(Numeric)
    expected_volatility: Mapped[Decimal] = mapped_column(Numeric)
    confidence_level: Mapped[Decimal] = mapped_column(Numeric)
    score: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    analysis: Mapped["GeneratedAnalyses"] = relationship("GeneratedAnalyses", back_populates="analysis_assets")
    asset: Mapped["Assets"] = relationship("Assets", back_populates="analysis_assets")


class AnalysisHistory(Base):
    __tablename__ = "analysis_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(Integer, ForeignKey("generated_analyses.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)
    
    # Relationships
    analysis: Mapped[Optional["GeneratedAnalyses"]] = relationship("GeneratedAnalyses", back_populates="analysis_history")


class AnalysisIndicators(Base):
    __tablename__ = "analysis_indicators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(Integer, ForeignKey("generated_analyses.id"), nullable=False)
    indicator_id: Mapped[int] = mapped_column(Integer, ForeignKey("fundamental_indicators.id"), nullable=False)
    raw_value: Mapped[Decimal] = mapped_column(Numeric)
    normalized_value: Mapped[Decimal] = mapped_column(Numeric)
    score: Mapped[Decimal] = mapped_column(Numeric)
    weight: Mapped[Decimal] = mapped_column(Numeric)
    signal: Mapped[str] = mapped_column(String(8))
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    analysis: Mapped["GeneratedAnalyses"] = relationship("GeneratedAnalyses", back_populates="analysis_indicators")
    indicator: Mapped["FundamentalIndicators"] = relationship("FundamentalIndicators", back_populates="analysis_indicators")


class AnalysisNewsSources(Base):
    __tablename__ = "analysis_news_sources"

    analysis_id: Mapped[int] = mapped_column(Integer, ForeignKey("generated_analyses.id"), primary_key=True, nullable=False)
    source_id: Mapped[int] = mapped_column(Integer, ForeignKey("news_sources.id"), primary_key=True, nullable=False)
    
    # Relationships
    analysis: Mapped["GeneratedAnalyses"] = relationship("GeneratedAnalyses", back_populates="analysis_news_sources")
    source: Mapped["NewsSources"] = relationship("NewsSources", back_populates="analysis_news_sources")


class AssetSpecificExposures(Base):
    __tablename__ = "asset_specific_exposures"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(Integer, ForeignKey("macro_regimes.id"), nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, ForeignKey("assets.id"), nullable=False)
    exposure: Mapped[Decimal] = mapped_column(Numeric)
    override: Mapped[bool] = mapped_column(Boolean)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    macro_regime: Mapped["MacroRegimes"] = relationship("MacroRegimes", back_populates="asset_specific_exposures")
    asset: Mapped["Assets"] = relationship("Assets", back_populates="asset_specific_exposures")


class Assets(Base):
    __tablename__ = "assets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    symbol: Mapped[str] = mapped_column(String)
    name: Mapped[str] = mapped_column(String)
    asset_class: Mapped[str] = mapped_column(String(11))
    asset_subclass: Mapped[str] = mapped_column(String(8))
    currency: Mapped[str] = mapped_column(String)
    base_currency: Mapped[str] = mapped_column(String)
    quote_currency: Mapped[str] = mapped_column(String)
    lot_unit: Mapped[Decimal] = mapped_column(Numeric)
    price_tick: Mapped[Decimal] = mapped_column(Numeric)
    quantity_step: Mapped[Decimal] = mapped_column(Numeric)
    liquidity_profile: Mapped[str] = mapped_column(String(9))
    volatility_profile: Mapped[str] = mapped_column(String(6))
    trading_hours: Mapped[str] = mapped_column(String)
    market: Mapped[str] = mapped_column(String(3))
    
    # Relationships
    assets_alerts: Mapped[List["AssetsAlerts"]] = relationship("AssetsAlerts", back_populates="asset")
    operations: Mapped[List["Operations"]] = relationship("Operations", back_populates="asset")
    opportunities: Mapped[List["Opportunities"]] = relationship("Opportunities", back_populates="asset")
    analysis_assets: Mapped[List["AnalysisAssets"]] = relationship("AnalysisAssets", back_populates="asset")
    asset_specific_exposures: Mapped[List["AssetSpecificExposures"]] = relationship("AssetSpecificExposures", back_populates="asset")
    price_history: Mapped[List["PriceHistory"]] = relationship("PriceHistory", back_populates="asset")


class AssetsAlerts(Base):
    __tablename__ = "assets_alerts"

    alert_id: Mapped[int] = mapped_column(Integer, ForeignKey("alerts.id"), primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, ForeignKey("assets.id"), primary_key=True, nullable=False)
    asset_price: Mapped[Decimal] = mapped_column(Numeric)
    
    # Relationships
    alert: Mapped["Alerts"] = relationship("Alerts", back_populates="assets_alerts")
    asset: Mapped["Assets"] = relationship("Assets", back_populates="assets_alerts")


class BehavioralStats(Base):
    __tablename__ = "behavioral_stats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, ForeignKey("portfolios.id"), nullable=False)
    trade_frequency: Mapped[Decimal] = mapped_column(Numeric)
    overtrading_score: Mapped[Decimal] = mapped_column(Numeric)
    avg_holding_time: Mapped[Decimal] = mapped_column(Numeric)
    deviation_from_expected_horizon: Mapped[Decimal] = mapped_column(Numeric)
    revenge_trading_score: Mapped[Decimal] = mapped_column(Numeric)
    consistency_score: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    portfolio: Mapped["Portfolios"] = relationship("Portfolios", back_populates="behavioral_stats")


class EconomicCalendar(Base):
    __tablename__ = "economic_calendar"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    fundamental_indicator_id: Mapped[int] = mapped_column(Integer, ForeignKey("fundamental_indicators.id"), nullable=False)
    previous_value: Mapped[Decimal] = mapped_column(Numeric)
    forecast_value: Mapped[Decimal] = mapped_column(Numeric)
    actual_value: Mapped[Decimal] = mapped_column(Numeric)
    event_name: Mapped[str] = mapped_column(String)
    country: Mapped[str] = mapped_column(String)
    impact_level: Mapped[str] = mapped_column(String)
    event_date: Mapped[datetime] = mapped_column(Time)
    
    # Relationships
    fundamental_indicator: Mapped["FundamentalIndicators"] = relationship("FundamentalIndicators", back_populates="economic_calendars")
    publication_alerts: Mapped[List["PublicationAlerts"]] = relationship("PublicationAlerts", back_populates="publication")
    indicator_scores: Mapped[List["IndicatorScores"]] = relationship("IndicatorScores", back_populates="publication")


class ExecutionStats(Base):
    __tablename__ = "execution_stats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, ForeignKey("portfolios.id"), nullable=False)
    avg_slippage: Mapped[Decimal] = mapped_column(Numeric)
    avg_fees: Mapped[Decimal] = mapped_column(Numeric)
    slippage_ratio: Mapped[Decimal] = mapped_column(Numeric)
    fill_rate: Mapped[Decimal] = mapped_column(Numeric)
    avg_time_to_execution: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    portfolio: Mapped["Portfolios"] = relationship("Portfolios", back_populates="execution_stats")


class FundamentalIndicators(Base):
    __tablename__ = "fundamental_indicators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    code: Mapped[str] = mapped_column(String)
    description: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String)
    sub_category: Mapped[str] = mapped_column(String)
    unit: Mapped[str] = mapped_column(String)
    value_type: Mapped[str] = mapped_column(String(6))
    directionality: Mapped[str] = mapped_column(String(5))
    typical_frequency: Mapped[str] = mapped_column(String(9))
    leading_status: Mapped[str] = mapped_column(String(7))
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    analysis_indicators: Mapped[List["AnalysisIndicators"]] = relationship("AnalysisIndicators", back_populates="indicator")
    indicator_scores: Mapped[List["IndicatorScores"]] = relationship("IndicatorScores", back_populates="indicator")
    indicator_scores_rules: Mapped[List["IndicatorScoresRules"]] = relationship("IndicatorScoresRules", back_populates="indicator")
    economic_calendars: Mapped[List["EconomicCalendar"]] = relationship("EconomicCalendar", back_populates="fundamental_indicator")


class GeneratedAnalyses(Base):
    __tablename__ = "generated_analyses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(Integer, ForeignKey("macro_regimes.id"), nullable=False)
    agent_id: Mapped[int] = mapped_column(Integer, ForeignKey("agents.id"), nullable=False)
    analysis_type: Mapped[str] = mapped_column(String(8))
    time_horizon: Mapped[str] = mapped_column(String(8))
    global_score: Mapped[Decimal] = mapped_column(Numeric)
    confidence_level: Mapped[Decimal] = mapped_column(Numeric)
    bias: Mapped[str] = mapped_column(String(7))
    valid_from: Mapped[datetime] = mapped_column(Time)
    valid_until: Mapped[datetime] = mapped_column(Time)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    macro_regime: Mapped["MacroRegimes"] = relationship("MacroRegimes", back_populates="generated_analyses")
    agent: Mapped["Agents"] = relationship("Agents", back_populates="generated_analyses")
    analysis_news_sources: Mapped[List["AnalysisNewsSources"]] = relationship("AnalysisNewsSources", back_populates="analysis")
    analysis_artifacts: Mapped[List["AnalysisArtifacts"]] = relationship("AnalysisArtifacts", back_populates="analysis")
    analysis_assets: Mapped[List["AnalysisAssets"]] = relationship("AnalysisAssets", back_populates="analysis")
    analysis_indicators: Mapped[List["AnalysisIndicators"]] = relationship("AnalysisIndicators", back_populates="analysis")
    opportunities: Mapped[List["Opportunities"]] = relationship("Opportunities", back_populates="analysis")
    analysis_history: Mapped[List["AnalysisHistory"]] = relationship("AnalysisHistory", back_populates="analysis")


class IndicatorScores(Base):
    __tablename__ = "indicator_scores"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    indicator_id: Mapped[int] = mapped_column(Integer, ForeignKey("fundamental_indicators.id"), nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(Integer, ForeignKey("macro_regimes.id"), nullable=False)
    publication_id: Mapped[int] = mapped_column(Integer, ForeignKey("economic_calendar.id"), nullable=False)
    country_code: Mapped[str] = mapped_column(String)
    score_naive: Mapped[int] = mapped_column(Integer)
    score_weighted: Mapped[Decimal] = mapped_column(Numeric)
    signal_direction: Mapped[str] = mapped_column(String(5))
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    indicator: Mapped["FundamentalIndicators"] = relationship("FundamentalIndicators", back_populates="indicator_scores")
    macro_regime: Mapped["MacroRegimes"] = relationship("MacroRegimes", back_populates="indicator_scores")
    publication: Mapped["EconomicCalendar"] = relationship("EconomicCalendar", back_populates="indicator_scores")


class IndicatorScoresRules(Base):
    __tablename__ = "indicator_scores_rules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    indicator_id: Mapped[int] = mapped_column(Integer, ForeignKey("fundamental_indicators.id"), nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(Integer, ForeignKey("macro_regimes.id"), nullable=False)
    score_naive: Mapped[int] = mapped_column(Integer)
    threshold_low: Mapped[Decimal] = mapped_column(Numeric)
    threshold_high: Mapped[Decimal] = mapped_column(Numeric)
    weight: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    indicator: Mapped["FundamentalIndicators"] = relationship("FundamentalIndicators", back_populates="indicator_scores_rules")
    macro_regime: Mapped["MacroRegimes"] = relationship("MacroRegimes", back_populates="indicator_scores_rules")


class MacroAssetClassExposures(Base):
    __tablename__ = "macro_asset_class_exposures"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(Integer, ForeignKey("macro_regimes.id"), nullable=False)
    asset_class: Mapped[str] = mapped_column(String(11))
    default_exposure: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    macro_regime: Mapped["MacroRegimes"] = relationship("MacroRegimes", back_populates="macro_asset_class_exposures")


class MacroRegimes(Base):
    __tablename__ = "macro_regimes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    description: Mapped[str] = mapped_column(Text)
    growth_trend: Mapped[str] = mapped_column(String(9))
    inflation_trend: Mapped[str] = mapped_column(String(7))
    monetary_policy: Mapped[str] = mapped_column(String(10))
    risk_appetite: Mapped[str] = mapped_column(String(8))
    expected_volatility: Mapped[str] = mapped_column(String(6))
    liquidity_level: Mapped[str] = mapped_column(String(6))
    confidence_score: Mapped[Decimal] = mapped_column(Numeric)
    valid_from: Mapped[datetime] = mapped_column(Time)
    valid_to: Mapped[datetime] = mapped_column(Time)
    
    # Relationships
    generated_analyses: Mapped[List["GeneratedAnalyses"]] = relationship("GeneratedAnalyses", back_populates="macro_regime")
    macro_asset_class_exposures: Mapped[List["MacroAssetClassExposures"]] = relationship("MacroAssetClassExposures", back_populates="macro_regime")
    asset_specific_exposures: Mapped[List["AssetSpecificExposures"]] = relationship("AssetSpecificExposures", back_populates="macro_regime")
    indicator_scores: Mapped[List["IndicatorScores"]] = relationship("IndicatorScores", back_populates="macro_regime")
    indicator_scores_rules: Mapped[List["IndicatorScoresRules"]] = relationship("IndicatorScoresRules", back_populates="macro_regime")


class NewsSources(Base):
    __tablename__ = "news_sources"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    category: Mapped[str] = mapped_column(String)
    country_code: Mapped[str] = mapped_column(String(3))
    
    # Relationships
    analysis_news_sources: Mapped[List["AnalysisNewsSources"]] = relationship("AnalysisNewsSources", back_populates="source")
    agents_sources: Mapped[List["AgentsSources"]] = relationship("AgentsSources", back_populates="source")


class ObjectiveHistory(Base):
    __tablename__ = "objective_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    objective_id: Mapped[int] = mapped_column(Integer, ForeignKey("objectives.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)
    
    # Relationships
    objective: Mapped[Optional["Objectives"]] = relationship("Objectives", back_populates="objective_history")


class Objectives(Base):
    __tablename__ = "objectives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, ForeignKey("portfolios.id"), nullable=False)
    type: Mapped[str] = mapped_column(String)
    target_return: Mapped[Decimal] = mapped_column(Numeric)
    max_drawdown: Mapped[Decimal] = mapped_column(Numeric)
    asset_class: Mapped[str] = mapped_column(String(11))
    exposure: Mapped[Decimal] = mapped_column(Numeric)
    time_horizon: Mapped[str] = mapped_column(String(8))
    priority: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(22))
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    portfolio: Mapped["Portfolios"] = relationship("Portfolios", back_populates="objectives")
    strategy_objectives: Mapped[List["StrategyObjectives"]] = relationship("StrategyObjectives", back_populates="objective")
    objective_history: Mapped[List["ObjectiveHistory"]] = relationship("ObjectiveHistory", back_populates="objective")


class OperationHistory(Base):
    __tablename__ = "operation_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    operation_id: Mapped[int] = mapped_column(Integer, ForeignKey("operations.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)
    
    # Relationships
    operation: Mapped[Optional["Operations"]] = relationship("Operations", back_populates="operation_history")


class Operations(Base):
    __tablename__ = "operations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, ForeignKey("portfolios.id"), nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, ForeignKey("assets.id"), nullable=False)
    strategy_id: Mapped[int] = mapped_column(Integer, ForeignKey("strategies.id"))
    opportunity_id: Mapped[int] = mapped_column(Integer, ForeignKey("opportunities.id"))
    direction: Mapped[str] = mapped_column(String(5))
    operation_type: Mapped[str] = mapped_column(String(13))
    time_horizon: Mapped[str] = mapped_column(String(8))
    quantity: Mapped[Decimal] = mapped_column(Numeric)
    price: Mapped[Decimal] = mapped_column(Numeric)
    notional: Mapped[Decimal] = mapped_column(Numeric)
    stop_loss: Mapped[Decimal] = mapped_column(Numeric)
    take_profit: Mapped[Decimal] = mapped_column(Numeric)
    fees: Mapped[Decimal] = mapped_column(Numeric)
    slippage: Mapped[Decimal] = mapped_column(Numeric)
    status: Mapped[str] = mapped_column(String(8))
    executed_at: Mapped[datetime] = mapped_column(Time)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    portfolio: Mapped["Portfolios"] = relationship("Portfolios", back_populates="operations")
    asset: Mapped["Assets"] = relationship("Assets", back_populates="operations")
    strategy: Mapped[Optional["Strategies"]] = relationship("Strategies", back_populates="operations")
    opportunity: Mapped[Optional["Opportunities"]] = relationship("Opportunities", back_populates="operations")
    operation_history: Mapped[List["OperationHistory"]] = relationship("OperationHistory", back_populates="operation")


class Opportunities(Base):
    __tablename__ = "opportunities"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, ForeignKey("assets.id"), nullable=False)
    strategy_id: Mapped[int] = mapped_column(Integer, ForeignKey("strategies.id"), nullable=False)
    analysis_id: Mapped[int] = mapped_column(Integer, ForeignKey("generated_analyses.id"), nullable=False)
    direction: Mapped[str] = mapped_column(String(5))
    confidence_score: Mapped[Decimal] = mapped_column(Numeric)
    entry_price: Mapped[Decimal] = mapped_column(Numeric)
    stop_loss: Mapped[Decimal] = mapped_column(Numeric)
    take_profit: Mapped[Decimal] = mapped_column(Numeric)
    expected_return: Mapped[Decimal] = mapped_column(Numeric)
    risk_reward_ratio: Mapped[Decimal] = mapped_column(Numeric)
    status: Mapped[str] = mapped_column(String(9))
    valid_from: Mapped[datetime] = mapped_column(Time)
    valid_until: Mapped[datetime] = mapped_column(Time)
    detected_at: Mapped[datetime] = mapped_column(Time)
    closed_at: Mapped[datetime] = mapped_column(Time)
    
    # Relationships
    asset: Mapped["Assets"] = relationship("Assets", back_populates="opportunities")
    strategy: Mapped["Strategies"] = relationship("Strategies", back_populates="opportunities")
    analysis: Mapped["GeneratedAnalyses"] = relationship("GeneratedAnalyses", back_populates="opportunities")
    operations: Mapped[List["Operations"]] = relationship("Operations", back_populates="opportunity")
    opportunity_history: Mapped[List["OpportunityHistory"]] = relationship("OpportunityHistory", back_populates="opportunity")


class OpportunityHistory(Base):
    __tablename__ = "opportunity_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    opportunity_id: Mapped[int] = mapped_column(Integer, ForeignKey("opportunities.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)
    
    # Relationships
    opportunity: Mapped[Optional["Opportunities"]] = relationship("Opportunities", back_populates="opportunity_history")


class PerformanceReturns(Base):
    __tablename__ = "performance_returns"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, ForeignKey("portfolios.id"), nullable=False)
    period: Mapped[str] = mapped_column(String(8))
    total_return: Mapped[Decimal] = mapped_column(Numeric)
    win_rate: Mapped[Decimal] = mapped_column(Numeric)
    avg_win: Mapped[Decimal] = mapped_column(Numeric)
    avg_loss: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    portfolio: Mapped["Portfolios"] = relationship("Portfolios", back_populates="performance_returns")


class PerformanceRisk(Base):
    __tablename__ = "performance_risk"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, ForeignKey("portfolios.id"), nullable=False)
    volatility: Mapped[Decimal] = mapped_column(Numeric)
    max_drawdown: Mapped[Decimal] = mapped_column(Numeric)
    avg_drawdown: Mapped[Decimal] = mapped_column(Numeric)
    drawdown_duration: Mapped[int] = mapped_column(Integer)
    sharpe_ratio: Mapped[Decimal] = mapped_column(Numeric)
    sortino_ratio: Mapped[Decimal] = mapped_column(Numeric)
    calmar_ratio: Mapped[Decimal] = mapped_column(Numeric)
    tail_risk: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    portfolio: Mapped["Portfolios"] = relationship("Portfolios", back_populates="performance_risk")


class PortfolioHistory(Base):
    __tablename__ = "portfolio_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(Integer, ForeignKey("portfolios.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)
    
    # Relationships
    portfolio: Mapped[Optional["Portfolios"]] = relationship("Portfolios", back_populates="portfolio_history")


class Portfolios(Base):
    __tablename__ = "portfolios"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), nullable=False)
    name: Mapped[str] = mapped_column(String)
    description: Mapped[str] = mapped_column(Text)
    base_currency: Mapped[str] = mapped_column(String)
    initial_capital: Mapped[Decimal] = mapped_column(Numeric)
    current_capital: Mapped[Decimal] = mapped_column(Numeric)
    risk_profile: Mapped[str] = mapped_column(String)
    benchmark: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    user: Mapped["Users"] = relationship("Users", back_populates="portfolios")
    operations: Mapped[List["Operations"]] = relationship("Operations", back_populates="portfolio")
    objectives: Mapped[List["Objectives"]] = relationship("Objectives", back_populates="portfolio")
    performance_returns: Mapped[List["PerformanceReturns"]] = relationship("PerformanceReturns", back_populates="portfolio")
    performance_risk: Mapped[List["PerformanceRisk"]] = relationship("PerformanceRisk", back_populates="portfolio")
    execution_stats: Mapped[List["ExecutionStats"]] = relationship("ExecutionStats", back_populates="portfolio")
    behavioral_stats: Mapped[List["BehavioralStats"]] = relationship("BehavioralStats", back_populates="portfolio")
    portfolio_history: Mapped[List["PortfolioHistory"]] = relationship("PortfolioHistory", back_populates="portfolio")


class PriceHistory(Base):
    __tablename__ = "price_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(Integer, ForeignKey("assets.id"))
    high: Mapped[Decimal] = mapped_column(Numeric)
    low: Mapped[Decimal] = mapped_column(Numeric)
    open: Mapped[Decimal] = mapped_column(Numeric)
    close: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    time_unit: Mapped[str] = mapped_column(String)
    
    # Relationships
    asset: Mapped[Optional["Assets"]] = relationship("Assets", back_populates="price_history")


class PublicationAlerts(Base):
    __tablename__ = "publication_alerts"

    alert_id: Mapped[int] = mapped_column(Integer, ForeignKey("alerts.id"), primary_key=True, nullable=False)
    publication_id: Mapped[int] = mapped_column(Integer, ForeignKey("economic_calendar.id"), primary_key=True, nullable=False)
    estimated_date: Mapped[datetime] = mapped_column(Time)
    
    # Relationships
    alert: Mapped["Alerts"] = relationship("Alerts", back_populates="publication_alerts")
    publication: Mapped["EconomicCalendar"] = relationship("EconomicCalendar", back_populates="publication_alerts")


class Strategies(Base):
    __tablename__ = "strategies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    asset_class: Mapped[str] = mapped_column(String(11))
    strategy_type: Mapped[str] = mapped_column(String(13))
    creator_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    max_position_size: Mapped[Decimal] = mapped_column(Numeric)
    expected_return: Mapped[Decimal] = mapped_column(Numeric)
    risk_estimate: Mapped[Decimal] = mapped_column(Numeric)
    leverage: Mapped[Decimal] = mapped_column(Numeric)
    
    # Relationships
    creator: Mapped["Users"] = relationship("Users", back_populates="strategies")
    opportunities: Mapped[List["Opportunities"]] = relationship("Opportunities", back_populates="strategy")
    operations: Mapped[List["Operations"]] = relationship("Operations", back_populates="strategy")
    strategy_objectives: Mapped[List["StrategyObjectives"]] = relationship("StrategyObjectives", back_populates="strategy")
    strategy_history: Mapped[List["StrategyHistory"]] = relationship("StrategyHistory", back_populates="strategy")


class StrategyHistory(Base):
    __tablename__ = "strategy_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    strategy_id: Mapped[int] = mapped_column(Integer, ForeignKey("strategies.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(Time)
    
    # Relationships
    strategy: Mapped[Optional["Strategies"]] = relationship("Strategies", back_populates="strategy_history")


class StrategyObjectives(Base):
    __tablename__ = "strategy_objectives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    strategy_id: Mapped[int] = mapped_column(Integer, ForeignKey("strategies.id"), nullable=False)
    objective_id: Mapped[int] = mapped_column(Integer, ForeignKey("objectives.id"), nullable=False)
    correlation_ratio: Mapped[Decimal] = mapped_column(Numeric)
    
    # Relationships
    strategy: Mapped["Strategies"] = relationship("Strategies", back_populates="strategy_objectives")
    objective: Mapped["Objectives"] = relationship("Objectives", back_populates="strategy_objectives")


class Users(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    email: Mapped[str] = mapped_column(String, nullable=False)
    password_hash: Mapped[str] = mapped_column(String)
    role: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(Time, server_default=func.now(), nullable=False)
    
    # Relationships
    alerts: Mapped[List["Alerts"]] = relationship("Alerts", back_populates="user")
    portfolios: Mapped[List["Portfolios"]] = relationship("Portfolios", back_populates="user")
    strategies: Mapped[List["Strategies"]] = relationship("Strategies", back_populates="creator")

