"""Framework and sanitizer model catalogs."""

