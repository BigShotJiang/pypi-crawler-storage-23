"""Allow running as `python -m oncecheck`."""

from .cli import cli

cli()
