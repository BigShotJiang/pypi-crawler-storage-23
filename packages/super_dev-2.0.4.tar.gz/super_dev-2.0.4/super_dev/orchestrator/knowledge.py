"""
知识增强模块

将用户输入需求通过「本地知识库 + 联网检索」进行增强，
为后续 PRD / 架构 / UIUX / Spec 生成提供更完整上下文。
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import urllib.parse
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import requests  # type: ignore[import-untyped]


@dataclass
class KnowledgeItem:
    """知识项"""

    source: str
    title: str
    snippet: str
    link: str = ""
    score: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "title": self.title,
            "snippet": self.snippet,
            "link": self.link,
            "score": self.score,
        }


class KnowledgeAugmenter:
    """需求知识增强器"""

    _STOPWORDS = {
        "the",
        "and",
        "for",
        "with",
        "that",
        "from",
        "this",
        "功能",
        "项目",
        "系统",
        "需要",
        "支持",
        "实现",
        "一个",
        "需求",
    }
    _STAGE_ORDER = [
        "research",
        "prd",
        "architecture",
        "uiux",
        "spec",
        "frontend",
        "backend",
        "quality",
        "delivery",
    ]
    _DOMAIN_STAGE_MAP = {
        "product": ["research", "prd", "spec"],
        "design": ["research", "uiux", "frontend"],
        "architecture": ["architecture", "spec", "backend"],
        "development": ["architecture", "spec", "frontend", "backend"],
        "testing": ["quality"],
        "security": ["architecture", "backend", "quality"],
        "cicd": ["quality", "delivery"],
        "operations": ["quality", "delivery"],
        "data": ["architecture", "backend", "quality"],
        "incident": ["quality", "delivery"],
        "ai": ["research", "architecture", "quality", "delivery"],
        "00-governance": ["research", "prd", "architecture", "uiux", "spec", "quality", "delivery"],
        "docs": ["research", "prd", "architecture", "uiux"],
        "specs": ["spec"],
    }

    def __init__(
        self,
        project_dir: Path,
        web_enabled: bool = True,
        allowed_web_domains: list[str] | None = None,
        cache_ttl_seconds: int | None = None,
    ):
        self.project_dir = Path(project_dir).resolve()
        self.web_enabled = web_enabled
        self.docs_dir = self.project_dir / "docs"
        self.knowledge_dir = self.project_dir / "knowledge"
        self.specs_dir = self.project_dir / ".super-dev" / "specs"
        self.data_dir = self.project_dir / "super_dev" / "data"
        self.builtin_data_dir = Path(__file__).resolve().parents[1] / "data"
        env_domains = [
            item.strip().lower()
            for item in os.getenv("SUPER_DEV_KNOWLEDGE_ALLOWED_DOMAINS", "").split(",")
            if item.strip()
        ]
        selected_domains = allowed_web_domains if allowed_web_domains is not None else env_domains
        self.allowed_web_domains = [item.strip().lower() for item in selected_domains if item.strip()]
        env_cache_ttl = os.getenv("SUPER_DEV_KNOWLEDGE_CACHE_TTL_SECONDS", "").strip()
        env_cache_ttl_value = int(env_cache_ttl) if env_cache_ttl.isdigit() else 1800
        self.cache_ttl_seconds = cache_ttl_seconds if cache_ttl_seconds is not None else env_cache_ttl_value
        self._last_web_stats: dict[str, Any] = {
            "provider": "none",
            "raw_count": 0,
            "filtered_count": 0,
            "filtered_out_count": 0,
        }

    def augment(
        self,
        requirement: str,
        domain: str = "",
        max_local_results: int = 8,
        max_web_results: int = 5,
    ) -> dict[str, Any]:
        """对需求做知识增强"""
        query = requirement.strip()
        keywords = self._extract_keywords(query)

        local_items = self._collect_local_items(
            keywords=keywords,
            max_results=max_local_results,
        )
        web_items = self._collect_web_items(
            query=self._build_web_query(query, domain),
            max_results=max_web_results,
        )

        enriched_requirement = self._compose_enriched_requirement(
            requirement=requirement,
            local_items=local_items,
            web_items=web_items,
        )
        research_summary = self._build_research_summary(
            requirement=requirement,
            domain=domain,
            keywords=keywords,
            local_items=local_items,
            web_items=web_items,
        )
        knowledge_application_plan = self._build_knowledge_application_plan(local_items)

        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "original_requirement": requirement,
            "domain": domain,
            "keywords": keywords,
            "local_knowledge": [item.to_dict() for item in local_items],
            "web_knowledge": [item.to_dict() for item in web_items],
            "citations": {
                "local": [self._to_citation(item) for item in local_items],
                "web": [self._to_citation(item) for item in web_items],
            },
            "metadata": {
                "web_enabled": self.web_enabled,
                "allowed_web_domains": self.allowed_web_domains,
                "web_stats": self._last_web_stats,
            },
            "research_summary": research_summary,
            "knowledge_application_plan": knowledge_application_plan,
            "enriched_requirement": enriched_requirement,
        }

    def to_markdown(self, bundle: dict[str, Any]) -> str:
        """将增强结果渲染为 Markdown 报告"""
        lines = [
            "# 需求增强报告",
            "",
            f"**原始需求**: {bundle.get('original_requirement', '')}",
            f"**领域**: {bundle.get('domain', 'general') or 'general'}",
            "",
            "## 提取关键词",
            "",
            ", ".join(bundle.get("keywords", [])) or "(none)",
            "",
            "## 本地知识库结果",
            "",
        ]

        local_items = bundle.get("local_knowledge", [])
        if not local_items:
            lines.append("- 未命中本地知识。")
        else:
            for item in local_items:
                title = item.get("title", "unknown")
                snippet = item.get("snippet", "")
                lines.append(f"- **{title}** ({item.get('source', 'local')}): {snippet}")
        lines.append("")

        lines.extend(["## 本地知识应用计划", ""])
        plan = bundle.get("knowledge_application_plan", {}) or {}
        stage_guidance = plan.get("stage_guidance", {}) if isinstance(plan, dict) else {}
        hard_constraints = plan.get("hard_constraints", []) if isinstance(plan, dict) else []
        if isinstance(hard_constraints, list) and hard_constraints:
            lines.append("### 硬约束")
            lines.append("")
            for item in hard_constraints:
                if isinstance(item, str):
                    lines.append(f"- {item}")
            lines.append("")
        if isinstance(stage_guidance, dict) and stage_guidance:
            for stage in self._STAGE_ORDER:
                entries = stage_guidance.get(stage, [])
                lines.extend(self._render_summary_section(f"### {self._stage_label(stage)}", entries if isinstance(entries, list) else []))
        else:
            lines.append("- 当前未生成阶段化知识应用计划。")
            lines.append("")

        lines.extend(["## 联网检索结果", ""])
        web_items = bundle.get("web_knowledge", [])
        if not web_items:
            lines.append("- 未获得联网结果（可能网络受限或无匹配结果）。")
        else:
            for item in web_items:
                title = item.get("title", "unknown")
                snippet = item.get("snippet", "")
                link = item.get("link", "")
                link_text = f" [{link}]({link})" if link else ""
                lines.append(f"- **{title}**: {snippet}{link_text}")
        lines.append("")

        research_summary = bundle.get("research_summary", {}) or {}
        lines.extend(["## 同类产品研究与机会洞察", ""])
        lines.extend(self._render_summary_section("### 1. 对标产品", research_summary.get("benchmark_products", [])))
        lines.extend(self._render_summary_section("### 2. 共性功能模式", research_summary.get("feature_patterns", [])))
        lines.extend(self._render_summary_section("### 3. 交互与体验模式", research_summary.get("interaction_patterns", [])))
        lines.extend(self._render_summary_section("### 4. 信任与商业化信号", research_summary.get("trust_signals", [])))
        lines.extend(self._render_summary_section("### 5. 差异化机会", research_summary.get("differentiation_opportunities", [])))
        lines.extend(self._render_summary_section("### 6. 交付建议", research_summary.get("delivery_recommendations", [])))
        lines.append("")

        lines.extend(
            [
                "## 增强后的需求描述",
                "",
                bundle.get("enriched_requirement", bundle.get("original_requirement", "")),
                "",
            ]
        )
        return "\n".join(lines)

    def save_bundle(
        self,
        bundle: dict[str, Any],
        output_dir: Path,
        project_name: str,
        requirement: str | None = None,
        domain: str | None = None,
    ) -> Path:
        cache_dir = Path(output_dir) / "knowledge-cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = cache_dir / f"{project_name}-knowledge-bundle.json"
        cached_bundle = dict(bundle)
        cached_bundle.setdefault("generated_at", datetime.now(timezone.utc).isoformat())
        if requirement is not None:
            cached_bundle["cache_signature"] = self._bundle_signature(
                requirement=requirement,
                domain=domain or "",
            )
        cached_bundle["cache_ttl_seconds"] = self.cache_ttl_seconds
        cache_file.write_text(json.dumps(cached_bundle, ensure_ascii=False, indent=2), encoding="utf-8")
        return cache_file

    def load_cached_bundle(
        self,
        output_dir: Path,
        project_name: str,
        requirement: str,
        domain: str = "",
    ) -> dict[str, Any] | None:
        if self.cache_ttl_seconds <= 0:
            return None

        cache_file = Path(output_dir) / "knowledge-cache" / f"{project_name}-knowledge-bundle.json"
        if not cache_file.exists():
            return None
        try:
            payload = json.loads(cache_file.read_text(encoding="utf-8"))
        except Exception:
            return None
        if not isinstance(payload, dict):
            return None

        generated_at_raw = str(payload.get("generated_at", "")).strip()
        cache_signature = str(payload.get("cache_signature", "")).strip()
        if not generated_at_raw or not cache_signature:
            return None

        expected_signature = self._bundle_signature(requirement=requirement, domain=domain)
        if cache_signature != expected_signature:
            return None

        generated_at = self._parse_datetime(generated_at_raw)
        if generated_at is None:
            return None
        expired_at = generated_at + timedelta(seconds=self.cache_ttl_seconds)
        if expired_at <= datetime.now(timezone.utc):
            return None
        return payload

    def _extract_keywords(self, text: str) -> list[str]:
        lowered = text.lower()
        mixed_tokens = re.findall(r"[A-Za-z0-9_\u4e00-\u9fff]{2,}", lowered)
        expanded: list[str] = []
        for token in mixed_tokens:
            expanded.append(token)
            ascii_parts = re.findall(r"[a-z0-9_]{2,}", token)
            zh_parts = re.findall(r"[\u4e00-\u9fff]{2,}", token)
            expanded.extend(ascii_parts)
            expanded.extend(zh_parts)
            for zh in zh_parts:
                if len(zh) >= 3:
                    for i in range(len(zh) - 1):
                        expanded.append(zh[i : i + 2])

        unique: list[str] = []
        for token in expanded:
            if token in self._STOPWORDS:
                continue
            if token not in unique:
                unique.append(token)
        return unique[:12]

    def _iter_local_files(self) -> list[Path]:
        files: list[Path] = []
        if self.docs_dir.exists():
            files.extend(self.docs_dir.rglob("*.md"))
        if self.knowledge_dir.exists():
            files.extend(self.knowledge_dir.rglob("*.md"))
            files.extend(self.knowledge_dir.rglob("*.txt"))
            files.extend(self.knowledge_dir.rglob("*.yml"))
            files.extend(self.knowledge_dir.rglob("*.yaml"))
        if self.specs_dir.exists():
            files.extend(self.specs_dir.rglob("*.md"))
        if self.data_dir.exists():
            files.extend(self.data_dir.rglob("*.csv"))
        if self.builtin_data_dir.exists() and self.builtin_data_dir != self.data_dir:
            files.extend(self.builtin_data_dir.rglob("*.csv"))
        return files

    def _collect_local_items(self, keywords: list[str], max_results: int) -> list[KnowledgeItem]:
        if not keywords:
            return []

        items: list[KnowledgeItem] = []
        for file_path in self._iter_local_files():
            content = ""
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                content = ""
            if not content:
                continue

            lowered = content.lower()
            score = 0.0
            for keyword in keywords:
                if keyword in lowered:
                    score += 1.0
            if score <= 0:
                continue

            snippet = self._first_matching_snippet(content, keywords)
            items.append(
                KnowledgeItem(
                    source=self._format_source_path(file_path),
                    title=file_path.stem,
                    snippet=snippet,
                    score=score,
                )
            )

        items.sort(key=lambda item: item.score, reverse=True)
        return items[:max_results]

    def _first_matching_snippet(self, content: str, keywords: list[str]) -> str:
        lines = [line.strip() for line in content.splitlines() if line.strip()]
        for line in lines:
            lowered = line.lower()
            if any(keyword in lowered for keyword in keywords):
                return line[:220]
        return (lines[0][:220] if lines else "")

    def _format_source_path(self, file_path: Path) -> str:
        try:
            return str(file_path.relative_to(self.project_dir))
        except ValueError:
            try:
                return f"builtin/{file_path.relative_to(self.builtin_data_dir)}"
            except ValueError:
                return str(file_path)

    def _to_citation(self, item: KnowledgeItem) -> dict[str, str]:
        return {
            "title": item.title,
            "source": item.source,
            "link": item.link,
        }

    def _build_web_query(self, requirement: str, domain: str) -> str:
        benchmark_terms = (
            "similar products competitor analysis benchmark feature patterns "
            "user flow information architecture interaction design ui ux best practices"
        )
        if domain:
            return f"{requirement} {domain} {benchmark_terms}"
        return f"{requirement} {benchmark_terms}"

    def _collect_web_items(self, query: str, max_results: int) -> list[KnowledgeItem]:
        if not self.web_enabled:
            self._last_web_stats = {
                "provider": "disabled",
                "raw_count": 0,
                "filtered_count": 0,
                "filtered_out_count": 0,
            }
            return []

        provider = "ddgs"
        results = self._collect_web_items_ddgs(query=query, max_results=max_results)
        if not results:
            provider = "duckduckgo"
            results = self._collect_web_items_duckduckgo(query=query, max_results=max_results)
        raw_count = len(results)
        filtered = self._filter_web_items(results)[:max_results]
        self._last_web_stats = {
            "provider": provider,
            "raw_count": raw_count,
            "filtered_count": len(filtered),
            "filtered_out_count": max(raw_count - len(filtered), 0),
        }
        return filtered

    def _filter_web_items(self, items: list[KnowledgeItem]) -> list[KnowledgeItem]:
        if not self.allowed_web_domains:
            return items

        filtered: list[KnowledgeItem] = []
        for item in items:
            if not item.link:
                continue
            parsed = urllib.parse.urlparse(item.link)
            netloc = parsed.netloc.lower()
            if netloc.startswith("www."):
                netloc = netloc[4:]
            if any(netloc == domain or netloc.endswith(f".{domain}") for domain in self.allowed_web_domains):
                filtered.append(item)
        return filtered

    def _collect_web_items_ddgs(self, query: str, max_results: int) -> list[KnowledgeItem]:
        try:
            from ddgs import DDGS  # type: ignore
        except Exception:
            return []

        results: list[KnowledgeItem] = []
        try:
            with DDGS() as ddgs:
                entries = ddgs.text(query, max_results=max_results)
                for index, entry in enumerate(entries):
                    if not isinstance(entry, dict):
                        continue
                    results.append(
                        KnowledgeItem(
                            source="web",
                            title=str(entry.get("title", "web-result")).strip(),
                            snippet=str(entry.get("body", "")).strip()[:220],
                            link=str(entry.get("href", "")).strip(),
                            score=float(max_results - index),
                        )
                    )
        except Exception:
            return []

        return results

    def _collect_web_items_duckduckgo(self, query: str, max_results: int) -> list[KnowledgeItem]:
        encoded_query = urllib.parse.quote(query)
        url = (
            "https://api.duckduckgo.com/"
            f"?q={encoded_query}&format=json&no_html=1&skip_disambig=1"
        )

        try:
            response = requests.get(url, timeout=6)
            if response.status_code >= 400:
                return []
            payload = response.text
            data = json.loads(payload)
        except Exception:
            return []

        results: list[KnowledgeItem] = []
        abstract = str(data.get("Abstract", "")).strip()
        if abstract:
            results.append(
                KnowledgeItem(
                    source="web",
                    title=str(data.get("Heading", "DuckDuckGo Result")).strip() or "DuckDuckGo Result",
                    snippet=abstract[:220],
                    link=str(data.get("AbstractURL", "")).strip(),
                    score=float(max_results),
                )
            )

        related = data.get("RelatedTopics", [])
        for item in related:
            if len(results) >= max_results:
                break
            if not isinstance(item, dict):
                continue
            if "Topics" in item and isinstance(item.get("Topics"), list):
                sub_topics = item.get("Topics", [])
            else:
                sub_topics = [item]

            for topic in sub_topics:
                if len(results) >= max_results:
                    break
                if not isinstance(topic, dict):
                    continue
                text = str(topic.get("Text", "")).strip()
                if not text:
                    continue
                results.append(
                    KnowledgeItem(
                        source="web",
                        title=text[:80],
                        snippet=text[:220],
                        link=str(topic.get("FirstURL", "")).strip(),
                        score=float(max_results - len(results)),
                    )
                )

        return results[:max_results]

    def _compose_enriched_requirement(
        self,
        requirement: str,
        local_items: list[KnowledgeItem],
        web_items: list[KnowledgeItem],
    ) -> str:
        notes: list[str] = []
        for item in local_items[:3]:
            notes.append(f"本地知识参考: {item.title} - {item.snippet}")
        for item in web_items[:3]:
            notes.append(f"外部最佳实践: {item.title} - {item.snippet}")

        if not notes:
            return requirement

        joined = "；".join(notes)
        return f"{requirement}。请结合以下上下文实现：{joined}"

    def _build_research_summary(
        self,
        requirement: str,
        domain: str,
        keywords: list[str],
        local_items: list[KnowledgeItem],
        web_items: list[KnowledgeItem],
    ) -> dict[str, list[str]]:
        benchmark_products = [
            self._format_research_item(item, include_link=True)
            for item in web_items[:5]
        ]

        feature_patterns = self._unique_preserve_order(
            [
                f"围绕“{keyword}”建立清晰功能分区、任务入口与状态反馈。"
                for keyword in keywords[:4]
            ]
            + [self._format_research_item(item) for item in web_items[:3]]
            + [self._format_research_item(item) for item in local_items[:2]]
        )

        interaction_patterns = self._unique_preserve_order(
            [
                "关键任务链路必须具备明确的下一步、完成反馈与可回退路径。",
                "复杂页面应先给信息架构和优先级，再给具体视觉样式，避免一屏堆满功能。",
                "列表、详情、编辑、确认四类页面应形成统一的交互骨架，降低学习成本。",
            ]
            + [self._interaction_pattern_from_item(item) for item in web_items[:3]]
        )

        trust_signals = self._unique_preserve_order(
            [
                "首页或主工作台优先展示价值主张、能力边界、成功案例或关键数据，避免空泛口号。",
                "涉及数据录入、协作、交易、发布的流程必须提供校验、草稿、撤销或审计提示。",
                "商业产品页面必须体现加载态、空态、错误态和权限态，而不是只做正常态截图。",
            ]
        )

        domain_label = domain or "当前业务领域"
        differentiation_opportunities = self._unique_preserve_order(
            [
                f"把 {domain_label} 场景下最关键的任务路径压缩到更少步骤，并用清晰状态机承载流程进度。",
                "将研究结论沉淀到 PRD / 架构 / UIUX / Spec，确保不是只参考外部产品外观，而是参考其流程与交付标准。",
                "优先做能体现商业级完成度的能力：权限、审计、异常处理、批量操作、搜索筛选、可观测性。",
            ]
        )

        delivery_recommendations = self._unique_preserve_order(
            [
                "在生成 PRD 前先冻结同类产品研究结论，明确借鉴项、禁用项与差异化方向。",
                "UI 产出必须先确定设计方向、字体系统、栅格、组件状态矩阵，再开始页面实现。",
                "实现阶段应先完成信息架构正确的页面框架，再补视觉细节、动效和性能优化。",
            ]
        )

        if not benchmark_products:
            benchmark_products.append("未获取到可靠联网结果时，应由宿主继续使用原生联网能力补充同类产品研究。")

        return {
            "benchmark_products": benchmark_products,
            "feature_patterns": feature_patterns[:6],
            "interaction_patterns": interaction_patterns[:6],
            "trust_signals": trust_signals[:5],
            "differentiation_opportunities": differentiation_opportunities[:5],
            "delivery_recommendations": delivery_recommendations[:5],
        }

    def _format_research_item(self, item: KnowledgeItem, include_link: bool = False) -> str:
        snippet = item.snippet.strip().replace("\n", " ")
        snippet = snippet[:140] if snippet else "提供了可参考的行业实践。"
        if include_link and item.link:
            return f"{item.title}: {snippet} [{item.link}]({item.link})"
        return f"{item.title}: {snippet}"

    def _interaction_pattern_from_item(self, item: KnowledgeItem) -> str:
        if not item.snippet:
            return f"参考 {item.title} 的功能组织方式，提炼关键流程和页面层级。"
        return f"参考 {item.title} 的页面与流程组织方式：{item.snippet[:120]}"

    def _render_summary_section(self, title: str, items: list[str]) -> list[str]:
        lines = [title, ""]
        if not items:
            lines.append("- 暂无结论，需要继续补充研究。")
            lines.append("")
            return lines
        for item in items:
            lines.append(f"- {item}")
        lines.append("")
        return lines

    def _unique_preserve_order(self, items: list[str]) -> list[str]:
        result: list[str] = []
        for item in items:
            normalized = item.strip()
            if not normalized or normalized in result:
                continue
            result.append(normalized)
        return result

    def _source_domain(self, item: KnowledgeItem) -> str:
        source = item.source.strip()
        if source.startswith("knowledge/"):
            parts = source.split("/")
            if len(parts) >= 2:
                return parts[1]
        if source.startswith("docs/"):
            return "docs"
        if source.startswith(".super-dev/specs/"):
            return "specs"
        return "general"

    def _constraint_type(self, item: KnowledgeItem) -> str:
        lowered = f"{item.source} {item.title}".lower()
        if any(token in lowered for token in ["checklist", "baseline", "gate", "criteria"]):
            return "hard-gate"
        if any(token in lowered for token in ["template", "catalog", "index", "taxonomy", "map"]):
            return "reference"
        if any(token in lowered for token in ["runbook", "playbook", "policy", "guide"]):
            return "operating-guidance"
        return "knowledge"

    def _build_knowledge_application_plan(self, local_items: list[KnowledgeItem]) -> dict[str, Any]:
        stage_guidance: dict[str, list[str]] = {stage: [] for stage in self._STAGE_ORDER}
        hard_constraints: list[str] = []

        for item in local_items:
            domain = self._source_domain(item)
            stages = self._DOMAIN_STAGE_MAP.get(domain, ["research", "prd", "architecture", "spec"])
            snippet = item.snippet.strip() or "将该知识作为当前阶段的约束输入。"
            entry = f"{item.title}（{item.source}）: {snippet[:140]}"
            for stage in stages:
                stage_guidance.setdefault(stage, [])
                if entry not in stage_guidance[stage]:
                    stage_guidance[stage].append(entry)
            if self._constraint_type(item) == "hard-gate":
                hard_rule = f"{item.title}（{item.source}）属于硬门禁/基线，命中后必须进入对应阶段的文档、Spec 或验收。"
                if hard_rule not in hard_constraints:
                    hard_constraints.append(hard_rule)

        normalized_stage_guidance = {
            stage: entries[:5]
            for stage, entries in stage_guidance.items()
            if entries
        }
        return {
            "hard_constraints": hard_constraints[:8],
            "stage_guidance": normalized_stage_guidance,
        }

    def _stage_label(self, stage: str) -> str:
        labels = {
            "research": "Research / 同类产品研究",
            "prd": "PRD / 产品需求文档",
            "architecture": "Architecture / 架构设计",
            "uiux": "UIUX / 交互与视觉规范",
            "spec": "Spec / 变更规范与任务拆解",
            "frontend": "Frontend / 前端实现与运行验证",
            "backend": "Backend / 后端与联调",
            "quality": "Quality / 测试、安全与质量门禁",
            "delivery": "Delivery / 交付、部署与发布",
        }
        return labels.get(stage, stage)

    def _bundle_signature(self, requirement: str, domain: str) -> str:
        normalized_requirement = requirement.strip().lower()
        normalized_domain = domain.strip().lower()
        allowed_domains = ",".join(sorted(self.allowed_web_domains))
        payload = f"{normalized_requirement}|{normalized_domain}|{self.web_enabled}|{allowed_domains}"
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _parse_datetime(self, value: str) -> datetime | None:
        cleaned = value.strip()
        if not cleaned:
            return None
        normalized = cleaned.replace("Z", "+00:00")
        try:
            parsed = datetime.fromisoformat(normalized)
        except ValueError:
            return None
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
