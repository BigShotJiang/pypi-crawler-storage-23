def any2dict(obj, **kwargs):
    if obj is None:
        return obj

    if (kwargs.get('max_depth') is not None and
        kwargs.get('depth',0) > kwargs.get('max_depth')):
        return str(obj)

    kwargs['depth'] = kwargs.get('depth', 0) + 1

    if isinstance(obj, [str, int, float]):
        return obj

    if isinstance(obj, dict):
        return {k: any2dict(v, **kwargs) for k, v in obj.items()}

    if isinstance(obj, list):
        return [any2dict(v, **kwargs) for v in obj]

    if isinstance(obj, tuple):
        return tuple(any2dict(v, **kwargs) for v in obj)

    if isinstance(obj, set):
        return set(any2dict(v, **kwargs) for v in obj)

    if hasattr(obj, '__dict__'):
        return {k: any2dict(v, **kwargs) for k, v in obj.__dict__.items()}

    return str(obj)
