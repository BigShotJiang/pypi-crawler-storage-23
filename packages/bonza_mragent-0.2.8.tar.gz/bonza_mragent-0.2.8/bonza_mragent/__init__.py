# bonza_mragent package — entry point shim for `python -m bonza_mragent`
