# Plan: Storage layer improvements

Three orthogonal changes to the flatmachines storage layer. Each can land independently.

**Related plans:**
- `PIPELINE_SCHEDULER_PLAN.md` — `run_pipeline()` helper (uses backends, needs updating: references dead `lifecycle.py`)
- `../examples/dfss_pipeline/PLAN_v2.md` — DFSS example (needs updating: references dead `list_executions`/`cleanup_executions`, uses `FileWorkQueue` instead of `WorkPool`)

---

## 1. SQLite persistence backend + execution lock

### `persistence.py` — `SQLiteCheckpointBackend(PersistenceBackend)`

Two tables: `machine_checkpoints` (keyed blobs) + `machine_latest` (pointer per execution). WAL mode, busy timeout, async lock for writes. Implements `save`, `load`, `delete`, `list_execution_ids`, `delete_execution`.

### `locking.py` — `SQLiteLeaseLock(ExecutionLock)`

Table: `execution_leases` with owner, TTL, fencing token. Heartbeat renewal task. Implements `acquire`, `release`.

### `__init__.py`

Export both.

### Tests

Unit tests for both (same TDD pattern: parametrize SQLite alongside existing backends for persistence, separate lock tests for lease semantics).

### Notes

Strip the research crawler's production hardening down to what's general-purpose. Leave the terminal purging policy out — that's domain-specific. The crawler can subclass or configure if needed.

---

## 2. WorkPool out of distributed.py

`WorkPool` is a storage primitive (durable queue with atomic claim/complete/fail), not a distributed coordination concept. Currently lives in `distributed.py` next to `RegistrationBackend`, implying they're a package deal.

### What moves

- `WorkPool` protocol, `WorkItem` dataclass, `WorkBackend` protocol → new home (TBD: `persistence.py`, `backends.py`, or own module)
- `MemoryWorkPool`, `MemoryWorkBackend` → same
- `SQLiteWorkPool`, `SQLiteWorkBackend` → same
- Factory function `create_work_backend()` → same

### What stays in `distributed.py`

- `RegistrationBackend` — genuinely distributed-only (worker process tracking)
- `MemoryRegistrationBackend`, `SQLiteRegistrationBackend`
- `DistributedWorkerHooks` stays in `distributed_hooks.py`, imports from both

### Why this matters

The DFSS example and the research crawler both need durable work items with atomic claim semantics. Neither is distributed. Having `WorkPool` in `distributed.py` makes it invisible for non-distributed use.

### Key insight from analysis

`WorkPool` is an unordered collection. "Pool" is the right name — the scheduler imposes ordering, not the pool. The pool provides storage + atomic withdrawal. The current `claim()` hardcodes FIFO (`ORDER BY created_at ASC`), but the pool shouldn't own ordering. A `list_pending()` or similar would let the scheduler evaluate candidates and claim the winner. For single-process this is trivial (no contention between list and claim).

---

## 3. "The machine is the job"

After parts 1 and 2, three small changes let the persistence layer do double duty as the job store:

### Propagate lock + persistence to peer machines

`FlatMachine._launch_and_write` already passes `result_backend` and `agent_registry` to peers. Add `persistence` and `lock`. Eliminates the research crawler's `LeaseFlatMachine` subclass (exists only to propagate these).

### `list_execution_ids()` with status filtering

Add an optional filter to the method we already implemented on the ABC:

```python
async def list_execution_ids(self, *, event: str = None) -> List[str]:
```

SQLite backend filters on the `event` column directly. `list_execution_ids(event="machine_end")` = completed jobs. Set difference with all IDs = incomplete jobs. Replaces raw SQL in the research crawler's `find_incomplete_executions`.

### `CheckpointManager.load_status()` — lightweight snapshot peek

```python
async def load_status(self) -> Optional[tuple[str, str]]:
    """Return (event, current_state) without deserializing full context."""
```

SQLite backend reads indexed columns directly. Replaces raw SQL in the research crawler's `reset_orphaned_executions`.

### Boundary clarification

Checkpoints answer "what state is this execution in?" (resume, warm-start, status).
WorkPool answers "what should I work on next?" (durable queue, atomic claims).
The scheduler owns priority and ordering — neither storage layer does.
