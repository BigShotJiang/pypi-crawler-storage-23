"""Modules: cell-type-specific configuration and enrichment logic."""
