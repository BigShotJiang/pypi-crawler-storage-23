"""
Nomic API embedder — drop-in replacement for ONNXEmbedder during backfill.

Uses the Nomic API (nomic-embed-text-v1.5) instead of local ONNX inference.
Same model, same 128d Matryoshka vectors, 100% compatible with cells embedded
by ONNXEmbedder. Intended for the initial backfill pass on CPU-only machines
where local ONNX would take hours.

Requires: pip install getflex[nomic]  (or: pipx inject getflex nomic)
"""
import numpy as np
from typing import List, Union


class NomicEmbedder:
    """Wraps Nomic embed API with the same .encode() interface as ONNXEmbedder."""

    def __init__(self, api_key: str, model: str = "nomic-embed-text-v1.5"):
        self.api_key = api_key
        self.model = model
        self._batch_size = 256  # conservative; Nomic supports up to 8192

    def validate(self) -> "str | None":
        """Test the key with a single embed. Returns error string or None on success."""
        try:
            self._embed_batch(["validation"])
            return None
        except Exception as e:
            return str(e)

    def _embed_batch(self, texts: List[str]) -> np.ndarray:
        try:
            from nomic import embed as _nomic_embed
        except ImportError:
            raise RuntimeError(
                "nomic package required.\n"
                "  pip install getflex[nomic]\n"
                "  # or for pipx: pipx inject getflex nomic"
            )
        import os
        os.environ["NOMIC_API_KEY"] = self.api_key
        result = _nomic_embed.text(
            texts=texts,
            model=self.model,
            task_type="search_document",
            dimensionality=128,
        )
        return np.array(result["embeddings"], dtype=np.float32)

    def encode(
        self,
        sentences: Union[str, List[str]],
        prefix: str = "search_document: ",  # accepted for API compat; task_type handles it
        matryoshka_dim: int = 128,
        **kwargs,
    ) -> np.ndarray:
        """Encode sentences via Nomic API. Returns (n, 128) float32 array."""
        if isinstance(sentences, str):
            sentences = [sentences]
        all_embs = []
        for i in range(0, len(sentences), self._batch_size):
            batch = sentences[i : i + self._batch_size]
            all_embs.append(self._embed_batch(batch))
        result = np.vstack(all_embs)
        # Enforce unit norm (API returns normalized but be explicit)
        norms = np.linalg.norm(result, axis=1, keepdims=True)
        norms = np.where(norms < 1e-9, 1.0, norms)
        return result / norms
