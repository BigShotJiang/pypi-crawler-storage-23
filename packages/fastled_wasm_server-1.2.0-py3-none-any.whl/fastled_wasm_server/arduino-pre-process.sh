#!/bin/bash

arduino-cli compile --preprocess --fqbn arduino:avr:uno /pre-warm/Blink/Blink.ino