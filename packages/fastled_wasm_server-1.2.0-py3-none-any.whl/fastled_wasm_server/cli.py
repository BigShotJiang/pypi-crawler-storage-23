"""
Main entry point.
"""

import sys


def main() -> int:
    """Main entry point for the template_python_cmd package."""
    print("Replace with a CLI entry point.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
