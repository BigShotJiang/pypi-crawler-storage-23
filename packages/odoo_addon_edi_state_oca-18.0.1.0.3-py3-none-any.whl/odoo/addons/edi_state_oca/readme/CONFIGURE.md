Go to "EDI -\> Config -\> States" and configure workflow and states. Go
to "EDI -\> Config -\> EDI Exchange Type" and enable 1 or more workflow
on a given type.
