"""Report generation and output utilities."""

# Note: html_report and screenshot modules are large and imported on-demand
# to avoid slow startup times
