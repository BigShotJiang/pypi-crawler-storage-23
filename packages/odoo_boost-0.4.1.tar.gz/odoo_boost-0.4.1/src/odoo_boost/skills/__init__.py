"""Odoo development skills for AI agents."""

from odoo_boost.skills.loader import install_skills, list_skills, load_skill

__all__ = ["list_skills", "load_skill", "install_skills"]
