"""MCP tool implementations for Odoo introspection."""
