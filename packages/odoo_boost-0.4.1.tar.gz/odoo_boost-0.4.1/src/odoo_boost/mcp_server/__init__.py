"""MCP server for Odoo Boost."""
