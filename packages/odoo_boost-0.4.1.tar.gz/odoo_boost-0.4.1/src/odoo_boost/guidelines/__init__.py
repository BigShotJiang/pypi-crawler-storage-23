"""Odoo development guidelines for AI agents."""

from odoo_boost.guidelines.composer import compose_guidelines

__all__ = ["compose_guidelines"]
