"""Odoo Boost - AI coding agents with deep introspection into running Odoo instances."""

from odoo_boost.__version__ import __version__

__all__ = ["__version__"]
