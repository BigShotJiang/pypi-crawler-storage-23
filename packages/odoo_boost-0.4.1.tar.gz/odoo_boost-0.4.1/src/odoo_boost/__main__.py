"""Allow running as ``python -m odoo_boost``."""

from odoo_boost.cli.app import main

main()
