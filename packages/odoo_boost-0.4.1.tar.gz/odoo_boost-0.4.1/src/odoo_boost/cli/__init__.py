"""CLI commands for Odoo Boost."""
