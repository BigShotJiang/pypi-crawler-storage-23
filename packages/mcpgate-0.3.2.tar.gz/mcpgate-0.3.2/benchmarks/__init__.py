"""Benchmarking for mcpgate."""
