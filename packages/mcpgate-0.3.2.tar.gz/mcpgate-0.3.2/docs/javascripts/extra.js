/**
 * Custom JavaScript for mcpgate documentation
 *
 * Add any custom scripts here to enhance functionality.
 */

// Example: Log page load
// console.log('mcpgate documentation loaded');
