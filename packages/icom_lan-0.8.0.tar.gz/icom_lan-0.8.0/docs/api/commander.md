# IcomCommander

Serialized CI-V command executor with priority queuing (wfview-style).
Most users should use the high-level [`IcomRadio`](radio.md) API, which
manages an `IcomCommander` internally.

::: icom_lan.commander.IcomCommander

## Priority Levels

::: icom_lan.commander.Priority
