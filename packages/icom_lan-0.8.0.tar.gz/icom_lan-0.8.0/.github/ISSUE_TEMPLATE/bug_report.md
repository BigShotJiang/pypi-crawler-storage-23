---
name: Bug Report
about: Report a bug or unexpected behavior
title: "[Bug] "
labels: bug
assignees: ''
---

**Radio Model:**
<!-- e.g., IC-7610, IC-705 -->

**Python Version:**
<!-- e.g., 3.12.1 -->

**OS:**
<!-- e.g., macOS 15, Ubuntu 24.04, Windows 11 -->

**icom-lan Version:**
<!-- e.g., 0.2.0 -->

**Description:**
<!-- What happened? What did you expect? -->

**Steps to Reproduce:**
```python
# Minimal code to reproduce
```

**Debug Log:**
<!-- Run with: logging.basicConfig(level=logging.DEBUG) -->
```
paste log output here
```
