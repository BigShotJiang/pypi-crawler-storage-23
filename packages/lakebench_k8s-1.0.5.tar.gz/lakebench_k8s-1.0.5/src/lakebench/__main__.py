"""Entry point for python -m lakebench."""

from lakebench.cli import app

if __name__ == "__main__":
    app()
