# rye:signed:2026-02-26T05:02:30Z:bf580c8cdf1b944e2ab8a446fad5606499ddb6ab1b4b095838d364b5429995fd:e1T3KfGj6LG3qet9wqaS8XPQso1aKR5R5u76iEpw3il86rtEFsB6XC0BbRBg7mSl-6tt_mMyB_pqodtQ43ygCg==:4b987fd4e40303ac
"""Bundler tools package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/bundler"
__tool_description__ = "Bundler tools package"
