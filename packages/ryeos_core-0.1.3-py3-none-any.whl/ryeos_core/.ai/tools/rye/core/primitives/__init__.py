# rye:signed:2026-02-26T05:02:29Z:a9fd434ceda3993cccc6a574eff17de08ba5b6761cb815485e47387386231414:UNu90953CoFE-ks696iF8kB5ee1CS1lmsqUE438wfTBxc_HqeYdy3P4ropdjQDKL0rZw_7glcIu7hUwTi2-qCw==:4b987fd4e40303ac
"""Core primitives package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/primitives"
__tool_description__ = "Core primitives package"
