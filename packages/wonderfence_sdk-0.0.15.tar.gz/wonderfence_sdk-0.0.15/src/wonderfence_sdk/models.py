from dataclasses import dataclass
from enum import Enum
from typing import Optional, Union

from pydantic import BaseModel, Field


class MessageType(str, Enum):
    PROMPT = "prompt"
    RESPONSE = "response"


class Actions(str, Enum):
    BLOCK = "BLOCK"
    DETECT = "DETECT"
    MASK = "MASK"
    NO_ACTION = ""


class SpanDetection(BaseModel):
    """
    Represents a span of text detected in the input.
    Commonly used for PII violations (emails, SSNs, phone numbers, etc.) to indicate
    the exact location of sensitive data in the text.
    """

    start: int
    end: int


class DetectionResults(BaseModel):
    type: str
    score: float
    spans: Optional[list[SpanDetection]] = None


class ErrorResponse(BaseModel):
    violation: str
    status: int
    type: str
    message: str


class EvaluateMessageResponse(BaseModel):
    correlation_id: str
    action: Actions
    action_text: Optional[str] = None
    detections: list[DetectionResults] = Field(default_factory=list)
    errors: list[ErrorResponse] = Field(default_factory=list)


class AnalysisContext(BaseModel):
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    provider: Optional[str] = None
    model_name: Optional[str] = None
    model_version: Optional[str] = None
    platform: Optional[str] = None


@dataclass(frozen=True)
class CustomField:
    name: str
    value: Union[str, int, float, bool, list[str]]

    def __hash__(self) -> int:
        """Custom hash method that handles unhashable values by converting them to strings."""
        # Convert the value to a string representation for hashing
        # this is a workaround to handle unhashable values like lists and dicts
        value_str = str(self.value)
        return hash((self.name, value_str))

    def to_dict(self) -> dict[str, Union[str, int, float, bool, list[str]]]:
        return {self.name: self.value}


@dataclass
class ImageInput:
    """
    Represents image input for message evaluation.
    Use one of the following approaches:
    - media_url: URL to the image (http://, https://, or s3://)
    - raw_media + mime_type: Base64-encoded image content with MIME type
    """

    media_url: Optional[str] = None
    raw_media: Optional[str] = None
    mime_type: Optional[str] = None

    def __post_init__(self) -> None:
        """Validate that exactly one input method is provided."""
        has_url = self.media_url is not None
        has_raw_media = self.raw_media is not None
        has_mime_type = self.mime_type is not None

        # Check for partial base64 input first (more specific errors)
        if has_raw_media and not has_mime_type:
            raise ValueError("mime_type is required when raw_media is provided")

        if has_mime_type and not has_raw_media:
            raise ValueError("raw_media is required when mime_type is provided")

        # Now check for valid input combinations
        has_base64 = has_raw_media and has_mime_type

        if not has_url and not has_base64:
            raise ValueError("Either media_url or (raw_media + mime_type) must be provided")

        if has_url and has_base64:
            raise ValueError("Cannot provide both media_url and raw_media - they are mutually exclusive")

    def to_dict(self) -> dict[str, str]:
        """Convert image input to dictionary format for API request."""
        if self.media_url:
            return {"media_url": self.media_url}
        else:
            return {"raw_media": self.raw_media, "mime_type": self.mime_type}  # type: ignore
