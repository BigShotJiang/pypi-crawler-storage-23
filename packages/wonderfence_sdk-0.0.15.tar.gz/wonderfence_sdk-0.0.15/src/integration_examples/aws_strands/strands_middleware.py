import json
import sys
import uuid
from collections.abc import Callable
from pathlib import Path
from typing import Any

from bedrock_agentcore import BedrockAgentCoreApp
from bedrock_agentcore.runtime.context import RequestContext
from starlette.applications import Starlette
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from strands import Agent

from wonderfence_sdk.client import WonderFenceClient
from wonderfence_sdk.models import Actions, AnalysisContext

http_ok = 200
agent_id = "strands_middleware"


class WonderFenceMiddleware(BaseHTTPMiddleware):
    """Starlette middleware for WonderFence content evaluation."""

    def __init__(self, app: Starlette, client: WonderFenceClient):
        super().__init__(app)
        self.client = client

    async def dispatch(self, request: Request, call_next: Callable[[Request], Any]) -> Response:  # noqa: PLR0911
        # Only process /invocations requests (the main AgentCore endpoint)
        if request.url.path != "/invocations":
            return await call_next(request)  # type: ignore[no-any-return]

        # Read and parse the request body
        body = await request.body()
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            return JSONResponse({"error": "Invalid JSON payload"}, status_code=400)

        # Extract user message for evaluation
        user_message = payload.get("prompt", "")
        if not user_message:
            return await call_next(request)  # type: ignore[no-any-return]

        # Create analysis context
        analysis_context = AnalysisContext(
            session_id=payload.get("session_id", str(uuid.uuid4())),
            user_id=payload.get("user_id", str(uuid.uuid4())),
            provider="aws-bedrock",
            platform="aws",
        )

        # Evaluate user prompt for safety
        prompt_eval = await self.client.evaluate_prompt(user_message, analysis_context)
        if prompt_eval.action == Actions.BLOCK:
            return JSONResponse(
                {
                    "result": "I cannot process this request due to content policy violations.",
                    "status": "blocked",
                    "reason": "prompt_safety_violation",
                }
            )
        elif prompt_eval.action == Actions.MASK:
            # Modify the payload with masked prompt
            payload["prompt"] = prompt_eval.action_text
            # Create new request with modified body
            new_body = json.dumps(payload).encode()
            request._body = new_body

        # Continue processing with original or modified request
        response = await call_next(request)

        # Only evaluate response for successful JSON responses
        if response.status_code == http_ok and response.headers.get("content-type", "").startswith("application/json"):
            # Read response body
            response_body = b""
            async for chunk in response.body_iterator:
                response_body += chunk

            try:
                response_data = json.loads(response_body)
                ai_message = response_data.get("result", "")

                if ai_message:
                    # Evaluate AI response for safety
                    analysis_context.user_id = agent_id
                    response_eval = await self.client.evaluate_response(ai_message, analysis_context)

                    if response_eval.action == Actions.BLOCK:
                        return JSONResponse(
                            {
                                "result": "I cannot provide this response due to content policy violations.",
                                "status": "blocked",
                                "reason": "response_safety_violation",
                            }
                        )
                    elif response_eval.action == Actions.MASK:
                        response_data["result"] = response_eval.action_text
                        return JSONResponse(response_data)

            except json.JSONDecodeError:
                pass  # If response isn't JSON, just return as-is

        # Return the original response if no modifications needed
        return Response(
            content=response_body,
            status_code=response.status_code,
            headers=dict(response.headers),
            media_type=response.media_type,
        )


# Initialize app with WonderFence middleware
client = WonderFenceClient(provider="aws-bedrock", platform="aws")
app = BedrockAgentCoreApp()
# Add middleware after app creation - Starlette will pass app automatically
app.add_middleware(WonderFenceMiddleware, client=client)  # type: ignore[arg-type]
agent = Agent()


@app.entrypoint
def invoke(payload: dict, context: RequestContext | None = None) -> dict[str, Any]:  # type: ignore[syntax]
    """Simple AI agent function - safety evaluation handled by middleware"""
    print("invoke parameters:", list(locals().keys()))
    print("Payload contents:", payload)
    print("Context contents:", context)

    user_message = payload.get("prompt", "Hello! How can I help you today?")

    # Process with your agent - WonderFence evaluation is handled by middleware
    result = agent(user_message)

    return {"result": result.message}


if __name__ == "__main__":
    app.run()
