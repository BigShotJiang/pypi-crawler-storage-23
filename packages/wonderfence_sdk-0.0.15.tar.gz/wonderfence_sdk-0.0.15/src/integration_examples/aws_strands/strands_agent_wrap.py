import sys
import uuid
from pathlib import Path
from typing import Any

from bedrock_agentcore import BedrockAgentCoreApp
from bedrock_agentcore.runtime.context import RequestContext
from strands import Agent

from wonderfence_sdk.client import WonderFenceClient
from wonderfence_sdk.models import Actions, AnalysisContext

app = BedrockAgentCoreApp()
agent = Agent()
client = WonderFenceClient(provider="aws-bedrock", platform="aws")
agent_id = "strands_agent_wrap"


@app.entrypoint
def invoke(payload: dict[str, Any], context: RequestContext | None = None) -> dict[str, Any]:  # type: ignore[syntax]
    print("invoke parameters:", list(locals().keys()))
    print("Payload contents:", payload)
    print("Context contents:", context)
    """Your AI agent function with WonderFence content evaluation"""
    user_message = payload.get("prompt", "Hello! How can I help you today?")

    # Create analysis context with user/session tracking
    analysis_context = AnalysisContext(
        session_id=getattr(context, "session_id", None) or payload.get("session_id") or str(uuid.uuid4()),
    )
    # Evaluate user prompt for safety
    prompt_eval = client.evaluate_prompt_sync(user_message, analysis_context)
    if prompt_eval.action == Actions.BLOCK:
        return {"result": "I cannot process this request due to content policy violations."}
    elif prompt_eval.action == Actions.MASK:
        processed_prompt = prompt_eval.action_text
    else:
        processed_prompt = user_message

    # Process with your agent
    result = agent(processed_prompt)

    # Evaluate AI response for safety
    analysis_context.user_id = agent_id
    response_eval = client.evaluate_response_sync(result.message, analysis_context)
    if response_eval.action == Actions.BLOCK:
        return {"result": "I cannot provide this response due to content policy violations."}
    elif response_eval.action == Actions.MASK:
        return {"result": response_eval.action_text}
    else:
        return {"result": result.message}


if __name__ == "__main__":
    app.run()
