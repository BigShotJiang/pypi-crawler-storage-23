import json
import os
import sys
import uuid
from pathlib import Path
from typing import Any

from bedrock_agentcore import BedrockAgentCoreApp
from strands import Agent, tool
from strands.hooks import (
    AfterToolCallEvent,
    BeforeToolCallEvent,
    HookProvider,
    HookRegistry,
)
from strands.models.gemini import GeminiModel

from wonderfence_sdk.client import WonderFenceClient
from wonderfence_sdk.models import Actions, AnalysisContext

agent_id = "strands_agent_hooks_bank_example"

# --- 1. Simulate the State (Bank Database) ---
# In a real application, this would be an API call to a database.
# We use a simple dictionary to hold the balance for a single user.
BANK_BALANCE = {
    "user_id_123": 1500.50  # Starting balance: $1500.50
}

# --- 2. WONDERFENCE SAFETY INTEGRATION WITH HOOKS ---

# Initialize WonderFenceClient client
client = WonderFenceClient(provider="aws-bedrock", platform="aws")


class WonderFenceBankingHook(HookProvider):
    """
    Hook provider that integrates WonderFence safety evaluation for banking tools.

    This hook:
    1. Evaluates tool inputs before execution (BeforeToolCallEvent)
    2. Evaluates tool outputs after execution (AfterToolCallEvent)
    3. Blocks unsafe tool calls and responses
    """

    def __init__(self, wonderfence_client: WonderFenceClient):
        """
        Initialize the WonderFence banking hook.

        Args:
            wonderfence_client: WonderFenceClient client for safety evaluation
        """
        self.client = wonderfence_client

    def register_hooks(self, registry: HookRegistry) -> None:
        """Register hook callbacks with the registry."""
        registry.add_callback(BeforeToolCallEvent, self.on_before_tool_call)
        registry.add_callback(AfterToolCallEvent, self.on_after_tool_call)

    def on_before_tool_call(self, event: BeforeToolCallEvent) -> None:
        """
        Called before any tool is invoked.

        Evaluates tool input for safety and blocks unsafe tool calls.
        """
        tool_name = event.tool_use.get("name", "unknown")
        tool_input = event.tool_use.get("input", {})

        print("\n" + "=" * 60)
        print(f"🔒 WONDERFENCE PRE-CALL EVALUATION: Tool '{tool_name}'")

        # Get session_id from invocation_state if available
        session_id = str(uuid.uuid4())
        if hasattr(event, "invocation_state") and event.invocation_state:
            session_id = event.invocation_state.get("session_id", session_id)

        # Create analysis context
        analysis_context = AnalysisContext(
            session_id=session_id,
        )

        # 🟢 Input Safety Evaluation
        # Combine all string arguments and parameters for evaluation
        input_content = f"Tool: {tool_name}, Input: {json.dumps(tool_input)}"

        print(f"   Evaluating input content: '{input_content[:100]}...'")

        try:
            prompt_eval = self.client.evaluate_prompt_sync(input_content, analysis_context)

            if prompt_eval.action == Actions.BLOCK:
                blocked_msg = f"🚨 INPUT BLOCKED: Tool '{tool_name}' input violates content policy"
                print(f"   {blocked_msg}")
                print("=" * 60)
                # Cancel the tool execution
                event.cancel_tool = f"Access Denied: {blocked_msg}. Please modify your request."
                return

            elif prompt_eval.action == Actions.MASK:
                print("   INPUT MASKED: Using sanitized content")
                # For banking tools, if input is masked, we should be cautious
                masked_msg = f"⚠️  INPUT SANITIZED: Tool '{tool_name}' input was modified for safety"
                print(f"   {masked_msg}")
                # Continue with original input for banking operations (conservative approach)

            else:  # ALLOW
                print("   ✅ INPUT SAFE: Proceeding with tool execution")

        except Exception as e:
            print(f"   ❌ INPUT EVALUATION ERROR: {e}")
            # Continue execution but log the error

        print("=" * 60)

    def on_after_tool_call(self, event: AfterToolCallEvent) -> None:  # noqa: PLR0912
        """
        Called after a tool invocation completes.

        Evaluates tool output for safety and blocks/masks unsafe responses.
        """
        tool_name = event.tool_use.get("name", "unknown")
        result = event.result

        print("\n" + "=" * 60)
        print(f"🔒 WONDERFENCE POST-CALL EVALUATION: Tool '{tool_name}'")

        # Get session_id from invocation_state if available
        session_id = str(uuid.uuid4())
        if hasattr(event, "invocation_state") and event.invocation_state:
            session_id = event.invocation_state.get("session_id", session_id)

        # Create analysis context
        analysis_context = AnalysisContext(
            user_id=agent_id,
            session_id=session_id,
        )

        # 🔴 Output Safety Evaluation
        # Extract result text for evaluation
        result_text = str(result)
        if isinstance(result, dict) and "content" in result:
            if isinstance(result["content"], list) and result["content"]:
                result_text = result["content"][0].get("text", str(result))
            else:
                result_text = str(result["content"])

        print(f"   Evaluating output content: '{result_text[:100]}...'")

        try:
            response_eval = self.client.evaluate_response_sync(result_text, analysis_context)

            if response_eval.action == Actions.BLOCK:
                blocked_msg = f"🚨 OUTPUT BLOCKED: Tool '{tool_name}' response violates content policy"
                print(f"   {blocked_msg}")
                print("=" * 60)
                # Replace the result with a blocked message
                blocked_response = "Response Blocked: Cannot provide this information due to content policy."
                if isinstance(result, dict) and "content" in result:
                    if isinstance(result["content"], list) and result["content"]:
                        result["content"][0]["text"] = blocked_response
                    else:
                        result["content"] = blocked_response
                else:
                    event.result = blocked_response
                return

            elif response_eval.action == Actions.MASK:
                masked_response = response_eval.action_text or result_text
                print("   OUTPUT MASKED: Using sanitized response")
                print("=" * 60)
                # Replace the result with masked content
                if isinstance(result, dict) and "content" in result:
                    if isinstance(result["content"], list) and result["content"]:
                        result["content"][0]["text"] = masked_response
                    else:
                        result["content"] = masked_response
                else:
                    event.result = masked_response
                return

            else:  # ALLOW
                print("   ✅ OUTPUT SAFE: Returning original response")
                print("=" * 60)

        except Exception as e:
            print(f"   ❌ OUTPUT EVALUATION ERROR: {e}")
            print(f"🔒 WONDERFENCE POST-CALL EVALUATION: Tool '{tool_name}' completed with evaluation error")
            print("=" * 60)
            # Return original result if evaluation fails


# --- 3. Define the Tool Functions ---


@tool  # type: ignore[misc]
def get_account_balance(user_id: str = "user_id_123") -> str:
    """
    Retrieves the current bank balance for a specified user ID.

    Args:
        user_id: The ID of the user whose balance is requested. Defaults to 'user_id_123'.

    Returns:
        A string indicating the current balance or an error message.
    """
    balance = BANK_BALANCE.get(user_id)
    if balance is not None:
        return f"The current balance for user {user_id} is ${balance:,.2f}."
    else:
        return f"Error: User ID {user_id} not found."


@tool  # type: ignore[misc]
def update_account_balance(user_id: str, amount: float) -> str:
    """
    Updates the bank balance for a specified user ID by adding or subtracting an amount.
    Positive amounts are deposits; negative amounts are withdrawals.

    Args:
        user_id: The ID of the user whose balance is being updated.
        amount: The amount to transact. Use a positive number for deposit, negative for withdrawal.

    Returns:
        A string confirming the transaction and the new balance, or an error message.
    """
    if user_id not in BANK_BALANCE:
        return f"Error: Cannot transact. User ID {user_id} not found."

    current_balance = BANK_BALANCE[user_id]
    new_balance = current_balance + amount

    # Simple validation for non-negative balances on withdrawal
    if new_balance < 0:
        return f"Transaction Failed: Withdrawal of ${abs(amount):,.2f} would result in a negative balance. Current balance: ${current_balance:,.2f}."

    # Update the global state
    BANK_BALANCE[user_id] = new_balance

    transaction_type = "Deposit" if amount >= 0 else "Withdrawal"

    return (
        f"{transaction_type} successful. Amount: ${abs(amount):,.2f}. "
        f"The new balance for user {user_id} is ${new_balance:,.2f}."
    )


# --- 4. Create the Agent and Register the Tools ---


def create_bank_agent(tool_functions: list[Any]) -> Agent:
    """Initializes and returns the Agent instance with WonderFence hooks."""
    # Ensure you set your GOOGLE_API_KEY environment variable
    model = GeminiModel(model_id="gemini-2.0-flash-exp", client_args={"api_key": os.getenv("GOOGLE_API_KEY")})

    # Create WonderFence hook
    wonderfence_hook = WonderFenceBankingHook(wonderfence_client=client)

    agent = Agent(
        model=model,
        # **Tool Registration:** Pass both tool functions to the 'tools' parameter.
        tools=tool_functions,
        # **Hook Registration:** Register WonderFence safety hooks
        hooks=[wonderfence_hook],
        system_prompt=(
            "You are a specialized Bank Agent. Your primary function is to check "
            "and update user bank balances using the available tools. When asked "
            "about a balance, use 'get_account_balance'. When asked to deposit "
            "or withdraw money, use 'update_account_balance'. The default user ID is 'user_id_123'."
        ),
    )
    return agent


# --- 5. Bedrock AgentCore Entrypoint ---

app = BedrockAgentCoreApp()

# Instantiate the agent with the new tools
bank_tools = [get_account_balance, update_account_balance]
bank_agent = create_bank_agent(bank_tools)


@app.entrypoint
def invoke(payload: dict[str, Any], context: Any) -> dict[str, Any]:
    """AgentCore Runtime entry point."""
    print(payload)
    prompt = payload.get("prompt", "What is my current bank balance?")

    # Get session_id from payload or generate one
    session_id = payload.get("session_id", str(uuid.uuid4()))

    # Invoke the agent with the user's prompt and session_id
    # The hooks will automatically use the session_id from invocation_state
    result = bank_agent(prompt, session_id=session_id)

    # Extract the final text response
    response_text = result.message.get("content", [{}])[0].get("text", str(result))

    return {"response": response_text}


def demo_wonderfence_safety() -> None:
    """
    Demonstrate WonderFence safety evaluation with banking tools.

    Note: This demo now uses the agent with hooks, rather than calling tools directly.
    The hooks will automatically evaluate tool inputs and outputs.
    """
    print("\n" + "=" * 70)
    print("🛡️  WONDERFENCE SAFETY DEMO - Banking Tools with Content Evaluation")
    print("=" * 70)

    # Create a test agent with hooks
    test_agent = create_bank_agent([get_account_balance, update_account_balance])

    # Test cases to demonstrate safety evaluation
    test_cases = [
        {"prompt": "What is my current bank balance?", "description": "Safe balance check"},
        {"prompt": "Deposit $100 to my account", "description": "Safe deposit"},
        {"prompt": "What is the balance for suspicious_user_admin?", "description": "Potentially suspicious user ID"},
        {"prompt": "Withdraw $50 from my account", "description": "Safe withdrawal"},
    ]

    for i, test_case in enumerate(test_cases, 1):
        print(f"\n--- Demo Test {i}: {test_case['description']} ---")
        try:
            result = test_agent(test_case["prompt"], session_id=f"demo_session_{i}")
            response_text = result.message.get("content", [{}])[0].get("text", str(result))
            print(f"FINAL OUTPUT: {response_text}")
        except Exception as e:
            print(f"ERROR: {e}")
        print()


if __name__ == "__main__":
    print(f"Initial Balance for user_id_123: ${BANK_BALANCE['user_id_123']:,.2f}")

    # Run WonderFence safety demo
    demo_wonderfence_safety()

    print("\n" + "=" * 70)
    print("🚀 STARTING AGENTCORE SERVER WITH WONDERFENCE SAFETY")
    print("Banking tools are now protected with WonderFence content evaluation!")
    print("=" * 70)

    # Runs the agent as a local server for testing on http://localhost:8080
    app.run(port=8080)
