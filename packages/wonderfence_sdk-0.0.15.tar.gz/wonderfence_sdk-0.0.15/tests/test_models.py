import pytest
from wonderfence_sdk.models import AnalysisContext, CustomField, ImageInput


def test_custom_field_hash_with_arrays() -> None:
    """Test that CustomField instances with equal array values have the same hash."""
    # Create arrays with the same content
    array1 = ["test", "1"]
    array2 = ["test", "1"]

    # Create CustomField instances with these arrays
    field1 = CustomField(name="test_field", value=array1)
    field2 = CustomField(name="test_field", value=array2)

    # Test equality
    assert field1 == field2, "CustomField instances with equal arrays should be equal"

    # Test hash equality
    hash1 = hash(field1)
    hash2 = hash(field2)
    assert hash1 == hash2, "CustomField instances with equal arrays should have the same hash"

    # Test that they can be used in a set (which requires hashable objects)
    test_set = {field1, field2}
    assert len(test_set) == 1, "Set should contain only one unique CustomField"

    # Test with different arrays
    array3 = ["different"]
    field3 = CustomField(name="test_field", value=array3)

    # Should not be equal
    assert field1 != field3, "CustomField instances with different arrays should not be equal"

    # Should have different hashes
    hash3 = hash(field3)
    assert hash1 != hash3, "CustomField instances with different arrays should have different hashes"


def test_analysis_context_creation() -> None:
    """Test that AnalysisContext is created correctly."""
    context = AnalysisContext(
        session_id="test_session_id",
    )
    assert context.session_id == "test_session_id"
    assert context.user_id is None
    assert context.provider is None
    assert context.model_name is None
    assert context.model_version is None
    assert context.platform is None


def test_image_input_with_media_url() -> None:
    """Test ImageInput creation with media_url."""
    image = ImageInput(media_url="https://example.com/image.jpg")
    assert image.media_url == "https://example.com/image.jpg"
    assert image.raw_media is None
    assert image.mime_type is None
    assert image.to_dict() == {"media_url": "https://example.com/image.jpg"}


def test_image_input_with_base64() -> None:
    """Test ImageInput creation with raw_media and mime_type."""
    image = ImageInput(raw_media="base64encodedstring", mime_type="image/jpeg")
    assert image.media_url is None
    assert image.raw_media == "base64encodedstring"
    assert image.mime_type == "image/jpeg"
    assert image.to_dict() == {"raw_media": "base64encodedstring", "mime_type": "image/jpeg"}


def test_image_input_validation_no_input() -> None:
    """Test that ImageInput raises error when no input is provided."""
    with pytest.raises(ValueError, match="Either media_url or \\(raw_media \\+ mime_type\\) must be provided"):
        ImageInput()


def test_image_input_validation_both_inputs() -> None:
    """Test that ImageInput raises error when both media_url and raw_media are provided."""
    with pytest.raises(ValueError, match="Cannot provide both media_url and raw_media - they are mutually exclusive"):
        ImageInput(media_url="https://example.com/image.jpg", raw_media="base64", mime_type="image/jpeg")


def test_image_input_validation_raw_media_without_mime_type() -> None:
    """Test that ImageInput raises error when raw_media is provided without mime_type."""
    with pytest.raises(ValueError, match="mime_type is required when raw_media is provided"):
        ImageInput(raw_media="base64encodedstring")


def test_image_input_validation_mime_type_without_raw_media() -> None:
    """Test that ImageInput raises error when mime_type is provided without raw_media."""
    with pytest.raises(ValueError, match="raw_media is required when mime_type is provided"):
        ImageInput(mime_type="image/jpeg")
