"""keephive: a knowledge sidecar for Claude Code."""

__version__ = "0.21.1"
