"""内置通用菜单 — 添加 Session、Tab 右键菜单、Session 列表右键菜单。"""

from __future__ import annotations

import mutobj

from mutbot.menu import Menu, MenuItem, MenuResult
from mutbot.web.rpc import RpcContext


# ---------------------------------------------------------------------------
# Session 类型显示信息：从类属性读取
# ---------------------------------------------------------------------------

def _session_display(cls: type) -> tuple[str, str]:
    """获取 Session 子类的 (显示名, 图标)，未声明时从类名推导。"""
    name = getattr(cls, "display_name", "") or ""
    icon = getattr(cls, "display_icon", "") or ""
    if not name:
        # 回退：从类名推导 ("GuideSession" → "Guide Session")
        name = cls.__name__
        if name.endswith("Session"):
            name = name[:-7] + " Session"
    return (name, icon)


# ---------------------------------------------------------------------------
# 内置菜单：添加 Session (SessionPanel/Add)
# ---------------------------------------------------------------------------

class AddSessionMenu(Menu):
    """动态菜单：根据已注册的 Session 子类生成 \"新建 Session\" 菜单项"""

    display_name = "New Session"
    display_category = "SessionPanel/Add"
    display_order = "0new:0"

    @classmethod
    def dynamic_items(cls, context: RpcContext) -> list[MenuItem]:
        """根据已注册的 Session 子类动态生成菜单项"""
        from mutbot.session import Session

        items: list[MenuItem] = []
        idx = 0
        for session_cls in mutobj.discover_subclasses(Session):
            qualified = f"{session_cls.__module__}.{session_cls.__qualname__}"
            label, icon = _session_display(session_cls)
            items.append(MenuItem(
                id=f"add_session:{qualified}",
                name=label,
                icon=icon,
                order=f"0new:{idx}",
                data={"session_type": qualified},
            ))
            idx += 1
        return items

    def execute(self, params: dict, context: RpcContext) -> MenuResult:
        """创建指定类型的 Session。

        处理特殊逻辑：
        - terminal: on_create 中创建 PTY 并设 running 状态
        - document: on_create 中生成默认文件路径
        """
        from mutbot.session import Session

        session_type = params.get("session_type", "")
        if not session_type:
            return MenuResult(action="error", data={"message": "session type is required"})
        sm = context.managers.get("session_manager")
        if sm is None:
            return MenuResult(action="error", data={"message": "session_manager not available"})

        # 验证 Session 类型
        try:
            Session.get_session_class(session_type)
        except ValueError:
            return MenuResult(action="error", data={"message": f"unknown session type: {session_type}"})

        # 将 cwd 写入 config，on_create 按需使用
        config: dict = {}
        wm = context.managers.get("workspace_manager")
        ws = wm.get(context.workspace_id) if wm else None
        if ws:
            config["cwd"] = ws.project_path

        session = sm.create(
            workspace_id=context.workspace_id,
            session_type=session_type,
            config=config if config else None,
        )

        # 将 workspace 的 sessions 列表也更新
        if context.managers.get("workspace_manager"):
            wm = context.managers["workspace_manager"]
            ws = wm.get(context.workspace_id)
            if ws:
                ws.sessions.append(session.id)
                wm.update(ws)

        return MenuResult(
            action="session_created",
            data={
                "session_id": session.id,
                "session_type": session_type,
                "title": session.title,
            },
        )


# ---------------------------------------------------------------------------
# 内置菜单：Tab 右键菜单 (Tab/Context)
# ---------------------------------------------------------------------------

class RenameSessionMenu(Menu):
    """Tab 右键菜单 — 重命名"""
    display_name = "Rename"
    display_icon = "pencil"
    display_category = "Tab/Context"
    display_order = "0basic:0"
    display_shortcut = "F2"
    client_action = "start_rename"


class ChangeIconTabMenu(Menu):
    """Tab 右键菜单 — 更换图标"""
    display_name = "Change Icon"
    display_icon = "palette"
    display_category = "Tab/Context"
    display_order = "0basic:1"
    client_action = "change_icon"


class CloseTabMenu(Menu):
    """Tab 右键菜单 — 关闭 Tab"""
    display_name = "Close"
    display_icon = "x"
    display_category = "Tab/Context"
    display_order = "0basic:2"
    client_action = "close_tab"


class CloseOthersMenu(Menu):
    """Tab 右键菜单 — 关闭其他 Tab"""
    display_name = "Close Others"
    display_category = "Tab/Context"
    display_order = "0basic:3"
    client_action = "close_others"


class CloseAllMenu(Menu):
    """Tab 右键菜单 — 关闭所有 Tab"""
    display_name = "Close All"
    display_category = "Tab/Context"
    display_order = "0basic:4"
    client_action = "close_all"



# ---------------------------------------------------------------------------
# 内置菜单：Session 列表右键菜单 (SessionList/Context)
# ---------------------------------------------------------------------------

class RenameSessionListMenu(Menu):
    """Session 列表右键菜单 — 重命名"""
    display_name = "Rename"
    display_category = "SessionList/Context"
    display_order = "0basic:0"
    client_action = "start_rename"


class ChangeIconSessionListMenu(Menu):
    """Session 列表右键菜单 — 更换图标"""
    display_name = "Change Icon"
    display_icon = "palette"
    display_category = "SessionList/Context"
    display_order = "0basic:1"
    client_action = "change_icon"



class DeleteSessionMenu(Menu):
    """Session 列表右键菜单 — 删除 Session（支持多选批量删除）"""
    display_name = "Delete"
    display_category = "SessionList/Context"
    display_order = "2danger:0"

    @classmethod
    def dynamic_items(cls, context: RpcContext) -> list[MenuItem]:
        menu_ctx = getattr(context, "_menu_context", {})
        session_ids = menu_ctx.get("session_ids", [])
        count = len(session_ids) if isinstance(session_ids, list) else 0
        name = f"Delete ({count})" if count > 1 else "Delete"
        return [MenuItem(
            id=f"{cls.__module__}.{cls.__qualname__}",
            name=name,
            order="2danger:0",
        )]

    def execute(self, params: dict, context: RpcContext) -> MenuResult:
        sm = context.managers.get("session_manager")
        if not sm:
            return MenuResult(action="error", data={"message": "missing session_manager"})
        session_ids = params.get("session_ids", [])
        session_id = params.get("session_id", "")
        # 多选时使用 session_ids，单选时回退到 session_id
        if not session_ids and session_id:
            session_ids = [session_id]
        if not session_ids:
            return MenuResult(action="error", data={"message": "missing session_id(s)"})
        if len(session_ids) == 1:
            return MenuResult(action="session_deleted", data={"session_id": session_ids[0]})
        return MenuResult(action="session_deleted_batch", data={"session_ids": session_ids})


# ---------------------------------------------------------------------------
# 内置菜单：消息列表右键菜单 (MessageList/Context)
# ---------------------------------------------------------------------------

def _is_assistant_text(context: dict) -> bool:
    return context.get("message_role") == "assistant" and context.get("message_type") == "text"


class CopySelectionMenu(Menu):
    """消息列表右键菜单 — 复制选中文本"""
    display_name = "Copy"
    display_icon = "copy"
    display_category = "MessageList/Context"
    display_order = "0edit:0"
    display_shortcut = "Ctrl+C"
    client_action = "copy_selection"


class SelectAllMenu(Menu):
    """消息列表右键菜单 — 全选"""
    display_name = "Select All"
    display_category = "MessageList/Context"
    display_order = "0edit:1"
    display_shortcut = "Ctrl+A"
    client_action = "select_all"


class CopyMarkdownMenu(Menu):
    """消息列表右键菜单 — 复制 Markdown 源码（仅 assistant text 可见）"""
    display_name = "Copy Markdown"
    display_category = "MessageList/Context"
    display_order = "1markdown:0"
    client_action = "copy_markdown"

    @classmethod
    def check_visible(cls, context: dict) -> bool | None:
        return _is_assistant_text(context)


class ToggleMarkdownModeMenu(Menu):
    """消息列表右键菜单 — 切换 Markdown 渲染/源码显示（仅 assistant text 可见）"""
    display_name = "Toggle Markdown Mode"
    display_category = "MessageList/Context"
    display_order = "1markdown:1"
    client_action = "toggle_markdown_mode"

    @classmethod
    def check_visible(cls, context: dict) -> bool | None:
        return _is_assistant_text(context)

    @classmethod
    def dynamic_items(cls, context: RpcContext) -> list[MenuItem]:
        menu_ctx = getattr(context, "_menu_context", {})
        mode = menu_ctx.get("markdown_mode", "rendered")
        name = "View Source" if mode == "rendered" else "View Rendered"
        return [MenuItem(
            id=f"{cls.__module__}.{cls.__qualname__}",
            name=name,
            order="1markdown:1",
            client_action="toggle_markdown_mode",
        )]


# ---------------------------------------------------------------------------
# 内置菜单：Sessions 标题栏全局菜单 (SessionList/Header)
# ---------------------------------------------------------------------------

class CloseWorkspaceMenu(Menu):
    """全局菜单 — Close Workspace"""
    display_name = "Close Workspace"
    display_icon = "log-out"
    display_category = "SessionList/Header"
    display_order = "1workspace:0"
    client_action = "close_workspace"


# ---------------------------------------------------------------------------
# 内置菜单：AgentPanel 标题栏菜单 (AgentPanel/Header)
# ---------------------------------------------------------------------------

class ConfigLLMMenu(Menu):
    """AgentPanel 菜单 — LLM 配置"""
    display_name = "LLM Setup"
    display_icon = "settings"
    display_category = "AgentPanel/Header"
    display_order = "0config:0"
    client_action = "run_setup"


# ---------------------------------------------------------------------------
# 内置菜单：Session 列表空白区域右键菜单 (SessionList/Blank)
# ---------------------------------------------------------------------------

class NewSessionBlankMenu(Menu):
    """Session 列表空白区域右键菜单 — 新建 Session（子菜单）"""
    display_name = "New Session"
    display_icon = "plus"
    display_category = "SessionList/Blank"
    display_order = "0new:0"
    display_submenu_category = "SessionPanel/Add"


# ---------------------------------------------------------------------------
# 内置菜单：Workspace 选择器右键 (WorkspaceSelector/Context)
# ---------------------------------------------------------------------------

class RemoveWorkspaceMenu(Menu):
    """右键菜单 — 从列表中移除 workspace（不删除数据文件）"""
    display_name = "Remove"
    display_icon = "trash-2"
    display_category = "WorkspaceSelector/Context"
    display_order = "0manage:0"

    def execute(self, params: dict, context: RpcContext) -> MenuResult:
        workspace_id = params.get("workspace_id", "")
        if not workspace_id:
            return MenuResult(action="error", data={"message": "missing workspace_id"})
        return MenuResult(
            action="workspace_removed",
            data={"workspace_id": workspace_id},
        )
