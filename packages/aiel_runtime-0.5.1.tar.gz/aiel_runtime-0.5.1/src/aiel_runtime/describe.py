from __future__ import annotations

from typing import Any, Dict, Optional

from aiel_sdk import get_registry, SDK_VERSION
from ._version import RUNTIME_VERSION


def describe(*, snapshot_id: Optional[str] = None) -> Dict[str, Any]:
    reg = get_registry()

    # Describe what can actually be invoked by this runtime (no lying)
    invokable_kinds = ["tool", "agent", "flow", "http", "mcp"]

    return {
        "sdk_version": SDK_VERSION,
        "runtime_version": RUNTIME_VERSION,
        "snapshot_id": snapshot_id,
        "invokable_kinds": invokable_kinds,
        "tools": sorted(reg.tools.keys()),
        "agents": sorted(reg.agents.keys()),
        "flows": sorted(reg.flows.keys()),

        # Still useful metadata, but not invokable by runner.invoke
        "http_handlers": [{"method": h.method, "path": h.path} for h in reg.http_handlers],
        "mcp_servers": [{"name": s.name, "tools": s.tools} for s in reg.mcp_servers.values()],
    }
