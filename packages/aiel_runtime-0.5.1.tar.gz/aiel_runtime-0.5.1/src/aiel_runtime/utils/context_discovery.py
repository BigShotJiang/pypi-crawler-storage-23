from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

def _load_local_ctx_or_raise() -> Dict[str, Any]:
    """
    Load local authenticated context from ~/.config/aiel/credentials.json
    (written by aiel-cli). No dependency on importing aiel_cli.
    """
    p = Path.home() / ".config" / "aiel" / "credentials.json"
    if not p.exists():
        raise ValueError("No local credentials found. Run `aiel auth login`.")

    data = json.loads(p.read_text(encoding="utf-8"))
    current = data.get("current_profile") or "default"
    prof = (data.get("profiles") or {}).get(current) or {}

    ws = prof.get("workspace") or {}
    proj = prof.get("project") or {}

    workspace_id = ws.get("id")
    if not workspace_id:
        raise ValueError("Missing workspace selection. Run `aiel checkout workspace <slug>`.")

    # tenant_id is not stored yet in your file; keep optional for now
    return {
        "tenant_id": prof.get("tenant_id"),  # None until you start storing it
        "workspace_id": workspace_id,
        "project_id": proj.get("id"),
        "user_id": prof.get("user_id"),
    }


def _merge_ctx(auto_ctx: Optional[dict], provided_ctx: Optional[dict]) -> dict[str, Any]:
    """
    Merge ctx dicts; provided_ctx wins.
    Filters out None/"" from auto_ctx.
    """
    out: dict[str, Any] = {}

    for k, v in (auto_ctx or {}).items():
        if v is not None and v != "":
            out[k] = v

    for k, v in (provided_ctx or {}).items():
        if v is not None:
            out[k] = v

    return out