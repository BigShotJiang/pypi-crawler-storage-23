from __future__ import annotations

import asyncio
import json
import sys
from typing import Any, Callable, Optional

import pytest

import aiel_runtime.runner as runner
from aiel_runtime.invoke import InvokeTimeout
from aiel_runtime.loader import SnapshotInfo


def _run_runner(
    *,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    req: dict[str, Any],
    invoke_impl: Optional[Callable[..., Any]] = None,
    describe_impl: Optional[Callable[..., Any]] = None,
    debug: bool = False,
    no_traceback: bool = False,
    files_root: Optional[str] = None,
) -> tuple[int, dict[str, Any]]:
    snapshot = SnapshotInfo(snapshot_id="snap-123", cold_start=True, module_name="mod")
    monkeypatch.setattr(runner, "_read_stdin_json", lambda: json.dumps(req))
    monkeypatch.setattr(runner, "_read_stdin_json_optional", lambda: json.dumps(req))
    monkeypatch.setattr(runner, "_load_snapshot_cached", lambda **kwargs: snapshot)
    if invoke_impl is not None:
        monkeypatch.setattr(runner, "invoke_fn", invoke_impl)
    if describe_impl is not None:
        monkeypatch.setattr(runner, "describe_fn", describe_impl)

    argv = ["aiel_runtime.runner", "--files-root", files_root or "/tmp"]
    if debug:
        argv.append("--debug")
    if no_traceback:
        argv.append("--no-traceback")
    monkeypatch.setattr(sys, "argv", argv)

    rc = asyncio.run(runner.main_async())
    out = capsys.readouterr().out.strip()
    payload = json.loads(out)
    return rc, payload


def test_describe_ok(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path) -> None:
    def _describe(*, snapshot_id: Optional[str] = None) -> dict[str, Any]:
        return {"snapshot_id": snapshot_id, "tools": ["t1"]}

    (tmp_path / "entry_point.py").write_text("# test")
    rc, payload = _run_runner(
        monkeypatch=monkeypatch,
        capsys=capsys,
        req={"action": "describe"},
        describe_impl=_describe,
        files_root=str(tmp_path),
    )
    assert rc == 0
    assert payload["ok"] is True
    assert payload["http_status"] == 200
    assert payload["result"]["tools"] == ["t1"]
    assert payload["meta"]["snapshot_id"] == "snap-123"


def test_invoke_ok(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path) -> None:
    async def _invoke(*, kind: str, handler: str, event: dict, http, mcp, ctx, timeout_ms: int):
        remaining = ctx.get_remaining_time_ms()
        assert remaining is None or remaining <= timeout_ms
        return {"ok": True}

    (tmp_path / "entry_point.py").write_text("# test")
    rc, payload = _run_runner(
        monkeypatch=monkeypatch,
        capsys=capsys,
        req={
            "action": "invoke",
            "kind": "tool",
            "handler": "my_tool",
            "event": {},
            "meta": {"timeout_ms": 5000},
        },
        invoke_impl=_invoke,
        files_root=str(tmp_path),
    )
    assert rc == 0
    assert payload["ok"] is True
    assert payload["http_status"] == 200
    assert payload["result"]["ok"] is True


def test_invoke_not_found(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path) -> None:
    async def _invoke(*, kind: str, handler: str, event: dict, http, mcp, ctx, timeout_ms: int):
        raise KeyError("Tool not found: my_tool")

    (tmp_path / "entry_point.py").write_text("# test")
    rc, payload = _run_runner(
        monkeypatch=monkeypatch,
        capsys=capsys,
        req={"action": "invoke", "kind": "tool", "handler": "my_tool", "event": {}},
        invoke_impl=_invoke,
        files_root=str(tmp_path),
    )
    assert rc == 5
    assert payload["ok"] is False
    assert payload["http_status"] == 404
    assert payload["error"]["code"] == "NOT_FOUND"


def test_validation_error(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path) -> None:
    (tmp_path / "entry_point.py").write_text("# test")
    rc, payload = _run_runner(
        monkeypatch=monkeypatch,
        capsys=capsys,
        req={"action": "invoke", "kind": "tool", "handler": "my_tool", "event": "bad"},
        files_root=str(tmp_path),
    )
    assert rc == 2
    assert payload["ok"] is False
    assert payload["http_status"] == 400
    assert payload["error"]["code"] == "VALIDATION_ERROR"
    assert "traceback" not in (payload["error"].get("details") or {})


def test_user_code_error(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path) -> None:
    async def _invoke(*, kind: str, handler: str, event: dict, http, mcp, ctx, timeout_ms: int):
        raise RuntimeError("boom")

    (tmp_path / "entry_point.py").write_text("# test")
    rc, payload = _run_runner(
        monkeypatch=monkeypatch,
        capsys=capsys,
        req={"action": "invoke", "kind": "tool", "handler": "my_tool", "event": {}},
        invoke_impl=_invoke,
        files_root=str(tmp_path),
    )
    assert rc == 7
    assert payload["ok"] is False
    assert payload["http_status"] == 500
    assert payload["error"]["code"] == "USER_CODE_ERROR"


def test_user_code_error_preserves_upstream_status(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path
) -> None:
    async def _invoke(*, kind: str, handler: str, event: dict, http, mcp, ctx, timeout_ms: int):
        raise RuntimeError("Integration API error (400): Bad Request")

    (tmp_path / "entry_point.py").write_text("# test")
    rc, payload = _run_runner(
        monkeypatch=monkeypatch,
        capsys=capsys,
        req={"action": "invoke", "kind": "tool", "handler": "my_tool", "event": {}},
        invoke_impl=_invoke,
        files_root=str(tmp_path),
    )
    assert rc == 7
    assert payload["ok"] is False
    assert payload["http_status"] == 400
    assert payload["error"]["code"] == "USER_CODE_ERROR"
    assert payload["error"]["details"]["status_code"] == 400


def test_error_response_uses_details_status_code_when_no_explicit_status() -> None:
    resp = runner._error_response(
        request_id="req_1",
        trace_id=None,
        start_ms=0,
        cold_start=False,
        snapshot_id=None,
        code=runner.ERROR_USER_CODE,
        message="failed",
        details={"status_code": 422},
    )
    assert resp.http_status == 422


def test_timeout(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path) -> None:
    async def _invoke(*, kind: str, handler: str, event: dict, http, mcp, ctx, timeout_ms: int):
        raise InvokeTimeout("timeout")

    (tmp_path / "entry_point.py").write_text("# test")
    rc, payload = _run_runner(
        monkeypatch=monkeypatch,
        capsys=capsys,
        req={"action": "invoke", "kind": "tool", "handler": "my_tool", "event": {}},
        invoke_impl=_invoke,
        files_root=str(tmp_path),
    )
    assert rc == 4
    assert payload["ok"] is False
    assert payload["http_status"] == 504
    assert payload["error"]["code"] == "TIMEOUT"


def test_execute_ok(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path) -> None:
    async def _execute(*, files_root, handler: str, event: dict, ctx, timeout_ms: int):
        assert handler == "app.aiel_handler"
        return {"ok": True}

    (tmp_path / "entry_point.py").write_text("# test")
    monkeypatch.setattr(runner, "execute_handler", _execute)
    rc, payload = _run_runner(
        monkeypatch=monkeypatch,
        capsys=capsys,
        req={"action": "execute", "handler": "app.aiel_handler", "event": {}},
        files_root=str(tmp_path),
    )
    assert rc == 0
    assert payload["ok"] is True
    assert payload["http_status"] == 200


def test_execute_default_handler(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path) -> None:
    async def _execute(*, files_root, handler: str, event: dict, ctx, timeout_ms: int):
        assert handler == "entry_point.aiel_handler"
        return {"ok": True}

    (tmp_path / "entry_point.py").write_text("# test")
    monkeypatch.setattr(runner, "execute_handler", _execute)
    rc, payload = _run_runner(
        monkeypatch=monkeypatch,
        capsys=capsys,
        req={"action": "execute", "event": {}},
        files_root=str(tmp_path),
    )
    assert rc == 0
    assert payload["ok"] is True
    assert payload["http_status"] == 200
