"""Сервисы для работы с бизнес-логикой."""

from weblite_framework.services.base import BaseServiceClass

__all__ = ['BaseServiceClass']
