"""Модуль репозиториев."""

from weblite_framework.repository.base import BaseRepositoryClass

__all__ = [
    'BaseRepositoryClass',
]
