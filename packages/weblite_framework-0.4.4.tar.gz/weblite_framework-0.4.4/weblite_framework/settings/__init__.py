"""Настройки для конфигурационных параметров."""

from weblite_framework.settings.database import DatabaseSettings

__all__ = [
    'DatabaseSettings',
]
