"""Support for Peewee ORM (https://github.com/coleifer/peewee)."""

from .handler import PWRESTHandler  # noqa: F401
