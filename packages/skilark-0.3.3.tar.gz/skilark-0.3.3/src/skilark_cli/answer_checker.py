import re


def normalize(s: str) -> str:
    """Normalize answer string for comparison.

    Strips whitespace, lowercases, removes bracket/paren wrappers,
    normalizes commas to spaces, and collapses internal whitespace.
    This lets users write answers in natural forms like "(1, 2)" or
    "[1, 2, 3]" and still match the canonical expected value "1 2 3".
    """
    s = s.strip().lower()
    # Remove common wrappers: parentheses, brackets, braces
    s = re.sub(r'[\[\]\(\)\{\}]', '', s)
    # Normalize commas to spaces
    s = s.replace(',', ' ')
    # Collapse multiple spaces
    s = re.sub(r'\s+', ' ', s)
    return s.strip()


def check_answer(user_answer: str, expected: str) -> bool:
    """Check if user's answer matches expected, with normalization.

    Returns False for blank input so callers can distinguish
    "no answer given" from a wrong answer without special-casing.
    """
    if not user_answer.strip():
        return False
    return normalize(user_answer) == normalize(expected)
