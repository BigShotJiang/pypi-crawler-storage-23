"""
Onboarding flow for first-time CLI users.

Prompts the user to pick topics of interest, registers them with the API,
and persists the resulting config so subsequent commands can skip this step.

Run via: skilark setup
"""

import uuid as _uuid_module

from InquirerPy import inquirer
from rich.console import Console

from skilark_cli.client import SkilarkClient
from skilark_cli.config_store import ConfigStore

TOPIC_CHOICES = [
    # Languages — values match challenges.source column
    {"name": "Python", "value": "python"},
    {"name": "Java", "value": "java"},
    {"name": "JavaScript", "value": "javascript"},
    {"name": "Go", "value": "go"},
    {"name": "Rust", "value": "rust"},
    {"name": "C / C++", "value": "c"},
    {"name": "TypeScript", "value": "typescript"},
    {"name": "SQL", "value": "sql"},
    # Infrastructure & DevOps
    {"name": "Kubernetes", "value": "kubernetes"},
    {"name": "Docker", "value": "docker"},
    {"name": "Terraform", "value": "terraform"},
    {"name": "AWS", "value": "aws"},
    {"name": "CI/CD", "value": "cicd"},
    {"name": "Linux", "value": "linux"},
    # Data Engineering
    {"name": "Spark", "value": "spark"},
    {"name": "Kafka", "value": "kafka"},
    {"name": "Airflow", "value": "airflow"},
    {"name": "Data Modeling", "value": "data-modeling"},
    # ML/AI
    {"name": "PyTorch", "value": "pytorch"},
    {"name": "LLMs", "value": "llms"},
    {"name": "Deep Learning", "value": "deep-learning"},
    {"name": "Machine Learning", "value": "machine-learning"},
    # Backend & Systems
    {"name": "REST APIs", "value": "rest-api"},
    {"name": "Redis", "value": "redis"},
    {"name": "Spring Boot", "value": "spring-boot"},
    {"name": "Distributed Systems", "value": "distributed-systems"},
    # Software Engineering
    {"name": "DSA", "value": "dsa"},
    {"name": "Design Patterns", "value": "patterns"},
    {"name": "System Design", "value": "system-design"},
    # Build Tools
    {"name": "Git", "value": "git"},
    {"name": "Maven", "value": "maven"},
    {"name": "Bazel", "value": "bazel"},
]


def run_onboarding(config_store: ConfigStore, api_url: str) -> None:
    """Run the interactive first-time setup flow.

    Presents a checkbox prompt for topic selection, registers the user via
    the API, and writes the resulting config to disk.

    Args:
        config_store: Where to persist the user config after setup.
        api_url:      Base URL of the Skilark API to register against.
    """
    console = Console()
    console.print("\n[bold]Welcome to Skilark.[/bold] Pick topics to sharpen:\n")

    choices = [{"name": t["name"], "value": t["value"]} for t in TOPIC_CHOICES]

    selected = inquirer.checkbox(
        message="Select topics (space to toggle, enter to confirm):",
        choices=choices,
        validate=lambda result: len(result) >= 1,
        invalid_message="Pick at least one topic.",
    ).execute()

    client = SkilarkClient(base_url=api_url)
    user = client.create_user(topics=selected)

    user_id: str = user["id"]
    try:
        _uuid_module.UUID(user_id)
    except (ValueError, AttributeError, TypeError) as exc:
        raise ValueError(f"API returned an invalid user_id: {user_id!r}") from exc

    config_store.save(user_id=user_id, topics=selected, api_url=api_url)
    console.print(f"\n[green]✓[/green] Ready. You picked {len(selected)} topic(s). Let's go.\n")
