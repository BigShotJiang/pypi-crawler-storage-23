"""Entry point for the skilark CLI."""

import sys

from skilark_cli import __version__


USAGE = """\
Usage: skilark [command]

Commands:
  today           Show today's coding challenge (default)
  status          Show your progress and streaks
  signals [--all] Show this week's market intelligence signals
  fit <query>     Find matching jobs by description or resume
  config          Configure API key and preferences
  link [code]     Link accounts across channels (generate or redeem a code)

Options:
  --help, -h  Print this help message and exit
  --version   Print version and exit
"""


def main() -> None:
    args = sys.argv[1:]

    if not args or args[0] == "today":
        from skilark_cli.commands import today
        today.run()
        return

    command = args[0]

    if command in ("--help", "-h", "help"):
        print(USAGE)
        return

    if command == "--version":
        print(f"skilark {__version__}")
        return

    if command == "status":
        from skilark_cli.commands import status
        status.run()
        return

    if command == "config":
        from skilark_cli.commands import config
        config.run()
        return

    if command == "signals":
        from skilark_cli.commands import signals
        signals.dispatch(args[1:])
        return

    if command == "fit":
        from skilark_cli.commands import fit
        fit.dispatch(args[1:])
        return

    if command == "link":
        from skilark_cli.commands import link
        link.dispatch(args[1:])
        return

    print(f"Unknown command: {command!r}\n", file=sys.stderr)
    print(USAGE, file=sys.stderr)
    sys.exit(1)


if __name__ == "__main__":
    main()
