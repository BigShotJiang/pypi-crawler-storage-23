from http import HTTPStatus
from typing import Any, Dict, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.sync_native_triggers_service_name import SyncNativeTriggersServiceName
from ...types import Response


def _get_kwargs(
    workspace: str,
    service_name: SyncNativeTriggersServiceName,
) -> Dict[str, Any]:
    pass

    return {
        "method": "post",
        "url": "/w/{workspace}/native_triggers/{service_name}/sync".format(
            workspace=workspace,
            service_name=service_name,
        ),
    }


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Any]:
    if response.status_code == HTTPStatus.OK:
        return None
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workspace: str,
    service_name: SyncNativeTriggersServiceName,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[Any]:
    """sync native triggers with external service

    Args:
        workspace (str):
        service_name (SyncNativeTriggersServiceName):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        service_name=service_name,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    workspace: str,
    service_name: SyncNativeTriggersServiceName,
    *,
    client: Union[AuthenticatedClient, Client],
) -> Response[Any]:
    """sync native triggers with external service

    Args:
        workspace (str):
        service_name (SyncNativeTriggersServiceName):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs(
        workspace=workspace,
        service_name=service_name,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
