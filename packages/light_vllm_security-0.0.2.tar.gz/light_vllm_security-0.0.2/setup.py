"""
Custom setup.py to ensure vllm_model_security.pth is installed
into site-packages on both Linux and Windows.

The standard [tool.setuptools.data-files] approach places the .pth file
into the Python prefix data directory, NOT site-packages, when installed
via wheel. This custom install command fixes that.
"""
import os
import site
import shutil
from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop


PTH_FILE = "vllm_model_security.pth"


def _install_pth(install_dir: str) -> None:
    """Copy the .pth file into the given site-packages directory."""
    src = os.path.join(os.path.dirname(__file__), PTH_FILE)
    dst = os.path.join(install_dir, PTH_FILE)
    shutil.copy2(src, dst)
    print(f"Installed {PTH_FILE} -> {dst}")


class InstallWithPth(install):
    """Override install to also drop the .pth file into site-packages."""

    def run(self):
        super().run()
        # self.install_lib is the site-packages directory chosen by pip/setuptools
        _install_pth(self.install_lib)


class DevelopWithPth(develop):
    """Override develop (pip install -e) to also drop the .pth file."""

    def run(self):
        super().run()
        # For editable installs, use the first writable site-packages
        sp = site.getsitepackages()
        target = sp[0] if sp else site.getusersitepackages()
        _install_pth(target)


setup(
    cmdclass={
        "install": InstallWithPth,
        "develop": DevelopWithPth,
    },
)
