# SPDX-License-Identifier: Apache-2.0
"""
vLLM Model Security — namespace package extension.

This package extends the official vllm package with model encryption,
license validation, and authorization capabilities.

When imported (automatically via .pth or manually), it patches the
official vllm.config.LoadFormat enum to add ENCRYPTED support.

Installation:
    pip install vllm==0.8.5.post2
    pip install vllm-model-security

After installation the patch fires automatically at Python startup
via the vllm_model_security.pth file placed in site-packages.
Users can then run vllm normally:

    vllm serve /path/to/encrypted_model --load-format encrypted

or use auto-detection (just point at an encrypted model dir):

    vllm serve /path/to/encrypted_model
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Patch vllm.config.LoadFormat to include ENCRYPTED at import time.
# This is safe to call multiple times (idempotent).
# ---------------------------------------------------------------------------

def _patch_load_format() -> None:
    """Inject LoadFormat.ENCRYPTED into the official vllm.config module."""
    try:
        import vllm.config as _cfg
        lf = _cfg.LoadFormat
        if not hasattr(lf, "ENCRYPTED"):
            lf.ENCRYPTED = "encrypted"  # type: ignore[attr-defined]
            logger.debug("vllm-model-security: patched LoadFormat.ENCRYPTED")
    except Exception as exc:  # pragma: no cover
        # Non-fatal: the loader will still work via auto-detection
        logger.warning("vllm-model-security: failed to patch LoadFormat: %s", exc)


_patch_load_format()

# ---------------------------------------------------------------------------
# Public API re-exports
# ---------------------------------------------------------------------------

from vllm.model_security.crypto import (  # noqa: E402
    ModelEncryptor,
    ModelDecryptor,
    generate_dek,
)
from vllm.model_security.license import (  # noqa: E402
    LicenseManager,
    LicenseValidator,
    LicenseInfo,
)
from vllm.model_security.fingerprint import (  # noqa: E402
    get_machine_fingerprint,
    FingerprintPolicy,
)

__all__ = [
    "ModelEncryptor",
    "ModelDecryptor",
    "generate_dek",
    "LicenseManager",
    "LicenseValidator",
    "LicenseInfo",
    "get_machine_fingerprint",
    "FingerprintPolicy",
]
