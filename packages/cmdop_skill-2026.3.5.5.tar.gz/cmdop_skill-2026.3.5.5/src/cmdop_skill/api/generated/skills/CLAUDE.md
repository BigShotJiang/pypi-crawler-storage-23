# Cmdop API - Python Client

Auto-generated. **Do not edit manually.**

```bash
python manage.py generate_client --groups skills --python
```

## Stats

| | |
|---|---|
| Version | 3.1.0 |
| Operations | 21 |
| Schemas | 23 |

## Resources

- **Skills** (21 ops)

## Usage

```python
from .client import APIClient

client = APIClient(base_url="...", token="...")

await client.skills.list()
await client.skills.retrieve(id=1)
```

## How It Works

```
DRF ViewSets → drf-spectacular → OpenAPI → IR Parser → Generator → This Client
```

**Configuration** (`api/config.py`):
```python
openapi_client = OpenAPIClientConfig(
    enabled=True,
    groups=[OpenAPIGroupConfig(name="skills", apps=["..."])],
)
```

@see https://djangocfg.com/docs/features/api-generation

