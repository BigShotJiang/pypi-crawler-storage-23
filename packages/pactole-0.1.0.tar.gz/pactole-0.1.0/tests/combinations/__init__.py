"""Unit tests for combinations package."""
