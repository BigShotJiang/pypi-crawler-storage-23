# Changelog

All notable changes to this project will be documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
Versions follow [Semantic Versioning](https://semver.org/).

---

## [0.1.0] — 2026-02-25

### Added
- Initial release
- YAML-driven terminal demo SVG generation — no recording required
- `termstage` CLI with `render` command
- Support for typing, pause, output, and clear actions
- Typer-based CLI with `--output` flag
- PyPI packaging via hatchling + uv
