"""AI-based chatbot that provides sensible answers based on documentation"""

__version__ = '1.14.2'

