# Notes

Working notes and temporary documentation for session-buddy project.

