#!/bin/bash
# Run the E2E test and capture results

# Make test script executable
chmod +x /Users/les/Projects/session-buddy/test_e2e.sh

# Run the test
/Users/les/Projects/session-buddy/test_e2e.sh
