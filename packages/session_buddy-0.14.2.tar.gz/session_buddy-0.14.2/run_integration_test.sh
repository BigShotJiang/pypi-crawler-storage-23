#!/bin/bash
# Run the Python integration test

cd /Users/les/Projects/session-buddy
chmod +x test_session_tracking_integration.py
python test_session_tracking_integration.py
