- Update the python bindings, streaming server and frontend if needed
- Update CHANGELOG.md and docs/
- Commit and push

$ARGUMENTS
