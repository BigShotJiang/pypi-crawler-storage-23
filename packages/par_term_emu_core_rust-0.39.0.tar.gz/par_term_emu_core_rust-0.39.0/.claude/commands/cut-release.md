- Ensure the python bindings and streaming server are up to date
- Bump version
- Update CHANGELOG.md, docs/ and README.md
- Run `make pre-commit-run`
- Commit and push
- run `make deploy` to trigger cicd workflow

$ARGUMENTS
