An agent did work on this project.

- See what it did
- Update the python bindings and streaming server and frontend if needed
- Update CHANGELOG.md
- Commit and push

$ARGUMENTS
