"""Tests for PDF retrieval module."""

from __future__ import annotations

from opencite.config import Config
from opencite.models import Author, IDSet, Paper, PDFLocation
from opencite.pdf import _PUBLISHER_MAP, PDFRetriever


class TestCollectUrls:
    def _make_retriever(self, **config_kwargs):
        retriever = PDFRetriever.__new__(PDFRetriever)
        retriever.config = Config(**config_kwargs)
        return retriever

    def test_pdf_locations_first(self):
        paper = Paper(
            title="Test",
            ids=IDSet(doi="10.1234/test"),
            pdf_locations=[
                PDFLocation(url="https://example.com/paper.pdf", source="s2"),
            ],
        )
        retriever = self._make_retriever()
        urls = retriever._collect_urls(paper, "10.1234/test")
        assert urls[0] == "https://example.com/paper.pdf"

    def test_pmc_url_added(self):
        paper = Paper(
            title="Test",
            ids=IDSet(pmcid="PMC12345"),
        )
        retriever = self._make_retriever()
        urls = retriever._collect_urls(paper, "PMC12345")
        assert any("PMC12345" in u for u in urls)

    def test_doi_url_added(self):
        paper = Paper(
            title="Test",
            ids=IDSet(doi="10.1234/test"),
        )
        retriever = self._make_retriever()
        urls = retriever._collect_urls(paper, "10.1234/test")
        assert "https://doi.org/10.1234/test" in urls

    def test_no_paper_doi_fallback(self):
        retriever = self._make_retriever()
        urls = retriever._collect_urls(None, "10.1234/test")
        assert "https://doi.org/10.1234/test" in urls

    def test_no_paper_non_doi(self):
        retriever = self._make_retriever()
        urls = retriever._collect_urls(None, "some_invalid_id")
        assert urls == []

    def test_no_duplicate_urls(self):
        paper = Paper(
            title="Test",
            ids=IDSet(doi="10.1234/test"),
            pdf_locations=[
                PDFLocation(url="https://doi.org/10.1234/test", source="doi"),
            ],
        )
        retriever = self._make_retriever()
        urls = retriever._collect_urls(paper, "10.1234/test")
        assert urls.count("https://doi.org/10.1234/test") == 1


class TestPublisherUrls:
    def _make_retriever(self, **config_kwargs):
        retriever = PDFRetriever.__new__(PDFRetriever)
        retriever.config = Config(**config_kwargs)
        return retriever

    def test_elsevier_url_added_with_key(self):
        retriever = self._make_retriever(elsevier_api_key="els_test")
        paper = Paper(title="Test", ids=IDSet(doi="10.1016/j.test.2024"))
        urls = retriever._collect_urls(paper, "10.1016/j.test.2024")
        assert any("api.elsevier.com" in u for u in urls)
        # Publisher URL should be first (highest priority)
        assert "api.elsevier.com" in urls[0]

    def test_elsevier_url_not_added_without_key(self):
        retriever = self._make_retriever()
        paper = Paper(title="Test", ids=IDSet(doi="10.1016/j.test.2024"))
        urls = retriever._collect_urls(paper, "10.1016/j.test.2024")
        assert not any("api.elsevier.com" in u for u in urls)

    def test_wiley_url_added_with_key(self):
        retriever = self._make_retriever(wiley_tdm_token="wiley_test")
        paper = Paper(title="Test", ids=IDSet(doi="10.1002/test.123"))
        urls = retriever._collect_urls(paper, "10.1002/test.123")
        assert any("api.wiley.com" in u for u in urls)

    def test_springer_url_added_with_key(self):
        retriever = self._make_retriever(springer_api_key="springer_test")
        paper = Paper(title="Test", ids=IDSet(doi="10.1007/s123-test"))
        urls = retriever._collect_urls(paper, "10.1007/s123-test")
        assert any("api.springernature.com" in u for u in urls)

    def test_springer_nature_prefix(self):
        retriever = self._make_retriever(springer_api_key="springer_test")
        paper = Paper(title="Test", ids=IDSet(doi="10.1038/nature12345"))
        urls = retriever._collect_urls(paper, "10.1038/nature12345")
        assert any("api.springernature.com" in u for u in urls)

    def test_unknown_publisher_no_extra_urls(self):
        retriever = self._make_retriever(elsevier_api_key="test")
        paper = Paper(title="Test", ids=IDSet(doi="10.9999/unknown"))
        urls = retriever._collect_urls(paper, "10.9999/unknown")
        assert not any("api.elsevier.com" in u for u in urls)
        assert not any("api.wiley.com" in u for u in urls)


class TestPublisherMap:
    def test_elsevier_prefix(self):
        assert "10.1016" in _PUBLISHER_MAP

    def test_wiley_prefix(self):
        assert "10.1002" in _PUBLISHER_MAP

    def test_springer_prefix(self):
        assert "10.1007" in _PUBLISHER_MAP


class TestReportFailures:
    def _make_retriever(self):
        retriever = PDFRetriever.__new__(PDFRetriever)
        retriever.config = Config()
        return retriever

    def test_empty_failures(self, caplog):
        import logging

        retriever = self._make_retriever()
        with caplog.at_level(logging.WARNING):
            retriever._report_failures("10.1234/test", [], None)
        assert "All PDF download attempts failed" in caplog.text

    def test_failures_with_reasons(self, caplog):
        import logging

        retriever = self._make_retriever()
        failures = [
            ("https://example.com/paper.pdf", "403 Forbidden/Unauthorized"),
            ("https://doi.org/10.1234/test", "timeout"),
        ]
        with caplog.at_level(logging.WARNING):
            retriever._report_failures("10.1234/test", failures, None)
        assert "Tried 2 source(s)" in caplog.text
        assert "403 Forbidden" in caplog.text
        assert "timeout" in caplog.text

    def test_suggests_institutional_access(self, caplog):
        import logging

        retriever = self._make_retriever()
        paper = Paper(title="Test", ids=IDSet(doi="10.1234/test"))
        failures = [("https://example.com", "404 Not Found")]
        with caplog.at_level(logging.INFO):
            retriever._report_failures("10.1234/test", failures, paper)
        assert "institutional access" in caplog.text


class TestMakeFilename:
    def test_with_paper(self):
        paper = Paper(
            title="Attention Is All You Need",
            authors=[Author(name="Vaswani", family_name="Vaswani")],
            year=2017,
        )
        retriever = PDFRetriever.__new__(PDFRetriever)
        name = retriever._make_filename(paper, "10.xxx")
        assert "Vaswani" in name
        assert "2017" in name
        assert "Attention" in name

    def test_no_paper(self):
        retriever = PDFRetriever.__new__(PDFRetriever)
        name = retriever._make_filename(None, "10.1234/test.123")
        assert name == "10.1234_test.123"

    def test_no_authors(self):
        paper = Paper(title="Some Title", year=2020)
        retriever = PDFRetriever.__new__(PDFRetriever)
        name = retriever._make_filename(paper, "id")
        assert "2020" in name
        assert "Some" in name


class TestMakeFilenameEdgeCases:
    def test_author_name_only(self):
        """When author has no family_name, uses name field."""
        paper = Paper(
            title="Some Title",
            authors=[Author(name="J. Smith")],
            year=2020,
        )
        retriever = PDFRetriever.__new__(PDFRetriever)
        name = retriever._make_filename(paper, "id")
        # Should split on comma and use first part
        assert "J" in name or "Smith" in name

    def test_title_only(self):
        """Paper with title but no authors or year."""
        paper = Paper(title="Test Title Here")
        retriever = PDFRetriever.__new__(PDFRetriever)
        name = retriever._make_filename(paper, "id")
        assert "Test" in name

    def test_special_chars_in_identifier(self):
        retriever = PDFRetriever.__new__(PDFRetriever)
        name = retriever._make_filename(None, "10.1016/j.neuroimage.2024.001")
        # Slashes and dots should be replaced
        assert "/" not in name


class TestReportFailuresEdgeCases:
    def _make_retriever(self):
        retriever = PDFRetriever.__new__(PDFRetriever)
        retriever.config = Config()
        return retriever

    def test_institutional_access_from_identifier(self, caplog):
        """When paper has no DOI but identifier is a DOI, suggest access."""
        import logging

        retriever = self._make_retriever()
        failures = [("https://example.com", "404")]
        with caplog.at_level(logging.INFO):
            retriever._report_failures("10.1234/test", failures, None)
        assert "institutional access" in caplog.text

    def test_no_institutional_suggestion_for_non_doi(self, caplog):
        """When identifier is not a DOI, no institutional suggestion."""
        import logging

        retriever = self._make_retriever()
        failures = [("https://example.com", "404")]
        with caplog.at_level(logging.INFO):
            retriever._report_failures("some_random_id", failures, None)
        assert "institutional access" not in caplog.text


class TestCollectUrlsEdgeCases:
    def _make_retriever(self, **config_kwargs):
        retriever = PDFRetriever.__new__(PDFRetriever)
        retriever.config = Config(**config_kwargs)
        return retriever

    def test_multiple_pdf_locations(self):
        paper = Paper(
            title="Test",
            ids=IDSet(doi="10.1234/test"),
            pdf_locations=[
                PDFLocation(url="https://a.pdf", source="s2"),
                PDFLocation(url="https://b.pdf", source="openalex"),
            ],
        )
        retriever = self._make_retriever()
        urls = retriever._collect_urls(paper, "10.1234/test")
        assert "https://a.pdf" in urls
        assert "https://b.pdf" in urls

    def test_identifier_parsed_when_no_paper(self):
        """When paper is None, DOI is extracted from identifier."""
        retriever = self._make_retriever()
        urls = retriever._collect_urls(None, "10.1234/test")
        assert "https://doi.org/10.1234/test" in urls

    def test_identifier_pmid_no_urls(self):
        """A PMID with no paper produces no URLs (no DOI to negotiate)."""
        retriever = self._make_retriever()
        urls = retriever._collect_urls(None, "pmid:12345")
        assert urls == []
