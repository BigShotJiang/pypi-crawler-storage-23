"""API clients for academic data sources."""
