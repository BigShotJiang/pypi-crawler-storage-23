# Process module - request handling for batch processing
from .request import send_request

__all__ = ["send_request"]
