"""
This package implements the functions for Noviat's isabel_connect Odoo application.
"""
