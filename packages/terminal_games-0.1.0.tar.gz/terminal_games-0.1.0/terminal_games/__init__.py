"""Terminal Games - A collection of classic mini games for your terminal 🎮"""

__version__ = "0.1.0"
