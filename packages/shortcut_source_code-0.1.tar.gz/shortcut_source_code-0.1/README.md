# cp_utils

Competitive Programming Utilities (CP Utils)

A lightweight Python package that provides simple helper functions for reading input in competitive programming.

## Features

- Read a single integer
- Read a list of integers
- Read a list of floats

## Installation

```bash
pip install cp-utils

```
## Author

Abdelrahman Maali  
Email: abedalrahmanmaali23@gmail.com