from setuptools import setup, find_packages

with open("README.md", "r") as f:
    description = f.read()


setup(
    name = "shortcut_source_code",
    version = "0.1",
    long_description = description,
    packages = find_packages(),
    long_description_content_type = "text/markdown",
    author="Abdelrahman Maali",
    author_email="abedalrahmanmaali23@gmail.com",
)