def read_int_list() -> list[int]:
    # Convarte multible interger from input to int in list
    return list(map(int, input().split()))
def read_float_list() -> list[float]:
    # Convarte multible float number from input to float in list
    return list(map(float, input().split()))
def read_int() -> int:
    # Convarte single interger from input to int in list
    return int(input())