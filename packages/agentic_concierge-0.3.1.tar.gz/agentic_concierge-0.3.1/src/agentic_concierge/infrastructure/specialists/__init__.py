from .registry import ConfigSpecialistRegistry

__all__ = ["ConfigSpecialistRegistry"]
