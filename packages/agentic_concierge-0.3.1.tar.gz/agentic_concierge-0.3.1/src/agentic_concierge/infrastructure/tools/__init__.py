"""Tool implementations: sandbox, file, shell, web."""
