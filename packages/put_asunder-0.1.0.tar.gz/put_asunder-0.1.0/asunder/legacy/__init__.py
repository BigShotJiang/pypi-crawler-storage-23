"""Legacy compatibility shims for notebook-era API names."""

from asunder.legacy.notebook_compat import CSD_decomposition

__all__ = ["CSD_decomposition"]
