"""Tests for shared-cache file management methods in AIAutoController."""

import json
from unittest.mock import MagicMock, patch

import pytest
import requests

from aiauto.core import AIAutoController


@pytest.fixture
def mock_controller():
    """Create an AIAutoController with mocked dependencies (bypass __init__)."""
    ctrl = object.__new__(AIAutoController)
    ctrl.token = "test-token-abc"
    ctrl.client = MagicMock()
    ctrl.client.base_url = "https://api.example.com"
    return ctrl


@pytest.fixture
def tmp_files(tmp_path):
    """Create temporary files for upload testing."""
    f1 = tmp_path / "train.csv"
    f1.write_text("col1,col2\n1,2\n")
    f2 = tmp_path / "test.csv"
    f2.write_text("col1,col2\n3,4\n")
    return str(f1), str(f2)


def _mock_encoder():
    """Create a mock MultipartEncoder with standard content_type."""
    encoder = MagicMock()
    encoder.content_type = "multipart/form-data; boundary=abc123"
    return encoder


def _mock_json_response(json_data=None, status_code=200):
    """Create a mock response that returns JSON successfully."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data or {}
    resp.raise_for_status = MagicMock()
    return resp


class TestSharedCacheHeaders:
    """Test _shared_cache_headers helper."""

    def test_returns_bearer_token(self, mock_controller):
        headers = mock_controller._shared_cache_headers()
        assert headers == {"Authorization": "Bearer test-token-abc"}


class TestUploadToSharedCache:
    """Test upload_to_shared_cache method."""

    @patch("aiauto.core.requests.post")
    @patch("aiauto.core.MultipartEncoder")
    def test_single_file(self, mock_encoder_cls, mock_post, mock_controller, tmp_files):
        mock_encoder_cls.return_value = _mock_encoder()
        mock_post.return_value = _mock_json_response({"uploaded": ["train.csv"]})

        result = mock_controller.upload_to_shared_cache(tmp_files[0])

        assert result == {"uploaded": ["train.csv"]}
        mock_post.assert_called_once()
        call_kwargs = mock_post.call_args.kwargs
        assert call_kwargs["data"] is mock_encoder_cls.return_value
        assert call_kwargs["headers"]["Content-Type"] == "multipart/form-data; boundary=abc123"
        assert call_kwargs["headers"]["Authorization"] == "Bearer test-token-abc"
        assert call_kwargs["verify"] is True
        assert call_kwargs["timeout"] == (10, 3600)

    @patch("aiauto.core.requests.post")
    @patch("aiauto.core.MultipartEncoder")
    def test_multiple_files(self, mock_encoder_cls, mock_post, mock_controller, tmp_files):
        mock_encoder_cls.return_value = _mock_encoder()
        mock_post.return_value = _mock_json_response({"uploaded": ["train.csv", "test.csv"]})

        result = mock_controller.upload_to_shared_cache(list(tmp_files))

        assert result == {"uploaded": ["train.csv", "test.csv"]}
        fields = mock_encoder_cls.call_args.kwargs.get("fields") or mock_encoder_cls.call_args[0][0]
        assert len(fields) == 2
        assert fields[0][0] == "files"
        assert fields[1][0] == "files"

    @patch("aiauto.core.requests.post")
    @patch("aiauto.core.MultipartEncoder")
    def test_with_dest_dir(self, mock_encoder_cls, mock_post, mock_controller, tmp_files):
        mock_encoder_cls.return_value = _mock_encoder()
        mock_post.return_value = _mock_json_response({"uploaded": ["data/train.csv"]})

        mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="/data/")

        fields = mock_encoder_cls.call_args.kwargs.get("fields") or mock_encoder_cls.call_args[0][0]
        assert fields[0][1][0] == "data/train.csv"

    @patch("aiauto.core.requests.post")
    @patch("aiauto.core.MultipartEncoder")
    def test_url_construction(self, mock_encoder_cls, mock_post, mock_controller, tmp_files):
        mock_encoder_cls.return_value = _mock_encoder()
        mock_post.return_value = _mock_json_response()

        mock_controller.upload_to_shared_cache(tmp_files[0])

        url = mock_post.call_args[0][0]
        assert url == "https://api.example.com/api/workspace/upload"

    @patch("aiauto.core.requests.post")
    @patch("aiauto.core.MultipartEncoder")
    def test_http_error_raises(self, mock_encoder_cls, mock_post, mock_controller, tmp_files):
        mock_encoder_cls.return_value = _mock_encoder()
        mock_resp = MagicMock()
        mock_resp.raise_for_status.side_effect = requests.exceptions.HTTPError("401 Unauthorized")
        mock_post.return_value = mock_resp

        with pytest.raises(requests.exceptions.HTTPError):
            mock_controller.upload_to_shared_cache(tmp_files[0])

    @patch("aiauto.core.requests.post")
    @patch("aiauto.core.MultipartEncoder")
    def test_non_json_response_raises_runtime_error(
        self, mock_encoder_cls, mock_post, mock_controller, tmp_files
    ):
        mock_encoder_cls.return_value = _mock_encoder()
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.status_code = 200
        mock_resp.text = "<html>Bad Gateway</html>"
        mock_resp.json.side_effect = json.JSONDecodeError("", "", 0)
        mock_post.return_value = mock_resp

        with pytest.raises(RuntimeError, match="non-JSON response"):
            mock_controller.upload_to_shared_cache(tmp_files[0])

    def test_empty_list_raises_value_error(self, mock_controller):
        with pytest.raises(ValueError, match="must not be empty"):
            mock_controller.upload_to_shared_cache([])

    def test_dest_dir_path_traversal_raises(self, mock_controller, tmp_files):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="../etc")

    def test_dest_dir_dotdot_only_raises(self, mock_controller, tmp_files):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="..")

    def test_dest_dir_middle_traversal_raises(self, mock_controller, tmp_files):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="data/../secret")

    @patch("aiauto.core.requests.post")
    @patch("aiauto.core.MultipartEncoder")
    def test_dest_dir_empty_string_treated_as_none(
        self, mock_encoder_cls, mock_post, mock_controller, tmp_files
    ):
        """dest_dir="" should behave like dest_dir=None (upload to root)."""
        mock_encoder_cls.return_value = _mock_encoder()
        mock_post.return_value = _mock_json_response({"uploaded": ["train.csv"]})

        mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="")

        fields = mock_encoder_cls.call_args.kwargs.get("fields") or mock_encoder_cls.call_args[0][0]
        assert fields[0][1][0] == "train.csv"

    @patch("aiauto.core.requests.post")
    @patch("aiauto.core.MultipartEncoder")
    def test_dest_dir_whitespace_only_treated_as_none(
        self, mock_encoder_cls, mock_post, mock_controller, tmp_files
    ):
        """dest_dir="  " should behave like dest_dir=None after strip()."""
        mock_encoder_cls.return_value = _mock_encoder()
        mock_post.return_value = _mock_json_response({"uploaded": ["train.csv"]})

        mock_controller.upload_to_shared_cache(tmp_files[0], dest_dir="  ")

        fields = mock_encoder_cls.call_args.kwargs.get("fields") or mock_encoder_cls.call_args[0][0]
        assert fields[0][1][0] == "train.csv"

    @patch("aiauto.core.requests.post")
    @patch("aiauto.core.MultipartEncoder")
    def test_string_input_converted_to_list(
        self, mock_encoder_cls, mock_post, mock_controller, tmp_files
    ):
        """Test that a single string path is automatically wrapped in a list."""
        mock_encoder_cls.return_value = _mock_encoder()
        mock_post.return_value = _mock_json_response()

        mock_controller.upload_to_shared_cache(tmp_files[0])

        fields = mock_encoder_cls.call_args.kwargs.get("fields") or mock_encoder_cls.call_args[0][0]
        assert len(fields) == 1


class TestListSharedCache:
    """Test list_shared_cache method."""

    @patch("aiauto.core.requests.get")
    def test_success(self, mock_get, mock_controller):
        mock_get.return_value = _mock_json_response({"files": ["train.csv", "test.csv"]})

        result = mock_controller.list_shared_cache()

        assert result == {"files": ["train.csv", "test.csv"]}
        mock_get.assert_called_once_with(
            "https://api.example.com/api/workspace/files",
            headers={"Authorization": "Bearer test-token-abc"},
            verify=True,
            timeout=10,
        )

    @patch("aiauto.core.requests.get")
    def test_http_error_raises(self, mock_get, mock_controller):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.side_effect = requests.exceptions.HTTPError("401")
        mock_get.return_value = mock_resp

        with pytest.raises(requests.exceptions.HTTPError):
            mock_controller.list_shared_cache()

    @patch("aiauto.core.requests.get")
    def test_non_json_response_raises_runtime_error(self, mock_get, mock_controller):
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.status_code = 200
        mock_resp.text = "not json"
        mock_resp.json.side_effect = json.JSONDecodeError("", "", 0)
        mock_get.return_value = mock_resp

        with pytest.raises(RuntimeError, match="non-JSON response"):
            mock_controller.list_shared_cache()


class TestDeleteFromSharedCache:
    """Test delete_from_shared_cache method."""

    @patch("aiauto.core.requests.delete")
    def test_success(self, mock_delete, mock_controller):
        mock_delete.return_value = _mock_json_response({"deleted": "data/train.csv"})

        result = mock_controller.delete_from_shared_cache("data/train.csv")

        assert result == {"deleted": "data/train.csv"}
        mock_delete.assert_called_once_with(
            "https://api.example.com/api/workspace/files/data/train.csv",
            headers={"Authorization": "Bearer test-token-abc"},
            verify=True,
            timeout=10,
        )

    @patch("aiauto.core.requests.delete")
    def test_url_encoding(self, mock_delete, mock_controller):
        """Test that special characters in path are URL-encoded."""
        mock_delete.return_value = _mock_json_response({"deleted": "data/my file.csv"})

        mock_controller.delete_from_shared_cache("data/my file.csv")

        url = mock_delete.call_args[0][0]
        assert "my%20file.csv" in url
        assert "/data/" in url

    def test_empty_path_raises_value_error(self, mock_controller):
        with pytest.raises(ValueError, match="must not be empty"):
            mock_controller.delete_from_shared_cache("")

    def test_path_traversal_raises(self, mock_controller):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.delete_from_shared_cache("../etc/passwd")

    def test_path_dotdot_only_raises(self, mock_controller):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.delete_from_shared_cache("..")

    def test_path_middle_traversal_raises(self, mock_controller):
        with pytest.raises(ValueError, match="must not contain"):
            mock_controller.delete_from_shared_cache("data/../secret")

    @patch("aiauto.core.requests.delete")
    def test_http_error_raises(self, mock_delete, mock_controller):
        mock_resp = MagicMock()
        mock_resp.raise_for_status.side_effect = requests.exceptions.HTTPError("404")
        mock_delete.return_value = mock_resp

        with pytest.raises(requests.exceptions.HTTPError):
            mock_controller.delete_from_shared_cache("nonexistent.csv")

    @patch("aiauto.core.requests.delete")
    def test_non_json_response_raises_runtime_error(self, mock_delete, mock_controller):
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.status_code = 200
        mock_resp.text = "deleted"
        mock_resp.json.side_effect = json.JSONDecodeError("", "", 0)
        mock_delete.return_value = mock_resp

        with pytest.raises(RuntimeError, match="non-JSON response"):
            mock_controller.delete_from_shared_cache("file.csv")
