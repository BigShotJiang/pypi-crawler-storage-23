## [0.15.7](https://github.com/easytocloud/Mac-letterhead/compare/v0.15.6...v0.15.7) (2026-03-02)


### Bug Fixes

* use MCP_PUBLISHER_TOKEN PAT for mcp-publisher login ([e4eeae7](https://github.com/easytocloud/Mac-letterhead/commit/e4eeae74c95a42e5909aebeeae742526452df67d))

## [0.15.6](https://github.com/easytocloud/Mac-letterhead/compare/v0.15.5...v0.15.6) (2026-03-02)


### Bug Fixes

* add mcp-publisher login step before publish ([6031ca7](https://github.com/easytocloud/Mac-letterhead/commit/6031ca78873aced90b966f3fe316098103766608))

## [0.15.5](https://github.com/easytocloud/Mac-letterhead/compare/v0.15.4...v0.15.5) (2026-03-02)


### Bug Fixes

* target arm64 mcp-publisher binary for macos-latest runners ([3dd1a3f](https://github.com/easytocloud/Mac-letterhead/commit/3dd1a3f875319d2afaa813cb7686dcede71815ce))

## [0.15.4](https://github.com/easytocloud/Mac-letterhead/compare/v0.15.3...v0.15.4) (2026-03-02)


### Bug Fixes

* use gh release list instead of unsupported --latest flag ([a7ad14a](https://github.com/easytocloud/Mac-letterhead/commit/a7ad14a2e39b3e08b84d03a2b5ee07b01ba0795e))

## [0.15.3](https://github.com/easytocloud/Mac-letterhead/compare/v0.15.2...v0.15.3) (2026-03-02)


### Bug Fixes

* trigger publish-mcp-registry via workflow_run instead of tag push ([2810472](https://github.com/easytocloud/Mac-letterhead/commit/281047284cd84ed94dc206fd82881cd9f2c580cb))

## [0.15.2](https://github.com/easytocloud/Mac-letterhead/compare/v0.15.1...v0.15.2) (2026-03-02)


### Bug Fixes

* convert mcp-name to hidden HTML comment for registry verification ([51373c3](https://github.com/easytocloud/Mac-letterhead/commit/51373c32aa79fd2f6ac787e1932e86aaed014a55))

## [0.15.1](https://github.com/easytocloud/Mac-letterhead/compare/v0.15.0...v0.15.1) (2026-03-02)


### Bug Fixes

* keep DXT manifest version in lockstep with package version ([3cbd301](https://github.com/easytocloud/Mac-letterhead/commit/3cbd3019efce1377990d19bb9f1fc52d42763024))

# [0.15.0](https://github.com/easytocloud/Mac-letterhead/compare/v0.14.3...v0.15.0) (2026-03-01)


### Bug Fixes

* correct DXT manifest and build toolchain for mcpb packer ([2159ad7](https://github.com/easytocloud/Mac-letterhead/commit/2159ad756ee138acf41d752c3b03e368ac4b6fd8))


### Features

* add Desktop Extension (DXT) for one-click Claude installation ([d42104b](https://github.com/easytocloud/Mac-letterhead/commit/d42104b5928e53592cd18795afa7778edd9ba203))

## [0.14.3](https://github.com/easytocloud/Mac-letterhead/compare/v0.14.2...v0.14.3) (2026-03-01)


### Bug Fixes

* pin cryptography>=46.0.5 to address subgroup attack vulnerability ([a6d26e3](https://github.com/easytocloud/Mac-letterhead/commit/a6d26e3c59c5cf8c309ecb75d489785196fdd981))

## [0.14.2](https://github.com/easytocloud/Mac-letterhead/compare/v0.14.1...v0.14.2) (2026-03-01)


### Bug Fixes

* resolve remaining security vulnerabilities in transitive dependencies ([7348802](https://github.com/easytocloud/Mac-letterhead/commit/7348802a61886cb2cc220383e7e1296f7aa27fad))

## [0.14.1](https://github.com/easytocloud/Mac-letterhead/compare/v0.14.0...v0.14.1) (2026-03-01)


### Bug Fixes

* upgrade dependencies to address security vulnerabilities ([ee95775](https://github.com/easytocloud/Mac-letterhead/commit/ee95775289f5a57f433d8a893eef6838a1d1cdb7))

# [0.14.0](https://github.com/easytocloud/Mac-letterhead/compare/v0.13.9...v0.14.0) (2025-10-12)


### Features

* publish Mac-letterhead to MCP Registry ([35325c5](https://github.com/easytocloud/Mac-letterhead/commit/35325c5a1feda4a39af62ae248defc941585c571))

# Changelog

All notable changes to this project will be managed automatically by semantic-release.
