"""openpyxl adapter for metadata reads, formatting inspection, and write operations.

This adapter is the fallback for metadata that fastexcel cannot provide (formulas,
formatting, charts, comments, conditional formatting, data validation) and the
primary backend for all write operations.

Uses read_only=True where possible for memory efficiency, but falls back to normal
mode for metadata that read-only worksheets do not expose (charts, tables, merged
cells, freeze panes, conditional formatting, data validation, hyperlinks).

Use keep_vba=True when working with .xlsm files.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

from agent_xlsx.utils.constants import (
    MAX_FORMULA_CELLS,
    MAX_LOCATIONS,
    WRITABLE_EXTENSIONS,
    WRITE_SIZE_WARN_BYTES,
)
from agent_xlsx.utils.validation import file_size_bytes

# ---------------------------------------------------------------------------
# Workbook-level metadata
# ---------------------------------------------------------------------------


def get_workbook_metadata(filepath: str | Path) -> dict[str, Any]:
    """Return full structural metadata for a workbook.

    Covers: sheets, formulas, charts, VBA presence, tables, named ranges,
    merged cells count per sheet.

    Uses normal (non-read-only) mode because read-only worksheets do not
    expose charts, tables, or merged cell metadata.
    """
    filepath = Path(filepath)
    wb = load_workbook(str(filepath), data_only=False)
    try:
        sheets_info: list[dict[str, Any]] = []
        total_formulas = 0
        total_charts = 0

        for ws in wb.worksheets:
            formula_count = 0
            for row in ws.iter_rows():
                for cell in row:
                    if isinstance(cell.value, str) and cell.value.startswith("="):
                        formula_count += 1

            chart_count = len(ws._charts)
            table_names = [t.name for t in ws.tables.values()]

            total_formulas += formula_count
            total_charts += chart_count

            sheet_data: dict[str, Any] = {
                "name": ws.title,
                "dimensions": ws.dimensions or "",
                "has_formulas": formula_count > 0,
                "formula_count": formula_count,
                "has_charts": chart_count > 0,
                "chart_count": chart_count,
                "has_tables": len(table_names) > 0,
                "table_names": table_names,
            }
            sheets_info.append(sheet_data)

        defined_names = list(wb.defined_names)

        result: dict[str, Any] = {
            "sheets": sheets_info,
            "named_ranges": defined_names,
            "named_range_count": len(defined_names),
            "has_vba": wb.vba_archive is not None,
            "total_formula_count": total_formulas,
            "total_chart_count": total_charts,
        }
        return result
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Sheet-level metadata
# ---------------------------------------------------------------------------


def _extract_chart_title(chart: Any) -> str | None:
    """Extract plain text from an openpyxl chart title object."""
    if not chart.title:
        return None
    title_obj = chart.title
    # Try to get text from rich text paragraphs
    if hasattr(title_obj, "text") and title_obj.text:
        tx = title_obj.text
        if hasattr(tx, "rich") and tx.rich and hasattr(tx.rich, "paragraphs"):
            parts = []
            for para in tx.rich.paragraphs:
                for run in para.r:
                    if run.t:
                        parts.append(run.t)
            text = "".join(parts)
            if text and text != "None":
                return text
    # Fallback: body attribute
    if hasattr(title_obj, "body") and title_obj.body:
        return str(title_obj.body)
    return None


def get_sheet_metadata(filepath: str | Path, sheet_name: str) -> dict[str, Any]:
    """Return detailed metadata for a single sheet.

    Includes: formulas (sampled), merged cells, tables, charts, freeze panes.

    Uses normal mode (not read-only) to access charts, tables, merged cells,
    and freeze panes.
    """
    wb = load_workbook(str(filepath), data_only=False)
    try:
        ws = wb[sheet_name]
        formula_cells: list[dict[str, str]] = []
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and cell.value.startswith("="):
                    formula_cells.append(
                        {
                            "cell": f"{get_column_letter(cell.column)}{cell.row}",
                            "formula": cell.value,
                        }
                    )

        chart_info = []
        for chart in ws._charts:
            chart_info.append(
                {
                    "title": _extract_chart_title(chart),
                    "type": chart.__class__.__name__,
                }
            )

        table_info = []
        for t in ws.tables.values():
            table_info.append(
                {
                    "name": t.name,
                    "range": t.ref,
                    "header_row": t.headerRowCount != 0 if hasattr(t, "headerRowCount") else True,
                    "total_row": (
                        t.totalsRowCount is not None and t.totalsRowCount > 0
                        if hasattr(t, "totalsRowCount")
                        else False
                    ),
                }
            )

        merged = [str(m) for m in ws.merged_cells.ranges]

        freeze = None
        if ws.freeze_panes:
            freeze = str(ws.freeze_panes)

        result: dict[str, Any] = {
            "sheet": sheet_name,
            "dimensions": ws.dimensions or "",
            "formula_count": len(formula_cells),
            "sample_formulas": formula_cells[:MAX_FORMULA_CELLS],
            "formulas_truncated": len(formula_cells) > MAX_FORMULA_CELLS,
            "merged_regions": merged[:MAX_LOCATIONS],
            "merged_count": len(merged),
            "tables": table_info,
            "charts": chart_info,
            "freeze_panes": freeze,
        }
        return result
    finally:
        wb.close()


def get_full_sheet_inspection(filepath: str | Path, sheet_name: str) -> dict[str, Any]:
    """Return comprehensive inspection data for a single sheet in one pass.

    Combines the data from get_sheet_metadata, get_comments,
    get_conditional_formatting, get_data_validations, and get_hyperlinks
    into a single workbook open/close for efficiency.
    """
    wb = load_workbook(str(filepath), read_only=False, data_only=False)
    try:
        ws = wb[sheet_name]

        # --- Formulas ---
        formula_cells: list[dict[str, str]] = []
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and cell.value.startswith("="):
                    formula_cells.append(
                        {
                            "cell": f"{get_column_letter(cell.column)}{cell.row}",
                            "formula": cell.value,
                        }
                    )

        # --- Charts ---
        chart_info = []
        for chart in ws._charts:
            chart_info.append(
                {
                    "title": _extract_chart_title(chart),
                    "type": chart.__class__.__name__,
                }
            )

        # --- Tables ---
        table_info = []
        for t in ws.tables.values():
            table_info.append(
                {
                    "name": t.name,
                    "range": t.ref,
                    "header_row": t.headerRowCount != 0 if hasattr(t, "headerRowCount") else True,
                    "total_row": (
                        t.totalsRowCount is not None and t.totalsRowCount > 0
                        if hasattr(t, "totalsRowCount")
                        else False
                    ),
                }
            )

        # --- Merged cells ---
        merged = [str(m) for m in ws.merged_cells.ranges]

        # --- Freeze panes ---
        freeze = str(ws.freeze_panes) if ws.freeze_panes else None

        # --- Comments ---
        comment_items: list[dict[str, Any]] = []
        for row in ws.iter_rows():
            for cell in row:
                if cell.comment:
                    comment_items.append(
                        {
                            "cell": f"{get_column_letter(cell.column)}{cell.row}",
                            "author": cell.comment.author,
                            "text": cell.comment.text,
                        }
                    )

        # --- Conditional formatting ---
        cf_rules: list[dict[str, Any]] = []
        for cf in ws.conditional_formatting:
            for rule in cf.rules:
                rule_data: dict[str, Any] = {
                    "range": str(cf.sqref),
                    "type": rule.type,
                    "priority": rule.priority,
                }
                if rule.operator:
                    rule_data["operator"] = rule.operator
                if rule.formula:
                    rule_data["formula"] = list(rule.formula)
                cf_rules.append(rule_data)

        # --- Data validation ---
        dv_rules: list[dict[str, Any]] = []
        if ws.data_validations and ws.data_validations.dataValidation:
            for dv in ws.data_validations.dataValidation:
                val_data: dict[str, Any] = {
                    "range": str(dv.sqref),
                    "type": dv.type,
                    "allow_blank": dv.allow_blank,
                }
                if dv.operator:
                    val_data["operator"] = dv.operator
                if dv.formula1:
                    val_data["formula1"] = dv.formula1
                if dv.formula2:
                    val_data["formula2"] = dv.formula2
                if dv.error:
                    val_data["error_message"] = dv.error
                if dv.errorTitle:
                    val_data["error_title"] = dv.errorTitle
                if dv.prompt:
                    val_data["prompt"] = dv.prompt
                dv_rules.append(val_data)

        # --- Hyperlinks ---
        # Read from cell objects (openpyxl 3.1+ stores hyperlinks on cells, not _hyperlinks)
        link_items: list[dict[str, Any]] = []
        for row in ws.iter_rows():
            for cell in row:
                if cell.hyperlink:
                    link_items.append(
                        {
                            "cell": f"{get_column_letter(cell.column)}{cell.row}",
                            "target": cell.hyperlink.target,
                            "display": cell.hyperlink.display,
                            "tooltip": cell.hyperlink.tooltip,
                        }
                    )

        # --- Build result with capping ---
        result: dict[str, Any] = {
            "sheet": sheet_name,
            "dimensions": ws.dimensions or "",
            "formulas": {
                "count": len(formula_cells),
                "sample": formula_cells[:MAX_FORMULA_CELLS],
                "truncated": len(formula_cells) > MAX_FORMULA_CELLS,
            },
            "merged_cells": {
                "count": len(merged),
                "regions": merged[:MAX_LOCATIONS],
                "truncated": len(merged) > MAX_LOCATIONS,
            },
            "tables": table_info,
            "charts": chart_info,
            "freeze_panes": freeze,
            "comments": {
                "count": len(comment_items),
                "items": comment_items[:MAX_LOCATIONS],
                "truncated": len(comment_items) > MAX_LOCATIONS,
            },
            "conditional_formatting": {
                "count": len(cf_rules),
                "rules": cf_rules[:MAX_LOCATIONS],
                "truncated": len(cf_rules) > MAX_LOCATIONS,
            },
            "data_validation": {
                "count": len(dv_rules),
                "rules": dv_rules[:MAX_LOCATIONS],
                "truncated": len(dv_rules) > MAX_LOCATIONS,
            },
            "hyperlinks": {
                "count": len(link_items),
                "items": link_items[:MAX_LOCATIONS],
                "truncated": len(link_items) > MAX_LOCATIONS,
            },
        }
        return result
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Cell formatting
# ---------------------------------------------------------------------------


def _colour_to_hex(colour: Any) -> str | None:
    """Extract hex colour string from an openpyxl Color object."""
    if colour is None:
        return None
    if colour.type == "rgb" and colour.rgb:
        rgb = str(colour.rgb)
        # Strip leading alpha if present (AARRGGBB -> RRGGBB)
        if len(rgb) == 8:
            return rgb[2:]
        return rgb
    if colour.type == "theme":
        return f"theme:{colour.theme}"
    if colour.type == "indexed" and colour.indexed is not None:
        return f"indexed:{colour.indexed}"
    return None


def _border_side(side: Any) -> dict[str, Any] | None:
    """Convert an openpyxl Side to a dict."""
    if side is None or side.style is None:
        return None
    return {
        "style": side.style,
        "color": _colour_to_hex(side.color),
    }


def get_cell_formatting(filepath: str | Path, sheet_name: str, cell_ref: str) -> dict[str, Any]:
    """Return detailed formatting for a single cell."""
    wb = load_workbook(str(filepath), data_only=True)
    try:
        ws = wb[sheet_name]
        cell = ws[cell_ref]

        font = cell.font
        fill = cell.fill
        alignment = cell.alignment
        border = cell.border

        result: dict[str, Any] = {
            "cell": cell_ref,
            "value": cell.value,
            "font": {
                "name": font.name,
                "size": font.size,
                "bold": font.bold,
                "italic": font.italic,
                "underline": font.underline,
                "color": _colour_to_hex(font.color),
            },
            "fill": {
                "type": fill.fill_type,
                "color": _colour_to_hex(fill.fgColor) if fill.fgColor else None,
            },
            "border": {
                "top": _border_side(border.top),
                "bottom": _border_side(border.bottom),
                "left": _border_side(border.left),
                "right": _border_side(border.right),
            },
            "alignment": {
                "horizontal": alignment.horizontal,
                "vertical": alignment.vertical,
                "wrap_text": alignment.wrap_text,
                "text_rotation": alignment.text_rotation,
            },
            "number_format": cell.number_format,
        }
        return result
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Range formulas
# ---------------------------------------------------------------------------


def get_range_formulas(
    filepath: str | Path, sheet_name: str, start: str, end: str | None
) -> list[dict[str, Any]]:
    """Return formula strings for cells in a range."""
    wb = load_workbook(str(filepath), data_only=False)
    try:
        ws = wb[sheet_name]
        range_str = f"{start}:{end}" if end else start
        formula_cells: list[dict[str, Any]] = []
        for row in ws[range_str]:
            if not isinstance(row, tuple):
                row = (row,)
            for cell in row:
                val = cell.value
                formula_cells.append(
                    {
                        "cell": f"{get_column_letter(cell.column)}{cell.row}",
                        "value": val
                        if not (isinstance(val, str) and val.startswith("="))
                        else None,
                        "formula": val if isinstance(val, str) and val.startswith("=") else None,
                    }
                )
        return formula_cells
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


def get_comments(filepath: str | Path, sheet_name: str) -> list[dict[str, Any]]:
    """Return all cell comments for a sheet."""
    wb = load_workbook(str(filepath))
    try:
        ws = wb[sheet_name]
        comments: list[dict[str, Any]] = []
        for row in ws.iter_rows():
            for cell in row:
                if cell.comment:
                    comments.append(
                        {
                            "cell": f"{get_column_letter(cell.column)}{cell.row}",
                            "author": cell.comment.author,
                            "text": cell.comment.text,
                        }
                    )
        return comments
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Conditional formatting
# ---------------------------------------------------------------------------


def get_conditional_formatting(filepath: str | Path, sheet_name: str) -> list[dict[str, Any]]:
    """Return conditional formatting rules for a sheet."""
    wb = load_workbook(str(filepath))
    try:
        ws = wb[sheet_name]
        rules: list[dict[str, Any]] = []
        for cf in ws.conditional_formatting:
            for rule in cf.rules:
                rule_data: dict[str, Any] = {
                    "range": str(cf.sqref),
                    "type": rule.type,
                    "priority": rule.priority,
                }
                if rule.operator:
                    rule_data["operator"] = rule.operator
                if rule.formula:
                    rule_data["formula"] = list(rule.formula)
                rules.append(rule_data)
        return rules
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Data validations
# ---------------------------------------------------------------------------


def get_data_validations(filepath: str | Path, sheet_name: str) -> list[dict[str, Any]]:
    """Return data validation rules for a sheet."""
    wb = load_workbook(str(filepath))
    try:
        ws = wb[sheet_name]
        validations: list[dict[str, Any]] = []
        if ws.data_validations and ws.data_validations.dataValidation:
            for dv in ws.data_validations.dataValidation:
                val_data: dict[str, Any] = {
                    "range": str(dv.sqref),
                    "type": dv.type,
                    "allow_blank": dv.allow_blank,
                }
                if dv.operator:
                    val_data["operator"] = dv.operator
                if dv.formula1:
                    val_data["formula1"] = dv.formula1
                if dv.formula2:
                    val_data["formula2"] = dv.formula2
                if dv.error:
                    val_data["error_message"] = dv.error
                if dv.errorTitle:
                    val_data["error_title"] = dv.errorTitle
                if dv.prompt:
                    val_data["prompt"] = dv.prompt
                validations.append(val_data)
        return validations
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Hyperlinks
# ---------------------------------------------------------------------------


def get_hyperlinks(filepath: str | Path, sheet_name: str) -> list[dict[str, Any]]:
    """Return all hyperlinks for a sheet."""
    wb = load_workbook(str(filepath))
    try:
        ws = wb[sheet_name]
        # Read from cell objects (openpyxl 3.1+ stores hyperlinks on cells, not _hyperlinks)
        links: list[dict[str, Any]] = []
        for row in ws.iter_rows():
            for cell in row:
                if cell.hyperlink:
                    links.append(
                        {
                            "cell": f"{get_column_letter(cell.column)}{cell.row}",
                            "target": cell.hyperlink.target,
                            "display": cell.hyperlink.display,
                            "tooltip": cell.hyperlink.tooltip,
                        }
                    )
        return links
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Write operations
# ---------------------------------------------------------------------------


def _create_blank_workbook(filepath: Path, sheet_name: str | None = None) -> None:
    """Create a new blank workbook. Renames the default sheet if sheet_name provided."""
    from openpyxl import Workbook

    filepath.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    if sheet_name:
        wb.active.title = sheet_name
    wb.save(str(filepath))
    wb.close()


def write_cells(
    filepath: str | Path,
    sheet_name: str | None,
    data: list[dict[str, Any]],
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """Write values or formulas to cells.

    Each item in `data` should have: cell (str), value (any), and optionally
    number_format (str).

    Auto-creates a new workbook when the target file doesn't exist.
    Preserves existing workbook content. For .xlsm files, VBA is preserved.
    """
    from agent_xlsx.utils.errors import AgentExcelError

    filepath = Path(filepath)
    created = False
    warning = None

    # Auto-create: if file doesn't exist, bootstrap a blank workbook
    if not filepath.exists():
        if output_path:
            # --output with non-existent source: create the output file directly
            target = Path(output_path)
            if target.suffix.lower() not in WRITABLE_EXTENSIONS:
                target = target.with_suffix(".xlsx")
            _create_blank_workbook(target, sheet_name=sheet_name)
            filepath = target
            output_path = None  # Already writing to output, no save-as needed
        else:
            _create_blank_workbook(filepath, sheet_name=sheet_name)
        created = True

    # Size guard: large files can hang or OOM when loaded for write
    if not created:
        size = file_size_bytes(filepath)
        size_mb = size / (1024 * 1024)
        if size > WRITE_SIZE_WARN_BYTES:
            if output_path:
                raise AgentExcelError(
                    "FILE_TOO_LARGE",
                    f"Source file is {size_mb:.0f}MB — too large to copy via --output",
                    [
                        "Create a new file directly instead of copying from a large source:",
                        f"  agent-xlsx write {output_path} A1 --json '<data>'",
                        "Or extract needed data with 'read' first, then write to a new file",
                    ],
                )
            else:
                warning = f"File is {size_mb:.0f}MB — write may be slow"

    keep_vba = filepath.suffix.lower() == ".xlsm"
    wb = load_workbook(str(filepath), keep_vba=keep_vba)
    try:
        ws = wb[sheet_name] if sheet_name else wb.active

        cells_written = 0
        for item in data:
            cell_ref = item["cell"]
            value = item["value"]
            cell = ws[cell_ref]
            cell.value = value
            if "number_format" in item and item["number_format"]:
                cell.number_format = item["number_format"]
            cells_written += 1

        save_path = Path(output_path) if output_path else filepath
        if save_path.suffix.lower() not in WRITABLE_EXTENSIONS:
            save_path = save_path.with_suffix(".xlsx")
        wb.save(str(save_path))

        result: dict[str, Any] = {
            "status": "success",
            "cells_written": cells_written,
            "output_file": str(save_path),
        }
        if created:
            result["created"] = True
        if warning:
            result["warning"] = warning
        return result
    finally:
        wb.close()


# ---------------------------------------------------------------------------
# Apply formatting
# ---------------------------------------------------------------------------


def apply_formatting(
    filepath: str | Path,
    sheet_name: str | None,
    cell_ref: str,
    font_opts: dict[str, Any] | None = None,
    fill_opts: dict[str, Any] | None = None,
    border_opts: dict[str, Any] | None = None,
    number_format: str | None = None,
    alignment_opts: dict[str, Any] | None = None,
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """Apply formatting to a cell or range.

    Accepts optional font, fill, border, alignment dicts and number_format string.
    """
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    filepath = Path(filepath)
    keep_vba = filepath.suffix.lower() == ".xlsm"
    wb = load_workbook(str(filepath), keep_vba=keep_vba)
    try:
        ws = wb[sheet_name] if sheet_name else wb.active

        # Determine if range or single cell
        cells = _resolve_cells(ws, cell_ref)

        for cell in cells:
            if font_opts:
                # Preserve existing colour object unless a new hex colour is provided
                font_colour = cell.font.color
                if "color" in font_opts:
                    font_colour = font_opts["color"]
                cell.font = Font(
                    name=font_opts.get("name", cell.font.name),
                    size=font_opts.get("size", cell.font.size),
                    bold=font_opts.get("bold", cell.font.bold),
                    italic=font_opts.get("italic", cell.font.italic),
                    underline=font_opts.get("underline", cell.font.underline),
                    color=font_colour,
                )

            if fill_opts:
                cell.fill = PatternFill(
                    fill_type=fill_opts.get("type", "solid"),
                    fgColor=fill_opts.get("color", "FFFFFF"),
                )

            if border_opts:
                style = border_opts.get("style", "thin")
                colour = border_opts.get("color", "000000")
                side = Side(style=style, color=colour)
                cell.border = Border(
                    top=side if border_opts.get("top", True) else cell.border.top,
                    bottom=side if border_opts.get("bottom", True) else cell.border.bottom,
                    left=side if border_opts.get("left", True) else cell.border.left,
                    right=side if border_opts.get("right", True) else cell.border.right,
                )

            if number_format:
                cell.number_format = number_format

            if alignment_opts:
                cell.alignment = Alignment(
                    horizontal=alignment_opts.get("horizontal", cell.alignment.horizontal),
                    vertical=alignment_opts.get("vertical", cell.alignment.vertical),
                    wrap_text=alignment_opts.get("wrap_text", cell.alignment.wrap_text),
                    text_rotation=alignment_opts.get("text_rotation", cell.alignment.text_rotation),
                )

        save_path = Path(output_path) if output_path else filepath
        if save_path.suffix.lower() not in WRITABLE_EXTENSIONS:
            save_path = save_path.with_suffix(".xlsx")
        wb.save(str(save_path))

        return {
            "status": "success",
            "cells_formatted": len(cells),
            "output_file": str(save_path),
        }
    finally:
        wb.close()


def batch_format(
    filepath: str | Path,
    sheet_name: str | None,
    spec: list[dict[str, Any]],
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """Apply multiple different formatting groups in a single file open/save.

    Each entry in *spec* has ``range`` (required) plus flat styling keys:
    bold, italic, font_size, font_color, font_name, fill_color, fill_type,
    border_style, border_color, number_format, horizontal, vertical,
    wrap_text, text_rotation.
    """
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    filepath = Path(filepath)
    keep_vba = filepath.suffix.lower() == ".xlsm"
    wb = load_workbook(str(filepath), keep_vba=keep_vba)
    try:
        ws = wb[sheet_name] if sheet_name else wb.active
        total_cells = 0

        for entry in spec:
            cell_ref = entry.get("range")
            if not cell_ref:
                continue
            # Support comma-separated ranges in a single batch entry
            # (e.g. "A5:L5,A11:L11" applies the same style to both ranges)
            if "," in cell_ref:
                from agent_xlsx.utils.validation import parse_multi_range

                cells = []
                for parsed in parse_multi_range(cell_ref):
                    r = (
                        f"{parsed['start']}:{parsed['end']}"
                        if parsed.get("end")
                        else parsed["start"]
                    )
                    cells.extend(_resolve_cells(ws, r))
            else:
                cells = _resolve_cells(ws, cell_ref)

            # Build style objects from flat keys
            font_kwargs: dict[str, Any] = {}
            if "bold" in entry:
                font_kwargs["bold"] = entry["bold"]
            if "italic" in entry:
                font_kwargs["italic"] = entry["italic"]
            if "font_size" in entry:
                font_kwargs["size"] = entry["font_size"]
            if "font_color" in entry:
                font_kwargs["color"] = entry["font_color"]
            if "font_name" in entry:
                font_kwargs["name"] = entry["font_name"]

            fill_color = entry.get("fill_color")
            number_fmt = entry.get("number_format")
            border_style = entry.get("border_style")
            border_color = entry.get("border_color", "000000")

            align_kwargs: dict[str, Any] = {}
            if "horizontal" in entry:
                align_kwargs["horizontal"] = entry["horizontal"]
            if "vertical" in entry:
                align_kwargs["vertical"] = entry["vertical"]
            if "wrap_text" in entry:
                align_kwargs["wrap_text"] = entry["wrap_text"]
            if "text_rotation" in entry:
                align_kwargs["text_rotation"] = entry["text_rotation"]

            for cell in cells:
                if font_kwargs:
                    cell.font = Font(
                        name=font_kwargs.get("name", cell.font.name),
                        size=font_kwargs.get("size", cell.font.size),
                        bold=font_kwargs.get("bold", cell.font.bold),
                        italic=font_kwargs.get("italic", cell.font.italic),
                        color=font_kwargs.get("color", cell.font.color),
                    )
                if fill_color:
                    cell.fill = PatternFill(
                        fill_type=entry.get("fill_type", "solid"),
                        fgColor=fill_color,
                    )
                if border_style:
                    side = Side(style=border_style, color=border_color)
                    cell.border = Border(top=side, bottom=side, left=side, right=side)
                if number_fmt:
                    cell.number_format = number_fmt
                if align_kwargs:
                    cell.alignment = Alignment(
                        horizontal=align_kwargs.get("horizontal", cell.alignment.horizontal),
                        vertical=align_kwargs.get("vertical", cell.alignment.vertical),
                        wrap_text=align_kwargs.get("wrap_text", cell.alignment.wrap_text),
                        text_rotation=align_kwargs.get(
                            "text_rotation", cell.alignment.text_rotation
                        ),
                    )

            total_cells += len(cells)

        save_path = Path(output_path) if output_path else filepath
        if save_path.suffix.lower() not in WRITABLE_EXTENSIONS:
            save_path = save_path.with_suffix(".xlsx")
        wb.save(str(save_path))

        return {
            "status": "success",
            "groups_applied": len(spec),
            "total_cells_formatted": total_cells,
            "output_file": str(save_path),
        }
    finally:
        wb.close()


def copy_formatting(
    filepath: str | Path,
    sheet_name: str | None,
    source_ref: str,
    target_ref: str,
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """Copy formatting from a source cell to a target cell or range."""
    from copy import copy

    filepath = Path(filepath)
    keep_vba = filepath.suffix.lower() == ".xlsm"
    wb = load_workbook(str(filepath), keep_vba=keep_vba)
    try:
        ws = wb[sheet_name] if sheet_name else wb.active
        source = ws[source_ref]

        targets = _resolve_cells(ws, target_ref)
        for cell in targets:
            cell.font = copy(source.font)
            cell.fill = copy(source.fill)
            cell.border = copy(source.border)
            cell.alignment = copy(source.alignment)
            cell.number_format = source.number_format

        save_path = Path(output_path) if output_path else filepath
        if save_path.suffix.lower() not in WRITABLE_EXTENSIONS:
            save_path = save_path.with_suffix(".xlsx")
        wb.save(str(save_path))

        return {
            "status": "success",
            "cells_formatted": len(targets),
            "source": source_ref,
            "output_file": str(save_path),
        }
    finally:
        wb.close()


def _resolve_cells(ws: Any, cell_ref: str) -> list[Any]:
    """Resolve a cell reference (single or range) to a flat list of cell objects."""
    if ":" in cell_ref:
        cells = []
        for row in ws[cell_ref]:
            if isinstance(row, tuple):
                cells.extend(row)
            else:
                cells.append(row)
        return cells
    return [ws[cell_ref]]


# ---------------------------------------------------------------------------
# Sheet management
# ---------------------------------------------------------------------------


def manage_sheet(
    filepath: str | Path,
    action: str,
    sheet_name: str,
    new_name: str | None = None,
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    """Create, delete, rename, copy, hide, or unhide a sheet.

    Actions: create, delete, rename, copy, hide, unhide
    """
    filepath = Path(filepath)
    keep_vba = filepath.suffix.lower() == ".xlsm"
    wb = load_workbook(str(filepath), keep_vba=keep_vba)
    try:
        result: dict[str, Any] = {"status": "success", "action": action}

        if action == "create":
            wb.create_sheet(title=sheet_name)
            result["sheet"] = sheet_name

        elif action == "delete":
            if sheet_name not in wb.sheetnames:
                from agent_xlsx.utils.errors import SheetNotFoundError

                raise SheetNotFoundError(sheet_name, wb.sheetnames)
            del wb[sheet_name]
            result["sheet"] = sheet_name

        elif action == "rename":
            if sheet_name not in wb.sheetnames:
                from agent_xlsx.utils.errors import SheetNotFoundError

                raise SheetNotFoundError(sheet_name, wb.sheetnames)
            ws = wb[sheet_name]
            ws.title = new_name or sheet_name
            result["old_name"] = sheet_name
            result["new_name"] = ws.title

        elif action == "copy":
            if sheet_name not in wb.sheetnames:
                from agent_xlsx.utils.errors import SheetNotFoundError

                raise SheetNotFoundError(sheet_name, wb.sheetnames)
            source = wb[sheet_name]
            copied = wb.copy_worksheet(source)
            if new_name:
                copied.title = new_name
            result["source"] = sheet_name
            result["copy"] = copied.title

        elif action == "hide":
            if sheet_name not in wb.sheetnames:
                from agent_xlsx.utils.errors import SheetNotFoundError

                raise SheetNotFoundError(sheet_name, wb.sheetnames)
            wb[sheet_name].sheet_state = "hidden"
            result["sheet"] = sheet_name

        elif action == "unhide":
            if sheet_name not in wb.sheetnames:
                from agent_xlsx.utils.errors import SheetNotFoundError

                raise SheetNotFoundError(sheet_name, wb.sheetnames)
            wb[sheet_name].sheet_state = "visible"
            result["sheet"] = sheet_name

        elif action == "list":
            sheets = []
            for ws in wb.worksheets:
                sheets.append(
                    {
                        "name": ws.title,
                        "state": ws.sheet_state,
                        "dimensions": ws.dimensions or "",
                    }
                )
            result["sheets"] = sheets
            result["count"] = len(sheets)
            # No save needed for list
            return result

        else:
            from agent_xlsx.utils.errors import AgentExcelError

            raise AgentExcelError(
                "INVALID_ACTION",
                f"Unknown sheet action: '{action}'",
                ["Valid actions: create, delete, rename, copy, hide, unhide, list"],
            )

        save_path = Path(output_path) if output_path else filepath
        if save_path.suffix.lower() not in WRITABLE_EXTENSIONS:
            save_path = save_path.with_suffix(".xlsx")
        wb.save(str(save_path))
        result["output_file"] = str(save_path)
        return result
    finally:
        wb.close()
