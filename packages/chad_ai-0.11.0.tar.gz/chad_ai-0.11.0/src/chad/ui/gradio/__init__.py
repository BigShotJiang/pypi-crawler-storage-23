"""Gradio web UI for Chad."""

from chad.ui.gradio.gradio_ui import launch_web_ui

__all__ = ["launch_web_ui"]
