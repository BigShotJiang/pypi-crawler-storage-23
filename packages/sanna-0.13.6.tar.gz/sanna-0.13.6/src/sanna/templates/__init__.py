"""Sanna constitution templates — pre-built starting points for common use cases."""
