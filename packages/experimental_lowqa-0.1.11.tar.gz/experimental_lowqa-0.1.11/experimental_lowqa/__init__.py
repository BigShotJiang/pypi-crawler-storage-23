# =====================================
# generator=datazen
# version=3.2.3
# hash=adb4841725eb26df47263957d36f0344
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "Read the sign."
PKG_NAME = "experimental-lowqa"
VERSION = "0.1.11"
