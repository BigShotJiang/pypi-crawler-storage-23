"""SQLAlchemy DeclarativeBase for all AuthFort models."""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass
