"""Version resolution for aiauto-client package.

Single source of truth for the package version, resolved from
pyproject.toml via importlib.metadata at import time.

Separated into its own module to avoid circular imports:
__init__.py -> core.py -> http_client.py
"""

import re
from importlib.metadata import PackageNotFoundError, version

# Semver format: X.Y.Z only (PEP 440 suffixes like rc1, .post1, .dev1 are not valid semver)
_SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")


def get_version() -> str:
    """Get package version from installed metadata.

    Returns semver-compatible version string (X.Y.Z).
    Falls back to "0.0.0" if package is not installed
    or version format is not semver-compatible.
    """
    try:
        v = version("aiauto-client")
    except PackageNotFoundError:
        return "0.0.0"

    if not _SEMVER_RE.match(v):
        return "0.0.0"

    return v


__version__ = get_version()

# Alias for http_client.py (ruff N812: avoid renaming lowercase to uppercase at import)
CLIENT_VERSION = __version__
