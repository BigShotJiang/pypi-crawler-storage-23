# seedream6-ai

Seedream 6.0 AI image generator for creators.

## Official Website

🌐 Visit: [https://seedream6.net](https://seedream6.net)

## Installation

```bash
pip install seedream6-ai
```

## Usage

```python
from seedream6_ai import get_info
print(get_info())
```

## Links

- Website: [https://seedream6.net](https://seedream6.net)
