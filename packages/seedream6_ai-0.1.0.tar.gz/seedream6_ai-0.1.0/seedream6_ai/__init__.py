"""Seedream 6.0 AI image generator. Visit https://seedream6.net"""

__version__ = "0.1.0"
WEBSITE = "https://seedream6.net"


def get_info():
    return {
        "name": "Seedream 6.0",
        "version": __version__,
        "website": WEBSITE,
        "description": "Seedream 6.0 AI image generator"
    }


def get_platform_url():
    return WEBSITE
