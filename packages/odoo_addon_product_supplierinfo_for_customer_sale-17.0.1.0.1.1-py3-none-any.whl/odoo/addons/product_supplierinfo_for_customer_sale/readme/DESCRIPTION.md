Based on product_supplierinfo_for_customer, this module loads in every
sale order the customer code defined in the product and allows use the
product codes and product name configured in each products in sale
orders.

If you use Advanced price rules with formulas to define your pricing,
and choose that the price should be calculated from the partner prices
in the product form, the quantity in the sales order will be proposed
from the minimum quantity defined in the customerinfo.
