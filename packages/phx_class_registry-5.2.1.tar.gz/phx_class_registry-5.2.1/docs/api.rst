API Documentation
=================

.. automodule:: class_registry.base
.. automodule:: class_registry.cache
.. automodule:: class_registry.entry_points
.. automodule:: class_registry.patcher
.. automodule:: class_registry.registry
