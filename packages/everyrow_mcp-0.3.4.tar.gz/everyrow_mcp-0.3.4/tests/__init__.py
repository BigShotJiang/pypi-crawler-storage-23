"""Tests for everyrow MCP server."""
