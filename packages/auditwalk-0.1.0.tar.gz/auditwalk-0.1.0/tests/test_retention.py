"""Retention scaffolding tests (names only)."""


def test_prune_runs_by_count():
    """Ensure retention drops runs beyond the max count."""
    pass


def test_prune_runs_by_age():
    """Ensure runs older than the age threshold are pruned."""
    pass


def test_compares_removed_when_run_missing():
    """Ensure compares referencing missing runs are deleted."""
    pass


def test_index_resync_after_retention():
    """Ensure index.json is rebuilt after retention changes."""
    pass


def test_dry_run_makes_no_changes():
    """Ensure dry-run mode produces reports without mutations."""
    pass
