from __future__ import annotations

from PySide6 import QtWidgets

from auditwalk.gui.main_window import MainWindow


def test_mainwindow_observer_link_refresh_and_copy(monkeypatch) -> None:
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])

    class _FakeObserverServer:
        def pairing_urls(self) -> dict[str, str]:
            return {
                "observer_url": "http://127.0.0.1:4582/observer?token=test-token",
                "status_url": "http://127.0.0.1:4582/observer/status?token=test-token",
                "expires_at": "2026-03-02T11:00:00",
            }

        def stop(self) -> None:
            return

    win = MainWindow()
    try:
        win._observer_server = _FakeObserverServer()  # type: ignore[assignment]
        win._refresh_observer_link()
        assert "observer?token=test-token" in win._observer_url.text()

        copied: dict[str, str] = {"text": ""}

        class _FakeClipboard:
            def setText(self, text: str) -> None:
                copied["text"] = text

        monkeypatch.setattr(QtWidgets.QApplication, "clipboard", lambda: _FakeClipboard())
        win._copy_observer_link()
        assert copied["text"] == win._observer_url.text()
    finally:
        win.close()
        app.processEvents()
