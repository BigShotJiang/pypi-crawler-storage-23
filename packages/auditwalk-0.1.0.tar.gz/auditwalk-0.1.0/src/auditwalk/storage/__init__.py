"""storage package (scaffold)."""
