"""Module entrypoint: python -m auditwalk"""

from __future__ import annotations

from auditwalk.cli.main import main

if __name__ == "__main__":
    raise SystemExit(main())
