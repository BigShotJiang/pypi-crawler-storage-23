"""worker package (scaffold)."""
