"""Risk scoring and policy-decision helpers."""

from __future__ import annotations


def score_from_signals(signals: list[dict], thresholds: dict[str, int]) -> tuple[int, str]:
    """Return (score, level) from weighted signals and threshold policy."""
    score = max(0, min(100, int(sum(int(s.get("weight", 0)) for s in signals))))
    if score >= thresholds["high_min"]:
        return score, "high"
    if score >= thresholds["medium_min"]:
        return score, "medium"
    return score, "low"


def policy_decision(level: str, on_high: str, on_medium: str, allow_override: bool) -> dict:
    """Map risk level + policy settings to a user-facing action contract."""
    if level == "high":
        action = "block" if on_high == "block" else "warn"
        return {
            "action": action,
            "requires_user_ack": True,
            "override_allowed": bool(allow_override and action == "block"),
            "override_token_ttl_sec": 300 if allow_override and action == "block" else 0,
        }
    if level == "medium":
        action = "warn" if on_medium == "warn" else "allow"
        return {
            "action": action,
            "requires_user_ack": action == "warn",
            "override_allowed": False,
            "override_token_ttl_sec": 0,
        }
    return {
        "action": "allow",
        "requires_user_ack": False,
        "override_allowed": False,
        "override_token_ttl_sec": 0,
    }
