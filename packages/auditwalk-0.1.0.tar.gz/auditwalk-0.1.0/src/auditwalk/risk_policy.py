"""Compatibility shim. Prefer: auditwalk.risk.risk_policy"""

from .risk.risk_policy import *  # noqa: F401,F403
