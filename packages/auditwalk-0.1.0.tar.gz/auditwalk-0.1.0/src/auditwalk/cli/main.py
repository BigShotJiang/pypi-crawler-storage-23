from __future__ import annotations

import sys
from typing import List, Optional

from auditwalk.cli.adapters.argparse_app import build_argparse_app
from auditwalk.cli.dispatch import build_invocation_from_namespace, dispatch
from auditwalk.cli.registry import build_registry


def main(argv: Optional[List[str]] = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    registry = build_registry()
    parser = build_argparse_app(registry)

    # Default to kitchen-sink profile for no-arg invocation.
    if len(argv) == 0:
        argv = ["scan", "full"]

    ns = parser.parse_args(argv)
    parsed = vars(ns)
    noun = parsed.pop("_aw_noun", "")
    verb = parsed.pop("_aw_verb", "")
    parsed.pop("_aw_handler", None)
    parsed.pop("_aw_is_root", None)

    invocation = build_invocation_from_namespace(registry, noun, verb, parsed)
    return dispatch(registry, invocation)


if __name__ == "__main__":
    raise SystemExit(main())
