"""CLI adapter implementations."""
