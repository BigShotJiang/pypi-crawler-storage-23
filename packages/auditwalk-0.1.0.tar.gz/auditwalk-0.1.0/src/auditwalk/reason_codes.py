"""Compatibility shim. Prefer: auditwalk.risk.reason_codes"""

from .risk.reason_codes import *  # noqa: F401,F403
