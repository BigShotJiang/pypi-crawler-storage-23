"""AuditWalk desktop GUI package (PySide6)."""
