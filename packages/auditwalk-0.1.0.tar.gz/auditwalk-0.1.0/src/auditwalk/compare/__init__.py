"""compare package (scaffold)."""
