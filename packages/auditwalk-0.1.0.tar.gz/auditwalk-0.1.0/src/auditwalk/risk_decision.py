"""Compatibility shim. Prefer: auditwalk.risk.risk_decision"""

from .risk.risk_decision import *  # noqa: F401,F403
