"""Environment-level detector helpers.

Signals generated here reflect setup/health state, not file-content behavior.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Callable

from ..reason_codes import ENV_BASELINE_MISSING, ENV_THREAT_DB_STALE


def add_environment_signals(
    *,
    baseline: dict[str, dict],
    baseline_path: Path,
    threat_db_path: Path,
    feed_generated_at: float,
    add_signal: Callable[[str, float, dict], None],
) -> None:
    """Emit baseline/threatdb freshness signals."""
    if not baseline:
        add_signal(
            ENV_BASELINE_MISSING,
            1.0,
            {"path": str(baseline_path), "detail": "Baseline file missing or empty"},
        )

    if feed_generated_at <= 0 or (time.time() - feed_generated_at) > (72 * 3600):
        add_signal(
            ENV_THREAT_DB_STALE,
            0.9,
            {
                "path": str(threat_db_path),
                "detail": "Threat intelligence metadata missing or stale",
                "last_update_epoch": feed_generated_at,
            },
        )
