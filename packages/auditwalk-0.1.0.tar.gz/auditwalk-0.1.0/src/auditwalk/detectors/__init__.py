"""Detector feature package for transfer assessment."""

from .environment import add_environment_signals
from .filesystem import FilesystemDetectorResult, run_filesystem_detectors

__all__ = [
    "add_environment_signals",
    "FilesystemDetectorResult",
    "run_filesystem_detectors",
]
