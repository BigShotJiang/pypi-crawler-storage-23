"""scan package (scaffold)."""
