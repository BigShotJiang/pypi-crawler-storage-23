"""Run artifact storage layer."""
