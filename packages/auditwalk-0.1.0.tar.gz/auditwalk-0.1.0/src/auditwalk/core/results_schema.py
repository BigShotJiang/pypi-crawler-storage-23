from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Dict


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class PreflightResult:
    kind: str
    version: str
    run_id: str
    created_at: str
    host: Dict[str, Any]
    signals: Dict[str, Any]
    prls: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def prls_from_signals(signals: Dict[str, Any]) -> Dict[str, Any]:
    issues = []
    if signals.get("is_admin") is False:
        issues.append("not_running_as_admin")
    if signals.get("boot_time_epoch") is None:
        issues.append("boot_time_unknown")

    status = "CLEAR" if not issues else "REVIEW"
    return {
        "status": status,
        "issues": issues,
        "score": 0 if not issues else 25,
    }
