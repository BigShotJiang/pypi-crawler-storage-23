from __future__ import annotations


class AuditWalkError(Exception):
    """Base exception for AuditWalk."""


class RunStoreError(AuditWalkError):
    """Raised for run-store read/write/index failures."""


class RunNotFound(RunStoreError):
    """Raised when a requested run directory cannot be resolved."""
