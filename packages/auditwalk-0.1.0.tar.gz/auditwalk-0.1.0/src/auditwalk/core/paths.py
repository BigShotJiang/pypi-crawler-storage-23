from __future__ import annotations

import os
import sys
from pathlib import Path


def default_data_dir(app_name: str) -> Path:
    """
    OS-appropriate per-user data directory.

    - Linux:  ~/.local/share/<app_name> (or $XDG_DATA_HOME)
    - macOS:  ~/Library/Application Support/<app_name>
    - Windows: %APPDATA%\\<app_name>
    """
    home = Path.home()

    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
        return (base / app_name).resolve()

    if sys.platform == "darwin":
        return (home / "Library" / "Application Support" / app_name).resolve()

    # Linux / other POSIX
    xdg = os.environ.get("XDG_DATA_HOME")
    if xdg:
        return (Path(xdg) / app_name).resolve()
    return (home / ".local" / "share" / app_name).resolve()
