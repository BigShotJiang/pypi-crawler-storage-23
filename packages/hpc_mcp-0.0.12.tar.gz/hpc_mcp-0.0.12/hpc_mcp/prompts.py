def format_rules(rules):
    return "\n".join([f"- {r}" for r in rules])
