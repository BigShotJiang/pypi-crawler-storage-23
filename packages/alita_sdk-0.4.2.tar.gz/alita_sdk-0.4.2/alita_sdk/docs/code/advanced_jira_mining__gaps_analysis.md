# advanced_jira_mining - gaps_analysis

**Toolkit**: `advanced_jira_mining`
**Method**: `gaps_analysis`
**Source File**: `data_mining_wrapper.py`
**Class**: `AdvancedJiraMiningWrapper`

---

## Method Implementation

```python
    def gaps_analysis(self, jira_issue_key: str, query: str) -> str:
        """
        Perform a gaps analysis using the JIRA issue key already provided by the user and the given query.
        The query is typically an acceptance criterion (AC) from the same ticket.
        If a gaps analysis prompt is provided, it will be used to generate the analysis.
        """
        _, vectorstore = self.__prepare_vectorstore(jira_issue_key, obtain_vectorstore=True)
        retriever = vectorstore.as_retriever(search_type="mmr", search_kwargs={'k': 25, 'fetch_k': 50})
        if self.gaps_analysis_prompt:
            # Create the LLM chain with the provided in settings gaps_analysis_prompt
            chain = (
                    RunnableParallel({
                        'context': retriever | RunnableLambda(self.__build_search_results),
                        'question': RunnablePassthrough()
                    })
                    | RunnableLambda(self.__build_prompt)
                    | self._llm
                    | StrOutputParser()
            )
            return chain.invoke(query)
        else:
            return "No gap analysis prompt has been provided. Please provide the gap analysis prompt in toolkit configuration. You should provide it under gaps_analysis_prompt value as a string."
```
