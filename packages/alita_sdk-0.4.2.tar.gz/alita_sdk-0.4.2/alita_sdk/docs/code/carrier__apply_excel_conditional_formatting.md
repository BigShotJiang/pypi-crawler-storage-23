# carrier - apply_excel_conditional_formatting

**Toolkit**: `carrier`
**Method**: `apply_excel_conditional_formatting`
**Source File**: `lighthouse_excel_reporter.py`

---

## Method Implementation

```python
def apply_excel_conditional_formatting(ws, column_letter, thresholds, colors):
    ws.conditional_formatting.add(f'{column_letter}2:{column_letter}{ws.max_row}',
                                  CellIsRule(operator='lessThanOrEqual', formula=[str(thresholds[0])], stopIfTrue=True, fill=PatternFill(start_color=colors[0], end_color=colors[0], fill_type="solid")))
    ws.conditional_formatting.add(f'{column_letter}2:{column_letter}{ws.max_row}',
                                  CellIsRule(operator='between', formula=[str(thresholds[0]+0.0001), str(thresholds[1])], stopIfTrue=True, fill=PatternFill(start_color=colors[1], end_color=colors[1], fill_type="solid")))
    ws.conditional_formatting.add(f'{column_letter}2:{column_letter}{ws.max_row}',
                                  CellIsRule(operator='greaterThanOrEqual', formula=[str(thresholds[1]+0.0001)], stopIfTrue=True, fill=PatternFill(start_color=colors[2], end_color=colors[2], fill_type="solid")))
```
