# elastic - get_tools

**Toolkit**: `elastic`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `ElasticToolkit`

---

## Method Implementation

```python
    def get_tools(self) -> list[BaseTool]:
        return self.tools
```
