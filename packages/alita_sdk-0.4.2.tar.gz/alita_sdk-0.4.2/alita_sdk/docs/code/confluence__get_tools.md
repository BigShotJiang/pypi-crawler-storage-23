# confluence - get_tools

**Toolkit**: `confluence`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `ConfluenceToolkit`

---

## Method Implementation

```python
    def get_tools(self):
        return self.tools
```
