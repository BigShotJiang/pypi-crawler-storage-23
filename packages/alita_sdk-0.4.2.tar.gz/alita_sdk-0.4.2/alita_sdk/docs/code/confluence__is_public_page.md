# confluence - is_public_page

**Toolkit**: `confluence`
**Method**: `is_public_page`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def is_public_page(self, page: dict) -> bool:
        """Check if a page is publicly accessible."""
        restrictions = self.client.get_all_restrictions_for_content(page["id"])

        return (
                (page["status"] == "current"
                # allow user to see archived content if needed
                 or page["status"] == "archived")
                and not restrictions["read"]["restrictions"]["user"]["results"]
                and not restrictions["read"]["restrictions"]["group"]["results"]
        )
```
