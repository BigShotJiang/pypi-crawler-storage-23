# ado_test_plan - check_connection

**Toolkit**: `ado_test_plan`
**Method**: `check_connection`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsPlansToolkit`

---

## Method Implementation

```python
        def check_connection(self):
            ado_config = self.ado_test_plan_configuration.ado_configuration if self.ado_test_plan_configuration else None
            if not ado_config:
                raise ValueError("ADO test plan configuration is required")
            response = requests.get(
                f'{ado_config.organization_url}/{ado_config.project}/_apis/testplan/plans?api-version=7.0',
                headers = {'Authorization': f'Bearer {ado_config.token}'},
                timeout=5
            )
            return response
```
