# figma - infer_journey_category

**Toolkit**: `figma`
**Method**: `infer_journey_category`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def infer_journey_category(frame_name: str, buttons: List[str]) -> Optional[str]:
    """
    Infer which user journey a frame belongs to.
    """
    name_lower = frame_name.lower()
    buttons_lower = [b.lower() for b in buttons]
    all_text = name_lower + ' ' + ' '.join(buttons_lower)

    for category, keywords in JOURNEY_CATEGORIES.items():
        if any(kw in all_text for kw in keywords):
            return category
    return None
```
