# azure_ai - get_tools

**Toolkit**: `azure_ai`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `AzureSearchToolkit`

---

## Method Implementation

```python
    def get_tools(self):
        return self.tools
```
