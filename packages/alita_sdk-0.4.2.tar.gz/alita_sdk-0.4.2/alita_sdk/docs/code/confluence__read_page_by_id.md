# confluence - read_page_by_id

**Toolkit**: `confluence`
**Method**: `read_page_by_id`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def read_page_by_id(self, page_id: str, skip_images: bool = False):
        """Reads a page by its id in the Confluence space. If id is not available, but there is a title - use get_page_id first."""
        result = list(self.get_pages_by_id([page_id], skip_images))
        if not result:
            return f"Pages not found. Errors: {self._errors}" if self._errors \
                else "Pages not found or you do not have access to them."
        return result[0].page_content
```

## Helper Methods

```python
Helper: get_pages_by_id
    def get_pages_by_id(self, page_ids: List[str], skip_images: bool = False):
        """ Gets pages by id in the Confluence space."""
        for page_id in page_ids:
            get_page = retry(
                reraise=True,
                stop=stop_after_attempt(
                    self.number_of_retries  # type: ignore[arg-type]
                ),
                wait=wait_exponential(
                    multiplier=1,  # type: ignore[arg-type]
                    min=self.min_retry_seconds,  # type: ignore[arg-type]
                    max=self.max_retry_seconds,  # type: ignore[arg-type]
                ),
                before_sleep=before_sleep_log(logger, logging.WARNING),
            )(self.client.get_page_by_id)
            try:
                page = get_page(
                    page_id=page_id, expand=f"{self.content_format.value},version"
                )
            except (ApiError, HTTPError) as e:
                logger.error(f"Error fetching page with ID {page_id}: {e}")
                page_content_temp = f"Confluence API Error: cannot fetch the page with ID {page_id}: {e}"
                # store errors
                if self._errors is None:
                    self._errors = []
                self._errors.append(page_content_temp)
                return Document(page_content=page_content_temp,
                                metadata={})
            # TODO: update on toolkit advanced settings level as a separate feature
            # if not self.include_restricted_content and not self.is_public_page(page):
            #     continue
            yield self.process_page(page, skip_images)
```
