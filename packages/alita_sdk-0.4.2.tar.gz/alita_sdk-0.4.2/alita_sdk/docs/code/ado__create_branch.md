# ado - create_branch

**Toolkit**: `ado`
**Method**: `create_branch`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def create_branch(self, branch_name: str) -> str:
        """
        Create a new branch in Azure DevOps, and set it as the active bot branch.
        Equivalent to `git switch -c branch_name`.

        Parameters:
            branch_name (str): The name of the branch to be created.

        Returns:
            str: A plaintext success message or raises an exception if the branch already exists.
        """
        self.active_branch = (
            self.active_branch if self.active_branch else self.base_branch
        )
        new_branch_name = branch_name
        if bool(re.search(r"\s", new_branch_name)):
            return (
                f"Branch '{new_branch_name}' contains spaces. "
                "Please remove them or use special characters"
            )

        # Check if the branch already exists
        existing_branch = None
        try:
            existing_branch = self._client.get_branch(
                repository_id=self.repository_id,
                name=new_branch_name,
                project=self.project,
            )
        except Exception:
            # expected exception
            pass

        if existing_branch:
            msg = f"Branch '{new_branch_name}' already exists."
            logger.error(msg)
            raise ToolException(msg)

        base_branch = self._client.get_branch(
            repository_id=self.repository_id,
            name=self.active_branch,
            project=self.project,
        )

        try:
            ref_update = GitRefUpdate(
                name=f"refs/heads/{new_branch_name}",
                old_object_id="0000000000000000000000000000000000000000",
                new_object_id=base_branch.commit.commit_id,
            )
            ref_update_list = [ref_update]
            self._client.update_refs(
                ref_updates=ref_update_list,
                repository_id=self.repository_id,
                project=self.project,
            )
            self.active_branch = new_branch_name
            return f"Branch '{new_branch_name}' created successfully, and set as current active branch."
        except Exception as e:
            msg = f"Failed to create branch. Error: {str(e)}"
            logger.error(msg)
            raise ToolException(msg)
```
