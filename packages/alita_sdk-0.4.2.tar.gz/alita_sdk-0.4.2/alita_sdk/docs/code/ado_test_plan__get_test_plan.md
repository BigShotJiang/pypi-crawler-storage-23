# ado_test_plan - get_test_plan

**Toolkit**: `ado_test_plan`
**Method**: `get_test_plan`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def get_test_plan(self, plan_id: Optional[int] = None):
        """Get a test plan or list of test plans in Azure DevOps."""
        try:
            if plan_id:
                test_plan = self._client.get_test_plan_by_id(self.project, plan_id)
                return test_plan.as_dict()
            else:
                test_plans = self._client.get_test_plans(self.project)
                return [plan.as_dict() for plan in test_plans]
        except Exception as e:
            logger.error(f"Error getting test plan(s): {e}")
            return ToolException(f"Error getting test plan(s): {e}")
```
