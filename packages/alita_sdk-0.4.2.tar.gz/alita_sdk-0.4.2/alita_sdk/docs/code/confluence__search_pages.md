# confluence - search_pages

**Toolkit**: `confluence`
**Method**: `search_pages`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def search_pages(self, query: str, skip_images: bool = False):
        """Search pages in Confluence by query text in title or page content."""

        if not query:
            raise ToolException("Search query text is empty. Query parameter is required for Confluence search.")

        if not self.space:
            cql = f'(type=page) and (title~"{query}" or text~"{query}")'
        else:
            cql = f'(type=page and space={self.__sanitize_confluence_space()}) and (title~"{query}" or text~"{query}")'
        return self._process_search(cql, skip_images)
```
