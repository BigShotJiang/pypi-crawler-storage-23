# carrier - search_by_name

**Toolkit**: `carrier`
**Method**: `search_by_name`
**Source File**: `ui_reports_tool.py`
**Class**: `GetUIReportsTool`

---

## Method Implementation

```python
    def search_by_name(self, name):
        """Return all UI reports that match the given name (case-insensitive, partial match)."""
        try:
            reports = self.api_wrapper.get_ui_reports_list()
            base_fields = {
                "id", "name", "environment", "test_type", "browser", "browser_version", "test_status",
                "start_time", "end_time", "duration", "loops", "aggregation", "passed"
            }
            matched_reports = []
            for report in reports:
                if name and name.lower() in report.get("name", "").lower():
                    trimmed = {k: report[k] for k in base_fields if k in report}
                    test_config = report.get("test_config", {})
                    trimmed["test_parameters"] = [
                        {"name": param["name"], "default": param["default"]}
                        for param in test_config.get("test_parameters", [])
                    ]
                    if "source" in test_config:
                        trimmed["source"] = test_config["source"]
                    matched_reports.append(trimmed)
            return json.dumps(matched_reports)
        except Exception:
            stacktrace = traceback.format_exc()
            logger.error(f"Error searching UI reports by name: {stacktrace}")
            raise ToolException(stacktrace)
```
