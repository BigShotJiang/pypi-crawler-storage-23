# carrier - prepare_headers_and_titles

**Toolkit**: `carrier`
**Method**: `prepare_headers_and_titles`
**Source File**: `excel_reporter.py`
**Class**: `ExcelReporter`

---

## Method Implementation

```python
    def prepare_headers_and_titles(self):
        self.title = {
            'Users': 'max_user_count',
            'Ramp Up, min': 'ramp_up_period',
            'Duration, min': 'duration',
            'Think time, sec': 'think_time',
            'Start Date, EST': 'date_start',
            'End Date, EST': 'date_end',
            'Throughput, req/sec': 'throughput',
            'Error rate, %': 'error_rate',
            'Carrier report': 'carrier_report',
            'Build status': 'build_status',
            "Justification": 'justification'
        }
```
