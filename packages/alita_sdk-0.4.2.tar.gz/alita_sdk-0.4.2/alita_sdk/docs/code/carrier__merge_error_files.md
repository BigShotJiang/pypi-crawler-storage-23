# carrier - merge_error_files

**Toolkit**: `carrier`
**Method**: `merge_error_files`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def merge_error_files(self, error_file, extracted_reports):
        with open(error_file, mode='w') as summary_errors:
            for i, log_file in enumerate(extracted_reports):
                report_file = f"{log_file}/simulation-errors.log"
                with open(report_file, mode='r') as f:
                    lines = f.readlines()
                    summary_errors.writelines(lines)
```
