# bitbucket - check_connection

**Toolkit**: `bitbucket`
**Method**: `check_connection`
**Source File**: `__init__.py`
**Class**: `AlitaBitbucketToolkit`

---

## Method Implementation

```python
        def check_connection(self):
            bitbucket_config = self.bitbucket_configuration or {}
            url = bitbucket_config.get('url', '')
            username = bitbucket_config.get('username', '')
            password = bitbucket_config.get('password', '')

            if self.cloud:
                request_url = f"{url}/2.0/repositories/{self.project}/{self.repository}"
            else:
                request_url = f"{url}/rest/api/1.0/projects/{self.project}/repos/{self.repository}"
            response = requests.get(request_url, auth=HTTPBasicAuth(username, password))
            return response
```
