# bitbucket - read_file

**Toolkit**: `bitbucket`
**Method**: `read_file`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def read_file(self, file_path: str, branch: str) -> str:
        """Read the contents of a file in the repository."""
        try:
            return self._read_file(file_path, branch)
        except Exception as e:
            raise ToolException(f"Failed to read file {file_path}: {str(e)}")
```
