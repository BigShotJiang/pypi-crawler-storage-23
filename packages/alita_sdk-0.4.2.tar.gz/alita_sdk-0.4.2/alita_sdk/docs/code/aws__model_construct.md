# aws - model_construct

**Toolkit**: `aws`
**Method**: `model_construct`
**Source File**: `api_wrapper.py`
**Class**: `DeltaLakeApiWrapper`

---

## Method Implementation

```python
    def model_construct(cls, *args, **kwargs):
        klass = super().model_construct(*args, **kwargs)
        klass._delta_table = None
        return klass
```
