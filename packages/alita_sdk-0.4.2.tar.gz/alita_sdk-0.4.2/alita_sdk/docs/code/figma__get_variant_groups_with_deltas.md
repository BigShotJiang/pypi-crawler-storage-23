# figma - get_variant_groups_with_deltas

**Toolkit**: `figma`
**Method**: `get_variant_groups_with_deltas`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def get_variant_groups_with_deltas(frames: List[Dict]) -> List[Dict]:
    """
    Get variant groups with computed deltas for efficient output.

    Returns list of variant groups:
    [
        {
            'base_name': 'Login',
            'base_frame': {...full frame data...},
            'variants': [
                {'name': 'Login_Error', 'state': 'error', 'added': {...}, ...},
                ...
            ]
        }
    ]
    """
    groups = group_variants(frames)
    result = []

    for base_name, variant_list in groups.items():
        if len(variant_list) < 2:
            continue

        # Sort variants to find the "default" state as base
        sorted_variants = sorted(variant_list, key=lambda v: (
            0 if infer_state_from_name(v['name']) == 'default' else 1,
            v['name']
        ))

        base_variant = sorted_variants[0]
        base_frame = base_variant.get('frame', {})

        group_data = {
            'base_name': base_name,
            'base_frame': base_frame,
            'variants': [],
        }

        # Compute deltas for other variants
        for variant in sorted_variants[1:]:
            variant_frame = variant.get('frame', {})
            delta = compute_frame_delta(base_frame, variant_frame)
            group_data['variants'].append(delta)

        result.append(group_data)

    return result
```

## Helper Methods

```python
Helper: group_variants
def group_variants(frames: List[Dict]) -> Dict[str, List[Dict]]:
    """
    Group frames that are variants of the same screen.

    Detects variants by:
    1. Same base name (with variant suffixes like _error, _hover removed)
    2. Identical names but different content (true state variants)

    Returns dict with frame data including position and inferred state:
    {"Login": [{"name": "Login", "pos": "0,105", "id": "1:100", "state": "default"}, ...]}
    """
    groups = {}

    for frame in frames:
        name = frame.get('name', '')
        base = extract_base_name(name)
        pos = frame.get('position', {})
        pos_str = f"{int(pos.get('x', 0))},{int(pos.get('y', 0))}"

        if base not in groups:
            groups[base] = []
        groups[base].append({
            'name': name,
            'pos': pos_str,
            'id': frame.get('id', ''),
            'frame': frame,  # Keep full frame data for delta computation
        })

    # Return groups that are true variants (different names OR different content)
    result = {}
    for base, variant_list in groups.items():
        if len(variant_list) > 1:
            unique_names = set(v['name'] for v in variant_list)

            # Variants if: different names OR same names but different content
            is_variant_group = (
                len(unique_names) > 1 or
                _frames_have_content_differences(variant_list)
            )

            if is_variant_group:
                # Infer state for each variant
                for v in variant_list:
                    v['state'] = _infer_variant_state(v.get('frame', v), variant_list)
                result[base] = variant_list

    return result
```

```python
Helper: compute_frame_delta
def compute_frame_delta(base_frame: Dict, variant_frame: Dict) -> Dict[str, Any]:
    """
    Compute the differences between a base frame and a variant.

    Returns dict with only the changed/added content:
    {
        'name': 'Login_Error',
        'state': 'error',
        'added': {'errors': ['Invalid email'], 'buttons': ['Retry']},
        'removed': {'buttons': ['Sign In']},
        'changed': {'headings': 'Welcome → Try Again'}
    }
    """
    delta = {
        'name': variant_frame.get('name', ''),
        'id': variant_frame.get('id', ''),
        'state': variant_frame.get('state', 'default'),
        'added': {},
        'removed': {},
        'changed': {},
    }

    # Fields to compare
    content_fields = ['headings', 'labels', 'buttons', 'body', 'errors', 'placeholders']

    for field in content_fields:
        base_values = set(base_frame.get(field, []))
        variant_values = set(variant_frame.get(field, []))

        added = variant_values - base_values
        removed = base_values - variant_values

        if added:
            delta['added'][field] = list(added)[:5]  # Limit to 5
        if removed:
            delta['removed'][field] = list(removed)[:5]

    # Check for changed components
    base_components = set(base_frame.get('components', []))
    variant_components = set(variant_frame.get('components', []))
    added_components = variant_components - base_components
    removed_components = base_components - variant_components

    if added_components:
        delta['added']['components'] = list(added_components)[:5]
    if removed_components:
        delta['removed']['components'] = list(removed_components)[:5]

    # Clean up empty dicts
    if not delta['added']:
        del delta['added']
    if not delta['removed']:
        del delta['removed']
    if not delta['changed']:
        del delta['changed']

    return delta
```

```python
Helper: infer_state_from_name
def infer_state_from_name(name: str) -> str:
    """
    Infer screen state from name.

    Returns: default, error, success, loading, empty, or the detected state
    """
    name_lower = name.lower()

    state_keywords = {
        'error': ['error', 'fail', 'invalid', 'wrong'],
        'success': ['success', 'complete', 'done', 'confirmed'],
        'loading': ['loading', 'progress', 'spinner', 'wait'],
        'empty': ['empty', 'no data', 'no results', 'blank'],
        'disabled': ['disabled', 'inactive', 'locked'],
    }

    for state, keywords in state_keywords.items():
        if any(kw in name_lower for kw in keywords):
            return state

    return 'default'
```
