# ado_repos - list_files

**Toolkit**: `ado_repos`
**Method**: `list_files`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def list_files(self, directory_path: str = "", branch_name: str = None) -> List[str]:
        """
        Recursively fetches files from a directory in the repo.

        Parameters:
            directory_path (str): Path to the directory
            branch_name (str): The name of the branch where the files to be received.

        Returns:
            List[str]: List of file paths, or an error message.
        """
        self.active_branch = branch_name if branch_name else self.active_branch
        return self._get_files(
            path=directory_path,
            branch=self.active_branch if self.active_branch else self.base_branch,
        )
```
