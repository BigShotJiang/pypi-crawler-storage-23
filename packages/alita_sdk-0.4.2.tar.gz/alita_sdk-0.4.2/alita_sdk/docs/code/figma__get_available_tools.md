# figma - get_available_tools

**Toolkit**: `figma`
**Method**: `get_available_tools`
**Source File**: `api_wrapper.py`
**Class**: `FigmaApiWrapper`

---

## Method Implementation

```python
    def get_available_tools(self):
        return [
            {
                "name": "get_file_nodes",
                "description": self.get_file_nodes.__doc__,
                "args_schema": ArgsSchema.FileNodes.value,
                "ref": self.get_file_nodes,
            },
            {
                "name": "get_file",
                "description": self.get_file.__doc__,
                "args_schema": ArgsSchema.File.value,
                "ref": self.get_file,
            },
            # TODO disabled until new requirements
            # {
            #     "name": "get_file_summary",
            #     "description": self.get_file_summary.__doc__,
            #     "args_schema": ArgsSchema.FileSummary.value,
            #     "ref": self.get_file_summary,
            # },
            {
                "name": "get_file_versions",
                "description": self.get_file_versions.__doc__,
                "args_schema": ArgsSchema.FileKey.value,
                "ref": self.get_file_versions,
            },
            {
                "name": "get_file_comments",
                "description": self.get_file_comments.__doc__,
                "args_schema": ArgsSchema.FileKey.value,
                "ref": self.get_file_comments,
            },
            {
                "name": "post_file_comment",
                "description": self.post_file_comment.__doc__,
                "args_schema": ArgsSchema.FileComment.value,
                "ref": self.post_file_comment,
            },
            {
                "name": "get_file_images",
                "description": self.get_file_images.__doc__,
                "args_schema": ArgsSchema.FileImages.value,
                "ref": self.get_file_images,
            },
            {
                "name": "get_team_projects",
                "description": self.get_team_projects.__doc__,
                "args_schema": ArgsSchema.TeamProjects.value,
                "ref": self.get_team_projects,
            },
            {
                "name": "get_project_files",
                "description": self.get_project_files.__doc__,
                "args_schema": ArgsSchema.ProjectFiles.value,
                "ref": self.get_project_files,
            },
            # TOON Format Tools (Token-Optimized)
            # Primary unified tool with configurable detail levels
            {
                "name": "analyze_file",
                "description": self.analyze_file.__doc__,
                "args_schema": AnalyzeFileSchema,
                "ref": self.analyze_file,
            },
            # TODO disabled until new requirements
            # # Targeted drill-down for specific frames (more efficient than level 3 for 2-3 frames)
            # {
            #     "name": "get_frame_detail_toon",
            #     "description": self.get_frame_detail_toon.__doc__,
            #     "args_schema": FrameDetailTOONSchema,
            #     "ref": self.get_frame_detail_toon,
            # },
        ]
```
