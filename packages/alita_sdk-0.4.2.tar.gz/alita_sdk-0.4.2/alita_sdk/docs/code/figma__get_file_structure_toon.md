# figma - get_file_structure_toon

**Toolkit**: `figma`
**Method**: `get_file_structure_toon`
**Source File**: `api_wrapper.py`
**Class**: `FigmaApiWrapper`

---

## Method Implementation

```python
    def get_file_structure_toon(
        self,
        url: Optional[str] = None,
        file_key: Optional[str] = None,
        include_pages: Optional[str] = None,
        exclude_pages: Optional[str] = None,
        max_frames: int = 50,
        **kwargs,
    ) -> str:
        """
        Get file structure in TOON format - optimized for LLM token consumption.

        Returns a compact, human-readable format with:
        - Page and frame hierarchy
        - Text content categorized (headings, labels, buttons, body, errors)
        - Component usage
        - Inferred screen types and states
        - Flow analysis (sequences, variants, CTA destinations)

        TOON format uses ~70% fewer tokens than JSON for the same data.

        Use this tool when you need to:
        - Understand overall file structure quickly
        - Generate user journey documentation
        - Analyze screen flows and navigation
        - Identify UI patterns and components
        """
        self._log_tool_event("Getting file structure in TOON format")

        # Parse URL or use file_key
        if url:
            file_key, node_ids_from_url = self._parse_figma_url(url)
            if node_ids_from_url and not include_pages:
                include_pages = ','.join(node_ids_from_url)

        if not file_key:
            raise ToolException("Either url or file_key must be provided")

        # Parse include/exclude pages
        include_ids = [p.strip() for p in include_pages.split(',')] if include_pages else None
        exclude_ids = [p.strip() for p in exclude_pages.split(',')] if exclude_pages else None

        # Get file structure (shallow fetch - only top-level pages, not full content)
        # This avoids "Request too large" errors for big files
        self._log_tool_event(f"Fetching file structure for {file_key}")
        file_data = self._client.get_file(file_key, geometry='depth=1')

        if not file_data:
            raise ToolException(f"Failed to retrieve file {file_key}")

        # Process pages
        pages_data = []
        all_pages = file_data.document.get('children', [])

        for page_node in all_pages:
            page_id = page_node.get('id', '')

            # Apply page filters
            if include_ids and page_id not in include_ids and page_id.replace(':', '-') not in include_ids:
                continue
            if exclude_ids and not include_ids:
                if page_id in exclude_ids or page_id.replace(':', '-') in exclude_ids:
                    continue

            self._log_tool_event(f"Processing page: {page_node.get('name', 'Untitled')}")

            # Fetch full page content individually (avoids large single request)
            try:
                page_full = self._get_file_nodes(file_key, page_id)
                if page_full:
                    page_content = page_full.get('nodes', {}).get(page_id, {}).get('document', page_node)
                else:
                    page_content = page_node
            except Exception as e:
                self._log_tool_event(f"Warning: Could not fetch full page content for {page_id}: {e}")
                page_content = page_node

            page_data = process_page_to_toon_data(page_content)

            # Limit frames per page
            if len(page_data['frames']) > max_frames:
                page_data['frames'] = page_data['frames'][:max_frames]
                page_data['truncated'] = True

            pages_data.append(page_data)

        # Build file data structure
        toon_data = {
            'name': file_data.name,
            'key': file_key,
            'pages': pages_data,
        }

        # Serialize to TOON format
        serializer = TOONSerializer()
        result = serializer.serialize_file(toon_data)

        self._log_tool_event("File structure extracted in TOON format")
        return result
```
