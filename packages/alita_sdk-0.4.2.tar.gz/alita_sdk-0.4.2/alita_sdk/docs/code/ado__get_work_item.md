# ado - get_work_item

**Toolkit**: `ado`
**Method**: `get_work_item`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def get_work_item(self, id: int, fields: Optional[list[str]] = None, as_of: Optional[str] = None, expand: Optional[str] = None, parse_attachments=False, image_description_prompt=None):
        """Get a single work item by ID."""
        try:
            # Validate that the Azure DevOps client is initialized
            if not self._client:
                raise ToolException("Azure DevOps client not initialized.")

            # Fetch the work item
            work_item = self._client.get_work_item(id=id, project=self.project, fields=fields, as_of=as_of, expand=expand)

            # Parse the fields dynamically
            fields_data = work_item.fields
            parsed_item = {"id": work_item.id, "url": f"{self.organization_url}/_workitems/edit/{work_item.id}"}

            # Iterate through the requested fields and add them to the parsed result
            if fields:
                for field in fields:
                    parsed_item[field] = fields_data.get(field, "N/A")
            else:
                parsed_item.update(fields_data)

            # extract relations if any
            relations_data = None
            if expand and str(expand).lower() in ("relations", "all"):
                try:
                    relations_data = getattr(work_item, 'relations', None)
                except KeyError:
                    relations_data = None
            if relations_data:
                parsed_item['relations'] = [relation.as_dict() for relation in relations_data]

            if parse_attachments:
                # describe images in work item fields if present
                for field_name, field_value in fields_data.items():
                    if isinstance(field_value, str):
                        soup = BeautifulSoup(field_value, 'html.parser')
                        images = soup.find_all('img')
                        for img in images:
                            src = img.get('src')
                            if src:
                                description = self.parse_attachment_by_url(src, image_description_prompt=image_description_prompt)
                                img['image-description'] = description
                        parsed_item[field_name] = str(soup)
                # parse attached documents if present
                for relation in parsed_item.get('relations', []):
                    # Only process actual file attachments
                    if relation.get('rel') == 'AttachedFile':
                        file_name = relation.get('attributes', {}).get('name')
                        if file_name:
                            try:
                                relation['content'] = self.parse_attachment_by_url(relation['url'], file_name, image_description_prompt=image_description_prompt)
                            except Exception as att_e:
                                logger.warning(f"Failed to parse attachment {file_name}: {att_e}")


            return parsed_item
        except Exception as e:
            logger.error(f"Error getting work item: {e}")
            return ToolException(f"Error getting work item: {e}")
```
