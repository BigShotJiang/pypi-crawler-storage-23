# figma - compute_frame_delta

**Toolkit**: `figma`
**Method**: `compute_frame_delta`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def compute_frame_delta(base_frame: Dict, variant_frame: Dict) -> Dict[str, Any]:
    """
    Compute the differences between a base frame and a variant.

    Returns dict with only the changed/added content:
    {
        'name': 'Login_Error',
        'state': 'error',
        'added': {'errors': ['Invalid email'], 'buttons': ['Retry']},
        'removed': {'buttons': ['Sign In']},
        'changed': {'headings': 'Welcome → Try Again'}
    }
    """
    delta = {
        'name': variant_frame.get('name', ''),
        'id': variant_frame.get('id', ''),
        'state': variant_frame.get('state', 'default'),
        'added': {},
        'removed': {},
        'changed': {},
    }

    # Fields to compare
    content_fields = ['headings', 'labels', 'buttons', 'body', 'errors', 'placeholders']

    for field in content_fields:
        base_values = set(base_frame.get(field, []))
        variant_values = set(variant_frame.get(field, []))

        added = variant_values - base_values
        removed = base_values - variant_values

        if added:
            delta['added'][field] = list(added)[:5]  # Limit to 5
        if removed:
            delta['removed'][field] = list(removed)[:5]

    # Check for changed components
    base_components = set(base_frame.get('components', []))
    variant_components = set(variant_frame.get('components', []))
    added_components = variant_components - base_components
    removed_components = base_components - variant_components

    if added_components:
        delta['added']['components'] = list(added_components)[:5]
    if removed_components:
        delta['removed']['components'] = list(removed_components)[:5]

    # Clean up empty dicts
    if not delta['added']:
        del delta['added']
    if not delta['removed']:
        del delta['removed']
    if not delta['changed']:
        del delta['changed']

    return delta
```
