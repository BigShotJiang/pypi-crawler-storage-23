# carrier - log_action

**Toolkit**: `carrier`
**Method**: `log_action`
**Source File**: `utils.py`

---

## Method Implementation

```python
def log_action(action: str, details: dict = None):
    """
    Log an action with optional details.

    Args:
        action (str): Description of the action
        details (dict, optional): Additional details about the action
    """
    logger = logging.getLogger(__name__)
    log_message = action
    if details is not None:  # Check for None instead of truthiness to handle empty dicts
        log_message += f": {json.dumps(details, indent=2)}"
    logger.info(log_message)
```
