# carrier - toolkit_config_schema

**Toolkit**: `carrier`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `AlitaCarrierToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema(cls) -> BaseModel:
        selected_tools = {}
        for t in __all__:
            default = t['tool'].__pydantic_fields__['args_schema'].default
            selected_tools[t['name']] = default.schema() if default else default
        return create_model(
            name,
            project_id=(Optional[str], Field(None, description="Optional project ID for scoped operations")),
            carrier_configuration=(CarrierConfiguration, Field(description="Carrier Configuration", json_schema_extra={'configuration_types': ['carrier']})),
            selected_tools=(
                List[Literal[tuple(selected_tools)]],
                Field(default=[], json_schema_extra={"args_schemas": selected_tools}),
            ),
            __config__=ConfigDict(json_schema_extra={
                'metadata': {
                    "label": "Carrier",
                    "version": "2.0.1",
                    "icon_url": "carrier.svg",
                    "categories": ["testing"],
                    "extra_categories": ["carrier", "ticket management", "log management"],
                }
            })
        )
```
