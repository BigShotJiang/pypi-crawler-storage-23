# confluence - list_pages_with_label

**Toolkit**: `confluence`
**Method**: `list_pages_with_label`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def list_pages_with_label(self, label: str):
        """ Lists the pages with specific label in the Confluence space."""
        return [{'id': page['page_id'], 'title': page['page_title']} for page in self._get_labeled_page(label)]
```
