# ado - convert_steps_tag_to_ado_steps

**Toolkit**: `ado`
**Method**: `convert_steps_tag_to_ado_steps`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def convert_steps_tag_to_ado_steps(self, input_xml: str) -> str:
        """
        Converts input XML from format:
        <Steps><Step><Action>...</Action><ExpectedResult>...</ExpectedResult></Step></Steps>
        to Azure DevOps test case format:
        <steps><step id="1" type="Action">...</step>...</steps>
        """
        input_root = ET.fromstring(input_xml)
        steps_elem = ET.Element("steps")
        for step_node in input_root.findall("Step"):
            step_number = step_node.findtext("StepNumber", default="1")
            action = step_node.findtext("Action", default="")
            expected_result = step_node.findtext("ExpectedResult", default="")
            steps_elem.append(self.build_step_element(step_number, action, expected_result))
        return ET.tostring(steps_elem, encoding="unicode")
```

## Helper Methods

```python
Helper: build_step_element
    def build_step_element(self, step_number: str, action: str, expected_result: str) -> ET.Element:
        """
            Creates an individual <step> element for Azure DevOps.
            """
        step_elem = ET.Element("step", id=str(step_number), type="Action")
        action_elem = ET.SubElement(step_elem, "parameterizedString", isformatted="true")
        action_elem.text = action or ""
        expected_elem = ET.SubElement(step_elem, "parameterizedString", isformatted="true")
        expected_elem.text = expected_result or ""
        return step_elem
```
