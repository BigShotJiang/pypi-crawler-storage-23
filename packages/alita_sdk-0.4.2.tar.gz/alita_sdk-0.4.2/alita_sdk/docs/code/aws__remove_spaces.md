# aws - remove_spaces

**Toolkit**: `aws`
**Method**: `remove_spaces`
**Source File**: `tool.py`
**Class**: `DeltaLakeAction`

---

## Method Implementation

```python
    def remove_spaces(cls, v):
        return v.replace(' ', '')
```
