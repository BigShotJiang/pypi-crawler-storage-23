# ado_wiki - get_wiki

**Toolkit**: `ado_wiki`
**Method**: `get_wiki`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def get_wiki(self, wiki_identified: Optional[str] = None):
        """Extract ADO wiki information."""
        try:
            wiki_id = self._resolve_wiki_identifier(wiki_identified)
            wiki_response = self._client.get_wiki(project=self.project, wiki_identifier=wiki_id)
            return _format_wiki_response(wiki_response)
        except Exception as e:
            logger.error(f"Error during the attempt to extract wiki: {str(e)}")
            return ToolException(f"Error during the attempt to extract wiki: {str(e)}")
```
