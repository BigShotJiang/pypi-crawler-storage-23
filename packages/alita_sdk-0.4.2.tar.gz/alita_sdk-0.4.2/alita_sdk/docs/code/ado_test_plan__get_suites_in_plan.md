# ado_test_plan - get_suites_in_plan

**Toolkit**: `ado_test_plan`
**Method**: `get_suites_in_plan`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def get_suites_in_plan(self, plan_id: int) -> List[dict]:
        """Get all test suites in a test plan."""
        try:
            test_suites = self._client.get_test_suites_for_plan(self.project, plan_id)
            return [suite.as_dict() for suite in test_suites]
        except Exception as e:
            logger.error(f"Error getting test suites: {e}")
            return ToolException(f"Error getting test suites: {e}")
```
