# carrier - write_title_above_headers

**Toolkit**: `carrier`
**Method**: `write_title_above_headers`
**Source File**: `excel_reporter.py`
**Class**: `ExcelReporter`

---

## Method Implementation

```python
    def write_title_above_headers(title, results, header, ws):

        for i, (header_field_name, header_key) in enumerate(title.items()):
            title_name = ws.cell(row=i + 1, column=1, value=header_field_name)
            title_value = ws.cell(row=i + 1, column=2, value=results[header_key])
            title_name.font = Font(b=True, color='00291A75')
            title_name.fill = PatternFill("solid", fgColor='00CDEBEA')
            title_name.alignment = Alignment(horizontal="left", vertical="center")
            title_value.alignment = Alignment(horizontal="center", vertical="center")
            title_value.fill = PatternFill("solid", fgColor='00CDEBEA')
            border_style = Side(border_style="thin", color="040404")
            title_value.border = Border(top=border_style, left=border_style, right=border_style, bottom=border_style)
            title_name.border = Border(top=border_style, left=border_style, right=border_style, bottom=border_style)

            if header_key == 'error_rate':
                title_value.number_format = '0.00%'
            if header_key == 'carrier_report':
                title_value.hyperlink, title_value.value = title_value.value, "Carrier report"
                title_value.font = Font(b=True, underline="single", color='00291A75')
            if header_key == 'build_status':
                title_value.font = Font(b=True,
                                        color=GREEN_COLOR_FONT if title_value.value == 'SUCCESS'
                                        else RED_COLOR_FONT)
            if header_key == 'justification' and len(title_value.value) > 125:
                title_value.alignment = Alignment(horizontal="center", vertical="justify")
                ws.row_dimensions[i + 1].height = 30

            ws.merge_cells(start_row=i + 1, start_column=2, end_row=i + 1, end_column=len(header.items()))
```
