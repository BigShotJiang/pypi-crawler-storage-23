# figma - extract_components

**Toolkit**: `figma`
**Method**: `extract_components`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def extract_components(node: Dict, depth: int = 0, max_depth: int = 10) -> List[str]:
    """
    Recursively extract component/instance names.
    """
    if depth > max_depth:
        return []

    components = []
    node_type = node.get('type', '').upper()

    if node_type in ['COMPONENT', 'INSTANCE', 'COMPONENT_SET']:
        name = node.get('name', '')
        if name:
            components.append(name)

    for child in node.get('children', []):
        components.extend(extract_components(child, depth + 1, max_depth))

    return components
```
