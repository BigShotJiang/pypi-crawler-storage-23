# confluence - process_base64_image

**Toolkit**: `confluence`
**Method**: `process_base64_image`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
            def process_base64_image(match):
                """Process base64 embedded image references and get contextual descriptions"""
                media_type = match.group(1)
                base64_data = match.group(2)
                full_match = match.group(0)  # The complete image reference

                logger.info(f"Processing base64 embedded image of type: {media_type}")

                try:
                    # Generate a name for the image based on media type
                    image_format = media_type.split('/')[-1]
                    image_name = f"embedded-image.{image_format}"

                    # Decode base64 data
                    try:
                        image_data = base64.b64decode(base64_data)
                    except Exception as e:
                        logger.error(f"Failed to decode base64 image data: {str(e)}")
                        return f"[Image: embedded {media_type} - decode failed]"

                    # Collect surrounding context
                    context_text = self._collect_context_for_image(page_content, full_match, context_radius)

                    # Process with LLM (will use cache if available)
                    description = self._process_image_with_llm(image_data, image_name, context_text, prompt)
                    return f"[Image {image_name} Description: {description}]"

                except Exception as e:
                    logger.error(f"Error processing base64 image: {str(e)}")
                    return f"[Image: embedded {media_type} - Error: {str(e)}]"
```
