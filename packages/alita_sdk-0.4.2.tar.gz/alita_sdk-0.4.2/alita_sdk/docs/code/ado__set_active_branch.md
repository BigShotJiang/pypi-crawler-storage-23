# ado - set_active_branch

**Toolkit**: `ado`
**Method**: `set_active_branch`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def set_active_branch(self, branch_name: str) -> str:
        """
        Equivalent to `git checkout branch_name` for this Agent.

        Parameters:
            branch_name (str): The name of the branch to be the current branch

        Returns:
            Error (as a string) if branch doesn't exist.
        """
        current_branches = [
            branch.name
            for branch in self._client.get_branches(
                repository_id=self.repository_id, project=self.project
            )
        ]
        if branch_name in current_branches:
            self.active_branch = branch_name
            return f"Switched to branch `{branch_name}`"
        else:
            msg = (
                    f"Error {branch_name} does not exist, "
                    + f"in repo with current branches: {str(current_branches)}"
            )
            return ToolException(msg)
```
