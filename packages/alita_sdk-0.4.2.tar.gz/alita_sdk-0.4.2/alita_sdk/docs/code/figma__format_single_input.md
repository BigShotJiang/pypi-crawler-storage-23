# figma - format_single_input

**Toolkit**: `figma`
**Method**: `format_single_input`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def format_single_input(
    label: str,
    input_type: str,
    required: bool = False,
    value: Optional[str] = None,
    options: Optional[List[str]] = None,
    placeholder: Optional[str] = None,
) -> str:
    """
    Format a single input field in standardized TOON format.

    Standard format: Label* (type): "value" or Label* (type): [Opt1/Opt2/...]

    Args:
        label: Input label/name
        input_type: Type (text, email, slider, select, etc.)
        required: Whether field is required (adds * marker)
        value: Current value shown
        options: Options for select/radio/slider types
        placeholder: Placeholder text (fallback if no value/options)

    Returns:
        Formatted input string
    """
    req_marker = '*' if required else ''
    base_str = f"{label}{req_marker} ({input_type})"

    # Priority: value > options > placeholder
    if value and len(str(value)) < INPUT_FORMAT_MAX_VALUE_LEN:
        base_str += f': "{value}"'
    elif options:
        opts_str = '/'.join(options[:INPUT_FORMAT_MAX_OPTIONS])
        base_str += f": [{opts_str}]"
    elif placeholder and len(str(placeholder)) < INPUT_FORMAT_MAX_VALUE_LEN:
        base_str += f': "{placeholder}"'

    return base_str
```
