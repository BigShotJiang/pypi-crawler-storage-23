# bitbucket - get_pull_requests_commits

**Toolkit**: `bitbucket`
**Method**: `get_pull_requests_commits`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def get_pull_requests_commits(self, pr_id: str) -> List[Dict[str, Any]]:
        """
        Get commits from a pull request
        Parameters:
            pr_id(str): the pull request ID
        Returns:
            List[Dict[str, Any]]: List of commits in the pull request
        """
        try:
            result = self._bitbucket.get_pull_request_commits(pr_id=pr_id)
            return result
        except Exception as e:
            return ToolException(f"Can't get commits from pull request `{pr_id}` due to error:\n{str(e)}")
```
