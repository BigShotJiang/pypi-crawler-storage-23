# confluence - get_pages_with_label

**Toolkit**: `confluence`
**Method**: `get_pages_with_label`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def get_pages_with_label(self, label: str):
        """ Gets pages with specific label in the Confluence space."""
        return str(self._get_labeled_page(label))
```
