# ado - get_wiki_page_by_id

**Toolkit**: `ado`
**Method**: `get_wiki_page_by_id`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def get_wiki_page_by_id(self, wiki_identified: Optional[str] = None, page_id: int = None, image_description_prompt=None):
        """Extract ADO wiki page content."""
        try:
            wiki_id = self._resolve_wiki_identifier(wiki_identified)
            return self._process_images(self._client.get_page_by_id(project=self.project, wiki_identifier=wiki_id, id=page_id,
                                                include_content=True).page.content,
                                        image_description_prompt=image_description_prompt, wiki_identified=wiki_id)
        except Exception as e:
            logger.error(f"Error during the attempt to extract wiki page: {str(e)}")
            return ToolException(f"Error during the attempt to extract wiki page: {str(e)}")
```
