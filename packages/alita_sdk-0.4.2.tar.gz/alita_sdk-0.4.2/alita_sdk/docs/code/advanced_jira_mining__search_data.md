# advanced_jira_mining - search_data

**Toolkit**: `advanced_jira_mining`
**Method**: `search_data`
**Source File**: `data_mining_wrapper.py`
**Class**: `AdvancedJiraMiningWrapper`

---

## Method Implementation

```python
    def search_data(self, jira_issue_key: str, query: str) -> str:
        """
        Search the specific jira ticket data using already provided by user jira ticket id and given query.
        Usually query will be a simple acceptance criterion (AC) from the same ticket
        """
        result = self.__perform_similarity_search(jira_issue_key, query)
        return ''.join(result)
```
