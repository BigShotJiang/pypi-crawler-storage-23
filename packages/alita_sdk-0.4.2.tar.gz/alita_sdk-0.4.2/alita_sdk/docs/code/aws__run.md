# aws - run

**Toolkit**: `aws`
**Method**: `run`
**Source File**: `api_wrapper.py`
**Class**: `DeltaLakeApiWrapper`

---

## Method Implementation

```python
    def run(self, name: str, *args: Any, **kwargs: Any):
        for tool in self.get_available_tools():
            if tool["name"] == name:
                if len(args) == 1 and isinstance(args[0], dict) and not kwargs:
                    kwargs = args[0]
                    args = ()
                try:
                    return tool["ref"](*args, **kwargs)
                except TypeError as e:
                    if kwargs and not args:
                        try:
                            return tool["ref"](**kwargs)
                        except TypeError:
                            raise ValueError(
                                f"Argument mismatch for tool '{name}'. Error: {e}"
                            ) from e
                    else:
                        raise ValueError(
                            f"Argument mismatch for tool '{name}'. Error: {e}"
                        ) from e
        else:
            raise ValueError(f"Unknown tool name: {name}")
```
