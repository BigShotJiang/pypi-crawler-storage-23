# figma - process_frame_to_toon_data

**Toolkit**: `figma`
**Method**: `process_frame_to_toon_data`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def process_frame_to_toon_data(frame_node: Dict) -> Dict:
    """
    Process a Figma frame node into TOON-ready data structure.

    Returns structured data that can be serialized to TOON format.
    """
    name = frame_node.get('name', 'Untitled')

    # Extract position and size
    bounds = frame_node.get('absoluteBoundingBox', {})
    position = {'x': bounds.get('x', 0), 'y': bounds.get('y', 0)}
    size = {'w': bounds.get('width', 0), 'h': bounds.get('height', 0)}

    # Extract text by role
    text_data = extract_text_by_role(frame_node)

    # Extract components
    components = extract_components(frame_node)

    # Extract input fields
    inputs = extract_inputs(frame_node)
    # Dedupe inputs by name
    seen_inputs = set()
    unique_inputs = []
    for inp in inputs:
        if inp['name'] not in seen_inputs:
            seen_inputs.add(inp['name'])
            unique_inputs.append(inp)

    # Build frame data with deduplication
    frame_data = {
        'id': frame_node.get('id', ''),
        'name': name,
        'position': position,
        'size': size,
        # Deduplicate and limit text fields
        'headings': dedupe_and_clean_text(text_data['headings'], max_items=5),
        'labels': dedupe_and_clean_text(text_data['labels'], max_items=15),
        'buttons': dedupe_and_clean_text(text_data['buttons'], max_items=10),
        'inputs': unique_inputs[:10],  # Limit to 10 inputs
        'body': dedupe_and_clean_text(text_data['body'], max_items=10),
        'errors': dedupe_and_clean_text(text_data['errors'], max_items=5),
        'placeholders': dedupe_and_clean_text(text_data.get('placeholders', []), max_items=5),
        'components': list(dict.fromkeys(components))[:15],  # Dedupe components too
    }

    # Infer type and state
    frame_data['type'] = infer_screen_type(frame_data)
    frame_data['state'] = infer_state_from_name(name)

    # Check if variant
    base_name = extract_base_name(name)
    if base_name != name:
        frame_data['variant_of'] = base_name

    return frame_data
```

## Helper Methods

```python
Helper: extract_inputs
def extract_inputs(node: Dict, depth: int = 0, max_depth: int = 12) -> List[Dict[str, Any]]:
    """
    Recursively extract input fields with their labels, types, and options.

    Enhanced to detect:
    - Modal form fields with label+control patterns
    - Sliders with labels (Creativity, Reasoning, etc.)
    - Selectors with current values
    - Display fields (read-only info)
    - Radio/segment controls with options

    Returns list of dicts:
        [{'name': 'Email', 'type': 'email', 'required': True, 'placeholder': '...', 'options': [], 'value': '...'}, ...]
    """
    if depth > max_depth:
        return []

    inputs = []
    node_type = node.get('type', '').upper()
    node_name = node.get('name', '')
    node_name_lower = node_name.lower()
    children = node.get('children', [])

    # Check if this node is a form container (modal, settings panel, etc.)
    is_form_container = any(kw in node_name_lower for kw in MODAL_FORM_KEYWORDS)

    # Strategy 1: Check if this is a direct input component/instance
    is_input = False
    input_type = 'text'

    if node_type in ['COMPONENT', 'INSTANCE', 'COMPONENT_SET', 'FRAME']:
        is_input, input_type = _infer_input_type(node_name, len(children))

    if is_input:
        # Extract all text from this input node
        all_texts = _extract_all_text_from_node(node, max_depth=6)

        label = ''
        placeholder = ''
        value = ''
        options = []
        required = False

        # Check node name for required indicator
        for indicator in REQUIRED_INDICATORS:
            if indicator in node_name_lower:
                required = True
                break

        # Process extracted texts with improved categorization
        for t in all_texts:
            text = t['text']

            # Check for required indicators
            if '*' in text:
                required = True
                text = text.replace('*', '').strip()

            # Skip very short text (but allow numbers)
            if len(text) < 2:
                continue

            # Categorize text more carefully
            if t.get('is_placeholder') or (t.get('is_gray') and not t.get('is_value')):
                if not placeholder:
                    placeholder = text
            elif t.get('is_label') or (t.get('font_size', 14) <= 12 and not t.get('is_value')):
                if not label:
                    label = text
            elif t.get('is_value') or t.get('is_option'):
                # Value or option
                if input_type in ['select', 'radio', 'slider']:
                    options.append(text)
                else:
                    if not value:
                        value = text
            else:
                # Guess based on context and length
                if not label and len(text) < 40:
                    label = text
                elif input_type in ['select', 'radio', 'slider'] and len(text) < 25:
                    options.append(text)
                elif not value:
                    value = text

        # Try to get label from node name if not found
        if not label:
            label = _clean_input_label(node_name)

        # Skip if label is empty or generic
        if not label or label.lower() in ['input', 'field', '', 'text', 'frame']:
            label = _clean_input_label(node_name) or 'Input'

        # Only add if we have a meaningful label
        if label and label.lower() not in ['', 'input', 'field', 'frame', 'instance', 'component']:
            input_data = {
                'name': label,
                'type': input_type,
                'required': required,
                'placeholder': placeholder,
            }
            # Add value if present
            if value:
                input_data['value'] = value
            # Add options for select/radio/slider types
            if options and input_type in ['select', 'radio', 'slider']:
                input_data['options'] = list(dict.fromkeys(options))[:6]  # Dedupe, limit to 6

            inputs.append(input_data)
        # Don't recurse into detected input nodes
        return inputs

    # Strategy 2: For form containers, try to detect label+control patterns
    if is_form_container or node_type == 'FRAME':
        for child in children:
            field = _detect_form_field_in_subtree(child, depth=0, max_depth=4)
            if field:
                input_data = {
                    'name': field['name'],
                    'type': field['type'],
                    'required': False,
                    'placeholder': '',
                }
                if field.get('value'):
                    input_data['value'] = field['value']
                if field.get('options'):
                    input_data['options'] = field['options']
                inputs.append(input_data)

    # Recurse into children
    for child in children:
        inputs.extend(extract_inputs(child, depth + 1, max_depth))

    # Deduplicate by name (keep first occurrence)
    seen_names = set()
    deduped = []
    for inp in inputs:
        name_key = inp['name'].lower()
        if name_key not in seen_names:
            seen_names.add(name_key)
            deduped.append(inp)

    return deduped
```

```python
Helper: infer_screen_type
def infer_screen_type(frame_data: Dict) -> str:
    """
    Infer screen type from content.

    Returns: form, list, detail, dashboard, modal, menu, settings, chat, etc.
    """
    name_lower = frame_data.get('name', '').lower()
    components = frame_data.get('components', [])
    buttons = frame_data.get('buttons', [])
    labels = frame_data.get('labels', [])

    components_lower = [c.lower() for c in components]
    buttons_lower = [b.lower() for b in buttons]

    # Check name hints
    type_hints = {
        'form': ['login', 'signup', 'register', 'checkout', 'payment', 'form', 'input'],
        'list': ['list', 'feed', 'timeline', 'results', 'search results'],
        'detail': ['detail', 'profile', 'item', 'product', 'article'],
        'dashboard': ['dashboard', 'home', 'overview', 'summary'],
        'modal': ['modal', 'dialog', 'popup', 'overlay', 'alert'],
        'menu': ['menu', 'navigation', 'sidebar', 'drawer'],
        'settings': ['settings', 'preferences', 'config', 'options'],
        'chat': ['chat', 'message', 'conversation', 'inbox'],
        'onboarding': ['onboarding', 'welcome', 'intro', 'tutorial'],
    }

    for screen_type, keywords in type_hints.items():
        if any(kw in name_lower for kw in keywords):
            return screen_type

    # Check components
    if any('input' in c or 'textfield' in c or 'form' in c for c in components_lower):
        return 'form'
    if any('card' in c or 'listitem' in c for c in components_lower):
        return 'list'
    if any('modal' in c or 'dialog' in c for c in components_lower):
        return 'modal'

    # Check buttons for form indicators
    form_buttons = ['submit', 'save', 'sign in', 'log in', 'register', 'next', 'continue']
    if any(any(fb in b for fb in form_buttons) for b in buttons_lower):
        return 'form'

    return 'screen'  # Generic fallback
```
