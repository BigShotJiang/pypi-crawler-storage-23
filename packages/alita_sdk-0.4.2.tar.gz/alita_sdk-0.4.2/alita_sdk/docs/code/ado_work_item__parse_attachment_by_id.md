# ado_work_item - parse_attachment_by_id

**Toolkit**: `ado_work_item`
**Method**: `parse_attachment_by_id`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def parse_attachment_by_id(self, attachment_id, file_name, image_description_prompt):
        file_content = self.get_attachment_content(attachment_id)
        return parse_file_content(file_content=file_content, file_name=file_name,
                                            llm=self.llm, prompt=image_description_prompt)
```

## Helper Methods

```python
Helper: get_attachment_content
    def get_attachment_content(self, attachment_id):
        content_generator = self._client.get_attachment_content(id=attachment_id, download=True)
        return b"".join(content_generator)
```
