# carrier - get_response_threshold

**Toolkit**: `carrier`
**Method**: `get_response_threshold`
**Source File**: `excel_reporter.py`
**Class**: `ExcelReporter`

---

## Method Implementation

```python
    def get_response_threshold(thresholds):
        for th in thresholds:
            if th["target"] == "response_time":
                return th["threshold"]
```
