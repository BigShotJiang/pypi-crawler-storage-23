# ado - to_dict

**Toolkit**: `ado`
**Method**: `to_dict`
**Source File**: `repos_wrapper.py`
**Class**: `GitChange`

---

## Method Implementation

```python
    def to_dict(self):
        change_dict = {"changeType": self.changeType, "item": self.item}
        if self.newContent:
            change_dict["newContent"] = self.newContent
        return change_dict
```
