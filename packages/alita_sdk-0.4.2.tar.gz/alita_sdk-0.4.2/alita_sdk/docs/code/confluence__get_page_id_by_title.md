# confluence - get_page_id_by_title

**Toolkit**: `confluence`
**Method**: `get_page_id_by_title`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def get_page_id_by_title(self, title: str, type: str = "page"):
        """
        Provide page id from search result by title.
        :param title: title
        :param type: type of content: page or blogpost. Defaults to page
        """

        result = self.client.get_page_id(space=self.space, title=title, type=type)
        return result if result else "Page not found. Check the title or space."
```
