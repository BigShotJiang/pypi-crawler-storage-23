# carrier - convert_time

**Toolkit**: `carrier`
**Method**: `convert_time`
**Source File**: `excel_reporter.py`
**Class**: `JMeterReportParser`

---

## Method Implementation

```python
    def convert_time(self, ts):
        element = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
        tuple = element.timetuple()
        timestamp = time.mktime(tuple)
        return timestamp
```
