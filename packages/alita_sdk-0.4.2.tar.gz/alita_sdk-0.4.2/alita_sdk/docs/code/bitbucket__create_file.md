# bitbucket - create_file

**Toolkit**: `bitbucket`
**Method**: `create_file`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def create_file(self, file_path: str, file_contents: str, branch: str) -> str:
        form_data = {
            'branch': f'{branch}',
            f'{file_path}': f'{file_contents}',
        }
        return self.repository.post(path='src', data=form_data, files={},
                                    headers={'Content-Type': 'application/x-www-form-urlencoded'})
```
