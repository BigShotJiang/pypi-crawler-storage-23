# bitbucket - get_toolkit

**Toolkit**: `bitbucket`
**Method**: `get_toolkit`
**Source File**: `__init__.py`
**Class**: `AlitaBitbucketToolkit`

---

## Method Implementation

```python
    def get_toolkit(cls, selected_tools: list[str] | None = None, toolkit_name: Optional[str] = None, **kwargs):
        if selected_tools is None:
            selected_tools = []
        if kwargs["cloud"] is None:
            kwargs["cloud"] = True if "bitbucket.org" in kwargs.get('url') else False
        wrapper_payload = {
            **kwargs,
            # TODO use bitbucket_configuration fields
            **kwargs['bitbucket_configuration'],
            **(kwargs.get('pgvector_configuration') or {}),
        }
        bitbucket_api_wrapper = BitbucketAPIWrapper(**wrapper_payload)
        available_tools: List[Dict] = bitbucket_api_wrapper.get_available_tools()
        tools = []
        for tool in available_tools:
            if selected_tools:
                if tool['name'] not in selected_tools:
                    continue
            description = tool["description"] + f"\nrepo: {bitbucket_api_wrapper.repository}"
            if toolkit_name:
                description = f"{description}\nToolkit: {toolkit_name}"
            description = description[:1000]
            tools.append(BaseAction(
                api_wrapper=bitbucket_api_wrapper,
                name=tool["name"],
                description=description,
                args_schema=tool["args_schema"],
                metadata={TOOLKIT_NAME_META: toolkit_name, TOOLKIT_TYPE_META: name, TOOL_NAME_META: tool["name"]} if toolkit_name else {TOOL_NAME_META: tool["name"]}
            ))
        return cls(tools=tools)
```
