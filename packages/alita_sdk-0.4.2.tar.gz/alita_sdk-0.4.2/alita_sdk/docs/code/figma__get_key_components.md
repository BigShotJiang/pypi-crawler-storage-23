# figma - get_key_components

**Toolkit**: `figma`
**Method**: `get_key_components`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def get_key_components(components: List[str], max_items: int = 5) -> List[str]:
    """
    Get the most important/unique component names for display.

    Prioritizes:
    - Interactive elements (buttons, inputs)
    - Unique component names
    - Avoids generic names (icons, dividers)
    """
    if not components:
        return []

    categorized = categorize_components(components)

    result = []
    # Priority order: interactive first
    priority = ['buttons', 'inputs', 'selects', 'modals', 'cards', 'navigation', 'other']

    for cat in priority:
        if cat in categorized:
            # Take first few unique components from this category
            for comp in categorized[cat]:
                if comp not in result:
                    result.append(comp)
                    if len(result) >= max_items:
                        return result

    return result
```

## Helper Methods

```python
Helper: categorize_components
def categorize_components(components: List[str]) -> Dict[str, List[str]]:
    """
    Group components into semantic categories.

    Returns:
        {
            'buttons': ['Button/Primary', 'Button/Secondary'],
            'inputs': ['Input/Text', 'Input/Email'],
            'other': ['CustomComponent'],
            ...
        }
    """
    categorized = {cat: [] for cat in COMPONENT_CATEGORIES}
    categorized['other'] = []

    for component in components:
        comp_lower = component.lower()
        found_category = False

        for category, keywords in COMPONENT_CATEGORIES.items():
            if any(kw in comp_lower for kw in keywords):
                categorized[category].append(component)
                found_category = True
                break

        if not found_category:
            categorized['other'].append(component)

    # Remove empty categories
    return {k: v for k, v in categorized.items() if v}
```
