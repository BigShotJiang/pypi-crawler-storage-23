# carrier - merge_log_files

**Toolkit**: `carrier`
**Method**: `merge_log_files`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def merge_log_files(self, summary_file, extracted_reports, lg_type):
        with open(summary_file, mode='w') as summary:
            for i, log_file in enumerate(extracted_reports):
                if lg_type == "jmeter":
                    report_file = f"{log_file}/jmeter.jtl"
                else:
                    report_file = get_latest_log_file(log_file, "simulation.log")
                with open(report_file, mode='r') as f:
                    lines = f.readlines()
                    if i == 0:
                        # Write all lines from the first file (including the header)
                        summary.writelines(lines)
                    else:
                        # Skip the first line (header) for subsequent files
                        summary.writelines(lines[1:])
```
