# carrier - find_param_by_name

**Toolkit**: `carrier`
**Method**: `find_param_by_name`
**Source File**: `run_ui_test_tool.py`
**Class**: `RunUITestTool`

---

## Method Implementation

```python
            def find_param_by_name(params, name):
                for param in params:
                    if param.get("name") == name:
                        return param
                return {}
```
