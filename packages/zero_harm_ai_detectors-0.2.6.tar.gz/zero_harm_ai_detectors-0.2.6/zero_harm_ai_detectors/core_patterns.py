"""
Core patterns, validators, and result types shared across detection modes.

This module contains:
- Heuristic patterns for structured data detection
- Validators (Luhn, entropy)
- Detection and DetectionResult dataclasses
- HarmfulResult dataclass (distinct from List[Detection] for clarity)
- Redaction utilities

File: zero_harm_ai_detectors/core_patterns.py
"""
import hashlib
import math
import re
from dataclasses import dataclass, field
from enum import Enum, IntFlag
from typing import Any, Dict, List, Optional, Tuple


# ============================================================
# Detection Types
# ============================================================

class DetectionType(Enum):
    """Types of detectable content."""
    # PII
    EMAIL = "EMAIL"
    PHONE = "PHONE"
    SSN = "SSN"
    CREDIT_CARD = "CREDIT_CARD"
    BANK_ACCOUNT = "BANK_ACCOUNT"
    DOB = "DOB"
    DRIVERS_LICENSE = "DRIVERS_LICENSE"
    MEDICAL_RECORD_NUMBER = "MEDICAL_RECORD_NUMBER"
    ADDRESS = "ADDRESS"
    PERSON = "PERSON"
    LOCATION = "LOCATION"
    ORGANIZATION = "ORGANIZATION"
    # Secrets
    API_KEY = "API_KEY"
    SECRET = "SECRET"
    # Harmful
    HARMFUL = "HARMFUL"


class DetectTarget(IntFlag):
    """Detection targets for the unified detect() API."""
    PII = 1
    HARMFUL = 2
    SECRET = 4
    ALL = PII | HARMFUL | SECRET

    @classmethod
    def from_value(cls, value: "int | DetectTarget") -> "DetectTarget":
        if isinstance(value, cls):
            return value
        try:
            return cls(int(value))
        except (TypeError, ValueError):
            raise ValueError(
                "targets must be a DetectTarget or int bitmask. "
                "Use DetectTarget.PII | DetectTarget.HARMFUL | DetectTarget.SECRET."
            )


class RedactionStrategy(Enum):
    """Redaction strategies."""
    MASK_ALL = "mask_all"       # ********
    MASK_LAST4 = "mask_last4"   # ****1234
    HASH = "hash"               # [HASH:a1b2c3...]
    TOKEN = "token"             # [REDACTED_EMAIL]

    @classmethod
    def from_value(cls, value: "str | RedactionStrategy") -> "RedactionStrategy":
        """
        Accept either a RedactionStrategy enum or a plain string.

        Unknown strings silently fall back to TOKEN so existing callers
        (and the unified detect() API) don't break on typos.
        """
        if isinstance(value, cls):
            return value
        try:
            return cls(value)
        except ValueError:
            return cls.TOKEN


# ============================================================
# Heuristic Patterns
# ============================================================

# Email pattern
EMAIL_RE = re.compile(
    r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
)

# Phone patterns (US formats)
PHONE_RE = re.compile(
    r'(?:\+?1[-.\s]?)?'  # Optional country code
    r'(?:'
    r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}'  # (123) 456-7890 or 123-456-7890
    r'|'
    r'\d{3}[-.\s]\d{4}'  # 456-7890
    r')\b'
)

# SSN pattern
SSN_RE = re.compile(
    r'\b(?!000|666|9\d{2})\d{3}[-\s]?(?!00)\d{2}[-\s]?(?!0000)\d{4}\b'
)

# Credit card pattern (major cards)
CREDIT_CARD_RE = re.compile(
    r'\b(?:'
    r'4[0-9]{12}(?:[0-9]{3})?|'           # Visa
    r'5[1-5][0-9]{14}|'                    # Mastercard
    r'3[47][0-9]{13}|'                     # Amex
    r'6(?:011|5[0-9]{2})[0-9]{12}|'        # Discover
    r'(?:2131|1800|35\d{3})\d{11}'         # JCB
    r')\b'
    r'|'
    r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b'  # Generic 16-digit with separators
)

# Bank account (basic patterns)
BANK_ACCOUNT_RE = re.compile(
    r'\b(?:'
    r'(?:account|acct)[-\s#:]*\d{8,17}'
    r'|'
    r'(?:routing|aba)[-\s#:]*\d{9}'
    r')\b',
    re.IGNORECASE
)

# Date of birth patterns
DOB_RE = re.compile(
    r'\b(?:'
    r'(?:0?[1-9]|1[0-2])[/\-](0?[1-9]|[12]\d|3[01])[/\-](?:19|20)\d{2}'  # MM/DD/YYYY
    r'|'
    r'(?:19|20)\d{2}[/\-](?:0?[1-9]|1[0-2])[/\-](?:0?[1-9]|[12]\d|3[01])'  # YYYY-MM-DD
    r'|'
    r'(?:0?[1-9]|[12]\d|3[01])[/\-](?:0?[1-9]|1[0-2])[/\-](?:19|20)\d{2}'  # DD/MM/YYYY
    r')\b'
)

# Driver's license (US state patterns - conservative)
# Avoid matching plain phone-like numeric groups unless license context exists.
DRIVERS_LICENSE_RE = re.compile(
    r'\b(?:'
    r'[A-Z]\d{7,8}'  # Common format: A1234567
    r'|'
    r'(?:dl|d\/l|driver(?:\'s)?\s+license|license(?:\s+no)?|lic(?:\s+no)?)'
    r'\s*[:#-]?\s*[A-Z0-9][A-Z0-9\-\s]{5,15}'
    r')\b',
    re.IGNORECASE
)

# Medical Record Number
MRN_RE = re.compile(
    r'\b(?:MRN|MR#|Medical Record)[-\s#:]*[A-Z0-9]{6,12}\b',
    re.IGNORECASE
)

# Address patterns (US)
ADDRESS_RE = re.compile(
    r'\b\d{1,5}\s+(?:[A-Za-z]+\s+){1,4}'
    r'(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Way|Court|Ct|Circle|Cir|Place|Pl)'
    r'\.?\b',
    re.IGNORECASE
)

# Person name patterns (limited accuracy ~30-40%)
# FIX #4: Require a title prefix (Mr/Mrs/Dr/etc.) OR explicit "Name:" context keyword
# to dramatically reduce false positives while keeping recall for clearly-labelled names.
# Plain "FirstName LastName" matches are retained but returned with confidence=0.20
# so callers can filter by confidence threshold if needed.
PERSON_NAME_TITLED_RE = re.compile(
    r'\b(?:Mr|Mrs|Ms|Miss|Dr|Prof|Rev|Capt|Lt|Sgt|Cpl|Pvt)\.?\s+'
    r'[A-Z][a-z]{1,20}(?:\s+[A-Z]\.?\s+)?[A-Z][a-z]{1,20}\b'
)

PERSON_NAME_CONTEXT_RE = re.compile(
    r'(?:(?:name|contact|from|to|cc|bcc|signed\s+by|authored\s+by)\s*[:\-]?\s*)'
    r'([A-Z][a-z]{1,20}(?:\s+[A-Z]\.?\s+)?[A-Z][a-z]{1,20})\b',
    re.IGNORECASE
)

# Low-confidence fallback: bare "First Last" without title/context
# Kept for completeness but flagged with confidence=0.20
PERSON_NAME_BARE_RE = re.compile(
    r'\b[A-Z][a-z]{1,20}\s+(?:[A-Z]\.?\s+)?[A-Z][a-z]{1,20}\b'
)

# ============================================================
# Secrets Patterns (Three-Tier Detection)
# ============================================================

# Tier 1: Structured prefixes (auto-detect)
STRUCTURED_SECRET_PREFIXES = [
    # OpenAI
    (r'sk-[A-Za-z0-9]{32,}', 'openai_api_key'),
    (r'sk-proj-[A-Za-z0-9\-_]{32,}', 'openai_project_key'),
    # AWS
    (r'AKIA[0-9A-Z]{16}', 'aws_access_key'),
    # GitHub
    (r'ghp_[A-Za-z0-9]{36,}', 'github_pat'),
    (r'gho_[A-Za-z0-9]{36,}', 'github_oauth'),
    (r'ghu_[A-Za-z0-9]{36,}', 'github_user'),
    (r'ghs_[A-Za-z0-9]{36,}', 'github_server'),
    (r'ghr_[A-Za-z0-9]{36,}', 'github_refresh'),
    # Stripe
    (r'sk_live_[A-Za-z0-9]{24,}', 'stripe_live_key'),
    (r'sk_test_[A-Za-z0-9]{24,}', 'stripe_test_key'),
    (r'rk_live_[A-Za-z0-9]{24,}', 'stripe_restricted'),
    # Slack
    (r'xox[baprs]-[A-Za-z0-9\-]{10,}', 'slack_token'),
    # Google
    (r'AIza[A-Za-z0-9\-_]{35}', 'google_api_key'),
    # Twilio
    (r'SK[a-f0-9]{32}', 'twilio_api_key'),
    # SendGrid
    (r'SG\.[A-Za-z0-9\-_]{22}\.[A-Za-z0-9\-_]{43}', 'sendgrid_api_key'),
    # npm
    (r'npm_[A-Za-z0-9]{36}', 'npm_token'),
    # PyPI
    (r'pypi-[A-Za-z0-9]{32,}', 'pypi_token'),
    # Anthropic
    (r'sk-ant-[A-Za-z0-9\-_]{32,}', 'anthropic_api_key'),
]

# Compile structured patterns
STRUCTURED_SECRET_PATTERNS = [
    (re.compile(r'\b' + pattern + r'\b'), name)
    for pattern, name in STRUCTURED_SECRET_PREFIXES
]

# Tier 2: AWS Secret Access Key (needs context + entropy)
AWS_SECRET_RE = re.compile(
    r'(?:aws[_\-]?secret[_\-]?(?:access[_\-]?)?key|'
    r'secret[_\-]?access[_\-]?key)\s*[=:]\s*["\']?'
    r'([A-Za-z0-9+/]{40})["\']?',
    re.IGNORECASE
)

# Tier 3: Generic secrets (needs context + entropy)
SECRET_CONTEXT_KEYWORDS = [
    'password', 'passwd', 'pwd', 'secret', 'token', 'api_key', 'apikey',
    'api-key', 'auth', 'credential', 'private_key', 'privatekey', 'access_key',
    'accesskey', 'secret_key', 'secretkey', 'bearer', 'jwt',
]

GENERIC_SECRET_RE = re.compile(
    r'(?:' + '|'.join(SECRET_CONTEXT_KEYWORDS) + r')'
    r'\s*[=:]\s*["\']?'
    r'([A-Za-z0-9+/=\-_]{16,})["\']?',
    re.IGNORECASE
)

# ============================================================
# Harmful Content Patterns
# ============================================================

HARMFUL_PATTERNS = {
    # Toxic/offensive language (broad catch-all)
    'toxic': re.compile(
        r'\b(?:fuck|fucker|fuckhead|motherfucker|shit|shithead|dipshit|'
        r'damn|hell|ass|asshat|bitch|bastard|crap|piss|whore|slut|'
        r'dickhead|asshole|dumbass|jackass|douchebag|moron|idiot|stupid|'
        r'twat|wanker|prick|arsehole|bollocks|tosser|'
        r'dimwit|halfwit|imbecile|buffoon|nitwit|dolt|dunce|schmuck|'
        r'hate|hated|hates|hating|despise|despises|loathe|loathes)\b',
        re.IGNORECASE
    ),

    # Single-word threat verbs (higher severity when combined with target)
    'threat': re.compile(
        r'\b(?:kill|murder|hurt|harm|stab|slash|knife|shoot|snipe|'
        r'attack|destroy|beat|punch|kick|slap|hit|strike|assault|'
        r'rape|torture|mutilate|strangle|choke|bomb|explode|burn|'
        r'lynch|hang|drown|suffocate|poison|maim|wound|behead|'
        r'decapitate|dismember|execute|exterminate|annihilate|'
        r'obliterate|stalk)\b',
        re.IGNORECASE
    ),

    # Explicit threat phrases — highest signal, always high severity
    'threat_phrases': re.compile(
        r'\b(?:going\s+to\s+(?:kill|hurt|harm|attack|destroy|find\s+you)|'
        r'i\s+will\s+(?:kill|hurt|harm|attack|destroy)|'
        r"i'll\s+(?:kill|hurt|harm|attack|destroy)|"
        r'gonna\s+(?:kill|hurt|harm|attack|destroy)|'
        r'want\s+(?:you|to)\s+dead|'
        r'should\s+(?:kill|die|be\s+killed)|'
        r'deserve\s+to\s+(?:die|be\s+killed|suffer)|'
        r'hope\s+you\s+(?:die|get\s+killed|suffer)|'
        r"you\s*(?:\'re|are)\s+(?:dead|finished|done)|"
        r'watch\s+your\s+back|'
        r'i\s+know\s+where\s+you\s+live|'
        r'make\s+you\s+(?:pay|suffer|regret))\b',
        re.IGNORECASE
    ),

    # Personal insults
    'insult': re.compile(
        r'\b(?:stupid|idiot|moron|dumb|retard|loser|pathetic|worthless|'
        r'useless|garbage|trash|scum|vermin|disgusting|repulsive|'
        r'ugly|fat|pig|slob|freak|creep|weirdo|psycho|crazy|insane|'
        r'jerk|prick|schmuck|douchebag|asshat|tool|twit|'
        r'airhead|dimwit|halfwit|imbecile|dolt|nitwit|buffoon)\b',
        re.IGNORECASE
    ),

    # Identity-based hate speech — always high severity
    'identity_hate': re.compile(
        r'\b(?:fag|faggot|dyke|tranny|'
        r'nigger|nigga|coon|spook|'
        r'chink|gook|jap|slope|zipperhead|'
        r'spic|wetback|beaner|gringo|cholo|'
        r'kike|heeb|hymie|'
        r'raghead|towelhead|camel\s*jockey|sand\s*n\w+|paki|'
        r'wop|dago|polak|kraut|mick|'
        r'redskin|injun|halfbreed|mongrel|'
        r'nazi|supremacist|white\s*trash)\b',
        re.IGNORECASE
    ),

    # Obscene/sexual content
    'obscene': re.compile(
        r'\b(?:cock|dick|pussy|vagina|cunt|tits|boobs|titties|'
        r'cum|jizz|anal|blowjob|handjob|rimjob|orgy|dildo|'
        r'porn|masturbate|orgasm|screw|bang|hump|nude|nudes|XXX)\b',
        re.IGNORECASE
    ),

    # Self-harm / suicide — critical for mental health moderation
    'self_harm': re.compile(
        r'\b(?:kill\s+myself|end\s+my\s+life|take\s+my\s+(?:own\s+)?life|'
        r'want\s+to\s+die|wish\s+(?:i\s+were|i\s+was)\s+dead|'
        r'suicide|suicidal|self[\-\s]harm|cut\s+myself|'
        r'overdose\s+on|slit\s+my\s+wrists)\b',
        re.IGNORECASE
    ),

    # Doxxing / personal info threats
    'doxxing': re.compile(
        r'\b(?:dox(?:x)?(?:ing|ed)?|post\s+your\s+(?:address|info|details)|'
        r'leak\s+your\s+(?:info|address|details)|'
        r'expose\s+you(?:r)?|find\s+where\s+you\s+live|'
        r'i\s+know\s+where\s+you\s+live)\b',
        re.IGNORECASE
    ),
}

# Severity ordering (for comparison)
_SEVERITY_ORDER = {'none': 0, 'low': 1, 'medium': 2, 'high': 3}


def _max_severity(a: str, b: str) -> str:
    """Return the higher of two severity strings."""
    return a if _SEVERITY_ORDER[a] >= _SEVERITY_ORDER[b] else b


# ============================================================
# Validators
# ============================================================

def luhn_check(card_number: str) -> bool:
    """Validate credit card number using Luhn algorithm."""
    digits = [int(d) for d in card_number if d.isdigit()]
    if len(digits) < 13 or len(digits) > 19:
        return False

    checksum = 0
    for i, digit in enumerate(reversed(digits)):
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        checksum += digit

    return checksum % 10 == 0


def shannon_entropy(text: str) -> float:
    """Calculate Shannon entropy of a string."""
    if not text:
        return 0.0

    freq = {}
    for char in text:
        freq[char] = freq.get(char, 0) + 1

    length = len(text)
    entropy = 0.0
    for count in freq.values():
        prob = count / length
        entropy -= prob * math.log2(prob)

    return entropy


# ============================================================
# Result Types
# ============================================================

@dataclass
class Detection:
    """Single detection result."""
    type: str
    text: str
    start: int
    end: int
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type,
            "text": self.text,
            "start": self.start,
            "end": self.end,
            "confidence": self.confidence,
            "metadata": self.metadata,
        }


@dataclass
class HarmfulResult:
    """
    Result from detect_harmful_heuristic() / HarmfulContentDetector.classify().

    Kept as its own type (not List[Detection]) because it represents an
    aggregate classification over the whole text rather than a set of
    located spans.
    """
    harmful: bool
    severity: str           # "none" | "low" | "medium" | "high"
    scores: Dict[str, float]  # per-category scores

    def to_dict(self) -> Dict[str, Any]:
        return {
            "harmful": self.harmful,
            "severity": self.severity,
            "scores": self.scores,
        }


@dataclass
class DetectionResult:
    """Unified result from detection - identical structure for both modes."""
    original_text: str
    redacted_text: str
    detections: List[Detection]
    mode: str = "heuristic"  # "heuristic" or "ai"
    harmful: bool = False
    harmful_scores: Dict[str, float] = field(default_factory=dict)
    severity: str = "none"  # "none", "low", "medium", "high"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to full dictionary format."""
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for det in self.detections:
            if det.type not in grouped:
                grouped[det.type] = []
            grouped[det.type].append(det.to_dict())

        return {
            "original_text": self.original_text,
            "redacted_text": self.redacted_text,
            "detections": grouped,
            "detection_count": len(self.detections),
            "mode": self.mode,
            "harmful": self.harmful,
            "harmful_scores": self.harmful_scores,
            "severity": self.severity,
        }

    def get_pii(self) -> List[Detection]:
        """Get only PII detections."""
        pii_types = {
            DetectionType.EMAIL.value, DetectionType.PHONE.value,
            DetectionType.SSN.value, DetectionType.CREDIT_CARD.value,
            DetectionType.BANK_ACCOUNT.value, DetectionType.DOB.value,
            DetectionType.DRIVERS_LICENSE.value, DetectionType.MEDICAL_RECORD_NUMBER.value,
            DetectionType.ADDRESS.value, DetectionType.PERSON.value,
            DetectionType.LOCATION.value, DetectionType.ORGANIZATION.value,
        }
        return [d for d in self.detections if d.type in pii_types]

    def get_secrets(self) -> List[Detection]:
        """Get only secret detections."""
        secret_types = {DetectionType.API_KEY.value, DetectionType.SECRET.value}
        return [d for d in self.detections if d.type in secret_types]


# ============================================================
# Redaction Utilities
# ============================================================

def apply_redaction(
    text: str,
    detection_type: str,
    strategy: RedactionStrategy = RedactionStrategy.TOKEN,
) -> str:
    """Apply redaction to a detected value."""
    if strategy == RedactionStrategy.MASK_ALL:
        return "*" * len(text)
    elif strategy == RedactionStrategy.MASK_LAST4:
        if len(text) > 4:
            return "*" * (len(text) - 4) + text[-4:]
        return "*" * len(text)
    elif strategy == RedactionStrategy.HASH:
        hash_val = hashlib.sha256(text.encode()).hexdigest()[:12]
        return f"[HASH:{hash_val}]"
    else:  # TOKEN
        return f"[REDACTED_{detection_type}]"


def redact_spans(
    text: str,
    detections: List[Detection],
    strategy: "str | RedactionStrategy" = RedactionStrategy.TOKEN,
) -> str:
    """
    Redact all detected spans in text, handling overlaps safely.

    FIX #1 — Overlap-safe redaction:
    The previous implementation sorted by start (descending) and replaced
    spans one-by-one using string slicing.  When two detections overlapped
    (e.g. a bare phone match inside an address match) the second replacement
    used stale character offsets and could corrupt the output or silently
    skip the second span.

    The new algorithm:
      1. Sort detections by (start ASC, end DESC) so that when two spans
         start at the same position the longer one takes priority.
      2. Walk the detections left-to-right, tracking the *cursor* (the end
         of the last written region in the original string).
      3. Overlapping spans (start < cursor) are skipped — the earlier,
         longer span already covers them.  This is consistent with how most
         NER post-processors handle overlaps: first-longest wins.
      4. The result is assembled in a single list join, avoiding repeated
         string concatenation.

    Validates text input before processing.
    Accepts either a RedactionStrategy enum or a plain string.
    """
    from .input_validation import validate_input, HEURISTIC_MODE_CONFIG
    text = validate_input(text, HEURISTIC_MODE_CONFIG)
    if not detections:
        return text

    strategy = RedactionStrategy.from_value(strategy)

    # Sort: primary = start ASC, secondary = end DESC (longer span first on ties)
    sorted_detections = sorted(detections, key=lambda d: (d.start, -d.end))

    parts: List[str] = []
    cursor = 0  # tracks our position in the original string

    for det in sorted_detections:
        if det.start < cursor:
            # This span overlaps with (or is contained within) a span we already
            # processed — skip it so we don't corrupt the output.
            continue
        if det.end <= det.start:
            # Zero-length or inverted span — skip to avoid empty replacements.
            continue

        # Append the gap between the last processed span and this one
        if det.start > cursor:
            parts.append(text[cursor:det.start])

        # Append the redacted replacement
        parts.append(apply_redaction(det.text, det.type, strategy))
        cursor = det.end

    # Append any trailing text after the last detection
    if cursor < len(text):
        parts.append(text[cursor:])

    return "".join(parts)


def find_secrets(text: str) -> List[Dict[str, Any]]:
    """
    Find secrets using three-tier detection.

    Validates input before processing.
    """
    # Import here to avoid circular import (input_validation has no deps)
    from .input_validation import validate_input, HEURISTIC_MODE_CONFIG
    text = validate_input(text, HEURISTIC_MODE_CONFIG)

    secrets = []

    # Tier 1: Structured prefixes
    for pattern, secret_type in STRUCTURED_SECRET_PATTERNS:
        for match in pattern.finditer(text):
            secrets.append({
                "span": match.group(),
                "start": match.start(),
                "end": match.end(),
                "type": secret_type,
                "method": "structured_prefix",
            })

    # Tier 2: AWS Secret Access Key
    for match in AWS_SECRET_RE.finditer(text):
        secret_value = match.group(1)
        if shannon_entropy(secret_value) > 4.0:
            secrets.append({
                "span": match.group(),
                "start": match.start(),
                "end": match.end(),
                "type": "aws_secret_key",
                "method": "context_entropy",
            })

    # Tier 3: Generic secrets with context
    for match in GENERIC_SECRET_RE.finditer(text):
        secret_value = match.group(1)
        if shannon_entropy(secret_value) > 3.5 and len(secret_value) >= 16:
            secrets.append({
                "span": match.group(),
                "start": match.start(),
                "end": match.end(),
                "type": "generic_secret",
                "method": "context_entropy",
            })

    return secrets
