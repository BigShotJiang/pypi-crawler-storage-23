"""
AI-enhanced detection.

NER backend options:
- transformers (default)
- spacy

Harmful content model uses transformers when available; otherwise
heuristic harmful classifier is used as fallback.
"""
import importlib.util
import logging
import threading
import warnings
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union

from .core_patterns import (
    Detection,
    DetectionResult,
    DetectionType,
    HarmfulResult,
    RedactionStrategy,
    redact_spans,
)
from .input_validation import validate_input, AI_MODE_CONFIG
from .heuristic_detectors import (
    _detect_emails_raw,
    _detect_phones_raw,
    _detect_ssns_raw,
    _detect_credit_cards_raw,
    _detect_bank_accounts_raw,
    _detect_dob_raw,
    _detect_drivers_licenses_raw,
    _detect_mrn_raw,
    _detect_addresses_raw,
    _detect_person_names_raw,
    _detect_secrets_raw,
    _detect_harmful_raw,
)

logger = logging.getLogger(__name__)
REQUIRED_HARMFUL_MODEL = "unitary/multilingual-toxic-xlm-roberta"


def _ai_dependency_import_error() -> ImportError:
    return ImportError(
        "AI dependencies not available. "
        "Install with: pip install 'zero_harm_ai_detectors[ai]'"
    )


# ============================================================
# Availability check — uses importlib.util so we never pay the
# cost of importing torch/transformers just to check presence.
# ============================================================

def check_ai_available() -> bool:
    """
    Check if AI dependencies are installed without importing them.

    Uses importlib.util.find_spec() so the check is cheap (~0.1ms)
    regardless of whether the packages are installed.
    """
    return _has_transformers() or _has_spacy()


def _has_transformers() -> bool:
    return (
        importlib.util.find_spec("torch") is not None
        and importlib.util.find_spec("transformers") is not None
    )


def _has_spacy() -> bool:
    return importlib.util.find_spec("spacy") is not None


AI_AVAILABLE: bool = check_ai_available()


# ============================================================
# Configuration
# ============================================================

@dataclass
class AIConfig:
    """Configuration for AI models."""
    backend: str = "transformers"  # "transformers" | "spacy"
    ner_model: str = "dslim/bert-base-NER"
    spacy_model: str = "en_core_web_sm"
    harmful_model: str = REQUIRED_HARMFUL_MODEL
    ner_threshold: float = 0.70
    harmful_threshold: float = 0.5
    device: str = "cpu"   # "cpu" or "cuda"
    max_length: int = 512
    error_handling: str = "raise"  # "raise" | "open" | "closed"


# ============================================================
# NER Detector
# ============================================================

class NERDetector:
    """Named Entity Recognition using transformers."""

    LABEL_MAP = {
        "PER":   DetectionType.PERSON.value,
        "LOC":   DetectionType.LOCATION.value,
        "ORG":   DetectionType.ORGANIZATION.value,
        "B-PER": DetectionType.PERSON.value,
        "I-PER": DetectionType.PERSON.value,
        "B-LOC": DetectionType.LOCATION.value,
        "I-LOC": DetectionType.LOCATION.value,
        "B-ORG": DetectionType.ORGANIZATION.value,
        "I-ORG": DetectionType.ORGANIZATION.value,
    }
    SPACY_LABEL_MAP = {
        "PERSON": DetectionType.PERSON.value,
        "PER": DetectionType.PERSON.value,
        "ORG": DetectionType.ORGANIZATION.value,
        "GPE": DetectionType.LOCATION.value,
        "LOC": DetectionType.LOCATION.value,
    }

    def __init__(self, config: Optional[AIConfig] = None):
        if not AI_AVAILABLE:
            raise ImportError(
                "AI dependencies not available. "
                "Install with: pip install 'zero_harm_ai_detectors[ai]'"
            )
        self.config = config or AIConfig()
        backend = self.config.backend.strip().lower()
        if backend not in {"transformers", "spacy"}:
            raise ValueError("AIConfig.backend must be 'transformers' or 'spacy'.")
        if backend == "transformers" and not _has_transformers():
            raise ImportError(
                "Transformers backend requested but not installed. "
                "Install with: pip install 'zero_harm_ai_detectors[ai]'"
            )
        if backend == "spacy" and not _has_spacy():
            raise ImportError(
                "SpaCy backend requested but not installed. "
                "Install with: pip install 'zero_harm_ai_detectors[ai]'"
            )
        self._pipeline = None
        self._spacy_fallback_pipeline = None

    def _handle_error(self, exc: Exception) -> List[Detection]:
        mode = str(self.config.error_handling).strip().lower()
        if mode not in {"raise", "open", "closed"}:
            raise ValueError(
                "AIConfig.error_handling must be one of: 'raise', 'open', 'closed'."
            )
        if mode == "raise":
            raise RuntimeError("NER inference failed.") from exc

        if mode == "closed":
            logger.warning("NERDetector failed in fail-closed mode: %s", exc)
            return [
                Detection(
                    type=DetectionType.PERSON.value,
                    text="[MODEL_ERROR]",
                    start=0,
                    end=0,
                    confidence=1.0,
                    metadata={
                        "method": "ai_ner",
                        "error": str(exc),
                        "error_component": "ner",
                        "fail_mode": "closed",
                    },
                )
            ]

        logger.warning("NERDetector failed in fail-open mode: %s", exc)
        return []

    @property
    def pipeline(self):
        """Lazy-load the NER pipeline."""
        if self._pipeline is None:
            if self.config.backend == "spacy":
                import spacy
                try:
                    self._pipeline = spacy.load(self.config.spacy_model)
                except OSError as exc:
                    raise OSError(
                        f"Failed to load spaCy model '{self.config.spacy_model}'. "
                        "Install it with: python -m spacy download en_core_web_sm"
                    ) from exc
            else:
                from transformers import pipeline as hf_pipeline
                try:
                    self._pipeline = hf_pipeline(
                        "ner",
                        model=self.config.ner_model,
                        aggregation_strategy="simple",
                        device=0 if self.config.device == "cuda" else -1,
                    )
                except OSError as exc:
                    raise OSError(
                        f"Failed to load NER model '{self.config.ner_model}'. "
                        "This is usually a network error downloading from HuggingFace Hub. "
                        "Check your internet connection or set HF_HUB_OFFLINE=1 to use "
                        "a locally cached model."
                    ) from exc
        return self._pipeline

    @property
    def spacy_fallback_pipeline(self):
        """Lazy-load a spaCy model for fallback when transformers NER fails."""
        if self._spacy_fallback_pipeline is None:
            import spacy
            self._spacy_fallback_pipeline = spacy.load(self.config.spacy_model)
        return self._spacy_fallback_pipeline

    def detect(self, text: str) -> List[Detection]:
        """
        Detect named entities in text.

        Validates input then delegates to _detect_raw().
        """
        text = validate_input(text, AI_MODE_CONFIG)
        return self._detect_raw(text)

    def _detect_raw(self, text: str) -> List[Detection]:
        """
        Detect named entities on pre-validated text.

        Called by AIPipeline.detect() which has already validated the input,
        so we avoid paying the validation cost a second time.
        """
        if not text.strip():
            return []

        try:
            if self.config.backend == "spacy":
                return self._detect_with_spacy(text)
            return self._detect_with_transformers(text)
        except Exception as exc:
            fallback = self._fallback_detect(text, exc)
            if fallback is not None:
                return fallback
            return self._handle_error(exc)

    def _detect_with_transformers(self, text: str) -> List[Detection]:
        detections: List[Detection] = []
        results = self.pipeline(text[: self.config.max_length])
        for entity in results:
            label = entity.get("entity_group", entity.get("entity", ""))
            det_type = self.LABEL_MAP.get(label)
            if det_type and entity["score"] >= self.config.ner_threshold:
                detections.append(Detection(
                    type=det_type,
                    text=entity["word"],
                    start=entity["start"],
                    end=entity["end"],
                    confidence=entity["score"],
                    metadata={"method": "ai_ner", "model": self.config.ner_model},
                ))
        return detections

    def _detect_with_spacy(self, text: str, fallback_mode: bool = False) -> List[Detection]:
        detections: List[Detection] = []
        pipeline = self.spacy_fallback_pipeline if fallback_mode else self.pipeline
        doc = pipeline(text[: self.config.max_length])
        for ent in doc.ents:
            det_type = self.SPACY_LABEL_MAP.get(ent.label_)
            if det_type:
                detections.append(Detection(
                    type=det_type,
                    text=ent.text,
                    start=ent.start_char,
                    end=ent.end_char,
                    confidence=0.85,
                    metadata={
                        "method": "ai_spacy",
                        "model": self.config.spacy_model,
                        "label": ent.label_,
                    },
                ))
        return detections

    def _fallback_detect(self, text: str, root_exc: Exception) -> Optional[List[Detection]]:
        """
        Fallback order for NER failures:
        1) spaCy (if installed and current backend is transformers)
        2) heuristic person-name detector
        """
        if self.config.backend == "transformers" and _has_spacy():
            try:
                detections = self._detect_with_spacy(text, fallback_mode=True)
                for det in detections:
                    det.metadata["fallback_from"] = "transformers"
                logger.warning("Transformer NER failed; falling back to spaCy: %s", root_exc)
                return detections
            except Exception as spacy_exc:
                logger.warning("SpaCy fallback failed after transformer error: %s", spacy_exc)

        try:
            detections = _detect_person_names_raw(text)
            for det in detections:
                det.metadata["method"] = "regex_fallback"
                det.metadata["fallback_from"] = self.config.backend
            logger.warning("AI NER failed; falling back to regex PERSON detection: %s", root_exc)
            return detections
        except Exception as regex_exc:
            logger.warning("Regex fallback failed after AI NER error: %s", regex_exc)
            return None


# ============================================================
# Harmful Content Detector
# ============================================================

class HarmfulContentDetector:
    """Harmful content detection using transformers."""

    def __init__(self, config: Optional[AIConfig] = None):
        if not _has_transformers():
            raise ImportError(
                "Transformers dependencies not available. "
                "Install with: pip install 'zero_harm_ai_detectors[ai]'"
            )
        self.config = config or AIConfig()
        self._pipeline = None

    def _handle_error(self, exc: Exception) -> HarmfulResult:
        mode = str(self.config.error_handling).strip().lower()
        if mode not in {"raise", "open", "closed"}:
            raise ValueError(
                "AIConfig.error_handling must be one of: 'raise', 'open', 'closed'."
            )
        if mode == "raise":
            raise RuntimeError("Harmful-content inference failed.") from exc

        if mode == "closed":
            logger.warning("HarmfulContentDetector failed in fail-closed mode: %s", exc)
            return HarmfulResult(
                harmful=True,
                severity="high",
                scores={"model_error": 1.0},
            )

        logger.warning("HarmfulContentDetector failed in fail-open mode: %s", exc)
        return HarmfulResult(harmful=False, severity="none", scores={})

    @property
    def pipeline(self):
        """Lazy-load the classification pipeline."""
        if self._pipeline is None:
            from transformers import pipeline as hf_pipeline
            try:
                self._pipeline = hf_pipeline(
                    "text-classification",
                    model=self.config.harmful_model,
                    top_k=None,
                    device=0 if self.config.device == "cuda" else -1,
                )
            except OSError as exc:
                raise OSError(
                    f"Failed to load harmful-content model '{self.config.harmful_model}'. "
                    "This is usually a network error downloading from HuggingFace Hub. "
                    "Check your internet connection or set HF_HUB_OFFLINE=1 to use "
                    "a locally cached model."
                ) from exc
        return self._pipeline

    def classify(self, text: str) -> HarmfulResult:
        """
        Classify harmful content in text.

        Returns a HarmfulResult (not a dict and not List[Detection]) because
        this is an aggregate classification, not a set of located spans.
        Validates input then delegates to _classify_raw().

        Returns:
            HarmfulResult with fields: harmful (bool), severity (str), scores (dict)
        """
        text = validate_input(text, AI_MODE_CONFIG)
        return self._classify_raw(text)

    def _classify_raw(self, text: str) -> HarmfulResult:
        """
        Classify harmful content on pre-validated text.

        Called by AIPipeline.detect() which has already validated the input.
        """
        if not text.strip():
            return HarmfulResult(harmful=False, severity="none", scores={})

        try:
            results = self.pipeline(text[: self.config.max_length])

            scores: Dict[str, float] = {}
            max_score = 0.0

            items = results[0] if isinstance(results[0], list) else results
            for item in items:
                label = item["label"].lower()
                score = item["score"]
                scores[label] = score
                if label != "neutral" and score > max_score:
                    max_score = score

            is_harmful = max_score >= self.config.harmful_threshold

            if max_score >= 0.8:
                severity = "high"
            elif max_score >= 0.6:
                severity = "medium"
            elif is_harmful:
                severity = "low"
            else:
                severity = "none"

            return HarmfulResult(harmful=is_harmful, severity=severity, scores=scores)

        except Exception as exc:
            return self._handle_error(exc)


# ============================================================
# AI Pipeline
# ============================================================

class AIPipeline:
    """
    Complete AI detection pipeline.

    Uses AI for: person names, locations, organisations, harmful content.
    Uses heuristic for: email, phone, SSN, credit card, secrets (95%+ accuracy).

    Input is validated once at the top of detect(); sub-components receive
    pre-validated text via internal _*_raw methods to avoid re-validation.
    """

    def __init__(self, ai_config: Optional[AIConfig] = None):
        self.config = ai_config or AIConfig()
        self._ner_detector: Optional[NERDetector] = None
        self._harmful_detector: Optional[HarmfulContentDetector] = None

    @property
    def ner_detector(self) -> NERDetector:
        if self._ner_detector is None:
            self._ner_detector = NERDetector(self.config)
        return self._ner_detector

    @property
    def harmful_detector(self) -> HarmfulContentDetector:
        if self._harmful_detector is None:
            self._harmful_detector = HarmfulContentDetector(self.config)
        return self._harmful_detector

    def _detect_structured_pii(self, text: str) -> List[Detection]:
        """Run heuristic-based structured PII detection on pre-validated text."""
        detections: List[Detection] = []
        detections.extend(_detect_emails_raw(text))
        detections.extend(_detect_phones_raw(text))
        detections.extend(_detect_ssns_raw(text))
        detections.extend(_detect_credit_cards_raw(text))
        detections.extend(_detect_bank_accounts_raw(text))
        detections.extend(_detect_dob_raw(text))
        detections.extend(_detect_drivers_licenses_raw(text))
        detections.extend(_detect_mrn_raw(text))
        detections.extend(_detect_addresses_raw(text))
        return detections

    def detect(
        self,
        text: str,
        detect_pii: bool = True,
        detect_secrets: bool = True,
        detect_harmful: bool = True,
        redaction_strategy: "Union[str, RedactionStrategy]" = RedactionStrategy.TOKEN,
    ) -> DetectionResult:
        """
        Run full AI-enhanced detection.

        Validates input once at entry; sub-components receive pre-validated
        text through internal _*_raw methods, avoiding duplicate validation.

        Args:
            text:               Input text to scan.
            detect_pii:         Whether to detect PII.
            detect_secrets:     Whether to detect secrets/API keys.
            detect_harmful:     Whether to detect harmful content.
            redaction_strategy: How to replace detected content.
                                Accepts either a RedactionStrategy enum or a
                                plain string ("token", "mask_all", etc.).

        Returns:
            DetectionResult with all findings.

        Raises:
            InputValidationError: If text is None or looks like binary data.
            InputTooLongError:    If text exceeds AI_MODE_CONFIG.max_length.
        """
        text = validate_input(text, AI_MODE_CONFIG)
        strategy = RedactionStrategy.from_value(redaction_strategy)

        if not text:
            return DetectionResult(
                original_text="",
                redacted_text="",
                detections=[],
                mode="ai",
            )

        all_detections: List[Detection] = []

        if detect_pii:
            all_detections.extend(self._detect_structured_pii(text))
            # NER uses _detect_raw (pre-validated) to avoid double-validation
            all_detections.extend(self.ner_detector._detect_raw(text))

        if detect_secrets:
            all_detections.extend(_detect_secrets_raw(text))

        harmful_result = HarmfulResult(harmful=False, severity="none", scores={})
        if detect_harmful:
            if self.config.harmful_model != REQUIRED_HARMFUL_MODEL:
                warnings.warn(
                    "Non-default harmful_model configured. "
                    "Best-supported model is "
                    f"'{REQUIRED_HARMFUL_MODEL}'. "
                    "If model loading/inference fails, harmful detection falls back to heuristic.",
                    UserWarning,
                    stacklevel=2,
                )
            if not _has_transformers():
                logger.warning(
                    "Transformers unavailable for AI harmful detection; "
                    "falling back to regex harmful detection."
                )
                harmful_result = _detect_harmful_raw(text)
            else:
                try:
                    harmful_result = self.harmful_detector._classify_raw(text)
                except Exception as exc:
                    logger.warning(
                        "AI harmful detection failed; falling back to regex harmful detection: %s",
                        exc,
                    )
                    harmful_result = _detect_harmful_raw(text)

        # Deduplicate
        seen: set = set()
        unique_detections: List[Detection] = []
        for det in all_detections:
            key = (det.start, det.end, det.type)
            if key not in seen:
                seen.add(key)
                unique_detections.append(det)

        return DetectionResult(
            original_text=text,
            redacted_text=redact_spans(text, unique_detections, strategy),
            detections=unique_detections,
            mode="ai",
            harmful=harmful_result.harmful,
            harmful_scores=harmful_result.scores,
            severity=harmful_result.severity,
        )


# ============================================================
# Module-level singleton + convenience function
# FIX #2 — Thread-safe get_pipeline()
# ============================================================

# The original implementation had a classic double-checked locking gap:
#
#   if _default_pipeline is None:           # Thread A reads None
#       _default_pipeline = AIPipeline()    # Thread B also reads None → two instances
#
# Two consequences:
#   1. Both threads build AIPipeline and download/load the transformer model
#      concurrently — wasting memory and time.
#   2. Subsequent callers may receive different pipeline instances across
#      threads, making behaviour non-deterministic.
#
# The fix uses threading.Lock() with an explicit double-checked locking pattern
# (safe in CPython and explicitly correct in all Python implementations):
#
#   with _pipeline_lock:
#       if _default_pipeline is None:
#           _default_pipeline = AIPipeline()
#
# The outer check before acquiring the lock is a fast-path optimisation: once
# the singleton is initialised (the common case) we avoid the overhead of lock
# acquisition entirely.

_default_pipeline: Optional[AIPipeline] = None
_pipeline_lock: threading.Lock = threading.Lock()


def get_pipeline(ai_config: Optional[AIConfig] = None) -> AIPipeline:
    """
    Return (or create) the shared default AIPipeline.

    Thread-safe: at most one AIPipeline is created even when multiple threads
    call get_pipeline() simultaneously for the first time.

    Args:
        ai_config: Optional AIConfig. If provided, a fresh pipeline is
                   created with the given config (not cached).
    """
    global _default_pipeline

    # Custom config → always return a fresh (uncached) pipeline so the caller
    # gets exactly the configuration they asked for.
    if ai_config is not None:
        return AIPipeline(ai_config)

    # Fast path: singleton already created — no lock needed.
    if _default_pipeline is not None:
        return _default_pipeline

    # Slow path: first initialisation — acquire lock and double-check.
    with _pipeline_lock:
        if _default_pipeline is None:
            if _has_spacy() and not _has_transformers():
                _default_pipeline = AIPipeline(AIConfig(backend="spacy"))
            else:
                # Keep get_pipeline() constructible even when AI deps are missing.
                # Execution-time calls that require unavailable backends will raise.
                _default_pipeline = AIPipeline()
    return _default_pipeline


def detect_all_ai(
    text: str,
    detect_pii: bool = True,
    detect_secrets: bool = True,
    detect_harmful: bool = True,
    redaction_strategy: "Union[str, RedactionStrategy]" = RedactionStrategy.TOKEN,
    ai_config: Optional[AIConfig] = None,
) -> DetectionResult:
    """
    Convenience function for AI detection.

    Validates input via AIPipeline.detect().

    Args:
        text:               Input text to scan.
        detect_pii:         Whether to detect PII.
        detect_secrets:     Whether to detect secrets/API keys.
        detect_harmful:     Whether to detect harmful content.
        redaction_strategy: Redaction strategy (str or RedactionStrategy enum).
        ai_config:          Optional AIConfig.

    Returns:
        DetectionResult
    """
    pipeline = get_pipeline(ai_config)
    return pipeline.detect(
        text,
        detect_pii=detect_pii,
        detect_secrets=detect_secrets,
        detect_harmful=detect_harmful,
        redaction_strategy=redaction_strategy,
    )
