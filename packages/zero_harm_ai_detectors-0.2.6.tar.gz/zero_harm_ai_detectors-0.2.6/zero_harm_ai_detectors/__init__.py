"""
Zero Harm AI Detectors - Privacy & Content Safety Detection Library

Two detection modes:
- HEURISTIC mode: Fast pattern-based detection (1-5ms), 95%+ accuracy on structured data
- AI mode: Transformer-based detection (50-200ms), enhanced accuracy for names/locations/orgs

Usage:
    from zero_harm_ai_detectors import detect

    # Heuristic mode (default) - fast, great for structured data
    result = detect("Email: john@example.com")

    # AI mode - provide ai_config to enable AI backend
    from zero_harm_ai_detectors import AIConfig
    result = detect("Contact John Smith at Microsoft", ai_config=AIConfig())

    # Both return identical DetectionResult format!

File: zero_harm_ai_detectors/__init__.py
"""
from typing import Optional, Union

# ============================================================
# Core Exports (always available)
# ============================================================

from .core_patterns import (
    # Result types
    Detection,
    DetectionResult,
    DetectionType,
    DetectTarget,
    HarmfulResult,
    # Redaction
    RedactionStrategy,
    apply_redaction,
    redact_spans,
    # Validators
    luhn_check,
    shannon_entropy,
    # Pattern exports (for advanced users)
    EMAIL_RE,
    PHONE_RE,
    SSN_RE,
    CREDIT_CARD_RE,
    find_secrets,
)

from .input_validation import (
    validate_input,
    validate_input_soft,
    InputConfig,
    InputValidationError,
    InputTooLongError,
)

# ============================================================
# Heuristic Mode (always available)
# ============================================================

from .heuristic_detectors import (
    # Main function
    detect_all_heuristic,
    # Individual detectors
    detect_emails,
    detect_phones,
    detect_ssns,
    detect_credit_cards,
    detect_bank_accounts,
    detect_dob,
    detect_drivers_licenses,
    detect_mrn,
    detect_addresses,
    detect_person_names_heuristic,
    detect_secrets_heuristic,
    detect_harmful_heuristic,  # returns HarmfulResult
)

# ============================================================
# AI Mode (optional - requires transformers/torch)
# ============================================================

try:
    from .ai_detectors import (
        AI_AVAILABLE,
        check_ai_available,
        AIConfig,
        AIPipeline,
        NERDetector,
        HarmfulContentDetector,
        detect_all_ai,
        get_pipeline,
    )
except ImportError:
    AI_AVAILABLE = False

    def check_ai_available() -> bool:
        return False

    def _raise_ai_import_error() -> None:
        raise ImportError(
            "AI mode requires additional dependencies.\n"
            "Install with: pip install 'zero_harm_ai_detectors[ai]'"
        )

    class AIConfig:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            _raise_ai_import_error()

    class AIPipeline:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            _raise_ai_import_error()

    class NERDetector:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            _raise_ai_import_error()

    class HarmfulContentDetector:  # type: ignore[no-redef]
        def __init__(self, *args, **kwargs):
            _raise_ai_import_error()

    def detect_all_ai(*args, **kwargs):  # type: ignore[no-redef]
        _raise_ai_import_error()

    def get_pipeline(*args, **kwargs):  # type: ignore[no-redef]
        _raise_ai_import_error()


# ============================================================
# Unified API
# ============================================================

def detect(
    text: str,
    targets: "Union[int, DetectTarget]" = DetectTarget.ALL,
    redaction_strategy: "Union[str, RedactionStrategy]" = "token",
    ai_config: Optional["AIConfig"] = None,
) -> DetectionResult:
    """
    Unified detection function - main entry point for the library.

    Args:
        text: Input text to scan.
        targets: Bitmask of detection targets (DetectTarget enum). Example:
                 DetectTarget.PII | DetectTarget.HARMFUL
        ai_config: Optional AIConfig. If provided, AI mode is used. If omitted,
                   heuristic mode is used.
        redaction_strategy: "token", "mask_all", "mask_last4", or "hash".
                            Accepts either a plain string or a RedactionStrategy
                            enum value.  Unknown strings silently fall back to
                            "token".

    Returns:
        DetectionResult with:
            original_text (str)   - Original input
            redacted_text (str)   - Text with sensitive content replaced
            detections (list)     - List of Detection objects
            mode (str)            - "heuristic" or "ai" (auto-selected)
            harmful (bool)        - Whether harmful content was found
            harmful_scores (dict) - Per-category harm scores
            severity (str)        - "none" | "low" | "medium" | "high"

    Raises:
        ValueError:   If targets is not a valid DetectTarget bitmask.
        ImportError:  If ai_config is provided but AI dependencies are not installed.
        InputValidationError: If text is None or looks like binary data.
        InputTooLongError:    If text exceeds the mode's max_length limit.
    """
    target_flags = DetectTarget.from_value(targets)
    detect_pii = bool(target_flags & DetectTarget.PII)
    detect_secrets = bool(target_flags & DetectTarget.SECRET)
    detect_harmful = bool(target_flags & DetectTarget.HARMFUL)

    # Normalize redaction_strategy once here so both branches receive the enum
    strategy = RedactionStrategy.from_value(redaction_strategy)

    if ai_config is not None:
        backend = getattr(ai_config, "backend", "transformers")
        if backend not in {"transformers", "spacy"}:
            raise ValueError("AIConfig.backend must be 'transformers' or 'spacy'.")

        if not AI_AVAILABLE:
            raise ImportError(
                "AI mode requires additional dependencies.\n"
                "Install with: pip install 'zero_harm_ai_detectors[ai]'"
            )
        pipeline = get_pipeline(ai_config)
        return pipeline.detect(
            text,
            detect_pii=detect_pii,
            detect_secrets=detect_secrets,
            detect_harmful=detect_harmful,
            redaction_strategy=strategy,
        )

    return detect_all_heuristic(
        text,
        detect_pii=detect_pii,
        detect_secrets=detect_secrets,
        detect_harmful=detect_harmful,
        redaction_strategy=strategy,
    )


# ============================================================
# Version
# ============================================================

try:
    from ._version import version as __version__
except ImportError:
    try:
        from importlib.metadata import version as _pkg_version
        __version__ = _pkg_version("zero_harm_ai_detectors")
    except Exception:
        __version__ = "0+unknown"


# ============================================================
# Public API
# ============================================================

__all__ = [
    # Main entry point
    "detect",

    # Result types
    "Detection",
    "DetectionResult",
    "DetectionType",
    "DetectTarget",
    "HarmfulResult",

    # Redaction
    "RedactionStrategy",
    "apply_redaction",
    "redact_spans",

    # Input validation
    "validate_input",
    "validate_input_soft",
    "InputConfig",
    "InputValidationError",
    "InputTooLongError",

    # Heuristic mode - individual detectors
    "detect_all_heuristic",
    "detect_emails",
    "detect_phones",
    "detect_ssns",
    "detect_credit_cards",
    "detect_bank_accounts",
    "detect_dob",
    "detect_drivers_licenses",
    "detect_mrn",
    "detect_addresses",
    "detect_person_names_heuristic",
    "detect_secrets_heuristic",
    "detect_harmful_heuristic",

    # AI mode (None if dependencies not installed)
    "AI_AVAILABLE",
    "check_ai_available",
    "AIConfig",
    "AIPipeline",
    "detect_all_ai",
    "get_pipeline",
    "NERDetector",
    "HarmfulContentDetector",

    # Utilities
    "luhn_check",
    "shannon_entropy",
    "find_secrets",

    # Version
    "__version__",
]
