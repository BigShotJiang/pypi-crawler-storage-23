"""
Tests for AI-enhanced detection (mode='ai').

These tests are skipped if AI dependencies are not installed.

Covers:
  #1  HarmfulContentDetector.classify() returns HarmfulResult (not dict)
  #2  ai_config param name is consistent (AIPipeline, get_pipeline, detect_all_ai)
  #4  mode='AI' / mode='Heuristic' (case-insensitive) works via unified detect()
  #5  _detect_raw / _classify_raw exist so AIPipeline avoids double-validation

Regression tests for targeted fixes:
  Fix #2  Thread-safe get_pipeline() — at most one AIPipeline created under
          concurrent first-time calls; custom-config calls bypass the cache.

File: tests/test_ai_detectors.py
"""
import threading
import time
import pytest
from zero_harm_ai_detectors import (
    detect,
    AI_AVAILABLE,
    AIConfig,
    DetectionResult,
    HarmfulResult,
    DetectTarget,
)

# Applied selectively below — only on classes that actually load model weights.
# Structural tests (threading, param names, method existence) run on every CI
# job regardless of whether the [ai] extra is installed.
needs_ai = pytest.mark.skipif(
    not AI_AVAILABLE,
    reason="AI dependencies not installed (pip install zero_harm_ai_detectors[ai])"
)


@needs_ai
class TestAIMode:
    """Tests for AI mode detection."""

    def test_ai_mode_returns_detection_result(self):
        result = detect("Contact John Smith", ai_config=AIConfig(device="cpu"))
        assert isinstance(result, DetectionResult)
        assert result.mode == "ai"

    def test_ai_mode_detects_person_names(self):
        result = detect("Please contact John Smith for assistance", ai_config=AIConfig(device="cpu"))
        persons = [d for d in result.detections if d.type == "PERSON"]
        assert len(persons) >= 1

    def test_ai_mode_detects_locations(self):
        result = detect("Our office is in New York City", ai_config=AIConfig(device="cpu"))
        locations = [d for d in result.detections if d.type == "LOCATION"]
        assert len(locations) >= 1

    def test_ai_mode_detects_organizations(self):
        result = detect("I work at Microsoft", ai_config=AIConfig(device="cpu"))
        orgs = [d for d in result.detections if d.type == "ORGANIZATION"]
        assert len(orgs) >= 1

    def test_ai_mode_still_detects_structured_pii(self):
        result = detect("Email: test@example.com, Phone: 555-123-4567", ai_config=AIConfig(device="cpu"))
        types = {d.type for d in result.detections}
        assert "EMAIL" in types
        assert "PHONE" in types

    def test_ai_mode_detects_secrets(self):
        result = detect("API key: sk-1234567890abcdef1234567890abcdef", ai_config=AIConfig(device="cpu"))
        types = {d.type for d in result.detections}
        assert "API_KEY" in types or "SECRET" in types

    def test_ai_mode_harmful_detection(self):
        result = detect(
            "I hate you so much!",
            ai_config=AIConfig(device="cpu"),
            targets=DetectTarget.HARMFUL,
        )
        assert result.harmful is True or result.severity != "none"

    def test_ai_mode_clean_text(self):
        result = detect(
            "Hello, how are you today?",
            ai_config=AIConfig(device="cpu"),
            targets=DetectTarget.HARMFUL,
        )
        assert result.harmful is False or result.severity == "none"

    def test_ai_mode_mixed_content(self):
        text = """
        Contact: John Smith
        Email: john.smith@example.com
        Company: Acme Corporation
        Location: San Francisco, CA
        """
        result = detect(text, ai_config=AIConfig(device="cpu"))
        types = {d.type for d in result.detections}
        assert "EMAIL" in types
        assert "PERSON" in types or "ORGANIZATION" in types

    def test_ai_mode_redaction(self):
        result = detect("Contact John Smith at john@example.com", ai_config=AIConfig(device="cpu"))
        assert "[REDACTED_" in result.redacted_text


# ============================================================
# AI mode routing
# ============================================================

@needs_ai
class TestAIModeRouting:
    def test_ai_config_enables_ai_mode(self):
        result = detect("Contact John Smith at john@example.com", ai_config=AIConfig(device="cpu"))
        assert result.mode == "ai"


# ============================================================
# Issue #2 — ai_config param name consistency
# ============================================================

@needs_ai
class TestAIConfigParamName:
    """Issue #2: ai_config should be the param name everywhere."""

    def test_detect_accepts_ai_config(self):
        config = AIConfig(ner_threshold=0.9, device="cpu")
        result = detect("Contact John Smith", ai_config=config)
        assert result.mode == "ai"

    def test_get_pipeline_accepts_ai_config(self):
        from zero_harm_ai_detectors import get_pipeline
        config = AIConfig(device="cpu")
        pipeline = get_pipeline(ai_config=config)
        assert pipeline is not None

    def test_detect_all_ai_accepts_ai_config(self):
        from zero_harm_ai_detectors import detect_all_ai
        config = AIConfig(device="cpu")
        result = detect_all_ai("test@example.com", ai_config=config)
        assert isinstance(result, DetectionResult)

    def test_aipipeline_accepts_ai_config(self):
        from zero_harm_ai_detectors import AIPipeline
        config = AIConfig(device="cpu")
        pipeline = AIPipeline(ai_config=config)
        assert pipeline.config is config

    def test_harmful_target_warns_on_custom_harmful_model(self):
        config = AIConfig(harmful_model="bad/model", device="cpu")
        with pytest.warns(UserWarning, match="Non-default harmful_model"):
            result = detect("I hate you", targets=DetectTarget.HARMFUL, ai_config=config)
        assert isinstance(result, DetectionResult)


# ============================================================
# Issue #1 — HarmfulContentDetector.classify() returns HarmfulResult
# ============================================================

@needs_ai
class TestHarmfulContentDetectorClassify:
    """Issue #1: classify() replaces detect() and returns HarmfulResult."""

    def test_classify_returns_harmful_result(self):
        from zero_harm_ai_detectors import HarmfulContentDetector
        detector = HarmfulContentDetector()
        result = detector.classify("I hate you!")
        assert isinstance(result, HarmfulResult)

    def test_classify_has_expected_fields(self):
        from zero_harm_ai_detectors import HarmfulContentDetector
        detector = HarmfulContentDetector()
        result = detector.classify("Hello there!")
        assert hasattr(result, "harmful")
        assert hasattr(result, "severity")
        assert hasattr(result, "scores")


# ============================================================
# Issue #5 — _detect_raw / _classify_raw exist on sub-components
# ============================================================

@needs_ai
class TestRawMethodsExist:
    """
    Issue #5: sub-components expose _*_raw methods so AIPipeline can call them
    directly without double-validation.  Checks both interface and inference.
    """

    def test_ner_detector_has_detect_raw(self):
        from zero_harm_ai_detectors import NERDetector
        detector = NERDetector()
        assert hasattr(detector, "_detect_raw")
        assert callable(detector._detect_raw)

    def test_harmful_detector_has_classify_raw(self):
        from zero_harm_ai_detectors import HarmfulContentDetector
        detector = HarmfulContentDetector()
        assert hasattr(detector, "_classify_raw")
        assert callable(detector._classify_raw)

    def test_ner_detect_raw_returns_list(self):
        from zero_harm_ai_detectors import NERDetector
        detector = NERDetector()
        result = detector._detect_raw("John Smith works at Google")
        assert isinstance(result, list)

    def test_harmful_classify_raw_returns_harmful_result(self):
        from zero_harm_ai_detectors import HarmfulContentDetector
        detector = HarmfulContentDetector()
        result = detector._classify_raw("I hate you!")
        assert isinstance(result, HarmfulResult)


# ============================================================
# Fix #2 — Thread-safe get_pipeline()
# ============================================================

class TestThreadSafeGetPipeline:
    """
    get_pipeline() must create at most one AIPipeline under concurrent calls.

    The original implementation had a double-checked locking gap where two
    threads could both read _default_pipeline as None before either assigned
    it, constructing two separate AIPipeline instances (loading the model
    twice, non-deterministic behaviour across threads).  The fix uses a
    threading.Lock with a double-checked pattern inside the lock.
    """

    def test_sequential_calls_return_same_instance(self):
        """After the first call, every subsequent call returns the same object."""
        import zero_harm_ai_detectors.ai_detectors as _ai_mod
        from zero_harm_ai_detectors.ai_detectors import get_pipeline
        _ai_mod._default_pipeline = None

        p1 = get_pipeline()
        p2 = get_pipeline()
        assert p1 is p2, "get_pipeline() must return the same instance on repeated calls"

        _ai_mod._default_pipeline = None

    def test_custom_config_bypasses_cache(self):
        """A call with ai_config must always return a fresh uncached pipeline."""
        import zero_harm_ai_detectors.ai_detectors as _ai_mod
        from zero_harm_ai_detectors.ai_detectors import get_pipeline, AIConfig
        _ai_mod._default_pipeline = None

        cfg = AIConfig(device="cpu")
        p_custom1 = get_pipeline(ai_config=cfg)
        p_custom2 = get_pipeline(ai_config=cfg)
        p_default = get_pipeline()

        # Two custom-config calls produce different (uncached) instances
        assert p_custom1 is not p_custom2
        # Custom-config pipeline is not the cached default
        assert p_custom1 is not p_default

        _ai_mod._default_pipeline = None

    def test_concurrent_first_call_single_instance(self):
        """
        N threads calling get_pipeline() simultaneously for the first time
        must all receive the identical AIPipeline object, and AIPipeline.__init__
        must be called exactly once.
        """
        import zero_harm_ai_detectors.ai_detectors as _ai_mod
        from zero_harm_ai_detectors.ai_detectors import get_pipeline, AIPipeline

        original_init = AIPipeline.__init__
        created_instances = []
        record_lock = threading.Lock()

        def slow_init(self, ai_config=None):
            with record_lock:
                created_instances.append(self)
            time.sleep(0.02)   # hold the CPU slot so threads actually race
            original_init(self, ai_config)

        AIPipeline.__init__ = slow_init
        _ai_mod._default_pipeline = None

        results = []

        def call_get_pipeline():
            results.append(get_pipeline())

        threads = [threading.Thread(target=call_get_pipeline) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # Restore state
        AIPipeline.__init__ = original_init
        _ai_mod._default_pipeline = None

        unique_ids = set(id(r) for r in results)
        assert len(unique_ids) == 1, (
            f"Expected 1 unique pipeline instance across all threads, got {len(unique_ids)}"
        )
        assert len(created_instances) == 1, (
            f"AIPipeline.__init__ called {len(created_instances)} times; expected exactly 1"
        )

    def test_pipeline_lock_is_lock_like(self):
        """The module must expose a Lock-like object (duck-type check)."""
        import zero_harm_ai_detectors.ai_detectors as _ai_mod
        lock = _ai_mod._pipeline_lock
        assert hasattr(lock, "acquire") and hasattr(lock, "release"), (
            "_pipeline_lock must be a Lock-like object with acquire() and release()"
        )


# ============================================================
# Existing AI Tests (unchanged behaviour)
# ============================================================

@needs_ai
class TestAIConfig:
    def test_custom_config(self):
        config = AIConfig(ner_threshold=0.9, device="cpu")
        result = detect("Contact John Smith", ai_config=config)
        assert result.mode == "ai"

    def test_high_threshold_reduces_detections(self):
        text = "Contact John Smith at Microsoft"
        result_low = detect(text, ai_config=AIConfig(ner_threshold=0.5))
        result_high = detect(text, ai_config=AIConfig(ner_threshold=0.99))
        assert len(result_high.detections) <= len(result_low.detections)


@needs_ai
class TestAIPipeline:
    def test_get_pipeline(self):
        from zero_harm_ai_detectors import get_pipeline
        pipeline = get_pipeline()
        assert pipeline is not None

    def test_pipeline_detect(self):
        from zero_harm_ai_detectors import get_pipeline
        pipeline = get_pipeline()
        result = pipeline.detect("Contact John Smith at john@example.com")
        assert isinstance(result, DetectionResult)
        assert result.mode == "ai"


@needs_ai
class TestAIvsHeuristicComparison:
    def test_both_modes_return_same_structure(self):
        text = "Contact john@example.com"
        result_heuristic = detect(text)
        result_ai = detect(text, ai_config=AIConfig(device="cpu"))
        for attr in ("original_text", "redacted_text", "detections", "mode"):
            assert hasattr(result_heuristic, attr)
            assert hasattr(result_ai, attr)

    def test_ai_detects_more_person_names(self):
        text = "Please contact John Smith or Sarah Johnson for help"
        result_heuristic = detect(text)
        result_ai = detect(text, ai_config=AIConfig(device="cpu"))
        heuristic_persons = [d for d in result_heuristic.detections if d.type == "PERSON"]
        ai_persons = [d for d in result_ai.detections if d.type == "PERSON"]
        assert len(ai_persons) >= len(heuristic_persons) or len(ai_persons) > 0

    def test_structured_pii_same_in_both_modes(self):
        text = "Email: test@example.com, SSN: 123-45-6789"
        result_heuristic = detect(text)
        result_ai = detect(text, ai_config=AIConfig(device="cpu"))
        heuristic_emails = [d for d in result_heuristic.detections if d.type == "EMAIL"]
        ai_emails = [d for d in result_ai.detections if d.type == "EMAIL"]
        assert len(heuristic_emails) == len(ai_emails)


@needs_ai
class TestNERDetector:
    def test_ner_detector_creation(self):
        from zero_harm_ai_detectors import NERDetector, AIConfig
        detector = NERDetector(AIConfig())
        assert detector is not None

    def test_ner_detector_detect(self):
        from zero_harm_ai_detectors import NERDetector
        detector = NERDetector()
        results = detector.detect("John Smith works at Google in Seattle")
        assert isinstance(results, list)
        assert len(results) > 0
