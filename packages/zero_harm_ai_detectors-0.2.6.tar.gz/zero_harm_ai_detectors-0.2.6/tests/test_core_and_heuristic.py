"""
Tests for core patterns, validators, and heuristic detection.

Covers all improvements from the v1.0 audit:
  #1  detect_harmful_heuristic returns HarmfulResult, not a dict
  #2  ai_config param name is consistent across public APIs
  #3  redaction_strategy accepts both str and RedactionStrategy enum
  #4  mode is case-insensitive and whitespace-tolerant
  #5  No double-validation (AIPipeline calls _raw helpers directly)
  #6  AI_AVAILABLE uses importlib (cheap check, no heavy imports)
  #7  field import removed from ai_detectors (code-cleanliness, no runtime test)
  #8  Detection.text is still populated by default (include_match_text=True)

Regression tests for targeted fixes:
  Fix #1  Overlap-safe redaction in redact_spans()
  Fix #3  finditer instead of findall for harmful counting
  Fix #4  Tamed heuristic PERSON detection — reduced false positives + confidence tiers

File: tests/test_core_and_heuristic.py
"""

import pytest
from zero_harm_ai_detectors import (
    # Main API
    detect,
    # Result types
    Detection,
    DetectionResult,
    DetectionType,
    DetectTarget,
    HarmfulResult,
    # Redaction
    RedactionStrategy,
    apply_redaction,
    redact_spans,
    # Individual detectors
    detect_emails,
    detect_phones,
    detect_ssns,
    detect_credit_cards,
    detect_bank_accounts,
    detect_dob,
    detect_addresses,
    detect_person_names_heuristic,
    detect_secrets_heuristic,
    detect_harmful_heuristic,
    detect_all_heuristic,
    # Utilities
    luhn_check,
    shannon_entropy,
    find_secrets,
    # Validation
    validate_input,
    validate_input_soft,
    InputConfig,
    InputValidationError,
    InputTooLongError,
    AI_AVAILABLE,
)
from zero_harm_ai_detectors.core_patterns import redact_spans, apply_redaction


# ============================================================
# Input Validation — validate_input() itself
# ============================================================

class TestValidateInput:
    def test_valid_string_returned_unchanged(self):
        assert validate_input("Hello world") == "Hello world"

    def test_none_raises(self):
        with pytest.raises(InputValidationError):
            validate_input(None)

    def test_too_long_raises(self):
        with pytest.raises(InputTooLongError):
            validate_input("x" * 11, InputConfig(max_length=10))

    def test_null_bytes_stripped(self):
        result = validate_input("Hello\x00World")
        assert "\x00" not in result
        assert "HelloWorld" in result

    def test_soft_truncates_instead_of_raising(self):
        result = validate_input_soft("x" * 20, InputConfig(max_length=10))
        assert len(result) == 10

    def test_line_too_long_raises(self):
        with pytest.raises(InputValidationError):
            validate_input("a" * 101, InputConfig(max_line_length=100))

    def test_non_string_coerced(self):
        result = validate_input(12345)  # type: ignore[arg-type]
        assert result == "12345"


# ============================================================
# Input Validation — at every public individual detector
# ============================================================

class TestDetectorInputValidation:
    """Every exported detect_* function must reject None and overly long input."""

    LONG = "x" * 2_000_000  # Exceeds HEURISTIC_MODE_CONFIG.max_length (1 000 000)

    def test_detect_emails_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_emails(None)  # type: ignore[arg-type]

    def test_detect_emails_rejects_too_long(self):
        with pytest.raises(InputTooLongError):
            detect_emails(self.LONG)

    def test_detect_phones_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_phones(None)  # type: ignore[arg-type]

    def test_detect_ssns_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_ssns(None)  # type: ignore[arg-type]

    def test_detect_credit_cards_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_credit_cards(None)  # type: ignore[arg-type]

    def test_detect_bank_accounts_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_bank_accounts(None)  # type: ignore[arg-type]

    def test_detect_dob_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_dob(None)  # type: ignore[arg-type]

    def test_detect_addresses_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_addresses(None)  # type: ignore[arg-type]

    def test_detect_person_names_heuristic_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_person_names_heuristic(None)  # type: ignore[arg-type]

    def test_detect_secrets_heuristic_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_secrets_heuristic(None)  # type: ignore[arg-type]

    def test_detect_harmful_heuristic_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_harmful_heuristic(None)  # type: ignore[arg-type]

    def test_detect_harmful_heuristic_rejects_too_long(self):
        with pytest.raises(InputTooLongError):
            detect_harmful_heuristic(self.LONG)

    def test_find_secrets_rejects_none(self):
        with pytest.raises(InputValidationError):
            find_secrets(None)  # type: ignore[arg-type]

    def test_redact_spans_rejects_none(self):
        with pytest.raises(InputValidationError):
            redact_spans(None, [])  # type: ignore[arg-type]


class TestOrchestrationValidation:
    """detect_all_heuristic and top-level detect() must also validate."""

    def test_detect_all_heuristic_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect_all_heuristic(None)  # type: ignore[arg-type]

    def test_detect_rejects_none(self):
        with pytest.raises(InputValidationError):
            detect(None)  # type: ignore[arg-type]

    def test_detect_rejects_too_long_heuristic(self):
        with pytest.raises(InputTooLongError):
            detect("x" * 2_000_000)

    def test_detect_strips_null_bytes(self):
        result = detect("Email:\x00 test@example.com")
        assert len(result.detections) >= 1


# ============================================================
# Issue #1 — detect_harmful_heuristic returns HarmfulResult (not dict)
# ============================================================

class TestDetectHarmfulReturnsHarmfulResult:
    """Issue #1: detect_harmful_heuristic returns HarmfulResult, not a dict."""

    def test_returns_harmful_result_type_clean(self):
        result = detect_harmful_heuristic("Hello, how are you today?")
        assert isinstance(result, HarmfulResult), (
            "detect_harmful_heuristic must return HarmfulResult, not a dict"
        )

    def test_returns_harmful_result_type_harmful(self):
        result = detect_harmful_heuristic("I'm going to kill you!")
        assert isinstance(result, HarmfulResult), (
            "detect_harmful_heuristic must return HarmfulResult, not a dict"
        )

    def test_harmful_result_has_expected_fields(self):
        result = detect_harmful_heuristic("You're such a loser!")
        assert hasattr(result, "harmful")
        assert hasattr(result, "severity")
        assert hasattr(result, "scores")

    def test_clean_text_returns_not_harmful(self):
        result = detect_harmful_heuristic("Hello, how are you today?")
        assert result.harmful is False
        assert result.severity == "none"
        assert result.scores == {}

    def test_insult_is_harmful_low(self):
        result = detect_harmful_heuristic("You're such a loser!")
        assert result.harmful is True
        assert result.severity == "low"

    def test_threat_phrase_is_high(self):
        result = detect_harmful_heuristic("I'm going to kill you!")
        assert result.harmful is True
        assert result.severity == "high"

    def test_identity_hate_is_high(self):
        result = detect_harmful_heuristic("You are a faggot")
        assert result.harmful is True
        assert result.severity == "high"

    def test_to_dict_produces_expected_keys(self):
        """HarmfulResult.to_dict() should be dict-compatible for migration."""
        d = detect_harmful_heuristic("You idiot!").to_dict()
        assert set(d.keys()) == {"harmful", "severity", "scores"}

    def test_scores_populated_when_harmful(self):
        result = detect_harmful_heuristic("You idiot!")
        assert len(result.scores) > 0

    def test_scores_empty_when_clean(self):
        assert detect_harmful_heuristic("Nice weather today.").scores == {}


# ============================================================
# Fix #3 — finditer instead of findall for harmful counting
# ============================================================

class TestFinditerHarmfulCounting:
    """
    _detect_harmful_raw must produce correct severity/scores when counting
    pattern matches.  Previously findall() with grouped patterns could
    return captured groups rather than full matches, silently miscounting.
    finditer() is both correct and more memory-efficient.
    """

    def test_single_insult_is_low(self):
        result = detect_harmful_heuristic("You are such a loser.")
        assert result.harmful is True
        assert result.severity == "low"

    def test_two_insults_still_low(self):
        # 1 insult word = total_matches=1 → "low" (< 4 total, no threat)
        result = detect_harmful_heuristic("You are stupid!")
        assert result.harmful is True
        assert result.severity == "low"

    def test_many_matches_escalate_to_high(self):
        # 6+ total matches → high
        text = "stupid idiot moron loser pathetic worthless"
        result = detect_harmful_heuristic(text)
        assert result.harmful is True
        assert result.severity == "high"

    def test_threat_phrase_always_high(self):
        result = detect_harmful_heuristic("I'm going to kill you!")
        assert result.severity == "high"

    def test_identity_hate_always_high(self):
        result = detect_harmful_heuristic("You are a faggot")
        assert result.severity == "high"

    def test_counts_are_accurate_not_inflated(self):
        """
        'kill' appears exactly twice; scores['threat'] must reflect count=2,
        not inflated counts that a findall() group-capture bug would produce.
        """
        result = detect_harmful_heuristic("I will kill and kill again.")
        assert result.harmful is True
        assert "threat" in result.scores
        # score = min(1.0, 0.3 + 2 * 0.20) = 0.70
        expected_score = min(1.0, 0.3 + 2 * 0.20)
        assert abs(result.scores["threat"] - expected_score) < 0.001

    def test_clean_text_returns_no_scores(self):
        result = detect_harmful_heuristic("The weather is lovely today.")
        assert result.harmful is False
        assert result.scores == {}

    def test_scores_dict_only_contains_matched_categories(self):
        """Only categories with at least one match should appear in scores."""
        result = detect_harmful_heuristic("You stupid fool!")
        for cat, score in result.scores.items():
            assert score > 0.0, f"Category '{cat}' in scores but has zero score"

    def test_returns_harmful_result_type(self):
        result = detect_harmful_heuristic("You idiot!")
        assert isinstance(result, HarmfulResult)

    def test_score_capped_at_1_0(self):
        """Extremely repetitive text: score must not exceed 1.0."""
        text = " ".join(["stupid"] * 50)
        result = detect_harmful_heuristic(text)
        for score in result.scores.values():
            assert score <= 1.0, f"Score {score} exceeds maximum 1.0"


class TestRedactionStrategyFlexibility:
    """Issue #3: all public entry points accept str or RedactionStrategy enum."""

    def test_detect_accepts_string_strategy(self):
        result = detect("test@example.com", redaction_strategy="token")
        assert "[REDACTED_EMAIL]" in result.redacted_text

    def test_detect_accepts_enum_strategy(self):
        result = detect("test@example.com", redaction_strategy=RedactionStrategy.TOKEN)
        assert "[REDACTED_EMAIL]" in result.redacted_text

    def test_detect_all_heuristic_accepts_string_strategy(self):
        result = detect_all_heuristic("test@example.com", redaction_strategy="mask_all")
        assert "****" in result.redacted_text

    def test_detect_all_heuristic_accepts_enum_strategy(self):
        result = detect_all_heuristic(
            "test@example.com", redaction_strategy=RedactionStrategy.MASK_ALL
        )
        assert "****" in result.redacted_text

    def test_redact_spans_accepts_string(self):
        dets = [Detection(type="EMAIL", text="a@b.com", start=0, end=7, confidence=0.99)]
        out = redact_spans("a@b.com", dets, "token")
        assert "[REDACTED_EMAIL]" in out

    def test_unknown_string_falls_back_to_token(self):
        result = detect("test@example.com", redaction_strategy="nonexistent")
        assert "[REDACTED_EMAIL]" in result.redacted_text

    def test_from_value_idempotent_with_enum(self):
        """RedactionStrategy.from_value should be idempotent."""
        s = RedactionStrategy.TOKEN
        assert RedactionStrategy.from_value(s) is s


# ============================================================
# Fix #1 — Overlap-safe redaction
# ============================================================

class TestOverlapSafeRedaction:
    """
    redact_spans() must handle overlapping and nested spans without output
    corruption.  The old sort-descending / replace-in-place approach used
    stale character offsets when two spans overlapped, silently corrupting
    output or double-applying a replacement.  The new algorithm walks
    left-to-right with a cursor and skips any span whose start falls inside
    an already-processed region (first-longest wins).
    """

    def _det(self, type_: str, text: str, start: int, end: int, conf: float = 0.99):
        return Detection(type=type_, text=text, start=start, end=end, confidence=conf)

    def test_single_span_basic(self):
        text = "Email: test@example.com"
        dets = [self._det("EMAIL", "test@example.com", 7, 23)]
        assert redact_spans(text, dets, "token") == "Email: [REDACTED_EMAIL]"

    def test_non_overlapping_spans_left_to_right(self):
        text = "a@b.com and c@d.com"
        dets = [
            self._det("EMAIL", "a@b.com", 0, 7),
            self._det("EMAIL", "c@d.com", 12, 19),
        ]
        assert redact_spans(text, dets, "token") == "[REDACTED_EMAIL] and [REDACTED_EMAIL]"

    def test_non_overlapping_spans_reversed_order(self):
        """Spans provided in reverse order must produce identical output."""
        text = "a@b.com and c@d.com"
        dets = [
            self._det("EMAIL", "c@d.com", 12, 19),
            self._det("EMAIL", "a@b.com", 0, 7),
        ]
        assert redact_spans(text, dets, "token") == "[REDACTED_EMAIL] and [REDACTED_EMAIL]"

    def test_contained_span_skipped(self):
        """
        A span fully contained within a longer earlier span must be skipped —
        not double-applied.  Only the outer span's replacement appears.
        """
        text = "123 Main St, call 555-1234 today"
        outer = self._det("ADDRESS", "123 Main St, call 555-1234", 0, 26)
        inner = self._det("PHONE", "555-1234", 17, 25)
        result = redact_spans(text, [outer, inner], "token")
        assert "[REDACTED_ADDRESS]" in result
        assert "[REDACTED_PHONE]" not in result
        assert "today" in result

    def test_partially_overlapping_spans(self):
        """First span wins; the overlapping second span is skipped entirely."""
        text = "ABCDEFGHIJ"
        first  = self._det("TYPE_A", "ABCDE", 0, 5)
        second = self._det("TYPE_B", "CDEFG", 2, 7)
        result = redact_spans(text, [first, second], "token")
        assert "[REDACTED_TYPE_A]" in result
        assert "[REDACTED_TYPE_B]" not in result
        assert result.endswith("HIJ")

    def test_adjacent_spans_both_redacted(self):
        """Spans sharing a boundary (end == next start) are both replaced."""
        text = "AAABBB"
        first  = self._det("TYPE_A", "AAA", 0, 3)
        second = self._det("TYPE_B", "BBB", 3, 6)
        result = redact_spans(text, [first, second], "token")
        assert "[REDACTED_TYPE_A]" in result
        assert "[REDACTED_TYPE_B]" in result

    def test_zero_length_span_skipped(self):
        """A zero-length span (start == end) must not corrupt output."""
        text = "hello world"
        dets = [self._det("GHOST", "", 5, 5)]
        assert redact_spans(text, dets, "token") == "hello world"

    def test_trailing_text_preserved(self):
        text = "Email: a@b.com, and more text after."
        dets = [self._det("EMAIL", "a@b.com", 7, 14)]
        assert redact_spans(text, dets, "token").endswith(", and more text after.")

    def test_leading_text_preserved(self):
        text = "Before: a@b.com"
        dets = [self._det("EMAIL", "a@b.com", 8, 15)]
        assert redact_spans(text, dets, "token").startswith("Before: ")

    def test_mask_all_strategy_overlap(self):
        """mask_all replaces outer span with asterisks; inner is skipped."""
        text = "ABCDEFGHIJ"
        outer = self._det("TYPE_A", "ABCDE", 0, 5)
        inner = self._det("TYPE_B", "CDE",   2, 5)
        assert redact_spans(text, [outer, inner], RedactionStrategy.MASK_ALL) == "*****FGHIJ"

    def test_three_overlapping_spans_only_first_wins(self):
        """Three nested spans — only the outermost wins."""
        text = "AABBBCC"
        outer  = self._det("OUTER",  "AABBBCC", 0, 7)
        middle = self._det("MIDDLE", "ABBB",    1, 5)
        inner  = self._det("INNER",  "BB",      2, 4)
        assert redact_spans(text, [outer, middle, inner], "token") == "[REDACTED_OUTER]"

    def test_multiple_strategies_via_detect(self):
        """End-to-end: both token and mask_all strategies redact without corruption."""
        text = "Email: alice@test.com, phone: 555-123-4567"
        r_token = detect(text, redaction_strategy="token")
        r_mask  = detect(text, redaction_strategy="mask_all")
        assert "alice@test.com" not in r_token.redacted_text
        assert "alice@test.com" not in r_mask.redacted_text
        assert "555-123-4567"   not in r_token.redacted_text
        assert "555-123-4567"   not in r_mask.redacted_text

    def test_no_duplicate_token_for_single_detection(self):
        """A single detection must produce exactly one replacement token."""
        result = detect("SSN: 123-45-6789")
        assert result.redacted_text.count("[REDACTED_SSN]") == 1


# ============================================================
# Target enum normalization
# ============================================================

class TestTargetNormalization:
    def test_targets_enum(self):
        result = detect("test@example.com", targets=DetectTarget.PII)
        assert result.mode == "heuristic"

    def test_targets_bitmask_int(self):
        result = detect("test@example.com", targets=int(DetectTarget.PII))
        assert result.mode == "heuristic"

    def test_invalid_targets_raise(self):
        with pytest.raises(ValueError):
            detect("test@example.com", targets="invalid")  # type: ignore[arg-type]


# ============================================================
# Issue #6 — AI_AVAILABLE check is cheap (importlib-based)
# ============================================================

class TestAIAvailableCheck:
    """Issue #6: check_ai_available() should use importlib, not import torch."""

    def test_check_ai_available_returns_bool(self):
        from zero_harm_ai_detectors import check_ai_available
        result = check_ai_available()
        assert isinstance(result, bool)

    def test_ai_available_is_bool(self):
        from zero_harm_ai_detectors import AI_AVAILABLE
        assert isinstance(AI_AVAILABLE, bool)

    def test_ai_exports_raise_import_error_when_ai_missing(self):
        if AI_AVAILABLE:
            pytest.skip("AI dependencies installed; missing-dependency stub path not active")

        from zero_harm_ai_detectors import detect_all_ai, get_pipeline
        pipeline = get_pipeline()
        assert pipeline is not None
        with pytest.raises(ImportError):
            detect_all_ai("test@example.com")


# ============================================================
# Issue #1 — HarmfulResult is exported from top-level package
# ============================================================

class TestHarmfulResultExport:
    def test_harmful_result_importable(self):
        from zero_harm_ai_detectors import HarmfulResult
        assert HarmfulResult is not None

    def test_harmful_result_instantiable(self):
        r = HarmfulResult(harmful=True, severity="high", scores={"threat": 0.9})
        assert r.harmful is True
        assert r.severity == "high"


# ============================================================
# Validator Tests
# ============================================================

class TestLuhnCheck:
    def test_valid_visa(self):
        assert luhn_check("4532015112830366") is True

    def test_valid_mastercard(self):
        assert luhn_check("5425233430109903") is True

    def test_valid_amex(self):
        assert luhn_check("374245455400126") is True

    def test_invalid_card(self):
        assert luhn_check("1234567890123456") is False

    def test_too_short(self):
        assert luhn_check("123456789") is False


class TestShannonEntropy:
    def test_empty_string(self):
        assert shannon_entropy("") == 0.0

    def test_single_char(self):
        assert shannon_entropy("aaaa") == 0.0

    def test_two_chars(self):
        assert shannon_entropy("ab") == 1.0

    def test_high_entropy(self):
        assert shannon_entropy("aB3$xY9@mK2!") > 3.0

    def test_low_entropy(self):
        assert shannon_entropy("aaaaabbbbb") < 1.5


# ============================================================
# Email Detection
# ============================================================

class TestEmailDetection:
    def test_simple_email(self):
        result = detect_emails("Contact john@example.com")
        assert len(result) == 1
        assert result[0].text == "john@example.com"
        assert result[0].type == "EMAIL"

    def test_multiple_emails(self):
        assert len(detect_emails("Email alice@test.com or bob@example.org")) == 2

    def test_email_with_plus(self):
        result = detect_emails("Use john+tag@example.com")
        assert len(result) == 1
        assert "john+tag@example.com" in result[0].text

    def test_no_email(self):
        assert detect_emails("No email here") == []

    def test_invalid_email_no_tld(self):
        assert detect_emails("Not an email: john@localhost") == []

    def test_empty_string_returns_empty(self):
        assert detect_emails("") == []


# ============================================================
# Phone Detection
# ============================================================

class TestPhoneDetection:
    def test_dashed_phone(self):
        result = detect_phones("Call 555-123-4567")
        assert len(result) == 1
        assert "555-123-4567" in result[0].text

    def test_parentheses_phone(self):
        assert len(detect_phones("Call (555) 123-4567")) == 1

    def test_with_country_code(self):
        assert len(detect_phones("Call +1-555-123-4567")) == 1

    def test_no_phone(self):
        assert detect_phones("No phone here") == []

    def test_phone_not_classified_as_drivers_license(self):
        result = detect("503-730-0669", targets=DetectTarget.PII)
        det_types = {d.type for d in result.detections}
        assert "PHONE" in det_types
        assert "DRIVERS_LICENSE" not in det_types
        assert result.redacted_text == "[REDACTED_PHONE]"


# ============================================================
# SSN Detection
# ============================================================

class TestSSNDetection:
    def test_dashed_ssn(self):
        result = detect_ssns("SSN: 123-45-6789")
        assert len(result) == 1
        assert "123-45-6789" in result[0].text

    def test_invalid_ssn_000(self):
        assert detect_ssns("Invalid: 000-45-6789") == []

    def test_invalid_ssn_666(self):
        assert detect_ssns("Invalid: 666-45-6789") == []

    def test_invalid_ssn_9xx(self):
        assert detect_ssns("Invalid: 900-45-6789") == []


# ============================================================
# Credit Card Detection
# ============================================================

class TestCreditCardDetection:
    def test_valid_visa(self):
        assert len(detect_credit_cards("Card: 4532015112830366")) == 1

    def test_valid_with_dashes(self):
        assert len(detect_credit_cards("Card: 4532-0151-1283-0366")) == 1

    def test_invalid_luhn(self):
        assert detect_credit_cards("Card: 1234567890123456") == []

    def test_valid_mastercard(self):
        assert len(detect_credit_cards("Card: 5425233430109903")) == 1


# ============================================================
# Secrets Detection
# ============================================================

class TestSecretsDetection:
    def test_openai_key(self):
        result = detect_secrets_heuristic("key = sk-1234567890abcdef1234567890abcdef")
        assert len(result) >= 1
        assert any("API_KEY" in d.type or "SECRET" in d.type for d in result)

    def test_github_pat(self):
        assert len(detect_secrets_heuristic("token = ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcd1234")) >= 1

    def test_aws_access_key(self):
        assert len(detect_secrets_heuristic("aws_key = AKIAIOSFODNN7EXAMPLE")) >= 1

    def test_no_secrets_normal_text(self):
        assert detect_secrets_heuristic("The quick brown fox jumps over the lazy dog") == []

    def test_generic_secret_with_context(self):
        assert len(detect_secrets_heuristic("password = AbCdEfGhIjKlMnOpQrStUvWxYz123456")) >= 1


# ============================================================
# Harmful Content Classification
# ============================================================

class TestHarmfulClassification:
    def test_clean_text(self):
        result = detect_harmful_heuristic("Hello, how are you today?")
        assert result.harmful is False
        assert result.severity == "none"
        assert result.scores == {}

    def test_insult_is_low(self):
        result = detect_harmful_heuristic("You're such a loser!")
        assert result.harmful is True
        assert result.severity == "low"

    def test_threat_phrase_is_high(self):
        result = detect_harmful_heuristic("I'm going to kill you!")
        assert result.harmful is True
        assert result.severity == "high"

    def test_identity_hate_is_high(self):
        result = detect_harmful_heuristic("You are a faggot")
        assert result.harmful is True
        assert result.severity == "high"

    def test_profanity_alone_is_low(self):
        result = detect_harmful_heuristic("What the fuck is this?")
        assert result.harmful is True
        assert result.severity == "low"

    def test_multiple_insults_escalate_to_medium(self):
        result = detect_harmful_heuristic("I hate you, you stupid idiot!")
        assert result.harmful is True
        assert result.severity == "medium"

    def test_scores_present_when_harmful(self):
        result = detect_harmful_heuristic("You idiot!")
        assert isinstance(result.scores, dict)
        assert len(result.scores) > 0

    def test_scores_empty_when_clean(self):
        assert detect_harmful_heuristic("Nice weather today.").scores == {}


# ============================================================
# Redaction
# ============================================================

class TestRedaction:
    def test_token_redaction(self):
        assert apply_redaction("test@example.com", "EMAIL", RedactionStrategy.TOKEN) == "[REDACTED_EMAIL]"

    def test_mask_all_redaction(self):
        assert apply_redaction("secret123", "SECRET", RedactionStrategy.MASK_ALL) == "*********"

    def test_mask_last4_redaction(self):
        result = apply_redaction("4532015112830366", "CREDIT_CARD", RedactionStrategy.MASK_LAST4)
        assert result.endswith("0366")
        assert result.startswith("****")

    def test_hash_redaction(self):
        result = apply_redaction("test@example.com", "EMAIL", RedactionStrategy.HASH)
        assert result.startswith("[HASH:")
        assert result.endswith("]")

    def test_redact_spans(self):
        text = "Email: test@example.com"
        detections = [Detection(type="EMAIL", text="test@example.com", start=7, end=23, confidence=0.99)]
        assert redact_spans(text, detections, RedactionStrategy.TOKEN) == "Email: [REDACTED_EMAIL]"

    def test_redact_spans_empty_detections(self):
        assert redact_spans("No PII here", []) == "No PII here"

    def test_redact_spans_string_strategy(self):
        """Issue #3: redact_spans should accept a plain string."""
        dets = [Detection(type="EMAIL", text="a@b.com", start=0, end=7, confidence=0.99)]
        assert redact_spans("a@b.com", dets, "token") == "[REDACTED_EMAIL]"


# ============================================================
# Fix #4 — Tamed PERSON heuristic detection
# ============================================================

class TestPersonNameHeuristicTiers:
    """
    Person name heuristic uses three confidence tiers to reduce false positives.
    Each Detection carries metadata['tier'] in {'titled', 'context', 'bare'}
    and a confidence value from {0.60, 0.45, 0.20} respectively.
    Tiers 1 and 2 suppress overlapping Tier 3 matches.
    """

    # ---- True positives still detected ----

    def test_titled_name_detected(self):
        result = detect_person_names_heuristic("Please contact Dr. Jane Smith for assistance.")
        persons = [d for d in result if d.type == "PERSON"]
        assert any("Jane Smith" in d.text or "Dr" in d.text for d in persons), (
            "Titled name 'Dr. Jane Smith' should be detected"
        )

    def test_titled_name_confidence_high(self):
        result = detect_person_names_heuristic("Please contact Dr. Jane Smith.")
        titled = [d for d in result if d.type == "PERSON" and d.metadata.get("tier") == "titled"]
        assert all(d.confidence >= 0.55 for d in titled)

    def test_context_name_detected(self):
        result = detect_person_names_heuristic("Name: Alice Johnson")
        context = [d for d in result if d.type == "PERSON" and d.metadata.get("tier") == "context"]
        assert len(context) >= 1, "Context-keyword name 'Alice Johnson' should be detected"

    def test_context_name_confidence_medium(self):
        result = detect_person_names_heuristic("Name: Alice Johnson")
        context = [d for d in result if d.type == "PERSON" and d.metadata.get("tier") == "context"]
        assert all(d.confidence >= 0.40 for d in context)

    def test_bare_name_confidence_low(self):
        result = detect_person_names_heuristic("Meet John Smith tomorrow.")
        bare = [d for d in result if d.type == "PERSON" and d.metadata.get("tier") == "bare"]
        if bare:
            assert all(d.confidence <= 0.25 for d in bare)

    # ---- No duplication across tiers ----

    def test_titled_not_duplicated_as_bare(self):
        """A titled span must not also appear as a bare match."""
        result = detect_person_names_heuristic("Prof. Robert Brown lectured today.")
        persons = [d for d in result if d.type == "PERSON"]
        titled_spans = [(d.start, d.end) for d in persons if d.metadata.get("tier") == "titled"]
        bare_spans   = [(d.start, d.end) for d in persons if d.metadata.get("tier") == "bare"]
        for ts in titled_spans:
            for bs in bare_spans:
                assert not (ts[0] < bs[1] and ts[1] > bs[0]), (
                    "Titled span must not overlap with any bare span"
                )

    # ---- False positive reduction ----

    def test_product_name_not_titled(self):
        """Product names must not receive titled-tier confidence."""
        result = detect_person_names_heuristic("Install Visual Studio on your machine.")
        persons = [d for d in result if d.type == "PERSON"]
        for p in persons:
            assert p.confidence <= 0.25, (
                f"'{p.text}' got confidence {p.confidence}; expected ≤ 0.25 for bare match"
            )

    def test_generic_phrase_not_titled(self):
        """Plain two-word capitalized phrase without a title must not be titled-tier."""
        result = detect_person_names_heuristic("Open Source is great.")
        titled = [d for d in result if d.type == "PERSON" and d.metadata.get("tier") == "titled"]
        assert titled == []

    # ---- Metadata contract ----

    def test_tier_key_present_in_metadata(self):
        """Every PERSON detection must carry a 'tier' key."""
        texts = [
            "Dr. Alice Brown arrived.",
            "Contact: Bob White",
            "Meet James Green tomorrow.",
        ]
        for text in texts:
            for d in detect_person_names_heuristic(text):
                if d.type == "PERSON":
                    assert "tier" in d.metadata, f"'{d.text}' missing 'tier' in metadata"

    def test_confidence_values_from_allowed_set(self):
        """Confidence must be one of the three documented values."""
        allowed = {0.20, 0.45, 0.60}
        texts = [
            "Dr. Alice Brown arrived.",
            "Contact: Bob White",
            "Meet James Green tomorrow.",
        ]
        for text in texts:
            for d in detect_person_names_heuristic(text):
                if d.type == "PERSON":
                    assert d.confidence in allowed, (
                        f"confidence {d.confidence} for '{d.text}' not in {allowed}"
                    )

    def test_confidence_propagated_through_detect(self):
        """detect() must preserve per-tier confidence from _detect_person_names_raw."""
        result = detect("Dr. Carol White is here.")
        titled = [d for d in result.detections
                  if d.type == "PERSON" and d.metadata.get("tier") == "titled"]
        if titled:
            assert all(d.confidence >= 0.55 for d in titled)

    # ---- Edge cases ----

    def test_empty_string_no_persons(self):
        assert detect_person_names_heuristic("") == []

    def test_all_lowercase_no_match(self):
        assert detect_person_names_heuristic("john smith is a name.") == []

    def test_single_capitalized_word_no_match(self):
        result = detect_person_names_heuristic("Hello there.")
        persons = [d for d in result if d.type == "PERSON"]
        assert all(len(d.text.split()) > 1 for d in persons)


# ============================================================
# Unified detect() API
# ============================================================

class TestUnifiedDetect:
    def test_default_mode_is_heuristic(self):
        assert detect("test@example.com").mode == "heuristic"

    def test_ai_mode_when_ai_config_provided(self):
        if not AI_AVAILABLE:
            with pytest.raises(ImportError):
                detect("test@example.com", ai_config=object())  # type: ignore[arg-type]
        else:
            from zero_harm_ai_detectors import AIConfig
            assert detect("test@example.com", ai_config=AIConfig(device="cpu")).mode == "ai"

    def test_returns_detection_result(self):
        result = detect("Email: test@example.com")
        assert isinstance(result, DetectionResult)
        assert result.original_text == "Email: test@example.com"
        assert "[REDACTED_EMAIL]" in result.redacted_text
        assert len(result.detections) >= 1

    def test_detect_pii_only(self):
        result = detect(
            "Email: test@example.com, key: sk-abc123def456abc123def456abc123def456",
            targets=DetectTarget.PII,
        )
        types = [d.type for d in result.detections]
        assert "EMAIL" in types
        assert "API_KEY" not in types and "SECRET" not in types

    def test_detect_secrets_only(self):
        result = detect(
            "Email: test@example.com, key: sk-abc123def456abc123def456abc123def456",
            targets=DetectTarget.SECRET,
        )
        assert "EMAIL" not in [d.type for d in result.detections]

    def test_redaction_strategies(self):
        text = "Email: test@example.com"
        assert "[REDACTED_EMAIL]" in detect(text, redaction_strategy="token").redacted_text
        assert "****" in detect(text, redaction_strategy="mask_all").redacted_text

    def test_unknown_redaction_strategy_defaults_to_token(self):
        result = detect("test@example.com", redaction_strategy="nonexistent")
        assert "[REDACTED_EMAIL]" in result.redacted_text

    def test_to_dict_format(self):
        d = detect("Email: test@example.com").to_dict()
        assert all(
            k in d
            for k in (
                "original_text",
                "redacted_text",
                "detections",
                "mode",
                "harmful",
                "severity",
            )
        )
        assert d["mode"] == "heuristic"

    def test_empty_string_returns_empty_result(self):
        result = detect("")
        assert result.original_text == ""
        assert result.detections == []

    def test_ai_config_with_harmful_warns_on_non_default_model(self):
        if not AI_AVAILABLE:
            pytest.skip("AI dependencies required for harmful-model warning path")
        from zero_harm_ai_detectors import AIConfig
        cfg = AIConfig(harmful_model="bad/model")
        with pytest.warns(UserWarning, match="Non-default harmful_model"):
            result = detect("I hate you", targets=DetectTarget.HARMFUL, ai_config=cfg)
        assert isinstance(result.harmful, bool)


class TestDetectAllHeuristic:
    def test_mixed_content(self):
        text = """
        Email: john@example.com
        Phone: 555-123-4567
        SSN: 123-45-6789
        API Key: sk-1234567890abcdef1234567890abcdef
        """
        result = detect_all_heuristic(text)
        types = {d.type for d in result.detections}
        assert "EMAIL" in types
        assert "PHONE" in types
        assert "SSN" in types

    def test_harmful_content_included(self):
        result = detect_all_heuristic("You stupid idiot!", detect_harmful=True)
        assert result.harmful is True
        assert result.severity != "none"

    def test_null_bytes_stripped_before_detection(self):
        result = detect_all_heuristic("Email:\x00 test@example.com")
        assert len(result.detections) >= 1


# ============================================================
# DetectionResult helpers
# ============================================================

class TestDetectionResult:
    def test_get_pii(self):
        result = detect("Email: test@example.com, key: sk-abc123def456abc123def456abc123def456")
        pii = result.get_pii()
        assert any(d.type == "EMAIL" for d in pii)
        assert all(d.type != "API_KEY" for d in pii)

    def test_get_secrets(self):
        result = detect("key: sk-abc123def456abc123def456abc123def456")
        assert isinstance(result.get_secrets(), list)

    def test_to_dict_detections_grouped(self):
        result = detect("Emails: a@b.com, c@d.com")
        d = result.to_dict()
        assert "EMAIL" in d["detections"]
        assert len(d["detections"]["EMAIL"]) == 2

    def test_to_dict_uses_canonical_text_keys(self):
        d = detect("Email: test@example.com").to_dict()
        assert d["original_text"] == "Email: test@example.com"
        assert "original" not in d
        assert "redacted" not in d


# ============================================================
# Edge Cases
# ============================================================

class TestEdgeCases:
    def test_unicode_text(self):
        assert detect("Email: café@example.com") is not None

    def test_special_characters(self):
        assert len(detect("Email: <test@example.com>").detections) >= 1

    def test_overlapping_patterns(self):
        result = detect("Number: 4532-0151-1283-0366")
        assert "CREDIT_CARD" in [d.type for d in result.detections]

    def test_multiple_detections_same_type(self):
        emails = [d for d in detect("Emails: a@b.com, c@d.com, e@f.com").detections if d.type == "EMAIL"]
        assert len(emails) == 3

    def test_whitespace_only_returns_empty(self):
        assert detect("   \n\t  ").detections == []
