# Commercial License Terms

This file describes the commercial licensing path for `zero_harm_ai_detectors`.

## Summary

- The open-source core remains available under the MIT License in `LICENSE`.
- Commercial use under custom enterprise terms is available by separate agreement.

## Commercial Terms

Commercial terms (including support/SLA, warranty, indemnity, private support,
and other contractual requirements) are provided only under a signed commercial
license agreement with Zero Harm AI, LLC.

To request commercial licensing terms, contact:

- `info@scalapps.com`

## Priority of Terms

If you have a signed commercial agreement, that agreement governs your use.
Otherwise, use is governed by the MIT license in `LICENSE`.
