============================= test session starts ==============================
platform darwin -- Python 3.12.9, pytest-9.0.2, pluggy-1.6.0 -- /Users/lokugamh/Documents/solveit/mcptube/.venv/bin/python3.12
cachedir: .pytest_cache
rootdir: /Users/lokugamh/Documents/solveitax/mcptube
configfile: pyproject.toml
plugins: anyio-4.12.1, asyncio-1.3.0
asyncio: mode=Mode.AUTO, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
collecting ... collected 18 items

tests/test_service.py::TestAddVideo::test_add_video PASSED               [  5%]
tests/test_service.py::TestAddVideo::test_add_video_duplicate PASSED     [ 11%]
tests/test_service.py::TestAddVideo::test_add_video_auto_classify PASSED [ 16%]
tests/test_service.py::TestAddVideo::test_add_video_no_llm FAILED        [ 22%]
tests/test_service.py::TestListAndInfo::test_list_videos PASSED          [ 27%]
tests/test_service.py::TestListAndInfo::test_get_info PASSED             [ 33%]
tests/test_service.py::TestListAndInfo::test_get_info_not_found PASSED   [ 38%]
tests/test_service.py::TestRemoveVideo::test_remove_video PASSED         [ 44%]
tests/test_service.py::TestRemoveVideo::test_remove_video_not_found PASSED [ 50%]
tests/test_service.py::TestSearch::test_search PASSED                    [ 55%]
tests/test_service.py::TestSearch::test_search_no_vectorstore PASSED     [ 61%]
tests/test_service.py::TestGetFrame::test_get_frame PASSED               [ 66%]
tests/test_service.py::TestGetFrame::test_get_frame_not_found PASSED     [ 72%]
tests/test_service.py::TestGetFrame::test_get_frame_by_query PASSED      [ 77%]
tests/test_service.py::TestClassify::test_classify_video PASSED          [ 83%]
tests/test_service.py::TestClassify::test_classify_video_no_llm PASSED   [ 88%]
tests/test_service.py::TestReport::test_generate_report PASSED           [ 94%]
tests/test_service.py::TestReport::test_generate_report_no_llm PASSED    [100%]

=================================== FAILURES ===================================
______________________ TestAddVideo.test_add_video_no_llm ______________________

self = <test_service.TestAddVideo object at 0x121ead7f0>
sqlite_repo = <mcptube.storage.sqlite.SQLiteVideoRepository object at 0x1228e2180>
chroma_store = <mcptube.storage.vectorstore.ChromaVectorStore object at 0x122aa6b40>
mock_extractor = <mcptube.ingestion.youtube.YouTubeExtractor object at 0x122aaf170>

    def test_add_video_no_llm(self, sqlite_repo, chroma_store, mock_extractor):
        with patch.dict("os.environ", {}, clear=True):
            from mcptube.llm import LLMClient
            llm = LLMClient()
            svc = McpTubeService(
                repository=sqlite_repo,
                extractor=mock_extractor,
                vectorstore=chroma_store,
                llm_client=llm,
            )
            video = svc.add_video("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
>           assert video.tags == []
E           AssertionError: assert ['AI', 'Machi...', 'Tutorial'] == []
E             
E             Left contains 3 more items, first extra item: 'AI'
E             
E             Full diff:
E             - []
E             + [
E             +     'AI',...
E             
E             ...Full output truncated (3 lines hidden), use '-vv' to show

tests/test_service.py:41: AssertionError
=========================== short test summary info ============================
FAILED tests/test_service.py::TestAddVideo::test_add_video_no_llm - Assertion...
========================= 1 failed, 17 passed in 2.62s =========================
