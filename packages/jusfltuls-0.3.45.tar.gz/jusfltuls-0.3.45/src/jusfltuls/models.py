"""Data models for disk and partition information."""

from dataclasses import dataclass
from typing import Optional, List


@dataclass
class Partition:
    """Represents a disk partition."""
    name: str
    device_path: str
    size: str
    filesystem: str
    snapper_managed: bool = False  # True if this partition has snapper config
    snapper_config: Optional[str] = None  # Config name (e.g., "home", "root")
    snapper_snapshot_count: int = 0  # Number of snapshots
    mountpoint: Optional[str] = None  # Mount point for the partition
    # Btrfs status information
    btrfs_errors: Optional[str] = None  # "OK" or "ERR"
    btrfs_scrub_status: Optional[str] = None  # "xx%" if running, empty otherwise

    def __str__(self) -> str:
        return f"{self.name} ({self.size}, {self.filesystem})"


@dataclass
class Disk:
    """Represents a physical disk."""
    name: str
    device_path: str
    size: str
    disk_type: str  # 'sata', 'nvme', etc.
    partitions: List[Partition]
    # Health information (populated on demand)
    health_status: Optional[str] = None  # "PASSED", "FAILED", "UNKNOWN"
    power_on_hours: Optional[int] = None
    # Short test info
    last_short_test_hours_ago: Optional[int] = None
    short_test_in_progress: bool = False
    short_test_remaining_percent: Optional[int] = None
    # Long test info
    last_long_test_hours_ago: Optional[int] = None
    long_test_in_progress: bool = False
    long_test_remaining_percent: Optional[int] = None
    
    def __str__(self) -> str:
        return f"{self.name} ({self.size})"
    
    def has_health_info(self) -> bool:
        """Check if health information has been loaded."""
        return self.health_status is not None

    def has_test_info(self) -> bool:
        """Check if test information has been loaded."""
        return (self.last_short_test_hours_ago is not None or 
                self.short_test_in_progress or
                self.last_long_test_hours_ago is not None or 
                self.long_test_in_progress)
