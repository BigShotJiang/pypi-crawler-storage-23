<div align="center">

# 🎙️ PayPerTranscript

**Voice-to-Text ohne Abo-Falle**

Hotkey halten → Sprechen → Text erscheint  
*Bezahle nur, was du nutzt: ~0.02¢ pro Transkription*

[![MIT License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://python.org)
[![Windows](https://img.shields.io/badge/platform-Windows-blue.svg)]()

</div>

---

## 💡 Das Problem

Kommerzielle Voice-to-Text Dienste kosten **$12-15/Monat** - egal ob du sie 5 Minuten oder 5 Stunden nutzt.

## ✨ Die Lösung

**PayPerTranscript** nutzt deinen eigenen API-Key. Du zahlst nur für tatsächliche Nutzung:
- **100 Transkriptionen/Tag** = nur **~74 Cent/Monat**
- Kommerzielle Alternative = **$15/Monat**
- **Du sparst über 95%**

**Open Source** · **Keine Telemetrie** · **Dein eigener API-Key**

---

## 🚀 Features

### 🎯 Kernfunktionen
- **Hold-to-Record**: `Ctrl+Win` halten - sprechen - loslassen - fertig
- **Blitzschnell**: 30 Sekunden Audio = 0.14 Sekunden Transkription (via Groq Whisper)
- **Smart Formatting**: WhatsApp bekommt lockere Texte, Outlook professionelle E-Mails
- **Wortliste**: Eigene Namen und Fachbegriffe werden immer korrekt geschrieben

### 📊 Transparenz & Kontrolle
- **Live-Kosten-Dashboard**: Sieh genau, was du verbrauchst
- **Abo-Vergleich**: Wie viel du im Vergleich zu kommerziellen Diensten sparst
- **Session-Historie**: Jede Transkription nachvollziehbar

### 🔒 Privatsphäre
- Dein eigener API-Key - du kontrollierst die Daten
- Keine Telemetrie, kein Tracking
- Audio-Dateien werden automatisch gelöscht
- Open Source unter MIT-Lizenz

---

## 📦 Installation

### Via pip (empfohlen)

```bash
pip install paypertranscript
paypertranscript
```

Beim ersten Start führt dich ein **Setup-Wizard** durch die Konfiguration (2 Minuten).

**Voraussetzungen**: Windows 10/11 · Python 3.12+

### Aus Quellcode

```bash
git clone https://github.com/jxnxts/PayPerTranscript.git
cd PayPerTranscript
pip install -e .
paypertranscript
```

---

<div align="center">

**Bezahle nur, was du wirklich nutzt** 💰

</div>
