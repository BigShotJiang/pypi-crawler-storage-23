﻿"""Provider-Registry für PayPerTranscript.

Factory-Funktionen zum Erstellen von STT- und LLM-Providern
basierend auf dem konfigurierten Provider-Namen.
"""

from paypertranscript.core.logging import get_logger
from paypertranscript.providers.base import AbstractLLMProvider, AbstractSTTProvider, ProviderError

log = get_logger("providers")

# Registrierte Provider-Namen → Lazy-Import-Funktionen
_STT_PROVIDERS: dict[str, type] = {}
_LLM_PROVIDERS: dict[str, type] = {}


def _ensure_registered() -> None:
    """Registriert alle bekannten Provider (lazy, einmalig)."""
    if _STT_PROVIDERS:
        return

    # Groq-Provider importieren und registrieren
    # Import erfolgt lazy um Startup-Zeit zu minimieren
    try:
        from paypertranscript.providers.groq_provider import GroqLLMProvider, GroqSTTProvider

        _STT_PROVIDERS["groq"] = GroqSTTProvider
        _LLM_PROVIDERS["groq"] = GroqLLMProvider
    except ImportError:
        log.debug("Groq-Provider nicht verfügbar (groq SDK nicht installiert)")


def create_stt_provider(provider_name: str, **kwargs: object) -> AbstractSTTProvider:
    """Erstellt einen STT-Provider anhand des Namens.

    Args:
        provider_name: Name des Providers (z.B. "groq").
        **kwargs: Provider-spezifische Argumente.

    Returns:
        Eine Instanz des STT-Providers.

    Raises:
        ProviderError: Wenn der Provider nicht gefunden wird.
    """
    _ensure_registered()
    if provider_name not in _STT_PROVIDERS:
        available = ", ".join(_STT_PROVIDERS.keys()) or "(keine)"
        raise ProviderError(
            f"Unbekannter STT-Provider: '{provider_name}'. "
            f"Verfügbar: {available}"
        )
    return _STT_PROVIDERS[provider_name](**kwargs)


def create_llm_provider(provider_name: str, **kwargs: object) -> AbstractLLMProvider:
    """Erstellt einen LLM-Provider anhand des Namens.

    Args:
        provider_name: Name des Providers (z.B. "groq").
        **kwargs: Provider-spezifische Argumente.

    Returns:
        Eine Instanz des LLM-Providers.

    Raises:
        ProviderError: Wenn der Provider nicht gefunden wird.
    """
    _ensure_registered()
    if provider_name not in _LLM_PROVIDERS:
        available = ", ".join(_LLM_PROVIDERS.keys()) or "(keine)"
        raise ProviderError(
            f"Unbekannter LLM-Provider: '{provider_name}'. "
            f"Verfügbar: {available}"
        )
    return _LLM_PROVIDERS[provider_name](**kwargs)


__all__ = [
    "AbstractSTTProvider",
    "AbstractLLMProvider",
    "ProviderError",
    "create_stt_provider",
    "create_llm_provider",
]
