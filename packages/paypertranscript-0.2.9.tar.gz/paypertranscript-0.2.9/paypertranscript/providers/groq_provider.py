﻿"""GroqCloud API-Provider für PayPerTranscript.

Implementiert STT (Whisper) und LLM-Formatierung über die GroqCloud API.
"""

from collections.abc import Iterator
from pathlib import Path

import groq

from paypertranscript.core.logging import get_logger
from paypertranscript.providers.base import AbstractLLMProvider, AbstractSTTProvider, ProviderError

log = get_logger("providers.groq")


class GroqSTTProvider(AbstractSTTProvider):
    """GroqCloud Whisper STT-Provider.

    Nutzt whisper-large-v3-turbo für Speech-to-Text.
    Der Groq-Client wird einmal instanziiert und wiederverwendet
    (Connection Pooling via httpx).
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "whisper-large-v3-turbo",
    ) -> None:
        self._model = model
        try:
            self._client = groq.Groq(api_key=api_key)
        except groq.GroqError as e:
            raise ProviderError(f"Groq-Client konnte nicht erstellt werden: {e}") from e
        log.info("GroqSTTProvider initialisiert (Modell: %s)", self._model)

    def transcribe(self, audio_path: Path, language: str, prompt: str = "") -> str:
        """Transkribiert eine WAV-Datei via GroqCloud Whisper API."""
        if not audio_path.exists():
            raise ProviderError(f"Audio-Datei nicht gefunden: {audio_path}")

        log.info(
            "STT-Anfrage: %s (Sprache: %s, Modell: %s)",
            audio_path.name,
            language,
            self._model,
        )
        if prompt:
            log.info("STT-Prompt: %s", prompt)

        try:
            with open(audio_path, "rb") as audio_file:
                transcription = self._client.audio.transcriptions.create(
                    model=self._model,
                    file=audio_file,
                    language=language,
                    prompt=prompt,
                    response_format="text",
                    temperature=0.0,
                )
        except groq.AuthenticationError as e:
            raise ProviderError(f"API-Key ungültig: {e}") from e
        except groq.RateLimitError as e:
            raise ProviderError(f"Rate Limit erreicht: {e}") from e
        except groq.APIConnectionError as e:
            raise ProviderError(f"Keine Verbindung zu GroqCloud: {e}") from e
        except groq.APITimeoutError as e:
            raise ProviderError(f"GroqCloud Timeout: {e}") from e
        except groq.APIError as e:
            raise ProviderError(f"GroqCloud API-Fehler: {e}") from e

        # response_format="text" gibt direkt einen String zurück
        text = transcription.strip() if isinstance(transcription, str) else transcription.text.strip()

        log.info("STT-Ergebnis: %d Zeichen", len(text))
        return text


class GroqLLMProvider(AbstractLLMProvider):
    """GroqCloud LLM-Provider für Textformatierung.

    Nutzt openai/gpt-oss-20b für kontextabhängige Formatierung.
    Der Groq-Client wird einmal instanziiert und wiederverwendet.
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "openai/gpt-oss-20b",
        temperature: float | None = None,
    ) -> None:
        self._model = model
        self._temperature = temperature
        self._last_usage: dict[str, int] | None = None
        try:
            self._client = groq.Groq(api_key=api_key)
        except groq.GroqError as e:
            raise ProviderError(f"Groq-Client konnte nicht erstellt werden: {e}") from e
        log.info("GroqLLMProvider initialisiert (Modell: %s, Temperature: %s)", self._model, self._temperature)

    @property
    def last_usage(self) -> dict[str, int] | None:
        """Token-Usage der letzten LLM-Anfrage."""
        return self._last_usage

    def _build_messages(
        self, system_prompt: str, text: str
    ) -> list[dict[str, str]]:
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"<transcript>{text}</transcript>"},
        ]

    def _completion_kwargs(self) -> dict:
        """Baut gemeinsame kwargs für chat.completions.create."""
        kwargs: dict = {}
        if self._temperature is not None:
            kwargs["temperature"] = self._temperature
        return kwargs

    def format_text(self, system_prompt: str, text: str) -> str:
        log.info("LLM-Anfrage (non-streaming, Modell: %s, Temperature: %s)", self._model, self._temperature)
        self._last_usage = None
        try:
            response = self._client.chat.completions.create(
                model=self._model,
                messages=self._build_messages(system_prompt, text),
                stream=False,
                **self._completion_kwargs(),
            )
        except groq.AuthenticationError as e:
            raise ProviderError(f"API-Key ungültig: {e}") from e
        except groq.RateLimitError as e:
            raise ProviderError(f"Rate Limit erreicht: {e}") from e
        except groq.APIConnectionError as e:
            raise ProviderError(f"Keine Verbindung zu GroqCloud: {e}") from e
        except groq.APITimeoutError as e:
            raise ProviderError(f"GroqCloud Timeout: {e}") from e
        except groq.APIError as e:
            raise ProviderError(f"GroqCloud API-Fehler: {e}") from e

        # Usage-Daten erfassen
        if hasattr(response, "usage") and response.usage:
            self._last_usage = {
                "prompt_tokens": response.usage.prompt_tokens or 0,
                "completion_tokens": response.usage.completion_tokens or 0,
            }

        result = response.choices[0].message.content or ""
        result = result.strip()
        log.info("LLM-Ergebnis: %d Zeichen", len(result))
        return result

    def format_text_stream(self, system_prompt: str, text: str) -> Iterator[str]:
        log.info("LLM-Anfrage (streaming, Modell: %s, Temperature: %s)", self._model, self._temperature)
        self._last_usage = None
        try:
            stream = self._client.chat.completions.create(
                model=self._model,
                messages=self._build_messages(system_prompt, text),
                stream=True,
                **self._completion_kwargs(),
            )
        except groq.AuthenticationError as e:
            raise ProviderError(f"API-Key ungültig: {e}") from e
        except groq.RateLimitError as e:
            raise ProviderError(f"Rate Limit erreicht: {e}") from e
        except groq.APIConnectionError as e:
            raise ProviderError(f"Keine Verbindung zu GroqCloud: {e}") from e
        except groq.APITimeoutError as e:
            raise ProviderError(f"GroqCloud Timeout: {e}") from e
        except groq.APIError as e:
            raise ProviderError(f"GroqCloud API-Fehler: {e}") from e

        total_chars = 0
        for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                total_chars += len(delta)
                yield delta
            # Groq streaming: Usage im letzten Chunk via x_groq
            if (
                hasattr(chunk, "x_groq")
                and chunk.x_groq
                and hasattr(chunk.x_groq, "usage")
                and chunk.x_groq.usage
            ):
                usage = chunk.x_groq.usage
                self._last_usage = {
                    "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
                    "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
                }
        log.info("LLM-Stream abgeschlossen: %d Zeichen", total_chars)
