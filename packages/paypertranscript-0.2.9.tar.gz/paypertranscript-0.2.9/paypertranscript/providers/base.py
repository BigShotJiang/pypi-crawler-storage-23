"""Abstrakte Basis-Klassen für API-Provider.

Definiert die Interfaces für STT- und LLM-Provider.
Aktuell nur GroqCloud implementiert - das Interface ermöglicht
zukünftige Erweiterung ohne Refactoring.
"""

from abc import ABC, abstractmethod
from collections.abc import Iterator
from pathlib import Path


class AbstractSTTProvider(ABC):
    """Abstrakte Basis-Klasse für Speech-to-Text Provider."""

    @abstractmethod
    def transcribe(self, audio_path: Path, language: str, prompt: str = "") -> str:
        """Transkribiert eine Audio-Datei zu Text.

        Args:
            audio_path: Pfad zur WAV-Datei.
            language: ISO-639-1 Sprachcode (z.B. "de", "en").
            prompt: Optionaler Prompt mit korrekten Schreibweisen.

        Returns:
            Transkribierter Text.

        Raises:
            ProviderError: Bei API-Fehlern.
        """


class AbstractLLMProvider(ABC):
    """Abstrakte Basis-Klasse für LLM-Formatierungs-Provider."""

    @abstractmethod
    def format_text(self, system_prompt: str, text: str) -> str:
        """Formatiert Text via LLM (non-streaming).

        Args:
            system_prompt: System-Prompt für die Formatierung.
            text: Zu formatierender Rohtext.

        Returns:
            Formatierter Text.

        Raises:
            ProviderError: Bei API-Fehlern.
        """

    @abstractmethod
    def format_text_stream(self, system_prompt: str, text: str) -> Iterator[str]:
        """Formatiert Text via LLM mit Streaming.

        Args:
            system_prompt: System-Prompt für die Formatierung.
            text: Zu formatierender Rohtext.

        Yields:
            Text-Chunks sobald sie verfügbar sind.

        Raises:
            ProviderError: Bei API-Fehlern.
        """

    @property
    def last_usage(self) -> dict[str, int] | None:
        """Token-Usage der letzten Anfrage.

        Returns:
            Dict mit "prompt_tokens" und "completion_tokens" oder None
            wenn keine Usage-Daten verfuegbar sind.
        """
        return None


class ProviderError(Exception):
    """Fehler bei einem API-Provider-Aufruf."""
