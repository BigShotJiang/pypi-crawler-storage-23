"""Transkriptions-Pipeline fuer PayPerTranscript.

Orchestriert: WAV-Datei -> STT -> (optional) LLM-Formatierung -> Text-Einfuegung.
"""

from __future__ import annotations

import threading
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path

import soundfile as sf

from paypertranscript.core.config import ConfigManager
from paypertranscript.core.cost_tracker import calculate_total_cost
from paypertranscript.core.logging import get_logger
from paypertranscript.core.session_logger import SessionLogger
from paypertranscript.core.text_inserter import insert_text, insert_text_streaming
from paypertranscript.core.window_detector import WindowInfo
from paypertranscript.providers.base import AbstractLLMProvider, AbstractSTTProvider, ProviderError

# Status-Strings fuer on_status Callback
STATUS_STT_START = "stt_start"
STATUS_STT_DONE = "stt_done"
STATUS_LLM_START = "llm_start"
STATUS_DONE = "done"
STATUS_ERROR = "error"

log = get_logger("pipeline.transcription")

# Maximale Prompt-Laenge fuer Whisper (224 Tokens).
# Konservative Schaetzung: ~4 Zeichen pro Token fuer gemischten DE/EN Text.
_MAX_PROMPT_CHARS = 896


def _build_word_list_prompt(words: list[str]) -> str:
    """Baut den Wortlisten-Prompt fuer Whisper.

    Format: "Korrekte Schreibweisen: Wort1, Wort2, Wort3"
    Wird auf _MAX_PROMPT_CHARS gekuerzt falls noetig.

    Args:
        words: Liste korrekter Schreibweisen.

    Returns:
        Prompt-String oder leerer String wenn keine Woerter.
    """
    if not words:
        return ""

    prefix = "Correct spellings: "
    word_str = ", ".join(words)
    prompt = prefix + word_str

    if len(prompt) > _MAX_PROMPT_CHARS:
        prompt = prompt[:_MAX_PROMPT_CHARS]
        # Am letzten Komma abschneiden (kein halbes Wort)
        last_comma = prompt.rfind(",")
        if last_comma > len(prefix):
            prompt = prompt[:last_comma]
        log.warning(
            "Wortlisten-Prompt gekuerzt auf %d Zeichen (max %d)",
            len(prompt),
            _MAX_PROMPT_CHARS,
        )

    return prompt


class TranscriptionPipeline:
    """Orchestriert die Transkriptions-Pipeline.

    WAV-Datei + WindowInfo -> STT -> (optional) LLM-Formatierung -> Text-Einfuegung.
    """

    def __init__(
        self,
        stt_provider: AbstractSTTProvider,
        config: ConfigManager,
        llm_provider: AbstractLLMProvider | None = None,
        session_logger: SessionLogger | None = None,
    ) -> None:
        self._stt = stt_provider
        self._llm = llm_provider
        self._config = config
        self._session_logger = session_logger
        self.last_transcription: str | None = None
        log.info(
            "TranscriptionPipeline initialisiert (LLM: %s, Tracking: %s)",
            "aktiv" if llm_provider else "deaktiviert",
            "aktiv" if session_logger else "deaktiviert",
        )

    def _resolve_formatting(self, window: WindowInfo | None) -> tuple[str | None, str]:
        """Loest Window-Mapping auf und gibt System-Prompt + Kategorie-Key zurueck.

        Matching-Reihenfolge:
        1. Exaktes Match auf process_name (z.B. "WhatsApp.Root.exe")
        2. Substring-Match auf window_title, case-insensitive (z.B. "Gmail" matcht
           "Gmail - Google Chrome"). Erster Treffer gewinnt.

        Args:
            window: Info ueber das aktive Fenster.

        Returns:
            Tuple (system_prompt, category_key). Beide koennen leer/None sein.
        """
        if not window or not window.process_name:
            return None, ""

        mappings: dict[str, str] = self._config.get("formatting.window_mappings", {})

        # 1. Exaktes Match auf Prozessname
        category_key = mappings.get(window.process_name, "")

        # 2. Substring-Match auf Fenstertitel (case-insensitive)
        if not category_key and window.window_title:
            title_lower = window.window_title.lower()
            for pattern, cat_key in mappings.items():
                if pattern.lower() in title_lower:
                    category_key = cat_key
                    log.info(
                        "Window-Mapping (Titel-Match): '%s' in '%s' -> '%s'",
                        pattern,
                        window.window_title,
                        cat_key,
                    )
                    break

        if not category_key:
            return None, ""

        categories: dict = self._config.get("formatting.categories", {})
        category = categories.get(category_key)
        if not category or "prompt" not in category:
            log.warning(
                "Kategorie '%s' fuer '%s' nicht gefunden oder ohne Prompt",
                category_key,
                window.process_name,
            )
            return None, category_key

        log.info(
            "Window-Mapping: %s -> Kategorie '%s'",
            window.process_name,
            category_key,
        )
        return category["prompt"], category_key

    def _log_session(
        self,
        audio_duration: float,
        llm_used: bool,
        llm_input_tokens: int,
        llm_output_tokens: int,
        window: WindowInfo | None,
        category_key: str,
    ) -> None:
        """Berechnet Kosten und loggt die Session in tracking.json."""
        if not self._session_logger or audio_duration <= 0:
            return

        cost = calculate_total_cost(
            audio_duration_seconds=audio_duration,
            llm_input_tokens=llm_input_tokens,
            llm_output_tokens=llm_output_tokens,
            llm_model=self._config.get("api.llm_model", ""),
        )

        session_data = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "audio_duration_seconds": round(cost.audio_duration_seconds, 2),
            "billed_seconds": round(cost.billed_seconds, 2),
            "stt_cost_usd": round(cost.stt_cost_usd, 8),
            "stt_model": self._config.get("api.stt_model", "whisper-large-v3-turbo"),
            "llm_used": llm_used,
            "llm_model": self._config.get("api.llm_model", "openai/gpt-oss-20b") if llm_used else "",
            "llm_input_tokens": llm_input_tokens,
            "llm_output_tokens": llm_output_tokens,
            "llm_cost_usd": round(cost.llm_cost_usd, 8),
            "total_cost_usd": round(cost.total_cost_usd, 8),
            "window_process": window.process_name if window else "",
            "window_title": window.window_title if window else "",
            "category": category_key,
            "language": self._config.get("general.language", "de"),
        }

        try:
            self._session_logger.log_session(session_data)
        except Exception as e:
            log.warning("Session konnte nicht geloggt werden: %s", e)

    def process(
        self,
        wav_path: Path,
        window: WindowInfo | None = None,
        on_status: Callable[[str], None] | None = None,
        audio_duration: float | None = None,
    ) -> None:
        """Verarbeitet eine Aufnahme: STT -> (LLM) -> Text-Einfuegung.

        Args:
            wav_path: Pfad zur WAV-Datei.
            window: Info ueber das Fenster bei Aufnahme-Start.
            on_status: Optionaler Callback fuer Status-Updates (UI-Integration).
                       Wird mit STATUS_*-Konstanten aufgerufen.
            audio_duration: Audio-Dauer in Sekunden (fuer Kosten-Tracking).
        """
        def _notify(status: str, detail: str = "") -> None:
            if on_status:
                try:
                    on_status(status, detail)
                except TypeError:
                    try:
                        on_status(status)
                    except Exception:
                        pass
                except Exception:
                    pass

        try:
            # Audio-Dauer: entweder uebergeben oder aus WAV-Datei berechnen
            if audio_duration is None:
                try:
                    info = sf.info(str(wav_path))
                    audio_duration = info.duration
                except Exception:
                    audio_duration = 0.0

            # Sprache und Wortliste aus Config
            language = self._config.get("general.language", "de")
            words = self._config.get("words.misspelled_words", [])
            prompt = _build_word_list_prompt(words)

            # STT-Transkription
            log.info("Pipeline: Starte STT fuer %s", wav_path.name)
            _notify(STATUS_STT_START)
            text = self._stt.transcribe(wav_path, language=language, prompt=prompt)
            _notify(STATUS_STT_DONE)

            if not text:
                log.info("Pipeline: STT lieferte leeren Text - uebersprungen")
                _notify(STATUS_DONE)
                return

            # LLM-Formatierung (falls Window-Mapping existiert)
            system_prompt, category_key = self._resolve_formatting(window)

            llm_used = False
            llm_input_tokens = 0
            llm_output_tokens = 0

            # Helper: Text sicher einfuegen mit Fehlerbehandlung
            insert_ok = True

            def _do_insert(txt: str) -> None:
                nonlocal insert_ok
                self.last_transcription = txt
                try:
                    insert_text(txt)
                except Exception as e:
                    insert_ok = False
                    log.error("Pipeline: Text-Einfuegung fehlgeschlagen: %s", e)
                    _notify(STATUS_ERROR, "Text konnte nicht eingefuegt werden")

            def _do_insert_stream(chunks_iter: object) -> None:
                nonlocal insert_ok
                try:
                    insert_text_streaming(chunks_iter)
                except Exception as e:
                    insert_ok = False
                    log.error("Pipeline: Streaming-Einfuegung fehlgeschlagen: %s", e)
                    _notify(STATUS_ERROR, "Text konnte nicht eingefuegt werden")

            if system_prompt and self._llm:
                _notify(STATUS_LLM_START)
                try:
                    streaming = self._config.get("general.streaming_typing", False)
                    if streaming:
                        log.info("Pipeline: LLM-Formatierung (streaming)")
                        chunks = self._llm.format_text_stream(system_prompt, text)
                        self.last_transcription = text
                        _do_insert_stream(chunks)
                    else:
                        log.info("Pipeline: LLM-Formatierung (non-streaming)")
                        formatted = self._llm.format_text(system_prompt, text)
                        if formatted:
                            text = formatted
                        else:
                            log.warning("Pipeline: LLM lieferte leeren Text - verwende Rohtext")
                        _do_insert(text)

                    llm_used = True
                    usage = self._llm.last_usage
                    if usage:
                        llm_input_tokens = usage.get("prompt_tokens", 0)
                        llm_output_tokens = usage.get("completion_tokens", 0)

                except ProviderError as e:
                    log.warning("Pipeline: LLM-Fehler - Fallback auf Rohtext: %s", e)
                    _do_insert(text)
            else:
                # Kein Mapping oder kein LLM-Provider -> Rohtext direkt einfuegen
                log.info("Pipeline: Fuege Rohtext ein (%d Zeichen)", len(text))
                _do_insert(text)

            if not insert_ok:
                return

            # Kosten berechnen & Session loggen
            self._log_session(
                audio_duration=audio_duration,
                llm_used=llm_used,
                llm_input_tokens=llm_input_tokens,
                llm_output_tokens=llm_output_tokens,
                window=window,
                category_key=category_key,
            )

            _notify(STATUS_DONE)
            log.info(
                "Pipeline: Erfolgreich abgeschlossen fuer %s (Fenster: %s)",
                wav_path.name,
                window.process_name if window else "(unbekannt)",
            )

        except ProviderError as e:
            msg = str(e).split(": ", 1)[0] if ": " in str(e) else str(e)
            log.error("Pipeline: STT-Fehler - %s", e)
            _notify(STATUS_ERROR, msg)
        except Exception as e:
            log.error("Pipeline: Unerwarteter Fehler - %s", e, exc_info=True)
            _notify(STATUS_ERROR, "Unerwarteter Fehler")

    def process_async(
        self,
        wav_path: Path,
        window: WindowInfo | None = None,
        on_status: Callable[[str], None] | None = None,
        audio_duration: float | None = None,
    ) -> threading.Thread:
        """Startet die Pipeline in einem Hintergrund-Thread.

        Args:
            wav_path: Pfad zur WAV-Datei.
            window: Info ueber das Fenster bei Aufnahme-Start.
            on_status: Optionaler Callback fuer Status-Updates.
            audio_duration: Audio-Dauer in Sekunden (fuer Kosten-Tracking).

        Returns:
            Der gestartete Thread (fuer Tests / Monitoring).
        """
        thread = threading.Thread(
            target=self.process,
            args=(wav_path, window, on_status, audio_duration),
            daemon=True,
            name="pipeline-worker",
        )
        thread.start()
        log.debug("Pipeline-Thread gestartet fuer %s", wav_path.name)
        return thread
