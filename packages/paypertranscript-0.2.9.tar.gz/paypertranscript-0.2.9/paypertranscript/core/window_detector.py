"""Foreground-Window-Erkennung für PayPerTranscript.

Erkennt das aktive Fenster (Prozessname + Fenstertitel) via pywin32 + psutil.
Wird bei Aufnahme-Start aufgerufen, um das Fenster für Window-Mapping zu identifizieren.
"""

from dataclasses import dataclass

import psutil
import win32gui
import win32process

from paypertranscript.core.logging import get_logger

log = get_logger("core.window_detector")


@dataclass(frozen=True)
class WindowInfo:
    """Informationen über das aktive Fenster."""

    process_name: str
    window_title: str


def get_foreground_window() -> WindowInfo:
    """Ermittelt Prozessname und Titel des aktiven Vordergrund-Fensters.

    Returns:
        WindowInfo mit process_name und window_title.
        Bei Fehlern werden leere Strings zurückgegeben.
    """
    try:
        hwnd = win32gui.GetForegroundWindow()
        if not hwnd:
            log.debug("Kein Foreground-Window gefunden")
            return WindowInfo(process_name="", window_title="")

        # Fenstertitel
        window_title = win32gui.GetWindowText(hwnd)

        # PID des Fensters ermitteln
        _, pid = win32process.GetWindowThreadProcessId(hwnd)

        # Prozessname via psutil
        try:
            process = psutil.Process(pid)
            process_name = process.name()
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            process_name = ""
            log.debug("Prozessname für PID %d nicht ermittelbar", pid)

        log.debug("Foreground-Window: %s - '%s'", process_name, window_title)
        return WindowInfo(process_name=process_name, window_title=window_title)

    except Exception as e:
        log.warning("Foreground-Window konnte nicht ermittelt werden: %s", e)
        return WindowInfo(process_name="", window_title="")
