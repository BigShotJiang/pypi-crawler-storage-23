"""Sound-Playback & Temp-File-Management für PayPerTranscript.

Sounds werden beim App-Start in den Speicher vorgeladen (kein Disk-I/O während Aufnahme).
WAV-Dateien werden im %APPDATA%-Audio-Verzeichnis gespeichert.
"""

import time
from pathlib import Path

import numpy as np
import sounddevice as sd
import soundfile as sf

from paypertranscript.core.config import AUDIO_DIR
from paypertranscript.core.logging import get_logger
from paypertranscript.core.paths import get_sounds_dir

log = get_logger("core.audio_manager")

SOUNDS_DIR = get_sounds_dir()


class AudioManager:
    """Verwaltet Sound-Playback und temporäre Audio-Dateien."""

    def __init__(self) -> None:
        self._sounds: dict[str, tuple[np.ndarray, int]] = {}
        AUDIO_DIR.mkdir(parents=True, exist_ok=True)

    def _generate_default_sounds(self) -> None:
        """Generiert Standard-Sounds falls keine vorhanden."""
        try:
            SOUNDS_DIR.mkdir(parents=True, exist_ok=True)
        except OSError:
            # Package-Verzeichnis kann read-only sein (z.B. site-packages)
            return

        for name, freq, duration in [("start", 880, 0.08), ("stop", 440, 0.08)]:
            path = SOUNDS_DIR / f"{name}.wav"
            if path.exists():
                continue
            try:
                sr = 44100
                t = np.linspace(0, duration, int(sr * duration), endpoint=False)
                wave = np.sin(2 * np.pi * freq * t).astype(np.float32)
                fade_len = int(sr * 0.01)
                wave[:fade_len] *= np.linspace(0, 1, fade_len).astype(np.float32)
                wave[-fade_len:] *= np.linspace(1, 0, fade_len).astype(np.float32)
                wave *= 0.3
                sf.write(str(path), wave, sr)
                log.info("Standard-Sound generiert: %s", name)
            except Exception as e:
                log.warning("Standard-Sound konnte nicht generiert werden: %s - %s", name, e)

    def preload_sounds(self) -> None:
        """Lädt alle Sound-Dateien aus assets/sounds/ in den Speicher."""
        self._generate_default_sounds()

        if not SOUNDS_DIR.exists():
            log.debug("Sound-Verzeichnis existiert nicht: %s", SOUNDS_DIR)
            return

        for sound_file in SOUNDS_DIR.glob("*.wav"):
            try:
                data, samplerate = sf.read(str(sound_file), dtype="float32")
                self._sounds[sound_file.stem] = (data, samplerate)
                log.debug("Sound vorgeladen: %s (%.1f KB)", sound_file.stem, sound_file.stat().st_size / 1024)
            except Exception as e:
                log.warning("Sound konnte nicht geladen werden: %s - %s", sound_file.name, e)

        if self._sounds:
            log.info("%d Sound(s) vorgeladen", len(self._sounds))
        else:
            log.debug("Keine Sounds zum Vorladen gefunden")

    def play_sound(self, name: str) -> None:
        """Spielt einen vorgeladenen Sound ab (non-blocking).

        Args:
            name: Name des Sounds (ohne .wav Extension).
        """
        if name not in self._sounds:
            log.debug("Sound nicht gefunden: '%s'", name)
            return

        data, samplerate = self._sounds[name]
        try:
            sd.play(data, samplerate)
        except sd.PortAudioError as e:
            log.warning("Sound-Playback fehlgeschlagen: %s - %s", name, e)

    def generate_temp_path(self) -> Path:
        """Generiert einen eindeutigen Pfad für eine temporäre WAV-Datei.

        Returns:
            Pfad im Format: %APPDATA%/PayPerTranscript/audio/rec_<timestamp>.wav
        """
        AUDIO_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        # Millisekunden für Eindeutigkeit
        ms = f"{time.time() % 1:.3f}"[2:]
        filename = f"rec_{timestamp}_{ms}.wav"
        return AUDIO_DIR / filename

    def cleanup_old_files(self, max_age_hours: float) -> int:
        """Löscht Audio-Dateien die älter als max_age_hours sind.

        Args:
            max_age_hours: Maximales Alter in Stunden. 0 = sofort alles löschen.
                          Negative Werte = nichts löschen (Retention deaktiviert).

        Returns:
            Anzahl gelöschter Dateien.
        """
        if max_age_hours < 0:
            return 0

        if not AUDIO_DIR.exists():
            return 0

        now = time.time()
        max_age_seconds = max_age_hours * 3600
        deleted = 0

        for wav_file in AUDIO_DIR.glob("*.wav"):
            try:
                age = now - wav_file.stat().st_mtime
                if age > max_age_seconds:
                    wav_file.unlink()
                    deleted += 1
                    log.debug("Audio-Datei gelöscht: %s (%.1fh alt)", wav_file.name, age / 3600)
            except OSError as e:
                log.warning("Audio-Datei konnte nicht gelöscht werden: %s - %s", wav_file.name, e)

        if deleted:
            log.info("%d alte Audio-Datei(en) gelöscht", deleted)
        return deleted

    @property
    def has_sounds(self) -> bool:
        """Gibt zurück, ob Sounds vorgeladen sind."""
        return bool(self._sounds)
