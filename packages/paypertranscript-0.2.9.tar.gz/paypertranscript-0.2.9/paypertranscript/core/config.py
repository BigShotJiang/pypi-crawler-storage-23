"""Konfigurationsmanagement für PayPerTranscript.

JSON-basiert, Merge-on-Write, Schema-Validierung mit Fallback auf Defaults.
Alle Laufzeit-Daten liegen unter %APPDATA%\\PayPerTranscript\\.
"""

import copy
import json
import os
import sys
from pathlib import Path
from typing import Any

from paypertranscript.core.logging import APPDATA_DIR, get_logger

log = get_logger("core.config")

CONFIG_FILE = APPDATA_DIR / "config.json"
AUDIO_DIR = APPDATA_DIR / "audio"
TRACKING_FILE = APPDATA_DIR / "tracking.json"

DEFAULT_CONFIG: dict[str, Any] = {
    "general": {
        "language": "de",
        "autostart": False,
        "sound_enabled": False,
        "hold_hotkey": ["ctrl", "cmd"],
        "toggle_hotkey": None,
        "streaming_typing": False,
        "overlay_position": "mouse_cursor",
    },
    "api": {
        "provider": "groq",
        "stt_model": "whisper-large-v3-turbo",
        "llm_model": "openai/gpt-oss-20b",
        "llm_temperature": 1.0,
    },
    "words": {
        "misspelled_words": [],
    },
    "formatting": {
        "window_mappings": {
            "WhatsApp.Root.exe": "casual",
            "Telegram.exe": "casual",
            "Discord.exe": "casual",
            "Outlook": "professional",
        },
        "categories": {
            "casual": {
                "name": "Persönlich",
                "prompt": (
                    "Formatiere den folgenden transkribierten Text als lockere "
                    "Chat-Nachricht. Alles kleingeschrieben, minimale Interpunktion, "
                    "Kommas zur Trennung von Gedanken. Kein Punkt am Ende. "
                    "Gib NUR den formatierten Text aus, keine Erklärungen."
                ),
            },
            "professional": {
                "name": "Professionell",
                "prompt": (
                    "Formatiere den folgenden transkribierten Text als professionelle "
                    "Nachricht. Korrekte Groß-/Kleinschreibung, saubere Interpunktion, "
                    "entferne Füllwörter und Wiederholungen. Sachlicher Stil, kurze "
                    "Absätze. Gib NUR den formatierten Text aus, keine Erklärungen."
                ),
            },
        },
    },
    "data": {
        "audio_retention_hours": 24,
        "save_transcripts": False,
    },
    "updates": {
        "auto_update": True,
        "check_interval_hours": 24,
    },
}

# Schema: Erlaubte Typen pro Pfad für Validierung
_SCHEMA: dict[str, type | tuple[type, ...]] = {
    "general.language": str,
    "general.autostart": bool,
    "general.sound_enabled": bool,
    "general.hold_hotkey": list,
    "general.toggle_hotkey": (list, type(None)),
    "general.streaming_typing": bool,
    "general.overlay_position": str,
    "api.provider": str,
    "api.stt_model": str,
    "api.llm_model": str,
    "api.llm_temperature": (int, float),
    "words.misspelled_words": list,
    "formatting.window_mappings": dict,
    "formatting.categories": dict,
    "data.audio_retention_hours": (int, float),
    "data.save_transcripts": bool,
    "updates.auto_update": bool,
    "updates.check_interval_hours": (int, float),
}


# Keys whose dict values represent user data collections (not config structure).
# These are replaced entirely by the user's saved value, not recursively merged,
# so that deletions of default entries persist across restarts.
_REPLACE_KEYS = frozenset({"window_mappings", "categories"})


def _deep_merge(base: dict, override: dict) -> dict:
    """Merge override in base (rekursiv). Gibt neues Dict zurück."""
    result = copy.deepcopy(base)
    for key, value in override.items():
        if (
            key in result
            and isinstance(result[key], dict)
            and isinstance(value, dict)
            and key not in _REPLACE_KEYS
        ):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def _validate_config(config: dict) -> dict:
    """Validiert Config gegen Schema. Ungültige Werte werden durch Defaults ersetzt."""
    validated = copy.deepcopy(config)

    for path, expected_type in _SCHEMA.items():
        parts = path.split(".")
        # Wert aus Config holen
        node = validated
        default_node = DEFAULT_CONFIG
        valid = True
        for part in parts[:-1]:
            if isinstance(node, dict) and part in node:
                node = node[part]
                default_node = default_node[part]
            else:
                valid = False
                break

        if not valid:
            continue

        key = parts[-1]
        if key not in node:
            # Fehlender Wert → Default einsetzen
            node[key] = copy.deepcopy(default_node[key])
            log.warning("Config: Fehlender Wert '%s' → Default verwendet", path)
        elif not isinstance(node[key], expected_type):
            old_val = node[key]
            node[key] = copy.deepcopy(default_node[key])
            log.warning(
                "Config: Ungültiger Typ für '%s' (%s statt %s) → Default verwendet",
                path,
                type(old_val).__name__,
                expected_type,
            )

    return validated


def _ensure_dirs() -> None:
    """Erstellt alle nötigen Verzeichnisse."""
    APPDATA_DIR.mkdir(parents=True, exist_ok=True)
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)


class ConfigManager:
    """Verwaltet die App-Konfiguration.

    - Lädt Config aus JSON (mit Fallback auf Defaults)
    - Merge-on-Write: bestehende Config lesen, neue Werte mergen, schreiben
    - Schema-Validierung bei Load
    """

    def __init__(self) -> None:
        _ensure_dirs()
        self._config: dict[str, Any] = self._load()

    def _load(self) -> dict[str, Any]:
        """Lädt Config aus Datei, merged mit Defaults, validiert."""
        if CONFIG_FILE.exists():
            try:
                raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
                if not isinstance(raw, dict):
                    log.warning("Config-Datei enthält kein Dict → Defaults verwendet")
                    raw = {}
            except (json.JSONDecodeError, OSError) as e:
                log.warning("Config-Datei konnte nicht gelesen werden: %s → Defaults verwendet", e)
                raw = {}
        else:
            log.info("Keine Config-Datei gefunden → Defaults werden verwendet")
            raw = {}

        merged = _deep_merge(DEFAULT_CONFIG, raw)
        validated = _validate_config(merged)
        return validated

    def _save(self) -> None:
        """Speichert aktuelle Config in Datei."""
        _ensure_dirs()
        try:
            CONFIG_FILE.write_text(
                json.dumps(self._config, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            log.debug("Config gespeichert: %s", CONFIG_FILE)
        except OSError as e:
            log.error("Config konnte nicht gespeichert werden: %s", e)

    @property
    def config(self) -> dict[str, Any]:
        """Gibt die komplette Config als Dict zurück (Read-only Kopie)."""
        return copy.deepcopy(self._config)

    def get(self, path: str, default: Any = None) -> Any:
        """Holt einen Wert per Punkt-Pfad (z.B. 'general.language').

        Args:
            path: Punkt-separierter Pfad zum Wert.
            default: Fallback, wenn Pfad nicht existiert.
        """
        node = self._config
        for part in path.split("."):
            if isinstance(node, dict) and part in node:
                node = node[part]
            else:
                return default
        return copy.deepcopy(node)

    def set(self, path: str, value: Any) -> None:
        """Setzt einen Wert per Punkt-Pfad und speichert.

        Merge-on-Write: Liest aktuelle Datei, merged, speichert.

        Args:
            path: Punkt-separierter Pfad (z.B. 'general.language').
            value: Neuer Wert.
        """
        # Aktuellen Stand von Disk lesen (falls von außen geändert)
        if CONFIG_FILE.exists():
            try:
                disk_config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
                if isinstance(disk_config, dict):
                    self._config = _deep_merge(DEFAULT_CONFIG, disk_config)
                    self._config = _validate_config(self._config)
            except (json.JSONDecodeError, OSError):
                pass

        # Wert setzen
        parts = path.split(".")
        node = self._config
        for part in parts[:-1]:
            if part not in node or not isinstance(node[part], dict):
                node[part] = {}
            node = node[part]
        node[parts[-1]] = value

        log.info("Config geändert: %s = %s", path, value)
        self._save()

    def update(self, updates: dict[str, Any]) -> None:
        """Merged ein Dict in die Config und speichert.

        Args:
            updates: Dict mit Werten zum Mergen (gleiche Struktur wie Config).
        """
        self._config = _deep_merge(self._config, updates)
        self._config = _validate_config(self._config)
        self._save()

    def reload(self) -> None:
        """Lädt Config erneut von Disk."""
        self._config = self._load()
        log.info("Config neu geladen")

    def is_first_run(self) -> bool:
        """Prüft ob dies der erste Start ist (keine Config-Datei vorhanden)."""
        return not CONFIG_FILE.exists()

    def save_initial(self) -> None:
        """Speichert die initiale Config (nach Setup-Wizard)."""
        self._save()


# -- API-Key-Speicherung via Windows Credential Manager --

KEYRING_SERVICE = "PayPerTranscript"
KEYRING_ACCOUNT = "groq_api_key"


def save_api_key(api_key: str) -> None:
    """Speichert den API-Key im Windows Credential Manager (keyring)."""
    import keyring

    keyring.set_password(KEYRING_SERVICE, KEYRING_ACCOUNT, api_key)
    log.info("API-Key im Credential Manager gespeichert")


def load_api_key() -> str | None:
    """Lädt den API-Key aus dem Windows Credential Manager (keyring).

    Returns:
        Den API-Key oder None wenn keiner gespeichert ist.
    """
    import keyring

    try:
        key = keyring.get_password(KEYRING_SERVICE, KEYRING_ACCOUNT)
        if key:
            log.debug("API-Key aus Credential Manager geladen")
        return key
    except Exception as e:
        log.warning("Keyring-Zugriff fehlgeschlagen: %s", e)
        return None


# -- Autostart via Windows Startup-Folder --

_STARTUP_DIR = Path(os.environ.get("APPDATA", "")) / (
    r"Microsoft\Windows\Start Menu\Programs\Startup"
)
_SHORTCUT_NAME = "PayPerTranscript.lnk"


def enable_autostart() -> bool:
    """Erstellt Windows-Startup-Shortcut. Returns True bei Erfolg."""
    try:
        import shutil

        import win32com.client  # type: ignore[import-untyped]

        shortcut_path = _STARTUP_DIR / _SHORTCUT_NAME
        shell = win32com.client.Dispatch("WScript.Shell")
        shortcut = shell.CreateShortCut(str(shortcut_path))

        # pip-installiertes GUI-Script suchen
        entry_point = shutil.which("paypertranscript")
        if entry_point:
            shortcut.Targetpath = str(Path(entry_point))
            shortcut.WorkingDirectory = str(Path.home())
            shortcut.Arguments = ""
        else:
            # Fallback: pythonw.exe -m paypertranscript (kein CMD-Fenster)
            python_dir = Path(sys.executable).parent
            pythonw = python_dir / "pythonw.exe"
            if not pythonw.exists():
                log.warning("pythonw.exe nicht gefunden - Fallback auf python.exe")
                pythonw = Path(sys.executable)
            shortcut.Targetpath = str(pythonw)
            shortcut.WorkingDirectory = str(Path.home())
            shortcut.Arguments = "-m paypertranscript"

        shortcut.Description = "PayPerTranscript - Voice-to-Text"
        shortcut.save()
        log.info("Autostart-Shortcut erstellt: %s", shortcut_path)
        return True
    except Exception as e:
        log.error("Autostart konnte nicht aktiviert werden: %s", e)
        return False


def disable_autostart() -> bool:
    """Entfernt Windows-Startup-Shortcut. Returns True bei Erfolg."""
    try:
        shortcut_path = _STARTUP_DIR / _SHORTCUT_NAME
        if shortcut_path.exists():
            shortcut_path.unlink()
            log.info("Autostart-Shortcut entfernt: %s", shortcut_path)
        return True
    except Exception as e:
        log.error("Autostart konnte nicht deaktiviert werden: %s", e)
        return False


def is_autostart_enabled() -> bool:
    """Prüft ob der Autostart-Shortcut existiert."""
    return (_STARTUP_DIR / _SHORTCUT_NAME).exists()
