"""Kostenberechnung fuer PayPerTranscript.

Reine Berechnungsfunktionen fuer STT- und LLM-Kosten.
Keine I/O, keine Seiteneffekte - einfach testbar.
"""

from dataclasses import dataclass

# STT API-Preise (Stand: 2026-02)
STT_PRICE_PER_HOUR_USD = 0.04
STT_MIN_BILLED_SECONDS = 10  # API-seitiges Minimum-Billing

# LLM-Preise pro Modell: (Input USD/M Tokens, Output USD/M Tokens)
LLM_PRICES: dict[str, tuple[float, float]] = {
    "openai/gpt-oss-20b": (0.075, 0.30),
    "openai/gpt-oss-120b": (0.15, 0.60),
    "moonshotai/kimi-k2-instruct-0905": (1.00, 3.00),
}

_DEFAULT_LLM_PRICES = (0.075, 0.30)  # Fallback


@dataclass(frozen=True)
class CostResult:
    """Ergebnis einer Kostenberechnung."""

    audio_duration_seconds: float
    billed_seconds: float
    stt_cost_usd: float
    llm_input_tokens: int
    llm_output_tokens: int
    llm_cost_usd: float
    total_cost_usd: float


def calculate_stt_cost(audio_duration_seconds: float) -> tuple[float, float]:
    """Berechnet STT-Kosten.

    Args:
        audio_duration_seconds: Tatsaechliche Audio-Dauer in Sekunden.

    Returns:
        Tuple (billed_seconds, cost_usd).
    """
    billed = max(audio_duration_seconds, STT_MIN_BILLED_SECONDS)
    cost = billed / 3600.0 * STT_PRICE_PER_HOUR_USD
    return billed, cost


def calculate_llm_cost(
    input_tokens: int, output_tokens: int, model: str = "",
) -> float:
    """Berechnet LLM-Kosten.

    Args:
        input_tokens: Anzahl Input-Tokens.
        output_tokens: Anzahl Output-Tokens.
        model: LLM-Modellname fuer modellspezifische Preise.

    Returns:
        Kosten in USD.
    """
    input_price, output_price = LLM_PRICES.get(model, _DEFAULT_LLM_PRICES)
    return (
        input_tokens * input_price + output_tokens * output_price
    ) / 1_000_000


def calculate_total_cost(
    audio_duration_seconds: float,
    llm_input_tokens: int = 0,
    llm_output_tokens: int = 0,
    llm_model: str = "",
) -> CostResult:
    """Berechnet Gesamtkosten einer Transkription.

    Args:
        audio_duration_seconds: Audio-Dauer in Sekunden.
        llm_input_tokens: LLM Input-Tokens (0 wenn kein LLM).
        llm_output_tokens: LLM Output-Tokens (0 wenn kein LLM).
        llm_model: LLM-Modellname fuer modellspezifische Preise.

    Returns:
        CostResult mit allen Kosten-Details.
    """
    billed, stt_cost = calculate_stt_cost(audio_duration_seconds)
    llm_cost = calculate_llm_cost(llm_input_tokens, llm_output_tokens, llm_model)
    return CostResult(
        audio_duration_seconds=audio_duration_seconds,
        billed_seconds=billed,
        stt_cost_usd=stt_cost,
        llm_input_tokens=llm_input_tokens,
        llm_output_tokens=llm_output_tokens,
        llm_cost_usd=llm_cost,
        total_cost_usd=stt_cost + llm_cost,
    )


