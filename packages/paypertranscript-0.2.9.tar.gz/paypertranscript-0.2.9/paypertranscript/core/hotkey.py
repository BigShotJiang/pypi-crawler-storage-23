﻿"""Globaler Hotkey-Listener für PayPerTranscript.

Nutzt pynput für systemweite Hotkey-Erkennung.
Unterstützt Hold-to-Record und Toggle-Modus.
"""

import threading
from collections.abc import Callable
from typing import Any

from pynput import keyboard

from paypertranscript.core.logging import get_logger

log = get_logger("core.hotkey")

# Mapping von Config-Strings zu pynput-Keys
_KEY_MAP: dict[str, keyboard.Key | str] = {
    "ctrl": keyboard.Key.ctrl_l,
    "ctrl_l": keyboard.Key.ctrl_l,
    "ctrl_r": keyboard.Key.ctrl_r,
    "shift": keyboard.Key.shift_l,
    "shift_l": keyboard.Key.shift_l,
    "shift_r": keyboard.Key.shift_r,
    "alt": keyboard.Key.alt_l,
    "alt_l": keyboard.Key.alt_l,
    "alt_r": keyboard.Key.alt_r,
    "cmd": keyboard.Key.cmd,
    "win": keyboard.Key.cmd,
    "cmd_l": keyboard.Key.cmd_l,
    "cmd_r": keyboard.Key.cmd_r,
    "space": keyboard.Key.space,
    "tab": keyboard.Key.tab,
    "caps_lock": keyboard.Key.caps_lock,
    "f1": keyboard.Key.f1,
    "f2": keyboard.Key.f2,
    "f3": keyboard.Key.f3,
    "f4": keyboard.Key.f4,
    "f5": keyboard.Key.f5,
    "f6": keyboard.Key.f6,
    "f7": keyboard.Key.f7,
    "f8": keyboard.Key.f8,
    "f9": keyboard.Key.f9,
    "f10": keyboard.Key.f10,
    "f11": keyboard.Key.f11,
    "f12": keyboard.Key.f12,
}

# Keys die als Modifier gelten (haben links/rechts Varianten)
_MODIFIER_GROUPS: dict[str, set[keyboard.Key]] = {
    "ctrl": {keyboard.Key.ctrl_l, keyboard.Key.ctrl_r},
    "shift": {keyboard.Key.shift_l, keyboard.Key.shift_r},
    "alt": {keyboard.Key.alt_l, keyboard.Key.alt_r},
    "cmd": {keyboard.Key.cmd, keyboard.Key.cmd_l, keyboard.Key.cmd_r},
}

# Alt-Keys fuer Menu-Bar-Workaround (Windows aktiviert Menueleiste bei bare Alt-Release)
_ALT_KEYS: set[keyboard.Key] = {keyboard.Key.alt_l, keyboard.Key.alt_r}


def _resolve_key(key_str: str) -> keyboard.Key | keyboard.KeyCode:
    """Löst einen Config-String in ein pynput-Key-Objekt auf."""
    lower = key_str.lower().strip()
    if lower in _KEY_MAP:
        return _KEY_MAP[lower]
    # Einzelner Buchstabe/Zeichen
    if len(lower) == 1:
        return keyboard.KeyCode.from_char(lower)
    raise ValueError(f"Unbekannter Key: '{key_str}'")


def _is_modifier(key: keyboard.Key | keyboard.KeyCode) -> bool:
    """Prüft ob ein Key ein Modifier ist."""
    for group in _MODIFIER_GROUPS.values():
        if key in group:
            return True
    return False


def _get_modifier_group(key_str: str) -> set[keyboard.Key] | None:
    """Gibt die Modifier-Gruppe für einen Config-String zurück."""
    lower = key_str.lower().strip()
    # Direkte Zuordnung
    if lower in _MODIFIER_GROUPS:
        return _MODIFIER_GROUPS[lower]
    # Auch "win" → "cmd"
    if lower == "win":
        return _MODIFIER_GROUPS["cmd"]
    return None


class HotkeyListener:
    """Globaler Hotkey-Listener mit Hold-to-Record und Toggle-Modus.

    Callbacks:
        on_hold_start: Wird aufgerufen wenn Hold-Hotkey gedrückt wird.
        on_hold_stop: Wird aufgerufen wenn Hold-Hotkey losgelassen wird.
        on_toggle: Wird aufgerufen wenn Toggle-Hotkey gedrückt wird.
    """

    def __init__(
        self,
        hold_hotkey: list[str] | None = None,
        toggle_hotkey: list[str] | None = None,
        on_hold_start: Callable[[], Any] | None = None,
        on_hold_stop: Callable[[], Any] | None = None,
        on_toggle: Callable[[], Any] | None = None,
    ) -> None:
        self._on_hold_start = on_hold_start
        self._on_hold_stop = on_hold_stop
        self._on_toggle = on_toggle

        # Hold-Hotkey parsen
        self._hold_keys: list[keyboard.Key | keyboard.KeyCode] = []
        self._hold_modifier_groups: list[set[keyboard.Key]] = []
        if hold_hotkey:
            for key_str in hold_hotkey:
                group = _get_modifier_group(key_str)
                if group:
                    self._hold_modifier_groups.append(group)
                self._hold_keys.append(_resolve_key(key_str))
            log.info("Hold-Hotkey konfiguriert: %s", " + ".join(hold_hotkey))

        # Toggle-Hotkey parsen
        self._toggle_keys: list[keyboard.Key | keyboard.KeyCode] = []
        self._toggle_modifier_groups: list[set[keyboard.Key]] = []
        if toggle_hotkey:
            for key_str in toggle_hotkey:
                group = _get_modifier_group(key_str)
                if group:
                    self._toggle_modifier_groups.append(group)
                self._toggle_keys.append(_resolve_key(key_str))
            log.info("Toggle-Hotkey konfiguriert: %s", " + ".join(toggle_hotkey))

        # State-Tracking
        self._pressed_keys: set[keyboard.Key | keyboard.KeyCode] = set()
        self._hold_active = False
        self._toggle_combo_held = False
        self._listener: keyboard.Listener | None = None
        self._lock = threading.Lock()
        self._kb_controller: keyboard.Controller | None = None

    def _normalize_key(self, key: keyboard.Key | keyboard.KeyCode) -> keyboard.Key | keyboard.KeyCode:
        """Normalisiert einen Key (z.B. ctrl_l/ctrl_r werden nicht zusammengefasst)."""
        return key

    def _check_combo(
        self,
        target_keys: list[keyboard.Key | keyboard.KeyCode],
        modifier_groups: list[set[keyboard.Key]],
    ) -> bool:
        """Prüft ob eine Tastenkombination aktuell gedrückt ist."""
        if not target_keys:
            return False

        for i, target_key in enumerate(target_keys):
            # Für Modifier: prüfe ob *irgendein* Key aus der Gruppe gedrückt ist
            if i < len(modifier_groups) and modifier_groups[i]:
                if not (modifier_groups[i] & self._pressed_keys):
                    return False
            else:
                if target_key not in self._pressed_keys:
                    return False
        return True

    def _combo_uses_alt(self, target_keys: list[keyboard.Key | keyboard.KeyCode]) -> bool:
        """Prueft ob Alt Teil der Hotkey-Kombination ist."""
        for key in target_keys:
            if key in _ALT_KEYS:
                return True
        return False

    def _cancel_alt_menu(self) -> None:
        """Sendet einen Shift-Tap um Windows-Menueleisten-Aktivierung nach Alt-Release zu verhindern."""
        try:
            if self._kb_controller is None:
                self._kb_controller = keyboard.Controller()
            self._kb_controller.tap(keyboard.Key.shift)
            log.debug("Alt-Menu-Workaround: Shift-Tap gesendet")
        except Exception as e:
            log.debug("Alt-Menu-Workaround fehlgeschlagen: %s", e)

    def _on_press(self, key: keyboard.Key | keyboard.KeyCode) -> None:
        """Callback für Key-Press-Events."""
        with self._lock:
            self._pressed_keys.add(key)

            # Hold-Hotkey prüfen
            if not self._hold_active and self._check_combo(self._hold_keys, self._hold_modifier_groups):
                self._hold_active = True
                log.debug("Hold-Hotkey gedrückt")
                if self._on_hold_start:
                    threading.Thread(target=self._on_hold_start, daemon=True).start()

            # Toggle-Hotkey prüfen
            if self._toggle_keys and self._check_combo(self._toggle_keys, self._toggle_modifier_groups):
                self._toggle_combo_held = True
                log.debug("Toggle-Hotkey gedrückt")
                if self._on_toggle:
                    threading.Thread(target=self._on_toggle, daemon=True).start()

    def _on_release(self, key: keyboard.Key | keyboard.KeyCode) -> None:
        """Callback für Key-Release-Events."""
        cancel_alt = False

        with self._lock:
            self._pressed_keys.discard(key)

            # Hold-Hotkey: Aufnahme stoppen wenn einer der Hold-Keys losgelassen wird
            if self._hold_active:
                if not self._check_combo(self._hold_keys, self._hold_modifier_groups):
                    self._hold_active = False
                    log.debug("Hold-Hotkey losgelassen")
                    if key in _ALT_KEYS and self._combo_uses_alt(self._hold_keys):
                        cancel_alt = True
                    if self._on_hold_stop:
                        threading.Thread(target=self._on_hold_stop, daemon=True).start()

            # Toggle-Hotkey: Alt-Workaround wenn Combo losgelassen wird
            if self._toggle_combo_held:
                if not self._check_combo(self._toggle_keys, self._toggle_modifier_groups):
                    self._toggle_combo_held = False
                    if key in _ALT_KEYS and self._combo_uses_alt(self._toggle_keys):
                        cancel_alt = True

        # Alt-Menu-Workaround AUSSERHALB des Locks ausfuehren
        if cancel_alt:
            self._cancel_alt_menu()

    def start(self) -> None:
        """Startet den globalen Hotkey-Listener."""
        if self._listener is not None:
            log.warning("Listener läuft bereits")
            return

        self._listener = keyboard.Listener(
            on_press=self._on_press,
            on_release=self._on_release,
        )
        self._listener.daemon = True
        self._listener.start()
        log.info("Hotkey-Listener gestartet")

    def stop(self) -> None:
        """Stoppt den globalen Hotkey-Listener."""
        if self._listener is not None:
            self._listener.stop()
            self._listener = None
            self._pressed_keys.clear()
            self._hold_active = False
            self._toggle_combo_held = False
            log.info("Hotkey-Listener gestoppt")

    def update_hotkeys(
        self,
        hold_hotkey: list[str] | None = None,
        toggle_hotkey: list[str] | None = None,
    ) -> None:
        """Aktualisiert die Hotkey-Konfiguration zur Laufzeit."""
        with self._lock:
            if hold_hotkey is not None:
                self._hold_keys = []
                self._hold_modifier_groups = []
                for key_str in hold_hotkey:
                    group = _get_modifier_group(key_str)
                    if group:
                        self._hold_modifier_groups.append(group)
                    self._hold_keys.append(_resolve_key(key_str))
                log.info("Hold-Hotkey aktualisiert: %s", " + ".join(hold_hotkey))

            if toggle_hotkey is not None:
                self._toggle_keys = []
                self._toggle_modifier_groups = []
                for key_str in toggle_hotkey:
                    group = _get_modifier_group(key_str)
                    if group:
                        self._toggle_modifier_groups.append(group)
                    self._toggle_keys.append(_resolve_key(key_str))
                log.info("Toggle-Hotkey aktualisiert: %s", " + ".join(toggle_hotkey))

            # State zurücksetzen
            self._hold_active = False
            self._toggle_combo_held = False
            self._pressed_keys.clear()

    @property
    def is_hold_active(self) -> bool:
        """Gibt zurück, ob der Hold-Hotkey gerade gedrückt wird."""
        return self._hold_active

    @property
    def is_running(self) -> bool:
        """Gibt zurück, ob der Listener läuft."""
        return self._listener is not None and self._listener.is_alive()
