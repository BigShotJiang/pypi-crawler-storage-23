"""Clipboard-basierte Texteinfügung für PayPerTranscript.

Sichert die Zwischenablage, kopiert den Text, simuliert Ctrl+V,
und stellt die alte Zwischenablage wieder her.
"""

import time
from collections.abc import Iterator

import pyautogui
import pyperclip

from paypertranscript.core.logging import get_logger

log = get_logger("core.text_inserter")

# pyautogui: Kein FAILSAFE (App läuft im Hintergrund),
# keine Pause zwischen Aktionen (Latenz minimieren)
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0


def insert_text(text: str) -> None:
    """Fügt Text an der aktuellen Cursor-Position ein.

    Ablauf:
    1. Aktuelle Zwischenablage sichern
    2. Text in Zwischenablage kopieren
    3. Ctrl+V simulieren
    4. 50ms warten (Ziel-App verarbeitet Paste)
    5. Alte Zwischenablage wiederherstellen

    Args:
        text: Der einzufügende Text.
    """
    if not text:
        log.warning("insert_text aufgerufen mit leerem Text - übersprungen")
        return

    # 1. Aktuelle Zwischenablage sichern
    old_clipboard = ""
    try:
        old_clipboard = pyperclip.paste() or ""
    except Exception:
        log.debug("Zwischenablage konnte nicht gelesen werden - wird als leer behandelt")

    try:
        # 2. Text in Zwischenablage kopieren
        pyperclip.copy(text)

        # 3. Ctrl+V simulieren
        pyautogui.hotkey("ctrl", "v")

        # 4. Warten, damit die Ziel-App den Paste verarbeiten kann
        time.sleep(0.05)

        log.info("Text eingefügt (%d Zeichen)", len(text))

    except Exception as e:
        log.error("Text-Einfügung fehlgeschlagen: %s", e)
        raise

    finally:
        # 5. Alte Zwischenablage wiederherstellen
        try:
            pyperclip.copy(old_clipboard)
        except Exception:
            log.debug("Zwischenablage konnte nicht wiederhergestellt werden")


# Intervall (Sekunden) zwischen Chunk-Pastes bei Streaming-Typing
_STREAM_INTERVAL = 0.15


def insert_text_streaming(chunks: Iterator[str]) -> None:
    """Fügt Text chunk-weise an der Cursor-Position ein (Live-Typing).

    Chunks werden gesammelt und in ~150ms-Intervallen per Clipboard+Paste
    eingefügt. Bei Fehler wird der gesamte gesammelte Text als Fallback
    komplett eingefügt.

    Args:
        chunks: Iterator der Text-Chunks (z.B. von LLM-Streaming).
    """
    old_clipboard = ""
    try:
        old_clipboard = pyperclip.paste() or ""
    except Exception:
        log.debug("Zwischenablage konnte nicht gelesen werden - wird als leer behandelt")

    buffer = ""
    total_inserted = 0

    try:
        last_paste = time.monotonic()
        for chunk in chunks:
            buffer += chunk
            now = time.monotonic()
            if now - last_paste >= _STREAM_INTERVAL and buffer:
                pyperclip.copy(buffer)
                pyautogui.hotkey("ctrl", "v")
                time.sleep(0.05)
                total_inserted += len(buffer)
                buffer = ""
                last_paste = now

        # Restlichen Buffer einfügen
        if buffer:
            pyperclip.copy(buffer)
            pyautogui.hotkey("ctrl", "v")
            time.sleep(0.05)
            total_inserted += len(buffer)

        log.info("Streaming-Text eingefügt (%d Zeichen)", total_inserted)

    except Exception as e:
        log.error("Streaming-Einfügung fehlgeschlagen: %s - versuche Fallback", e)
        # Fallback: alles was noch nicht eingefügt wurde komplett pasten
        if buffer:
            try:
                pyperclip.copy(buffer)
                pyautogui.hotkey("ctrl", "v")
                time.sleep(0.05)
            except Exception:
                log.error("Auch Fallback-Paste fehlgeschlagen")

    finally:
        try:
            pyperclip.copy(old_clipboard)
        except Exception:
            log.debug("Zwischenablage konnte nicht wiederhergestellt werden")
