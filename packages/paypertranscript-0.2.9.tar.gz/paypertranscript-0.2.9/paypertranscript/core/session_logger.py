﻿"""Session-Logging fuer PayPerTranscript.

Thread-sichere Speicherung von Transkriptions-Sessions in tracking.json.
"""

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from paypertranscript.core.config import TRACKING_FILE
from paypertranscript.core.logging import get_logger

log = get_logger("core.session_logger")


def _empty_totals() -> dict[str, Any]:
    """Leere Totals-Struktur."""
    return {
        "session_count": 0,
        "total_audio_seconds": 0.0,
        "total_billed_seconds": 0.0,
        "total_stt_cost_usd": 0.0,
        "total_llm_cost_usd": 0.0,
        "total_cost_usd": 0.0,
    }


class SessionLogger:
    """Thread-sicherer Session-Logger fuer tracking.json."""

    def __init__(self, tracking_file: Path = TRACKING_FILE) -> None:
        self._file = tracking_file
        self._lock = threading.Lock()
        log.info("SessionLogger initialisiert: %s", self._file)

    def _read_tracking(self) -> dict[str, Any]:
        """Liest tracking.json (muss unter Lock aufgerufen werden)."""
        if self._file.exists():
            try:
                raw = json.loads(self._file.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    return raw
            except (json.JSONDecodeError, OSError) as e:
                log.warning("tracking.json konnte nicht gelesen werden: %s", e)
        return {"sessions": [], "totals": _empty_totals()}

    def _write_tracking(self, data: dict[str, Any]) -> None:
        """Schreibt tracking.json (muss unter Lock aufgerufen werden)."""
        self._file.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._file.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError as e:
            log.error("tracking.json konnte nicht geschrieben werden: %s", e)

    def log_session(self, session: dict[str, Any]) -> None:
        """Loggt eine abgeschlossene Transkriptions-Session.

        Thread-safe. Liest tracking.json, haengt Session an, aktualisiert Totals.

        Args:
            session: Dict mit Session-Daten (Felder aus PRD 5.7).
        """
        with self._lock:
            tracking = self._read_tracking()

            tracking.setdefault("sessions", []).append(session)

            totals = tracking.setdefault("totals", _empty_totals())
            totals["session_count"] = totals.get("session_count", 0) + 1
            totals["total_audio_seconds"] = (
                totals.get("total_audio_seconds", 0.0)
                + session.get("audio_duration_seconds", 0.0)
            )
            totals["total_billed_seconds"] = (
                totals.get("total_billed_seconds", 0.0)
                + session.get("billed_seconds", 0.0)
            )
            totals["total_stt_cost_usd"] = (
                totals.get("total_stt_cost_usd", 0.0)
                + session.get("stt_cost_usd", 0.0)
            )
            totals["total_llm_cost_usd"] = (
                totals.get("total_llm_cost_usd", 0.0)
                + session.get("llm_cost_usd", 0.0)
            )
            totals["total_cost_usd"] = (
                totals.get("total_cost_usd", 0.0)
                + session.get("total_cost_usd", 0.0)
            )

            self._write_tracking(tracking)

        log.info(
            "Session geloggt: %.1fs Audio, $%.6f total",
            session.get("audio_duration_seconds", 0),
            session.get("total_cost_usd", 0),
        )

    def get_tracking_data(self) -> dict[str, Any]:
        """Gibt alle Tracking-Daten zurueck (thread-safe read)."""
        with self._lock:
            return self._read_tracking()

    def get_sessions(self, days: int | None = None) -> list[dict[str, Any]]:
        """Gibt Sessions zurueck, optional gefiltert auf letzte N Tage.

        Args:
            days: Wenn angegeben, nur Sessions der letzten N Tage.

        Returns:
            Liste von Session-Dicts.
        """
        data = self.get_tracking_data()
        sessions = data.get("sessions", [])

        if days is not None:
            cutoff = datetime.now(timezone.utc).timestamp() - (days * 86400)
            filtered = []
            for s in sessions:
                try:
                    ts = datetime.fromisoformat(s["timestamp"]).timestamp()
                    if ts >= cutoff:
                        filtered.append(s)
                except (KeyError, ValueError):
                    pass
            return filtered

        return sessions

    def get_totals(self) -> dict[str, Any]:
        """Gibt aggregierte Totals zurueck."""
        data = self.get_tracking_data()
        return data.get("totals", _empty_totals())
