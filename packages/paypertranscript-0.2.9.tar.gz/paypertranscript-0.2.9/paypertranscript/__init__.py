"""PayPerTranscript - Voice-to-Text mit Pay-per-Use Pricing."""

__version__ = "0.2.9"
