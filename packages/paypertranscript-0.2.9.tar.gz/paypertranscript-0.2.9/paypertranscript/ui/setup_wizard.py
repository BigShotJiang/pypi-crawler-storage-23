"""Setup-Wizard für PayPerTranscript.

Ersteinrichtungs-Assistent: API-Key, Sprache, Wortliste, Hotkeys.
Wird beim ersten Start angezeigt (wenn keine config.json existiert).
"""

import threading

from PySide6.QtCore import QObject, QSize, Qt, Signal, Slot
from PySide6.QtGui import QColor, QFont, QPainter, QPaintEvent, QPixmap
from PySide6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QPushButton,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.ui.animated import AnimatedDialog
from paypertranscript.ui.constants import HOLD_PRESETS, LANGUAGES, TOGGLE_PRESETS

from paypertranscript.core.config import ConfigManager, save_api_key
from paypertranscript.core.logging import get_logger
from paypertranscript.core.paths import get_icons_dir

log = get_logger("ui.setup_wizard")

# Wizard-Schritte
_STEP_LABELS = ["Willkommen", "API-Key", "Sprache", "Wortliste", "Hotkeys", "Fertig"]


class _ApiKeyValidator(QObject):
    """Validiert den API-Key in einem Background-Thread."""

    finished = Signal(bool, str)  # (success, message)

    def validate(self, api_key: str) -> None:
        """Startet die Validierung in einem Background-Thread."""
        thread = threading.Thread(target=self._run, args=(api_key,), daemon=True)
        thread.start()

    def _run(self, api_key: str) -> None:
        try:
            import groq

            client = groq.Groq(api_key=api_key)
            client.models.list()
            self.finished.emit(True, "")
        except Exception as e:
            self.finished.emit(False, str(e))


class _StepIndicator(QWidget):
    """Fortschrittsanzeige mit Kreisen und Verbindungslinien."""

    def __init__(self, steps: list[str], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._steps = steps
        self._current = 0
        self.setFixedHeight(80)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set_current(self, index: int) -> None:
        self._current = index
        self.update()

    def paintEvent(self, event: QPaintEvent) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        n = len(self._steps)
        w = self.width()
        h = self.height()
        circle_r = 12
        y_center = 26
        label_y = y_center + circle_r + 8

        # Berechne X-Positionen (gleichverteilt)
        margin = 40
        spacing = (w - 2 * margin) / max(n - 1, 1)
        positions = [int(margin + i * spacing) for i in range(n)]

        font_small = QFont("Segoe UI", 8)
        font_bold = QFont("Segoe UI", 8, QFont.Weight.Bold)

        for i in range(n):
            x = positions[i]

            # Verbindungslinie zum nächsten Schritt
            if i < n - 1:
                x_next = positions[i + 1]
                if i < self._current:
                    painter.setPen(QColor("#ffffff"))
                else:
                    painter.setPen(QColor("#333340"))
                painter.drawLine(x + circle_r, y_center, x_next - circle_r, y_center)

            # Kreis
            if i < self._current:
                # Abgeschlossen
                painter.setBrush(QColor("#ffffff"))
                painter.setPen(Qt.PenStyle.NoPen)
            elif i == self._current:
                # Aktuell
                painter.setBrush(QColor("#ffffff"))
                painter.setPen(Qt.PenStyle.NoPen)
            else:
                # Ausstehend
                painter.setBrush(QColor("#1c1c24"))
                painter.setPen(QColor("#333340"))
            painter.drawEllipse(x - circle_r, y_center - circle_r, circle_r * 2, circle_r * 2)

            # Nummer im Kreis
            painter.setPen(QColor("#ffffff") if i <= self._current else QColor("#a0a0a0"))
            painter.setFont(font_bold if i == self._current else font_small)
            painter.drawText(
                x - circle_r, y_center - circle_r, circle_r * 2, circle_r * 2,
                Qt.AlignmentFlag.AlignCenter, str(i + 1),
            )

            # Label unter dem Kreis
            painter.setPen(QColor("#e0e0e0") if i == self._current else QColor("#a0a0a0"))
            painter.setFont(font_bold if i == self._current else font_small)
            painter.drawText(
                x - 40, label_y, 80, 16,
                Qt.AlignmentFlag.AlignCenter, self._steps[i],
            )

        painter.end()

    def sizeHint(self) -> QSize:
        return QSize(500, 80)


class SetupWizard(AnimatedDialog):
    """Ersteinrichtungs-Assistent (6 Schritte)."""

    def __init__(self, config: ConfigManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._config = config

        # Gesammelte Werte
        self._api_key = ""
        self._api_key_valid = False
        self._language = "de"
        self._words: list[str] = []
        self._hold_hotkey: list[str] = ["ctrl", "cmd"]
        self._toggle_hotkey: list[str] | None = None

        # API-Key-Validator
        self._validator = _ApiKeyValidator()
        self._validator.finished.connect(self._on_validation_result)

        self._setup_ui()
        log.info("Setup-Wizard gestartet")

    def _setup_ui(self) -> None:
        self.setWindowTitle("PayPerTranscript - Einrichtung")
        self.setWindowFlags(
            Qt.WindowType.Dialog
            | Qt.WindowType.WindowCloseButtonHint
            | Qt.WindowType.MSWindowsFixedSizeDialogHint
        )
        self.setFixedSize(620, 520)

        layout = QVBoxLayout(self)
        layout.setSpacing(0)
        layout.setContentsMargins(0, 0, 0, 0)

        # Fortschrittsanzeige
        self._step_indicator = _StepIndicator(_STEP_LABELS)
        indicator_container = QWidget()
        indicator_container.setFixedHeight(96)
        indicator_layout = QVBoxLayout(indicator_container)
        indicator_layout.setContentsMargins(20, 8, 20, 0)
        indicator_layout.addWidget(self._step_indicator)
        layout.addWidget(indicator_container)

        # Trennlinie
        separator = QWidget()
        separator.setFixedHeight(1)
        separator.setStyleSheet("background-color: #333340;")
        layout.addWidget(separator)

        # Seiten-Stack
        self._stack = QStackedWidget()
        self._stack.addWidget(self._create_welcome_page())
        self._stack.addWidget(self._create_api_key_page())
        self._stack.addWidget(self._create_language_page())
        self._stack.addWidget(self._create_word_list_page())
        self._stack.addWidget(self._create_hotkey_page())
        self._stack.addWidget(self._create_finish_page())
        layout.addWidget(self._stack, 1)

        # Trennlinie
        separator2 = QWidget()
        separator2.setFixedHeight(1)
        separator2.setStyleSheet("background-color: #333340;")
        layout.addWidget(separator2)

        # Button-Leiste
        btn_container = QWidget()
        btn_container.setFixedHeight(60)
        btn_layout = QHBoxLayout(btn_container)
        btn_layout.setContentsMargins(20, 10, 20, 10)

        self._btn_back = QPushButton("Zur\u00fcck")
        self._btn_back.setFixedWidth(100)
        self._btn_back.clicked.connect(self._go_back)

        btn_layout.addWidget(self._btn_back)
        btn_layout.addStretch()

        self._btn_next = QPushButton("Weiter")
        self._btn_next.setFixedWidth(140)
        self._btn_next.setProperty("primary", True)
        self._btn_next.clicked.connect(self._go_next)

        btn_layout.addWidget(self._btn_next)
        layout.addWidget(btn_container)

        # Initialzustand
        self._update_buttons()

    # -- Seiten erstellen --

    def _create_welcome_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 30, 40, 20)
        layout.setSpacing(16)

        # Logo
        logo_path = get_icons_dir() / "app_big.png"
        if logo_path.exists():
            logo_label = QLabel()
            logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            pixmap = QPixmap(str(logo_path)).scaled(
                80, 80,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            logo_label.setPixmap(pixmap)
            layout.addWidget(logo_label)

        title = QLabel("Willkommen bei PayPerTranscript")
        title.setProperty("heading", True)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        layout.addSpacing(10)

        desc = QLabel(
            "PayPerTranscript ist deine Open-Source Voice-to-Text App.\n\n"
            "Halte einen Hotkey gedr\u00fcckt, sprich, und der transkribierte Text "
            "wird direkt an der Cursor-Position eingef\u00fcgt.\n\n"
            "Kein Abo - du zahlst nur f\u00fcr die tats\u00e4chliche Nutzung "
            "(ca. 0,04 $/Stunde). Daf\u00fcr brauchst du einen kostenlosen "
            "GroqCloud API-Key."
        )
        desc.setProperty("subheading", True)
        desc.setWordWrap(True)
        desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(desc)

        layout.addStretch()
        return page

    def _create_api_key_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 30, 40, 20)
        layout.setSpacing(12)

        title = QLabel("GroqCloud API-Key")
        title.setProperty("heading", True)
        layout.addWidget(title)

        desc = QLabel(
            "Erstelle einen kostenlosen API-Key auf console.groq.com\n"
            "und f\u00fcge ihn hier ein. Der Key wird sicher im Windows\n"
            "Credential Manager gespeichert."
        )
        desc.setProperty("subheading", True)
        desc.setWordWrap(True)
        layout.addWidget(desc)

        layout.addSpacing(8)

        # API-Key Eingabe
        key_label = QLabel("API-Key:")
        layout.addWidget(key_label)

        self._key_input = QLineEdit()
        self._key_input.setPlaceholderText("gsk_...")
        self._key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self._key_input.textChanged.connect(self._on_key_text_changed)
        layout.addWidget(self._key_input)

        # Checkbox: Key anzeigen
        show_layout = QHBoxLayout()
        self._btn_show_key = QPushButton("Key anzeigen")
        self._btn_show_key.setFixedWidth(120)
        self._btn_show_key.setCheckable(True)
        self._btn_show_key.toggled.connect(self._on_toggle_key_visibility)
        show_layout.addWidget(self._btn_show_key)
        show_layout.addStretch()

        self._btn_test_key = QPushButton("Key testen")
        self._btn_test_key.setFixedWidth(120)
        self._btn_test_key.clicked.connect(self._on_test_key)
        show_layout.addWidget(self._btn_test_key)

        layout.addLayout(show_layout)

        # Status-Label
        self._key_status = QLabel("")
        self._key_status.setWordWrap(True)
        layout.addWidget(self._key_status)

        layout.addStretch()
        return page

    def _create_language_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 30, 40, 20)
        layout.setSpacing(12)

        title = QLabel("Transkriptions-Sprache")
        title.setProperty("heading", True)
        layout.addWidget(title)

        desc = QLabel(
            "W\u00e4hle die Sprache, in der du haupts\u00e4chlich sprichst.\n"
            "Die Spracherkennung wird auf diese Sprache optimiert."
        )
        desc.setProperty("subheading", True)
        desc.setWordWrap(True)
        layout.addWidget(desc)

        layout.addSpacing(16)

        lang_label = QLabel("Sprache:")
        layout.addWidget(lang_label)

        self._lang_combo = QComboBox()
        for code, name in LANGUAGES:
            self._lang_combo.addItem(name, code)
        self._lang_combo.setCurrentIndex(0)  # Deutsch
        self._lang_combo.currentIndexChanged.connect(self._on_language_changed)
        layout.addWidget(self._lang_combo)

        layout.addStretch()
        return page

    def _create_word_list_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 30, 40, 20)
        layout.setSpacing(12)

        title = QLabel("Wortliste (optional)")
        title.setProperty("heading", True)
        layout.addWidget(title)

        desc = QLabel(
            "F\u00fcge W\u00f6rter hinzu, die oft falsch geschrieben werden -\n"
            "deinen Namen, Fachbegriffe oder Produktnamen.\n"
            "Das hilft der Spracherkennung, diese W\u00f6rter korrekt zu schreiben."
        )
        desc.setProperty("subheading", True)
        desc.setWordWrap(True)
        layout.addWidget(desc)

        layout.addSpacing(8)

        # Eingabezeile + Button
        input_layout = QHBoxLayout()
        self._word_input = QLineEdit()
        self._word_input.setPlaceholderText("Wort eingeben...")
        self._word_input.returnPressed.connect(self._on_add_word)
        input_layout.addWidget(self._word_input)

        btn_add = QPushButton("Hinzuf\u00fcgen")
        btn_add.setFixedWidth(100)
        btn_add.clicked.connect(self._on_add_word)
        input_layout.addWidget(btn_add)
        layout.addLayout(input_layout)

        # Wortliste
        self._word_list = QListWidget()
        layout.addWidget(self._word_list, 1)

        # Entfernen-Button
        btn_remove = QPushButton("Ausgew\u00e4hltes entfernen")
        btn_remove.clicked.connect(self._on_remove_word)
        layout.addWidget(btn_remove)

        return page

    def _create_hotkey_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 30, 40, 20)
        layout.setSpacing(12)

        title = QLabel("Hotkeys konfigurieren")
        title.setProperty("heading", True)
        layout.addWidget(title)

        desc = QLabel(
            "W\u00e4hle die Tastenkombinationen f\u00fcr die Aufnahme.\n"
            "Du kannst sie sp\u00e4ter in den Einstellungen \u00e4ndern."
        )
        desc.setProperty("subheading", True)
        desc.setWordWrap(True)
        layout.addWidget(desc)

        layout.addSpacing(16)

        # Hold-to-Record
        hold_label = QLabel("Hold-to-Record (gedr\u00fcckt halten = Aufnahme):")
        hold_label.setStyleSheet("font-weight: bold;")
        layout.addWidget(hold_label)

        self._hold_combo = QComboBox()
        for name, _keys in HOLD_PRESETS:
            self._hold_combo.addItem(name)
        self._hold_combo.setCurrentIndex(0)
        self._hold_combo.currentIndexChanged.connect(self._on_hold_changed)
        layout.addWidget(self._hold_combo)

        layout.addSpacing(16)

        # Toggle-Hotkey
        toggle_label = QLabel("Toggle-Hotkey (optional - einmal dr\u00fccken = Start/Stop):")
        toggle_label.setStyleSheet("font-weight: bold;")
        layout.addWidget(toggle_label)

        self._toggle_combo = QComboBox()
        for name, _keys in TOGGLE_PRESETS:
            self._toggle_combo.addItem(name)
        self._toggle_combo.setCurrentIndex(0)
        self._toggle_combo.currentIndexChanged.connect(self._on_toggle_changed)
        layout.addWidget(self._toggle_combo)

        layout.addStretch()
        return page

    def _create_finish_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(40, 30, 40, 20)
        layout.setSpacing(12)

        title = QLabel("Alles bereit!")
        title.setProperty("heading", True)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        layout.addSpacing(10)

        desc = QLabel("Hier ist eine \u00dcbersicht deiner Einstellungen:")
        desc.setProperty("subheading", True)
        desc.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(desc)

        layout.addSpacing(16)

        self._summary_label = QLabel("")
        self._summary_label.setWordWrap(True)
        self._summary_label.setStyleSheet(
            "background-color: #1c1c24; border: 1px solid #333340; "
            "border-radius: 8px; padding: 16px; font-size: 10pt;"
        )
        layout.addWidget(self._summary_label)

        layout.addStretch()
        return page

    # -- Navigation --

    def _go_next(self) -> None:
        current = self._stack.currentIndex()
        if current == len(_STEP_LABELS) - 1:
            # Letzte Seite → Fertig
            self._finish()
            return
        self._stack.setCurrentIndex(current + 1)
        self._step_indicator.set_current(current + 1)
        self._update_buttons()

        # Zusammenfassung aktualisieren wenn wir zur letzten Seite kommen
        if current + 1 == len(_STEP_LABELS) - 1:
            self._update_summary()

    def _go_back(self) -> None:
        current = self._stack.currentIndex()
        if current > 0:
            self._stack.setCurrentIndex(current - 1)
            self._step_indicator.set_current(current - 1)
            self._update_buttons()

    def _update_buttons(self) -> None:
        current = self._stack.currentIndex()
        last = len(_STEP_LABELS) - 1

        # Zurück-Button: versteckt auf erster Seite
        self._btn_back.setVisible(current > 0)

        # Weiter-Button: Text und Aktivierung
        if current == last:
            self._btn_next.setText("Los geht's!")
        else:
            self._btn_next.setText("Weiter")

        # Weiter nur aktiviert wenn API-Key-Seite validiert ist
        if current == 1:
            self._btn_next.setEnabled(self._api_key_valid)
        else:
            self._btn_next.setEnabled(True)

    # -- API-Key Seite --

    def _on_key_text_changed(self, text: str) -> None:
        self._api_key = text.strip()
        self._api_key_valid = False
        self._key_status.setText("")
        self._key_status.setStyleSheet("")
        self._update_buttons()

    def _on_toggle_key_visibility(self, checked: bool) -> None:
        if checked:
            self._key_input.setEchoMode(QLineEdit.EchoMode.Normal)
            self._btn_show_key.setText("Key verbergen")
        else:
            self._key_input.setEchoMode(QLineEdit.EchoMode.Password)
            self._btn_show_key.setText("Key anzeigen")

    def _on_test_key(self) -> None:
        key = self._key_input.text().strip()
        if not key:
            self._key_status.setText("Bitte gib einen API-Key ein.")
            self._key_status.setStyleSheet("color: #f87171;")
            return

        self._key_status.setText("Wird gepr\u00fcft...")
        self._key_status.setStyleSheet("color: #a0a0a0;")
        self._btn_test_key.setEnabled(False)
        self._validator.validate(key)

    @Slot(bool, str)
    def _on_validation_result(self, success: bool, message: str) -> None:
        self._btn_test_key.setEnabled(True)
        if success:
            self._api_key_valid = True
            self._key_status.setText("API-Key ist g\u00fcltig!")
            self._key_status.setStyleSheet("color: #34d399; font-weight: bold;")
            log.info("API-Key erfolgreich validiert")
        else:
            self._api_key_valid = False
            error_msg = message
            if "AuthenticationError" in message or "401" in message:
                error_msg = "API-Key ist ung\u00fcltig."
            elif "Connection" in message:
                error_msg = "Keine Verbindung zu GroqCloud. Pr\u00fcfe deine Internetverbindung."
            self._key_status.setText(error_msg)
            self._key_status.setStyleSheet("color: #f87171;")
            log.warning("API-Key-Validierung fehlgeschlagen: %s", message)
        self._update_buttons()

    # -- Sprache --

    def _on_language_changed(self, index: int) -> None:
        self._language = self._lang_combo.itemData(index)

    # -- Wortliste --

    def _on_add_word(self) -> None:
        word = self._word_input.text().strip()
        if not word:
            return
        # Duplikate vermeiden
        for i in range(self._word_list.count()):
            if self._word_list.item(i).text() == word:
                return
        self._word_list.addItem(word)
        self._words.append(word)
        self._word_input.clear()
        self._word_input.setFocus()

    def _on_remove_word(self) -> None:
        current = self._word_list.currentRow()
        if current >= 0:
            item = self._word_list.takeItem(current)
            if item and item.text() in self._words:
                self._words.remove(item.text())

    # -- Hotkeys --

    def _on_hold_changed(self, index: int) -> None:
        _name, keys = HOLD_PRESETS[index]
        self._hold_hotkey = keys

    def _on_toggle_changed(self, index: int) -> None:
        _name, keys = TOGGLE_PRESETS[index]
        self._toggle_hotkey = keys

    # -- Zusammenfassung --

    def _update_summary(self) -> None:
        key_masked = "****" + self._api_key[-4:] if len(self._api_key) > 4 else "****"
        lang_name = dict(LANGUAGES).get(self._language, self._language)
        word_count = len(self._words)
        words_text = f"{word_count} W\u00f6rter" if word_count else "Keine"
        hold_name = HOLD_PRESETS[self._hold_combo.currentIndex()][0]
        toggle_idx = self._toggle_combo.currentIndex()
        toggle_name = TOGGLE_PRESETS[toggle_idx][0]

        summary = (
            f"<table style='font-size: 10pt; line-height: 1.8;'>"
            f"<tr><td style='color: #a0a0a0; padding-right: 20px;'>API-Key:</td>"
            f"<td>{key_masked}</td></tr>"
            f"<tr><td style='color: #a0a0a0; padding-right: 20px;'>Sprache:</td>"
            f"<td>{lang_name}</td></tr>"
            f"<tr><td style='color: #a0a0a0; padding-right: 20px;'>Wortliste:</td>"
            f"<td>{words_text}</td></tr>"
            f"<tr><td style='color: #a0a0a0; padding-right: 20px;'>Hold-Hotkey:</td>"
            f"<td>{hold_name}</td></tr>"
            f"<tr><td style='color: #a0a0a0; padding-right: 20px;'>Toggle-Hotkey:</td>"
            f"<td>{toggle_name}</td></tr>"
            f"</table>"
        )
        self._summary_label.setText(summary)

    # -- Abschluss --

    def _finish(self) -> None:
        """Speichert alle Einstellungen und schließt den Wizard."""
        log.info("Setup-Wizard abgeschlossen - speichere Einstellungen")

        # API-Key im Credential Manager speichern
        try:
            save_api_key(self._api_key)
        except Exception as e:
            log.error("API-Key konnte nicht im Keyring gespeichert werden: %s", e)

        # Config-Werte setzen
        self._config.set("general.language", self._language)
        self._config.set("general.hold_hotkey", self._hold_hotkey)
        self._config.set("general.toggle_hotkey", self._toggle_hotkey)
        self._config.set("words.misspelled_words", self._words)

        log.info(
            "Config gespeichert: Sprache=%s, Hold=%s, Toggle=%s, W\u00f6rter=%d",
            self._language,
            self._hold_hotkey,
            self._toggle_hotkey,
            len(self._words),
        )

        self.accept()

    def reject(self) -> None:
        """Window-Close → App beendet sich."""
        log.info("Setup-Wizard abgebrochen")
        super().reject()
