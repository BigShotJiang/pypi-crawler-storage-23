"""System Tray fuer PayPerTranscript.

QSystemTrayIcon mit Kontextmenue und Icon-Zustandswechsel.
"""

from collections.abc import Callable

from PySide6.QtCore import Qt, Slot
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QMenu,
    QPushButton,
    QSystemTrayIcon,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.ui.animated import AnimatedDialog

from paypertranscript.core.config import ConfigManager
from paypertranscript.core.hotkey import HotkeyListener
from paypertranscript.core.logging import get_logger
from paypertranscript.core.paths import get_icons_dir
from paypertranscript.core.session_logger import SessionLogger

log = get_logger("ui.tray")

# Icon-Dateinamen fuer die drei Zustaende
_ICON_FILES: dict[str, str] = {
    "idle": "tray.png",
    "recording": "tray_orange.png",
    "processing": "tray_green.png",
}


def _load_icon(filename: str, size: int = 64) -> QIcon:
    """Laedt ein Tray-Icon aus den Assets.

    Args:
        filename: Dateiname im icons-Ordner.
        size: Zielgroesse in Pixeln.
    """
    path = get_icons_dir() / filename
    if path.exists():
        pixmap = QPixmap(str(path))
        if not pixmap.isNull():
            scaled = pixmap.scaled(
                size, size,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            return QIcon(scaled)

    log.warning("Tray-Icon nicht gefunden: %s", path)
    return QIcon()


def create_tray_icons() -> dict[str, QIcon]:
    """Laedt alle Tray-Icons (idle, recording, processing) aus PNG-Dateien."""
    return {state: _load_icon(fname) for state, fname in _ICON_FILES.items()}


# ---------------------------------------------------------------------------
# Update-Info-Dialog (kleiner In-App-Screen statt System-Notification)
# ---------------------------------------------------------------------------


class _UpdateInfoDialog(AnimatedDialog):
    """Kleiner Info-Dialog fuer Update-Status im App-Design."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("PayPerTranscript - Updates")
        self.setFixedSize(340, 160)
        self.setWindowFlags(
            Qt.WindowType.Window
            | Qt.WindowType.WindowCloseButtonHint
            | Qt.WindowType.WindowStaysOnTopHint
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        self._status_label = QLabel()
        self._status_label.setWordWrap(True)
        self._status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self._status_label)

        self._btn_row = QHBoxLayout()
        self._btn_row.setSpacing(10)

        self._btn_action = QPushButton()
        self._btn_action.setVisible(False)
        self._btn_row.addWidget(self._btn_action)

        self._btn_close = QPushButton("Schlie\u00dfen")
        self._btn_close.clicked.connect(self.close)
        self._btn_row.addWidget(self._btn_close)

        layout.addLayout(self._btn_row)

        self._on_action: Callable[[], None] | None = None

    def show_checking(self) -> None:
        """Zeigt 'Pruefe auf Updates...' Status."""
        self._status_label.setText("Pr\u00fcfe auf Updates...")
        self._btn_action.setVisible(False)
        self._btn_close.setText("Abbrechen")
        self._show_centered()

    def show_update_available(self, version: str, on_update: Callable[[], None]) -> None:
        """Zeigt 'Update verfuegbar' mit Aktualisieren-Button."""
        from paypertranscript import __version__

        self._status_label.setText(
            f"Update verf\u00fcgbar!\n\n"
            f"Installiert: {__version__}  \u2192  Neu: {version}"
        )
        self._on_action = on_update
        self._btn_action.setText("Jetzt aktualisieren")
        self._btn_action.setVisible(True)
        self._btn_action.setEnabled(True)
        try:
            self._btn_action.clicked.disconnect()
        except RuntimeError:
            pass
        self._btn_action.clicked.connect(self._do_action)
        self._btn_close.setText("Sp\u00e4ter")
        self._show_centered()

    def show_no_update(self) -> None:
        """Zeigt 'Alles aktuell' Status."""
        from paypertranscript import __version__

        self._status_label.setText(
            f"Alles aktuell!\n\nInstallierte Version: {__version__}"
        )
        self._btn_action.setVisible(False)
        self._btn_close.setText("Schlie\u00dfen")
        self._show_centered()

    def show_installing(self) -> None:
        """Zeigt 'Installiere...' Status."""
        self._status_label.setText("Update wird installiert...\nApp startet gleich neu.")
        self._btn_action.setVisible(False)
        self._btn_close.setEnabled(False)
        self.repaint()

    def _do_action(self) -> None:
        if self._on_action:
            self.show_installing()
            self._on_action()

    def _show_centered(self) -> None:
        if not self.isVisible():
            self.show()
        self.raise_()
        self.activateWindow()


# ---------------------------------------------------------------------------
# SystemTray
# ---------------------------------------------------------------------------


class SystemTray:
    """System Tray mit Icon-Zustaenden und Kontextmenue."""

    def __init__(
        self,
        config: ConfigManager,
        hotkey_listener: HotkeyListener | None = None,
        session_logger: SessionLogger | None = None,
        get_last_transcription: Callable[[], str | None] | None = None,
        show_done_overlay: Callable[[], None] | None = None,
        on_update_check: Callable[[], None] | None = None,
        on_perform_update: Callable[[], None] | None = None,
        parent: QWidget | None = None,
    ) -> None:
        self._config = config
        self._hotkey_listener = hotkey_listener
        self._session_logger = session_logger
        self._get_last_transcription = get_last_transcription
        self._show_done_overlay = show_done_overlay
        self._on_update_check = on_update_check
        self._on_perform_update = on_perform_update
        self._icons = create_tray_icons()

        # MainWindow (lazy creation)
        self._main_window = None
        self._update_dialog: _UpdateInfoDialog | None = None
        self._manual_check_pending = False

        self._tray = QSystemTrayIcon(self._icons["idle"], parent)
        self._tray.setToolTip(self._build_tooltip())

        self._menu = QMenu()
        self._build_menu()
        self._tray.setContextMenu(self._menu)
        self._tray.activated.connect(self._on_tray_activated)

    def show(self) -> None:
        """Zeigt das Tray-Icon an."""
        self._tray.show()
        log.info("System Tray angezeigt")

    def show_info(self, message: str) -> None:
        """Zeigt eine Info-Benachrichtigung im System Tray."""
        self._tray.showMessage(
            "PayPerTranscript",
            message,
            QSystemTrayIcon.MessageIcon.Information,
            3000,
        )

    def hide(self) -> None:
        """Versteckt das Tray-Icon."""
        self._tray.hide()

    # -- Icon-Zustandswechsel (als Slots fuer Qt-Signals) --

    @Slot()
    def on_recording_started(self) -> None:
        """Aufnahme gestartet - Icon auf Gruen."""
        self._tray.setIcon(self._icons["recording"])
        self._tray.setToolTip("PayPerTranscript - Aufnahme...")

    @Slot()
    def on_recording_stopped(self) -> None:
        """Aufnahme gestoppt - Icon auf Grau (Processing)."""
        self._tray.setIcon(self._icons["processing"])
        self._tray.setToolTip("PayPerTranscript - Verarbeite...")

    @Slot()
    def on_processing_started(self) -> None:
        """Pipeline gestartet - Icon auf Grau."""
        self._tray.setIcon(self._icons["processing"])
        self._tray.setToolTip("PayPerTranscript - Transkribiere...")

    @Slot()
    def on_processing_done(self) -> None:
        """Pipeline fertig - Icon zurueck auf Idle."""
        self._tray.setIcon(self._icons["idle"])
        self._tray.setToolTip(self._build_tooltip())
        if self._get_last_transcription and self._get_last_transcription():
            self._act_copy_last.setEnabled(True)

    @Slot(str)
    def on_processing_error(self, message: str) -> None:
        """Pipeline-Fehler - Icon zurueck auf Idle."""
        self._tray.setIcon(self._icons["idle"])
        self._tray.setToolTip(self._build_tooltip())
        log.warning("Pipeline-Fehler: %s", message)

    # -- Menue --

    def _build_menu(self) -> None:
        """Erstellt das Kontextmenue."""
        act_open = self._menu.addAction("\u00d6ffnen")
        act_open.triggered.connect(self._show_main_window)

        self._menu.addSeparator()

        act_check_update = self._menu.addAction("Updates pr\u00fcfen")
        act_check_update.triggered.connect(self._on_check_update)

        self._act_copy_last = self._menu.addAction("Letzte Transkription kopieren")
        self._act_copy_last.triggered.connect(self._on_copy_last_transcription)
        self._act_copy_last.setEnabled(False)

        self._menu.addSeparator()

        act_quit = self._menu.addAction("Beenden")
        act_quit.triggered.connect(self._on_quit)

    def _build_tooltip(self) -> str:
        """Baut den Tooltip-Text."""
        hold = self._config.get("general.hold_hotkey")
        hold_str = " + ".join(hold) if hold else "(nicht konfiguriert)"
        return f"PayPerTranscript - Bereit (Hold: {hold_str})"

    # -- MainWindow --

    def _get_main_window(self):
        """Gibt das MainWindow zurueck (lazy creation)."""
        if self._main_window is None:
            from paypertranscript.ui.main_window import MainWindow

            self._main_window = MainWindow(
                self._config,
                hotkey_listener=self._hotkey_listener,
                session_logger=self._session_logger,
                get_last_transcription=self._get_last_transcription,
            )
            self._main_window.update_check_requested.connect(self._on_check_update)
        return self._main_window

    def _show_main_window(self) -> None:
        """Oeffnet/zeigt das MainWindow (Home-Seite)."""
        win = self._get_main_window()
        win.navigate_to(0)

    def _on_copy_last_transcription(self) -> None:
        """Kopiert die letzte Transkription in die Zwischenablage."""
        if not self._get_last_transcription:
            return
        text = self._get_last_transcription()
        if text:
            import pyperclip

            try:
                pyperclip.copy(text)
                if self._show_done_overlay:
                    self._show_done_overlay()
                log.info("Letzte Transkription in Zwischenablage kopiert (%d Zeichen)", len(text))
            except Exception as e:
                log.error("Konnte Transkription nicht kopieren: %s", e)
        else:
            log.info("Keine Transkription zum Kopieren vorhanden")

    # -- Update-Callbacks --

    def _get_update_dialog(self) -> _UpdateInfoDialog:
        """Gibt den Update-Dialog zurueck (lazy creation)."""
        if self._update_dialog is None or not self._update_dialog.isVisible():
            self._update_dialog = _UpdateInfoDialog()
        return self._update_dialog

    def _on_check_update(self) -> None:
        """Manueller Update-Check ueber Tray-Menue."""
        self._manual_check_pending = True
        dlg = self._get_update_dialog()
        dlg.show_checking()
        if self._on_update_check:
            self._on_update_check()

    @Slot(str)
    def on_update_available(self, version: str) -> None:
        """Wird aufgerufen wenn ein Update verfuegbar ist."""
        self._manual_check_pending = False
        dlg = self._get_update_dialog()
        dlg.show_update_available(version, self._do_perform_update)

    @Slot()
    def on_update_not_available(self) -> None:
        """Wird aufgerufen wenn kein Update verfuegbar ist (nur bei manuellem Check)."""
        if self._manual_check_pending:
            self._manual_check_pending = False
            dlg = self._get_update_dialog()
            dlg.show_no_update()

    def _do_perform_update(self) -> None:
        """Fuehrt Update + Restart aus."""
        if self._on_perform_update:
            self._on_perform_update()

    # -- Tray-Aktivierung --

    def _on_tray_activated(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        """Reagiert auf Tray-Icon-Klicks (Linksklick oeffnet MainWindow)."""
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self._show_main_window()

    def _on_quit(self) -> None:
        log.info("Menue: Beenden ausgewaehlt")
        from PySide6.QtWidgets import QApplication
        QApplication.quit()
