"""Status-Overlay fuer PayPerTranscript.

Modernes, rahmenloses Overlay mit Glassmorphism-Effekt.
Zeigt Audio-Visualizer, Lade-Dots, Erfolgs- und Fehlermeldungen.
"""

import math
import random

from PySide6.QtCore import (
    QEasingCurve,
    QPropertyAnimation,
    QRectF,
    QTimer,
    Qt,
    Slot,
)
from PySide6.QtGui import (
    QColor,
    QCursor,
    QFont,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QRadialGradient,
)
from PySide6.QtWidgets import QApplication, QWidget

from paypertranscript.core.config import ConfigManager
from paypertranscript.core.logging import get_logger

log = get_logger("ui.overlay")

# -- Dimensionen (kompakt) --
_WIDTH = 150
_HEIGHT = 34
_RADIUS = 17  # Pillenform

# -- Farbpalette (clean, monochrom + Akzentfarben) --
_BG_COLOR = QColor(18, 18, 24, 230)  # Fast-Schwarz, 90% Opazitaet
_BORDER_COLOR = QColor(255, 255, 255, 30)  # Weisser Glasrand
_WHITE = QColor(255, 255, 255)  # Visualizer + Dots
_GREEN = QColor(52, 211, 153)  # #34d399 - Erfolg (Emerald)
_RED = QColor(248, 113, 113)  # #f87171 - Fehler
_TEXT_PRIMARY = QColor(255, 255, 255, 220)
_TEXT_DIM = QColor(255, 255, 255, 100)

# -- Timing --
_FPS_INTERVAL = 16  # ~60fps
_FADE_IN_MS = 120
_FADE_OUT_MS = 200  # Smooth fade-out (nicht abrupt)
_DONE_SHOW_MS = 700  # Kurz sichtbar, dann smooth weg
_ERROR_SHOW_MS = 2500

# -- Visualizer --
_BAR_COUNT = 5
_BAR_W = 3.0
_BAR_GAP = 3.0
_BAR_MAX_H = 18
_BAR_MIN_H = 2.5
_SMOOTHING = 0.35
_VISUAL_GAIN = 30.0  # Hoher Gain fuer leise Mikrofone

# -- Pulsing Dots --
_DOT_COUNT = 3
_DOT_RADIUS = 2.5
_DOT_GAP = 9.0
_DOT_PHASE_OFFSET = 0.7


class StatusOverlay(QWidget):
    """Modernes, rahmenloses Status-Overlay mit Glow-Effekten."""

    RECORDING = "recording"
    TRANSCRIBING = "transcribing"
    FORMATTING = "formatting"
    DONE = "done"
    ERROR = "error"

    def __init__(self, config: ConfigManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._config = config
        self._state: str | None = None
        self._error_message = ""

        # Animation
        self._tick = 0
        self._amplitude = 0.0
        self._bar_heights = [0.0] * _BAR_COUNT

        # Fenster-Flags
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFixedSize(_WIDTH, _HEIGHT)

        # Render-Timer
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(_FPS_INTERVAL)
        self._anim_timer.timeout.connect(self._on_tick)

        # Fade
        self._fade_anim = QPropertyAnimation(self, b"windowOpacity")
        self._fade_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade_anim.finished.connect(self._on_fade_finished)
        self._fading_out = False

        # Auto-Hide
        self._hide_timer = QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self._start_fade_out)

    # ── Public API ──────────────────────────────────────────────

    @Slot()
    def show_recording(self) -> None:
        self._switch_state(self.RECORDING)

    @Slot()
    def show_transcribing(self) -> None:
        self._switch_state(self.TRANSCRIBING)

    @Slot()
    def show_formatting(self) -> None:
        self._switch_state(self.FORMATTING)

    @Slot()
    def show_done(self) -> None:
        self._switch_state(self.DONE)
        self._hide_timer.start(_DONE_SHOW_MS)

    @Slot(str)
    def show_error(self, message: str) -> None:
        self._error_message = message
        self._switch_state(self.ERROR)
        self._hide_timer.start(_ERROR_SHOW_MS)

    def set_amplitude(self, value: float) -> None:
        self._amplitude = max(0.0, min(1.0, value))

    @Slot()
    def dismiss(self) -> None:
        self._hide_timer.stop()
        self._anim_timer.stop()
        self._fade_anim.stop()
        self._fading_out = False
        self._state = None
        self.hide()

    # ── State Management ────────────────────────────────────────

    def _switch_state(self, new_state: str) -> None:
        old = self._state
        self._state = new_state
        self._fading_out = False
        self._hide_timer.stop()
        self._fade_anim.stop()

        if new_state != old:
            self._tick = 0

        # Animations-Timer
        needs_anim = new_state in (self.RECORDING, self.TRANSCRIBING, self.FORMATTING)
        if needs_anim and not self._anim_timer.isActive():
            self._anim_timer.start()
        elif not needs_anim:
            self._anim_timer.stop()

        # Zeigen
        if not self.isVisible() or old is None:
            # Erstmaliges Erscheinen: positionieren + fade-in
            self._position()
            self.setWindowOpacity(0.0)
            self.show()
            self._fade_in()
        # Bereits sichtbar → kein harter Opacity-Sprung, einfach weiter-rendern

        self.update()
        log.debug("Overlay: %s -> %s", old, new_state)

    def _position(self) -> None:
        cursor_pos = QCursor.pos()
        mode = self._config.get("general.overlay_position", "mouse_cursor")

        # Screen ermitteln: dort wo der Cursor ist (Multi-Monitor-Support)
        screen = QApplication.screenAt(cursor_pos)
        if not screen:
            screen = QApplication.primaryScreen()
        if not screen:
            return
        geo = screen.availableGeometry()

        if mode == "bottom_center":
            x = geo.x() + (geo.width() - _WIDTH) // 2
            y = geo.y() + geo.height() - _HEIGHT - 80
        else:
            x = cursor_pos.x() - _WIDTH // 2
            y = cursor_pos.y() - _HEIGHT - 16
            # Bildschirmgrenzen des aktuellen Monitors beachten
            x = max(geo.x(), min(x, geo.x() + geo.width() - _WIDTH))
            y = max(geo.y(), min(y, geo.y() + geo.height() - _HEIGHT))

        self.move(x, y)

    # ── Animations ──────────────────────────────────────────────

    def _fade_in(self) -> None:
        self._fading_out = False
        self._fade_anim.stop()
        self._fade_anim.setDuration(_FADE_IN_MS)
        self._fade_anim.setStartValue(0.0)
        self._fade_anim.setEndValue(1.0)
        self._fade_anim.start()

    def _start_fade_out(self) -> None:
        self._fading_out = True
        self._fade_anim.stop()
        self._fade_anim.setDuration(_FADE_OUT_MS)
        self._fade_anim.setStartValue(self.windowOpacity())
        self._fade_anim.setEndValue(0.0)
        self._fade_anim.start()

    def _on_fade_finished(self) -> None:
        if self._fading_out:
            self._state = None
            self._fading_out = False
            self._anim_timer.stop()
            self.hide()

    def _on_tick(self) -> None:
        self._tick += 1
        if self._state == self.RECORDING:
            self._update_bars()
        self.update()

    def _update_bars(self) -> None:
        amp = min(1.0, self._amplitude * _VISUAL_GAIN)
        for i in range(len(self._bar_heights)):
            target = amp * random.uniform(0.4, 1.3)
            target = max(0.0, min(1.0, target))
            self._bar_heights[i] += (target - self._bar_heights[i]) * _SMOOTHING

    # ── Painting ────────────────────────────────────────────────

    def paintEvent(self, event: object) -> None:
        if self._state is None:
            return

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        accent = self._accent_color()
        self._draw_bg(p, accent)

        if self._state == self.RECORDING:
            self._draw_recording(p)
        elif self._state in (self.TRANSCRIBING, self.FORMATTING):
            self._draw_processing(p)
        elif self._state == self.DONE:
            self._draw_done(p)
        elif self._state == self.ERROR:
            self._draw_error(p)

        p.end()

    def _accent_color(self) -> QColor:
        if self._state == self.DONE:
            return _GREEN
        if self._state == self.ERROR:
            return _RED
        return _WHITE

    def _draw_bg(self, p: QPainter, accent: QColor) -> None:
        """Glassmorphism-Hintergrund mit weissem Rand."""
        pill = QPainterPath()
        pill.addRoundedRect(QRectF(0, 0, _WIDTH, _HEIGHT), _RADIUS, _RADIUS)

        # Hintergrund
        p.fillPath(pill, _BG_COLOR)

        # Weisser Rand (clean)
        p.setPen(QPen(_BORDER_COLOR, 1.0))
        p.drawRoundedRect(QRectF(0.5, 0.5, _WIDTH - 1, _HEIGHT - 1), _RADIUS, _RADIUS)

    def _draw_recording(self, p: QPainter) -> None:
        """Audio-Visualizer: weisse Balken mit hellem Gradient."""
        total_w = _BAR_COUNT * _BAR_W + (_BAR_COUNT - 1) * _BAR_GAP
        sx = (_WIDTH - total_w) / 2
        cy = _HEIGHT / 2

        p.setPen(Qt.PenStyle.NoPen)

        for i, bh in enumerate(self._bar_heights):
            h = _BAR_MIN_H + bh * (_BAR_MAX_H - _BAR_MIN_H)
            x = sx + i * (_BAR_W + _BAR_GAP)
            y = cy - h / 2

            # Vertikaler Gradient: halbtransparent unten → weiss oben
            grad = QLinearGradient(x, y + h, x, y)
            base = QColor(255, 255, 255, 140)
            grad.setColorAt(0.0, base)
            grad.setColorAt(1.0, _WHITE)

            p.setBrush(grad)
            p.drawRoundedRect(QRectF(x, y, _BAR_W, h), _BAR_W / 2, _BAR_W / 2)

    def _draw_processing(self, p: QPainter) -> None:
        """Pulsierende weisse Dots + Label."""
        label = "Transkribiere..." if self._state == self.TRANSCRIBING else "Formatiere..."

        dots_total_w = (_DOT_COUNT - 1) * _DOT_GAP + _DOT_RADIUS * 2
        content_w = dots_total_w + 12 + len(label) * 6.5
        start_x = max(_RADIUS + 6, (_WIDTH - content_w) / 2)
        cy = _HEIGHT / 2

        t = self._tick * _FPS_INTERVAL / 1000.0
        for i in range(_DOT_COUNT):
            dx = start_x + _DOT_RADIUS + i * _DOT_GAP
            phase = t * 4.0 - i * _DOT_PHASE_OFFSET
            bounce = max(0.0, math.sin(phase)) ** 2
            dy = cy - bounce * 5

            alpha = int(80 + bounce * 175)
            dot_color = QColor(255, 255, 255, alpha)

            # Dot
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(dot_color)
            p.drawEllipse(QRectF(dx - _DOT_RADIUS, dy - _DOT_RADIUS,
                                 _DOT_RADIUS * 2, _DOT_RADIUS * 2))

        # Text
        text_x = start_x + dots_total_w + 12
        font = QFont("Segoe UI", 9)
        font.setWeight(QFont.Weight.Medium)
        p.setFont(font)
        p.setPen(QPen(_TEXT_DIM))
        p.drawText(QRectF(text_x, 0, _WIDTH - text_x - 10, _HEIGHT),
                   Qt.AlignmentFlag.AlignVCenter, label)

    def _draw_done(self, p: QPainter) -> None:
        """Gruener Checkmark mit Glow."""
        cx = _WIDTH / 2
        cy = _HEIGHT / 2

        # Subtiler Glow
        glow = QRadialGradient(cx, cy, 18)
        g = QColor(_GREEN)
        g.setAlpha(35)
        glow.setColorAt(0.0, g)
        glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(glow)
        p.drawEllipse(QRectF(cx - 18, cy - 18, 36, 36))

        # Checkmark
        pen = QPen(_GREEN, 2.0, Qt.PenStyle.SolidLine,
                   Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen)
        p.drawLine(int(cx - 6), int(cy), int(cx - 2), int(cy + 5))
        p.drawLine(int(cx - 2), int(cy + 5), int(cx + 7), int(cy - 4))

    def _draw_error(self, p: QPainter) -> None:
        """Rotes X + Fehlermeldung."""
        ix = 24
        cy = _HEIGHT / 2

        # Glow
        glow = QRadialGradient(ix, cy, 12)
        g = QColor(_RED)
        g.setAlpha(30)
        glow.setColorAt(0.0, g)
        glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(glow)
        p.drawEllipse(QRectF(ix - 12, cy - 12, 24, 24))

        # X
        pen = QPen(_RED, 2.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        p.drawLine(int(ix - 4), int(cy - 4), int(ix + 4), int(cy + 4))
        p.drawLine(int(ix + 4), int(cy - 4), int(ix - 4), int(cy + 4))

        # Text
        font = QFont("Segoe UI", 8)
        font.setWeight(QFont.Weight.Medium)
        p.setFont(font)
        p.setPen(QPen(_TEXT_PRIMARY))
        msg = self._error_message or "Fehler"
        p.drawText(QRectF(ix + 14, 0, _WIDTH - ix - 24, _HEIGHT),
                   Qt.AlignmentFlag.AlignVCenter | Qt.TextFlag.TextSingleLine, msg)
