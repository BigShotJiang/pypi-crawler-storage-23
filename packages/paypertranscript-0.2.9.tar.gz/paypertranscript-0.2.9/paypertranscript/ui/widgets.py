"""Wiederverwendbare UI-Widgets fuer PayPerTranscript.

StatCard, CostSplitBar, CostBarChart - extrahiert aus statistics.py.
"""

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QFont, QPainter
from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout, QWidget


class StatCard(QFrame):
    """Einzelne Statistik-Karte mit Titel und Wert."""

    def __init__(self, title: str, value: str = "-", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setProperty("stat-card", True)
        self.setStyleSheet(
            "background-color: #1c1c24; border: 1px solid #333340; border-radius: 8px;"
        )
        self.setMinimumHeight(62)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(4)

        self._title_label = QLabel(title)
        self._title_label.setStyleSheet("color: #a0a0a0; font-size: 8pt; border: none;")
        layout.addWidget(self._title_label)

        self._value_label = QLabel(value)
        self._value_label.setStyleSheet("color: #ffffff; font-size: 12pt; font-weight: bold; border: none;")
        layout.addWidget(self._value_label)

    def set_value(self, value: str) -> None:
        """Setzt den angezeigten Wert."""
        self._value_label.setText(value)

    def set_color(self, color: str) -> None:
        """Setzt die Farbe des Werts."""
        self._value_label.setStyleSheet(
            f"color: {color}; font-size: 12pt; font-weight: bold; border: none;"
        )


class CostSplitBar(QWidget):
    """Horizontaler Proportionsbalken: Transkription vs. Formatierung."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._stt_ratio = 0.0
        self._stt_label = ""
        self._llm_label = ""
        self.setFixedHeight(48)
        self.setStyleSheet("background-color: transparent;")

    def set_data(self, stt_cost: float, llm_cost: float) -> None:
        """Setzt die Kostendaten."""
        total = stt_cost + llm_cost
        if total > 0:
            self._stt_ratio = stt_cost / total
        else:
            self._stt_ratio = 1.0

        stt_pct = self._stt_ratio * 100
        llm_pct = 100 - stt_pct
        self._stt_label = f"Transkription ${stt_cost:.4f} ({stt_pct:.0f}%)"
        self._llm_label = f"Formatierung ${llm_cost:.4f} ({llm_pct:.0f}%)"
        self.update()

    def paintEvent(self, event: object) -> None:
        """Zeichnet den Proportionsbalken."""
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        bar_y = 0
        bar_h = 20
        radius = 4

        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#a0a0a0"))
        p.drawRoundedRect(0, bar_y, w, bar_h, radius, radius)

        stt_w = max(0, int(w * self._stt_ratio))
        if stt_w > 0:
            p.setBrush(QColor("#ffffff"))
            if stt_w >= w:
                p.drawRoundedRect(0, bar_y, stt_w, bar_h, radius, radius)
            else:
                p.drawRoundedRect(0, bar_y, stt_w + radius, bar_h, radius, radius)
                p.drawRect(stt_w, bar_y, radius, bar_h)

        font = QFont("Segoe UI", 9)
        p.setFont(font)
        p.setPen(QColor("#a0a0a0"))

        if self._stt_label:
            p.drawText(0, bar_y + bar_h + 16, self._stt_label)
        if self._llm_label:
            fm = p.fontMetrics()
            text_w = fm.horizontalAdvance(self._llm_label)
            p.drawText(w - text_w, bar_y + bar_h + 16, self._llm_label)

        p.end()


class CostBarChart(QWidget):
    """Einfaches Balkendiagramm fuer Kosten-Verlauf (letzte 7/30 Tage)."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._data: list[tuple[str, float]] = []
        self.setMinimumHeight(120)
        self.setStyleSheet("background-color: transparent;")

    def set_data(self, data: list[tuple[str, float]]) -> None:
        """Setzt die Daten fuer das Diagramm."""
        self._data = data
        self.update()

    def paintEvent(self, event: object) -> None:
        """Zeichnet das Balkendiagramm."""
        if not self._data:
            return

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        w = self.width()
        h = self.height()
        margin_bottom = 20
        margin_top = 10
        chart_h = h - margin_bottom - margin_top

        max_val = max((v for _, v in self._data), default=0.0)
        if max_val <= 0:
            max_val = 0.001

        bar_count = len(self._data)
        if bar_count == 0:
            p.end()
            return

        gap = 4
        bar_w = max(4, (w - (bar_count + 1) * gap) / bar_count)

        font = QFont("Segoe UI", 7)
        p.setFont(font)

        for i, (label, value) in enumerate(self._data):
            x = gap + i * (bar_w + gap)
            bar_h = max(2, (value / max_val) * chart_h)
            y = margin_top + chart_h - bar_h

            color = QColor("#ffffff")
            color.setAlpha(180)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(color)
            p.drawRoundedRect(int(x), int(y), int(bar_w), int(bar_h), 2, 2)

            if bar_count <= 7 or i % 5 == 0 or i == bar_count - 1:
                p.setPen(QColor("#a0a0a0"))
                p.drawText(int(x), h - 2, label)

        p.end()
