"""Statistik-Seite fuer das MainWindow.

Zeigt Nutzungsstatistiken, Kosten und Abo-Vergleichsrechnung.
"""

from collections import defaultdict
from datetime import datetime, timedelta, timezone

from PySide6.QtWidgets import (
    QComboBox,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)
from PySide6.QtCore import Qt

from paypertranscript.core.logging import get_logger
from paypertranscript.core.session_logger import SessionLogger
from paypertranscript.ui.widgets import CostBarChart, CostSplitBar, StatCard

log = get_logger("ui.pages.statistics")

_USD_TO_EUR = 0.92


class StatisticsPage(QWidget):
    """Statistik-Dashboard mit Kosten, Nutzung und Vergleich."""

    def __init__(
        self,
        session_logger: SessionLogger,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._logger = session_logger
        self._setup_ui()

    def _setup_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { border: none; background-color: transparent; }")

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(28, 28, 28, 28)
        layout.setSpacing(12)

        title = QLabel("Statistiken")
        title.setProperty("heading", True)
        layout.addWidget(title)

        # Haupt-Karten: 2x2 Grid
        grid = QGridLayout()
        grid.setSpacing(10)

        self._card_total_cost = StatCard("Gesamtkosten")
        self._card_monthly_projection = StatCard("Hochrechnung / Monat")
        self._card_sessions = StatCard("Transkriptionen")
        self._card_audio_time = StatCard("Audio-Dauer gesamt")

        grid.addWidget(self._card_total_cost, 0, 0)
        grid.addWidget(self._card_monthly_projection, 0, 1)
        grid.addWidget(self._card_sessions, 1, 0)
        grid.addWidget(self._card_audio_time, 1, 1)
        layout.addLayout(grid)

        # Zusaetzliche Metriken
        metrics_row = QHBoxLayout()
        metrics_row.setSpacing(10)

        self._card_avg_duration = StatCard("Durchschn. Aufnahme")
        self._card_avg_cost = StatCard("Durchschn. Kosten")
        metrics_row.addWidget(self._card_avg_duration)
        metrics_row.addWidget(self._card_avg_cost)
        layout.addLayout(metrics_row)

        # Kostenaufteilung
        split_label = QLabel("Kostenaufteilung")
        split_label.setStyleSheet("font-weight: bold; color: #ffffff;")
        layout.addWidget(split_label)

        self._cost_split = CostSplitBar()
        layout.addWidget(self._cost_split)

        # Kosten-Verlauf
        chart_header = QHBoxLayout()
        chart_label = QLabel("Kosten-Verlauf")
        chart_label.setStyleSheet("font-weight: bold; color: #ffffff;")
        chart_header.addWidget(chart_label)
        chart_header.addStretch()

        self._period_combo = QComboBox()
        self._period_combo.addItems(["Letzte 7 Tage", "Letzte 30 Tage"])
        self._period_combo.currentIndexChanged.connect(self._on_period_changed)
        self._period_combo.setFixedWidth(140)
        chart_header.addWidget(self._period_combo)
        layout.addLayout(chart_header)

        self._cost_chart = CostBarChart()
        layout.addWidget(self._cost_chart)

        # Top Apps
        apps_label = QLabel("Meistgenutzte Apps")
        apps_label.setStyleSheet("font-weight: bold; color: #ffffff;")
        layout.addWidget(apps_label)

        self._apps_label = QLabel("-")
        self._apps_label.setProperty("subheading", True)
        self._apps_label.setWordWrap(True)
        layout.addWidget(self._apps_label)

        layout.addStretch()

        scroll.setWidget(container)
        outer.addWidget(scroll)

    def showEvent(self, event: object) -> None:
        """Daten bei jedem Anzeigen aktualisieren."""
        super().showEvent(event)
        self._refresh_data()

    def _refresh_data(self) -> None:
        """Laedt alle Daten und aktualisiert die Anzeige."""
        totals = self._logger.get_totals()
        sessions = self._logger.get_sessions()

        total_usd = totals.get("total_cost_usd", 0.0)
        total_eur = total_usd * _USD_TO_EUR
        count = totals.get("session_count", 0)

        self._card_total_cost.set_value(f"${total_usd:.4f} (~{total_eur:.4f} EUR)")
        self._card_sessions.set_value(str(count))

        if sessions and count > 0:
            first_ts = sessions[0].get("timestamp", "")
            try:
                first_dt = datetime.fromisoformat(first_ts)
                now = datetime.now(timezone.utc)
                days_active = max(1, (now - first_dt).days)
            except (ValueError, TypeError):
                days_active = 1

            daily_cost = total_usd / days_active
            monthly_usd = daily_cost * 30
            monthly_eur = monthly_usd * _USD_TO_EUR
            self._card_monthly_projection.set_value(f"~${monthly_usd:.4f} (~{monthly_eur:.4f} EUR)")
        else:
            self._card_monthly_projection.set_value("-")

        total_seconds = totals.get("total_audio_seconds", 0.0)
        minutes = total_seconds / 60.0
        if minutes >= 60:
            self._card_audio_time.set_value(f"{minutes / 60:.1f} Stunden")
        else:
            self._card_audio_time.set_value(f"{minutes:.1f} Minuten")

        if count > 0:
            avg_sec = total_seconds / count
            self._card_avg_duration.set_value(f"{avg_sec:.1f}s")
        else:
            self._card_avg_duration.set_value("-")

        if count > 0:
            avg_cost = total_usd / count
            self._card_avg_cost.set_value(f"${avg_cost:.6f}")
        else:
            self._card_avg_cost.set_value("-")

        stt_cost = totals.get("total_stt_cost_usd", 0.0)
        llm_cost = totals.get("total_llm_cost_usd", 0.0)
        self._cost_split.set_data(stt_cost, llm_cost)

        self._update_chart(7)
        self._update_top_apps(sessions)

    def _on_period_changed(self, index: int) -> None:
        days = 7 if index == 0 else 30
        self._update_chart(days)

    def _update_chart(self, days: int) -> None:
        sessions = self._logger.get_sessions(days=days)

        daily_costs: dict[str, float] = defaultdict(float)
        for s in sessions:
            try:
                dt = datetime.fromisoformat(s["timestamp"])
                day_key = dt.strftime("%d.%m")
                daily_costs[day_key] += s.get("total_cost_usd", 0.0)
            except (KeyError, ValueError):
                pass

        chart_data: list[tuple[str, float]] = []
        now = datetime.now(timezone.utc)
        for i in range(days - 1, -1, -1):
            day = now - timedelta(days=i)
            key = day.strftime("%d.%m")
            chart_data.append((key, daily_costs.get(key, 0.0)))

        self._cost_chart.set_data(chart_data)

    def _update_top_apps(self, sessions: list[dict]) -> None:
        app_counts: dict[str, int] = defaultdict(int)
        for s in sessions:
            proc = s.get("window_process", "")
            if proc:
                app_counts[proc] += 1

        if not app_counts:
            self._apps_label.setText("Noch keine Daten")
            return

        top5 = sorted(app_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        lines = [f"{name} ({count}x)" for name, count in top5]
        self._apps_label.setText("  |  ".join(lines))
