"""Home-Seite fuer das MainWindow.

Zeigt Konfigurationsuebersicht, Tagesstatistiken, letzte Transkription und API-Status.
"""

from collections.abc import Callable
from datetime import datetime, timezone

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.core.config import ConfigManager, load_api_key
from paypertranscript.core.logging import get_logger
from paypertranscript.core.session_logger import SessionLogger
from paypertranscript.ui.constants import LANGUAGES
from paypertranscript.ui.widgets import StatCard

log = get_logger("ui.pages.home")

# Lookup: ISO-Code → Anzeigename
_LANG_NAMES: dict[str, str] = {code: name for code, name in LANGUAGES}


def _format_hotkey(keys: list[str] | None) -> str:
    """Formatiert eine Hotkey-Liste als lesbaren String."""
    if not keys:
        return "(nicht konfiguriert)"
    return " + ".join(k.title() for k in keys)


class HomePage(QWidget):
    """Dashboard-Seite mit Konfigurationsuebersicht, Stats und letzter Transkription."""

    def __init__(
        self,
        config: ConfigManager,
        session_logger: SessionLogger | None = None,
        get_last_transcription: Callable[[], str | None] | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._config = config
        self._session_logger = session_logger
        self._get_last_transcription = get_last_transcription
        self._setup_ui()

    def _setup_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { border: none; background-color: transparent; }")

        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(28, 28, 28, 28)
        layout.setSpacing(20)

        # Titel
        title = QLabel("Home")
        title.setProperty("heading", True)
        layout.addWidget(title)

        # -- Konfigurationsuebersicht --
        config_card = QWidget()
        config_card.setStyleSheet(
            "background-color: #1c1c24; border: 1px solid #333340; border-radius: 8px;"
        )
        config_layout = QVBoxLayout(config_card)
        config_layout.setContentsMargins(16, 14, 16, 14)
        config_layout.setSpacing(10)

        # Row 1: Hotkeys
        hotkey_row = QHBoxLayout()
        hotkey_row.setSpacing(0)
        lbl = QLabel("Hotkeys")
        lbl.setFixedWidth(80)
        lbl.setStyleSheet("color: #a0a0a0; font-size: 9pt; border: none;")
        hotkey_row.addWidget(lbl)
        self._hotkey_value = QLabel()
        self._hotkey_value.setStyleSheet("color: #ffffff; font-size: 9pt; border: none;")
        hotkey_row.addWidget(self._hotkey_value, 1)
        config_layout.addLayout(hotkey_row)

        # Trennlinie
        sep1 = QWidget()
        sep1.setFixedHeight(1)
        sep1.setStyleSheet("background-color: #333340; border: none;")
        config_layout.addWidget(sep1)

        # Row 2: Modelle
        model_row = QHBoxLayout()
        model_row.setSpacing(0)
        lbl2 = QLabel("Modelle")
        lbl2.setFixedWidth(80)
        lbl2.setStyleSheet("color: #a0a0a0; font-size: 9pt; border: none;")
        model_row.addWidget(lbl2)
        self._model_value = QLabel()
        self._model_value.setStyleSheet("color: #ffffff; font-size: 9pt; border: none;")
        model_row.addWidget(self._model_value, 1)
        config_layout.addLayout(model_row)

        # Trennlinie
        sep2 = QWidget()
        sep2.setFixedHeight(1)
        sep2.setStyleSheet("background-color: #333340; border: none;")
        config_layout.addWidget(sep2)

        # Row 3: Sprache + Status
        status_row = QHBoxLayout()
        status_row.setSpacing(0)
        lbl3 = QLabel("Status")
        lbl3.setFixedWidth(80)
        lbl3.setStyleSheet("color: #a0a0a0; font-size: 9pt; border: none;")
        status_row.addWidget(lbl3)
        self._status_value = QLabel()
        self._status_value.setStyleSheet("color: #ffffff; font-size: 9pt; border: none;")
        status_row.addWidget(self._status_value, 1)
        config_layout.addLayout(status_row)

        layout.addWidget(config_card)

        # -- Tagesstatistiken --
        stats_row = QHBoxLayout()
        stats_row.setSpacing(10)

        self._card_sessions = StatCard("Heutige Transkriptionen")
        self._card_cost = StatCard("Heutige Kosten")
        self._card_audio = StatCard("Heutige Audiozeit")

        stats_row.addWidget(self._card_sessions)
        stats_row.addWidget(self._card_cost)
        stats_row.addWidget(self._card_audio)
        layout.addLayout(stats_row)

        # -- Letzte Transkriptionen --
        recent_card = QWidget()
        recent_card.setStyleSheet(
            "background-color: #1c1c24; border: 1px solid #333340; border-radius: 8px;"
        )
        recent_outer = QVBoxLayout(recent_card)
        recent_outer.setContentsMargins(16, 14, 16, 14)
        recent_outer.setSpacing(8)

        recent_header = QHBoxLayout()
        recent_title = QLabel("Letzte Transkriptionen")
        recent_title.setStyleSheet("color: #a0a0a0; font-size: 8pt; border: none;")
        recent_header.addWidget(recent_title)
        recent_header.addStretch()

        self._btn_copy = QPushButton("Letzte kopieren")
        self._btn_copy.setEnabled(False)
        self._btn_copy.setCursor(Qt.CursorShape.PointingHandCursor)
        self._btn_copy.setFixedHeight(24)
        self._btn_copy.setStyleSheet(
            "QPushButton {"
            "  background-color: #2a2a34; color: #ffffff; border: 1px solid #333340;"
            "  border-radius: 4px; padding: 2px 12px; font-size: 8pt;"
            "}"
            "QPushButton:hover { background-color: #333340; }"
            "QPushButton:disabled { color: #606060; background-color: #1c1c24; }"
        )
        self._btn_copy.clicked.connect(self._on_copy_last)
        recent_header.addWidget(self._btn_copy)
        recent_outer.addLayout(recent_header)

        # Tabelle fuer die einzelnen Zeilen (wird in _refresh befuellt)
        self._recent_grid = QGridLayout()
        self._recent_grid.setSpacing(0)
        self._recent_grid.setContentsMargins(0, 0, 0, 0)
        self._recent_grid.setColumnStretch(1, 1)  # App-Spalte darf wachsen
        recent_outer.addLayout(self._recent_grid)

        self._no_sessions_label = QLabel("Noch keine Transkription heute")
        self._no_sessions_label.setStyleSheet("color: #606060; font-size: 9pt; border: none;")
        recent_outer.addWidget(self._no_sessions_label)

        layout.addWidget(recent_card)

        layout.addStretch()

        scroll.setWidget(container)
        outer.addWidget(scroll)

    def showEvent(self, event: object) -> None:
        """Daten bei jedem Anzeigen aktualisieren."""
        super().showEvent(event)
        self._refresh()

    def _refresh(self) -> None:
        """Aktualisiert alle angezeigten Daten."""
        # -- Hotkeys --
        hold = self._config.get("general.hold_hotkey", ["ctrl", "cmd"])
        toggle = self._config.get("general.toggle_hotkey")
        hold_str = _format_hotkey(hold)
        parts = [f"Hold-to-Record: {hold_str}"]
        if toggle:
            parts.append(f"Toggle: {_format_hotkey(toggle)}")
        self._hotkey_value.setText("  ·  ".join(parts))

        # -- Modelle --
        stt_model = self._config.get("api.stt_model", "whisper-large-v3-turbo")
        llm_model = self._config.get("api.llm_model", "openai/gpt-oss-20b")
        self._model_value.setText(f"STT: {stt_model}  ·  LLM: {llm_model}")

        # -- Sprache + API-Status --
        lang_code = self._config.get("stt.language", "de")
        lang_name = _LANG_NAMES.get(lang_code, lang_code)
        api_key = load_api_key()
        if api_key:
            status_text = f"{lang_name}  ·  <span style='color:#34d399;'>Bereit</span>"
        else:
            status_text = f"{lang_name}  ·  <span style='color:#f87171;'>API-Key fehlt</span>"
        self._status_value.setText(status_text)
        self._status_value.setTextFormat(Qt.TextFormat.RichText)

        # -- Tagesstatistiken --
        sessions: list[dict] = []
        if self._session_logger:
            sessions = self._session_logger.get_sessions(days=1)
            count = len(sessions)
            cost = sum(s.get("total_cost_usd", 0.0) for s in sessions)
            audio_sec = sum(s.get("audio_duration_seconds", 0.0) for s in sessions)

            self._card_sessions.set_value(str(count))
            self._card_cost.set_value(f"${cost:.4f}")

            if audio_sec >= 60:
                self._card_audio.set_value(f"{audio_sec / 60:.1f} Min")
            else:
                self._card_audio.set_value(f"{audio_sec:.0f}s")
        else:
            self._card_sessions.set_value("-")
            self._card_cost.set_value("-")
            self._card_audio.set_value("-")

        # -- Letzte Transkriptionen --
        # Alte Zellen entfernen
        while self._recent_grid.count():
            item = self._recent_grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        has_transcription = (
            self._get_last_transcription is not None
            and self._get_last_transcription() is not None
        )

        if sessions:
            self._no_sessions_label.setVisible(False)
            # Letzte 5, neueste zuerst
            recent = list(reversed(sessions[-5:]))
            for row, s in enumerate(recent):
                ts = s.get("timestamp", "")
                try:
                    dt = datetime.fromisoformat(ts)
                    time_str = dt.strftime("%H:%M")
                except (ValueError, TypeError):
                    time_str = "?"
                process = s.get("window_process", "")
                duration = s.get("audio_duration_seconds", 0.0)
                cost_usd = s.get("total_cost_usd", 0.0)
                out_tokens = s.get("llm_output_tokens", 0)

                color = "#ffffff" if row == 0 else "#a0a0a0"
                cell_style = f"color: {color}; font-size: 9pt; border: none; padding: 3px 0px;"

                # Spalte 0: Zeit
                lbl_time = QLabel(time_str)
                lbl_time.setStyleSheet(cell_style)
                lbl_time.setFixedWidth(42)
                self._recent_grid.addWidget(lbl_time, row, 0)

                # Spalte 1: App (nur wenn bekannt)
                app_name = ""
                if process:
                    app_name = process.rsplit(".exe", 1)[0] if process.endswith(".exe") else process
                lbl_app = QLabel(app_name)
                lbl_app.setStyleSheet(cell_style)
                self._recent_grid.addWidget(lbl_app, row, 1)

                # Spalte 2: Dauer
                lbl_dur = QLabel(f"{duration:.1f}s")
                lbl_dur.setStyleSheet(cell_style)
                lbl_dur.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                lbl_dur.setFixedWidth(46)
                self._recent_grid.addWidget(lbl_dur, row, 2)

                # Spalte 3: Kosten
                lbl_cost = QLabel(f"${cost_usd:.4f}")
                lbl_cost.setStyleSheet(cell_style)
                lbl_cost.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                lbl_cost.setFixedWidth(62)
                self._recent_grid.addWidget(lbl_cost, row, 3)

                # Spalte 4: Tokens
                tok_text = f"{out_tokens} tok" if out_tokens else ""
                lbl_tok = QLabel(tok_text)
                lbl_tok.setStyleSheet(cell_style)
                lbl_tok.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                lbl_tok.setFixedWidth(58)
                self._recent_grid.addWidget(lbl_tok, row, 4)

            self._btn_copy.setEnabled(has_transcription)
        else:
            self._no_sessions_label.setVisible(True)
            self._btn_copy.setEnabled(has_transcription)

    def _on_copy_last(self) -> None:
        """Kopiert die letzte Transkription in die Zwischenablage."""
        if not self._get_last_transcription:
            return
        text = self._get_last_transcription()
        if text:
            import pyperclip

            try:
                pyperclip.copy(text)
                self._btn_copy.setText("Kopiert!")
                # Reset nach 2s
                from PySide6.QtCore import QTimer

                QTimer.singleShot(2000, lambda: self._btn_copy.setText("Letzte kopieren"))
                log.info("Letzte Transkription kopiert (%d Zeichen)", len(text))
            except Exception as e:
                log.error("Kopieren fehlgeschlagen: %s", e)
