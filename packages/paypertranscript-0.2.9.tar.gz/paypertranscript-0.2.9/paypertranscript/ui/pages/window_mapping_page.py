"""Fenster-Zuordnungs-Seite fuer das MainWindow.

Verwaltet Window-Mappings (Prozessname -> Kategorie) und Kategorien.
"""

from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import QEvent, QModelIndex, QRect, QSize, Qt
from PySide6.QtGui import QColor, QCursor, QFont, QMouseEvent, QPainter
from PySide6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QStyle,
    QStyleOptionViewItem,
    QStyledItemDelegate,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from paypertranscript.core.config import ConfigManager
from paypertranscript.core.logging import get_logger

log = get_logger("ui.pages.window_mapping")

# Segoe MDL2 Assets icon codepoints (Windows 10/11 vector icons)
_ICON_FONT = "Segoe MDL2 Assets"
_ICON_EDIT = "\uE70F"    # Edit / Pencil
_ICON_DELETE = "\uE711"  # Delete / X


class _MappingItemDelegate(QStyledItemDelegate):
    """Delegate for mapping items: process → category with edit + delete icons."""

    _ICON_SIZE = 32
    _ICONS_TOTAL = _ICON_SIZE * 2 + 4  # edit + delete + small gap

    def __init__(
        self,
        on_edit: Callable[[int], None],
        on_delete: Callable[[int], None],
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._on_edit = on_edit
        self._on_delete = on_delete

    def paint(
        self, painter: QPainter, option: QStyleOptionViewItem, index: QModelIndex
    ) -> None:
        option.state &= ~QStyle.StateFlag.State_HasFocus

        # --- Background ---
        painter.save()
        if option.state & QStyle.StateFlag.State_Selected:
            painter.fillRect(option.rect, QColor("#2a2a34"))
        elif option.state & QStyle.StateFlag.State_MouseOver:
            painter.fillRect(option.rect, QColor("#121218"))
        painter.restore()

        hovered = bool(option.state & QStyle.StateFlag.State_MouseOver)
        color_icon_on = QColor("#a0a0a0")
        color_icon_off = QColor("#4a4a58")

        # Parse stored data: "process_name\ncategory_display_name"
        raw = index.data(Qt.ItemDataRole.DisplayRole) or ""
        parts = raw.split("\n", 1)
        process_name = parts[0] if parts else ""
        category_name = parts[1] if len(parts) > 1 else ""

        # --- Text: process → category ---
        text_rect = QRect(
            option.rect.left() + 12,
            option.rect.top(),
            option.rect.width() - 12 - self._ICONS_TOTAL - 8,
            option.rect.height(),
        )

        painter.save()
        bold_font = QFont("Segoe UI", 10)
        bold_font.setBold(True)
        painter.setFont(bold_font)
        painter.setPen(QColor("#ffffff"))
        fm_bold = painter.fontMetrics()
        process_width = fm_bold.horizontalAdvance(process_name)
        painter.drawText(
            text_rect,
            Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
            process_name,
        )
        painter.restore()

        arrow = "  \u2192  "
        painter.save()
        normal_font = QFont("Segoe UI", 10)
        painter.setFont(normal_font)
        painter.setPen(QColor("#606060"))
        fm_normal = painter.fontMetrics()
        arrow_width = fm_normal.horizontalAdvance(arrow)
        arrow_rect = QRect(
            text_rect.left() + process_width,
            text_rect.top(),
            arrow_width,
            text_rect.height(),
        )
        painter.drawText(
            arrow_rect,
            Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
            arrow,
        )
        painter.restore()

        painter.save()
        painter.setFont(normal_font)
        painter.setPen(QColor("#a0a0a0"))
        cat_rect = QRect(
            text_rect.left() + process_width + arrow_width,
            text_rect.top(),
            text_rect.width() - process_width - arrow_width,
            text_rect.height(),
        )
        painter.drawText(
            cat_rect,
            Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
            category_name,
        )
        painter.restore()

        # --- Right: edit + delete icons ---
        icon_font = QFont(_ICON_FONT, 10)

        edit_rect = QRect(
            option.rect.right() - self._ICONS_TOTAL,
            option.rect.top(),
            self._ICON_SIZE,
            option.rect.height(),
        )
        delete_rect = QRect(
            option.rect.right() - self._ICON_SIZE,
            option.rect.top(),
            self._ICON_SIZE,
            option.rect.height(),
        )

        painter.save()
        painter.setFont(icon_font)
        painter.setPen(color_icon_on if hovered else color_icon_off)
        painter.drawText(edit_rect, Qt.AlignmentFlag.AlignCenter, _ICON_EDIT)
        painter.drawText(delete_rect, Qt.AlignmentFlag.AlignCenter, _ICON_DELETE)
        painter.restore()

    def editorEvent(
        self,
        event: QEvent,
        model: QModelIndex,
        option: QStyleOptionViewItem,
        index: QModelIndex,
    ) -> bool:
        # Click handling is done via viewport event filter in WindowMappingPage
        # (editorEvent does not receive MouseButtonRelease with default edit triggers)
        if event.type() == QEvent.Type.MouseMove:
            mouse: QMouseEvent = event  # type: ignore[assignment]
            over_icon = mouse.position().x() >= option.rect.right() - self._ICONS_TOTAL
            view = option.widget
            if view is not None:
                if over_icon:
                    view.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
                else:
                    view.unsetCursor()
            return False
        return super().editorEvent(event, model, option, index)

    def sizeHint(self, option: QStyleOptionViewItem, index: QModelIndex) -> QSize:
        size = super().sizeHint(option, index)
        return QSize(size.width(), max(size.height(), 40))


class _CategoryItemDelegate(QStyledItemDelegate):
    """Delegate for category items: name with delete icon on hover."""

    _ICON_SIZE = 32

    def __init__(
        self,
        on_delete: Callable[[int], None],
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._on_delete = on_delete

    def paint(
        self, painter: QPainter, option: QStyleOptionViewItem, index: QModelIndex
    ) -> None:
        option.state &= ~QStyle.StateFlag.State_HasFocus

        painter.save()
        if option.state & QStyle.StateFlag.State_Selected:
            painter.fillRect(option.rect, QColor("#2a2a34"))
        elif option.state & QStyle.StateFlag.State_MouseOver:
            painter.fillRect(option.rect, QColor("#121218"))
        painter.restore()

        hovered = bool(option.state & QStyle.StateFlag.State_MouseOver)

        # --- Text ---
        text_rect = QRect(
            option.rect.left() + 10,
            option.rect.top(),
            option.rect.width() - 10 - self._ICON_SIZE - 4,
            option.rect.height(),
        )
        painter.save()
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        painter.setPen(QColor("#ffffff") if selected else QColor("#e0e0e0"))
        painter.setFont(QFont("Segoe UI", 10))
        text = index.data(Qt.ItemDataRole.DisplayRole) or ""
        painter.drawText(
            text_rect,
            Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
            text,
        )
        painter.restore()

        # --- Delete icon ---
        icon_rect = QRect(
            option.rect.right() - self._ICON_SIZE,
            option.rect.top(),
            self._ICON_SIZE,
            option.rect.height(),
        )
        painter.save()
        painter.setFont(QFont(_ICON_FONT, 9))
        painter.setPen(QColor("#a0a0a0") if hovered else QColor("#4a4a58"))
        painter.drawText(icon_rect, Qt.AlignmentFlag.AlignCenter, _ICON_DELETE)
        painter.restore()

    def editorEvent(
        self,
        event: QEvent,
        model: QModelIndex,
        option: QStyleOptionViewItem,
        index: QModelIndex,
    ) -> bool:
        # Click handling is done via viewport event filter in WindowMappingPage
        if event.type() == QEvent.Type.MouseMove:
            mouse: QMouseEvent = event  # type: ignore[assignment]
            over_icon = mouse.position().x() >= option.rect.right() - self._ICON_SIZE
            view = option.widget
            if view is not None:
                if over_icon:
                    view.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
                else:
                    view.unsetCursor()
            return False
        return super().editorEvent(event, model, option, index)

    def sizeHint(self, option: QStyleOptionViewItem, index: QModelIndex) -> QSize:
        size = super().sizeHint(option, index)
        return QSize(size.width(), max(size.height(), 36))


class WindowMappingPage(QWidget):
    """Editor fuer Fenster-Zuordnungen und Formatierungs-Kategorien."""

    def __init__(self, config: ConfigManager, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._config = config
        self._current_category_key: str | None = None
        self._updating = False
        self._setup_ui()
        self._reload_all()

    def _setup_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 28, 28, 28)
        layout.setSpacing(12)

        title = QLabel("Fenster-Zuordnung")
        title.setProperty("heading", True)
        layout.addWidget(title)

        desc = QLabel(
            "Ordne Anwendungen einer Formatierungs-Kategorie zu. "
            "Der transkribierte Text wird dann automatisch per LLM formatiert."
        )
        desc.setProperty("subheading", True)
        desc.setWordWrap(True)
        layout.addWidget(desc)

        self._tabs = QTabWidget()
        self._tabs.addTab(self._create_mappings_tab(), "Zuordnungen")
        self._tabs.addTab(self._create_categories_tab(), "Kategorien")
        layout.addWidget(self._tabs, 1)

        # Viewport event filters for reliable icon click handling
        # (editorEvent does not receive MouseButtonRelease with default edit triggers)
        self._mapping_list.viewport().installEventFilter(self)
        self._cat_list.viewport().installEventFilter(self)

    # -- Tab: Zuordnungen --

    def _create_mappings_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(8, 12, 8, 8)
        layout.setSpacing(10)

        self._mapping_list = QListWidget()
        self._mapping_list.setMouseTracking(True)
        self._mapping_list.setItemDelegate(
            _MappingItemDelegate(self._edit_mapping_at, self._remove_mapping_at, self._mapping_list)
        )
        layout.addWidget(self._mapping_list, 1)

        add_label = QLabel("Neue Zuordnung:")
        add_label.setProperty("subheading", True)
        layout.addWidget(add_label)

        row1 = QHBoxLayout()
        row1.setSpacing(8)
        proc_label = QLabel("Prozess:")
        proc_label.setFixedWidth(60)
        row1.addWidget(proc_label)

        self._process_combo = QComboBox()
        self._process_combo.setEditable(True)
        self._process_combo.lineEdit().setPlaceholderText("z.\u202fB. chrome.exe")
        row1.addWidget(self._process_combo, 1)
        layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.setSpacing(8)
        cat_label = QLabel("Kategorie:")
        cat_label.setFixedWidth(60)
        row2.addWidget(cat_label)

        self._mapping_category_combo = QComboBox()
        row2.addWidget(self._mapping_category_combo, 1)
        layout.addLayout(row2)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        btn_add = QPushButton("Hinzuf\u00fcgen")
        btn_add.setProperty("primary", True)
        btn_add.setMinimumWidth(120)
        btn_add.clicked.connect(self._add_mapping)
        btn_row.addWidget(btn_add)

        btn_row.addStretch()
        layout.addLayout(btn_row)

        return tab

    # -- Tab: Kategorien --

    def _create_categories_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(8, 12, 8, 8)
        layout.setSpacing(10)

        content = QHBoxLayout()
        content.setSpacing(12)

        left = QVBoxLayout()
        left.setSpacing(6)

        self._cat_list = QListWidget()
        self._cat_list.setMinimumWidth(180)
        self._cat_list.setMaximumWidth(220)
        self._cat_list.setMouseTracking(True)
        self._cat_list.setItemDelegate(
            _CategoryItemDelegate(self._delete_category_at, self._cat_list)
        )
        self._cat_list.currentItemChanged.connect(self._on_category_selected)
        left.addWidget(self._cat_list, 1)

        btn_new = QPushButton("Neue Kategorie")
        btn_new.setMinimumWidth(120)
        btn_new.clicked.connect(self._new_category)
        left.addWidget(btn_new)

        content.addLayout(left)

        right = QVBoxLayout()
        right.setSpacing(6)

        name_label = QLabel("Anzeigename:")
        right.addWidget(name_label)

        self._cat_name_input = QLineEdit()
        self._cat_name_input.setPlaceholderText("z.\u202fB. E-Mail, Notizen...")
        right.addWidget(self._cat_name_input)

        prompt_label = QLabel("System-Prompt:")
        right.addWidget(prompt_label)

        self._cat_prompt_input = QTextEdit()
        self._cat_prompt_input.setPlaceholderText(
            "Anweisung f\u00fcr das LLM...\n\n"
            "z.\u202fB. \"Formatiere den Text als professionelle E-Mail.\""
        )
        right.addWidget(self._cat_prompt_input, 1)

        btn_save = QPushButton("Speichern")
        btn_save.setProperty("primary", True)
        btn_save.setMinimumWidth(120)
        btn_save.clicked.connect(self._save_category)
        right.addWidget(btn_save)

        content.addLayout(right, 1)
        layout.addLayout(content, 1)

        return tab

    # -- Viewport event filter: icon clicks --

    def eventFilter(self, watched: object, event: QEvent) -> bool:
        """Intercept mouse clicks on delegate icons (edit/delete)."""
        if event.type() == QEvent.Type.MouseButtonRelease:
            mouse: QMouseEvent = event  # type: ignore[assignment]
            if watched is self._mapping_list.viewport():
                return self._handle_mapping_icon_click(mouse)
            if watched is self._cat_list.viewport():
                return self._handle_category_icon_click(mouse)
        return super().eventFilter(watched, event)

    def _handle_mapping_icon_click(self, event: QMouseEvent) -> bool:
        pos = event.position().toPoint()
        index = self._mapping_list.indexAt(pos)
        if not index.isValid():
            return False
        rect = self._mapping_list.visualRect(index)
        x = event.position().x()
        delete_left = rect.right() - _MappingItemDelegate._ICON_SIZE
        edit_left = rect.right() - _MappingItemDelegate._ICONS_TOTAL
        if x >= delete_left:
            self._remove_mapping_at(index.row())
            return True
        if x >= edit_left:
            self._edit_mapping_at(index.row())
            return True
        return False

    def _handle_category_icon_click(self, event: QMouseEvent) -> bool:
        pos = event.position().toPoint()
        index = self._cat_list.indexAt(pos)
        if not index.isValid():
            return False
        rect = self._cat_list.visualRect(index)
        if event.position().x() >= rect.right() - _CategoryItemDelegate._ICON_SIZE:
            self._delete_category_at(index.row())
            return True
        return False

    # -- Daten laden --

    def _reload_all(self) -> None:
        self._updating = True
        self._load_categories()
        self._load_mappings()
        self._populate_process_combo()
        self._updating = False

    def _load_categories(self) -> None:
        categories = self._config.get("formatting.categories", {})

        self._cat_list.clear()
        for key, cat in categories.items():
            item = QListWidgetItem(cat.get("name", key))
            item.setData(Qt.ItemDataRole.UserRole, key)
            self._cat_list.addItem(item)

        self._mapping_category_combo.clear()
        for key, cat in categories.items():
            self._mapping_category_combo.addItem(cat.get("name", key), key)

        self._current_category_key = None
        self._cat_name_input.clear()
        self._cat_prompt_input.clear()

    def _load_mappings(self) -> None:
        mappings = self._config.get("formatting.window_mappings", {})
        categories = self._config.get("formatting.categories", {})

        self._mapping_list.clear()
        for process_name, category_key in mappings.items():
            cat_name = categories.get(category_key, {}).get("name", category_key)
            # Store as "process\ncategory" — delegate parses both parts
            display = f"{process_name}\n{cat_name}"
            item = QListWidgetItem(display)
            item.setData(Qt.ItemDataRole.UserRole, process_name)
            self._mapping_list.addItem(item)

    def _populate_process_combo(self) -> None:
        processes: set[str] = set()
        try:
            import psutil

            for proc in psutil.process_iter(["name"]):
                try:
                    name = proc.info["name"]
                    if name and name.endswith(".exe"):
                        processes.add(name)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        except Exception:
            log.debug("Prozessliste konnte nicht geladen werden")

        self._process_combo.clear()
        for name in sorted(processes):
            self._process_combo.addItem(name)
        self._process_combo.setCurrentText("")

    # -- Zuordnungen --

    def _add_mapping(self) -> None:
        process = self._process_combo.currentText().strip()
        if not process:
            return

        category_key = self._mapping_category_combo.currentData()
        if not category_key:
            return

        mappings = self._config.get("formatting.window_mappings", {})
        if process in mappings:
            QMessageBox.information(
                self,
                "Zuordnung existiert",
                f"'{process}' ist bereits zugeordnet.\n"
                "Entferne die bestehende Zuordnung zuerst.",
            )
            return

        mappings[process] = category_key
        self._config.set("formatting.window_mappings", mappings)
        self._process_combo.setCurrentText("")
        log.info("Zuordnung hinzugefuegt: %s -> %s", process, category_key)
        self._reload_all()

    def _edit_mapping_at(self, row: int) -> None:
        """Edit the category of the mapping at the given row (delegate callback)."""
        item = self._mapping_list.item(row)
        if not item:
            return

        process = item.data(Qt.ItemDataRole.UserRole)
        categories = self._config.get("formatting.categories", {})
        if not categories:
            return

        cat_names = [cat.get("name", key) for key, cat in categories.items()]
        cat_keys = list(categories.keys())

        mappings = self._config.get("formatting.window_mappings", {})
        current_cat_key = mappings.get(process, "")
        current_index = cat_keys.index(current_cat_key) if current_cat_key in cat_keys else 0

        chosen_name, ok = QInputDialog.getItem(
            self,
            "Kategorie \u00e4ndern",
            f"Neue Kategorie f\u00fcr '{process}':",
            cat_names,
            current_index,
            False,
        )
        if not ok:
            return

        chosen_idx = cat_names.index(chosen_name)
        new_key = cat_keys[chosen_idx]

        mappings[process] = new_key
        self._config.set("formatting.window_mappings", mappings)
        log.info("Zuordnung geaendert: %s -> %s", process, new_key)
        self._reload_all()

    def _remove_mapping_at(self, row: int) -> None:
        """Remove the mapping at the given row (delegate callback)."""
        item = self._mapping_list.item(row)
        if not item:
            return

        process = item.data(Qt.ItemDataRole.UserRole)
        mappings = self._config.get("formatting.window_mappings", {})
        mappings.pop(process, None)
        self._config.set("formatting.window_mappings", mappings)
        log.info("Zuordnung entfernt: %s", process)
        self._reload_all()

    # -- Kategorien --

    def _on_category_selected(
        self, current: QListWidgetItem | None, _previous: QListWidgetItem | None
    ) -> None:
        if current is None:
            self._current_category_key = None
            self._cat_name_input.clear()
            self._cat_prompt_input.clear()
            return

        key = current.data(Qt.ItemDataRole.UserRole)
        self._current_category_key = key

        categories = self._config.get("formatting.categories", {})
        cat = categories.get(key, {})
        self._cat_name_input.setText(cat.get("name", ""))
        self._cat_prompt_input.setPlainText(cat.get("prompt", ""))

    def _save_category(self) -> None:
        key = self._current_category_key
        if not key:
            return

        name = self._cat_name_input.text().strip()
        prompt = self._cat_prompt_input.toPlainText().strip()

        if not name:
            QMessageBox.warning(self, "Fehler", "Bitte einen Anzeigenamen eingeben.")
            return

        categories = self._config.get("formatting.categories", {})
        categories[key] = {"name": name, "prompt": prompt}
        self._config.set("formatting.categories", categories)
        log.info("Kategorie gespeichert: %s (%s)", key, name)

        self._reload_all()

        for i in range(self._cat_list.count()):
            item = self._cat_list.item(i)
            if item and item.data(Qt.ItemDataRole.UserRole) == key:
                self._cat_list.setCurrentItem(item)
                break

    def _new_category(self) -> None:
        key, ok = QInputDialog.getText(
            self,
            "Neue Kategorie",
            "Interner Name (z.\u202fB. 'technical', 'notes'):",
        )
        if not ok or not key.strip():
            return

        key = key.strip().lower().replace(" ", "_")

        categories = self._config.get("formatting.categories", {})
        if key in categories:
            QMessageBox.warning(
                self,
                "Kategorie existiert",
                f"Eine Kategorie mit dem Key '{key}' existiert bereits.",
            )
            return

        categories[key] = {"name": key.replace("_", " ").title(), "prompt": ""}
        self._config.set("formatting.categories", categories)
        log.info("Neue Kategorie erstellt: %s", key)
        self._reload_all()

        for i in range(self._cat_list.count()):
            item = self._cat_list.item(i)
            if item and item.data(Qt.ItemDataRole.UserRole) == key:
                self._cat_list.setCurrentItem(item)
                break

    def _delete_category_at(self, row: int) -> None:
        """Delete the category at the given row (delegate callback)."""
        item = self._cat_list.item(row)
        if not item:
            return

        key = item.data(Qt.ItemDataRole.UserRole)
        categories = self._config.get("formatting.categories", {})
        cat_name = categories.get(key, {}).get("name", key)

        reply = QMessageBox.question(
            self,
            "Kategorie l\u00f6schen",
            f"Kategorie '{cat_name}' wirklich l\u00f6schen?\n\n"
            "Alle zugeh\u00f6rigen Fenster-Zuordnungen werden ebenfalls entfernt.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        categories.pop(key, None)
        self._config.set("formatting.categories", categories)

        mappings = self._config.get("formatting.window_mappings", {})
        cleaned = {k: v for k, v in mappings.items() if v != key}
        if len(cleaned) != len(mappings):
            self._config.set("formatting.window_mappings", cleaned)

        log.info(
            "Kategorie geloescht: %s (+ %d Zuordnungen entfernt)",
            key,
            len(mappings) - len(cleaned),
        )
        self._reload_all()
