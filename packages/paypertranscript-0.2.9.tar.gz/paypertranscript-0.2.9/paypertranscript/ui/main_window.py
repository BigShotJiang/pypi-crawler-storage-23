"""Unified MainWindow fuer PayPerTranscript.

Einzelnes Fenster mit Sidebar-Navigation und gestapelten Seiten.
Ersetzt die fragmentierten Einzel-Dialoge.
"""

from collections.abc import Callable

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QCloseEvent, QIcon
from PySide6.QtWidgets import QDialog, QHBoxLayout, QStackedWidget, QWidget

from paypertranscript.core.config import ConfigManager
from paypertranscript.core.hotkey import HotkeyListener
from paypertranscript.core.logging import get_logger
from paypertranscript.core.paths import get_icons_dir
from paypertranscript.core.session_logger import SessionLogger
from paypertranscript.ui.pages.home_page import HomePage
from paypertranscript.ui.sidebar import Sidebar

log = get_logger("ui.main_window")


class MainWindow(QDialog):
    """Unified MainWindow mit Sidebar + gestapelten Seiten."""

    update_check_requested = Signal()

    def __init__(
        self,
        config: ConfigManager,
        hotkey_listener: HotkeyListener | None = None,
        session_logger: SessionLogger | None = None,
        get_last_transcription: Callable[[], str | None] | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._config = config
        self._setup_ui(config, hotkey_listener, session_logger, get_last_transcription)
        log.info("MainWindow erstellt")

    def _setup_ui(
        self,
        config: ConfigManager,
        hotkey_listener: HotkeyListener | None,
        session_logger: SessionLogger | None,
        get_last_transcription: Callable[[], str | None] | None = None,
    ) -> None:
        self.setWindowTitle("PayPerTranscript")
        self.setFixedSize(780, 560)
        self.setWindowFlags(
            Qt.WindowType.Window
            | Qt.WindowType.WindowCloseButtonHint
            | Qt.WindowType.WindowMinimizeButtonHint
        )

        # App-Icon setzen
        icon_path = get_icons_dir() / "app.ico"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))

        # Haupt-Layout: Sidebar + Content
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Sidebar
        self._sidebar = Sidebar()
        self._sidebar.page_changed.connect(self._on_page_changed)
        self._sidebar.restart_requested.connect(self._on_restart)
        self._sidebar.quit_requested.connect(self._on_quit)
        self._sidebar.update_check_requested.connect(self.update_check_requested)
        layout.addWidget(self._sidebar)

        # Trennlinie
        separator = QWidget()
        separator.setFixedWidth(1)
        separator.setStyleSheet("background-color: #333340;")
        layout.addWidget(separator)

        # Content-Stack
        self._stack = QStackedWidget()
        self._stack.setStyleSheet("QStackedWidget { background-color: #121218; }")

        # Lazy Page Loading: Nur HomePage sofort erstellen, Rest on-demand.
        self._pages: dict[int, QWidget] = {}
        self._page_factories: dict[int, Callable[[], QWidget]] = {
            1: lambda: self._create_statistics_page(session_logger),
            2: lambda: self._create_settings_page(config, hotkey_listener),
            3: lambda: self._create_word_list_page(config),
            4: lambda: self._create_window_mapping_page(config),
        }

        # HomePage (Index 0) sofort — wird bei jedem Oeffnen angezeigt
        home = HomePage(config, session_logger, get_last_transcription)
        self._pages[0] = home
        self._stack.addWidget(home)  # 0

        # Placeholders fuer restliche Seiten
        for _ in range(1, 5):
            self._stack.addWidget(QWidget())

        layout.addWidget(self._stack, 1)

    # -- Lazy Page Factories --

    @staticmethod
    def _create_statistics_page(session_logger: SessionLogger | None) -> QWidget:
        from paypertranscript.ui.pages.statistics_page import StatisticsPage

        return StatisticsPage(session_logger) if session_logger else QWidget()

    @staticmethod
    def _create_settings_page(
        config: ConfigManager, hotkey_listener: HotkeyListener | None
    ) -> QWidget:
        from paypertranscript.ui.pages.settings_page import SettingsPage

        return SettingsPage(config, hotkey_listener)

    @staticmethod
    def _create_word_list_page(config: ConfigManager) -> QWidget:
        from paypertranscript.ui.pages.word_list_page import WordListPage

        return WordListPage(config)

    @staticmethod
    def _create_window_mapping_page(config: ConfigManager) -> QWidget:
        from paypertranscript.ui.pages.window_mapping_page import WindowMappingPage

        return WindowMappingPage(config)

    def _ensure_page(self, index: int) -> None:
        """Erstellt die Seite beim ersten Zugriff (lazy loading)."""
        if index in self._pages:
            return
        factory = self._page_factories.pop(index, None)
        if factory is None:
            return
        page = factory()
        self._pages[index] = page
        old = self._stack.widget(index)
        self._stack.removeWidget(old)
        self._stack.insertWidget(index, page)
        old.deleteLater()
        log.debug("Seite %d lazy erstellt: %s", index, type(page).__name__)

    # -- Navigation --

    def _on_page_changed(self, index: int) -> None:
        """Wechselt zur angeforderten Seite (lazy creation bei Erstaufruf)."""
        self._ensure_page(index)
        self._stack.setCurrentIndex(index)
        self._sidebar.set_active(index)

    def navigate_to(self, page_index: int) -> None:
        """Navigiert zu einer bestimmten Seite und zeigt das Fenster."""
        if 0 <= page_index < self._stack.count():
            self._ensure_page(page_index)
            self._stack.setCurrentIndex(page_index)
            self._sidebar.set_active(page_index)
        self.show()
        self.raise_()
        self.activateWindow()

    def closeEvent(self, event: QCloseEvent) -> None:
        """Schliessen versteckt das Fenster (App laeuft im Tray weiter)."""
        event.ignore()
        self.hide()

    def _on_restart(self) -> None:
        """Neustart ueber Sidebar."""
        log.info("Neustart ueber MainWindow-Sidebar")
        from paypertranscript.core.updater import restart_app
        restart_app()

    def _on_quit(self) -> None:
        """Beenden ueber Sidebar."""
        log.info("Beenden ueber MainWindow-Sidebar")
        from PySide6.QtWidgets import QApplication
        QApplication.quit()
