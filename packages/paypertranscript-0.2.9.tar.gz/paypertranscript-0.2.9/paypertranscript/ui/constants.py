"""Gemeinsame UI-Konstanten fuer PayPerTranscript.

Zentralisiert Sprachen, Hotkey-Presets und Modell-Listen,
die in Setup-Wizard und Einstellungen benoetigt werden.
"""

# Sprachen fuer Whisper (ISO-639-1 → Anzeigename)
LANGUAGES: list[tuple[str, str]] = [
    ("de", "Deutsch"),
    ("en", "English"),
    ("fr", "Fran\u00e7ais"),
    ("es", "Espa\u00f1ol"),
    ("it", "Italiano"),
    ("pt", "Portugu\u00eas"),
    ("nl", "Nederlands"),
    ("pl", "Polski"),
    ("ru", "\u0420\u0443\u0441\u0441\u043a\u0438\u0439"),
    ("ja", "\u65e5\u672c\u8a9e"),
    ("zh", "\u4e2d\u6587"),
    ("ko", "\ud55c\uad6d\uc5b4"),
    ("tr", "T\u00fcrk\u00e7e"),
    ("ar", "\u0627\u0644\u0639\u0631\u0628\u064a\u0629"),
    ("uk", "\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430"),
]

# Hotkey-Presets (Anzeigename, pynput-Keys)
HOLD_PRESETS: list[tuple[str, list[str]]] = [
    ("Ctrl + Win", ["ctrl", "cmd"]),
    ("Ctrl + Alt", ["ctrl", "alt"]),
    ("Ctrl + Shift", ["ctrl", "shift"]),
]

TOGGLE_PRESETS: list[tuple[str, list[str] | None]] = [
    ("Keiner", None),
    ("Ctrl + Win", ["ctrl", "cmd"]),
    ("Ctrl + Alt", ["ctrl", "alt"]),
    ("Ctrl + Shift", ["ctrl", "shift"]),
]

# STT-Modelle
STT_MODELS: list[str] = [
    "whisper-large-v3-turbo",
    "whisper-large-v3",
]

# LLM-Modelle
LLM_MODELS: list[str] = [
    "openai/gpt-oss-20b",
    "openai/gpt-oss-120b",
    "moonshotai/kimi-k2-instruct-0905",
]

# LLM-Modell-Metadaten: (Standard-Temperature, Empfohlene Temperature)
LLM_MODEL_DEFAULTS: dict[str, tuple[float, float]] = {
    "openai/gpt-oss-20b": (1.0, 0.6),
    "openai/gpt-oss-120b": (1.0, 0.6),
    "moonshotai/kimi-k2-instruct-0905": (0.6, 0.4),
}
