"""PayPerTranscript - Entry Point.

Open-Source Voice-to-Text mit Pay-per-Use Pricing.
Supports: python -m paypertranscript
"""

import ctypes
import os
import sys
from pathlib import Path

# DPI-Awareness setzen BEVOR Qt oder andere Libraries es tun.
# Verhindert "SetProcessDpiAwarenessContext() failed: Zugriff verweigert".
try:
    ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
except Exception:
    pass

# AppUserModelID setzen, damit Windows das App-Icon in der Taskbar zeigt
# statt des Python-Logos.
try:
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
        "PayPerTranscript.PayPerTranscript"
    )
except Exception:
    pass


def _load_dotenv() -> None:
    """Laedt .env-Datei aus dem Arbeitsverzeichnis (falls vorhanden)."""
    env_file = Path.cwd() / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip("'\"")
        if key and key not in os.environ:
            os.environ[key] = value


def main() -> None:
    """Hauptfunktion - initialisiert Logging und startet die PySide6-App."""
    _load_dotenv()

    from paypertranscript.core.logging import setup_logging

    setup_logging(debug="--debug" in sys.argv)

    # Auto-Update bei Startup (vor PySide6-Import)
    if "--no-update" not in sys.argv:
        try:
            from paypertranscript.core.updater import check_and_auto_update

            check_and_auto_update()  # Bei Update: install + restart + sys.exit(0)
        except Exception:
            pass  # Update-Fehler darf App-Start nie blockieren

    from paypertranscript.ui.app import PayPerTranscriptApp

    app = PayPerTranscriptApp()
    sys.exit(app.run())


if __name__ == "__main__":
    main()
