"""Open-Meteo MCP tools — import all tool modules to register @tool decorators."""

from . import air_quality, forecast, geocoding, historical, marine, weather_codes  # noqa: F401
