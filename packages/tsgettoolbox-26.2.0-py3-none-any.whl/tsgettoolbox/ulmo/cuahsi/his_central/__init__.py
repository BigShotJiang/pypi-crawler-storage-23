"""
`CUAHSI HIS Central`_ catalog web services
"""

__all__ = ["get_services"]
from .core import get_services
