"""chdb-core: Core library for chDB"""

__version__ = "0.0.1"
