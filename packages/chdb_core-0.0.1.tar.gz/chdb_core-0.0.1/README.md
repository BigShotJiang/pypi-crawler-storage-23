# chdb-core

Core library for [chDB](https://github.com/chdb-io/chdb) - an in-process SQL OLAP Engine powered by ClickHouse.

This package is under development.
