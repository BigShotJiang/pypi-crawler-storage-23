from .types import _SubparserType


def add_get_token_command(subparsers: _SubparserType):
    get_token_parser = subparsers.add_parser("get-token", help="Get the access token for the Mindgard API")
    return get_token_parser
