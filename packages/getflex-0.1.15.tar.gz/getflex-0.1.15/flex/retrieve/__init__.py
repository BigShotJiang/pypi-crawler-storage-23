"""Retrieve: query execution. Matrix multiply, named presets, direct SQL."""
