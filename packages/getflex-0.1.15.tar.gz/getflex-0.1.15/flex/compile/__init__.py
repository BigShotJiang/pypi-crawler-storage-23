"""Compile: reusable parsers for ingestion pipelines."""
