"""Doc-pac module — enrichment config for documentation/context cells."""
