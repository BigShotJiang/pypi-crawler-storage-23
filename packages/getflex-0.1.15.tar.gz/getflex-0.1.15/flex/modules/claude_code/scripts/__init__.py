"""Claude Code scripts — thin runners for enrichment and migration."""
