"""ONNX embedding model — local inference, no PyTorch."""
from .embed import ONNXEmbedder, get_model, encode, MAX_LENGTH
