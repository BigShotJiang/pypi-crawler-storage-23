#!/usr/bin/env python3
"""
Interactive SSO Authentication Script
Allows users to select environment and user credentials to get authentication tokens.

Environment-based Configuration:
- Users are now organized by environment (dev/prod/staging) for better clarity
- Each environment has its own set of users with environment-specific credentials
- Supports both new environment-based config and legacy config for backward compatibility

Example .env structure:
DEV_ADMIN_EMAIL=admin@company.com
DEV_ADMIN_PASSWORD=your_password_here
PROD_API_EMAIL=api@company.com
PROD_API_PASSWORD=another_password
"""

import os
import sys
import asyncio
import base64
import json
import httpx
import logging
import argparse
import yaml
from typing import Dict, Any, Optional, List, Tuple
from dotenv import load_dotenv
import pyperclip
from rich.console import Console
from rich.prompt import Prompt
from rich.panel import Panel
from rich.text import Text
from rich import print as rprint
from rich.prompt import Confirm
import inquirer

# Configure logging - suppress HTTP logs for cleaner output
logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)
# Suppress httpx logs
logging.getLogger("httpx").setLevel(logging.WARNING)

# Initialize Rich console
console = Console()

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "sso_config.yaml")


def _get_env_or_value(env_vars: Dict[str, str], key: Optional[str], value: Optional[str]) -> Optional[str]:
    if key:
        return env_vars.get(key)
    return value

class SSOAuthenticator:
    def __init__(self):
        self.env_vars = {}
        self.environments: Dict[str, Dict[str, str]] = {}
        self.environment_users: Dict[str, Dict[str, Dict[str, str]]] = {}
        self.load_environment()
        self.load_config()

    def load_config(self):
        """Load environments and users from YAML config (sso_config.yaml)."""
        self.environments = {}
        self.environment_users = {}

        if not os.path.exists(CONFIG_PATH):
            logger.info("sso_config.yaml not found. No environments configured by default.")
            return

        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                raw_cfg = yaml.safe_load(f) or {}
        except Exception as exc:  # pragma: no cover
            logger.error(f"Failed to read {CONFIG_PATH}: {exc}")
            return

        # Support two shapes: top-level environments or nested under "environments"
        env_cfg = raw_cfg.get("environments", raw_cfg)
        if not isinstance(env_cfg, dict):
            logger.error("Invalid config format: expected mapping of environments")
            return

        for env_key, env_data in env_cfg.items():
            if not isinstance(env_data, dict):
                logger.warning(f"Skipping environment '{env_key}' (expected a mapping)")
                continue
            sso_url = env_data.get("sso_url")
            if not sso_url:
                logger.warning(f"Skipping environment '{env_key}' (missing sso_url)")
                continue
            env_name = env_data.get("name", env_key.title())
            self.environments[env_key] = {"name": env_name, "sso_url": sso_url}

            users = env_data.get("users", {}) or {}
            if not isinstance(users, dict):
                logger.warning(f"Skipping users for environment '{env_key}' (expected mapping)")
                continue
            self.environment_users[env_key] = {}
            for user_key, user_data in users.items():
                if not isinstance(user_data, dict):
                    logger.warning(f"Skipping user '{user_key}' in env '{env_key}' (expected mapping)")
                    continue
                self.environment_users[env_key][user_key] = {
                    "name": user_data.get("name", user_key),
                    "auth_type": user_data.get("auth_type", "password"),
                    "email": user_data.get("email"),
                    "password": user_data.get("password"),
                    "email_env": user_data.get("email_env"),
                    "password_env": user_data.get("password_env"),
                    "client_id": user_data.get("client_id"),
                    "client_secret": user_data.get("client_secret"),
                    "client_id_env": user_data.get("client_id_env"),
                    "client_secret_env": user_data.get("client_secret_env"),
                }

        if not self.environments:
            logger.info("No environments loaded from config; tool will prompt for setup.")
    
    def load_environment(self):
        """Load environment variables from .env file"""
        env_path = os.path.join(os.path.dirname(__file__), '.env')
        if os.path.exists(env_path):
            load_dotenv(env_path)
            logger.info("Loaded environment variables from .env file")
        else:
            logger.warning(".env file not found. Please create one based on .env.template")
        
        # Load all environment variables
        self.env_vars = dict(os.environ)
    
    def get_available_users_for_environment(self, environment: str) -> Dict[str, Dict[str, str]]:
        """Get available users for a specific environment"""
        return self.environment_users.get(environment, {})
    
    def get_all_available_users(self) -> Dict[str, Dict[str, Dict[str, str]]]:
        """Get all available users organized by environment"""
        return self.environment_users
    
    def get_user_credentials(self, environment: str, user_key: str) -> Tuple[str, str, str]:
        """Get credentials for a specific user in a specific environment
        
        Returns:
            tuple: (credential1, credential2, auth_type) where:
                - For password auth: (email, password, "password")
                - For client_credentials auth: (client_id, client_secret, "client_credentials")
        """
        users = self.environment_users.get(environment, {})
        if environment in self.environment_users and user_key in users:
            user_config = users[user_key]
            auth_type = user_config.get("auth_type", "password")
            
            if auth_type == "client_credentials":
                client_id = _get_env_or_value(self.env_vars, user_config.get("client_id_env"), user_config.get("client_id"))
                client_secret = _get_env_or_value(self.env_vars, user_config.get("client_secret_env"), user_config.get("client_secret"))
                
                if client_id and client_secret:
                    return client_id, client_secret, auth_type
                missing = []
                if not client_id:
                    missing.append(user_config.get("client_id_env") or "client_id")
                if not client_secret:
                    missing.append(user_config.get("client_secret_env") or "client_secret")
                raise ValueError(
                    f"Missing credentials for {user_config['name']} on {environment}: {', '.join(missing)}"
                )
            else:  # password auth
                email = _get_env_or_value(self.env_vars, user_config.get("email_env"), user_config.get("email"))
                password = _get_env_or_value(self.env_vars, user_config.get("password_env"), user_config.get("password"))
                
                if email and password:
                    return email, password, auth_type
                missing = []
                if not email:
                    missing.append(user_config.get("email_env") or "email")
                if not password:
                    missing.append(user_config.get("password_env") or "password")
                raise ValueError(
                    f"Missing credentials for {user_config['name']} on {environment}: {', '.join(missing)}"
                )

        raise ValueError(
            f"User '{user_key}' not found for environment '{environment}'. "
            "Check sso_config.yaml for configured users."
        )
        
        # If we get here, no valid configuration was found
        available_users = list(ENVIRONMENT_USERS.get(environment, {}).keys())
        if available_users:
            raise ValueError(f"User '{user_key}' not found for environment '{environment}'. "
                           f"Available users: {', '.join(available_users)}")
        else:
            raise ValueError(f"No users configured for environment '{environment}'. "
                           f"Please check your .env file configuration.")
    
    async def get_token(self, environment: str, user_key: str) -> str:
        """Get authentication token for the specified environment and user"""
        env_config = ENVIRONMENTS[environment]
        cred1, cred2, auth_type = self.get_user_credentials(environment, user_key)
        
        token_url = f"{env_config['sso_url']}/protocol/openid-connect/token"
        
        # Prepare data based on authentication type
        if auth_type == "client_credentials":
            # Client credentials flow
            data = {
                "grant_type": "client_credentials",
                "client_id": cred1,  # client_id
                "client_secret": cred2  # client_secret
            }
        else:
            # Password flow (default)
            data = {
                "grant_type": "password",
                "client_id": "delivery-ops-frontend-client",  # Public client ID for the web app
                "username": cred1,  # email
                "password": cred2  # password
            }
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(token_url, data=data)
                response.raise_for_status()
                token_data = response.json()
                
                return token_data["access_token"]
        except httpx.HTTPError as e:
            logger.error(f"Failed to get token: {str(e)}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"Response content: {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}")
            raise
    
    def extract_user_from_token(self, token: str) -> Dict[str, Any]:
        """Extract user information from a JWT token"""
        try:
            # JWT tokens have 3 parts: header.payload.signature
            parts = token.split('.')
            if len(parts) != 3:
                logger.error("Invalid JWT token format")
                return {}
            
            # Decode the payload (middle part)
            # Add padding if needed
            payload = parts[1]
            payload += '=' * (4 - len(payload) % 4) if len(payload) % 4 else ''
            
            # Decode base64
            decoded = base64.urlsafe_b64decode(payload)
            user_info = json.loads(decoded)
            
            return user_info
        except Exception as e:
            logger.error(f"Failed to extract user from token: {str(e)}")
            return {}


class ModernSelector:
    def __init__(self):
        self.console = Console()
    
    def select_from_list(self, title: str, options: List[str], description: str = None) -> int:
        """Selection using inquirer for proper arrow key navigation"""
        # Use inquirer for arrow key navigation with custom message
        questions = [
            inquirer.List('choice',
                         message=title,  # Use title as the message to avoid [?] prompt
                         choices=options,
                         carousel=True)
        ]
        
        try:
            answers = inquirer.prompt(questions)
            if answers is None:  # User pressed Ctrl+C
                self.console.print("\n[yellow]Exiting...[/yellow]")
                sys.exit(0)
            
            selected_option = answers['choice']
            return options.index(selected_option)
            
        except (KeyboardInterrupt, EOFError):
            self.console.print("\n[yellow]Exiting...[/yellow]")
            sys.exit(0)


def copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard if possible"""
    try:
        pyperclip.copy(text)
        return True
    except Exception as e:
        logger.warning(f"Failed to copy to clipboard: {e}")
        return False


def show_help():
    """Show help information with available environments and users"""
    authenticator = SSOAuthenticator()
    console.print()
    help_panel = Panel(
        Text("🔐 SSO Authentication Tool - Help", style="bold green"),
        border_style="green"
    )
    console.print(help_panel)
    
    console.print("\n[bold]Usage:[/bold]")
    console.print("  sso [environment] [user]     # Get token for specific environment and user")
    console.print("  sso --help                   # Show this help")
    console.print("  sso                          # Interactive mode")
    
    if authenticator.environments:
        console.print("\n[bold]Available Environments:[/bold]")
        for env_key, config in authenticator.environments.items():
            console.print(f"  • [cyan]{env_key}[/cyan] - {config['name']}")
        
        console.print("\n[bold]Available Users by Environment:[/bold]")
        for env_key, users in authenticator.environment_users.items():
            console.print(f"\n[bold cyan]{env_key.upper()}:[/bold cyan]")
            for user_key, user_config in users.items():
                console.print(f"  • [yellow]{user_key}[/yellow] - {user_config['name']}")
    else:
        console.print("\n[yellow]No environments configured yet. Create sso_config.yaml (see README).[/yellow]")
    
    console.print("\n[bold]Examples:[/bold]")
    console.print("  sso dev admin                # Get token for admin on 'dev' (configured in sso_config.yaml)")
    console.print("  curl -H \"Authorization: Bearer $(sso dev admin)\" https://api.example.com")
    
    console.print()


async def get_token_non_interactive(environment: str, user: str) -> str:
    """Get token in non-interactive mode"""
    authenticator = SSOAuthenticator()
    if not authenticator.environments:
        raise ValueError("No environments configured. Please create sso_config.yaml (see README).")
    
    # Validate environment
    if environment not in authenticator.environments:
        available_envs = ", ".join(authenticator.environments.keys()) or "none"
        raise ValueError(f"Environment '{environment}' not found. Available: {available_envs}")
    
    # Validate user for environment
    env_users = authenticator.environment_users.get(environment, {})
    if user not in env_users:
        available_users = ", ".join(env_users.keys()) if env_users else "none"
        raise ValueError(f"User '{user}' not found for environment '{environment}'. Available: {available_users}")
    
    # Get token
    token = await authenticator.get_token(environment, user)
    return token


async def main():
    """Main function"""
    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description="SSO Authentication Tool",
        add_help=False  # We'll handle help manually
    )
    parser.add_argument('environment', nargs='?', help='Environment key (as defined in sso_config.yaml)')
    parser.add_argument('user', nargs='?', help='User key')
    parser.add_argument('--help', action='store_true', help='Show help')
    
    args = parser.parse_args()
    
    # Handle help
    if args.help:
        show_help()
        return
    
    # Non-interactive mode: environment and user provided
    if args.environment and args.user:
        try:
            token = await get_token_non_interactive(args.environment, args.user)
            # In non-interactive mode, just output the token (for use in scripts/curl)
            print(token)
            return
        except Exception as e:
            print(f"Error: {str(e)}", file=sys.stderr)
            sys.exit(1)
    
    # Interactive mode: no arguments provided
    if not args.environment and not args.user:
        # Welcome message with Rich styling
        console.print()
        welcome_panel = Panel(
            Text("🔐 SSO Authentication Tool", style="bold green"),
            border_style="green"
        )
        console.print(welcome_panel)
        
        # Initialize authenticator
        authenticator = SSOAuthenticator()
        selector = ModernSelector()

        if not authenticator.environments:
            error_panel = Panel(
                "[red]❌ No environments configured.[/red]\n\n"
                "Create sso_config.yaml with your realms and users. See README for a template.",
                title="Configuration required",
                border_style="red"
            )
            console.print(error_panel)
            sys.exit(1)
        
        # Select environment
        env_options = [f"{config['name']} ({env_key})" for env_key, config in authenticator.environments.items()]
        env_choice = selector.select_from_list(
            "Select Environment", 
            env_options
        )
        selected_env = list(authenticator.environments.keys())[env_choice]
        
        # Select user based on the selected environment
        env_users = authenticator.environment_users.get(selected_env, {})
        if not env_users:
            error_panel = Panel(
                f"[red]❌ No users configured for environment '{selected_env}'[/red]\n\n"
                "[yellow]Available environments with users:[/yellow]\n" +
                "\n".join([f"  • {env_key}: {', '.join(users.keys())}" 
                          for env_key, users in ENVIRONMENT_USERS.items() if users]),
                title="Configuration Error",
                border_style="red"
            )
            console.print(error_panel)
            sys.exit(1)
        
        user_options = [config['name'] for user_key, config in env_users.items()]
        user_choice = selector.select_from_list(
            "Select User", 
            user_options
        )
        selected_user = list(env_users.keys())[user_choice]
        
        # Show authentication progress
        console.print()
        progress_text = Text(f"🔄 Authenticating as ", style="yellow")
        progress_text.append(env_users[selected_user]['name'], style="bold")
        progress_text.append(f" on ", style="yellow")
        progress_text.append(ENVIRONMENTS[selected_env]['name'], style="bold blue")
        progress_text.append("...", style="yellow")
        console.print(progress_text)
        
        try:
            # Get token
            token = await authenticator.get_token(selected_env, selected_user)
            
            # Extract user info from token
            user_info = authenticator.extract_user_from_token(token)
            
            # Success message
            console.print()
            if copy_to_clipboard(token):
                success_panel = Panel(
                    Text("✅ Token copied to clipboard!", style="bold green"),
                    border_style="green"
                )
                console.print(success_panel)
            else:
                # Only display token if clipboard copy failed
                success_panel = Panel(
                    Text("✅ Authentication successful!", style="bold green"),
                    border_style="green"
                )
                console.print(success_panel)
                
                if user_info:
                    user_display = Text("👤 User: ", style="cyan")
                    user_display.append(user_info.get('preferred_username', 'Unknown'), style="bold")
                    console.print(user_display)
                
                console.print()
                token_panel = Panel(
                    f"[bold]🔑 Token:[/bold]\n{token}\n\n[bold]🎯 Authorization:[/bold] Bearer {token}",
                    title="Authentication Token",
                    border_style="blue"
                )
                console.print(token_panel)
            
        except Exception as e:
            error_panel = Panel(
                f"[red]❌ Authentication failed:[/red]\n{str(e)}",
                title="Error",
                border_style="red"
            )
            console.print(error_panel)
            sys.exit(1)
    
    # Invalid usage: only one argument provided
    else:
        print("Error: Both environment and user must be provided for non-interactive mode.", file=sys.stderr)
        print("Usage: sso [environment] [user] or sso --help", file=sys.stderr)
        sys.exit(1)


def cli():
    """Entry point wrapper for console_scripts."""
    asyncio.run(main())


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        console.print("\n[yellow]👋 Goodbye![/yellow]")
        sys.exit(0)
