# 🔐 SSO Tool

Lightweight CLI to fetch tokens from your Keycloak/SSO realms.

- Interactive and non-interactive modes
- Supports password and client_credentials flows
- Uses a simple YAML config; nothing is bundled by default

## 🚀 Quick Start

```bash
# Install
pip install --upgrade sso-cli

# Create your config
cp sso_config.yaml.example sso_config.yaml
# edit sso_config.yaml with your realms/users

# Run
sso            # interactive
sso dev admin  # non-interactive example
```

## 🛠️ Configuration

Create `sso_config.yaml` (or point `SSO_CONFIG_PATH` to another file). Example:

```yaml
environments:
  dev:
    name: Dev Realm
    sso_url: https://sso.dev.example.com/realms/internal
    users:
      admin:
        name: Dev Admin
        auth_type: password
        email: ${DEV_ADMIN_EMAIL}
        password: ${DEV_ADMIN_PASSWORD}
      service_bot:
        name: Dev Service Bot
        auth_type: client_credentials
        client_id: ${DEV_BOT_CLIENT_ID}
        client_secret: ${DEV_BOT_CLIENT_SECRET}
  prod:
    name: Prod Realm
    sso_url: https://sso.example.com/realms/main
    users:
      ops:
        name: Ops User
        auth_type: password
        email_env: PROD_OPS_EMAIL
        password_env: PROD_OPS_PASSWORD
```

Notes:
- You define every environment and user yourself; no sample credentials are shipped.
- Use `${VAR}` or the `_env` keys to load secrets from environment variables.

## 🎯 Usage

Interactive:
```bash
sso
```

Non-interactive:
```bash
sso dev admin
```

## 📦 Development

```bash
make install-dev   # editable install with dev deps
make test          # run tests (if any)
make clean         # clean build artifacts
```

## 📤 Publishing

```bash
export PYPI_API_TOKEN=pypi-...
make publish
```

## 🧩 Troubleshooting
- "No environments configured": create `sso_config.yaml` with your realms/users.
- "Missing credentials": set the env vars referenced in your config (e.g., `${DEV_ADMIN_EMAIL}`).
