"""Beckit — lightweight cross-platform book writing app with GitHub sync."""

__version__ = "3.0.0"
