# Signal wiring is handled by TeamEvents.__set_name__ in team_events.py.
# This module is reserved for future global signal handlers.
