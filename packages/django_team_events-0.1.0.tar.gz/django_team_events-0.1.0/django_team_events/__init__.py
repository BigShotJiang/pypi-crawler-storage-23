default_app_config = "django_team_events.apps.DjangoTeamEventsConfig"

from django_team_events.team_events import TeamEvents  # noqa: E402

__all__ = ["TeamEvents"]