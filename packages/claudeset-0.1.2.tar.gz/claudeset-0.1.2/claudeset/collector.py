"""Scanne les projets Claude Code et synchronise les sessions dans SQLite."""

from pathlib import Path

from .db import get_connection, get_known_sessions, upsert_session, count_sessions
from .parser import discover_projects, parse_session_file


def collect(db_path: Path | None = None) -> dict:
    """
    Scanne tous les projets Claude Code et upsert les sessions nouvelles
    ou modifiées dans la base SQLite.

    Détection des changements : si la taille du fichier source a changé
    depuis la dernière collecte → re-parse et REPLACE.

    Retourne un résumé : {new, updated, skipped, failed, projects}.
    """
    conn  = get_connection(db_path) if db_path else get_connection()
    known = get_known_sessions(conn)   # {session_id: source_size}

    projects = discover_projects()

    stats = {"new": 0, "updated": 0, "skipped": 0, "failed": 0, "projects": len(projects)}

    for project in projects:
        for session_file in project["session_files"]:
            session_id   = session_file.stem
            current_size = session_file.stat().st_size

            # Pas de changement détecté → skip
            if session_id in known and known[session_id] == current_size:
                stats["skipped"] += 1
                continue

            session = parse_session_file(session_file)

            # Session invalide (vide, synthétique, sans modèle)
            if not session or not session.get("model"):
                stats["failed"] += 1
                continue

            session["project"] = project["display_name"]

            is_update = session_id in known
            upsert_session(conn, session, str(session_file), current_size)

            if is_update:
                stats["updated"] += 1
            else:
                stats["new"] += 1

    stats["total_in_db"] = count_sessions(conn)
    conn.close()
    return stats


# ---------------------------------------------------------------------------
# CLI minimal
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    result = collect()
    print(f"Collecte terminée :")
    print(f"  Nouvelles sessions  : {result['new']}")
    print(f"  Sessions mises à jour : {result['updated']}")
    print(f"  Ignorées (inchangées) : {result['skipped']}")
    print(f"  Échecs de parsing     : {result['failed']}")
    print(f"  Total en base         : {result['total_in_db']}")
    print(f"  Projets scannés       : {result['projects']}")
