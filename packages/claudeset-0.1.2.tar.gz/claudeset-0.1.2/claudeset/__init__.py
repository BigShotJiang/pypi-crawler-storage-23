"""claudeset — Export your Claude Code conversations to HuggingFace as rich training datasets."""

__version__ = "0.1.2"
