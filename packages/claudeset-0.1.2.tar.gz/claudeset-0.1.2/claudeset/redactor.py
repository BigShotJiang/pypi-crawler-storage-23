"""
Redaction et anonymisation des sessions avant push communautaire.

Couvre toutes les failles identifiées dans l'audit de sécurité :
  - Fournisseurs manquants (Google, Stripe, SendGrid, Vault...)
  - Format OpenAI récent (sk-proj-)
  - Basic auth dans toutes les URLs (pas seulement postgres)
  - Bearer tokens opaques (pas seulement JWT)
  - Strings haute entropie hors guillemets
  - Numéros de téléphone et cartes bancaires
  - Anonymisation chemins/usernames système
"""

import hashlib
import math
import os
import re
from typing import Any

REDACTED = "[REDACTED]"


# ---------------------------------------------------------------------------
# Anonymisation chemins / username système
# ---------------------------------------------------------------------------

def _detect_user() -> tuple[str, str, str]:
    """Retourne (home, username, username_hash)."""
    home     = os.path.expanduser("~")
    username = os.path.basename(home)
    uhash    = "user_" + hashlib.sha256(username.encode()).hexdigest()[:8]
    return home, username, uhash


_HOME, _USERNAME, _USERNAME_HASH = _detect_user()


def _anonymize_text(text: str) -> str:
    """Remplace les chemins absolus et le username système par leur hash."""
    if not text or not _USERNAME:
        return text

    esc = re.escape(_USERNAME)

    # /home/username/ et /Users/username/
    text = re.sub(rf"/home/{esc}(?=/|$)",  f"/{_USERNAME_HASH}", text)
    text = re.sub(rf"/Users/{esc}(?=/|$)", f"/{_USERNAME_HASH}", text)

    # Chemins encodés en tirets (format interne Claude Code)
    text = re.sub(rf"-home-{esc}(?=-|/|$)",  f"-home-{_USERNAME_HASH}",  text)
    text = re.sub(rf"-Users-{esc}(?=-|/|$)", f"-Users-{_USERNAME_HASH}", text)

    # Username seul (>= 4 chars pour éviter faux positifs)
    if len(_USERNAME) >= 4:
        text = re.sub(rf"\b{esc}\b", _USERNAME_HASH, text)

    return text


# ---------------------------------------------------------------------------
# Patterns de secrets
# (ordonnés du plus spécifique au moins spécifique pour limiter les overlaps)
# ---------------------------------------------------------------------------

SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [

    # ── JWT ────────────────────────────────────────────────────────────────
    ("jwt",
     re.compile(r"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}")),
    ("jwt_partial",
     re.compile(r"eyJ[A-Za-z0-9_-]{15,}")),

    # ── Clés API connues ───────────────────────────────────────────────────

    # OpenAI ancien format sk-xxx et nouveau sk-proj-xxx
    ("openai_key",
     re.compile(r"sk-(?:proj-)?[A-Za-z0-9_-]{40,}")),

    # Anthropic
    ("anthropic_key",
     re.compile(r"sk-ant-[A-Za-z0-9_-]{20,}")),

    # Google API  (audit : manquant dans dataclaw)
    ("google_api",
     re.compile(r"AIzaSy[A-Za-z0-9_-]{33}")),

    # Stripe live / test  (audit : underscore cassait le pattern dataclaw)
    ("stripe_key",
     re.compile(r"(?:sk|pk|rk)_(?:live|test)_[A-Za-z0-9]{20,}")),

    # HuggingFace
    ("hf_token",
     re.compile(r"hf_[A-Za-z0-9]{20,}")),

    # GitHub
    ("github_token",
     re.compile(r"(?:ghp|gho|ghs|ghr)_[A-Za-z0-9]{30,}")),

    # SendGrid  (audit : manquant) — format : SG.<part1>.<part2>
    ("sendgrid",
     re.compile(r"SG\.[A-Za-z0-9_.-]{22,}")),

    # HashiCorp Vault  (audit : manquant)
    ("vault_token",
     re.compile(r"hvs\.[A-Za-z0-9]{24,}")),

    # Slack
    ("slack_token",
     re.compile(r"xox[bpsa]-[A-Za-z0-9-]{20,}")),

    # PyPI
    ("pypi_token",
     re.compile(r"pypi-[A-Za-z0-9_-]{50,}")),

    # NPM
    ("npm_token",
     re.compile(r"npm_[A-Za-z0-9]{30,}")),

    # AWS access key
    ("aws_key",
     re.compile(r"(?<![A-Za-z0-9\[])AKIA[0-9A-Z]{16}(?![0-9A-Z\]{}])")),

    # AWS secret (avec label explicite)
    ("aws_secret",
     re.compile(
         r"(?:aws_secret_access_key|secret_key)\s*[=:]\s*['\"]?([A-Za-z0-9/+=]{40})['\"]?",
         re.IGNORECASE,
     )),

    # Discord webhook
    ("discord_webhook",
     re.compile(
         r"https?://(?:discord\.com|discordapp\.com)/api/webhooks/\d+/[A-Za-z0-9_-]{20,}"
     )),

    # Clés privées PEM
    ("private_key",
     re.compile(
         r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"
         r"[\s\S]*?"
         r"-----END (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"
     )),

    # ── URLs avec basic auth  (audit : seulement postgres dans dataclaw) ──
    ("basic_auth_url",
     re.compile(
         r"\b(?:https?|mongodb(?:\+srv)?|redis|mysql|postgresql?|ftp)"
         r"://[^:/@\s\"'`]+:[^@\s\"'`]{3,}@[^\s\"'`]+"
     )),

    # ── Bearer token générique  (audit : seulement JWT dans dataclaw) ─────
    # On exclut les tokens très courts et les valeurs trop simples
    ("bearer_opaque",
     re.compile(r"(?i)Bearer\s+([A-Za-z0-9_\-\.=+/]{20,})")),

    # ── Variables d'environnement et assignations ──────────────────────────
    ("cli_token_flag",
     re.compile(
         r"(?:--|-)(?:access[_-]?token|auth[_-]?token|api[_-]?key|secret|password|token)"
         r"[\s=]+([A-Za-z0-9_/+=.\-]{8,})",
         re.IGNORECASE,
     )),
    ("env_secret",
     re.compile(
         r"(?:SECRET|PASSWORD|TOKEN|API_KEY|AUTH_KEY|ACCESS_KEY|SERVICE_KEY"
         r"|DB_PASSWORD|SUPABASE_KEY|SUPABASE_SERVICE|ANON_KEY|SERVICE_ROLE)"
         r"\s*[=]\s*['\"]?([^\s'\"]{6,})['\"]?",
         re.IGNORECASE,
     )),
    ("generic_secret",
     re.compile(
         r"""(?:secret[_-]?key|api[_-]?key|api[_-]?secret|access[_-]?token"""
         r"""|auth[_-]?token|service[_-]?role[_-]?key|private[_-]?key)"""
         r"""\s*[=:]\s*['"]([A-Za-z0-9_/+=.\-]{20,})['"]""",
         re.IGNORECASE,
     )),

    # URL query params
    ("url_token",
     re.compile(
         r"[?&](?:key|token|secret|password|apikey|api_key|access_token|auth)"
         r"=([A-Za-z0-9_/+=.\-]{8,})",
         re.IGNORECASE,
     )),

    # ── PII ───────────────────────────────────────────────────────────────

    # IP publiques (non privées, non loopback)
    ("ip_address",
     re.compile(
         r"\b(?!127\.0\.0\.)(?!0\.0\.0\.0)(?!255\.255\.)"
         r"(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}"
         r"(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\b"
     )),

    # Emails
    ("email",
     re.compile(r"\b[A-Za-z0-9._%+-]{2,}@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")),

    # Numéros de téléphone  (audit : manquant dans dataclaw)
    ("phone",
     re.compile(
         r"\b(?:\+?(?:33|1|44|49|34|39|81|86|91)[\s.\-]?)?"
         r"(?:\(?\d{2,4}\)?[\s.\-]?)?"
         r"\d{2,4}[\s.\-]?\d{2,4}[\s.\-]?\d{2,4}\b"
     )),

    # Cartes bancaires  (audit : manquant dans dataclaw)
    ("credit_card",
     re.compile(r"\b\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b")),

    # ── Strings haute entropie ────────────────────────────────────────────

    # Dans guillemets (dataclaw en avait un équivalent)
    ("high_entropy_quoted",
     re.compile(r"""['"][A-Za-z0-9_/+=.\-]{40,}['"]""")),

    # Hors guillemets  (audit : manquant dans dataclaw)
    # Capture après = ou : (assignations, headers)
    ("high_entropy_bare",
     re.compile(r"""(?:=|:\s{0,4})([A-Za-z0-9_/+=.\-]{32,})""")),
]


# Patterns allowlistés → pas de redaction même si match
ALLOWLIST: list[re.Pattern] = [
    re.compile(r"noreply@"),
    re.compile(r"@example\.com"),
    re.compile(r"@localhost"),
    re.compile(r"@anthropic\.com"),
    re.compile(r"@github\.com"),
    re.compile(r"@users\.noreply\.github\.com"),
    re.compile(r"@pytest"),
    re.compile(r"@tasks\."),
    re.compile(r"@mcp\."),
    re.compile(r"@server\."),
    re.compile(r"@app\."),
    re.compile(r"@router\."),
    re.compile(r"192\.168\."),
    re.compile(r"10\.\d+\.\d+\.\d+"),
    re.compile(r"172\.(?:1[6-9]|2\d|3[01])\."),
    re.compile(r"8\.8\.8\.8"),
    re.compile(r"8\.8\.4\.4"),
    re.compile(r"1\.1\.1\.1"),
    re.compile(r"AKIA\["),
    re.compile(r"sk-ant-\.\*"),
    re.compile(r"postgres://user(?:name)?:pass(?:word)?@"),   # exemples doc
    re.compile(r"mongodb://localhost"),
    re.compile(r"redis://(?:localhost|127)"),
    re.compile(r"sk-notification"),                           # faux positif connu
    # Numéros de version type 1.2.3.4 ou dates
    re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$"),
]

# Faux positifs téléphone connus (numéros de port, versions, etc.)
PHONE_ALLOWLIST = [
    re.compile(r"\b(?:8080|8443|3000|4000|5000|5432|5433|6379|27017|9200|9300|3306)\b"),
]


# ---------------------------------------------------------------------------
# Entropie de Shannon
# ---------------------------------------------------------------------------

def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for c in s:
        freq[c] = freq.get(c, 0) + 1
    n = len(s)
    return -sum((v / n) * math.log2(v / n) for v in freq.values())


def _has_mixed_chars(s: str) -> bool:
    return any(c.isupper() for c in s) and any(c.islower() for c in s) and any(c.isdigit() for c in s)


# ---------------------------------------------------------------------------
# Scan et redaction
# ---------------------------------------------------------------------------

def scan_text(text: str) -> list[dict]:
    """Retourne la liste des secrets détectés avec leurs positions."""
    if not text:
        return []

    findings: list[dict] = []

    for name, pattern in SECRET_PATTERNS:
        for match in pattern.finditer(text):
            matched = match.group(0)

            # Allowlist globale
            if any(p.search(matched) for p in ALLOWLIST):
                continue

            # Validation spécifique par type
            if name == "high_entropy_quoted":
                inner = matched[1:-1]
                if not _has_mixed_chars(inner):
                    continue
                if _shannon_entropy(inner) < 3.5:
                    continue
                if inner.count(".") > 2:
                    continue

            elif name == "high_entropy_bare":
                inner = match.group(1) if match.lastindex else matched.lstrip("=: ")
                if not _has_mixed_chars(inner):
                    continue
                if _shannon_entropy(inner) < 4.0:   # seuil plus élevé (hors guillemets = plus de FP)
                    continue
                if inner.count(".") > 2:
                    continue

            elif name == "phone":
                # Filtrer les séquences trop courtes ou ressemblant à des versions
                digits = re.sub(r"\D", "", matched)
                if len(digits) < 7 or len(digits) > 15:
                    continue
                if any(p.search(matched) for p in PHONE_ALLOWLIST):
                    continue

            elif name == "credit_card":
                digits = re.sub(r"\D", "", matched)
                if not _luhn_check(digits):
                    continue

            elif name == "bearer_opaque":
                # Ne pas redacter les valeurs trop simples (ex: "Bearer application/json")
                inner = match.group(1) if match.lastindex else matched.split()[-1]
                if _shannon_entropy(inner) < 3.0:
                    continue

            findings.append({
                "type":  name,
                "start": match.start(),
                "end":   match.end(),
            })

    return findings


def _luhn_check(digits: str) -> bool:
    """Validation Luhn pour les numéros de carte bancaire."""
    if not digits.isdigit() or len(digits) < 13:
        return False
    total = 0
    reverse = digits[::-1]
    for i, d in enumerate(reverse):
        n = int(d)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0


def redact_text(text: str) -> tuple[str, int]:
    """Redacte les secrets dans `text`. Retourne (texte_nettoyé, nb_redactions)."""
    if not text:
        return text, 0

    # 1. Anonymisation chemins/username
    text = _anonymize_text(text)

    # 2. Détection secrets
    findings = scan_text(text)
    if not findings:
        return text, 0

    # Tri décroissant par position → remplacement de la fin vers le début
    findings.sort(key=lambda f: f["start"], reverse=True)

    # Dédoublonnage des overlaps
    deduped: list[dict] = []
    for f in findings:
        if not deduped or f["end"] <= deduped[-1]["start"]:
            deduped.append(f)

    result = text
    for f in deduped:
        result = result[:f["start"]] + REDACTED + result[f["end"]:]

    return result, len(deduped)


def redact_custom(text: str, strings: list[str]) -> tuple[str, int]:
    """Redacte des strings personnalisées (noms, domaines internes, etc.)."""
    if not text or not strings:
        return text, 0
    count = 0
    for s in strings:
        if not s or len(s) < 3:
            continue
        escaped = re.escape(s)
        pattern = rf"\b{escaped}\b" if len(s) >= 4 else escaped
        text, n = re.subn(pattern, REDACTED, text, flags=re.IGNORECASE)
        count += n
    return text, count


# ---------------------------------------------------------------------------
# Redaction d'une valeur (récursif : str / dict / list)
# ---------------------------------------------------------------------------

def _redact_value(v: Any, custom: list[str]) -> tuple[Any, int]:
    if isinstance(v, str):
        text, n1 = redact_text(v)
        text, n2 = redact_custom(text, custom)
        return text, n1 + n2
    if isinstance(v, dict):
        total = 0
        out = {}
        for key, val in v.items():
            out[key], n = _redact_value(val, custom)
            total += n
        return out, total
    if isinstance(v, list):
        total = 0
        out = []
        for item in v:
            cleaned, n = _redact_value(item, custom)
            out.append(cleaned)
            total += n
        return out, total
    return v, 0


# ---------------------------------------------------------------------------
# Point d'entrée principal : redacter une session complète
# ---------------------------------------------------------------------------

def redact_session(session: dict, custom_strings: list[str] | None = None) -> tuple[dict, int]:
    """
    Redacte tous les champs texte d'une session avant push communautaire.
    Retourne (session_redactée, nb_total_redactions).

    Champs traités :
      - turns[].summary             (compacts)
      - turns[].user                (messages utilisateur)
      - turns[].assistant.thinking  (pensées étendues)
      - turns[].assistant.text      (réponses texte)
      - turns[].assistant.tool_calls[].input   (inputs outils)
      - turns[].assistant.tool_calls[].output  (outputs outils — Read, Glob...)
      - turns[].assistant.tool_calls[].stdout  (stdout bash)
      - turns[].assistant.tool_calls[].stderr  (stderr bash)
    """
    custom = custom_strings or []
    total  = 0

    for turn in session.get("turns", []):

        if turn.get("type") == "compact":
            turn["summary"], n = _redact_value(turn.get("summary", ""), custom)
            total += n
            continue

        if turn.get("type") != "exchange":
            continue

        # Message utilisateur
        turn["user"], n = _redact_value(turn.get("user", ""), custom)
        total += n

        asst = turn.get("assistant", {})

        # Thinking et texte
        for field in ("thinking", "text"):
            if asst.get(field):
                asst[field], n = _redact_value(asst[field], custom)
                total += n

        # Tool calls
        for tc in asst.get("tool_calls", []):
            for field in ("input", "output", "stdout", "stderr"):
                if tc.get(field):
                    tc[field], n = _redact_value(tc[field], custom)
                    total += n

    return session, total
