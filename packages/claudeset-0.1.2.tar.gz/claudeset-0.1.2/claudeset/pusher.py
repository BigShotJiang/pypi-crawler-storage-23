"""Push des sessions vers HuggingFace (repo perso ou repo communautaire)."""

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

COMMUNITY_REPO = "lelouch0110/claudeset-community"


# ---------------------------------------------------------------------------
# Helpers HF
# ---------------------------------------------------------------------------

def get_hf_username() -> str | None:
    try:
        from huggingface_hub import HfApi
        return HfApi().whoami()["name"]
    except Exception:
        return None


def _shard_filename() -> str:
    ts = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%S")
    return f"shard_{ts}.jsonl"


def _hash_username(username: str) -> str:
    """Hash court pour anonymiser le username HF dans les données."""
    return "user_" + hashlib.sha256(username.encode()).hexdigest()[:8]


def _upload_shard(sessions: list[dict], repo_path: str, repo_id: str) -> None:
    """Encode les sessions en JSONL et uploade sur HF."""
    try:
        from huggingface_hub import HfApi
    except ImportError:
        raise RuntimeError("huggingface_hub non installé. Lancez : pip install huggingface_hub")

    api = HfApi()
    api.create_repo(repo_id, repo_type="dataset", exist_ok=True)

    content = "\n".join(json.dumps(s, ensure_ascii=False) for s in sessions) + "\n"

    api.upload_file(
        path_or_fileobj=content.encode("utf-8"),
        path_in_repo=repo_path,
        repo_id=repo_id,
        repo_type="dataset",
        commit_message=f"Add {len(sessions)} sessions",
    )


def _update_dataset_card(repo_id: str, extra_info: dict) -> None:
    """Met à jour le README.md du repo avec les stats."""
    try:
        from huggingface_hub import HfApi
        api = HfApi()
        conn_tmp = _get_stats_from_hf(repo_id, api)
        # Simple card — peut être enrichie plus tard
        card = _build_card(repo_id, extra_info)
        api.upload_file(
            path_or_fileobj=card.encode("utf-8"),
            path_in_repo="README.md",
            repo_id=repo_id,
            repo_type="dataset",
            commit_message="Update dataset card",
        )
    except Exception:
        pass  # La card n'est pas critique


def _get_stats_from_hf(repo_id: str, api) -> dict:
    return {}


def _build_card(repo_id: str, info: dict) -> str:
    sessions = info.get("total_sessions", "?")
    updated  = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")
    return f"""---
license: mit
task_categories:
  - text-generation
language:
  - en
tags:
  - claude-code
  - conversations
  - coding-assistant
  - tool-use
  - agentic-coding
pretty_name: Claude Code Conversations
---

# Claude Code Conversations

Exported with **clawback** — a richer fork of [dataclaw](https://github.com/banodoco/dataclaw).

## Stats

| Metric | Value |
|--------|-------|
| Sessions | {sessions} |
| Last updated | {updated} |

## Schema

Each line in each shard file is one full conversation session:

```json
{{
  "id": "session-uuid",
  "project": "my-project",
  "model": "claude-sonnet-4-6",
  "git_branch": "main",
  "start_time": "2026-02-26T02:14:28Z",
  "end_time":   "2026-02-26T03:00:00Z",
  "turns": [
    {{"type": "compact", "summary": "...résumé du contexte compressé..."}},
    {{
      "type": "exchange",
      "user": "fix the login bug",
      "assistant": {{
        "thinking": "...",
        "text":     "Je vais analyser...",
        "tool_calls": [
          {{"tool": "Read",  "input": "src/auth.py", "output": "..."}},
          {{"tool": "Bash",  "input": "pytest ...",  "stdout": "...", "stderr": ""}}
        ]
      }},
      "usage": {{"input_tokens": 5000, "output_tokens": 300}}
    }}
  ],
  "stats": {{
    "exchanges": 12, "compacts": 2, "tool_calls": 45,
    "input_tokens": 150000, "output_tokens": 8000
  }}
}}
```

## Load

```python
from datasets import load_dataset
ds = load_dataset("{repo_id}", split="train")
```
"""


# ---------------------------------------------------------------------------
# Push vers repo PERSO
# ---------------------------------------------------------------------------

def push_personal(conn, repo_id: str) -> dict:
    """
    Pousse les sessions pas encore envoyées vers le repo perso de l'utilisateur.
    Chaque push crée un nouveau shard : data/shard_YYYYMMDD_HHMMSS.jsonl
    """
    from .db import get_unpushed_sessions, mark_pushed

    sessions = get_unpushed_sessions(conn, target="personal")
    if not sessions:
        print("Aucune nouvelle session à pousser vers le repo perso.")
        return {"pushed": 0, "repo": repo_id}

    shard     = _shard_filename()
    repo_path = f"data/{shard}"

    print(f"  → {len(sessions)} nouvelles sessions")
    print(f"  → Shard : {repo_path}")
    print(f"  → Repo  : {repo_id}")

    _upload_shard(sessions, repo_path, repo_id)
    mark_pushed(conn, [s["id"] for s in sessions], target="personal")

    _update_dataset_card(repo_id, {"total_sessions": len(sessions)})

    print(f"  ✓ Poussé vers https://huggingface.co/datasets/{repo_id}")
    return {"pushed": len(sessions), "shard": repo_path, "repo": repo_id}


# ---------------------------------------------------------------------------
# Push vers repo COMMUNAUTAIRE
# ---------------------------------------------------------------------------

def push_community(conn, repo_id: str = COMMUNITY_REPO, custom_strings: list[str] | None = None) -> dict:
    """
    Pousse les sessions pas encore envoyées vers le repo communautaire.
    Les sessions sont stockées sous : data/<hf_username>/shard_YYYYMMDD_HHMMSS.jsonl

    Avant le push :
      - Redaction automatique (secrets, PII, chemins, username système)
      - Redaction des strings personnalisées (noms, domaines internes...)
      - Username HF hashé dans les données
    """
    from .db import get_unpushed_sessions, mark_pushed
    from .redactor import redact_session

    hf_username = get_hf_username()
    if not hf_username:
        raise RuntimeError(
            "Non connecté à HuggingFace.\n"
            "Lancez : huggingface-cli login --token <TOKEN>"
        )

    sessions = get_unpushed_sessions(conn, target="community")
    if not sessions:
        print("Aucune nouvelle session à pousser vers le repo communautaire.")
        return {"pushed": 0, "repo": repo_id}

    contributor   = _hash_username(hf_username)
    total_redacted = 0

    cleaned_sessions = []
    for s in sessions:
        s["contributor"] = contributor
        s, n = redact_session(s, custom_strings=custom_strings)
        total_redacted += n
        cleaned_sessions.append(s)

    shard     = _shard_filename()
    repo_path = f"data/{hf_username}/{shard}"

    print(f"  → {len(cleaned_sessions)} nouvelles sessions")
    print(f"  → {total_redacted} redactions appliquées")
    print(f"  → Shard : {repo_path}")
    print(f"  → Repo  : {repo_id}")

    _upload_shard(cleaned_sessions, repo_path, repo_id)
    mark_pushed(conn, [s["id"] for s in cleaned_sessions], target="community")

    print(f"  ✓ Poussé vers https://huggingface.co/datasets/{repo_id}")
    return {
        "pushed":      len(cleaned_sessions),
        "redactions":  total_redacted,
        "shard":       repo_path,
        "repo":        repo_id,
        "contributor": hf_username,
    }


# ---------------------------------------------------------------------------
# CLI minimal
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    from .db import get_connection

    conn = get_connection()

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python pusher.py personal <repo_id>   # ex: lelouch/claude-code-lelouch")
        print("  python pusher.py community             # repo communautaire par défaut")
        sys.exit(1)

    target = sys.argv[1]

    if target == "personal":
        if len(sys.argv) < 3:
            print("Erreur : spécifiez le repo. Ex: python pusher.py personal lelouch/my-dataset")
            sys.exit(1)
        result = push_personal(conn, sys.argv[2])

    elif target == "community":
        repo = sys.argv[2] if len(sys.argv) > 2 else COMMUNITY_REPO
        result = push_community(conn, repo)

    else:
        print(f"Cible inconnue : {target}. Utilisez 'personal' ou 'community'.")
        sys.exit(1)

    conn.close()
    print(f"\nRésultat : {result}")
