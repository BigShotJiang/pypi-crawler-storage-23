from typing import List, Dict, Any, Optional, Union, TypedDict, Literal

class PaginationMeta(TypedDict):
    total_records: int
    current_page: Union[int, str]
    records_per_page: Union[int, str]
    total_pages: int

class PaginatedResponse(TypedDict):
    data: List[Dict[str, Any]]
    meta: PaginationMeta

# --- HABITACIONES ---
class RoomDescription(TypedDict):
    description: str
    lang: str

class RoomPhoto(TypedDict):
    photo_id: int
    url: str

class RoomUnit(TypedDict):
    id: int
    name: str
    type: str

class RoomCategory(TypedDict):
    category_id: int
    name: str
    type: str
    capacity: int
    quantity: int
    descriptions: List[RoomDescription]
    photos: List[RoomPhoto]
    rooms: List[RoomUnit]

class RoomStatusItem(TypedDict):
    category_id: int
    room_category: str
    room_id: int
    room: str
    blocked: int
    notes: str

class RoomStatusResponse(TypedDict):
    checkin_today: List[RoomStatusItem]
    checkout_today: List[RoomStatusItem]
    in_house: List[RoomStatusItem]
    no_guest: List[RoomStatusItem]

# --- DISPONIBILIDAD ---
class Restriction(TypedDict):
    min_stay: int
    max_stay: int
    lead_days: int

class AvailablePrice(TypedDict):
    people: int
    value: float

class AvailableCategory(TypedDict):
    category_id: int
    name: str
    available_rooms: int
    prices: List[AvailablePrice]
    restrictions: Restriction

class AvailableRoomDate(TypedDict):
    date: str
    categories: List[AvailableCategory]

class AvailableRoomsResponse(TypedDict):
    data: List[AvailableRoomDate]
    meta: PaginationMeta

# --- CLIENTES ---
class DocumentType(TypedDict):
    id: int
    name: str

class CustomerData(TypedDict, total=False):
    customer_document: str
    customer_nationality: str
    name: str
    surname: str
    second_surname: str
    document_id: int
    birthdate: str
    gender: Literal["male", "female"]
    phone: str
    email: str
    activities: str
    address: str
    note: str

# --- RESERVAS ---
class BookingHolder(TypedDict):
    client_id: int
    type_document: str
    document: str
    name: str
    surname: str
    second_surname: str
    email: str
    phone: str
    country: str

class BookingCategory(TypedDict):
    category_id: int
    name: str

class BookingChannel(TypedDict):
    channel_id: int
    name: str

class BookingListItem(TypedDict):
    booking_id: int
    creation_date: str
    category: BookingCategory
    assigned_room: Dict[str, str]
    channel: BookingChannel
    start_date: str
    end_date: str
    checkin_online: bool
    holder: BookingHolder
    plan: str
    guests: List[BookingHolder]
    note: str
    total_guests: int
    paid_out: float
    total_to_pay_accommodation: float
    total_to_pay: float
    checked_in: bool
    checked_out: bool

class BookingListResponse(TypedDict):
    data: List[BookingListItem]
    meta: PaginationMeta

class RatePerDay(TypedDict):
    date: str
    price: float

class BookingData(TypedDict, total=False):
    category_id: int
    start_date: str
    end_date: str
    total_adults: int
    total_children: int
    holder_name: str
    customer_document: str
    customer_nationality: str
    rates_per_day: List[RatePerDay]
    note: str
    payment: float
    channel: int

class PanelUser(TypedDict):
    id: str
    name: str

class BookingDetailResponse(TypedDict):
    id_reserva: int
    fecha_creacion: str
    estatus: str
    fecha_ingreso: str
    fecha_salida: str
    impuesto: str
    checkin_realizado: Optional[bool]
    checkout_realizado: Optional[bool]
    nota: str
    total_alojamiento: str
    usuario_creacion: int
    numero_personas: int
    factura_cliente: Dict[str, Any]
    tarifas_por_dia: List[Dict[str, Any]]
    cliente: Dict[str, Any]
    huespedes: List[Dict[str, Any]]
    agencia: str
    cuarto: str
    categoria: str
