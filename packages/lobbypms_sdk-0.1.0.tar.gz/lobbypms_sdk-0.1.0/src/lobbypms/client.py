import os
import json
import urllib.request
import urllib.parse
import urllib.error
import ssl
import http.cookiejar
from html.parser import HTMLParser
from typing import List, Dict, Any, Optional, Literal

from .types import (
    PaginatedResponse, RoomStatusResponse, AvailableRoomsResponse,
    DocumentType, CustomerData, BookingListResponse, BookingData,
    BookingDetailResponse, BookingChannel, PanelUser
)

BASE_API_URL = "https://api.lobbypms.com/api"
BASE_PANEL_URL = "https://app.lobbypms.com"

class UserListParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.users: List[PanelUser] = []
        self.is_usuario_select = False
        
    def handle_starttag(self, tag, attrs):
        if tag == "select":
            for name, value in attrs:
                if name == "name" and value == "usuario":
                    self.is_usuario_select = True
        
        if self.is_usuario_select and tag == "option":
            for name, value in attrs:
                if name == "value" and value:
                    self.users.append({"id": value, "name": ""})

    def handle_data(self, data):
        if self.is_usuario_select and self.users and not self.users[-1]["name"]:
            self.users[-1]["name"] = data.strip()

    def handle_endtag(self, tag):
        if tag == "select" and self.is_usuario_select:
            self.is_usuario_select = False

class PMSRequest:
    def __init__(self, api_token: Optional[str] = None, verify_ssl: bool = True):
        self.api_token = api_token
        self.verify_ssl = verify_ssl
        self.cookie_jar = http.cookiejar.CookieJar()
        
        handlers = [urllib.request.HTTPCookieProcessor(self.cookie_jar)]
        
        if not verify_ssl:
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            handlers.append(urllib.request.HTTPSHandler(context=ssl_context))
        
        self.opener = urllib.request.build_opener(*handlers)

    def api(self, path: str, method: str = "GET", params: Dict[str, Any] = None, data: Dict[str, Any] = None, base_url: str = BASE_API_URL, is_json: bool = True) -> Any:
        version = ""
        if base_url == BASE_API_URL:
            version = "/v1" if not (path.startswith("/v1") or path.startswith("/v2")) else ""
            
        full_url = f"{base_url}{version}{path}"
        
        req_params = params.copy() if params else {}
        req_json = data.copy() if data else {}

        if base_url == BASE_API_URL and self.api_token:
            if "api_token" not in req_params and "api_token" not in req_json:
                if method == "GET":
                    req_params["api_token"] = self.api_token
                    if "paginate" not in req_params: req_params["paginate"] = 100
                else:
                    req_json["api_token"] = self.api_token

        if req_params:
            query_string = urllib.parse.urlencode(req_params)
            full_url = f"{full_url}?{query_string}"

        headers = {
            "Accept": "application/json" if is_json else "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
        }
        
        if base_url == BASE_PANEL_URL:
            headers["Authorization"] = "Basic ZGV2ZWxvcGVyczpMb2JieVBNUyQ4NCoh"

        request_body = None
        if req_json and method != "GET":
            if is_json:
                request_body = json.dumps(req_json).encode("utf-8")
                headers["Content-Type"] = "application/json"
            else:
                request_body = urllib.parse.urlencode(req_json).encode("utf-8")
                headers["Content-Type"] = "application/x-www-form-urlencoded"

        req = urllib.request.Request(full_url, data=request_body, headers=headers, method=method)

        try:
            with self.opener.open(req) as response:
                status_code = response.getcode()
                content = response.read().decode("utf-8")
                
                if is_json:
                    try:
                        return json.loads(content)
                    except json.JSONDecodeError:
                        return {"error": "Invalid JSON response", "content": content, "status_code": status_code}
                return content
        except urllib.error.HTTPError as e:
            try:
                error_content = e.read().decode("utf-8")
                return json.loads(error_content) if is_json else error_content
            except:
                return {"error": f"HTTP Error {e.code}", "status_code": e.code}
        except urllib.error.URLError as e:
            return {"error": f"URL Error: {str(e.reason)}"}
        except Exception as e:
            return {"error": f"Error: {str(e)}"}

class PMS:
    """
    Client for LobbyPMS API and Dashboard.
    Zero external dependencies.
    """
    def __init__(self, api_token: Optional[str] = None, verify_ssl: bool = True):
        """
        Initialize the PMS client.
        
        :param api_token: Your LobbyPMS API token.
        :param verify_ssl: Whether to verify SSL certificates (default: True).
        """
        self.api_token = api_token or os.environ.get("LOBBYPMS_API_TOKEN") or self._load_from_dot_env()
        self.request_handler = PMSRequest(self.api_token, verify_ssl=verify_ssl)

    def _load_from_dot_env(self) -> Optional[str]:
        dotenv_path = os.path.join(os.getcwd(), '.env')
        if os.path.exists(dotenv_path):
            try:
                with open(dotenv_path, 'r') as f:
                    for line in f:
                        if line.startswith('LOBBYPMS_API_TOKEN='):
                            return line.split('=', 1)[1].strip().strip('"').strip("'")
            except:
                pass
        return None

    # --- PANEL / DASHBOARD AUTHENTICATION ---
    
    def get_panel_users(self, hotel_code: str) -> List[PanelUser]:
        """
        Retrieves the list of administrative users for a given hotel code.
        """
        html_response = self.request_handler.api(
            "/entrar/validarhotel", 
            method="POST", 
            data={"codigoHotel": hotel_code, "lg": ""}, 
            base_url=BASE_PANEL_URL,
            is_json=False
        )
        
        if isinstance(html_response, dict) and "error" in html_response:
            return []

        parser = UserListParser()
        parser.feed(html_response)
        return parser.users

    def login_panel(self, hotel_code: str, user_id: str, password: str) -> bool:
        """
        Authenticates a user into the administrative panel.
        Returns True if login redirect was successful.
        """
        # Ensure we have a session by calling validarhotel first if cookie jar is empty
        if not any(cookie.name == 'PHPSESSID' for cookie in self.request_handler.cookie_jar):
            self.get_panel_users(hotel_code)

        response = self.request_handler.api(
            "/entrar/validarDatos", 
            method="POST", 
            data={
                "codigoHotel": hotel_code,
                "usuario": user_id,
                "pass": password,
                "lg": ""
            }, 
            base_url=BASE_PANEL_URL,
            is_json=False
        )
        # Success logic: Successful login redirects to /dashboard.
        # If we get a response that doesn't look like an error or the login page again, we consider it success.
        return "Iniciar sesión" not in response

    def get_notifications(self) -> Dict[str, Any]:
        """
        Fetches administrative notifications from the panel.
        Requires prior call to login_panel.
        """
        return self.request_handler.api(
            "/ajax/Dashboard/getNotifications",
            params={"type": "all", "is_priority": "0", "page": "0"},
            base_url=BASE_PANEL_URL,
            is_json=True
        )

    # --- API HABITACIONES ---
    def rooms(self, page: int = 1) -> PaginatedResponse:
        return self.request_handler.api("/rooms", params={"page": page})

    def rooms_status(self, page: int = 1) -> RoomStatusResponse:
        return self.request_handler.api("/rooms/status", params={"page": page})

    def available_rooms(self, start_date: str, end_date: str, category_id: Optional[int] = None, page: int = 1, paginate: Optional[int] = None) -> AvailableRoomsResponse:
        params: Dict[str, Any] = {"start_date": start_date, "end_date": end_date, "page": page}
        if category_id: params["category_id"] = category_id
        if paginate: params["paginate"] = paginate
        return self.request_handler.api("/available-rooms", params=params)

    def available_rooms_v2(self, start_date: str, end_date: str, category_id: Optional[int] = None, page: int = 1, paginate: Optional[int] = None) -> AvailableRoomsResponse:
        params: Dict[str, Any] = {"start_date": start_date, "end_date": end_date, "page": page}
        if category_id: params["category_id"] = category_id
        if paginate: params["paginate"] = paginate
        return self.request_handler.api("/v2/available-rooms", params=params)

    # --- API PRODUCTOS Y TARIFAS ---
    def products(self, page: int = 1, paginate: Optional[int] = None) -> PaginatedResponse:
        params: Dict[str, Any] = {"page": page}
        if paginate: params["paginate"] = paginate
        return self.request_handler.api("/products", params=params)

    def rate_plans(self, paginate: Optional[int] = None) -> PaginatedResponse:
        params: Dict[str, Any] = {}
        if paginate: params["paginate"] = paginate
        return self.request_handler.api("/rate-plans", params=params)

    def channels(self) -> Dict[str, List[BookingChannel]]:
        return self.request_handler.api("/channels")

    # --- API CONFIGURACION ---
    def documents(self) -> List[DocumentType]:
        return self.request_handler.api("/documents")

    # --- API CLIENTES ---
    def create_customer(self, type: Literal[1, 2], customer_data: CustomerData) -> Dict[str, str]:
        return self.request_handler.api(f"/customer/{type}", method="POST", data=customer_data)

    # --- API RESERVAS ---
    def bookings(self, **kwargs: Any) -> BookingListResponse:
        return self.request_handler.api("/bookings", params=kwargs)

    def create_booking(self, booking_data: BookingData) -> Dict[str, Any]:
        return self.request_handler.api("/bookings", method="POST", data=booking_data)

    def booking_details(self, booking_id: int) -> Dict[str, BookingDetailResponse]:
        return self.request_handler.api(f"/bookings/{booking_id}")

    def cancel_booking(self, booking_id: int, reason: Literal["NS","RC","RE","TTC","CC","OTH"], description: str = "") -> Dict[str, Any]:
        data = {"cancellation_reason": reason, "description": description}
        return self.request_handler.api(f"/cancel-booking/{booking_id}", method="POST", data=data)

    # --- API BLOQUEOS ---
    def create_block(self, block_data: Dict[str, Any]) -> Dict[str, Any]:
        return self.request_handler.api("/block", method="POST", data=block_data)

    def delete_block(self, block_id: int) -> Dict[str, Any]:
        return self.request_handler.api(f"/block/{block_id}", method="DELETE")

    # --- API ESTADISTICAS Y CONSUMOS ---
    def occupancy(self, start_date: str, end_date: str, category_id: Optional[int] = None) -> PaginatedResponse:
        params: Dict[str, Any] = {"start_date": start_date, "end_date": end_date}
        if category_id: params["category_id"] = category_id
        return self.request_handler.api("/occupancy", params=params)

    def daily_occupancy(self, start_date: str, end_date: str, category_id: Optional[int] = None) -> PaginatedResponse:
        params: Dict[str, Any] = {"start_date": start_date, "end_date": end_date}
        if category_id: params["category_id"] = category_id
        return self.request_handler.api("/daily-occupancy", params=params)

    def add_consumption(self, booking_id: int, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        data = {"booking_id": booking_id, "items": items}
        return self.request_handler.api("/booking/add-product-service", method="POST", data=data)

    def update_seasons(self, season_data: Dict[str, Any]) -> Dict[str, Any]:
        return self.request_handler.api("/seasons", method="POST", data=season_data)
