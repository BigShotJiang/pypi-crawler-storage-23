# LobbyPMS SDK

A professional, zero-dependency, fully-typed Python SDK for the [LobbyPMS](https://lobbypms.com) API and Administrative Dashboard.

## Installation

```bash
pip install lobbypms-sdk
```

## Features

- **Zero Dependencies:** Built entirely on Python's standard library (`urllib`, `ssl`, `json`).
- **Fully Typed:** Comprehensive `TypedDict` definitions for all API responses.
- **API & Dashboard Support:** Access both the official v1/v2 API and the administrative panel (session/cookie based auth).
- **Pure Python:** No external requirements like `requests` or `dotenv`.

## Quick Start

### 1. Basic API Usage

```python
from lobbypms import PMS

# Authentication is handled via parameter or environment variable (LOBBYPMS_API_TOKEN)
pms = PMS(api_token="your_token_here")

# Get rooms
rooms = pms.rooms()
print(rooms['data'])
```

### 2. Administrative Panel Authentication

```python
from lobbypms import PMS

pms = PMS()

# 1. Get users for a hotel code
users = pms.get_panel_users('13814')

# 2. Login to the visual dashboard
success = pms.login_panel('13814', user_id='330414', password='your_password')

if success:
    # 3. Access dashboard-only endpoints
    notifications = pms.get_notifications()
```

## Environment Variables

The SDK can automatically load the API token from the environment:

- `LOBBYPMS_API_TOKEN`: Your API token.

It also supports a native fallback to read from a local `.env` file in the current working directory without requiring any external libraries.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request to [lobbypms-sdk-python](https://github.com/nikitacontreras/lobbypms-sdk-python).

## License

MIT
