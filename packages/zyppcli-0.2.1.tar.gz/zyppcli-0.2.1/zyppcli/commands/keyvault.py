import argparse
import logging
import sys

from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from azure.mgmt.keyvault import KeyVaultManagementClient

logger = logging.getLogger(__name__)


def register(subparsers: argparse._SubParsersAction) -> None:
    """Register the 'keyvault' command and its subcommands."""
    keyvault_parser = subparsers.add_parser("keyvault", help="Azure Key Vault operations")
    keyvault_subparsers = keyvault_parser.add_subparsers(dest="keyvault_command")

    list_parser = keyvault_subparsers.add_parser("list", help="List all accessible Key Vaults")
    list_parser.add_argument("--subscription", required=True, help="Azure subscription ID")
    list_parser.add_argument("--name", help="Filter vaults whose name contains this value (case-insensitive)")

    load_parser = keyvault_subparsers.add_parser("load", help="Load secrets as shell export statements")
    load_parser.add_argument("--vault", required=True, help="Name of the Azure Key Vault")


def run(args: argparse.Namespace) -> None:
    """Execute the specified 'keyvault' command."""
    if args.keyvault_command == "list":
        _list(args.subscription, name_filter=args.name)
    elif args.keyvault_command == "load":
        _load(args.vault)
    else:
        logger.error("Usage: zypp keyvault {list,load}")
        sys.exit(1)


def _list(subscription_id: str, name_filter: str | None = None) -> None:
    """List all accessible Key Vaults in the subscription."""
    try:
        credential = DefaultAzureCredential(exclude_environment_credential=True)
        client = KeyVaultManagementClient(credential=credential, subscription_id=subscription_id)
        for vault in client.vaults.list_by_subscription():
            if name_filter and name_filter.lower() not in vault.name.lower():
                continue
            print(vault.name)
    except Exception as e:
        logger.exception("Failed to list Key Vaults: %s", e)
        logger.info("Hint: Make sure you are authenticated via `az login`.")
        sys.exit(1)


def _get_secrets(vault_name: str) -> dict[str, str]:
    """Fetch secrets from the specified Azure Key Vault."""
    credential = DefaultAzureCredential(exclude_environment_credential=True)
    client = SecretClient(vault_url=f"https://{vault_name}.vault.azure.net", credential=credential)

    secrets = {}
    for prop in client.list_properties_of_secrets():
        if prop.enabled:
            secrets[prop.name] = client.get_secret(prop.name).value

    return secrets


def _load(vault_name: str) -> None:
    """Load secrets from the specified Azure Key Vault and print them as shell export statements."""
    try:
        secrets = _get_secrets(vault_name)
    except Exception as e:
        logger.exception("Failed to fetch secrets from '%s': %s", vault_name, e)
        logger.info("Hint: Make sure you are authenticated via `az login`.")
        sys.exit(1)

    for name, value in secrets.items():
        env_name = name.replace("-", "_").upper()
        escaped_value = value.replace("'", "'\\''")
        print(f"export {env_name}='{escaped_value}'")
