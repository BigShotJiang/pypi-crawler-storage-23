# Zypp CLI

Internal CLI for Zypp. Replaces `.env` files by loading secrets directly from Azure Key Vault into your shell environment.

## Installation

```bash
uv tool install zyppcli
```

To upgrade to the latest version:

```bash
uv tool install zyppcli --upgrade
```

## Prerequisites

You need to be authenticated with Azure:

```bash
az login
```

## Usage

### List Key Vaults

```bash
zypp keyvault list --subscription <subscription-id>
```

Lists all accessible Key Vaults in the given Azure subscription.

To filter by name (case-insensitive substring match):

```bash
zypp keyvault list --subscription <subscription-id> --name dev
```

### Load secrets from Azure Key Vault

```bash
eval $(zypp keyvault load --vault <vault-name>)
```

This fetches all enabled secrets from the specified vault and exports them as environment variables. Secret names are transformed: hyphens become underscores and the name is uppercased (e.g. `db-password` becomes `DB_PASSWORD`).

Without `eval`, the command only prints the export statements without setting them:

```bash
zypp keyvault load --vault <vault-name>
# Output:
# export DB_PASSWORD='...'
# export SQL_DB='...'
```

### Version

```bash
zypp --version
```
