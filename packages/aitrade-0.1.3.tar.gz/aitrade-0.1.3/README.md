# aitrade

A Python client for accessing financial data through the aitrade API.

## Installation

```bash
pip install aitrade
```

## Usage

```python
import aitrade as ts

# Initialize API client
pro = ts.pro_api("your_token")

# Get stock basic data
data = pro.tradepost("stock_basic", exchange='', list_status='L', fields='ts_code,symbol,name,area,industry,list_date')
print(data)

# Get ETF share size data
data = pro.tradepost("etf_share_size", ts_code='510330.SH', start_date='20250101', end_date='20251224')
print(data)
```

## Requirements

- pandas
- requests

## License

MIT License
