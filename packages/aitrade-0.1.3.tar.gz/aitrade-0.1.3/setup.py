from setuptools import setup, find_packages
import os
from setuptools.command.install import install
import shutil

# 只包含 aitrade 包
packages = ['aitrade']

# 获取 aitrade 目录下所有需要包含的文件
def package_data():
    data = {}
    for root, dirs, files in os.walk('aitrade'):
        if files:
            # 只处理 aitrade 目录下的文件
            if root.startswith('aitrade'):
                package = root.replace(os.path.sep, '.')
                data[package] = files
    return data

# 自定义安装命令，确保 pyarmor_runtime_000000 安装到根级别
class CustomInstall(install):
    def run(self):
        install.run(self)
        # 复制 pyarmor_runtime_000000 到安装目录的根级别
        if os.path.exists('aitrade/pyarmor_runtime_000000'):
            target_dir = os.path.join(self.install_lib, 'pyarmor_runtime_000000')
            if not os.path.exists(target_dir):
                os.makedirs(target_dir)
            for file in os.listdir('aitrade/pyarmor_runtime_000000'):
                src = os.path.join('aitrade/pyarmor_runtime_000000', file)
                dst = os.path.join(target_dir, file)
                if os.path.isfile(src):
                    shutil.copy2(src, dst)

setup(
    name="aitrade",
    version="0.1.3",
    packages=packages,
    package_data=package_data(),
    install_requires=[
        "pandas",
        "requests"
    ],
    author="Your Name",
    author_email="your.email@example.com",
    description="A Python client for accessing financial data",
    long_description="A Python client for accessing financial data through the aitrade API",
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/aitrade",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    cmdclass={
        'install': CustomInstall,
    },
    # 确保 pyarmor_runtime_000000 被包含在发布包中
    data_files=[
        ('pyarmor_runtime_000000', [
            'aitrade/pyarmor_runtime_000000/__init__.py',
            'aitrade/pyarmor_runtime_000000/pyarmor_runtime.pyd'
        ])
    ],
    # 排除不需要的文件
    exclude_package_data={
        '': ['backup/*', 'codeshouhu2026/*', '*.pyc'],
    },
)
