import pandas as pd
import requests
import json
from typing import Optional, Dict, Any

# 公共变量：Java Controller服务地址
BASE_URL = "http://www.aitrade888.com"

class ProApi:
    def __init__(self, token: str, base_url: str = BASE_URL):
        self.token = token
        self.base_url = base_url
       
    def tradepost(self, strmethod: str, **kwargs) -> pd.DataFrame:
        """
        通过Java Controller转发到Flask服务调用tushare API
        参数:
            strmethod: tushare API方法名
            **kwargs: API方法参数
        返回:
            DataFrame格式的API返回数据
        """
        # Java Controller服务地址
        url = f"{self.base_url}/cms/blog/cms/tushare"
        
        # 构造请求数据
        data = {
            "method": strmethod,
            "token": self.token,
            "params": kwargs
        }
        
        try:
            # 发送POST请求到Java Controller
            response = requests.post(url, json=data, timeout=30)
            response.raise_for_status()  # 检查请求是否成功
            
            # 解析响应数据
            result = response.json()
            
            if result.get("code") == 200:
                # 获取Flask服务的原始响应数据
                flask_data = result.get("data", {})
                
                # 检查Flask服务是否返回成功
                if flask_data.get("success"):
                    # 获取数据列表
                    data_list = flask_data.get("data", [])
                    if data_list:
                        df = pd.DataFrame(data_list)
                        return df
                    else:
                        # 如果没有数据，返回空DataFrame
                        return pd.DataFrame()
                else:
                    # 处理Flask服务错误
                    error_msg = flask_data.get("message", "Unknown error")
                    raise Exception(f"Flask服务调用失败: {error_msg}")
            else:
                # 处理Java Controller错误
                error_msg = result.get("msg", "Unknown error")
                raise Exception(f"Java Controller调用失败: {error_msg}")
                
        except requests.exceptions.RequestException as e:
            # 处理网络错误
            raise Exception(f"网络请求失败: {str(e)}")
        except Exception as e:
            # 处理其他错误
            raise Exception(f"调用tradepost失败: {str(e)}")

def pro_api(token: str, base_url: str = BASE_URL) -> ProApi:
    """
    初始化API客户端
    参数:
        token: 访问令牌
        base_url: Java Controller服务地址，默认为 BASE_URL
    返回:
        ProApi实例
    """
    return ProApi(token, base_url)
