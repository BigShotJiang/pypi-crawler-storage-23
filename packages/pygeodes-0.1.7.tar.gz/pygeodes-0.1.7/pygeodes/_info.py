version = "0.1.7"
name = "pygeodes"
description = "A Python client for Geodes APIs"
author = "CNES"
