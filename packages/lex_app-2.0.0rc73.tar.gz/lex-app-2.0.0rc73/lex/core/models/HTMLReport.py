class HTMLReport:

    def get_html(self, user):
        return ''
