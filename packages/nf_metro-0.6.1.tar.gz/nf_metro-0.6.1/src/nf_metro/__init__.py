"""nf-metro: Generate metro-map-style SVG diagrams from Mermaid graph definitions."""

__version__ = "0.6.1"

__all__ = ["__version__"]
