# services/workflows/constants.py
from datetime import timedelta
from temporalio.common import RetryPolicy
# guardianhub/workflows/constants.py
from guardianhub.config.settings import settings
from guardianhub import get_logger
logger = get_logger(__name__)

# Rapid response for DB lookups
SHORT_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(seconds=60),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=1),
        backoff_coefficient=2.0,
        maximum_attempts=5,  # Higher retries for transient DB flickers
    )
}

# Standard LLM reasoning and bundle assembly
MEDIUM_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(minutes=5),
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=5),
        backoff_coefficient=2.0,
        maximum_attempts=3,
    )
}

# Heavy lifting: Agentic ReAct loops and complex audits
# services/workflows/constants.py

LONG_ACTIVITY_OPTIONS = {
    "start_to_close_timeout": timedelta(minutes=30),
    "heartbeat_timeout": timedelta(minutes=3),  # Increased from 1m to 3m
    "retry_policy": RetryPolicy(
        initial_interval=timedelta(seconds=10),
        backoff_coefficient=2.0,
        maximum_attempts=3,
        non_retryable_error_types=["ValidationError"] # Don't retry bad data
    )
}

from typing import Any
from enum import Enum


def get_activity_options(activity_input: Any) -> dict:
    """
    Unified Timeout Resolver: Maps Activity Roles to Temporal Timeout Profiles.
    Handles Enum objects, raw strings, and provides a safety fallback.
    """
    wf_config = settings.workflow_settings

    # 1. Normalize: Extract the string name regardless of input type
    if isinstance(activity_input, Enum):
        role_name = activity_input.value
    elif hasattr(activity_input, 'value'):  # Catch-all for other Enum-like objects
        role_name = str(activity_input.value)
    else:
        role_name = str(activity_input)

    # 2. Priority Routing (Matches your config_prod.json structure)
    if role_name in wf_config.long_activities:
        logger.info(f"🚀 [TIMEOUT_ROUTING] '{role_name}' -> LONG_PROFILE (30m)")
        return LONG_ACTIVITY_OPTIONS

    if role_name in wf_config.medium_activities:
        logger.info(f"📊 [TIMEOUT_ROUTING] '{role_name}' -> MEDIUM_PROFILE (5m)")
        return MEDIUM_ACTIVITY_OPTIONS

    if role_name in wf_config.short_activities:
        logger.debug(f"⚡ [TIMEOUT_ROUTING] '{role_name}' -> SHORT_PROFILE (60s)")
        return SHORT_ACTIVITY_OPTIONS

    # 3. Keyword-Based Safety Net
    # This catches "execute_direct_intervention" even if it's missing from config lists
    role_lower = role_name.lower()
    if any(k in role_lower for k in ["intervention", "support", "scrap", "report"]):
        logger.warning(f"⚠️ [TIMEOUT_FALLBACK] '{role_name}' missing from config. Mapping to LONG based on keyword.")
        return LONG_ACTIVITY_OPTIONS

    # 4. Final Default
    logger.warning(f"❓ [TIMEOUT_DEFAULT] '{role_name}' unknown. Defaulting to SHORT.")
    return SHORT_ACTIVITY_OPTIONS



# guardianhub/workflows/constants.py

def get_all_activities(activity_service_instance) -> list:
    activities = []
    mapping = settings.workflow_settings.activity_mapping
    cls = type(activity_service_instance)

    logger.info(f"🧬 [GET_ALL_ACTIVITIES] Final Forensic Scan: {cls.__name__}")

    for role_key, method_name in mapping.items():
        # 🟢 THE SECRET SAUCE: Look in the class's raw internal dictionary
        # This bypasses all Python 'lookup magic' and bound-method shadows
        raw_func_from_dict = cls.__dict__.get(method_name)

        logger.info(f"🕵️ [DICT_LOOKUP] Role: '{role_key}' | Method: '{method_name}' | Obj: {raw_func_from_dict}")

        if raw_func_from_dict:
            # Check if the decorator metadata is physically on the object in the dict
            if hasattr(raw_func_from_dict, "_defn"):
                # SUCCESS: We found the 'Blessing'.
                # Now get the bound version from the instance so 'self' is correct.
                bound_method = getattr(activity_service_instance, method_name)
                activities.append(bound_method)
                logger.info(f"✅ [VERIFIED] {method_name} is a blessed Temporal activity.")
            else:
                logger.warning(f"❌ [NAKED] {method_name} exists in dict but has no _defn attribute!")
        else:
            # Fallback for inherited methods (which don't show up in __dict__)
            inherited_func = getattr(cls, method_name, None)
            if inherited_func and hasattr(inherited_func, "_defn"):
                bound_method = getattr(activity_service_instance, method_name)
                activities.append(bound_method)
                logger.info(f"✅ [VERIFIED-INHERITED] {method_name} found via MRO.")
            else:
                logger.error(f"🚫 [NOT_FOUND] {method_name} is missing or undecorated.")

    return activities