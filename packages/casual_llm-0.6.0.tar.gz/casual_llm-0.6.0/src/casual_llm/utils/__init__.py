"""
Utility modules for casual-llm.
"""

from casual_llm.utils.image import fetch_image_as_base64

__all__ = [
    "fetch_image_as_base64",
]
