'''
Exceptions used in snapctl.
'''


class SnapendDownloadException(Exception):
    """Raised when a Snapend download fails or is incomplete."""
    pass
