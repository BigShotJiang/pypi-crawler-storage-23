# CLAUDE.md

## Project

swarm.at — Git-native Information Settlement Protocol for agentic workflows.

## Commands

```bash
# Tests
pytest tests/ -v --tb=short

# Lint
ruff check swarm_at/ tests/

# Type check (strict)
mypy swarm_at/ --ignore-missing-imports

# Run API (via CLI or direct)
swarm serve --reload
uvicorn swarm_at.api.main:app --reload

# Run MCP server
swarm mcp
python -m swarm_at.mcp

# CLI (install: pip install -e ".[cli]")
swarm --help
swarm settle <action> --agent <name>
swarm status
swarm ledger list [--limit 20] [--offset 0]
swarm ledger verify <hash>
swarm agents list [--role ROLE] [--trust LEVEL]
swarm agents register <agent_id> [--role worker]
swarm agents info <agent_id>
swarm blueprints list [--tag TAG]
swarm blueprints info <blueprint_id>
swarm molecules list [--agent AGENT_ID] [--limit 50]
swarm molecules get <molecule_id>
swarm authorship claim <content> --agent <name>
swarm authorship verify <content_hash> [--agent <name>]
swarm authorship list <agent_id> [--limit 50] [--offset 0]
swarm authorship sessions [--writer NAME]          # remote only
swarm authorship report <session_id> [--text]      # remote only
swarm credits balance <agent_id>                   # remote only
swarm credits topup <agent_id> <amount>            # remote only
swarm init [directory]
swarm login
swarm whoami <agent_id>
```

## Architecture

```
swarm_at/
  cli.py             # Click CLI: local/remote modes, config (~/.swarm/config.toml)
  models.py          # Pydantic models: Proposal, Header, Payload, LedgerEntry
  settle.py          # SettlementContext: stateful wrapper, local/remote mode, settle()
  settler.py         # Ledger: JSONL hash-chain, generate_hash(), GENESIS_HASH
  engine.py          # SwarmAtEngine: verify_and_settle() pipeline
  tiers.py           # SettlementTier enum (SANDBOX/STAGING/PRODUCTION), TierPolicy
  context.py         # Context Injector: keyword-filtered state slices
  dispatcher.py      # Model Arbitrage: route by complexity to tier
  auditor.py         # Shadow Auditor: cross-model divergence decorator
  consensus.py       # Consensus Engine: stake/verify/finalize rounds
  heartbeat.py       # Settlement Pulse: periodic drift detection
  agents.py          # Agent Identity: roles, trust levels, registry
  workflow.py        # Workflow Chaining: Bead → Molecule → Formula → Convoy
  gitplane.py        # Git-Native Ledger: branching/merging data plane
  openclaw.py        # Discovery generators: llms.txt, A2A card, robots.txt, JSON-LD, OpenAPI
  authorship.py      # Authorship provenance: WritingSession, session stores, Agency Spectrum L0-L5, reports
  seed_blueprints.py # Canonical blueprint seeding (48 blueprints, 9 categories)
  api/main.py        # FastAPI: settlement, agents, blueprints, authorship, discovery routes
  api/state.py       # Mutable API state: ledger, engine, agent_registry, writing_sessions
  mcp/server.py      # MCP server via FastMCP (18 tools incl. 7 authorship)
  sdk/client.py      # Python SDK: SwarmClient (no authorship — proprietary)
```

## Conventions

- **Tests**: datasette-enrichments style. Shared fixtures in `tests/conftest.py`. Factory functions (`make_proposal`, `make_settle_request`). `@pytest.mark.parametrize` with `ids=`. Assertion helpers (`assert_settled`, `assert_rejected`, `assert_escrowed`).
- **Hashes**: Always 64 chars. Use `"0" * 64` for test genesis hashes, never shorter strings.
- **API state**: Read from `swarm_at.api.state` module at call time, not import time. The autouse `_reset_api_state` fixture swaps it per test (including `blueprint_store`).
- **OpenClaw**: Pure functions in `openclaw.py` — no side effects, lazy-imported from routes. Discovery URLs come from `SWARM_API_URL`/`SWARM_SITE_URL` env vars.
- **GitLedger**: Uses subprocess for git ops. Fixtures use lazy imports to avoid import-time git operations.
- **Authorship**: `WritingSession` composes `SettlementContext` — no changes to existing modules. Never stores raw content in the ledger, only SHA-256 hashes. Phase weights are customizable via `phase_weights` dict. Tests use `tmp_path` for isolated ledger files. Design doc: `docs/plans/2026-02-14-authorship-provenance-design.md`. Reference: `docs/authorship.md`. **Proprietary**: authorship is exposed via MCP tools (5), REST API (7 endpoints, OpenAPI tag `"authorship"`), and CLI (`swarm authorship` group — claim/verify/list local, sessions/report remote-only) but deliberately omitted from the public agent card, llms.txt, and SDK. Sessions backed by `WritingSessionStore` (in-memory) or `PersistentWritingSessionStore` (JSONL via `SWARM_SESSION_PATH` env var). `to_dict()`/`from_dict()` for serialization. The ledger persists settlement hashes.
- **CLI**: Click-based (`swarm_at/cli.py`), entry point `swarm = swarm_at.cli:main`. Two modes: local (default, direct Ledger/Engine) and remote (SwarmClient over HTTP). Mode priority: `--local` flag > `--api-url` flag > `SWARM_API_URL` env > `~/.swarm/config.toml` > default local. Server-only commands (`agents`, `blueprints`, `serve`, `mcp`) guarded with install hint on ImportError. `--json` flag for machine-readable output. Config at `~/.swarm/config.toml` (0600 perms). Dep group: `cli = ["click>=8.0"]`. Tests use `CliRunner` with `invoke()`/`invoke_local()` helpers.
- **Types**: mypy strict mode. Parameterize all generics. MCP decorators need `# type: ignore[misc,untyped-decorator]`.

## Feature Parity

When adding a feature to any interface, update this table. Dashes are intentional omissions.

| Feature | API | MCP | CLI | SDK |
|---------|-----|-----|-----|-----|
| Settlement (+ batch) | Y | Y | Y | Y |
| Agents | Y | - | Y | Y |
| Blueprints | Y | - | Y | Y |
| Credits | Y | Y | Y (remote) | Y |
| Authorship claims | Y | Y | Y | - |
| Authorship sessions | Y | Y | Y (remote) | Y |
| Webhooks | Y | - | Y (remote) | Y |
| Workflows (+ molecules) | Y | - | Y | Y |
| Ledger ops | Y | Y | Y | Y |
| Discovery | Y | - | - | - |

## Related Repos

- **Public Ledger**: [Mediaeater/swarm-at-ledger](https://github.com/Mediaeater/swarm-at-ledger) — the public settlement record. When changing settlement types, ledger format, or verification endpoints here, check if the ledger repo's README needs updating too.

## Commit Style

- Imperative subject, ~50 chars
- Body explains why, not what
- No co-author tags
