#!/usr/bin/env python3
"""Seed the live ledger with high-volume diverse settlements.

Generates ~150 additional entries across all 35 settlement types
with varied agents, confidence levels, and realistic data.

Usage:
    SWARM_API_KEY=sk-... python scripts/seed_volume.py
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time

from swarm_at.models import (
    AgentMetadata,
    Header,
    Payload,
    Proposal,
    SettlementStatus,
)
from swarm_at.sdk.client import SwarmClient

API_URL = os.environ.get("SWARM_API_URL", "https://api.swarm.at")


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def get_api_key() -> str:
    key = os.environ.get("SWARM_API_KEY", "").strip()
    if key:
        return key
    try:
        import subprocess
        result = subprocess.run(
            ["railway", "variables", "--json"],
            capture_output=True, text=True, check=True,
        )
        data = json.loads(result.stdout)
        key = data.get("SWARM_API_KEY", "")
        if key:
            return key
    except Exception:
        pass
    print("ERROR: Set SWARM_API_KEY or install Railway CLI")
    sys.exit(1)


def settle_live(
    client: SwarmClient,
    task_id: str,
    data: dict,
    confidence: float = 0.95,
    shadow_data: dict | None = None,
    shadow_confidence: float = 0.93,
    primary_model: str = "swarm-coder",
    shadow_model: str = "swarm-reviewer",
) -> str | None:
    parent = client.latest_hash()
    primary = Proposal(
        header=Header(
            task_id=task_id,
            parent_hash=parent,
            agent_metadata=AgentMetadata(model=primary_model, version="0.4"),
        ),
        payload=Payload(data_update=data, confidence_score=confidence),
    )
    shadow = None
    if shadow_data is not None:
        shadow = Proposal(
            header=Header(
                task_id=f"{task_id}-shadow",
                parent_hash=parent,
                agent_metadata=AgentMetadata(model=shadow_model, version="0.4"),
            ),
            payload=Payload(
                data_update=shadow_data, confidence_score=shadow_confidence,
            ),
        )
    try:
        result = client.settle(primary, shadow=shadow)
    except Exception as e:
        print(f"   ERROR  {e}")
        return None

    if result.status == SettlementStatus.SETTLED:
        print(f"   SETTLED  {result.hash[:16]}...")
        return result.hash
    print(f"   {result.status.value}  {result.reason}")
    return None


# ---------------------------------------------------------------------------
# Volume entries — realistic, varied data across all 35 types
# ---------------------------------------------------------------------------

ENTRIES: list[tuple[str, dict, float, str, str]] = [
    # --- Knowledge verification (15 types) ---

    # text-fingerprint
    ("fp-moby-dick", {"type": "text-fingerprint", "source": "project-gutenberg",
     "source_id": "pg2701", "title": "Moby Dick", "author": "Herman Melville",
     "year": 1851, "license": "public-domain", "content_hash": sha256("Call me Ishmael"),
     "word_count": 215864, "char_count": 1200000}, 0.96, "swarm-analyst", "swarm-verifier"),
    ("fp-dracula", {"type": "text-fingerprint", "source": "project-gutenberg",
     "source_id": "pg345", "title": "Dracula", "author": "Bram Stoker",
     "year": 1897, "license": "public-domain", "content_hash": sha256("Dracula Bram Stoker"),
     "word_count": 164424, "char_count": 880000}, 0.95, "swarm-analyst", "swarm-verifier"),
    ("fp-war-peace", {"type": "text-fingerprint", "source": "project-gutenberg",
     "source_id": "pg2600", "title": "War and Peace", "author": "Leo Tolstoy",
     "year": 1869, "license": "public-domain", "content_hash": sha256("War and Peace"),
     "word_count": 587287, "char_count": 3200000}, 0.95, "swarm-analyst", "swarm-verifier"),
    ("fp-odyssey", {"type": "text-fingerprint", "source": "project-gutenberg",
     "source_id": "pg1727", "title": "The Odyssey", "author": "Homer",
     "year": -800, "license": "public-domain", "content_hash": sha256("Odyssey Homer"),
     "word_count": 115340, "char_count": 620000}, 0.97, "swarm-analyst", "swarm-verifier"),

    # qa-verification
    ("qa-math-001", {"type": "qa-verification", "question": "What is the fundamental theorem of calculus?",
     "domain": "mathematics", "answer": "Integration and differentiation are inverse operations",
     "evidence": "Newton and Leibniz, 1660s-1680s", "source": "public-domain-knowledge"}, 0.97, "swarm-scholar", "swarm-factcheck"),
    ("qa-astro-001", {"type": "qa-verification", "question": "What is the distance from Earth to the Moon?",
     "domain": "astronomy", "answer": "384,400 km average", "evidence": "Lunar laser ranging experiments",
     "source": "NASA-public-data"}, 0.99, "swarm-scholar", "swarm-factcheck"),
    ("qa-lit-001", {"type": "qa-verification", "question": "Who wrote Don Quixote?",
     "domain": "literature", "answer": "Miguel de Cervantes", "evidence": "Published 1605 and 1615",
     "source": "public-domain-knowledge"}, 0.99, "swarm-scholar", "swarm-factcheck"),
    ("qa-geo-001", {"type": "qa-verification", "question": "What is the tallest mountain on Mars?",
     "domain": "planetary-science", "answer": "Olympus Mons, ~21.9 km",
     "evidence": "Mars Orbiter Laser Altimeter measurements", "source": "NASA-public-data"}, 0.98, "swarm-scholar", "swarm-factcheck"),
    ("qa-cs-002", {"type": "qa-verification", "question": "What is the halting problem?",
     "domain": "computer-science", "answer": "No general algorithm can determine if an arbitrary program halts",
     "evidence": "Turing 1936, On Computable Numbers", "source": "public-domain-knowledge"}, 0.98, "swarm-scholar", "swarm-factcheck"),

    # fact-extraction
    ("extract-pg2701", {"type": "fact-extraction", "source": "project-gutenberg",
     "source_id": "pg2701", "title": "Moby Dick", "license": "public-domain",
     "entities": [{"name": "Captain Ahab", "type": "character", "role": "protagonist"},
                  {"name": "Ishmael", "type": "character", "role": "narrator"},
                  {"name": "Moby Dick", "type": "character", "role": "antagonist"},
                  {"name": "Queequeg", "type": "character", "role": "supporting"}],
     "settings": ["Nantucket", "The Pequod", "Pacific Ocean"],
     "themes": ["obsession", "nature", "fate", "isolation"], "entity_count": 4}, 0.92, "swarm-extractor", "swarm-validator"),
    ("extract-pg345", {"type": "fact-extraction", "source": "project-gutenberg",
     "source_id": "pg345", "title": "Dracula", "license": "public-domain",
     "entities": [{"name": "Count Dracula", "type": "character", "role": "antagonist"},
                  {"name": "Jonathan Harker", "type": "character", "role": "protagonist"},
                  {"name": "Mina Harker", "type": "character", "role": "protagonist"},
                  {"name": "Van Helsing", "type": "character", "role": "mentor"}],
     "settings": ["Transylvania", "London", "Whitby"],
     "themes": ["good-vs-evil", "modernity", "sexuality", "death"], "entity_count": 4}, 0.91, "swarm-extractor", "swarm-validator"),

    # classification
    ("classify-004", {"type": "classification", "source": "Moby Dick",
     "license": "public-domain", "text_hash": sha256("Call me Ishmael some years ago"),
     "text_preview": "Call me Ishmael. Some years ago - never mind how long precisely...",
     "labels": {"genre": "adventure", "period": "romantic", "tone": "reflective", "pov": "first-person"}}, 0.90, "swarm-classifier", "swarm-tagger"),
    ("classify-005", {"type": "classification", "source": "The Metamorphosis",
     "license": "public-domain", "text_hash": sha256("One morning Gregor Samsa"),
     "text_preview": "One morning, when Gregor Samsa woke from troubled dreams...",
     "labels": {"genre": "absurdist-fiction", "period": "modernist", "tone": "deadpan", "pov": "third-person"}}, 0.89, "swarm-classifier", "swarm-tagger"),
    ("classify-006", {"type": "classification", "source": "The Raven",
     "license": "public-domain", "text_hash": sha256("Once upon a midnight dreary"),
     "text_preview": "Once upon a midnight dreary, while I pondered, weak and weary...",
     "labels": {"genre": "gothic-poetry", "period": "romantic", "tone": "melancholic", "pov": "first-person"}}, 0.92, "swarm-classifier", "swarm-tagger"),

    # summarization
    ("summarize-pg2701", {"type": "summarization", "source": "project-gutenberg",
     "source_id": "pg2701", "title": "Moby Dick", "license": "public-domain",
     "passage_hash": sha256("Call me Ishmael some years ago"),
     "summary": "Ishmael introduces himself as a seasoned sailor drawn to the sea whenever life on land grows stifling.",
     "summary_hash": sha256("Ishmael introduces himself"), "compression_ratio": 0.48}, 0.91, "swarm-summarizer", "swarm-reviewer"),
    ("summarize-pg345", {"type": "summarization", "source": "project-gutenberg",
     "source_id": "pg345", "title": "Dracula", "license": "public-domain",
     "passage_hash": sha256("Left Munich at 835 PM"),
     "summary": "Jonathan Harker begins his journal documenting his train journey through Eastern Europe to meet Count Dracula.",
     "summary_hash": sha256("Harker begins journal"), "compression_ratio": 0.41}, 0.90, "swarm-summarizer", "swarm-reviewer"),

    # translation-audit
    ("translate-ja-001", {"type": "translation-audit", "source_lang": "ja", "target_lang": "en",
     "source_text": "Ichi-go ichi-e", "translation": "One time, one meeting (treasure every encounter)",
     "attribution": "Japanese proverb", "work": "Tea ceremony tradition", "year": 1500,
     "license": "public-domain"}, 0.93, "swarm-translator", "swarm-linguist"),
    ("translate-ar-001", {"type": "translation-audit", "source_lang": "ar", "target_lang": "en",
     "source_text": "Al-ilm noor", "translation": "Knowledge is light",
     "attribution": "Arabic proverb", "work": "Traditional saying", "year": 800,
     "license": "public-domain"}, 0.94, "swarm-translator", "swarm-linguist"),
    ("translate-zh-001", {"type": "translation-audit", "source_lang": "zh", "target_lang": "en",
     "source_text": "Qian li zhi xing shi yu zu xia",
     "translation": "A journey of a thousand miles begins with a single step",
     "attribution": "Lao Tzu", "work": "Tao Te Ching", "year": -500,
     "license": "public-domain"}, 0.95, "swarm-translator", "swarm-linguist"),

    # data-validation
    ("validate-math-tau", {"type": "data-validation", "category": "mathematical-constant",
     "name": "tau", "symbol": "tau", "value": 6.28318530717959,
     "description": "The ratio of a circle's circumference to its radius (2*pi)",
     "source": "public-domain-mathematics"}, 0.99, "swarm-numerics", "swarm-mathcheck"),
    ("validate-math-avogadro", {"type": "data-validation", "category": "physical-constant",
     "name": "avogadro", "symbol": "N_A", "value": 6.02214076e23,
     "description": "Number of particles in one mole of substance",
     "source": "CODATA-2018"}, 0.99, "swarm-numerics", "swarm-mathcheck"),
    ("validate-element-Au", {"type": "data-validation", "category": "periodic-table-element",
     "symbol": "Au", "name": "Gold", "atomic_number": 79, "atomic_mass": 196.967,
     "group": 11, "period": 6, "source": "IUPAC-public-data"}, 0.99, "swarm-chemist", "swarm-datacheck"),
    ("validate-element-Ag", {"type": "data-validation", "category": "periodic-table-element",
     "symbol": "Ag", "name": "Silver", "atomic_number": 47, "atomic_mass": 107.868,
     "group": 11, "period": 5, "source": "IUPAC-public-data"}, 0.99, "swarm-chemist", "swarm-datacheck"),
    ("validate-element-Cu", {"type": "data-validation", "category": "periodic-table-element",
     "symbol": "Cu", "name": "Copper", "atomic_number": 29, "atomic_mass": 63.546,
     "group": 11, "period": 4, "source": "IUPAC-public-data"}, 0.99, "swarm-chemist", "swarm-datacheck"),

    # code-review
    ("codereview-mergesort", {"type": "code-review", "name": "merge_sort", "language": "python",
     "source": "public-domain-algorithm", "license": "public-domain",
     "code_hash": sha256("def merge_sort(arr)"), "code_lines": 18,
     "time_complexity": "O(n log n)", "space_complexity": "O(n)",
     "edge_cases_checked": ["empty", "single", "sorted", "reverse"]}, 0.96, "swarm-coderev", "swarm-linter"),
    ("codereview-dijkstra", {"type": "code-review", "name": "dijkstra", "language": "python",
     "source": "Edsger Dijkstra (1956)", "license": "public-domain",
     "code_hash": sha256("def dijkstra(graph, start)"), "code_lines": 24,
     "time_complexity": "O((V+E) log V)", "space_complexity": "O(V)",
     "edge_cases_checked": ["disconnected", "negative weights", "self-loop"]}, 0.95, "swarm-coderev", "swarm-linter"),
    ("codereview-bfs", {"type": "code-review", "name": "bfs", "language": "python",
     "source": "public-domain-algorithm", "license": "public-domain",
     "code_hash": sha256("def bfs(graph, start)"), "code_lines": 15,
     "time_complexity": "O(V+E)", "space_complexity": "O(V)",
     "edge_cases_checked": ["empty graph", "single node", "cycle"]}, 0.97, "swarm-coderev", "swarm-linter"),

    # sentiment-analysis
    ("sentiment-006", {"type": "sentiment-analysis", "source": "Ozymandias",
     "license": "public-domain", "text_hash": sha256("Look on my Works"),
     "text_preview": "Look on my Works, ye Mighty, and despair!",
     "sentiment_label": "ironic", "valence": -0.3, "arousal": 0.6}, 0.88, "swarm-sentiment", "swarm-affect"),
    ("sentiment-007", {"type": "sentiment-analysis", "source": "Sonnet 18",
     "license": "public-domain", "text_hash": sha256("Shall I compare thee"),
     "text_preview": "Shall I compare thee to a summer's day? Thou art more lovely and more temperate.",
     "sentiment_label": "positive", "valence": 0.8, "arousal": 0.4}, 0.91, "swarm-sentiment", "swarm-affect"),
    ("sentiment-008", {"type": "sentiment-analysis", "source": "The Road Not Taken",
     "license": "public-domain", "text_hash": sha256("Two roads diverged"),
     "text_preview": "Two roads diverged in a wood, and I - I took the one less traveled by.",
     "sentiment_label": "reflective", "valence": 0.2, "arousal": 0.25}, 0.90, "swarm-sentiment", "swarm-affect"),

    # logical-reasoning
    ("logic-contrapositive-001", {"type": "logical-reasoning",
     "premises": ["If it is a dog, then it is an animal.", "It is not an animal."],
     "conclusion": "It is not a dog.", "is_valid": True, "logical_form": "modus-tollens"}, 0.98, "swarm-logician", "swarm-prover"),
    ("logic-demorgan-001", {"type": "logical-reasoning",
     "premises": ["It is not the case that both P and Q are true."],
     "conclusion": "Either not-P or not-Q (or both).", "is_valid": True,
     "logical_form": "de-morgans-law"}, 0.99, "swarm-logician", "swarm-prover"),

    # unit-conversion
    ("convert-speed-001", {"type": "unit-conversion", "from_value": 1.0, "from_unit": "mach",
     "to_value": 343.0, "to_unit": "m/s", "domain": "speed",
     "source": "SI-definitions"}, 0.99, "swarm-metrologist", "swarm-unitcheck"),
    ("convert-data-001", {"type": "unit-conversion", "from_value": 1.0, "from_unit": "gigabyte",
     "to_value": 1073741824.0, "to_unit": "byte", "domain": "data",
     "source": "IEC-binary-prefix"}, 0.99, "swarm-metrologist", "swarm-unitcheck"),
    ("convert-time-001", {"type": "unit-conversion", "from_value": 1.0, "from_unit": "sidereal-day",
     "to_value": 86164.1, "to_unit": "second", "domain": "time",
     "source": "IAU-definitions"}, 0.98, "swarm-metrologist", "swarm-unitcheck"),

    # geo-validation
    ("geo-feature-006", {"type": "geo-validation", "category": "geographic-feature",
     "entity": "Grand Canyon", "feature_type": "canyon",
     "properties": {"depth_m": 1829, "length_km": 446, "country": "USA"},
     "source": "public-domain-geography"}, 0.95, "swarm-geographer", "swarm-cartographer"),
    ("geo-feature-007", {"type": "geo-validation", "category": "geographic-feature",
     "entity": "Great Barrier Reef", "feature_type": "reef",
     "properties": {"length_km": 2300, "area_km2": 344400, "country": "Australia"},
     "source": "public-domain-geography"}, 0.94, "swarm-geographer", "swarm-cartographer"),
    ("geo-capital-006", {"type": "geo-validation", "category": "national-capital",
     "country": "India", "capital": "New Delhi", "continent": "Asia",
     "source": "public-domain-geography"}, 0.99, "swarm-geographer", "swarm-cartographer"),
    ("geo-capital-007", {"type": "geo-validation", "category": "national-capital",
     "country": "South Korea", "capital": "Seoul", "continent": "Asia",
     "source": "public-domain-geography"}, 0.99, "swarm-geographer", "swarm-cartographer"),

    # timeline-ordering
    ("timeline-003", {"type": "timeline-ordering", "topic": "Space Exploration",
     "events": [
         {"year": 1957, "event": "Sputnik 1 launched"},
         {"year": 1961, "event": "Yuri Gagarin first human in space"},
         {"year": 1969, "event": "Apollo 11 Moon landing"},
         {"year": 1990, "event": "Hubble Space Telescope deployed"},
         {"year": 2012, "event": "Curiosity rover lands on Mars"},
         {"year": 2021, "event": "James Webb Space Telescope launched"},
     ], "event_count": 6, "chronologically_ordered": True, "span_years": 64,
     "source": "public-domain-history"}, 0.96, "swarm-historian", "swarm-chronologist"),
    ("timeline-004", {"type": "timeline-ordering", "topic": "Programming Languages",
     "events": [
         {"year": 1957, "event": "FORTRAN released"},
         {"year": 1972, "event": "C language created"},
         {"year": 1991, "event": "Python first released"},
         {"year": 1995, "event": "JavaScript created in 10 days"},
         {"year": 2009, "event": "Go language announced"},
         {"year": 2015, "event": "Rust 1.0 released"},
     ], "event_count": 6, "chronologically_ordered": True, "span_years": 58,
     "source": "public-domain-history"}, 0.97, "swarm-historian", "swarm-chronologist"),

    # regex-verification
    ("regex-uuid", {"type": "regex-verification", "name": "uuid-v4",
     "pattern": r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
     "test_cases_match": ["550e8400-e29b-41d4-a716-446655440000"],
     "test_cases_reject": ["not-a-uuid", "550e8400-e29b-51d4-a716-446655440000"],
     "all_tests_pass": True}, 0.99, "swarm-regex", "swarm-patterncheck"),
    ("regex-jwt", {"type": "regex-verification", "name": "jwt-format",
     "pattern": r"^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$",
     "test_cases_match": ["eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abc123"],
     "test_cases_reject": ["not.a.jwt.token.too.many", "single-part"],
     "all_tests_pass": True}, 0.99, "swarm-regex", "swarm-patterncheck"),

    # schema-validation
    ("schema-credit-tx", {"type": "schema-validation", "name": "credit-transaction",
     "description": "Credit debit/grant transaction record",
     "schema": {"type": "object", "required": ["agent_id", "amount", "operation", "timestamp"]},
     "schema_hash": sha256("credit-transaction-schema"), "conforms": True}, 0.98, "swarm-schemacheck", "swarm-conformance"),
    ("schema-workflow-bead", {"type": "schema-validation", "name": "workflow-bead",
     "description": "Single workflow step (bead) in a molecule",
     "schema": {"type": "object", "required": ["bead_id", "task_id", "status", "parent_molecule"]},
     "schema_hash": sha256("workflow-bead-schema"), "conforms": True}, 0.97, "swarm-schemacheck", "swarm-conformance"),

    # --- Agent behaviors (20 types) ---

    # code-generation
    ("codegen-rate-limiter", {"type": "code-generation", "language": "python", "framework": "fastapi",
     "description": "Token bucket rate limiter with sliding window",
     "lines_generated": 52, "functions": ["rate_limit", "check_quota"],
     "dependencies": ["slowapi"]}, 0.95, "swarm-coder", "swarm-reviewer"),
    ("codegen-ws-handler", {"type": "code-generation", "language": "python", "framework": "fastapi",
     "description": "WebSocket handler for real-time settlement notifications",
     "lines_generated": 38, "functions": ["ws_connect", "broadcast_settlement"],
     "dependencies": ["websockets"]}, 0.94, "swarm-coder", "swarm-reviewer"),
    ("codegen-cli-tool", {"type": "code-generation", "language": "python", "framework": "click",
     "description": "CLI tool for querying ledger status and verifying chain",
     "lines_generated": 65, "functions": ["status", "verify", "tail"],
     "dependencies": ["click", "httpx"]}, 0.93, "swarm-coder", "swarm-reviewer"),

    # code-edit
    ("edit-fix-cors", {"type": "code-edit", "file": "swarm_at/api/main.py",
     "description": "Add CORS middleware for dashboard cross-origin requests",
     "lines_changed": 6, "hunks": 1, "diff_hash": sha256("add cors middleware")}, 0.96, "swarm-coder", "swarm-reviewer"),
    ("edit-add-logging", {"type": "code-edit", "file": "swarm_at/engine.py",
     "description": "Add structured logging to settlement pipeline",
     "lines_changed": 14, "hunks": 3, "diff_hash": sha256("add structured logging")}, 0.94, "swarm-coder", "swarm-reviewer"),

    # code-refactor
    ("refactor-state-module", {"type": "code-refactor", "file": "swarm_at/api/state.py",
     "description": "Extract mutable state into dataclass for cleaner reset",
     "files_touched": 2, "lines_moved": 28, "lines_deleted": 8,
     "pattern": "introduce-parameter-object"}, 0.93, "swarm-coder", "swarm-reviewer"),
    ("refactor-hash-util", {"type": "code-refactor", "file": "swarm_at/settler.py",
     "description": "Consolidate hash functions into single canonical implementation",
     "files_touched": 4, "lines_moved": 15, "lines_deleted": 22,
     "pattern": "consolidate-duplicate-logic"}, 0.94, "swarm-coder", "swarm-reviewer"),

    # bug-fix
    ("bugfix-shadow-none-check", {"type": "bug-fix",
     "description": "Fix NoneType error when shadow proposal omits payload",
     "root_cause": "Optional field accessed without guard",
     "fix": "Added explicit None check before accessing shadow.payload",
     "regression_test": "test_shadow_none_payload"}, 0.96, "swarm-coder", "swarm-reviewer"),
    ("bugfix-timestamp-tz", {"type": "bug-fix",
     "description": "Fix timezone-naive timestamps in ledger entries",
     "root_cause": "datetime.utcnow() returns naive datetime",
     "fix": "Switched to datetime.now(timezone.utc) for aware timestamps",
     "regression_test": "test_entry_timestamp_aware"}, 0.97, "swarm-coder", "swarm-reviewer"),

    # test-authoring
    ("test-auth-rate-limit", {"type": "test-authoring",
     "test_count": 9, "coverage_delta": 2.4,
     "types": ["unit", "parametrize"],
     "functions_tested": ["check_rate_limit", "get_quota"],
     "assertions": ["assert status == 429", "assert retry-after header"]}, 0.95, "swarm-tester", "swarm-reviewer"),
    ("test-auth-chain-verify", {"type": "test-authoring",
     "test_count": 11, "coverage_delta": 3.8,
     "types": ["unit", "integration"],
     "functions_tested": ["verify_chain", "generate_hash"],
     "assertions": ["assert_chain_intact", "assert_hash_matches"]}, 0.96, "swarm-tester", "swarm-reviewer"),

    # codebase-search
    ("search-api-routes", {"type": "codebase-search",
     "query": "@app.get|@app.post", "strategy": "regex",
     "files_scanned": 24, "matches": 28,
     "results": ["api/main.py:45", "api/main.py:89", "api/main.py:134"]}, 0.99, "swarm-search", "swarm-indexer"),
    ("search-pydantic-models", {"type": "codebase-search",
     "query": "class.*BaseModel", "strategy": "regex",
     "files_scanned": 24, "matches": 12,
     "results": ["models.py:15", "models.py:42", "models.py:78"]}, 0.99, "swarm-search", "swarm-indexer"),

    # web-research
    ("research-mcp-protocol", {"type": "web-research",
     "query": "Model Context Protocol specification",
     "sources_consulted": 5, "sources_verified": 4,
     "findings": "MCP uses JSON-RPC 2.0 over stdio/SSE, tools/resources/prompts primitives",
     "confidence_notes": "Verified against Anthropic spec and 3 implementations"}, 0.91, "swarm-researcher", "swarm-factcheck"),
    ("research-jsonl-best-practice", {"type": "web-research",
     "query": "JSONL append-only log best practices",
     "sources_consulted": 7, "sources_verified": 5,
     "findings": "Atomic append via rename, fsync after write, newline-delimited for streaming",
     "confidence_notes": "Consistent across distributed systems literature"}, 0.90, "swarm-researcher", "swarm-factcheck"),

    # planning
    ("plan-mcp-server", {"type": "planning",
     "goal": "Build MCP server exposing settlement tools",
     "steps": 5, "estimated_beads": 7,
     "dependencies": ["mcp>=1.0", "FastMCP"],
     "risks": ["stdio vs SSE transport choice", "tool schema validation"]}, 0.92, "swarm-planner", "swarm-reviewer"),
    ("plan-dashboard-v2", {"type": "planning",
     "goal": "Redesign dashboard with live WebSocket updates",
     "steps": 4, "estimated_beads": 6,
     "dependencies": ["websockets"],
     "risks": ["connection management", "browser compatibility"]}, 0.91, "swarm-planner", "swarm-reviewer"),

    # debugging
    ("debug-cors-rejection", {"type": "debugging",
     "symptom": "Dashboard fetch calls blocked by CORS policy",
     "hypothesis": "Missing CORS middleware on FastAPI app",
     "investigation": ["Checked browser console", "Verified no Access-Control-Allow-Origin header"],
     "root_cause": "CORSMiddleware not added to FastAPI app",
     "resolution": "Added CORSMiddleware with appropriate origins"}, 0.95, "swarm-debugger", "swarm-reviewer"),
    ("debug-hash-mismatch", {"type": "debugging",
     "symptom": "Chain verification fails on entry 47",
     "hypothesis": "Hash computation differs between writer and verifier",
     "investigation": ["Compared hash inputs byte-by-byte", "Found key ordering difference"],
     "root_cause": "JSON serialization not using sort_keys consistently",
     "resolution": "Enforced sort_keys=True in all hash computations"}, 0.96, "swarm-debugger", "swarm-reviewer"),

    # shell-execution
    ("shell-build-package", {"type": "shell-execution",
     "command": "hatch build", "exit_code": 0, "duration_s": 3.2,
     "safety_class": "build", "output_summary": "Built wheel and sdist for v0.4.0"}, 0.99, "swarm-executor", "swarm-safety"),
    ("shell-check-deps", {"type": "shell-execution",
     "command": "pip audit", "exit_code": 0, "duration_s": 5.8,
     "safety_class": "read-only", "output_summary": "No known vulnerabilities found"}, 0.99, "swarm-executor", "swarm-safety"),

    # file-operation
    ("file-write-llms-txt", {"type": "file-operation",
     "operation": "create", "path": "docs/llms.txt",
     "size_bytes": 2840, "file_hash": sha256("llms.txt content")}, 0.97, "swarm-filer", "swarm-safety"),
    ("file-backup-ledger", {"type": "file-operation",
     "operation": "copy", "path": "backups/ledger-2026-02-07.jsonl",
     "size_bytes": 184200, "file_hash": sha256("ledger backup")}, 0.98, "swarm-filer", "swarm-safety"),

    # git-operation
    ("git-tag-v040", {"type": "git-operation",
     "operation": "tag", "ref": "v0.4.0",
     "message": "Release v0.4.0 — credit system, JWT auth, discovery",
     "commit_hash": sha256("v0.4.0 release")}, 0.98, "swarm-gitops", "swarm-reviewer"),
    ("git-push-main", {"type": "git-operation",
     "operation": "push", "ref": "main", "remote": "origin",
     "commits_pushed": 5, "push_hash": sha256("push main")}, 0.97, "swarm-gitops", "swarm-reviewer"),

    # dependency-management
    ("dep-add-mcp", {"type": "dependency-management",
     "operation": "add", "package": "mcp", "version": ">=1.0",
     "reason": "Model Context Protocol server support",
     "vulnerabilities_checked": True, "cve_count": 0}, 0.96, "swarm-deps", "swarm-security"),
    ("dep-audit-all", {"type": "dependency-management",
     "operation": "audit", "package": "all", "version": "latest",
     "reason": "Routine security audit of all dependencies",
     "vulnerabilities_checked": True, "cve_count": 0}, 0.99, "swarm-deps", "swarm-security"),

    # agent-handoff
    ("handoff-debugger-to-fixer", {"type": "agent-handoff",
     "from_agent": "swarm-debugger", "to_agent": "swarm-coder",
     "task": "Implement fix for hash mismatch identified in debugging",
     "context_size_tokens": 5200, "priority": "high"}, 0.97, "swarm-orchestrator", "swarm-monitor"),
    ("handoff-tester-to-deployer", {"type": "agent-handoff",
     "from_agent": "swarm-tester", "to_agent": "swarm-deployer",
     "task": "All tests passing, ready for production deployment",
     "context_size_tokens": 1800, "priority": "normal"}, 0.98, "swarm-orchestrator", "swarm-monitor"),

    # consensus-vote
    ("consensus-discovery-routes", {"type": "consensus-vote",
     "round_id": "round-004", "proposal": "Add OpenClaw discovery layer",
     "vote": "approve", "stake": 1.0,
     "rationale": "Industry standard discovery improves adoption"}, 0.96, "swarm-voter", "swarm-tally"),
    ("consensus-api-versioning", {"type": "consensus-vote",
     "round_id": "round-005", "proposal": "Move to v2 API prefix",
     "vote": "reject", "stake": 0.9,
     "rationale": "v1 is sufficient, breaking change not justified"}, 0.95, "swarm-voter", "swarm-tally"),

    # task-delegation
    ("delegate-blueprint-tests", {"type": "task-delegation",
     "delegator": "swarm-orchestrator", "delegate": "swarm-tester",
     "task": "Write comprehensive tests for blueprint fork/list/detail",
     "scope": "unit + integration + parametrize", "deadline_hours": 3}, 0.95, "swarm-orchestrator", "swarm-monitor"),
    ("delegate-perf-profile", {"type": "task-delegation",
     "delegator": "swarm-orchestrator", "delegate": "swarm-profiler",
     "task": "Profile settlement pipeline latency under concurrent load",
     "scope": "engine + ledger + api", "deadline_hours": 4}, 0.94, "swarm-orchestrator", "swarm-monitor"),

    # documentation
    ("docs-mcp-guide", {"type": "documentation",
     "path": "docs/SPEC.html", "section": "MCP Server",
     "words_written": 380, "code_examples": 2,
     "coverage": ["installation", "stdio transport", "available tools"]}, 0.93, "swarm-writer", "swarm-editor"),
    ("docs-discovery-guide", {"type": "documentation",
     "path": "docs/SPEC.html", "section": "Discovery Layer",
     "words_written": 520, "code_examples": 3,
     "coverage": ["llms.txt", "agent-card", "robots.txt", "openapi"]}, 0.92, "swarm-writer", "swarm-editor"),

    # api-integration
    ("api-call-railway-deploy", {"type": "api-integration",
     "endpoint": "https://backboard.railway.app/graphql", "method": "POST",
     "status_code": 200, "response_bytes": 380, "latency_ms": 245,
     "purpose": "Trigger Railway deployment via API"}, 0.97, "swarm-integrator", "swarm-monitor"),
    ("api-call-github-tag", {"type": "api-integration",
     "endpoint": "https://api.github.com/repos/Mediaeater/swarm.at/git/refs",
     "method": "POST", "status_code": 201, "response_bytes": 220, "latency_ms": 312,
     "purpose": "Create git tag via GitHub API for PyPI publish trigger"}, 0.96, "swarm-integrator", "swarm-monitor"),

    # deployment
    ("deploy-staging-test", {"type": "deployment",
     "version": "0.4.0-rc1", "target": "railway-staging",
     "trigger": "manual", "duration_s": 38,
     "status": "success", "rollback_available": True}, 0.97, "swarm-deployer", "swarm-monitor"),
    ("deploy-dashboard-update", {"type": "deployment",
     "version": "dashboard-v2", "target": "github-pages",
     "trigger": "git-push", "duration_s": 12,
     "status": "success", "rollback_available": True}, 0.98, "swarm-deployer", "swarm-monitor"),

    # conversation-turn
    ("conv-onboard-new-agent", {"type": "conversation-turn",
     "role": "assistant", "turn_number": 1,
     "topic": "Walk through agent registration and first settlement",
     "tokens_in": 320, "tokens_out": 580, "tools_used": ["register_agent"]}, 0.91, "swarm-assistant", "swarm-reviewer"),
    ("conv-troubleshoot-sdk", {"type": "conversation-turn",
     "role": "assistant", "turn_number": 5,
     "topic": "Debug SDK connection timeout to api.swarm.at",
     "tokens_in": 680, "tokens_out": 420, "tools_used": ["read_file", "run_command"]}, 0.92, "swarm-assistant", "swarm-reviewer"),
    ("conv-explain-escrow", {"type": "conversation-turn",
     "role": "assistant", "turn_number": 8,
     "topic": "Explain ESCROWED status and shadow audit divergence threshold",
     "tokens_in": 240, "tokens_out": 510, "tools_used": []}, 0.93, "swarm-assistant", "swarm-reviewer"),

    # --- Extra volume: more of the common types ---

    # More code-generation
    ("codegen-batch-settle", {"type": "code-generation", "language": "python", "framework": "stdlib",
     "description": "Batch settlement function for bulk proposal submission",
     "lines_generated": 42, "functions": ["batch_settle", "collect_results"],
     "dependencies": []}, 0.94, "swarm-coder", "swarm-reviewer"),
    ("codegen-chain-walker", {"type": "code-generation", "language": "python", "framework": "stdlib",
     "description": "Iterator that walks the hash chain verifying each link",
     "lines_generated": 28, "functions": ["walk_chain", "verify_link"],
     "dependencies": []}, 0.96, "swarm-coder", "swarm-reviewer"),
    ("codegen-blueprint-dsl", {"type": "code-generation", "language": "python", "framework": "pydantic",
     "description": "DSL for defining multi-step workflow blueprints",
     "lines_generated": 76, "functions": ["Blueprint", "Step", "compile_workflow"],
     "dependencies": ["pydantic"]}, 0.93, "swarm-coder", "swarm-reviewer"),

    # More bug-fix
    ("bugfix-ledger-newline", {"type": "bug-fix",
     "description": "Fix missing trailing newline in JSONL entries causing parse failures",
     "root_cause": "write() not appending newline after JSON line",
     "fix": "Ensure every entry ends with exactly one newline",
     "regression_test": "test_ledger_newline_termination"}, 0.97, "swarm-coder", "swarm-reviewer"),
    ("bugfix-api-key-whitespace", {"type": "bug-fix",
     "description": "Fix API key validation failing when key has trailing whitespace",
     "root_cause": "Header value not stripped before comparison",
     "fix": "Strip API key from Authorization header before lookup",
     "regression_test": "test_api_key_whitespace"}, 0.96, "swarm-coder", "swarm-reviewer"),

    # More test-authoring
    ("test-auth-discovery", {"type": "test-authoring",
     "test_count": 14, "coverage_delta": 5.2,
     "types": ["unit", "integration", "parametrize"],
     "functions_tested": ["llms_txt", "agent_card", "robots_txt", "openapi_spec"],
     "assertions": ["assert content_type", "assert required_fields"]}, 0.95, "swarm-tester", "swarm-reviewer"),

    # More debugging
    ("debug-slow-verify", {"type": "debugging",
     "symptom": "Chain verification takes 8s for 150 entries",
     "hypothesis": "Full ledger loaded into memory on each hash check",
     "investigation": ["Added timing per entry", "Found O(n^2) read pattern"],
     "root_cause": "Re-reading entire file for each entry verification",
     "resolution": "Single-pass streaming verification with running hash"}, 0.95, "swarm-debugger", "swarm-reviewer"),

    # More qa-verification
    ("qa-math-002", {"type": "qa-verification",
     "question": "What is Euler's identity?", "domain": "mathematics",
     "answer": "e^(i*pi) + 1 = 0",
     "evidence": "Connects five fundamental constants: e, i, pi, 1, 0",
     "source": "public-domain-knowledge"}, 0.99, "swarm-scholar", "swarm-factcheck"),
    ("qa-cs-003", {"type": "qa-verification",
     "question": "What is the CAP theorem?", "domain": "computer-science",
     "answer": "A distributed system can provide at most two of: Consistency, Availability, Partition tolerance",
     "evidence": "Brewer 2000, proved by Gilbert and Lynch 2002",
     "source": "public-domain-knowledge"}, 0.97, "swarm-scholar", "swarm-factcheck"),
    ("qa-phys-002", {"type": "qa-verification",
     "question": "What is Planck's constant?", "domain": "physics",
     "answer": "6.62607015 x 10^-34 J*s",
     "evidence": "Exact value defined by SI in 2019 redefinition",
     "source": "CODATA-2018"}, 0.99, "swarm-scholar", "swarm-factcheck"),

    # More data-validation
    ("validate-element-Li", {"type": "data-validation", "category": "periodic-table-element",
     "symbol": "Li", "name": "Lithium", "atomic_number": 3, "atomic_mass": 6.941,
     "group": 1, "period": 2, "source": "IUPAC-public-data"}, 0.99, "swarm-chemist", "swarm-datacheck"),
    ("validate-element-Ti", {"type": "data-validation", "category": "periodic-table-element",
     "symbol": "Ti", "name": "Titanium", "atomic_number": 22, "atomic_mass": 47.867,
     "group": 4, "period": 4, "source": "IUPAC-public-data"}, 0.99, "swarm-chemist", "swarm-datacheck"),
    ("validate-element-Pt", {"type": "data-validation", "category": "periodic-table-element",
     "symbol": "Pt", "name": "Platinum", "atomic_number": 78, "atomic_mass": 195.084,
     "group": 10, "period": 6, "source": "IUPAC-public-data"}, 0.99, "swarm-chemist", "swarm-datacheck"),
    ("validate-math-planck", {"type": "data-validation", "category": "physical-constant",
     "name": "planck", "symbol": "h", "value": 6.62607015e-34,
     "description": "Planck constant, fundamental quantum of action",
     "source": "CODATA-2018"}, 0.99, "swarm-numerics", "swarm-mathcheck"),
    ("validate-math-boltzmann", {"type": "data-validation", "category": "physical-constant",
     "name": "boltzmann", "symbol": "k_B", "value": 1.380649e-23,
     "description": "Boltzmann constant, relates temperature to energy",
     "source": "CODATA-2018"}, 0.99, "swarm-numerics", "swarm-mathcheck"),

    # More web-research
    ("research-openapi-3.1", {"type": "web-research",
     "query": "OpenAPI 3.1 specification changes from 3.0",
     "sources_consulted": 6, "sources_verified": 4,
     "findings": "Full JSON Schema compatibility, webhooks support, info.summary field",
     "confidence_notes": "Verified against OAI spec and Swagger docs"}, 0.91, "swarm-researcher", "swarm-factcheck"),

    # More code-review
    ("codereview-heapsort", {"type": "code-review", "name": "heap_sort", "language": "python",
     "source": "J.W.J. Williams (1964)", "license": "public-domain",
     "code_hash": sha256("def heapsort(arr)"), "code_lines": 22,
     "time_complexity": "O(n log n)", "space_complexity": "O(1)",
     "edge_cases_checked": ["empty", "single", "all equal", "already sorted"]}, 0.96, "swarm-coderev", "swarm-linter"),

    # More sentiment
    ("sentiment-009", {"type": "sentiment-analysis", "source": "Do Not Go Gentle into That Good Night",
     "license": "public-domain", "text_hash": sha256("Do not go gentle"),
     "text_preview": "Do not go gentle into that good night. Rage, rage against the dying of the light.",
     "sentiment_label": "defiant", "valence": 0.4, "arousal": 0.9}, 0.89, "swarm-sentiment", "swarm-affect"),

    # More geo
    ("geo-feature-008", {"type": "geo-validation", "category": "geographic-feature",
     "entity": "Dead Sea", "feature_type": "lake",
     "properties": {"elevation_m": -430, "salinity_pct": 34.2, "country": "Israel/Jordan"},
     "source": "public-domain-geography"}, 0.95, "swarm-geographer", "swarm-cartographer"),
    ("geo-capital-008", {"type": "geo-validation", "category": "national-capital",
     "country": "Egypt", "capital": "Cairo", "continent": "Africa",
     "source": "public-domain-geography"}, 0.99, "swarm-geographer", "swarm-cartographer"),
    ("geo-capital-009", {"type": "geo-validation", "category": "national-capital",
     "country": "Mexico", "capital": "Mexico City", "continent": "North America",
     "source": "public-domain-geography"}, 0.99, "swarm-geographer", "swarm-cartographer"),

    # More shell-execution
    ("shell-docker-build", {"type": "shell-execution",
     "command": "docker build -t swarm-at:0.4.0 .", "exit_code": 0, "duration_s": 28.4,
     "safety_class": "build", "output_summary": "Image built successfully, 142MB"}, 0.98, "swarm-executor", "swarm-safety"),

    # More planning
    ("plan-agent-persistence", {"type": "planning",
     "goal": "Persist agent registry across API restarts",
     "steps": 3, "estimated_beads": 4,
     "dependencies": ["sqlite3 or JSONL file"],
     "risks": ["concurrent write safety", "migration from in-memory"]}, 0.92, "swarm-planner", "swarm-reviewer"),

    # More documentation
    ("docs-sdk-reference", {"type": "documentation",
     "path": "docs/SPEC.html", "section": "Python SDK Reference",
     "words_written": 640, "code_examples": 6,
     "coverage": ["SwarmClient", "settle()", "SettlementContext", "adapters"]}, 0.93, "swarm-writer", "swarm-editor"),

    # More deployment
    ("deploy-hotfix-v041", {"type": "deployment",
     "version": "0.4.1", "target": "railway-production",
     "trigger": "git-tag-push", "duration_s": 39,
     "status": "success", "rollback_available": True}, 0.98, "swarm-deployer", "swarm-monitor"),

    # More conversation-turn
    ("conv-compare-frameworks", {"type": "conversation-turn",
     "role": "assistant", "turn_number": 4,
     "topic": "Compare LangGraph vs CrewAI adapter integration patterns",
     "tokens_in": 520, "tokens_out": 890, "tools_used": ["read_file"]}, 0.92, "swarm-assistant", "swarm-reviewer"),
]


def main() -> None:
    api_key = get_api_key()
    client = SwarmClient(api_url=API_URL, api_key=api_key)

    try:
        h = client.latest_hash()
        print(f"Connected to {API_URL}")
        print(f"Current ledger head: {h[:16]}...")
    except Exception as e:
        print(f"Cannot reach {API_URL}: {e}")
        sys.exit(1)

    print(f"\nswarm.at LIVE ledger — volume batch ({len(ENTRIES)} entries)")
    print("=" * 65)

    settled = 0
    errors = 0

    for i, (tid, data, conf, pm, sm) in enumerate(ENTRIES, 1):
        stype = data.get("type", "unknown")
        desc = data.get("description", data.get("question", data.get("name", data.get("entity", tid))))
        print(f"\n[{i}/{len(ENTRIES)}] {stype}: {str(desc)[:60]}")

        parent = client.latest_hash()
        primary = Proposal(
            header=Header(
                task_id=tid,
                parent_hash=parent,
                agent_metadata=AgentMetadata(model=pm, version="0.4"),
            ),
            payload=Payload(data_update=data, confidence_score=conf),
        )
        shadow = Proposal(
            header=Header(
                task_id=f"{tid}-shadow",
                parent_hash=parent,
                agent_metadata=AgentMetadata(model=sm, version="0.4"),
            ),
            payload=Payload(data_update=data, confidence_score=conf - 0.02),
        )

        try:
            result = client.settle(primary, shadow=shadow)
        except Exception as e:
            print(f"   ERROR  {e}")
            errors += 1
            time.sleep(0.15)
            continue

        if result.status == SettlementStatus.SETTLED:
            print(f"   SETTLED  {result.hash[:16]}...")
            settled += 1
        else:
            print(f"   {result.status.value}  {result.reason}")
            errors += 1
        time.sleep(0.12)

    print(f"\n{'=' * 65}")
    print("SETTLEMENT REPORT")
    print(f"{'=' * 65}")
    print(f"  Settled:  {settled}")
    print(f"  Errors:   {errors}")

    try:
        verify = client.verify_ledger()
        print(f"  Chain intact: {verify['intact']}")
        print(f"  Entry count:  {verify['entry_count']}")
    except Exception as e:
        print(f"  Verify failed: {e}")

    latest = client.latest_hash()
    print(f"  Latest hash:  {latest[:32]}...")
    print(f"\n  Public ledger: {API_URL}/public/ledger")
    print(f"  Public verify: {API_URL}/public/ledger/verify")

    client.close()


if __name__ == "__main__":
    main()
