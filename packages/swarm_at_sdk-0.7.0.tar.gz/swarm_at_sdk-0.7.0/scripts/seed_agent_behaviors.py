#!/usr/bin/env python3
"""Seed the live ledger with agent behavior settlement types.

Adds entries for all 20 agent behavior types to complement the
15 knowledge verification types already seeded by seed_live.py.

Usage:
    SWARM_API_KEY=sk-... python scripts/seed_agent_behaviors.py
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time

from swarm_at.models import (
    AgentMetadata,
    Header,
    Payload,
    Proposal,
    SettlementStatus,
)
from swarm_at.sdk.client import SwarmClient

API_URL = os.environ.get("SWARM_API_URL", "https://api.swarm.at")


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def get_api_key() -> str:
    key = os.environ.get("SWARM_API_KEY", "").strip()
    if key:
        return key
    try:
        import subprocess
        result = subprocess.run(
            ["railway", "variables", "--json"],
            capture_output=True, text=True, check=True,
        )
        data = json.loads(result.stdout)
        key = data.get("SWARM_API_KEY", "")
        if key:
            return key
    except Exception:
        pass
    print("ERROR: Set SWARM_API_KEY or install Railway CLI")
    sys.exit(1)


def settle_live(
    client: SwarmClient,
    task_id: str,
    data: dict,
    confidence: float = 0.95,
    shadow_data: dict | None = None,
    shadow_confidence: float = 0.93,
    primary_model: str = "swarm-coder",
    shadow_model: str = "swarm-reviewer",
) -> str | None:
    parent = client.latest_hash()
    primary = Proposal(
        header=Header(
            task_id=task_id,
            parent_hash=parent,
            agent_metadata=AgentMetadata(model=primary_model, version="0.4"),
        ),
        payload=Payload(data_update=data, confidence_score=confidence),
    )
    shadow = None
    if shadow_data is not None:
        shadow = Proposal(
            header=Header(
                task_id=f"{task_id}-shadow",
                parent_hash=parent,
                agent_metadata=AgentMetadata(model=shadow_model, version="0.4"),
            ),
            payload=Payload(
                data_update=shadow_data, confidence_score=shadow_confidence,
            ),
        )
    try:
        result = client.settle(primary, shadow=shadow)
    except Exception as e:
        print(f"   ERROR  {e}")
        return None

    if result.status == SettlementStatus.SETTLED:
        print(f"   SETTLED  {result.hash[:16]}...")
        return result.hash
    print(f"   {result.status.value}  {result.reason}")
    return None


# ---------------------------------------------------------------------------
# Agent behavior data — realistic entries across all 20 types
# ---------------------------------------------------------------------------

CODE_GENERATIONS = [
    ("codegen-fastapi-healthcheck", "python", "fastapi", {
        "description": "Health check endpoint returning service status",
        "lines_generated": 12, "functions": ["healthcheck"],
        "dependencies": ["fastapi"],
    }),
    ("codegen-jwt-middleware", "python", "fastapi", {
        "description": "JWT authentication middleware for API routes",
        "lines_generated": 45, "functions": ["verify_jwt", "create_token"],
        "dependencies": ["pyjwt", "fastapi"],
    }),
    ("codegen-csv-parser", "python", "stdlib", {
        "description": "CSV parser with type inference and validation",
        "lines_generated": 38, "functions": ["parse_csv", "infer_types"],
        "dependencies": [],
    }),
    ("codegen-retry-decorator", "python", "stdlib", {
        "description": "Exponential backoff retry decorator with jitter",
        "lines_generated": 24, "functions": ["retry"],
        "dependencies": [],
    }),
]

CODE_EDITS = [
    ("edit-fix-pagination", "swarm_at/api/main.py", {
        "description": "Fix off-by-one in blueprint pagination",
        "lines_changed": 3, "hunks": 1,
        "diff_hash": sha256("fix pagination offset"),
    }),
    ("edit-add-timeout", "swarm_at/sdk/client.py", {
        "description": "Add configurable timeout to HTTP client",
        "lines_changed": 8, "hunks": 2,
        "diff_hash": sha256("add timeout parameter"),
    }),
    ("edit-update-schema", "swarm_at/models.py", {
        "description": "Add optional metadata field to Proposal model",
        "lines_changed": 5, "hunks": 1,
        "diff_hash": sha256("add metadata field"),
    }),
]

CODE_REFACTORS = [
    ("refactor-extract-auth", "swarm_at/api/main.py", {
        "description": "Extract auth logic into dedicated module",
        "files_touched": 3, "lines_moved": 62, "lines_deleted": 5,
        "pattern": "extract-method",
    }),
    ("refactor-client-retry", "swarm_at/sdk/client.py", {
        "description": "Replace manual retry loops with decorator pattern",
        "files_touched": 1, "lines_moved": 0, "lines_deleted": 18,
        "pattern": "replace-conditional-with-polymorphism",
    }),
    ("refactor-model-validation", "swarm_at/models.py", {
        "description": "Consolidate duplicate validation into base class",
        "files_touched": 2, "lines_moved": 24, "lines_deleted": 31,
        "pattern": "extract-superclass",
    }),
]

BUG_FIXES = [
    ("bugfix-hash-encoding", {
        "description": "Fix hash computation using wrong encoding for unicode payloads",
        "root_cause": "json.dumps default encoding not specified",
        "fix": "Explicit ensure_ascii=False in hash computation",
        "regression_test": "test_unicode_payload_hash",
    }),
    ("bugfix-race-ledger-append", {
        "description": "Fix race condition in concurrent ledger appends",
        "root_cause": "File append not using atomic write",
        "fix": "Write to temp file then rename",
        "regression_test": "test_concurrent_settle",
    }),
    ("bugfix-empty-shadow", {
        "description": "Fix crash when shadow proposal has empty payload",
        "root_cause": "Missing None check before divergence calculation",
        "fix": "Guard divergence check with payload existence test",
        "regression_test": "test_empty_shadow_payload",
    }),
]

TEST_AUTHORINGS = [
    ("test-auth-settlement-tiers", {
        "test_count": 12, "coverage_delta": 3.2,
        "types": ["unit", "parametrize"],
        "functions_tested": ["verify_and_settle"],
        "assertions": ["assert_settled", "assert_rejected", "assert_escrowed"],
    }),
    ("test-auth-blueprint-fork", {
        "test_count": 8, "coverage_delta": 1.8,
        "types": ["unit", "integration"],
        "functions_tested": ["fork_blueprint", "debit_credits"],
        "assertions": ["assert status == 200", "assert balance decreased"],
    }),
    ("test-auth-consensus-round", {
        "test_count": 15, "coverage_delta": 4.1,
        "types": ["unit", "parametrize"],
        "functions_tested": ["stake", "verify_stake", "finalize"],
        "assertions": ["assert_finalized", "assert quorum met"],
    }),
]

CODEBASE_SEARCHES = [
    ("search-unused-imports", {
        "query": "unused imports", "strategy": "ast-analysis",
        "files_scanned": 24, "matches": 7,
        "results": ["context.py:3", "dispatcher.py:5", "auditor.py:2"],
    }),
    ("search-todo-comments", {
        "query": "TODO|FIXME|HACK", "strategy": "regex",
        "files_scanned": 24, "matches": 11,
        "results": ["engine.py:142", "api/main.py:88", "consensus.py:67"],
    }),
    ("search-hash-usage", {
        "query": "generate_hash|sha256", "strategy": "regex",
        "files_scanned": 24, "matches": 14,
        "results": ["settler.py:18", "engine.py:45", "models.py:92"],
    }),
]

WEB_RESEARCHES = [
    ("research-llms-txt-spec", {
        "query": "llms.txt specification",
        "sources_consulted": 4, "sources_verified": 3,
        "findings": "llms.txt v1.1.0: plain text, one-line desc, endpoint list",
        "confidence_notes": "Cross-verified against 3 implementations",
    }),
    ("research-a2a-protocol", {
        "query": "Google A2A agent-to-agent protocol",
        "sources_consulted": 6, "sources_verified": 4,
        "findings": "Agent card at /.well-known/agent-card.json with skills array",
        "confidence_notes": "Verified against Google spec and 2 live implementations",
    }),
    ("research-hash-chain-patterns", {
        "query": "append-only hash chain verification patterns",
        "sources_consulted": 8, "sources_verified": 5,
        "findings": "SHA-256 chain with sorted-key JSON canonical form is standard",
        "confidence_notes": "Consistent across blockchain and audit log literature",
    }),
]

PLANNINGS = [
    ("plan-credit-system", {
        "goal": "Implement per-agent credit metering",
        "steps": 5, "estimated_beads": 8,
        "dependencies": ["agent-registry", "blueprint-store"],
        "risks": ["concurrent debit race condition", "negative balance edge case"],
    }),
    ("plan-jwt-auth", {
        "goal": "Add JWT token authentication alongside API keys",
        "steps": 4, "estimated_beads": 6,
        "dependencies": ["pyjwt"],
        "risks": ["secret rotation", "token expiry edge cases"],
    }),
    ("plan-framework-adapters", {
        "goal": "Build drop-in adapters for LangGraph, AutoGen, CrewAI, OpenAI",
        "steps": 6, "estimated_beads": 12,
        "dependencies": [],
        "risks": ["framework version pinning", "duck-type breakage"],
    }),
]

DEBUGGINGS = [
    ("debug-stale-hash", {
        "symptom": "Intermittent REJECTED settlements in production",
        "hypothesis": "Race condition between hash read and proposal submit",
        "investigation": ["Added logging to latest_hash()", "Reproduced under load"],
        "root_cause": "Two agents reading same parent_hash concurrently",
        "resolution": "Retry with fresh parent_hash on state drift rejection",
    }),
    ("debug-memory-leak", {
        "symptom": "API memory usage growing linearly over 24h",
        "hypothesis": "Ledger entries cached but never evicted",
        "investigation": ["Profiled with tracemalloc", "Identified growing list"],
        "root_cause": "verify_chain() loading full ledger into memory on each call",
        "resolution": "Stream verification, read one entry at a time",
    }),
    ("debug-timeout-blueprints", {
        "symptom": "Blueprint list endpoint timing out under load",
        "hypothesis": "N+1 query pattern loading blueprint steps",
        "investigation": ["Added timing middleware", "Traced slow queries"],
        "root_cause": "Each blueprint loading steps in a separate read",
        "resolution": "Batch load steps with single pass over store",
    }),
]

SHELL_EXECUTIONS = [
    ("shell-run-tests", {
        "command": "pytest tests/ -v --tb=short",
        "exit_code": 0, "duration_s": 11.2,
        "safety_class": "read-only",
        "output_summary": "605 passed, 0 failed",
    }),
    ("shell-lint-check", {
        "command": "ruff check swarm_at/ tests/",
        "exit_code": 0, "duration_s": 1.8,
        "safety_class": "read-only",
        "output_summary": "All checks passed",
    }),
    ("shell-type-check", {
        "command": "mypy swarm_at/ --ignore-missing-imports",
        "exit_code": 0, "duration_s": 4.3,
        "safety_class": "read-only",
        "output_summary": "Success: no issues found",
    }),
]

FILE_OPERATIONS = [
    ("file-create-config", {
        "operation": "create", "path": "swarm_at/config.py",
        "size_bytes": 1240, "file_hash": sha256("config module"),
    }),
    ("file-append-ledger", {
        "operation": "append", "path": "ledger.jsonl",
        "bytes_written": 384, "file_hash": sha256("ledger append"),
    }),
    ("file-delete-temp", {
        "operation": "delete", "path": "/tmp/swarm_staging_ledger.jsonl",
        "size_bytes": 48200, "reason": "Staging ledger cleanup",
    }),
]

GIT_OPERATIONS = [
    ("git-commit-auth-module", {
        "operation": "commit", "ref": "main",
        "message": "Add JWT authentication module",
        "files_changed": 4, "insertions": 128, "deletions": 12,
        "commit_hash": sha256("commit auth module"),
    }),
    ("git-branch-create", {
        "operation": "branch", "ref": "feature/credit-system",
        "base": "main", "base_hash": sha256("main head"),
    }),
    ("git-merge-feature", {
        "operation": "merge", "source": "feature/credit-system", "target": "main",
        "strategy": "fast-forward", "commits_merged": 3,
        "merge_hash": sha256("merge credit system"),
    }),
]

DEPENDENCY_MANAGEMENTS = [
    ("dep-add-pyjwt", {
        "operation": "add", "package": "PyJWT", "version": ">=2.8",
        "reason": "JWT token authentication",
        "vulnerabilities_checked": True, "cve_count": 0,
    }),
    ("dep-add-slowapi", {
        "operation": "add", "package": "slowapi", "version": ">=0.1.9",
        "reason": "Rate limiting for API endpoints",
        "vulnerabilities_checked": True, "cve_count": 0,
    }),
    ("dep-upgrade-pydantic", {
        "operation": "upgrade", "package": "pydantic", "from_version": "2.0", "to_version": "2.6",
        "reason": "Performance improvements and bug fixes",
        "breaking_changes": False,
    }),
]

AGENT_HANDOFFS = [
    ("handoff-research-to-writer", {
        "from_agent": "swarm-researcher", "to_agent": "swarm-writer",
        "task": "Compile research findings into documentation",
        "context_size_tokens": 4200, "priority": "normal",
    }),
    ("handoff-coder-to-reviewer", {
        "from_agent": "swarm-coder", "to_agent": "swarm-reviewer",
        "task": "Review generated authentication module",
        "context_size_tokens": 8100, "priority": "high",
    }),
    ("handoff-planner-to-executor", {
        "from_agent": "swarm-planner", "to_agent": "swarm-executor",
        "task": "Execute credit system implementation plan",
        "context_size_tokens": 3400, "priority": "normal",
    }),
]

CONSENSUS_VOTES = [
    ("consensus-schema-change", {
        "round_id": "round-001", "proposal": "Add metadata field to Proposal",
        "vote": "approve", "stake": 1.0,
        "rationale": "Backwards compatible, enables extensibility",
    }),
    ("consensus-breaking-change", {
        "round_id": "round-002", "proposal": "Change hash algorithm to SHA-3",
        "vote": "reject", "stake": 1.0,
        "rationale": "Breaking change, migration cost outweighs benefit",
    }),
    ("consensus-new-type", {
        "round_id": "round-003", "proposal": "Add conversation-turn settlement type",
        "vote": "approve", "stake": 0.8,
        "rationale": "Covers common agent interaction pattern",
    }),
]

TASK_DELEGATIONS = [
    ("delegate-test-suite", {
        "delegator": "swarm-orchestrator", "delegate": "swarm-tester",
        "task": "Write test suite for credit system",
        "scope": "unit + integration", "deadline_hours": 2,
    }),
    ("delegate-security-audit", {
        "delegator": "swarm-orchestrator", "delegate": "swarm-auditor",
        "task": "Security review of JWT implementation",
        "scope": "auth module", "deadline_hours": 4,
    }),
    ("delegate-docs-update", {
        "delegator": "swarm-orchestrator", "delegate": "swarm-writer",
        "task": "Update SPEC.html with credit system docs",
        "scope": "sections 13-14", "deadline_hours": 1,
    }),
]

DOCUMENTATIONS = [
    ("docs-api-credits", {
        "path": "docs/SPEC.html", "section": "Credit System",
        "words_written": 420, "code_examples": 3,
        "coverage": ["endpoints", "environment", "error codes"],
    }),
    ("docs-adapter-guide", {
        "path": "docs/SPEC.html", "section": "Framework Adapters",
        "words_written": 680, "code_examples": 4,
        "coverage": ["langgraph", "autogen", "crewai", "openai"],
    }),
    ("docs-quickstart", {
        "path": "mktg/tutorial_quickstart.md", "section": "Quick Start",
        "words_written": 350, "code_examples": 5,
        "coverage": ["install", "one-liner", "context", "tiers"],
    }),
]

API_INTEGRATIONS = [
    ("api-call-gutenberg", {
        "endpoint": "https://www.gutenberg.org/cache/epub/84/pg84.txt",
        "method": "GET", "status_code": 200,
        "response_bytes": 5000, "latency_ms": 342,
        "purpose": "Fetch public domain text for fingerprinting",
    }),
    ("api-call-pypi", {
        "endpoint": "https://pypi.org/pypi/swarm-at-sdk/json",
        "method": "GET", "status_code": 200,
        "response_bytes": 2800, "latency_ms": 128,
        "purpose": "Check published package metadata",
    }),
    ("api-call-ledger-verify", {
        "endpoint": "https://api.swarm.at/public/ledger/verify",
        "method": "GET", "status_code": 200,
        "response_bytes": 42, "latency_ms": 85,
        "purpose": "Verify chain integrity after settlement batch",
    }),
]

DEPLOYMENTS = [
    ("deploy-v0.3.0", {
        "version": "0.3.0", "target": "railway-production",
        "trigger": "git-tag-push", "duration_s": 45,
        "status": "success", "rollback_available": True,
    }),
    ("deploy-v0.4.0", {
        "version": "0.4.0", "target": "railway-production",
        "trigger": "git-tag-push", "duration_s": 42,
        "status": "success", "rollback_available": True,
    }),
    ("deploy-pypi-v0.4.0", {
        "version": "0.4.0", "target": "pypi",
        "trigger": "github-actions", "duration_s": 16,
        "status": "success", "package": "swarm-at-sdk",
    }),
]

CONVERSATION_TURNS = [
    ("conv-clarify-requirements", {
        "role": "assistant", "turn_number": 3,
        "topic": "Clarify credit system requirements",
        "tokens_in": 420, "tokens_out": 380,
        "tools_used": [],
    }),
    ("conv-explain-architecture", {
        "role": "assistant", "turn_number": 7,
        "topic": "Explain triage-execute-settle pattern",
        "tokens_in": 180, "tokens_out": 620,
        "tools_used": ["read_file"],
    }),
    ("conv-debug-assist", {
        "role": "assistant", "turn_number": 12,
        "topic": "Help diagnose intermittent settlement rejections",
        "tokens_in": 850, "tokens_out": 440,
        "tools_used": ["read_file", "grep", "run_tests"],
    }),
]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def main() -> None:
    api_key = get_api_key()
    client = SwarmClient(api_url=API_URL, api_key=api_key)

    try:
        h = client.latest_hash()
        print(f"Connected to {API_URL}")
        print(f"Current ledger head: {h[:16]}...")
    except Exception as e:
        print(f"Cannot reach {API_URL}: {e}")
        sys.exit(1)

    print(f"\nswarm.at LIVE ledger — 20 agent behavior types")
    print("=" * 65)

    settled = 0
    errors = 0

    def _settle(
        tid: str, data: dict, conf: float = 0.95,
        pm: str = "swarm-coder", sm: str = "swarm-reviewer",
    ) -> None:
        nonlocal settled, errors
        h = settle_live(client, tid, data, conf, data, conf - 0.02, pm, sm)
        if h:
            settled += 1
        else:
            errors += 1
        time.sleep(0.15)

    # 1. Code generation
    print("\n[1/20] CODE GENERATION")
    for tid, lang, fw, meta in CODE_GENERATIONS:
        print(f"\n   {meta['description']}")
        _settle(tid, {"type": "code-generation", "language": lang, "framework": fw, **meta})

    # 2. Code edit
    print("\n[2/20] CODE EDIT")
    for tid, path, meta in CODE_EDITS:
        print(f"\n   {meta['description']}")
        _settle(tid, {"type": "code-edit", "file": path, **meta})

    # 3. Code refactor
    print("\n[3/20] CODE REFACTOR")
    for tid, path, meta in CODE_REFACTORS:
        print(f"\n   {meta['description']}")
        _settle(tid, {"type": "code-refactor", "file": path, **meta})

    # 4. Bug fix
    print("\n[4/20] BUG FIX")
    for tid, meta in BUG_FIXES:
        print(f"\n   {meta['description']}")
        _settle(tid, {"type": "bug-fix", **meta})

    # 5. Test authoring
    print("\n[5/20] TEST AUTHORING")
    for tid, meta in TEST_AUTHORINGS:
        print(f"\n   {meta['test_count']} tests, +{meta['coverage_delta']}% coverage")
        _settle(tid, {"type": "test-authoring", **meta})

    # 6. Codebase search
    print("\n[6/20] CODEBASE SEARCH")
    for tid, meta in CODEBASE_SEARCHES:
        print(f"\n   {meta['query']} — {meta['matches']} matches")
        _settle(tid, {"type": "codebase-search", **meta}, 0.99, "swarm-search", "swarm-indexer")

    # 7. Web research
    print("\n[7/20] WEB RESEARCH")
    for tid, meta in WEB_RESEARCHES:
        print(f"\n   {meta['query']}")
        _settle(tid, {"type": "web-research", **meta}, 0.90, "swarm-researcher", "swarm-factcheck")

    # 8. Planning
    print("\n[8/20] PLANNING")
    for tid, meta in PLANNINGS:
        print(f"\n   {meta['goal']}")
        _settle(tid, {"type": "planning", **meta}, 0.92, "swarm-planner", "swarm-reviewer")

    # 9. Debugging
    print("\n[9/20] DEBUGGING")
    for tid, meta in DEBUGGINGS:
        print(f"\n   {meta['symptom']}")
        _settle(tid, {"type": "debugging", **meta}, 0.94, "swarm-debugger", "swarm-reviewer")

    # 10. Shell execution
    print("\n[10/20] SHELL EXECUTION")
    for tid, meta in SHELL_EXECUTIONS:
        print(f"\n   $ {meta['command']}")
        _settle(tid, {"type": "shell-execution", **meta}, 0.99, "swarm-executor", "swarm-safety")

    # 11. File operation
    print("\n[11/20] FILE OPERATION")
    for tid, meta in FILE_OPERATIONS:
        print(f"\n   {meta['operation']} {meta['path']}")
        _settle(tid, {"type": "file-operation", **meta}, 0.97, "swarm-filer", "swarm-safety")

    # 12. Git operation
    print("\n[12/20] GIT OPERATION")
    for tid, meta in GIT_OPERATIONS:
        print(f"\n   git {meta['operation']}")
        _settle(tid, {"type": "git-operation", **meta}, 0.98, "swarm-gitops", "swarm-reviewer")

    # 13. Dependency management
    print("\n[13/20] DEPENDENCY MANAGEMENT")
    for tid, meta in DEPENDENCY_MANAGEMENTS:
        print(f"\n   {meta['operation']} {meta['package']}")
        _settle(tid, {"type": "dependency-management", **meta}, 0.96, "swarm-deps", "swarm-security")

    # 14. Agent handoff
    print("\n[14/20] AGENT HANDOFF")
    for tid, meta in AGENT_HANDOFFS:
        print(f"\n   {meta['from_agent']} -> {meta['to_agent']}")
        _settle(tid, {"type": "agent-handoff", **meta}, 0.97, "swarm-orchestrator", "swarm-monitor")

    # 15. Consensus vote
    print("\n[15/20] CONSENSUS VOTE")
    for tid, meta in CONSENSUS_VOTES:
        print(f"\n   {meta['proposal']} [{meta['vote']}]")
        _settle(tid, {"type": "consensus-vote", **meta}, 0.96, "swarm-voter", "swarm-tally")

    # 16. Task delegation
    print("\n[16/20] TASK DELEGATION")
    for tid, meta in TASK_DELEGATIONS:
        print(f"\n   {meta['delegator']} -> {meta['delegate']}")
        _settle(tid, {"type": "task-delegation", **meta}, 0.95, "swarm-orchestrator", "swarm-monitor")

    # 17. Documentation
    print("\n[17/20] DOCUMENTATION")
    for tid, meta in DOCUMENTATIONS:
        print(f"\n   {meta['section']} — {meta['words_written']} words")
        _settle(tid, {"type": "documentation", **meta}, 0.93, "swarm-writer", "swarm-editor")

    # 18. API integration
    print("\n[18/20] API INTEGRATION")
    for tid, meta in API_INTEGRATIONS:
        print(f"\n   {meta['method']} {meta['endpoint'][:50]}...")
        _settle(tid, {"type": "api-integration", **meta}, 0.97, "swarm-integrator", "swarm-monitor")

    # 19. Deployment
    print("\n[19/20] DEPLOYMENT")
    for tid, meta in DEPLOYMENTS:
        print(f"\n   {meta['version']} -> {meta['target']}")
        _settle(tid, {"type": "deployment", **meta}, 0.98, "swarm-deployer", "swarm-monitor")

    # 20. Conversation turn
    print("\n[20/20] CONVERSATION TURN")
    for tid, meta in CONVERSATION_TURNS:
        print(f"\n   {meta['topic']}")
        _settle(tid, {"type": "conversation-turn", **meta}, 0.91, "swarm-assistant", "swarm-reviewer")

    # Final report
    print(f"\n{'=' * 65}")
    print("SETTLEMENT REPORT")
    print(f"{'=' * 65}")
    print(f"  Settled:  {settled}")
    print(f"  Errors:   {errors}")

    try:
        verify = client.verify_ledger()
        print(f"  Chain intact: {verify['intact']}")
        print(f"  Entry count:  {verify['entry_count']}")
    except Exception as e:
        print(f"  Verify failed: {e}")

    latest = client.latest_hash()
    print(f"  Latest hash:  {latest[:32]}...")
    print(f"\n  Public ledger: {API_URL}/public/ledger")
    print(f"  Public verify: {API_URL}/public/ledger/verify")

    client.close()


if __name__ == "__main__":
    main()
