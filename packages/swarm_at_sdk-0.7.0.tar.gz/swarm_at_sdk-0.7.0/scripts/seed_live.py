#!/usr/bin/env python3
"""Seed the live api.swarm.at ledger with public domain settlements.

Uses the SwarmClient SDK to submit all 15 settlement types against
the production API. Reads API key from SWARM_API_KEY env var or
fetches it from Railway.

Usage:
    python scripts/seed_live.py
    SWARM_API_KEY=sk-... python scripts/seed_live.py
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import time
import urllib.request

from swarm_at.models import (
    AgentMetadata,
    Header,
    Payload,
    Proposal,
    SettlementStatus,
)
from swarm_at.sdk.client import SwarmClient

API_URL = os.environ.get("SWARM_API_URL", "https://api.swarm.at")


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def get_api_key() -> str:
    """Get API key from env, or from Railway CLI."""
    key = os.environ.get("SWARM_API_KEY", "").strip()
    if key:
        return key
    try:
        import subprocess
        result = subprocess.run(
            ["railway", "variables", "--json"],
            capture_output=True, text=True, check=True,
        )
        data = json.loads(result.stdout)
        key = data.get("SWARM_API_KEY", "")
        if key:
            return key
    except Exception:
        pass
    print("ERROR: Set SWARM_API_KEY or install Railway CLI")
    sys.exit(1)


def settle_live(
    client: SwarmClient,
    task_id: str,
    data: dict,
    confidence: float = 0.95,
    shadow_data: dict | None = None,
    shadow_confidence: float = 0.93,
    primary_model: str = "swarm-analyst",
    shadow_model: str = "swarm-verifier",
) -> str | None:
    """Submit a settlement to the live API. Returns hash or None."""
    parent = client.latest_hash()
    primary = Proposal(
        header=Header(
            task_id=task_id,
            parent_hash=parent,
            agent_metadata=AgentMetadata(model=primary_model, version="0.1"),
        ),
        payload=Payload(data_update=data, confidence_score=confidence),
    )
    shadow = None
    if shadow_data is not None:
        shadow = Proposal(
            header=Header(
                task_id=f"{task_id}-shadow",
                parent_hash=parent,
                agent_metadata=AgentMetadata(model=shadow_model, version="0.1"),
            ),
            payload=Payload(
                data_update=shadow_data, confidence_score=shadow_confidence,
            ),
        )
    try:
        result = client.settle(primary, shadow=shadow)
    except Exception as e:
        print(f"   ERROR  {e}")
        return None

    if result.status == SettlementStatus.SETTLED:
        print(f"   SETTLED  {result.hash[:16]}...")
        return result.hash
    print(f"   {result.status.value}  {result.reason}")
    return None


# ---------------------------------------------------------------------------
# Settlement data (same as seed_ledger.py but condensed for live run)
# ---------------------------------------------------------------------------

def fetch_gutenberg(url: str, max_chars: int = 5000) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "swarm.at/0.1"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        raw = resp.read().decode("utf-8-sig", errors="replace")
    idx = raw.find("*** START")
    if idx != -1:
        raw = raw[idx + raw[idx:].find("\n") + 1:]
    end = raw.find("*** END")
    if end != -1:
        raw = raw[:end]
    return raw[:max_chars].strip()


GUTENBERG = [
    ("pg84", "Frankenstein", "Mary Shelley", 1818, "https://www.gutenberg.org/cache/epub/84/pg84.txt"),
    ("pg1342", "Pride and Prejudice", "Jane Austen", 1813, "https://www.gutenberg.org/cache/epub/1342/pg1342.txt"),
    ("pg11", "Alice's Adventures in Wonderland", "Lewis Carroll", 1865, "https://www.gutenberg.org/cache/epub/11/pg11.txt"),
    ("pg1661", "The Adventures of Sherlock Holmes", "Arthur Conan Doyle", 1892, "https://www.gutenberg.org/cache/epub/1661/pg1661.txt"),
    ("pg98", "A Tale of Two Cities", "Charles Dickens", 1859, "https://www.gutenberg.org/cache/epub/98/pg98.txt"),
]

QA_PAIRS = [
    ("chemistry", "What is the chemical formula for water?", "H2O", "Water molecule: two hydrogen atoms and one oxygen atom."),
    ("history", "In what year did the French Revolution begin?", "1789", "Storming of the Bastille, July 14, 1789."),
    ("physics", "What is the speed of light in a vacuum?", "299,792,458 m/s", "Defined constant in the International System of Units."),
    ("philosophy", "Who wrote 'The Republic'?", "Plato", "Written circa 375 BC as a Socratic dialogue on justice."),
    ("biology", "What is the largest organ in the human body?", "Skin", "Covers approximately 1.5-2 square meters in adults."),
    ("computer-science", "What is the Big O complexity of binary search?", "O(log n)", "Each comparison halves the remaining search space."),
    ("chemistry", "What is the atomic number of carbon?", "6", "Carbon has 6 protons in its nucleus."),
    ("physics", "Who formulated the three laws of motion?", "Isaac Newton", "Published in Principia Mathematica, 1687."),
]

EXTRACTIONS = [
    ("pg84", "Frankenstein",
     [{"name": "Victor Frankenstein", "type": "character", "role": "protagonist"},
      {"name": "The Creature", "type": "character", "role": "antagonist"},
      {"name": "Elizabeth Lavenza", "type": "character", "role": "love-interest"},
      {"name": "Robert Walton", "type": "character", "role": "narrator"}],
     ["Geneva", "Ingolstadt", "Arctic"], ["creation", "ambition", "isolation", "responsibility"]),
    ("pg1342", "Pride and Prejudice",
     [{"name": "Elizabeth Bennet", "type": "character", "role": "protagonist"},
      {"name": "Mr. Darcy", "type": "character", "role": "love-interest"},
      {"name": "Mr. Bennet", "type": "character", "role": "supporting"},
      {"name": "Mr. Wickham", "type": "character", "role": "antagonist"}],
     ["Hertfordshire", "Pemberley", "London"], ["pride", "prejudice", "class", "marriage"]),
    ("pg11", "Alice's Adventures in Wonderland",
     [{"name": "Alice", "type": "character", "role": "protagonist"},
      {"name": "Queen of Hearts", "type": "character", "role": "antagonist"},
      {"name": "Cheshire Cat", "type": "character", "role": "guide"},
      {"name": "Mad Hatter", "type": "character", "role": "supporting"}],
     ["Wonderland", "garden", "courtroom"], ["identity", "absurdity", "growing-up", "logic"]),
    ("pg1661", "The Adventures of Sherlock Holmes",
     [{"name": "Sherlock Holmes", "type": "character", "role": "protagonist"},
      {"name": "Dr. John Watson", "type": "character", "role": "narrator"},
      {"name": "Irene Adler", "type": "character", "role": "notable"},
      {"name": "Inspector Lestrade", "type": "character", "role": "supporting"}],
     ["221B Baker Street", "London"], ["deduction", "justice", "observation", "mystery"]),
]

CLASSIFICATIONS = [
    ("It was the best of times, it was the worst of times", "A Tale of Two Cities",
     {"genre": "historical-fiction", "period": "victorian", "tone": "dramatic", "pov": "third-person"}),
    ("Call me Ishmael. Some years ago, never mind how long precisely", "Moby Dick",
     {"genre": "adventure", "period": "romantic", "tone": "reflective", "pov": "first-person"}),
    ("All happy families are alike; each unhappy family is unhappy in its own way", "Anna Karenina",
     {"genre": "realist-fiction", "period": "romantic", "tone": "philosophical", "pov": "third-person"}),
    ("It is a truth universally acknowledged, that a single man in possession of a good fortune", "Pride and Prejudice",
     {"genre": "romance", "period": "regency", "tone": "satirical", "pov": "third-person"}),
    ("In the beginning God created the heaven and the earth", "King James Bible, Genesis",
     {"genre": "religious-text", "period": "ancient", "tone": "declarative", "pov": "third-person"}),
    ("To be, or not to be, that is the question", "Hamlet",
     {"genre": "tragedy", "period": "elizabethan", "tone": "contemplative", "pov": "first-person"}),
]

SUMMARIES = [
    ("pg84", "Frankenstein",
     "I am by birth a Genevese, and my family is one of the most distinguished of that republic.",
     "Victor Frankenstein introduces himself as a member of a prominent Geneva family.", 0.45),
    ("pg11", "Alice's Adventures in Wonderland",
     "Alice was beginning to get very tired of sitting by her sister on the bank.",
     "Alice grows bored sitting idle beside her sister on a riverbank.", 0.50),
    ("pg1661", "The Adventures of Sherlock Holmes",
     "To Sherlock Holmes she is always the woman. I have seldom heard him mention her under any other name.",
     "Watson notes Holmes uniquely refers to Irene Adler simply as 'the woman.'", 0.52),
    ("pg98", "A Tale of Two Cities",
     "It was the best of times, it was the worst of times, it was the age of wisdom.",
     "Dickens opens with contrasting descriptions of the era's contradictions.", 0.42),
]

TRANSLATIONS = [
    ("la", "en", "Cogito, ergo sum.", "I think, therefore I am.", "Rene Descartes", "Discourse on the Method", 1637),
    ("la", "en", "Veni, vidi, vici.", "I came, I saw, I conquered.", "Julius Caesar", "Letter to the Roman Senate", -47),
    ("grc", "en", "Gnothi seauton.", "Know thyself.", "Inscription at Delphi", "Temple of Apollo", -600),
    ("fr", "en", "L'etat, c'est moi.", "I am the state.", "Louis XIV", "Attributed statement", 1655),
    ("de", "en", "Ich bin ein Berliner.", "I am a Berliner.", "John F. Kennedy", "Berlin speech", 1963),
]

MATH_CONSTANTS = [
    ("pi", "pi", 3.14159265358979, "Ratio of circumference to diameter"),
    ("e", "e", 2.71828182845905, "Base of the natural logarithm"),
    ("golden_ratio", "phi", 1.61803398874989, "The golden ratio"),
    ("sqrt2", "sqrt(2)", 1.41421356237310, "Square root of 2"),
]

ELEMENTS = [
    ("H", "Hydrogen", 1, 1.008, 1, 1), ("He", "Helium", 2, 4.003, 18, 1),
    ("C", "Carbon", 6, 12.011, 14, 2), ("N", "Nitrogen", 7, 14.007, 15, 2),
    ("O", "Oxygen", 8, 15.999, 16, 2), ("Fe", "Iron", 26, 55.845, 8, 4),
]

CODE_SNIPPETS = [
    ("binary_search", "python", "public-domain-algorithm",
     "def binary_search(arr, target):\n    lo, hi = 0, len(arr) - 1\n    while lo <= hi:\n        mid = (lo + hi) // 2\n        if arr[mid] == target: return mid\n        elif arr[mid] < target: lo = mid + 1\n        else: hi = mid - 1\n    return -1",
     "O(log n)", "O(1)", ["empty array", "single element", "target not found", "duplicates"]),
    ("fizzbuzz", "python", "public-domain-algorithm",
     "def fizzbuzz(n):\n    for i in range(1, n+1):\n        if i % 15 == 0: print('FizzBuzz')\n        elif i % 3 == 0: print('Fizz')\n        elif i % 5 == 0: print('Buzz')\n        else: print(i)",
     "O(n)", "O(1)", ["n=0", "n=1", "n=15"]),
    ("euclidean_gcd", "python", "Euclid's Elements (~300 BC)",
     "def gcd(a, b):\n    while b:\n        a, b = b, a % b\n    return a",
     "O(log(min(a,b)))", "O(1)", ["a=0", "b=0", "a==b", "coprime"]),
    ("sieve_of_eratosthenes", "python", "Eratosthenes (~240 BC)",
     "def sieve(n):\n    is_prime = [True]*(n+1)\n    is_prime[0]=is_prime[1]=False\n    for i in range(2,int(n**0.5)+1):\n        if is_prime[i]:\n            for j in range(i*i,n+1,i): is_prime[j]=False\n    return [i for i in range(n+1) if is_prime[i]]",
     "O(n log log n)", "O(n)", ["n=0", "n=1", "n=2", "large n"]),
    ("quicksort", "python", "Tony Hoare (1959)",
     "def quicksort(arr):\n    if len(arr)<=1: return arr\n    pivot=arr[len(arr)//2]\n    left=[x for x in arr if x<pivot]\n    mid=[x for x in arr if x==pivot]\n    right=[x for x in arr if x>pivot]\n    return quicksort(left)+mid+quicksort(right)",
     "O(n log n) avg", "O(n)", ["empty", "sorted", "reverse sorted", "all duplicates"]),
]

SENTIMENTS = [
    ("Happy families are all alike; every unhappy family is unhappy in its own way.",
     "Anna Karenina", "mixed", -0.15, 0.3),
    ("It is a far, far better thing that I do, than I have ever done.",
     "A Tale of Two Cities", "positive", 0.7, 0.6),
    ("The horror! The horror!", "Heart of Darkness", "negative", -0.9, 0.95),
    ("So we beat on, boats against the current, borne back ceaselessly into the past.",
     "The Great Gatsby", "melancholic", -0.4, 0.35),
    ("I have spread my dreams under your feet; Tread softly because you tread on my dreams.",
     "W.B. Yeats", "tender", 0.3, 0.5),
    ("Now is the winter of our discontent made glorious summer by this sun of York.",
     "Richard III", "triumphant", 0.6, 0.7),
]

LOGIC = [
    (["All men are mortal.", "Socrates is a man."], "Socrates is mortal.", True, "barbara-syllogism"),
    (["If it rains, the ground is wet.", "It is raining."], "The ground is wet.", True, "modus-ponens"),
    (["If it rains, the ground is wet.", "The ground is wet."], "It is raining.", False, "affirming-the-consequent"),
    (["No reptiles have fur.", "All snakes are reptiles."], "No snakes have fur.", True, "celarent-syllogism"),
    (["If P then Q.", "If Q then R."], "If P then R.", True, "hypothetical-syllogism"),
    (["Either it is day or it is night.", "It is not day."], "It is night.", True, "disjunctive-syllogism"),
    (["All birds can fly.", "Penguins are birds."], "Penguins can fly.", False, "unsound-barbara"),
]

CONVERSIONS = [
    (1.0, "mile", 1.60934, "kilometer", "length"),
    (1.0, "kilogram", 2.20462, "pound", "mass"),
    (0.0, "celsius", 32.0, "fahrenheit", "temperature"),
    (100.0, "celsius", 373.15, "kelvin", "temperature"),
    (1.0, "atmosphere", 101325.0, "pascal", "pressure"),
    (1.0, "light-year", 9.461e15, "meter", "distance"),
    (1.0, "electron-volt", 1.602e-19, "joule", "energy"),
    (1.0, "astronomical-unit", 1.496e11, "meter", "distance"),
]

GEO_FEATURES = [
    ("Mount Everest", "peak", {"elevation_m": 8849, "lat": 27.9881, "lon": 86.9250, "country": "Nepal/China"}),
    ("Mariana Trench", "trench", {"depth_m": 10994, "lat": 11.3493, "lon": 142.1996, "ocean": "Pacific"}),
    ("Nile River", "river", {"length_km": 6650, "continent": "Africa"}),
    ("Sahara Desert", "desert", {"area_km2": 9200000, "continent": "Africa"}),
    ("Lake Baikal", "lake", {"depth_m": 1642, "volume_km3": 23615, "country": "Russia"}),
    ("Amazon River", "river", {"length_km": 6400, "continent": "South America", "discharge_m3s": 209000}),
]

CAPITALS = [
    ("Japan", "Tokyo", "Asia"), ("Brazil", "Brasilia", "South America"),
    ("Australia", "Canberra", "Oceania"), ("Kenya", "Nairobi", "Africa"),
    ("Canada", "Ottawa", "North America"), ("Germany", "Berlin", "Europe"),
]

TIMELINES = [
    ("Scientific Revolutions", [
        {"year": 1543, "event": "Copernicus publishes De Revolutionibus"},
        {"year": 1609, "event": "Galileo uses telescope for astronomy"},
        {"year": 1687, "event": "Newton publishes Principia Mathematica"},
        {"year": 1859, "event": "Darwin publishes On the Origin of Species"},
        {"year": 1905, "event": "Einstein publishes special relativity"},
        {"year": 1953, "event": "Watson and Crick describe DNA structure"},
    ]),
    ("Computing Milestones", [
        {"year": 1837, "event": "Babbage designs the Analytical Engine"},
        {"year": 1936, "event": "Turing publishes On Computable Numbers"},
        {"year": 1945, "event": "ENIAC becomes operational"},
        {"year": 1969, "event": "ARPANET first message sent"},
        {"year": 1991, "event": "World Wide Web goes public"},
        {"year": 2007, "event": "iPhone launches the smartphone era"},
    ]),
    ("Ancient Civilizations", [
        {"year": -3100, "event": "Egyptian First Dynasty established"},
        {"year": -2560, "event": "Great Pyramid of Giza completed"},
        {"year": -776, "event": "First recorded Olympic Games"},
        {"year": -509, "event": "Roman Republic founded"},
        {"year": -221, "event": "Qin Shi Huang unifies China"},
        {"year": -44, "event": "Assassination of Julius Caesar"},
    ]),
]

REGEX_TESTS = [
    ("email-basic", r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
     ["user@example.com", "test+tag@domain.co.uk", "a@b.io"],
     ["@missing.com", "no-at-sign", "user@", "user@.com"]),
    ("ipv4-address", r"^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$",
     ["192.168.1.1", "0.0.0.0", "255.255.255.255"],
     ["256.1.1.1", "1.2.3", "abc.def.ghi.jkl"]),
    ("iso-date", r"^\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])$",
     ["2024-01-15", "1999-12-31", "2000-06-01"],
     ["2024-13-01", "2024-00-15", "24-01-15"]),
    ("hex-color", r"^#(?:[0-9a-fA-F]{3}){1,2}$",
     ["#fff", "#000000", "#A1B2C3"],
     ["#gg0000", "000000", "#12345"]),
    ("semantic-version", r"^(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)(?:-[\da-zA-Z-]+)?$",
     ["1.0.0", "0.1.0", "12.34.56", "1.0.0-alpha"],
     ["1.0", "v1.0.0", "1.02.3"]),
]

SCHEMAS = [
    ("settlement-proposal", "swarm.at proposal schema",
     {"type": "object", "required": ["header", "payload"]}, True),
    ("ledger-entry", "Ledger entry with hash-chain fields",
     {"type": "object", "required": ["timestamp", "task_id", "parent_hash", "payload", "current_hash"]}, True),
    ("agent-identity", "Agent identity registration payload",
     {"type": "object", "required": ["agent_id", "role", "trust_level"]}, True),
    ("consensus-round", "Consensus round structure",
     {"type": "object", "required": ["round_id", "task_id", "stakes", "status"]}, True),
]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def main() -> None:
    api_key = get_api_key()
    client = SwarmClient(api_url=API_URL, api_key=api_key)

    # Quick connectivity check
    try:
        h = client.latest_hash()
        print(f"Connected to {API_URL}")
        print(f"Current ledger head: {h[:16]}...")
    except Exception as e:
        print(f"Cannot reach {API_URL}: {e}")
        sys.exit(1)

    print(f"\nswarm.at LIVE ledger seeding — 15 settlement types")
    print("=" * 65)

    settled = 0
    errors = 0

    def _settle(tid, data, conf=0.95, sconf=0.93, pm="swarm-analyst", sm="swarm-verifier"):
        nonlocal settled, errors
        h = settle_live(client, tid, data, conf, data, sconf, pm, sm)
        if h:
            settled += 1
        else:
            errors += 1
        # Small delay to avoid hammering
        time.sleep(0.1)

    # 1. Text fingerprints
    print("\n[1/15] TEXT FINGERPRINT")
    for gid, title, author, year, url in GUTENBERG:
        print(f"\n   {title}")
        try:
            text = fetch_gutenberg(url)
        except Exception as e:
            print(f"   SKIP: {e}"); errors += 1; continue
        _settle(f"fingerprint-{gid}", {
            "type": "text-fingerprint", "source": "project-gutenberg", "source_id": gid,
            "title": title, "author": author, "year": year, "license": "public-domain",
            "content_hash": sha256(text), "word_count": len(text.split()), "char_count": len(text),
        }, pm="swarm-analyst", sm="swarm-verifier")

    # 2. Q&A
    print("\n[2/15] Q&A VERIFICATION")
    for i, (domain, q, a, ev) in enumerate(QA_PAIRS):
        print(f"\n   Q: {q}")
        _settle(f"qa-{domain}-{i:03d}", {
            "type": "qa-verification", "question": q, "domain": domain, "answer": a,
            "evidence": ev, "source": "public-domain-knowledge", "license": "facts-not-copyrightable",
        }, 0.97, 0.96, "swarm-scholar", "swarm-factcheck")

    # 3. Fact extraction
    print("\n[3/15] FACT EXTRACTION")
    for sid, title, entities, settings, themes in EXTRACTIONS:
        print(f"\n   {title} — {len(entities)} entities")
        _settle(f"extract-{sid}", {
            "type": "fact-extraction", "source": "project-gutenberg", "source_id": sid,
            "title": title, "license": "public-domain", "entities": entities,
            "settings": settings, "themes": themes, "entity_count": len(entities),
        }, 0.92, 0.91, "swarm-extractor", "swarm-validator")

    # 4. Classification
    print("\n[4/15] CLASSIFICATION")
    for i, (text, source, labels) in enumerate(CLASSIFICATIONS):
        print(f"\n   \"{text[:50]}...\"")
        _settle(f"classify-{i:03d}", {
            "type": "classification", "source": source, "license": "public-domain",
            "text_hash": sha256(text), "text_preview": text[:100], "labels": labels,
        }, 0.90, 0.89, "swarm-classifier", "swarm-tagger")

    # 5. Summarization
    print("\n[5/15] SUMMARIZATION")
    for sid, title, passage, summary, ratio in SUMMARIES:
        print(f"\n   {title}")
        _settle(f"summarize-{sid}", {
            "type": "summarization", "source": "project-gutenberg", "source_id": sid,
            "title": title, "license": "public-domain", "passage_hash": sha256(passage),
            "summary": summary, "summary_hash": sha256(summary), "compression_ratio": ratio,
        }, 0.91, 0.90, "swarm-summarizer", "swarm-reviewer")

    # 6. Translation
    print("\n[6/15] TRANSLATION AUDIT")
    for i, (sl, tl, st, tr, auth, work, yr) in enumerate(TRANSLATIONS):
        print(f"\n   [{sl}] \"{st}\" -> [{tl}] \"{tr}\"")
        _settle(f"translate-{sl}-{i:03d}", {
            "type": "translation-audit", "source_lang": sl, "target_lang": tl,
            "source_text": st, "translation": tr, "attribution": auth,
            "work": work, "year": yr, "license": "public-domain",
        }, 0.94, 0.93, "swarm-translator", "swarm-linguist")

    # 7. Data validation — math
    print("\n[7/15] DATA VALIDATION")
    for name, sym, val, desc in MATH_CONSTANTS:
        print(f"\n   {sym} = {val}")
        _settle(f"validate-math-{name}", {
            "type": "data-validation", "category": "mathematical-constant",
            "name": name, "symbol": sym, "value": val, "description": desc,
            "source": "public-domain-mathematics", "license": "facts-not-copyrightable",
        }, 0.99, 0.99, "swarm-numerics", "swarm-mathcheck")

    for sym, name, num, mass, grp, per in ELEMENTS:
        print(f"\n   {sym} ({name}) Z={num}")
        _settle(f"validate-element-{sym}", {
            "type": "data-validation", "category": "periodic-table-element",
            "symbol": sym, "name": name, "atomic_number": num, "atomic_mass": mass,
            "group": grp, "period": per, "source": "IUPAC-public-data",
            "license": "facts-not-copyrightable",
        }, 0.99, 0.99, "swarm-chemist", "swarm-datacheck")

    # 8. Code review
    print("\n[8/15] CODE REVIEW")
    for name, lang, src, code, tc, sc, edges in CODE_SNIPPETS:
        print(f"\n   {name} ({lang}) — {tc}")
        _settle(f"codereview-{name}", {
            "type": "code-review", "name": name, "language": lang, "source": src,
            "license": "public-domain", "code_hash": sha256(code),
            "code_lines": code.count("\n") + 1, "time_complexity": tc,
            "space_complexity": sc, "edge_cases_checked": edges,
        }, 0.96, 0.95, "swarm-coderev", "swarm-linter")

    # 9. Sentiment
    print("\n[9/15] SENTIMENT ANALYSIS")
    for i, (text, src, sent, val, aro) in enumerate(SENTIMENTS):
        print(f"\n   \"{text[:50]}...\" -> {sent}")
        _settle(f"sentiment-{i:03d}", {
            "type": "sentiment-analysis", "source": src, "license": "public-domain",
            "text_hash": sha256(text), "text_preview": text[:120],
            "sentiment_label": sent, "valence": val, "arousal": aro,
        }, 0.89, 0.88, "swarm-sentiment", "swarm-affect")

    # 10. Logic
    print("\n[10/15] LOGICAL REASONING")
    for i, (premises, conclusion, valid, form) in enumerate(LOGIC):
        v = "VALID" if valid else "INVALID"
        print(f"\n   {form} [{v}]")
        _settle(f"logic-{form}-{i:03d}", {
            "type": "logical-reasoning", "premises": premises, "conclusion": conclusion,
            "is_valid": valid, "logical_form": form, "license": "facts-not-copyrightable",
        }, 0.98, 0.97, "swarm-logician", "swarm-prover")

    # 11. Unit conversion
    print("\n[11/15] UNIT CONVERSION")
    for i, (fv, fu, tv, tu, dom) in enumerate(CONVERSIONS):
        print(f"\n   {fv} {fu} = {tv} {tu}")
        _settle(f"convert-{dom}-{i:03d}", {
            "type": "unit-conversion", "from_value": fv, "from_unit": fu,
            "to_value": tv, "to_unit": tu, "domain": dom,
            "source": "SI-BIPM-definitions", "license": "facts-not-copyrightable",
        }, 0.99, 0.99, "swarm-metrologist", "swarm-unitcheck")

    # 12. Geo
    print("\n[12/15] GEO VALIDATION")
    for i, (entity, ftype, props) in enumerate(GEO_FEATURES):
        print(f"\n   {entity} ({ftype})")
        _settle(f"geo-feature-{i:03d}", {
            "type": "geo-validation", "category": "geographic-feature",
            "entity": entity, "feature_type": ftype, "properties": props,
            "source": "public-domain-geography", "license": "facts-not-copyrightable",
        }, 0.95, 0.94, "swarm-geographer", "swarm-cartographer")

    for i, (country, capital, continent) in enumerate(CAPITALS):
        print(f"\n   {country} -> {capital}")
        _settle(f"geo-capital-{i:03d}", {
            "type": "geo-validation", "category": "national-capital",
            "country": country, "capital": capital, "continent": continent,
            "source": "public-domain-geography", "license": "facts-not-copyrightable",
        }, 0.99, 0.99, "swarm-geographer", "swarm-cartographer")

    # 13. Timelines
    print("\n[13/15] TIMELINE ORDERING")
    for i, (topic, events) in enumerate(TIMELINES):
        print(f"\n   {topic} — {len(events)} events")
        years = [e["year"] for e in events]
        _settle(f"timeline-{i:03d}", {
            "type": "timeline-ordering", "topic": topic, "events": events,
            "event_count": len(events), "chronologically_ordered": True,
            "span_years": years[-1] - years[0],
            "source": "public-domain-history", "license": "facts-not-copyrightable",
        }, 0.96, 0.95, "swarm-historian", "swarm-chronologist")

    # 14. Regex
    print("\n[14/15] REGEX VERIFICATION")
    for name, pattern, matches, rejects in REGEX_TESTS:
        compiled = re.compile(pattern)
        all_pass = (all(compiled.match(s) for s in matches) and
                    all(not compiled.match(s) for s in rejects))
        print(f"\n   {name}: {'PASS' if all_pass else 'FAIL'}")
        _settle(f"regex-{name}", {
            "type": "regex-verification", "name": name, "pattern": pattern,
            "pattern_hash": sha256(pattern), "test_cases_match": matches,
            "test_cases_reject": rejects, "all_tests_pass": all_pass,
            "license": "public-domain",
        }, 0.99, 0.99, "swarm-regex", "swarm-patterncheck")

    # 15. Schema validation
    print("\n[15/15] SCHEMA VALIDATION")
    for name, desc, schema, conforms in SCHEMAS:
        print(f"\n   {name}")
        _settle(f"schema-{name}", {
            "type": "schema-validation", "name": name, "description": desc,
            "schema": schema, "schema_hash": sha256(json.dumps(schema, sort_keys=True)),
            "conforms": conforms, "license": "public-domain",
        }, 0.98, 0.97, "swarm-schemacheck", "swarm-conformance")

    # Final report
    print(f"\n{'=' * 65}")
    print(f"LIVE SETTLEMENT REPORT")
    print(f"{'=' * 65}")
    print(f"  Settled:  {settled}")
    print(f"  Errors:   {errors}")

    # Verify via public endpoints
    try:
        verify = client.verify_ledger()
        print(f"  Chain intact: {verify['intact']}")
        print(f"  Entry count:  {verify['entry_count']}")
    except Exception as e:
        print(f"  Verify failed: {e}")

    latest = client.latest_hash()
    print(f"  Latest hash:  {latest[:32]}...")
    print(f"\n  Public ledger: {API_URL}/public/ledger")
    print(f"  Public verify: {API_URL}/public/ledger/verify")

    client.close()


if __name__ == "__main__":
    main()
