# Next Steps

Prioritized work items for swarm.at. Updated 2026-02-27, version 0.6.2.

## Critical — DONE

### 1. Workflow State API + CLI (DONE)
The fork/execute flow is opaque. After forking a blueprint, there's no way to inspect molecule state.

- `GET /v1/molecules/{id}` — query molecule, bead list, execution status
- `GET /v1/molecules` — list agent's molecules
- `swarm molecules list`, `swarm molecules get <id>`
- SDK: `get_molecule()`, `list_molecules()`
- Files: `api/main.py`, `cli.py`, `sdk/client.py`

### 2. Batch Settlement (DONE)
Single-proposal endpoint is the only path. Polymarket batch trades and code review batches need a batch endpoint.

- `POST /v1/settle/batch` — array of proposals, returns array of results
- SDK: `settle_batch(proposals)`
- MCP: `settle_batch` tool
- Files: `api/main.py`, `sdk/client.py`, `mcp/server.py`

### 3. SDK Authorship Session Lifecycle (DONE)
SDK has claim/verify but missing session lifecycle. Feature parity table says "Y" but it's incomplete.

- `start_session()`, `record_event()`, `approve_writing()`, `delete_session()`
- These map to existing API endpoints that already work
- Files: `sdk/client.py`, tests

### 4. Adapter Base Protocol (DONE)
8 adapters, 8 different signatures. No common interface.

- Define `SwarmAdapter(Protocol)` with `settle()` method
- Add adapter registry / factory: `get_adapter("langgraph")`
- Add health check: verify framework imports before settling
- Files: `adapters/__init__.py` (new), all adapter files

## High — Next 2-3 Sessions

### 5. Multi-Python CI
CI only tests py3.12 but package claims py3.10+.

- Add matrix: `python-version: ["3.10", "3.11", "3.12"]`
- File: `.github/workflows/ci.yml`

### 6. Adapter Integration Guide
Biggest adoption blocker. Each adapter has a docstring but no standalone guide.

- One page per adapter: install, configure, usage example, full code snippet
- Files: `docs/adapters.md` (new)

### 7. Ledger Indexing
All ledger reads are O(n) — `read_all()` then filter. Fine at 789 entries, slow at 100k.

- Cache latest hash + entry count
- Index: `task_id → hash`, `agent_id → [entries]`
- Files: `settler.py`

### 8. Blueprint Lifecycle API
Authors can publish but not maintain blueprints.

- `PATCH /v1/blueprints/{id}` — update metadata
- `DELETE /v1/blueprints/{id}` — remove unpublished
- `POST /v1/blueprints/{id}/deprecate` — mark obsolete
- Files: `api/main.py`, `blueprints.py`

### 9. Rate Limit Headers
slowapi is configured but clients can't see their limits.

- Add `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset` headers
- `GET /v1/rate-limits` — query limits per endpoint
- Files: `api/main.py`

### 10. Settlement Types Catalog
75 settlement types exist but aren't documented anywhere for users.

- Table with type name, description, when to use, example payload
- Files: `docs/settlement-types.md` (new)

## Medium — Polish

### 11. Missing Test Files
- `test_context.py` — context slicing, keyword filtering (context.py has no tests)
- `test_auditor.py` — shadow audit divergence detection (auditor.py has no tests)

### 12. SDK Error Hierarchy
SDK throws raw `httpx` exceptions. Need domain-specific errors.

- `SettlementError` (base), `AuthError`, `RateLimitError`, `NotFoundError`, `ValidationError`
- Files: `sdk/client.py`, `sdk/errors.py` (new)

### 13. Observability
No structured logging, no metrics, no trace IDs.

- JSON logging format for production
- `GET /metrics` — Prometheus format (settlement rate, latency, error count)
- Correlation ID header propagation
- Files: `api/main.py`, new middleware

### 14. Developer Experience
- `Makefile` or `justfile` — test, lint, typecheck, serve, format, publish
- `docker-compose.yml` — local dev with API + MCP
- `.env.example` checked in (not `.env`)

### 15. Webhook Testing
- `POST /v1/webhooks/test` — fire test event to verify hook before registration
- SDK: `test_webhook(event, url)`
- Files: `api/main.py`, `webhooks.py`, `sdk/client.py`

## Low — Nice to Have

### 16. Getting Started Guide
Homepage → SPEC.md is too steep. Need a 5-minute quickstart.

- Install, first settlement, verify, done
- Files: `docs/quickstart.md` (new)

### 17. Code Coverage
- Add codecov/coveralls to CI
- File: `.github/workflows/ci.yml`

### 18. Docker Image
- Dockerfile for API server
- Publish to GitHub Container Registry
- File: `Dockerfile` (new)

### 19. CLI Config Subcommand
- `swarm config get [key]` — read `~/.swarm/config.toml`
- `swarm config set <key> <value>` — write to config
- File: `cli.py`

### 20. Polymarket Edge Cases
- `settle_liquidation()` — margin calls, forced closes
- `settle_dispute()` — cancelled market outcomes
- File: `adapters/polymarket.py`

## Current State

| Metric | Value |
|--------|-------|
| Version | 0.6.2 |
| PyPI | swarm-at-sdk 0.6.2 |
| MCP Registry | io.github.Mediaeater/swarm-at 0.6.2 |
| Blueprints | 48 across 9 categories |
| MCP Tools | 18 |
| API Endpoints | 54 |
| Framework Adapters | 8 |
| Tests | 1494 passing, ~18s |
| Settlement Types | 75 |
| Public Ledger | 789 entries |
