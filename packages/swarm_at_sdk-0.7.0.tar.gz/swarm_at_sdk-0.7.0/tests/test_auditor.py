"""Tests for the Shadow Auditor."""

import pytest

from swarm_at.auditor import DivergenceError, shadow_audit


@pytest.mark.parametrize(
    "primary_result, shadow_result, max_drift, should_raise",
    [
        ({"result": "A"}, {"result": "A"}, 0.15, False),
        ({"result": "A"}, {"result": "B"}, 0.15, True),
        ({"result": "A"}, {"result": "B"}, 1.0, False),
    ],
    ids=["matching", "divergent", "high-threshold-passes"],
)
def test_shadow_audit(primary_result, shadow_result, max_drift, should_raise):
    def primary(ctx):
        return primary_result

    def shadow(ctx):
        return shadow_result

    decorated = shadow_audit(shadow_fn=shadow, max_drift=max_drift)(primary)

    if should_raise:
        with pytest.raises(DivergenceError) as exc_info:
            decorated({"context": "test"})
        assert exc_info.value.divergence > max_drift
    else:
        result = decorated({"context": "test"})
        assert result == primary_result
