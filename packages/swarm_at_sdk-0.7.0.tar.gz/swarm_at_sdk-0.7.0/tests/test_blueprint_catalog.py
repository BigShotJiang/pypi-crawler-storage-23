"""Tests for the blueprint catalog — validates all 48 canonical blueprints."""

from __future__ import annotations

import pytest

from swarm_at.seed_blueprints import CANONICAL_BLUEPRINTS


class TestBlueprintCatalog:
    """Validate structure and integrity of the full blueprint catalog."""

    def test_catalog_has_48_blueprints(self) -> None:
        assert len(CANONICAL_BLUEPRINTS) == 48

    def test_all_blueprint_ids_unique(self) -> None:
        ids = [bp.blueprint_id for bp in CANONICAL_BLUEPRINTS]
        assert len(ids) == len(set(ids)), f"Duplicate IDs: {[x for x in ids if ids.count(x) > 1]}"

    @pytest.mark.parametrize(
        "bp",
        CANONICAL_BLUEPRINTS,
        ids=[bp.blueprint_id for bp in CANONICAL_BLUEPRINTS],
    )
    def test_each_has_at_least_2_steps(self, bp) -> None:
        assert len(bp.steps) >= 2, f"{bp.blueprint_id} has {len(bp.steps)} steps"

    @pytest.mark.parametrize(
        "bp",
        CANONICAL_BLUEPRINTS,
        ids=[bp.blueprint_id for bp in CANONICAL_BLUEPRINTS],
    )
    def test_tags_non_empty(self, bp) -> None:
        assert len(bp.tags) > 0, f"{bp.blueprint_id} has no tags"

    @pytest.mark.parametrize(
        "bp",
        CANONICAL_BLUEPRINTS,
        ids=[bp.blueprint_id for bp in CANONICAL_BLUEPRINTS],
    )
    def test_credit_cost_positive(self, bp) -> None:
        assert bp.credit_cost > 0, f"{bp.blueprint_id} has non-positive credit cost"

    @pytest.mark.parametrize(
        "bp",
        CANONICAL_BLUEPRINTS,
        ids=[bp.blueprint_id for bp in CANONICAL_BLUEPRINTS],
    )
    def test_step_dependencies_valid(self, bp) -> None:
        """All depends_on references point to steps that exist in the same blueprint."""
        step_ids = {s.step_id for s in bp.steps}
        for step in bp.steps:
            for dep in step.depends_on:
                assert dep in step_ids, (
                    f"{bp.blueprint_id}: step '{step.step_id}' depends on "
                    f"'{dep}' which doesn't exist"
                )

    @pytest.mark.parametrize(
        "tag,min_count",
        [
            ("audit", 4),
            ("compliance", 6),
            ("development", 7),
            ("finance", 7),
            ("procurement", 6),
            ("customer-ops", 6),
            ("specialty", 6),
            ("ai", 3),
            ("security", 2),
            ("hr", 1),
            ("marketing", 1),
            ("design", 1),
            ("data", 1),
            ("rag", 1),
            ("consensus", 1),
            ("delegation", 1),
            ("creative", 2),
        ],
        ids=[
            "audit", "compliance", "development", "finance", "procurement",
            "customer-ops", "specialty", "ai", "security", "hr", "marketing",
            "design", "data", "rag", "consensus", "delegation", "creative",
        ],
    )
    def test_tag_filter_returns_matches(self, tag: str, min_count: int) -> None:
        matches = [bp for bp in CANONICAL_BLUEPRINTS if tag in bp.tags]
        assert len(matches) >= min_count, (
            f"Tag '{tag}': expected >= {min_count}, got {len(matches)}"
        )

    def test_all_categories_covered(self) -> None:
        """Every blueprint category has at least one tag represented."""
        all_tags = {tag for bp in CANONICAL_BLUEPRINTS for tag in bp.tags}
        required = {"ai", "security", "hr", "marketing", "design", "data",
                     "development", "finance", "procurement", "customer-ops"}
        missing = required - all_tags
        assert not missing, f"Missing category tags: {missing}"

    def test_community_blueprints_exist(self) -> None:
        community = [bp for bp in CANONICAL_BLUEPRINTS if bp.author != "swarm.at"]
        assert len(community) == 8

    @pytest.mark.parametrize(
        "bp",
        [bp for bp in CANONICAL_BLUEPRINTS if bp.author != "swarm.at"],
        ids=[bp.blueprint_id for bp in CANONICAL_BLUEPRINTS if bp.author != "swarm.at"],
    )
    def test_community_author_not_swarm_at(self, bp) -> None:
        assert bp.author != "swarm.at"
        assert bp.author  # not empty
