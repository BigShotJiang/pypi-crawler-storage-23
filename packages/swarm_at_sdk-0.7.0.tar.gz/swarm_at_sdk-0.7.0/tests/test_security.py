"""Adversarial Test Suite: 32 STRIDE tests for security hardening.

Covers Spoofing, Tampering, DoS, Privilege Escalation, and Info Disclosure
across the full swarm.at stack.
"""

from __future__ import annotations

import threading
from pathlib import Path

import pytest
from pydantic import ValidationError

from swarm_at.agents import (
    RESERVED_AGENT_IDS,
    AgentError,
    AgentIdentity,
    AgentRegistry,
    AgentRole,
    TrustLevel,
)
from swarm_at.consensus import ConsensusEngine, ConsensusError
from swarm_at.engine import SwarmAtEngine
from swarm_at.models import Header, Payload
from swarm_at.settler import Ledger

from tests.conftest import make_proposal


# ---------------------------------------------------------------------------
# Spoofing (7 tests)
# ---------------------------------------------------------------------------


class TestSpoofing:
    """Attempts to create agents with malicious identities."""

    @pytest.mark.parametrize(
        "agent_id",
        [
            "'; DROP TABLE agents;--",
            "<script>alert(1)</script>",
            "../../../etc/passwd",
            "agent\x00null",
            "agent\ninjection",
        ],
        ids=["sql-injection", "xss", "path-traversal", "null-byte", "newline-injection"],
    )
    def test_injection_in_agent_id_rejected(self, registry: AgentRegistry, agent_id: str) -> None:
        with pytest.raises((AgentError, ValidationError)):
            registry.register(agent_id)

    def test_empty_agent_id_rejected(self, registry: AgentRegistry) -> None:
        with pytest.raises((AgentError, ValidationError)):
            registry.register("")

    def test_single_char_agent_id_rejected(self, registry: AgentRegistry) -> None:
        with pytest.raises((AgentError, ValidationError)):
            registry.register("a")

    @pytest.mark.parametrize(
        "reserved",
        sorted(RESERVED_AGENT_IDS),
        ids=[f"reserved-{r}" for r in sorted(RESERVED_AGENT_IDS)],
    )
    def test_reserved_agent_ids_blocked(self, registry: AgentRegistry, reserved: str) -> None:
        with pytest.raises((AgentError, ValidationError)):
            registry.register(reserved)

    def test_impersonation_in_consensus(self, tmp_path: Path) -> None:
        """Staker cannot verify their own stake."""
        ledger = Ledger(path=tmp_path / "impersonate.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        ce = ConsensusEngine(engine=engine, required_verifications=1)
        proposal = make_proposal()
        ce.stake("task-1", "agent-aa", proposal)
        with pytest.raises(ConsensusError, match="cannot verify their own"):
            ce.verify("task-1", "agent-aa", agrees=True)

    def test_sybil_mutual_verification_blocked(self, tmp_path: Path) -> None:
        """Same agent cannot verify twice."""
        ledger = Ledger(path=tmp_path / "sybil.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        ce = ConsensusEngine(engine=engine, required_verifications=2)
        proposal = make_proposal()
        ce.stake("task-1", "staker-01", proposal)
        ce.verify("task-1", "verifier-01", agrees=True)
        with pytest.raises(ConsensusError, match="already verified"):
            ce.verify("task-1", "verifier-01", agrees=True)

    def test_excessive_length_agent_id_rejected(self, registry: AgentRegistry) -> None:
        with pytest.raises((AgentError, ValidationError)):
            registry.register("a" * 100)


# ---------------------------------------------------------------------------
# Tampering (6 tests)
# ---------------------------------------------------------------------------


class TestTampering:
    """Attempts to corrupt data or bypass integrity checks."""

    def test_oversized_payload_rejected(self) -> None:
        """Payload > 1MB is rejected."""
        big_data = {"big": "x" * 1_100_000}
        with pytest.raises(ValidationError, match="exceeds"):
            Payload(data_update=big_data, confidence_score=0.95)

    def test_deep_nesting_rejected(self) -> None:
        """Payload nesting > 32 levels is rejected."""
        nested: dict[str, object] = {"leaf": True}
        for _ in range(35):
            nested = {"level": nested}
        with pytest.raises(ValidationError, match="nesting"):
            Payload(data_update=nested, confidence_score=0.95)

    def test_concurrent_write_integrity(self, tmp_path: Path) -> None:
        """Concurrent writes to ledger don't corrupt the chain."""
        ledger = Ledger(path=tmp_path / "concurrent.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        errors: list[Exception] = []

        def write_entry(idx: int) -> None:
            try:
                p = make_proposal(
                    parent_hash=ledger.get_latest_hash(),
                    task_id=f"concurrent-{idx}",
                )
                engine.verify_and_settle(p)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=write_entry, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        # Chain should still be valid (some entries may fail due to hash collision)
        entries = ledger.read_all()
        assert len(entries) > 0

    def test_replay_detection_via_hash_chain(self, tmp_path: Path) -> None:
        """Re-submitting a settled proposal with old parent_hash is rejected."""
        ledger = Ledger(path=tmp_path / "replay.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        p1 = make_proposal(task_id="first")
        r1 = engine.verify_and_settle(p1)
        assert r1.status.value == "SETTLED"

        # Replay p1 again — parent_hash points to genesis, but latest is now r1.hash
        r2 = engine.verify_and_settle(p1)
        assert r2.status.value == "REJECTED"
        assert r2.reason is not None
        assert "drift" in r2.reason.lower() or "parent" in r2.reason.lower()

    def test_settlement_history_mutation_blocked(self, registry: AgentRegistry) -> None:
        """Directly setting settlements_completed without history doesn't promote trust."""
        registry.register("agent-aa")
        agent = registry.get("agent-aa")
        # Try to directly mutate settlement counts
        agent.settlements_completed = 1000
        # Bayesian bound uses raw counts, but _calculate_trust is called on record_settlement
        # Direct mutation alone doesn't trigger recalculation — trust stays UNTRUSTED
        assert agent.trust_level == TrustLevel.UNTRUSTED

    def test_non_hex_hash_rejected(self) -> None:
        """Parent hash with non-hex characters is rejected."""
        with pytest.raises(ValidationError, match="hex"):
            Header(parent_hash="z" * 64)


# ---------------------------------------------------------------------------
# DoS (6 tests)
# ---------------------------------------------------------------------------


class TestDoS:
    """Attempts to exhaust resources or crash the system."""

    def test_payload_size_limit_enforced(self) -> None:
        """API-level payload size limit via Pydantic validation."""
        with pytest.raises(ValidationError):
            Payload(data_update={"huge": "a" * 2_000_000}, confidence_score=0.95)

    def test_rapid_fire_consensus_limited(self, tmp_path: Path) -> None:
        """Consensus engine rejects rounds beyond max_active_rounds."""
        ledger = Ledger(path=tmp_path / "dos.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        ce = ConsensusEngine(engine=engine, max_active_rounds=5)
        for i in range(5):
            ce.stake(f"task-{i}", "agent-aa", make_proposal(task_id=f"task-{i}"))
        with pytest.raises(ConsensusError, match="Too many"):
            ce.stake("task-overflow", "agent-aa", make_proposal(task_id="overflow"))

    def test_nesting_does_not_crash(self) -> None:
        """Deep nesting raises ValidationError, not RecursionError."""
        nested: dict[str, object] = {"leaf": True}
        for _ in range(40):
            nested = {"level": nested}
        with pytest.raises(ValidationError):
            Payload(data_update=nested, confidence_score=0.95)

    def test_unbounded_registration_limited(self) -> None:
        """Registry rejects agents beyond max_agents."""
        registry = AgentRegistry(max_agents=5)
        for i in range(5):
            registry.register(f"agent-{i:02d}")
        with pytest.raises(AgentError, match="full"):
            registry.register("agent-overflow")

    def test_unbounded_consensus_rounds_limited(self, tmp_path: Path) -> None:
        """Consensus engine enforces max_active_rounds."""
        ledger = Ledger(path=tmp_path / "unbounded.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        ce = ConsensusEngine(engine=engine, max_active_rounds=3)
        for i in range(3):
            ce.stake(f"task-{i}", "agent-aa", make_proposal(task_id=f"t-{i}"))
        with pytest.raises(ConsensusError, match="Too many"):
            ce.stake("task-4", "agent-aa", make_proposal(task_id="t-4"))

    def test_large_agent_id_within_limit_accepted(self, registry: AgentRegistry) -> None:
        """64-char agent_id (max) is accepted, 65+ is rejected."""
        max_id = "a" * 64
        agent = registry.register(max_id)
        assert agent.agent_id == max_id
        with pytest.raises((AgentError, ValidationError)):
            registry.register("b" * 65)


# ---------------------------------------------------------------------------
# Privilege Escalation (7 tests)
# ---------------------------------------------------------------------------


class TestPrivilegeEscalation:
    """Attempts to gain unauthorized access or bypass trust gates."""

    def test_direct_trust_level_mutation_does_not_persist(self, registry: AgentRegistry) -> None:
        """Directly setting trust_level is overwritten on next settlement."""
        registry.register("agent-aa")
        agent = registry.get("agent-aa")
        agent.trust_level = TrustLevel.SENIOR
        # Next settlement recalculates trust
        registry.record_settlement("agent-aa", success=True)
        agent = registry.get("agent-aa")
        # With only 1 success, Bayesian bound is ~0.24, far below SENIOR
        assert agent.trust_level != TrustLevel.SENIOR

    def test_counter_manipulation_requires_recalculation(self, registry: AgentRegistry) -> None:
        """Directly inflating settlement counts doesn't promote without recalculation."""
        registry.register("agent-aa")
        agent = registry.get("agent-aa")
        # Inflate counters directly
        agent.settlements_completed = 500
        # Trust stays UNTRUSTED until a record_settlement triggers _calculate_trust
        assert agent.trust_level == TrustLevel.UNTRUSTED
        # The counter is mutable but trust_level is only updated via record_settlement()
        # This tests that the data model alone doesn't auto-promote

    def test_sybil_verification_blocked(self, tmp_path: Path) -> None:
        """Same agent trying to verify multiple times is blocked."""
        ledger = Ledger(path=tmp_path / "sybil_escalate.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        ce = ConsensusEngine(engine=engine, required_verifications=2)
        ce.stake("task-1", "staker-01", make_proposal())
        ce.verify("task-1", "verifier-01", agrees=True)
        with pytest.raises(ConsensusError, match="already verified"):
            ce.verify("task-1", "verifier-01", agrees=True)

    def test_untrusted_cannot_stake_with_registry(self, tmp_path: Path) -> None:
        """ConsensusEngine with registry blocks untrusted agents from staking."""
        ledger = Ledger(path=tmp_path / "no_stake.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        reg = AgentRegistry()
        reg.register("untrusted-agent")
        ce = ConsensusEngine(engine=engine, registry=reg)
        with pytest.raises(ConsensusError, match="lacks permission to stake"):
            ce.stake("task-1", "untrusted-agent", make_proposal())

    def test_untrusted_cannot_verify_with_registry(self, tmp_path: Path) -> None:
        """ConsensusEngine with registry blocks untrusted agents from verifying."""
        ledger = Ledger(path=tmp_path / "no_verify.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        reg = AgentRegistry()
        reg.register("staker-01")
        reg.register("untrusted-verifier")
        for _ in range(8):
            reg.record_settlement("staker-01", success=True)
        ce = ConsensusEngine(engine=engine, registry=reg)
        ce.stake("task-1", "staker-01", make_proposal())
        with pytest.raises(ConsensusError, match="lacks permission to verify"):
            ce.verify("task-1", "untrusted-verifier", agrees=True)

    def test_circuit_breaker_bypass_blocked(self, registry: AgentRegistry) -> None:
        """Agent in cooldown cannot be re-promoted by adding successes."""
        registry.register("agent-aa")
        for _ in range(50):
            registry.record_settlement("agent-aa", success=True)
        # Trigger circuit breaker
        for _ in range(3):
            registry.record_settlement("agent-aa", success=False)
        agent = registry.get("agent-aa")
        assert agent.trust_level == TrustLevel.PROVISIONAL
        assert agent.is_in_cooldown
        # Successes during cooldown don't promote
        for _ in range(20):
            registry.record_settlement("agent-aa", success=True)
        agent = registry.get("agent-aa")
        assert agent.trust_level == TrustLevel.PROVISIONAL

    def test_role_escalation_via_direct_mutation(self, registry: AgentRegistry) -> None:
        """Direct role mutation doesn't grant orchestration without SENIOR trust."""
        registry.register("agent-aa", role=AgentRole.WORKER)
        agent = registry.get("agent-aa")
        agent.role = AgentRole.ORCHESTRATOR
        # Still UNTRUSTED — can't orchestrate
        assert agent.can_orchestrate() is False


# ---------------------------------------------------------------------------
# Information Disclosure (6 tests)
# ---------------------------------------------------------------------------


class TestInfoDisclosure:
    """Attempts to leak sensitive data through public interfaces."""

    def test_sensitive_payload_stays_in_ledger(self, tmp_path: Path) -> None:
        """Sensitive data in payload is stored in ledger, not exposed elsewhere."""
        ledger = Ledger(path=tmp_path / "sensitive.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        p = make_proposal(data={"api_key": "sk-secret-12345"})
        result = engine.verify_and_settle(p)
        # The hash doesn't contain the raw data
        assert "sk-secret" not in (result.hash or "")

    def test_error_messages_are_generic(self, registry: AgentRegistry) -> None:
        """Error messages don't leak internal state."""
        with pytest.raises(AgentError) as exc_info:
            registry.get("nonexistent")
        # Should say "not found" but not leak registry internals
        assert "not found" in str(exc_info.value)
        assert "_agents" not in str(exc_info.value)

    def test_api_key_not_in_agent_data(self, registry: AgentRegistry) -> None:
        """Agent identity model doesn't expose API keys or tokens."""
        registry.register("agent-aa")
        agent = registry.get("agent-aa")
        serialized = agent.model_dump()
        # Should not contain any key-like fields
        for key in serialized:
            assert "api_key" not in key.lower()
            assert "token" not in key.lower()
            assert "password" not in key.lower()

    def test_agent_metadata_privacy(self, registry: AgentRegistry) -> None:
        """Agent metadata doesn't leak into public-facing fields."""
        registry.register("agent-aa")
        agent = registry.get("agent-aa")
        agent.metadata["internal_secret"] = "s3cret"
        # Public properties don't contain metadata
        assert "s3cret" not in str(agent.reputation_score)
        assert "s3cret" not in str(agent.success_rate)
        assert "s3cret" not in str(agent.trust_level)

    def test_settlement_hash_is_opaque(self, tmp_path: Path) -> None:
        """Settlement hashes don't reveal payload content."""
        ledger = Ledger(path=tmp_path / "opaque.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        p = make_proposal(data={"password": "hunter2"})
        result = engine.verify_and_settle(p)
        assert result.hash is not None
        assert "hunter2" not in result.hash
        assert "password" not in result.hash

    def test_review_queue_only_returns_ids(self, registry: AgentRegistry) -> None:
        """Review queue exposes only agent IDs, not full identity objects."""
        registry.register("agent-aa")
        for _ in range(25):
            registry.record_settlement("agent-aa", success=True)
        registry.record_divergence("agent-aa", critical=True)
        queue = registry.review_queue
        assert isinstance(queue, list)
        assert all(isinstance(item, str) for item in queue)
        # No AgentIdentity objects leaked
        assert not any(isinstance(item, AgentIdentity) for item in queue)
