"""Tests for WritingSessionStore and PersistentWritingSessionStore."""

from __future__ import annotations

from pathlib import Path

from swarm_at.authorship import (
    CreativePhase,
    PersistentWritingSessionStore,
    WritingSession,
    WritingSessionStore,
)


# ---------------------------------------------------------------------------
# In-memory store
# ---------------------------------------------------------------------------


class TestWritingSessionStore:
    """In-memory WritingSessionStore."""

    def _make_session(self, tmp_path: Path, writer: str = "jane") -> WritingSession:
        return WritingSession(
            writer=writer,
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )

    def test_create_and_get(self, tmp_path: Path) -> None:
        store = WritingSessionStore()
        session = self._make_session(tmp_path)
        store.create(session)
        assert store.get(session.session_id) is session

    def test_get_missing_returns_none(self) -> None:
        store = WritingSessionStore()
        assert store.get("nonexistent") is None

    def test_contains(self, tmp_path: Path) -> None:
        store = WritingSessionStore()
        session = self._make_session(tmp_path)
        store.create(session)
        assert session.session_id in store
        assert "nonexistent" not in store

    def test_len(self, tmp_path: Path) -> None:
        store = WritingSessionStore()
        assert len(store) == 0
        store.create(self._make_session(tmp_path))
        assert len(store) == 1

    def test_list_sessions(self, tmp_path: Path) -> None:
        store = WritingSessionStore()
        s1 = self._make_session(tmp_path, writer="jane")
        s2 = self._make_session(tmp_path, writer="bob")
        store.create(s1)
        store.create(s2)
        assert len(store.list_sessions()) == 2

    def test_filter_by_writer(self, tmp_path: Path) -> None:
        store = WritingSessionStore()
        s1 = self._make_session(tmp_path, writer="jane")
        s2 = self._make_session(tmp_path, writer="bob")
        store.create(s1)
        store.create(s2)
        jane_sessions = store.list_sessions(writer="jane")
        assert len(jane_sessions) == 1
        assert jane_sessions[0].writer == "jane"


# ---------------------------------------------------------------------------
# Persistent store
# ---------------------------------------------------------------------------


class TestPersistentWritingSessionStore:
    """PersistentWritingSessionStore with JSONL backing."""

    def _make_session(self, tmp_path: Path, writer: str = "jane") -> WritingSession:
        return WritingSession(
            writer=writer,
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )

    def test_create_persists(self, tmp_path: Path) -> None:
        store_path = str(tmp_path / "sessions.jsonl")
        ledger_path = str(tmp_path / "ledger.jsonl")

        store1 = PersistentWritingSessionStore(path=store_path, ledger_path=ledger_path)
        session = self._make_session(tmp_path)
        store1.create(session)
        assert len(store1) == 1

        # Reload from disk
        store2 = PersistentWritingSessionStore(path=store_path, ledger_path=ledger_path)
        assert len(store2) == 1
        restored = store2.get(session.session_id)
        assert restored is not None
        assert restored.writer == session.writer
        assert restored.session_id == session.session_id

    def test_events_persisted(self, tmp_path: Path) -> None:
        store_path = str(tmp_path / "sessions.jsonl")
        ledger_path = str(tmp_path / "ledger.jsonl")

        store1 = PersistentWritingSessionStore(path=store_path, ledger_path=ledger_path)
        session = self._make_session(tmp_path)
        session.direct(action="premise", chose="noir", phase=CreativePhase.CONCEPT)
        store1.create(session)

        session.prompt(text="Write scene", phase=CreativePhase.SCENE)
        store1.update(session)

        # Reload
        store2 = PersistentWritingSessionStore(path=store_path, ledger_path=ledger_path)
        restored = store2.get(session.session_id)
        assert restored is not None
        assert len(restored.events) == 2

    def test_multiple_sessions(self, tmp_path: Path) -> None:
        store_path = str(tmp_path / "sessions.jsonl")
        ledger_path = str(tmp_path / "ledger.jsonl")

        store = PersistentWritingSessionStore(path=store_path, ledger_path=ledger_path)
        s1 = self._make_session(tmp_path, writer="jane")
        s2 = self._make_session(tmp_path, writer="bob")
        store.create(s1)
        store.create(s2)

        # Reload
        store2 = PersistentWritingSessionStore(path=store_path, ledger_path=ledger_path)
        assert len(store2) == 2

    def test_missing_file_starts_empty(self, tmp_path: Path) -> None:
        store = PersistentWritingSessionStore(
            path=str(tmp_path / "nonexistent.jsonl"),
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        assert len(store) == 0

    def test_corrupt_line_skipped(self, tmp_path: Path) -> None:
        store_path = tmp_path / "sessions.jsonl"
        ledger_path = str(tmp_path / "ledger.jsonl")

        # Write a valid line then a corrupt line
        store1 = PersistentWritingSessionStore(path=str(store_path), ledger_path=ledger_path)
        session = self._make_session(tmp_path)
        store1.create(session)

        # Append garbage
        with open(store_path, "a") as f:
            f.write("NOT VALID JSON\n")

        # Should load the valid session, skip the corrupt line
        store2 = PersistentWritingSessionStore(path=str(store_path), ledger_path=ledger_path)
        assert len(store2) == 1
