"""Tests for framework adapters — all use MagicMock, no framework dependencies."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

from swarm_at.models import SettlementStatus
from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


# ---------------------------------------------------------------------------
# Shared fixture: sandbox context so tests never touch the filesystem
# ---------------------------------------------------------------------------


@pytest.fixture()
def sandbox_ctx(tmp_path: Path) -> SettlementContext:
    return SettlementContext(tier=SettlementTier.SANDBOX, ledger_path=str(tmp_path / "l.jsonl"))


# ---------------------------------------------------------------------------
# LangGraph adapter
# ---------------------------------------------------------------------------


class TestLangGraphAdapter:
    """SwarmNodeWrapper wraps node functions and settles outputs."""

    def test_wrap_returns_original_result(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.langgraph import SwarmNodeWrapper

        wrapper = SwarmNodeWrapper(context=sandbox_ctx)

        @wrapper.wrap
        def research_node(state: dict[str, Any]) -> dict[str, Any]:
            return {"findings": "important data"}

        result = research_node({"query": "test"})
        assert result == {"findings": "important data"}

    def test_wrap_settles_dict_output(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.langgraph import SwarmNodeWrapper

        wrapper = SwarmNodeWrapper(agent="test-node", context=sandbox_ctx)

        @wrapper.wrap
        def my_node(state: dict[str, Any]) -> dict[str, Any]:
            return {"answer": 42}

        my_node({})
        # Context should have advanced (sandbox produces hashes)
        assert sandbox_ctx._parent_hash != "0" * 64

    def test_wrap_handles_non_dict_output(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.langgraph import SwarmNodeWrapper

        wrapper = SwarmNodeWrapper(context=sandbox_ctx)

        @wrapper.wrap
        def string_node(state: dict[str, Any]) -> str:
            return "plain string"

        result = string_node({})
        assert result == "plain string"

    def test_custom_confidence(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.langgraph import SwarmNodeWrapper

        wrapper = SwarmNodeWrapper(confidence=0.5, context=sandbox_ctx)
        assert wrapper.confidence == 0.5


# ---------------------------------------------------------------------------
# AutoGen adapter
# ---------------------------------------------------------------------------


class TestAutoGenAdapter:
    """SwarmReplyCallback observes replies without interfering."""

    def test_on_reply_returns_false_none(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.autogen import SwarmReplyCallback

        cb = SwarmReplyCallback(context=sandbox_ctx)
        sender = MagicMock()
        sender.name = "research-agent"
        recipient = MagicMock()
        recipient.name = "user-proxy"

        result = cb.on_reply(
            recipient=recipient,
            messages=[{"content": "Here are my findings."}],
            sender=sender,
        )
        assert result == (False, None)

    def test_on_reply_settles_message(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.autogen import SwarmReplyCallback

        cb = SwarmReplyCallback(context=sandbox_ctx)
        sender = MagicMock()
        sender.name = "analyst"
        recipient = MagicMock()
        recipient.name = "manager"

        cb.on_reply(recipient, [{"content": "analysis complete"}], sender)
        assert sandbox_ctx._parent_hash != "0" * 64

    def test_empty_messages(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.autogen import SwarmReplyCallback

        cb = SwarmReplyCallback(context=sandbox_ctx)
        result = cb.on_reply(MagicMock(), [], MagicMock())
        assert result == (False, None)

    def test_string_messages(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.autogen import SwarmReplyCallback

        cb = SwarmReplyCallback(context=sandbox_ctx)
        result = cb.on_reply(MagicMock(), ["plain text reply"], MagicMock())
        assert result == (False, None)


# ---------------------------------------------------------------------------
# CrewAI adapter
# ---------------------------------------------------------------------------


class TestCrewAIAdapter:
    """SwarmTaskCallback settles CrewAI task outputs."""

    def test_on_task_complete(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.crewai import SwarmTaskCallback

        cb = SwarmTaskCallback(context=sandbox_ctx)
        task_output = MagicMock()
        task_output.description = "Research market trends"
        task_output.raw = "Market is bullish on AI agents"
        task_output.agent = "researcher"

        cb.on_task_complete(task_output)
        assert sandbox_ctx._parent_hash != "0" * 64

    def test_agent_with_role_attr(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.crewai import SwarmTaskCallback

        cb = SwarmTaskCallback(context=sandbox_ctx)
        agent_mock = MagicMock()
        agent_mock.role = "data-scientist"
        task_output = MagicMock()
        task_output.description = "Analyze dataset"
        task_output.raw = "Found 3 clusters"
        task_output.agent = agent_mock

        cb.on_task_complete(task_output)
        assert sandbox_ctx._parent_hash != "0" * 64

    def test_custom_confidence(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.crewai import SwarmTaskCallback

        cb = SwarmTaskCallback(confidence=0.8, context=sandbox_ctx)
        assert cb.confidence == 0.8


# ---------------------------------------------------------------------------
# OpenAI Assistants adapter
# ---------------------------------------------------------------------------


class TestOpenAIAssistantsAdapter:
    """SwarmRunHandler settles runs and individual steps."""

    def test_settle_run(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_assistants import SwarmRunHandler

        handler = SwarmRunHandler(assistant_id="asst_test123", context=sandbox_ctx)
        run = MagicMock()
        run.id = "run_abc"
        run.status = "completed"

        result = handler.settle_run(run, messages=[])
        assert result.status == SettlementStatus.SETTLED

    def test_settle_run_with_messages(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_assistants import SwarmRunHandler

        handler = SwarmRunHandler(context=sandbox_ctx)
        run = MagicMock()
        run.id = "run_def"
        run.status = "completed"

        text_block = MagicMock()
        text_block.text.value = "The answer is 42"
        msg = MagicMock()
        msg.content = [text_block]

        result = handler.settle_run(run, messages=[msg])
        assert result.status == SettlementStatus.SETTLED

    def test_settle_step(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_assistants import SwarmRunHandler

        handler = SwarmRunHandler(context=sandbox_ctx)
        result = handler.settle_step("tool_calls", {"tool": "code_interpreter", "input": "x=1"})
        assert result.status == SettlementStatus.SETTLED

    def test_settle_step_with_mock_object(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_assistants import SwarmRunHandler

        handler = SwarmRunHandler(context=sandbox_ctx)
        step = MagicMock()
        step.id = "step_xyz"
        step.step_details = "tool_calls details"

        result = handler.settle_step("message_creation", step)
        assert result.status == SettlementStatus.SETTLED

    def test_custom_assistant_id(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_assistants import SwarmRunHandler

        handler = SwarmRunHandler(assistant_id="asst_custom", context=sandbox_ctx)
        assert handler.assistant_id == "asst_custom"


# ---------------------------------------------------------------------------
# OpenAI Agents SDK adapter
# ---------------------------------------------------------------------------


class TestOpenAIAgentsAdapter:
    """SwarmAgentHook settles Agents SDK run results and tool calls."""

    def test_settle_run(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_agents import SwarmAgentHook

        hook = SwarmAgentHook(context=sandbox_ctx)
        result = MagicMock()
        result.final_output = "The answer is 42"
        result.last_agent = MagicMock()
        result.last_agent.name = "research-agent"
        result.new_items = []

        settlement = hook.settle_run(result)
        assert settlement.status == SettlementStatus.SETTLED

    def test_settle_tool_call(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_agents import SwarmAgentHook

        hook = SwarmAgentHook(context=sandbox_ctx)
        settlement = hook.settle_tool_call("search", {"query": "test"}, {"results": ["a", "b"]})
        assert settlement.status == SettlementStatus.SETTLED

    def test_custom_agent_name(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_agents import SwarmAgentHook

        hook = SwarmAgentHook(agent="my-agent", context=sandbox_ctx)
        assert hook.agent == "my-agent"

    def test_run_extracts_tool_call_ids(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.openai_agents import SwarmAgentHook

        hook = SwarmAgentHook(context=sandbox_ctx)
        item = MagicMock()
        item.call_id = "call_abc123"
        result = MagicMock()
        result.final_output = "done"
        result.last_agent = None
        result.new_items = [item]

        settlement = hook.settle_run(result)
        assert settlement.status == SettlementStatus.SETTLED


# ---------------------------------------------------------------------------
# Strands adapter
# ---------------------------------------------------------------------------


class TestStrandsAdapter:
    """SwarmStrandsCallback settles Strands tool and agent events."""

    def test_on_tool_complete(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.strands import SwarmStrandsCallback

        cb = SwarmStrandsCallback(context=sandbox_ctx)
        settlement = cb.on_tool_complete("search", {"q": "test"}, {"results": []})
        assert settlement.status == SettlementStatus.SETTLED

    def test_on_agent_complete(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.strands import SwarmStrandsCallback

        cb = SwarmStrandsCallback(context=sandbox_ctx)
        result = MagicMock()
        result.output = "Research complete"
        settlement = cb.on_agent_complete("researcher", result)
        assert settlement.status == SettlementStatus.SETTLED

    def test_custom_confidence(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.strands import SwarmStrandsCallback

        cb = SwarmStrandsCallback(confidence=0.8, context=sandbox_ctx)
        assert cb.confidence == 0.8

    def test_agent_complete_with_string_result(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.strands import SwarmStrandsCallback

        cb = SwarmStrandsCallback(context=sandbox_ctx)
        settlement = cb.on_agent_complete("analyst", "plain string result")
        assert settlement.status == SettlementStatus.SETTLED


# ---------------------------------------------------------------------------
# Haystack adapter
# ---------------------------------------------------------------------------


class TestHaystackAdapter:
    """SwarmSettlementComponent settles Haystack pipeline outputs."""

    def test_run_with_dict_data(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.haystack import SwarmSettlementComponent

        comp = SwarmSettlementComponent(context=sandbox_ctx)
        result = comp.run(data={"answer": "42", "confidence": 0.95})
        assert result["receipt"]["status"] == "SETTLED"
        assert result["receipt"]["hash"] is not None

    def test_run_with_string_data(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.haystack import SwarmSettlementComponent

        comp = SwarmSettlementComponent(context=sandbox_ctx)
        result = comp.run(data="plain text answer")
        assert result["receipt"]["status"] == "SETTLED"

    def test_custom_agent_name(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.haystack import SwarmSettlementComponent

        comp = SwarmSettlementComponent(agent="my-pipeline", context=sandbox_ctx)
        assert comp.agent == "my-pipeline"

    def test_custom_task_name(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.haystack import SwarmSettlementComponent

        comp = SwarmSettlementComponent(context=sandbox_ctx)
        result = comp.run(data={"answer": "yes"}, task="custom:task")
        assert result["receipt"]["status"] == "SETTLED"


# ---------------------------------------------------------------------------
# Polymarket adapter
# ---------------------------------------------------------------------------


class TestPolymarketAdapter:
    """SwarmPolymarketAdapter settles market reads, trades, prices, portfolios."""

    def test_settle_market_read(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.polymarket import SwarmPolymarketAdapter

        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        result = adapter.settle_market_read([{"id": "0x1", "question": "Will X?"}])
        assert result.status == SettlementStatus.SETTLED

    def test_settle_trade(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.polymarket import SwarmPolymarketAdapter

        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        result = adapter.settle_trade("buy", "0xtoken", 0.65, 100, {"filled": True})
        assert result.status == SettlementStatus.SETTLED

    def test_trade_forces_high_confidence(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.polymarket import SwarmPolymarketAdapter

        adapter = SwarmPolymarketAdapter(confidence=0.5, context=sandbox_ctx)
        result = adapter.settle_trade("sell", "0xtoken", 0.70, 50, {"filled": True})
        assert result.status == SettlementStatus.SETTLED

    def test_settle_price_check(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.polymarket import SwarmPolymarketAdapter

        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        result = adapter.settle_price_check("0xtoken", {"bid": 0.64, "ask": 0.66})
        assert result.status == SettlementStatus.SETTLED

    def test_settle_portfolio(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.polymarket import SwarmPolymarketAdapter

        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        result = adapter.settle_portfolio("0xaddr", [{"token": "0x1", "size": 50}])
        assert result.status == SettlementStatus.SETTLED

    def test_custom_agent_name(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.polymarket import SwarmPolymarketAdapter

        adapter = SwarmPolymarketAdapter(agent="my-market-bot", context=sandbox_ctx)
        assert adapter.agent == "my-market-bot"

    def test_custom_confidence(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.polymarket import SwarmPolymarketAdapter

        adapter = SwarmPolymarketAdapter(confidence=0.8, context=sandbox_ctx)
        assert adapter.confidence == 0.8

    def test_default_agent_name(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.polymarket import SwarmPolymarketAdapter

        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        assert adapter.agent == "polymarket"

    def test_market_read_advances_hash(self, sandbox_ctx: SettlementContext) -> None:
        from swarm_at.adapters.polymarket import SwarmPolymarketAdapter

        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        adapter.settle_market_read([{"id": "0x1"}])
        assert sandbox_ctx._parent_hash != "0" * 64
