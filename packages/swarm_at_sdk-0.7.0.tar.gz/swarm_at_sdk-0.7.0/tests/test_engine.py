"""Tests for the core Settlement Engine, Ledger, and models."""

from __future__ import annotations

from pathlib import Path

import pytest

from swarm_at.engine import SwarmAtEngine, calculate_divergence
from swarm_at.models import InstitutionalRules
from swarm_at.settler import GENESIS_HASH, Ledger

from tests.conftest import assert_escrowed, assert_rejected, assert_settled, make_proposal


class TestLedger:
    def test_genesis_hash_on_empty(self, tmp_ledger: Ledger) -> None:
        assert tmp_ledger.get_latest_hash() == GENESIS_HASH

    def test_genesis_hash_on_missing_file(self, tmp_path: Path) -> None:
        ledger = Ledger(path=tmp_path / "nonexistent.jsonl")
        assert ledger.get_latest_hash() == GENESIS_HASH

    def test_read_all_empty(self, tmp_ledger: Ledger) -> None:
        assert tmp_ledger.read_all() == []

    def test_verify_chain_empty(self, tmp_ledger: Ledger) -> None:
        assert tmp_ledger.verify_chain() is True


class TestSettlement:
    def test_settle_valid_proposal(self, engine: SwarmAtEngine) -> None:
        result = engine.verify_and_settle(make_proposal())
        assert_settled(result)

    def test_ledger_updated_after_settlement(self, engine: SwarmAtEngine, tmp_ledger: Ledger) -> None:
        result = engine.verify_and_settle(make_proposal())
        assert tmp_ledger.get_latest_hash() == result.hash
        entries = tmp_ledger.read_all()
        assert len(entries) == 1
        assert entries[0].task_id == "test-task-1"

    def test_chain_multiple_settlements(self, engine: SwarmAtEngine, tmp_ledger: Ledger) -> None:
        r1 = engine.verify_and_settle(make_proposal(data={"step": 1}))
        assert_settled(r1)
        assert r1.hash is not None
        r2 = engine.verify_and_settle(
            make_proposal(parent_hash=r1.hash, data={"step": 2}, task_id="test-task-2")
        )
        assert_settled(r2)
        assert tmp_ledger.verify_chain() is True
        assert len(tmp_ledger.read_all()) == 2

    @pytest.mark.parametrize("bad_hash", ["b" * 64, "f" * 64, "0" * 63 + "1"])
    def test_reject_state_drift(self, engine: SwarmAtEngine, bad_hash: str) -> None:
        result = engine.verify_and_settle(make_proposal(parent_hash=bad_hash))
        assert_rejected(result, reason_contains="State drift")

    @pytest.mark.parametrize("confidence", [0.0, 0.5, 0.84])
    def test_reject_low_confidence(self, engine: SwarmAtEngine, confidence: float) -> None:
        result = engine.verify_and_settle(make_proposal(confidence=confidence))
        assert_rejected(result, reason_contains="confidence")

    def test_escrow_high_divergence(self, engine: SwarmAtEngine) -> None:
        primary = make_proposal(data={"answer": "A"})
        shadow = make_proposal(data={"answer": "B"})
        result = engine.verify_and_settle(primary, shadow=shadow)
        assert_escrowed(result)

    def test_settle_with_matching_shadow(self, engine: SwarmAtEngine) -> None:
        primary = make_proposal(data={"answer": "A"})
        shadow = make_proposal(data={"answer": "A"})
        result = engine.verify_and_settle(primary, shadow=shadow)
        assert_settled(result)

    def test_custom_rules(self, tmp_ledger: Ledger) -> None:
        rules = InstitutionalRules(min_confidence=0.5, max_drift_allowed=0.5)
        engine = SwarmAtEngine(ledger=tmp_ledger, rules=rules)
        result = engine.verify_and_settle(make_proposal(confidence=0.6))
        assert_settled(result)


class TestDivergence:
    @pytest.mark.parametrize(
        "d1, d2, expected",
        [
            ({"a": 1, "b": 2}, {"a": 1, "b": 2}, 0.0),
            ({"a": 1}, {"a": 2}, 1.0),
            ({"a": 1, "b": 2}, {"a": 1, "b": 99}, 0.5),
            ({}, {}, 0.0),
        ],
        ids=["identical", "completely-different", "partial-overlap", "empty"],
    )
    def test_divergence(self, d1: dict, d2: dict, expected: float) -> None:
        assert calculate_divergence(make_proposal(data=d1), make_proposal(data=d2)) == expected
