"""Tests for the Context Injector."""

import pytest

from swarm_at.context import get_context_slice


@pytest.mark.parametrize(
    "state, keywords, always_include, expected",
    [
        (
            {"core_logic": "rules", "topic_a": "data_a", "topic_b": "data_b", "irrelevant": "noise"},
            ["topic_a"],
            None,
            {"core_logic": "rules", "topic_a": "data_a"},
        ),
        (
            {"core_logic": "important", "other": "stuff"},
            [],
            None,
            {"core_logic": "important"},
        ),
        (
            {"core_logic": "rules", "config": "settings", "data": "values"},
            ["data"],
            ["config"],
            {"config": "settings", "data": "values"},
        ),
        ({}, ["anything"], None, {}),
        ({"a": 1, "b": 2}, ["x", "y"], None, {}),
    ],
    ids=["filter-by-keyword", "core-logic-always", "custom-always-include", "empty-state", "no-matches"],
)
def test_context_slice(state, keywords, always_include, expected):
    kwargs = {"always_include": always_include} if always_include is not None else {}
    assert get_context_slice(state, keywords, **kwargs) == expected
