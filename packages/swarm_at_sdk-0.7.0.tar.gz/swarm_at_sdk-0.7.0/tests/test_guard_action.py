"""Tests for guard_action pattern: SDK and MCP."""

from __future__ import annotations

import pytest

from swarm_at.sdk.client import GuardError


class TestSDKGuardAction:
    """SwarmClient.guard_action() settle-before-act pattern."""

    def test_guard_action_settles(self, sdk_client):
        result = sdk_client.guard_action(
            agent_id="guard-agent",
            action="delete-records",
            data={"table": "users"},
        )
        assert result["status"] == "SETTLED"
        assert result["hash"] is not None
        assert len(result["hash"]) == 64
        assert result["action"] == "delete-records"
        assert result["agent_id"] == "guard-agent"

    def test_guard_action_rejects_low_confidence(self, sdk_client):
        with pytest.raises(GuardError) as exc_info:
            sdk_client.guard_action(
                agent_id="timid-agent",
                action="risky-op",
                confidence=0.1,
            )
        assert "confidence" in exc_info.value.reason.lower()

    def test_guard_action_with_empty_data(self, sdk_client):
        result = sdk_client.guard_action(
            agent_id="simple-agent",
            action="read-file",
        )
        assert result["status"] == "SETTLED"

    def test_guard_action_chain(self, sdk_client):
        r1 = sdk_client.guard_action(agent_id="chain-agent", action="step-1")
        assert r1["status"] == "SETTLED"
        r2 = sdk_client.guard_action(agent_id="chain-agent", action="step-2")
        assert r2["status"] == "SETTLED"
        assert r1["hash"] != r2["hash"]


class TestMCPGuardAction:
    """MCP guard_action tool."""

    def test_mcp_guard_action_returns_json(self, mcp_server):
        result_str = mcp_server.settle_action(
            action="deploy-service",
            context={"env": "staging"},
        )
        assert result_str["proceed"] is True
        assert result_str["settlement_token"] is not None

    def test_mcp_guard_action_blocks_dangerous(self, mcp_server):
        result = mcp_server.settle_action(action="rm -rf /")
        assert result["proceed"] is False
        assert "blocked" in result["reason"].lower()

    def test_mcp_guard_action_with_empty_context(self, mcp_server):
        result = mcp_server.settle_action(action="safe-op", context={})
        assert result["proceed"] is True

    def test_guard_error_has_reason(self):
        err = GuardError("low confidence")
        assert err.reason == "low confidence"
        assert str(err) == "low confidence"
