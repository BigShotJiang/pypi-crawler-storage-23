"""Tests for MCP Phase 3 tools: credits and blueprint forking."""

from __future__ import annotations

from swarm_at.mcp.server import SettlementMCPServer


class TestMcpGetCredits:
    """get_credits method on SettlementMCPServer."""

    def test_returns_balance_for_registered_agent(self, mcp_server: SettlementMCPServer) -> None:
        mcp_server.credit_ledger.register("agent-a", initial_balance=50.0)
        result = mcp_server.get_credits("agent-a")
        assert result["agent_id"] == "agent-a"
        assert result["balance"] == 50.0

    def test_raises_on_unknown_agent(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.get_credits("unknown")
        assert "error" in result
        assert "not registered" in result["error"]


class TestMcpTopupCredits:
    """topup_credits method on SettlementMCPServer."""

    def test_adds_credits_to_existing_agent(self, mcp_server: SettlementMCPServer) -> None:
        mcp_server.credit_ledger.register("agent-b", initial_balance=100.0)
        result = mcp_server.topup_credits("agent-b", 50.0)
        assert result["agent_id"] == "agent-b"
        assert result["balance"] == 150.0
        assert result["topup_amount"] == 50.0

    def test_creates_agent_with_default_balance_before_topup(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.topup_credits("new-agent", 25.0)
        assert result["agent_id"] == "new-agent"
        # CreditLedger defaults to 100.0 + 25.0 topup
        assert result["balance"] == 125.0

    def test_balance_persists_after_topup(self, mcp_server: SettlementMCPServer) -> None:
        mcp_server.topup_credits("agent-c", 10.0)
        balance_check = mcp_server.get_credits("agent-c")
        assert balance_check["balance"] == 110.0


class TestMcpForkBlueprint:
    """fork_blueprint method on SettlementMCPServer."""

    def test_returns_molecule_info(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.fork_blueprint("audit-chain", agent_id="test-agent")
        assert "molecule_id" in result
        assert result["name"] == "Audit Chain"
        assert result["bead_count"] == 3
        assert result["metadata"]["source_blueprint"] == "audit-chain"
        assert result["metadata"]["agent_id"] == "test-agent"

    def test_uses_default_agent_if_not_specified(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.fork_blueprint("code-review-pipeline")
        assert result["metadata"]["agent_id"] == "anonymous"

    def test_raises_on_unknown_blueprint(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.fork_blueprint("nonexistent")
        assert "error" in result
        assert "not found" in result["error"]

    def test_molecule_id_is_unique_per_fork(self, mcp_server: SettlementMCPServer) -> None:
        result1 = mcp_server.fork_blueprint("research-workflow")
        result2 = mcp_server.fork_blueprint("research-workflow")
        assert result1["molecule_id"] != result2["molecule_id"]
