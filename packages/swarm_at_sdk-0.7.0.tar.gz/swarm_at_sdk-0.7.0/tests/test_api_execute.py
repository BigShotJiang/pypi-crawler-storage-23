"""Tests for blueprint step execution API endpoint."""

from __future__ import annotations

import pytest

import swarm_at.api.state as api_state
from fastapi.testclient import TestClient

from swarm_at.api.main import app


@pytest.fixture()
def authed_client() -> TestClient:
    """API client with auth enabled and a valid Bearer token."""
    api_state.api_keys = {"sk-test-key"}
    client = TestClient(app)
    client.headers["Authorization"] = "Bearer sk-test-key"
    return client


@pytest.fixture()
def seeded_client(authed_client: TestClient) -> TestClient:
    """Authed client with blueprints seeded and test agent credits registered."""
    from swarm_at.seed_blueprints import seed_blueprints

    seed_blueprints(api_state.blueprint_store)
    api_state.credit_ledger.register("test-agent", initial_balance=500.0)
    return authed_client


def test_fork_then_execute_first_step(seeded_client: TestClient):
    """Fork a blueprint then execute its first step — returns 200 with hash."""
    # Fork the audit-chain blueprint
    fork_resp = seeded_client.post(
        "/v1/blueprints/audit-chain/fork",
        params={"agent_id": "test-agent"},
    )
    assert fork_resp.status_code == 200
    data = fork_resp.json()
    molecule_id = data["molecule_id"]
    assert data["bead_count"] == 3  # audit-chain blueprint has 3 steps

    # Execute the first step (collect)
    exec_resp = seeded_client.post(
        f"/v1/molecules/{molecule_id}/execute",
        json={
            "agent_id": "test-agent",
            "step_id": "collect",
            "data": {"evidence": ["source1", "source2"], "count": 2},
            "confidence": 0.98,
        },
    )
    assert exec_resp.status_code == 200
    result = exec_resp.json()
    assert result["molecule_id"] == molecule_id
    assert result["step_id"] == "collect"
    assert result["status"] == "SETTLED"
    assert len(result["hash"]) == 64


def test_execute_step_on_unknown_molecule(seeded_client: TestClient):
    """Execute step on unknown molecule — returns 400."""
    exec_resp = seeded_client.post(
        "/v1/molecules/unknown-molecule-id/execute",
        json={
            "agent_id": "test-agent",
            "step_id": "collect",
            "data": {},
        },
    )
    assert exec_resp.status_code == 400
    assert "not found" in exec_resp.json()["detail"].lower()


def test_execute_step_with_unmet_dependencies(seeded_client: TestClient):
    """Execute step with unmet dependencies — returns 400."""
    # Fork the audit-chain blueprint
    fork_resp = seeded_client.post(
        "/v1/blueprints/audit-chain/fork",
        params={"agent_id": "test-agent"},
    )
    assert fork_resp.status_code == 200
    molecule_id = fork_resp.json()["molecule_id"]

    # Try to execute "validate" step before "collect" (dependency not met)
    exec_resp = seeded_client.post(
        f"/v1/molecules/{molecule_id}/execute",
        json={
            "agent_id": "test-agent",
            "step_id": "validate",
            "data": {"result": "validation complete"},
        },
    )
    assert exec_resp.status_code == 400
    assert "unmet dependencies" in exec_resp.json()["detail"].lower()


def test_full_workflow_chained_execution(seeded_client: TestClient):
    """Full workflow: fork, execute step 1, execute step 2 (chained)."""
    # Fork the audit-chain blueprint
    fork_resp = seeded_client.post(
        "/v1/blueprints/audit-chain/fork",
        params={"agent_id": "test-agent"},
    )
    assert fork_resp.status_code == 200
    molecule_id = fork_resp.json()["molecule_id"]

    # Step 1: collect
    exec1_resp = seeded_client.post(
        f"/v1/molecules/{molecule_id}/execute",
        json={
            "agent_id": "test-agent",
            "step_id": "collect",
            "data": {"evidence": ["audit-log-1", "audit-log-2"]},
        },
    )
    assert exec1_resp.status_code == 200
    hash1 = exec1_resp.json()["hash"]
    assert len(hash1) == 64

    # Step 2: validate (depends on collect)
    exec2_resp = seeded_client.post(
        f"/v1/molecules/{molecule_id}/execute",
        json={
            "agent_id": "test-agent",
            "step_id": "validate",
            "data": {"validation": "passed", "anomalies": []},
        },
    )
    assert exec2_resp.status_code == 200
    hash2 = exec2_resp.json()["hash"]
    assert len(hash2) == 64
    assert hash2 != hash1  # Each step gets a unique hash

    # Step 3: report (depends on validate)
    exec3_resp = seeded_client.post(
        f"/v1/molecules/{molecule_id}/execute",
        json={
            "agent_id": "test-agent",
            "step_id": "report",
            "data": {"report": "All systems compliant", "score": 95},
        },
    )
    assert exec3_resp.status_code == 200
    hash3 = exec3_resp.json()["hash"]
    assert len(hash3) == 64

    # Verify ledger has all three settlements
    entries = api_state.ledger.read_all()
    task_ids = [e.task_id for e in entries]
    assert "collect" in task_ids
    assert "validate" in task_ids
    assert "report" in task_ids


def test_execute_step_twice_fails(seeded_client: TestClient):
    """Executing the same step twice should fail on second attempt."""
    # Fork and execute first step
    fork_resp = seeded_client.post(
        "/v1/blueprints/audit-chain/fork",
        params={"agent_id": "test-agent"},
    )
    molecule_id = fork_resp.json()["molecule_id"]

    exec1_resp = seeded_client.post(
        f"/v1/molecules/{molecule_id}/execute",
        json={
            "agent_id": "test-agent",
            "step_id": "collect",
            "data": {"evidence": ["log1"]},
        },
    )
    assert exec1_resp.status_code == 200

    # Try to execute same step again
    exec2_resp = seeded_client.post(
        f"/v1/molecules/{molecule_id}/execute",
        json={
            "agent_id": "test-agent",
            "step_id": "collect",
            "data": {"evidence": ["log2"]},
        },
    )
    assert exec2_resp.status_code == 400
    assert "pending" in exec2_resp.json()["detail"].lower()
