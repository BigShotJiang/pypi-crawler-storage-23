"""Tests for API Bearer token authentication.

Follows datasette-enrichments pattern of parametrize for permission levels.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state

from tests.conftest import make_settle_request

# All read-only GET endpoints to check
_READ_ENDPOINTS = [
    ("/v1/ledger/latest", {}),
    ("/v1/ledger/verify", {}),
    ("/v1/context", {"keywords": "a"}),
]


class TestDevMode:
    """When api_keys is empty, auth is disabled."""

    def test_no_auth_required(self, api_client: TestClient) -> None:
        assert api_client.post("/v1/settle", json=make_settle_request()).status_code == 200

    @pytest.mark.parametrize("path, params", _READ_ENDPOINTS, ids=["latest", "verify", "context"])
    def test_endpoints_open(self, api_client: TestClient, path: str, params: dict) -> None:
        assert api_client.get(path, params=params).status_code == 200


class TestAuthEnabled:
    """When api_keys has entries, Bearer tokens are required."""

    @pytest.fixture(autouse=True)
    def _enable_auth(self):
        api_state.api_keys = {"sk-valid-key-123"}
        yield

    @pytest.mark.parametrize(
        "auth_header, expected_code",
        [
            (None, 401),
            ("Bearer wrong-key", 403),
            ("Bearer sk-valid-key-123", 200),
        ],
        ids=["missing", "invalid", "valid"],
    )
    def test_settle_auth(self, api_client: TestClient, auth_header: str | None, expected_code: int) -> None:
        headers = {"Authorization": auth_header} if auth_header else {}
        resp = api_client.post("/v1/settle", json=make_settle_request(), headers=headers)
        assert resp.status_code == expected_code

    @pytest.mark.parametrize("path, params", _READ_ENDPOINTS, ids=["latest", "verify", "context"])
    def test_endpoints_require_auth(self, api_client: TestClient, path: str, params: dict) -> None:
        assert api_client.get(path, params=params).status_code == 401

    @pytest.mark.parametrize("path, params", _READ_ENDPOINTS, ids=["latest", "verify", "context"])
    def test_endpoints_pass_with_key(self, api_client: TestClient, path: str, params: dict) -> None:
        headers = {"Authorization": "Bearer sk-valid-key-123"}
        assert api_client.get(path, params=params, headers=headers).status_code == 200
