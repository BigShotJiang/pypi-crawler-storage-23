"""Tests for settlement receipts: model, engine method, and API endpoint."""

from __future__ import annotations

from swarm_at.models import SettlementReceipt, SettlementStatus
from swarm_at.settler import GENESIS_HASH

from tests.conftest import make_proposal


class TestSettlementReceiptModel:
    """SettlementReceipt validation."""

    def test_minimal_receipt(self):
        receipt = SettlementReceipt(
            status=SettlementStatus.SETTLED,
            task_id="task-1",
        )
        assert receipt.status == SettlementStatus.SETTLED
        assert receipt.hash is None
        assert receipt.agent_id == ""
        assert receipt.credit_cost == 0.0

    def test_full_receipt(self):
        receipt = SettlementReceipt(
            status=SettlementStatus.SETTLED,
            hash="a" * 64,
            task_id="task-1",
            agent_id="agent-1",
            timestamp=1234567890.0,
            parent_hash=GENESIS_HASH,
            trust_level="trusted",
            credit_cost=5.0,
        )
        assert receipt.hash == "a" * 64
        assert receipt.agent_id == "agent-1"
        assert receipt.trust_level == "trusted"
        assert receipt.credit_cost == 5.0

    def test_rejected_receipt(self):
        receipt = SettlementReceipt(
            status=SettlementStatus.REJECTED,
            reason="drift",
            task_id="task-1",
        )
        assert receipt.status == SettlementStatus.REJECTED
        assert receipt.reason == "drift"


class TestSettleWithReceipt:
    """Engine.settle_with_receipt() returns enriched data."""

    def test_settled_receipt_has_timestamp(self, engine):
        proposal = make_proposal()
        receipt = engine.settle_with_receipt(proposal, agent_id="agent-a")
        assert receipt.status == SettlementStatus.SETTLED
        assert receipt.hash is not None
        assert receipt.task_id == "test-task-1"
        assert receipt.agent_id == "agent-a"
        assert receipt.timestamp > 0
        assert receipt.parent_hash == GENESIS_HASH

    def test_receipt_with_credit_cost(self, engine):
        proposal = make_proposal()
        receipt = engine.settle_with_receipt(
            proposal, agent_id="agent-b", credit_cost=3.5, trust_level="trusted",
        )
        assert receipt.credit_cost == 3.5
        assert receipt.trust_level == "trusted"

    def test_rejected_receipt(self, engine):
        proposal = make_proposal(confidence=0.1)
        receipt = engine.settle_with_receipt(proposal)
        assert receipt.status == SettlementStatus.REJECTED
        assert receipt.reason is not None
        assert receipt.hash is None
        assert receipt.timestamp == 0.0

    def test_receipt_chain(self, engine):
        p1 = make_proposal(task_id="chain-1")
        r1 = engine.settle_with_receipt(p1)
        assert r1.status == SettlementStatus.SETTLED

        p2 = make_proposal(parent_hash=r1.hash, task_id="chain-2")
        r2 = engine.settle_with_receipt(p2)
        assert r2.status == SettlementStatus.SETTLED
        assert r2.parent_hash == r1.hash


class TestReceiptEndpoint:
    """GET /public/receipts/{hash} endpoint."""

    def test_receipt_found(self, api_client):
        body = {
            "primary": {
                "header": {"task_id": "receipt-test", "parent_hash": GENESIS_HASH},
                "payload": {"data_update": {"x": 1}, "confidence_score": 0.95},
            }
        }
        settle_resp = api_client.post("/v1/settle", json=body)
        assert settle_resp.status_code == 200
        settled_hash = settle_resp.json()["hash"]

        resp = api_client.get(f"/public/receipts/{settled_hash}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["hash"] == settled_hash
        assert data["task_id"] == "receipt-test"
        assert data["status"] == "SETTLED"
        assert "timestamp" in data
        assert "parent_hash" in data

    def test_receipt_not_found(self, api_client):
        resp = api_client.get(f"/public/receipts/{'f' * 64}")
        assert resp.status_code == 404

    def test_receipt_includes_parent_hash(self, api_client):
        body = {
            "primary": {
                "header": {"task_id": "parent-check", "parent_hash": GENESIS_HASH},
                "payload": {"data_update": {"y": 2}, "confidence_score": 0.95},
            }
        }
        settle_resp = api_client.post("/v1/settle", json=body)
        settled_hash = settle_resp.json()["hash"]

        resp = api_client.get(f"/public/receipts/{settled_hash}")
        assert resp.json()["parent_hash"] == GENESIS_HASH
