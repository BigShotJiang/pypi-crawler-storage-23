"""Tests for Agent Identity & Roles."""

from __future__ import annotations

import time

import pytest

from swarm_at.agents import (
    AgentError,
    AgentRegistry,
    AgentRole,
    TrustLevel,
    _beta_quantile,
)


class TestRegistration:
    def test_register_agent(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        assert agent.agent_id == "agent-1"
        assert agent.role == AgentRole.WORKER
        assert agent.trust_level == TrustLevel.UNTRUSTED
        assert agent.settlements_completed == 0
        assert registry.count == 1

    def test_duplicate_raises(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        with pytest.raises(AgentError, match="already registered"):
            registry.register("agent-1")

    def test_register_with_role(self, registry: AgentRegistry) -> None:
        agent = registry.register("orchestrator-1", role=AgentRole.ORCHESTRATOR)
        assert agent.role == AgentRole.ORCHESTRATOR

    def test_register_with_capabilities(self, registry: AgentRegistry) -> None:
        agent = registry.register("specialist-1", capabilities=["python", "rust"])
        assert agent.capabilities == ["python", "rust"]

    def test_get_agent(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        agent = registry.get("agent-1")
        assert agent.agent_id == "agent-1"


class TestTrustPromotion:
    def test_starts_untrusted(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        assert agent.trust_level == TrustLevel.UNTRUSTED

    def test_five_successes_stays_untrusted(self, registry: AgentRegistry) -> None:
        """With Bayesian trust, 5/5 has insufficient evidence for promotion."""
        registry.register("agent-1")
        for _ in range(5):
            agent = registry.record_settlement("agent-1", success=True)
        assert agent.trust_level == TrustLevel.UNTRUSTED

    def test_promotes_to_provisional_at_8(self, registry: AgentRegistry) -> None:
        """Bayesian lower bound crosses 0.60 threshold at ~8 successes."""
        registry.register("agent-1")
        for _ in range(7):
            agent = registry.record_settlement("agent-1", success=True)
            assert agent.trust_level == TrustLevel.UNTRUSTED
        agent = registry.record_settlement("agent-1", success=True)
        assert agent.trust_level == TrustLevel.PROVISIONAL

    def test_promotes_to_trusted_at_23(self, registry: AgentRegistry) -> None:
        """Bayesian lower bound crosses 0.82 threshold at ~23 successes."""
        registry.register("agent-1")
        for _ in range(22):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.trust_level != TrustLevel.TRUSTED
        agent = registry.record_settlement("agent-1", success=True)
        assert agent.trust_level == TrustLevel.TRUSTED

    def test_promotes_to_senior_at_100(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(99):
            registry.record_settlement("agent-1", success=True)
        agent = registry.record_settlement("agent-1", success=True)
        assert agent.trust_level == TrustLevel.SENIOR
        assert agent.settlements_completed == 100

    def test_demotion_on_failures(self, registry: AgentRegistry) -> None:
        """Failures drop Bayesian bound below TRUSTED threshold, demoting to PROVISIONAL."""
        registry.register("agent-1")
        # Get to TRUSTED (~23 successful)
        for _ in range(23):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.TRUSTED
        # A single failure drops Bayesian lower bound below 0.82
        agent = registry.record_settlement("agent-1", success=False)
        assert agent.trust_level == TrustLevel.PROVISIONAL

    def test_updates_last_active(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        original_time = agent.last_active
        time.sleep(0.01)
        registry.record_settlement("agent-1", success=True)
        updated = registry.get("agent-1")
        assert updated.last_active > original_time

    def test_success_rate_calculation(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        registry.record_settlement("agent-1", success=True)
        registry.record_settlement("agent-1", success=True)
        registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        assert agent.success_rate == pytest.approx(2 / 3)


class TestPermissions:
    def test_untrusted_cannot_stake(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        assert agent.can_stake() is False

    def test_untrusted_cannot_verify(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        assert agent.can_verify() is False

    def test_provisional_can_verify_and_stake(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(8):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.PROVISIONAL
        assert agent.can_verify() is True
        assert agent.can_stake() is True

    def test_trusted_can_stake(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(23):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.can_stake() is True

    def test_senior_orchestrator_can_orchestrate(self, registry: AgentRegistry) -> None:
        registry.register("orchestrator-1", role=AgentRole.ORCHESTRATOR)
        for _ in range(100):
            registry.record_settlement("orchestrator-1", success=True)
        agent = registry.get("orchestrator-1")
        assert agent.can_orchestrate() is True

    def test_senior_non_orchestrator_cannot_orchestrate(self, registry: AgentRegistry) -> None:
        registry.register("worker-1", role=AgentRole.WORKER)
        for _ in range(100):
            registry.record_settlement("worker-1", success=True)
        agent = registry.get("worker-1")
        assert agent.trust_level == TrustLevel.SENIOR
        assert agent.can_orchestrate() is False

    @pytest.mark.parametrize(
        "role, trust, can_stake, can_verify, can_orchestrate, can_merge",
        [
            (AgentRole.WORKER, TrustLevel.UNTRUSTED, False, False, False, False),
            (AgentRole.WORKER, TrustLevel.PROVISIONAL, True, True, False, False),
            (AgentRole.WORKER, TrustLevel.TRUSTED, True, True, False, True),
            (AgentRole.WORKER, TrustLevel.SENIOR, True, True, False, True),
            (AgentRole.ORCHESTRATOR, TrustLevel.SENIOR, True, True, True, True),
            (AgentRole.VALIDATOR, TrustLevel.TRUSTED, True, True, False, True),
        ],
        ids=[
            "untrusted-worker",
            "provisional-worker",
            "trusted-worker",
            "senior-worker",
            "senior-orchestrator",
            "trusted-validator",
        ],
    )
    def test_permission_matrix(
        self,
        registry: AgentRegistry,
        role: AgentRole,
        trust: TrustLevel,
        can_stake: bool,
        can_verify: bool,
        can_orchestrate: bool,
        can_merge: bool,
    ) -> None:
        agent = registry.register("agent-1", role=role)
        # Manually set trust level for testing
        agent.trust_level = trust
        assert agent.can_stake() == can_stake
        assert agent.can_verify() == can_verify
        assert agent.can_orchestrate() == can_orchestrate
        assert agent.can_merge() == can_merge


class TestLookup:
    def test_find_by_role_returns_correct_agents(self, registry: AgentRegistry) -> None:
        registry.register("worker-1", role=AgentRole.WORKER)
        registry.register("worker-2", role=AgentRole.WORKER)
        registry.register("orchestrator-1", role=AgentRole.ORCHESTRATOR)
        workers = registry.find_by_role(AgentRole.WORKER)
        assert len(workers) == 2
        assert all(a.role == AgentRole.WORKER for a in workers)

    def test_find_by_trust_filters_correctly(self, registry: AgentRegistry) -> None:
        registry.register("untrusted-1")
        registry.register("provisional-1")
        for _ in range(8):
            registry.record_settlement("provisional-1", success=True)
        registry.register("trusted-1")
        for _ in range(23):
            registry.record_settlement("trusted-1", success=True)
        trusted_agents = registry.find_by_trust(TrustLevel.TRUSTED)
        assert len(trusted_agents) == 1
        assert trusted_agents[0].agent_id == "trusted-1"

    def test_find_by_trust_includes_higher_levels(self, registry: AgentRegistry) -> None:
        registry.register("trusted-1")
        for _ in range(23):
            registry.record_settlement("trusted-1", success=True)
        registry.register("senior-1")
        for _ in range(100):
            registry.record_settlement("senior-1", success=True)
        # Find TRUSTED should include SENIOR
        trusted_plus = registry.find_by_trust(TrustLevel.TRUSTED)
        assert len(trusted_plus) == 2

    def test_active_agents_works(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        agent2 = registry.register("agent-2")
        # Make agent-2 inactive (25 hours ago)
        agent2.last_active = time.time() - (25 * 3600)
        active = registry.active_agents()
        assert len(active) == 1
        assert active[0].agent_id == "agent-1"

    def test_revoke_removes_agent(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        assert registry.count == 1
        registry.revoke("agent-1")
        assert registry.count == 0
        with pytest.raises(AgentError, match="not found"):
            registry.get("agent-1")

    def test_get_unknown_raises(self, registry: AgentRegistry) -> None:
        with pytest.raises(AgentError, match="not found"):
            registry.get("nonexistent")

    def test_revoke_unknown_raises(self, registry: AgentRegistry) -> None:
        with pytest.raises(AgentError, match="not found"):
            registry.revoke("nonexistent")


class TestAgentIdentity:
    def test_is_active_true_when_recent(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        assert agent.is_active is True

    def test_is_active_false_when_old(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        agent.last_active = time.time() - (25 * 3600)
        assert agent.is_active is False

    def test_success_rate_zero_when_no_settlements(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        assert agent.success_rate == 0.0

    def test_metadata_can_store_custom_data(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        agent.metadata["custom_field"] = "custom_value"
        retrieved = registry.get("agent-1")
        assert retrieved.metadata["custom_field"] == "custom_value"


class TestReputationScore:
    def test_reputation_score_zero_with_no_history(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        assert agent.reputation_score == 0.0

    def test_reputation_score_perfect_with_all_success(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(10):
            registry.record_settlement("agent-1", success=True, complexity=0.5)
        agent = registry.get("agent-1")
        assert agent.reputation_score == pytest.approx(1.0)

    def test_reputation_score_weights_by_complexity(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        # Succeed on easy task, fail on hard task
        registry.record_settlement("agent-1", success=True, complexity=0.1)
        registry.record_settlement("agent-1", success=False, complexity=1.0)
        agent = registry.get("agent-1")
        # R = 0.1 / (0.1 + 1.0) = 0.0909...
        assert agent.reputation_score == pytest.approx(0.1 / 1.1)

    def test_divergence_penalty_reduces_score(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(10):
            registry.record_settlement("agent-1", success=True)
        registry.record_divergence("agent-1", penalty=0.1)
        agent = registry.get("agent-1")
        assert agent.reputation_score == pytest.approx(0.9)

    def test_complexity_param_defaults_to_half(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.settlement_history[0].complexity == 0.5


class TestCircuitBreaker:
    def test_rolling_demotion_triggers_on_rapid_failures(self, registry: AgentRegistry) -> None:
        """Rolling 10-task success rate < 80% triggers circuit breaker demotion."""
        registry.register("agent-1")
        # 50 successes = well into TRUSTED, Bayesian bound ~0.912
        for _ in range(50):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.TRUSTED
        # Fail 3: rolling window 7/10 = 70% < 80% triggers circuit breaker
        for _ in range(3):
            registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.PROVISIONAL

    def test_no_demotion_when_rolling_rate_above_threshold(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(50):
            registry.record_settlement("agent-1", success=True)
        # Fail 1 out of recent 10 (90% > 80%)
        registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.TRUSTED

    def test_rolling_rate_ignores_old_failures(self, registry: AgentRegistry) -> None:
        """Old failures outside the window don't trigger demotion."""
        registry.register("agent-1")
        # 50 successes to reach TRUSTED
        for _ in range(50):
            registry.record_settlement("agent-1", success=True)
        # 2 failures
        for _ in range(2):
            registry.record_settlement("agent-1", success=False)
        # 10 more successes push failures out of rolling window
        for _ in range(10):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.rolling_success_rate == 1.0


class TestCriticalDivergence:
    def test_critical_divergence_revokes_to_review(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(25):
            registry.record_settlement("agent-1", success=True)
        registry.record_divergence("agent-1", penalty=0.5, critical=True)
        agent = registry.get("agent-1")
        assert agent.under_review is True
        assert agent.trust_level == TrustLevel.UNTRUSTED
        assert "agent-1" in registry.review_queue

    def test_non_critical_divergence_only_adds_penalty(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(25):
            registry.record_settlement("agent-1", success=True)
        registry.record_divergence("agent-1", penalty=0.01)
        agent = registry.get("agent-1")
        assert agent.under_review is False
        assert agent.divergence_penalty == pytest.approx(0.01)

    def test_reinstate_from_review(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(25):
            registry.record_settlement("agent-1", success=True)
        registry.record_divergence("agent-1", critical=True)
        assert "agent-1" in registry.review_queue
        agent = registry.reinstate("agent-1")
        assert agent.under_review is False
        assert agent.divergence_penalty == 0.0
        assert "agent-1" not in registry.review_queue

    def test_reinstate_non_reviewed_raises(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        with pytest.raises(AgentError, match="not under review"):
            registry.reinstate("agent-1")

    def test_accumulated_penalties_can_prevent_promotion(self, registry: AgentRegistry) -> None:
        """Multiple small penalties accumulate and can drop effective bound below threshold."""
        registry.register("agent-1")
        for _ in range(25):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.TRUSTED
        # Penalty of 0.03 drops effective bound below 0.82 (lb ~0.836 - 0.03 = 0.806)
        # Even with 1 more success (26S: lb=0.842 - 0.03 = 0.812 < 0.82)
        registry.record_divergence("agent-1", penalty=0.03)
        # Next settlement recalculates trust
        registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        # Should be demoted from TRUSTED since effective_bound - penalty < 0.82
        assert agent.trust_level == TrustLevel.PROVISIONAL


class TestPromotionPath:
    def test_full_promotion_untrusted_to_senior(self, registry: AgentRegistry) -> None:
        """Agent goes UNTRUSTED -> PROVISIONAL -> TRUSTED -> SENIOR."""
        registry.register("agent-1")
        assert registry.get("agent-1").trust_level == TrustLevel.UNTRUSTED

        # Needs 8 successes for PROVISIONAL with Bayesian trust
        for _ in range(8):
            registry.record_settlement("agent-1", success=True)
        assert registry.get("agent-1").trust_level == TrustLevel.PROVISIONAL

        # Needs 23 total for TRUSTED
        for _ in range(15):
            registry.record_settlement("agent-1", success=True)
        assert registry.get("agent-1").trust_level == TrustLevel.TRUSTED

        # Needs 100 total for SENIOR
        for _ in range(77):
            registry.record_settlement("agent-1", success=True)
        assert registry.get("agent-1").trust_level == TrustLevel.SENIOR

    def test_single_failure_blocks_senior_promotion(self, registry: AgentRegistry) -> None:
        """99 successes + 1 failure = lower Bayesian bound, may not reach SENIOR."""
        registry.register("agent-1")
        for _ in range(99):
            registry.record_settlement("agent-1", success=True)
        registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        # 99/100 Bayesian lower bound ~0.94, which is still >= 0.92
        # With Bayesian trust, a single failure is tolerated at high volume
        assert agent.trust_level == TrustLevel.SENIOR


class TestBayesianTrust:
    """Tests for the Beta-distribution based trust system."""

    def test_bayesian_lower_bound_zero_with_no_history(self, registry: AgentRegistry) -> None:
        agent = registry.register("agent-1")
        assert agent.bayesian_lower_bound == 0.0

    @pytest.mark.parametrize(
        "successes, failures, min_expected, max_expected",
        [
            (5, 0, 0.40, 0.55),
            (10, 0, 0.60, 0.72),
            (20, 0, 0.78, 0.85),
            (100, 0, 0.94, 0.97),
            (50, 50, 0.40, 0.52),
        ],
        ids=["5-of-5", "10-of-10", "20-of-20", "100-of-100", "50-50-split"],
    )
    def test_bayesian_lower_bound_ranges(
        self, registry: AgentRegistry,
        successes: int, failures: int, min_expected: float, max_expected: float,
    ) -> None:
        registry.register("agent-1")
        for _ in range(successes):
            registry.record_settlement("agent-1", success=True)
        for _ in range(failures):
            registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        assert min_expected <= agent.bayesian_lower_bound <= max_expected

    def test_skeptical_prior_penalizes_small_samples(self, registry: AgentRegistry) -> None:
        """5/5 success rate of 100% should NOT promote to PROVISIONAL."""
        registry.register("agent-1")
        for _ in range(5):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        # Bayesian lower bound is ~0.48, well below 0.60 threshold
        assert agent.trust_level == TrustLevel.UNTRUSTED

    def test_high_volume_perfect_record_reaches_senior(self, registry: AgentRegistry) -> None:
        """100/100 with no failures should reach SENIOR."""
        registry.register("agent-1")
        for _ in range(100):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.SENIOR

    def test_beta_quantile_edge_cases(self) -> None:
        """Verify beta quantile handles edge inputs."""
        assert _beta_quantile(0.0, 2.0, 3.0) == 0.0
        assert _beta_quantile(1.0, 2.0, 3.0) == 1.0

    def test_divergence_compounds_with_demotion_count(self, registry: AgentRegistry) -> None:
        """Divergence penalty multiplied by (1 + 0.5 * demotion_count)."""
        registry.register("agent-1")
        for _ in range(50):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.TRUSTED

        # Trigger a demotion via circuit breaker
        for _ in range(3):
            registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        assert agent.demotion_count >= 1

        # Clear cooldown to allow re-promotion check
        agent.cooldown_until = None

        # Add divergence penalty — should be compounded by demotion count
        registry.record_divergence("agent-1", penalty=0.02)
        agent = registry.get("agent-1")
        # Effective penalty is 0.02 * (1 + 0.5 * demotion_count)
        assert agent.divergence_penalty == pytest.approx(0.02)


class TestEnhancedCircuitBreaker:
    """Tests for demotion tracking, cooldown, and double-fault escalation."""

    def test_demotion_records_metadata(self, registry: AgentRegistry) -> None:
        """Demotion sets last_demotion_at, increments demotion_count, sets cooldown."""
        registry.register("agent-1")
        for _ in range(50):
            registry.record_settlement("agent-1", success=True)
        # Trigger circuit breaker demotion: 3 failures -> rolling 70%
        for _ in range(3):
            registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        assert agent.last_demotion_at is not None
        assert agent.demotion_count >= 1
        assert agent.cooldown_until is not None
        assert agent.cooldown_until > time.time()

    def test_cooldown_blocks_repromotion(self, registry: AgentRegistry) -> None:
        """Agent in cooldown cannot be re-promoted even with good record."""
        registry.register("agent-1")
        for _ in range(50):
            registry.record_settlement("agent-1", success=True)
        # Trigger circuit breaker demotion
        for _ in range(3):
            registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.PROVISIONAL
        # More successes during cooldown shouldn't promote
        for _ in range(5):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.PROVISIONAL  # still in cooldown

    def test_cooldown_expires_allows_promotion(self, registry: AgentRegistry) -> None:
        """After cooldown expires, agent can be re-promoted."""
        registry.register("agent-1")
        for _ in range(50):
            registry.record_settlement("agent-1", success=True)
        # Trigger circuit breaker demotion
        for _ in range(3):
            registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.PROVISIONAL

        # Record successes while in cooldown (trust stays frozen at PROVISIONAL)
        for _ in range(10):
            registry.record_settlement("agent-1", success=True)
        assert agent.trust_level == TrustLevel.PROVISIONAL  # still in cooldown

        # Now expire the cooldown — rolling window is clean (all successes)
        agent.cooldown_until = time.time() - 1

        # Next settlement triggers recalculation with clean rolling window
        registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        # Should be re-promoted since cooldown expired and rolling window is clean
        assert agent.trust_level in (TrustLevel.TRUSTED, TrustLevel.SENIOR)

    def test_double_fault_escalation(self, registry: AgentRegistry) -> None:
        """Already PROVISIONAL + rolling failure -> UNTRUSTED + under_review."""
        registry.register("agent-1")
        # Get to PROVISIONAL with enough successes to stay there through initial failures
        for _ in range(20):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        # 20S gives Bayesian lb=0.80, which is PROVISIONAL (not TRUSTED since < 0.82)
        assert agent.trust_level == TrustLevel.PROVISIONAL

        # First demotion: 3 failures triggers rolling < 80%
        for _ in range(3):
            registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        # Agent was PROVISIONAL, circuit breaker targets PROVISIONAL -> double-fault
        assert agent.trust_level == TrustLevel.UNTRUSTED
        assert agent.under_review is True
        assert "agent-1" in registry.review_queue

    def test_exponential_cooldown(self, registry: AgentRegistry) -> None:
        """Each demotion doubles the cooldown duration (up to 24h cap)."""
        registry.register("agent-1")
        for _ in range(50):
            registry.record_settlement("agent-1", success=True)

        # First demotion
        for _ in range(3):
            registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        first_cooldown = agent.cooldown_until
        assert first_cooldown is not None

        # Clear cooldown + add successes to recover
        agent.cooldown_until = time.time() - 1
        for _ in range(15):
            registry.record_settlement("agent-1", success=True)

        # Second demotion
        for _ in range(5):
            registry.record_settlement("agent-1", success=False)
        agent = registry.get("agent-1")
        assert agent.demotion_count >= 2


class TestToolPermissions:
    """Tests for MCP tool permission system."""

    @pytest.mark.parametrize(
        "role, tool, expected",
        [
            (AgentRole.WORKER, "settle_action", True),
            (AgentRole.WORKER, "ledger_status", False),
            (AgentRole.ORCHESTRATOR, "ledger_status", True),
            (AgentRole.VALIDATOR, "settle_action", False),
            (AgentRole.AUDITOR, "settle_action", False),
            (AgentRole.SPECIALIST, "check_settlement", True),
        ],
        ids=[
            "worker-settle",
            "worker-no-ledger-status",
            "orchestrator-ledger-status",
            "validator-no-settle",
            "auditor-no-settle",
            "specialist-check",
        ],
    )
    def test_role_default_tools(
        self, registry: AgentRegistry, role: AgentRole, tool: str, expected: bool,
    ) -> None:
        registry.register("agent-1", role=role)
        # Promote to PROVISIONAL so trust gate doesn't block settle_action
        for _ in range(8):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.can_use_tool(tool) is expected

    def test_denied_tools_override(self, registry: AgentRegistry) -> None:
        registry.register("agent-1", role=AgentRole.ORCHESTRATOR)
        for _ in range(8):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.can_use_tool("settle_action") is True
        agent.denied_tools.append("settle_action")
        assert agent.can_use_tool("settle_action") is False

    def test_allowed_tools_override_role_defaults(self, registry: AgentRegistry) -> None:
        registry.register("agent-1", role=AgentRole.WORKER)
        for _ in range(8):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        # Worker can't use ledger_status by default
        assert agent.can_use_tool("ledger_status") is False
        # Override with explicit allowed_tools
        agent.allowed_tools = ["settle_action", "check_settlement", "ledger_status"]
        assert agent.can_use_tool("ledger_status") is True

    def test_trust_gate_blocks_untrusted_settle(self, registry: AgentRegistry) -> None:
        """UNTRUSTED agents can't use settle_action regardless of role."""
        registry.register("agent-1", role=AgentRole.ORCHESTRATOR)
        agent = registry.get("agent-1")
        assert agent.trust_level == TrustLevel.UNTRUSTED
        assert agent.can_use_tool("settle_action") is False
        # But check_settlement is gated at UNTRUSTED level
        assert agent.can_use_tool("check_settlement") is True

    def test_unknown_tool_denied(self, registry: AgentRegistry) -> None:
        registry.register("agent-1")
        for _ in range(8):
            registry.record_settlement("agent-1", success=True)
        agent = registry.get("agent-1")
        assert agent.can_use_tool("nonexistent_tool") is False
