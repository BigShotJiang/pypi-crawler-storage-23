"""Tests for the /public/schema endpoint."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from swarm_at.api.main import app


@pytest.fixture()
def client() -> TestClient:
    return TestClient(app)


class TestSchemaEndpoint:
    """Machine-readable schema for agent discovery."""

    def test_returns_200(self, client: TestClient) -> None:
        resp = client.get("/public/schema")
        assert resp.status_code == 200

    def test_no_auth_required(self, client: TestClient) -> None:
        """Schema endpoint works without any auth header."""
        resp = client.get("/public/schema")
        assert resp.status_code == 200

    def test_protocol_name(self, client: TestClient) -> None:
        data = client.get("/public/schema").json()
        assert data["protocol"] == "swarm.at"

    def test_version(self, client: TestClient) -> None:
        data = client.get("/public/schema").json()
        assert data["version"] == "0.1.0"

    def test_has_schemas(self, client: TestClient) -> None:
        data = client.get("/public/schema").json()
        schemas = data["schemas"]
        assert "Proposal" in schemas
        assert "SettlementResult" in schemas
        assert "SettleRequest" in schemas

    def test_proposal_schema_has_properties(self, client: TestClient) -> None:
        data = client.get("/public/schema").json()
        proposal = data["schemas"]["Proposal"]
        assert "properties" in proposal

    def test_guarantees(self, client: TestClient) -> None:
        data = client.get("/public/schema").json()
        guarantees = data["guarantees"]
        assert "determinism" in guarantees
        assert "chain_integrity" in guarantees
        assert "trust_scoring" in guarantees

    def test_tiers(self, client: TestClient) -> None:
        data = client.get("/public/schema").json()
        tiers = data["tiers"]
        assert "sandbox" in tiers
        assert "staging" in tiers
        assert "production" in tiers

    def test_sandbox_tier_is_log_only(self, client: TestClient) -> None:
        data = client.get("/public/schema").json()
        sandbox = data["tiers"]["sandbox"]
        assert sandbox["log_only"] is True
        assert sandbox["write_ledger"] is False

    def test_production_tier_enforces_chain(self, client: TestClient) -> None:
        data = client.get("/public/schema").json()
        prod = data["tiers"]["production"]
        assert prod["enforce_chain"] is True
        assert prod["enforce_confidence"] is True
