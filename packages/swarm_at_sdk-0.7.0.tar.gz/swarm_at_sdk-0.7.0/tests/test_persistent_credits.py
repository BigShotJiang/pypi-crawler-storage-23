"""Tests for PersistentCreditLedger — file-backed credit tracking."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from swarm_at.credits import CreditError, PersistentCreditLedger


class TestPersistence:
    def test_register_persists(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        ledger = PersistentCreditLedger(path=path)
        ledger.register("agent-a", initial_balance=50.0)

        ledger2 = PersistentCreditLedger(path=path)
        assert ledger2.balance("agent-a") == 50.0

    def test_topup_persists(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        ledger = PersistentCreditLedger(path=path)
        ledger.register("agent-a", initial_balance=10.0)
        ledger.topup("agent-a", 25.0)

        ledger2 = PersistentCreditLedger(path=path)
        assert ledger2.balance("agent-a") == 35.0

    def test_debit_persists(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        ledger = PersistentCreditLedger(path=path)
        ledger.register("agent-a", initial_balance=100.0)
        ledger.debit("agent-a", 30.0)

        ledger2 = PersistentCreditLedger(path=path)
        assert ledger2.balance("agent-a") == 70.0

    def test_multiple_ops_replay_in_order(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        ledger = PersistentCreditLedger(path=path)
        ledger.register("agent-a", initial_balance=100.0)
        ledger.debit("agent-a", 20.0)
        ledger.topup("agent-a", 50.0)
        ledger.debit("agent-a", 10.0)

        ledger2 = PersistentCreditLedger(path=path)
        assert ledger2.balance("agent-a") == 120.0  # 100 - 20 + 50 - 10

    def test_multiple_agents_persist(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        ledger = PersistentCreditLedger(path=path)
        ledger.register("a", initial_balance=50.0)
        ledger.register("b", initial_balance=200.0)
        ledger.debit("b", 75.0)

        ledger2 = PersistentCreditLedger(path=path)
        assert ledger2.balance("a") == 50.0
        assert ledger2.balance("b") == 125.0


class TestFileGrowth:
    def test_append_only(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        ledger = PersistentCreditLedger(path=path)
        ledger.register("a", initial_balance=10.0)
        lines_after_register = len(path.read_text().splitlines())
        ledger.topup("a", 5.0)
        lines_after_topup = len(path.read_text().splitlines())
        assert lines_after_topup == lines_after_register + 1

    def test_events_are_valid_json(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        ledger = PersistentCreditLedger(path=path)
        ledger.register("a", initial_balance=50.0)
        ledger.topup("a", 10.0)
        ledger.debit("a", 5.0)

        for line in path.read_text().splitlines():
            event = json.loads(line)
            assert "event" in event
            assert "agent_id" in event


class TestReplayEdgeCases:
    def test_empty_file(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        path.write_text("")
        ledger = PersistentCreditLedger(path=path)
        assert ledger.all_balances() == {}

    def test_missing_file(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        ledger = PersistentCreditLedger(path=path)
        assert ledger.all_balances() == {}

    def test_corrupt_line_skipped(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        path.write_text(
            '{"event":"register","agent_id":"a","balance":50.0}\n'
            "not valid json\n"
            '{"event":"topup","agent_id":"a","amount":10.0}\n'
        )
        ledger = PersistentCreditLedger(path=path)
        assert ledger.balance("a") == 60.0

    def test_duplicate_register_idempotent(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        ledger = PersistentCreditLedger(path=path)
        ledger.register("a", initial_balance=50.0)
        ledger.register("a", initial_balance=999.0)  # ignored
        assert ledger.balance("a") == 50.0

    def test_debit_error_not_persisted(self, tmp_path: Path) -> None:
        path = tmp_path / "credits.jsonl"
        ledger = PersistentCreditLedger(path=path)
        ledger.register("a", initial_balance=10.0)
        with pytest.raises(CreditError):
            ledger.debit("a", 999.0)
        lines = len(path.read_text().splitlines())
        assert lines == 1  # only the register event
