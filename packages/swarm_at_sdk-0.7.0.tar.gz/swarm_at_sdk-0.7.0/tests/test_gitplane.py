"""Tests for Git-Native Data Plane: git-backed ledger with branching."""

from __future__ import annotations

import subprocess
import time
from pathlib import Path

import pytest

from swarm_at.gitplane import GitLedger
from swarm_at.models import LedgerEntry
from swarm_at.settler import GENESIS_HASH, generate_hash


def make_entry(parent_hash: str = GENESIS_HASH, task_id: str = "task-1") -> LedgerEntry:
    """Create a test ledger entry with valid hash chain."""
    entry_dict = {
        "timestamp": time.time(),
        "task_id": task_id,
        "parent_hash": parent_hash,
        "payload": {"result": "test"},
        "current_hash": "",
    }
    entry_dict["current_hash"] = generate_hash(entry_dict)
    return LedgerEntry.model_validate(entry_dict)


class TestGitLedgerBasics:
    def test_initializes_git_repo(self, git_ledger: GitLedger) -> None:
        assert (git_ledger.repo_path / ".git").exists()

    def test_get_latest_hash_returns_genesis_on_empty(self, git_ledger: GitLedger) -> None:
        assert git_ledger.get_latest_hash() == GENESIS_HASH

    def test_append_entry_writes_to_jsonl_and_commits(self, git_ledger: GitLedger) -> None:
        entry = make_entry()
        git_ledger.append_entry(entry)

        # Check file exists and has content
        assert git_ledger.path.exists()
        content = git_ledger.path.read_text()
        assert entry.task_id in content

        # Check git commit was created
        log = git_ledger.log(max_entries=1)
        assert len(log) >= 1
        assert "Settle: task-1" in log[0]["message"]

    def test_read_all_returns_appended_entries(self, git_ledger: GitLedger) -> None:
        entry1 = make_entry(task_id="task-1")
        entry2 = make_entry(parent_hash=entry1.current_hash, task_id="task-2")

        git_ledger.append_entry(entry1)
        git_ledger.append_entry(entry2)

        entries = git_ledger.read_all()
        assert len(entries) == 2
        assert entries[0].task_id == "task-1"
        assert entries[1].task_id == "task-2"

    def test_verify_chain_passes_on_valid_chain(self, git_ledger: GitLedger) -> None:
        entry1 = make_entry()
        entry2 = make_entry(parent_hash=entry1.current_hash, task_id="task-2")

        git_ledger.append_entry(entry1)
        git_ledger.append_entry(entry2)

        assert git_ledger.verify_chain() is True


class TestBranching:
    def test_create_branch_creates_new_branch(self, git_ledger: GitLedger) -> None:
        new_ledger = git_ledger.create_branch("feature-1")

        branches = git_ledger.branches()
        assert "feature-1" in branches
        assert new_ledger.branch == "feature-1"

    def test_branches_lists_all_branches(self, git_ledger: GitLedger) -> None:
        git_ledger.create_branch("branch-a")
        git_ledger.create_branch("branch-b")

        branches = git_ledger.branches()
        assert "main" in branches
        assert "branch-a" in branches
        assert "branch-b" in branches

    def test_separate_branches_have_independent_ledgers(self, git_ledger: GitLedger) -> None:
        # Append to main branch
        entry1 = make_entry(task_id="main-task")
        git_ledger.append_entry(entry1)

        # Create branch and append to it
        branch_ledger = git_ledger.create_branch("feature")
        entry2 = make_entry(task_id="feature-task")
        branch_ledger.append_entry(entry2)

        # Main should only have main-task
        main_entries = git_ledger.read_all()
        assert len(main_entries) == 1
        assert main_entries[0].task_id == "main-task"

        # Feature should have both (inherited + new)
        feature_entries = branch_ledger.read_all()
        assert len(feature_entries) == 2
        assert feature_entries[0].task_id == "main-task"
        assert feature_entries[1].task_id == "feature-task"

    def test_branch_created_from_specific_base_inherits_entries(self, git_ledger: GitLedger) -> None:
        # Setup: main with 1 entry
        entry1 = make_entry(task_id="main-1")
        git_ledger.append_entry(entry1)

        # Create feature-a from main and add entry
        feature_a = git_ledger.create_branch("feature-a")
        entry2 = make_entry(parent_hash=entry1.current_hash, task_id="feature-a-1")
        feature_a.append_entry(entry2)

        # Create feature-b from feature-a (should inherit both entries)
        feature_b = feature_a.create_branch("feature-b", from_branch="feature-a")

        entries = feature_b.read_all()
        assert len(entries) == 2
        assert entries[0].task_id == "main-1"
        assert entries[1].task_id == "feature-a-1"


class TestMerging:
    def test_merge_non_conflicting_branch_succeeds(self, git_ledger: GitLedger) -> None:
        # Main has entry 1
        entry1 = make_entry(task_id="main-1")
        git_ledger.append_entry(entry1)

        # Feature branch has entry 2
        feature = git_ledger.create_branch("feature")
        entry2 = make_entry(parent_hash=entry1.current_hash, task_id="feature-1")
        feature.append_entry(entry2)

        # Merge feature into main
        result = git_ledger.merge("feature")

        assert result.success is True
        assert result.branch == "feature"
        assert len(result.conflicts) == 0

        # Main should now have both entries
        entries = git_ledger.read_all()
        assert len(entries) == 2

    def test_merge_conflicting_branch_resolves_deterministically(self, git_ledger: GitLedger) -> None:
        # Main has entry 1
        entry1 = make_entry(task_id="main-1")
        git_ledger.append_entry(entry1)

        # Create feature branch
        feature = git_ledger.create_branch("feature")

        # Both branches add different entries at same position
        # Main adds entry 2
        entry2_main = make_entry(parent_hash=entry1.current_hash, task_id="main-2")
        git_ledger.append_entry(entry2_main)

        # Feature adds entry 2 (different)
        entry2_feature = make_entry(parent_hash=entry1.current_hash, task_id="feature-2")
        feature.append_entry(entry2_feature)

        # Merge feature into main — should resolve deterministically
        result = git_ledger.merge("feature")

        assert result.success is True
        assert result.branch == "feature"

        # Both entries should be present (common prefix + merged divergent)
        entries = git_ledger.read_all()
        task_ids = [e.task_id for e in entries]
        assert "main-1" in task_ids
        assert "main-2" in task_ids
        assert "feature-2" in task_ids

    def test_diff_branches_shows_differences(self, git_ledger: GitLedger) -> None:
        # Main has entry 1
        entry1 = make_entry(task_id="main-1")
        git_ledger.append_entry(entry1)

        # Feature has entry 2
        feature = git_ledger.create_branch("feature")
        entry2 = make_entry(parent_hash=entry1.current_hash, task_id="feature-1")
        feature.append_entry(entry2)

        # Get diff from main's perspective
        diff = git_ledger.diff_branches("feature")

        # Diff should show the feature entry being added
        assert "task-id" in diff.lower() or "feature-1" in diff


class TestHistory:
    def test_log_returns_commit_entries(self, git_ledger: GitLedger) -> None:
        entry1 = make_entry(task_id="task-1")
        entry2 = make_entry(parent_hash=entry1.current_hash, task_id="task-2")

        git_ledger.append_entry(entry1)
        git_ledger.append_entry(entry2)

        log = git_ledger.log()

        # Should have at least 3 commits: init + 2 entries
        assert len(log) >= 3
        # Most recent commits should be our settlements
        assert "Settle: task-2" in log[0]["message"]
        assert "Settle: task-1" in log[1]["message"]

    def test_log_respects_max_entries_limit(self, git_ledger: GitLedger) -> None:
        # Add several entries
        prev_hash = GENESIS_HASH
        for i in range(5):
            entry = make_entry(parent_hash=prev_hash, task_id=f"task-{i}")
            git_ledger.append_entry(entry)
            prev_hash = entry.current_hash

        # Request only 3 log entries
        log = git_ledger.log(max_entries=3)

        assert len(log) == 3


class TestRemotePush:
    """Remote push after append_entry."""

    @pytest.fixture()
    def bare_remote(self, tmp_path: Path) -> Path:
        """Create a bare git repo to act as remote."""
        bare = tmp_path / "remote.git"
        bare.mkdir()
        subprocess.run(
            ["git", "init", "--bare"],
            cwd=bare,
            capture_output=True,
            check=True,
        )
        return bare

    @pytest.fixture()
    def remote_ledger(self, tmp_path: Path, bare_remote: Path) -> "GitLedger":
        """GitLedger configured with a local bare remote."""
        return GitLedger(
            repo_path=tmp_path / "push_repo",
            remote_url=str(bare_remote),
        )

    def test_push_to_remote_after_append(
        self, remote_ledger: GitLedger, bare_remote: Path,
    ) -> None:
        import time as _time

        entry = make_entry(task_id="remote-1")
        remote_ledger.append_entry(entry)
        # Wait for async push to complete
        _time.sleep(0.5)

        # Verify the remote has the commit
        result = subprocess.run(
            ["git", "log", "--oneline", "main"],
            cwd=bare_remote,
            capture_output=True,
            text=True,
            check=True,
        )
        assert "Settle: remote-1" in result.stdout

    def test_push_failure_does_not_block_append(self, tmp_path: Path) -> None:
        """Push to invalid remote fails silently, append still works."""
        ledger = GitLedger(
            repo_path=tmp_path / "bad_remote_repo",
            remote_url="https://invalid.example.com/repo.git",
        )
        entry = make_entry(task_id="no-block-1")
        # Should not raise despite bad remote
        ledger.append_entry(entry)
        # Entry was written to local ledger
        entries = ledger.read_all()
        assert len(entries) == 1
        assert entries[0].task_id == "no-block-1"

    def test_no_push_without_remote_url(self, git_ledger: GitLedger) -> None:
        """GitLedger without remote_url doesn't attempt push."""
        assert git_ledger.remote_url == ""
        entry = make_entry(task_id="local-only")
        git_ledger.append_entry(entry)
        # No remote configured, should have no origin
        result = subprocess.run(
            ["git", "remote"],
            cwd=git_ledger.repo_path,
            capture_output=True,
            text=True,
        )
        assert "origin" not in result.stdout


class TestFreeze:
    """Tests for ledger freeze / unfreeze kill-switch."""

    def test_freeze_creates_marker_file(self, git_ledger: GitLedger) -> None:
        git_ledger.freeze("security incident")
        assert git_ledger.is_frozen is True
        assert (git_ledger.repo_path / "FROZEN").exists()
        assert (git_ledger.repo_path / "FROZEN").read_text() == "security incident"

    def test_frozen_ledger_rejects_writes(self, git_ledger: GitLedger) -> None:
        git_ledger.freeze("lockdown")
        entry = make_entry(task_id="blocked")
        from swarm_at.gitplane import GitPlaneError
        with pytest.raises(GitPlaneError, match="frozen"):
            git_ledger.append_entry(entry)

    def test_freeze_records_ledger_event(self, git_ledger: GitLedger) -> None:
        git_ledger.freeze("audit required")
        entries = git_ledger.read_all()
        assert any(e.payload.get("type") == "ledger_freeze" for e in entries)

    def test_frozen_ledger_allows_reads(self, git_ledger: GitLedger) -> None:
        entry = make_entry(task_id="before-freeze")
        git_ledger.append_entry(entry)
        git_ledger.freeze("read-only mode")
        entries = git_ledger.read_all()
        assert len(entries) >= 1

    def test_unfreeze_allows_writes_again(self, git_ledger: GitLedger) -> None:
        git_ledger.freeze("temporary")
        git_ledger.unfreeze()
        assert git_ledger.is_frozen is False
        entry = make_entry(
            task_id="after-unfreeze",
            parent_hash=git_ledger.get_latest_hash(),
        )
        git_ledger.append_entry(entry)
        entries = git_ledger.read_all()
        task_ids = [e.task_id for e in entries]
        assert "after-unfreeze" in task_ids

    def test_freeze_survives_new_instance(self, tmp_path: Path) -> None:
        """Freeze persists across GitLedger instances (file-based)."""
        ledger1 = GitLedger(repo_path=tmp_path / "freeze_repo")
        ledger1.freeze("persistent")
        # Create new instance pointing to same repo
        ledger2 = GitLedger(repo_path=tmp_path / "freeze_repo")
        assert ledger2.is_frozen is True

    def test_double_freeze_raises(self, git_ledger: GitLedger) -> None:
        from swarm_at.gitplane import GitPlaneError
        git_ledger.freeze("first")
        with pytest.raises(GitPlaneError, match="already frozen"):
            git_ledger.freeze("second")

    def test_unfreeze_not_frozen_raises(self, git_ledger: GitLedger) -> None:
        from swarm_at.gitplane import GitPlaneError
        with pytest.raises(GitPlaneError, match="not frozen"):
            git_ledger.unfreeze()

    def test_freeze_commits_to_git(self, git_ledger: GitLedger) -> None:
        git_ledger.freeze("audit")
        log = git_ledger.log(max_entries=1)
        assert "Freeze" in log[0]["message"]

    def test_unfreeze_records_event(self, git_ledger: GitLedger) -> None:
        git_ledger.freeze("temp")
        git_ledger.unfreeze()
        entries = git_ledger.read_all()
        assert any(e.payload.get("type") == "ledger_unfreeze" for e in entries)


class TestConflictResolution:
    """Tests for deterministic conflict resolution during merge."""

    def test_conflict_preserves_all_entries(self, git_ledger: GitLedger) -> None:
        """Both sides' entries survive conflict resolution."""
        entry1 = make_entry(task_id="common")
        git_ledger.append_entry(entry1)
        feature = git_ledger.create_branch("feat")

        entry_main = make_entry(parent_hash=entry1.current_hash, task_id="main-only")
        git_ledger.append_entry(entry_main)

        entry_feat = make_entry(parent_hash=entry1.current_hash, task_id="feat-only")
        feature.append_entry(entry_feat)

        result = git_ledger.merge("feat")
        assert result.success is True
        entries = git_ledger.read_all()
        task_ids = [e.task_id for e in entries]
        assert "common" in task_ids
        assert "main-only" in task_ids
        assert "feat-only" in task_ids

    def test_resolved_entries_sorted_by_timestamp(self, git_ledger: GitLedger) -> None:
        """Divergent entries are sorted by timestamp for deterministic ordering."""
        entry1 = make_entry(task_id="root")
        git_ledger.append_entry(entry1)
        feature = git_ledger.create_branch("feat")

        import time as _time
        entry_main = make_entry(parent_hash=entry1.current_hash, task_id="main-later")
        git_ledger.append_entry(entry_main)

        _time.sleep(0.01)
        entry_feat = make_entry(parent_hash=entry1.current_hash, task_id="feat-later")
        feature.append_entry(entry_feat)

        result = git_ledger.merge("feat")
        assert result.success is True

    def test_merged_chain_is_valid(self, git_ledger: GitLedger) -> None:
        """Hash chain remains valid after conflict resolution."""
        entry1 = make_entry(task_id="base")
        git_ledger.append_entry(entry1)
        feature = git_ledger.create_branch("feat")

        entry_main = make_entry(parent_hash=entry1.current_hash, task_id="main-e")
        git_ledger.append_entry(entry_main)

        entry_feat = make_entry(parent_hash=entry1.current_hash, task_id="feat-e")
        feature.append_entry(entry_feat)

        git_ledger.merge("feat")
        # The chain should verify after merge
        assert git_ledger.verify_chain() is True

    def test_no_duplicates_after_merge(self, git_ledger: GitLedger) -> None:
        """Common prefix entries are not duplicated."""
        entry1 = make_entry(task_id="shared")
        git_ledger.append_entry(entry1)
        feature = git_ledger.create_branch("feat")

        entry_main = make_entry(parent_hash=entry1.current_hash, task_id="m-1")
        git_ledger.append_entry(entry_main)

        entry_feat = make_entry(parent_hash=entry1.current_hash, task_id="f-1")
        feature.append_entry(entry_feat)

        git_ledger.merge("feat")
        entries = git_ledger.read_all()
        # Should have exactly 3: shared + m-1 + f-1
        assert len(entries) == 3

    def test_fast_forward_merge_still_works(self, git_ledger: GitLedger) -> None:
        """Non-conflicting merge (fast-forward) still succeeds."""
        entry1 = make_entry(task_id="base-ff")
        git_ledger.append_entry(entry1)

        feature = git_ledger.create_branch("ff-feat")
        entry_feat = make_entry(parent_hash=entry1.current_hash, task_id="ff-entry")
        feature.append_entry(entry_feat)

        result = git_ledger.merge("ff-feat")
        assert result.success is True
        entries = git_ledger.read_all()
        assert len(entries) == 2
