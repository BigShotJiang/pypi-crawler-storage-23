"""Tests for Collective Consensus (Molt logic)."""

from __future__ import annotations

from pathlib import Path

import pytest

from swarm_at.consensus import ConsensusEngine, ConsensusError, StakeStatus
from swarm_at.engine import SwarmAtEngine
from swarm_at.settler import Ledger

from tests.conftest import make_proposal


class TestStaking:
    def test_stake_creates_round(self, consensus: ConsensusEngine) -> None:
        round_ = consensus.stake("task-1", "agent-A", make_proposal())
        assert round_.status == StakeStatus.STAKED
        assert round_.stake is not None
        assert round_.stake.agent_id == "agent-A"

    def test_cannot_double_stake(self, consensus: ConsensusEngine) -> None:
        consensus.stake("task-1", "agent-A", make_proposal())
        with pytest.raises(ConsensusError, match="already has an active stake"):
            consensus.stake("task-1", "agent-B", make_proposal())

    def test_can_restake_after_contest(self, consensus: ConsensusEngine) -> None:
        consensus.stake("task-1", "agent-A", make_proposal(data={"answer": "wrong"}))
        consensus.verify("task-1", "agent-B", agrees=False, reason="bad answer")
        consensus.verify("task-1", "agent-C", agrees=False, reason="also disagree")
        round_check = consensus.get_round("task-1")
        assert round_check is not None
        assert round_check.status == StakeStatus.CONTESTED
        round_ = consensus.stake("task-1", "agent-D", make_proposal(data={"answer": "correct"}))
        assert round_.status == StakeStatus.STAKED


class TestVerification:
    def test_agree_reaches_consensus(self, consensus: ConsensusEngine) -> None:
        consensus.stake("task-1", "agent-A", make_proposal())
        consensus.verify("task-1", "agent-B", agrees=True)
        round_ = consensus.verify("task-1", "agent-C", agrees=True)
        assert round_.status == StakeStatus.FINALIZED
        assert round_.settled_hash is not None

    @pytest.mark.parametrize(
        "error_scenario, agent_id, match",
        [
            ("self-verify", "agent-A", "cannot verify their own"),
            ("duplicate", "agent-B", "already verified"),
            ("nonexistent", "agent-X", "No active stake"),
        ],
        ids=["self-verify", "duplicate", "nonexistent"],
    )
    def test_verification_errors(
        self, consensus: ConsensusEngine, error_scenario: str, agent_id: str, match: str
    ) -> None:
        if error_scenario != "nonexistent":
            consensus.stake("task-1", "agent-A", make_proposal())
        if error_scenario == "duplicate":
            consensus.verify("task-1", "agent-B", agrees=True)
        task = "task-1" if error_scenario != "nonexistent" else "nope"
        with pytest.raises(ConsensusError, match=match):
            consensus.verify(task, agent_id, agrees=True)

    def test_contest_with_counter_proposal(self, consensus: ConsensusEngine) -> None:
        consensus.stake("task-1", "agent-A", make_proposal(data={"answer": "42"}))
        counter = make_proposal(data={"answer": "43"})
        round_ = consensus.verify("task-1", "agent-B", agrees=False, counter_proposal=counter)
        assert round_.verifications[0].agrees is False

    def test_cannot_verify_finalized(self, consensus: ConsensusEngine) -> None:
        consensus.stake("task-1", "agent-A", make_proposal())
        consensus.verify("task-1", "agent-B", agrees=True)
        consensus.verify("task-1", "agent-C", agrees=True)
        with pytest.raises(ConsensusError, match="already finalized"):
            consensus.verify("task-1", "agent-D", agrees=True)


class TestConsensusEngine:
    def test_active_rounds(self, consensus: ConsensusEngine) -> None:
        consensus.stake("task-1", "agent-A", make_proposal())
        consensus.stake("task-2", "agent-B", make_proposal())
        assert len(consensus.active_rounds()) == 2

    def test_finalized_not_in_active(self, consensus: ConsensusEngine) -> None:
        consensus.stake("task-1", "agent-A", make_proposal())
        consensus.verify("task-1", "agent-B", agrees=True)
        consensus.verify("task-1", "agent-C", agrees=True)
        assert len(consensus.active_rounds()) == 0

    @pytest.mark.parametrize("required", [1, 2, 3])
    def test_verification_threshold(self, tmp_path: Path, required: int) -> None:
        ledger = Ledger(path=tmp_path / f"threshold_{required}.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        c = ConsensusEngine(engine=engine, required_verifications=required)
        c.stake("task-1", "agent-A", make_proposal())
        for i in range(required):
            round_ = c.verify("task-1", f"agent-{i}", agrees=True)
        assert round_.status == StakeStatus.FINALIZED

    def test_ledger_integrity_after_consensus(self, consensus: ConsensusEngine) -> None:
        consensus.stake("task-1", "agent-A", make_proposal())
        consensus.verify("task-1", "agent-B", agrees=True)
        consensus.verify("task-1", "agent-C", agrees=True)
        assert consensus.engine.ledger.verify_chain() is True
