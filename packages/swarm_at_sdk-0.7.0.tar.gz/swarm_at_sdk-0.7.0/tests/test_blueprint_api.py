"""Tests for public blueprint API endpoints."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.api.main import app
from swarm_at.blueprints import BlueprintStore
from swarm_at.seed_blueprints import seed_blueprints


@pytest.fixture()
def api_client() -> TestClient:
    return TestClient(app)


@pytest.fixture()
def seeded_store() -> BlueprintStore:
    """Seed the API state blueprint store with canonical blueprints."""
    seed_blueprints(api_state.blueprint_store)
    return api_state.blueprint_store


class TestListBlueprints:
    """GET /public/blueprints"""

    def test_empty_store_returns_empty(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/blueprints")
        assert resp.status_code == 200
        data = resp.json()
        assert data["blueprints"] == []
        assert data["total"] == 0

    def test_seeded_store_returns_all(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        resp = api_client.get("/public/blueprints")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 48
        assert len(data["blueprints"]) == 48

    def test_filter_by_tag(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        resp = api_client.get("/public/blueprints?tag=audit")
        data = resp.json()
        assert data["total"] == 4
        assert any(bp["blueprint_id"] == "audit-chain" for bp in data["blueprints"])

    def test_filter_by_unknown_tag(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        resp = api_client.get("/public/blueprints?tag=nonexistent")
        data = resp.json()
        assert data["total"] == 0

    def test_pagination(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        resp = api_client.get("/public/blueprints?page=1&page_size=2")
        data = resp.json()
        assert len(data["blueprints"]) == 2
        assert data["has_more"] is True

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/public/blueprints")
        assert resp.status_code == 200

    def test_response_shape(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        resp = api_client.get("/public/blueprints")
        bp = resp.json()["blueprints"][0]
        for field in ["blueprint_id", "name", "description", "tags", "step_count", "validated", "credit_cost", "fork_count"]:
            assert field in bp, f"Missing field: {field}"


class TestBlueprintDetail:
    """GET /public/blueprints/{blueprint_id}"""

    def test_returns_detail(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        resp = api_client.get("/public/blueprints/audit-chain")
        assert resp.status_code == 200
        data = resp.json()
        assert data["blueprint_id"] == "audit-chain"
        assert len(data["steps"]) == 3

    def test_includes_fork_count(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        resp = api_client.get("/public/blueprints/audit-chain")
        data = resp.json()
        assert "fork_count" in data
        assert data["fork_count"] == 0

    def test_step_structure(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        resp = api_client.get("/public/blueprints/code-review-pipeline")
        steps = resp.json()["steps"]
        step = steps[0]
        for field in ["step_id", "name", "description", "depends_on", "agent_role", "complexity"]:
            assert field in step, f"Missing step field: {field}"

    def test_not_found(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/blueprints/nonexistent")
        assert resp.status_code == 404

    def test_includes_validated_status(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        resp = api_client.get("/public/blueprints/research-workflow")
        data = resp.json()
        assert data["validated"] is True

    def test_no_auth_required(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.get("/public/blueprints/audit-chain")
        assert resp.status_code == 200
