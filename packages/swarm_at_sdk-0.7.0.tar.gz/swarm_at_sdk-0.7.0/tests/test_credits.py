"""Tests for credit tracking module."""

from __future__ import annotations

import pytest

from swarm_at.credits import CreditError, CreditLedger, check_blueprint_cost


class TestCreditLedger:
    """Test CreditLedger accounting operations."""

    def test_register_creates_entry_with_default_balance(self) -> None:
        """Register creates new agent with default balance."""
        ledger = CreditLedger(default_balance=100.0)
        balance = ledger.register("agent1")
        assert balance == 100.0
        assert ledger.balance("agent1") == 100.0

    def test_register_with_custom_balance(self) -> None:
        """Register can set custom initial balance."""
        ledger = CreditLedger(default_balance=100.0)
        balance = ledger.register("agent1", initial_balance=250.0)
        assert balance == 250.0
        assert ledger.balance("agent1") == 250.0

    def test_register_existing_agent_is_noop(self) -> None:
        """Register existing agent returns current balance without change."""
        ledger = CreditLedger(default_balance=100.0)
        ledger.register("agent1", initial_balance=150.0)
        # Try re-registering with different balance
        balance = ledger.register("agent1", initial_balance=300.0)
        assert balance == 150.0  # Original balance unchanged
        assert ledger.balance("agent1") == 150.0

    def test_balance_returns_correct_amount(self) -> None:
        """Balance returns current credit amount."""
        ledger = CreditLedger(default_balance=100.0)
        ledger.register("agent1", initial_balance=75.5)
        assert ledger.balance("agent1") == 75.5

    def test_balance_unknown_agent_raises_credit_error(self) -> None:
        """Balance raises CreditError for unregistered agent."""
        ledger = CreditLedger()
        with pytest.raises(CreditError, match="Agent unknown not registered"):
            ledger.balance("unknown")

    def test_topup_adds_credits(self) -> None:
        """Topup adds credits to existing balance."""
        ledger = CreditLedger(default_balance=100.0)
        ledger.register("agent1")
        new_balance = ledger.topup("agent1", 50.0)
        assert new_balance == 150.0
        assert ledger.balance("agent1") == 150.0

    def test_topup_creates_new_agent_if_not_exists(self) -> None:
        """Topup auto-registers agent with default balance then adds amount."""
        ledger = CreditLedger(default_balance=100.0)
        new_balance = ledger.topup("agent1", 25.0)
        assert new_balance == 125.0
        assert ledger.balance("agent1") == 125.0

    def test_debit_subtracts_credits(self) -> None:
        """Debit subtracts credits from balance."""
        ledger = CreditLedger(default_balance=100.0)
        ledger.register("agent1")
        new_balance = ledger.debit("agent1", 30.0)
        assert new_balance == 70.0
        assert ledger.balance("agent1") == 70.0

    def test_debit_insufficient_raises_credit_error(self) -> None:
        """Debit raises CreditError when balance insufficient."""
        ledger = CreditLedger(default_balance=100.0)
        ledger.register("agent1")
        with pytest.raises(
            CreditError, match="Insufficient credits.*has 100.*needs 150"
        ):
            ledger.debit("agent1", 150.0)

    def test_debit_unknown_agent_raises_credit_error(self) -> None:
        """Debit raises CreditError for unregistered agent."""
        ledger = CreditLedger()
        with pytest.raises(CreditError, match="Agent unknown not registered"):
            ledger.debit("unknown", 10.0)

    def test_can_afford_returns_true_false(self) -> None:
        """Can_afford checks balance without debiting."""
        ledger = CreditLedger(default_balance=100.0)
        ledger.register("agent1")
        assert ledger.can_afford("agent1", 50.0) is True
        assert ledger.can_afford("agent1", 100.0) is True
        assert ledger.can_afford("agent1", 150.0) is False
        # Balance unchanged
        assert ledger.balance("agent1") == 100.0

    def test_can_afford_unknown_agent_returns_false(self) -> None:
        """Can_afford returns False for unregistered agent."""
        ledger = CreditLedger()
        assert ledger.can_afford("unknown", 10.0) is False

    def test_all_balances_returns_snapshot(self) -> None:
        """All_balances returns dict of all agent balances."""
        ledger = CreditLedger(default_balance=100.0)
        ledger.register("agent1", initial_balance=50.0)
        ledger.register("agent2", initial_balance=75.0)
        ledger.register("agent3")  # Uses default
        balances = ledger.all_balances()
        assert balances == {
            "agent1": 50.0,
            "agent2": 75.0,
            "agent3": 100.0,
        }
        # Verify it's a copy, not reference
        balances["agent1"] = 999.0
        assert ledger.balance("agent1") == 50.0


class TestCheckBlueprintCost:
    """Test blueprint cost checking convenience function."""

    def test_passes_when_agent_can_afford(self) -> None:
        """Check_blueprint_cost passes when balance sufficient."""
        ledger = CreditLedger(default_balance=100.0)
        ledger.register("agent1")
        # Should not raise
        check_blueprint_cost(ledger, "agent1", 50.0)
        check_blueprint_cost(ledger, "agent1", 100.0)

    def test_raises_when_agent_cannot_afford(self) -> None:
        """Check_blueprint_cost raises when balance insufficient."""
        ledger = CreditLedger(default_balance=100.0)
        ledger.register("agent1")
        with pytest.raises(
            CreditError, match="Agent agent1 cannot afford blueprint cost 150"
        ):
            check_blueprint_cost(ledger, "agent1", 150.0)

    def test_raises_when_agent_unknown(self) -> None:
        """Check_blueprint_cost raises for unregistered agent."""
        ledger = CreditLedger()
        with pytest.raises(CreditError, match="cannot afford blueprint cost"):
            check_blueprint_cost(ledger, "unknown", 10.0)
