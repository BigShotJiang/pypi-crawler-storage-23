"""Tests for canonical agent seeding."""

from __future__ import annotations

import pytest

from swarm_at.agents import AgentRegistry, AgentRole, TrustLevel
from swarm_at.seed import CANONICAL_AGENTS, CanonicalAgent, seed_registry


class TestCanonicalAgents:
    """Verify the canonical agent definitions."""

    def test_canonical_agents_count(self) -> None:
        assert len(CANONICAL_AGENTS) == 13

    @pytest.mark.parametrize(
        "agent_id,role",
        [
            ("orchestrator-prime", AgentRole.ORCHESTRATOR),
            ("validator-alpha", AgentRole.VALIDATOR),
            ("auditor-shadow", AgentRole.AUDITOR),
            ("worker-general", AgentRole.WORKER),
            ("specialist-data", AgentRole.SPECIALIST),
        ],
        ids=["orchestrator", "validator", "auditor", "worker", "specialist"],
    )
    def test_agent_roles(self, agent_id: str, role: AgentRole) -> None:
        agent = next(a for a in CANONICAL_AGENTS if a.agent_id == agent_id)
        assert agent.role == role

    def test_orchestrator_is_senior(self) -> None:
        agent = next(a for a in CANONICAL_AGENTS if a.agent_id == "orchestrator-prime")
        assert agent.trust_level == TrustLevel.SENIOR

    def test_all_have_capabilities(self) -> None:
        for agent in CANONICAL_AGENTS:
            assert len(agent.capabilities) > 0


class TestSeedRegistry:
    """Seed a registry and verify trust levels match."""

    def test_seeds_all_agents(self, registry: AgentRegistry) -> None:
        seeded = seed_registry(registry)
        assert len(seeded) == 13
        assert registry.count == 13

    def test_orchestrator_reaches_senior(self, registry: AgentRegistry) -> None:
        seed_registry(registry)
        agent = registry.get("orchestrator-prime")
        assert agent.trust_level == TrustLevel.SENIOR

    def test_workers_reach_trusted(self, registry: AgentRegistry) -> None:
        seed_registry(registry)
        for agent_id in ["validator-alpha", "auditor-shadow", "worker-general", "specialist-data"]:
            agent = registry.get(agent_id)
            assert agent.trust_level in (TrustLevel.TRUSTED, TrustLevel.SENIOR)

    def test_settlement_histories(self, registry: AgentRegistry) -> None:
        seed_registry(registry)
        agent = registry.get("orchestrator-prime")
        assert agent.settlements_completed == 150

    def test_custom_agents(self, registry: AgentRegistry) -> None:
        custom = [
            CanonicalAgent(
                agent_id="custom-bot",
                role=AgentRole.WORKER,
                trust_level=TrustLevel.PROVISIONAL,
                settlement_count=10,
                capabilities=["testing"],
            ),
        ]
        seeded = seed_registry(registry, agents=custom)
        assert len(seeded) == 1
        assert registry.get("custom-bot").settlements_completed == 10

    def test_seed_idempotency_raises(self, registry: AgentRegistry) -> None:
        """Seeding twice raises because agents already exist."""
        seed_registry(registry)
        with pytest.raises(Exception, match="already registered"):
            seed_registry(registry)
