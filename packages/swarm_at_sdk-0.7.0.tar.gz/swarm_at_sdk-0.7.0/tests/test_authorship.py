"""Tests for authorship provenance module."""

from __future__ import annotations

import hashlib
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.api.main import app
from swarm_at.authorship import (
    PHASE_WEIGHTS,
    AgencyLayer,
    AuthorshipEvent,
    ComplianceAssessment,
    CreativePhase,
    ProvenanceReport,
    WritingSession,
)
from swarm_at.engine import SwarmAtEngine
from swarm_at.models import SettlementStatus
from swarm_at.settler import Ledger, content_fingerprint


# ---------------------------------------------------------------------------
# Task 1: Data model — AgencyLayer, CreativePhase, constants
# ---------------------------------------------------------------------------


class TestAgencyLayer:
    """AgencyLayer enum basics."""

    def test_values_are_0_through_5(self) -> None:
        assert AgencyLayer.L0_ORACLE == 0
        assert AgencyLayer.L5_PURE_TOOL == 5

    def test_all_six_layers_exist(self) -> None:
        assert len(AgencyLayer) == 6

    @pytest.mark.parametrize(
        "layer,expected",
        [
            (AgencyLayer.L0_ORACLE, 0.0),
            (AgencyLayer.L2_COLLABORATOR, 0.4),
            (AgencyLayer.L5_PURE_TOOL, 1.0),
        ],
        ids=["L0=0.0", "L2=0.4", "L5=1.0"],
    )
    def test_normalized_score(self, layer: AgencyLayer, expected: float) -> None:
        assert layer.value / 5.0 == expected


class TestCreativePhase:
    """CreativePhase enum and weights."""

    def test_all_six_phases_exist(self) -> None:
        assert len(CreativePhase) == 6

    def test_weights_sum_to_1(self) -> None:
        assert abs(sum(PHASE_WEIGHTS.values()) - 1.0) < 1e-9

    def test_every_phase_has_a_weight(self) -> None:
        for phase in CreativePhase:
            assert phase in PHASE_WEIGHTS

    def test_concept_is_heaviest(self) -> None:
        assert PHASE_WEIGHTS[CreativePhase.CONCEPT] == 0.25

    def test_revision_is_lightest(self) -> None:
        assert PHASE_WEIGHTS[CreativePhase.REVISION] == 0.10


# ---------------------------------------------------------------------------
# Task 2: Internal event model and WritingSession construction
# ---------------------------------------------------------------------------


class TestAuthorshipEvent:
    """Internal event data model."""

    def test_event_has_required_fields(self) -> None:
        event = AuthorshipEvent(
            event_type="creative-direction",
            actor="jane",
            actor_role="writer",
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L4_DIRECTOR,
            settlement_hash="a" * 64,
            metadata={"chose": "noir"},
        )
        assert event.event_type == "creative-direction"
        assert event.actor_role == "writer"
        assert event.timestamp > 0


class TestWritingSessionInit:
    """WritingSession construction."""

    def test_creates_with_writer_and_tool(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane-doe",
            tool="claude-sonnet",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        assert session.writer == "jane-doe"
        assert session.tool == "claude-sonnet"
        assert session.session_id  # non-empty string

    def test_starts_with_no_events(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane-doe",
            tool="claude-sonnet",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        assert len(session.events) == 0

    def test_custom_phase_weights(self, tmp_path: Path) -> None:
        custom = {
            CreativePhase.CONCEPT: 0.50,
            CreativePhase.STRUCTURE: 0.50,
        }
        session = WritingSession(
            writer="jane-doe",
            tool="claude-sonnet",
            phase_weights=custom,
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        assert session.phase_weights[CreativePhase.CONCEPT] == 0.50


# ---------------------------------------------------------------------------
# Task 3: direct() and prompt()
# ---------------------------------------------------------------------------


class TestDirect:
    """WritingSession.direct() — records human creative decisions."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.direct(
            action="outline",
            chose="3-act structure",
            phase=CreativePhase.STRUCTURE,
        )
        assert result.status == SettlementStatus.SETTLED

    def test_records_event(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(action="premise", chose="noir detective")
        assert len(session.events) == 1
        ev = session.events[0]
        assert ev.event_type == "creative-direction"
        assert ev.actor == "jane"
        assert ev.actor_role == "writer"
        assert ev.metadata["chose"] == "noir detective"

    def test_default_agency_is_L4(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(action="theme", chose="revenge")
        assert session.events[0].agency == AgencyLayer.L4_DIRECTOR

    def test_default_phase_is_scene(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(action="blocking", chose="wide shot")
        assert session.events[0].phase == CreativePhase.SCENE

    def test_rejected_options_stored(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(
            action="outline",
            chose="3-act",
            rejected=["listicle", "essay"],
        )
        assert session.events[0].metadata["rejected"] == ["listicle", "essay"]

    def test_custom_agency_override(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(
            action="outline",
            chose="3-act",
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        assert session.events[0].agency == AgencyLayer.L5_PURE_TOOL


class TestPrompt:
    """WritingSession.prompt() — records prompts given to the AI tool."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.prompt(text="Write the opening scene")
        assert result.status == SettlementStatus.SETTLED

    def test_hashes_prompt_text(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.prompt(text="Write the opening scene")
        ev = session.events[0]
        expected_hash = hashlib.sha256(b"Write the opening scene").hexdigest()
        assert ev.metadata["prompt_hash"] == expected_hash
        assert "text" not in ev.metadata  # raw text NOT stored

    def test_default_agency_is_L3(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.prompt(text="anything")
        assert session.events[0].agency == AgencyLayer.L3_SUPERVISOR

    def test_actor_is_writer(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.prompt(text="anything")
        assert session.events[0].actor == "jane"
        assert session.events[0].actor_role == "writer"


# ---------------------------------------------------------------------------
# Task 4: generate(), revise(), reject(), approve()
# ---------------------------------------------------------------------------


class TestGenerate:
    """WritingSession.generate() — records AI output."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.generate(output_hash="a" * 64, model="claude-sonnet")
        assert result.status == SettlementStatus.SETTLED

    def test_actor_is_tool(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.generate(output_hash="a" * 64)
        ev = session.events[0]
        assert ev.actor == "claude"
        assert ev.actor_role == "tool"

    def test_default_agency_is_L1(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.generate(output_hash="a" * 64)
        assert session.events[0].agency == AgencyLayer.L1_EXECUTOR

    def test_stores_model_and_params(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.generate(
            output_hash="a" * 64,
            model="claude-sonnet",
            params={"temperature": 0.7},
        )
        ev = session.events[0]
        assert ev.metadata["model"] == "claude-sonnet"
        assert ev.metadata["params"] == {"temperature": 0.7}


class TestRevise:
    """WritingSession.revise() — records human edits to AI output."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.revise(description="rewrote opening", kept_ratio=0.3)
        assert result.status == SettlementStatus.SETTLED

    def test_stores_kept_ratio(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.revise(description="rewrote opening", kept_ratio=0.3)
        assert session.events[0].metadata["kept_ratio"] == 0.3

    def test_actor_is_writer(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.revise(description="edits", kept_ratio=0.5)
        assert session.events[0].actor_role == "writer"

    @pytest.mark.parametrize(
        "ratio",
        [-0.1, 1.1],
        ids=["below-zero", "above-one"],
    )
    def test_rejects_invalid_kept_ratio(self, tmp_path: Path, ratio: float) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        with pytest.raises(ValueError, match="kept_ratio"):
            session.revise(description="edits", kept_ratio=ratio)


class TestReject:
    """WritingSession.reject() — records rejection of AI output."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.reject(output_hash="b" * 64, reason="too generic")
        assert result.status == SettlementStatus.SETTLED

    def test_agency_is_always_L4(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.reject(output_hash="b" * 64, reason="off-brand")
        assert session.events[0].agency == AgencyLayer.L4_DIRECTOR

    def test_stores_reason(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.reject(output_hash="b" * 64, reason="too generic")
        assert session.events[0].metadata["reason"] == "too generic"


class TestApprove:
    """WritingSession.approve() — records final sign-off."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.approve(content_hash="c" * 64)
        assert result.status == SettlementStatus.SETTLED

    def test_stores_version(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.approve(content_hash="c" * 64, version="final-v1")
        assert session.events[0].metadata["version"] == "final-v1"

    def test_event_type_is_approval(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.approve(content_hash="c" * 64)
        assert session.events[0].event_type == "approval"


# ---------------------------------------------------------------------------
# Task 5: Work agency calculation
# ---------------------------------------------------------------------------


class TestWorkAgency:
    """Work agency: weighted phase scoring from Agency Spectrum framework."""

    def _make_session(self, tmp_path: Path) -> WritingSession:
        return WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )

    def test_empty_session_returns_zero(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        assert session.work_agency == 0.0

    def test_all_L5_returns_1(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(
            action="concept",
            chose="noir",
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        session.direct(
            action="outline",
            chose="3-act",
            phase=CreativePhase.STRUCTURE,
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        assert session.work_agency == 1.0

    def test_all_L0_returns_0(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.generate(
            output_hash="a" * 64,
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L0_ORACLE,
        )
        assert session.work_agency == 0.0

    def test_case_study_a_screenplay(self, tmp_path: Path) -> None:
        """Reproduce Agency Spectrum Case Study A: discrete layer scoring."""
        session = self._make_session(tmp_path)
        # concept: L5
        session.direct(
            action="research",
            chose="topic",
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        # structure: L4
        session.direct(
            action="outline",
            chose="3-act",
            phase=CreativePhase.STRUCTURE,
            agency=AgencyLayer.L4_DIRECTOR,
        )
        # character: L5
        session.direct(
            action="characters",
            chose="detective",
            phase=CreativePhase.CHARACTER,
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        # scene: L3
        session.prompt(
            text="Write scene",
            phase=CreativePhase.SCENE,
            agency=AgencyLayer.L3_SUPERVISOR,
        )
        # dialogue: L2
        session.generate(
            output_hash="a" * 64,
            phase=CreativePhase.DIALOGUE,
            agency=AgencyLayer.L2_COLLABORATOR,
        )
        # revision: L4
        session.revise(
            description="polish",
            kept_ratio=0.5,
            phase=CreativePhase.REVISION,
            agency=AgencyLayer.L4_DIRECTOR,
        )
        # L5=1.0, L4=0.8, L3=0.6, L2=0.4
        expected = (
            1.0 * 0.25  # concept L5
            + 0.8 * 0.20  # structure L4
            + 1.0 * 0.15  # character L5
            + 0.6 * 0.15  # scene L3
            + 0.4 * 0.15  # dialogue L2
            + 0.8 * 0.10  # revision L4
        )
        assert abs(session.work_agency - expected) < 0.01

    def test_single_phase_not_penalized(self, tmp_path: Path) -> None:
        """A session with only concept events should score on concept alone."""
        session = self._make_session(tmp_path)
        session.direct(
            action="premise",
            chose="noir",
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        assert session.work_agency == 1.0

    def test_multiple_events_same_phase_averaged(self, tmp_path: Path) -> None:
        """Two events in same phase get averaged."""
        session = self._make_session(tmp_path)
        session.direct(
            action="a",
            chose="x",
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        session.generate(
            output_hash="a" * 64,
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L1_EXECUTOR,
        )
        # avg of L5 (1.0) and L1 (0.2) = 0.6
        assert abs(session.work_agency - 0.6) < 0.01

    def test_custom_weights_used(self, tmp_path: Path) -> None:
        """Custom weights override defaults."""
        session = WritingSession(
            writer="jane",
            tool="claude",
            phase_weights={
                CreativePhase.CONCEPT: 1.0,  # only concept matters
            },
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(
            action="premise",
            chose="noir",
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L4_DIRECTOR,
        )
        session.generate(
            output_hash="a" * 64,
            phase=CreativePhase.DIALOGUE,
            agency=AgencyLayer.L0_ORACLE,
        )
        # Dialogue has no weight in custom weights, so only concept counts
        assert abs(session.work_agency - 0.8) < 0.01


# ---------------------------------------------------------------------------
# Task 6: Compliance assessment and behavioral flags
# ---------------------------------------------------------------------------


class TestComplianceAssessment:
    """Compliance mapping from work agency to regulatory frameworks."""

    @pytest.mark.parametrize(
        "score,safe_harbor,copyright,market_tier",
        [
            (0.95, True, "Clean", "Premium"),
            (0.90, True, "Clean", "Premium"),
            (0.89, False, "Diluted", "Standard"),
            (0.70, False, "Diluted", "Standard"),
            (0.69, False, "Shared", "Budget"),
            (0.40, False, "Shared", "Budget"),
            (0.39, False, "Absent", "Locked out"),
            (0.0, False, "Absent", "Locked out"),
        ],
        ids=["95%", "90%-boundary", "89%", "70%", "69%", "40%", "39%", "0%"],
    )
    def test_threshold_mapping(
        self,
        score: float,
        safe_harbor: bool,
        copyright: str,
        market_tier: str,
    ) -> None:
        c = ComplianceAssessment.from_score(score)
        assert c.safe_harbor == safe_harbor
        assert copyright in c.copyright
        assert market_tier in c.market_tier


class TestBehavioralFlags:
    """Behavioral constraint detection from session data."""

    def _make_session(self, tmp_path: Path) -> WritingSession:
        return WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )

    def test_no_flags_on_good_session(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.prompt(text="write scene")
        session.generate(output_hash="a" * 64)
        session.revise(description="rewrote", kept_ratio=0.3)
        flags = session.behavioral_flags
        assert not flags.anchoring_risk
        assert not flags.satisficing_risk
        assert not flags.missing_foundation

    def test_anchoring_risk_high_kept_ratio(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.revise(description="minor tweak", kept_ratio=0.9)
        session.revise(description="small edit", kept_ratio=0.85)
        session.revise(description="typo fix", kept_ratio=0.95)
        flags = session.behavioral_flags
        assert flags.anchoring_risk

    def test_no_anchoring_when_low_kept_ratio(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.revise(description="major rewrite", kept_ratio=0.2)
        session.revise(description="overhaul", kept_ratio=0.3)
        flags = session.behavioral_flags
        assert not flags.anchoring_risk

    def test_satisficing_risk_consecutive_generates(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.generate(output_hash="a" * 64)
        session.generate(output_hash="b" * 64)
        session.generate(output_hash="c" * 64)
        flags = session.behavioral_flags
        assert flags.satisficing_risk

    def test_no_satisficing_when_interspersed(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.generate(output_hash="a" * 64)
        session.revise(description="edit", kept_ratio=0.5)
        session.generate(output_hash="b" * 64)
        flags = session.behavioral_flags
        assert not flags.satisficing_risk

    def test_missing_foundation_generate_first(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.generate(output_hash="a" * 64)
        flags = session.behavioral_flags
        assert flags.missing_foundation

    def test_no_missing_foundation_when_direct_first(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.generate(output_hash="a" * 64)
        flags = session.behavioral_flags
        assert not flags.missing_foundation


# ---------------------------------------------------------------------------
# Task 7: Provenance report generation
# ---------------------------------------------------------------------------


class TestProvenanceReport:
    """ProvenanceReport generation from WritingSession."""

    def _make_full_session(self, tmp_path: Path) -> WritingSession:
        session = WritingSession(
            writer="jane-doe",
            tool="claude-sonnet",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(
            action="premise",
            chose="noir",
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        session.prompt(text="write scene", phase=CreativePhase.SCENE)
        session.generate(output_hash="a" * 64, phase=CreativePhase.SCENE)
        session.revise(
            description="rewrote",
            kept_ratio=0.3,
            phase=CreativePhase.SCENE,
        )
        session.approve(content_hash="f" * 64, version="v1")
        return session

    def test_report_returns_provenance_report(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert isinstance(report, ProvenanceReport)

    def test_report_has_correct_counts(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert report.total_events == 5
        assert report.human_events == 4
        assert report.ai_events == 1

    def test_report_has_work_agency(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert 0.0 < report.work_agency <= 1.0

    def test_report_has_compliance(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert isinstance(report.compliance, ComplianceAssessment)

    def test_report_has_chain_verification(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert report.chain_verified is True

    def test_report_has_all_events(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert len(report.events) == 5
        assert report.events[0].event_type == "creative-direction"
        assert report.events[-1].event_type == "approval"

    def test_report_hashes_set(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert len(report.first_hash) == 64
        assert len(report.last_hash) == 64
        assert report.first_hash != report.last_hash

    def test_to_text_contains_key_sections(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        text = report.to_text()
        assert "AUTHORSHIP PROVENANCE REPORT" in text
        assert "jane-doe" in text
        assert "claude-sonnet" in text
        assert "WORK AGENCY" in text
        assert "COMPLIANCE" in text
        assert "CHAIN INTEGRITY" in text
        assert "VERIFIED" in text

    def test_empty_session_report(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        report = session.report()
        assert report.total_events == 0
        assert report.work_agency == 0.0


# ---------------------------------------------------------------------------
# Task 8: Public imports and end-to-end
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Task: Serialization round-trip
# ---------------------------------------------------------------------------


class TestSerialization:
    """WritingSession to_dict / from_dict round-trip."""

    def _make_session(self, tmp_path: Path) -> WritingSession:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(action="premise", chose="noir", phase=CreativePhase.CONCEPT)
        session.prompt(text="Write scene", phase=CreativePhase.SCENE)
        session.generate(output_hash="a" * 64, phase=CreativePhase.SCENE)
        return session

    def test_to_dict_has_required_keys(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        d = session.to_dict()
        for key in ("writer", "tool", "session_id", "events", "started_at", "phase_weights"):
            assert key in d, f"Missing key: {key}"

    def test_to_dict_is_json_safe(self, tmp_path: Path) -> None:
        import json

        session = self._make_session(tmp_path)
        d = session.to_dict()
        json.dumps(d)  # should not raise

    def test_from_dict_round_trip(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        d = session.to_dict()
        restored = WritingSession.from_dict(d, ledger_path=str(tmp_path / "ledger2.jsonl"))
        assert restored.session_id == session.session_id
        assert restored.writer == session.writer
        assert restored.tool == session.tool
        assert len(restored.events) == len(session.events)

    def test_from_dict_preserves_work_agency(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        d = session.to_dict()
        restored = WritingSession.from_dict(d, ledger_path=str(tmp_path / "ledger2.jsonl"))
        assert abs(restored.work_agency - session.work_agency) < 0.01

    def test_empty_session_round_trip(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane",
            tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        d = session.to_dict()
        restored = WritingSession.from_dict(d, ledger_path=str(tmp_path / "ledger2.jsonl"))
        assert len(restored.events) == 0
        assert restored.work_agency == 0.0


class TestPublicImports:
    """Verify WritingSession is importable from swarm_at."""

    def test_import_from_package(self) -> None:
        from swarm_at import WritingSession as WS

        assert WS is WritingSession


class TestEndToEnd:
    """Full session lifecycle: create, record events, generate report."""

    def test_full_screenplay_session(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="mark-ghuneim",
            tool="claude-sonnet-4-5",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )

        # Act 1: Concept and structure (pure human, L5)
        session.direct(
            action="premise",
            chose="AI agency framework explainer",
            rejected=["listicle", "academic paper"],
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        session.direct(
            action="structure",
            chose="six-layer progressive disclosure",
            phase=CreativePhase.STRUCTURE,
            agency=AgencyLayer.L5_PURE_TOOL,
        )

        # Act 2: Drafting with AI assistance (L3-L4)
        session.prompt(
            text="Draft the section on the 90% threshold",
            phase=CreativePhase.SCENE,
        )
        session.generate(
            output_hash="a" * 64,
            model="claude-sonnet-4-5",
            params={"temperature": 0.7},
            phase=CreativePhase.SCENE,
            agency=AgencyLayer.L2_COLLABORATOR,
        )
        session.revise(
            description="Rewrote framing, kept legal citations, cut 40%",
            kept_ratio=0.35,
            phase=CreativePhase.SCENE,
            agency=AgencyLayer.L4_DIRECTOR,
        )

        # Act 3: Dialogue polish (L2-L3)
        session.prompt(
            text="Suggest stakeholder positioning language",
            phase=CreativePhase.DIALOGUE,
        )
        session.generate(
            output_hash="b" * 64,
            phase=CreativePhase.DIALOGUE,
            agency=AgencyLayer.L2_COLLABORATOR,
        )
        session.reject(
            output_hash="b" * 64,
            reason="Too corporate, doesn't match voice",
            phase=CreativePhase.DIALOGUE,
        )

        # Final approval
        session.approve(content_hash="f" * 64, version="v1.0")

        # Verify
        report = session.report()
        assert report.total_events == 9
        assert report.human_events == 7
        assert report.ai_events == 2
        assert report.work_agency > 0.70  # should be well above L3
        assert report.chain_verified
        assert not report.behavioral_flags.missing_foundation
        assert not report.behavioral_flags.anchoring_risk

        # Text report is non-empty and has key sections
        text = report.to_text()
        assert "mark-ghuneim" in text
        assert "claude-sonnet-4-5" in text
        assert "VERIFIED" in text
        assert len(text) > 500


# ---------------------------------------------------------------------------
# Proof of Authorship: content fingerprinting, claims, verification
# ---------------------------------------------------------------------------


class TestContentFingerprint:
    """content_fingerprint() in settler.py."""

    def test_deterministic(self) -> None:
        assert content_fingerprint("hello") == content_fingerprint("hello")

    def test_differs_for_different_content(self) -> None:
        assert content_fingerprint("hello") != content_fingerprint("world")

    def test_returns_64_char_hex(self) -> None:
        h = content_fingerprint("test content")
        assert len(h) == 64
        assert all(c in "0123456789abcdef" for c in h)

    def test_empty_string(self) -> None:
        h = content_fingerprint("")
        assert len(h) == 64


# ---------------------------------------------------------------------------
# TestAuthorshipClaim (engine level)
# ---------------------------------------------------------------------------


class TestAuthorshipClaim:
    """claim_authorship() on SwarmAtEngine."""

    def test_claim_settles(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("my research findings")
        receipt = engine.claim_authorship(agent_id="researcher", content_hash=c_hash)
        assert receipt.status == SettlementStatus.SETTLED
        assert receipt.hash is not None
        assert len(receipt.hash) == 64

    def test_claim_includes_content_hash_in_payload(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("some content")
        engine.claim_authorship(agent_id="agent-a", content_hash=c_hash)
        entries = engine.ledger.read_all()
        assert len(entries) == 1
        payload = entries[0].payload
        assert payload["type"] == "authorship-claim"
        assert payload["content_hash"] == c_hash

    def test_claim_includes_agent_id_in_payload(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("content")
        engine.claim_authorship(agent_id="my-agent", content_hash=c_hash)
        entries = engine.ledger.read_all()
        assert entries[0].payload["agent_id"] == "my-agent"

    def test_claim_chain(self, engine: SwarmAtEngine) -> None:
        h1 = content_fingerprint("first")
        h2 = content_fingerprint("second")
        r1 = engine.claim_authorship(agent_id="agent-a", content_hash=h1)
        r2 = engine.claim_authorship(agent_id="agent-a", content_hash=h2)
        assert r1.status == SettlementStatus.SETTLED
        assert r2.status == SettlementStatus.SETTLED
        assert r1.hash != r2.hash
        entries = engine.ledger.read_all()
        assert entries[1].parent_hash == entries[0].current_hash

    def test_claim_low_confidence_rejected(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("content")
        receipt = engine.claim_authorship(agent_id="agent-a", content_hash=c_hash, confidence=0.5)
        assert receipt.status == SettlementStatus.REJECTED

    def test_receipt_has_content_hash(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("content")
        receipt = engine.claim_authorship(
            agent_id="agent-a", content_hash=c_hash, content_type="text",
        )
        assert receipt.content_hash == c_hash
        assert receipt.content_type == "text"

    def test_receipt_has_agent_id(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("content")
        receipt = engine.claim_authorship(agent_id="claimer", content_hash=c_hash)
        assert receipt.agent_id == "claimer"


# ---------------------------------------------------------------------------
# TestAuthorshipVerification (engine level)
# ---------------------------------------------------------------------------


class TestAuthorshipVerification:
    """verify_authorship() on SwarmAtEngine."""

    def test_verify_existing_claim(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("verified content")
        engine.claim_authorship(agent_id="agent-a", content_hash=c_hash)
        result = engine.verify_authorship(c_hash)
        assert result["verified"] is True
        assert result["agent_id"] == "agent-a"
        assert result["content_hash"] == c_hash
        assert result["settlement_hash"] is not None

    def test_verify_nonexistent_claim(self, engine: SwarmAtEngine) -> None:
        result = engine.verify_authorship("0" * 64)
        assert result["verified"] is False

    def test_verify_with_agent_id_match(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("content")
        engine.claim_authorship(agent_id="agent-a", content_hash=c_hash)
        result = engine.verify_authorship(c_hash, agent_id="agent-a")
        assert result["verified"] is True

    def test_verify_with_agent_id_mismatch(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("content")
        engine.claim_authorship(agent_id="agent-a", content_hash=c_hash)
        result = engine.verify_authorship(c_hash, agent_id="agent-b")
        assert result["verified"] is False

    def test_verify_first_claim_wins(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("content")
        engine.claim_authorship(agent_id="first-agent", content_hash=c_hash)
        engine.claim_authorship(agent_id="second-agent", content_hash=c_hash)
        result = engine.verify_authorship(c_hash)
        assert result["first_claim"]["agent_id"] == "first-agent"
        assert len(result["claims"]) == 2

    def test_verify_competing_claims(self, engine: SwarmAtEngine) -> None:
        c_hash = content_fingerprint("disputed content")
        engine.claim_authorship(agent_id="agent-a", content_hash=c_hash)
        engine.claim_authorship(agent_id="agent-b", content_hash=c_hash)
        result = engine.verify_authorship(c_hash)
        agent_ids = [c["agent_id"] for c in result["claims"]]
        assert "agent-a" in agent_ids
        assert "agent-b" in agent_ids


# ---------------------------------------------------------------------------
# TestAuthorshipAPI
# ---------------------------------------------------------------------------


@pytest.fixture()
def api_client() -> TestClient:
    return TestClient(app)


class TestAuthorshipAPI:
    """Public authorship verification endpoints."""

    def _settle_claim(self, agent_id: str, content: str) -> str:
        """Helper: settle an authorship claim directly on api_state engine."""
        c_hash = content_fingerprint(content)
        receipt = api_state.engine.claim_authorship(agent_id=agent_id, content_hash=c_hash)
        assert receipt.status == SettlementStatus.SETTLED
        return c_hash

    def test_verify_authorship_endpoint(self, api_client: TestClient) -> None:
        c_hash = self._settle_claim("agent-a", "my content")
        resp = api_client.get(f"/public/verify-authorship?content_hash={c_hash}&agent_id=agent-a")
        assert resp.status_code == 200
        data = resp.json()
        assert data["verified"] is True
        assert data["agent_id"] == "agent-a"

    def test_verify_authorship_not_found(self, api_client: TestClient) -> None:
        resp = api_client.get(f"/public/verify-authorship?content_hash={'0' * 64}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["verified"] is False

    def test_authorship_by_content_endpoint(self, api_client: TestClient) -> None:
        c_hash = self._settle_claim("agent-a", "unique content")
        resp = api_client.get(f"/public/authorship/{c_hash}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["content_hash"] == c_hash
        assert len(data["claims"]) == 1
        assert data["first_claim"]["agent_id"] == "agent-a"

    def test_authorship_by_content_empty(self, api_client: TestClient) -> None:
        resp = api_client.get(f"/public/authorship/{'0' * 64}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["claims"] == []
        assert data["first_claim"] is None

    def test_agent_authored_endpoint(self, api_client: TestClient) -> None:
        self._settle_claim("author-agent", "content one")
        self._settle_claim("author-agent", "content two")
        resp = api_client.get("/public/agents/author-agent/authored")
        assert resp.status_code == 200
        data = resp.json()
        assert data["agent_id"] == "author-agent"
        assert data["total"] == 2
        assert len(data["claims"]) == 2

    def test_agent_authored_empty(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/agents/nobody/authored")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        c_hash = self._settle_claim("agent-a", "no auth needed")
        resp = api_client.get(f"/public/verify-authorship?content_hash={c_hash}")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# TestAuthorshipSDK
# ---------------------------------------------------------------------------


class TestAuthorshipSDK:
    """SDK claim_authorship() and verify_authorship()."""

    @pytest.fixture()
    def sdk_client(self):
        from swarm_at.sdk.client import SwarmClient

        test_client = TestClient(app)
        sdk = SwarmClient.__new__(SwarmClient)
        sdk.api_url = "http://testserver"
        sdk._http = test_client
        return sdk

    def test_sdk_claim_authorship(self, sdk_client) -> None:
        result = sdk_client.claim_authorship(
            agent_id="sdk-agent", content="sdk content", content_type="text",
        )
        assert result["status"] == "SETTLED"
        assert result["hash"] is not None
        assert result["content_hash"] == content_fingerprint("sdk content")

    def test_sdk_verify_authorship(self, sdk_client) -> None:
        result = sdk_client.claim_authorship(agent_id="sdk-agent", content="verify me")
        c_hash = result["content_hash"]
        verification = sdk_client.verify_authorship(c_hash, agent_id="sdk-agent")
        assert verification["verified"] is True
        assert verification["agent_id"] == "sdk-agent"


# ---------------------------------------------------------------------------
# TestAuthorshipMCP
# ---------------------------------------------------------------------------


class TestAuthorshipMCP:
    """MCP claim_authorship() and verify_authorship()."""

    @pytest.fixture()
    def mcp_server(self, tmp_path: Path):
        from swarm_at.mcp.server import SettlementMCPServer

        ledger = Ledger(path=tmp_path / "mcp_authorship_ledger.jsonl")
        return SettlementMCPServer(ledger=ledger)

    def test_mcp_claim_authorship(self, mcp_server) -> None:
        result = mcp_server.claim_authorship(
            agent_id="mcp-agent", content="mcp content", content_type="code",
        )
        assert result["claimed"] is True
        assert result["content_hash"] == content_fingerprint("mcp content")
        assert result["settlement_hash"] is not None

    def test_mcp_verify_authorship(self, mcp_server) -> None:
        mcp_server.claim_authorship(agent_id="mcp-agent", content="verify this")
        c_hash = content_fingerprint("verify this")
        result = mcp_server.verify_authorship(c_hash)
        assert result["verified"] is True
        assert result["agent_id"] == "mcp-agent"

    def test_mcp_verify_not_found(self, mcp_server) -> None:
        result = mcp_server.verify_authorship("0" * 64)
        assert result["verified"] is False


# ---------------------------------------------------------------------------
# TestBlueprintAuthorship
# ---------------------------------------------------------------------------


class TestBlueprintAuthorship:
    """Blueprint publish auto-settles authorship claim."""

    @pytest.fixture()
    def authed_client(self) -> TestClient:
        api_state.api_keys = {"sk-test-key"}
        client = TestClient(app)
        client.headers["Authorization"] = "Bearer sk-test-key"
        return client

    def test_publish_creates_authorship_hash(self, authed_client: TestClient) -> None:
        resp = authed_client.post("/v1/blueprints/publish", json={
            "name": "test-bp",
            "description": "A test blueprint",
            "tags": ["test"],
            "steps": [
                {"step_id": "s1", "name": "Step 1"},
                {"step_id": "s2", "name": "Step 2", "depends_on": ["s1"]},
            ],
            "credit_cost": 2.0,
            "agent_id": "publisher",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["authorship_hash"] != ""
        assert len(data["authorship_hash"]) == 64

    def test_blueprint_detail_includes_authorship_hash(self, authed_client: TestClient) -> None:
        resp = authed_client.post("/v1/blueprints/publish", json={
            "name": "detail-bp",
            "tags": ["test"],
            "steps": [
                {"step_id": "s1", "name": "Step 1"},
                {"step_id": "s2", "name": "Step 2"},
            ],
            "credit_cost": 1.0,
            "agent_id": "publisher",
        })
        bp_id = resp.json()["blueprint_id"]
        detail_resp = TestClient(app).get(f"/public/blueprints/{bp_id}")
        assert detail_resp.status_code == 200
        assert "authorship_hash" in detail_resp.json()
