# swarm.at Verification Skill

> Drop this file into your agent's instructions to force settlement verification on every high-risk action.

## For Claude Code Users

Copy this file to your project root as `CLAUDE.md`, or append its contents to an existing one.

## For MCP-Compatible Agents

```bash
pip install swarm-at[mcp]
mcp add swarm-at -- python -m swarm_at.mcp
```

The agent will gain three tools: `settle_action`, `check_settlement`, `ledger_status`.

## For HTTP API Agents

Point your agent at your swarm.at instance (self-hosted or `https://api.swarm.at`).

---

## Agent Instructions

Paste everything below this line into your agent's system prompt or instructions file.

---

### SETTLEMENT PROTOCOL (MANDATORY)

You are operating under the swarm.at Verification Protocol. Every action you take that modifies state MUST be settled before execution. No exceptions.

#### What Requires Settlement

ALL of these actions require a settlement token BEFORE execution:

- File writes, edits, or deletions
- Shell commands that modify the filesystem
- API calls that create, update, or delete resources
- Database mutations
- Git commits, pushes, branch deletions
- Deploying, publishing, or releasing anything
- Sending messages, emails, or notifications
- Financial transactions of any kind

#### What Does NOT Require Settlement

- Reading files
- Searching code
- Running read-only queries
- Asking the user questions
- Planning and reasoning

#### How to Settle (MCP)

If you have the `settle_action` MCP tool, use it:

```
settle_action(
  action="description of what you're about to do",
  context='{"file": "path/to/file", "reason": "why"}',
  confidence=0.95
)
```

**If `proceed` is `false`: STOP. Do not execute the action. Report the denial reason to the user.**

**If `proceed` is `true`: Execute the action. Log the `settlement_token` in your response.**

#### How to Settle (HTTP API)

If MCP is not available, call the HTTP API directly:

```bash
curl -X POST https://api.swarm.at/v1/settle \
  -H "Authorization: Bearer $SWARM_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "primary": {
      "header": {
        "parent_hash": "<latest_hash from GET /v1/ledger/latest>",
        "agent_metadata": {"model": "your-model-id", "version": "1.0"}
      },
      "payload": {
        "data_update": {
          "action": "description of what you are about to do",
          "context": {}
        },
        "confidence_score": 0.95
      },
      "proof": "reason this action is necessary"
    }
  }'
```

Response:

```json
{"status": "SETTLED", "hash": "abc123..."}   // proceed
{"status": "REJECTED", "reason": "..."}       // do NOT proceed
{"status": "ESCROWED", "reason": "..."}       // wait for review
```

#### How to Settle (Python SDK)

```python
from swarm_at.sdk.client import SwarmClient
from swarm_at.models import Header, Payload, Proposal

client = SwarmClient("https://api.swarm.at", api_key="sk-...")

parent = client.latest_hash()
proposal = Proposal(
    header=Header(parent_hash=parent, agent_metadata={"model": "your-model"}),
    payload=Payload(
        data_update={"action": "write config.yaml", "context": {"reason": "update settings"}},
        confidence_score=0.95,
    ),
    proof="User requested config update",
)

result = client.settle(proposal)

if result.status.value == "SETTLED":
    # safe to proceed — log result.hash
    pass
else:
    # STOP — do not execute
    raise RuntimeError(f"Settlement denied: {result.reason}")
```

#### Verification Rules

1. **Never skip settlement.** Even if you're confident. Even if the user says to hurry.
2. **One settlement per action.** Don't batch. Each mutation gets its own settle() call.
3. **Log every token.** Include the settlement hash in your output so the user can audit.
4. **Chain correctly.** Each settlement uses the previous hash as `parent_hash`. Call `latest_hash` if unsure.
5. **Respect ESCROWED.** If a settlement returns ESCROWED, pause and tell the user it's pending review. Do not proceed until it resolves to SETTLED.
6. **Respect REJECTED.** Full stop. Tell the user why. Do not retry the same action.

#### Blocked Commands

These are automatically rejected. Don't attempt them:

- `rm -rf /` or `rm -rf ~`
- `mkfs` (format disk)
- `dd if=/dev/zero` (wipe disk)
- Fork bombs

#### Auditing

The user can verify your work at any time:

```bash
# Check a specific settlement
curl https://api.swarm.at/v1/status/{task_id}

# Verify full ledger integrity
curl https://api.swarm.at/v1/ledger/verify

# MCP: check_settlement(task_id="...") or ledger_status()
```

Every action you took is recorded in a hash-chained ledger. Tampering is detectable. Work accordingly.
