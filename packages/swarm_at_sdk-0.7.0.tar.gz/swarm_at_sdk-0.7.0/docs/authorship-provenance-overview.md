# Authorship Provenance

Settlement-backed audit trails for human-AI creative work.

Authorship Provenance implements the Human-AI Agency Spectrum framework (Ghuneim, 2026) as a verifiable evidence layer on top of swarm.at's hash-chained ledger. It records every human decision and AI action during a creative session, settles each to a tamper-evident ledger, and produces provenance reports with compliance assessments across four regulatory frameworks.

## The Problem

When a writer uses an AI tool to create content, there is no tamper-evident way to prove:

- Which creative decisions the human made vs. delegated to AI
- What proportion of the work reflects human agency
- Whether the process meets legal and contractual thresholds for copyright, guild credit, or regulatory exemptions

This matters because the U.S. Copyright Office (USCO), Writers Guild of America (WGA), SAG-AFTRA, and the EU AI Act all require evidence of human creative control when AI tools are involved. Writers using AI today have no standardized, verifiable mechanism for producing that evidence.

## How It Works

### WritingSession

The core object is `WritingSession`, which wraps a `SettlementContext` and records every interaction between a human writer and an AI tool. Six methods capture the full creative workflow:

| Method | Actor | What It Records |
|--------|-------|-----------------|
| `direct()` | Human | Creative decisions — what was chosen, what was rejected |
| `prompt()` | Human | Prompt text, SHA-256 hashed (raw text is never stored) |
| `generate()` | AI | Output hash, model identifier, generation parameters |
| `revise()` | Human | Description of edits, `kept_ratio` (fraction of AI output retained, 0.0–1.0) |
| `reject()` | Human | Hash of rejected output, reason for rejection |
| `approve()` | Human | Final sign-off with content hash and optional version label |

Each method call settles an event to the hash-chained ledger and returns a `SettlementResult` containing the cryptographic hash.

### Agency Layers (L0–L5)

Every event is tagged with a human agency level from the Agency Spectrum's six-layer model:

| Layer | Name | Agency Range | Description |
|-------|------|-------------|-------------|
| L0 | ORACLE | ~0–14% | AI generates everything |
| L1 | EXECUTOR | ~15–39% | Human curates AI output |
| L2 | COLLABORATOR | ~40–69% | Human selects and edits AI drafts |
| L3 | SUPERVISOR | ~70–89% | Human reviews and modifies AI suggestions |
| L4 | DIRECTOR | ~90–99% | Human directs, AI assists on command |
| L5 | PURE_TOOL | ~100% | Full human control, AI is passive |

Each layer normalizes to a 0.0–1.0 score via `layer.value / 5.0`.

When the agency parameter is omitted, defaults are inferred from the event type:

| Method | Default Agency |
|--------|---------------|
| `direct()` | L4_DIRECTOR |
| `prompt()` | L3_SUPERVISOR |
| `generate()` | L1_EXECUTOR |
| `revise()` | L3_SUPERVISOR |
| `reject()` | L4_DIRECTOR |
| `approve()` | L4_DIRECTOR |

### Creative Phases and Weights

Work is categorized across six creative phases, weighted by their significance to the overall creative contribution:

| Phase | Weight | Description |
|-------|--------|-------------|
| CONCEPT | 0.25 | Foundational creative decisions — carries the most weight |
| STRUCTURE | 0.20 | Architectural framing |
| CHARACTER | 0.15 | Core creative expression |
| SCENE | 0.15 | Narrative architecture |
| DIALOGUE | 0.15 | Surface-level expression |
| REVISION | 0.10 | Refinement and quality control — carries the least weight |

Weights are customizable per session via the `phase_weights` parameter, supporting non-screenwriting workflows such as novels, journalism, or technical writing where the weight distribution differs.

### Work Agency Score

The work agency score is a weighted average of human agency across all creative phases that contain events:

```
For each phase with events:
    phase_agency = mean(event.agency / 5.0 for each event in the phase)

work_agency = sum(weight[phase] * phase_agency[phase]) / sum(weights_used)
```

Only phases with events contribute to the score. A session covering Concept, Structure, and Scene is scored against those three phases' weights alone — it is not penalized for missing Dialogue, Character, or Revision.

The score ranges from 0.0 (pure AI authorship) to 1.0 (pure human authorship).

## Compliance Assessment

The work agency score maps to four regulatory and contractual frameworks:

### Thresholds

| Score | Copyright (USCO) | WGA | SAG-AFTRA | EU AI Act | Safe Harbor | Market Tier |
|-------|-------------------|-----|-----------|-----------|-------------|-------------|
| >= 90% | Clean — Full human authorship claim | Full credit — Literary material | Compliant with consent | Assistive function — Marking exempt | Yes | Premium |
| 70–89% | Diluted — Defensible with documentation | Conditional — L3 requires process evidence | Enhanced consent required | Assistive function — Marking exempt | No | Standard |
| 40–69% | Shared — Thin copyright at best | Not literary material (studio use) | Prohibited for performance | Marking required | No | Budget |
| < 40% | Absent — No human authorship claim | Not literary material | Prohibited | Marking required | No | Locked out |

The **90% safe harbor threshold** is the critical boundary. Above it, a writer has a strong copyright claim and full guild credit eligibility. Below it, the strength of the claim degrades progressively.

These assessments are informational, not legal advice. Reports include a disclaimer.

## Behavioral Flags

Three automated warnings detect patterns that may undermine an authorship claim:

**Anchoring risk** — Triggered when the average `kept_ratio` across all revision events exceeds 0.80. A high kept ratio indicates the writer is retaining most of the AI's output with minimal transformation, suggesting cognitive anchoring on AI-generated content rather than genuine editorial judgment.

**Satisficing risk** — Triggered when three or more consecutive AI generation events occur without an intervening human creative event (creative direction, editorial revision, or rejection). This pattern suggests the writer is accepting AI outputs without critical evaluation.

**Missing foundation** — Triggered when the first AI generation event occurs before any L4+ human creative direction. The Agency Spectrum's "Photographer Principle" holds that pre-AI creative work is what establishes authorship. A session that begins with AI generation has no human creative foundation.

These flags indicate risk, not guilt. A writer may have valid reasons for any of these patterns.

## Privacy

No raw content enters the ledger. Prompts are SHA-256 hashed before storage. AI outputs are referenced by caller-provided hashes. Revision descriptions are metadata strings, not content. The writer retains their content; the ledger retains the proof chain.

## Interfaces

### Python

```python
from swarm_at.authorship import WritingSession, CreativePhase, AgencyLayer

session = WritingSession(writer="jane", tool="claude-4")

# Human establishes creative direction
session.direct(
    action="premise",
    chose="three-act structure",
    rejected=["episodic", "nonlinear"],
    phase=CreativePhase.CONCEPT,
    agency=AgencyLayer.L5_PURE_TOOL,
)

# Prompt the AI
session.prompt(text="Write the opening scene", phase=CreativePhase.SCENE)

# Record AI output
session.generate(
    output_hash="abc123...",
    model="claude-4",
    phase=CreativePhase.SCENE,
)

# Human revises, keeping 30% of AI output
session.revise(
    description="Rewrote opening, cut two paragraphs",
    kept_ratio=0.3,
    phase=CreativePhase.SCENE,
)

# Final approval
session.approve(content_hash="def456...", version="v1.0")

# Generate report
report = session.report()
print(report.work_agency_pct)  # "85.0%"
print(report.safe_harbor)      # True or False
print(report.to_text())        # Full provenance report
```

### REST API

Seven endpoints under `/v1/authorship/`, all requiring Bearer token authentication:

| Method | Path | Purpose |
|--------|------|---------|
| POST | `/v1/authorship/sessions` | Create a new writing session |
| GET | `/v1/authorship/sessions` | List and filter sessions (supports pagination) |
| DELETE | `/v1/authorship/sessions/{id}` | Delete a session |
| POST | `/v1/authorship/sessions/{id}/events` | Record a creative event |
| POST | `/v1/authorship/sessions/{id}/approve` | Record final approval |
| GET | `/v1/authorship/sessions/{id}/report` | Retrieve JSON provenance report |
| GET | `/v1/authorship/sessions/{id}/report/text` | Retrieve plain-text provenance report |

### MCP Tools

Four tools available on the MCP server for integration with Claude and other MCP-compatible models:

| Tool | Purpose |
|------|---------|
| `start_writing_session` | Create a session, returns session_id |
| `record_writing_event` | Log a creative event (direction, prompt, generation, revision, rejection) |
| `approve_writing` | Record final sign-off with content hash |
| `get_provenance_report` | Fetch the JSON provenance report |

### Deliberate Omissions

Authorship provenance is deliberately excluded from:

- The public agent card (A2A discovery)
- `llms.txt` (AI tool discovery)
- The Python SDK client (`SwarmClient`)

This is a proprietary capability exposed only through MCP tools and the REST API.

## Persistence

### In-Memory (Default)

Sessions live in memory via `WritingSessionStore`. Settlement hashes are written to the ledger, but session metadata is not persisted across restarts.

### File-Backed (JSONL)

Setting the `SWARM_SESSION_PATH` environment variable enables `PersistentWritingSessionStore`, which appends session create/update/delete events to a JSONL file and replays them on startup.

```bash
export SWARM_SESSION_PATH=/var/lib/swarm/sessions.jsonl
```

When `SWARM_LEDGER_PATH` is set, persistence is auto-enabled with `sessions.jsonl` co-located alongside the ledger.

Settlement hashes always persist to the ledger regardless of session store configuration.

## Provenance Report

`session.report()` returns a `ProvenanceReport` containing:

- **Session metadata** — session ID, writer, tool, timestamps
- **Work agency** — overall score (0.0–1.0) and formatted percentage
- **Phase scores** — per-phase agency breakdown
- **Compliance assessment** — copyright, WGA, SAG-AFTRA, EU AI Act, market tier
- **Safe harbor status** — boolean, true if work agency >= 90%
- **Behavioral flags** — anchoring risk, satisficing risk, missing foundation
- **Event timeline** — chronological list of all events with actor, phase, and agency layer
- **Chain integrity** — verification status, first and last settlement hashes, ledger path

`report.to_text()` produces a human-readable version suitable for submission to publishers, legal review, or compliance documentation:

```
AUTHORSHIP PROVENANCE REPORT
============================================================
Session: a1b2c3d4 | Writer: jane-doe | Tool: claude-sonnet
Period: 2026-02-14 10:30 -> 2026-02-14 11:45

WORK AGENCY: 82.5%
============================================================

Phase Breakdown:
  concept          ################         100%
  structure        ##############           80%
  scene            #############            60%

SAFE HARBOR: BELOW THRESHOLD (82.5%)

COMPLIANCE ASSESSMENT:
  Copyright (USCO):  Diluted — Defensible with documentation
  WGA:               Conditional — L3 requires process evidence
  SAG-AFTRA:         Enhanced consent required
  EU AI Act:         Assistive function — Marking exempt
  Market Tier:       Standard

EVENT TIMELINE (9 events: 7 human, 2 AI):
  10:30:45  L5  [HUMAN]  creative-direction  concept
  10:32:12  L4  [HUMAN]  creative-direction  structure
  ...

CHAIN INTEGRITY: VERIFIED (9/9 hashes valid)
Ledger: /var/lib/swarm/ledger.jsonl
First hash: a1b2c3d4...  Last hash: z9y8x7w6...

This report is informational, not legal advice.
Generated by swarm.at v1.3.0
```

## References

- Ghuneim, M. (2026). "On the Calculation of The Human-AI Agency Spectrum." Narrative.new. CC BY 4.0.
- U.S. Copyright Office, "Copyright Registration Guidance: Works Containing Material Generated by Artificial Intelligence" (2023)
- WGA Minimum Basic Agreement, AI Provisions (2023, updated December 2025)
- SAG-AFTRA AI Provisions and Four Pillars of Ethical AI (2025)
- EU AI Act, Article 50: Transparency Obligations (Regulation 2024/1689)
