# Authorship Provenance Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build `WritingSession` — a settlement-backed audit trail for human-AI creative work implementing the Agency Spectrum framework (L0-L5 layers, phase-weighted scoring, compliance mapping).

**Architecture:** Single new module `swarm_at/authorship.py` that composes `SettlementContext` internally. Every human decision and AI action settles to the hash-chained ledger. A `report()` method walks the ledger and produces a verifiable provenance report with compliance assessments. No changes to existing modules beyond adding `WritingSession` to `__init__.py`.

**Tech Stack:** Python 3.10+, Pydantic v2, existing swarm_at.settle.SettlementContext, pytest

**Design doc:** `docs/plans/2026-02-14-authorship-provenance-design.md`

---

### Task 1: Data model — AgencyLayer, CreativePhase, constants

**Files:**
- Create: `swarm_at/authorship.py`
- Test: `tests/test_authorship.py`

**Step 1: Write the failing tests**

```python
"""Tests for authorship provenance module."""

from __future__ import annotations

import pytest

from swarm_at.authorship import AgencyLayer, CreativePhase, PHASE_WEIGHTS


class TestAgencyLayer:
    """AgencyLayer enum basics."""

    def test_values_are_0_through_5(self) -> None:
        assert AgencyLayer.L0_ORACLE == 0
        assert AgencyLayer.L5_PURE_TOOL == 5

    def test_all_six_layers_exist(self) -> None:
        assert len(AgencyLayer) == 6

    @pytest.mark.parametrize(
        "layer,expected",
        [
            (AgencyLayer.L0_ORACLE, 0.0),
            (AgencyLayer.L2_COLLABORATOR, 0.4),
            (AgencyLayer.L5_PURE_TOOL, 1.0),
        ],
        ids=["L0=0.0", "L2=0.4", "L5=1.0"],
    )
    def test_normalized_score(self, layer: AgencyLayer, expected: float) -> None:
        assert layer.value / 5.0 == expected


class TestCreativePhase:
    """CreativePhase enum and weights."""

    def test_all_six_phases_exist(self) -> None:
        assert len(CreativePhase) == 6

    def test_weights_sum_to_1(self) -> None:
        assert abs(sum(PHASE_WEIGHTS.values()) - 1.0) < 1e-9

    def test_every_phase_has_a_weight(self) -> None:
        for phase in CreativePhase:
            assert phase in PHASE_WEIGHTS

    def test_concept_is_heaviest(self) -> None:
        assert PHASE_WEIGHTS[CreativePhase.CONCEPT] == 0.25

    def test_revision_is_lightest(self) -> None:
        assert PHASE_WEIGHTS[CreativePhase.REVISION] == 0.10
```

**Step 2: Run tests to verify they fail**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py -v --tb=short`
Expected: FAIL — `ModuleNotFoundError: No module named 'swarm_at.authorship'`

**Step 3: Write minimal implementation**

Create `swarm_at/authorship.py`:

```python
"""Authorship provenance: settlement-backed audit trails for human-AI creative work.

Implements the Human-AI Agency Spectrum framework (Ghuneim, 2026) as a
verifiable evidence layer on top of swarm.at's hash-chained ledger.
"""

from __future__ import annotations

from enum import IntEnum, Enum


class AgencyLayer(IntEnum):
    """Six layers of human-AI agency from the Agency Spectrum framework."""

    L0_ORACLE = 0
    L1_EXECUTOR = 1
    L2_COLLABORATOR = 2
    L3_SUPERVISOR = 3
    L4_DIRECTOR = 4
    L5_PURE_TOOL = 5


class CreativePhase(str, Enum):
    """Creative contribution types with associated weights."""

    CONCEPT = "concept"
    STRUCTURE = "structure"
    CHARACTER = "character"
    SCENE = "scene"
    DIALOGUE = "dialogue"
    REVISION = "revision"


PHASE_WEIGHTS: dict[CreativePhase, float] = {
    CreativePhase.CONCEPT: 0.25,
    CreativePhase.STRUCTURE: 0.20,
    CreativePhase.CHARACTER: 0.15,
    CreativePhase.SCENE: 0.15,
    CreativePhase.DIALOGUE: 0.15,
    CreativePhase.REVISION: 0.10,
}
```

**Step 4: Run tests to verify they pass**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py -v --tb=short`
Expected: 8 passed

**Step 5: Commit**

```bash
git add swarm_at/authorship.py tests/test_authorship.py
git commit -m "Add AgencyLayer, CreativePhase, and phase weights"
```

---

### Task 2: Internal event model and WritingSession construction

**Files:**
- Modify: `swarm_at/authorship.py`
- Modify: `tests/test_authorship.py`

**Step 1: Write the failing tests**

Append to `tests/test_authorship.py`:

```python
from pathlib import Path

from swarm_at.authorship import WritingSession, AuthorshipEvent


class TestAuthorshipEvent:
    """Internal event data model."""

    def test_event_has_required_fields(self) -> None:
        event = AuthorshipEvent(
            event_type="creative-direction",
            actor="jane",
            actor_role="writer",
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L4_DIRECTOR,
            settlement_hash="a" * 64,
            metadata={"chose": "noir"},
        )
        assert event.event_type == "creative-direction"
        assert event.actor_role == "writer"
        assert event.timestamp > 0


class TestWritingSessionInit:
    """WritingSession construction."""

    def test_creates_with_writer_and_tool(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane-doe",
            tool="claude-sonnet",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        assert session.writer == "jane-doe"
        assert session.tool == "claude-sonnet"
        assert session.session_id  # non-empty string

    def test_starts_with_no_events(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane-doe",
            tool="claude-sonnet",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        assert len(session.events) == 0

    def test_custom_phase_weights(self, tmp_path: Path) -> None:
        custom = {
            CreativePhase.CONCEPT: 0.50,
            CreativePhase.STRUCTURE: 0.50,
        }
        session = WritingSession(
            writer="jane-doe",
            tool="claude-sonnet",
            phase_weights=custom,
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        assert session.phase_weights[CreativePhase.CONCEPT] == 0.50
```

**Step 2: Run tests to verify they fail**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py::TestAuthorshipEvent -v --tb=short`
Expected: FAIL — `cannot import name 'AuthorshipEvent'`

**Step 3: Write minimal implementation**

Add to `swarm_at/authorship.py`:

```python
import hashlib
import time
import uuid
from typing import Any

from pydantic import BaseModel, Field

from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


class AuthorshipEvent(BaseModel):
    """Single event in a writing session's provenance chain."""

    event_type: str
    actor: str
    actor_role: str  # "writer" or "tool"
    phase: CreativePhase
    agency: AgencyLayer
    timestamp: float = Field(default_factory=time.time)
    settlement_hash: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class WritingSession:
    """Settlement-backed audit trail for human-AI creative work."""

    def __init__(
        self,
        writer: str,
        tool: str,
        phase_weights: dict[CreativePhase, float] | None = None,
        tier: SettlementTier | None = None,
        ledger_path: str = "ledger.jsonl",
    ) -> None:
        self.writer = writer
        self.tool = tool
        self.session_id = uuid.uuid4().hex[:8]
        self.phase_weights = phase_weights or dict(PHASE_WEIGHTS)
        self.events: list[AuthorshipEvent] = []
        self._ctx = SettlementContext(tier=tier, ledger_path=ledger_path)
        self._started_at = time.time()
```

**Step 4: Run tests to verify they pass**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py -v --tb=short`
Expected: 11 passed

**Step 5: Commit**

```bash
git add swarm_at/authorship.py tests/test_authorship.py
git commit -m "Add AuthorshipEvent model and WritingSession constructor"
```

---

### Task 3: direct() and prompt() methods

**Files:**
- Modify: `swarm_at/authorship.py`
- Modify: `tests/test_authorship.py`

**Step 1: Write the failing tests**

Append to `tests/test_authorship.py`:

```python
from swarm_at.models import SettlementStatus


class TestDirect:
    """WritingSession.direct() — records human creative decisions."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.direct(
            action="outline",
            chose="3-act structure",
            phase=CreativePhase.STRUCTURE,
        )
        assert result.status == SettlementStatus.SETTLED

    def test_records_event(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(action="premise", chose="noir detective")
        assert len(session.events) == 1
        ev = session.events[0]
        assert ev.event_type == "creative-direction"
        assert ev.actor == "jane"
        assert ev.actor_role == "writer"
        assert ev.metadata["chose"] == "noir detective"

    def test_default_agency_is_L4(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(action="theme", chose="revenge")
        assert session.events[0].agency == AgencyLayer.L4_DIRECTOR

    def test_default_phase_is_scene(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(action="blocking", chose="wide shot")
        assert session.events[0].phase == CreativePhase.SCENE

    def test_rejected_options_stored(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(
            action="outline",
            chose="3-act",
            rejected=["listicle", "essay"],
        )
        assert session.events[0].metadata["rejected"] == ["listicle", "essay"]

    def test_custom_agency_override(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(
            action="outline",
            chose="3-act",
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        assert session.events[0].agency == AgencyLayer.L5_PURE_TOOL


class TestPrompt:
    """WritingSession.prompt() — records prompts given to the AI tool."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.prompt(text="Write the opening scene")
        assert result.status == SettlementStatus.SETTLED

    def test_hashes_prompt_text(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.prompt(text="Write the opening scene")
        ev = session.events[0]
        expected_hash = hashlib.sha256(b"Write the opening scene").hexdigest()
        assert ev.metadata["prompt_hash"] == expected_hash
        assert "text" not in ev.metadata  # raw text NOT stored

    def test_default_agency_is_L3(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.prompt(text="anything")
        assert session.events[0].agency == AgencyLayer.L3_SUPERVISOR

    def test_actor_is_writer(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.prompt(text="anything")
        assert session.events[0].actor == "jane"
        assert session.events[0].actor_role == "writer"
```

**Step 2: Run tests to verify they fail**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py::TestDirect -v --tb=short`
Expected: FAIL — `WritingSession has no attribute 'direct'`

**Step 3: Write minimal implementation**

Add to `WritingSession` in `swarm_at/authorship.py`:

```python
    def _settle_event(
        self,
        event_type: str,
        actor: str,
        actor_role: str,
        phase: CreativePhase,
        agency: AgencyLayer,
        metadata: dict[str, Any],
    ) -> SettlementResult:
        """Settle an event to the ledger and record it."""
        from swarm_at.models import SettlementResult

        data = {
            "event_type": event_type,
            "actor": actor,
            "actor_role": actor_role,
            "phase": phase.value,
            "agency_layer": agency.value,
            "session_id": self.session_id,
            **metadata,
        }
        result = self._ctx.settle(agent=actor, task=event_type, data=data)

        if result.hash:
            event = AuthorshipEvent(
                event_type=event_type,
                actor=actor,
                actor_role=actor_role,
                phase=phase,
                agency=agency,
                settlement_hash=result.hash,
                metadata=metadata,
            )
            self.events.append(event)

        return result

    def direct(
        self,
        action: str,
        chose: str,
        rejected: list[str] | None = None,
        phase: CreativePhase = CreativePhase.SCENE,
        agency: AgencyLayer = AgencyLayer.L4_DIRECTOR,
    ) -> SettlementResult:
        """Record a human creative decision."""
        meta: dict[str, Any] = {"action": action, "chose": chose}
        if rejected:
            meta["rejected"] = rejected
        return self._settle_event(
            "creative-direction", self.writer, "writer", phase, agency, meta,
        )

    def prompt(
        self,
        text: str,
        phase: CreativePhase = CreativePhase.SCENE,
        agency: AgencyLayer = AgencyLayer.L3_SUPERVISOR,
    ) -> SettlementResult:
        """Record a prompt given to the AI tool. Text is hashed, not stored."""
        prompt_hash = hashlib.sha256(text.encode()).hexdigest()
        meta: dict[str, Any] = {"prompt_hash": prompt_hash}
        return self._settle_event(
            "prompt", self.writer, "writer", phase, agency, meta,
        )
```

Also add the import at the top of `authorship.py`:

```python
from swarm_at.models import SettlementResult
```

And update the return type annotations.

**Step 4: Run tests to verify they pass**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py -v --tb=short`
Expected: 21 passed

**Step 5: Commit**

```bash
git add swarm_at/authorship.py tests/test_authorship.py
git commit -m "Add direct() and prompt() methods to WritingSession"
```

---

### Task 4: generate(), revise(), reject(), approve() methods

**Files:**
- Modify: `swarm_at/authorship.py`
- Modify: `tests/test_authorship.py`

**Step 1: Write the failing tests**

Append to `tests/test_authorship.py`:

```python
class TestGenerate:
    """WritingSession.generate() — records AI output."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.generate(output_hash="a" * 64, model="claude-sonnet")
        assert result.status == SettlementStatus.SETTLED

    def test_actor_is_tool(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.generate(output_hash="a" * 64)
        ev = session.events[0]
        assert ev.actor == "claude"
        assert ev.actor_role == "tool"

    def test_default_agency_is_L1(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.generate(output_hash="a" * 64)
        assert session.events[0].agency == AgencyLayer.L1_EXECUTOR

    def test_stores_model_and_params(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.generate(
            output_hash="a" * 64,
            model="claude-sonnet",
            params={"temperature": 0.7},
        )
        ev = session.events[0]
        assert ev.metadata["model"] == "claude-sonnet"
        assert ev.metadata["params"] == {"temperature": 0.7}


class TestRevise:
    """WritingSession.revise() — records human edits to AI output."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.revise(description="rewrote opening", kept_ratio=0.3)
        assert result.status == SettlementStatus.SETTLED

    def test_stores_kept_ratio(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.revise(description="rewrote opening", kept_ratio=0.3)
        assert session.events[0].metadata["kept_ratio"] == 0.3

    def test_actor_is_writer(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.revise(description="edits", kept_ratio=0.5)
        assert session.events[0].actor_role == "writer"

    @pytest.mark.parametrize(
        "ratio",
        [-0.1, 1.1],
        ids=["below-zero", "above-one"],
    )
    def test_rejects_invalid_kept_ratio(self, tmp_path: Path, ratio: float) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        with pytest.raises(ValueError, match="kept_ratio"):
            session.revise(description="edits", kept_ratio=ratio)


class TestReject:
    """WritingSession.reject() — records rejection of AI output."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.reject(output_hash="b" * 64, reason="too generic")
        assert result.status == SettlementStatus.SETTLED

    def test_agency_is_always_L4(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.reject(output_hash="b" * 64, reason="off-brand")
        assert session.events[0].agency == AgencyLayer.L4_DIRECTOR

    def test_stores_reason(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.reject(output_hash="b" * 64, reason="too generic")
        assert session.events[0].metadata["reason"] == "too generic"


class TestApprove:
    """WritingSession.approve() — records final sign-off."""

    def test_settles_successfully(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = session.approve(content_hash="c" * 64)
        assert result.status == SettlementStatus.SETTLED

    def test_stores_version(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.approve(content_hash="c" * 64, version="final-v1")
        assert session.events[0].metadata["version"] == "final-v1"

    def test_event_type_is_approval(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.approve(content_hash="c" * 64)
        assert session.events[0].event_type == "approval"
```

**Step 2: Run tests to verify they fail**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py::TestGenerate -v --tb=short`
Expected: FAIL — `WritingSession has no attribute 'generate'`

**Step 3: Write minimal implementation**

Add to `WritingSession` in `swarm_at/authorship.py`:

```python
    def generate(
        self,
        output_hash: str,
        model: str = "",
        params: dict[str, Any] | None = None,
        phase: CreativePhase = CreativePhase.SCENE,
        agency: AgencyLayer = AgencyLayer.L1_EXECUTOR,
    ) -> SettlementResult:
        """Record AI-generated output. Caller provides the hash."""
        meta: dict[str, Any] = {"output_hash": output_hash}
        if model:
            meta["model"] = model
        if params:
            meta["params"] = params
        return self._settle_event(
            "ai-generation", self.tool, "tool", phase, agency, meta,
        )

    def revise(
        self,
        description: str,
        kept_ratio: float,
        phase: CreativePhase = CreativePhase.SCENE,
        agency: AgencyLayer = AgencyLayer.L3_SUPERVISOR,
    ) -> SettlementResult:
        """Record human edits to AI output."""
        if not 0.0 <= kept_ratio <= 1.0:
            raise ValueError(f"kept_ratio must be 0.0-1.0, got {kept_ratio}")
        meta: dict[str, Any] = {
            "description": description,
            "kept_ratio": kept_ratio,
        }
        return self._settle_event(
            "editorial-revision", self.writer, "writer", phase, agency, meta,
        )

    def reject(
        self,
        output_hash: str,
        reason: str,
        phase: CreativePhase = CreativePhase.SCENE,
    ) -> SettlementResult:
        """Record rejection of AI output. Agency is always L4."""
        meta: dict[str, Any] = {"output_hash": output_hash, "reason": reason}
        return self._settle_event(
            "rejection", self.writer, "writer", phase, AgencyLayer.L4_DIRECTOR, meta,
        )

    def approve(
        self,
        content_hash: str,
        version: str = "",
    ) -> SettlementResult:
        """Record final approval. Session-level, no phase."""
        meta: dict[str, Any] = {"content_hash": content_hash}
        if version:
            meta["version"] = version
        return self._settle_event(
            "approval", self.writer, "writer",
            CreativePhase.REVISION, AgencyLayer.L4_DIRECTOR, meta,
        )
```

**Step 4: Run tests to verify they pass**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py -v --tb=short`
Expected: 35 passed

**Step 5: Commit**

```bash
git add swarm_at/authorship.py tests/test_authorship.py
git commit -m "Add generate, revise, reject, approve methods"
```

---

### Task 5: Work agency calculation

**Files:**
- Modify: `swarm_at/authorship.py`
- Modify: `tests/test_authorship.py`

**Step 1: Write the failing tests**

Append to `tests/test_authorship.py`:

```python
class TestWorkAgency:
    """Work agency: weighted phase scoring from Agency Spectrum framework."""

    def _make_session(self, tmp_path: Path) -> WritingSession:
        return WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )

    def test_empty_session_returns_zero(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        assert session.work_agency == 0.0

    def test_all_L5_returns_1(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(
            action="concept", chose="noir",
            phase=CreativePhase.CONCEPT, agency=AgencyLayer.L5_PURE_TOOL,
        )
        session.direct(
            action="outline", chose="3-act",
            phase=CreativePhase.STRUCTURE, agency=AgencyLayer.L5_PURE_TOOL,
        )
        assert session.work_agency == 1.0

    def test_all_L0_returns_0(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.generate(
            output_hash="a" * 64,
            phase=CreativePhase.CONCEPT, agency=AgencyLayer.L0_ORACLE,
        )
        assert session.work_agency == 0.0

    def test_case_study_a_screenplay(self, tmp_path: Path) -> None:
        """Reproduce Agency Spectrum Case Study A: 88.75% -> ~0.887."""
        session = self._make_session(tmp_path)
        # concept: L5
        session.direct(
            action="research", chose="topic",
            phase=CreativePhase.CONCEPT, agency=AgencyLayer.L5_PURE_TOOL,
        )
        # structure: L4
        session.direct(
            action="outline", chose="3-act",
            phase=CreativePhase.STRUCTURE, agency=AgencyLayer.L4_DIRECTOR,
        )
        # character: L5
        session.direct(
            action="characters", chose="detective",
            phase=CreativePhase.CHARACTER, agency=AgencyLayer.L5_PURE_TOOL,
        )
        # scene: L3
        session.prompt(
            text="Write scene",
            phase=CreativePhase.SCENE, agency=AgencyLayer.L3_SUPERVISOR,
        )
        # dialogue: L2
        session.generate(
            output_hash="a" * 64,
            phase=CreativePhase.DIALOGUE, agency=AgencyLayer.L2_COLLABORATOR,
        )
        # revision: L4
        session.revise(
            description="polish",
            kept_ratio=0.5,
            phase=CreativePhase.REVISION, agency=AgencyLayer.L4_DIRECTOR,
        )
        # Expected: (1.0*0.25 + 0.8*0.20 + 1.0*0.15 + 0.6*0.15 + 0.4*0.15 + 0.8*0.10) / 1.0
        #         = 0.25 + 0.16 + 0.15 + 0.09 + 0.06 + 0.08 = 0.79
        # Wait — layers are discrete. L5=1.0, L4=0.8, L3=0.6, L2=0.4
        # = (1.0*0.25 + 0.8*0.20 + 1.0*0.15 + 0.6*0.15 + 0.4*0.15 + 0.8*0.10)
        # = 0.25 + 0.16 + 0.15 + 0.09 + 0.06 + 0.08 = 0.79
        expected = (
            1.0 * 0.25  # concept L5
            + 0.8 * 0.20  # structure L4
            + 1.0 * 0.15  # character L5
            + 0.6 * 0.15  # scene L3
            + 0.4 * 0.15  # dialogue L2
            + 0.8 * 0.10  # revision L4
        )
        assert abs(session.work_agency - expected) < 0.01

    def test_single_phase_not_penalized(self, tmp_path: Path) -> None:
        """A session with only concept events should score on concept alone."""
        session = self._make_session(tmp_path)
        session.direct(
            action="premise", chose="noir",
            phase=CreativePhase.CONCEPT, agency=AgencyLayer.L5_PURE_TOOL,
        )
        assert session.work_agency == 1.0

    def test_multiple_events_same_phase_averaged(self, tmp_path: Path) -> None:
        """Two events in same phase get averaged."""
        session = self._make_session(tmp_path)
        session.direct(
            action="a", chose="x",
            phase=CreativePhase.CONCEPT, agency=AgencyLayer.L5_PURE_TOOL,
        )
        session.generate(
            output_hash="a" * 64,
            phase=CreativePhase.CONCEPT, agency=AgencyLayer.L1_EXECUTOR,
        )
        # avg of L5 (1.0) and L1 (0.2) = 0.6
        assert abs(session.work_agency - 0.6) < 0.01

    def test_custom_weights_used(self, tmp_path: Path) -> None:
        """Custom weights override defaults."""
        session = WritingSession(
            writer="jane", tool="claude",
            phase_weights={
                CreativePhase.CONCEPT: 1.0,  # only concept matters
            },
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(
            action="premise", chose="noir",
            phase=CreativePhase.CONCEPT, agency=AgencyLayer.L4_DIRECTOR,
        )
        session.generate(
            output_hash="a" * 64,
            phase=CreativePhase.DIALOGUE, agency=AgencyLayer.L0_ORACLE,
        )
        # Dialogue has no weight in custom weights, so only concept counts
        assert abs(session.work_agency - 0.8) < 0.01
```

**Step 2: Run tests to verify they fail**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py::TestWorkAgency -v --tb=short`
Expected: FAIL — `WritingSession has no attribute 'work_agency'`

**Step 3: Write minimal implementation**

Add to `WritingSession` in `swarm_at/authorship.py`:

```python
    @property
    def work_agency(self) -> float:
        """Weighted agency score across creative phases.

        Formula from Agency Spectrum: Work Agency = sum(weight * phase_agency) / sum(weights_used)
        Phases without events are excluded from the denominator.
        """
        if not self.events:
            return 0.0

        # Group events by phase
        phase_scores: dict[CreativePhase, list[float]] = {}
        for ev in self.events:
            phase_scores.setdefault(ev.phase, []).append(ev.agency.value / 5.0)

        # Weighted sum over phases that have events AND have a weight
        numerator = 0.0
        denominator = 0.0
        for phase, scores in phase_scores.items():
            weight = self.phase_weights.get(phase, 0.0)
            if weight > 0:
                phase_avg = sum(scores) / len(scores)
                numerator += weight * phase_avg
                denominator += weight

        if denominator == 0:
            return 0.0
        return numerator / denominator
```

**Step 4: Run tests to verify they pass**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py -v --tb=short`
Expected: 42 passed

**Step 5: Commit**

```bash
git add swarm_at/authorship.py tests/test_authorship.py
git commit -m "Add work agency calculation with phase-weighted scoring"
```

---

### Task 6: Compliance assessment and behavioral flags

**Files:**
- Modify: `swarm_at/authorship.py`
- Modify: `tests/test_authorship.py`

**Step 1: Write the failing tests**

Append to `tests/test_authorship.py`:

```python
from swarm_at.authorship import BehavioralFlags, ComplianceAssessment


class TestComplianceAssessment:
    """Compliance mapping from work agency to regulatory frameworks."""

    @pytest.mark.parametrize(
        "score,safe_harbor,copyright,market_tier",
        [
            (0.95, True, "Clean", "Premium"),
            (0.90, True, "Clean", "Premium"),
            (0.89, False, "Diluted", "Standard"),
            (0.70, False, "Diluted", "Standard"),
            (0.69, False, "Shared", "Budget"),
            (0.40, False, "Shared", "Budget"),
            (0.39, False, "Absent", "Locked out"),
            (0.0, False, "Absent", "Locked out"),
        ],
        ids=["95%", "90%-boundary", "89%", "70%", "69%", "40%", "39%", "0%"],
    )
    def test_threshold_mapping(
        self, score: float, safe_harbor: bool, copyright: str, market_tier: str,
    ) -> None:
        c = ComplianceAssessment.from_score(score)
        assert c.safe_harbor == safe_harbor
        assert copyright in c.copyright
        assert market_tier in c.market_tier


class TestBehavioralFlags:
    """Behavioral constraint detection from session data."""

    def _make_session(self, tmp_path: Path) -> WritingSession:
        return WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )

    def test_no_flags_on_good_session(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.prompt(text="write scene")
        session.generate(output_hash="a" * 64)
        session.revise(description="rewrote", kept_ratio=0.3)
        flags = session.behavioral_flags
        assert not flags.anchoring_risk
        assert not flags.satisficing_risk
        assert not flags.missing_foundation

    def test_anchoring_risk_high_kept_ratio(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.revise(description="minor tweak", kept_ratio=0.9)
        session.revise(description="small edit", kept_ratio=0.85)
        session.revise(description="typo fix", kept_ratio=0.95)
        flags = session.behavioral_flags
        assert flags.anchoring_risk

    def test_no_anchoring_when_low_kept_ratio(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.revise(description="major rewrite", kept_ratio=0.2)
        session.revise(description="overhaul", kept_ratio=0.3)
        flags = session.behavioral_flags
        assert not flags.anchoring_risk

    def test_satisficing_risk_consecutive_generates(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.generate(output_hash="a" * 64)
        session.generate(output_hash="b" * 64)
        session.generate(output_hash="c" * 64)
        flags = session.behavioral_flags
        assert flags.satisficing_risk

    def test_no_satisficing_when_interspersed(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.generate(output_hash="a" * 64)
        session.revise(description="edit", kept_ratio=0.5)
        session.generate(output_hash="b" * 64)
        flags = session.behavioral_flags
        assert not flags.satisficing_risk

    def test_missing_foundation_generate_first(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.generate(output_hash="a" * 64)
        flags = session.behavioral_flags
        assert flags.missing_foundation

    def test_no_missing_foundation_when_direct_first(self, tmp_path: Path) -> None:
        session = self._make_session(tmp_path)
        session.direct(action="concept", chose="noir", phase=CreativePhase.CONCEPT)
        session.generate(output_hash="a" * 64)
        flags = session.behavioral_flags
        assert not flags.missing_foundation
```

**Step 2: Run tests to verify they fail**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py::TestComplianceAssessment -v --tb=short`
Expected: FAIL — `cannot import name 'ComplianceAssessment'`

**Step 3: Write minimal implementation**

Add to `swarm_at/authorship.py`:

```python
class ComplianceAssessment(BaseModel):
    """Maps work agency score to regulatory frameworks."""

    copyright: str
    wga: str
    sag_aftra: str
    eu_ai_act: str
    safe_harbor: bool
    market_tier: str

    @classmethod
    def from_score(cls, score: float) -> ComplianceAssessment:
        if score >= 0.90:
            return cls(
                copyright="Clean — Full human authorship claim",
                wga="Full credit — Literary material",
                sag_aftra="Compliant with consent",
                eu_ai_act="Assistive function — Marking exempt",
                safe_harbor=True,
                market_tier="Premium",
            )
        if score >= 0.70:
            return cls(
                copyright="Diluted — Defensible with documentation",
                wga="Conditional — L3 requires process evidence",
                sag_aftra="Enhanced consent required",
                eu_ai_act="Assistive function — Marking exempt",
                safe_harbor=False,
                market_tier="Standard",
            )
        if score >= 0.40:
            return cls(
                copyright="Shared — Thin copyright at best",
                wga="Not literary material (studio use)",
                sag_aftra="Prohibited for performance",
                eu_ai_act="Marking required",
                safe_harbor=False,
                market_tier="Budget",
            )
        return cls(
            copyright="Absent — No human authorship claim",
            wga="Not literary material",
            sag_aftra="Prohibited",
            eu_ai_act="Marking required",
            safe_harbor=False,
            market_tier="Locked out of professional tiers",
        )


ANCHORING_THRESHOLD = 0.80
SATISFICING_THRESHOLD = 3


class BehavioralFlags(BaseModel):
    """Behavioral constraint warnings detected from session data."""

    anchoring_risk: bool = False
    satisficing_risk: bool = False
    missing_foundation: bool = False
    high_acceptance: float = 0.0
```

Add to `WritingSession`:

```python
    @property
    def behavioral_flags(self) -> BehavioralFlags:
        """Detect behavioral constraint risks from session data."""
        # Anchoring: high average kept_ratio across revisions
        revisions = [e for e in self.events if e.event_type == "editorial-revision"]
        avg_kept = 0.0
        if revisions:
            ratios = [e.metadata.get("kept_ratio", 0.0) for e in revisions]
            avg_kept = sum(ratios) / len(ratios)
        anchoring = len(revisions) > 0 and avg_kept > ANCHORING_THRESHOLD

        # Satisficing: N+ consecutive ai-generation without human creative event
        human_types = {"creative-direction", "editorial-revision", "rejection"}
        max_consecutive_gen = 0
        current_streak = 0
        for ev in self.events:
            if ev.event_type == "ai-generation":
                current_streak += 1
                max_consecutive_gen = max(max_consecutive_gen, current_streak)
            elif ev.event_type in human_types:
                current_streak = 0
        satisficing = max_consecutive_gen >= SATISFICING_THRESHOLD

        # Missing foundation: first AI generation before any L4+ human event
        has_foundation = False
        missing = False
        for ev in self.events:
            if ev.actor_role == "writer" and ev.agency >= AgencyLayer.L4_DIRECTOR:
                has_foundation = True
            if ev.event_type == "ai-generation" and not has_foundation:
                missing = True
                break

        # High acceptance ratio
        gen_count = sum(1 for e in self.events if e.event_type == "ai-generation")
        reject_count = sum(1 for e in self.events if e.event_type == "rejection")
        high_accept = 0.0
        if gen_count > 0:
            high_accept = (gen_count - reject_count) / gen_count

        return BehavioralFlags(
            anchoring_risk=anchoring,
            satisficing_risk=satisficing,
            missing_foundation=missing,
            high_acceptance=high_accept,
        )
```

**Step 4: Run tests to verify they pass**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py -v --tb=short`
Expected: 57 passed

**Step 5: Commit**

```bash
git add swarm_at/authorship.py tests/test_authorship.py
git commit -m "Add compliance assessment and behavioral flag detection"
```

---

### Task 7: Provenance report generation

**Files:**
- Modify: `swarm_at/authorship.py`
- Modify: `tests/test_authorship.py`

**Step 1: Write the failing tests**

Append to `tests/test_authorship.py`:

```python
from swarm_at.authorship import ProvenanceEvent, ProvenanceReport


class TestProvenanceReport:
    """ProvenanceReport generation from WritingSession."""

    def _make_full_session(self, tmp_path: Path) -> WritingSession:
        session = WritingSession(
            writer="jane-doe", tool="claude-sonnet",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        session.direct(
            action="premise", chose="noir",
            phase=CreativePhase.CONCEPT, agency=AgencyLayer.L5_PURE_TOOL,
        )
        session.prompt(text="write scene", phase=CreativePhase.SCENE)
        session.generate(output_hash="a" * 64, phase=CreativePhase.SCENE)
        session.revise(
            description="rewrote", kept_ratio=0.3,
            phase=CreativePhase.SCENE,
        )
        session.approve(content_hash="f" * 64, version="v1")
        return session

    def test_report_returns_provenance_report(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert isinstance(report, ProvenanceReport)

    def test_report_has_correct_counts(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert report.total_events == 5
        assert report.human_events == 4
        assert report.ai_events == 1

    def test_report_has_work_agency(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert 0.0 < report.work_agency <= 1.0

    def test_report_has_compliance(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert isinstance(report.compliance, ComplianceAssessment)

    def test_report_has_chain_verification(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert report.chain_verified is True

    def test_report_has_all_events(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert len(report.events) == 5
        assert report.events[0].event_type == "creative-direction"
        assert report.events[-1].event_type == "approval"

    def test_report_hashes_set(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        assert len(report.first_hash) == 64
        assert len(report.last_hash) == 64
        assert report.first_hash != report.last_hash

    def test_to_text_contains_key_sections(self, tmp_path: Path) -> None:
        session = self._make_full_session(tmp_path)
        report = session.report()
        text = report.to_text()
        assert "AUTHORSHIP PROVENANCE REPORT" in text
        assert "jane-doe" in text
        assert "claude-sonnet" in text
        assert "WORK AGENCY" in text
        assert "COMPLIANCE" in text
        assert "CHAIN INTEGRITY" in text
        assert "VERIFIED" in text

    def test_empty_session_report(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="jane", tool="claude",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        report = session.report()
        assert report.total_events == 0
        assert report.work_agency == 0.0
```

**Step 2: Run tests to verify they fail**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py::TestProvenanceReport -v --tb=short`
Expected: FAIL — `cannot import name 'ProvenanceEvent'`

**Step 3: Write minimal implementation**

Add to `swarm_at/authorship.py`:

```python
import datetime


class ProvenanceEvent(BaseModel):
    """Single event in the provenance report."""

    event_type: str
    actor: str
    actor_role: str
    phase: str
    agency_layer: int
    timestamp: float
    settlement_hash: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class ProvenanceReport(BaseModel):
    """Verifiable authorship provenance report."""

    session_id: str
    writer: str
    tool: str
    started_at: float
    completed_at: float | None

    work_agency: float
    work_agency_pct: str
    phase_scores: dict[str, float]

    compliance: ComplianceAssessment
    safe_harbor: bool
    behavioral_flags: BehavioralFlags

    total_events: int
    human_events: int
    ai_events: int
    events: list[ProvenanceEvent]

    first_hash: str
    last_hash: str
    chain_verified: bool
    ledger_path: str

    def to_text(self) -> str:
        """Human-readable provenance report."""
        lines: list[str] = []
        lines.append("AUTHORSHIP PROVENANCE REPORT")
        lines.append("=" * 60)
        lines.append(
            f"Session: {self.session_id} | Writer: {self.writer} | Tool: {self.tool}"
        )

        start = datetime.datetime.fromtimestamp(self.started_at).strftime("%Y-%m-%d %H:%M")
        end = (
            datetime.datetime.fromtimestamp(self.completed_at).strftime("%Y-%m-%d %H:%M")
            if self.completed_at
            else "in progress"
        )
        lines.append(f"Period: {start} -> {end}")
        lines.append("")

        lines.append(f"WORK AGENCY: {self.work_agency_pct}")
        lines.append("=" * 60)
        lines.append("")

        lines.append("Phase Breakdown:")
        for phase_name, score in self.phase_scores.items():
            bar_len = int(score * 20)
            bar = "#" * bar_len
            lines.append(f"  {phase_name:<16} {bar:<20} {score:.0%}")
        lines.append("")

        harbor = "ABOVE THRESHOLD" if self.safe_harbor else "BELOW THRESHOLD"
        lines.append(f"SAFE HARBOR: {harbor} ({self.work_agency_pct})")
        lines.append("")

        lines.append("COMPLIANCE ASSESSMENT:")
        lines.append(f"  Copyright (USCO):  {self.compliance.copyright}")
        lines.append(f"  WGA:               {self.compliance.wga}")
        lines.append(f"  SAG-AFTRA:         {self.compliance.sag_aftra}")
        lines.append(f"  EU AI Act:         {self.compliance.eu_ai_act}")
        lines.append(f"  Market Tier:       {self.compliance.market_tier}")
        lines.append("")

        flags = self.behavioral_flags
        if flags.anchoring_risk or flags.satisficing_risk or flags.missing_foundation:
            lines.append("BEHAVIORAL FLAGS:")
            if flags.anchoring_risk:
                lines.append("  ! Anchoring risk: high average kept_ratio")
            if flags.satisficing_risk:
                lines.append("  ! Satisficing risk: consecutive AI outputs without human review")
            if flags.missing_foundation:
                lines.append("  ! Missing foundation: AI generation before human creative direction")
            lines.append("")

        lines.append(
            f"EVENT TIMELINE ({self.total_events} events: "
            f"{self.human_events} human, {self.ai_events} AI):"
        )
        for ev in self.events:
            ts = datetime.datetime.fromtimestamp(ev.timestamp).strftime("%H:%M:%S")
            role = "HUMAN" if ev.actor_role == "writer" else "AI"
            lines.append(
                f"  {ts}  L{ev.agency_layer}  [{role}]  {ev.event_type}  {ev.phase}"
            )
        lines.append("")

        verified = "VERIFIED" if self.chain_verified else "FAILED"
        lines.append(
            f"CHAIN INTEGRITY: {verified} ({self.total_events}/{self.total_events} hashes valid)"
        )
        lines.append(f"Ledger: {self.ledger_path}")
        if self.first_hash:
            lines.append(f"First hash: {self.first_hash[:12]}...  Last hash: {self.last_hash[:12]}...")
        lines.append("")
        lines.append("This report is informational, not legal advice.")
        lines.append(f"Generated by swarm.at v{__version__}")
        return "\n".join(lines)
```

Add to the top of `authorship.py`:

```python
from swarm_at import __version__
```

Add `report()` to `WritingSession`:

```python
    def report(self) -> ProvenanceReport:
        """Generate a verifiable provenance report for this session."""
        wa = self.work_agency
        flags = self.behavioral_flags
        compliance = ComplianceAssessment.from_score(wa)

        # Phase scores
        phase_scores: dict[str, float] = {}
        phase_events: dict[CreativePhase, list[float]] = {}
        for ev in self.events:
            phase_events.setdefault(ev.phase, []).append(ev.agency.value / 5.0)
        for phase, scores in phase_events.items():
            phase_scores[phase.value] = sum(scores) / len(scores)

        # Event conversion
        prov_events = [
            ProvenanceEvent(
                event_type=ev.event_type,
                actor=ev.actor,
                actor_role=ev.actor_role,
                phase=ev.phase.value,
                agency_layer=ev.agency.value,
                timestamp=ev.timestamp,
                settlement_hash=ev.settlement_hash,
                metadata=ev.metadata,
            )
            for ev in self.events
        ]

        human = sum(1 for e in self.events if e.actor_role == "writer")
        ai = sum(1 for e in self.events if e.actor_role == "tool")

        first_hash = self.events[0].settlement_hash if self.events else ""
        last_hash = self.events[-1].settlement_hash if self.events else ""

        # Chain verification
        chain_ok = True
        if self.events and hasattr(self._ctx, "_engine") and self._ctx._engine:
            chain_ok = self._ctx._engine.ledger.verify_chain()

        return ProvenanceReport(
            session_id=self.session_id,
            writer=self.writer,
            tool=self.tool,
            started_at=self._started_at,
            completed_at=time.time(),
            work_agency=wa,
            work_agency_pct=f"{wa:.1%}",
            phase_scores=phase_scores,
            compliance=compliance,
            safe_harbor=compliance.safe_harbor,
            behavioral_flags=flags,
            total_events=len(self.events),
            human_events=human,
            ai_events=ai,
            events=prov_events,
            first_hash=first_hash,
            last_hash=last_hash,
            chain_verified=chain_ok,
            ledger_path=str(self._ctx._engine.ledger.path)
            if hasattr(self._ctx, "_engine") and self._ctx._engine
            else "",
        )
```

**Step 4: Run tests to verify they pass**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py -v --tb=short`
Expected: 66 passed

**Step 5: Commit**

```bash
git add swarm_at/authorship.py tests/test_authorship.py
git commit -m "Add provenance report generation with text output"
```

---

### Task 8: Export from __init__.py and final integration test

**Files:**
- Modify: `swarm_at/__init__.py`
- Modify: `tests/test_authorship.py`

**Step 1: Write the failing test**

Append to `tests/test_authorship.py`:

```python
class TestPublicImports:
    """Verify WritingSession is importable from swarm_at."""

    def test_import_from_package(self) -> None:
        from swarm_at import WritingSession as WS
        assert WS is WritingSession


class TestEndToEnd:
    """Full session lifecycle: create, record events, generate report."""

    def test_full_screenplay_session(self, tmp_path: Path) -> None:
        session = WritingSession(
            writer="mark-ghuneim",
            tool="claude-sonnet-4-5",
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )

        # Act 1: Concept and structure (pure human, L5)
        session.direct(
            action="premise",
            chose="AI agency framework explainer",
            rejected=["listicle", "academic paper"],
            phase=CreativePhase.CONCEPT,
            agency=AgencyLayer.L5_PURE_TOOL,
        )
        session.direct(
            action="structure",
            chose="six-layer progressive disclosure",
            phase=CreativePhase.STRUCTURE,
            agency=AgencyLayer.L5_PURE_TOOL,
        )

        # Act 2: Drafting with AI assistance (L3-L4)
        session.prompt(
            text="Draft the section on the 90% threshold",
            phase=CreativePhase.SCENE,
        )
        session.generate(
            output_hash="a" * 64,
            model="claude-sonnet-4-5",
            params={"temperature": 0.7},
            phase=CreativePhase.SCENE,
            agency=AgencyLayer.L2_COLLABORATOR,
        )
        session.revise(
            description="Rewrote framing, kept legal citations, cut 40%",
            kept_ratio=0.35,
            phase=CreativePhase.SCENE,
            agency=AgencyLayer.L4_DIRECTOR,
        )

        # Act 3: Dialogue polish (L2-L3)
        session.prompt(
            text="Suggest stakeholder positioning language",
            phase=CreativePhase.DIALOGUE,
        )
        session.generate(
            output_hash="b" * 64,
            phase=CreativePhase.DIALOGUE,
            agency=AgencyLayer.L2_COLLABORATOR,
        )
        session.reject(
            output_hash="b" * 64,
            reason="Too corporate, doesn't match voice",
            phase=CreativePhase.DIALOGUE,
        )

        # Final approval
        session.approve(content_hash="f" * 64, version="v1.0")

        # Verify
        report = session.report()
        assert report.total_events == 9
        assert report.human_events == 7
        assert report.ai_events == 2
        assert report.work_agency > 0.70  # should be well above L3
        assert report.chain_verified
        assert not report.behavioral_flags.missing_foundation
        assert not report.behavioral_flags.anchoring_risk

        # Text report is non-empty and has key sections
        text = report.to_text()
        assert "mark-ghuneim" in text
        assert "claude-sonnet-4-5" in text
        assert "VERIFIED" in text
        assert len(text) > 500
```

**Step 2: Run tests to verify they fail**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py::TestPublicImports -v --tb=short`
Expected: FAIL — `cannot import name 'WritingSession' from 'swarm_at'`

**Step 3: Update __init__.py**

In `swarm_at/__init__.py`, add the import and export:

Add after the existing imports:
```python
from swarm_at.authorship import WritingSession
```

Add `"WritingSession"` to the `__all__` list.

**Step 4: Run all tests to verify everything passes**

Run: `source .venv/bin/activate && python -m pytest tests/test_authorship.py -v --tb=short`
Expected: 68 passed

Then run the full suite to confirm no regressions:

Run: `source .venv/bin/activate && python -m pytest tests/ -v --tb=short 2>&1 | tail -5`
Expected: all existing tests + new tests pass

**Step 5: Commit**

```bash
git add swarm_at/__init__.py swarm_at/authorship.py tests/test_authorship.py
git commit -m "Export WritingSession from package, add end-to-end test"
```

---

### Task 9: Lint and type check

**Files:**
- Possibly modify: `swarm_at/authorship.py` (fix any lint/type issues)

**Step 1: Run ruff**

Run: `source .venv/bin/activate && python -m ruff check swarm_at/authorship.py tests/test_authorship.py`
Expected: no errors (or fix any that appear)

**Step 2: Run mypy**

Run: `source .venv/bin/activate && python -m mypy swarm_at/authorship.py --ignore-missing-imports`
Expected: no errors (or fix any that appear)

**Step 3: Fix any issues found**

Apply fixes as needed. Common issues:
- Missing type annotations on dict comprehensions
- `_ctx._engine` private access may need `# type: ignore` or a helper property

**Step 4: Run full test suite one final time**

Run: `source .venv/bin/activate && python -m pytest tests/ -v --tb=short 2>&1 | tail -5`
Expected: all tests pass

**Step 5: Commit**

```bash
git add swarm_at/authorship.py tests/test_authorship.py
git commit -m "Fix lint and type check issues in authorship module"
```
