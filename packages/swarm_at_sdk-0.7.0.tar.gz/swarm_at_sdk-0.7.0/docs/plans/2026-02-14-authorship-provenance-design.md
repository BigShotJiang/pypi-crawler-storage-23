# Authorship Provenance: WritingSession Design

**Status:** Implemented in `swarm_at/authorship.py` (77 tests in `tests/test_authorship.py`).

Settlement-backed audit trails for human-AI creative work, implementing the
Human-AI Agency Spectrum framework (Ghuneim, 2026) as a verifiable evidence layer.

## Problem

Legal standards (USCO), guild contracts (WGA, SAG-AFTRA, DGA), and the EU AI Act
all require proof of human creative control when AI tools are involved. The Agency
Spectrum framework defines six layers (L0-L5) and a 90% professional safe harbor
threshold, but specifies no mechanism for recording or verifying that evidence.

Writers using AI tools today have no tamper-evident way to prove:
- Which creative decisions they made vs. delegated
- What percentage of the work reflects human agency
- Whether the process meets compliance thresholds for copyright, guild credit,
  or EU marking exemptions

swarm.at already provides hash-chained, git-native settlement ledgers. This design
adds a `WritingSession` wrapper that maps every human decision and AI action to the
Agency Spectrum's L0-L5 layers, settles each event to the ledger, and produces
verifiable provenance reports with compliance assessments.

## Audience

- **Legal/copyright**: Evidentiary record for USCO "significant human control" claims
- **Publishers/editors**: Process documentation for AI disclosure requirements

## Decisions

- **SDK wrapper, not editor plugin**: Tool-agnostic Python class that any writing
  tool can integrate. Follows existing adapter pattern (LangGraph, CrewAI, etc.).
- **Decision-level granularity**: Every human choice and AI action is a separate
  settlement event. Strongest possible evidence chain.
- **Metadata + content hashes**: No raw content stored in the ledger. SHA-256 hashes
  of prompts, outputs, and edits. Content stays with the writer.
- **Inside swarm.at repo**: New module `swarm_at/authorship.py`. Ships with the SDK.

## Data Model

### Agency Layers

Six layers from the Agency Spectrum framework, encoded as an IntEnum:

```
L0_ORACLE       =  0   # ~0-14%   AI generates everything
L1_EXECUTOR     =  1   # ~15-39%  Human curates AI output
L2_COLLABORATOR =  2   # ~40-69%  Human selects/edits AI drafts
L3_SUPERVISOR   =  3   # ~70-89%  Human reviews/modifies AI suggestions
L4_DIRECTOR     =  4   # ~90-99%  Human directs, AI assists on command
L5_PURE_TOOL    =  5   # ~100%    Full human control, AI is passive
```

Normalized to 0.0-1.0 for scoring: `layer.value / 5.0`.

### Creative Phases

Six contribution types with weights from the Agency Spectrum weighted contribution
model:

```
CONCEPT     0.25   Foundational creative decision
STRUCTURE   0.20   Architectural framing
CHARACTER   0.15   Core creative expression
SCENE       0.15   Narrative architecture
DIALOGUE    0.15   Surface-level expression
REVISION    0.10   Refinement and quality control
```

These weights are the defaults. `WritingSession` accepts a custom `phase_weights`
dict at construction to support non-screenwriting workflows (novels, journalism,
technical writing) where the weight distribution differs.

### Event Types

Six event types, each recording who acted and what happened:

| Event Type           | Actor  | What It Records                                    |
|----------------------|--------|----------------------------------------------------|
| `creative-direction` | Human  | Outline choice, structural decision, theme selected |
| `prompt`             | Human  | Hash of prompt text given to AI tool               |
| `ai-generation`      | AI     | Hash of AI output, model, parameters               |
| `editorial-revision` | Human  | Description of edits, kept_ratio (0.0-1.0)         |
| `rejection`          | Human  | Hash of rejected AI output, reason                 |
| `approval`           | Human  | Final sign-off, hash of approved content            |

Every event carries:
- `phase`: which `CreativePhase` this belongs to
- `agency`: which `AgencyLayer` this represents
- `timestamp`: when the event was settled
- `settlement_hash`: the ledger hash from `SettlementContext.settle()`

### Default Agency Inference

When `agency` is omitted, inferred from event type:

```
direct()   → L4_DIRECTOR
prompt()   → L3_SUPERVISOR
generate() → L1_EXECUTOR
revise()   → L3_SUPERVISOR
reject()   → L4_DIRECTOR
approve()  → L4_DIRECTOR (phase: REVISION)
```

When `phase` is omitted, defaults to `SCENE`.

## API

### WritingSession

```python
class WritingSession:
    def __init__(
        self,
        writer: str,                              # human agent ID
        tool: str,                                # AI tool agent ID
        phase_weights: dict[CreativePhase, float] | None = None,  # custom weights
        tier: SettlementTier | None = None,       # sandbox/staging/production
        ledger_path: str = "ledger.jsonl",
    ) -> None: ...
```

Internally creates a `SettlementContext` and tracks events in an ordered list.

### Methods

```python
def direct(
    self,
    action: str,                          # what decision was made
    chose: str,                           # what was chosen
    rejected: list[str] | None = None,    # what was rejected
    phase: CreativePhase = CreativePhase.SCENE,
    agency: AgencyLayer = AgencyLayer.L4_DIRECTOR,
) -> SettlementResult: ...

def prompt(
    self,
    text: str,                            # prompt text (hashed, not stored)
    phase: CreativePhase = CreativePhase.SCENE,
    agency: AgencyLayer = AgencyLayer.L3_SUPERVISOR,
) -> SettlementResult: ...

def generate(
    self,
    output_hash: str,                     # SHA-256 of AI output (caller provides)
    model: str = "",                      # model identifier
    params: dict[str, Any] | None = None, # generation parameters
    phase: CreativePhase = CreativePhase.SCENE,
    agency: AgencyLayer = AgencyLayer.L1_EXECUTOR,
) -> SettlementResult: ...

def revise(
    self,
    description: str,                     # what the human changed
    kept_ratio: float,                    # 0.0-1.0: how much AI output was kept
    phase: CreativePhase = CreativePhase.SCENE,
    agency: AgencyLayer = AgencyLayer.L3_SUPERVISOR,
) -> SettlementResult: ...

def reject(
    self,
    output_hash: str,                     # hash of the rejected output
    reason: str,                          # why it was rejected
    phase: CreativePhase = CreativePhase.SCENE,
) -> SettlementResult: ...
# agency is always L4_DIRECTOR for rejections

def approve(
    self,
    content_hash: str,                    # hash of approved final content
    version: str = "",                    # version label
) -> SettlementResult: ...

def report(self) -> ProvenanceReport: ...
```

Each method calls `self._ctx.settle()` under the hood:
- `agent` = `self.writer` for human events, `self.tool` for AI events
- `task` = the event type string
- `data` = metadata dict with phase, agency layer, content hashes, descriptions

### Settlement Data Format

Example `data_update` dict settled to the ledger for a `revise()` call:

```json
{
    "event_type": "editorial-revision",
    "actor": "jane-doe",
    "actor_role": "writer",
    "phase": "scene",
    "agency_layer": 3,
    "description": "Rewrote opening, cut 2 paragraphs",
    "kept_ratio": 0.3,
    "session_id": "a1b2c3d4"
}
```

No raw content. Hashes of content where relevant (prompts, outputs). The writer
holds the content; the ledger holds the proof.

## Work Agency Calculation

### Interaction Agency

Per-event score, simple normalization:

```
interaction_agency = agency_layer / 5.0
```

### Work Agency

Weighted aggregate across the full session, following the Agency Spectrum formula:

```
For each phase with events:
    phase_events = all events in this phase
    phase_agency = mean(event.agency_layer / 5.0 for event in phase_events)

work_agency = sum(PHASE_WEIGHTS[p] * phase_agency[p] for p in phases_used)
            / sum(PHASE_WEIGHTS[p] for p in phases_used)
```

Normalization divides by the sum of weights for phases that actually have events.
A session covering only concept + structure + scene is scored against those three
phases' weights, not penalized for missing dialogue/revision/character.

### Verification

The paper's Case Study A produces 88.75%. Our calculation with the same inputs:

```
concept:   1.0 * 0.25 = 0.250
structure: 0.8 * 0.20 = 0.190   (L4 ≈ 95%, normalized to 0.8-1.0 range)
character: 1.0 * 0.15 = 0.150
scene:     0.6 * 0.15 = 0.120   (L3 ≈ 80%)
dialogue:  0.4 * 0.15 = 0.082   (L2 ≈ 55%)
revision:  0.8 * 0.10 = 0.095
                total  = 0.887 → 88.7%
```

Within rounding of the paper's result. The small delta comes from mapping
continuous percentages (95%, 80%, 55%) to discrete layers (L4, L3, L2). This is
consistent with the paper's own guidance: "The layer (not the exact percentage) is
the unit of practical analysis."

## Compliance Assessment

Maps the work agency score to four regulatory frameworks from the Agency Spectrum:

### Thresholds

```
>= 90% (L4-L5):
    safe_harbor  = True
    copyright    = "Clean — Full human authorship claim"
    wga          = "Full credit — Literary material"
    sag_aftra    = "Compliant with consent"
    eu_ai_act    = "Assistive function — Marking exempt"
    market_tier  = "Premium"

70-89% (L3):
    safe_harbor  = False
    copyright    = "Diluted — Defensible with documentation"
    wga          = "Conditional — L3 requires process evidence"
    sag_aftra    = "Enhanced consent required"
    eu_ai_act    = "Assistive function — Marking exempt"
    market_tier  = "Standard"

40-69% (L2):
    safe_harbor  = False
    copyright    = "Shared — Thin copyright at best"
    wga          = "Not literary material (studio use)"
    sag_aftra    = "Prohibited for performance"
    eu_ai_act    = "Marking required"
    market_tier  = "Budget"

< 40% (L0-L1):
    safe_harbor  = False
    copyright    = "Absent — No human authorship claim"
    wga          = "Not literary material"
    sag_aftra    = "Prohibited"
    eu_ai_act    = "Marking required"
    market_tier  = "Locked out of professional tiers"
```

These are informational assessments, not legal advice. The report includes a
disclaimer to that effect.

## Behavioral Constraint Detection

Three of the five constraints from Agency Spectrum Part III can be detected from
session data:

### Anchoring Risk

Triggered when the average `kept_ratio` across all `revise()` events exceeds 0.80.
High kept ratios suggest the writer is anchoring on AI output rather than
transforming it.

### Satisficing Risk

Triggered when 3+ consecutive `ai-generation` events occur without an intervening
human creative event (`creative-direction`, `editorial-revision`, or `rejection`).
Suggests the writer is accepting outputs without critical evaluation.

### Missing Foundation

Triggered when the first AI generation event (`generate()`) occurs before any
L4-L5 human creative event (`direct()`). The paper's "Photographer Principle"
argues that pre-AI creative work is what establishes authorship. A session that
starts with AI generation has no L4-L5 foundation.

### Output

Behavioral flags appear as warnings in the provenance report. They flag risk, not
guilt. A writer may have valid reasons for any of these patterns.

## Provenance Report

`session.report()` returns a `ProvenanceReport` Pydantic model with:

```python
class ProvenanceReport(BaseModel):
    session_id: str
    writer: str
    tool: str
    started_at: float
    completed_at: float | None

    # Scores
    work_agency: float                          # 0.0-1.0 weighted aggregate
    work_agency_pct: str                        # "87.5%" formatted string
    phase_scores: dict[str, float]              # per-phase agency scores

    # Compliance
    compliance: ComplianceAssessment
    safe_harbor: bool

    # Behavioral flags
    behavioral_flags: BehavioralFlags

    # Events
    total_events: int
    human_events: int
    ai_events: int
    events: list[ProvenanceEvent]

    # Chain verification
    first_hash: str
    last_hash: str
    chain_verified: bool
    ledger_path: str
```

### Text Report

`report.to_text()` produces a human-readable summary suitable for submission to
publishers, legal review, or compliance documentation. Format:

```
AUTHORSHIP PROVENANCE REPORT
Session / Writer / Tool / Period

WORK AGENCY: score — layer classification

Phase Breakdown (bar chart per phase)

SAFE HARBOR STATUS

COMPLIANCE ASSESSMENT (copyright, WGA, SAG-AFTRA, EU AI Act, market tier)

BEHAVIORAL FLAGS (warnings if any)

EVENT TIMELINE (chronological, with layer/actor/type/phase per event)

CHAIN INTEGRITY (verified count)
Ledger path, first/last hash

Disclaimer + generator version
```

## Integration Layer (Proprietary)

**Status:** Implemented. Deliberately omitted from public discovery (agent card, llms.txt, SDK).

### MCP Tools (4 tools on `SettlementMCPServer`)

| Tool | Purpose |
|------|---------|
| `start_writing_session` | Create session, returns session_id |
| `record_writing_event` | Record direction/prompt/generation/revision/rejection |
| `approve_writing` | Final sign-off with content hash |
| `get_provenance_report` | JSON report with agency score + compliance |

Server methods on `SettlementMCPServer` in `mcp/server.py`. Sessions stored in
`server._writing_sessions: WritingSessionStore` (in-memory).

Tool wrappers in `create_mcp_app()` serialize to JSON strings. `record_writing_event`
takes `rejected` as a JSON array string (MCP tools can't pass lists natively).

### REST API (7 endpoints, auth required)

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/v1/authorship/sessions` | List/filter/paginate sessions |
| DELETE | `/v1/authorship/sessions/{id}` | Delete session |
| POST | `/v1/authorship/sessions` | Create session |
| POST | `/v1/authorship/sessions/{id}/events` | Record event |
| POST | `/v1/authorship/sessions/{id}/approve` | Approve content |
| GET | `/v1/authorship/sessions/{id}/report` | JSON report |
| GET | `/v1/authorship/sessions/{id}/report/text` | Plain text report |

Sessions stored in `state.writing_sessions: WritingSessionStore` (in-memory,
reset by `_reset_api_state` fixture in tests).

Request models: `CreateSessionRequest`, `RecordEventRequest`, `ApproveRequest`
(Pydantic, defined in `api/main.py`).

### What is NOT exposed

- **Agent card**: No authorship skills listed (proprietary)
- **llms.txt**: Mentions WritingSession as Python SDK import only
- **SDK client**: No authorship convenience methods

### Tests

- `tests/test_mcp.py` — 34 tests (session lifecycle, all 5 event types, error cases)
- `tests/test_authorship_api.py` — 18 tests (REST endpoints, auth, error codes)

## File Structure

```
swarm_at/authorship.py       # All authorship provenance code
swarm_at/mcp/server.py       # 4 authorship methods + 4 MCP tool wrappers
swarm_at/api/main.py         # 7 REST endpoints + 3 Pydantic request models
swarm_at/api/state.py        # writing_sessions dict
tests/test_authorship.py     # 77 tests — core WritingSession
tests/test_mcp.py            # 34 tests — MCP authorship tools
tests/test_session_store.py  # 11 tests — session store persistence
tests/test_authorship_api.py # 18 tests — REST API endpoints
swarm_at/__init__.py         # WritingSession in __all__
```

### What Goes in authorship.py

- `AgencyLayer` (IntEnum)
- `CreativePhase` (str Enum)
- `PHASE_WEIGHTS` (dict)
- `AuthorshipEvent` (Pydantic model, internal)
- `BehavioralFlags` (Pydantic model)
- `ComplianceAssessment` (Pydantic model)
- `ProvenanceEvent` (Pydantic model)
- `ProvenanceReport` (Pydantic model, with `to_text()`)
- `WritingSession` (main class)
- `WritingSessionStore` (in-memory session store)
- `PersistentWritingSessionStore` (JSONL-backed session store)
- `to_dict()` / `from_dict()` (serialization methods on WritingSession)

Single file. No changes to existing modules beyond the `__init__.py` export.

### What Does NOT Change

- `models.py`, `settler.py`, `engine.py` — untouched
- `settle.py` / `SettlementContext` — used as-is via composition
- Existing adapters — unaffected
- Existing tests — unaffected

## Testing Strategy

Following the project's existing conventions (conftest fixtures, factory functions,
parametrize with ids, assertion helpers):

### Test Helpers

Tests use class-level helper methods for session creation:

```python
class TestWorkAgency:
    def _make_session(self, tmp_path: Path) -> WritingSession: ...

class TestProvenanceReport:
    def _make_full_session(self, tmp_path: Path) -> WritingSession: ...
```

All tests use `tmp_path` for isolated ledger files (no shared state between tests).

### Test Categories

1. **Event settlement** — each method settles correctly, data_update contains
   expected fields, hash chain advances
2. **Agency defaults** — omitted agency/phase parameters use correct defaults
3. **Work agency calculation** — reproduces Case Study A (88.75%), Case Study B
   (75.5%), edge cases (single phase, all L5, all L0)
4. **Compliance mapping** — threshold boundaries (89.9% vs 90.0%, 69.9% vs 70.0%)
5. **Behavioral flags** — anchoring (high kept_ratio), satisficing (consecutive
   generates), missing foundation (generate before direct)
6. **Report generation** — text output format, event ordering, chain verification
7. **Custom weights** — non-default phase_weights produce correct scores
8. **Tier support** — sandbox mode returns synthetic hashes, production enforces chain

## References

- Ghuneim, M. (2026). "On the Calculation of The Human-AI Agency Spectrum."
  Narrative.new. CC BY 4.0.
- U.S. Copyright Office, "Copyright Registration Guidance: Works Containing
  Material Generated by Artificial Intelligence" (2023)
- WGA Minimum Basic Agreement, AI Provisions (2023, updated December 2025)
- SAG-AFTRA AI Provisions and Four Pillars of Ethical AI (2025)
- EU AI Act, Article 50: Transparency Obligations (Regulation 2024/1689)
