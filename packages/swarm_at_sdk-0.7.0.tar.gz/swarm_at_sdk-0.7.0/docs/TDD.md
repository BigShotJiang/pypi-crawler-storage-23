# Technical Design Document: swarm.at

**Version:** 1.0.0
**Date:** 2026-02-07
**Status:** Implemented (358 tests passing)
**Repository:** https://github.com/Mediaeater/swarm.at
**Live:** https://swarm.at

---

## 1. Foundational Specifications

### 1.1 Functional Requirements

| ID | Requirement | Status |
|----|------------|--------|
| FR-01 | Agents submit proposals containing a parent hash, payload, and confidence score | Implemented |
| FR-02 | Settlement engine verifies hash-chain integrity before committing | Implemented |
| FR-03 | Proposals below confidence threshold are rejected | Implemented |
| FR-04 | Cross-model divergence above drift threshold triggers escrow | Implemented |
| FR-05 | Settled entries are appended to an immutable JSONL ledger | Implemented |
| FR-06 | Full hash-chain verification walkable at any time | Implemented |
| FR-07 | Context injector prunes shared state into keyword-filtered slices | Implemented |
| FR-08 | Dispatcher routes tasks to model tiers by complexity score | Implemented |
| FR-09 | Multi-agent consensus via stake/verify/finalize rounds | Implemented |
| FR-10 | Agents earn trust through settlement history (UNTRUSTED to SENIOR) | Implemented |
| FR-11 | Workflows chain atomic beads into molecules with dependency tracking | Implemented |
| FR-12 | Git-backed ledger supports branching and merging for parallel agents | Implemented |
| FR-13 | REST API exposes settle, context, status, and ledger endpoints | Implemented |
| FR-14 | MCP server gates high-risk agent actions via settlement tokens | Implemented |
| FR-15 | Python SDK provides settle, context_slice, and shadow_audit | Implemented |
| FR-16 | Periodic heartbeat settles work summaries and detects drift | Implemented |
| FR-17 | Graduated settlement tiers (sandbox/staging/production) with env-based config | Implemented |
| FR-18 | One-liner `settle()` public API with local and remote modes | Implemented |
| FR-19 | Framework adapters for LangGraph, AutoGen, CrewAI, OpenAI Assistants | Implemented |
| FR-20 | Canonical agent seeding with settlement histories | Implemented |
| FR-21 | Machine-readable `/public/schema` endpoint for protocol discovery | Implemented |
| FR-22 | 35 settlement types covering knowledge verification and agent behaviors | Implemented |

### 1.2 Technical Specifications

- **Language:** Python 3.10+
- **Runtime:** CPython, stdlib-first (external libs only when complexity reduction >50%)
- **Framework:** FastAPI 0.110+ (HTTP API), FastMCP (MCP server)
- **Data Validation:** Pydantic v2
- **HTTP Client:** httpx 0.27+
- **Hash Algorithm:** SHA-256 (deterministic via `json.dumps(sort_keys=True)`)
- **Ledger Format:** Append-only JSONL, one entry per line
- **Genesis Hash:** `"0" * 64` (64 zero characters)
- **Type Checking:** mypy strict mode
- **Linting:** ruff
- **Testing:** pytest with datasette-enrichments conventions

### 1.3 Constraints

- **Statelessness:** No agent sessions. Every call is a pure function: `(Context + Task) = Proposal`.
- **Determinism:** All state updates verified against institutional rules before commit.
- **Immutability:** Settled ledger entries cannot be altered. Hash-chain enforces this.
- **Thrift:** Minimize infrastructure. Flat-file storage. Serverless-compatible.
- **No External State:** Agents never read mutable global state. They receive read-only context slices.

---

## 2. System Architecture

### 2.1 High-Level Component Diagram

```mermaid
graph TB
    subgraph "Client Layer"
        SDK[Python SDK<br>SwarmClient]
        API_CLIENT[HTTP Client]
        MCP_CLIENT[MCP Agent]
    end

    subgraph "API Layer"
        REST[FastAPI<br>/v1/settle, /v1/context<br>/v1/status, /v1/ledger/*]
        MCP[MCP Server<br>settle_action<br>check_settlement]
    end

    subgraph "Engine Layer"
        ENGINE[SwarmAtEngine<br>verify_and_settle]
        DISPATCH[Dispatcher<br>score_complexity<br>select_tier]
        CTX[Context Injector<br>get_context_slice]
        AUDITOR[Shadow Auditor<br>@shadow_audit]
        CONSENSUS[ConsensusEngine<br>stake/verify/finalize]
        PULSE[SettlementPulse<br>drift detection]
    end

    subgraph "Identity Layer"
        REGISTRY[AgentRegistry<br>register/promote/revoke]
        IDENTITY[AgentIdentity<br>trust levels, roles]
    end

    subgraph "Workflow Layer"
        WF_ENGINE[WorkflowEngine]
        MOLECULE[Molecule<br>chained beads]
        FORMULA[Formula<br>templates]
        CONVOY[Convoy<br>feature tracking]
    end

    subgraph "Storage Layer"
        LEDGER[Ledger<br>JSONL hash-chain]
        GIT[GitLedger<br>git-backed branches]
    end

    SDK --> REST
    API_CLIENT --> REST
    MCP_CLIENT --> MCP

    REST --> ENGINE
    MCP --> ENGINE
    REST --> CTX

    ENGINE --> LEDGER
    ENGINE --> AUDITOR
    CONSENSUS --> ENGINE
    PULSE --> ENGINE
    WF_ENGINE --> ENGINE

    WF_ENGINE --> MOLECULE
    FORMULA --> MOLECULE
    CONVOY --> MOLECULE

    GIT --> LEDGER

    REGISTRY --> IDENTITY
```

### 2.2 Data Flow: Triage-Execute-Settle

```mermaid
sequenceDiagram
    participant A as Agent
    participant D as Dispatcher
    participant C as Context Injector
    participant E as Settlement Engine
    participant S as Shadow Auditor
    participant L as Ledger

    A->>D: Submit task
    D->>D: score_complexity(task)
    D-->>A: TierConfig (thrifty/standard/premium)

    A->>C: Request context slice
    C->>C: Filter shared state by keywords
    C-->>A: Pruned context

    A->>A: Execute task with context
    A->>E: Submit Proposal (parent_hash, payload, confidence)

    E->>L: get_latest_hash()
    L-->>E: current chain head

    E->>E: 1. Integrity check (parent_hash == latest)
    E->>E: 2. Confidence check (>= min_confidence)

    opt Shadow proposal provided
        E->>S: calculate_divergence(primary, shadow)
        S-->>E: divergence score
        E->>E: 3. Divergence check (<= max_drift)
    end

    alt All checks pass
        E->>L: append_entry(entry)
        E-->>A: SETTLED + hash
    else Integrity or confidence fail
        E-->>A: REJECTED + reason
    else High divergence
        E-->>A: ESCROWED + reason
    end
```

### 2.3 Consensus Flow: Multi-Agent Settlement

```mermaid
sequenceDiagram
    participant A1 as Agent A (Staker)
    participant CE as ConsensusEngine
    participant A2 as Agent B (Verifier)
    participant A3 as Agent C (Verifier)
    participant E as SwarmAtEngine
    participant L as Ledger

    A1->>CE: stake(task_id, proposal)
    CE-->>A1: ConsensusRound(STAKED)

    A2->>CE: verify(task_id, agrees=true)
    CE-->>A2: ConsensusRound(STAKED, 1 verification)

    A3->>CE: verify(task_id, agrees=true)
    CE->>CE: threshold met (2 >= required)
    CE->>E: verify_and_settle(staked_proposal)
    E->>L: append_entry
    CE-->>A3: ConsensusRound(FINALIZED, settled_hash)
```

---

## 3. Data Model

### 3.1 Class Diagram

```mermaid
classDiagram
    class Proposal {
        +Header header
        +Payload payload
        +str|None proof
    }

    class Header {
        +str task_id  [UUID]
        +str parent_hash  [64 hex chars]
        +AgentMetadata agent_metadata
    }

    class Payload {
        +dict data_update
        +float confidence_score  [0.0-1.0]
    }

    class LedgerEntry {
        +float timestamp
        +str task_id
        +str parent_hash
        +dict payload
        +str current_hash
    }

    class SettlementResult {
        +SettlementStatus status
        +str|None hash
        +str|None reason
    }

    class InstitutionalRules {
        +float min_confidence  [0.85]
        +float max_drift_allowed  [0.15]
    }

    class AgentIdentity {
        +str agent_id
        +AgentRole role
        +TrustLevel trust_level
        +list capabilities
        +int settlements_completed
        +int settlements_failed
        +list settlement_history
        +float divergence_penalty
        +bool under_review
        +success_rate() float
        +reputation_score() float
        +rolling_success_rate() float
        +can_stake() bool
        +can_verify() bool
        +can_merge() bool
        +can_orchestrate() bool
    }

    class Bead {
        +str bead_id
        +str name
        +str agent_id
        +BeadStatus status
        +dict input_data
        +dict output_data
        +str|None settlement_hash
        +list depends_on
        +is_ready(completed) bool
    }

    class Molecule {
        +str molecule_id
        +str name
        +list~Bead~ beads
        +MoleculeStatus status
        +add_bead() Bead
        +ready_beads() list~Bead~
        +progress() float
        +is_complete() bool
    }

    class Ledger {
        +Path path
        +get_latest_hash() str
        +append_entry(entry) void
        +read_all() list~LedgerEntry~
        +verify_chain() bool
    }

    class GitLedger {
        +Path repo_path
        +str branch
        +create_branch() GitLedger
        +merge(source) MergeResult
        +branches() list
        +log() list
    }

    Proposal --> Header
    Proposal --> Payload
    Header --> AgentMetadata
    Molecule --> Bead
    GitLedger --|> Ledger
    SettlementResult --> SettlementStatus
    AgentIdentity --> AgentRole
    AgentIdentity --> TrustLevel
```

### 3.2 Settlement Status Enumeration

| Status | Meaning | Trigger |
|--------|---------|---------|
| `SETTLED` | Committed to ledger | All verification checks pass |
| `REJECTED` | Denied entry | Parent hash mismatch or confidence below threshold |
| `ESCROWED` | Held for review | Shadow audit divergence exceeds `max_drift_allowed` |

### 3.3 Trust Level Progression

| Level | Requirements | Permissions |
|-------|-------------|-------------|
| `UNTRUSTED` | Default for new agents | Execute only |
| `PROVISIONAL` | 5+ settlements, 90%+ success rate | Stake, verify |
| `TRUSTED` | 20+ settlements, 0.95+ reputation score | Merge branches |
| `SENIOR` | 100+ settlements, 99.5%+ success rate | Orchestrate workflows |

---

## 4. Governance

### 4.1 Design Patterns

| Pattern | Where Applied | Rationale |
|---------|--------------|-----------|
| **Pipeline** | `SwarmAtEngine.verify_and_settle()` | Sequential verification steps with early exit on failure |
| **Decorator** | `shadow_audit()` in auditor.py | Wraps agent functions with transparent cross-model verification |
| **Strategy** | `Dispatcher.select_tier()` | Swappable model tier selection based on complexity score |
| **Template Method** | `Formula.instantiate()` | Formulas define step patterns, instantiation fills in concrete beads |
| **Registry** | `AgentRegistry`, `WorkflowEngine` | Centralized lifecycle management for agents and workflows |
| **Chain of Responsibility** | Hash-chain ledger | Each entry links to its parent, forming a verifiable chain |
| **Observer** | `SettlementPulse` | Periodic check-in that reacts to drift between local and ledger state |
| **Adapter** | `GitLedger extends Ledger` | Git-backed storage adapts the flat-file Ledger interface |

### 4.2 Principles

- **Immutability First:** Ledger entries are append-only. No updates, no deletes.
- **Verify Before Write:** Every state-modifying operation passes through `verify_and_settle()`.
- **Earn Trust:** Agents start at zero. Permissions are granted through proven settlement history.
- **Fail Safe:** Rejected proposals return a reason. Escrowed proposals are flagged, not lost.
- **Single Responsibility:** Each module handles one concern (settling, dispatching, auditing, etc.).
- **Open/Closed:** New model tiers, trust levels, and workflow patterns can be added without modifying existing verification logic.

### 4.3 Coding Standards

- Python 3.10+ with `from __future__ import annotations`
- Pydantic `BaseModel` for all data structures crossing boundaries
- mypy strict mode, all generics parameterized
- ruff for formatting and linting (100 char line length)
- Tests follow datasette-enrichments style: shared `conftest.py`, factory functions, `@pytest.mark.parametrize` with `ids=`
- SHA-256 hashes must be exactly 64 hex characters (test convention: `"0" * 64`)

---

## 5. Component Specifications

### 5.1 Settlement Engine (`engine.py`)

The core orchestrator. Takes a primary proposal and optional shadow proposal, runs a 4-step verification pipeline, and either commits to the ledger or returns a rejection/escrow.

**Inputs:** `Proposal` (primary), `Proposal | None` (shadow)
**Outputs:** `SettlementResult` (status + hash or reason)
**Dependencies:** `Ledger`, `InstitutionalRules`

### 5.2 Ledger (`settler.py`)

Append-only JSONL file with SHA-256 hash chaining. Each entry's `current_hash` is computed from the entry content (with the hash field zeroed), and becomes the `parent_hash` of the next entry.

**Hash function:** `SHA-256(json.dumps(content, sort_keys=True).encode())`
**Chain invariant:** `entry[n].parent_hash == entry[n-1].current_hash`

### 5.3 Dispatcher (`dispatcher.py`)

Scores task complexity on a 0.0-1.0 scale using three heuristics (description length, step count, keyword presence) and routes to the cheapest capable model tier.

| Tier | Range | Default Model |
|------|-------|---------------|
| Thrifty | 0.0-0.3 | claude-haiku-4-5 |
| Standard | 0.3-0.7 | claude-sonnet-4-5 |
| Premium | 0.7-1.0 | claude-opus-4-6 |

### 5.4 Context Injector (`context.py`)

Single function. Filters a shared state dict by keyword match, always including `core_logic` by default.

### 5.5 Shadow Auditor (`auditor.py`)

Python decorator. Runs a primary function and a shadow function, compares outputs via structural key-level divergence. Raises `DivergenceError` if drift exceeds threshold.

### 5.6 Consensus Engine (`consensus.py`)

Multi-agent coordination. One agent stakes a solution, others verify or contest. Finality when agreement count meets the configurable threshold. Uses the settlement engine to commit the winning proposal.

### 5.7 Agent Identity (`agents.py`)

Registry-based lifecycle. Agents register with roles, start `UNTRUSTED`, and auto-promote based on settlement volume and success rates. Circuit breaker demotes agents whose rolling 10-task success rate drops below 80%.

### 5.8 Workflow Engine (`workflow.py`)

Beads (atomic tasks) chain into Molecules (workflows) via dependency graphs. Formulas template reusable patterns. Convoys group molecules for feature-level tracking. Each bead settlement commits to the ledger.

### 5.9 Git Data Plane (`gitplane.py`)

`GitLedger` extends `Ledger` with git-backed storage. Each `append_entry()` creates a git commit. Supports `create_branch()` for parallel agent work and `merge()` with conflict detection.

### 5.10 API (`api/main.py`)

FastAPI service with Bearer token auth. 5 authenticated endpoints (`/v1/*`) + 4 public endpoints (`/public/*`) + health check.

### 5.11 MCP Server (`mcp/server.py`)

Exposes `settle_action`, `check_settlement`, and `ledger_status` as MCP tools. Blocked command patterns deny destructive operations before they reach the settlement engine.

### 5.12 SDK (`sdk/client.py`)

`SwarmClient` wraps the HTTP API with typed methods. Supports context manager pattern for connection cleanup. `shadow_audit` delegates to the decorator in `auditor.py`.

### 5.13 Settlement Tiers (`tiers.py`)

`SettlementTier` enum (SANDBOX/STAGING/PRODUCTION) with `TierPolicy` Pydantic model controlling enforcement flags. `get_tier()` reads `SWARM_TIER` env var, defaults to PRODUCTION.

### 5.14 Public API (`settle.py`)

`SettlementContext` wraps an in-process engine (local mode) or `SwarmClient` (remote mode when `SWARM_API_URL` set). Tracks `parent_hash` between calls. SANDBOX returns synthetic hashes without touching the ledger. STAGING syncs parent hash to skip chain enforcement.

Module-level `settle()` uses a lazy singleton context. `reset_context()` prevents test leakage.

### 5.15 Framework Adapters (`adapters/`)

Four adapters for LangGraph (`SwarmNodeWrapper`), AutoGen (`SwarmReplyCallback`), CrewAI (`SwarmTaskCallback`), and OpenAI Assistants (`SwarmRunHandler`). All use `getattr` on duck-typed objects -- no framework imports required. Tests use `MagicMock`.

### 5.16 Agent Seeding (`seed.py`)

`CANONICAL_AGENTS` list of 5 agents with roles and target trust levels. `seed_registry()` bootstraps a registry by recording settlement histories.

---

## 6. Algorithmic Logic: Three Most Complex Blocks

### 6.1 Settlement Verification Pipeline

The core algorithm. Every state change flows through this. Correctness here is the entire system's integrity guarantee.

```
FUNCTION verify_and_settle(primary, shadow=None):
    latest_hash = ledger.get_latest_hash()

    # Step 1: Hash-chain integrity
    IF primary.header.parent_hash != latest_hash:
        RETURN REJECTED("State drift detected. Re-base required.")

    # Step 2: Confidence threshold
    IF primary.payload.confidence_score < rules.min_confidence:
        RETURN REJECTED("Insufficient confidence: {score} < {threshold}")

    # Step 3: Shadow audit (optional)
    IF shadow IS NOT NULL:
        divergence = calculate_divergence(primary, shadow)
        IF divergence > rules.max_drift_allowed:
            RETURN ESCROWED("High model divergence: {divergence} > {max_drift}")

    # Step 4: Finality — construct entry and commit
    entry = {
        timestamp: now(),
        task_id: primary.header.task_id,
        parent_hash: latest_hash,
        payload: primary.payload.data_update,
        current_hash: ""    # placeholder for hash computation
    }
    entry.current_hash = SHA256(json_sorted(entry))
    ledger.append(entry)

    RETURN SETTLED(hash=entry.current_hash)
```

**Key invariant:** The `current_hash` is computed with the hash field set to empty string, then filled in. This prevents circular dependency while ensuring the hash covers all other fields.

### 6.2 Trust Calculation with Circuit Breaker

Determines an agent's trust level using volume thresholds, reputation scoring, and a rolling-window circuit breaker that catches sudden performance drops.

```
FUNCTION calculate_trust(agent):
    # Hard block: agents under review are always UNTRUSTED
    IF agent.under_review:
        RETURN UNTRUSTED

    total = agent.settlements_completed + agent.settlements_failed

    # Circuit breaker: rolling window demotion
    # Catches sudden degradation even in high-volume agents
    IF total >= ROLLING_WINDOW (10):
        recent = last 10 settlement records
        rolling_rate = count(success in recent) / len(recent)
        IF rolling_rate < ROLLING_THRESHOLD (0.80):
            RETURN PROVISIONAL    # immediate demotion regardless of lifetime stats

    # Promotion checks (highest tier first, so agents get max earned level)

    # SENIOR: 100+ settlements, 99.5%+ simple success rate
    IF total >= 100 AND success_rate >= 0.995:
        RETURN SENIOR

    # TRUSTED: 20+ settlements, 0.95+ reputation score
    # (reputation = complexity-weighted success minus divergence penalty)
    IF total >= 20 AND reputation_score >= 0.95:
        RETURN TRUSTED

    # PROVISIONAL: 5+ settlements, 90%+ success rate
    IF total >= 5 AND success_rate >= 0.90:
        RETURN PROVISIONAL

    RETURN UNTRUSTED
```

**Key subtlety:** Reputation score is not simple success rate. It weights by task complexity:
```
reputation = SUM(complexity_i for successful tasks) / SUM(complexity_i for all tasks) - divergence_penalty
```
An agent that succeeds on hard tasks ranks higher than one that succeeds only on easy ones.

### 6.3 Consensus Evaluation with Contest Recovery

Manages the multi-agent agreement protocol. Handles staking, verification, contest detection, and automatic re-staking after contested rounds.

```
FUNCTION stake(task_id, agent_id, proposal):
    IF task_id IN active_rounds:
        existing = rounds[task_id]
        IF existing.status == FINALIZED:
            RAISE "already finalized"
        IF existing.status NOT IN (CONTESTED, REJECTED):
            RAISE "already has active stake from {existing.staker}"
        # Allow re-staking after contest/rejection (recovery path)

    round = new ConsensusRound(
        task_id, stake=(agent_id, proposal),
        required_verifications=threshold
    )
    rounds[task_id] = round
    RETURN round

FUNCTION verify(task_id, agent_id, agrees, counter_proposal=None):
    round = rounds[task_id]

    # Guard rails
    IF round.status == FINALIZED: RAISE "already finalized"
    IF agent_id == round.staker: RAISE "cannot self-verify"
    IF agent_id IN round.existing_verifiers: RAISE "already verified"

    # Record verification with optional counter-proposal
    IF NOT agrees AND counter_proposal IS NOT NULL:
        divergence = calculate_divergence(round.stake.proposal, counter_proposal)

    round.verifications.append(agent_id, agrees, counter_proposal)
    RETURN evaluate(round)

FUNCTION evaluate(round):
    agrees = count(v for v in verifications WHERE v.agrees)
    contests = count(v for v in verifications WHERE NOT v.agrees)

    # Enough agreements → finalize via settlement engine
    IF agrees >= required_verifications:
        result = engine.verify_and_settle(round.stake.proposal)
        IF result.status == SETTLED:
            round.status = FINALIZED
            round.settled_hash = result.hash
        ELSE:
            round.status = REJECTED
        RETURN round

    # Enough verifications received but contested → mark CONTESTED
    # This allows a new agent to re-stake with a better proposal
    IF contests > 0 AND total_verifications >= required_verifications:
        round.status = CONTESTED
        RETURN round

    # Still waiting for more verifications
    RETURN round
```

**Recovery path:** When a round is `CONTESTED`, any new agent can call `stake()` again with a corrected proposal. This creates a self-healing loop where bad proposals are replaced without manual intervention.

---

## 7. Deployment Architecture

```mermaid
graph LR
    subgraph "GitHub Pages"
        LP[Landing Page<br>swarm.at]
        SPEC[SPEC.html]
    end

    subgraph "Railway"
        API[FastAPI<br>api.swarm.at]
        VOL[(/data volume)]
        API --> VOL
    end

    subgraph "PyPI"
        PKG[swarm-at 0.1.0]
    end

    subgraph "Agent Runtime"
        AGENT[AI Agent]
        AGENT -->|pip install| PKG
        AGENT -->|HTTP| API
        AGENT -->|MCP stdio| MCP_LOCAL[Local MCP Server]
    end

    LP --> SPEC
```

### 7.1 Infrastructure

| Component | Platform | URL |
|-----------|----------|-----|
| Landing page | GitHub Pages | https://swarm.at |
| API | Railway (Docker) | https://api.swarm.at |
| Package | PyPI | `pip install swarm-at` |
| Ledger storage | Persistent volume (`/data`) | N/A |

---

## 8. Test Coverage Summary

| Module | Test File | Tests | Coverage Focus |
|--------|-----------|-------|---------------|
| Engine + Ledger | test_engine.py | 16 | Settlement pipeline, hash-chain, rejection scenarios |
| API | test_api.py | 10 | All endpoints, auth, error responses |
| Dispatcher | test_dispatcher.py | 7 | Complexity scoring, tier selection |
| Context | test_context.py | 5 | Keyword filtering, always_include |
| Auditor | test_auditor.py | 3 | Decorator, divergence detection |
| MCP | test_mcp.py | 6 | settle_action, check_settlement, blocked commands |
| Consensus | test_consensus.py | 14 | Staking, verification, threshold, contest recovery |
| Heartbeat | test_heartbeat.py | 10 | Drift detection, pulse, scheduling |
| Agents | test_agents.py | 35 | Registration, trust promotion, permissions, lookup |
| Workflow | test_workflow.py | 60 | Beads, molecules, formulas, convoys, engine |
| GitPlane | test_gitplane.py | 14 | Git basics, branching, merging, history |
| SDK | test_sdk.py | 37 | Client methods, context manager, shadow audit |
| Tiers | test_tiers.py | 18 | Tier enum, policies, env var, fallback |
| Settle API | test_settle.py | 13 | Local/sandbox/staging modes, chaining, module-level |
| Adapters | test_adapters.py | 16 | LangGraph, AutoGen, CrewAI, OpenAI (all MagicMock) |
| Seed | test_seed.py | 6 | Canonical agents, trust levels, custom definitions |
| Schema Endpoint | test_schema_endpoint.py | 10 | Schema fields, tiers, guarantees, no auth |
| Agent Registry API | test_agent_registry_api.py | 36 | Public agent endpoints |
| Public Ledger API | test_public_ledger.py | 42 | Public ledger endpoints |
| **Total** | | **358** | **~5s runtime** |

---

## 9. File Map

```
swarm_at/
  __init__.py                    Ergonomic exports: settle, SettlementContext, etc.
  models.py          62 lines   Pydantic schemas: Proposal, Header, Payload, LedgerEntry
  settler.py          73 lines   Ledger: JSONL hash-chain, generate_hash(), GENESIS_HASH
  engine.py          104 lines   SwarmAtEngine: verify_and_settle() pipeline
  context.py          21 lines   Context Injector: keyword-filtered state slices
  dispatcher.py       76 lines   Dispatcher: complexity scoring, model tier routing
  auditor.py          74 lines   Shadow Auditor: @shadow_audit decorator
  consensus.py       162 lines   ConsensusEngine: stake/verify/finalize rounds
  heartbeat.py       113 lines   SettlementPulse: periodic drift detection
  agents.py          262 lines   AgentIdentity, AgentRegistry, trust levels, roles
  workflow.py        316 lines   Bead, Molecule, Formula, Convoy, WorkflowEngine
  gitplane.py        195 lines   GitLedger: git-backed branching/merging data plane
  tiers.py                       SettlementTier enum, TierPolicy, env-based config
  settle.py                      SettlementContext + module-level settle() one-liner
  seed.py                        Canonical agent seeding (5 agents, 35 settlement types)
  adapters/
    __init__.py
    langgraph.py                 SwarmNodeWrapper: decorator for LangGraph nodes
    autogen.py                   SwarmReplyCallback: observer for AutoGen replies
    crewai.py                    SwarmTaskCallback: callback for CrewAI tasks
    openai_assistants.py         SwarmRunHandler: run + step settlement for Assistants
  api/
    __init__.py
    main.py                      FastAPI: 9 auth + 6 public endpoints + health check
    state.py                     Mutable API state (swappable in tests)
  mcp/
    __init__.py
    __main__.py                  Entry point: python -m swarm_at.mcp
    server.py        191 lines   SettlementMCPServer + FastMCP transport
  sdk/
    __init__.py
    client.py         84 lines   SwarmClient: HTTP wrapper + shadow_audit decorator
tests/
  conftest.py                    Shared fixtures, factory functions, assertion helpers
  test_engine.py                 16 tests
  test_api.py                    10 tests
  test_dispatcher.py              7 tests
  test_context.py                 5 tests
  test_auditor.py                 3 tests
  test_mcp.py                     6 tests
  test_consensus.py              14 tests
  test_heartbeat.py              10 tests
  test_agents.py                 35 tests
  test_workflow.py               60 tests
  test_gitplane.py               14 tests
  test_sdk.py                    37 tests
  test_tiers.py                  18 tests
  test_settle.py                 13 tests
  test_adapters.py               16 tests
  test_seed.py                    6 tests
  test_schema_endpoint.py        10 tests
  test_agent_registry_api.py     36 tests
  test_public_ledger.py          42 tests
docs/
  SPEC.md                        Protocol specification (markdown source)
  TDD.md                         Technical design document
  SPEC.html                      HTML spec page
  index.html                     Landing page
  CNAME                          Custom domain: swarm.at
scripts/
  seed_ledger.py                 Seed script: 35 settlement types, 167 entries
```
