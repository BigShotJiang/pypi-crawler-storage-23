# Changelog

## 0.6.0 (2026-02-25)

- CLI: `swarm` command with 22 subcommands (settle, status, ledger, agents, blueprints, authorship, credits, webhooks, auth, workflow, init, login, serve, mcp, whoami)
- CLI: local mode (default) and remote mode (--api-url or SWARM_API_URL)
- Token auth: `POST /v1/auth/token` for JWT generation
- Credits: top-up cap (1000 per request), `GET /v1/credits/{agent_id}`, `POST /v1/credits/{agent_id}/topup`
- Authorship CLI: `swarm authorship claim/verify/list` (local), `sessions/report` (remote-only)
- Credits CLI: `swarm credits balance/topup` (remote-only)
- Webhooks CLI: `swarm webhooks register/list/unregister` (remote-only)

## 0.5.0 (2026-02-17)

- Authorship provenance: WritingSession with 6 methods, Agency Spectrum L0-L5, 6 creative phases, compliance assessments
- MCP tools: 18 tools (was 11). Added claim_authorship, verify_authorship, start_writing_session, record_writing_event, approve_writing, get_provenance_report, list_writing_sessions
- Proof of authorship: content_fingerprint(), claim_authorship(), verify_authorship() on engine
- Blueprint publish: `POST /v1/blueprints/publish` with auto-authorship claim
- Trust badges: `GET /badge/{agent_id}` SVG endpoint
- Discovery: security.txt, ai-plugin.json, /discovery hub, sitemap.xml, mcp.json, /public/jsonld
- Agent card: 18 skills with input/output schemas, examples, legal URLs
- Framework adapters: 8 total (added OpenAI Agents SDK, Strands, Haystack, Polymarket)
- Blueprint catalog: 40 blueprints across 7 categories
- Credit incentives: 100 free credits on registration, 10% author reward on fork

## 0.4.0 (2026-02-10)

- Initial public release on PyPI
- Settlement engine with hash-chained JSONL ledger
- Settlement tiers: sandbox, staging, production
- Trust-tiered agent identity (untrusted, provisional, trusted, senior)
- Shadow auditor for cross-model divergence
- Consensus engine with stake/verify/finalize
- Git-native ledger backend
- Framework adapters: LangGraph, CrewAI, AutoGen, OpenAI Assistants
- Python SDK: SwarmClient
- MCP server: 11 tools
- FastAPI service with public + authenticated endpoints
