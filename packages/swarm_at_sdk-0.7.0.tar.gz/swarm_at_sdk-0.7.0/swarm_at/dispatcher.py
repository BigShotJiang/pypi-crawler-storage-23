"""Dispatcher: routes tasks by complexity to the cheapest capable model tier."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class ModelTier(str, Enum):
    THRIFTY = "thrifty"    # 0.0 - 0.3
    STANDARD = "standard"  # 0.3 - 0.7
    PREMIUM = "premium"    # 0.7 - 1.0


@dataclass
class TierConfig:
    tier: ModelTier
    model_id: str
    max_tokens: int = 4096


DEFAULT_TIERS: dict[ModelTier, TierConfig] = {
    ModelTier.THRIFTY: TierConfig(tier=ModelTier.THRIFTY, model_id="claude-haiku-4-5-20251001", max_tokens=2048),
    ModelTier.STANDARD: TierConfig(tier=ModelTier.STANDARD, model_id="claude-sonnet-4-5-20250929", max_tokens=4096),
    ModelTier.PREMIUM: TierConfig(tier=ModelTier.PREMIUM, model_id="claude-opus-4-6", max_tokens=8192),
}


def score_complexity(task: dict[str, Any]) -> float:
    """Estimate task complexity on a 0.0-1.0 scale.

    Heuristic based on:
    - Length of the task description
    - Number of subtasks / required steps
    - Presence of keywords indicating complexity
    """
    description = str(task.get("description", ""))
    steps = task.get("steps", [])

    score = 0.0

    # Length factor (longer = more complex, up to 0.3)
    word_count = len(description.split())
    score += min(word_count / 200, 0.3)

    # Steps factor (more steps = more complex, up to 0.3)
    score += min(len(steps) / 10, 0.3)

    # Keyword factor (up to 0.4)
    complex_keywords = {"analyze", "compare", "synthesize", "multi-step", "reasoning", "evaluate", "design"}
    found = sum(1 for kw in complex_keywords if kw in description.lower())
    score += min(found / len(complex_keywords), 0.4)

    return min(score, 1.0)


def select_tier(complexity: float) -> ModelTier:
    """Select the cheapest model tier capable of handling the given complexity."""
    if complexity <= 0.3:
        return ModelTier.THRIFTY
    if complexity <= 0.7:
        return ModelTier.STANDARD
    return ModelTier.PREMIUM


def dispatch(
    task: dict[str, Any],
    tiers: dict[ModelTier, TierConfig] | None = None,
) -> TierConfig:
    """Score a task and return the appropriate model tier configuration."""
    tiers = tiers or DEFAULT_TIERS
    complexity = score_complexity(task)
    tier = select_tier(complexity)
    return tiers[tier]
