"""swarm.at — Git-native settlement protocol for AI agent workflows."""

__version__ = "0.7.0"

from swarm_at.models import Proposal, SettlementResult, SettlementStatus
from swarm_at.sdk.client import SwarmClient
from swarm_at.settle import SettlementContext, settle
from swarm_at.authorship import WritingSession
from swarm_at.tiers import SettlementTier

__all__ = [
    "Proposal",
    "SettlementContext",
    "SettlementResult",
    "SettlementStatus",
    "SettlementTier",
    "SwarmClient",
    "WritingSession",
    "settle",
]
