"""Git-Native Data Plane: git-backed ledger with branching and merging."""

from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
import time
from pathlib import Path

from swarm_at.models import LedgerEntry
from swarm_at.settler import GENESIS_HASH, Ledger, generate_hash


class GitLedger(Ledger):
    """Ledger backed by a git repository.

    Each branch maintains its own hash chain in a JSONL file.
    Parallel agents work on separate branches.
    Merging combines settlement paths with conflict detection.

    Storage layout:
        <repo_root>/
            ledger.jsonl          # the actual ledger file
            .git/                 # git internals
    """

    def __init__(self, repo_path: str | Path, branch: str = "main", remote_url: str = "") -> None:
        self.repo_path = Path(repo_path)
        self.branch = branch
        self.remote_url = remote_url
        self._ledger_file = "ledger.jsonl"
        self._push_lock = threading.Lock()
        self._logger = logging.getLogger("swarm_at.gitplane")
        self._ssh_key_path: str | None = None
        self._setup_git_auth()
        super().__init__(path=self.repo_path / self._ledger_file)
        self._ensure_repo()

    def _setup_git_auth(self) -> None:
        """Configure git authentication from environment.

        Supports two modes:
        - SWARM_GIT_TOKEN: HTTPS token auth (preferred, simplest)
        - SWARM_GIT_DEPLOY_KEY: SSH deploy key auth
        """
        # Mode 1: HTTPS token — rewrite remote URL to embed token
        token = os.environ.get("SWARM_GIT_TOKEN", "").strip()
        if token and self.remote_url:
            # Convert git@github.com:org/repo.git to https://token@github.com/org/repo.git
            if self.remote_url.startswith("git@github.com:"):
                path = self.remote_url.replace("git@github.com:", "")
                self.remote_url = f"https://x-access-token:{token}@github.com/{path}"
            elif "github.com" in self.remote_url and "x-access-token" not in self.remote_url:
                # Already HTTPS, inject token
                self.remote_url = self.remote_url.replace(
                    "https://github.com/", f"https://x-access-token:{token}@github.com/",
                )
            self._logger.info("HTTPS token auth configured for git push")
            return

        # Mode 2: SSH deploy key
        key_data = os.environ.get("SWARM_GIT_DEPLOY_KEY", "").strip()
        if not key_data:
            return
        if "\\n" in key_data:
            key_data = key_data.replace("\\n", "\n")
        key_path = Path("/tmp/swarm-deploy-key")
        key_path.write_text(key_data + "\n")
        key_path.chmod(0o600)
        self._ssh_key_path = str(key_path)
        self._logger.info("SSH deploy key configured for git push")

    def _run_git(self, *args: str, check: bool = True, timeout: int = 30) -> subprocess.CompletedProcess[str]:
        """Run a git command in the repo directory."""
        env = None
        if self._ssh_key_path:
            env = {**os.environ, "GIT_SSH_COMMAND": f"ssh -i {self._ssh_key_path} -o StrictHostKeyChecking=no -o BatchMode=yes"}
        try:
            return subprocess.run(
                ["git", *args],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=check,
                timeout=timeout,
                env=env,
            )
        except subprocess.TimeoutExpired:
            self._logger.warning("Git command timed out: git %s", " ".join(args))
            return subprocess.CompletedProcess(
                args=["git", *args], returncode=1,
                stdout="", stderr="timeout",
            )

    def _ensure_repo(self) -> None:
        """Initialize git repo — clone from remote if available, else init empty.

        Handles all edge cases: empty dir, stale .git, missing remote, etc.
        Never raises — falls back to fresh init on any failure.
        """
        try:
            self._ensure_repo_inner()
        except Exception:
            self._logger.exception("Git repo setup failed, falling back to fresh init")
            import shutil
            git_dir = self.repo_path / ".git"
            if git_dir.exists():
                shutil.rmtree(git_dir)
            self._init_fresh()

    def _ensure_repo_inner(self) -> None:
        self._logger.info("Ensuring repo at %s", self.repo_path)
        self.repo_path.mkdir(parents=True, exist_ok=True)

        # Force reset: wipe stale .git and re-clone
        if os.environ.get("SWARM_GIT_RESET") and (self.repo_path / ".git").exists():
            import shutil
            self._logger.info("SWARM_GIT_RESET set, wiping stale repo")
            shutil.rmtree(self.repo_path / ".git")
            for f in self.repo_path.iterdir():
                if f.is_file():
                    f.unlink()

        if not (self.repo_path / ".git").exists():
            self._logger.info("No .git found, initializing")
            self._run_git("init")
            self._run_git("config", "user.email", "swarm@swarm.at")
            self._run_git("config", "user.name", "swarm.at")

            if self.remote_url:
                self._logger.info("Fetching ledger from remote")
                self._run_git("remote", "add", "origin", self.remote_url)
                result = self._run_git("fetch", "origin", check=False, timeout=15)
                self._logger.info("Fetch result: rc=%d", result.returncode)
                if result.returncode == 0:
                    check = self._run_git(
                        "rev-parse", "--verify", f"origin/{self.branch}", check=False,
                    )
                    if check.returncode == 0:
                        self._run_git("checkout", "-b", self.branch, f"origin/{self.branch}", check=False)
                        self._logger.info("Fetched %s from remote", self.branch)
                        return
                self._logger.warning("Remote fetch failed, starting fresh")

            # No remote or fetch failed — create initial commit
            self.path.touch()
            self._run_git("add", self._ledger_file)
            self._run_git("commit", "-m", "Initialize ledger")
        else:
            # Repo already exists
            self._logger.info("Repo exists, configuring")
            self._run_git("config", "user.email", "swarm@swarm.at")
            self._run_git("config", "user.name", "swarm.at")

            # Ensure remote is set correctly
            if self.remote_url:
                result = self._run_git("remote", "get-url", "origin", check=False)
                if result.returncode != 0:
                    self._run_git("remote", "add", "origin", self.remote_url)
                elif result.stdout.strip() != self.remote_url:
                    self._run_git("remote", "set-url", "origin", self.remote_url)

                self._logger.info("Pulling latest from remote")
                self._run_git("pull", "origin", self.branch, "--ff-only", check=False)

        # Ensure on correct branch
        current = self._run_git("branch", "--show-current", check=False)
        if current.returncode == 0 and current.stdout.strip() != self.branch:
            result = self._run_git("checkout", self.branch, check=False)
            if result.returncode != 0:
                self._run_git("checkout", "-b", self.branch, check=False)

    def _init_fresh(self) -> None:
        """Initialize a fresh git repo with empty ledger."""
        self.repo_path.mkdir(parents=True, exist_ok=True)
        self._run_git("init")
        self._run_git("config", "user.email", "swarm@swarm.at")
        self._run_git("config", "user.name", "swarm.at")
        self.path.touch()
        self._run_git("add", self._ledger_file)
        self._run_git("commit", "-m", "Initialize ledger")

    def _current_branch(self) -> str:
        result = self._run_git("branch", "--show-current")
        return str(result.stdout.strip())

    def _ensure_on_branch(self) -> None:
        """Ensure working directory is on the correct branch."""
        if self.branch != self._current_branch():
            self._run_git("checkout", self.branch)

    def _push_async(self) -> None:
        """Push to remote in a daemon thread. Skips if already pushing."""
        if not self.remote_url:
            return

        def _do_push() -> None:
            if not self._push_lock.acquire(blocking=False):
                self._logger.debug("Push already in progress, skipping")
                return
            try:
                self._run_git("push", "origin", self.branch, check=False)
            except Exception:
                self._logger.exception("Push to remote failed")
            finally:
                self._push_lock.release()

        thread = threading.Thread(target=_do_push, daemon=True)
        thread.start()

    @property
    def is_frozen(self) -> bool:
        """Check if the ledger is frozen (file-based, survives restarts)."""
        return (self.repo_path / "FROZEN").exists()

    def freeze(self, reason: str) -> None:
        """Emergency kill-switch: freeze the ledger to prevent writes."""
        if self.is_frozen:
            raise GitPlaneError("Ledger is already frozen.")
        self._ensure_on_branch()
        # Write freeze event to ledger (bypasses the frozen guard)
        freeze_entry = {
            "timestamp": time.time(),
            "task_id": "ledger-freeze",
            "parent_hash": self.get_latest_hash(),
            "payload": {"type": "ledger_freeze", "reason": reason},
            "current_hash": "",
        }
        freeze_entry["current_hash"] = generate_hash(freeze_entry)
        entry = LedgerEntry.model_validate(freeze_entry)
        super().append_entry(entry)
        # Create FROZEN marker file
        (self.repo_path / "FROZEN").write_text(reason)
        self._run_git("add", self._ledger_file, "FROZEN")
        self._run_git("commit", "-m", f"Freeze ledger: {reason}")
        self._push_async()

    def unfreeze(self) -> None:
        """Remove the freeze and allow writes again."""
        if not self.is_frozen:
            raise GitPlaneError("Ledger is not frozen.")
        self._ensure_on_branch()
        (self.repo_path / "FROZEN").unlink()
        # Write unfreeze event
        unfreeze_entry = {
            "timestamp": time.time(),
            "task_id": "ledger-unfreeze",
            "parent_hash": super().get_latest_hash(),
            "payload": {"type": "ledger_unfreeze"},
            "current_hash": "",
        }
        unfreeze_entry["current_hash"] = generate_hash(unfreeze_entry)
        entry = LedgerEntry.model_validate(unfreeze_entry)
        super().append_entry(entry)
        self._run_git("add", self._ledger_file, "FROZEN")
        self._run_git("commit", "-m", "Unfreeze ledger")
        self._push_async()

    def append_entry(self, entry: LedgerEntry) -> None:
        """Append entry and commit to git."""
        if self.is_frozen:
            raise GitPlaneError("Ledger is frozen. Use unfreeze() to resume writes.")
        self._ensure_on_branch()
        super().append_entry(entry)
        self._run_git("add", self._ledger_file)
        self._run_git("commit", "-m", f"Settle: {entry.task_id}")
        self._push_async()

    def get_latest_hash(self) -> str:
        """Return the current_hash of the last ledger entry, or genesis hash."""
        self._ensure_on_branch()
        return super().get_latest_hash()

    def read_all(self) -> list[LedgerEntry]:
        """Read all entries from the ledger."""
        self._ensure_on_branch()
        return super().read_all()

    def verify_chain(self) -> bool:
        """Walk the full ledger and verify every hash link."""
        self._ensure_on_branch()
        return super().verify_chain()

    def create_branch(self, branch_name: str, from_branch: str | None = None) -> "GitLedger":
        """Create a new branch for parallel agent work. Returns a new GitLedger on that branch."""
        base = from_branch or self.branch
        self._run_git("checkout", base)
        self._run_git("checkout", "-b", branch_name)
        # Switch back to original branch
        self._run_git("checkout", self.branch)
        return GitLedger(repo_path=self.repo_path, branch=branch_name, remote_url=self.remote_url)

    def _read_branch_ledger(self, branch: str) -> list[dict[str, str | float | dict[str, str]]]:
        """Read the raw JSONL entries from a specific branch without checkout."""
        result = self._run_git("show", f"{branch}:{self._ledger_file}", check=False)
        if result.returncode != 0:
            return []
        entries = []
        for line in result.stdout.strip().splitlines():
            line = line.strip()
            if line:
                entries.append(json.loads(line))
        return entries

    def _resolve_conflict(self, source_branch: str) -> MergeResult:
        """Deterministic conflict resolution: append-only union strategy.

        Finds common prefix, takes divergent entries from both sides,
        sorts by (timestamp, task_id), and rehashes.
        """
        ours = self._read_branch_ledger(self.branch)
        theirs = self._read_branch_ledger(source_branch)

        # Find common prefix
        prefix_len = 0
        for i in range(min(len(ours), len(theirs))):
            if ours[i].get("current_hash") == theirs[i].get("current_hash"):
                prefix_len = i + 1
            else:
                break

        common = ours[:prefix_len]
        ours_divergent = ours[prefix_len:]
        theirs_divergent = theirs[prefix_len:]

        # Merge divergent entries: sort by (timestamp, task_id) for determinism
        merged_divergent = sorted(
            ours_divergent + theirs_divergent,
            key=lambda e: (e.get("timestamp", 0), e.get("task_id", "")),
        )

        # Rehash divergent entries to rebuild parent chain
        if common:
            parent_hash = str(common[-1].get("current_hash", GENESIS_HASH))
        else:
            parent_hash = GENESIS_HASH

        for entry in merged_divergent:
            entry["parent_hash"] = parent_hash
            entry["current_hash"] = ""
            entry["current_hash"] = generate_hash(entry)
            parent_hash = str(entry["current_hash"])

        # Write merged file
        all_entries = common + merged_divergent
        lines = [json.dumps(e, default=str) for e in all_entries]
        self.path.write_text("\n".join(lines) + "\n" if lines else "")
        self._run_git("add", self._ledger_file)
        self._run_git("commit", "-m", f"Merge {source_branch}: resolved {len(merged_divergent)} entries")

        return MergeResult(
            success=True,
            branch=source_branch,
            details=f"Resolved {len(ours_divergent)} + {len(theirs_divergent)} divergent entries",
        )

    def merge(self, source_branch: str) -> MergeResult:
        """Merge another branch into this one.

        Returns MergeResult with success status and any conflict info.
        Uses deterministic conflict resolution for ledger conflicts.
        """
        self._run_git("checkout", self.branch)
        result = self._run_git("merge", source_branch, "--no-edit", check=False)

        if result.returncode == 0:
            return MergeResult(success=True, branch=source_branch)

        # Conflict detected — use deterministic resolution
        if "CONFLICT" in result.stdout or "CONFLICT" in result.stderr:
            self._run_git("merge", "--abort")
            return self._resolve_conflict(source_branch)

        return MergeResult(success=False, branch=source_branch, details=result.stderr)

    def branches(self) -> list[str]:
        """List all branches in the repo."""
        result = self._run_git("branch")
        return [b.strip().lstrip("* ") for b in result.stdout.strip().splitlines() if b.strip()]

    def log(self, max_entries: int = 10) -> list[dict[str, str]]:
        """Get git commit log."""
        result = self._run_git("log", f"--max-count={max_entries}", "--format=%H|%s|%ai")
        entries = []
        for line in result.stdout.strip().splitlines():
            if line:
                parts = line.split("|", 2)
                if len(parts) == 3:
                    entries.append({"hash": parts[0], "message": parts[1], "date": parts[2]})
        return entries

    def diff_branches(self, other_branch: str) -> str:
        """Show diff between this branch and another."""
        result = self._run_git("diff", f"{self.branch}...{other_branch}", "--", self._ledger_file)
        return str(result.stdout)


class MergeResult:
    """Result of a branch merge operation."""

    def __init__(
        self,
        success: bool,
        branch: str,
        conflicts: list[str] | None = None,
        details: str = "",
    ) -> None:
        self.success = success
        self.branch = branch
        self.conflicts = conflicts or []
        self.details = details


class GitPlaneError(Exception):
    pass
