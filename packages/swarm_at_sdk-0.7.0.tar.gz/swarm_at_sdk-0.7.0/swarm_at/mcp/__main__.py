"""Entry point for running the MCP server via stdio.

Usage:
    python -m swarm_at.mcp
    mcp add swarm-at -- python -m swarm_at.mcp
"""

import asyncio

from swarm_at.mcp.server import create_mcp_app


def main() -> None:
    mcp = create_mcp_app()
    asyncio.run(mcp.run_stdio_async())


if __name__ == "__main__":
    main()
