"""Ledger operations: read, append, verify hash-chain integrity."""

from __future__ import annotations

import hashlib
import json
import threading
from pathlib import Path
from typing import Any

from swarm_at.models import LedgerEntry

GENESIS_HASH = "0" * 64


def content_fingerprint(content: str) -> str:
    """SHA-256 fingerprint of content for authorship claims."""
    return hashlib.sha256(content.encode()).hexdigest()


def generate_hash(content: dict[str, Any]) -> str:
    """Deterministic SHA-256 hash of a dict (sorted keys)."""
    raw = json.dumps(content, sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


class Ledger:
    def __init__(self, path: str | Path = "ledger.jsonl"):
        self.path = Path(path)
        self._write_lock = threading.Lock()

    def get_latest_hash(self) -> str:
        """Return the current_hash of the last ledger entry, or genesis hash."""
        if not self.path.exists():
            return GENESIS_HASH
        text = self.path.read_text().strip()
        if not text:
            return GENESIS_HASH
        last_line = text.splitlines()[-1]
        entry: dict[str, Any] = json.loads(last_line)
        return str(entry["current_hash"])

    def append_entry(self, entry: LedgerEntry) -> None:
        """Append a settled entry to the ledger. Thread-safe via lock."""
        with self._write_lock:
            with self.path.open("a") as f:
                f.write(entry.model_dump_json() + "\n")

    def read_all(self) -> list[LedgerEntry]:
        """Read all entries from the ledger."""
        if not self.path.exists():
            return []
        entries = []
        for line in self.path.read_text().strip().splitlines():
            if line:
                entries.append(LedgerEntry.model_validate_json(line))
        return entries

    def verify_chain(self) -> bool:
        """Walk the full ledger and verify every hash link.

        Returns True if the chain is intact, False otherwise.
        """
        entries = self.read_all()
        if not entries:
            return True

        expected_parent = GENESIS_HASH
        for entry in entries:
            if entry.parent_hash != expected_parent:
                return False
            # Recompute the hash to verify integrity
            entry_dict = entry.model_dump()
            entry_dict["current_hash"] = ""
            computed = generate_hash(entry_dict)
            if entry.current_hash != computed:
                return False
            expected_parent = entry.current_hash

        return True
