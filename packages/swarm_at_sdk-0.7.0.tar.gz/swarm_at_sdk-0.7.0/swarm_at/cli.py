"""swarm CLI — local-first settlement protocol interface."""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import click

from swarm_at.settler import Ledger
from swarm_at.tiers import SettlementTier


# ---------------------------------------------------------------------------
# Config file helpers
# ---------------------------------------------------------------------------

CONFIG_DIR = Path.home() / ".swarm"
CONFIG_FILE = CONFIG_DIR / "config.toml"


def _load_config() -> dict[str, str]:
    """Load ~/.swarm/config.toml. Flat key = "value" parser (no dep needed)."""
    if not CONFIG_FILE.exists():
        return {}
    result: dict[str, str] = {}
    for line in CONFIG_FILE.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        result[key] = val
    return result


def _save_config(data: dict[str, str]) -> None:
    """Write ~/.swarm/config.toml with secure permissions."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_DIR.chmod(0o700)
    lines = [f'{k} = "{v}"' for k, v in sorted(data.items())]
    CONFIG_FILE.write_text("\n".join(lines) + "\n")
    CONFIG_FILE.chmod(0o600)


# ---------------------------------------------------------------------------
# CLI context
# ---------------------------------------------------------------------------


@dataclass
class CliContext:
    api_url: str | None = None
    api_key: str = ""
    ledger_path: str = "ledger.jsonl"
    force_local: bool = False
    json_output: bool = False
    _mode: str | None = field(default=None, repr=False)

    @property
    def mode(self) -> str:
        if self._mode is not None:
            return self._mode
        self._mode = self._resolve_mode()
        return self._mode

    def _resolve_mode(self) -> str:
        """Priority: --local > --api-url > SWARM_API_URL > config > local."""
        if self.force_local:
            return "local"
        if self.api_url:
            return "remote"
        if os.environ.get("SWARM_API_URL"):
            self.api_url = os.environ["SWARM_API_URL"]
            return "remote"
        cfg = _load_config()
        if cfg.get("api_url"):
            self.api_url = cfg["api_url"]
            if not self.api_key:
                self.api_key = cfg.get("api_key", "")
            return "remote"
        return "local"

    def get_ledger(self) -> Ledger:
        path = os.environ.get("SWARM_LEDGER_PATH", self.ledger_path)
        return Ledger(path=path)

    def get_client(self) -> Any:
        from swarm_at.sdk.client import SwarmClient
        api_key = self.api_key or os.environ.get("SWARM_API_KEY", "")
        return SwarmClient(api_url=self.api_url or "", api_key=api_key)


def _output(ctx: CliContext, data: Any) -> None:
    """Print data in JSON or human-readable format."""
    if ctx.json_output:
        click.echo(json.dumps(data, indent=2, default=str))
    elif isinstance(data, dict):
        for k, v in data.items():
            click.echo(f"{k}: {v}")
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                line = "  ".join(f"{k}={v}" for k, v in item.items())
                click.echo(line)
            else:
                click.echo(str(item))
    else:
        click.echo(str(data))


def _error(msg: str) -> None:
    click.echo(f"Error: {msg}", err=True)
    sys.exit(1)


def _server_guard(module_name: str) -> Any:
    """Try importing a server-only module. Exit with install hint on failure."""
    try:
        if module_name == "agents":
            from swarm_at import agents
            return agents
        elif module_name == "blueprints":
            from swarm_at import blueprints
            return blueprints
        elif module_name == "seed_blueprints":
            from swarm_at import seed_blueprints
            return seed_blueprints
        else:
            import importlib
            return importlib.import_module(f"swarm_at.{module_name}")
    except ImportError:
        _error(f"Module '{module_name}' not available. Install with: pip install swarm-at-sdk[server]")


# ---------------------------------------------------------------------------
# Main group
# ---------------------------------------------------------------------------

pass_ctx = click.make_pass_decorator(CliContext, ensure=True)


@click.group()
@click.option("--api-url", envvar="SWARM_API_URL", default=None, help="Override SWARM_API_URL.")
@click.option("--api-key", envvar="SWARM_API_KEY", default="", help="Override SWARM_API_KEY.")
@click.option("--ledger-path", default="ledger.jsonl", help="Override ledger file path.")
@click.option("--local", "force_local", is_flag=True, help="Force local mode (no server).")
@click.option("--json", "json_output", is_flag=True, help="JSON output instead of human-readable.")
@click.pass_context
def main(ctx: click.Context, api_url: str | None, api_key: str, ledger_path: str,
         force_local: bool, json_output: bool) -> None:
    """swarm — Git-native settlement protocol CLI."""
    ctx.ensure_object(CliContext)
    obj = ctx.obj
    obj.api_url = api_url
    obj.api_key = api_key
    obj.ledger_path = ledger_path
    obj.force_local = force_local
    obj.json_output = json_output


# ---------------------------------------------------------------------------
# settle
# ---------------------------------------------------------------------------


@main.command()
@click.argument("action")
@click.option("--agent", default="cli-agent", help="Agent name.")
@click.option("--confidence", type=float, default=0.95, help="Confidence score (0.0-1.0).")
@click.option("--data", "data_json", default=None, help="JSON payload data.")
@click.option("--tier", type=click.Choice(["sandbox", "staging", "production"]), default=None)
@pass_ctx
def settle(ctx: CliContext, action: str, agent: str, confidence: float,
           data_json: str | None, tier: str | None) -> None:
    """Settle an agent action."""
    from swarm_at.settle import SettlementContext

    data: dict[str, Any] | None = None
    if data_json:
        try:
            data = json.loads(data_json)
        except json.JSONDecodeError as exc:
            _error(f"Invalid JSON data: {exc}")

    settlement_tier = SettlementTier(tier) if tier else None

    if ctx.mode == "remote":
        sc = SettlementContext(
            tier=settlement_tier,
            api_url=ctx.api_url,
            api_key=ctx.api_key,
        )
    else:
        sc = SettlementContext(
            tier=settlement_tier,
            ledger_path=os.environ.get("SWARM_LEDGER_PATH", ctx.ledger_path),
        )

    result = sc.settle(agent=agent, task=action, data=data, confidence=confidence)
    out = {
        "status": result.status.value,
        "hash": result.hash or "",
    }
    if result.reason:
        out["reason"] = result.reason
    _output(ctx, out)


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


@main.command()
@pass_ctx
def status(ctx: CliContext) -> None:
    """Show ledger status: latest hash, entry count, chain integrity."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            verify = client.verify_ledger()
            latest = client.latest_hash()
            _output(ctx, {
                "mode": "remote",
                "api_url": ctx.api_url,
                "latest_hash": latest,
                "chain_intact": verify.get("chain_intact", verify.get("valid")),
                "entry_count": verify.get("entry_count", "unknown"),
            })
        except Exception as exc:
            _error(str(exc))
    else:
        ledger = ctx.get_ledger()
        entries = ledger.read_all()
        _output(ctx, {
            "mode": "local",
            "ledger_path": str(ledger.path),
            "latest_hash": ledger.get_latest_hash(),
            "chain_intact": ledger.verify_chain(),
            "entry_count": len(entries),
        })


# ---------------------------------------------------------------------------
# ledger group
# ---------------------------------------------------------------------------


@main.group()
def ledger() -> None:
    """Inspect the settlement ledger."""


@ledger.command("list")
@click.option("--limit", type=int, default=20, help="Max entries to show.")
@click.option("--offset", type=int, default=0, help="Skip first N entries.")
@click.option("--task-id", default=None, help="Filter by task ID.")
@pass_ctx
def ledger_list(ctx: CliContext, limit: int, offset: int, task_id: str | None) -> None:
    """List ledger entries."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            data = client.list_ledger(limit=limit, offset=offset, task_id=task_id)
            _output(ctx, data if ctx.json_output else data.get("entries", data))
        except Exception as exc:
            _error(str(exc))
    else:
        ledger_obj = ctx.get_ledger()
        entries = ledger_obj.read_all()
        if task_id:
            entries = [e for e in entries if e.task_id == task_id]
        page = entries[offset:offset + limit]
        rows = []
        for e in page:
            rows.append({
                "hash": e.current_hash[:16] + "...",
                "task_id": e.task_id,
                "timestamp": e.timestamp,
                "parent": e.parent_hash[:16] + "...",
            })
        if ctx.json_output:
            full = [e.model_dump() for e in page]
            _output(ctx, full)
        else:
            click.echo(f"Showing {len(rows)} of {len(entries)} entries (offset={offset})")
            for r in rows:
                click.echo(
                    f"  {r['hash']}  {str(r['task_id']).ljust(24)}  {r['timestamp']}"
                )


@ledger.command("verify")
@click.argument("hash_value")
@pass_ctx
def ledger_verify(ctx: CliContext, hash_value: str) -> None:
    """Verify a specific settlement hash exists in the ledger."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            _output(ctx, client.get_receipt(hash_value))
        except Exception as exc:
            _error(str(exc))
    else:
        ledger_obj = ctx.get_ledger()
        entries = ledger_obj.read_all()
        for entry in entries:
            if entry.current_hash == hash_value:
                _output(ctx, {
                    "found": True,
                    "hash": entry.current_hash,
                    "task_id": entry.task_id,
                    "timestamp": entry.timestamp,
                    "parent_hash": entry.parent_hash,
                })
                return
        _output(ctx, {"found": False, "hash": hash_value})


# ---------------------------------------------------------------------------
# agents group
# ---------------------------------------------------------------------------


@main.group()
def agents() -> None:
    """Manage agent identities."""


@agents.command("list")
@click.option("--role", default=None, help="Filter by role.")
@click.option("--trust", default=None, help="Filter by minimum trust level.")
@pass_ctx
def agents_list(ctx: CliContext, role: str | None, trust: str | None) -> None:
    """List registered agents."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            _output(ctx, client.list_agents(role=role, min_trust=trust))
        except Exception as exc:
            _error(str(exc))
    else:
        mod = _server_guard("agents")
        registry = mod.AgentRegistry()
        agents_data = registry.active_agents()
        if role:
            agents_data = [a for a in agents_data if a.role.value == role]
        if trust:
            trust_level = mod.TrustLevel(trust)
            levels = list(mod.TrustLevel)
            min_idx = levels.index(trust_level)
            agents_data = [a for a in agents_data if levels.index(a.trust_level) >= min_idx]
        rows = [
            {
                "agent_id": a.agent_id,
                "role": a.role.value,
                "trust": a.trust_level.value,
                "settlements": a.settlements_completed,
            }
            for a in agents_data
        ]
        _output(ctx, rows)


@agents.command("register")
@click.argument("agent_id")
@click.option("--role", default="worker", help="Agent role.")
@pass_ctx
def agents_register(ctx: CliContext, agent_id: str, role: str) -> None:
    """Register a new agent."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            result = client.register_agent(agent_id=agent_id, role=role)
            _output(ctx, result)
        except Exception as exc:
            _error(str(exc))
    else:
        mod = _server_guard("agents")
        registry = mod.PersistentAgentRegistry()
        try:
            agent = registry.register(agent_id=agent_id, role=mod.AgentRole(role))
            _output(ctx, {
                "agent_id": agent.agent_id,
                "role": agent.role.value,
                "trust": agent.trust_level.value,
                "registered": True,
            })
        except mod.AgentError as exc:
            _error(str(exc))


@agents.command("info")
@click.argument("agent_id")
@pass_ctx
def agents_info(ctx: CliContext, agent_id: str) -> None:
    """Show agent details."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            _output(ctx, client.get_agent(agent_id))
        except Exception as exc:
            _error(str(exc))
    else:
        mod = _server_guard("agents")
        registry = mod.AgentRegistry()
        try:
            agent = registry.get(agent_id)
            _output(ctx, {
                "agent_id": agent.agent_id,
                "role": agent.role.value,
                "trust": agent.trust_level.value,
                "settlements_completed": agent.settlements_completed,
                "settlements_failed": agent.settlements_failed,
                "reputation": agent.reputation_score,
            })
        except mod.AgentError as exc:
            _error(str(exc))


@agents.command("verify-trust")
@click.argument("agent_id")
@click.option("--min-trust", default="trusted", help="Minimum trust level (untrusted/provisional/trusted/senior).")
@pass_ctx
def agents_verify_trust(ctx: CliContext, agent_id: str, min_trust: str) -> None:
    """Check if an agent meets a trust threshold."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            _output(ctx, client.verify_trust(agent_id, min_trust=min_trust))
        except Exception as exc:
            _error(str(exc))
    else:
        mod = _server_guard("agents")
        try:
            level = mod.TrustLevel(min_trust)
        except ValueError:
            _error(f"Invalid trust level: {min_trust}")
        try:
            agent = mod.AgentRegistry().get(agent_id)
        except mod.AgentError:
            _error(f"Agent '{agent_id}' not found.")
        trust_order = list(mod.TrustLevel)
        meets = trust_order.index(agent.trust_level) >= trust_order.index(level)
        _output(ctx, {
            "agent_id": agent.agent_id,
            "meets_requirement": meets,
            "trust_level": agent.trust_level.value,
            "reputation_score": round(agent.reputation_score, 4),
        })


@agents.command("trust-summary")
@pass_ctx
def agents_trust_summary(ctx: CliContext) -> None:
    """Show aggregate trust-level counts across all agents."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            _output(ctx, client.get_trust_summary())
        except Exception as exc:
            _error(str(exc))
    else:
        mod = _server_guard("agents")
        counts: dict[str, int] = {level.value: 0 for level in mod.TrustLevel}
        all_agents = mod.AgentRegistry().find_by_trust(mod.TrustLevel.UNTRUSTED)
        for agent in all_agents:
            counts[agent.trust_level.value] += 1
        _output(ctx, {
            "total_agents": sum(counts.values()),
            "by_trust_level": counts,
        })


# ---------------------------------------------------------------------------
# blueprints group
# ---------------------------------------------------------------------------


@main.group()
def blueprints() -> None:
    """Browse blueprint catalog."""


@blueprints.command("list")
@click.option("--tag", default=None, help="Filter by tag.")
@pass_ctx
def blueprints_list(ctx: CliContext, tag: str | None) -> None:
    """List available blueprints."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            result = client.list_blueprints(tag=tag)
            _output(ctx, result)
        except Exception as exc:
            _error(str(exc))
    else:
        bp_mod = _server_guard("blueprints")
        seed_mod = _server_guard("seed_blueprints")
        store = bp_mod.BlueprintStore()
        seed_mod.seed_blueprints(store)
        all_bps = store.list_blueprints()
        if tag:
            all_bps = [b for b in all_bps if tag in b.tags]
        rows = [
            {
                "id": b.blueprint_id,
                "name": b.name,
                "tags": ", ".join(b.tags),
                "credits": b.credit_cost,
            }
            for b in all_bps
        ]
        _output(ctx, rows)


@blueprints.command("info")
@click.argument("blueprint_id")
@pass_ctx
def blueprints_info(ctx: CliContext, blueprint_id: str) -> None:
    """Show blueprint details."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            result = client.get_blueprint(blueprint_id)
            _output(ctx, result)
        except Exception as exc:
            _error(str(exc))
    else:
        bp_mod = _server_guard("blueprints")
        seed_mod = _server_guard("seed_blueprints")
        store = bp_mod.BlueprintStore()
        seed_mod.seed_blueprints(store)
        try:
            bp = store.get_blueprint(blueprint_id)
        except Exception:
            _error(f"Blueprint '{blueprint_id}' not found.")
        _output(ctx, {
            "id": bp.blueprint_id,
            "name": bp.name,
            "description": bp.description,
            "version": bp.version,
            "author": bp.author,
            "tags": bp.tags,
            "credit_cost": bp.credit_cost,
            "steps": [
                {"step_id": s.step_id, "name": s.name, "depends_on": s.depends_on}
                for s in bp.steps
            ],
        })


@blueprints.command("fork")
@click.argument("blueprint_id")
@click.option("--agent", default="anonymous", help="Agent ID for credit billing.")
@pass_ctx
def blueprints_fork(ctx: CliContext, blueprint_id: str, agent: str) -> None:
    """Fork a blueprint into an executable workflow."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            result = client.fork_blueprint(blueprint_id, agent_id=agent)
            _output(ctx, result)
        except Exception as exc:
            _error(str(exc))
    else:
        bp_mod = _server_guard("blueprints")
        seed_mod = _server_guard("seed_blueprints")
        wf_mod = _server_guard("workflow")
        store = bp_mod.BlueprintStore()
        seed_mod.seed_blueprints(store)
        try:
            bp = store.get_blueprint(blueprint_id)
        except Exception:
            _error(f"Blueprint '{blueprint_id}' not found.")
        molecule = wf_mod.fork_blueprint(bp, agent_id=agent)
        _output(ctx, {
            "molecule_id": molecule.molecule_id,
            "name": molecule.name,
            "bead_count": len(molecule.beads),
        })


@blueprints.command("publish")
@click.option("--name", required=True, help="Blueprint name.")
@click.option("--description", "desc", default="", help="Blueprint description.")
@click.option("--tag", "tags", multiple=True, help="Tags (repeatable).")
@click.option("--agent", required=True, help="Author agent ID.")
@click.option("--credit-cost", type=float, default=1.0, help="Credit cost to fork.")
@click.option("--steps", "steps_json", default=None, help="Steps as JSON array.")
@pass_ctx
def blueprints_publish(ctx: CliContext, name: str, desc: str, tags: tuple[str, ...],
                       agent: str, credit_cost: float, steps_json: str | None) -> None:
    """Publish a new blueprint (remote only, auth required)."""
    if ctx.mode != "remote":
        _error("blueprints publish requires a remote API. Use --api-url or set SWARM_API_URL.")

    steps: list[dict[str, Any]] = []
    if steps_json:
        try:
            steps = json.loads(steps_json)
        except json.JSONDecodeError as exc:
            _error(f"Invalid JSON steps: {exc}")

    client = ctx.get_client()
    try:
        result = client.publish_blueprint(
            name=name, description=desc, tags=list(tags),
            steps=steps, credit_cost=credit_cost, agent_id=agent,
        )
        _output(ctx, result)
    except Exception as exc:
        _error(str(exc))


# ---------------------------------------------------------------------------
# webhooks group (remote only)
# ---------------------------------------------------------------------------


@main.group()
def webhooks() -> None:
    """Manage webhook subscriptions (remote only)."""


@webhooks.command("register")
@click.argument("event")
@click.argument("url")
@pass_ctx
def webhooks_register(ctx: CliContext, event: str, url: str) -> None:
    """Register a webhook URL for an event type."""
    if ctx.mode != "remote":
        _error("webhooks require a remote API. Use --api-url or set SWARM_API_URL.")
    client = ctx.get_client()
    try:
        _output(ctx, client.register_webhook(event, url))
    except Exception as exc:
        _error(str(exc))


@webhooks.command("list")
@click.option("--event", default=None, help="Filter by event type.")
@pass_ctx
def webhooks_list(ctx: CliContext, event: str | None) -> None:
    """List registered webhooks."""
    if ctx.mode != "remote":
        _error("webhooks require a remote API. Use --api-url or set SWARM_API_URL.")
    client = ctx.get_client()
    try:
        _output(ctx, client.list_webhooks(event=event))
    except Exception as exc:
        _error(str(exc))


@webhooks.command("unregister")
@click.argument("event")
@click.argument("url")
@pass_ctx
def webhooks_unregister(ctx: CliContext, event: str, url: str) -> None:
    """Remove a webhook registration."""
    if ctx.mode != "remote":
        _error("webhooks require a remote API. Use --api-url or set SWARM_API_URL.")
    client = ctx.get_client()
    try:
        _output(ctx, client.unregister_webhook(event, url))
    except Exception as exc:
        _error(str(exc))


# ---------------------------------------------------------------------------
# credits group (remote only)
# ---------------------------------------------------------------------------


@main.group()
def credits() -> None:
    """Manage agent credit balances (remote only)."""


@credits.command("balance")
@click.argument("agent_id")
@pass_ctx
def credits_balance(ctx: CliContext, agent_id: str) -> None:
    """Check an agent's credit balance."""
    if ctx.mode != "remote":
        _error("credits require a remote API. Use --api-url or set SWARM_API_URL.")
    client = ctx.get_client()
    try:
        _output(ctx, client.get_credits(agent_id))
    except Exception as exc:
        _error(str(exc))


@credits.command("topup")
@click.argument("agent_id")
@click.argument("amount", type=float)
@pass_ctx
def credits_topup(ctx: CliContext, agent_id: str, amount: float) -> None:
    """Add credits to an agent's balance (max 1000 per topup)."""
    if ctx.mode != "remote":
        _error("credits require a remote API. Use --api-url or set SWARM_API_URL.")
    client = ctx.get_client()
    try:
        _output(ctx, client.topup_credits(agent_id, amount))
    except Exception as exc:
        _error(str(exc))


# ---------------------------------------------------------------------------
# auth group (remote only)
# ---------------------------------------------------------------------------


@main.group()
def auth() -> None:
    """Authentication and token management."""


@auth.command("token")
@click.argument("agent_id")
@click.option("--role", default="worker", help="Agent role for the token.")
@pass_ctx
def auth_token(ctx: CliContext, agent_id: str, role: str) -> None:
    """Request a JWT token for an agent (remote only)."""
    if ctx.mode != "remote":
        _error("auth token requires a remote API. Use --api-url or set SWARM_API_URL.")
    client = ctx.get_client()
    try:
        result = client.create_token(agent_id=agent_id, role=role)
        _output(ctx, result)
    except Exception as exc:
        _error(str(exc))


# ---------------------------------------------------------------------------
# workflow group (remote only)
# ---------------------------------------------------------------------------


@main.group()
def workflow() -> None:
    """Execute workflow steps (remote only)."""


@workflow.command("execute")
@click.argument("molecule_id")
@click.option("--step", required=True, help="Step ID to execute.")
@click.option("--agent", required=True, help="Agent ID executing the step.")
@click.option("--data", "data_json", default=None, help="Step data as JSON.")
@click.option("--confidence", type=float, default=0.95, help="Confidence score.")
@pass_ctx
def workflow_execute(ctx: CliContext, molecule_id: str, step: str, agent: str,
                     data_json: str | None, confidence: float) -> None:
    """Execute a single step in a forked workflow."""
    if ctx.mode != "remote":
        _error("workflow execute requires a remote API. Use --api-url or set SWARM_API_URL.")

    data: dict[str, Any] = {}
    if data_json:
        try:
            data = json.loads(data_json)
        except json.JSONDecodeError as exc:
            _error(f"Invalid JSON data: {exc}")

    client = ctx.get_client()
    try:
        result = client.execute_step(
            molecule_id=molecule_id, step_id=step,
            agent_id=agent, data=data, confidence=confidence,
        )
        _output(ctx, result)
    except Exception as exc:
        _error(str(exc))


# ---------------------------------------------------------------------------
# molecules group
# ---------------------------------------------------------------------------


@main.group()
def molecules() -> None:
    """Inspect workflow molecule state."""


@molecules.command("list")
@click.option("--agent", "agent_id", default=None, help="Filter by agent ID.")
@click.option("--limit", default=50, help="Max results.")
@click.option("--offset", default=0, help="Skip first N results.")
@pass_ctx
def molecules_list(ctx: CliContext, agent_id: str | None, limit: int, offset: int) -> None:
    """List workflow molecules."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            _output(ctx, client.list_molecules(agent_id=agent_id, limit=limit, offset=offset))
        except Exception as exc:
            _error(str(exc))
    else:
        wf_mod = _server_guard("workflow")
        engine = wf_mod.WorkflowEngine()
        # local mode: no molecules registered yet — return empty list
        all_mols = list(engine._molecules.values())
        if agent_id:
            all_mols = [m for m in all_mols if m.metadata.get("agent_id") == agent_id]
        page = all_mols[offset : offset + limit]
        rows = [
            {
                "molecule_id": m.molecule_id,
                "name": m.name,
                "status": m.status.value,
                "beads": len(m.beads),
                "progress": round(m.progress, 4),
            }
            for m in page
        ]
        _output(ctx, rows)


@molecules.command("get")
@click.argument("molecule_id")
@pass_ctx
def molecules_get(ctx: CliContext, molecule_id: str) -> None:
    """Show molecule detail with bead list."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            _output(ctx, client.get_molecule(molecule_id))
        except Exception as exc:
            _error(str(exc))
    else:
        wf_mod = _server_guard("workflow")
        engine = wf_mod.WorkflowEngine()
        mol = engine.get_molecule(molecule_id)
        if mol is None:
            _error(f"Molecule '{molecule_id}' not found.")
        _output(ctx, {
            "molecule_id": mol.molecule_id,
            "name": mol.name,
            "status": mol.status.value,
            "progress": round(mol.progress, 4),
            "bead_count": len(mol.beads),
            "beads": [
                {
                    "bead_id": b.bead_id,
                    "name": b.name,
                    "status": b.status.value,
                    "settlement_hash": b.settlement_hash or "",
                }
                for b in mol.beads
            ],
        })


# ---------------------------------------------------------------------------
# authorship group
# ---------------------------------------------------------------------------


@main.group()
def authorship() -> None:
    """Manage authorship claims and provenance."""


@authorship.command("claim")
@click.argument("content")
@click.option("--agent", required=True, help="Agent ID claiming authorship.")
@click.option("--content-type", default="", help="Content type (e.g., text, code).")
@click.option("--label", default="", help="Human-readable label.")
@click.option("--confidence", type=float, default=0.95, help="Confidence score.")
@pass_ctx
def authorship_claim(ctx: CliContext, content: str, agent: str,
                     content_type: str, label: str, confidence: float) -> None:
    """Claim authorship of content."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            result = client.claim_authorship(
                agent_id=agent, content=content,
                content_type=content_type, label=label,
                confidence=confidence,
            )
            _output(ctx, result)
        except Exception as exc:
            _error(str(exc))
    else:
        from swarm_at.engine import SwarmAtEngine
        from swarm_at.settler import content_fingerprint

        ledger = ctx.get_ledger()
        engine = SwarmAtEngine(ledger)
        c_hash = content_fingerprint(content)
        receipt = engine.claim_authorship(
            agent_id=agent, content_hash=c_hash,
            content_type=content_type, label=label,
            confidence=confidence,
        )
        _output(ctx, {
            "status": receipt.status.value,
            "hash": receipt.hash,
            "content_hash": c_hash,
            "agent_id": agent,
        })


@authorship.command("verify")
@click.argument("content_hash")
@click.option("--agent", default="", help="Filter by agent ID.")
@pass_ctx
def authorship_verify(ctx: CliContext, content_hash: str, agent: str) -> None:
    """Verify an authorship claim by content hash."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            result = client.verify_authorship(content_hash=content_hash, agent_id=agent)
            _output(ctx, result)
        except Exception as exc:
            _error(str(exc))
    else:
        from swarm_at.engine import SwarmAtEngine

        ledger = ctx.get_ledger()
        engine = SwarmAtEngine(ledger)
        result = engine.verify_authorship(content_hash=content_hash, agent_id=agent)
        _output(ctx, result)


@authorship.command("list")
@click.argument("agent_id")
@click.option("--limit", default=50, help="Max results.")
@click.option("--offset", default=0, help="Skip first N results.")
@pass_ctx
def authorship_list(ctx: CliContext, agent_id: str, limit: int, offset: int) -> None:
    """List content authored by an agent."""
    if ctx.mode == "remote":
        client = ctx.get_client()
        try:
            page = (offset // limit) + 1 if limit else 1
            _output(ctx, client.list_authored(agent_id, page=page, page_size=limit))
        except Exception as exc:
            _error(str(exc))
    else:
        ledger = ctx.get_ledger()
        entries = ledger.read_all()
        claims: list[dict[str, Any]] = []
        for entry in entries:
            payload = entry.payload
            if payload.get("type") != "authorship-claim":
                continue
            if payload.get("agent_id") != agent_id:
                continue
            claims.append({
                "content_hash": payload.get("content_hash", ""),
                "content_type": payload.get("content_type", ""),
                "label": payload.get("label", ""),
                "settlement_hash": entry.current_hash,
            })
        page_claims = claims[offset : offset + limit]
        _output(ctx, {
            "agent_id": agent_id,
            "claims": page_claims,
            "total": len(claims),
        })


@authorship.command("sessions")
@click.option("--writer", default=None, help="Filter by writer name.")
@click.option("--limit", default=50, help="Max results.")
@click.option("--offset", default=0, help="Skip first N results.")
@pass_ctx
def authorship_sessions(ctx: CliContext, writer: str | None, limit: int, offset: int) -> None:
    """List provenance sessions (remote only)."""
    if ctx.mode != "remote":
        _error("authorship sessions requires a remote API. Use --api-url or set SWARM_API_URL.")
    client = ctx.get_client()
    try:
        page = (offset // limit) + 1 if limit else 1
        _output(ctx, client.list_authorship_sessions(
            writer=writer, page=page, page_size=limit,
        ))
    except Exception as exc:
        _error(str(exc))


@authorship.command("report")
@click.argument("session_id")
@click.option("--text", "use_text", is_flag=True, help="Plain text report instead of JSON.")
@pass_ctx
def authorship_report(ctx: CliContext, session_id: str, use_text: bool) -> None:
    """Get provenance report for a session (remote only)."""
    if ctx.mode != "remote":
        _error("authorship report requires a remote API. Use --api-url or set SWARM_API_URL.")
    client = ctx.get_client()
    try:
        result = client.get_authorship_report(session_id, text=use_text)
        if use_text:
            click.echo(result)
        else:
            _output(ctx, result)
    except Exception as exc:
        _error(str(exc))


# ---------------------------------------------------------------------------
# serve
# ---------------------------------------------------------------------------


@main.command()
@click.option("--host", default="0.0.0.0", help="Bind host.")
@click.option("--port", type=int, default=8000, help="Bind port.")
@click.option("--reload", "use_reload", is_flag=True, help="Enable auto-reload.")
@pass_ctx
def serve(ctx: CliContext, host: str, port: int, use_reload: bool) -> None:
    """Start the swarm.at API server."""
    _server_guard("api")
    try:
        import uvicorn
    except ImportError:
        _error("uvicorn not available. Install with: pip install swarm-at-sdk[server]")
    uvicorn.run("swarm_at.api.main:app", host=host, port=port, reload=use_reload)


# ---------------------------------------------------------------------------
# mcp
# ---------------------------------------------------------------------------


@main.command()
@pass_ctx
def mcp(ctx: CliContext) -> None:
    """Start the MCP stdio server."""
    try:
        from swarm_at.mcp.__main__ import main as mcp_main
    except ImportError:
        _error("MCP module not available. Install with: pip install swarm-at-sdk[server,mcp]")
    mcp_main()


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------

_ENV_EXAMPLE = """\
# swarm.at configuration
# SWARM_API_URL=https://api.swarm.at
# SWARM_API_KEY=sk-...
# SWARM_LEDGER_PATH=ledger.jsonl
# SWARM_TIER=production
# SWARM_SESSION_PATH=sessions.jsonl
"""

_AGENTS_MD = """\
# Agents

Define your agent identities and roles.

| Agent ID | Role | Description |
|----------|------|-------------|
| my-agent | worker | Primary task executor |
"""

_SETTLE_EXAMPLE = """\
\"\"\"Quick-start: settle an agent action.\"\"\"

from swarm_at import settle

result = settle(agent="my-agent", task="research")
print(f"Status: {result.status.value}")
print(f"Hash: {result.hash}")
"""


@main.command()
@click.argument("directory", default=".")
@pass_ctx
def init(ctx: CliContext, directory: str) -> None:
    """Initialize a swarm.at project with starter files."""
    target = Path(directory).resolve()
    target.mkdir(parents=True, exist_ok=True)
    created = []
    for name, content in [
        (".env.example", _ENV_EXAMPLE),
        ("AGENTS.md", _AGENTS_MD),
        ("settle_example.py", _SETTLE_EXAMPLE),
    ]:
        path = target / name
        if path.exists():
            click.echo(f"  skip {name} (exists)")
        else:
            path.write_text(content)
            created.append(name)
            click.echo(f"  created {name}")

    if created:
        click.echo(f"Initialized swarm.at project in {target}")
    else:
        click.echo("All files already exist, nothing to do.")


# ---------------------------------------------------------------------------
# login
# ---------------------------------------------------------------------------


@main.command()
@click.option("--api-url", prompt="API URL", default="https://api.swarm.at")
@click.option("--api-key", prompt="API Key", hide_input=True)
@pass_ctx
def login(ctx: CliContext, api_url: str, api_key: str) -> None:
    """Save credentials to ~/.swarm/config.toml."""
    cfg = _load_config()
    cfg["api_url"] = api_url
    cfg["api_key"] = api_key
    _save_config(cfg)
    click.echo(f"Credentials saved to {CONFIG_FILE}")


# ---------------------------------------------------------------------------
# whoami
# ---------------------------------------------------------------------------


@main.command()
@click.argument("agent_id")
@pass_ctx
def whoami(ctx: CliContext, agent_id: str) -> None:
    """Check agent identity and trust status (remote only)."""
    if ctx.mode != "remote":
        _error("whoami requires a remote API. Use --api-url or set SWARM_API_URL.")
    client = ctx.get_client()
    try:
        result = client.whoami(agent_id)
        _output(ctx, result)
    except Exception as exc:
        _error(str(exc))


if __name__ == "__main__":
    main()
