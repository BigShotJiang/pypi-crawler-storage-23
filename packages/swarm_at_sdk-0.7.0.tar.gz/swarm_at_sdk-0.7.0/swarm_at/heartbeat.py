"""Settlement Pulse: periodic audit submissions and memory drift detection."""

from __future__ import annotations

import time
from typing import Any

from swarm_at.engine import SwarmAtEngine
from swarm_at.models import AgentMetadata, Header, Payload, Proposal
from swarm_at.settler import generate_hash


class DriftResult:
    def __init__(self, drifted: bool, local_hash: str, ledger_hash: str, details: str = ""):
        self.drifted = drifted
        self.local_hash = local_hash
        self.ledger_hash = ledger_hash
        self.details = details


class SettlementPulse:
    """Periodic integrity check that submits work summaries and detects drift.

    Replaces simple heartbeats with audit settlements. Every pulse:
    1. Hashes local agent state
    2. Compares against the ledger's latest hash
    3. Submits a Work Summary to the ledger if no drift
    4. Flags drift if local state is out of sync
    """

    def __init__(
        self,
        engine: SwarmAtEngine | None = None,
        agent_id: str = "default-agent",
        interval_seconds: float = 4 * 3600,  # 4 hours
    ):
        self.engine = engine or SwarmAtEngine()
        self.agent_id = agent_id
        self.interval_seconds = interval_seconds
        self._last_pulse: float = 0.0

    def check_drift(self, local_state: dict[str, Any]) -> DriftResult:
        """Compare local agent state hash against the ledger's latest hash.

        This does NOT submit to the ledger. Use `pulse()` for that.
        """
        local_hash = generate_hash(local_state)
        ledger_hash = self.engine.ledger.get_latest_hash()

        if local_hash == ledger_hash:
            return DriftResult(drifted=False, local_hash=local_hash, ledger_hash=ledger_hash)

        return DriftResult(
            drifted=True,
            local_hash=local_hash,
            ledger_hash=ledger_hash,
            details=f"Local state hash {local_hash[:16]}... != ledger hash {ledger_hash[:16]}...",
        )

    def pulse(self, work_summary: dict[str, Any]) -> dict[str, Any]:
        """Submit a Work Summary + Hash to the ledger.

        This is the "Settlement Pulse" — the agent's periodic check-in
        proving it followed institutional rules.

        Returns:
            Dict with 'status', 'hash' (if settled), and 'timestamp'.
        """
        parent_hash = self.engine.ledger.get_latest_hash()

        proposal = Proposal(
            header=Header(
                parent_hash=parent_hash,
                agent_metadata=AgentMetadata(model=self.agent_id, version="pulse"),
            ),
            payload=Payload(
                data_update={
                    "type": "settlement_pulse",
                    "agent_id": self.agent_id,
                    "work_summary": work_summary,
                    "pulse_timestamp": time.time(),
                },
                confidence_score=1.0,  # Heartbeat pulses are self-attested
            ),
            proof=f"Settlement pulse from {self.agent_id}",
        )

        result = self.engine.verify_and_settle(proposal)
        self._last_pulse = time.time()

        return {
            "status": result.status.value,
            "hash": result.hash,
            "timestamp": self._last_pulse,
            "reason": result.reason,
        }

    def is_due(self) -> bool:
        """Check if enough time has elapsed since the last pulse."""
        if self._last_pulse == 0.0:
            return True
        return (time.time() - self._last_pulse) >= self.interval_seconds

    def pulse_if_due(self, work_summary: dict[str, Any]) -> dict[str, Any] | None:
        """Submit a pulse only if the interval has elapsed. Returns None if not due."""
        if not self.is_due():
            return None
        return self.pulse(work_summary)

    @property
    def last_pulse_time(self) -> float:
        return self._last_pulse
