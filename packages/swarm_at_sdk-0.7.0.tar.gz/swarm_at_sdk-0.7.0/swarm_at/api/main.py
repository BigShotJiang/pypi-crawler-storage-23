"""FastAPI service exposing the swarm.at settlement protocol."""

from __future__ import annotations

import os

import swarm_at.api.state as state
from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel, ValidationError
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address

from swarm_at.context import get_context_slice
from swarm_at.models import (
    BatchSettleRequest,
    BatchSettleResponse,
    SettleRequest,
    SettlementResult,
)

app = FastAPI(
    title="swarm.at",
    description="Stateless Swarm-as-a-Service Information Settlement Protocol",
    version="0.7.0",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
)

# CORS — public API, allow all origins (CDN caches vary by Origin)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rate limiting
limiter = Limiter(key_func=get_remote_address, headers_enabled=True)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)  # type: ignore[arg-type]
app.add_middleware(SlowAPIMiddleware)


@app.exception_handler(405)
async def method_not_allowed(request: Request, exc: HTTPException) -> JSONResponse:
    """Return actionable error for wrong HTTP method."""
    return JSONResponse(
        status_code=405,
        content={
            "error": "Method Not Allowed",
            "detail": f"{request.method} is not allowed on {request.url.path}. Check the OpenAPI spec for valid methods.",
            "docs": "/.well-known/openapi.json",
        },
    )


@app.exception_handler(404)
async def not_found(request: Request, exc: HTTPException) -> JSONResponse:
    """Return actionable 404 with discovery hint."""
    detail = getattr(exc, "detail", "Resource not found")
    return JSONResponse(
        status_code=404,
        content={
            "error": "Not Found",
            "detail": detail,
            "hint": "Use GET /v1/ledger/latest for valid hashes, GET /public/agents for agent IDs.",
        },
    )


def verify_api_key(request: Request) -> None:
    """Validate Bearer token via JWT or API key. No-op in dev mode."""
    if not state.api_keys and state.jwt_auth is None:
        return  # Auth disabled (dev mode)
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing Bearer token. Add header: Authorization: Bearer <api-key>")
    token = auth[7:].strip()
    # Try JWT first
    if state.jwt_auth is not None:
        try:
            state.jwt_auth.verify_token(token)
            return
        except Exception:
            pass
    # Fall back to API key
    if token in state.api_keys:
        return
    raise HTTPException(status_code=403, detail="Invalid API key or expired JWT. Re-authenticate via POST /v1/auth/token.")


@app.post("/v1/settle", response_model=SettlementResult, dependencies=[Depends(verify_api_key)], tags=["settlement"])
def settle(request: SettleRequest) -> SettlementResult:
    """Submit a proposal for settlement."""
    return state.engine.verify_and_settle(request.primary, shadow=request.shadow)


@app.post("/v1/settle/batch", response_model=BatchSettleResponse, dependencies=[Depends(verify_api_key)], tags=["settlement"])
def settle_batch(request: BatchSettleRequest) -> BatchSettleResponse:
    """Submit multiple proposals for settlement in one request.

    Each proposal is settled sequentially to preserve hash-chain order.
    If one proposal fails, the rest continue. Returns per-proposal results
    with aggregate settled/rejected counts.
    """
    if not request.proposals:
        raise HTTPException(status_code=400, detail="proposals must not be empty")

    results: list[SettlementResult] = []
    settled = 0
    rejected = 0

    for req in request.proposals:
        result = state.engine.verify_and_settle(req.primary, shadow=req.shadow)
        results.append(result)
        if result.status.value == "SETTLED":
            settled += 1
        else:
            rejected += 1

    return BatchSettleResponse(results=results, settled=settled, rejected=rejected)


@app.get("/v1/context", dependencies=[Depends(verify_api_key)], tags=["settlement"])
def context(keywords: str = Query(..., description="Comma-separated keywords")) -> dict[str, str]:
    """Get a context slice for a task."""
    kw_list = [k.strip() for k in keywords.split(",") if k.strip()]
    return get_context_slice(state.shared_state, kw_list)


@app.get("/v1/status/{task_id}", dependencies=[Depends(verify_api_key)], tags=["settlement"])
def status(task_id: str) -> dict[str, object]:
    """Check settlement status of a specific task."""
    entries = state.ledger.read_all()
    for entry in reversed(entries):
        if entry.task_id == task_id:
            return {
                "task_id": task_id,
                "status": "SETTLED",
                "hash": entry.current_hash,
                "timestamp": entry.timestamp,
            }
    raise HTTPException(status_code=404, detail=f"Task {task_id} not found in ledger")


@app.get("/v1/ledger/latest", dependencies=[Depends(verify_api_key)], tags=["ledger"])
def ledger_latest() -> dict[str, str]:
    """Get the latest settled hash."""
    return {"latest_hash": state.ledger.get_latest_hash()}


@app.get("/v1/ledger/verify", dependencies=[Depends(verify_api_key)], tags=["ledger"])
def ledger_verify() -> dict[str, object]:
    """Verify full ledger integrity."""
    intact = state.ledger.verify_chain()
    entry_count = len(state.ledger.read_all())
    return {
        "intact": intact,
        "entry_count": entry_count,
    }


# ---------------------------------------------------------------------------
# Public read-only endpoints (no auth required)
# ---------------------------------------------------------------------------


@app.get("/public/ledger", tags=["ledger"])
@limiter.limit("60/minute")
def public_ledger(
    request: Request,
    offset: int = Query(0, ge=0, description="Number of entries to skip"),
    limit: int = Query(50, ge=1, le=500, description="Max entries to return"),
) -> JSONResponse:
    """Paginated public ledger view."""
    entries = state.ledger.read_all()
    total = len(entries)
    page = entries[offset : offset + limit]
    return JSONResponse({
        "entries": [e.model_dump() for e in page],
        "total": total,
        "offset": offset,
        "limit": limit,
    })


@app.get("/public/ledger/latest", tags=["ledger"])
def public_ledger_latest() -> dict[str, str]:
    """Latest settled hash (public)."""
    return {"latest_hash": state.ledger.get_latest_hash()}


@app.get("/public/ledger/verify", tags=["ledger"])
def public_ledger_verify() -> dict[str, object]:
    """Verify chain integrity (public)."""
    intact = state.ledger.verify_chain()
    entry_count = len(state.ledger.read_all())
    return {"intact": intact, "entry_count": entry_count}


@app.get("/public/receipts/{hash}", tags=["ledger"])
def public_receipt(hash: str) -> dict[str, object]:
    """Look up a settlement receipt by hash (public)."""
    entries = state.ledger.read_all()
    for entry in entries:
        if entry.current_hash == hash:
            return {
                "status": "SETTLED",
                "hash": entry.current_hash,
                "task_id": entry.task_id,
                "timestamp": entry.timestamp,
                "parent_hash": entry.parent_hash,
            }
    raise HTTPException(status_code=404, detail=f"Receipt {hash} not found in ledger")


@app.get("/public/ledger/entry/{task_id}", tags=["ledger"])
def public_ledger_entry(task_id: str) -> dict[str, object]:
    """Look up a single entry by task_id (public)."""
    entries = state.ledger.read_all()
    for entry in reversed(entries):
        if entry.task_id == task_id:
            return entry.model_dump()
    raise HTTPException(status_code=404, detail=f"Task {task_id} not found in ledger")


# ---------------------------------------------------------------------------
# Public agent registry endpoints (no auth required)
# ---------------------------------------------------------------------------


_AGENT_SORT_KEYS = {
    "reputation": lambda a: a.reputation_score,
    "volume": lambda a: a.settlements_completed,
    "success_rate": lambda a: a.success_rate,
    "active": lambda a: a.last_active,
    "seniority": lambda a: a.registered_at,
}


@app.get("/public/agents", tags=["agents"])
@limiter.limit("60/minute")
def public_agents(
    request: Request,
    min_trust: str = Query("untrusted", description="Minimum trust level"),
    role: str | None = Query(None, description="Filter by role (worker, orchestrator, etc.)"),
    sort: str = Query("reputation", description="Sort key: reputation, volume, success_rate, active, seniority"),
    order: str = Query("desc", description="Sort order: asc or desc"),
    page: int = Query(1, ge=1, description="Page number (1-indexed)"),
    page_size: int = Query(50, ge=1, le=200, description="Results per page"),
) -> JSONResponse:
    """Public agent leaderboard — ranked directory of agents."""
    from swarm_at.agents import AgentRole, TrustLevel

    try:
        level = TrustLevel(min_trust)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid trust level: {min_trust}")

    if sort not in _AGENT_SORT_KEYS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid sort: {sort}. Must be one of: {', '.join(_AGENT_SORT_KEYS)}",
        )

    if order not in ("asc", "desc"):
        raise HTTPException(status_code=400, detail="order must be 'asc' or 'desc'")

    agents = state.agent_registry.find_by_trust(level)

    if role is not None:
        try:
            role_filter = AgentRole(role)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid role: {role}")
        agents = [a for a in agents if a.role == role_filter]

    agents.sort(key=_AGENT_SORT_KEYS[sort], reverse=(order == "desc"))

    total = len(agents)
    start = (page - 1) * page_size
    page_agents = agents[start : start + page_size]

    return JSONResponse({
        "agents": [
            {
                "agent_id": a.agent_id,
                "role": a.role.value,
                "trust_level": a.trust_level.value,
                "settlements_completed": a.settlements_completed,
                "success_rate": round(a.success_rate, 4),
                "reputation_score": round(a.reputation_score, 4),
                "last_active": a.last_active,
            }
            for a in page_agents
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
        "has_more": start + page_size < total,
    })


@app.get("/public/verify-trust", tags=["agents"])
def public_verify_trust(
    agent_id: str = Query(..., description="Agent ID to verify"),
    min_trust: str = Query("trusted", description="Minimum trust level required"),
) -> dict[str, object]:
    """Check if an agent meets a trust threshold. No auth required."""
    from swarm_at.agents import AgentError, TrustLevel

    try:
        level = TrustLevel(min_trust)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid trust level: {min_trust}")

    try:
        agent = state.agent_registry.get(agent_id)
    except AgentError:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")

    trust_order = list(TrustLevel)
    meets = trust_order.index(agent.trust_level) >= trust_order.index(level)
    return {
        "agent_id": agent.agent_id,
        "meets_requirement": meets,
        "trust_level": agent.trust_level.value,
        "reputation_score": round(agent.reputation_score, 4),
    }


@app.get("/public/trust-summary", tags=["agents"])
def public_trust_summary() -> dict[str, object]:
    """Aggregate trust-level counts across all agents. No auth required."""
    from swarm_at.agents import TrustLevel

    counts: dict[str, int] = {level.value: 0 for level in TrustLevel}
    all_agents = state.agent_registry.find_by_trust(TrustLevel.UNTRUSTED)
    for agent in all_agents:
        counts[agent.trust_level.value] += 1

    return {
        "total_agents": sum(counts.values()),
        "by_trust_level": counts,
    }


# ---------------------------------------------------------------------------
# Public dashboard aggregate endpoint (no auth required)
# ---------------------------------------------------------------------------


@app.get("/public/dashboard", tags=["dashboard"])
@limiter.limit("30/minute")
def public_dashboard(request: Request) -> JSONResponse:
    """Aggregate dashboard data: ledger, agents, blueprints, leaderboard."""
    import time as _time

    from swarm_at.agents import TrustLevel

    # Ledger stats
    entries = state.ledger.read_all()
    entry_count = len(entries)
    intact = state.ledger.verify_chain()
    latest_hash = state.ledger.get_latest_hash()

    # Agent trust breakdown
    all_agents = state.agent_registry.find_by_trust(TrustLevel.UNTRUSTED)
    trust_counts: dict[str, int] = {level.value: 0 for level in TrustLevel}
    for agent in all_agents:
        trust_counts[agent.trust_level.value] += 1

    # Blueprint stats with fork counts
    from swarm_at.blueprints import Blueprint

    all_bps = state.blueprint_store.list_blueprints()
    bp_with_forks: list[tuple[Blueprint, int]] = []
    for bp in all_bps:
        try:
            forks = state.blueprint_store.fork_count(bp.blueprint_id)
        except Exception:
            forks = 0
        bp_with_forks.append((bp, forks))

    bp_with_forks.sort(key=lambda x: x[1], reverse=True)
    top_forked = [
        {
            "blueprint_id": bp.blueprint_id,
            "name": bp.name,
            "author": bp.author,
            "fork_count": forks,
            "credit_cost": bp.credit_cost,
            "tags": bp.tags,
        }
        for bp, forks in bp_with_forks[:5]
    ]

    # Publisher leaderboard: earnings per author from fork data
    _earned: dict[str, float] = {}
    _published: dict[str, int] = {}
    _author_forks: dict[str, int] = {}
    for bp, forks in bp_with_forks:
        if not bp.author or bp.author == "swarm.at":
            continue
        _earned[bp.author] = _earned.get(bp.author, 0.0) + forks * bp.credit_cost * bp.author_reward_rate
        _published[bp.author] = _published.get(bp.author, 0) + 1
        _author_forks[bp.author] = _author_forks.get(bp.author, 0) + forks

    leaderboard_authors = sorted(_earned.keys(), key=lambda a: _earned[a], reverse=True)[:10]
    leaderboard: list[dict[str, object]] = [
        {
            "agent_id": a,
            "total_earned": round(_earned[a], 2),
            "blueprints_published": _published[a],
            "total_forks": _author_forks[a],
        }
        for a in leaderboard_authors
    ]

    # Recent activity
    now = _time.time()
    recent_entries = [e for e in entries if e.timestamp > now - 86400]
    last_20 = sorted(entries, key=lambda e: e.timestamp, reverse=True)[:20]
    latest_types: list[str] = list(dict.fromkeys(
        e.payload.get("type", "") for e in last_20
        if isinstance(e.payload, dict)
    ))

    return JSONResponse({
        "ledger": {
            "entry_count": entry_count,
            "intact": intact,
            "latest_hash": latest_hash,
        },
        "agents": {
            "total": sum(trust_counts.values()),
            "by_trust_level": trust_counts,
        },
        "blueprints": {
            "total": len(all_bps),
            "top_forked": top_forked,
        },
        "publisher_leaderboard": leaderboard,
        "recent_activity": {
            "settlements_24h": len(recent_entries),
            "latest_types": latest_types[:10],
        },
    })


# ---------------------------------------------------------------------------
# Public authorship verification endpoints (no auth required)
# ---------------------------------------------------------------------------


@app.get("/public/verify-authorship", tags=["authorship"])
def public_verify_authorship(
    content_hash: str = Query(..., min_length=64, max_length=64, description="SHA-256 content hash"),
    agent_id: str = Query("", description="Optional agent ID to verify against"),
) -> dict[str, object]:
    """Verify an authorship claim. Returns the earliest matching claim."""
    result = state.engine.verify_authorship(content_hash, agent_id=agent_id)
    return result


@app.get("/public/authorship/{content_hash}", tags=["authorship"])
def public_authorship_by_content(content_hash: str) -> dict[str, object]:
    """All authorship claims for a given content hash, earliest first."""
    result = state.engine.verify_authorship(content_hash)
    if not result.get("verified"):
        return {"content_hash": content_hash, "claims": [], "first_claim": None}
    return {
        "content_hash": content_hash,
        "claims": result.get("claims", []),
        "first_claim": result.get("first_claim"),
    }


@app.get("/public/agents/{agent_id}/authored", tags=["authorship"])
def public_agent_authored(
    agent_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
) -> dict[str, object]:
    """Paginated list of content an agent has claimed authorship of."""
    entries = state.ledger.read_all()
    claims: list[dict[str, object]] = []
    for entry in entries:
        payload = entry.payload
        if payload.get("type") != "authorship-claim":
            continue
        if payload.get("agent_id") != agent_id:
            continue
        claims.append({
            "content_hash": payload.get("content_hash", ""),
            "content_type": payload.get("content_type", ""),
            "label": payload.get("label", ""),
            "settlement_hash": entry.current_hash,
            "timestamp": entry.timestamp,
        })
    total = len(claims)
    start = (page - 1) * page_size
    page_claims = claims[start : start + page_size]
    return {
        "agent_id": agent_id,
        "claims": page_claims,
        "total": total,
        "page": page,
        "has_more": start + page_size < total,
    }


@app.get("/badge/{agent_id}", tags=["discovery"])
def trust_badge(agent_id: str):  # type: ignore[no-untyped-def]
    """SVG trust badge for an agent (shields.io flat style). No auth required."""
    from fastapi.responses import Response

    from swarm_at.agents import AgentError
    from swarm_at.openclaw import generate_trust_badge

    try:
        agent = state.agent_registry.get(agent_id)
    except AgentError:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")

    svg = generate_trust_badge(agent.agent_id, agent.trust_level.value)
    return Response(content=svg, media_type="image/svg+xml")


@app.get("/public/agents/{agent_id}", tags=["agents"])
def public_agent_detail(agent_id: str) -> dict[str, object]:
    """Public agent profile — verified work history."""
    from swarm_at.agents import AgentError

    try:
        agent = state.agent_registry.get(agent_id)
    except AgentError:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")
    return {
        "agent_id": agent.agent_id,
        "role": agent.role.value,
        "trust_level": agent.trust_level.value,
        "settlements_completed": agent.settlements_completed,
        "settlements_failed": agent.settlements_failed,
        "success_rate": round(agent.success_rate, 4),
        "reputation_score": round(agent.reputation_score, 4),
        "capabilities": agent.capabilities,
        "registered_at": agent.registered_at,
        "under_review": agent.under_review,
    }


# ---------------------------------------------------------------------------
# Public blueprint endpoints (no auth required)
# ---------------------------------------------------------------------------


@app.get("/public/blueprints", tags=["blueprints"])
@limiter.limit("60/minute")
def public_blueprints(
    request: Request,
    tag: str | None = Query(None, description="Filter by tag"),
    page: int = Query(1, ge=1, description="Page number (1-indexed)"),
    page_size: int = Query(50, ge=1, le=200, description="Results per page"),
) -> JSONResponse:
    """Public blueprint catalog — list and filter blueprints."""
    blueprints = state.blueprint_store.list_blueprints(tag=tag)
    total = len(blueprints)
    start = (page - 1) * page_size
    page_bps = blueprints[start : start + page_size]

    def _fork_count(bp_id: str) -> int:
        try:
            return state.blueprint_store.fork_count(bp_id)
        except Exception:
            return 0

    return JSONResponse({
        "blueprints": [
            {
                "blueprint_id": bp.blueprint_id,
                "name": bp.name,
                "description": bp.description,
                "version": bp.version,
                "author": bp.author,
                "tags": bp.tags,
                "step_count": len(bp.steps),
                "validated": bp.validated,
                "credit_cost": bp.credit_cost,
                "fork_count": _fork_count(bp.blueprint_id),
            }
            for bp in page_bps
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
        "has_more": start + page_size < total,
    })


@app.get("/public/blueprints/{blueprint_id}", tags=["blueprints"])
def public_blueprint_detail(blueprint_id: str) -> dict[str, object]:
    """Blueprint detail with steps and fork count."""
    from swarm_at.blueprints import BlueprintError

    try:
        bp = state.blueprint_store.get_blueprint(blueprint_id)
    except BlueprintError:
        raise HTTPException(status_code=404, detail=f"Blueprint {blueprint_id} not found")

    try:
        forks = state.blueprint_store.fork_count(blueprint_id)
    except BlueprintError:
        forks = 0

    return {
        "blueprint_id": bp.blueprint_id,
        "name": bp.name,
        "description": bp.description,
        "version": bp.version,
        "author": bp.author,
        "tags": bp.tags,
        "steps": [
            {
                "step_id": s.step_id,
                "name": s.name,
                "description": s.description,
                "depends_on": s.depends_on,
                "agent_role": s.agent_role,
                "complexity": s.complexity,
            }
            for s in bp.steps
        ],
        "validated": bp.validated,
        "authorship_hash": bp.authorship_hash,
        "fork_count": forks,
    }


# ---------------------------------------------------------------------------
# Agent registration (auth required)
# ---------------------------------------------------------------------------


class RegisterAgentRequest(BaseModel):
    """Request body for agent self-registration."""

    agent_id: str
    role: str = "worker"
    capabilities: list[str] = []


@app.post("/v1/agents/register", dependencies=[Depends(verify_api_key)], tags=["agents"])
def register_agent(req: RegisterAgentRequest) -> dict[str, object]:
    """Register a new agent identity."""
    from swarm_at.agents import AgentError, AgentRole

    try:
        role = AgentRole(req.role)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid role: {req.role}")

    try:
        agent = state.agent_registry.register(
            agent_id=req.agent_id,
            role=role,
            capabilities=req.capabilities,
        )
    except ValidationError as exc:
        raise HTTPException(status_code=400, detail=exc.errors()[0]["msg"])
    except AgentError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    # Auto-seed credits for new agents
    balance = state.credit_ledger.register(req.agent_id)

    return {
        "agent_id": agent.agent_id,
        "role": agent.role.value,
        "trust_level": agent.trust_level.value,
        "capabilities": agent.capabilities,
        "registered_at": agent.registered_at,
        "credits": balance,
    }


@app.get("/v1/agents/{agent_id}", dependencies=[Depends(verify_api_key)], tags=["agents"])
def get_agent(agent_id: str) -> dict[str, object]:
    """Authenticated agent detail — includes review status."""
    from swarm_at.agents import AgentError

    try:
        agent = state.agent_registry.get(agent_id)
    except AgentError:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")

    return {
        "agent_id": agent.agent_id,
        "role": agent.role.value,
        "trust_level": agent.trust_level.value,
        "settlements_completed": agent.settlements_completed,
        "settlements_failed": agent.settlements_failed,
        "success_rate": round(agent.success_rate, 4),
        "reputation_score": round(agent.reputation_score, 4),
        "capabilities": agent.capabilities,
        "registered_at": agent.registered_at,
        "last_active": agent.last_active,
        "under_review": agent.under_review,
        "divergence_penalty": agent.divergence_penalty,
    }


@app.get("/v1/whoami", dependencies=[Depends(verify_api_key)], tags=["agents"])
def whoami(agent_id: str = Query(..., description="Agent ID to inspect")) -> dict[str, object]:
    """Agent self-check — trust status, effective permissions, promotion path."""
    from swarm_at.agents import (
        AgentError,
        BAYESIAN_THRESHOLDS,
        ROLE_DEFAULT_TOOLS,
        TrustLevel,
    )

    try:
        agent = state.agent_registry.get(agent_id)
    except AgentError:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")

    # Compute effective allowed tools (after trust gates)
    role_tools = ROLE_DEFAULT_TOOLS.get(agent.role, set())
    base_tools = set(agent.allowed_tools) if agent.allowed_tools is not None else role_tools
    effective_tools = sorted(
        t for t in base_tools
        if t not in agent.denied_tools and agent.can_use_tool(t)
    )

    # Next promotion target
    trust_order = list(TrustLevel)
    current_idx = trust_order.index(agent.trust_level)
    next_promotion: dict[str, object] | None = None
    if agent.trust_level != TrustLevel.SENIOR:
        target = trust_order[current_idx + 1]
        thresholds = BAYESIAN_THRESHOLDS[target]
        next_promotion = {
            "target_level": target.value,
            "required_volume": thresholds["min_volume"],
            "required_lower_bound": thresholds["min_lower_bound"],
        }

    return {
        "agent_id": agent.agent_id,
        "role": agent.role.value,
        "trust_level": agent.trust_level.value,
        "reputation_score": round(agent.reputation_score, 4),
        "bayesian_lower_bound": round(agent.bayesian_lower_bound, 4),
        "is_in_cooldown": agent.is_in_cooldown,
        "cooldown_until": agent.cooldown_until,
        "under_review": agent.under_review,
        "allowed_tools": effective_tools,
        "next_promotion": next_promotion,
    }


# ---------------------------------------------------------------------------
# Credit endpoints (auth required)
# ---------------------------------------------------------------------------


class TopupRequest(BaseModel):
    """Request body for credit topup."""

    amount: float


@app.get("/v1/credits/{agent_id}", dependencies=[Depends(verify_api_key)], tags=["credits"])
def get_credits(agent_id: str) -> dict[str, object]:
    """Check an agent's credit balance."""
    from swarm_at.credits import CreditError

    try:
        balance = state.credit_ledger.balance(agent_id)
    except CreditError:
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not registered in credit ledger")
    return {"agent_id": agent_id, "balance": balance}


MAX_TOPUP_AMOUNT = 1000.0


@app.post("/v1/credits/{agent_id}/topup", dependencies=[Depends(verify_api_key)], tags=["credits"])
def topup_credits(agent_id: str, req: TopupRequest) -> dict[str, object]:
    """Add credits to an agent's balance. Capped at 1000 per request."""
    if req.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")
    if req.amount > MAX_TOPUP_AMOUNT:
        raise HTTPException(
            status_code=400,
            detail=f"Amount exceeds maximum topup of {MAX_TOPUP_AMOUNT}",
        )
    new_balance = state.credit_ledger.topup(agent_id, req.amount)
    return {"agent_id": agent_id, "balance": new_balance}


# ---------------------------------------------------------------------------
# Blueprint execution (auth required)
# ---------------------------------------------------------------------------


@app.post("/v1/blueprints/{blueprint_id}/fork", dependencies=[Depends(verify_api_key)], tags=["blueprints"])
def fork_blueprint(blueprint_id: str, agent_id: str = Query("anonymous")) -> dict[str, object]:
    """Fork a blueprint into an executable workflow molecule. Debits credit cost."""
    from swarm_at.blueprints import BlueprintError
    from swarm_at.credits import CreditError
    from swarm_at.workflow import fork_blueprint as _fork

    try:
        bp = state.blueprint_store.get_blueprint(blueprint_id)
    except BlueprintError:
        raise HTTPException(status_code=404, detail=f"Blueprint {blueprint_id} not found")

    # Debit credits for the blueprint cost
    if bp.credit_cost > 0:
        try:
            state.credit_ledger.debit(agent_id, bp.credit_cost)
        except CreditError as exc:
            raise HTTPException(
                status_code=402,
                detail=f"{exc}. Check balance: GET /v1/credits/{agent_id}. Add credits: POST /v1/credits/{agent_id}/topup",
            )

        # Credit the blueprint author a reward (skip internal blueprints)
        if bp.author and bp.author != "swarm.at":
            reward = bp.credit_cost * bp.author_reward_rate
            if reward > 0:
                state.credit_ledger.topup(bp.author, reward)

    molecule = _fork(bp, agent_id=agent_id)
    state.workflow_engine.register_molecule(molecule)
    return {
        "molecule_id": molecule.molecule_id,
        "name": molecule.name,
        "bead_count": len(molecule.beads),
        "metadata": molecule.metadata,
    }


class PublishBlueprintRequest(BaseModel):
    """Request body for publishing a new blueprint."""

    name: str
    description: str = ""
    tags: list[str] = []
    steps: list[dict[str, object]] = []
    credit_cost: float = 1.0
    agent_id: str


@app.post("/v1/blueprints/publish", dependencies=[Depends(verify_api_key)], tags=["blueprints"])
def publish_blueprint(req: PublishBlueprintRequest) -> dict[str, object]:
    """Publish a new blueprint. Created as unvalidated."""
    import uuid

    from swarm_at.blueprints import Blueprint, BlueprintStep

    bp_steps = [
        BlueprintStep(
            step_id=str(s.get("step_id", str(uuid.uuid4()))),  # type: ignore[union-attr]
            name=str(s.get("name", "step")),  # type: ignore[union-attr]
            description=str(s.get("description", "")),  # type: ignore[union-attr]
            depends_on=s.get("depends_on", []),  # type: ignore[union-attr,arg-type]
            agent_role=str(s.get("agent_role", "worker")),  # type: ignore[union-attr]
        )
        for s in req.steps
    ]

    bp = Blueprint(
        blueprint_id=str(uuid.uuid4()),
        name=req.name,
        description=req.description,
        tags=req.tags,
        steps=bp_steps,
        credit_cost=req.credit_cost,
        author=req.agent_id,
        validated=False,
    )

    state.blueprint_store.register_blueprint(bp)

    # Auto-settle an authorship claim for the blueprint
    from swarm_at.settler import content_fingerprint

    bp_content = bp.model_dump_json(exclude={"authorship_hash"})
    authorship_result = state.engine.claim_authorship(
        agent_id=req.agent_id,
        content_hash=content_fingerprint(bp_content),
        content_type="blueprint",
        label=bp.name,
    )
    if authorship_result.status.value == "SETTLED":
        bp.authorship_hash = authorship_result.hash or ""

    return {
        "blueprint_id": bp.blueprint_id,
        "name": bp.name,
        "author": bp.author,
        "step_count": len(bp.steps),
        "validated": bp.validated,
        "authorship_hash": bp.authorship_hash,
    }


class ExecuteStepRequest(BaseModel):
    """Request body for executing a blueprint step."""
    agent_id: str
    step_id: str
    data: dict[str, object] = {}
    confidence: float = 0.95


@app.post("/v1/molecules/{molecule_id}/execute", dependencies=[Depends(verify_api_key)], tags=["workflows"])
def execute_step(molecule_id: str, req: ExecuteStepRequest) -> dict[str, object]:
    """Execute a single step in a forked blueprint molecule."""
    from swarm_at.workflow import WorkflowError
    try:
        bead = state.workflow_engine.execute_bead(
            molecule_id=molecule_id,
            bead_id=req.step_id,
            output_data=req.data,
        )
    except WorkflowError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    if bead.settlement_hash is None:
        raise HTTPException(status_code=400, detail=f"Step failed: {bead.error}")

    return {
        "molecule_id": molecule_id,
        "step_id": req.step_id,
        "status": "SETTLED",
        "hash": bead.settlement_hash,
    }


@app.get("/v1/molecules", dependencies=[Depends(verify_api_key)], tags=["workflows"])
def list_molecules(
    agent_id: str | None = Query(None, description="Filter by agent ID."),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
) -> dict[str, object]:
    """List registered workflow molecules. Optionally filter by agent_id."""
    all_molecules = list(state.workflow_engine._molecules.values())
    if agent_id is not None:
        all_molecules = [
            m for m in all_molecules
            if m.metadata.get("agent_id") == agent_id
        ]
    total = len(all_molecules)
    page = all_molecules[offset : offset + limit]
    return {
        "molecules": [
            {
                "molecule_id": m.molecule_id,
                "name": m.name,
                "status": m.status.value,
                "bead_count": len(m.beads),
                "progress": round(m.progress, 4),
                "created_at": m.created_at,
                "completed_at": m.completed_at,
                "metadata": m.metadata,
            }
            for m in page
        ],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


@app.get("/v1/molecules/{molecule_id}", dependencies=[Depends(verify_api_key)], tags=["workflows"])
def get_molecule(molecule_id: str) -> dict[str, object]:
    """Get molecule state including bead list and execution status."""
    mol = state.workflow_engine.get_molecule(molecule_id)
    if mol is None:
        raise HTTPException(status_code=404, detail=f"Molecule {molecule_id} not found")
    return {
        "molecule_id": mol.molecule_id,
        "name": mol.name,
        "status": mol.status.value,
        "progress": round(mol.progress, 4),
        "created_at": mol.created_at,
        "completed_at": mol.completed_at,
        "atomic": mol.atomic,
        "metadata": mol.metadata,
        "beads": [
            {
                "bead_id": b.bead_id,
                "name": b.name,
                "agent_id": b.agent_id,
                "status": b.status.value,
                "depends_on": b.depends_on,
                "settlement_hash": b.settlement_hash,
                "started_at": b.started_at,
                "completed_at": b.completed_at,
                "error": b.error,
            }
            for b in mol.beads
        ],
    }


# ---------------------------------------------------------------------------
# JWT token endpoint (public — agents exchange credentials for tokens)
# ---------------------------------------------------------------------------


class TokenRequest(BaseModel):
    """Request body for JWT token generation."""

    agent_id: str
    role: str = "worker"


@app.post("/v1/auth/token", dependencies=[Depends(verify_api_key)], tags=["auth"])
def create_token(req: TokenRequest) -> dict[str, object]:
    """Issue a JWT token for an agent. Requires auth + JWT to be configured."""
    if state.jwt_auth is None:
        raise HTTPException(status_code=501, detail="JWT auth not configured. Set SWARM_JWT_SECRET.")
    token = state.jwt_auth.create_token(agent_id=req.agent_id, role=req.role)
    return {"token": token, "agent_id": req.agent_id, "role": req.role}


# ---------------------------------------------------------------------------
# Ledger mode endpoint
# ---------------------------------------------------------------------------


@app.get("/v1/ledger/mode", tags=["ledger"])
def ledger_mode() -> dict[str, object]:
    """Report which ledger backend is active."""
    from swarm_at.ledger_factory import ledger_status as _status
    return _status(state.ledger)


# ---------------------------------------------------------------------------
# Webhook endpoints (auth required)
# ---------------------------------------------------------------------------


class WebhookRequest(BaseModel):
    """Request body for webhook registration."""

    event: str
    url: str


@app.post("/v1/webhooks", dependencies=[Depends(verify_api_key)], tags=["webhooks"])
def register_webhook(req: WebhookRequest) -> dict[str, object]:
    """Register a webhook URL for settlement events."""
    valid_events = {"settlement.created", "settlement.rejected", "blueprint.forked"}
    if req.event not in valid_events:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid event: {req.event}. Must be one of: {', '.join(sorted(valid_events))}",
        )
    state.webhook_registry.register(req.event, req.url)
    return {"event": req.event, "url": req.url, "status": "registered"}


@app.delete("/v1/webhooks", dependencies=[Depends(verify_api_key)], tags=["webhooks"])
def unregister_webhook(req: WebhookRequest) -> dict[str, object]:
    """Remove a webhook registration."""
    removed = state.webhook_registry.unregister(req.event, req.url)
    if not removed:
        raise HTTPException(status_code=404, detail="Webhook not found")
    return {"event": req.event, "url": req.url, "status": "removed"}


@app.get("/v1/webhooks", dependencies=[Depends(verify_api_key)], tags=["webhooks"])
def list_webhooks(event: str | None = Query(None)) -> dict[str, object]:
    """List registered webhooks."""
    hooks = state.webhook_registry.list_hooks(event)
    return {"webhooks": hooks, "total": state.webhook_registry.count}


# ---------------------------------------------------------------------------
# Authorship provenance endpoints (auth required)
# ---------------------------------------------------------------------------


class CreateSessionRequest(BaseModel):
    writer: str
    tool: str


class RecordEventRequest(BaseModel):
    event_type: str
    action: str = ""
    chose: str = ""
    rejected: list[str] | None = None
    text: str = ""
    output_hash: str = ""
    model: str = ""
    description: str = ""
    kept_ratio: float = 0.0
    reason: str = ""
    phase: str = "scene"


class ApproveRequest(BaseModel):
    content_hash: str
    version: str = ""


@app.get("/v1/authorship/sessions", dependencies=[Depends(verify_api_key)], tags=["authorship"])
def list_authorship_sessions(
    writer: str | None = Query(None, description="Filter by writer"),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(50, ge=1, le=200, description="Results per page"),
) -> JSONResponse:
    """List active authorship sessions with optional filtering and pagination."""
    sessions = state.writing_sessions.list_sessions(writer=writer)
    total = len(sessions)
    start = (page - 1) * page_size
    page_sessions = sessions[start : start + page_size]
    return JSONResponse({
        "sessions": [
            {
                "session_id": s.session_id,
                "writer": s.writer,
                "tool": s.tool,
                "event_count": len(s.events),
                "work_agency": s.work_agency,
                "started_at": s._started_at,
            }
            for s in page_sessions
        ],
        "total": total,
        "page": page,
        "page_size": page_size,
        "has_more": start + page_size < total,
    })


@app.delete("/v1/authorship/sessions/{session_id}", dependencies=[Depends(verify_api_key)], tags=["authorship"])
def delete_authorship_session(session_id: str) -> dict[str, object]:
    """Delete an authorship session."""
    if not state.writing_sessions.delete(session_id):
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")
    return {"session_id": session_id, "status": "deleted"}


@app.post("/v1/authorship/sessions", dependencies=[Depends(verify_api_key)], tags=["authorship"])
def create_authorship_session(req: CreateSessionRequest) -> dict[str, object]:
    """Start a new authorship provenance session."""
    from swarm_at.authorship import WritingSession

    session = WritingSession(
        writer=req.writer,
        tool=req.tool,
        ledger_path=str(state.ledger.path),
    )
    state.writing_sessions.create(session)
    return {"session_id": session.session_id, "writer": req.writer, "tool": req.tool}


@app.post("/v1/authorship/sessions/{session_id}/events", dependencies=[Depends(verify_api_key)], tags=["authorship"])
def record_authorship_event(session_id: str, req: RecordEventRequest) -> dict[str, object]:
    """Record a creative event in an authorship session."""
    from swarm_at.authorship import CreativePhase

    session = state.writing_sessions.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")

    try:
        cp = CreativePhase(req.phase)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid phase: {req.phase}")

    if req.event_type == "direction":
        result = session.direct(action=req.action, chose=req.chose, rejected=req.rejected, phase=cp)
    elif req.event_type == "prompt":
        result = session.prompt(text=req.text, phase=cp)
    elif req.event_type == "generation":
        result = session.generate(output_hash=req.output_hash, model=req.model, phase=cp)
    elif req.event_type == "revision":
        result = session.revise(description=req.description, kept_ratio=req.kept_ratio, phase=cp)
    elif req.event_type == "rejection":
        result = session.reject(output_hash=req.output_hash, reason=req.reason, phase=cp)
    else:
        raise HTTPException(status_code=400, detail=f"Invalid event_type: {req.event_type}")

    state.writing_sessions.update(session)
    return {"status": result.status.value, "hash": result.hash}


@app.post("/v1/authorship/sessions/{session_id}/approve", dependencies=[Depends(verify_api_key)], tags=["authorship"])
def approve_authorship(session_id: str, req: ApproveRequest) -> dict[str, object]:
    """Record final approval of content."""
    session = state.writing_sessions.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")
    result = session.approve(content_hash=req.content_hash, version=req.version)
    state.writing_sessions.update(session)
    return {"status": result.status.value, "hash": result.hash}


@app.get("/v1/authorship/sessions/{session_id}/report", dependencies=[Depends(verify_api_key)], tags=["authorship"])
def get_authorship_report(session_id: str) -> dict[str, object]:
    """Get the JSON provenance report."""
    session = state.writing_sessions.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")
    report: dict[str, object] = session.report().model_dump()
    return report


@app.get("/v1/authorship/sessions/{session_id}/report/text", dependencies=[Depends(verify_api_key)], tags=["authorship"])
def get_authorship_report_text(session_id: str) -> PlainTextResponse:
    """Get the plain text provenance report."""
    session = state.writing_sessions.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")
    return PlainTextResponse(content=session.report().to_text())


@app.get("/public/schema", tags=["discovery"])
def public_schema() -> dict[str, object]:
    """Machine-readable protocol schema for agent discovery."""
    from swarm_at.models import Proposal, SettlementResult, SettleRequest
    from swarm_at.tiers import TIER_POLICIES

    return {
        "protocol": "swarm.at",
        "version": "0.1.0",
        "schemas": {
            "Proposal": Proposal.model_json_schema(),
            "SettlementResult": SettlementResult.model_json_schema(),
            "SettleRequest": SettleRequest.model_json_schema(),
        },
        "guarantees": [
            "determinism",
            "idempotency",
            "chain_integrity",
            "trust_scoring",
        ],
        "tiers": {
            tier.value: {
                "enforce_chain": policy.enforce_chain,
                "enforce_confidence": policy.enforce_confidence,
                "write_ledger": policy.write_ledger,
                "log_only": policy.log_only,
            }
            for tier, policy in TIER_POLICIES.items()
        },
    }


@app.get("/health", tags=["discovery"])
def health() -> dict[str, str]:
    """Health check for load balancers and deployment platforms."""
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Discovery routes (public, no auth)
# ---------------------------------------------------------------------------

_API_URL = os.environ.get("SWARM_API_URL", "https://api.swarm.at")
_SITE_URL = os.environ.get("SWARM_SITE_URL", "https://swarm.at")


@app.get("/llms.txt", response_class=PlainTextResponse, tags=["discovery"])
def llms_txt() -> str:
    """LLM-readable protocol summary (llms.txt v1.1.0)."""
    from swarm_at.openclaw import generate_llms_txt
    return generate_llms_txt(_API_URL, _SITE_URL)


@app.get("/robots.txt", response_class=PlainTextResponse, tags=["discovery"])
def robots_txt() -> str:
    """Crawler guidance with llms.txt reference."""
    from swarm_at.openclaw import generate_robots_txt
    return generate_robots_txt(_API_URL)


@app.get("/.well-known/agent-card.json", tags=["discovery"])
@app.get("/.well-known/agent.json", tags=["discovery"])
def agent_card() -> JSONResponse:
    """A2A agent card for agent-to-agent discovery."""
    from swarm_at.openclaw import generate_agent_card
    return JSONResponse(content=generate_agent_card(_API_URL))


@app.get("/.well-known/openapi.json", tags=["discovery"])
def well_known_openapi() -> JSONResponse:
    """Enriched OpenAPI spec at .well-known path."""
    from swarm_at.openclaw import enrich_openapi
    schema = app.openapi()
    enriched = enrich_openapi(schema, api_url=_API_URL)
    return JSONResponse(content=enriched)


@app.get("/.well-known/security.txt", response_class=PlainTextResponse, tags=["discovery"])
def security_txt() -> str:
    """Security contact disclosure per RFC 9116."""
    from swarm_at.openclaw import generate_security_txt
    return generate_security_txt(_SITE_URL)


@app.get("/.well-known/ai-plugin.json", tags=["discovery"])
def ai_plugin() -> JSONResponse:
    """OpenAI plugin manifest for ChatGPT and compatible agents."""
    from swarm_at.openclaw import generate_ai_plugin
    return JSONResponse(content=generate_ai_plugin(_API_URL))


@app.get("/discovery", tags=["discovery"])
def discovery_index() -> JSONResponse:
    """Discovery hub listing all machine-readable endpoints."""
    from swarm_at.openclaw import generate_discovery_index
    return JSONResponse(content=generate_discovery_index(_API_URL, _SITE_URL))


@app.get("/public/jsonld", tags=["discovery"])
def public_jsonld() -> JSONResponse:
    """Schema.org JSON-LD for WebAPI type."""
    from swarm_at.openclaw import generate_jsonld
    return JSONResponse(content=generate_jsonld(_API_URL, _SITE_URL))


@app.get("/.well-known/mcp.json", tags=["discovery"])
def mcp_json() -> JSONResponse:
    """MCP server discovery document."""
    from swarm_at.openclaw import generate_mcp_json
    return JSONResponse(content=generate_mcp_json(_API_URL))


@app.get("/sitemap.xml", response_class=PlainTextResponse, tags=["discovery"])
def api_sitemap() -> str:
    """API sitemap listing discovery and public endpoints."""
    from swarm_at.openclaw import generate_api_sitemap
    return generate_api_sitemap(_API_URL)
