"""Mutable API state — swappable in tests."""

import logging
import os
from typing import Any

from swarm_at.agents import AgentRegistry, PersistentAgentRegistry
from swarm_at.authorship import WritingSessionStore
from swarm_at.blueprints import BlueprintStore
from swarm_at.credits import CreditLedger, PersistentCreditLedger
from swarm_at.engine import SwarmAtEngine
from swarm_at.settler import Ledger
from swarm_at.webhooks import WebhookRegistry
from swarm_at.workflow import WorkflowEngine

_logger = logging.getLogger("swarm_at.api.state")


def _make_ledger() -> Ledger:
    """Create ledger based on env config. GitLedger when SWARM_GIT_LEDGER is set."""
    if os.environ.get("SWARM_GIT_LEDGER"):
        try:
            from swarm_at.gitplane import GitLedger

            gl = GitLedger(
                repo_path=os.environ.get("SWARM_LEDGER_PATH", "/data/ledger-repo"),
                remote_url=os.environ.get("SWARM_GIT_REMOTE_URL", ""),
            )
            _logger.info("GitLedger initialized at %s", gl.repo_path)
            return gl
        except Exception:
            _logger.exception("GitLedger init failed, falling back to plain Ledger")
    ledger_path = os.environ.get("SWARM_LEDGER_PATH", "ledger.jsonl")
    # If SWARM_LEDGER_PATH is a directory (GitLedger path), put file inside it
    if os.path.isdir(ledger_path):
        ledger_path = os.path.join(ledger_path, "ledger.jsonl")
    return Ledger(path=ledger_path)


ledger = _make_ledger()
engine = SwarmAtEngine(ledger=ledger)
shared_state: dict[str, Any] = {}

# Set of valid API keys. Empty set means auth is disabled (dev mode).
# In production, set SWARM_API_KEY env var.
_env_key = os.environ.get("SWARM_API_KEY", "").strip()
api_keys: set[str] = {_env_key} if _env_key else set()

def _make_registry() -> AgentRegistry:
    """Create agent registry. Persistent when SWARM_REGISTRY_PATH is set.

    Seeds canonical agents on first run (empty registry file).
    """
    registry_path = os.environ.get("SWARM_REGISTRY_PATH", "")
    if registry_path:
        registry: AgentRegistry = PersistentAgentRegistry(path=registry_path)
    elif os.environ.get("SWARM_LEDGER_PATH"):
        # Co-locate with ledger
        base = os.environ["SWARM_LEDGER_PATH"]
        if os.path.isdir(base):
            rpath = os.path.join(base, "registry.jsonl")
        else:
            rpath = os.path.join(os.path.dirname(base) or ".", "registry.jsonl")
        registry = PersistentAgentRegistry(path=rpath)
    else:
        return AgentRegistry()

    # Seed canonical agents on first boot (registry file was just created)
    if registry.count == 0:
        try:
            from swarm_at.seed import seed_registry
            seed_registry(registry)
            _logger.info("Seeded %d canonical agents", registry.count)
        except Exception:
            _logger.exception("Failed to seed canonical agents")

    return registry


agent_registry = _make_registry()


def _make_blueprint_store() -> BlueprintStore:
    """Create blueprint store and seed with canonical blueprints if empty."""
    store = BlueprintStore()
    try:
        from swarm_at.seed_blueprints import seed_blueprints
        seed_blueprints(store)
        _logger.info("Seeded %d canonical blueprints", store.blueprint_count)
    except Exception:
        _logger.exception("Failed to seed canonical blueprints")
    return store


blueprint_store = _make_blueprint_store()

# Credit ledger for agent operations
def _make_credit_ledger() -> CreditLedger:
    """Create credit ledger. Persistent when SWARM_LEDGER_PATH is set."""
    credit_path = os.environ.get("SWARM_CREDIT_PATH", "")
    if credit_path:
        return PersistentCreditLedger(path=credit_path)
    if os.environ.get("SWARM_LEDGER_PATH"):
        base = os.environ["SWARM_LEDGER_PATH"]
        if os.path.isdir(base):
            cpath = os.path.join(base, "credits.jsonl")
        else:
            cpath = os.path.join(os.path.dirname(base) or ".", "credits.jsonl")
        return PersistentCreditLedger(path=cpath)
    return CreditLedger()


credit_ledger = _make_credit_ledger()

# Webhook registry for event notifications
webhook_registry = WebhookRegistry()

# Workflow engine for blueprint execution
workflow_engine = WorkflowEngine(engine=engine)

# Authorship provenance sessions
def _make_session_store() -> WritingSessionStore:
    """Create session store. Persistent when SWARM_SESSION_PATH or SWARM_LEDGER_PATH is set."""
    from swarm_at.authorship import PersistentWritingSessionStore, WritingSessionStore

    session_path = os.environ.get("SWARM_SESSION_PATH", "")
    ledger_path_str = os.environ.get("SWARM_LEDGER_PATH", "ledger.jsonl")
    if session_path:
        return PersistentWritingSessionStore(path=session_path, ledger_path=ledger_path_str)
    if os.environ.get("SWARM_LEDGER_PATH"):
        base = os.environ["SWARM_LEDGER_PATH"]
        spath = os.path.join(
            base if os.path.isdir(base) else os.path.dirname(base) or ".",
            "sessions.jsonl",
        )
        return PersistentWritingSessionStore(path=spath, ledger_path=ledger_path_str)
    return WritingSessionStore()


writing_sessions = _make_session_store()

# JWT auth (optional — activated when SWARM_JWT_SECRET is set)
_jwt_secret = os.environ.get("SWARM_JWT_SECRET", "").strip()
jwt_auth = None
if _jwt_secret:
    from swarm_at.auth import JWTAuth
    jwt_auth = JWTAuth(secret=_jwt_secret)
