"""Workflow Chaining: Beads, Molecules, Formulas, and Convoys."""

from __future__ import annotations

import random
import time
import uuid
from collections.abc import Callable
from enum import Enum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field

from swarm_at.blueprints import Blueprint
from swarm_at.engine import SwarmAtEngine
from swarm_at.models import Header, Payload, Proposal, SettlementStatus


class BeadStatus(str, Enum):
    """Lifecycle of an atomic work unit."""

    PENDING = "pending"
    RUNNING = "running"
    SETTLED = "settled"
    FAILED = "failed"
    SKIPPED = "skipped"
    ROLLED_BACK = "rolled_back"


class Bead(BaseModel):
    """Atomic unit of work — single agent action with inputs/outputs.

    A Bead represents one step in a workflow. It has:
    - A unique ID
    - A name describing the action
    - Input data (from previous bead or initial context)
    - Output data (produced by execution)
    - Settlement hash (after ledger commit)
    """

    bead_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    agent_id: str = ""
    status: BeadStatus = BeadStatus.PENDING
    input_data: dict[str, Any] = Field(default_factory=dict)
    output_data: dict[str, Any] = Field(default_factory=dict)
    settlement_hash: str | None = None
    started_at: float | None = None
    completed_at: float | None = None
    depends_on: list[str] = Field(default_factory=list)  # bead_ids this depends on
    error: str | None = None

    def is_ready(self, completed_beads: set[str]) -> bool:
        """Check if all dependencies are satisfied."""
        return all(dep in completed_beads for dep in self.depends_on)


class MoleculeStatus(str, Enum):
    """Lifecycle of a workflow chain."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


class Molecule(BaseModel):
    """Chain of Beads forming a workflow — ordered steps, dependency tracking.

    A Molecule is a "Turing-complete TODO list" — it chains Beads together,
    tracks progress, and can roll back on failure.
    """

    molecule_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    beads: list[Bead] = Field(default_factory=list)
    status: MoleculeStatus = MoleculeStatus.PENDING
    created_at: float = Field(default_factory=time.time)
    completed_at: float | None = None
    atomic: bool = False
    molecule_parent_hash: str | None = None
    rollback_hashes: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    def add_bead(
        self,
        name: str,
        agent_id: str = "",
        depends_on: list[str] | None = None,
        input_data: dict[str, Any] | None = None,
    ) -> Bead:
        """Add a new bead to this molecule."""
        bead = Bead(
            name=name,
            agent_id=agent_id,
            depends_on=depends_on or [],
            input_data=input_data or {},
        )
        self.beads.append(bead)
        return bead

    def get_bead(self, bead_id: str) -> Bead | None:
        for b in self.beads:
            if b.bead_id == bead_id:
                return b
        return None

    def ready_beads(self) -> list[Bead]:
        """Return beads whose dependencies are all satisfied and that are still PENDING."""
        completed = {b.bead_id for b in self.beads if b.status == BeadStatus.SETTLED}
        return [b for b in self.beads if b.status == BeadStatus.PENDING and b.is_ready(completed)]

    @property
    def progress(self) -> float:
        """Fraction of beads that are settled (0.0 to 1.0)."""
        if not self.beads:
            return 0.0
        settled = sum(1 for b in self.beads if b.status == BeadStatus.SETTLED)
        return settled / len(self.beads)

    @property
    def is_complete(self) -> bool:
        return all(b.status in (BeadStatus.SETTLED, BeadStatus.SKIPPED) for b in self.beads) and len(self.beads) > 0

    @property
    def has_failures(self) -> bool:
        return any(b.status == BeadStatus.FAILED for b in self.beads)


class FormulaStep(BaseModel):
    """A step definition within a formula template."""

    name: str
    agent_role: str = ""
    depends_on: list[str] = Field(default_factory=list)  # step names (resolved at instantiation)
    description: str = ""


class Formula(BaseModel):
    """Template for generating Molecules — reusable workflow recipes.

    A Formula defines a pattern of steps. When instantiated, it produces a
    Molecule with Beads pre-configured.
    """

    formula_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: str = ""
    steps: list[FormulaStep] = Field(default_factory=list)

    def instantiate(self, context: dict[str, Any] | None = None) -> Molecule:
        """Create a Molecule from this formula template."""
        mol = Molecule(name=f"{self.name} (instance)")
        bead_name_to_id: dict[str, str] = {}

        for step in self.steps:
            depends_on_ids = [bead_name_to_id[dep] for dep in step.depends_on if dep in bead_name_to_id]
            bead = mol.add_bead(
                name=step.name,
                agent_id=step.agent_role,
                depends_on=depends_on_ids,
                input_data=context or {},
            )
            bead_name_to_id[step.name] = bead.bead_id

        return mol


class ConvoyStatus(str, Enum):
    ACTIVE = "active"
    COMPLETED = "completed"
    STALLED = "stalled"


class Convoy(BaseModel):
    """Feature-level tracking across multiple Molecules.

    A Convoy groups related Molecules that together deliver a feature.
    Tracks overall progress and can detect stalled workflows.
    """

    convoy_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    molecule_ids: list[str] = Field(default_factory=list)
    status: ConvoyStatus = ConvoyStatus.ACTIVE
    created_at: float = Field(default_factory=time.time)
    metadata: dict[str, Any] = Field(default_factory=dict)


class WorkflowEngine:
    """Orchestrates workflow execution: runs beads through the settlement engine.

    The WorkflowEngine takes Molecules and executes their Beads in dependency
    order, settling each one to the ledger.
    """

    def __init__(
        self,
        engine: SwarmAtEngine | None = None,
        audit_rate: float = 0.1,
        shadow_fn: Callable[..., dict[str, Any]] | None = None,
        registry: Any | None = None,
    ) -> None:
        self.engine = engine or SwarmAtEngine()
        self.audit_rate = audit_rate
        self.shadow_fn = shadow_fn
        self.registry = registry
        self._molecules: dict[str, Molecule] = {}
        self._convoys: dict[str, Convoy] = {}

    def register_molecule(self, molecule: Molecule) -> Molecule:
        """Register a molecule for execution tracking."""
        self._molecules[molecule.molecule_id] = molecule
        return molecule

    def rollback_molecule(self, molecule_id: str, reason: str) -> list[str]:
        """Roll back all settled beads in a molecule by writing compensation entries."""
        mol = self._molecules.get(molecule_id)
        if mol is None:
            raise WorkflowError(f"Molecule {molecule_id} not found.")

        compensation_hashes: list[str] = []
        for bead in mol.beads:
            if bead.status != BeadStatus.SETTLED:
                continue
            parent_hash = self.engine.ledger.get_latest_hash()
            proposal = Proposal(
                header=Header(
                    task_id=f"rollback-{bead.bead_id}",
                    parent_hash=parent_hash,
                ),
                payload=Payload(
                    data_update={
                        "type": "bead_rollback",
                        "bead_id": bead.bead_id,
                        "molecule_id": molecule_id,
                        "reason": reason,
                        "original_hash": bead.settlement_hash,
                    },
                    confidence_score=1.0,
                ),
            )
            result = self.engine.verify_and_settle(proposal)
            if result.status == SettlementStatus.SETTLED and result.hash:
                compensation_hashes.append(result.hash)
            bead.status = BeadStatus.ROLLED_BACK

        mol.status = MoleculeStatus.ROLLED_BACK
        mol.rollback_hashes = compensation_hashes
        return compensation_hashes

    def _check_molecule_drift(self, mol: Molecule) -> bool:
        """Check if external writes happened during atomic molecule execution.

        Returns True if drift detected (ledger hash != last settled bead hash).
        """
        settled_beads = [b for b in mol.beads if b.status == BeadStatus.SETTLED]
        if not settled_beads:
            return False
        last_settled = settled_beads[-1]
        return last_settled.settlement_hash != self.engine.ledger.get_latest_hash()

    def execute_bead(self, molecule_id: str, bead_id: str, output_data: dict[str, Any]) -> Bead:
        """Execute a bead: record output and settle to ledger.

        The caller provides the output_data (the actual work result).
        This method records it and settles the bead to the ledger.
        """
        mol = self._molecules.get(molecule_id)
        if mol is None:
            raise WorkflowError(f"Molecule {molecule_id} not found.")

        bead = mol.get_bead(bead_id)
        if bead is None:
            raise WorkflowError(f"Bead {bead_id} not found in molecule {molecule_id}.")

        if bead.status != BeadStatus.PENDING:
            raise WorkflowError(f"Bead {bead_id} is {bead.status.value}, expected pending.")

        # Check dependencies
        completed = {b.bead_id for b in mol.beads if b.status == BeadStatus.SETTLED}
        if not bead.is_ready(completed):
            raise WorkflowError(f"Bead {bead_id} has unmet dependencies.")

        bead.status = BeadStatus.RUNNING
        bead.started_at = time.time()
        bead.output_data = output_data

        # Atomic molecule: capture parent hash on first bead, check drift on subsequent
        if mol.atomic:
            if mol.molecule_parent_hash is None:
                mol.molecule_parent_hash = self.engine.ledger.get_latest_hash()
            elif self._check_molecule_drift(mol):
                self.rollback_molecule(molecule_id, "Drift detected during atomic execution")
                bead.status = BeadStatus.ROLLED_BACK
                bead.error = "Drift detected during atomic execution"
                bead.completed_at = time.time()
                return bead

        # Settle to ledger
        parent_hash = self.engine.ledger.get_latest_hash()
        proposal = Proposal(
            header=Header(
                task_id=bead.bead_id,
                parent_hash=parent_hash,
            ),
            payload=Payload(
                data_update={
                    "type": "bead_settlement",
                    "bead_id": bead.bead_id,
                    "bead_name": bead.name,
                    "molecule_id": molecule_id,
                    "output": output_data,
                },
                confidence_score=0.95,
            ),
        )

        # Shadow audit: randomly audit bead output
        if self.shadow_fn is not None and random.random() < self.audit_rate:
            shadow_output = self.shadow_fn(output_data)
            shadow_proposal = Proposal(
                header=Header(
                    task_id=f"shadow-{bead.bead_id}",
                    parent_hash=parent_hash,
                ),
                payload=Payload(
                    data_update=shadow_output,
                    confidence_score=0.95,
                ),
            )
            result = self.engine.verify_and_settle(proposal, shadow=shadow_proposal)
            if result.status == SettlementStatus.ESCROWED and self.registry and bead.agent_id:
                self.registry.record_divergence(bead.agent_id, penalty=0.1)
        else:
            result = self.engine.verify_and_settle(proposal)

        if result.status == SettlementStatus.SETTLED:
            bead.status = BeadStatus.SETTLED
            bead.settlement_hash = result.hash
            bead.completed_at = time.time()
        elif result.status == SettlementStatus.ESCROWED:
            # Shadow audit divergence — still counts as settled for workflow
            bead.status = BeadStatus.SETTLED
            bead.settlement_hash = result.hash
            bead.completed_at = time.time()
        else:
            bead.status = BeadStatus.FAILED
            bead.error = result.reason
            bead.completed_at = time.time()
            # Atomic molecule: rollback on bead failure
            if mol.atomic:
                self.rollback_molecule(molecule_id, f"Bead {bead.bead_id} failed: {result.reason}")
                bead.status = BeadStatus.ROLLED_BACK
                return bead

        # Update molecule status
        if mol.is_complete:
            mol.status = MoleculeStatus.COMPLETED
            mol.completed_at = time.time()
        elif mol.has_failures:
            mol.status = MoleculeStatus.FAILED
        elif any(b.status in (BeadStatus.RUNNING, BeadStatus.SETTLED) for b in mol.beads):
            mol.status = MoleculeStatus.RUNNING

        return bead

    def fail_bead(self, molecule_id: str, bead_id: str, error: str) -> Bead:
        """Mark a bead as failed without settling."""
        mol = self._molecules.get(molecule_id)
        if mol is None:
            raise WorkflowError(f"Molecule {molecule_id} not found.")
        bead = mol.get_bead(bead_id)
        if bead is None:
            raise WorkflowError(f"Bead {bead_id} not found.")
        bead.status = BeadStatus.FAILED
        bead.error = error
        bead.completed_at = time.time()
        mol.status = MoleculeStatus.FAILED
        return bead

    def get_molecule(self, molecule_id: str) -> Molecule | None:
        return self._molecules.get(molecule_id)

    def create_convoy(self, name: str, molecule_ids: list[str] | None = None) -> Convoy:
        """Create a convoy grouping related molecules."""
        convoy = Convoy(name=name, molecule_ids=molecule_ids or [])
        self._convoys[convoy.convoy_id] = convoy
        return convoy

    def add_to_convoy(self, convoy_id: str, molecule_id: str) -> Convoy:
        """Add a molecule to a convoy."""
        convoy = self._convoys.get(convoy_id)
        if convoy is None:
            raise WorkflowError(f"Convoy {convoy_id} not found.")
        if molecule_id not in convoy.molecule_ids:
            convoy.molecule_ids.append(molecule_id)
        return convoy

    def convoy_progress(self, convoy_id: str) -> float:
        """Overall progress across all molecules in a convoy."""
        convoy = self._convoys.get(convoy_id)
        if convoy is None:
            raise WorkflowError(f"Convoy {convoy_id} not found.")
        if not convoy.molecule_ids:
            return 0.0
        total = 0.0
        for mid in convoy.molecule_ids:
            mol = self._molecules.get(mid)
            if mol:
                total += mol.progress
        return total / len(convoy.molecule_ids)


class WorkflowError(Exception):
    pass


def fork_blueprint(blueprint: Blueprint, agent_id: str = "anonymous") -> Molecule:
    """Create a Molecule from a Blueprint template.

    Maps each BlueprintStep to a Bead. Preserves step dependencies.
    """
    molecule = Molecule(
        molecule_id=f"bp-{blueprint.blueprint_id}-{uuid4().hex[:8]}",
        name=blueprint.name,
    )

    # Map steps to beads
    for step in blueprint.steps:
        bead = Bead(
            bead_id=step.step_id,
            name=step.name,
            agent_id=agent_id,
            depends_on=step.depends_on,
        )
        molecule.beads.append(bead)

    # Set metadata
    molecule.metadata = {
        "source_blueprint": blueprint.blueprint_id,
        "agent_id": agent_id,
    }

    return molecule


def execute_blueprint_step(
    engine: WorkflowEngine,
    molecule_id: str,
    step_id: str,
    data: dict[str, Any],
    confidence: float = 0.95,
) -> str:
    """Execute a single blueprint step. Returns settlement hash."""
    bead = engine.execute_bead(molecule_id, step_id, output_data=data)
    if bead.settlement_hash is None:
        raise WorkflowError(f"Step {step_id} failed to settle: {bead.error}")
    return bead.settlement_hash
