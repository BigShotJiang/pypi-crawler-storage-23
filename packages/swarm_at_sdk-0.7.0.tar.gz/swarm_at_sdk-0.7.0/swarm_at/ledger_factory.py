"""Ledger factory: select backend based on configuration."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal

LedgerMode = Literal["file", "git"]


def get_ledger_mode() -> str:
    """Read ledger mode from environment variable.

    Returns:
        Ledger mode string, defaults to "file".

    Raises:
        ValueError: If mode is not valid.
    """
    mode = os.environ.get("SWARM_LEDGER_MODE", "file").strip().lower()
    if mode not in ("file", "git"):
        raise ValueError(
            f"Invalid SWARM_LEDGER_MODE: {mode!r}. Must be 'file' or 'git'."
        )
    return mode


def create_ledger(
    path: str | Path = "ledger.jsonl",
    mode: str | None = None,
    **kwargs: Any,
) -> Any:
    """Create a ledger instance based on mode.

    Args:
        path: Path to ledger file (file mode) or repo directory (git mode).
        mode: Ledger mode ("file" or "git"). If None, reads from environment.
        **kwargs: Additional arguments passed to GitLedger constructor.

    Returns:
        Ledger instance (Ledger for file mode, GitLedger for git mode).

    Raises:
        ValueError: If mode is invalid.
    """
    if mode is None:
        mode = get_ledger_mode()

    mode = mode.strip().lower()
    if mode not in ("file", "git"):
        raise ValueError(f"Invalid ledger mode: {mode!r}. Must be 'file' or 'git'.")

    if mode == "file":
        from swarm_at.settler import Ledger

        return Ledger(path=path)
    else:
        # Lazy import to avoid git dependency at import time
        from swarm_at.gitplane import GitLedger

        return GitLedger(repo_path=path, **kwargs)


def ledger_status(ledger: Any) -> dict[str, Any]:
    """Get status information from a ledger instance.

    Args:
        ledger: Ledger or GitLedger instance.

    Returns:
        Dictionary with ledger status including:
        - mode: "file" or "git"
        - latest_hash: current hash
        - entry_count: number of entries
        - chain_intact: whether hash chain is valid
        - branch: current branch (git mode only)
    """
    # Determine mode by checking for GitLedger-specific attributes
    is_git = hasattr(ledger, "branch")
    mode = "git" if is_git else "file"

    status: dict[str, Any] = {
        "mode": mode,
        "latest_hash": ledger.get_latest_hash(),
        "entry_count": len(ledger.read_all()),
        "chain_intact": ledger.verify_chain(),
    }

    if is_git:
        status["branch"] = ledger.branch

    return status
