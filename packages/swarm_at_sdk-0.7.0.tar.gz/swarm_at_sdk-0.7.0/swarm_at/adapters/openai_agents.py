"""OpenAI Agents SDK adapter: settle agent runs and tool calls."""

from __future__ import annotations

from typing import Any

from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


class SwarmAgentHook:
    """Settles agent lifecycle events from the OpenAI Agents SDK.

    Usage::

        hook = SwarmAgentHook()
        # After Runner.run() completes:
        hook.settle_run(result)
        # Or per tool call:
        hook.settle_tool_call("search", {"query": "test"}, {"results": [...]})

    Duck-types RunResult via getattr — extracts final_output, last_agent.name,
    and tool calls from new_items.
    """

    def __init__(
        self,
        agent: str = "openai-agent",
        context: SettlementContext | None = None,
        confidence: float = 0.95,
        tier: SettlementTier | None = None,
    ) -> None:
        self.agent = agent
        self.confidence = confidence
        self.context = context or SettlementContext(tier=tier)

    def settle_run(self, result: Any) -> Any:
        """Settle a completed Runner.run() result."""
        final_output = getattr(result, "final_output", str(result))
        last_agent = getattr(result, "last_agent", None)
        agent_name = getattr(last_agent, "name", self.agent) if last_agent else self.agent

        # Extract tool call info from new_items if available
        new_items = getattr(result, "new_items", [])
        tool_calls = []
        for item in new_items:
            call_id = getattr(item, "call_id", None)
            if call_id:
                tool_calls.append(str(call_id))

        return self.context.settle(
            agent=str(agent_name),
            task=f"openai-agents:run:{agent_name}",
            data={
                "final_output": str(final_output),
                "agent": str(agent_name),
                "tool_calls": tool_calls,
            },
            confidence=self.confidence,
        )

    def settle_tool_call(
        self, tool_name: str, tool_input: Any, tool_output: Any,
    ) -> Any:
        """Settle an individual tool call."""
        return self.context.settle(
            agent=self.agent,
            task=f"openai-agents:tool:{tool_name}",
            data={
                "tool": tool_name,
                "input": str(tool_input),
                "output": str(tool_output),
            },
            confidence=self.confidence,
        )
