"""Common Protocol definition for swarm.at framework adapters."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class SwarmAdapter(Protocol):
    """Common interface for framework adapters.

    Every adapter should support ``settle()`` — a single entry point that
    records an agent action to the swarm.at ledger and returns a receipt.

    Existing adapters satisfy this Protocol structurally (no inheritance
    required) as long as they expose a ``settle()`` method with this
    signature.

    Example::

        from swarm_at.adapters.protocol import SwarmAdapter
        from swarm_at.adapters import get_adapter

        cls = get_adapter("haystack")
        adapter = cls()
        assert isinstance(adapter, SwarmAdapter)
    """

    def settle(self, action: str, agent_id: str, **kwargs: Any) -> Any:
        """Settle an agent action through the swarm.at protocol.

        Args:
            action: A short label for the action being settled (e.g.
                ``"search"``, ``"generate"``, ``"trade"``).
            agent_id: Identifier of the acting agent.
            **kwargs: Adapter-specific extras (data, confidence, tier, ...).

        Returns:
            A settlement receipt. Concrete type depends on the adapter's
            underlying ``SettlementContext``.
        """
        ...
