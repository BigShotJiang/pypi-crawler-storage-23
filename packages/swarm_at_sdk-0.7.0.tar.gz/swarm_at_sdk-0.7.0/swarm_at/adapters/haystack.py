"""Haystack adapter: pipeline component that settles outputs."""

from __future__ import annotations

from typing import Any

from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


class SwarmSettlementComponent:
    """Haystack pipeline component that settles pipeline outputs.

    Usage::

        pipeline.add_component("settlement", SwarmSettlementComponent())
        pipeline.connect("generator.replies", "settlement.data")

    Mimics the Haystack Component interface via duck typing.
    No hard dependency on haystack-ai.
    """

    def __init__(
        self,
        agent: str = "haystack-pipeline",
        context: SettlementContext | None = None,
        confidence: float = 0.95,
        tier: SettlementTier | None = None,
    ) -> None:
        self.agent = agent
        self.confidence = confidence
        self.context = context or SettlementContext(tier=tier)

    def run(self, data: Any, agent: str = "", task: str = "") -> dict[str, Any]:
        """Run the settlement component. Returns {"receipt": {...}}."""
        agent_name = agent or self.agent
        task_name = task or f"haystack:{agent_name}"

        if isinstance(data, dict):
            payload = data
        else:
            payload = {"output": str(data)}

        result = self.context.settle(
            agent=agent_name,
            task=task_name,
            data=payload,
            confidence=self.confidence,
        )

        return {
            "receipt": {
                "status": result.status.value,
                "hash": result.hash,
            },
        }
