"""Polymarket adapter: settle prediction market operations to the ledger."""

from __future__ import annotations

from typing import Any

from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


class SwarmPolymarketAdapter:
    """Settle prediction market reads, trades, price checks, and portfolios.

    Usage::

        adapter = SwarmPolymarketAdapter()
        adapter.settle_market_read([{"id": "0x...", "question": "Will X?"}])
        adapter.settle_trade("buy", "0xtoken", 0.65, 100, {"filled": True})
        adapter.settle_price_check("0xtoken", {"bid": 0.64, "ask": 0.66})
        adapter.settle_portfolio("0xaddr", [{"token": "0x...", "size": 50}])

    Duck-types Polymarket objects via str() — no hard dependency on py-clob-client.
    """

    def __init__(
        self,
        agent: str = "polymarket",
        context: SettlementContext | None = None,
        confidence: float = 0.95,
        tier: SettlementTier | None = None,
    ) -> None:
        self.agent = agent
        self.confidence = confidence
        self.context = context or SettlementContext(tier=tier)

    def settle_market_read(self, markets: Any) -> Any:
        """Settle a market data read."""
        return self.context.settle(
            agent=self.agent,
            task="polymarket:market-read",
            data={"markets": str(markets)},
            confidence=self.confidence,
        )

    def settle_trade(
        self,
        side: str,
        token: str,
        price: float,
        size: float,
        result: Any,
    ) -> Any:
        """Settle a trade execution. Confidence forced >= 0.99."""
        return self.context.settle(
            agent=self.agent,
            task="polymarket:trade",
            data={
                "side": side,
                "token": token,
                "price": str(price),
                "size": str(size),
                "result": str(result),
            },
            confidence=max(self.confidence, 0.99),
        )

    def settle_price_check(self, token: str, price_data: Any) -> Any:
        """Settle a price check."""
        return self.context.settle(
            agent=self.agent,
            task="polymarket:price-check",
            data={"token": token, "price_data": str(price_data)},
            confidence=self.confidence,
        )

    def settle_portfolio(self, address: str, positions: Any) -> Any:
        """Settle a portfolio snapshot."""
        return self.context.settle(
            agent=self.agent,
            task="polymarket:portfolio",
            data={"address": address, "positions": str(positions)},
            confidence=self.confidence,
        )
