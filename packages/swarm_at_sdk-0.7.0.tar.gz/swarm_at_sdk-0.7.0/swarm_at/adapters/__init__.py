"""Framework adapters for swarm.at settlement protocol."""

from __future__ import annotations

import importlib

ADAPTER_REGISTRY: dict[str, str] = {
    "autogen": "swarm_at.adapters.autogen",
    "crewai": "swarm_at.adapters.crewai",
    "haystack": "swarm_at.adapters.haystack",
    "langgraph": "swarm_at.adapters.langgraph",
    "openai_agents": "swarm_at.adapters.openai_agents",
    "openai_assistants": "swarm_at.adapters.openai_assistants",
    "polymarket": "swarm_at.adapters.polymarket",
    "strands": "swarm_at.adapters.strands",
}


def get_adapter(name: str) -> type:
    """Load an adapter class by name.

    Finds the first public class whose name starts with ``"Swarm"`` in the
    adapter module. Each adapter module exposes exactly one such class.

    Args:
        name: Registry key (e.g. ``"langgraph"``, ``"crewai"``).

    Returns:
        The adapter class (not an instance).

    Raises:
        KeyError: If *name* is not in ``ADAPTER_REGISTRY``.
        ImportError: If the adapter module's optional framework dependency is
            not installed, or if no ``Swarm*`` class is found in the module.
    """
    if name not in ADAPTER_REGISTRY:
        raise KeyError(
            f"Unknown adapter: {name!r}. Available: {sorted(ADAPTER_REGISTRY)}"
        )
    module_path = ADAPTER_REGISTRY[name]
    mod = importlib.import_module(module_path)
    for attr_name in dir(mod):
        if attr_name.startswith("Swarm") and isinstance(getattr(mod, attr_name), type):
            return getattr(mod, attr_name)  # type: ignore[return-value]
    raise ImportError(f"No Swarm* class found in {module_path}")


def list_adapters() -> list[str]:
    """Return the names of all registered adapters, sorted alphabetically."""
    return sorted(ADAPTER_REGISTRY)


def check_adapter(name: str) -> bool:
    """Return True if *name* is registered and its dependencies are importable.

    Never raises — returns False on any error so callers can use this as a
    lightweight capability probe without exception handling.
    """
    try:
        get_adapter(name)
        return True
    except (ImportError, KeyError):
        return False
