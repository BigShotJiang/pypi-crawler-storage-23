"""Canonical agent seeding: bootstrap a registry with known agents."""

from __future__ import annotations

from pydantic import BaseModel

from swarm_at.agents import AgentIdentity, AgentRegistry, AgentRole, TrustLevel


class CanonicalAgent(BaseModel):
    """Definition of a canonical agent for seeding."""

    agent_id: str
    role: AgentRole
    trust_level: TrustLevel
    settlement_count: int
    capabilities: list[str] = []


CANONICAL_AGENTS: list[CanonicalAgent] = [
    CanonicalAgent(
        agent_id="orchestrator-prime",
        role=AgentRole.ORCHESTRATOR,
        trust_level=TrustLevel.SENIOR,
        settlement_count=150,
        capabilities=["workflow-management", "task-routing", "escalation"],
    ),
    CanonicalAgent(
        agent_id="validator-alpha",
        role=AgentRole.VALIDATOR,
        trust_level=TrustLevel.TRUSTED,
        settlement_count=50,
        capabilities=["cross-validation", "consensus-verification"],
    ),
    CanonicalAgent(
        agent_id="auditor-shadow",
        role=AgentRole.AUDITOR,
        trust_level=TrustLevel.TRUSTED,
        settlement_count=30,
        capabilities=["shadow-audit", "divergence-detection"],
    ),
    CanonicalAgent(
        agent_id="worker-general",
        role=AgentRole.WORKER,
        trust_level=TrustLevel.TRUSTED,
        settlement_count=25,
        capabilities=["task-execution", "data-processing"],
    ),
    CanonicalAgent(
        agent_id="specialist-data",
        role=AgentRole.SPECIALIST,
        trust_level=TrustLevel.TRUSTED,
        settlement_count=23,
        capabilities=["data-analysis", "feature-engineering"],
    ),
    # Community blueprint authors
    CanonicalAgent(
        agent_id="telco-ops.agent",
        role=AgentRole.WORKER,
        trust_level=TrustLevel.PROVISIONAL,
        settlement_count=15,
        capabilities=["telecom-negotiation", "contract-analysis"],
    ),
    CanonicalAgent(
        agent_id="finreg.agent",
        role=AgentRole.WORKER,
        trust_level=TrustLevel.PROVISIONAL,
        settlement_count=15,
        capabilities=["compliance-checking", "sanctions-screening"],
    ),
    CanonicalAgent(
        agent_id="logistics.agent",
        role=AgentRole.WORKER,
        trust_level=TrustLevel.PROVISIONAL,
        settlement_count=15,
        capabilities=["supply-chain-audit", "risk-assessment"],
    ),
    CanonicalAgent(
        agent_id="mlops.agent",
        role=AgentRole.WORKER,
        trust_level=TrustLevel.PROVISIONAL,
        settlement_count=15,
        capabilities=["model-validation", "fairness-evaluation"],
    ),
    CanonicalAgent(
        agent_id="safety.agent",
        role=AgentRole.WORKER,
        trust_level=TrustLevel.PROVISIONAL,
        settlement_count=15,
        capabilities=["content-moderation", "policy-enforcement"],
    ),
    CanonicalAgent(
        agent_id="proptech.agent",
        role=AgentRole.WORKER,
        trust_level=TrustLevel.PROVISIONAL,
        settlement_count=15,
        capabilities=["due-diligence", "property-analysis"],
    ),
    CanonicalAgent(
        agent_id="devops.agent",
        role=AgentRole.WORKER,
        trust_level=TrustLevel.PROVISIONAL,
        settlement_count=15,
        capabilities=["api-testing", "integration-validation"],
    ),
    CanonicalAgent(
        agent_id="analytics.agent",
        role=AgentRole.WORKER,
        trust_level=TrustLevel.PROVISIONAL,
        settlement_count=15,
        capabilities=["churn-analysis", "customer-segmentation"],
    ),
]


def seed_registry(
    registry: AgentRegistry,
    agents: list[CanonicalAgent] | None = None,
) -> list[AgentIdentity]:
    """Bootstrap a registry with canonical agents and settlement histories.

    Registers each agent, then records successful settlements to build
    the history needed for their target trust level.
    """
    agent_defs = agents or CANONICAL_AGENTS
    seeded: list[AgentIdentity] = []

    for defn in agent_defs:
        registry.register(
            agent_id=defn.agent_id,
            role=defn.role,
            capabilities=defn.capabilities,
        )
        # Record settlements to build history
        for _ in range(defn.settlement_count):
            registry.record_settlement(defn.agent_id, success=True, complexity=0.5)

        seeded.append(registry.get(defn.agent_id))

    return seeded
