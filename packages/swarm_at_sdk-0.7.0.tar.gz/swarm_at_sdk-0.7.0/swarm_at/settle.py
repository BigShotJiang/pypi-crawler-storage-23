"""Dead-simple public API: one-liner settlement for any agent framework."""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from typing import Any

from swarm_at.models import (
    AgentMetadata,
    AuthorshipClaim,
    Header,
    Payload,
    Proposal,
    SettlementResult,
    SettlementStatus,
)
from swarm_at.settler import content_fingerprint
from swarm_at.tiers import SettlementTier, get_policy, get_tier


class SettlementContext:
    """Stateful wrapper that tracks parent_hash between calls.

    Local mode (default): creates in-process SwarmAtEngine + Ledger.
    Remote mode (when SWARM_API_URL set): uses SwarmClient HTTP calls.
    """

    def __init__(
        self,
        tier: SettlementTier | None = None,
        ledger_path: str = "ledger.jsonl",
        api_url: str | None = None,
        api_key: str = "",
    ) -> None:
        self.tier = tier or get_tier()
        self.policy = get_policy(self.tier)

        # Resolve mode: remote if api_url provided or env var set
        resolved_url = api_url or os.environ.get("SWARM_API_URL")

        if resolved_url:
            from swarm_at.sdk.client import SwarmClient

            self._client: Any = SwarmClient(
                api_url=resolved_url,
                api_key=api_key or os.environ.get("SWARM_API_KEY", ""),
            )
            self._mode = "remote"
            self._engine = None
            self._parent_hash = "0" * 64
        else:
            from swarm_at.engine import SwarmAtEngine
            from swarm_at.settler import Ledger

            ledger = Ledger(path=ledger_path)
            self._engine = SwarmAtEngine(ledger=ledger)
            self._client = None
            self._mode = "local"
            self._parent_hash = ledger.get_latest_hash()

    def settle(
        self,
        agent: str,
        task: str,
        data: dict[str, Any] | None = None,
        confidence: float = 0.95,
        task_id: str | None = None,
    ) -> SettlementResult:
        """Settle an agent action. Returns SettlementResult regardless of tier."""
        resolved_task_id = task_id or str(uuid.uuid4())
        data_update = data or {"task": task, "agent": agent}

        # SANDBOX: synthetic result, no ledger interaction
        if self.policy.log_only:
            synthetic_hash = hashlib.sha256(
                json.dumps(
                    {"task_id": resolved_task_id, "data": data_update},
                    sort_keys=True,
                ).encode()
            ).hexdigest()
            self._parent_hash = synthetic_hash
            return SettlementResult(
                status=SettlementStatus.SETTLED,
                hash=synthetic_hash,
            )

        proposal = Proposal(
            header=Header(
                task_id=resolved_task_id,
                parent_hash=self._parent_hash,
                agent_metadata=AgentMetadata(model=agent),
            ),
            payload=Payload(
                data_update=data_update,
                confidence_score=confidence,
            ),
        )

        # STAGING: sync parent_hash to skip chain enforcement
        if not self.policy.enforce_chain and self._mode == "local":
            assert self._engine is not None
            self._parent_hash = self._engine.ledger.get_latest_hash()
            proposal.header.parent_hash = self._parent_hash

        if self._mode == "remote":
            result: SettlementResult = self._client.settle(proposal)
        else:
            assert self._engine is not None
            result = self._engine.verify_and_settle(proposal)

        # Track parent_hash for next call
        if result.hash:
            self._parent_hash = result.hash

        return result

    def claim_authorship(
        self,
        agent: str,
        content: str,
        content_type: str = "",
        label: str = "",
        confidence: float = 0.95,
    ) -> SettlementResult:
        """Claim authorship of content. Fingerprints content and settles."""
        c_hash = content_fingerprint(content)
        claim = AuthorshipClaim(
            agent_id=agent,
            content_hash=c_hash,
            content_type=content_type,
            label=label,
        )
        return self.settle(
            agent=agent,
            task="authorship-claim",
            data=claim.model_dump(),
            confidence=confidence,
        )


# ---------------------------------------------------------------------------
# Module-level convenience API
# ---------------------------------------------------------------------------

_context: SettlementContext | None = None


def _get_context() -> SettlementContext:
    """Lazy singleton context."""
    global _context
    if _context is None:
        _context = SettlementContext()
    return _context


def settle(
    agent: str = "default",
    task: str = "",
    data: dict[str, Any] | None = None,
    confidence: float = 0.95,
    task_id: str | None = None,
) -> SettlementResult:
    """One-liner settlement: ``from swarm_at import settle; settle(agent="my-agent", task="research")``."""
    return _get_context().settle(
        agent=agent, task=task, data=data, confidence=confidence, task_id=task_id,
    )


def claim_authorship(
    agent: str = "default",
    content: str = "",
    content_type: str = "",
    label: str = "",
    confidence: float = 0.95,
) -> SettlementResult:
    """One-liner authorship claim: ``from swarm_at.settle import claim_authorship``."""
    return _get_context().claim_authorship(
        agent=agent, content=content, content_type=content_type,
        label=label, confidence=confidence,
    )


def reset_context() -> None:
    """Reset the module singleton. Called by test fixtures to prevent leakage."""
    global _context
    _context = None
