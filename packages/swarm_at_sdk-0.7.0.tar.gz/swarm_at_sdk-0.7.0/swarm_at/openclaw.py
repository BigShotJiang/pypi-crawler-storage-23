"""OpenClaw: agent & LLM discovery layer for swarm.at.

Pure functions that generate discovery documents — llms.txt, A2A agent cards,
robots.txt, Schema.org JSON-LD, and enriched OpenAPI specs. No side effects.
"""

from __future__ import annotations

from typing import Any


def generate_llms_txt(api_url: str, site_url: str) -> str:
    """Generate llms.txt v1.1.0 — LLM-readable protocol summary."""
    return f"""# swarm.at

> Need to prove an agent action was approved before executing it? swarm.at settles it.

Use swarm.at when your agent is about to do something irreversible — delete files,
send money, deploy code, modify production data. Call `guard_action()` before the
action. swarm.at validates it against institutional rules and writes a receipt to a
hash-chained ledger. If someone asks "who approved this?", you have the receipt.

## Quick Start (REST API)

1. Register your agent (gets 100 free credits):

    POST {api_url}/v1/agents/register
    {{"agent_id": "my-agent", "role": "worker"}}

    Response: {{"agent_id": "my-agent", "trust_level": "untrusted", "credits": 100.0}}

2. Settle an action before executing it:

    POST {api_url}/v1/settle
    {{"primary": {{"header": {{"parent_hash": "<latest-hash>"}}, "payload": {{"data_update": {{"action": "delete user records"}}, "confidence_score": 0.95}}}}}}

    Response: {{"status": "SETTLED", "hash": "a1b2c3...", "reason": "Verified"}}

3. Verify the settlement:

    GET {api_url}/public/receipts/a1b2c3...

    Response: {{"status": "SETTLED", "hash": "a1b2c3...", "task_id": "...", "timestamp": 1770480398.05}}

Get the latest parent hash with `GET {api_url}/v1/ledger/latest`.

## Quick Start (MCP)

Install: `mcp add swarm-at -- python -m swarm_at.mcp`

Guard an action:

    guard_action(agent_id="my-agent", action="delete user records", data='{{"count": 150}}')

Verify it later:

    verify_receipt(hash="<settlement-hash>")

## Quick Start (Python SDK)

    pip install swarm-at-sdk
    from swarm_at.sdk.client import SwarmClient
    client = SwarmClient("{api_url}", api_key="sk-...")
    receipt = client.guard_action(agent_id="my-agent", action="delete-records",
                                   data={{"table": "users", "count": 150}})

SDK methods: settle(), guard_action(), latest_hash(), verify_ledger(), task_status(),
list_ledger(), get_receipt(), register_agent(), get_agent(), list_agents(),
verify_trust(), get_trust_summary(), whoami(), get_credits(), topup_credits(),
list_blueprints(), get_blueprint(), fork_blueprint(), publish_blueprint(),
claim_authorship(), verify_authorship(), list_authored(),
list_authorship_sessions(), get_authorship_report(),
register_webhook(), list_webhooks(), unregister_webhook(),
execute_step(), create_token(), context_slice()

## MCP Tools

18 tools. Core: settle_action, check_settlement, ledger_status, guard_action,
list_blueprints, get_blueprint, fork_blueprint, verify_receipt, check_trust,
get_credits, topup_credits. Authorship: claim_authorship, verify_authorship,
start_writing_session, record_writing_event, approve_writing,
get_provenance_report, list_writing_sessions.

record_writing_event `event_type` values: direction, prompt, generation, revision, rejection.
record_writing_event `phase` values: concept, structure, character, scene, dialogue, revision.

## Endpoints

- POST {api_url}/v1/settle — Submit a proposal for settlement
- GET {api_url}/v1/context?keywords=... — Get context slice for a task
- GET {api_url}/v1/status/{{task_id}} — Check settlement status
- GET {api_url}/v1/ledger/latest — Latest settled hash
- GET {api_url}/v1/ledger/verify — Verify full chain integrity
- POST {api_url}/v1/agents/register — Register a new agent
- GET {api_url}/v1/whoami?agent_id=... — Agent self-check
- GET {api_url}/public/ledger — Paginated public ledger
- GET {api_url}/public/agents — Agent leaderboard
- GET {api_url}/public/blueprints — Blueprint catalog
- POST {api_url}/v1/blueprints/{{blueprint_id}}/fork — Fork blueprint into executable workflow
- POST {api_url}/v1/blueprints/publish — Publish a new blueprint (auth required)
- POST {api_url}/v1/molecules/{{molecule_id}}/execute — Execute a workflow step
- POST {api_url}/v1/auth/token — Get JWT token
- GET {api_url}/v1/ledger/mode — Ledger backend status
- GET {api_url}/public/receipts/{{hash}} — Look up settlement receipt by hash (no auth)
- GET {api_url}/public/verify-trust?agent_id=X&min_trust=trusted — Check agent trust (no auth)
- GET {api_url}/public/trust-summary — Aggregate trust-level counts (no auth)
- GET {api_url}/public/verify-authorship?content_hash=X&agent_id=Y — Verify authorship claim (no auth)
- GET {api_url}/public/authorship/{{content_hash}} — All claims for content (no auth)
- GET {api_url}/public/agents/{{agent_id}}/authored — Agent's authorship claims (no auth)
- GET {api_url}/public/schema — Machine-readable protocol schema (no auth)
- GET {api_url}/badge/{{agent_id}} — SVG trust badge (no auth)

## Credits

Each settlement costs 1 credit. New agents get 100 free credits on registration
(first 100 settlements cost nothing). When credits run out, settlement requests
return HTTP 402. Use `get_credits` to check balance, `topup_credits` to add more.

Blueprint forks debit credits equal to the blueprint's `credit_cost` (2.0-8.0).
Blueprint authors earn 10% of the credit cost on every fork of their blueprint.

## Authentication

All `/v1/*` endpoints require a Bearer token: `Authorization: Bearer <api-key>`.
All `/public/*` endpoints are open (no auth required).
Get an API key by registering at {site_url}, or generate a JWT via `POST /v1/auth/token`.

## Error Codes

- **400** — Invalid request (bad JSON, invalid enum value, missing required field)
- **401** — Missing or malformed Bearer token. Add `Authorization: Bearer <key>` header.
- **402** — Insufficient credits. Call `GET /v1/credits/{{agent_id}}` to check balance, `POST /v1/credits/{{agent_id}}/topup` to add more.
- **403** — Invalid API key or expired JWT. Re-authenticate.
- **404** — Resource not found (agent, blueprint, receipt, session).
- **409** — Chain conflict (stale parent_hash). Fetch `GET /v1/ledger/latest` for the current hash and retry.
- **422** — Validation error. Check the `detail` field for specifics.

## Proof of Authorship

Agents claim authorship by settling a content fingerprint (SHA-256 hash) bound to
their agent ID. The claim goes into the hash chain — tamper-evident, verifiable by
anyone. No cryptographic signatures needed: the settlement act IS the proof.

Claim: `claim_authorship(agent_id="my-agent", content="...", content_type="text")`
Verify: `GET /public/verify-authorship?content_hash=<hash>&agent_id=<id>`

First claim wins. Trust level gives weight to the claim. Content is fingerprinted
(SHA-256), never stored.

## Framework Adapters

Eight framework adapters settle agent outputs without hard dependencies:

- **LangGraph** — SwarmNodeWrapper wraps node functions
- **CrewAI** — SwarmTaskCallback for task completions
- **AutoGen** — SwarmReplyCallback observes agent replies
- **OpenAI Assistants** — SwarmRunHandler settles runs and steps
- **OpenAI Agents SDK** — SwarmAgentHook settles Runner results and tool calls
- **Strands (AWS)** — SwarmStrandsCallback for tool and agent events
- **Haystack** — SwarmSettlementComponent as a pipeline component
- **Polymarket** — SwarmPolymarketAdapter settles market reads, trades, and portfolios

## CLI

    pip install swarm-at-sdk[cli]

The `swarm` command works in local mode (default, no server needed) or remote mode
(talks to {api_url} via SwarmClient).

    swarm settle <action> --agent <name>   # Settle an action
    swarm status                            # Ledger status
    swarm ledger list                       # Browse entries
    swarm ledger verify <hash>              # Verify a settlement
    swarm agents list                       # List agents
    swarm agents register <id>              # Register an agent
    swarm agents info <id>                  # Agent details
    swarm agents verify-trust <id>          # Check trust threshold
    swarm agents trust-summary              # Trust level counts
    swarm blueprints list                   # Browse blueprints
    swarm blueprints info <id>              # Blueprint details
    swarm blueprints fork <id>              # Fork into workflow
    swarm blueprints publish --name --agent # Publish blueprint (remote)
    swarm authorship claim <content> --agent # Claim authorship of content
    swarm authorship verify <hash>          # Verify authorship claim
    swarm authorship list <agent_id>        # List agent's authored content
    swarm authorship sessions               # List provenance sessions (remote)
    swarm authorship report <session_id>    # Get provenance report (remote)
    swarm credits balance <agent_id>        # Check credit balance (remote)
    swarm credits topup <agent_id> <amount> # Add credits (remote)
    swarm webhooks register <event> <url>   # Subscribe to events (remote)
    swarm webhooks list                     # List webhooks (remote)
    swarm webhooks unregister <event> <url> # Remove webhook (remote)
    swarm auth token <agent_id>             # Get JWT token (remote)
    swarm workflow execute <mol> --step --agent  # Execute workflow step (remote)
    swarm init                              # Scaffold a project
    swarm login                             # Save credentials
    swarm serve                             # Start API server
    swarm mcp                               # Start MCP server
    swarm whoami <agent_id>                 # Agent self-check (remote)

Global flags: --local, --api-url, --api-key, --json, --ledger-path.
Config: ~/.swarm/config.toml (written by `swarm login`).

## Blueprint Catalog

48 pre-validated blueprints across 9 categories: Procurement & Supply Chain,
Software Development, Finance & Compliance, Content & Knowledge,
Customer Operations, Specialty (healthcare, legal, IoT, real estate,
insurance), AI & Data (RAG, debate, delegation, ETL), Security & Operations,
HR & Talent, and Marketing & Creative.

Browse: {api_url}/public/blueprints

## Settlement Tiers

- **sandbox** — Log-only, no ledger writes. Safe to experiment.
- **staging** — Writes ledger, no chain enforcement.
- **production** — Full verification + chain integrity (default).

## Trust Model

Agents progress through four trust levels based on Bayesian credible intervals:

- **untrusted** — New agent. Cannot stake.
- **provisional** — 5+ settlements, lower bound >= 0.60. Can execute.
- **trusted** — 20+ settlements, lower bound >= 0.82. Full participation.
- **senior** — 100+ settlements, lower bound >= 0.92. Can orchestrate.

## Authorship Provenance

Need to prove a human was in creative control when AI tools were involved?
WritingSession records every decision to the settlement ledger and produces a
verifiable provenance report with compliance assessments.

Use it when a writer needs evidence for copyright registration (USCO),
guild credit (WGA/SAG-AFTRA), or EU AI Act marking exemptions.

    from swarm_at import WritingSession
    from swarm_at.authorship import CreativePhase

    session = WritingSession(writer="jane-doe", tool="claude-sonnet-4-5")
    session.direct(action="premise", chose="noir detective", phase=CreativePhase.CONCEPT)
    session.prompt(text="Write the opening scene", phase=CreativePhase.SCENE)
    session.generate(output_hash="<sha256-of-output>", model="claude-sonnet-4-5")
    session.revise(description="Rewrote opening, cut 40%", kept_ratio=0.35)
    session.approve(content_hash="<sha256-of-final>", version="v1")
    report = session.report()

report.work_agency returns a 0.0-1.0 score. >= 0.90 triggers the professional
safe harbor (full copyright, guild credit, marking exempt). The report also flags
behavioral risks: anchoring (high kept_ratio), satisficing (consecutive AI outputs
without human review), and missing foundation (AI generation before human direction).

Six methods: direct(), prompt(), generate(), revise(), reject(), approve().
Six agency layers: L0 (Oracle) through L5 (Pure Tool).
Six creative phases: concept, structure, character, scene, dialogue, revision.

## Links

- Website: {site_url}
- API: {api_url}
- Discovery: {api_url}/discovery
- Agent Card: {api_url}/.well-known/agent-card.json
- OpenAPI: {api_url}/.well-known/openapi.json
- AI Plugin: {api_url}/.well-known/ai-plugin.json
- Schema: {api_url}/public/schema
- Security: {api_url}/.well-known/security.txt
- Trust Badge: {api_url}/badge/{{agent_id}}
- Robots.txt: {api_url}/robots.txt
- Sitemap: {api_url}/sitemap.xml
- MCP Registry: https://registry.modelcontextprotocol.io
- PyPI: https://pypi.org/project/swarm-at-sdk/
- Pricing: {site_url}/pricing.html
- Stack: {site_url}/stack.html
"""


def generate_agent_card(api_url: str) -> dict[str, Any]:
    """Generate A2A agent card — Google-backed agent-to-agent discovery."""
    return {
        "name": "swarm.at Settlement Protocol",
        "description": (
            "Git-native information settlement protocol for autonomous agent workflows. "
            "Validates actions against institutional rules, maintains a hash-chained ledger, "
            "and manages trust-tiered agent identities."
        ),
        "url": api_url,
        "version": "0.7.0",
        "capabilities": {
            "streaming": False,
            "pushNotifications": False,
        },
        "authentication": {
            "schemes": ["bearer"],
            "credentials": "API key via Authorization: Bearer <key>",
        },
        "defaultInputModes": ["application/json"],
        "defaultOutputModes": ["application/json"],
        "skills": [
            {
                "id": "guard_action",
                "name": "Guard Action",
                "description": (
                    "Validate a destructive action before execution. "
                    "Returns a settlement receipt or rejects with reason."
                ),
                "input": {"agent_id": "string", "action": "string", "data": "JSON string"},
                "output": {"proceed": "boolean", "reason": "string", "settlement_token": "string|null"},
                "examples": [{
                    "input": {"agent_id": "deploy-bot", "action": "deploy v2.1 to production", "data": "{\"service\": \"api\", \"version\": \"2.1\"}"},
                    "output": {"proceed": True, "reason": "Action settled and verified.", "settlement_token": "a1b2c3d4..."},
                }],
            },
            {
                "id": "settle_action",
                "name": "Settle Action",
                "description": (
                    "Submit any action for settlement against institutional rules. "
                    "Returns a settlement token."
                ),
                "input": {"action": "string", "context": "JSON string", "confidence": "float 0.0-1.0"},
                "output": {"proceed": "boolean", "reason": "string", "settlement_token": "string|null"},
                "examples": [{
                    "input": {"action": "research completed", "context": "{\"topic\": \"market analysis\"}", "confidence": 0.95},
                    "output": {"proceed": True, "reason": "Action settled and verified.", "settlement_token": "e5f6a7b8..."},
                }],
            },
            {
                "id": "check_settlement",
                "name": "Check Settlement",
                "description": "Look up whether a previous action was approved, by task ID or hash.",
                "input": {"task_id": "string (optional)", "hash": "string (optional)"},
                "output": {"found": "boolean", "task_id": "string", "hash": "string", "timestamp": "float"},
            },
            {
                "id": "ledger_status",
                "name": "Ledger Status",
                "description": "Check ledger health: latest hash, entry count, chain integrity.",
                "input": {},
                "output": {"latest_hash": "string", "entry_count": "integer", "chain_intact": "boolean"},
            },
            {
                "id": "list_blueprints",
                "name": "List Blueprints",
                "description": "Browse 48 pre-validated blueprints across 9 categories. Filter by tag.",
                "input": {"tag": "string (optional)"},
                "output": {"blueprints": "array", "total": "integer"},
            },
            {
                "id": "get_blueprint",
                "name": "Get Blueprint",
                "description": "Inspect a blueprint's steps and roles before forking.",
                "input": {"blueprint_id": "string"},
                "output": {"blueprint_id": "string", "name": "string", "steps": "array", "fork_count": "integer"},
            },
            {
                "id": "fork_blueprint",
                "name": "Fork Blueprint",
                "description": "Create an executable workflow from a blueprint template. Costs credits.",
                "input": {"blueprint_id": "string", "agent_id": "string"},
                "output": {"molecule_id": "string", "name": "string", "bead_count": "integer"},
            },
            {
                "id": "verify_receipt",
                "name": "Verify Receipt",
                "description": "Prove a past action was approved. Returns receipt with timestamp and parent hash.",
                "input": {"hash": "string (64-char hex)"},
                "output": {"found": "boolean", "task_id": "string", "hash": "string", "timestamp": "float", "parent_hash": "string"},
                "examples": [{
                    "input": {"hash": "a1b2c3d4e5f6..." + "0" * 50},
                    "output": {"found": True, "task_id": "deploy-1", "hash": "a1b2c3d4e5f6..." + "0" * 50, "timestamp": 1770480398.05, "parent_hash": "0" * 64},
                }],
            },
            {
                "id": "check_trust",
                "name": "Check Trust",
                "description": "Verify an agent meets a trust threshold before delegating work.",
                "input": {"agent_id": "string", "min_trust": "untrusted|provisional|trusted|senior"},
                "output": {"agent_id": "string", "meets_requirement": "boolean", "trust_level": "string"},
            },
            {
                "id": "get_credits",
                "name": "Get Credits",
                "description": "Check how many settlement credits an agent has. Each settlement costs 1 credit.",
                "input": {"agent_id": "string"},
                "output": {"agent_id": "string", "balance": "float"},
                "examples": [{
                    "input": {"agent_id": "deploy-bot"},
                    "output": {"agent_id": "deploy-bot", "balance": 97.0},
                }],
            },
            {
                "id": "topup_credits",
                "name": "Top Up Credits",
                "description": "Add settlement credits to an agent's balance.",
                "input": {"agent_id": "string", "amount": "float"},
                "output": {"agent_id": "string", "balance": "float", "topup_amount": "float"},
            },
            {
                "id": "claim_authorship",
                "name": "Claim Authorship",
                "description": "Create a verifiable authorship record binding agent identity to content.",
                "input": {"agent_id": "string", "content": "string", "content_type": "string (optional)", "label": "string (optional)"},
                "output": {"claimed": "boolean", "content_hash": "string", "settlement_hash": "string"},
                "examples": [{
                    "input": {"agent_id": "writer-bot", "content": "The quick brown fox...", "content_type": "text", "label": "blog post draft"},
                    "output": {"claimed": True, "content_hash": "b5c6d7e8...", "settlement_hash": "f9a0b1c2..."},
                }],
            },
            {
                "id": "verify_authorship",
                "name": "Verify Authorship",
                "description": "Check if an agent authored specific content by its SHA-256 fingerprint.",
                "input": {"content_hash": "string (64-char hex)", "agent_id": "string (optional)"},
                "output": {"verified": "boolean", "agent_id": "string", "trust_level": "string", "timestamp": "float"},
            },
            {
                "id": "start_writing_session",
                "name": "Start Writing Session",
                "description": "Begin tracking authorship provenance for human-AI creative work.",
                "input": {"writer": "string", "tool": "string"},
                "output": {"session_id": "string", "writer": "string", "tool": "string"},
            },
            {
                "id": "record_writing_event",
                "name": "Record Writing Event",
                "description": "Record a creative event (direction, prompt, generation, revision, rejection) in a session.",
                "input": {"session_id": "string", "event_type": "direction|prompt|generation|revision|rejection", "phase": "concept|structure|character|scene|dialogue|revision"},
                "output": {"status": "string", "hash": "string"},
            },
            {
                "id": "approve_writing",
                "name": "Approve Writing",
                "description": "Record final approval of creative content and close the provenance chain.",
                "input": {"session_id": "string", "content_hash": "string (SHA-256)", "version": "string (optional)"},
                "output": {"status": "string", "hash": "string"},
            },
            {
                "id": "get_provenance_report",
                "name": "Get Provenance Report",
                "description": "Generate a verifiable provenance report with work agency score and compliance assessments.",
                "input": {"session_id": "string"},
                "output": {"work_agency": "float 0.0-1.0", "compliance": "object", "events": "array", "chain_verified": "boolean"},
                "outputModes": ["application/json", "text/plain"],
            },
            {
                "id": "list_writing_sessions",
                "name": "List Writing Sessions",
                "description": "List active authorship provenance sessions with work agency scores.",
                "input": {"writer": "string (optional)"},
                "output": {"sessions": "array", "total": "integer"},
            },
        ],
        "provider": {
            "organization": "swarm.at",
            "url": "https://swarm.at",
        },
        "documentationUrl": "https://swarm.at/SPEC.html",
        "termsOfServiceUrl": "https://swarm.at/terms",
        "privacyPolicyUrl": "https://swarm.at/privacy",
        "serviceUrl": api_url,
        "links": {
            "llmsTxt": f"{api_url}/llms.txt",
            "openApi": f"{api_url}/.well-known/openapi.json",
            "schema": f"{api_url}/public/schema",
        },
    }


def generate_robots_txt(api_url: str) -> str:
    """Generate robots.txt — crawler guidance with llms.txt reference."""
    return f"""User-agent: *
Allow: /

# LLM-readable protocol summary
# See https://llmstxt.org for the llms.txt convention
LLMs-Txt: {api_url}/llms.txt
Sitemap: {api_url}/sitemap.xml
"""


def generate_jsonld(api_url: str, site_url: str) -> dict[str, Any]:
    """Generate Schema.org JSON-LD for WebAPI type."""
    return {
        "@context": "https://schema.org",
        "@type": "WebAPI",
        "name": "swarm.at",
        "description": (
            "Git-native Information Settlement Protocol for autonomous agent workflows."
        ),
        "url": api_url,
        "documentation": f"{site_url}/SPEC.html",
        "provider": {
            "@type": "Organization",
            "name": "swarm.at",
            "url": site_url,
        },
        "termsOfService": f"{site_url}/terms",
        "category": "AI Infrastructure",
    }


def generate_trust_badge(agent_id: str, trust_level: str) -> str:
    """Generate an SVG trust badge for an agent (shields.io flat style)."""
    colors = {
        "untrusted": "#e05d44",
        "provisional": "#dfb317",
        "trusted": "#4c1",
        "senior": "#007ec6",
    }
    color = colors.get(trust_level, "#9f9f9f")
    label = "trust"
    label_width = 35
    value_width = max(len(trust_level) * 7 + 10, 50)
    total_width = label_width + value_width

    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{total_width}" height="20">'
        f'<linearGradient id="b" x2="0" y2="100%">'
        f'<stop offset="0" stop-color="#bbb" stop-opacity=".1"/>'
        f'<stop offset="1" stop-opacity=".1"/>'
        f'</linearGradient>'
        f'<mask id="a"><rect width="{total_width}" height="20" rx="3" fill="#fff"/></mask>'
        f'<g mask="url(#a)">'
        f'<rect width="{label_width}" height="20" fill="#555"/>'
        f'<rect x="{label_width}" width="{value_width}" height="20" fill="{color}"/>'
        f'<rect width="{total_width}" height="20" fill="url(#b)"/>'
        f'</g>'
        f'<g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="11">'
        f'<text x="{label_width / 2}" y="15" fill="#010101" fill-opacity=".3">{label}</text>'
        f'<text x="{label_width / 2}" y="14">{label}</text>'
        f'<text x="{label_width + value_width / 2}" y="15" fill="#010101" fill-opacity=".3">'
        f'{trust_level}</text>'
        f'<text x="{label_width + value_width / 2}" y="14">{trust_level}</text>'
        f'</g>'
        f'</svg>'
    )


def generate_security_txt(site_url: str) -> str:
    """Generate /.well-known/security.txt per RFC 9116."""
    return f"""Contact: mailto:security@swarm.at
Expires: 2027-01-01T00:00:00.000Z
Preferred-Languages: en
Canonical: {site_url}/.well-known/security.txt
Policy: {site_url}/security
"""


def generate_ai_plugin(api_url: str) -> dict[str, Any]:
    """Generate /.well-known/ai-plugin.json (OpenAI plugin manifest)."""
    return {
        "schema_version": "v1",
        "name_for_human": "swarm.at",
        "name_for_model": "swarm_at",
        "description_for_human": (
            "Settlement protocol for AI agent actions. "
            "Validates actions, maintains an auditable ledger, and manages agent trust."
        ),
        "description_for_model": (
            "Use swarm.at to settle agent actions before executing them. "
            "Call guard_action before destructive operations. "
            "Each settlement costs 1 credit (100 free on registration). "
            "Verify past actions with verify_receipt."
        ),
        "auth": {"type": "service_http", "authorization_type": "bearer"},
        "api": {
            "type": "openapi",
            "url": f"{api_url}/.well-known/openapi.json",
        },
        "logo_url": f"{api_url}/badge/swarm-at",
        "contact_email": "hello@swarm.at",
        "legal_info_url": "https://swarm.at/terms",
    }


def generate_discovery_index(api_url: str, site_url: str) -> dict[str, Any]:
    """Generate discovery index listing all discovery endpoints."""
    return {
        "protocol": "swarm.at",
        "version": "0.7.0",
        "discovery": {
            "llms_txt": f"{api_url}/llms.txt",
            "agent_card": f"{api_url}/.well-known/agent-card.json",
            "openapi": f"{api_url}/.well-known/openapi.json",
            "ai_plugin": f"{api_url}/.well-known/ai-plugin.json",
            "mcp_json": f"{api_url}/.well-known/mcp.json",
            "jsonld": f"{api_url}/public/jsonld",
            "security_txt": f"{api_url}/.well-known/security.txt",
            "robots_txt": f"{api_url}/robots.txt",
            "schema": f"{api_url}/public/schema",
            "health": f"{api_url}/health",
        },
        "public_endpoints": {
            "ledger": f"{api_url}/public/ledger",
            "agents": f"{api_url}/public/agents",
            "blueprints": f"{api_url}/public/blueprints",
            "receipts": f"{api_url}/public/receipts/{{hash}}",
            "trust": f"{api_url}/public/verify-trust",
            "badge": f"{api_url}/badge/{{agent_id}}",
        },
        "documentation": f"{site_url}/SPEC.html",
    }


def generate_api_sitemap(api_url: str) -> str:
    """Generate sitemap.xml for API discovery endpoints."""
    urls = [
        f"{api_url}/llms.txt",
        f"{api_url}/.well-known/agent-card.json",
        f"{api_url}/.well-known/openapi.json",
        f"{api_url}/.well-known/ai-plugin.json",
        f"{api_url}/public/ledger",
        f"{api_url}/public/agents",
        f"{api_url}/public/blueprints",
        f"{api_url}/public/schema",
        f"{api_url}/health",
    ]
    entries = "\n".join(f"  <url><loc>{u}</loc></url>" for u in urls)
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
{entries}
</urlset>
"""


def generate_mcp_json(api_url: str) -> dict[str, Any]:
    """Generate /.well-known/mcp.json — MCP server discovery."""
    return {
        "name": "swarm-at",
        "version": "0.7.0",
        "description": "Settlement protocol for AI agent actions",
        "install": "mcp add swarm-at -- python -m swarm_at.mcp",
        "tool_count": 18,
        "registry": "https://registry.modelcontextprotocol.io",
        "repository": "https://pypi.org/project/swarm-at-sdk/",
        "openapi": f"{api_url}/.well-known/openapi.json",
        "agent_card": f"{api_url}/.well-known/agent-card.json",
    }


def enrich_openapi(schema: dict[str, Any], api_url: str = "") -> dict[str, Any]:
    """Add servers, tags, examples, and externalDocs to FastAPI's auto-generated spec."""
    enriched = dict(schema)

    if api_url:
        enriched["servers"] = [
            {"url": api_url, "description": "Production"},
            {"url": "http://localhost:8000", "description": "Local development"},
        ]

    enriched["tags"] = [
        {"name": "settlement", "description": "Core settlement operations"},
        {"name": "ledger", "description": "Ledger queries and verification"},
        {"name": "agents", "description": "Agent identity and trust management"},
        {"name": "blueprints", "description": "Blueprint catalog and forking"},
        {"name": "credits", "description": "Agent credit balance and top-up"},
        {"name": "workflows", "description": "Workflow execution and step management"},
        {"name": "auth", "description": "JWT token generation and API key auth"},
        {"name": "webhooks", "description": "Event notification subscriptions"},
        {"name": "discovery", "description": "Discovery endpoints (llms.txt, A2A, OpenAPI)"},
        {"name": "authorship", "description": "Authorship provenance sessions and reports"},
    ]

    enriched["externalDocs"] = {
        "description": "swarm.at Technical Specification",
        "url": "https://swarm.at/SPEC.html",
    }

    enriched.setdefault("info", {})
    enriched["info"]["x-llms-txt"] = "/llms.txt"
    enriched["info"]["x-agent-card"] = "/.well-known/agent-card.json"

    # Add examples to key endpoints
    paths = enriched.get("paths", {})

    settle_path = paths.get("/v1/settle", {})
    post_op = settle_path.get("post", {})
    if post_op and "x-example" not in post_op:
        post_op["x-example"] = {
            "primary": {
                "header": {
                    "task_id": "research-1",
                    "parent_hash": "0" * 64,
                },
                "payload": {
                    "data_update": {"findings": "Agent completed research"},
                    "confidence_score": 0.95,
                },
            }
        }

    register_path = paths.get("/v1/agents/register", {})
    register_op = register_path.get("post", {})
    if register_op and "x-example" not in register_op:
        register_op["x-example"] = {
            "request": {"agent_id": "my-agent", "role": "worker", "capabilities": ["code-review"]},
            "response": {
                "agent_id": "my-agent",
                "role": "worker",
                "trust_level": "untrusted",
                "credits": 100.0,
            },
        }

    receipt_path = paths.get("/public/receipts/{hash}", {})
    receipt_op = receipt_path.get("get", {})
    if receipt_op and "x-example" not in receipt_op:
        receipt_op["x-example"] = {
            "response": {
                "status": "SETTLED",
                "hash": "a1b2c3..." + "0" * 56,
                "task_id": "research-1",
                "timestamp": 1770480398.05,
                "parent_hash": "0" * 64,
            },
        }

    credits_path = paths.get("/v1/credits/{agent_id}", {})
    credits_op = credits_path.get("get", {})
    if credits_op and "x-example" not in credits_op:
        credits_op["x-example"] = {
            "response": {"agent_id": "my-agent", "balance": 97.0},
        }

    trust_path = paths.get("/public/verify-trust", {})
    trust_op = trust_path.get("get", {})
    if trust_op and "x-example" not in trust_op:
        trust_op["x-example"] = {
            "response": {
                "agent_id": "my-agent",
                "meets_requirement": True,
                "trust_level": "trusted",
                "reputation_score": 0.95,
            },
        }

    return enriched
