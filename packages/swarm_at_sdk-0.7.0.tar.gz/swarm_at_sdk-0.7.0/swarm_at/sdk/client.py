"""Public Python SDK for swarm.at."""

from __future__ import annotations

from typing import Any, Callable

import httpx

from swarm_at.models import Header, Payload, Proposal, SettlementResult


class GuardError(Exception):
    """Raised when guard_action() settlement is rejected."""

    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


class SwarmClient:
    """Drop-in client for the swarm.at settlement protocol.

    Usage:
        client = SwarmClient(api_url="https://api.swarm.at", api_key="sk-...")
        result = client.settle(proposal)
    """

    def __init__(self, api_url: str, api_key: str = "", timeout: float = 30.0):
        self.api_url = api_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self.api_url,
            headers={"Authorization": f"Bearer {api_key}"} if api_key else {},
            timeout=timeout,
        )

    def settle(self, proposal: Proposal, shadow: Proposal | None = None) -> SettlementResult:
        """Submit a proposal for settlement."""
        body: dict[str, Any] = {"primary": proposal.model_dump()}
        if shadow is not None:
            body["shadow"] = shadow.model_dump()
        resp = self._http.post("/v1/settle", json=body)
        resp.raise_for_status()
        return SettlementResult.model_validate(resp.json())

    def settle_batch(self, proposals: list[dict[str, Any]]) -> dict[str, Any]:
        """Settle multiple proposals in one request.

        Each element in proposals should be a dict with a "primary" key
        (and optional "shadow" key) matching the SettleRequest schema.
        """
        resp = self._http.post("/v1/settle/batch", json={"proposals": proposals})
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def context_slice(self, state: dict[str, Any], keywords: list[str]) -> dict[str, Any]:
        """Get a pruned context slice. Filters locally if state provided."""
        from swarm_at.context import get_context_slice
        return get_context_slice(state, keywords)

    def latest_hash(self) -> str:
        """Get the latest settled hash."""
        resp = self._http.get("/v1/ledger/latest")
        resp.raise_for_status()
        data: dict[str, Any] = resp.json()
        return str(data["latest_hash"])

    def verify_ledger(self) -> dict[str, Any]:
        """Verify full ledger integrity."""
        resp = self._http.get("/v1/ledger/verify")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def task_status(self, task_id: str) -> dict[str, Any]:
        """Check settlement status of a specific task."""
        resp = self._http.get(f"/v1/status/{task_id}")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def list_blueprints(
        self, tag: str | None = None, page: int = 1, page_size: int = 50,
    ) -> dict[str, Any]:
        """List available blueprints with optional tag filter."""
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if tag is not None:
            params["tag"] = tag
        resp = self._http.get("/public/blueprints", params=params)
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def get_blueprint(self, blueprint_id: str) -> dict[str, Any]:
        """Get full blueprint details including steps."""
        resp = self._http.get(f"/public/blueprints/{blueprint_id}")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def whoami(self, agent_id: str) -> dict[str, Any]:
        """Agent self-check: trust status, permissions, promotion path."""
        resp = self._http.get("/v1/whoami", params={"agent_id": agent_id})
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def register_agent(
        self, agent_id: str, role: str = "worker", capabilities: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register a new agent identity."""
        body: dict[str, Any] = {"agent_id": agent_id, "role": role}
        if capabilities is not None:
            body["capabilities"] = capabilities
        resp = self._http.post("/v1/agents/register", json=body)
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def get_credits(self, agent_id: str) -> dict[str, Any]:
        """Get agent credit balance."""
        resp = self._http.get(f"/v1/credits/{agent_id}")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def topup_credits(self, agent_id: str, amount: float) -> dict[str, Any]:
        """Add credits to agent balance."""
        resp = self._http.post(f"/v1/credits/{agent_id}/topup", json={"amount": amount})
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def fork_blueprint(self, blueprint_id: str, agent_id: str = "anonymous") -> dict[str, Any]:
        """Fork a blueprint into an executable workflow molecule."""
        resp = self._http.post(
            f"/v1/blueprints/{blueprint_id}/fork", params={"agent_id": agent_id},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def create_token(self, agent_id: str, role: str = "worker") -> dict[str, Any]:
        """Request a JWT token for an agent."""
        resp = self._http.post("/v1/auth/token", json={"agent_id": agent_id, "role": role})
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def guard_action(
        self,
        agent_id: str,
        action: str,
        data: dict[str, Any] | None = None,
        confidence: float = 0.95,
    ) -> dict[str, Any]:
        """Settle before acting. Builds a proposal, settles it, returns receipt.

        Raises GuardError if settlement is rejected.
        """
        latest = self.latest_hash()
        proposal = Proposal(
            header=Header(parent_hash=latest),
            payload=Payload(
                data_update={"action": action, "data": data or {}},
                confidence_score=confidence,
            ),
            proof=f"guard_action: {action}",
        )
        result = self.settle(proposal)
        if result.status.value != "SETTLED":
            raise GuardError(result.reason or "Settlement rejected")
        return {
            "status": result.status.value,
            "hash": result.hash,
            "action": action,
            "agent_id": agent_id,
        }

    def claim_authorship(
        self,
        agent_id: str,
        content: str,
        content_type: str = "",
        label: str = "",
        confidence: float = 0.95,
    ) -> dict[str, Any]:
        """Claim authorship of content. Fingerprints, settles, returns receipt."""
        from swarm_at.settler import content_fingerprint

        c_hash = content_fingerprint(content)
        latest = self.latest_hash()
        proposal = Proposal(
            header=Header(parent_hash=latest),
            payload=Payload(
                data_update={
                    "type": "authorship-claim",
                    "agent_id": agent_id,
                    "content_hash": c_hash,
                    "content_type": content_type,
                    "label": label,
                    "metadata": {},
                },
                confidence_score=confidence,
            ),
            proof=f"authorship-claim by {agent_id}",
        )
        result = self.settle(proposal)
        if result.status.value != "SETTLED":
            raise GuardError(result.reason or "Authorship claim rejected")
        return {
            "status": result.status.value,
            "hash": result.hash,
            "content_hash": c_hash,
            "agent_id": agent_id,
        }

    def verify_authorship(
        self,
        content_hash: str,
        agent_id: str = "",
    ) -> dict[str, Any]:
        """Verify an authorship claim by content hash. Public, no auth needed."""
        params: dict[str, str] = {"content_hash": content_hash}
        if agent_id:
            params["agent_id"] = agent_id
        resp = self._http.get("/public/verify-authorship", params=params)
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # ------------------------------------------------------------------
    # Ledger
    # ------------------------------------------------------------------

    def list_ledger(
        self, limit: int = 50, offset: int = 0, task_id: str | None = None,
    ) -> dict[str, Any]:
        """List ledger entries with pagination."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if task_id:
            params["task_id"] = task_id
        resp = self._http.get("/public/ledger", params=params)
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def get_receipt(self, hash_value: str) -> dict[str, Any]:
        """Look up a settlement receipt by hash."""
        resp = self._http.get(f"/public/receipts/{hash_value}")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # ------------------------------------------------------------------
    # Agents
    # ------------------------------------------------------------------

    def list_agents(
        self, role: str | None = None, min_trust: str | None = None,
    ) -> dict[str, Any]:
        """List agents with optional role/trust filtering."""
        params: dict[str, str] = {}
        if role:
            params["role"] = role
        if min_trust:
            params["min_trust"] = min_trust
        resp = self._http.get("/public/agents", params=params)
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def get_agent(self, agent_id: str) -> dict[str, Any]:
        """Get public agent profile."""
        resp = self._http.get(f"/public/agents/{agent_id}")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def verify_trust(self, agent_id: str, min_trust: str = "trusted") -> dict[str, Any]:
        """Check if an agent meets a trust threshold."""
        resp = self._http.get("/public/verify-trust", params={
            "agent_id": agent_id, "min_trust": min_trust,
        })
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def get_trust_summary(self) -> dict[str, Any]:
        """Get aggregate trust-level counts."""
        resp = self._http.get("/public/trust-summary")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # ------------------------------------------------------------------
    # Blueprints (publish)
    # ------------------------------------------------------------------

    def publish_blueprint(
        self,
        name: str,
        description: str = "",
        tags: list[str] | None = None,
        steps: list[dict[str, Any]] | None = None,
        credit_cost: float = 1.0,
        agent_id: str = "",
    ) -> dict[str, Any]:
        """Publish a new blueprint (auth required)."""
        resp = self._http.post("/v1/blueprints/publish", json={
            "name": name,
            "description": description,
            "tags": tags or [],
            "steps": steps or [],
            "credit_cost": credit_cost,
            "agent_id": agent_id,
        })
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # ------------------------------------------------------------------
    # Webhooks
    # ------------------------------------------------------------------

    def register_webhook(self, event: str, url: str) -> dict[str, Any]:
        """Register a webhook URL for an event type."""
        resp = self._http.post("/v1/webhooks", json={"event": event, "url": url})
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def list_webhooks(self, event: str | None = None) -> dict[str, Any]:
        """List registered webhooks, optionally filtered by event."""
        params: dict[str, str] = {}
        if event:
            params["event"] = event
        resp = self._http.get("/v1/webhooks", params=params)
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def unregister_webhook(self, event: str, url: str) -> dict[str, Any]:
        """Remove a webhook registration."""
        resp = self._http.request("DELETE", "/v1/webhooks", json={"event": event, "url": url})
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # ------------------------------------------------------------------
    # Workflow execution
    # ------------------------------------------------------------------

    def execute_step(
        self,
        molecule_id: str,
        step_id: str,
        agent_id: str = "",
        data: dict[str, Any] | None = None,
        confidence: float = 0.95,
    ) -> dict[str, Any]:
        """Execute a single step in a forked workflow."""
        resp = self._http.post(f"/v1/molecules/{molecule_id}/execute", json={
            "agent_id": agent_id,
            "step_id": step_id,
            "data": data or {},
            "confidence": confidence,
        })
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def list_molecules(
        self,
        agent_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List registered workflow molecules, optionally filtered by agent_id."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if agent_id is not None:
            params["agent_id"] = agent_id
        resp = self._http.get("/v1/molecules", params=params)
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def get_molecule(self, molecule_id: str) -> dict[str, Any]:
        """Get molecule state including bead list and execution status."""
        resp = self._http.get(f"/v1/molecules/{molecule_id}")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # ------------------------------------------------------------------
    # Authorship (list/sessions/reports)
    # ------------------------------------------------------------------

    def list_authored(
        self, agent_id: str, page: int = 1, page_size: int = 50,
    ) -> dict[str, Any]:
        """List content authored by an agent."""
        resp = self._http.get(
            f"/public/agents/{agent_id}/authored",
            params={"page": page, "page_size": page_size},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def list_authorship_sessions(
        self, writer: str | None = None, page: int = 1, page_size: int = 50,
    ) -> dict[str, Any]:
        """List authorship provenance sessions."""
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if writer:
            params["writer"] = writer
        resp = self._http.get("/v1/authorship/sessions", params=params)
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def get_authorship_report(self, session_id: str, text: bool = False) -> str | dict[str, Any]:
        """Get provenance report. Returns plain text if text=True, else JSON dict."""
        suffix = "/text" if text else ""
        resp = self._http.get(f"/v1/authorship/sessions/{session_id}/report{suffix}")
        resp.raise_for_status()
        if text:
            return resp.text
        result: dict[str, Any] = resp.json()
        return result

    def start_session(self, writer: str, tool: str = "unknown") -> dict[str, Any]:
        """Start a new authorship provenance session."""
        resp = self._http.post(
            "/v1/authorship/sessions",
            json={"writer": writer, "tool": tool},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def record_event(
        self,
        session_id: str,
        event_type: str,
        phase: str = "revision",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Record a creative event in an authorship session.

        event_type is one of: "direction", "prompt", "generation", "revision", "rejection".
        Extra keyword args (action, chose, text, output_hash, model, description,
        kept_ratio, reason) are forwarded to the API.
        """
        body: dict[str, Any] = {"event_type": event_type, "phase": phase, **kwargs}
        resp = self._http.post(
            f"/v1/authorship/sessions/{session_id}/events",
            json=body,
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def approve_writing(
        self, session_id: str, content_hash: str, version: str = "",
    ) -> dict[str, Any]:
        """Record final approval of content. Returns settlement status and hash."""
        resp = self._http.post(
            f"/v1/authorship/sessions/{session_id}/approve",
            json={"content_hash": content_hash, "version": version},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    def delete_session(self, session_id: str) -> dict[str, Any]:
        """Delete an authorship session. Returns confirmation dict."""
        resp = self._http.request("DELETE", f"/v1/authorship/sessions/{session_id}")
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def shadow_audit(
        self, shadow_fn: Callable[..., dict[str, Any]], max_drift: float = 0.15,
    ) -> Callable[[Callable[..., dict[str, Any]]], Callable[..., dict[str, Any]]]:
        """Decorator for cross-model verification.

        Usage:
            @client.shadow_audit(shadow_fn=cheap_model_call)
            def research_task(context):
                return expensive_model_call(context)
        """
        from swarm_at.auditor import shadow_audit as _shadow_audit
        return _shadow_audit(shadow_fn=shadow_fn, max_drift=max_drift)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> SwarmClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
