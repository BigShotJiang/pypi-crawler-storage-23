"""WAV file parsing module."""

from .parser import WavFile as WavFile
from .parser import parse_wav as parse_wav
