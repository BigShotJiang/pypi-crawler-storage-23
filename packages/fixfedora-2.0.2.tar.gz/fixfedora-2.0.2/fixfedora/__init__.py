"""fixfedora – AI-powered Fedora diagnostics and repair."""
__version__ = "2.0.2"
