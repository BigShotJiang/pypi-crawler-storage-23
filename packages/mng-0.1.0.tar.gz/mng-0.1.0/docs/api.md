All `mngr` CLI commands are accessible via a python API as well

See [the code]() for more details for now.

FIXME: generate some docs here
