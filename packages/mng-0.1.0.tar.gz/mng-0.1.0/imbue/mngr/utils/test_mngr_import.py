from imbue import mngr


def test_import():
    assert mngr
