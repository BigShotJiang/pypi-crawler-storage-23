from typing import Final

# Prefix for Modal test apps - all test Modal apps should use this prefix
# to enable easy identification and cleanup
MODAL_TEST_APP_PREFIX: Final[str] = "mngr-test-"
