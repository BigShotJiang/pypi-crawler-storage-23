import pluggy

hookimpl = pluggy.HookimplMarker("mngr")
