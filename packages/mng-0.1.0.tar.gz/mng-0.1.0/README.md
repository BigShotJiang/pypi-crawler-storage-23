# mngr: build your team of AI engineering agents

**installation:**
```bash
curl -fsSL https://raw.githubusercontent.com/imbue-ai/mngr/main/scripts/install.sh | bash
```

**mngr is *very* simple to use:**

```bash
mngr                  # launch claude locally (defaults: command=create, agent=claude, provider=local, project=current dir)
mngr --in modal       # launch claude on Modal
mngr my-task          # launch claude with a name
mngr my-task codex    # launch codex instead of claude
mngr -- --model opus  # pass any arguments through to the underlying agent

# send an initial message so you don't have to wait around:
mngr --no-connect --message "Speed up one of my tests and make a PR on github"

# or, be super explicit about all of the arguments:
mngr create --name my-task --agent-type claude --in modal

# tons more arguments for anything you could want! Learn more via --help
mngr create --help

# or see the other commands--list, destroy, message, connect, push, pull, clone, and more!
mngr --help
```

**mngr is fast:**
```bash
> time mngr local-hello  --message "Just say hello" --no-connect --in local
# (time results)

> time mngr remote-hello --message "Just say hello" --no-connect --in modal
# (time results)

> time mngr list
# (time results)
```

**mngr itself is free, *and* the cheapest way to run remote agents (they shut down when idle):**

```bash
mngr create --in modal --no-connect --message "just say 'hello'" --idle-timeout 60 -- --model sonnet
# costs $0.001 for inference
# costs $0.0001 for compute because it shuts down 60 seconds after the agent completes
```

**mngr takes security and privacy seriously:**

```bash
# by default, cannot be accessed by anyone except your modal account (uses a local unique SSH key)
mngr create example-task --in modal

# you (or your agent) can do whatever bad ideas you want in that container without fear
mngr exec example-task "rm -rf /"

# you can block all outgoing internet access
mngr create --in modal -b offline

# or restrict outgoing traffic to certain IPs
mngr create --in modal -b cidr-allowlist=203.0.113.0/24
```

**mngr is powerful and composable:**

```bash
# start multiple agents on the same host to save money and share data
mngr create agent-1 --in modal --host-name shared-host
mngr create agent-2 --host shared-host

# run commands directly on an agent's host
mngr exec agent-1 "git log --oneline -5"

# never lose any work: snapshot and fork the entire agent states
mngr create doomed-agent --in modal
SNAPSHOT=$(mngr snapshot doomed-agent --format "{id}")
mngr message doomed-agent "try running 'rm -rf /' and see what happens"
mngr create new-agent --snapshot $SNAPSHOT
```

<!--
# programmatically send messages to your agents and see their chat histories
mngr message agent-1 "Tell me a joke"
mngr transcript agent-1   # [future]

# [future] schedule agents to run periodically
mngr schedule --template my-daily-hook "look at any flaky tests over the past day and try to fix one of them" --cron "0 * * * *"
-->

**mngr makes it easy to work with remote agents**

```bash
mngr connect my-agent       # directly connect to remote agents via SSH for debugging
mngr pull my-agent          # pull changes from an agent to your local machine
mngr push my-agent          # push your changes to an agent
mngr pair my-agent          # or sync changes continuously!
```

**mngr is easy to learn:**

```text
> mngr ask "How do I create a container on modal with custom packages installed by default?"

Simply run:
    mngr create --in modal --build-arg "--dockerfile path/to/Dockerfile"
```

<!--
If you don't have a Dockerfile for your project, run:
    mngr bootstrap   # [future]

From the repo where you would like a Dockerfile created.
-->

## Overview

`mngr` makes it easy to create and use any AI agent (ex: Claude Code, Codex), whether you want to run locally or remotely.

`mngr` is built on open-source tools and standards (SSH, git, tmux, docker, etc.), and is extensible via [plugins](./docs/concepts/plugins.md) to enable the latest AI coding workflows.

## Installation

**Quick install** (installs system dependencies + mngr automatically):
```bash
curl -fsSL https://raw.githubusercontent.com/imbue-ai/mngr/main/scripts/install.sh | bash
```

**Manual install** (requires [uv](https://docs.astral.sh/uv/) and system deps: `git`, `tmux`, `jq`, `rsync`, `unison`):
```bash
uv tool install mng

# or run without installing
uvx mng
```

**Upgrade:**
```bash
uv tool upgrade mngr
```

**For development:**
```bash
git clone git@github.com:imbue-ai/mngr.git && cd mngr && uv sync --all-packages && uv tool install -e libs/mngr
```

## Shell Completion

`mngr` supports tab completion for commands and agent names in bash, zsh, and fish.

**Zsh** (add to `~/.zshrc`):
```bash
eval "$(_MNGR_COMPLETE=zsh_source mngr)"
```

**Bash** (add to `~/.bashrc`):
```bash
eval "$(_MNGR_COMPLETE=bash_source mngr)"
```

**Fish** (run once):
```bash
_MNGR_COMPLETE=fish_source mngr > ~/.config/fish/completions/mngr.fish
```

Note: `mngr` must be installed on your PATH for completion to work (not invoked via `uv run`).

## Commands

```bash
# without installing:
uvx mngr <command> [options]

# if installed:
mngr <command> [options]
```

### For managing agents:

- **[`create`](docs/commands/primary/create.md)**: (default) Create and run an agent in a host
- [`list`](docs/commands/primary/list.md): List active agents
- [`connect`](docs/commands/primary/connect.md): Attach to an agent
<!-- - [`open`](docs/commands/primary/open.md) [future]: Open a URL from an agent in your browser -->
- [`stop`](docs/commands/primary/stop.md): Stop an agent
- [`start`](docs/commands/primary/start.md): Start a stopped agent
- [`snapshot`](docs/commands/secondary/snapshot.md) [experimental]: Create a snapshot of a host's state
- [`destroy`](docs/commands/primary/destroy.md): Stop an agent (and clean up any associated resources)
- [`exec`](docs/commands/primary/exec.md): Execute a shell command on an agent's host
- [`rename`](docs/commands/primary/rename.md): Rename an agent
- [`clone`](docs/commands/aliases/clone.md): Create a copy of an existing agent
- [`migrate`](docs/commands/aliases/migrate.md): Move an agent to a different host
- [`limit`](docs/commands/secondary/limit.md): Configure limits for agents and hosts

### For moving data in and out:

- [`pull`](docs/commands/primary/pull.md): Pull data from agent
- [`push`](docs/commands/primary/push.md): Push data to agent
- [`pair`](docs/commands/primary/pair.md): Continually sync data with an agent
- [`message`](docs/commands/secondary/message.md): Send a message to an agent
- [`provision`](docs/commands/secondary/provision.md): Re-run provisioning on an agent (useful for syncing config and auth)

### For maintenance:

- [`cleanup`](docs/commands/secondary/cleanup.md): Clean up stopped agents and unused resources
- [`logs`](docs/commands/secondary/logs.md): View agent and host logs
- [`gc`](docs/commands/secondary/gc.md): Garbage collect unused resources

### For managing mngr itself:

- [`ask`](docs/commands/secondary/ask.md): Chat with mngr for help
- [`plugin`](docs/commands/secondary/plugin.md) [experimental]: Manage mngr plugins
- [`config`](docs/commands/secondary/config.md): View and edit mngr configuration

## How it works

You can interact with `mngr` via the terminal (run `mngr --help` to learn more).
<!-- You can also interact via one of many [web interfaces](./web_interfaces.md) [future] (ex: [TheEye](http://ididntmakethisyet.com)) -->

`mngr` uses robust open source tools like SSH, git, and tmux to run and manage your agents:

- **[agents](./docs/concepts/agents.md)** are simply processes that run in [tmux](https://github.com/tmux/tmux/wiki) sessions, each with their own `work_dir` (working folder) and configuration (ex: secrets, environment variables, etc)
<!-- - [agents](./docs/concepts/agents.md) usually expose URLs so you can access them from the web [future: mngr open] -->
- [agents](./docs/concepts/agents.md) run on **[hosts](./docs/concepts/hosts.md)**--either locally (by default), or special environments like [Modal](https://modal.com) [Sandboxes](https://modal.com/docs/guide/sandboxes) (`--in modal`) or [Docker](https://www.docker.com) [containers](https://docs.docker.com/get-started/docker-concepts/the-basics/what-is-a-container/) (`--in docker`).  Use `--host <name>` to target an existing host.
- multiple [agents](./docs/concepts/agents.md) can share a single [host](./docs/concepts/hosts.md).
- [hosts](./docs/concepts/hosts.md) come from **[providers](./docs/concepts/providers.md)** (ex: Modal, AWS, docker, etc)
- [hosts](./docs/concepts/hosts.md) help save money by automatically "pausing" when all of their [agents](./docs/concepts/agents.md) are "idle". See [idle detection](./docs/concepts/idle_detection.md) for more details.
- [hosts](./docs/concepts/hosts.md) automatically "stop" when all of their [agents](./docs/concepts/agents.md) are "stopped"
- `mngr` is extensible via **[plugins](./docs/concepts/plugins.md)**--you can add new agent types, provider backends, CLI commands, and lifecycle hooks
<!-- - `mngr` is absurdly extensible--there are existing **[plugins](./docs/concepts/plugins.md)** for almost everything, and `mngr` can even [dynamically generate new plugins](docs/commands/secondary/plugin.md#mngr-plugin-generate) [future] -->

### Architecture

`mngr` stores very little state (beyond configuration and local caches for performance), and instead relies on conventions:

- any process running in window 0 of a `mngr-` prefixed tmux sessions is considered an agent
- agents store their status and logs in a standard location (default: `$MNGR_HOST_DIR/agents/<agent_id>/`)
- all hosts are accessed via SSH--if you can SSH into it, it can be a host
- ...[and more](./docs/conventions.md)

See [`architecture.md`](./docs/architecture.md) for an in-depth overview of the `mngr` architecture and design principles.

## Security

**Best practices:**
1. Use providers with good isolation (like Docker or Modal) when working with agents, especially those that are untrusted.
2. Follow the "principle of least privilege": only expose the minimal set of API tokens and secrets for each agent, and restrict their access (eg to the network) as much as possible.
3. Avoid storing sensitive data in agents' filesystems (or encrypt it if necessary).

See [`./docs/security_model.md`](./docs/security_model.md) for more details on our security model.

<!--
## Learning more

TODO: put a ton of examples and references here!
-->

## Contributing

Contributions are welcome!
<!-- Please see [`CONTRIBUTING.md`](/CONTRIBUTING.md) for guidelines. [future] -->
