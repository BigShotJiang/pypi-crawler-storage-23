"""Example applications for fastapi-request-pipeline."""
