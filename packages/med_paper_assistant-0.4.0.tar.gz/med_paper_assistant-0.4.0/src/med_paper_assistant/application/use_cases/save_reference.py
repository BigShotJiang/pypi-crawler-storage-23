"""
Save Reference Use Case — DEPRECATED.

This module is retained as a tombstone. All save-reference logic now lives in
``interfaces/mcp/tools/reference/manager.py`` (``save_reference`` MCP tool)
and ``save_reference_mcp`` (MCP-to-MCP verified pathway).

Removed in v0.3.12: SaveReferenceUseCase, SaveReferenceInput, SaveReferenceOutput.
"""
