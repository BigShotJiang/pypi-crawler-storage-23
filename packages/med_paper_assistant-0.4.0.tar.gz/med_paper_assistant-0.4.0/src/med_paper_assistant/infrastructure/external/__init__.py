"""
External Services - Third-party API integrations.

Note: PubMed search functionality is now provided by pubmed-search MCP server.
Use MCP protocol for search operations, not direct imports.
"""

__all__ = []
