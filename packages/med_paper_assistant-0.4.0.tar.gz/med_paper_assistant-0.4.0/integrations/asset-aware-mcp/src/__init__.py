# Asset-Aware MCP - Source Package
"""
Asset-Aware Medical RAG MCP Server

A local-first MCP server for medical research with precise asset retrieval.
"""

__version__ = "0.1.0"
