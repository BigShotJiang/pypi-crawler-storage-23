# Presentation Layer - MCP Server Interface
