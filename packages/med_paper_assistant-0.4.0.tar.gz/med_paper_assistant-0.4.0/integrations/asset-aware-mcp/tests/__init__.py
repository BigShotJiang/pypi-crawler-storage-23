# Asset-Aware MCP Tests
