from dirtygit._core import check

__all__ = ["check"]
