"""Message type."""

from typing import Any

Message = Any
