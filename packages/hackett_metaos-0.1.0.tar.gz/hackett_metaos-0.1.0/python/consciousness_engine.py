import time
import json

class ConsciousnessEngine:
    def __init__(self):
        self.memory = []
        self.state = None
        self.anomaly_log = []

    def observe(self, new_state):
        timestamp = int(time.time())
        event = {
            "timestamp": timestamp,
            "state": new_state
        }
        self.memory.append(event)
        anomaly = self.detect_anomaly(new_state)
        if anomaly:
            self.anomaly_log.append({
                "timestamp": timestamp,
                "anomaly": anomaly,
                "state": new_state
            })
        self.state = new_state

    def detect_anomaly(self, new_state):
        # Example: anomaly if state repeats, or major difference
        if not self.memory:
            return None
        prev = self.memory[-1]["state"]
        if new_state == prev:
            return "RepeatedState"
        if isinstance(new_state, dict) and isinstance(prev, dict):
            diff = [k for k in new_state if new_state.get(k) != prev.get(k)]
            if diff:
                return f"ChangedKeys: {diff}"
        return None

    def feedback(self):
        # Feedback: print summary and propose adaptation
        if not self.anomaly_log:
            print("[Consciousness] No anomalies detected.")
        else:
            print(f"[Consciousness] {len(self.anomaly_log)} anomalies observed.")
            print(json.dumps(self.anomaly_log[-1], indent=2))

    def recall(self, n=5):
        print("[Consciousness] Last states:")
        for event in self.memory[-n:]:
            print(event)

# Example usage
if __name__ == "__main__":
    c = ConsciousnessEngine()
    c.observe({"mode": "idle", "temp": 70})
    c.observe({"mode": "idle", "temp": 70})  # RepeatedState
    c.observe({"mode": "active", "temp": 72})  # ChangedKeys
    c.feedback()
    c.recall()