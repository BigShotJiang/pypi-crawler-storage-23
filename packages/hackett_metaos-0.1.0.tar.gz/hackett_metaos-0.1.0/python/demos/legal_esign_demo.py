import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ledger import Ledger
import time

# ANSI color/style codes
BOLD = "\033[1m"
END = "\033[0m"
GREEN = "\033[92m"
RED = "\033[91m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
GRAY = "\033[90m"
BOX = "═" * 78

def print_header(title):
    print(f"\n{CYAN}{BOX}{END}")
    print(f"{CYAN}║{END} {BOLD}{title}{END}")
    print(f"{CYAN}{BOX}{END}")

def print_section(title, icon=""):
    print(f"\n{CYAN}{BOX}\n║{END} {BOLD}{icon} {title}{END}\n{CYAN}{BOX}{END}")

def print_event(msg, receipt_id, sig, observer, is_omission=False):
    color = RED if is_omission else GREEN
    prefix = "✗" if is_omission else "✓"
    who = f"{GRAY}Observer: {observer}{END}"
    print(f"{color}{prefix} {msg}{END}   {who}")
    print(f"{GRAY}    Receipt ID: {receipt_id} | Sig: {sig[:12]}...{END}")

def print_audit(ledger):
    print_section("AUDIT SUMMARY", "🗂")
    compressed = ledger.compress_ledger()
    print(f"{CYAN}Audit trail compressed: {len(compressed)} bytes{END}")
    print(f"{CYAN}Events: {len(ledger.events)} | Omissions: {len(ledger.nullreceipts)}{END}")

def print_benefits():
    print_section("LEGAL & ENTERPRISE VALUE", "⚖️")
    print(f"{BOLD}✓{END} Every signature, approval, and omission is cryptographically receipted")
    print(f"{BOLD}✓{END} Missing or late sign-off is instantly detected and logged")
    print(f"{BOLD}✓{END} Tamper-proof contract audit for litigation, compliance, and due diligence")
    print(f"{BOLD}✓{END} Ready for ESIGN Act, UETA, GDPR, SOC2, and global e-signature laws")
    print(f"{BOLD}✓{END} One-click export and verification for court, M&A, or audit")
    print(f"{CYAN}{BOX}{END}")

if __name__ == "__main__":
    print_header("HACKETT META OS - LEGAL CONTRACT E-SIGN & AUDIT DEMO")
    print_section("CONTRACT SIGNATURE WORKFLOW", "🖊️")
    ledger = Ledger()
    ts = int(time.time())

    # Step 1: Contract sent to parties
    c1 = f"Contract #2024-99 sent to Alice & Bob, ts={ts}"
    r1 = ledger.log_event(c1, observer_id="LegalBot")
    print_event(c1, r1['event_id'], r1['sig'], r1['observer'])

    # Step 2: Alice signs
    c2 = f"Alice signed Contract #2024-99, ts={ts+1}"
    r2 = ledger.log_event(c2, observer_id="Alice")
    print_event(c2, r2['event_id'], r2['sig'], r2['observer'])

    # Step 3: Omission - Bob's signature missing
    omission = f"Bob signature missing for Contract #2024-99, ts={ts+2}"
    nr = ledger.log_nullreceipt(omission, observer_id="ComplianceBot")
    print_event(omission, nr['event_id'], nr['sig'], nr['observer'], is_omission=True)

    # Step 4: Manager override, approval to execute
    c3 = f"Manager override: execute contract pending Bob, ts={ts+3}"
    r3 = ledger.log_event(c3, observer_id="Manager")
    print_event(c3, r3['event_id'], r3['sig'], r3['observer'])

    # Step 5: Final e-sign
    c4 = f"Bob signed Contract #2024-99, ts={ts+4}"
    r4 = ledger.log_event(c4, observer_id="Bob")
    print_event(c4, r4['event_id'], r4['sig'], r4['observer'])

    print_audit(ledger)
    print_benefits()
    print(f"{CYAN}{BOX}{END}")
    print(f"{CYAN}{BOLD}Demo Complete | github.com/adhack121-create/hackett-meta-os{END}")
    print(f"{CYAN}{BOX}{END}\n")