import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - FINANCIAL TRADING AUDIT DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())
ledger.log_event(f"Trade submitted at {ts}, Symbol: TSLA, Qty: 500, Type: BUY", observer_id="TraderBot")
ledger.log_event(f"Order routed to exchange at {ts+1}, Exchange: NASDAQ", observer_id="OrderRouter")
ledger.log_nullreceipt(f"Confirmation timeout at {ts+2}, market data gap detected", observer_id="MarketMonitor")
ledger.log_event(f"Execution received at {ts+3}, Fill Price: $331.44", observer_id="Exchange")
ledger.log_event(f"Compliance review completed at {ts+4}, all rules passed", observer_id="ComplianceDesk")
ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 📈 FINANCIAL TRADING VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every order, gap, and fill cryptographically receipted")
print("✓ NullReceipts flag missing confirmations or spoofing")
print("✓ Instant audit for SEC/CFTC, trading venues, and clients")
print("✓ No backdating, no hidden fills—one-click regulatory proof")
print("═════════════════════════════════════════════════════════════════════════════")