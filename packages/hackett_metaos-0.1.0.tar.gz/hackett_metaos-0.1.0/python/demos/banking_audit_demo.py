import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ledger import Ledger
import time

# ANSI color/style codes
BOLD = "\033[1m"
END = "\033[0m"
GREEN = "\033[92m"
RED = "\033[91m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
GRAY = "\033[90m"
BOX = "═" * 78

def print_header(title):
    print(f"\n{CYAN}{BOX}{END}")
    print(f"{CYAN}║{END} {BOLD}{title}{END}")
    print(f"{CYAN}{BOX}{END}")

def print_section(title, icon=""):
    print(f"\n{CYAN}{BOX}\n║{END} {BOLD}{icon} {title}{END}\n{CYAN}{BOX}{END}")

def print_event(msg, receipt_id, sig, observer, is_omission=False):
    color = RED if is_omission else GREEN
    prefix = "✗" if is_omission else "✓"
    who = f"{GRAY}Observer: {observer}{END}"
    print(f"{color}{prefix} {msg}{END}   {who}")
    print(f"{GRAY}    Receipt ID: {receipt_id} | Sig: {sig[:12]}...{END}")

def print_audit(ledger):
    print_section("AUDIT SUMMARY", "🗂")
    compressed = ledger.compress_ledger()
    print(f"{CYAN}Audit trail compressed: {len(compressed)} bytes{END}")
    print(f"{CYAN}Events: {len(ledger.events)} | Omissions: {len(ledger.nullreceipts)}{END}")

def print_benefits():
    print_section("BANKING COMPLIANCE & RISK VALUE", "🏦")
    print(f"{BOLD}✓{END} Every transaction, approval, and omission is cryptographically receipted")
    print(f"{BOLD}✓{END} Detects and logs missing approvals, fraud, or compliance failures instantly")
    print(f"{BOLD}✓{END} One-click audit trail for regulators, auditors, and legal teams")
    print(f"{BOLD}✓{END} Tamper/backdate resistant—meets global banking standards")
    print(f"{BOLD}✓{END} Compress and export full transaction history in seconds")
    print(f"{CYAN}{BOX}{END}")

if __name__ == "__main__":
    print_header("HACKETT META OS - BANKING TRANSACTION AUDIT DEMO")
    print_section("TRANSACTION WORKFLOW", "💸")
    ledger = Ledger()
    ts = int(time.time())

    # Step 1: Transaction Initiated
    tx1 = f"Wire transfer initiated at {ts}, $25,000 from Acct #10234 to Acct #45092"
    r1 = ledger.log_event(tx1, observer_id="CustomerPortal")
    print_event(tx1, r1['event_id'], r1['sig'], r1['observer'])

    # Step 2: AML/KYC Check
    kyc = f"AML/KYC check completed at {ts+1}, status: PASSED"
    r2 = ledger.log_event(kyc, observer_id="ComplianceBot")
    print_event(kyc, r2['event_id'], r2['sig'], r2['observer'])

    # Step 3: Omission - Approval missing
    omission = f"Manager approval missing at {ts+2} for high-value transfer"
    nr = ledger.log_nullreceipt(omission, observer_id="RiskEngine")
    print_event(omission, nr['event_id'], nr['sig'], nr['observer'], is_omission=True)

    # Step 4: Manual override (documented)
    override = f"Override: transfer approved by supervisor at {ts+3}"
    r3 = ledger.log_event(override, observer_id="Supervisor")
    print_event(override, r3['event_id'], r3['sig'], r3['observer'])

    print_audit(ledger)
    print_benefits()
    print(f"{CYAN}{BOX}{END}")
    print(f"{CYAN}{BOLD}Demo Complete | github.com/adhack121-create/hackett-meta-os{END}")
    print(f"{CYAN}{BOX}{END}\n")