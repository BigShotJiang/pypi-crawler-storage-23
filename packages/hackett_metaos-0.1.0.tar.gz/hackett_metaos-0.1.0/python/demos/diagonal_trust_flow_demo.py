import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - DIAGONAL / CROSS-FUNCTIONAL TRUST FLOW DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

# Horizontal: Finance <-> HR for Payroll
ledger.log_event(f"Payroll data submitted by HR at {ts}", observer_id="HRSystem")
ledger.log_event(f"Finance cross-check completed at {ts+1}", observer_id="PayrollAuditor")

# Diagonal: Ops <-> Product <-> IT for Incident Escalation
ledger.log_event(f"Ops incident detected: supply shortage at {ts+2}", observer_id="OpsMonitor")
ledger.log_event(f"Product team notified, escalation triggered", observer_id="OpsMonitor")
ledger.log_event(f"Product sprint reprioritized for alternate supplier integration", observer_id="ProductManager")
ledger.log_event(f"IT provisioned integration API for new supplier", observer_id="ITCloud")
ledger.log_event(f"Resolution verified by Ops", observer_id="OpsMonitor")

# Diagonal: Customer Crisis, “Swarm” Resolution (All Hands)
ledger.log_event(f"Major client outage reported at {ts+3}", observer_id="CustomerSupport")
ledger.log_event(f"Task force formed: Sales, IT, Product, Exec", observer_id="ExecAdmin")
ledger.log_event(f"Patch developed and deployed", observer_id="DevOps")
ledger.log_event(f"Customer notified and service restored", observer_id="SupportRep")
ledger.log_nullreceipt(f"Incident review post-mortem not yet submitted", observer_id="RiskOfficer")

# Meta-Process: Regulatory/Legal Compliance
ledger.log_event(f"External audit initiated: Data privacy compliance", observer_id="Legal")
ledger.log_event(f"All departments submit compliance attestation", observer_id="RegulatoryBot")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🔀 DIAGONAL & META-PROCESS TRUST FLOW VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Maps horizontal, vertical, and diagonal flows—every real-world handoff or escalation")
print("✓ Captures “crisis team”, “all hands”, and cross-department interventions")
print("✓ NullReceipts = instant proof of missing actions, delays, or compliance failures")
print("✓ This is the *living network* of trust: forensics, audit, governance, resilience")
print("✓ Outperforms any legacy org chart, SOC, GRC, or workflow tool—receipts-native everything")
print("═════════════════════════════════════════════════════════════════════════════")