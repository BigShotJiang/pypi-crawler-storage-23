import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - MISSILE TELEMETRY & LAUNCH AUDIT DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Launch command received at {ts}, Platform: Aegis Destroyer, Missile: SM-6", observer_id="CommandBridge")
ledger.log_event(f"Pre-flight check passed at {ts+1}, All systems nominal", observer_id="MissileControl")
ledger.log_event(f"Launch at {ts+2}, initial trajectory azimuth 315°, burn time 8.7s", observer_id="LaunchComputer")
ledger.log_event(f"Mid-course telemetry: Mach 3.5 at {ts+3}, 62km altitude", observer_id="FlightTelemetry")
ledger.log_nullreceipt(f"Telemetry gap at {ts+4}, GPS lock lost 3s", observer_id="TelemetryMonitor")
ledger.log_event(f"Terminal phase: target acquired, seeker activated at {ts+5}", observer_id="GuidanceSystem")
ledger.log_event(f"Impact confirmed at {ts+6}, coordinates 35.2N/129.7E", observer_id="ImpactSensor")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🚀 MISSILE TELEMETRY & AUDIT VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every launch, telemetry, GPS loss, and impact cryptographically receipted")
print("✓ NullReceipts catch data loss, jamming, and potential sabotage")
print("✓ Chain of custody for every mission-critical event")
print("✓ Full audit trail for arms control, R&D, and compliance")
print("✓ One-click evidence for incident review and accountability")
print("═════════════════════════════════════════════════════════════════════════════")