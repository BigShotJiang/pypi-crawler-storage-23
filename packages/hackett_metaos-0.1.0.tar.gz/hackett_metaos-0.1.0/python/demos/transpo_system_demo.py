import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - TRANSPORTATION SYSTEMS OPS DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())
ledger.log_event(f"Bus dispatch at {ts}, Route: 14, Vehicle: #3827", observer_id="DispatchCenter")
ledger.log_event(f"Passenger boarding at {ts+1}, Fare: $2.00", observer_id="FareBox")
ledger.log_nullreceipt(f"GPS signal lost at {ts+2}, Segment: Main & 8th", observer_id="AVLMonitor")
ledger.log_event(f"Traffic signal override at {ts+3}, Intersection: Main & 11th", observer_id="TrafficControlAI")
ledger.log_event(f"Safety inspection passed at {ts+4}, Inspector: T. Lewis", observer_id="SafetyOps")
ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🚍 TRANSPORTATION SYSTEMS VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every movement, event, and GPS gap cryptographically receipted")
print("✓ NullReceipts for missing location/sensor data = audit, accident, insurance, and legal proof")
print("✓ Tamper-proof, receipts-native mass transit, rail, and road ops")
print("✓ One-click export for DOT, NTSB, and safety review")
print("═════════════════════════════════════════════════════════════════════════════")