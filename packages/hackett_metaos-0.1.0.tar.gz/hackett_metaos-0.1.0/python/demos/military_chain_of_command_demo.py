import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - MILITARY CHAIN OF COMMAND DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Order issued at {ts}, Classification: SECRET, Unit: 5th Brigade", observer_id="CommandCenter")
ledger.log_event(f"Order acknowledged at {ts+1}, Commander: Col. Smith", observer_id="UnitComms")
ledger.log_nullreceipt(f"Confirmation missing at {ts+2}", observer_id="ChainOfCommand")
ledger.log_event(f"Override at {ts+3}, General: Maj. Gen. Jones", observer_id="TheaterCommand")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🛡️ MILITARY CHAIN OF COMMAND VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every order, acknowledgement, and omission cryptographically receipted")
print("✓ Breaks in chain (nullreceipts) are instantly visible")
print("✓ Tamper-proof, audit-ready command and override record")
print("✓ Proves operational integrity, prevents plausible deniability")
print("═════════════════════════════════════════════════════════════════════════════")