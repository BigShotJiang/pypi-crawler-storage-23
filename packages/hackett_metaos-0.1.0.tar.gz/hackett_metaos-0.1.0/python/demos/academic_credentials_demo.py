import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - ACADEMIC CREDENTIAL VERIFICATION DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Course enrolled at {ts}, Student #10234, CS-101", observer_id="RegistrarSystem")
ledger.log_event(f"Assignments completed at {ts+1}-{ts+10}", observer_id="LearningManagement")
ledger.log_nullreceipt(f"Final exam missing at {ts+11}", observer_id="ExamProctor")
ledger.log_event(f"Grade posted at {ts+12}, B+ (ANOMALY)", observer_id="ProfessorPortal")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🎓 ACADEMIC CREDENTIALS VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every course, assignment, and exam cryptographically receipted")
print("✓ Employers/universities can instantly verify credentials")
print("✓ NullReceipts catch fraud, grade inflation, and diploma mills")
print("✓ Tamper-proof, audit-native academic records for life")
print("═════════════════════════════════════════════════════════════════════════════")