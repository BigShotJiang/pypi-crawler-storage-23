import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ledger import Ledger
import time

# ANSI color/style codes
BOLD = "\033[1m"
END = "\033[0m"
GREEN = "\033[92m"
RED = "\033[91m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
GRAY = "\033[90m"
BOX = "═" * 78

def print_header(title):
    print(f"\n{CYAN}{BOX}{END}")
    print(f"{CYAN}║{END} {BOLD}{title}{END}")
    print(f"{CYAN}{BOX}{END}")

def print_section(title, icon=""):
    print(f"\n{CYAN}{BOX}\n║{END} {BOLD}{icon} {title}{END}\n{CYAN}{BOX}{END}")

def print_event(msg, receipt_id, sig, observer, is_omission=False):
    color = RED if is_omission else GREEN
    prefix = "✗" if is_omission else "✓"
    who = f"{GRAY}Observer: {observer}{END}"
    print(f"{color}{prefix} {msg}{END}   {who}")
    print(f"{GRAY}    Receipt ID: {receipt_id} | Sig: {sig[:12]}...{END}")

def print_audit(ledger):
    print_section("AUDIT SUMMARY", "🗂")
    compressed = ledger.compress_ledger()
    print(f"{CYAN}Audit trail compressed: {len(compressed)} bytes{END}")
    print(f"{CYAN}Events: {len(ledger.events)} | Omissions: {len(ledger.nullreceipts)}{END}")

def print_benefits():
    print_section("AVIATION SAFETY & RISK VALUE", "✈️")
    print(f"{BOLD}✓{END} Every inspection, repair, and omission cryptographically receipted")
    print(f"{BOLD}✓{END} Skipped safety checks, downtime, or event anomalies instantly logged")
    print(f"{BOLD}✓{END} Meets FAA, EASA, ICAO, and airline compliance—ready for root cause analysis")
    print(f"{BOLD}✓{END} Compress and export flight/maintenance records for audit or insurance")
    print(f"{BOLD}✓{END} Tamper-proof black-box: receipts-native proof for every key event")
    print(f"{CYAN}{BOX}{END}")

if __name__ == "__main__":
    print_header("HACKETT META OS - AVIATION MAINTENANCE & BLACK-BOX AUDIT DEMO")
    print_section("MAINTENANCE & FLIGHT WORKFLOW", "🛠️")
    ledger = Ledger()
    ts = int(time.time())

    # Step 1: Preflight inspection completed
    s1 = f"Preflight inspection completed on A320, tail #N4567, ts={ts}"
    r1 = ledger.log_event(s1, observer_id="Inspector")
    print_event(s1, r1['event_id'], r1['sig'], r1['observer'])

    # Step 2: Hydraulic system check performed
    s2 = f"Hydraulic system check PASSED, ts={ts+1}"
    r2 = ledger.log_event(s2, observer_id="MaintenanceBot")
    print_event(s2, r2['event_id'], r2['sig'], r2['observer'])

    # Step 3: Omission—Skipped brake wear check
    omission = f"Omission: Brake wear check SKIPPED, ts={ts+2}"
    nr = ledger.log_nullreceipt(omission, observer_id="AuditBot")
    print_event(omission, nr['event_id'], nr['sig'], nr['observer'], is_omission=True)

    # Step 4: Supervisor override, plane cleared for flight
    s3 = f"Supervisor override: flight cleared despite omission, ts={ts+3}"
    r3 = ledger.log_event(s3, observer_id="Supervisor")
    print_event(s3, r3['event_id'], r3['sig'], r3['observer'])

    # Step 5: In-flight engine anomaly detected
    s4 = f"In-flight event: Engine vibration anomaly detected, ts={ts+4}"
    r4 = ledger.log_event(s4, observer_id="FlightRecorder")
    print_event(s4, r4['event_id'], r4['sig'], r4['observer'])

    # Step 6: Post-flight report & NTSB alert
    s5 = f"Post-flight maintenance report filed, NTSB notified, ts={ts+5}"
    r5 = ledger.log_event(s5, observer_id="PostFlightBot")
    print_event(s5, r5['event_id'], r5['sig'], r5['observer'])

    print_audit(ledger)
    print_benefits()
    print(f"{CYAN}{BOX}{END}")
    print(f"{CYAN}{BOLD}Demo Complete | github.com/adhack121-create/hackett-meta-os{END}")
    print(f"{CYAN}{BOX}{END}\n")