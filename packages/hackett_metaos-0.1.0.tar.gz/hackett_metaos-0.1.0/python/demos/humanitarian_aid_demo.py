import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - HUMANITARIAN AID DISTRIBUTION DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Aid shipment dispatched at {ts}, Origin: UN Warehouse, Lot #R-2026-14", observer_id="DispatchManager")
ledger.log_event(f"Border crossing cleared at {ts+1}, Customs: Albania/Serbia", observer_id="BorderAgent")
ledger.log_nullreceipt(f"Checkpoint log missing at {ts+2}, expected delivery update not received", observer_id="TransitMonitor")
ledger.log_event(f"Aid delivered at {ts+3}, Location: Shkodër, Recipients: 184 families", observer_id="FieldTeam")
ledger.log_event(f"NGO verification at {ts+4}, Audit photos and recipient signatures uploaded", observer_id="AuditBot")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🤝 HUMANITARIAN AID ACCOUNTABILITY VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every shipment, handoff, and delivery cryptographically receipted")
print("✓ NullReceipts flag missing updates or suspected diversion instantly")
print("✓ Audit-ready trail for donors, governments, and recipients")
print("✓ Stops corruption/diversion, builds trust, ensures real aid impact")
print("✓ Tamper-proof, receipts-native humanitarian supply chain")
print("═════════════════════════════════════════════════════════════════════════════")