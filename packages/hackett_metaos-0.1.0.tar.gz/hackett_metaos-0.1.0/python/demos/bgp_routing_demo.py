import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - INTERNET BACKBONE (BGP ROUTING) DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())
ledger.log_event(f"BGP update at {ts}, ASN: 701, Prefix: 123.45.67.0/24", observer_id="Router-Core")
ledger.log_event(f"Route propagated to peer ASN: 3356", observer_id="PeerRouter")
ledger.log_nullreceipt(f"Route withdrawal not received at {ts+1}, potential hijack", observer_id="RouteMonitor")
ledger.log_event(f"Path validation passed at {ts+2}, RPKI signature valid", observer_id="SecurityBot")
ledger.log_event(f"Network reconvergence at {ts+3}, traffic stabilized", observer_id="NetOpsAI")
ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🌐 BGP ROUTING / INTERNET BACKBONE VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every update, propagation, and omission cryptographically receipted")
print("✓ NullReceipts stop route hijack, leaks, and invisible outages")
print("✓ Audit-ready for NOC, ISPs, and global regulators")
print("✓ Tamper-proof, receipts-native backbone ops")
print("═════════════════════════════════════════════════════════════════════════════")