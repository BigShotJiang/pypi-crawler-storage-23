import zlib
import lzma
import bz2
import os

class AdaptiveCompressor:
    def __init__(self):
        pass

    def detect_type(self, path):
        ext = os.path.splitext(path)[1].lower()
        if ext in [".txt", ".json", ".csv", ".log"]:
            return "text"
        elif ext in [".jpg", ".png", ".mp4", ".zip"]:
            return "already_compressed"
        else:
            return "generic"

    def compress(self, path):
        file_type = self.detect_type(path)

        with open(path, "rb") as f:
            data = f.read()

        original_size = len(data)

        if file_type == "text":
            compressed = lzma.compress(data)  # strongest
            algo = "LZMA"

        elif file_type == "generic":
            compressed = bz2.compress(data)
            algo = "BZ2"

        else:
            compressed = zlib.compress(data)  # fast
            algo = "ZLIB"

        new_size = len(compressed)
        ratio = round(original_size / new_size, 2)

        out_path = path + ".hmos"
        with open(out_path, "wb") as f:
            f.write(compressed)

        print(f"[HMOS] {algo} compression complete")
        print(f"Original: {original_size} bytes")
        print(f"Compressed: {new_size} bytes")
        print(f"Ratio: {ratio}x")

        return out_path