from ledger import Ledger

class LloydBot:
    def __init__(self, ledger):
        self.ledger = ledger

    def process(self, event):
        response = f"LloydBot processed: {event}"
        self.ledger.log_event(response, observer_id="LloydBot")
        print(f"[LloydBot] {response}")

# Example usage
if __name__ == "__main__":
    ledger = Ledger()
    bot = LloydBot(ledger)
    bot.process("Daily empire status check.")
    ledger.audit()