import json
from pathlib import Path

import pytest


def load_data(path: str) -> dict:
    return json.loads(Path(path).read_text())


@pytest.fixture
def testdata_loader():
    """Returns a function to load test data for any resource."""
    def _load(resource_name: str, file_type: str) -> dict:
        return load_data(f"tests/unit/testdata/{resource_name}/{file_type}.json")
    return _load


__all__ = ["testdata_loader"]
