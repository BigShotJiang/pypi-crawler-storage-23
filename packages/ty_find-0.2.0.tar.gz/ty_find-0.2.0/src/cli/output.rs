use crate::cli::args::{OutputDetail, OutputFormat};
#[cfg(unix)]
use crate::daemon::protocol::{MemberInfo, MembersResult};
use crate::lsp::protocol::{
    DocumentSymbol, Hover, HoverContents, Location, MarkedStringOrString, SymbolInformation,
    SymbolKind,
};
use std::fmt::Write;
use std::path::{Path, PathBuf};

/// A reference location enriched with enclosing symbol context.
#[derive(Clone, Debug)]
pub struct EnrichedReference {
    pub location: Location,
    /// Dot-separated path of the tightest enclosing symbol (e.g. "RequestHandler.process"),
    /// or "module scope" if at top level.
    pub context: String,
}

/// A single inspect result with optional symbol kind.
pub struct InspectEntry<'a> {
    pub symbol: &'a str,
    pub kind: Option<&'a SymbolKind>,
    pub definitions: &'a [Location],
    pub hover: Option<&'a Hover>,
    /// Total number of references found (always populated, used for count summary).
    pub total_reference_count: usize,
    /// Number of unique files across all references.
    pub total_reference_files: usize,
    /// Displayed references (capped by --references-limit), enriched with context.
    pub displayed_references: Vec<EnrichedReference>,
    /// How many references were not displayed due to the limit.
    pub remaining_reference_count: usize,
    /// Whether individual references should be shown (true = -r was passed).
    pub show_individual_refs: bool,
}

pub struct OutputFormatter {
    format: OutputFormat,
    detail: OutputDetail,
    cwd: PathBuf,
}

/// Read a single line of source code from a file (1-based line number).
fn read_source_line(file_path: &str, line: u32) -> Option<String> {
    let content = std::fs::read_to_string(file_path).ok()?;
    content.lines().nth((line - 1) as usize).map(|s| s.trim().to_string())
}

/// Context around a definition: decorator lines and the keyword line.
struct DefinitionContext {
    /// Decorator lines (e.g. `@dataclass`, `@property`), if any.
    decorators: Option<String>,
    /// The `class`/`def` keyword line (e.g. `class Dog(Animal):`).
    definition_line: String,
}

/// Read definition context from a file at a 0-indexed starting line.
///
/// Handles both cases:
/// - Start line is at a decorator (workspace symbols): scans forward past `@`
///   lines, then also scans backwards from the keyword line to capture any
///   decorators above it.
/// - Start line is at the `class`/`def` keyword (`execute_definition`): scans
///   backwards to find decorators above.
fn read_definition_context(file_path: &str, start_line_0: u32) -> Option<DefinitionContext> {
    let content = std::fs::read_to_string(file_path).ok()?;
    let lines: Vec<&str> = content.lines().collect();
    let start = start_line_0 as usize;

    // Find the keyword line by scanning forward past decorators
    let mut def_idx = None;
    for (i, line) in lines.iter().enumerate().skip(start) {
        if !line.trim().starts_with('@') {
            def_idx = Some(i);
            break;
        }
    }
    let def_idx = def_idx?;
    let definition_line = lines[def_idx].trim().to_string();

    // Scan backwards from the keyword line to collect all decorators
    let mut decorator_lines = Vec::new();
    let mut idx = def_idx;
    while idx > 0 {
        idx -= 1;
        let trimmed = lines[idx].trim();
        if trimmed.starts_with('@') {
            decorator_lines.push(trimmed);
        } else {
            break;
        }
    }

    let decorators = if decorator_lines.is_empty() {
        None
    } else {
        decorator_lines.reverse(); // restore top-to-bottom order
        Some(decorator_lines.into_iter().collect::<Vec<_>>().join("\n"))
    };

    Some(DefinitionContext { decorators, definition_line })
}

#[cfg(test)]
fn read_decorators(file_path: &str, start_line_0: u32) -> Option<String> {
    read_definition_context(file_path, start_line_0).and_then(|ctx| ctx.decorators)
}

#[cfg(test)]
fn read_definition_line(file_path: &str, start_line_0: u32) -> Option<String> {
    read_definition_context(file_path, start_line_0).map(|ctx| ctx.definition_line)
}

/// Enriched references result for the references command.
pub struct EnrichedReferencesResult {
    /// Symbol name or query label.
    pub label: String,
    /// Total number of references found.
    pub total_count: usize,
    /// Displayed references (capped by limit), enriched with context.
    pub displayed: Vec<EnrichedReference>,
    /// How many references were not displayed due to the limit.
    pub remaining_count: usize,
}

/// Check whether a position (line, character) is inside a range (inclusive).
fn position_in_range(range: &crate::lsp::protocol::Range, line: u32, character: u32) -> bool {
    if line < range.start.line || line > range.end.line {
        return false;
    }
    if line == range.start.line && character < range.start.character {
        return false;
    }
    if line == range.end.line && character > range.end.character {
        return false;
    }
    true
}

/// Walk a `DocumentSymbol` tree to find the tightest enclosing symbol for a position.
///
/// Returns the dot-separated path (e.g. `"MyClass.my_method"`) of the deepest
/// symbol whose `range` contains the given position, or `None` if the position
/// is outside all symbols (module scope).
pub fn find_enclosing_symbol(
    symbols: &[DocumentSymbol],
    line: u32,
    character: u32,
) -> Option<String> {
    let mut path = Vec::new();
    find_enclosing_recursive(symbols, line, character, &mut path);
    if path.is_empty() {
        None
    } else {
        Some(path.join("."))
    }
}

fn find_enclosing_recursive(
    symbols: &[DocumentSymbol],
    line: u32,
    character: u32,
    path: &mut Vec<String>,
) {
    for sym in symbols {
        if position_in_range(&sym.range, line, character) {
            path.push(sym.name.clone());
            if let Some(children) = &sym.children {
                find_enclosing_recursive(children, line, character, path);
            }
            return;
        }
    }
}

/// Strip markdown code fences (`` ```lang `` / `` ``` ``) leaving only content.
fn strip_code_fences(text: &str) -> String {
    let mut lines: Vec<&str> = Vec::new();
    for line in text.lines() {
        if line.trim_start().starts_with("```") {
            continue;
        }
        lines.push(line);
    }
    lines.join("\n")
}

impl OutputFormatter {
    #[cfg(test)]
    pub fn new(format: OutputFormat) -> Self {
        Self::with_detail(format, OutputDetail::default())
    }

    pub fn with_detail(format: OutputFormat, detail: OutputDetail) -> Self {
        Self { format, detail, cwd: std::env::current_dir().unwrap_or_else(|_| PathBuf::from("/")) }
    }

    pub fn format_definitions(&self, locations: &[Location], query_info: &str) -> String {
        match self.format {
            OutputFormat::Human => self.format_human(locations, query_info),
            OutputFormat::Json => Self::format_json(locations),
            OutputFormat::Csv => self.format_csv(locations),
            OutputFormat::Paths => self.format_paths(locations),
        }
    }

    fn format_human(&self, locations: &[Location], query_info: &str) -> String {
        if locations.is_empty() {
            return format!("No definitions found for: {query_info}");
        }

        let mut output = format!("Found {} definition(s) for: {query_info}\n\n", locations.len());

        for (i, location) in locations.iter().enumerate() {
            let file_path = self.uri_to_path(&location.uri);
            let line = location.range.start.line + 1;
            let column = location.range.start.character + 1;

            let _ = writeln!(output, "{}. {file_path}:{line}:{column}", i + 1);

            if let Some(src) = read_source_line(&file_path, line) {
                let _ = writeln!(output, "   {src}");
            }
            output.push('\n');
        }

        output
    }

    fn format_json(locations: &[Location]) -> String {
        serde_json::to_string_pretty(locations).unwrap_or_else(|_| "[]".to_string())
    }

    fn format_csv(&self, locations: &[Location]) -> String {
        let mut output = String::from("file,line,column\n");
        for location in locations {
            let file_path = self.uri_to_path(&location.uri);
            let line = location.range.start.line + 1;
            let column = location.range.start.character + 1;
            let _ = writeln!(output, "{file_path},{line},{column}");
        }
        output
    }

    fn format_paths(&self, locations: &[Location]) -> String {
        locations.iter().map(|loc| self.uri_to_path(&loc.uri)).collect::<Vec<_>>().join("\n")
    }

    fn uri_to_path(&self, uri: &str) -> String {
        let abs_path = if let Some(stripped) = uri.strip_prefix("file://") {
            stripped.to_string()
        } else {
            return uri.to_string();
        };

        // Try to make path relative to cwd
        let path = Path::new(&abs_path);
        match path.strip_prefix(&self.cwd) {
            Ok(rel) => rel.display().to_string(),
            Err(_) => abs_path,
        }
    }

    /// Format results for one or more symbol find queries, grouped by symbol.
    pub fn format_find_results(&self, results: &[(String, Vec<Location>)]) -> String {
        if results.len() == 1 {
            let (symbol, locations) = &results[0];
            if locations.is_empty() {
                return format!("No definitions found for: '{symbol}'");
            }
            let query_info = format!("'{symbol}'");
            return self.format_definitions(locations, &query_info);
        }

        match self.format {
            OutputFormat::Human => {
                let mut output = String::new();
                for (symbol, locations) in results {
                    let _ = writeln!(output, "=== {symbol} ===");
                    if locations.is_empty() {
                        output.push_str("No definitions found.\n");
                    } else {
                        output.push_str(&self.format_human(locations, &format!("'{symbol}'")));
                    }
                    output.push('\n');
                }
                output.trim_end().to_string()
            }
            OutputFormat::Json => {
                let grouped: Vec<serde_json::Value> = results
                    .iter()
                    .map(|(symbol, locations)| {
                        serde_json::json!({
                            "symbol": symbol,
                            "definitions": locations,
                        })
                    })
                    .collect();
                serde_json::to_string_pretty(&grouped).unwrap_or_else(|_| "[]".to_string())
            }
            OutputFormat::Csv => {
                let mut output = String::from("symbol,file,line,column\n");
                for (symbol, locations) in results {
                    for location in locations {
                        let file_path = self.uri_to_path(&location.uri);
                        let line = location.range.start.line + 1;
                        let column = location.range.start.character + 1;
                        let _ = writeln!(output, "{symbol},{file_path},{line},{column}");
                    }
                }
                output
            }
            OutputFormat::Paths => {
                let mut paths: Vec<String> = results
                    .iter()
                    .flat_map(|(_, locations)| {
                        locations.iter().map(|loc| self.uri_to_path(&loc.uri))
                    })
                    .collect();
                paths.sort();
                paths.dedup();
                paths.join("\n")
            }
        }
    }

    /// Format enriched references results (with context and limit support).
    pub fn format_enriched_references_results(
        &self,
        results: &[EnrichedReferencesResult],
    ) -> String {
        if results.len() == 1 {
            return self.format_enriched_references_single(&results[0]);
        }

        match self.format {
            OutputFormat::Human => {
                let mut output = String::new();
                for result in results {
                    let _ = writeln!(output, "=== {} ===", result.label);
                    output.push_str(&self.format_enriched_references_single(result));
                    output.push('\n');
                }
                output.trim_end().to_string()
            }
            OutputFormat::Json => {
                let grouped: Vec<serde_json::Value> =
                    results.iter().map(Self::enriched_refs_to_json).collect();
                serde_json::to_string_pretty(&grouped).unwrap_or_else(|_| "[]".to_string())
            }
            OutputFormat::Csv => {
                let mut output = String::from("symbol,file,line,column,context\n");
                for result in results {
                    for enriched in &result.displayed {
                        let file_path = self.uri_to_path(&enriched.location.uri);
                        let line = enriched.location.range.start.line + 1;
                        let column = enriched.location.range.start.character + 1;
                        let _ = writeln!(
                            output,
                            "{},{file_path},{line},{column},{}",
                            result.label, enriched.context
                        );
                    }
                }
                output
            }
            OutputFormat::Paths => {
                let mut paths: Vec<String> = results
                    .iter()
                    .flat_map(|r| r.displayed.iter().map(|e| self.uri_to_path(&e.location.uri)))
                    .collect();
                paths.sort();
                paths.dedup();
                paths.join("\n")
            }
        }
    }

    fn format_enriched_references_single(&self, result: &EnrichedReferencesResult) -> String {
        match self.format {
            OutputFormat::Human => {
                if result.total_count == 0 {
                    return format!("No references found for: '{}'", result.label);
                }

                let mut output = format!(
                    "Found {} reference(s) for: '{}'\n\n",
                    result.total_count, result.label
                );

                for (i, enriched) in result.displayed.iter().enumerate() {
                    let file_path = self.uri_to_path(&enriched.location.uri);
                    let line = enriched.location.range.start.line + 1;
                    let column = enriched.location.range.start.character + 1;

                    let _ = writeln!(
                        output,
                        "{}. {file_path}:{line}:{column} ({})",
                        i + 1,
                        enriched.context
                    );

                    if let Some(src) = read_source_line(&file_path, line) {
                        let _ = writeln!(output, "   {src}");
                    }
                    output.push('\n');
                }

                if result.remaining_count > 0 {
                    let _ = writeln!(
                        output,
                        "... and {} more — use --references-limit 0 to show all",
                        result.remaining_count
                    );
                }

                output
            }
            OutputFormat::Json => {
                let val = Self::enriched_refs_to_json(result);
                serde_json::to_string_pretty(&val).unwrap_or_else(|_| "{}".to_string())
            }
            OutputFormat::Csv => {
                let mut output = String::from("file,line,column,context\n");
                for enriched in &result.displayed {
                    let file_path = self.uri_to_path(&enriched.location.uri);
                    let line = enriched.location.range.start.line + 1;
                    let column = enriched.location.range.start.character + 1;
                    let _ = writeln!(output, "{file_path},{line},{column},{}", enriched.context);
                }
                output
            }
            OutputFormat::Paths => {
                let mut paths: Vec<String> =
                    result.displayed.iter().map(|r| self.uri_to_path(&r.location.uri)).collect();
                paths.sort();
                paths.dedup();
                paths.join("\n")
            }
        }
    }

    fn enriched_refs_to_json(result: &EnrichedReferencesResult) -> serde_json::Value {
        let refs_json: Vec<serde_json::Value> = result
            .displayed
            .iter()
            .map(|r| {
                let file_path = r.location.uri.strip_prefix("file://").unwrap_or(&r.location.uri);
                serde_json::json!({
                    "file": file_path,
                    "line": r.location.range.start.line + 1,
                    "column": r.location.range.start.character + 1,
                    "context": r.context,
                })
            })
            .collect();

        serde_json::json!({
            "symbol": result.label,
            "reference_count": result.total_count,
            "references": refs_json,
        })
    }

    pub fn format_workspace_symbols(&self, symbols: &[SymbolInformation]) -> String {
        match self.format {
            OutputFormat::Human => {
                let mut output = String::new();

                for (i, symbol) in symbols.iter().enumerate() {
                    let file_path = self.uri_to_path(&symbol.location.uri);
                    let line = symbol.location.range.start.line + 1;
                    let column = symbol.location.range.start.character + 1;

                    let _ = write!(
                        output,
                        "{}. {} ({:?})\n   {file_path}:{line}:{column}\n\n",
                        i + 1,
                        symbol.name,
                        symbol.kind,
                    );
                }

                output
            }
            OutputFormat::Json => {
                serde_json::to_string_pretty(symbols).unwrap_or_else(|_| "[]".to_string())
            }
            OutputFormat::Csv => {
                let mut output = String::from("name,kind,file,line,column\n");
                for symbol in symbols {
                    let file_path = self.uri_to_path(&symbol.location.uri);
                    let line = symbol.location.range.start.line + 1;
                    let column = symbol.location.range.start.character + 1;
                    let _ = writeln!(
                        output,
                        "{},{:?},{file_path},{line},{column}",
                        symbol.name, symbol.kind,
                    );
                }
                output
            }
            OutputFormat::Paths => symbols
                .iter()
                .map(|symbol| self.uri_to_path(&symbol.location.uri))
                .collect::<Vec<_>>()
                .join("\n"),
        }
    }

    pub fn format_document_symbols(&self, symbols: &[DocumentSymbol]) -> String {
        match self.format {
            OutputFormat::Human => {
                let mut output = String::new();
                format_document_symbols_recursive(symbols, 0, &mut output);
                output
            }
            OutputFormat::Json => {
                serde_json::to_string_pretty(symbols).unwrap_or_else(|_| "[]".to_string())
            }
            OutputFormat::Csv => {
                let mut output = String::from("name,kind,line,column\n");
                format_document_symbols_csv(symbols, &mut output);
                output
            }
            OutputFormat::Paths => {
                // Paths format doesn't make sense for document symbols, fall back to human
                let mut output = String::new();
                format_document_symbols_recursive(symbols, 0, &mut output);
                output
            }
        }
    }

    fn extract_hover_text(contents: &HoverContents) -> String {
        match contents {
            HoverContents::Scalar(s) => s.clone(),
            HoverContents::Markup(markup) => markup.value.clone(),
            HoverContents::MarkedString(ms) => ms.value.clone(),
            HoverContents::Array(arr) => arr
                .iter()
                .map(|item| match item {
                    MarkedStringOrString::String(s) => s.clone(),
                    MarkedStringOrString::MarkedString(ms) => ms.value.clone(),
                })
                .collect::<Vec<_>>()
                .join("\n"),
        }
    }

    /// Extract just the type signature from hover, stripping docstrings and code fences.
    ///
    /// ty's hover markdown is structured as:
    ///   ```lang\n<type info>\n```\n---\nDocstring...
    ///
    /// Returns the bare type text without markdown fences or docstring.
    fn extract_hover_type(contents: &HoverContents) -> String {
        let full = Self::extract_hover_text(contents);

        // Strip docstring: everything after the first "\n---" separator
        let type_part = match full.find("\n---") {
            Some(pos) => &full[..pos],
            None => &full,
        };

        // Strip code fences (```python, ```xml, etc.)
        strip_code_fences(type_part)
    }

    /// Extract just the docstring portion from hover, if present.
    ///
    /// Returns `None` if there is no `---` separator (i.e. no docstring).
    fn extract_hover_doc(contents: &HoverContents) -> Option<String> {
        let full = Self::extract_hover_text(contents);
        let pos = full.find("\n---")?;
        let doc = full[pos + 4..].trim(); // skip "\n---"
        if doc.is_empty() {
            None
        } else {
            Some(doc.to_string())
        }
    }

    /// Short label for a `SymbolKind`, used in condensed output.
    fn kind_label(kind: &SymbolKind) -> &'static str {
        match kind {
            SymbolKind::Function => "func",
            SymbolKind::Method => "method",
            SymbolKind::Class => "class",
            SymbolKind::Variable => "var",
            SymbolKind::Constant => "const",
            SymbolKind::Module => "module",
            SymbolKind::Property => "prop",
            SymbolKind::Field => "field",
            SymbolKind::Constructor => "ctor",
            SymbolKind::Enum => "enum",
            SymbolKind::Interface => "iface",
            SymbolKind::Struct => "struct",
            SymbolKind::EnumMember => "member",
            SymbolKind::TypeParameter => "type",
            _ => "symbol",
        }
    }

    /// Write the type section content to `output`.
    ///
    /// For class definitions: shows decorators + source `class` line (preserves
    /// inheritance info that ty's hover strips away).
    /// For everything else: shows decorators + hover type (has inferred return types).
    /// Falls back to `empty_label` when no information is available.
    fn write_type_section(
        &self,
        output: &mut String,
        location: Option<&Location>,
        hover: Option<&Hover>,
        empty_label: &str,
    ) {
        if let Some(location) = location {
            let file_path = self.uri_to_path(&location.uri);
            if let Some(ctx) = read_definition_context(&file_path, location.range.start.line) {
                // Show decorators
                if let Some(decs) = &ctx.decorators {
                    output.push_str(decs);
                    output.push('\n');
                }
                // For classes, prefer the source definition line (shows inheritance)
                // over ty's bare `<class 'X'>` which doesn't.
                if ctx.definition_line.starts_with("class ") {
                    output.push_str(&ctx.definition_line);
                    output.push('\n');
                    return;
                }
            }
        }

        // Non-class or source not readable: use hover type
        if let Some(hover) = hover {
            output.push_str(&Self::extract_hover_type(&hover.contents));
            output.push('\n');
        } else {
            output.push_str(empty_label);
        }
    }

    /// Format a single symbol inspect, using the header level appropriate for context.
    /// `h_level` controls markdown heading depth (1 = `#`, 2 = `##`).
    fn format_inspect_human(&self, entry: &InspectEntry<'_>, h_level: u8) -> String {
        match self.detail {
            OutputDetail::Condensed => self.format_inspect_condensed(entry, h_level),
            OutputDetail::Full => self.format_inspect_full(entry, h_level),
        }
    }

    fn format_inspect_condensed(&self, entry: &InspectEntry<'_>, h_level: u8) -> String {
        let h = "#".repeat(h_level as usize);
        let mut output = String::new();

        // Def section — paths only, no source snippets (symbol name is already known)
        if let Some(kind) = entry.kind {
            let _ = writeln!(output, "{h} Def ({})", Self::kind_label(kind));
        } else {
            let _ = writeln!(output, "{h} Def");
        }
        if entry.definitions.is_empty() {
            output.push_str("(none)\n");
        } else {
            for location in entry.definitions {
                let file_path = self.uri_to_path(&location.uri);
                let line = location.range.start.line + 1;
                let column = location.range.start.character + 1;
                let _ = writeln!(output, "{file_path}:{line}:{column}");
            }
        }

        // Type section — always shown, compact placeholder when empty
        //
        // For classes: show the source definition line (e.g. `class Dog(Animal):`)
        // instead of ty's bare `<class 'Dog'>`, since the source line preserves
        // inheritance information that the hover response strips away.
        // For everything else: use the hover type which includes inferred types.
        let _ = writeln!(output, "\n{h} Type");
        self.write_type_section(&mut output, entry.definitions.first(), entry.hover, "(none)\n");

        // Doc section — only shown when a docstring is present
        if let Some(hover) = entry.hover {
            if let Some(doc) = Self::extract_hover_doc(&hover.contents) {
                let _ = writeln!(output, "\n{h} Doc");
                output.push_str(&doc);
                output.push('\n');
            }
        }

        // Refs section — always show count summary
        let _ = write!(output, "\n{h} Refs");
        if entry.total_reference_count == 0 {
            output.push_str(": none\n");
        } else {
            let _ = writeln!(
                output,
                ": {} across {} file(s)",
                entry.total_reference_count, entry.total_reference_files
            );
            if entry.show_individual_refs {
                for enriched in &entry.displayed_references {
                    let file_path = self.uri_to_path(&enriched.location.uri);
                    let line = enriched.location.range.start.line + 1;
                    let column = enriched.location.range.start.character + 1;
                    let _ = writeln!(output, "{file_path}:{line}:{column} ({})", enriched.context);
                }
                if entry.remaining_reference_count > 0 {
                    let _ = writeln!(
                        output,
                        "... and {} more — use --references-limit 0 to show all",
                        entry.remaining_reference_count
                    );
                }
            }
        }

        output
    }

    fn format_inspect_full(&self, entry: &InspectEntry<'_>, h_level: u8) -> String {
        let h = "#".repeat(h_level as usize);
        let h2 = "#".repeat(h_level as usize + 1);
        let mut output = format!("{h} Inspect: {}\n\n", entry.symbol);

        // Definition section
        let _ = writeln!(output, "{h2} Definition");
        if entry.definitions.is_empty() {
            output.push_str("No definitions found.\n");
        } else {
            for (i, location) in entry.definitions.iter().enumerate() {
                let file_path = self.uri_to_path(&location.uri);
                let line = location.range.start.line + 1;
                let column = location.range.start.character + 1;
                let _ = writeln!(output, "{}. {file_path}:{line}:{column}", i + 1);

                if let Some(src) = read_source_line(&file_path, line) {
                    let _ = writeln!(output, "   {src}");
                }
            }
        }
        output.push('\n');

        // Type section — same class-vs-other logic as condensed mode
        let _ = writeln!(output, "{h2} Type Info");
        self.write_type_section(
            &mut output,
            entry.definitions.first(),
            entry.hover,
            "No hover information available.\n",
        );
        output.push('\n');

        // References section — always show count summary
        let _ = writeln!(output, "{h2} References");
        if entry.total_reference_count == 0 {
            output.push_str("No references found.\n");
        } else {
            let _ = writeln!(
                output,
                "{} reference(s) across {} file(s):",
                entry.total_reference_count, entry.total_reference_files
            );
            if entry.show_individual_refs {
                for (i, enriched) in entry.displayed_references.iter().enumerate() {
                    let file_path = self.uri_to_path(&enriched.location.uri);
                    let line = enriched.location.range.start.line + 1;
                    let column = enriched.location.range.start.character + 1;
                    let _ = writeln!(
                        output,
                        "{}. {file_path}:{line}:{column} ({})",
                        i + 1,
                        enriched.context
                    );

                    if let Some(src) = read_source_line(&file_path, line) {
                        let _ = writeln!(output, "   {src}");
                    }
                }
                if entry.remaining_reference_count > 0 {
                    let _ = writeln!(
                        output,
                        "... and {} more — use --references-limit 0 to show all",
                        entry.remaining_reference_count
                    );
                }
            }
        }

        output
    }

    pub fn format_inspect(&self, entry: &InspectEntry<'_>) -> String {
        match self.format {
            OutputFormat::Human => self.format_inspect_human(entry, 1),
            OutputFormat::Json => Self::format_inspect_json_single(entry),
            OutputFormat::Csv => self.format_inspect_csv_single(entry, false),
            OutputFormat::Paths => self.format_inspect_paths_single(entry),
        }
    }

    fn format_inspect_json_single(entry: &InspectEntry<'_>) -> String {
        let refs_json: Vec<serde_json::Value> = entry
            .displayed_references
            .iter()
            .map(|r| {
                let file_path = r.location.uri.strip_prefix("file://").unwrap_or(&r.location.uri);
                serde_json::json!({
                    "file": file_path,
                    "line": r.location.range.start.line + 1,
                    "column": r.location.range.start.character + 1,
                    "context": r.context,
                })
            })
            .collect();

        let json_val = serde_json::json!({
            "symbol": entry.symbol,
            "kind": entry.kind.map(Self::kind_label),
            "definitions": entry.definitions,
            "hover": entry.hover,
            "reference_count": entry.total_reference_count,
            "reference_files": entry.total_reference_files,
            "references": refs_json,
        });
        serde_json::to_string_pretty(&json_val).unwrap_or_else(|_| "{}".to_string())
    }

    fn format_inspect_csv_single(&self, entry: &InspectEntry<'_>, include_symbol: bool) -> String {
        let header = if include_symbol {
            "symbol,section,file,line,column,context\n"
        } else {
            "section,file,line,column,context\n"
        };
        let mut output = String::from(header);
        let prefix = if include_symbol { format!("{},", entry.symbol) } else { String::new() };
        for location in entry.definitions {
            let file_path = self.uri_to_path(&location.uri);
            let line = location.range.start.line + 1;
            let column = location.range.start.character + 1;
            let _ = writeln!(output, "{prefix}definition,{file_path},{line},{column},");
        }
        for enriched in &entry.displayed_references {
            let file_path = self.uri_to_path(&enriched.location.uri);
            let line = enriched.location.range.start.line + 1;
            let column = enriched.location.range.start.character + 1;
            let _ = writeln!(
                output,
                "{prefix}reference,{file_path},{line},{column},{}",
                enriched.context
            );
        }
        output
    }

    fn format_inspect_paths_single(&self, entry: &InspectEntry<'_>) -> String {
        let mut paths: Vec<String> = entry
            .definitions
            .iter()
            .map(|loc| self.uri_to_path(&loc.uri))
            .chain(entry.displayed_references.iter().map(|r| self.uri_to_path(&r.location.uri)))
            .collect();
        paths.sort();
        paths.dedup();
        paths.join("\n")
    }

    /// Format results for one or more symbol inspect queries, grouped by symbol.
    pub fn format_inspect_results(&self, results: &[InspectEntry<'_>]) -> String {
        if results.len() == 1 {
            return self.format_inspect(&results[0]);
        }

        match self.format {
            OutputFormat::Human => {
                let mut output = String::new();
                for entry in results {
                    // Multi-symbol: symbol name gets top-level heading, sections get sub-headings
                    let _ = writeln!(output, "# {}", entry.symbol);
                    output.push_str(&self.format_inspect_human(entry, 2));
                    output.push('\n');
                }
                output.trim_end().to_string()
            }
            OutputFormat::Json => {
                let grouped: Vec<serde_json::Value> = results
                    .iter()
                    .map(|entry| {
                        serde_json::from_str(&Self::format_inspect_json_single(entry))
                            .unwrap_or_default()
                    })
                    .collect();
                serde_json::to_string_pretty(&grouped).unwrap_or_else(|_| "[]".to_string())
            }
            OutputFormat::Csv => {
                let mut output = String::from("symbol,section,file,line,column,context\n");
                for entry in results {
                    // Skip the header from each entry — we already wrote it
                    let entry_csv = self.format_inspect_csv_single(entry, true);
                    for line in entry_csv.lines().skip(1) {
                        output.push_str(line);
                        output.push('\n');
                    }
                }
                output
            }
            OutputFormat::Paths => {
                let mut paths: Vec<String> = results
                    .iter()
                    .flat_map(|entry| {
                        entry.definitions.iter().map(|loc| self.uri_to_path(&loc.uri)).chain(
                            entry
                                .displayed_references
                                .iter()
                                .map(|r| self.uri_to_path(&r.location.uri)),
                        )
                    })
                    .collect();
                paths.sort();
                paths.dedup();
                paths.join("\n")
            }
        }
    }
}

/// Categorize members into Methods, Properties, and Class variables.
#[cfg(unix)]
fn categorize_members(
    members: &[MemberInfo],
) -> (Vec<&MemberInfo>, Vec<&MemberInfo>, Vec<&MemberInfo>) {
    let mut methods = Vec::new();
    let mut properties = Vec::new();
    let mut class_vars = Vec::new();

    for m in members {
        match m.kind {
            SymbolKind::Method | SymbolKind::Function | SymbolKind::Constructor => {
                methods.push(m);
            }
            SymbolKind::Property => {
                properties.push(m);
            }
            _ => {
                class_vars.push(m);
            }
        }
    }

    (methods, properties, class_vars)
}

/// Format members as human-readable text for a single class.
#[cfg(unix)]
fn format_members_human(result: &MembersResult, file_path: &str) -> String {
    let mut output = String::new();

    let class_line = result.class_line + 1;
    let class_col = result.class_column + 1;
    let _ = writeln!(output, "{} ({file_path}:{class_line}:{class_col})", result.class_name);

    if result.members.is_empty() {
        let _ = writeln!(output, "  (no public members)");
        return output;
    }

    let (methods, properties, class_vars) = categorize_members(&result.members);

    if !methods.is_empty() {
        let _ = writeln!(output, "  Methods:");
        for m in &methods {
            let sig = m.signature.as_deref().unwrap_or(&m.name);
            let line = m.line + 1;
            let col = m.column + 1;
            let _ = writeln!(output, "    {sig:<60} :{line}:{col}");
        }
    }

    if !properties.is_empty() {
        let _ = writeln!(output, "  Properties:");
        for m in &properties {
            let sig = m.signature.as_deref().unwrap_or(&m.name);
            let line = m.line + 1;
            let col = m.column + 1;
            let _ = writeln!(output, "    {sig:<60} :{line}:{col}");
        }
    }

    if !class_vars.is_empty() {
        let _ = writeln!(output, "  Class variables:");
        for m in &class_vars {
            let sig = m.signature.as_deref().unwrap_or(&m.name);
            let line = m.line + 1;
            let col = m.column + 1;
            let _ = writeln!(output, "    {sig:<60} :{line}:{col}");
        }
    }

    output
}

#[cfg(unix)]
impl OutputFormatter {
    /// Format a single class members result.
    pub fn format_members_result(&self, result: &MembersResult) -> String {
        let file_path = self.uri_to_path(&result.file_uri);

        match self.format {
            OutputFormat::Human => format_members_human(result, &file_path),
            OutputFormat::Json => {
                serde_json::to_string_pretty(result).unwrap_or_else(|_| "{}".to_string())
            }
            OutputFormat::Csv => {
                let mut output = String::from("class,member,kind,signature,line,column\n");
                for m in &result.members {
                    let sig = m.signature.as_deref().unwrap_or("");
                    let line = m.line + 1;
                    let col = m.column + 1;
                    let _ = writeln!(
                        output,
                        "{},{},{},\"{}\",{line},{col}",
                        result.class_name,
                        m.name,
                        Self::kind_label(&m.kind),
                        sig.replace('"', "\"\""),
                    );
                }
                output
            }
            OutputFormat::Paths => file_path,
        }
    }

    /// Format results for one or more class members queries.
    pub fn format_members_results(&self, results: &[MembersResult]) -> String {
        if results.len() == 1 {
            return self.format_members_result(&results[0]);
        }

        match self.format {
            OutputFormat::Human => {
                let mut output = String::new();
                for result in results {
                    output.push_str(&self.format_members_result(result));
                    output.push('\n');
                }
                output.trim_end().to_string()
            }
            OutputFormat::Json => {
                serde_json::to_string_pretty(results).unwrap_or_else(|_| "[]".to_string())
            }
            OutputFormat::Csv => {
                let mut output = String::from("class,member,kind,signature,line,column\n");
                for result in results {
                    let file_path = self.uri_to_path(&result.file_uri);
                    let _ = file_path; // included in class context
                    for m in &result.members {
                        let sig = m.signature.as_deref().unwrap_or("");
                        let line = m.line + 1;
                        let col = m.column + 1;
                        let _ = writeln!(
                            output,
                            "{},{},{},\"{}\",{line},{col}",
                            result.class_name,
                            m.name,
                            Self::kind_label(&m.kind),
                            sig.replace('"', "\"\""),
                        );
                    }
                }
                output
            }
            OutputFormat::Paths => {
                let mut paths: Vec<String> =
                    results.iter().map(|r| self.uri_to_path(&r.file_uri)).collect();
                paths.sort();
                paths.dedup();
                paths.join("\n")
            }
        }
    }
}

fn format_document_symbols_recursive(
    symbols: &[DocumentSymbol],
    indent: usize,
    output: &mut String,
) {
    for symbol in symbols {
        let line = symbol.range.start.line + 1;
        let column = symbol.range.start.character + 1;
        let indent_str = "  ".repeat(indent);

        let _ = writeln!(
            output,
            "{indent_str}{} ({:?}) - line {line}, col {column}",
            symbol.name, symbol.kind,
        );

        if let Some(children) = &symbol.children {
            format_document_symbols_recursive(children, indent + 1, output);
        }
    }
}

fn format_document_symbols_csv(symbols: &[DocumentSymbol], output: &mut String) {
    for symbol in symbols {
        let line = symbol.range.start.line + 1;
        let column = symbol.range.start.character + 1;

        let _ = writeln!(output, "{},{:?},{line},{column}", symbol.name, symbol.kind);

        if let Some(children) = &symbol.children {
            format_document_symbols_csv(children, output);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::lsp::protocol::{Position, Range, SymbolKind};

    fn make_location(uri: &str, line: u32, character: u32) -> Location {
        Location {
            uri: uri.to_string(),
            range: Range {
                start: Position { line, character },
                end: Position { line, character: character + 5 },
            },
        }
    }

    #[test]
    fn test_format_definitions_empty() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let result = formatter.format_definitions(&[], "test:1:1");
        assert_eq!(result, "No definitions found for: test:1:1");
    }

    #[test]
    fn test_format_definitions_single() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let locations = [make_location("file:///nonexistent.py", 5, 10)];
        let result = formatter.format_definitions(&locations, "test:6:11");

        assert!(result.contains("Found 1 definition(s)"));
        assert!(result.contains("nonexistent.py:6:11"));
    }

    #[test]
    fn test_format_definitions_json() {
        let formatter = OutputFormatter::new(OutputFormat::Json);
        let locations = [make_location("file:///test.py", 0, 0)];
        let result = formatter.format_definitions(&locations, "test");

        let parsed: serde_json::Value = serde_json::from_str(&result).unwrap();
        assert!(parsed.is_array());
        assert_eq!(parsed[0]["uri"], "file:///test.py");
    }

    #[test]
    fn test_format_definitions_csv() {
        let formatter = OutputFormatter::new(OutputFormat::Csv);
        let locations = [make_location("file:///test.py", 4, 2)];
        let result = formatter.format_definitions(&locations, "test");

        assert!(result.starts_with("file,line,column\n"));
        assert!(result.contains("5,3")); // 0-based -> 1-based
    }

    #[test]
    fn test_format_find_results_single_symbol() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let locations = vec![make_location("file:///test.py", 0, 0)];
        let results = vec![("foo".to_string(), locations)];
        let result = formatter.format_find_results(&results);

        assert!(result.contains("Found 1 definition(s) for: 'foo'"));
    }

    #[test]
    fn test_format_find_results_symbol_not_found() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let results = vec![("missing".to_string(), vec![])];
        let result = formatter.format_find_results(&results);

        assert_eq!(result, "No definitions found for: 'missing'");
    }

    #[test]
    fn test_format_find_results_multiple_symbols() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let results = vec![
            ("foo".to_string(), vec![make_location("file:///test.py", 0, 0)]),
            ("bar".to_string(), vec![]),
        ];
        let result = formatter.format_find_results(&results);

        assert!(result.contains("=== foo ==="));
        assert!(result.contains("=== bar ==="));
        assert!(result.contains("No definitions found."));
    }

    #[test]
    fn test_format_enriched_references_empty() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let result = EnrichedReferencesResult {
            label: "test:1:1".to_string(),
            total_count: 0,
            displayed: Vec::new(),
            remaining_count: 0,
        };
        let output = formatter.format_enriched_references_results(&[result]);
        assert_eq!(output, "No references found for: 'test:1:1'");
    }

    #[test]
    fn test_format_workspace_symbols() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let symbols = vec![SymbolInformation {
            name: "MyClass".to_string(),
            kind: SymbolKind::Class,
            tags: None,
            deprecated: None,
            location: make_location("file:///test.py", 0, 0),
            container_name: None,
        }];
        let result = formatter.format_workspace_symbols(&symbols);

        assert!(result.contains("MyClass"));
        assert!(result.contains("Class"));
    }

    #[test]
    fn test_uri_to_path_with_file_prefix() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let result = formatter.uri_to_path("file:///some/path/test.py");
        // Should strip the file:// prefix
        assert!(!result.starts_with("file://"));
        assert!(result.contains("test.py"));
    }

    #[test]
    fn test_uri_to_path_without_file_prefix() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let result = formatter.uri_to_path("https://example.com");
        assert_eq!(result, "https://example.com");
    }

    fn make_entry<'a>(
        symbol: &'a str,
        kind: Option<&'a SymbolKind>,
        definitions: &'a [Location],
        hover: Option<&'a Hover>,
    ) -> InspectEntry<'a> {
        InspectEntry {
            symbol,
            kind,
            definitions,
            hover,
            total_reference_count: 0,
            total_reference_files: 0,
            displayed_references: Vec::new(),
            remaining_reference_count: 0,
            show_individual_refs: false,
        }
    }

    #[test]
    fn test_format_inspect_condensed_empty() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let entry = make_entry("missing", None, &[], None);
        let result = formatter.format_inspect(&entry);

        // Condensed: no symbol header for single symbol, short section names
        assert!(result.contains("# Def"));
        assert!(result.contains("(none)"));
        // Type and Refs sections always shown, even when empty (with "(none)" placeholder)
        assert!(result.contains("# Type"));
        assert!(result.contains("# Refs"));
    }

    #[test]
    fn test_format_inspect_refs_zero_count_condensed() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let defs = [make_location("file:///test.py", 0, 0)];
        let entry = InspectEntry {
            symbol: "Animal",
            kind: Some(&SymbolKind::Class),
            definitions: &defs,
            hover: None,
            total_reference_count: 0,
            total_reference_files: 0,
            displayed_references: Vec::new(),
            remaining_reference_count: 0,
            show_individual_refs: false,
        };
        let result = formatter.format_inspect(&entry);

        // Zero refs should show "Refs: none"
        assert!(
            result.contains("# Refs: none"),
            "should show 'Refs: none' for zero references, got:\n{result}"
        );
    }

    #[test]
    fn test_format_inspect_refs_count_without_individual_full() {
        let formatter = OutputFormatter::with_detail(OutputFormat::Human, OutputDetail::Full);
        let defs = [make_location("file:///test.py", 0, 0)];
        let entry = InspectEntry {
            symbol: "Animal",
            kind: Some(&SymbolKind::Class),
            definitions: &defs,
            hover: None,
            total_reference_count: 5,
            total_reference_files: 2,
            displayed_references: Vec::new(),
            remaining_reference_count: 0,
            show_individual_refs: false,
        };
        let result = formatter.format_inspect(&entry);

        // Should show count summary but no individual refs
        assert!(
            result.contains("5 reference(s) across 2 file(s)"),
            "should show reference count summary, got:\n{result}"
        );
    }

    #[test]
    fn test_format_inspect_condensed_with_kind() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let defs = [make_location("file:///test.py", 0, 0)];
        let entry = make_entry("foo", Some(&SymbolKind::Function), &defs, None);
        let result = formatter.format_inspect(&entry);

        assert!(result.contains("# Def (func)"));
        assert!(result.contains("test.py:1:1"));
    }

    #[test]
    fn test_format_inspect_full_empty() {
        let formatter = OutputFormatter::with_detail(OutputFormat::Human, OutputDetail::Full);
        let entry = make_entry("missing", None, &[], None);
        let result = formatter.format_inspect(&entry);

        assert!(result.contains("# Inspect: missing"));
        assert!(result.contains("## Definition"));
        assert!(result.contains("No definitions found."));
        assert!(result.contains("No hover information available."));
        assert!(result.contains("No references found."));
    }

    #[test]
    fn test_format_inspect_condensed_with_defs() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let defs = [make_location("file:///test.py", 0, 0)];
        let entry = make_entry("foo", None, &defs, None);
        let result = formatter.format_inspect(&entry);

        // Should show path:line:col on one line (no numbering)
        assert!(result.contains("test.py:1:1"));
        assert!(result.contains("# Def"));
        // No symbol name header for single symbol in condensed
        assert!(!result.contains("foo"));
    }

    #[test]
    fn test_format_inspect_json() {
        let formatter = OutputFormatter::new(OutputFormat::Json);
        let defs = [make_location("file:///test.py", 0, 0)];
        let entry = make_entry("foo", Some(&SymbolKind::Function), &defs, None);
        let result = formatter.format_inspect(&entry);

        let parsed: serde_json::Value = serde_json::from_str(&result).unwrap();
        assert_eq!(parsed["symbol"], "foo");
        assert_eq!(parsed["kind"], "func");
        assert!(parsed["definitions"].is_array());
    }

    #[test]
    fn test_read_source_line_valid() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "line 1\n  line 2\nline 3\n").unwrap();

        assert_eq!(read_source_line(file.to_str().unwrap(), 1), Some("line 1".to_string()));
        assert_eq!(read_source_line(file.to_str().unwrap(), 2), Some("line 2".to_string()));
        assert_eq!(read_source_line(file.to_str().unwrap(), 3), Some("line 3".to_string()));
        assert_eq!(read_source_line(file.to_str().unwrap(), 4), None);
    }

    #[test]
    fn test_read_source_line_nonexistent_file() {
        assert_eq!(read_source_line("/nonexistent/file.py", 1), None);
    }

    #[test]
    fn test_extract_hover_type_strips_docstring() {
        use crate::lsp::protocol::{HoverContents, MarkupContent};

        let contents = HoverContents::Markup(MarkupContent {
            kind: crate::lsp::protocol::MarkupKind::Markdown,
            value: "```xml\n<class 'Animal'>\n```\n---\nBase class for animals.".to_string(),
        });

        let result = OutputFormatter::extract_hover_type(&contents);
        // Should strip docstring after ---
        assert!(!result.contains("Base class"));
        assert!(!result.contains("---"));
        // Should strip code fences
        assert!(!result.contains("```"), "should not contain code fences, got: {result}");
        assert_eq!(result, "<class 'Animal'>");
    }

    #[test]
    fn test_extract_hover_type_no_docstring() {
        use crate::lsp::protocol::{HoverContents, MarkupContent};

        let contents = HoverContents::Markup(MarkupContent {
            kind: crate::lsp::protocol::MarkupKind::Markdown,
            value: "```python\ndef hello_world() -> Unknown\n```".to_string(),
        });

        let result = OutputFormatter::extract_hover_type(&contents);
        assert!(result.contains("def hello_world() -> Unknown"));
        // No xml tag to replace
        assert!(!result.contains("xml"));
    }

    #[test]
    fn test_extract_hover_doc() {
        use crate::lsp::protocol::{HoverContents, MarkupContent};

        let with_doc = HoverContents::Markup(MarkupContent {
            kind: crate::lsp::protocol::MarkupKind::Markdown,
            value: "```xml\n<class 'Animal'>\n```\n---\nBase class for animals.".to_string(),
        });
        assert_eq!(
            OutputFormatter::extract_hover_doc(&with_doc),
            Some("Base class for animals.".to_string())
        );

        let without_doc = HoverContents::Markup(MarkupContent {
            kind: crate::lsp::protocol::MarkupKind::Markdown,
            value: "```python\ndef foo() -> int\n```".to_string(),
        });
        assert_eq!(OutputFormatter::extract_hover_doc(&without_doc), None);
    }

    #[test]
    fn test_condensed_inspect_separates_doc() {
        use crate::lsp::protocol::{Hover, HoverContents, MarkupContent, Range};

        let formatter = OutputFormatter::new(OutputFormat::Human);
        let defs = [make_location("file:///test.py", 3, 6)];
        let hover = Hover {
            contents: HoverContents::Markup(MarkupContent {
                kind: crate::lsp::protocol::MarkupKind::Markdown,
                value: "```xml\n<class 'Animal'>\n```\n---\nBase class for animals.".to_string(),
            }),
            range: Some(Range {
                start: crate::lsp::protocol::Position { line: 3, character: 6 },
                end: crate::lsp::protocol::Position { line: 3, character: 12 },
            }),
        };
        let entry = make_entry("Animal", Some(&SymbolKind::Class), &defs, Some(&hover));
        let result = formatter.format_inspect(&entry);

        // Type section should have the class type without code fences or docstring
        assert!(
            result.contains("# Type\n<class 'Animal'>"),
            "type section should contain bare type, got:\n{result}"
        );
        assert!(!result.contains("```"), "should not contain code fences, got:\n{result}");
        // Doc section should have the docstring separately
        assert!(result.contains("# Doc\nBase class for animals."));
        // No raw --- separator in output
        assert!(!result.contains("\n---\n"));
    }

    #[test]
    fn test_extract_hover_type_strips_code_fences() {
        use crate::lsp::protocol::{HoverContents, MarkupContent};

        let contents = HoverContents::Markup(MarkupContent {
            kind: crate::lsp::protocol::MarkupKind::Markdown,
            value: "```python\ndef hello_world() -> str\n```".to_string(),
        });

        let result = OutputFormatter::extract_hover_type(&contents);
        // Should NOT contain backtick fences
        assert!(!result.contains("```"), "type should not contain code fences, got: {result}");
        assert_eq!(result, "def hello_world() -> str");
    }

    #[test]
    fn test_extract_hover_type_strips_xml_fences() {
        use crate::lsp::protocol::{HoverContents, MarkupContent};

        let contents = HoverContents::Markup(MarkupContent {
            kind: crate::lsp::protocol::MarkupKind::Markdown,
            value: "```xml\n<class 'Animal'>\n```\n---\nBase class for animals.".to_string(),
        });

        let result = OutputFormatter::extract_hover_type(&contents);
        assert!(!result.contains("```"), "type should not contain code fences, got: {result}");
        assert_eq!(result, "<class 'Animal'>");
    }

    #[test]
    fn test_read_decorators_single() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "@dataclass\nclass Config:\n    host: str\n").unwrap();

        let result = read_decorators(file.to_str().unwrap(), 0);
        assert_eq!(result, Some("@dataclass".to_string()));
    }

    #[test]
    fn test_read_decorators_multiple() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "@some_decorator\n@another_decorator\ndef my_func():\n    pass\n")
            .unwrap();

        let result = read_decorators(file.to_str().unwrap(), 0);
        assert_eq!(result, Some("@some_decorator\n@another_decorator".to_string()));
    }

    #[test]
    fn test_read_decorators_none() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "class Config:\n    host: str\n").unwrap();

        let result = read_decorators(file.to_str().unwrap(), 0);
        assert_eq!(result, None);
    }

    #[test]
    fn test_read_decorators_nonexistent_file() {
        assert_eq!(read_decorators("/nonexistent/file.py", 0), None);
    }

    #[test]
    fn test_condensed_inspect_shows_decorators() {
        use crate::lsp::protocol::{Hover, HoverContents, MarkupContent, Range};

        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "@dataclass\nclass Config:\n    host: str\n").unwrap();

        let file_uri = format!("file://{}", file.to_str().unwrap());
        let formatter = OutputFormatter::new(OutputFormat::Human);
        // Definition starts at the decorator line (line 0)
        let defs = [make_location(&file_uri, 0, 0)];
        let hover = Hover {
            contents: HoverContents::Markup(MarkupContent {
                kind: crate::lsp::protocol::MarkupKind::Markdown,
                value: "```xml\n<class 'Config'>\n```".to_string(),
            }),
            range: Some(Range {
                start: crate::lsp::protocol::Position { line: 1, character: 6 },
                end: crate::lsp::protocol::Position { line: 1, character: 12 },
            }),
        };
        let entry = make_entry("Config", Some(&SymbolKind::Class), &defs, Some(&hover));
        let result = formatter.format_inspect(&entry);

        // Type section should show decorator + source class definition
        assert!(
            result.contains("@dataclass\nclass Config:"),
            "should show decorator and class definition in type section, got:\n{result}"
        );
        // No code fences
        assert!(!result.contains("```"), "should not contain code fences, got:\n{result}");
    }

    #[test]
    fn test_condensed_inspect_no_decorator_no_crash() {
        use crate::lsp::protocol::{Hover, HoverContents, MarkupContent, Range};

        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "class Animal:\n    pass\n").unwrap();

        let file_uri = format!("file://{}", file.to_str().unwrap());
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let defs = [make_location(&file_uri, 0, 0)];
        let hover = Hover {
            contents: HoverContents::Markup(MarkupContent {
                kind: crate::lsp::protocol::MarkupKind::Markdown,
                value: "```xml\n<class 'Animal'>\n```".to_string(),
            }),
            range: Some(Range {
                start: crate::lsp::protocol::Position { line: 0, character: 6 },
                end: crate::lsp::protocol::Position { line: 0, character: 12 },
            }),
        };
        let entry = make_entry("Animal", Some(&SymbolKind::Class), &defs, Some(&hover));
        let result = formatter.format_inspect(&entry);

        // Should show source class line (no decorator, no inheritance)
        assert!(
            result.contains("# Type\nclass Animal:"),
            "should show source class definition, got:\n{result}"
        );
    }

    #[test]
    fn test_read_definition_line_class() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "class Dog(Animal):\n    pass\n").unwrap();

        let result = read_definition_line(file.to_str().unwrap(), 0);
        assert_eq!(result, Some("class Dog(Animal):".to_string()));
    }

    #[test]
    fn test_read_definition_line_with_decorators() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "@dataclass\nclass Config(Base):\n    host: str\n").unwrap();

        // Starting at decorator line, should skip decorators and return class line
        let result = read_definition_line(file.to_str().unwrap(), 0);
        assert_eq!(result, Some("class Config(Base):".to_string()));
    }

    #[test]
    fn test_read_definition_line_no_inheritance() {
        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "class Animal:\n    pass\n").unwrap();

        let result = read_definition_line(file.to_str().unwrap(), 0);
        assert_eq!(result, Some("class Animal:".to_string()));
    }

    #[test]
    fn test_condensed_inspect_class_shows_source_definition() {
        use crate::lsp::protocol::{Hover, HoverContents, MarkupContent, Range};

        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "class Dog(Animal):\n    pass\n").unwrap();

        let file_uri = format!("file://{}", file.to_str().unwrap());
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let defs = [make_location(&file_uri, 0, 6)];
        let hover = Hover {
            contents: HoverContents::Markup(MarkupContent {
                kind: crate::lsp::protocol::MarkupKind::Markdown,
                value: "```xml\n<class 'Dog'>\n```\n---\nA dog.".to_string(),
            }),
            range: Some(Range {
                start: crate::lsp::protocol::Position { line: 0, character: 6 },
                end: crate::lsp::protocol::Position { line: 0, character: 9 },
            }),
        };
        let entry = make_entry("Dog", Some(&SymbolKind::Class), &defs, Some(&hover));
        let result = formatter.format_inspect(&entry);

        // Type section should show source class line with inheritance, not <class 'Dog'>
        assert!(
            result.contains("class Dog(Animal):"),
            "should show class definition with base class, got:\n{result}"
        );
        assert!(
            !result.contains("<class 'Dog'>"),
            "should NOT show bare <class> tag, got:\n{result}"
        );
    }

    #[test]
    fn test_condensed_inspect_decorated_class_with_inheritance() {
        use crate::lsp::protocol::{Hover, HoverContents, MarkupContent, Range};

        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "@dataclass\nclass AppConfig(Config):\n    debug: bool\n").unwrap();

        let file_uri = format!("file://{}", file.to_str().unwrap());
        let formatter = OutputFormatter::new(OutputFormat::Human);
        // Definition starts at the decorator line (line 0)
        let defs = [make_location(&file_uri, 0, 0)];
        let hover = Hover {
            contents: HoverContents::Markup(MarkupContent {
                kind: crate::lsp::protocol::MarkupKind::Markdown,
                value: "```xml\n<class 'AppConfig'>\n```".to_string(),
            }),
            range: Some(Range {
                start: crate::lsp::protocol::Position { line: 1, character: 6 },
                end: crate::lsp::protocol::Position { line: 1, character: 15 },
            }),
        };
        let entry = make_entry("AppConfig", Some(&SymbolKind::Class), &defs, Some(&hover));
        let result = formatter.format_inspect(&entry);

        // Should show decorator + source class line with inheritance
        assert!(
            result.contains("@dataclass\nclass AppConfig(Config):"),
            "should show decorator and class definition, got:\n{result}"
        );
    }

    #[test]
    fn test_condensed_inspect_function_keeps_hover_type() {
        use crate::lsp::protocol::{Hover, HoverContents, MarkupContent, Range};

        let dir = tempfile::tempdir().unwrap();
        let file = dir.path().join("test.py");
        std::fs::write(&file, "def hello_world():\n    return 'hi'\n").unwrap();

        let file_uri = format!("file://{}", file.to_str().unwrap());
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let defs = [make_location(&file_uri, 0, 4)];
        let hover = Hover {
            contents: HoverContents::Markup(MarkupContent {
                kind: crate::lsp::protocol::MarkupKind::Markdown,
                value: "```python\ndef hello_world() -> str\n```".to_string(),
            }),
            range: Some(Range {
                start: crate::lsp::protocol::Position { line: 0, character: 4 },
                end: crate::lsp::protocol::Position { line: 0, character: 15 },
            }),
        };
        let entry = make_entry("hello_world", Some(&SymbolKind::Function), &defs, Some(&hover));
        let result = formatter.format_inspect(&entry);

        // Functions should still show the hover type (has inferred return type)
        assert!(
            result.contains("def hello_world() -> str"),
            "function should show hover type with inferred return type, got:\n{result}"
        );
    }

    #[cfg(unix)]
    mod members_tests {
        use super::*;
        use crate::daemon::protocol::{MemberInfo, MembersResult};

        fn make_members_result() -> MembersResult {
            MembersResult {
                class_name: "Animal".to_string(),
                file_uri: "file:///src/models.py".to_string(),
                class_line: 4,
                class_column: 0,
                symbol_kind: Some(SymbolKind::Class),
                members: vec![
                    MemberInfo {
                        name: "speak".to_string(),
                        kind: SymbolKind::Method,
                        signature: Some("speak(self) -> str".to_string()),
                        line: 10,
                        column: 4,
                    },
                    MemberInfo {
                        name: "name".to_string(),
                        kind: SymbolKind::Property,
                        signature: Some("name: str".to_string()),
                        line: 7,
                        column: 4,
                    },
                    MemberInfo {
                        name: "MAX_LEGS".to_string(),
                        kind: SymbolKind::Variable,
                        signature: Some("MAX_LEGS: int".to_string()),
                        line: 5,
                        column: 4,
                    },
                ],
            }
        }

        #[test]
        fn test_format_members_human() {
            let formatter = OutputFormatter::new(OutputFormat::Human);
            let result = make_members_result();
            let output = formatter.format_members_result(&result);

            assert!(output.contains("Animal"), "should show class name");
            assert!(output.contains(":5:1"), "should show class location (1-based)");
            assert!(output.contains("Methods:"), "should have Methods section");
            assert!(output.contains("speak(self) -> str"), "should show method sig");
            assert!(output.contains("Properties:"), "should have Properties section");
            assert!(output.contains("name: str"), "should show property sig");
            assert!(output.contains("Class variables:"), "should have Class variables section");
            assert!(output.contains("MAX_LEGS: int"), "should show class var sig");
        }

        #[test]
        fn test_format_members_json() {
            let formatter = OutputFormatter::new(OutputFormat::Json);
            let result = make_members_result();
            let output = formatter.format_members_result(&result);

            let parsed: serde_json::Value = serde_json::from_str(&output).unwrap();
            assert_eq!(parsed["class_name"], "Animal");
            assert!(parsed["members"].is_array());
            assert_eq!(parsed["members"].as_array().unwrap().len(), 3);
        }

        #[test]
        fn test_format_members_csv() {
            let formatter = OutputFormatter::new(OutputFormat::Csv);
            let result = make_members_result();
            let output = formatter.format_members_result(&result);

            assert!(output.starts_with("class,member,kind,signature,line,column\n"));
            assert!(output.contains("Animal,speak,method"));
            assert!(output.contains("Animal,name,prop"));
            assert!(output.contains("Animal,MAX_LEGS,var"));
        }

        #[test]
        fn test_format_members_paths() {
            let formatter = OutputFormatter::new(OutputFormat::Paths);
            let result = make_members_result();
            let output = formatter.format_members_result(&result);

            assert!(output.contains("models.py"));
        }

        #[test]
        fn test_format_members_empty_class() {
            let formatter = OutputFormatter::new(OutputFormat::Human);
            let result = MembersResult {
                class_name: "Empty".to_string(),
                file_uri: "file:///empty.py".to_string(),
                class_line: 0,
                class_column: 0,
                symbol_kind: Some(SymbolKind::Class),
                members: Vec::new(),
            };
            let output = formatter.format_members_result(&result);

            assert!(output.contains("Empty"));
            assert!(output.contains("(no public members)"));
        }

        #[test]
        fn test_format_members_multiple_classes() {
            let formatter = OutputFormatter::new(OutputFormat::Human);
            let results = vec![
                make_members_result(),
                MembersResult {
                    class_name: "Dog".to_string(),
                    file_uri: "file:///src/models.py".to_string(),
                    class_line: 20,
                    class_column: 0,
                    symbol_kind: Some(SymbolKind::Class),
                    members: vec![MemberInfo {
                        name: "fetch".to_string(),
                        kind: SymbolKind::Method,
                        signature: Some("fetch(self, item: str) -> str".to_string()),
                        line: 25,
                        column: 4,
                    }],
                },
            ];
            let output = formatter.format_members_results(&results);

            assert!(output.contains("Animal"), "should show first class");
            assert!(output.contains("Dog"), "should show second class");
            assert!(output.contains("fetch(self, item: str) -> str"));
        }
    }

    // ── Enclosing symbol tree walk tests ───────────────────────────────

    fn make_doc_symbol(
        name: &str,
        kind: SymbolKind,
        start_line: u32,
        end_line: u32,
        children: Option<Vec<DocumentSymbol>>,
    ) -> DocumentSymbol {
        DocumentSymbol {
            name: name.to_string(),
            detail: None,
            kind,
            tags: None,
            deprecated: None,
            range: Range {
                start: Position { line: start_line, character: 0 },
                end: Position { line: end_line, character: 0 },
            },
            selection_range: Range {
                start: Position { line: start_line, character: 0 },
                #[allow(clippy::cast_possible_truncation)]
                end: Position { line: start_line, character: name.len() as u32 },
            },
            children,
        }
    }

    #[test]
    fn test_find_enclosing_symbol_top_level_function() {
        let symbols = vec![make_doc_symbol("my_func", SymbolKind::Function, 5, 15, None)];

        assert_eq!(find_enclosing_symbol(&symbols, 10, 4), Some("my_func".to_string()));
    }

    #[test]
    fn test_find_enclosing_symbol_nested_method() {
        let method = make_doc_symbol("process", SymbolKind::Method, 10, 20, None);
        let class = make_doc_symbol("RequestHandler", SymbolKind::Class, 5, 30, Some(vec![method]));
        let symbols = vec![class];

        assert_eq!(
            find_enclosing_symbol(&symbols, 15, 8),
            Some("RequestHandler.process".to_string())
        );
    }

    #[test]
    fn test_find_enclosing_symbol_module_scope() {
        let symbols = vec![make_doc_symbol("my_func", SymbolKind::Function, 5, 15, None)];

        // Position outside any symbol → module scope (None)
        assert_eq!(find_enclosing_symbol(&symbols, 2, 0), None);
    }

    #[test]
    fn test_find_enclosing_symbol_empty_tree() {
        assert_eq!(find_enclosing_symbol(&[], 10, 5), None);
    }

    #[test]
    fn test_find_enclosing_symbol_class_level_not_in_method() {
        let method = make_doc_symbol("process", SymbolKind::Method, 10, 20, None);
        let class = make_doc_symbol("RequestHandler", SymbolKind::Class, 5, 30, Some(vec![method]));
        let symbols = vec![class];

        // Position in class but outside the method
        assert_eq!(find_enclosing_symbol(&symbols, 7, 0), Some("RequestHandler".to_string()));
    }

    #[test]
    fn test_find_enclosing_symbol_deeply_nested() {
        let inner_method = make_doc_symbol("inner_method", SymbolKind::Method, 15, 18, None);
        let inner_class =
            make_doc_symbol("InnerClass", SymbolKind::Class, 12, 20, Some(vec![inner_method]));
        let outer_class =
            make_doc_symbol("OuterClass", SymbolKind::Class, 5, 30, Some(vec![inner_class]));
        let symbols = vec![outer_class];

        assert_eq!(
            find_enclosing_symbol(&symbols, 16, 4),
            Some("OuterClass.InnerClass.inner_method".to_string())
        );
    }

    // ── Enriched inspect output tests ──────────────────────────────────

    #[test]
    fn test_format_inspect_with_ref_count_condensed() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let defs = [make_location("file:///test.py", 0, 0)];
        let entry = InspectEntry {
            symbol: "my_func",
            kind: Some(&SymbolKind::Function),
            definitions: &defs,
            hover: None,
            total_reference_count: 47,
            total_reference_files: 12,
            displayed_references: Vec::new(),
            remaining_reference_count: 0,
            show_individual_refs: false,
        };
        let result = formatter.format_inspect(&entry);

        assert!(
            result.contains("# Refs: 47 across 12 file(s)"),
            "should show reference count summary, got:\n{result}"
        );
    }

    #[test]
    fn test_format_inspect_with_enriched_refs_condensed() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let defs = [make_location("file:///test.py", 0, 0)];
        let enriched = vec![
            EnrichedReference {
                location: make_location("file:///src/main.py", 44, 11),
                context: "RequestHandler.process".to_string(),
            },
            EnrichedReference {
                location: make_location("file:///src/main.py", 2, 0),
                context: "module scope".to_string(),
            },
        ];
        let entry = InspectEntry {
            symbol: "my_func",
            kind: Some(&SymbolKind::Function),
            definitions: &defs,
            hover: None,
            total_reference_count: 5,
            total_reference_files: 2,
            displayed_references: enriched,
            remaining_reference_count: 3,
            show_individual_refs: true,
        };
        let result = formatter.format_inspect(&entry);

        assert!(result.contains("# Refs: 5 across 2 file(s)"), "should show count, got:\n{result}");
        assert!(result.contains("(RequestHandler.process)"), "should show context, got:\n{result}");
        assert!(
            result.contains("(module scope)"),
            "should show module scope context, got:\n{result}"
        );
        assert!(result.contains("... and 3 more"), "should show remaining count, got:\n{result}");
    }

    #[test]
    fn test_format_inspect_json_includes_context() {
        let formatter = OutputFormatter::new(OutputFormat::Json);
        let defs = [make_location("file:///test.py", 0, 0)];
        let enriched = vec![EnrichedReference {
            location: make_location("file:///src/main.py", 44, 11),
            context: "RequestHandler.process".to_string(),
        }];
        let entry = InspectEntry {
            symbol: "my_func",
            kind: Some(&SymbolKind::Function),
            definitions: &defs,
            hover: None,
            total_reference_count: 1,
            total_reference_files: 1,
            displayed_references: enriched,
            remaining_reference_count: 0,
            show_individual_refs: true,
        };
        let result = formatter.format_inspect(&entry);
        let parsed: serde_json::Value = serde_json::from_str(&result).unwrap();

        assert_eq!(parsed["reference_count"], 1);
        assert_eq!(parsed["reference_files"], 1);
        assert_eq!(parsed["references"][0]["context"], "RequestHandler.process");
    }

    #[test]
    fn test_format_enriched_references_with_limit() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        let result = EnrichedReferencesResult {
            label: "my_func".to_string(),
            total_count: 50,
            displayed: vec![EnrichedReference {
                location: make_location("file:///src/main.py", 10, 5),
                context: "Handler.process".to_string(),
            }],
            remaining_count: 49,
        };
        let output = formatter.format_enriched_references_results(&[result]);

        assert!(
            output.contains("Found 50 reference(s)"),
            "should show total count, got:\n{output}"
        );
        assert!(output.contains("(Handler.process)"), "should show context, got:\n{output}");
        assert!(output.contains("... and 49 more"), "should show remaining, got:\n{output}");
    }

    #[test]
    fn test_format_enriched_references_json() {
        let formatter = OutputFormatter::new(OutputFormat::Json);
        let result = EnrichedReferencesResult {
            label: "my_func".to_string(),
            total_count: 2,
            displayed: vec![EnrichedReference {
                location: make_location("file:///src/main.py", 10, 5),
                context: "Handler.process".to_string(),
            }],
            remaining_count: 1,
        };
        let output = formatter.format_enriched_references_results(&[result]);
        let parsed: serde_json::Value = serde_json::from_str(&output).unwrap();

        assert_eq!(parsed["reference_count"], 2);
        assert_eq!(parsed["references"][0]["context"], "Handler.process");
    }

    #[test]
    fn test_format_enriched_references_limit_zero_shows_all() {
        let formatter = OutputFormatter::new(OutputFormat::Human);
        // When limit is 0, remaining_count should be 0 (all displayed)
        let result = EnrichedReferencesResult {
            label: "my_func".to_string(),
            total_count: 3,
            displayed: vec![
                EnrichedReference {
                    location: make_location("file:///a.py", 1, 0),
                    context: "module scope".to_string(),
                },
                EnrichedReference {
                    location: make_location("file:///b.py", 2, 0),
                    context: "foo".to_string(),
                },
                EnrichedReference {
                    location: make_location("file:///c.py", 3, 0),
                    context: "bar".to_string(),
                },
            ],
            remaining_count: 0,
        };
        let output = formatter.format_enriched_references_results(&[result]);

        assert!(
            !output.contains("... and"),
            "should not show truncation message when all displayed, got:\n{output}"
        );
        assert!(output.contains("Found 3 reference(s)"), "should show total count, got:\n{output}");
    }
}
