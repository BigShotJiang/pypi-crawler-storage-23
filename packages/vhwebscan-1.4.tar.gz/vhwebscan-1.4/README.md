# Viethas Website Scan v1.4
## Tính năng mới
- Cập nhật version 1.4 xóa code debug.