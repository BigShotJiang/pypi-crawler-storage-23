"""High-level entry point orchestrating runtime and RabbitMQ runner.

This module provides the main entry point used by provider runtime_app.py files.
It wires together ProviderRuntime (business logic) and RabbitMQRunner (transport).

Usage:
    from osp_provider_runtime import RuntimeConfig, run_provider_with_config
    from my_provider import MyProvider

    config = RuntimeConfig(...)
    run_provider_with_config(MyProvider(), config)

Notes:
    - Blocks until interrupted (SIGTERM, KeyboardInterrupt)
    - Calls runtime.close() in finally block to clean up timeout executor
"""

from __future__ import annotations

from osp_provider_contracts import Provider

from .config import RuntimeConfig
from .rabbitmq import RabbitMQRunner
from .runtime import ProviderRuntime


def run_provider_with_config(provider: Provider, config: RuntimeConfig) -> None:
    """Run provider with RabbitMQ transport until interrupted.

    This is the main entry point for provider daemons. Constructs ProviderRuntime
    and RabbitMQRunner, wires them together, and blocks until SIGTERM/KeyboardInterrupt.

    Why separate runtime and runner:
        - ProviderRuntime = testable business logic (no RabbitMQ dependency)
        - RabbitMQRunner = transport layer (pika-specific)

    Args:
        provider: Provider implementation conforming to osp_provider_contracts.Provider.
        config: Runtime configuration (RabbitMQ URL, queue, concurrency, etc.).

    Raises:
        RuntimeError: Propagates exceptions raised by `RabbitMQRunner.run()`.

    Notes:
        - runtime.close() is called in finally block even if runner crashes
        - Graceful shutdown: executor waits for in-flight handlers, then closes connection
    """
    runtime = ProviderRuntime(provider=provider, config=config)
    runner = RabbitMQRunner(config)
    try:
        runner.run(runtime.handle_delivery)
    finally:
        runtime.close()
