"""Thin RabbitMQ runtime harness for OSP providers.

This package handles message transport plumbing (contract envelope parsing,
RabbitMQ ack/nack, retries with exponential backoff, update emission) so
provider implementations can focus on business logic.

Key responsibilities:
    - Parse contract request envelopes (`contract_v1`)
    - Build provider RequestContext/ProviderRequest from envelope
    - Call provider.execute() with optional timeout enforcement
    - Serialize response envelopes and task updates
    - Apply explicit ack/requeue/dead-letter decisions based on retry logic
    - Emit structured logs for debugging and audit

Compatibility note:
    - Task updates remain legacy-orchestrator wire compatible until the
      orchestrator update consumer switches to a contract envelope.

Threading model:
    - RabbitMQ channel operations run on pika connection thread
    - Provider.execute() runs on ThreadPoolExecutor (configurable concurrency)
    - Timeout enforcement uses separate single-thread executor

Usage:
    from osp_provider_runtime import RuntimeConfig, run_provider_with_config

    config = RuntimeConfig(
        rabbitmq_url="amqp://guest:guest@localhost:5672/",
        request_queue="provider.vmware.tasks",
        request_binding="provider.vmware",
        provider_name="vmware",
        updates_routing_key="vmware",
        concurrency=4,
    )
    run_provider_with_config(my_provider, config)

Contracts:
    - Provider must implement osp_provider_contracts.Provider protocol
    - RuntimeConfig.provider_name and updates_routing_key must be set
    - Exponential backoff parameters control retry timing (not max_attempts)
    - Prefetch is max(prefetch_count, concurrency) to avoid starvation
"""

from .app import run_provider_with_config
from .config import RuntimeConfig
from .runtime import ProviderRuntime
from .updates import ProviderUpdate, TaskReporter
from .version import __version__

__all__ = [
    "__version__",
    "ProviderRuntime",
    "ProviderUpdate",
    "RuntimeConfig",
    "TaskReporter",
    "run_provider_with_config",
]
