"""Transport-agnostic delivery and ack decision types.

Decouples ProviderRuntime business logic from RabbitMQ-specific ack/nack mechanics.
ProviderRuntime returns DeliveryResult, RabbitMQRunner translates to pika calls.

Why three ack actions:
    - ACK: Success or non-retryable error (message processed, remove from queue)
    - REQUEUE: Retryable error with attempts remaining (exponential backoff retry)
    - DEAD_LETTER: Retryable error with attempts exhausted, or malformed envelope

Why not pika.Channel directly:
    - ProviderRuntime should be testable without RabbitMQ (use fake transport)
    - Separates concerns: runtime = business logic, rabbitmq = transport

Contracts:
    - Delivery is immutable input (what we received)
    - DeliveryResult is immutable output (what to do next)
    - RabbitMQRunner maps AckAction to pika basic_ack/basic_nack
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class AckAction(StrEnum):
    """Ack decision for a delivery.

    Maps to RabbitMQ basic_ack/basic_nack:
        - ACK: basic_ack(delivery_tag)
        - REQUEUE: Republish with incremented attempt, then basic_ack (not basic_nack requeue=True)
            Why republish: Allows exponential backoff delay before requeue
        - DEAD_LETTER: basic_nack(delivery_tag, requeue=False)
    """

    ACK = "ack"
    REQUEUE = "requeue"
    DEAD_LETTER = "dead_letter"


@dataclass(frozen=True, slots=True)
class Delivery:
    """Inbound message delivery from transport.

    Attributes:
        body: Raw message bytes (JSON envelope).
        reply_to: Optional RPC reply queue (used for capabilities requests).
        routing_key: Delivery routing key (for logging/debugging).
        correlation_id: RabbitMQ correlation ID (for RPC correlation).
    """

    body: bytes
    reply_to: str | None
    routing_key: str | None = None
    correlation_id: str | None = None


@dataclass(frozen=True, slots=True)
class DeliveryResult:
    """Handler result instructing transport how to ack and respond.

    Why response_* and update_* fields:
        - response_*: RPC reply to orchestrator (synchronous, via reply_to queue)
        - update_*: Async task update published to updates exchange (for task events)

    Attributes:
        ack_action: How to ack this delivery (ACK, REQUEUE, DEAD_LETTER).
        response_body: Optional RPC response bytes (sent to reply_to queue).
        response_routing_key: Usually delivery.reply_to (RPC reply queue).
        response_correlation_id: Echoed correlation_id for RPC correlation.
        update_body: Optional task update bytes (sent to updates exchange).
        update_exchange: Exchange for task updates (usually "osp.to_orch").
        update_routing_key: Routing key for updates (usually provider name).
    """

    ack_action: AckAction
    response_body: bytes | None = None
    response_routing_key: str | None = None
    response_correlation_id: str | None = None
    update_body: bytes | None = None
    update_exchange: str | None = None
    update_routing_key: str | None = None
