"""Request/response envelope parsing for contract_v1 messages.

Runtime now requires the versioned contract envelope shape:
    {"envelope_version": "1.0", ...} with payload nesting.

Why envelope_version + contract_version:
    - envelope_version: wire format version (controls parsing logic)
    - contract_version: provider protocol version (future: allows multi-version support)

Contracts:
    - RequestEnvelope.source_format is always "contract_v1"
    - legacy_task_id remains for backward type compatibility and is always None
    - ResponseEnvelope always uses contract_v1 format (no legacy response format)

Notes:
    - Malformed envelopes raise ValueError (caller should dead-letter these)
    - attempt field is validated >= 1 and defaults to 1 if missing
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class RequestEnvelope:
    """Parsed request envelope from orchestrator.

    Parsed representation of contract_v1 request envelopes.

    Attributes:
        envelope_version: Wire format version from request envelope.
        contract_version: Provider protocol version.
        message_id: Unique message identifier for RabbitMQ correlation.
        task_ref: Task correlation reference.
        task_id: Orchestrator task identifier.
        action: Provider action to execute (e.g., "create", "delete").
        resource_kind: Resource type (e.g., "vm", "network").
        payload: Action-specific parameters (dict).
        attempt: Delivery attempt counter (1-indexed, default: 1).
        idempotency_key: Optional pre-computed idempotency key from orchestrator.
        provider: Optional provider name hint from orchestrator.
        source_format: Always "contract_v1".
        legacy_task_id: Backward-compat field; always None.
    """

    envelope_version: str
    contract_version: str
    message_id: str
    task_ref: str
    task_id: str
    action: str
    resource_kind: str
    payload: dict[str, Any]
    attempt: int = 1
    idempotency_key: str | None = None
    provider: str | None = None
    source_format: str = "contract_v1"
    legacy_task_id: int | None = None


@dataclass(frozen=True, slots=True)
class ResponseEnvelope:
    """Response envelope sent back to orchestrator.

    Always uses contract_v1 format.

    Attributes:
        envelope_version: Echoed from request envelope.
        contract_version: Echoed from request.
        message_id: Echoed from request for correlation.
        task_ref: Echoed from request for task correlation.
        task_id: Echoed from request.
        ok: True for success, False for provider error.
        provider: Provider name from RuntimeConfig.
        action: Echoed action from request.
        result: Present when ok=True, contains success/external_id/message/data.
        error: Present when ok=False, contains code/detail/retryable/extra.
    """

    envelope_version: str
    contract_version: str
    message_id: str
    task_ref: str
    task_id: str
    ok: bool
    provider: str
    action: str
    result: dict[str, Any] | None = None
    error: dict[str, Any] | None = None


REQUIRED_REQUEST_FIELDS = {
    "envelope_version",
    "contract_version",
    "message_id",
    "task_ref",
    "action",
    "resource_kind",
    "payload",
}

_TASK_REF_ID_RE = re.compile(r"^task-(\d+)$")


def _derive_task_id_from_ref(task_ref: str) -> str | None:
    match = _TASK_REF_ID_RE.match(task_ref.strip())
    if not match:
        return None
    return match.group(1)


def parse_request_envelope(raw_body: bytes) -> RequestEnvelope:
    """Parse request envelope in contract_v1 format.

    Args:
        raw_body: UTF-8 encoded JSON bytes from RabbitMQ delivery.

    Returns:
        Parsed contract request envelope.

    Raises:
        ValueError: When body is not valid JSON, not a dict, or does not match
            required contract envelope fields.

    Example:
        Contract format:
            {"envelope_version": "1.0", "contract_version": "1.0", "message_id": "...", ...}
    """
    data = json.loads(raw_body.decode("utf-8"))

    if not isinstance(data, dict):
        raise ValueError("request envelope must be a JSON object")

    missing = sorted(REQUIRED_REQUEST_FIELDS - set(data.keys()))
    if missing:
        raise ValueError(f"missing required envelope fields: {missing}")

    payload = data["payload"]
    if not isinstance(payload, dict):
        raise ValueError("payload must be a JSON object")
    action = str(data["action"]).strip()
    if not action:
        raise ValueError("action must be a non-empty string")

    attempt = data.get("attempt", 1)
    if not isinstance(attempt, int) or attempt < 1:
        raise ValueError("attempt must be an integer >= 1")

    task_ref = str(data["task_ref"])
    derived_task_id = _derive_task_id_from_ref(task_ref)
    raw_task_id = data.get("task_id")
    if raw_task_id is None:
        if derived_task_id is None:
            raise ValueError("task_ref must encode numeric task id when task_id omitted")
        task_id = derived_task_id
    else:
        task_id = str(raw_task_id).strip()
        if not task_id:
            raise ValueError("task_id must be non-empty when provided")
        if derived_task_id is not None and task_id != derived_task_id:
            raise ValueError("task_id does not match task_ref")

    return RequestEnvelope(
        envelope_version=str(data["envelope_version"]),
        contract_version=str(data["contract_version"]),
        message_id=str(data["message_id"]),
        task_ref=task_ref,
        task_id=task_id,
        action=action,
        resource_kind=str(data["resource_kind"]),
        payload=payload,
        attempt=attempt,
        idempotency_key=(str(data["idempotency_key"]) if "idempotency_key" in data else None),
        provider=(str(data["provider"]) if "provider" in data else None),
        source_format="contract_v1",
        legacy_task_id=None,
    )


def dump_response_envelope(envelope: ResponseEnvelope) -> bytes:
    """Serialize response envelope to compact JSON bytes.

    Uses separators=(",", ":") to minimize payload size (no whitespace).

    Args:
        envelope: Response envelope to serialize.

    Returns:
        UTF-8 encoded JSON bytes ready for RabbitMQ publish.
    """
    return json.dumps(asdict(envelope), separators=(",", ":")).encode("utf-8")
