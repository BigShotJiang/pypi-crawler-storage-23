"""Runtime configuration for provider execution and RabbitMQ transport.

RuntimeConfig provides explicit control over all runtime knobs: prefetch, concurrency,
retry behavior, timeouts, dead-letter routing, and update emission.

Why so many knobs:
    - Different providers have different concurrency/timeout characteristics
    - Update emission must remain compatible with current orchestrator consumer
    - Dead-letter routing varies by deployment (some use DLX, some requeue)
    - Exponential backoff prevents thundering herd during transient failures

Contracts:
    - All defaults are production-safe but conservative (concurrency=1, prefetch=1)
    - connect_max_attempts=0 means retry connection forever (daemon behavior)
    - Prefetch is automatically max(prefetch_count, concurrency) to avoid starvation
    - Backoff parameters are shared between connection retries and task retries
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RuntimeConfig:
    """Runtime configuration controlling provider execution and RabbitMQ transport.

    This frozen dataclass holds all runtime knobs. Providers typically construct this
    once in runtime_app.py and pass it to run_provider_with_config().

    Why frozen:
        - Configuration should not change after runtime startup
        - Frozen dataclasses are hashable and thread-safe

    Attributes:
        rabbitmq_url: AMQP URL with credentials (amqp://user:pass@host:port/vhost).
        request_queue: Durable queue name for incoming task requests.
        request_exchange: Topic exchange for task routing (default: "osp.from_orch").
        request_binding: Optional comma-separated routing keys to bind (e.g., "provider.vmware").
            If None, queue is not bound (assume pre-existing binding or direct publish).
        prefetch_count: RabbitMQ prefetch (default: 1).
            Actual prefetch is max(prefetch_count, concurrency).
        concurrency: ThreadPoolExecutor worker count for provider.execute() (default: 1).
        max_attempts: Maximum delivery attempts before dead-lettering (default: 5).
        handler_timeout_seconds: Optional per-task timeout for provider.execute().
            None means no timeout. Why optional: Some providers have long-running
            operations (VM provisioning can take minutes).
        dead_letter_exchange: Optional DLX for non-retryable failures and exhausted retries.
        dead_letter_routing_key: Optional DLX routing key.
        heartbeat_seconds: RabbitMQ heartbeat interval (default: 60).
        blocked_connection_timeout_seconds: Timeout when connection is flow-controlled
            (default: 30).
        connect_max_attempts: Connection retry limit (0 = retry forever, default: 0).
            Why 0: Providers are daemons and should keep trying to reconnect.
        connect_backoff_base_seconds: Initial connection retry delay (default: 1.0).
        connect_backoff_max_seconds: Max connection retry delay (default: 30.0).
        connect_backoff_jitter_factor: Jitter as fraction of delay (default: 0.2 = ±20%).
            Why jitter: Avoids thundering herd when multiple providers restart simultaneously.
        retry_backoff_base_seconds: Initial task retry delay (default: 1.0).
        retry_backoff_max_seconds: Max task retry delay (default: 30.0).
        retry_backoff_jitter_factor: Jitter for task retries (default: 0.2).
        provider_name: Provider identifier for response envelopes (default: "unknown-provider").
        updates_exchange: Exchange for TaskReporter updates (default: "osp.to_orch").
        updates_routing_key: Routing key for updates (default: "unknown-provider").
        emit_legacy_updates: Enable legacy-compatible update emission (default: True).
            Why True: Current orchestrator update consumer expects this format.
        emit_legacy_updates_for_contract_requests: Emit updates for contract_v1
            requests (default: True). Why separate flag: rollout safety switch.
    """

    rabbitmq_url: str
    request_queue: str
    request_exchange: str = "osp.from_orch"
    request_binding: str | None = None
    prefetch_count: int = 1
    concurrency: int = 1
    max_attempts: int = 5
    handler_timeout_seconds: float | None = None
    dead_letter_exchange: str | None = None
    dead_letter_routing_key: str | None = None
    heartbeat_seconds: int = 60
    blocked_connection_timeout_seconds: int = 30
    connect_max_attempts: int = 0  # 0 means retry forever
    connect_backoff_base_seconds: float = 1.0
    connect_backoff_max_seconds: float = 30.0
    connect_backoff_jitter_factor: float = 0.2
    retry_backoff_base_seconds: float = 1.0
    retry_backoff_max_seconds: float = 30.0
    retry_backoff_jitter_factor: float = 0.2
    provider_name: str = "unknown-provider"
    updates_exchange: str = "osp.to_orch"
    updates_routing_key: str = "unknown-provider"
    emit_legacy_updates: bool = True
    emit_legacy_updates_for_contract_requests: bool = True
