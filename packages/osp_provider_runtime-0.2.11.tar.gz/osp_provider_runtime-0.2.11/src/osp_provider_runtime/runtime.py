"""Core provider execution runtime with timeout enforcement and update emission.

ProviderRuntime orchestrates the full request lifecycle:
    1. Parse request envelope (contract_v1)
    2. Build provider RequestContext/ProviderRequest
    3. Call provider.execute() with optional timeout
    4. Build response envelope and task update
    5. Decide ack action based on retry logic

Threading model:
    - ProviderRuntime.handle_delivery() runs on ThreadPoolExecutor (RabbitMQRunner concurrency)
    - Timeout enforcement uses separate single-thread executor
    - Timeout executor spawns thread per timed-out task, calls future.cancel()

Why timeout executor:
    - provider.execute() may block indefinitely (network calls, long operations)
    - Blocking affects concurrency (one stuck task = one fewer worker)
    - Timeout with future.cancel() allows provider to be interrupted

Retry logic:
    - Retryable errors with attempts < max_attempts → REQUEUE
    - Retryable errors with attempts >= max_attempts → DEAD_LETTER
    - Non-retryable errors → ACK (failed task, remove from queue)

Update emission:
    - Controlled by runtime config update flags
    - Emits contract update envelopes consumed by orchestrator
    - Progress events extracted from result.data to avoid duplication in TaskEvent rows

Contracts:
    - close() must be called to release timeout executor
    - Capabilities requests bypass normal execution path (RPC response only)
    - Approval detection uses detail="approval_required" + gate_reason
"""

from __future__ import annotations

import concurrent.futures
import json
from typing import Any

from loguru import logger
from osp_provider_contracts import (
    Provider,
    ProviderError,
    ProviderRequest,
    ProviderResult,
    RequestContext,
    parse_provider_update_envelope,
)
from osp_provider_contracts.errors import TransientError

from .config import RuntimeConfig
from .envelope import (
    RequestEnvelope,
    ResponseEnvelope,
    dump_response_envelope,
    parse_request_envelope,
)
from .transport import AckAction, Delivery, DeliveryResult
from .updates import TaskReporter, json_safe


class ProviderRuntime:
    """Provider execution runtime with envelope parsing, timeout, and update emission.

    Why separate from RabbitMQRunner:
        - ProviderRuntime = business logic (testable without RabbitMQ)
        - RabbitMQRunner = transport (pika channel, ack/nack, thread safety)
    """

    def __init__(self, provider: Provider, config: RuntimeConfig) -> None:
        """Initialize runtime with provider and configuration.

        Args:
            provider: Provider implementation conforming to osp_provider_contracts.Provider.
            config: Runtime configuration (concurrency, timeouts, retry limits, etc.).
        """
        self.provider = provider
        self.config = config
        self._timeout_executor: concurrent.futures.ThreadPoolExecutor | None = None
        self._closed = False

    def close(self) -> None:
        """Release runtime-owned resources.

        Shuts down timeout executor and cancels pending futures. Safe to call multiple times.

        Why shutdown with cancel_futures=True:
            - Pending timeout tasks should not continue after runtime closes
            - Prevents orphaned threads after graceful shutdown
        """
        self._closed = True
        if self._timeout_executor is not None:
            self._timeout_executor.shutdown(wait=False, cancel_futures=True)
            self._timeout_executor = None

    def handle_delivery(self, delivery: Delivery) -> DeliveryResult:
        """Process a single delivery and return ack decision.

        Main entry point called by RabbitMQRunner for each message. Handles:
            - Capabilities RPC (contract format)
            - Task execution with timeout enforcement
            - Response envelope construction
            - Update emission with progress event extraction
            - Retry logic and ack decision

        Why capabilities bypass normal execution:
            - Capabilities RPC needs immediate response (no task context)
            - No update emission or retry logic for capabilities

        Args:
            delivery: Inbound message from transport.

        Returns:
            DeliveryResult with ack_action and optional response/update bodies.

        Notes:
            - Malformed envelopes → DEAD_LETTER (parsing errors are permanent)
            - Unhandled exceptions → TransientError → REQUEUE or DEAD_LETTER
        """
        try:
            request_env = parse_request_envelope(delivery.body)
        except Exception:
            logger.exception("Malformed request envelope")
            return DeliveryResult(ack_action=AckAction.DEAD_LETTER)

        if request_env.action == "capabilities":
            return self._handle_contract_capabilities_request(request_env, delivery)

        try:
            result = self._execute_provider(request_env)
            response_env = self._build_success_response(request_env, result)
            response = dump_response_envelope(response_env)
            update_body = self._build_provider_update_success(request_env, result)
            update_event_id = self._extract_update_event_id(update_body)
            logger.info(
                "Processed message",
                message_id=request_env.message_id,
                task_id=request_env.task_id,
                task_ref=request_env.task_ref,
                update_event_id=update_event_id,
                attempt=request_env.attempt,
                decision="ack",
            )
            return DeliveryResult(
                ack_action=AckAction.ACK,
                response_body=response,
                response_routing_key=delivery.reply_to,
                response_correlation_id=request_env.task_ref,
                update_body=update_body,
                update_exchange=self.config.updates_exchange if update_body else None,
                update_routing_key=self.config.updates_routing_key if update_body else None,
            )
        except ProviderError as exc:
            return self._handle_provider_error(request_env, delivery, exc)
        except Exception as exc:  # noqa: BLE001
            transient = TransientError(str(exc), detail="Unhandled runtime exception")
            return self._handle_provider_error(request_env, delivery, transient)

    def _handle_contract_capabilities_request(
        self,
        request_env: RequestEnvelope,
        delivery: Delivery,
    ) -> DeliveryResult:
        """Handle contract_v1 capabilities request (action="capabilities").

        Returns raw capabilities dict (not wrapped in response envelope) for RPC compatibility.
        """
        payload = json_safe(self.provider.capabilities())
        response = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        logger.info(
            "Processed capabilities RPC",
            message_id=request_env.message_id,
            task_ref=request_env.task_ref,
            decision="ack",
        )
        return DeliveryResult(
            ack_action=AckAction.ACK,
            response_body=response if delivery.reply_to else None,
            response_routing_key=delivery.reply_to,
            response_correlation_id=delivery.correlation_id or request_env.task_ref,
        )

    def _execute_provider(self, request_env: RequestEnvelope) -> ProviderResult:
        """Execute provider with optional timeout enforcement.

        Why timeout executor:
            - provider.execute() may block indefinitely (external API calls, long operations)
            - Blocking one task reduces effective concurrency
            - future.result(timeout=X) + future.cancel() allows interruption

        Why single-thread executor:
            - Only used for timeout monitoring, not for actual work
            - Actual work runs on RabbitMQRunner's ThreadPoolExecutor

        Raises:
            TransientError: When timeout is exceeded (retryable).
            ProviderError: Propagated from provider.execute().
        """
        if self._closed:
            raise RuntimeError("ProviderRuntime is closed")

        context = RequestContext(
            task_id=request_env.task_id,
            task_ref=request_env.task_ref,
            idempotency_key=request_env.idempotency_key,
        )
        request = ProviderRequest(
            action=request_env.action,
            resource_kind=request_env.resource_kind,
            payload=request_env.payload,
        )
        timeout = self.config.handler_timeout_seconds
        if timeout is None:
            return self.provider.execute(request_env.action, request, context)

        if self._timeout_executor is None:
            self._timeout_executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        future = self._timeout_executor.submit(
            self.provider.execute,
            request_env.action,
            request,
            context,
        )
        try:
            return future.result(timeout=timeout)
        except concurrent.futures.TimeoutError as exc:
            future.cancel()
            raise TransientError(
                f"Provider execution timed out after {timeout} seconds",
                detail="handler_timeout",
                extra={"timeout_seconds": timeout},
            ) from exc

    def _handle_provider_error(
        self,
        request_env: RequestEnvelope,
        delivery: Delivery,
        exc: ProviderError,
    ) -> DeliveryResult:
        """Handle provider error and decide ack action based on retry logic.

        Retry decision matrix:
            - Retryable + attempts < max_attempts → REQUEUE
            - Retryable + attempts >= max_attempts → DEAD_LETTER
            - Non-retryable → ACK (failed, remove from queue)

        Why non-retryable errors are ACKed:
            - ValidationError, AuthError, etc. won't succeed on retry
            - ACK removes message from queue, orchestrator marks task as failed
            - Prevents infinite requeue loop for permanent failures
        """
        attempts_left = request_env.attempt < self.config.max_attempts
        if exc.retryable and attempts_left:
            logger.warning(
                "Retryable provider error; requeueing",
                message_id=request_env.message_id,
                task_id=request_env.task_id,
                attempt=request_env.attempt,
                decision="requeue",
                error_code=exc.code,
            )
            return DeliveryResult(ack_action=AckAction.REQUEUE)

        ack_action = AckAction.DEAD_LETTER if exc.retryable else AckAction.ACK
        decision = "dead_letter" if ack_action == AckAction.DEAD_LETTER else "ack"
        response_env = self._build_error_response(request_env, exc)
        response = dump_response_envelope(response_env)
        update_body = self._build_provider_update_error(request_env, exc)
        update_event_id = self._extract_update_event_id(update_body)
        logger.error(
            "Provider error",
            message_id=request_env.message_id,
            task_id=request_env.task_id,
            task_ref=request_env.task_ref,
            update_event_id=update_event_id,
            attempt=request_env.attempt,
            decision=decision,
            error_code=exc.code,
            retryable=exc.retryable,
        )
        return DeliveryResult(
            ack_action=ack_action,
            response_body=response,
            response_routing_key=delivery.reply_to,
            response_correlation_id=request_env.task_ref,
            update_body=update_body,
            update_exchange=self.config.updates_exchange,
            update_routing_key=self.config.updates_routing_key,
        )

    def _build_success_response(
        self,
        request_env: RequestEnvelope,
        result: ProviderResult,
    ) -> ResponseEnvelope:
        """Build success response envelope echoing request correlation fields."""
        payload: dict[str, Any] = {
            "success": result.success,
            "external_id": result.external_id,
            "message": result.message,
            "data": json_safe(dict(result.data)),
        }
        return ResponseEnvelope(
            envelope_version=request_env.envelope_version,
            contract_version=request_env.contract_version,
            message_id=request_env.message_id,
            task_ref=request_env.task_ref,
            task_id=request_env.task_id,
            ok=True,
            provider=self.config.provider_name,
            action=request_env.action,
            result=payload,
            error=None,
        )

    def _build_error_response(
        self,
        request_env: RequestEnvelope,
        exc: ProviderError,
    ) -> ResponseEnvelope:
        """Build error response envelope with ProviderError details."""
        error = {
            "code": exc.code,
            "detail": exc.detail,
            "retryable": exc.retryable,
            "extra": json_safe(exc.extra),
        }
        return ResponseEnvelope(
            envelope_version=request_env.envelope_version,
            contract_version=request_env.contract_version,
            message_id=request_env.message_id,
            task_ref=request_env.task_ref,
            task_id=request_env.task_id,
            ok=False,
            provider=self.config.provider_name,
            action=request_env.action,
            result=None,
            error=error,
        )

    def _build_provider_update_success(
        self,
        request_env: RequestEnvelope,
        result: ProviderResult,
    ) -> bytes | None:
        """Build task update for successful execution.

        Why extract and remove progress_events:
            - result.data may contain progress_events array from provider
            - Orchestrator expands progress_events into separate TaskEvent rows
            - Leaving progress_events in resolved payload duplicates data
            - Extraction happens before resolved payload is stored

        Returns:
            Serialized ProviderUpdate bytes, or None if update emission is disabled.
        """
        if not self._should_emit_provider_update(request_env):
            return None
        task_id = self._resolve_update_task_id(request_env)
        if task_id is None:
            return None
        reporter = TaskReporter(task_id=task_id, task_ref=request_env.task_ref)
        result_data = json_safe(dict(result.data or {}))
        progress_events = None
        if isinstance(result_data, dict):
            maybe_progress = result_data.get("progress_events")
            if isinstance(maybe_progress, list):
                progress_events = maybe_progress
                # Avoid duplicating the same data in both resolved payload and
                # expanded TaskEvent rows.
                result_data = dict(result_data)
                result_data.pop("progress_events", None)
        payload = {
            "requested": json_safe(dict(request_env.payload)),
            "resolved": result_data,
            "provenance": {},
            "dry_run": bool(request_env.payload.get("dry_run") or request_env.payload.get("check")),
        }
        if progress_events is not None:
            payload["progress_events"] = progress_events
        return reporter.completed(
            message=result.message or "Completed",
            payload=payload,
        ).to_transport_bytes()

    def _build_provider_update_error(
        self,
        request_env: RequestEnvelope,
        exc: ProviderError,
    ) -> bytes | None:
        """Build task update for provider error.

        Detects approval-required errors and emits require_approval update instead of failed.

        Why approval detection here:
            - ValidationError with detail="approval_required" triggers approval flow
            - gate_reason controls approval authority and quorum
            - Orchestrator routes to appropriate approval UI
        """
        if not self._should_emit_provider_update(request_env):
            return None
        task_id = self._resolve_update_task_id(request_env)
        if task_id is None:
            return None
        reporter = TaskReporter(task_id=task_id, task_ref=request_env.task_ref)
        if self._is_non_approvable_rejection(exc):
            return reporter.deny(
                message=exc.message or "Provider rejected request",
                reason_code=str(exc.extra.get("reason_code") or exc.extra.get("reason") or "REQUEST_REJECTED"),
                details=exc.extra.get("details") if isinstance(exc.extra.get("details"), dict) else None,
            ).to_transport_bytes()
        if self._is_approval_required(exc):
            maybe_progress = exc.extra.get("progress_events")
            gate_reason = str(exc.extra.get("gate_reason") or "").strip().lower() or None
            return reporter.require_approval(
                gate_reason=str(gate_reason or ""),
                importance=int(exc.extra.get("importance", 3)),
                reason=str(exc.extra.get("reason") or "approval_required"),
                details=exc.extra.get("details")
                if isinstance(exc.extra.get("details"), dict)
                else None,
                progress_events=maybe_progress if isinstance(maybe_progress, list) else None,
                message=exc.message or "Provider requires approval",
            ).to_transport_bytes()
        return reporter.failed(
            message=exc.message,
            code=exc.code,
            detail=exc.detail,
            retryable=exc.retryable,
            extra=json_safe(exc.extra),
        ).to_transport_bytes()

    def _should_emit_provider_update(self, request_env: RequestEnvelope) -> bool:
        """Check if task update should be emitted based on config flags.

        Flags are retained in RuntimeConfig for deploy-time toggling of update
        emission without changing provider code paths.
        """
        _ = request_env
        return bool(
            self.config.emit_legacy_updates
            and self.config.emit_legacy_updates_for_contract_requests
        )

    def _resolve_update_task_id(self, request_env: RequestEnvelope) -> int | None:
        """Extract integer task ID for provider update emission.

        Why needed:
            - Update consumer stores task IDs as integers.
            - Request envelopes may carry non-numeric task IDs.
            - Fallback strategy: str(task_id) → payload["id"].

        Returns:
            Integer task ID, or None if no valid int ID found (update emission skipped).
        """
        try:
            return int(str(request_env.task_id))
        except (TypeError, ValueError):
            pass
        payload_id = request_env.payload.get("id")
        if isinstance(payload_id, int):
            return payload_id
        if isinstance(payload_id, str) and payload_id.isdigit():
            return int(payload_id)
        return None

    def _is_approval_required(self, exc: ProviderError) -> bool:
        """Check if error is approval-required (not a regular failure).

        Approval contract:
            - detail="approval_required"
            - gate_reason present
        """
        if exc.detail != "approval_required":
            return False
        gate_reason = exc.extra.get("gate_reason")
        if isinstance(gate_reason, str) and gate_reason.strip():
            if gate_reason.strip().lower() == "requested_state_invalid":
                return False
            return True
        return False

    def _is_non_approvable_rejection(self, exc: ProviderError) -> bool:
        """True when provider error should map to terminal REJECTED (not approval gate)."""
        if exc.detail == "request_invalid":
            return True
        gate_reason = exc.extra.get("gate_reason")
        if isinstance(gate_reason, str) and gate_reason.strip().lower() == "requested_state_invalid":
            return True
        status_code = exc.extra.get("status_code")
        return isinstance(status_code, int) and int(status_code) == 900

    def _extract_update_event_id(self, update_body: bytes | None) -> str | None:
        """Extract event_id from update body for structured logging.

        Why extract:
            - Logs should include event_id for correlation with TaskEvent rows
            - Parsing is best-effort (graceful degradation if malformed)
        """
        if update_body is None:
            return None
        try:
            parsed = json.loads(update_body.decode("utf-8"))
        except Exception:  # noqa: BLE001
            return None
        if not isinstance(parsed, dict):
            return None

        try:
            _task_id, event = parse_provider_update_envelope(parsed)
        except ValueError:
            return None

        raw = event["payload"].get("event_id")
        if raw is None:
            raw = parsed.get("message_id")
        return str(raw).strip() or None
