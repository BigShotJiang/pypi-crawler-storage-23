# Release Notes: osp-provider-runtime 0.2.5

Date: 2026-02-13

## Summary

This patch release adds first-class support for contract-envelope capabilities
RPC requests (`action=capabilities`).

Without this fix, capability requests using the canonical envelope could flow
into provider action execution paths and fail depending on provider
implementation.

## Changes

- Added explicit `action=capabilities` handling in
  `ProviderRuntime.handle_delivery`.
- Returned provider capabilities directly as RPC response payload.
- Preserved request `correlation_id` in RPC responses.
- Added regression test for contract capabilities RPC handling.

## Operational Impact

- Providers no longer depend on legacy capabilities payload shape for
  capabilities RPC handling.
- Capability checks are stable across both legacy and canonical capabilities
  request formats.

## Upgrade Guidance

1. Publish runtime `0.2.5` to PyPI.
2. Rebuild provider images (`vmware`, `nrec`) so they resolve `0.2.5`.
3. Roll out provider containers and verify `/v1/capabilities` calls succeed.
