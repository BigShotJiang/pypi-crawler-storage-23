# osp-provider-runtime 0.2.8

## Highlights

- Preserve `progress_events` on approval-required provider updates.

## Why

Providers emit placement/request/spec progress lines as events. The
approval-required legacy update path previously dropped these events, leaving
operators with a single waiting message and degraded event visibility.

## Impact

- Orchestrator can emit distinct TaskEvents from provider progress lines before
  the waiting-approval event.
