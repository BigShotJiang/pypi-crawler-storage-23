# Provider Update Cookbook (v1)

Use `TaskReporter` for task lifecycle updates. Keep provider logic focused on
business rules; let runtime handle publishing and retries.

## Quick usage

```python
from osp_provider_runtime import TaskReporter

report = TaskReporter(task_id=42, correlation_id="task-42")

accepted = report.accepted(message="Accepted by provider")
running = report.running(message="Provisioning started")
progress = report.progress(message="Halfway", current=5, total=10)
gated = report.require_approval(
    gate_code=403,
    importance=2,
    reason="policy_violation",
    details={"scope": "network"},
)
done = report.completed(message="Provisioning completed", payload={"hostname": "vm-01"})
failed = report.failed(
    message="Provisioning failed",
    code="dependency_error",
    detail="vcenter unavailable",
    retryable=True,
)
```

Each helper returns a `ProviderUpdate` model. Runtime emits transport-compatible
updates from this model.

## Helper defaults

- `accepted` -> `status_code=105`, `severity=20`
- `running` -> `status_code=160`, `severity=20`
- `progress` -> `status_code=160`, `severity=20`
- `require_approval` -> `status_code=301`, `severity=30`
- `completed` -> `status_code=200`, `severity=20`
- `failed` -> `status_code=580`, `severity=40`
- `deny` -> `status_code=900`, `severity=40`
- `update` -> explicit escape hatch

## Payload conventions

- Approval block: `payload["approval"] = {...}`
- Progress block: `payload["progress"] = {"current": int, "total": int}`
- Runtime adds dedupe/trace fields:
  - `payload["event_id"]`
  - `payload["correlation_id"]`
  - `payload["task_id"]`

## Reliability model

- Providers signal business outcome and retryability.
- Runtime owns retries/backoff/max-attempts/DLQ behavior.
- Orchestrator dedupe should use `(task_id, event_id)`.
