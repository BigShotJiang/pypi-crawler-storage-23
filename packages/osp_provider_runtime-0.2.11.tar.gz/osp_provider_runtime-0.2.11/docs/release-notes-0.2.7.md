# osp-provider-runtime 0.2.7

## Summary

This patch release adds explicit support for provider progress events in
runtime-emitted task updates.

## Changes

- Runtime update emission now forwards `result.data.progress_events` as
  top-level `payload.progress_events`.
- `progress_events` is removed from `payload.resolved` during emission to
  avoid duplicated rendering in downstream consumers.
- Added regression coverage for the `progress_events` emission path.

## Upgrade Notes

- No API breakage.
- Existing providers continue to work unchanged.
- Providers may now include `progress_events` in `ProviderResult.data`.
