# Runtime Messaging Contract (v0.1)

Request envelope required fields:
- `envelope_version` (string)
- `contract_version` (string)
- `message_id` (string)
- `correlation_id` (string)
- `task_id` (string)
- `action` (string)
- `resource_kind` (string)
- `payload` (object)

Optional fields:
- `attempt` (int, defaults to 1)
- `idempotency_key` (string)
- `provider` (string)

Response envelope:
- `envelope_version`
- `contract_version`
- `message_id`
- `correlation_id`
- `task_id`
- `ok` (bool)
- `provider` (string)
- `action` (string)
- `result` (object, only when `ok=true`)
- `error` (object, only when `ok=false`)

Error object shape:
- `code` (string)
- `detail` (string | null)
- `retryable` (bool)
- `extra` (object)

Ack policy:
- Success: `ack`.
- `ProviderError(retryable=false)`: `ack`.
- `ProviderError(retryable=true)`: `requeue` until max attempts; then dead-letter.
- Unknown exception: treat as retryable transient error with same attempt policy.

Legacy compatibility:
- Runtime also accepts legacy orchestrator outbox payloads:
  - `{"id": <int>, "action": <str>, ...}`
- Runtime can emit provider update events to `osp.to_orch`:
  - Success: `status_code=200`
  - Terminal provider error: `status_code=580`
  - Approval-required provider error (`detail="approval_required"` with 4xx gate):
    `status_code=301` with gate payload
- By default, update emission is enabled for both legacy and contract envelopes
  when runtime can resolve an integer task id.

Canonical update model (runtime-internal):
- `event_id` (string, UUID recommended)
- `task_id` (int)
- `correlation_id` (string)
- `status_code` (int)
- `severity` (int)
- `message` (string)
- `payload` (object, optional)

Transport body (orchestrator-consumer compatible):
- `id` (task id)
- `status_code`
- `severity`
- `message`
- `payload` (optional)

Runtime always includes in `payload`:
- `event_id`
- `correlation_id`
- `task_id`

Reserved payload keys:
- `approval`: gate payload block (for approval-required flow)
- `progress`: informational progress block (`current`, `total`)

Runtime topology behavior:
- Runtime declares and binds its request queue on startup.
- Default request exchange: `osp.from_orch` (topic).
- Default request binding: `<provider_name>.#`.
- Default updates exchange: `osp.to_orch` (topic).
