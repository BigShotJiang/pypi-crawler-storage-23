# Migration Notes: Move Providers To `TaskReporter`

Goal: remove provider-local publish glue and standardize update emission.

## Before (provider-local publishing)

Typical legacy pattern:
- Provider creates AMQP message manually.
- Provider chooses routing key, exchange and payload structure.
- Provider owns json coercion edge cases.

## After (runtime-owned publishing contract)

- Provider emits typed updates via `TaskReporter`.
- Runtime handles transport serialization, metadata injection and retries.
- Orchestrator receives one consistent update shape.

## Minimal migration steps

1. Remove provider-local publish helpers for task lifecycle updates.
2. Keep provider execution logic unchanged.
3. Use runtime + `TaskReporter` output contract only.
4. Ensure provider tests assert status semantics (`completed`, `failed`,
   `require_approval`).

## Behavior notes

- `require_approval(...)` emits status `301` and payload `approval` block.
- `progress(...)` emits status `160` with `payload.progress`.
- Runtime injects `event_id`, `correlation_id`, and `task_id` into payload.

## Cutover validation

- Duplicate delivery with same `event_id` is dropped.
- Non-terminal updates after terminal status are ignored.
- Approval-required flow creates deterministic waiting state.
