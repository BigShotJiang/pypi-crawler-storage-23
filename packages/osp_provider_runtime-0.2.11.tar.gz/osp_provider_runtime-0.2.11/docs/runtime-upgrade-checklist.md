# Runtime Upgrade Checklist

Use this checklist when upgrading provider repos to the `TaskReporter` contract.

## Contract and code

- [ ] Provider no longer imports or uses bespoke publish helpers.
- [ ] Provider uses runtime contract updates only.
- [ ] Approval flow uses `payload.approval` with gate metadata.
- [ ] Progress flow uses `payload.progress.current/total`.

## Reliability and behavior

- [ ] Retryable errors requeue according to runtime policy.
- [ ] Non-retryable failures produce deterministic terminal updates.
- [ ] Duplicate `event_id` updates are deduped by orchestrator.
- [ ] Non-terminal updates after terminal status are ignored.

## Observability

- [ ] Logs include `task_id`.
- [ ] Logs include `correlation_id`.
- [ ] Update payload includes `event_id`.
- [ ] Delivery logs include decision (`ack`/`requeue`/`dead_letter`).

## Verification

- [ ] Runtime unit tests pass.
- [ ] Provider unit/integration tests pass.
- [ ] Orchestrator update-consumer tests pass.
- [ ] Staging RabbitMQ smoke test passes.
