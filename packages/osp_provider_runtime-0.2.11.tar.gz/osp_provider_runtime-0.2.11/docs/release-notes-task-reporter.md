# Release Notes: TaskReporter Update Contract

Date: 2026-02-13

## Summary

This release standardizes provider task lifecycle update emission through
runtime-owned `TaskReporter` APIs and a canonical update model.

## Runtime changes

- Added `TaskReporter` and `ProviderUpdate` in `osp_provider_runtime.updates`.
- Standardized helper methods:
  - `accepted`, `running`, `progress`, `require_approval`,
    `deny`, `completed`, `failed`, `update`.
- Added reserved payload blocks:
  - `payload.approval`
  - `payload.progress`
- Runtime now injects:
  - `payload.event_id`
  - `payload.correlation_id`
  - `payload.task_id`
- Runtime emits provider updates for contract envelopes when task id is
  resolvable.
- Approval-required errors map to waiting-approval updates deterministically.
- Added JSON-safe serialization guards for update payloads.
- Added correlation and update event identifiers in runtime logs.

## Orchestrator changes

- Consumer now reads approval data from `payload.approval` (with fallback).
- Duplicate delivery and out-of-order update handling verified by tests.
- Non-terminal updates after terminal status are ignored deterministically.

## Provider migration

- VMware bespoke task-lifecycle publish helper removed.
- Runtime package is now the canonical path for task update emission.
- Existing examples directory remains intentionally untouched.

## Operational notes

- Providers pinned to `osp-provider-runtime>=0.2,<0.3` should consume patch
  releases (`0.2.x`) for these changes.
- For staged rollout, verify RabbitMQ flow and observability fields before
  production cutover.
