#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# Avoid desktop keyring prompts/locks; prefer ~/.pypirc or explicit env vars.
export PYTHON_KEYRING_BACKEND=keyring.backends.null.Keyring

VERSION="$(
python - <<'PY'
from pathlib import Path
import tomllib

data = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
print(data["project"]["version"])
PY
)"

echo "Publishing osp-provider-runtime version ${VERSION}"
rm -rf dist
python -m build

ARTIFACTS=(
  "dist/osp_provider_runtime-${VERSION}-py3-none-any.whl"
  "dist/osp_provider_runtime-${VERSION}.tar.gz"
)

twine check "${ARTIFACTS[@]}"
twine upload "$@" "${ARTIFACTS[@]}"
