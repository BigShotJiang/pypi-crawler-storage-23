import json

import pytest

from osp_provider_runtime.envelope import parse_request_envelope


def test_parse_valid_request_envelope() -> None:
    body = json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m1",
            "task_ref": "task-1",
            "task_id": "1",
            "action": "create",
            "resource_kind": "bucket",
            "payload": {"name": "x"},
        }
    ).encode()

    env = parse_request_envelope(body)
    assert env.message_id == "m1"
    assert env.attempt == 1
    assert env.source_format == "contract_v1"


def test_parse_contract_envelope_strips_action_and_propagates_idempotency_key() -> None:
    body = json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m2",
            "task_ref": "task-2",
            "task_id": "2",
            "action": "  create  ",
            "resource_kind": "bucket",
            "payload": {"name": "y"},
            "idempotency_key": "idem-1",
        }
    ).encode()

    env = parse_request_envelope(body)
    assert env.action == "create"
    assert env.idempotency_key == "idem-1"


def test_parse_missing_field_raises() -> None:
    body = json.dumps({"envelope_version": "1"}).encode()
    with pytest.raises(ValueError):
        parse_request_envelope(body)


def test_parse_invalid_attempt_raises() -> None:
    body = json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m1",
            "task_ref": "task-1",
            "task_id": "1",
            "action": "create",
            "resource_kind": "bucket",
            "payload": {"name": "x"},
            "attempt": 0,
        }
    ).encode()
    with pytest.raises(ValueError):
        parse_request_envelope(body)


def test_parse_contract_envelope_rejects_blank_action() -> None:
    body = json.dumps(
        {
            "envelope_version": "1",
            "contract_version": "0.1",
            "message_id": "m3",
            "task_ref": "task-3",
            "task_id": "3",
            "action": "   ",
            "resource_kind": "bucket",
            "payload": {"name": "z"},
        }
    ).encode()
    with pytest.raises(ValueError):
        parse_request_envelope(body)


def test_parse_legacy_orchestrator_message_raises() -> None:
    body = json.dumps({"id": 123, "action": "provision", "provider": "nrec"}).encode()
    with pytest.raises(ValueError):
        parse_request_envelope(body)
