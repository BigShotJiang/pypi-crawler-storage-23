from __future__ import annotations

import concurrent.futures
from typing import Any

from osp_provider_runtime.config import RuntimeConfig
from osp_provider_runtime.rabbitmq import RabbitMQRunner
from osp_provider_runtime.transport import AckAction, DeliveryResult


class _SyncExecutor:
    def __init__(self, max_workers: int) -> None:
        self.max_workers = max_workers
        self.shutdown_called = False

    def submit(
        self,
        fn: Any,
        *args: Any,
        **kwargs: Any,
    ) -> concurrent.futures.Future[DeliveryResult]:
        fut: concurrent.futures.Future[DeliveryResult] = concurrent.futures.Future()
        try:
            fut.set_result(fn(*args, **kwargs))
        except Exception as exc:  # noqa: BLE001
            fut.set_exception(exc)
        return fut

    def shutdown(self, wait: bool = True) -> None:
        self.shutdown_called = True


class _FakeMethod:
    def __init__(self, routing_key: str, delivery_tag: int) -> None:
        self.routing_key = routing_key
        self.delivery_tag = delivery_tag


class _FakeProperties:
    def __init__(
        self,
        reply_to: str | None,
        correlation_id: str | None = "incoming-corr-1",
    ) -> None:
        self.reply_to = reply_to
        self.correlation_id = correlation_id


class _FakeChannel:
    def __init__(self) -> None:
        self.qos: list[int] = []
        self.exchanges: list[tuple[str, str, bool]] = []
        self.queues: list[tuple[str, bool, dict[str, Any] | None]] = []
        self.bindings: list[tuple[str, str, str]] = []
        self.publishes: list[tuple[str, str, bytes, Any]] = []
        self.acks: list[int] = []
        self.nacks: list[tuple[int, bool]] = []
        self.consumer_queue: str | None = None
        self.consumer_callback: Any = None

    def basic_qos(self, prefetch_count: int) -> None:
        self.qos.append(prefetch_count)

    def exchange_declare(self, exchange: str, exchange_type: str, durable: bool) -> None:
        self.exchanges.append((exchange, exchange_type, durable))

    def queue_declare(
        self,
        queue: str,
        durable: bool,
        arguments: dict[str, Any] | None,
    ) -> None:
        self.queues.append((queue, durable, arguments))

    def queue_bind(self, queue: str, exchange: str, routing_key: str) -> None:
        self.bindings.append((queue, exchange, routing_key))

    def basic_publish(self, exchange: str, routing_key: str, body: bytes, properties: Any) -> None:
        self.publishes.append((exchange, routing_key, body, properties))

    def basic_ack(self, delivery_tag: int) -> None:
        self.acks.append(delivery_tag)

    def basic_nack(self, delivery_tag: int, requeue: bool) -> None:
        self.nacks.append((delivery_tag, requeue))

    def basic_consume(self, queue: str, on_message_callback: Any) -> None:
        self.consumer_queue = queue
        self.consumer_callback = on_message_callback

    def start_consuming(self) -> None:
        assert self.consumer_callback is not None
        self.consumer_callback(
            self,
            _FakeMethod(routing_key="provider.demo.provision", delivery_tag=42),
            _FakeProperties(reply_to="reply.queue"),
            b'{"envelope_version":"1"}',
        )


class _FakeConnection:
    def __init__(self, channel: _FakeChannel) -> None:
        self._channel = channel
        self.callbacks: list[Any] = []
        self.is_open = True
        self.closed = False

    def channel(self) -> _FakeChannel:
        return self._channel

    def add_callback_threadsafe(self, callback: Any) -> None:
        self.callbacks.append(callback)
        callback()

    def close(self) -> None:
        self.closed = True
        self.is_open = False


def test_runner_declares_topology_and_publishes_and_acks(monkeypatch: Any) -> None:
    fake_channel = _FakeChannel()
    fake_connection = _FakeConnection(fake_channel)

    class _URLParams:
        def __init__(self, url: str) -> None:
            self.url = url
            self.heartbeat: int | None = None
            self.blocked_connection_timeout: int | None = None

    monkeypatch.setattr("osp_provider_runtime.rabbitmq.pika.URLParameters", _URLParams)
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.pika.BlockingConnection",
        lambda params: fake_connection,
    )
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.pika.BasicProperties",
        lambda **kwargs: kwargs,
    )
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.concurrent.futures.ThreadPoolExecutor",
        _SyncExecutor,
    )

    config = RuntimeConfig(
        rabbitmq_url="amqp://guest:guest@localhost:5672/",
        request_queue="provider.demo",
        request_exchange="osp.from_orch",
        request_binding="demo.#,demo.create",
        updates_exchange="osp.to_orch",
        updates_routing_key="demo",
        provider_name="demo",
    )

    runner = RabbitMQRunner(config)

    def handler(_: Any) -> DeliveryResult:
        return DeliveryResult(
            ack_action=AckAction.ACK,
            response_body=b'{"ok":true}',
            response_routing_key="reply.queue",
            response_correlation_id="corr-1",
            update_body=b'{"status":"ok"}',
            update_exchange="osp.to_orch",
            update_routing_key="demo",
        )

    runner.run(handler)

    assert fake_channel.qos == [1]
    assert ("osp.from_orch", "topic", True) in fake_channel.exchanges
    assert ("osp.to_orch", "topic", True) in fake_channel.exchanges
    assert fake_channel.queues[0][0] == "provider.demo"
    assert ("provider.demo", "osp.from_orch", "demo.#") in fake_channel.bindings
    assert ("provider.demo", "osp.from_orch", "demo.create") in fake_channel.bindings
    assert fake_channel.acks == [42]
    assert fake_channel.nacks == []
    assert len(fake_channel.publishes) == 2
    assert fake_connection.closed is True


def test_runner_requeues_on_requeue_result(monkeypatch: Any) -> None:
    fake_channel = _FakeChannel()
    fake_connection = _FakeConnection(fake_channel)

    class _URLParams:
        def __init__(self, url: str) -> None:
            self.url = url
            self.heartbeat: int | None = None
            self.blocked_connection_timeout: int | None = None

    monkeypatch.setattr("osp_provider_runtime.rabbitmq.pika.URLParameters", _URLParams)
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.pika.BlockingConnection",
        lambda params: fake_connection,
    )
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.concurrent.futures.ThreadPoolExecutor",
        _SyncExecutor,
    )
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.pika.BasicProperties",
        lambda **kwargs: kwargs,
    )
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.RabbitMQRunner._backoff_with_jitter",
        lambda *args, **kwargs: 0.0,
    )

    runner = RabbitMQRunner(
        RuntimeConfig(
            rabbitmq_url="amqp://guest:guest@localhost:5672/",
            request_queue="provider.demo",
            request_exchange="osp.from_orch",
            request_binding="demo.#",
        )
    )

    runner.run(lambda _: DeliveryResult(ack_action=AckAction.REQUEUE))

    assert fake_channel.acks == [42]
    assert fake_channel.nacks == []
    assert len(fake_channel.publishes) == 1
    exchange, routing_key, body, properties = fake_channel.publishes[0]
    assert exchange == "osp.from_orch"
    assert routing_key == "provider.demo.provision"
    assert body == b'{"envelope_version":"1","attempt":2}'
    assert properties["correlation_id"] == "incoming-corr-1"
    assert properties["reply_to"] == "reply.queue"
    assert fake_connection.closed is True


def test_increment_retry_attempt_rejects_non_json() -> None:
    updated, current = RabbitMQRunner._increment_retry_attempt(b"not-json")
    assert updated is None
    assert current == 1


def test_increment_retry_attempt_increments_existing_attempt() -> None:
    updated, current = RabbitMQRunner._increment_retry_attempt(
        b'{"id":7,"action":"provision","attempt":3}'
    )
    assert current == 3
    assert updated == b'{"id":7,"action":"provision","attempt":4}'


def test_runner_dead_letters_on_dead_letter_result(monkeypatch: Any) -> None:
    fake_channel = _FakeChannel()
    fake_connection = _FakeConnection(fake_channel)

    class _URLParams:
        def __init__(self, url: str) -> None:
            self.url = url
            self.heartbeat: int | None = None
            self.blocked_connection_timeout: int | None = None

    monkeypatch.setattr("osp_provider_runtime.rabbitmq.pika.URLParameters", _URLParams)
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.pika.BlockingConnection",
        lambda params: fake_connection,
    )
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.concurrent.futures.ThreadPoolExecutor",
        _SyncExecutor,
    )

    runner = RabbitMQRunner(
        RuntimeConfig(
            rabbitmq_url="amqp://guest:guest@localhost:5672/",
            request_queue="provider.demo",
            request_binding="demo.#",
        )
    )

    runner.run(lambda _: DeliveryResult(ack_action=AckAction.DEAD_LETTER))

    assert fake_channel.acks == []
    assert fake_channel.nacks == [(42, False)]
    assert fake_connection.closed is True


def test_connect_retries_then_succeeds(monkeypatch: Any) -> None:
    fake_channel = _FakeChannel()
    fake_connection = _FakeConnection(fake_channel)
    attempts = {"count": 0}

    class _URLParams:
        def __init__(self, url: str) -> None:
            self.url = url
            self.heartbeat: int | None = None
            self.blocked_connection_timeout: int | None = None

    class _OnceError(Exception):
        pass

    def _connect(_params: Any) -> _FakeConnection:
        attempts["count"] += 1
        if attempts["count"] == 1:
            raise _OnceError("connect failed")
        return fake_connection

    monkeypatch.setattr("osp_provider_runtime.rabbitmq.pika.URLParameters", _URLParams)
    monkeypatch.setattr("osp_provider_runtime.rabbitmq.pika.BlockingConnection", _connect)
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.concurrent.futures.ThreadPoolExecutor",
        _SyncExecutor,
    )
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.RabbitMQRunner._backoff_with_jitter",
        lambda *args, **kwargs: 0.0,
    )
    monkeypatch.setattr("osp_provider_runtime.rabbitmq.time.sleep", lambda _s: None)

    runner = RabbitMQRunner(
        RuntimeConfig(
            rabbitmq_url="amqp://guest:guest@localhost:5672/",
            request_queue="provider.demo",
            request_binding="demo.#",
            connect_max_attempts=3,
        )
    )

    runner.run(lambda _: DeliveryResult(ack_action=AckAction.ACK))

    assert attempts["count"] == 2
    assert fake_connection.closed is True


def test_runner_dead_letters_when_handler_raises(monkeypatch: Any) -> None:
    fake_channel = _FakeChannel()
    fake_connection = _FakeConnection(fake_channel)

    class _URLParams:
        def __init__(self, url: str) -> None:
            self.url = url
            self.heartbeat: int | None = None
            self.blocked_connection_timeout: int | None = None

    monkeypatch.setattr("osp_provider_runtime.rabbitmq.pika.URLParameters", _URLParams)
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.pika.BlockingConnection",
        lambda params: fake_connection,
    )
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.concurrent.futures.ThreadPoolExecutor",
        _SyncExecutor,
    )

    runner = RabbitMQRunner(
        RuntimeConfig(
            rabbitmq_url="amqp://guest:guest@localhost:5672/",
            request_queue="provider.demo",
            request_binding="demo.#",
            provider_name="demo",
            updates_routing_key="demo",
        )
    )

    def _handler_raises(_: Any) -> DeliveryResult:
        raise RuntimeError("boom")

    runner.run(_handler_raises)

    assert fake_channel.acks == []
    assert fake_channel.nacks == [(42, False)]
    assert fake_connection.closed is True


def test_connect_retries_forever_when_max_attempts_is_zero(monkeypatch: Any) -> None:
    fake_channel = _FakeChannel()
    fake_connection = _FakeConnection(fake_channel)
    attempts = {"count": 0}

    class _URLParams:
        def __init__(self, url: str) -> None:
            self.url = url
            self.heartbeat: int | None = None
            self.blocked_connection_timeout: int | None = None

    class _TransientConnectError(Exception):
        pass

    def _connect(_params: Any) -> _FakeConnection:
        attempts["count"] += 1
        if attempts["count"] < 3:
            raise _TransientConnectError("connect failed")
        return fake_connection

    monkeypatch.setattr("osp_provider_runtime.rabbitmq.pika.URLParameters", _URLParams)
    monkeypatch.setattr("osp_provider_runtime.rabbitmq.pika.BlockingConnection", _connect)
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.concurrent.futures.ThreadPoolExecutor",
        _SyncExecutor,
    )
    monkeypatch.setattr(
        "osp_provider_runtime.rabbitmq.RabbitMQRunner._backoff_with_jitter",
        lambda *args, **kwargs: 0.0,
    )
    monkeypatch.setattr("osp_provider_runtime.rabbitmq.time.sleep", lambda _s: None)

    runner = RabbitMQRunner(
        RuntimeConfig(
            rabbitmq_url="amqp://guest:guest@localhost:5672/",
            request_queue="provider.demo",
            request_binding="demo.#",
            connect_max_attempts=0,
            provider_name="demo",
            updates_routing_key="demo",
        )
    )

    runner.run(lambda _: DeliveryResult(ack_action=AckAction.ACK))

    assert attempts["count"] == 3
    assert fake_connection.closed is True
