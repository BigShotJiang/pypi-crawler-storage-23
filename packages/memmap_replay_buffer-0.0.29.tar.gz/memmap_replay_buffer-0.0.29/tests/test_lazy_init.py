import pytest
import numpy as np
import torch
from pathlib import Path
from memmap_replay_buffer.replay_buffer import ReplayBuffer

def test_lazy_initialization(tmp_path: Path):
    max_episodes = 2
    max_timesteps = 5
    
    fields = {
        'obs': ('float', (4,)),
        'image': ('float', (32, 32, 3), 1.0), # specific default value
        'action': ('int', (), -1) # specific default value
    }
    
    # 1) Initialize the buffer
    rb = ReplayBuffer(
        folder=tmp_path,
        max_episodes=max_episodes,
        max_timesteps=max_timesteps,
        fields=fields,
        overwrite=True
    )
    
    # Check that _initted was injected and is False everywhere
    is_init_data = np.load(str(tmp_path / '_initted.data.meta.npy'))
    assert is_init_data.shape == (max_episodes,)
    assert not np.any(is_init_data), "is_init should be all False on initialization"
    
    # Check that the default values were NOT eagerly written to the memmap arrays
    # (they will just be OS sparse file zeros, not 1.0 or -1)
    image_data = np.load(str(tmp_path / 'image.data.npy'))
    action_data = np.load(str(tmp_path / 'action.data.npy'))
    assert np.all(image_data == 0.), "image memmap shouldn't be initialized to 1.0 yet"
    assert np.all(action_data == 0), "action memmap shouldn't be initialized to -1 yet"
    
    # 2) Store a single timestep into the first episode
    rb.store(obs=np.random.randn(4)) # omit image and action, should get lazy-initialized for this episode only
    
    # Now check the active state of _initted
    is_init_data = np.load(str(tmp_path / '_initted.data.meta.npy'))
    assert is_init_data[0] == True, "Episode 0 should now be initialized"
    assert is_init_data[1] == False, "Episode 1 should NOT be initialized"
    
    # Check that eager initialization populated the REST of episode 0 with defaults
    # (since we only stored 1 timestep, the rest of the max_timesteps must be defaults)
    image_data = np.load(str(tmp_path / 'image.data.npy'))
    action_data = np.load(str(tmp_path / 'action.data.npy'))
    
    # Episode 0 should have defaults
    assert np.all(image_data[0] == 1.0), "Episode 0 image should have lazy-instantiated defaults"
    assert np.all(action_data[0] == -1), "Episode 0 action should have lazy-instantiated defaults"
    
    # Episode 1 should STILL have OS sparse zeros
    assert np.all(image_data[1] == 0.), "Episode 1 image should STILL NOT be initialized"
    assert np.all(action_data[1] == 0), "Episode 1 action should STILL NOT be initialized"
    
    # 3) Ensure datasets don't leak _initted
    dataset = rb.dataset()
    batch = dataset[0]
    assert '_initted' not in batch, "is_init shouldn't leak from datasets"
    
    # 4) Verify clear() wipes the bools instantly
    rb.clear()
    is_init_data = np.load(str(tmp_path / '_initted.data.meta.npy'))
    assert not np.any(is_init_data), "is_init should be all False after clear()"
