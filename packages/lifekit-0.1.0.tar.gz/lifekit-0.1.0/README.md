# LifeKit

**An AI-powered personal productivity system.** Planning, projects, people, and habits — all in markdown, all in your control.

> 🚧 Full release coming soon. Building in public at [neoagentix.com](https://neoagentix.com).

## What is LifeKit?

LifeKit is a distributable productivity system built for AI coding assistants. It brings together daily/weekly planning, project tracking, people files, and habit systems into a single markdown-native structure that lives in your repo and works with any AI assistant.

- **Claude Code first** — full agent integration, hooks, skills, MCP
- **Platform-agnostic core** — the markdown system works with any AI or manually
- **Built in public** — follow the build at [neoagentix.com](https://neoagentix.com)

## Status

Early development. Star the repo and watch for updates.

**GitHub:** [github.com/neoagentix/lifekit](https://github.com/neoagentix/lifekit)
