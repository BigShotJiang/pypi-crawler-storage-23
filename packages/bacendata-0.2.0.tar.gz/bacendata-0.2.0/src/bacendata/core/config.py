"""
bacendata.core.config
~~~~~~~~~~~~~~~~~~~~~

Configuração centralizada da API usando pydantic-settings.

Variáveis de ambiente podem ser definidas em arquivo .env ou diretamente no sistema.
"""

from typing import Optional

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Configurações da API BacenData."""

    # Aplicação
    app_name: str = "BacenData API"
    app_version: str = "0.2.0"
    debug: bool = False

    # Rate limiting (requisições por dia)
    rate_limit_free: int = 100
    rate_limit_pro: int = 10_000

    # API Keys para demonstração (em produção, usar banco de dados)
    # Formato: "chave1:plano,chave2:plano" ex: "abc123:free,xyz789:pro"
    api_keys: Optional[str] = None

    # BACEN
    bacen_max_concurrent: int = 5
    bacen_timeout: int = 30

    # Banco de dados (PostgreSQL em produção, SQLite em dev)
    database_url: Optional[str] = None

    # Stripe (webhook para gerar API keys após pagamento)
    stripe_webhook_secret: Optional[str] = None
    stripe_price_pro: Optional[str] = None
    stripe_price_enterprise: Optional[str] = None

    # Resend (envio de email com API key após pagamento)
    resend_api_key: Optional[str] = None
    resend_from_email: str = "BacenData <noreply@bacendata.com>"

    # Sentry (rastreamento de erros em produção)
    sentry_dsn: Optional[str] = None

    # Cache
    cache_ativo: bool = True

    model_config = {"env_prefix": "BACENDATA_", "env_file": ".env", "extra": "ignore"}


settings = Settings()
