"""
NexAgent 系统提示词
"""

# 系统内置提示词
SYSTEM_PROMPT = ""


def get_system_prompt() -> str:
    """获取系统提示词"""
    return SYSTEM_PROMPT
