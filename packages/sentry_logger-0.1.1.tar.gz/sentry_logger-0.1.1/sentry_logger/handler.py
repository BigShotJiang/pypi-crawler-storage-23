"""
Logging handler that buffers log records and sends them in batches to the Sentry ingest API.
"""
from __future__ import annotations

import atexit
import io
import json
import logging
import sys
import threading
import time
import traceback
import urllib.request
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .config import SentryLoggerConfig


class SentryLogHandler(logging.Handler):
    """
    Buffers log records and POSTs them in batches to the Sentry ingest endpoint.
    Uses a background thread for non-blocking sends.
    """

    def __init__(self, config: SentryLoggerConfig):
        super().__init__()
        self.config = config
        self._buffer: list[str] = []
        self._lock = threading.Lock()
        self._shutdown = False
        self._last_flush = time.monotonic()
        self.setFormatter(
            logging.Formatter("%(asctime)s [%(levelname)s] [%(name)s]: %(message)s")
        )
        atexit.register(self.flush)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            with self._lock:
                self._buffer.append(msg)
                now = time.monotonic()
                if (
                    len(self._buffer) >= self.config.batch_size
                    or (now - self._last_flush) >= self.config.flush_interval_seconds
                ):
                    self._flush_locked()
        except Exception:
            self.handleError(record)

    def _flush_locked(self) -> None:
        if not self._buffer:
            return
        logs = self._buffer[:]
        self._buffer = []
        self._last_flush = time.monotonic()
        threading.Thread(target=self._send, args=(logs,), daemon=True).start()

    def _send(self, logs: list[str]) -> None:
        try:
            body = json.dumps({"logs": logs}).encode("utf-8")
            req = urllib.request.Request(
                self.config.ingest_url,
                data=body,
                method="POST",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self.config.api_key}",
                    "X-API-Key": self.config.api_key,
                },
            )
            urllib.request.urlopen(req, timeout=10)
        except Exception:
            pass  # Fail silently to avoid disrupting the app

    def flush(self) -> None:
        with self._lock:
            self._flush_locked()


class _PrintCapture(io.TextIOBase):
    """Redirect writes to stdout/stderr into the Python logging system."""

    def __init__(self, level: int, original: io.TextIOBase) -> None:
        super().__init__()
        self._level = level
        self._original = original
        self._logger = logging.getLogger("print")

    def write(self, msg: str) -> int:
        stripped = msg.rstrip("\n")
        if stripped:
            self._logger.log(self._level, stripped)
        self._original.write(msg)
        return len(msg)

    def flush(self) -> None:
        self._original.flush()


def capture_print_statements() -> None:
    """
    Route all print() output through the root logger so it is captured by
    SentryLogHandler without any changes to application code.
    The original stdout/stderr are still written to, so local output is preserved.
    """
    sys.stdout = _PrintCapture(logging.INFO, sys.__stdout__)  # type: ignore[assignment]
    sys.stderr = _PrintCapture(logging.WARNING, sys.__stderr__)  # type: ignore[assignment]


def capture_unhandled_exceptions() -> None:
    """
    Log unhandled exceptions as CRITICAL before the interpreter exits.
    """
    _original_hook = sys.excepthook

    def _hook(exc_type: type, exc_value: BaseException, exc_tb: object) -> None:
        if not issubclass(exc_type, KeyboardInterrupt):
            tb_str = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
            logging.getLogger("sentry_logger.exceptions").critical(
                f"Unhandled exception:\n{tb_str}"
            )
        _original_hook(exc_type, exc_value, exc_tb)

    sys.excepthook = _hook
