# Sentry Logger SDK (Python)

Push logs from your Python app to the Sentry dashboard — zero code changes required.

## Installation

```bash
pip install sentry-logger
```

## Step 1 — Link your app (one-time)

```bash
sentry-logger init --app-name "my-service"
```

This opens a browser sign-in, registers your app, and saves credentials to
`~/.sentry_logger/config.json`. Check the linked app anytime with:

```bash
sentry-logger status
```

## Step 2 — Add one line to `main.py`

```python
from sentry_logger import init
init()  # that's it — nothing else to change anywhere
```

After this single call, **everything** flows to Sentry automatically:

| Source | Captured? |
|---|---|
| `logging.info/warning/error/critical(...)` in any module | ✅ |
| `print()` anywhere in your app | ✅ |
| Uvicorn / Gunicorn request logs | ✅ |
| Unhandled exceptions (crashes) | ✅ |

You do **not** need to add `logging.xxx()` calls to individual functions or routes.

## FastAPI example (zero changes to routes)

```python
from sentry_logger import init
init()  # must be before FastAPI import so uvicorn loggers are hooked

from fastapi import FastAPI
app = FastAPI()

@app.get("/")
def read_root():
    return {"Hello": "World"}          # uvicorn logs this request automatically

@app.get("/items/{item_id}")
def read_item(item_id: int):
    print("processing item")           # print() is also captured
    return {"item_id": item_id}
```

## How it works

`init()` attaches to the **root Python logger**, which means every library and
module in your app already propagates logs to it. It also:

- Redirects `stdout`/`stderr` through logging so `print()` is captured
- Installs a `sys.excepthook` to log unhandled exceptions as `CRITICAL`
- Flushes batches every 5 seconds or every 50 log lines (configurable)

## Service grouping

Name your loggers after services to group them in the dashboard:

```python
import logging
logger = logging.getLogger("PaymentService")
logger.warning("Payment retry attempt")   # shows under "PaymentService" tab
```

Uvicorn access logs appear under the `uvicorn.access` service group automatically.

## Configuration reference

| Parameter | Default | Description |
|---|---|---|
| `api_key` | — | API key (`sk_...`). If omitted, loaded from CLI config |
| `dsn` | — | Backend URL. Falls back to `SENTRY_INGEST_URL` env or production endpoint |
| `batch_size` | `50` | Send when buffer reaches this size |
| `flush_interval_seconds` | `5.0` | Auto-flush interval in seconds |
| `redirect_print` | `True` | Capture `print()` / stdout / stderr |
| `capture_exceptions` | `True` | Log unhandled crashes as CRITICAL |

## Explicit configuration

```python
from sentry_logger import init

init(
    api_key="sk_...",
    dsn="http://localhost:9000",
    redirect_print=True,       # default
    capture_exceptions=True,   # default
)
```
