"""
AITracer SDK - Monitor your AI/LLM applications

Usage:
    from aitracer import AITracer
    from openai import OpenAI

    tracer = AITracer(api_key="at-xxxxxxxx", project="my-chatbot")
    client = tracer.wrap_openai(OpenAI())

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "Hello!"}]
    )

LangChain Integration:
    from aitracer.integrations.langchain import AITracerCallbackHandler
    from langchain_openai import ChatOpenAI

    handler = AITracerCallbackHandler(api_key="at-xxx", project="my-langchain-app")
    llm = ChatOpenAI(callbacks=[handler])
"""

from aitracer.client import AITracer
from aitracer.pii import PIIDetector
from aitracer.session import Session
from aitracer.trace import Trace

__version__ = "0.1.3"
__all__ = ["AITracer", "Trace", "Session", "PIIDetector"]
