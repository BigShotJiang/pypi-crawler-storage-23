from lorai_workspace.client import LorAI

__version__ = "0.1.2"
PORT = 1842
__all__ = ["LorAI", "PORT"]
