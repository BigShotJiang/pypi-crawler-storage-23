from .reader import get_text

__version__ = "0.1.0"
__all__ = ["get_text"]