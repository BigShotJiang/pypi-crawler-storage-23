from setuptools import setup, find_packages

setup(
    name="greninja",
    version="0.1.0",
    author="Aditya",
    author_email="parekhaditya2004@email.com",
    description="A library to read and print contents of TXT, PDF, and DOCX files",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",  # optional
    packages=find_packages(),
    package_data={
        "greninja": ["data/*"],  # include all files in data folder
    },
    install_requires=[
        "pdfplumber",
        "python-docx",
    ],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)