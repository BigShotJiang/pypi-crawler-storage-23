# greninja

A simple Python library to read contents of TXT, PDF, and DOCX files.

## Installation
pip install greninja

## Usage
import greninja as nlpp

# Read a file bundled inside the library
print(nlpp.get_text("sample.txt"))

# Read any file from your computer
print(nlpp.get_text("C:/Users/you/documents/report.pdf"))