from __future__ import annotations

from dataclasses import dataclass

from agent_council.adapters.base import BaseModelAdapter


class BudgetExceededError(RuntimeError):
    pass


@dataclass
class BudgetManager:
    max_budget_usd: float | None = None
    hard_stop: bool = True
    spent_usd: float = 0.0

    def allow(self, cost: float) -> bool:
        if self.max_budget_usd is None:
            return True
        return (self.spent_usd + max(cost, 0.0)) <= self.max_budget_usd

    def spend(self, cost: float) -> None:
        if self.max_budget_usd is None:
            self.spent_usd += max(cost, 0.0)
            return
        next_spent = self.spent_usd + max(cost, 0.0)
        if next_spent > self.max_budget_usd and self.hard_stop:
            raise BudgetExceededError(
                f"Budget exceeded: attempted {next_spent:.2f} > {self.max_budget_usd:.2f} USD"
            )
        self.spent_usd = min(next_spent, self.max_budget_usd)


class BudgetingAdapter(BaseModelAdapter):
    """Adapter wrapper that enforces a per-call cost against a budget manager."""

    def __init__(self, inner: BaseModelAdapter, cost_per_call_usd: float, manager: BudgetManager):
        self._inner = inner
        self._cost = float(cost_per_call_usd or 0.0)
        self._manager = manager

    async def complete(self, system: str, user: str) -> str:
        if not self._manager.allow(self._cost):
            # Spend to trigger exception or track soft overflow
            self._manager.spend(self._cost)
        else:
            self._manager.spend(self._cost)
        return await self._inner.complete(system=system, user=user)

