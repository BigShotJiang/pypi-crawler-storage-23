from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class ConsensusLevel(str, Enum):
    STRONG = "strong"
    MODERATE = "moderate"
    WEAK = "weak"
    NONE = "none"


@dataclass
class MemberResponse:
    member_id: str
    member_name: str
    round_number: int
    content: str
    stance: str = ""
    confidence: float = 0.5
    changed_position: bool = False


@dataclass
class DebateRound:
    round_number: int
    responses: list[MemberResponse] = field(default_factory=list)
    consensus_score: float = 0.0


@dataclass
class FinalVerdict:
    topic: str
    verdict: str
    consensus_level: ConsensusLevel
    consensus_score: float
    key_agreements: list[str] = field(default_factory=list)
    dissenting_views: list[str] = field(default_factory=list)
    rounds_completed: int = 0
    early_exit: bool = False
    total_duration_seconds: float = 0.0


@dataclass
class CouncilSession:
    session_id: str
    topic: str
    started_at: datetime
    rounds: list[DebateRound] = field(default_factory=list)
    verdict: Optional[FinalVerdict] = None
