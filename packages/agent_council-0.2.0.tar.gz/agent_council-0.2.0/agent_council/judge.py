from __future__ import annotations

import json
import logging

from agent_council.adapters.base import BaseModelAdapter
from agent_council.types import ConsensusLevel, CouncilSession, FinalVerdict

logger = logging.getLogger(__name__)

_JUDGE_SYSTEM = """\
You are a neutral synthesis judge for a multi-agent debate council.
Your role is to objectively synthesize the debate, identify areas of agreement and disagreement,
and deliver a balanced final verdict. You have no personal opinions — only synthesis.
""".strip()

_JUDGE_SCHEMA = """
Respond with valid JSON only (no markdown fences). Schema:
{
  "verdict": "<2-4 sentence synthesis and conclusion>",
  "key_agreements": ["<agreement 1>", "<agreement 2>", ...],
  "dissenting_views": ["<dissent 1>", "<dissent 2>", ...]
}
""".strip()


def _build_transcript(session: CouncilSession) -> str:
    lines = [f"TOPIC: {session.topic}\n"]
    for debate_round in session.rounds:
        lines.append(f"=== Round {debate_round.round_number} (consensus: {debate_round.consensus_score:.2f}) ===")
        for r in debate_round.responses:
            lines.append(f"\n[{r.member_name}]")
            lines.append(f"Stance: {r.stance}")
            if r.changed_position:
                lines.append("(changed position from previous round)")
            lines.append(f"Confidence: {r.confidence:.2f}")
            lines.append(r.content)
        lines.append("")
    return "\n".join(lines)


def _score_to_level(score: float) -> ConsensusLevel:
    if score >= 0.8:
        return ConsensusLevel.STRONG
    if score >= 0.6:
        return ConsensusLevel.MODERATE
    if score >= 0.4:
        return ConsensusLevel.WEAK
    return ConsensusLevel.NONE


class JudgeAgent:
    def __init__(self, adapter: BaseModelAdapter):
        self._adapter = adapter

    async def render_verdict(self, session: CouncilSession, duration_seconds: float) -> FinalVerdict:
        transcript = _build_transcript(session)
        user_prompt = f"{transcript}\n\n{_JUDGE_SCHEMA}"

        raw = await self._adapter.complete(system=_JUDGE_SYSTEM, user=user_prompt)

        final_consensus = session.rounds[-1].consensus_score if session.rounds else 0.0
        rounds_completed = len(session.rounds)
        early_exit = (
            rounds_completed > 1
            and final_consensus >= 0.85
            and rounds_completed < 99  # placeholder, orchestrator knows the max
        )

        try:
            data = json.loads(raw.strip())
            verdict = str(data.get("verdict", raw))
            key_agreements = [str(a) for a in data.get("key_agreements", [])]
            dissenting_views = [str(d) for d in data.get("dissenting_views", [])]
        except (json.JSONDecodeError, TypeError, ValueError):
            logger.warning("Judge returned non-JSON; using raw text as verdict")
            verdict = raw
            key_agreements = []
            dissenting_views = []

        return FinalVerdict(
            topic=session.topic,
            verdict=verdict,
            consensus_level=_score_to_level(final_consensus),
            consensus_score=final_consensus,
            key_agreements=key_agreements,
            dissenting_views=dissenting_views,
            rounds_completed=rounds_completed,
            early_exit=early_exit,
            total_duration_seconds=duration_seconds,
        )
