from __future__ import annotations

import asyncio
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from agent_council.orchestrator import CouncilOrchestrator
from agent_council.types import ConsensusLevel, DebateRound, FinalVerdict, MemberResponse

app = typer.Typer(name="council", help="Run a multi-agent debate council on any topic.", add_completion=False)
console = Console()

_CONSENSUS_COLOR = {
    ConsensusLevel.STRONG: "green",
    ConsensusLevel.MODERATE: "yellow",
    ConsensusLevel.WEAK: "orange3",
    ConsensusLevel.NONE: "red",
}


def _confidence_bar(conf: float, width: int = 20) -> str:
    filled = int(conf * width)
    return "█" * filled + "░" * (width - filled)


def _member_panel(resp: MemberResponse) -> Panel:
    from rich.text import Text

    changed_tag = " [yellow](position changed)[/yellow]" if resp.changed_position else ""
    bar = _confidence_bar(resp.confidence)
    header = (
        f"[bold]{resp.member_name}[/bold]{changed_tag}\n"
        f"[dim]stance:[/dim] {resp.stance or '(none)'}\n"
        f"[dim]confidence:[/dim] {bar} {resp.confidence:.0%}"
    )
    return Panel(
        f"{header}\n\n{resp.content}",
        title=f"[bold blue]{resp.member_name}[/bold blue] · Round {resp.round_number}",
        border_style="blue",
        padding=(1, 2),
    )


def _print_verdict(verdict: FinalVerdict) -> None:
    level_color = _CONSENSUS_COLOR.get(verdict.consensus_level, "white")

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column(style="dim", no_wrap=True)
    table.add_column()
    table.add_row("Topic", verdict.topic)
    table.add_row(
        "Consensus",
        f"[{level_color}]{verdict.consensus_level.value.upper()}[/{level_color}]  ({verdict.consensus_score * 100:.1f}%)",
    )
    table.add_row("Rounds", str(verdict.rounds_completed) + (" (early exit)" if verdict.early_exit else ""))
    table.add_row("Duration", f"{verdict.total_duration_seconds:.1f}s")

    console.print("\n")
    console.print(Panel(table, title="[bold green]Final Verdict[/bold green]", border_style="green", padding=(1, 2)))
    console.print(Panel(verdict.verdict, title="[bold]Synthesis[/bold]", border_style="green", padding=(1, 2)))

    if verdict.key_agreements:
        items = "\n".join(f"  [green]✓[/green] {a}" for a in verdict.key_agreements)
        console.print(Panel(items, title="[bold]Key Agreements[/bold]", border_style="dim green", padding=(0, 2)))

    if verdict.dissenting_views:
        items = "\n".join(f"  [red]✗[/red] {d}" for d in verdict.dissenting_views)
        console.print(Panel(items, title="[bold]Dissenting Views[/bold]", border_style="dim red", padding=(0, 2)))


@app.command()
def review(
    topic: str = typer.Argument(..., help="The topic or question for the council to debate."),
    config: Path = typer.Option(Path("config/council.yaml"), "--config", "-c", help="Path to council YAML config file.", exists=True, readable=True),
    no_rounds: bool = typer.Option(False, "--no-rounds", help="Suppress per-round output; show only the final verdict."),
    trace_file: Path | None = typer.Option(None, "--trace-file", help="Write a JSON trace to this file (or to a directory if a folder is provided)."),
) -> None:
    console.print(f"\n[bold]Council:[/bold] Loading config from [cyan]{config}[/cyan]")

    try:
        orchestrator = CouncilOrchestrator.from_config_file(config)
    except Exception as exc:
        console.print(f"[red]Failed to load config:[/red] {exc}")
        raise typer.Exit(1)

    member_names = [m.name for m in orchestrator._members]
    console.print(f"[bold]Members:[/bold] {', '.join(member_names)}")
    console.print(f"[bold]Topic:[/bold] {topic}\n")

    current_round: list[int] = [0]

    def on_member(resp: MemberResponse) -> None:
        if no_rounds:
            return
        if resp.round_number != current_round[0]:
            current_round[0] = resp.round_number
            console.print(f"\n[bold cyan]Round {resp.round_number}[/bold cyan]")
        console.print(_member_panel(resp))

    def on_round(round_: DebateRound) -> None:
        if no_rounds:
            return
        console.print(
            f"[dim]  Round {round_.round_number} complete — consensus: {round_.consensus_score * 100:.1f}%[/dim]"
        )

    from agent_council.tracing import TraceRecorder

    console.print("[dim]Running debate…[/dim]")
    try:
        rec = TraceRecorder() if trace_file else None
        session, verdict = asyncio.run(
            orchestrator.run(topic, on_member_response=on_member, on_round_complete=on_round, trace=rec)
        )
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow]")
        raise typer.Exit(0)
    except Exception as exc:
        console.print(f"[red]Council run failed:[/red] {exc}")
        raise typer.Exit(1)

    _print_verdict(verdict)

    if trace_file:
        # If a directory is given, save under that dir using session_id.json
        if trace_file.exists() and trace_file.is_dir():
            out = rec.save(trace_file)  # type: ignore[arg-type]
        else:
            # Ensure parent exists, then write with the exact filename
            trace_file.parent.mkdir(parents=True, exist_ok=True)
            import json
            payload = {
                "session_id": session.session_id,
                "topic": session.topic,
                "started_at": session.started_at.isoformat(),
                "events": rec.events,  # type: ignore[union-attr]
            }
            trace_file.write_text(json.dumps(payload, indent=2))
            out = trace_file
        console.print(f"[dim]Trace written to {out}[/dim]")


@app.command()
def serve(
    config: Path = typer.Option(Path("config/council.yaml"), "--config", "-c", help="Default council config path (used when requests omit config)."),
    host: str = typer.Option("127.0.0.1", "--host", help="Bind host."),
    port: int = typer.Option(8000, "--port", "-p", help="Bind port."),
    reload: bool = typer.Option(False, "--reload", help="Auto-reload on code changes (dev mode)."),
) -> None:
    try:
        import uvicorn
        from agent_council.server import create_app
    except ImportError:
        console.print('[red]Server dependencies missing.[/red] Install with: [cyan]pip install -e ".[server]"[/cyan]')
        raise typer.Exit(1)

    console.print(f"[bold green]Agent Council server[/bold green] listening on [cyan]http://{host}:{port}[/cyan]")
    console.print(f"[dim]Docs: http://{host}:{port}/docs[/dim]\n")

    uvicorn.run("agent_council.server:create_app", factory=True, host=host, port=port, reload=reload)


if __name__ == "__main__":
    app()
