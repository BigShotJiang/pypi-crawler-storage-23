from __future__ import annotations

import time
import uuid
from datetime import datetime
from pathlib import Path

from agent_council.adapters import build_adapter
from agent_council.config import (
    CouncilConfig,
    FullConfig,
    JudgeConfig,
    MemberConfig,
    ProvidersConfig,
    load_config,
)
from agent_council.debate import DebateEngine, MemberCallback, RoundCallback
from agent_council.judge import JudgeAgent
from agent_council.member import CouncilMember
from agent_council.types import CouncilSession, FinalVerdict
from agent_council.budget import BudgetManager, BudgetingAdapter, BudgetExceededError
from agent_council.tracing import TraceRecorder


class CouncilOrchestrator:
    """
    Primary entry point for running a council debate.

    Programmatic usage (no config file needed)::

        from agent_council import CouncilOrchestrator, MemberConfig, JudgeConfig

        orchestrator = CouncilOrchestrator(
            members=[
                MemberConfig(
                    id="analyst",
                    name="The Analyst",
                    provider="anthropic",
                    model="claude-sonnet-4-6",
                    persona="Rigorous analytical thinker.",
                ),
                MemberConfig(
                    id="skeptic",
                    name="The Skeptic",
                    provider="openai",
                    model="gpt-4o",
                    persona="Challenge every assumption.",
                ),
            ],
            judge=JudgeConfig(provider="anthropic", model="claude-opus-4-6"),
        )

        session, verdict = await orchestrator.run("Should we adopt microservices?")

    Config-file usage::

        orchestrator = CouncilOrchestrator.from_config_file("config/council.yaml")
    """

    def __init__(
        self,
        members: list[MemberConfig],
        judge: JudgeConfig,
        rounds: int = 3,
        early_exit_threshold: float = 0.85,
        provider_configs: ProvidersConfig | None = None,
    ) -> None:
        """
        Args:
            members: Council member definitions (persona, model, provider).
            judge: Judge model definition.
            rounds: Maximum number of debate rounds.
            early_exit_threshold: Consensus score (0–1) that triggers early exit.
            provider_configs: Optional provider-level overrides (API keys, temperature, etc.).
                              Defaults to reading API keys from environment variables.
        """
        council_cfg = CouncilConfig(
            debate_rounds=rounds,
            early_exit_threshold=early_exit_threshold,
        )
        # Build a FullConfig so the adapter factory can resolve provider settings
        _full_cfg = FullConfig(
            council=council_cfg,
            members=members,
            judge=judge,
            providers=provider_configs or ProvidersConfig(),
        )

        # Optional budget awareness via env/config (simple per-call estimate).
        # These env vars offer a quick path without changing the config schema.
        import os
        cost_per_call = float(os.environ.get("COUNCIL_COST_PER_CALL_USD", "0") or 0)
        max_budget = os.environ.get("COUNCIL_MAX_BUDGET_USD")
        hard_stop = os.environ.get("COUNCIL_BUDGET_HARD_STOP", "1") not in {"0", "false", "False"}
        manager = BudgetManager(
            max_budget_usd=float(max_budget) if max_budget else None,
            hard_stop=hard_stop,
        )

        def maybe_wrap(a):
            return BudgetingAdapter(a, cost_per_call, manager) if cost_per_call or manager.max_budget_usd is not None else a

        self._members = [CouncilMember(m, maybe_wrap(build_adapter(m, _full_cfg))) for m in members]
        judge_as_member = MemberConfig(
            id="judge",
            name="Judge",
            provider=judge.provider,
            model=judge.model,
        )
        self._judge = JudgeAgent(maybe_wrap(build_adapter(judge_as_member, _full_cfg)))
        self._engine = DebateEngine(self._members, council_cfg)

    @classmethod
    def from_config_file(cls, path: str | Path = "config/council.yaml") -> CouncilOrchestrator:
        """Load council definition from a YAML file."""
        cfg = load_config(path)
        return cls(
            members=cfg.members,
            judge=cfg.judge,
            rounds=cfg.council.debate_rounds,
            early_exit_threshold=cfg.council.early_exit_threshold,
            provider_configs=cfg.providers,
        )

    async def run(
        self,
        topic: str,
        on_member_response: MemberCallback | None = None,
        on_round_complete: RoundCallback | None = None,
        trace: TraceRecorder | None = None,
    ) -> tuple[CouncilSession, FinalVerdict]:
        """
        Run the full debate and return the session transcript and final verdict.

        Args:
            topic: The question or topic to debate.
            on_member_response: Optional callback fired as each member responds (sync or async).
            on_round_complete: Optional callback fired after each round completes (sync or async).

        Returns:
            (CouncilSession, FinalVerdict)
        """
        session = CouncilSession(
            session_id=str(uuid.uuid4()),
            topic=topic,
            started_at=datetime.now(),
        )
        start = time.monotonic()
        if trace is not None:
            trace.start(session.session_id, topic)

        async def _wrap_member(resp):
            if trace is not None:
                trace.record_member_response(resp)
            if on_member_response:
                res = on_member_response(resp)
                if hasattr(res, '__await__'):
                    await res

        async def _wrap_round(round_):
            if trace is not None:
                trace.record_round(round_)
            if on_round_complete:
                res = on_round_complete(round_)
                if hasattr(res, '__await__'):
                    await res

        await self._engine.run(
            session,
            on_member_response=_wrap_member,
            on_round_complete=_wrap_round,
        )
        duration = time.monotonic() - start

        verdict = await self._judge.render_verdict(session, duration)
        if trace is not None:
            trace.record_verdict(verdict)
        session.verdict = verdict
        return session, verdict
