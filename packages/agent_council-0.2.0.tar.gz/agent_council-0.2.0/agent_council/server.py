"""
FastAPI server for the Agent Council.

Install extras:  pip install -e ".[server]"
Run:             council serve
                 uvicorn agent_council.server:create_app --factory --reload
"""
from __future__ import annotations

import asyncio
import dataclasses
import json
from pathlib import Path
from typing import AsyncGenerator

from agent_council.orchestrator import CouncilOrchestrator
from agent_council.types import DebateRound, FinalVerdict, MemberResponse

try:
    from fastapi import FastAPI, HTTPException
    from fastapi.responses import StreamingResponse
    from pydantic import BaseModel as ApiModel
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "FastAPI is required for the server. "
        'Install it with: pip install -e ".[server]"'
    ) from exc


# ---------------------------------------------------------------------------
# JSON serialization helpers
# ---------------------------------------------------------------------------

class _Encoder(json.JSONEncoder):
    def default(self, obj):
        if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
            return dataclasses.asdict(obj)
        if hasattr(obj, "value"):          # Enum
            return obj.value
        return super().default(obj)


def _dumps(obj) -> str:
    return json.dumps(obj, cls=_Encoder)


def _sse(event: str, data: object) -> str:
    payload = _dumps({"event": event, "data": data})
    return f"data: {payload}\n\n"


# ---------------------------------------------------------------------------
# Request / response schemas
# ---------------------------------------------------------------------------

class ReviewRequest(ApiModel):
    topic: str
    config: str = "config/council.yaml"


class ReviewResponse(ApiModel):
    session_id: str
    topic: str
    rounds_completed: int
    consensus_level: str
    consensus_score: float
    verdict: str
    key_agreements: list[str]
    dissenting_views: list[str]
    early_exit: bool
    total_duration_seconds: float


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app() -> FastAPI:
    api = FastAPI(
        title="Agent Council",
        description="Multi-agent debate council API",
        version="0.1.0",
    )

    @api.get("/health")
    async def health():
        return {"status": "ok"}

    @api.post("/review", response_model=ReviewResponse)
    async def review(req: ReviewRequest):
        config_path = Path(req.config)
        if not config_path.exists():
            raise HTTPException(status_code=404, detail=f"Config not found: {req.config}")
        try:
            orchestrator = CouncilOrchestrator.from_config_file(config_path)
            session, verdict = await orchestrator.run(req.topic)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc))

        return ReviewResponse(
            session_id=session.session_id,
            topic=verdict.topic,
            rounds_completed=verdict.rounds_completed,
            consensus_level=verdict.consensus_level.value,
            consensus_score=verdict.consensus_score,
            verdict=verdict.verdict,
            key_agreements=verdict.key_agreements,
            dissenting_views=verdict.dissenting_views,
            early_exit=verdict.early_exit,
            total_duration_seconds=verdict.total_duration_seconds,
        )

    @api.post("/review/stream")
    async def review_stream(req: ReviewRequest):
        """Server-Sent Events endpoint. Streams events as members respond."""
        config_path = Path(req.config)
        if not config_path.exists():
            raise HTTPException(status_code=404, detail=f"Config not found: {req.config}")

        queue: asyncio.Queue[str | None] = asyncio.Queue()

        async def on_member(resp: MemberResponse) -> None:
            await queue.put(_sse("member_response", resp))

        async def on_round(round_: DebateRound) -> None:
            # Send lightweight round summary (omit full response bodies to avoid duplication)
            summary = {
                "round_number": round_.round_number,
                "consensus_score": round_.consensus_score,
            }
            await queue.put(_sse("round_complete", summary))

        async def run_council() -> None:
            try:
                orchestrator = CouncilOrchestrator.from_config_file(config_path)
                _, verdict = await orchestrator.run(
                    req.topic,
                    on_member_response=on_member,
                    on_round_complete=on_round,
                )
                await queue.put(_sse("verdict", verdict))
            except Exception as exc:
                await queue.put(_sse("error", {"message": str(exc)}))
            finally:
                await queue.put(None)  # sentinel

        async def event_stream() -> AsyncGenerator[str, None]:
            asyncio.create_task(run_council())
            while True:
                item = await queue.get()
                if item is None:
                    break
                yield item

        return StreamingResponse(event_stream(), media_type="text/event-stream")

    return api
