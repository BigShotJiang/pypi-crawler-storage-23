from __future__ import annotations

from agent_council.adapters.base import BaseModelAdapter
from agent_council.adapters.anthropic_adapter import AnthropicAdapter
from agent_council.adapters.openai_adapter import OpenAIAdapter
from agent_council.adapters.ollama_adapter import OllamaAdapter
from agent_council.adapters.openrouter_adapter import OpenRouterAdapter
from agent_council.config import FullConfig, MemberConfig


def build_adapter(member_cfg: MemberConfig, full_config: FullConfig) -> BaseModelAdapter:
    provider_cfg = full_config.get_provider_config(member_cfg.provider)
    if provider_cfg is None:
        raise ValueError(f"Unknown provider: {member_cfg.provider!r}")

    match member_cfg.provider:
        case "anthropic":
            return AnthropicAdapter(member_cfg, provider_cfg)
        case "openai":
            return OpenAIAdapter(member_cfg, provider_cfg)
        case "ollama":
            return OllamaAdapter(member_cfg, provider_cfg)
        case "openrouter":
            return OpenRouterAdapter(member_cfg, provider_cfg)
        case _:
            raise ValueError(f"No adapter registered for provider: {member_cfg.provider!r}")


__all__ = [
    "BaseModelAdapter",
    "AnthropicAdapter",
    "OpenAIAdapter",
    "OllamaAdapter",
    "OpenRouterAdapter",
    "build_adapter",
]
