from __future__ import annotations

import os

import openai

from agent_council.adapters.base import BaseModelAdapter
from agent_council.config import MemberConfig, OpenRouterProviderConfig


class OpenRouterAdapter(BaseModelAdapter):
    """Adapter that talks to OpenRouter's OpenAI-compatible API.

    Uses the official OpenAI SDK pointed at the OpenRouter base URL.
    Expects an API key in the environment (default: ``OPENROUTER_API_KEY``).
    """

    def __init__(self, member_cfg: MemberConfig, provider_cfg: OpenRouterProviderConfig):
        api_key = os.environ.get(provider_cfg.api_key_env, "")
        # Optional recommended headers per OpenRouter docs
        headers: dict[str, str] = {}
        if getattr(provider_cfg, "http_referer", None):
            headers["HTTP-Referer"] = provider_cfg.http_referer  # type: ignore[attr-defined]
        if getattr(provider_cfg, "x_title", None):
            headers["X-Title"] = provider_cfg.x_title  # type: ignore[attr-defined]
        # OpenAI-compatible client against OpenRouter
        self._client = openai.AsyncOpenAI(
            api_key=api_key,
            base_url=provider_cfg.base_url,
            default_headers=headers or None,
        )
        self._model = self._normalize_model(member_cfg.model)
        self._max_tokens = provider_cfg.max_tokens
        self._temperature = provider_cfg.temperature

    async def complete(self, system: str, user: str) -> str:
        response = await self._client.chat.completions.create(
            model=self._model,
            max_tokens=self._max_tokens,
            temperature=self._temperature,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        return response.choices[0].message.content or ""

    @staticmethod
    def _normalize_model(model: str) -> str:
        """Accept vendorless names (e.g., "gpt-4o", "claude-3.5-sonnet") and
        map them to OpenRouter's vendor-qualified names. If a vendor prefix is
        already present (contains '/'), leave as-is.
        """
        if "/" in model:
            return model
        m = model.lower()
        if m.startswith("gpt"):
            return f"openai/{model}"
        if m.startswith("claude"):
            return f"anthropic/{model}"
        if "llama" in m:
            return f"meta-llama/{model}"
        return model
