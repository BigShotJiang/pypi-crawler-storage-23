from abc import ABC, abstractmethod


class BaseModelAdapter(ABC):
    @abstractmethod
    async def complete(self, system: str, user: str) -> str:
        """Send a system + user message and return the model's text response."""
        ...
