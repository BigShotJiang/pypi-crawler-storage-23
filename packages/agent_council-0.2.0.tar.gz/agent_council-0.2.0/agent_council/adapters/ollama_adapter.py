from __future__ import annotations

import httpx

from agent_council.adapters.base import BaseModelAdapter
from agent_council.config import MemberConfig, OllamaProviderConfig


class OllamaAdapter(BaseModelAdapter):
    def __init__(self, member_cfg: MemberConfig, provider_cfg: OllamaProviderConfig):
        self._base_url = provider_cfg.base_url.rstrip("/")
        self._model = member_cfg.model
        self._timeout = provider_cfg.timeout

    async def complete(self, system: str, user: str) -> str:
        payload = {
            "model": self._model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": False,
        }
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(f"{self._base_url}/api/chat", json=payload)
            response.raise_for_status()
            data = response.json()
            return data["message"]["content"]
