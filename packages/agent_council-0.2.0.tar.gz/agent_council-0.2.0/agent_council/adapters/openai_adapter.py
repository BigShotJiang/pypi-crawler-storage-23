from __future__ import annotations

import os

import openai

from agent_council.adapters.base import BaseModelAdapter
from agent_council.config import MemberConfig, OpenAIProviderConfig


class OpenAIAdapter(BaseModelAdapter):
    def __init__(self, member_cfg: MemberConfig, provider_cfg: OpenAIProviderConfig):
        api_key = os.environ.get(provider_cfg.api_key_env, "")
        self._client = openai.AsyncOpenAI(api_key=api_key)
        self._model = member_cfg.model
        self._max_tokens = provider_cfg.max_tokens
        self._temperature = provider_cfg.temperature

    async def complete(self, system: str, user: str) -> str:
        response = await self._client.chat.completions.create(
            model=self._model,
            max_tokens=self._max_tokens,
            temperature=self._temperature,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        return response.choices[0].message.content or ""
