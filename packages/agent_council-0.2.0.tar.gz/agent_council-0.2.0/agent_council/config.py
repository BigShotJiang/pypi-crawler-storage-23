from __future__ import annotations

from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field


class CouncilConfig(BaseModel):
    name: str = "General Review Council"
    debate_rounds: int = 3
    early_exit_threshold: float = 0.85
    voting_strategy: str = "weighted"


class MemberConfig(BaseModel):
    id: str
    name: str
    provider: str
    model: str
    weight: float = 1.0
    persona: str = ""


class JudgeConfig(BaseModel):
    provider: str
    model: str


class AnthropicProviderConfig(BaseModel):
    api_key_env: str = "ANTHROPIC_API_KEY"
    max_tokens: int = 2048
    temperature: float = 0.7


class OpenAIProviderConfig(BaseModel):
    api_key_env: str = "OPENAI_API_KEY"
    max_tokens: int = 2048
    temperature: float = 0.7


class OllamaProviderConfig(BaseModel):
    base_url: str = "http://localhost:11434"
    timeout: int = 120


class OpenRouterProviderConfig(BaseModel):
    """OpenRouter provider settings.

    Uses the OpenAI-compatible client with a custom base URL.
    Set ``OPENROUTER_API_KEY`` (or override ``api_key_env``) in your environment.
    """
    api_key_env: str = "OPENROUTER_API_KEY"
    base_url: str = "https://openrouter.ai/api/v1"
    max_tokens: int = 2048
    temperature: float = 0.7
    http_referer: str | None = None
    x_title: str | None = None


class ProvidersConfig(BaseModel):
    anthropic: AnthropicProviderConfig = Field(default_factory=AnthropicProviderConfig)
    openai: OpenAIProviderConfig = Field(default_factory=OpenAIProviderConfig)
    ollama: OllamaProviderConfig = Field(default_factory=OllamaProviderConfig)
    openrouter: OpenRouterProviderConfig = Field(default_factory=OpenRouterProviderConfig)


class FullConfig(BaseModel):
    council: CouncilConfig = Field(default_factory=CouncilConfig)
    members: list[MemberConfig] = Field(default_factory=list)
    judge: JudgeConfig
    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)

    def get_provider_config(self, provider: str):
        return getattr(self.providers, provider, None)


def load_config(path: str | Path = "config/council.yaml") -> FullConfig:
    with open(path) as f:
        data = yaml.safe_load(f)
    return FullConfig.model_validate(data)
