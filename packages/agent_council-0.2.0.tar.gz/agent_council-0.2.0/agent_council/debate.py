from __future__ import annotations

import asyncio
import inspect
import logging
from typing import Callable

from agent_council.config import CouncilConfig
from agent_council.member import CouncilMember
from agent_council.types import CouncilSession, DebateRound, MemberResponse

logger = logging.getLogger(__name__)

# Callbacks may be sync or async — we handle both
MemberCallback = Callable[[MemberResponse], object]
RoundCallback = Callable[[DebateRound], object]


async def _invoke(fn: Callable | None, arg: object) -> None:
    if fn is None:
        return
    result = fn(arg)
    if inspect.isawaitable(result):
        await result


def compute_consensus(responses: list[MemberResponse]) -> float:
    """Score 0-1: average confidence weighted by how many didn't change position."""
    if not responses:
        return 0.0
    avg_confidence = sum(r.confidence for r in responses) / len(responses)
    changed_fraction = sum(1 for r in responses if r.changed_position) / len(responses)
    return avg_confidence * (1.0 - changed_fraction)


class DebateEngine:
    def __init__(self, members: list[CouncilMember], council_cfg: CouncilConfig):
        self._members = members
        self._cfg = council_cfg

    async def run(
        self,
        session: CouncilSession,
        on_member_response: MemberCallback | None = None,
        on_round_complete: RoundCallback | None = None,
    ) -> None:
        topic = session.topic
        max_rounds = self._cfg.debate_rounds
        threshold = self._cfg.early_exit_threshold
        previous_responses: list[MemberResponse] | None = None

        for round_num in range(1, max_rounds + 1):
            logger.info("Starting round %d / %d", round_num, max_rounds)

            # Create individual tasks so we can stream responses as they arrive
            tasks = [
                asyncio.create_task(member.respond(topic, round_num, previous_responses))
                for member in self._members
            ]

            responses: list[MemberResponse] = []
            for coro in asyncio.as_completed(tasks):
                response = await coro
                responses.append(response)
                await _invoke(on_member_response, response)

            consensus = compute_consensus(responses)
            debate_round = DebateRound(
                round_number=round_num,
                responses=responses,
                consensus_score=consensus,
            )
            session.rounds.append(debate_round)
            await _invoke(on_round_complete, debate_round)
            logger.info("Round %d consensus score: %.3f", round_num, consensus)

            previous_responses = responses

            if round_num > 1 and consensus >= threshold:
                logger.info(
                    "Early exit at round %d (consensus %.3f >= %.3f)",
                    round_num, consensus, threshold,
                )
                break
