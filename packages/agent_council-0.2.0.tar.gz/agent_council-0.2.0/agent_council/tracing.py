from __future__ import annotations

import dataclasses
import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from agent_council.types import CouncilSession, DebateRound, FinalVerdict, MemberResponse


@dataclass
class TraceRecorder:
    """Collects trace events and can persist them as JSON.

    Usage:
      rec = TraceRecorder()
      rec.start(session_id, topic)
      rec.record_member_response(...)
      rec.record_round(...)
      rec.record_verdict(...)
      path = rec.save("traces/")
    """

    session_id: str | None = None
    topic: str | None = None
    started_at: datetime | None = None
    events: list[dict[str, Any]] = field(default_factory=list)

    def start(self, session_id: str, topic: str) -> None:
        self.session_id = session_id
        self.topic = topic
        self.started_at = datetime.utcnow()

    def record_member_response(self, resp: MemberResponse) -> None:
        self.events.append(
            {
                "event": "member_response",
                "round_number": resp.round_number,
                "member_id": resp.member_id,
                "member_name": resp.member_name,
                "stance": resp.stance,
                "confidence": resp.confidence,
                "changed_position": resp.changed_position,
                "content": resp.content,
            }
        )

    def record_round(self, round_: DebateRound) -> None:
        self.events.append(
            {
                "event": "round_complete",
                "round_number": round_.round_number,
                "consensus_score": round_.consensus_score,
            }
        )

    def record_verdict(self, verdict: FinalVerdict) -> None:
        self.events.append(
            {
                "event": "verdict",
                "data": {
                    "topic": verdict.topic,
                    "consensus_level": verdict.consensus_level.value,
                    "consensus_score": verdict.consensus_score,
                    "rounds_completed": verdict.rounds_completed,
                    "early_exit": verdict.early_exit,
                    "total_duration_seconds": verdict.total_duration_seconds,
                    "verdict": verdict.verdict,
                    "key_agreements": verdict.key_agreements,
                    "dissenting_views": verdict.dissenting_views,
                },
            }
        )

    def record_error(self, message: str) -> None:
        self.events.append({"event": "error", "message": message})

    def save(self, dir_path: str | Path = "traces") -> Path:
        if not self.session_id:
            raise RuntimeError("TraceRecorder.save() called before start()")
        dirp = Path(dir_path)
        dirp.mkdir(parents=True, exist_ok=True)
        payload = {
            "session_id": self.session_id,
            "topic": self.topic,
            "started_at": (self.started_at or datetime.utcnow()).isoformat(),
            "events": self.events,
        }
        path = dirp / f"{self.session_id}.json"
        path.write_text(json.dumps(payload, indent=2))
        return path

    @classmethod
    def from_session(cls, session: CouncilSession, verdict: FinalVerdict) -> "TraceRecorder":
        rec = cls()
        rec.start(session.session_id, session.topic)
        for r in session.rounds:
            for resp in r.responses:
                rec.record_member_response(resp)
            rec.record_round(r)
        rec.record_verdict(verdict)
        return rec

