from __future__ import annotations

import json
import logging

from agent_council.adapters.base import BaseModelAdapter
from agent_council.config import MemberConfig
from agent_council.types import MemberResponse

logger = logging.getLogger(__name__)

_RESPONSE_SCHEMA = """
Respond with valid JSON only (no markdown fences). Schema:
{
  "stance": "<one sentence summary of your position>",
  "confidence": <float 0.0-1.0 representing how confident you are>,
  "response": "<your full analysis and reasoning>"
}
""".strip()

_ROUND1_TEMPLATE = """\
Topic for debate: {topic}

{schema}
"""

_ROUNDN_TEMPLATE = """\
Topic for debate: {topic}

--- Peer responses from round {prev_round} ---
{peer_block}
--- End of peer responses ---

Review the above. You may revise your position or reinforce it.
{schema}
"""


class CouncilMember:
    def __init__(self, config: MemberConfig, adapter: BaseModelAdapter):
        self.config = config
        self._adapter = adapter

    @property
    def id(self) -> str:
        return self.config.id

    @property
    def name(self) -> str:
        return self.config.name

    @property
    def weight(self) -> float:
        return self.config.weight

    async def respond(
        self,
        topic: str,
        round_number: int,
        previous_round_responses: list[MemberResponse] | None = None,
    ) -> MemberResponse:
        system = self.config.persona or "You are a thoughtful council member."

        if not previous_round_responses:
            user = _ROUND1_TEMPLATE.format(topic=topic, schema=_RESPONSE_SCHEMA)
        else:
            peer_lines = []
            for r in previous_round_responses:
                if r.member_id != self.id:
                    peer_lines.append(f"[{r.member_name}] stance: {r.stance}\n{r.content}")
            peer_block = "\n\n".join(peer_lines) if peer_lines else "(no peer responses available)"
            user = _ROUNDN_TEMPLATE.format(
                topic=topic,
                prev_round=round_number - 1,
                peer_block=peer_block,
                schema=_RESPONSE_SCHEMA,
            )

        raw = await self._adapter.complete(system=system, user=user)

        stance, confidence, content, changed = self._parse_response(raw, previous_round_responses)
        return MemberResponse(
            member_id=self.id,
            member_name=self.name,
            round_number=round_number,
            content=content,
            stance=stance,
            confidence=confidence,
            changed_position=changed,
        )

    def _parse_response(
        self,
        raw: str,
        previous_responses: list[MemberResponse] | None,
    ) -> tuple[str, float, str, bool]:
        try:
            data = json.loads(raw.strip())
            stance = str(data.get("stance", ""))
            confidence = float(data.get("confidence", 0.5))
            confidence = max(0.0, min(1.0, confidence))
            content = str(data.get("response", raw))
        except (json.JSONDecodeError, TypeError, ValueError):
            logger.warning("%s returned non-JSON; falling back to raw text", self.name)
            stance = ""
            confidence = 0.5
            content = raw

        changed = False
        if previous_responses:
            my_prev = next(
                (r for r in previous_responses if r.member_id == self.id), None
            )
            if my_prev and stance and my_prev.stance and stance != my_prev.stance:
                changed = True

        return stance, confidence, content, changed
