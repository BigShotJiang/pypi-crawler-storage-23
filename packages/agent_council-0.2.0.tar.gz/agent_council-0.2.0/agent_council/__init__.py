"""
agent-council — config-driven multi-agent debate council.

Quick start::

    from agent_council import CouncilOrchestrator, MemberConfig, JudgeConfig

    orchestrator = CouncilOrchestrator(
        members=[
            MemberConfig(
                id="analyst", name="The Analyst",
                provider="anthropic", model="claude-sonnet-4-6",
                persona="Rigorous analytical thinker.",
            ),
            MemberConfig(
                id="skeptic", name="The Skeptic",
                provider="openai", model="gpt-4o",
                persona="Challenge every assumption.",
            ),
        ],
        judge=JudgeConfig(provider="anthropic", model="claude-opus-4-6"),
    )

    session, verdict = await orchestrator.run("Should we adopt microservices?")
    print(verdict.verdict)
    print(verdict.consensus_level)   # ConsensusLevel.MODERATE
    print(verdict.key_agreements)
"""
from agent_council.orchestrator import CouncilOrchestrator
from agent_council.config import (
    MemberConfig,
    JudgeConfig,
    ProvidersConfig,
    AnthropicProviderConfig,
    OpenAIProviderConfig,
    OllamaProviderConfig,
)
from agent_council.types import (
    MemberResponse,
    DebateRound,
    FinalVerdict,
    CouncilSession,
    ConsensusLevel,
)

__all__ = [
    # Orchestrator
    "CouncilOrchestrator",
    # Config primitives
    "MemberConfig",
    "JudgeConfig",
    "ProvidersConfig",
    "AnthropicProviderConfig",
    "OpenAIProviderConfig",
    "OllamaProviderConfig",
    # Result types
    "MemberResponse",
    "DebateRound",
    "FinalVerdict",
    "CouncilSession",
    "ConsensusLevel",
]
