# util.py
import ast
import configparser
import logging
import os.path
import sys

import numpy as np

import audeer

from nkululeko.utils.dataframe import DataFrameMixin
from nkululeko.utils.naming import NamingMixin
from nkululeko.utils.storage import StorageMixin


class Util(NamingMixin, StorageMixin, DataFrameMixin):
    # a list of words that need not to be warned upon if default values are
    # used
    stopvals = [
        "all",
        False,
        "False",
        True,
        "True",
        "classification",
        "png",
        "audio_path",
        "kde",
        "pkl",
        "eGeMAPSv02",
        "functionals",
        "n_jobs",
        "uar",
        "mse",
    ]

    def __init__(self, caller=None, has_config=True):
        self.logger = None
        if caller is not None:
            self.caller = caller
        else:
            self.caller = ""
        self.config = None
        if has_config:
            try:
                import nkululeko.glob_conf as glob_conf

                self.config = glob_conf.config
                self.got_data_roots = self.config_val("DATA", "root_folders", False)
                if self.got_data_roots:
                    # if there is a global data rootfolder file, read from
                    # there
                    if not os.path.isfile(self.got_data_roots):
                        self.error(f"no such file: {self.got_data_roots}")
                    self.data_roots = configparser.ConfigParser()
                    self.data_roots.read(self.got_data_roots)
            except ModuleNotFoundError as e:
                self.error(e)
                self.config = None
                self.got_data_roots = False
            except AttributeError as e:
                self.error(e)
                self.config = None
                self.got_data_roots = False

        self.setup_logging()
        # self.logged_configs = set()

    def setup_logging(self):
        # Setup logging
        logger = logging.getLogger(__name__)
        if not logger.hasHandlers():
            logger.setLevel(logging.DEBUG)  # Set the desired logging level

            # Create a console handler
            console_handler = logging.StreamHandler()

            # Create a simple formatter that only shows the message
            class SimpleFormatter(logging.Formatter):
                def format(self, record):
                    return record.getMessage()

            # Set the formatter for the console handler
            console_handler.setFormatter(SimpleFormatter())

            # Add the console handler to the logger
            logger.addHandler(console_handler)
        self.logger = logger

    def get_path(self, entry):
        """This method allows the user to get the directory path for the given argument."""
        if self.config is None:
            # If no configuration file is provided, use default paths
            if entry == "fig_dir":
                dir_name = "./images/"
            elif entry == "res_dir":
                dir_name = "./results/"
            elif entry == "model_dir":
                dir_name = "./models/"
            elif entry == "cache":
                dir_name = "./cache/"
            else:
                dir_name = "./store/"
        else:
            root = os.path.join(self.config["EXP"]["root"], "")
            name = self.config["EXP"]["name"]
            try:
                entryn = self.config["EXP"][entry]
            except KeyError:
                # some default values
                if entry == "fig_dir":
                    entryn = "images/"
                elif entry == "res_dir":
                    entryn = "results/"
                elif entry == "model_dir":
                    entryn = "models/"
                elif entry == "cache":
                    entryn = "cache/"
                else:
                    entryn = "store/"

            # Expand image, model and result directories with run index
            if entry == "fig_dir" or entry == "res_dir" or entry == "model_dir":
                run = self.config_val("EXP", "run", 0)
                entryn = entryn + f"run_{run}/"

            dir_name = f"{root}{name}/{entryn}"

        audeer.mkdir(dir_name)
        return dir_name

    def config_val_data(self, dataset, key, default):
        """Retrieve a configuration value for datasets.

        If the value is present in the experiment configuration it will be used, else
        we look in a global file specified by the root_folders value.
        """
        import nkululeko.glob_conf as glob_conf

        configuration = glob_conf.config
        try:
            if len(key) > 0:
                return configuration["DATA"][dataset + "." + key].strip("'\"")
            else:
                return configuration["DATA"][dataset].strip("'\"")
        except KeyError:
            if self.got_data_roots:
                try:
                    if len(key) > 0:
                        return self.data_roots["DATA"][dataset + "." + key].strip("'\"")
                    else:
                        return self.data_roots["DATA"][dataset].strip("'\"")
                except KeyError:
                    if default not in self.stopvals:
                        self.debug(
                            f"value for {key} not found, using default:" f" {default}"
                        )
                    return default
            if default not in self.stopvals:
                self.debug(f"value for {key} not found, using default: {default}")
            return default

    def set_config(self, config):
        self.config = config
        # self.logged_configs.clear()

    def get_name(self):
        """Get the name of the experiment."""
        return self.config["EXP"]["name"]

    def get_exp_dir(self):
        """Get the experiment directory."""
        root = os.path.join(self.config["EXP"]["root"], "")
        name = self.config["EXP"]["name"]
        dir_name = f"{root}/{name}"
        audeer.mkdir(dir_name)
        return dir_name

    def get_res_dir(self):
        home_dir = self.get_exp_dir()
        dir_name = f"{home_dir}/results/"
        audeer.mkdir(dir_name)
        return dir_name

    def exp_is_classification(self):
        type = self.config_val("EXP", "type", "classification")
        if type == "classification":
            return True
        return False

    def error(self, message):
        if self.logger is not None:
            self.logger.error(f"ERROR: {self.caller}: {message}")
        else:
            print(f"ERROR: {message}")
        sys.exit()

    def warn(self, message):
        if self.logger is not None:
            self.logger.warning(f"WARNING: {self.caller}: {message}")
        else:
            print(f"WARNING: {message}", flush=True)

    def debug(self, message):
        if self.logger is not None:
            self.logger.debug(f"DEBUG: {self.caller}: {message}")
        else:
            print(f"DEBUG: {message}", flush=True)

    def set_config_val(self, section, key, value):
        try:
            # does the section already exists?
            self.config[section][key] = str(value)
        except KeyError:
            self.config.add_section(section)
            self.config[section][key] = str(value)

    def check_df(self, i, df):
        """Check a dataframe."""
        print(f"check {i}: {df.shape}")
        print(df.head(1))

    def config_val(self, section, key, default):
        if self.config is None:
            return default
        try:
            return self.config[section][key]
        except KeyError:
            if default not in self.stopvals:
                self.debug(f"value for {key} is not found, using default: {default}")
            return default

    @classmethod
    def reset_logged_configs(cls):
        cls.logged_configs.clear()

    def config_val_list(self, section, key, default):
        try:
            return ast.literal_eval(self.config[section][key])
        except KeyError:
            if default not in self.stopvals:
                self.debug(f"value for {key} not found, using default: {default}")
            return default

    def print_best_results(self, best_reports):
        res_dir = self.get_res_dir()
        all = ""
        vals = np.empty(0)
        for report in best_reports:
            all += f"{report.result.test:.4f} "
            vals = np.append(vals, report.result.test)
        file_name = f"{res_dir}{self.get_exp_name()}_runs.txt"

        # For metrics where lower is better (EER, MSE, MAE), show min instead of max
        if self.high_is_good():
            best_val = vals.max()
            best_idx = vals.argmax()
            best_label = "max"
        else:
            best_val = vals.min()
            best_idx = vals.argmin()
            best_label = "min"

        output = (
            f"{all}"
            + f"\nmean: {vals.mean():.4f}, std: {vals.std():.4f}, "
            + f"{best_label}: {best_val:.4f}, {best_label}_index: {best_idx}"
        )
        with open(file_name, "w") as text_file:
            text_file.write(output)
        self.debug(output)

    def high_is_good(self):
        """check how to interpret results (higher is better)"""
        if self.exp_is_classification():
            measure = self.config_val("MODEL", "measure", "uar")
            measure_low = ["eer"]
            if measure in measure_low:
                return False
            else:
                return True
        else:
            measure = self.config_val("MODEL", "measure", "mse")
            measure_low = ["mse", "mae"]
            if measure in measure_low:
                return False
            elif measure == "ccc":
                return True
            else:
                self.error(f"unknown measure: {measure}")

    def to_3_digits(self, x):
        """Given a float, return this to 3 digits."""
        x = float(x)
        return (int(x * 1000)) / 1000.0

    def to_3_digits_str(self, x):
        """Given a float, return this to 3 digits as string with leading zero."""
        return f"{self.to_3_digits(x):.3f}"

    def to_4_digits(self, x):
        """Given a float, return this to 4 digits."""
        x = float(x)
        if np.isnan(x):
            return x
        return (int(x * 10000)) / 10000.0

    def to_4_digits_str(self, x):
        """Given a float, return this to 4 digits as string with leading zero."""
        x_val = self.to_4_digits(x)
        if np.isnan(x_val):
            return "nan"
        return f"{x_val:.4f}"
