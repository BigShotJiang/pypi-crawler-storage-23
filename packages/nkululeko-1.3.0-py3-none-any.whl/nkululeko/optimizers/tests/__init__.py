"""Tests for optimizers module."""
