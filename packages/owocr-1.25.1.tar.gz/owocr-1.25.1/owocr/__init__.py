__version__ = (1, 25, 1)
__version_string__ = '.'.join(map(str, __version__))
