"""TTS CLI - Command-line interface for Voicebox TTS."""

__version__ = "0.1.0"
