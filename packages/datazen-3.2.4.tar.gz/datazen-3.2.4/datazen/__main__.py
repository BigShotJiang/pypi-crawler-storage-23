# =====================================
# generator=datazen
# version=3.2.4
# hash=8e8dc92c50d7e4c18843c024dde96d7f
# =====================================
"""
datazen - Package's default entry-point.
"""

# built-in
import sys

# internal
from datazen.entry import main

if __name__ == "__main__":
    sys.exit(main(sys.argv))
