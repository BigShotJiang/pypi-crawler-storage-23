from . import TriSpectrum_mod, Jackknife, Numerics, Demographics

TriSpectrum = TriSpectrum_mod.TriSpectrum
