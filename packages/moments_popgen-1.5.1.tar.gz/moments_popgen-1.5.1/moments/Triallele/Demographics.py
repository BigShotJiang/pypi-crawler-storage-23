import numpy as np

"""
Demographic models for triallele model (all single population)
Two-epoch
Three-epoch
Growth
Bottlegrowth
"""
