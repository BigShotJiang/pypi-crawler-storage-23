============================
Triallele frequency spectrum
============================

API
---

.. autoclass:: moments.Triallele.TriSpectrum
    :members:
