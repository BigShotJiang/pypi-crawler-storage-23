# fasttps

Internal Rust extension for [leaguescheduler](https://pypi.org/project/leaguescheduler).
Not intended for direct use (but be my guest), rather install `leaguescheduler`.
