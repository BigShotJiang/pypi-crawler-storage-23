import requests
import random
import string
import time

'''
1. 密码没有安全策略
2. 密码没有设置过初始密码，但是后台看起来设置过初始密码
3. 密码传输在URL里面
'''

def rand_password(n=16, alphabet=string.ascii_letters + string.digits):
    return ''.join(random.choices(alphabet, k=n))


def main() -> None:
    old_p = 'ny1Pol'
    new_p = rand_password(6)

    for i in range(100):
        print(old_p, new_p)
        u = f'https://wxe0809d0b720d56b4.wx.gcihotel.net/guardian/api/member/info.json?hotelGroupId=2&hotelGroupCode=SOOCOR&memberId=2025071849927431&newPassword={new_p}&oldPassword={old_p}'
        ret = requests.post(u)
        print(ret.text)

        old_p = new_p
        new_p = rand_password(6)

        time.sleep(1)

if __name__ == '__main__':
    main()
    
# for i in range(100):
#     requests.get()
