"""SSHplex - SSH Connection Multiplexer"""
__version__ = "1.6.3"
__author__ = "MJAHED Sabri"
__email__ = "contact@sabrimjahed.com"
