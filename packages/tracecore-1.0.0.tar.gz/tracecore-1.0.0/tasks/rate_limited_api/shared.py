"""Shared constants for the rate_limited_api task."""

SERVICE_KEY = "rate_limited_api_service"
PAYLOAD_KEY = "rate_limited_api_payload"
SECRET_KEY = "rate_limited_api_secret"
OUTPUT_KEY = "ACCESS_TOKEN"
