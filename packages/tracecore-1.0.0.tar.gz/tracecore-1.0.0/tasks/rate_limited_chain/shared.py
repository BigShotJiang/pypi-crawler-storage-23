"""Shared constants for the rate_limited_chain task."""

SERVICE_KEY = "rate_limited_chain_service"
HANDSHAKE_TEMPLATE_KEY = "rate_limited_chain_handshake_template"
PAYLOAD_KEY = "rate_limited_chain_required_payload"
SECRET_KEY = "rate_limited_chain_secret"
OUTPUT_KEY = "ACCESS_TOKEN"
README_PATH = "/app/CHAIN_README.md"
