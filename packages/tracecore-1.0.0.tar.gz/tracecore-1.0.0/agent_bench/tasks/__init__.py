﻿"""Task modules for Agent Bench."""

from .registry import list_task_descriptors

__all__ = ["list_task_descriptors"]
