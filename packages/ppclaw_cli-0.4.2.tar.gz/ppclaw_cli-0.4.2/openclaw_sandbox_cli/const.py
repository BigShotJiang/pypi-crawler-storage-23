"""Brand constants for PPClaw CLI (PPIO variant).

This is the ONLY file that differs between brand variants.
All other source files import from here instead of hardcoding brand strings.
"""

# --- Display names ---
BRAND_NAME = "PPClaw"                       # Panel titles, table headers
PROVIDER_NAME = "PPIO"                      # Help text, error messages
CLI_NAME = "ppclaw-cli"                     # CLI command name
CONFIG_DIR_NAME = ".ppclaw-cli"             # ~/.ppclaw-cli/

# --- Environment / config ---
ENV_VAR_API_KEY = "PPIO_API_KEY"            # Environment variable name
CONFIG_SECTION = "ppio"                     # YAML config section name
API_KEY_URL = "https://ppio.com/docs/support/api-key"

# --- Sandbox ---
TEMPLATE_ID = "ppclaw"
SANDBOX_APP_LABEL = "ppclaw"                # metadata.app value
SANDBOX_PROXY = "http://10.1.80.46:1181"    # None = no proxy
SDK_PACKAGE = "ppio_sandbox"                # SDK package name

# --- OpenClaw config ---
API_KEY_PLACEHOLDER = "PPIO_API_KEY"        # Placeholder in openclaw.example.json
