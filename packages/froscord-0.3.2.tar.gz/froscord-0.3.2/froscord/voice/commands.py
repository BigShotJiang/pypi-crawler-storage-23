import discord
from discord import app_commands


class VCCommands(app_commands.Group):
    def __init__(self, manager):
        super().__init__(
            name="vc",
            description="Voice channel system"
        )
        self.manager = manager

    # ───────────────── SETUP ─────────────────

    @app_commands.command(
        name="setup",
        description="Setup join-to-create voice channels"
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def setup(self, interaction: discord.Interaction):
        # Prevent duplicate setup
        if self.manager.enabled:
            return await interaction.response.send_message(
                "⚠️ Voice system is already set up.",
                ephemeral=True
            )

        await self.manager.setup(interaction.guild)
        await interaction.response.send_message(
            "✅ Voice system setup complete.",
            ephemeral=True
        )

    # ───────────────── ERROR HANDLING ─────────────────

    @setup.error
    async def setup_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError
    ):
        if isinstance(error, app_commands.errors.MissingPermissions):
            await interaction.response.send_message(
                "❌ You must have **Administrator** permission to run this command.",
                ephemeral=True
            )
        else:
            # Catch-all safety (never leak tracebacks to users)
            await interaction.response.send_message(
                "❌ An unexpected error occurred while running this command.",
                ephemeral=True
            )