# recoverage

Code-coverage visualizer for binary-matching game reverse engineering.

## Installation

```bash
pip install recoverage
```

## Usage

```bash
recoverage
```

## License

MIT
