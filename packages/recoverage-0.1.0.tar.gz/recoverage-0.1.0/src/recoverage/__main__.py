"""Entry point for `python -m recoverage` and the `recoverage` console script."""

from __future__ import annotations


def main() -> int:
    print("recoverage is installed.  Full functionality coming soon.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
