"""recoverage — code-coverage visualizer for binary-matching game reverse engineering."""

__version__ = "0.1.0"
