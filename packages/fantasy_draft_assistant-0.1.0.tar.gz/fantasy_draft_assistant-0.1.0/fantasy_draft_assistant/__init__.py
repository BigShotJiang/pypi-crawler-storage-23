"""
shipp-fantasy: Fantasy sports draft recommendations combining live game performance with season stats.
"""
__version__ = "0.1.0"
