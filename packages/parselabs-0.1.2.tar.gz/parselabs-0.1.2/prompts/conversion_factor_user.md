Lab test: {lab_name}
Convert from: {from_unit}
Convert to: {to_unit}
What is the numeric conversion factor? Respond with only the number.
