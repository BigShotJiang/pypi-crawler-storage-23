Lab test: {lab_name}
Primary unit: {primary_unit}
User stats: {user_stats_json}
What is the healthy reference range for this test in the primary unit? Respond with only the numeric range.
