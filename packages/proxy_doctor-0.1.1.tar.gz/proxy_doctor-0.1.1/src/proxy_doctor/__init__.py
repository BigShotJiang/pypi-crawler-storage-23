"""proxy-doctor: Diagnose proxy misconfigurations that break AI coding tools."""

__version__ = "0.1.1"
