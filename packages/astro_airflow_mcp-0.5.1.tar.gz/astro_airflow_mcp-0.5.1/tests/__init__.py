"""Tests for airflow-mcp."""
