def test_import():
    import growthcurves

    assert growthcurves.__version__ is not None
