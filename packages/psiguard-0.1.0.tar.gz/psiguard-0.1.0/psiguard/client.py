import os
from dataclasses import dataclass, field
from typing import List, Optional
import requests

DEFAULT_BASE_URL = "https://bumpr-ai-safety-rafj.onrender.com"
DEFAULT_TIMEOUT  = 15

@dataclass
class CheckResult:
    should_block: bool
    state:        str
    risk_score:   int
    confidence:   float
    warnings:     List[str]
    explanation:  str
    timestamp:    float

@dataclass
class ThreadSummary:
    total_steps:  int
    mean_risk:    float
    max_risk:     int
    state_counts: dict = field(default_factory=dict)

class PsiGuardError(Exception):
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code

class PsiGuardAuthError(PsiGuardError):
    pass

class PsiGuardRateLimitError(PsiGuardError):
    pass

class PsiGuard:
    def __init__(
        self,
        api_key:  Optional[str] = None,
        base_url: str           = DEFAULT_BASE_URL,
        timeout:  int           = DEFAULT_TIMEOUT,
    ):
        resolved_key = api_key or os.environ.get("PSIGUARD_API_KEY", "")
        if not resolved_key:
            raise PsiGuardAuthError(
                "No API key provided. Pass api_key='pg_...' or set PSIGUARD_API_KEY."
            )
        if not resolved_key.startswith("pg_"):
            raise PsiGuardAuthError(
                "Invalid API key format. Keys must start with 'pg_'."
            )
        self._api_key  = resolved_key
        self._base_url = base_url.rstrip("/")
        self._timeout  = timeout
        self._session  = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type":  "application/json",
            "User-Agent":    "psiguard-python/0.1.0",
        })

    def _post(self, path: str, body: dict) -> dict:
        url = f"{self._base_url}{path}"
        try:
            resp = self._session.post(url, json=body, timeout=self._timeout)
        except requests.exceptions.ConnectionError as e:
            raise PsiGuardError(f"Could not connect to PsiGuard API: {e}")
        except requests.exceptions.Timeout:
            raise PsiGuardError(f"Request timed out after {self._timeout}s.")

        if resp.status_code == 401:
            raise PsiGuardAuthError("Invalid or inactive API key.", status_code=401)
        if resp.status_code == 429:
            data = resp.json() if resp.content else {}
            raise PsiGuardRateLimitError(
                data.get("error", "Monthly limit reached. Upgrade to Pro."),
                status_code=429,
            )
        if resp.status_code == 503:
            raise PsiGuardError("Service temporarily unavailable.", status_code=503)
        if not resp.ok:
            try:
                msg = resp.json().get("error", resp.text)
            except Exception:
                msg = resp.text
            raise PsiGuardError(f"API error ({resp.status_code}): {msg}", status_code=resp.status_code)

        return resp.json()

    def check(
        self,
        prompt:         str,
        response:       str,
        thread_id:      str = "default",
        risk_threshold: int = 70,
    ) -> CheckResult:
        if not prompt or not prompt.strip():
            raise ValueError("prompt must be a non-empty string.")
        if not response or not response.strip():
            raise ValueError("response must be a non-empty string.")

        data = self._post("/v1/check", {
            "prompt":         prompt.strip(),
            "response":       response.strip(),
            "thread_id":      thread_id or "default",
            "risk_threshold": int(risk_threshold),
        })
        return CheckResult(
            should_block = bool(data.get("should_block", False)),
            state        = str(data.get("state", "UNKNOWN")),
            risk_score   = int(data.get("risk_score", 0)),
            confidence   = float(data.get("confidence", 0.0)),
            warnings     = list(data.get("warnings", [])),
            explanation  = str(data.get("explanation", "")),
            timestamp    = float(data.get("timestamp", 0.0)),
        )

    def thread_reset(self, thread_id: str) -> bool:
        if not thread_id or not thread_id.strip():
            raise ValueError("thread_id must be a non-empty string.")
        data = self._post("/v1/thread/reset", {"thread_id": thread_id.strip()})
        return bool(data.get("ok", False))

    def thread_summary(self, thread_id: str) -> ThreadSummary:
        if not thread_id or not thread_id.strip():
            raise ValueError("thread_id must be a non-empty string.")
        data = self._post("/v1/thread/summary", {"thread_id": thread_id.strip()})
        return ThreadSummary(
            total_steps  = int(data.get("total_steps", 0)),
            mean_risk    = float(data.get("mean_risk", 0.0)),
            max_risk     = int(data.get("max_risk", 0)),
            state_counts = dict(data.get("state_counts", {})),
        )