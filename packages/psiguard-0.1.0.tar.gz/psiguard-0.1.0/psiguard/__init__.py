**File 3 of 4:**

This one goes inside a `psiguard` subfolder inside `psiguard-sdk`. So the full path is `psiguard-sdk/psiguard/`

Cmd+N, paste, Cmd+Shift+S

**Save as:** `__init__.py` — inside `psiguard-sdk/psiguard/`

```python
from .client import (
    PsiGuard,
    CheckResult,
    ThreadSummary,
    PsiGuardError,
    PsiGuardAuthError,
    PsiGuardRateLimitError,
)

__all__ = [
    "PsiGuard",
    "CheckResult",
    "ThreadSummary",
    "PsiGuardError",
    "PsiGuardAuthError",
    "PsiGuardRateLimitError",
]

__version__ = "0.1.0"
```

Done? One more after this! 🎯