"""Label helpers and type aliases."""

from __future__ import annotations

LabelId = int

__all__ = ["LabelId"]
