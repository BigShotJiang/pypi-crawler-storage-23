"""Shared configuration defaults."""

DEFAULT_FORMAT = "yolo"

__all__ = ["DEFAULT_FORMAT"]
