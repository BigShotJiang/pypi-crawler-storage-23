from mcp_fileSysUtils_server import main

main()