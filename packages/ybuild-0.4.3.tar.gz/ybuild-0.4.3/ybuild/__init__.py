"""
Y Build Runtime Python SDK

A Python client library for interacting with Y Build Runtime API.

Basic usage:
    from ybuild import YBuildClient

    client = YBuildClient(
        api_url="https://api.ybuild.dev",
        api_key="ybld_your_api_key"
    )

    # Create a container
    container = client.create_container(thread_id="my-thread")

    # Execute code
    result = container.exec("python -c 'print(1+1)'")
    print(result.stdout)

    # Write and read files
    container.write_file("/workspace/hello.py", "print('Hello!')")
    content = container.read_file("/workspace/hello.py")

    # Stop container
    container.stop()
"""

__version__ = "0.4.3"
__author__ = "Y Build Team"

from .client import YBuildClient
from .container import Container
from .exceptions import (
    YBuildError,
    AuthenticationError,
    ContainerError,
    ContainerNotFoundError,
    QuotaExceededError,
    RateLimitError,
    NetworkError,
    TimeoutError,
)
from .models import (
    ContainerStatus,
    ContainerInfo,
    ExecResult,
    FileInfo,
    ProcessInfo,
)

__all__ = [
    # Main client
    "YBuildClient",
    "Container",
    # Exceptions
    "YBuildError",
    "AuthenticationError",
    "ContainerError",
    "ContainerNotFoundError",
    "QuotaExceededError",
    "RateLimitError",
    "NetworkError",
    "TimeoutError",
    # Models
    "ContainerStatus",
    "ContainerInfo",
    "ExecResult",
    "FileInfo",
    "ProcessInfo",
]
