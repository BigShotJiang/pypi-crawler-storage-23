"""
Array subcommand app.
"""

from __future__ import annotations

from moat.lib.rpc import ArrayCmd


class Array(ArrayCmd):
    """List of mostly-same things."""

    pass
