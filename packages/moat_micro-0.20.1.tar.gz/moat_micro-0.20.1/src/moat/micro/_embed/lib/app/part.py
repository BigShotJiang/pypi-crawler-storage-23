"""
Random parts
"""

from __future__ import annotations

_attrs = {
    "PID": "pid",
    "Pin": "pin",
    "PWM": "pwm",
    "NoOp": "noop",
    "Relay": "relay",
    "Transfer": "transfer",
    "Average": "average",
}


# Lazy loader, effectively does:
#   global attr
#   from .mod import attr
def __getattr__(attr):
    mod = _attrs.get(attr, None)
    if mod is None:
        raise AttributeError(attr)
    value = getattr(__import__(f"moat.micro.part.{mod}", globals(), None, True, 0), attr)
    globals()[attr] = value
    return value
