"""
Directory subcommand app.
"""

from __future__ import annotations

from moat.lib.rpc import DirCmd


class Dir(DirCmd):
    """Plain subcommands."""

    pass
