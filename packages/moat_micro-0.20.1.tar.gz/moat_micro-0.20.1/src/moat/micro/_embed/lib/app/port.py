"""
Access any moat.micro Buf/Blk/Msg device
"""

from __future__ import annotations

from moat.util import import_
from moat.lib.micro import AC_use
from moat.lib.rpc import BaseCmdBBM


# Serial packet forwarder
# cfg:
# uart: N
# tx: PIN
# rx: PIN
# baud: 9600
# max:
#   len: N
#   idle: MSEC
# start: NUM
#
class Port(BaseCmdBBM):
    """
    Access any moat.micro Buf/Blk/Msg device.

    The config item "device" must contain the class path.
    """

    doc = dict(_c=dict(_d="device access", device="str:class path", _k="any:class setup"))

    pack = None

    async def stream(self):
        "setup,"
        intf = import_(self.cfg["device"])
        return await AC_use(self, intf(self.cfg))
