from __future__ import annotations  # noqa: D100

# package("app/bms", opt=0)
# package("moat/ems/battery", opt=0)

module("serialpacker.py", opt=0)
module("async_queue.py", opt=0)
package("moat", opt=0)
package("app", opt=0)
