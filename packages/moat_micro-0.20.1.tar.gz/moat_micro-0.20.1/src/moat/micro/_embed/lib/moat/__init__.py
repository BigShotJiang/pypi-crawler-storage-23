# noqa:D104
from __future__ import annotations

from .go_ import go as go

DOC = False
