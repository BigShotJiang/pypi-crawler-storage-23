# noqa:D104
from __future__ import annotations

from ._impl import RingBuffer as RingBuffer
