"""
MoaT main code.

Simply runs moat.go().

This file is not replaced if it already exists!
"""

from __future__ import annotations

import moat

moat.go(cmd=False)
