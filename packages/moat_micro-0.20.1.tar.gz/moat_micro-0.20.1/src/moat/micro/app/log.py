"""
Log app calls.
"""

from __future__ import annotations

from moat.lib.rpc import Logger

__all__ = ["Cmd"]

Cmd = Logger
