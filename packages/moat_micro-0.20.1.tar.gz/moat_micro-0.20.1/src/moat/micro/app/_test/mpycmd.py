"""
MoaT link to a local micropython process.
"""

from __future__ import annotations

from moat.lib.micro import AC_use
from moat.lib.rpc.stream.cmdmsg import BaseCmdMsg
from moat.lib.stream import serial_stack
from moat.micro._test import MpyBuf


class MpyCmd(BaseCmdMsg):
    """MoaT link to a local micropython process."""

    doc = dict(_c=dict(_d="RPC to MicroPython"))

    async def stream(self):
        """Returns the console-stack-wrapped micropython buffer."""
        mpy = MpyBuf(self.cfg)
        return await AC_use(self, serial_stack(mpy, self.cfg))
