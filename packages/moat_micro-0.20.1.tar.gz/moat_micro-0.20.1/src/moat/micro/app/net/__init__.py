"""
Network connectivity apps (TCP, Unix sockets).
"""
