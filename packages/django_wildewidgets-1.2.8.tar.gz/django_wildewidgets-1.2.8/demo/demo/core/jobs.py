############################################################################################################
# Define your core app's jobs here.
# Jobs are generally functions that are called by management commands and/or
# user-facing views.
############################################################################################################
