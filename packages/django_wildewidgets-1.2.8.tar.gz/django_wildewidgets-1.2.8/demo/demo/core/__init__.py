default_app_config = 'demo.core.apps.CoreConfig'
