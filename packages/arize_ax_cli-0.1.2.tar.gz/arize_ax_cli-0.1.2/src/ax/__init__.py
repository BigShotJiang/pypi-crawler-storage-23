"""Arize CLI."""

from ax.version import __version__

__all__ = ["__version__"]
