"""ASCII art banners for Arize AX CLI."""

from ax.version import __version__

# Option 1: Box Drawing
OPTION_1 = """[bold magenta]   ╔═╗╦═╗╦╔═╗╔═╗  [bold cyan]╔═╗═╗ ╦[/bold cyan][/bold magenta]
[bold magenta]   ╠═╣╠╦╝║╔═╝║╣   [bold cyan]╠═╣╔╩╦╝[/bold cyan][/bold magenta]
[bold magenta]   ╩ ╩╩╚═╩╚═╝╚═╝  [bold cyan]╩ ╩╩ ╚═[/bold cyan][/bold magenta]
[dim]          AI Observability Platform - v{version}[/dim]"""

# Option 2: Block Letters
OPTION_2 = """[bold magenta]    ▄▀█ █▀█ █ ▀█ █▀▀  [bold cyan]▄▀█ ▀▄▀[/bold cyan][/bold magenta]
[bold magenta]    █▀█ █▀▄ █ █▄ ██▄  [bold cyan]█▀█ █ █[/bold cyan][/bold magenta]
[dim]          AI Observability Platform - v{version}[/dim]"""

# Option 3: Simple Clean
OPTION_3 = """[bold magenta]    ╭─╮ ╭─╮ ╶┬╴ ╭─╴ ╭─╴  [bold cyan]╭─╮ ╷ ╷[/bold cyan][/bold magenta]
[bold magenta]    ├─┤ ├┬╯  │  ┌─╴ ├─╴  [bold cyan]├─┤ ╰─╯[/bold cyan][/bold magenta]
[bold magenta]    ╵ ╵ ╵╰╴ ╶┴╴ ╰─╴ ╰─╴  [bold cyan]╵ ╵ ╶─╴[/bold cyan][/bold magenta]
[dim]             AI Observability Platform - v{version}[/dim]"""

# Option 4: Banner Style
OPTION_4 = """[bold magenta]   ╔═══╗╔═══╗╦╔═══╗╔═══╗  [bold cyan]╔═══╗═╗ ╦[/bold cyan][/bold magenta]
[bold magenta]   ╠═══╣╠═╦═╝║╔═══╝║╔══╝  [bold cyan]╠═══╣╔╩╦╝[/bold cyan][/bold magenta]
[bold magenta]   ╩   ╩╩ ╚═╝╩╚═══╝╚═══╝  [bold cyan]╩   ╩╩ ╚═[/bold cyan][/bold magenta]
[dim]             AI Observability Platform - v{version}[/dim]"""

# Option 5: Stylized Stars
OPTION_5 = """[bold magenta]   ★ ᗩᖇIᘔᗴ [bold cyan]ᗩ᙭[/bold cyan] ★[/bold magenta]
[dim]   AI Observability Platform - v{version}[/dim]"""

# Option 6: Classic ASCII
OPTION_6 = """
[bold magenta]     _         _              [bold cyan]  _   __  __[/bold cyan] [/bold magenta]
[bold magenta]    / \\   _ __(_)_______     [bold cyan]  / \\  \\ \\/ /[/bold cyan] [/bold magenta]
[bold magenta]   / _ \\ | '__| |_  / _ \\   [bold cyan]  / _ \\  \\  /[/bold cyan] [/bold magenta]
[bold magenta]  / ___ \\| |  | |/ /  __/    [bold cyan]/ ___ \\ /  \\ [/bold cyan] [/bold magenta]
[bold magenta] /_/   \\_\\_|  |_/___\\___|  [bold cyan] /_/   \\_\\_/\\_\\ (v{version})[/bold cyan] [/bold magenta]
[dim cyan]                 AI Observability Platform[/dim cyan]"""

# Default banner (can be changed to any option)
DEFAULT_BANNER = OPTION_6.format(version=__version__)
