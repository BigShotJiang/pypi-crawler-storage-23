"""Core functionality for Arize CLI."""
