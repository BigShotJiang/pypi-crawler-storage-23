"""Utility functions and helpers for Arize CLI."""
