"""Version information for ax CLI."""

__version__ = "0.1.2"
