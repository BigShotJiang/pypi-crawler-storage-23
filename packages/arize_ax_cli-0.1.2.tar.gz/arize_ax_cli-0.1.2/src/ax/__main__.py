"""Allow running as python -m ax."""

from ax.cli import app

if __name__ == "__main__":
    app()
