"""
Attestant: Unified Compliance Platform for Regulated ML

Works with any model — scikit-learn, XGBoost, LightGBM, PyTorch,
TensorFlow, ONNX, or any callable.  Predictions run locally in your
environment; the model is never sent to the server.

Quick start — DataFrame style (protected attributes extracted automatically)::

    import attestant
    attestant.configure(api_key="pvt_live_...")

    clf.fit(X_train, y_train)

    result = attestant.validate(
        model=clf,
        test_df=holdout_df,          # DataFrame with ALL columns
        label_column="approved",
        protected_columns=["age", "race", "gender"],  # required — no auto-detection
        age_column="age",                             # required — None if no age data
        model_name="loan_approval_v2",
    )

    if result.approved:
        print(f"APPROVED ({result.compliance_score:.0f}/100)")
    else:
        print(f"BLOCKED: {result.reason}")

    print(f"Full report: {result.dashboard_url}")

Array style (NumPy / scikit-learn convention)::

    result = attestant.validate(
        model=clf,
        X_test=X_test,
        y_test=y_test,
        protected_columns=["age", "race", "gender"],  # required
        age_column="age",                             # required
        model_name="loan_approval_v2",
    )

Pre-computed predictions (model-free — any scoring source)::

    scores = external_api.score(batch)
    result = attestant.validate(
        test_df=holdout_df,
        label_column="approved",
        protected_columns=["age", "race", "gender"],
        age_column="age",
        predictions=scores,
        model_name="loan_approval_v2",
    )

Wrap for ongoing inference monitoring::

    model = attestant.wrap(clf, model_name="loan_approval",
                           protected_columns=["age", "race", "gender"])
    preds = model.predict(X_new, protected_df=demographics_new)

Check connectivity::

    info = attestant.status()
    # info.connected → True

Dashboard: https://getattestant.com/client/
"""

import logging
import os
import threading
import time
import json
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

__version__ = "0.14.3"

__all__ = [
    "__version__",
    "configure",
    "validate",
    "status",
    "wrap",
    "log_inference",
    "setup_logging",
    "ValidationResult",
    "StatusInfo",
    "ModelTamperError",
    "ModelWrapper",
]


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """Result from ``attestant.validate()`` or ``model.result``.

    Quick pass/fail — see the dashboard for full details.
    """
    approved: bool
    compliance_score: float
    findings: List[str]
    dashboard_url: str
    model_id: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    protected_isolation_verified: Optional[bool] = None
    protected_in_model: List[str] = field(default_factory=list)
    profile_used: Optional[str] = None
    regulations_run: List[str] = field(default_factory=list)
    documentation_urls: Dict[str, str] = field(default_factory=dict)

    @property
    def reason(self) -> str:
        """Human-readable explanation of why the model was blocked."""
        if self.approved:
            return "Model approved for deployment"
        return "%d finding(s) — review on dashboard: %s" % (
            len(self.findings), self.dashboard_url,
        )

    def __bool__(self) -> bool:
        return self.approved

    def __repr__(self) -> str:
        status = "APPROVED" if self.approved else "BLOCKED"
        return "ValidationResult(%s, score=%.0f, findings=%d)" % (
            status, self.compliance_score, len(self.findings),
        )


@dataclass
class StatusInfo:
    """Result from ``attestant.status()``.

    Truthy when the service is reachable.
    """
    connected: bool
    version: str = ""
    latency_ms: float = 0.0
    error: str = ""

    def __bool__(self) -> bool:
        return self.connected

    def __repr__(self) -> str:
        if self.connected:
            return "StatusInfo(connected=True, version=%r, latency_ms=%.0f)" % (
                self.version, self.latency_ms,
            )
        return "StatusInfo(connected=False, error=%r)" % self.error


# ---------------------------------------------------------------------------
# Global configuration
# ---------------------------------------------------------------------------

_API_KEY: Optional[str] = None
_SERVICE_URL: str = os.environ.get("ATTESTANT_SERVICE_URL", "https://getattestant.com")

# Re-export wrapper symbols so callers never need to import from submodules
from .wrapper import ModelTamperError, ModelWrapper  # noqa: E402

_logger = logging.getLogger(__name__)


def configure(
    api_key: Optional[str] = None,
    service_url: Optional[str] = None,
) -> None:
    """
    Configure Attestant with your API key.

    Call this once at application startup, before any calls to ``validate()``,
    ``wrap()``, or ``log_inference()``.

    Parameters
    ----------
    api_key : str, optional
        Your Attestant API key (copy from the dashboard → Settings).
        If omitted, uses ``ATTESTANT_API_KEY`` from the environment.
    service_url : str, optional
        Attestant service URL. If omitted, uses ``ATTESTANT_SERVICE_URL``
        from the environment, else the hosted service.

    Example::

        import attestant
        attestant.configure(api_key="pvt_live_...")
    """
    global _API_KEY, _SERVICE_URL

    resolved_api_key = api_key or os.environ.get("ATTESTANT_API_KEY")
    if not resolved_api_key:
        raise ValueError(
            "No API key provided. Pass api_key=... or set ATTESTANT_API_KEY."
        )

    resolved_service_url = (
        service_url
        or os.environ.get("ATTESTANT_SERVICE_URL")
        or _SERVICE_URL
        or "https://getattestant.com"
    )

    _API_KEY = resolved_api_key
    _SERVICE_URL = resolved_service_url.rstrip("/")

    # Also export to environment so sub-processes can inherit config
    os.environ["ATTESTANT_API_KEY"] = _API_KEY
    os.environ["ATTESTANT_SERVICE_URL"] = _SERVICE_URL


# ---------------------------------------------------------------------------
# validate() — synchronous golden path
# ---------------------------------------------------------------------------

def validate(
    model: Any = None,
    *,
    # ── DataFrame mode (recommended) ────────────────────────────────────────
    train_df: Any = None,
    test_df: Any = None,
    label_column: Optional[str] = None,
    # ── Array mode (alternative) ─────────────────────────────────────────────
    X_train: Any = None,
    y_train: Any = None,
    X_test: Any = None,
    y_test: Any = None,
    # ── Protected attributes (required) ─────────────────────────────────────
    protected_columns: List[str],
    age_column: Optional[str],
    # ── Pre-computed predictions (skip model.predict entirely) ───────────────
    predictions: Any = None,
    # ── Model identity ───────────────────────────────────────────────────────
    model_name: str = "model",
    model_version: str = "1.0.0",
    # ── Optional fine-tuning ─────────────────────────────────────────────────
    protected_column_types: Optional[Dict[str, str]] = None,
    compliance_profile: Optional[str] = None,
    di_threshold: Optional[float] = None,
    regulations: Optional[List[str]] = None,
    taint_risks: Optional[Dict[str, float]] = None,
    **metadata,
) -> ValidationResult:
    """
    Validate a trained model for compliance, fairness, and deployment readiness.

    Works with **any** model type — scikit-learn, XGBoost, LightGBM, CatBoost,
    PyTorch, TensorFlow/Keras, ONNX, or any callable.  Predictions are run
    **locally** in your environment and only the prediction array is sent to
    the Attestant service.

    Two data styles are supported — use whichever fits your pipeline:

    **DataFrame style** (recommended — protected attributes extracted automatically):

        result = attestant.validate(
            model=clf,
            test_df=holdout_df,
            label_column="approved",
            protected_columns=["age", "race", "gender"],
        )

    **Array style** (scikit-learn / NumPy convention):

        result = attestant.validate(
            model=clf,
            X_test=X_test,
            y_test=y_test,
            protected_columns=["age", "race", "gender"],
        )

    In both cases:
    - Protected columns are **automatically extracted** from the DataFrame / X_test
      if they appear there — they are never passed to the model as features.
    - Predictions are run locally via ``model.predict()`` or ``model.predict_proba()``
      (or the equivalent for PyTorch / TensorFlow / ONNX).
    - The model object is **never sent to the server**.

    Parameters
    ----------
    model : Any, optional
        A trained model.  Can be:

        - scikit-learn, XGBoost, LightGBM, CatBoost — standard ``predict`` /
          ``predict_proba`` interface.
        - PyTorch ``nn.Module`` — forwarded with ``torch.no_grad()``.
        - TensorFlow / Keras ``model.predict()``.
        - ONNX ``InferenceSession``.
        - Any callable that accepts ``X`` and returns predictions.

        May be omitted when ``predictions=`` is provided.

    train_df : DataFrame, optional
        Full training DataFrame (features + label + protected attributes).
        Use together with ``test_df`` and ``label_column``.

    test_df : DataFrame, optional
        Full holdout / evaluation DataFrame.
        ``label_column`` and ``protected_columns`` are extracted automatically.
        Features passed to the model are everything that remains.

    label_column : str, optional
        Column name for the target/label when using ``train_df`` / ``test_df``.
        Required if ``test_df`` is provided.

    X_train : array-like, optional
        Training features (array style).

    y_train : array-like, optional
        Training labels (array style).

    X_test : array-like, optional
        Evaluation features (array style).
        If a DataFrame, ``protected_columns`` present in it are auto-extracted.

    y_test : array-like, optional
        Ground-truth labels for evaluation.

    protected_columns : list of str
        **Required.** Names of all demographic / protected-attribute columns
        (e.g. ``["age", "race", "gender"]``).  Must be declared explicitly —
        there is no auto-detection.  If these columns appear in ``test_df``
        or ``X_test`` they are extracted from features automatically (the
        model never sees them).

    age_column : str or None
        **Required.** Column name in the protected attributes that holds
        applicant age, or ``None`` if your dataset has no age column.
        Age values must be whole years (e.g. ``35``).  Pass ``None``
        explicitly when age is not collected::

            age_column="applicant_age"   # has age data
            age_column=None              # no age column

    predictions : array-like, optional
        Pre-computed model output.  Supply this when you cannot (or prefer not
        to) pass the model object — e.g. when scoring is done by an external
        API, a compiled binary, or a model type that can't be passed to
        ``validate()``.  When provided, ``model.predict()`` is not called.

    model_name : str
        Display name shown in the dashboard (default ``"model"``).

    model_version : str
        Version string, e.g. ``"2.0"`` (default ``"1.0.0"``).

    protected_column_types : dict, optional
        Fine-grained age-format overrides. Map column name → format string:
        ``"age_years"``, ``"age_months"``, ``"birth_year"``, or ``"dob"``.
        Use only when ``age_column=`` is insufficient.

    compliance_profile : str, optional
        Name of a saved Compliance Sandbox profile (from the dashboard).

    di_threshold : float, optional
        Override the four-fifths (0.80) disparate-impact threshold.

    regulations : list of str, optional
        Restrict which regulations to run, e.g. ``["ecoa", "sr117"]``.

    taint_risks : dict, optional
        Feature-level proxy-discrimination risk scores from a local HYDRA-32
        DAG (advanced use).

    **metadata
        Optional key-value pairs attached to this model in the dashboard.

    Returns
    -------
    ValidationResult
        Quick pass/fail, compliance score, findings list, and dashboard URL.

    Raises
    ------
    ConnectionError
        Attestant service is unreachable.
    RuntimeError
        Server returned an error, or predictions could not be generated.
    ValueError
        ``configure()`` not called, or required arguments missing.

    Examples
    --------
    DataFrame style::

        result = attestant.validate(
            model=clf,
            test_df=holdout_df,
            label_column="approved",
            protected_columns=["age", "race", "gender"],
        )
        if result.approved:
            print(f"APPROVED ({result.compliance_score:.0f}/100)")
        else:
            print(f"BLOCKED: {result.reason}")

    Pre-computed predictions (model-free)::

        scores = external_api.score(batch)
        result = attestant.validate(
            test_df=holdout_df,
            label_column="approved",
            protected_columns=["age", "race", "gender"],
            predictions=scores,
        )

    PyTorch::

        result = attestant.validate(
            model=torch_net,
            X_test=X_test,
            y_test=y_test,
            protected_columns=["age", "race", "gender"],
        )
    """
    if not _API_KEY:
        raise ValueError(
            "Call attestant.configure(api_key='...') before validate(). "
            "Get your API key from the dashboard → Settings."
        )

    # ── 1. Resolve all data inputs to canonical form ─────────────────────────
    from .wrapper import _resolve_inputs, _run_local_predict, _serialize, _post_json

    X_train_r, y_train_r, X_test_r, y_test_r, protected_df = _resolve_inputs(
        train_df=train_df,
        test_df=test_df,
        label_column=label_column,
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        protected_columns=protected_columns,
    )

    # ── 2. Run predictions locally ────────────────────────────────────────────
    if predictions is None:
        if model is None:
            raise ValueError(
                "Either model= or predictions= must be provided."
            )
        try:
            predictions = _run_local_predict(model, X_test_r)
        except Exception as _pred_err:
            raise RuntimeError(
                "Failed to generate predictions locally: %s\n"
                "Tip: pass predictions= directly if the model cannot be called here."
                % _pred_err
            ) from _pred_err

    # ── 3. Optionally serialize the model (best-effort, for model hash) ───────
    import base64
    model_b64: Optional[str] = None
    if model is not None:
        try:
            import pickle
            model_b64 = base64.b64encode(pickle.dumps(model)).decode("utf-8")
        except Exception:
            # Non-picklable model (PyTorch, TF, ONNX, etc.) — omit
            model_b64 = None

    # ── 4. Build payload ──────────────────────────────────────────────────────
    import numpy as _np

    payload: Dict[str, Any] = {
        "model_name": model_name,
        "model_version": model_version,
        "X_test": _serialize(X_test_r),
        "y_test": _serialize(y_test_r),
        "predictions": _serialize(_np.asarray(predictions)),
        "protected_data": _serialize(protected_df),
        "protected_columns": list(protected_columns),
        "metadata": metadata,
    }
    if model_b64 is not None:
        payload["model_b64"] = model_b64

    # Column type hints (age_column is a convenience alias)
    if age_column is not None:
        protected_column_types = dict(protected_column_types or {})
        protected_column_types[age_column] = "age_years"
    if protected_column_types:
        payload["protected_column_types"] = protected_column_types
    if X_train_r is not None:
        payload["X_train"] = _serialize(X_train_r)
    if y_train_r is not None:
        payload["y_train"] = _serialize(y_train_r)
    if compliance_profile is not None:
        payload["compliance_profile"] = compliance_profile
    if di_threshold is not None:
        payload["di_threshold"] = di_threshold
    if regulations is not None:
        payload["regulations"] = regulations
    if taint_risks:
        payload["taint_risks"] = taint_risks

    # ── 5. Send to server ─────────────────────────────────────────────────────
    url = "%s/v1/training" % _SERVICE_URL
    try:
        resp: Dict[str, Any] = _post_json(url, _API_KEY, payload)
    except urllib.error.URLError as e:
        raise ConnectionError(
            "Could not reach Attestant service at %s: %s" % (_SERVICE_URL, e)
        ) from e

    # ── 6. Parse response ─────────────────────────────────────────────────────
    approved = resp.get("deployment_approved", False)
    try:
        compliance_score = float(resp.get("compliance_score", 0))
    except (TypeError, ValueError):
        compliance_score = 0.0

    raw_findings = resp.get("findings", [])
    if isinstance(raw_findings, list):
        findings = [str(f) for f in raw_findings]
    elif raw_findings is None:
        findings = []
    else:
        findings = [str(raw_findings)]

    dashboard_url = resp.get(
        "dashboard_url", "%s/client/models/%s" % (_SERVICE_URL, model_name)
    )
    model_id = resp.get("model_id", "")
    isolation_verified = resp.get("protected_isolation_verified")
    in_model = resp.get("protected_in_model", [])
    documentation_urls = resp.get("documentation_urls", {})
    if not isinstance(documentation_urls, dict):
        documentation_urls = {}

    result = ValidationResult(
        approved=approved,
        compliance_score=compliance_score,
        findings=findings,
        dashboard_url=dashboard_url,
        model_id=model_id,
        details=resp,
        protected_isolation_verified=isolation_verified,
        protected_in_model=in_model,
        profile_used=resp.get("profile_used"),
        regulations_run=resp.get("regulations_run", []),
        documentation_urls=documentation_urls,
    )

    # ── 7. Upload provenance DAG (best-effort, non-blocking) ──────────────────
    try:
        from .wrapper import _run_validate_provenance
        _run_validate_provenance(
            X=X_test_r,
            y=y_test_r,
            protected_data=protected_df,
            protected_columns=list(protected_columns),
            model_name=model_name,
            model_version=model_version,
            api_key=_API_KEY,
            service_url=_SERVICE_URL,
            model_id=model_id,
        )
    except Exception as _prov_err:
        _logger.error("[attestant] validate() provenance upload failed: %s", _prov_err)

    if isolation_verified is False and in_model:
        _logger.warning(
            "[attestant] protected_columns %s found in X_test — pass via protected_df only",
            in_model,
        )

    return result


# ---------------------------------------------------------------------------
# status() — connectivity check
# ---------------------------------------------------------------------------

def status() -> StatusInfo:
    """
    Check connectivity to the Attestant service.

    Calls ``/v1/health`` (unauthenticated). Never raises — returns
    ``StatusInfo(connected=False, error="...")`` on failure.

    Returns
    -------
    StatusInfo
        Connection status, server version, and round-trip latency.

    Example::

        info = attestant.status()
        if info.connected:
            print(f"Attestant v{info.version} ({info.latency_ms:.0f}ms)")
        else:
            print(f"Cannot reach service: {info.error}")
    """
    url = "%s/v1/health" % _SERVICE_URL
    start = time.monotonic()
    try:
        req = urllib.request.Request(
            url, method="GET",
            headers={"User-Agent": "attestant-python-client/1.0"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        elapsed = (time.monotonic() - start) * 1000
        return StatusInfo(
            connected=True,
            version=data.get("version", ""),
            latency_ms=round(elapsed, 1),
        )
    except Exception as e:
        elapsed = (time.monotonic() - start) * 1000
        return StatusInfo(
            connected=False,
            latency_ms=round(elapsed, 1),
            error=str(e),
        )


# ---------------------------------------------------------------------------
# wrap()
# ---------------------------------------------------------------------------

def wrap(
    model: Any,
    model_name: str,
    protected_columns: List[str],
    model_version: str = "1.0.0",
    verify_hash: bool = True,
    on_network_error: str = "warn",
    **metadata,
):
    """
    Wrap a model to automatically track training and inference with Attestant.

    The wrapped model is a drop-in replacement — it accepts all the same
    arguments, returns all the same values, and exposes all the same
    attributes as the original. Attestant captures data in a background
    thread without blocking your pipeline.

    Parameters
    ----------
    model : Any
        Your ML model (scikit-learn, XGBoost, LightGBM, PyTorch, etc.)
    model_name : str
        Display name shown in the dashboard, e.g. ``"loan_approval"``.
    protected_columns : list of str
        Protected attribute column names for fairness analysis,
        e.g. ``["age", "race", "gender"]``.
        These are used for monitoring only — never as model input features.
    model_version : str, optional
        Version string, e.g. ``"2.1.0"`` (default ``"1.0.0"``).
    **metadata
        Optional key-value pairs attached to this model in the dashboard.

    Returns
    -------
    ModelWrapper
        A wrapper that behaves exactly like the original model.

    Example — simple case (protected columns already in X)::

        model = attestant.wrap(
            GradientBoostingClassifier(),
            model_name="loan_approval",
            protected_columns=["age", "race", "gender"],
        )
        model.fit(X_train, y_train)        # age/race/gender auto-extracted
        preds = model.predict(X_test)

    Example — ECOA / Reg B pattern (protected columns NOT in X)::

        model = attestant.wrap(
            GradientBoostingClassifier(),
            model_name="loan_approval",
            protected_columns=["age", "race", "gender"],
        )
        model.fit(X_train, y_train, protected_df=demographics_train)
        preds = model.predict(X_test, protected_df=demographics_test)

    Example — real-time single decision::

        pred = model.predict(
            applicant_features,
            protected_df={"age": 34, "race": "White", "gender": "M"},
        )

    Notes
    -----
    Call :func:`flush` before your script exits to ensure all uploads
    complete before the daemon thread is killed::

        model.flush()

    After ``flush()``, check ``model.result`` for compliance results::

        model.flush()
        if model.result:
            print(model.result.dashboard_url)
    """
    if not _API_KEY:
        raise ValueError(
            "Call attestant.configure(api_key='...') before wrap(). "
            "Get your API key from the dashboard → Settings."
        )

    from .wrapper import ModelWrapper, ModelTamperError  # noqa: F401 (re-export)

    return ModelWrapper(
        model=model,
        model_name=model_name,
        protected_columns=protected_columns,
        api_key=_API_KEY,
        service_url=_SERVICE_URL,
        model_version=model_version,
        verify_hash=verify_hash,
        on_network_error=on_network_error,
        **metadata,
    )


def log_inference(
    model_name: str,
    predictions: Any,
    X: Any = None,
    protected_df: Any = None,
    protected_columns: Optional[List[str]] = None,
    model_version: str = "1.0.0",
) -> None:
    """
    Log inference results for an existing deployed model.

    Use this when you cannot (or do not want to) rewrap the model — for
    example, a scoring pipeline that calls an external model API, a
    pre-compiled binary, or a model deployed as a microservice.

    Unlike ``wrap()``, this is a fire-and-forget call: it enqueues the data
    in a daemon thread and returns immediately. Use ``log_inference_sync()``
    if you need a blocking call.

    Parameters
    ----------
    model_name : str
        Name matching the model registered in the Attestant dashboard.
    predictions : array-like
        Model output — binary predictions, probabilities, or scores.
    X : array-like, optional
        Input features used to produce the predictions. Used for feature
        distribution monitoring and drift detection.
    protected_df : DataFrame or dict, optional
        Protected attributes (age, race, gender, …) for fairness monitoring.
        Provide a DataFrame aligned row-for-row with ``predictions``, or a
        single ``dict`` for one-record logging.
    protected_columns : list of str, optional
        Column names to extract from ``X`` when ``protected_df`` is not
        provided. Ignored if ``protected_df`` is passed explicitly.
    model_version : str, optional
        Version string (default ``"1.0.0"``).

    Example — batch scoring pipeline::

        import attestant
        attestant.configure(api_key="pvt_live_...")

        # Your existing deployed model
        preds = deployed_model.score(batch_features)

        attestant.log_inference(
            model_name="loan_approval",
            predictions=preds,
            X=batch_features,
            protected_df=demographics_df,
            protected_columns=["age", "race", "gender"],
        )

    Example — single real-time decision::

        attestant.log_inference(
            model_name="loan_approval",
            predictions=[1],
            X=applicant_features,
            protected_df={"age": 34, "race": "White", "gender": "M"},
        )
    """
    if not _API_KEY:
        raise ValueError(
            "Call attestant.configure(api_key='...') before log_inference()."
        )

    # Capture at call time — globals could change before the thread runs
    api_key = _API_KEY
    service_url = _SERVICE_URL

    def _send() -> None:
        try:
            from datetime import datetime
            from .wrapper import _serialize, _resolve_protected, _post_json

            batch_id = f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            resolved = _resolve_protected(X, protected_df, protected_columns)

            payload = {
                "model_name":        model_name,
                "model_version":     model_version,
                "X_production":      _serialize(X),
                "predictions":       _serialize(predictions),
                "protected_data":    _serialize(resolved),
                "protected_columns": list(protected_columns or []),
                "batch_id":          batch_id,
                "metadata":          {},
            }
            _post_json(f"{service_url}/v1/inference", api_key, payload)
        except Exception as e:
            _logger.error(
                f"[attestant] log_inference upload failed for '{model_name}': {e}"
            )

    threading.Thread(
        target=_send, daemon=True, name=f"attestant-log-{model_name}"
    ).start()


# ---------------------------------------------------------------------------
# Production logging setup
# ---------------------------------------------------------------------------

def setup_logging(
    level: str = "INFO",
    fmt: str = "json",
    include_timestamp: bool = True,
) -> None:
    """
    Configure structured logging for all ``attestant.*`` loggers.

    Compatible with Splunk, ELK, Datadog, and CloudWatch Logs.

    Parameters
    ----------
    level : str
        Log level: ``"DEBUG"``, ``"INFO"``, ``"WARNING"``, ``"ERROR"``.
    fmt : str
        ``"json"`` for structured JSON lines (default, recommended for
        production), or ``"text"`` for human-readable output.
    include_timestamp : bool
        Include ISO-8601 timestamps (default ``True``).

    Example::

        import attestant
        attestant.setup_logging(level="INFO", fmt="json")
    """
    import logging as _logging
    import json as _json
    import sys
    from datetime import datetime, timezone

    numeric_level = getattr(_logging, level.upper(), _logging.INFO)

    class _JSONFormatter(_logging.Formatter):
        def format(self, record: _logging.LogRecord) -> str:
            entry: dict = {
                "logger": record.name,
                "level": record.levelname,
                "message": record.getMessage(),
            }
            if include_timestamp:
                entry["timestamp"] = (
                    datetime.fromtimestamp(record.created, tz=timezone.utc)
                    .isoformat()
                )
            if record.exc_info and record.exc_info[0] is not None:
                entry["exception"] = self.formatException(record.exc_info)
            return _json.dumps(entry, default=str)

    class _TextFormatter(_logging.Formatter):
        _fmt_ts = "%(asctime)s %(name)s %(levelname)s %(message)s"
        _fmt_no_ts = "%(name)s %(levelname)s %(message)s"

        def __init__(self, with_ts: bool = True) -> None:
            super().__init__(
                fmt=self._fmt_ts if with_ts else self._fmt_no_ts,
                datefmt="%Y-%m-%dT%H:%M:%S%z",
            )

    root = _logging.getLogger("attestant")
    root.setLevel(numeric_level)
    root.handlers.clear()

    handler = _logging.StreamHandler(sys.stderr)
    handler.setLevel(numeric_level)
    handler.setFormatter(
        _JSONFormatter() if fmt == "json" else _TextFormatter(with_ts=include_timestamp)
    )
    root.addHandler(handler)
