"""
FairLens Less Discriminatory Alternative (LDA) search: systematically
tests model variants with proxy features removed to find alternatives
that reduce disparate impact with minimal accuracy loss.
"""

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .model_adapter import adapt_model

logger = logging.getLogger(__name__)


@dataclass
class LDACandidate:
    """A candidate Less Discriminatory Alternative."""
    removed_features: List[str]
    added_features: List[str]
    original_auc: float
    candidate_auc: float
    auc_loss: float
    auc_loss_pct: float
    original_disparity: float
    candidate_disparity: float
    disparity_improvement: float
    disparity_improvement_pct: float
    passes_four_fifths: bool
    recommendation: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "removed_features": self.removed_features,
            "added_features": self.added_features,
            "original_auc": self.original_auc,
            "candidate_auc": self.candidate_auc,
            "auc_loss": self.auc_loss,
            "auc_loss_pct": self.auc_loss_pct,
            "original_disparity": self.original_disparity,
            "candidate_disparity": self.candidate_disparity,
            "disparity_improvement": self.disparity_improvement,
            "disparity_improvement_pct": self.disparity_improvement_pct,
            "passes_four_fifths": self.passes_four_fifths,
            "recommendation": self.recommendation,
        }


@dataclass
class LDASearchSummary:
    """Documents the LDA search space for regulatory compliance.

    CFPB supervisory guidance requires documentation that the institution
    conducted a thorough search for less discriminatory alternatives.
    This dataclass captures the search parameters and results needed to
    satisfy examiner review.
    """
    proxy_features_tested: List[str]
    single_removals_tested: int
    combinations_tested: int
    substitutions_tested: int
    total_candidates_evaluated: int
    passing_candidates: int
    best_candidate_disparity: Optional[float]
    search_time_seconds: float
    max_auc_loss_threshold: float
    four_fifths_threshold: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "proxy_features_tested": self.proxy_features_tested,
            "single_removals_tested": self.single_removals_tested,
            "combinations_tested": self.combinations_tested,
            "substitutions_tested": self.substitutions_tested,
            "total_candidates_evaluated": self.total_candidates_evaluated,
            "passing_candidates": self.passing_candidates,
            "best_candidate_disparity": self.best_candidate_disparity,
            "search_time_seconds": self.search_time_seconds,
            "max_auc_loss_threshold": self.max_auc_loss_threshold,
            "four_fifths_threshold": self.four_fifths_threshold,
        }


class LDASearcher:
    """
    Systematically searches for Less Discriminatory Alternatives (LDAs).

    Regulatory frameworks across industries (CFPB for lending, EEOC for hiring,
    HUD for housing) demand that organizations search for LDAs when using ML models. This class:
    1. Removes proxy features one at a time
    2. Tests combinations of proxy removals
    3. Tests adding substitute features
    4. Ranks candidates by fairness improvement vs accuracy loss

    References:
        - CFPB Supervisory Highlights, January 2025 (lending)
        - EEOC Uniform Guidelines, 29 CFR 1607 (hiring)
        - HUD 24 CFR 100.500 (housing)
        - Interagency guidance on model risk management (SR 11-7)
    """

    def __init__(
        self,
        max_auc_loss: float = 0.02,
        four_fifths_threshold: float = 0.80,
        max_combinations: int = 50,
    ):
        self.max_auc_loss = max_auc_loss
        self.four_fifths_threshold = four_fifths_threshold
        self.max_combinations = max_combinations
        self.last_search_summary: Optional[LDASearchSummary] = None

    def search(
        self,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_test: pd.DataFrame,
        y_test: np.ndarray,
        protected_test: pd.DataFrame,
        protected_column: str,
        proxy_features: List[str],
        model_factory: Callable,
        substitute_features: Optional[List[str]] = None,
        original_auc: Optional[float] = None,
        original_disparity: Optional[float] = None,
    ) -> List[LDACandidate]:
        """
        Search for LDAs by removing proxy features and testing alternatives.

        Args:
            X_train: Training features
            y_train: Training labels
            X_test: Test features
            y_test: Test labels
            protected_test: Protected attribute data for test set
            protected_column: Protected attribute column name
            proxy_features: Features identified as proxies to test removing
            model_factory: Callable that returns a fresh model instance
            substitute_features: Optional features to add when removing proxies
            original_auc: Pre-computed original AUC (computed if None)
            original_disparity: Pre-computed original disparity ratio

        Returns:
            List of LDACandidate sorted by best tradeoff
        """
        if not proxy_features:
            self.last_search_summary = None
            return []
        if not callable(model_factory):
            raise ValueError("model_factory must be a callable that returns a fresh model instance")

        from sklearn.metrics import roc_auc_score

        search_start = time.time()
        n_single = 0
        n_combos = 0
        n_subs = 0

        if original_auc is None:
            adapted = adapt_model(model_factory())
            adapted.fit(X_train, y_train)
            proba = adapted.predict_proba(X_test)
            if proba is None:
                proba = adapted.predict(X_test).astype(float)
            original_auc = roc_auc_score(y_test, proba)

        if original_disparity is None:
            adapted = adapt_model(model_factory())
            adapted.fit(X_train, y_train)
            preds = adapted.predict(X_test)
            original_disparity = self._compute_disparity(
                preds, protected_test[protected_column].values
            )

        candidates = []

        for feat in proxy_features:
            if feat not in X_train.columns:
                continue

            n_single += 1
            candidate = self._test_removal(
                X_train, y_train, X_test, y_test,
                protected_test, protected_column,
                removed=[feat], added=[],
                model_factory=model_factory,
                original_auc=original_auc,
                original_disparity=original_disparity,
            )
            if candidate:
                candidates.append(candidate)

        if substitute_features:
            for feat in proxy_features:
                if feat not in X_train.columns:
                    continue
                for sub in substitute_features:
                    if sub not in X_train.columns or sub == feat:
                        continue

                    n_subs += 1
                    candidate = self._test_removal(
                        X_train, y_train, X_test, y_test,
                        protected_test, protected_column,
                        removed=[feat], added=[sub],
                        model_factory=model_factory,
                        original_auc=original_auc,
                        original_disparity=original_disparity,
                    )
                    if candidate:
                        candidates.append(candidate)

        if len(proxy_features) > 1 and len(proxy_features) <= 5:
            from itertools import combinations
            combos_tested = 0
            for size in range(2, len(proxy_features) + 1):
                for combo in combinations(proxy_features, size):
                    if combos_tested >= self.max_combinations:
                        break
                    combo_list = [f for f in combo if f in X_train.columns]
                    if not combo_list:
                        continue

                    n_combos += 1
                    candidate = self._test_removal(
                        X_train, y_train, X_test, y_test,
                        protected_test, protected_column,
                        removed=combo_list, added=[],
                        model_factory=model_factory,
                        original_auc=original_auc,
                        original_disparity=original_disparity,
                    )
                    if candidate:
                        candidates.append(candidate)
                    combos_tested += 1

        candidates.sort(
            key=lambda c: (
                -c.disparity_improvement if c.auc_loss_pct <= self.max_auc_loss * 100 else -999,
                c.auc_loss,
            ),
            reverse=True,
        )

        passing = [c for c in candidates if c.passes_four_fifths]
        self.last_search_summary = LDASearchSummary(
            proxy_features_tested=list(proxy_features),
            single_removals_tested=n_single,
            combinations_tested=n_combos,
            substitutions_tested=n_subs,
            total_candidates_evaluated=n_single + n_combos + n_subs,
            passing_candidates=len(passing),
            best_candidate_disparity=(
                max(c.candidate_disparity for c in candidates) if candidates else None
            ),
            search_time_seconds=time.time() - search_start,
            max_auc_loss_threshold=self.max_auc_loss,
            four_fifths_threshold=self.four_fifths_threshold,
        )

        return candidates

    def _test_removal(
        self,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_test: pd.DataFrame,
        y_test: np.ndarray,
        protected_test: pd.DataFrame,
        protected_column: str,
        removed: List[str],
        added: List[str],
        model_factory: Callable,
        original_auc: float,
        original_disparity: float,
    ) -> Optional[LDACandidate]:
        """Test a specific feature removal/addition combination."""
        from sklearn.metrics import roc_auc_score

        try:
            keep_cols = [c for c in X_train.columns if c not in removed]
            for add_col in added:
                if add_col not in keep_cols:
                    keep_cols.append(add_col)

            X_train_mod = X_train[keep_cols].copy()
            X_test_mod = X_test[keep_cols].copy()

            adapted = adapt_model(model_factory())
            adapted.fit(X_train_mod, y_train)

            proba = adapted.predict_proba(X_test_mod)
            if proba is None:
                proba = adapted.predict(X_test_mod).astype(float)
            new_auc = roc_auc_score(y_test, proba)

            preds = adapted.predict(X_test_mod)
            new_disparity = self._compute_disparity(
                preds, protected_test[protected_column].values
            )

            auc_loss = original_auc - new_auc
            auc_loss_pct = (auc_loss / original_auc * 100) if original_auc > 0 else 0

            disp_improvement = new_disparity - original_disparity
            disp_improvement_pct = (
                (disp_improvement / (1 - original_disparity) * 100)
                if original_disparity < 1 else 0
            )

            passes = new_disparity >= self.four_fifths_threshold

            recommendation = self._generate_recommendation(
                removed, added, auc_loss_pct, new_disparity, passes
            )

            return LDACandidate(
                removed_features=removed,
                added_features=added,
                original_auc=original_auc,
                candidate_auc=new_auc,
                auc_loss=auc_loss,
                auc_loss_pct=auc_loss_pct,
                original_disparity=original_disparity,
                candidate_disparity=new_disparity,
                disparity_improvement=disp_improvement,
                disparity_improvement_pct=disp_improvement_pct,
                passes_four_fifths=passes,
                recommendation=recommendation,
            )

        except Exception as e:
            logger.debug("LDA test failed for %s: %s", removed, e)
            return None

    def _compute_disparity(
        self, predictions: np.ndarray, protected_values: np.ndarray
    ) -> float:
        """Compute minimum selection rate ratio (worst-case disparity)."""
        groups = pd.Series(protected_values).dropna().unique()
        rates = {}

        for group in groups:
            mask = (protected_values == group)
            total = mask.sum()
            if total > 0:
                rates[str(group)] = predictions[mask].mean()

        if len(rates) < 2:
            return 1.0

        max_rate = max(rates.values())
        if max_rate == 0:
            return 1.0

        return min(rates.values()) / max_rate

    def _generate_recommendation(
        self,
        removed: List[str],
        added: List[str],
        auc_loss_pct: float,
        new_disparity: float,
        passes: bool,
    ) -> str:
        removed_str = ", ".join(removed)
        added_str = f" + adding {', '.join(added)}" if added else ""

        if passes and auc_loss_pct <= self.max_auc_loss * 100:
            return (
                f"RECOMMENDED: Removing {removed_str}{added_str} "
                f"passes the four-fifths test (ratio: {new_disparity:.2f}) "
                f"with only {auc_loss_pct:.1f}% accuracy loss."
            )
        if passes:
            return (
                f"VIABLE: Removing {removed_str}{added_str} passes "
                f"four-fifths (ratio: {new_disparity:.2f}) but with "
                f"{auc_loss_pct:.1f}% accuracy loss."
            )
        if auc_loss_pct <= self.max_auc_loss * 100:
            return (
                f"PARTIAL: Removing {removed_str}{added_str} improves "
                f"disparity to {new_disparity:.2f} with only "
                f"{auc_loss_pct:.1f}% accuracy loss, but doesn't reach four-fifths."
            )
        return (
            f"NOT RECOMMENDED: Removing {removed_str}{added_str} "
            f"has too much accuracy loss ({auc_loss_pct:.1f}%)."
        )
