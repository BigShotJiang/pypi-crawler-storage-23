"""
FairLens core engine: orchestrates disparate impact analysis, proxy
detection, LDA search, and adverse action generation into a unified
algorithmic fairness report.
"""

import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import pandas as pd

from .disparate_impact import (
    DisparateImpactAnalyzer,
    DisparateImpactResult,
    IntersectionalResult,
)
from .proxy_detection import ProxyDetector, ProxyResult
from .lda_search import LDASearcher, LDACandidate, LDASearchSummary
from .adverse_action import AdverseActionGenerator, ApplicantExplanation
from .model_adapter import adapt_model, compute_model_hash

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Model identity / versioning (SR 11-7 § 4.1)
# ---------------------------------------------------------------------------

@dataclass
class ModelIdentity:
    """Cryptographic model identity for SR 11-7 audit trail.

    Every FairLens analysis captures a ``ModelIdentity`` that uniquely
    ties findings to the *exact* model weights evaluated.  Examiners
    can later verify that the model producing a given decision matches
    the model that passed validation.

    Attributes:
        model_hash: SHA-256 hex digest of the serialised model.
        model_version: Caller-supplied semantic version (e.g. "2.1.3").
        training_data_hash: Optional SHA-256 of the training dataset.
    """
    model_hash: str
    model_version: str = ""
    training_data_hash: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model_hash": self.model_hash,
            "model_version": self.model_version,
            "training_data_hash": self.training_data_hash,
        }


class FindingSeverity(Enum):
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"


@dataclass
class Finding:
    """A single finding from FairLens analysis."""
    severity: FindingSeverity
    category: str
    description: str
    regulation: str
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "severity": self.severity.value,
            "category": self.category,
            "description": self.description,
            "regulation": self.regulation,
            "details": self.details,
        }


_VALID_INDUSTRIES = ("lending", "hiring", "insurance", "housing", "healthcare", "education", "general")


@dataclass
class FairLensConfig:
    """Configuration for FairLens analysis."""
    protected_columns: List[str] = field(default_factory=list)
    proxy_correlation_threshold: float = 0.50
    four_fifths_threshold: float = 0.80
    max_auc_loss: float = 0.02
    max_adverse_action_reasons: int = 4
    run_lda_search: bool = True
    run_adverse_action: bool = True
    substitute_features: Optional[List[str]] = None
    industry: Optional[str] = None
    regulatory_framework: Optional[Any] = None
    column_hints: Dict[str, str] = field(default_factory=dict)

    def __post_init__(self):
        if isinstance(self.protected_columns, str):
            raise ValueError(
                "protected_columns must be a list of strings, not a bare string. "
                "Use ['race'] instead of 'race'."
            )
        for name, value in [
            ("proxy_correlation_threshold", self.proxy_correlation_threshold),
            ("four_fifths_threshold", self.four_fifths_threshold),
            ("max_auc_loss", self.max_auc_loss),
        ]:
            if not (0.0 <= value <= 1.0):
                raise ValueError(f"{name} must be between 0.0 and 1.0, got {value}")
        if self.max_adverse_action_reasons < 1:
            raise ValueError(
                f"max_adverse_action_reasons must be >= 1, got {self.max_adverse_action_reasons}"
            )
        if self.industry is not None and self.industry not in _VALID_INDUSTRIES:
            raise ValueError(
                f"Invalid industry '{self.industry}'. "
                f"Valid options: {', '.join(_VALID_INDUSTRIES)}"
            )


@dataclass
class FairLensReport:
    """Complete FairLens analysis report."""
    model_name: str
    timestamp: float
    config: FairLensConfig
    findings: List[Finding]
    disparate_impact_results: List[DisparateImpactResult]
    proxy_results: List[ProxyResult]
    lda_candidates: List[LDACandidate]
    adverse_action_samples: List[ApplicantExplanation]
    analysis_time_seconds: float
    summary: Dict[str, Any] = field(default_factory=dict)
    lda_search_summary: Optional[LDASearchSummary] = None
    intersectional_results: List[IntersectionalResult] = field(default_factory=list)
    model_identity: Optional[ModelIdentity] = None
    data_quality_findings: List["Finding"] = field(default_factory=list)
    framework_name: Optional[str] = None
    framework_description: Optional[str] = None
    monitoring_frequency: Optional[str] = None
    risk_tier: Optional[str] = None
    threshold_justification: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "model_name": self.model_name,
            "timestamp": self.timestamp,
            "analysis_time_seconds": self.analysis_time_seconds,
            "summary": self.summary,
            "findings": [f.to_dict() for f in self.findings],
            "disparate_impact": [d.to_dict() for d in self.disparate_impact_results],
            "proxy_detection": [p.to_dict() for p in self.proxy_results],
            "lda_candidates": [l.to_dict() for l in self.lda_candidates],
            "adverse_action_samples": [a.to_dict() for a in self.adverse_action_samples[:10]],
            "intersectional_analysis": [i.to_dict() for i in self.intersectional_results],
        }
        if self.lda_search_summary is not None:
            result["lda_search_summary"] = self.lda_search_summary.to_dict()
        if self.model_identity is not None:
            result["model_identity"] = self.model_identity.to_dict()
        if self.data_quality_findings:
            result["data_quality"] = [f.to_dict() for f in self.data_quality_findings]
        if self.framework_name and self.framework_description:
            framework_info: Dict[str, Any] = {
                "name": self.framework_name,
                "description": self.framework_description,
            }
            if self.monitoring_frequency:
                framework_info["monitoring_frequency"] = self.monitoring_frequency
            if self.risk_tier:
                framework_info["risk_tier"] = self.risk_tier
            if self.threshold_justification:
                framework_info["threshold_justification"] = (
                    self.threshold_justification
                )
            result["regulatory_framework"] = framework_info
        return result

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, default=str)


class FairLensEngine:
    """
    Main FairLens engine that orchestrates the complete algorithmic fairness analysis.

    Combines:
    1. Disparate impact testing (four-fifths rule)
    2. Proxy variable detection (correlation + known patterns)
    3. Less Discriminatory Alternative search
    4. Per-decision adverse action reason codes
    """

    def __init__(self, config: Optional[FairLensConfig] = None):
        self.config = config or FairLensConfig()
        self._framework = self.config.regulatory_framework
        if self._framework is None and self.config.industry is not None:
            from .regulatory import IndustryPreset, get_framework
            preset = IndustryPreset(self.config.industry)
            self._framework = get_framework(preset)
            if not self.config.protected_columns:
                self.config.protected_columns = list(self._framework.protected_attributes)
            self.config.proxy_correlation_threshold = self._framework.proxy_threshold
            self.config.four_fifths_threshold = self._framework.four_fifths_threshold
            self.config.max_adverse_action_reasons = self._framework.max_reasons

    def _get_regulation_citation(self, category: str) -> str:
        """Get regulation citation for a finding category from framework."""
        if self._framework is None:
            return "General algorithmic fairness principles"

        refs = self._framework.statute_references
        if not refs:
            return "General algorithmic fairness principles"

        if category == "disparate_impact":
            return refs[0]
        elif category == "proxy_discrimination":
            return refs[min(1, len(refs) - 1)]
        elif category == "adverse_action":
            return refs[min(2, len(refs) - 1)]
        elif category == "lda":
            return refs[-1]
        else:
            return refs[0]

    @staticmethod
    def _validate_data_quality(
        X_train: pd.DataFrame,
        X_test: pd.DataFrame,
        y_train: np.ndarray,
    ) -> List[Finding]:
        """Validate input data quality (SR 11-7 § 3.2, OCC 280.2).

        Checks:
        - High missing-value rates per column
        - Class imbalance in training labels
        - Numeric feature outliers (IQR method)
        - Test/train distribution shift (simple mean comparison)
        """
        dq_findings: List[Finding] = []

        # -- missing values --------------------------------------------------
        for col in X_train.columns:
            pct_train = X_train[col].isna().mean()
            if pct_train > 0.10:
                dq_findings.append(Finding(
                    severity=FindingSeverity.WARNING,
                    category="data_quality",
                    description=(
                        f"Column '{col}' has {pct_train:.0%} missing values "
                        f"in training data. High missingness may introduce "
                        f"bias or degrade model performance."
                    ),
                    regulation="SR 11-7 / OCC 2011-12 § 3.2",
                    details={"column": col, "missing_pct": round(pct_train, 4)},
                ))

        # -- class imbalance --------------------------------------------------
        y = np.asarray(y_train)
        if len(y) > 0:
            positive_rate = float(y.mean())
            minority_rate = min(positive_rate, 1 - positive_rate)
            if minority_rate < 0.05:
                dq_findings.append(Finding(
                    severity=FindingSeverity.WARNING,
                    category="data_quality",
                    description=(
                        f"Severe class imbalance: minority class is "
                        f"{minority_rate:.1%} of training data. May cause "
                        f"biased predictions for underrepresented outcomes."
                    ),
                    regulation="SR 11-7 / OCC 2011-12 § 3.2",
                    details={"positive_rate": round(positive_rate, 4)},
                ))

        # -- train/test distribution shift ------------------------------------
        numeric_cols = X_train.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            train_mean = X_train[col].mean()
            test_mean = X_test[col].mean()
            if np.isnan(train_mean) or np.isnan(test_mean) or train_mean == 0:
                continue
            relative_shift = abs(test_mean - train_mean) / abs(train_mean)
            if relative_shift > 0.20:
                dq_findings.append(Finding(
                    severity=FindingSeverity.WARNING,
                    category="data_quality",
                    description=(
                        f"Distribution shift detected for '{col}': "
                        f"train mean={train_mean:.4g}, test mean={test_mean:.4g} "
                        f"({relative_shift:.0%} relative shift). Model may "
                        f"not generalize to current population."
                    ),
                    regulation="SR 11-7 / OCC 2011-12 § 3.2",
                    details={
                        "column": col,
                        "train_mean": round(float(train_mean), 4),
                        "test_mean": round(float(test_mean), 4),
                        "relative_shift": round(relative_shift, 4),
                    },
                ))

        return dq_findings

    def analyze(
        self,
        model,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_test: pd.DataFrame,
        y_test: np.ndarray,
        protected_data: pd.DataFrame,
        model_name: str = "model",
        model_factory: Optional[Callable] = None,
        model_version: str = "",
        dag: Optional[Any] = None,
    ) -> FairLensReport:
        """
        Run complete algorithmic fairness analysis.

        Args:
            model: Trained model (sklearn, PyTorch, TensorFlow, XGBoost, LightGBM, CatBoost, etc.)
            X_train: Training features
            y_train: Training labels (1=positive outcome, 0=negative outcome)
            X_test: Test features
            y_test: Test labels
            protected_data: Protected attributes for test set
            model_name: Name for the report
            model_factory: Callable to create fresh model (for LDA search)
            model_version: Semantic version string for SR 11-7 audit trail

        Returns:
            FairLensReport with all findings
        """
        if not isinstance(X_train, pd.DataFrame) or len(X_train) == 0:
            raise ValueError("X_train must be a non-empty pandas DataFrame")
        if not isinstance(X_test, pd.DataFrame) or len(X_test) == 0:
            raise ValueError("X_test must be a non-empty pandas DataFrame")
        if len(y_train) != len(X_train):
            raise ValueError(
                f"y_train length ({len(y_train)}) must match X_train rows ({len(X_train)})"
            )
        if len(y_test) != len(X_test):
            raise ValueError(
                f"y_test length ({len(y_test)}) must match X_test rows ({len(X_test)})"
            )
        if not isinstance(protected_data, pd.DataFrame) or len(protected_data) != len(X_test):
            raise ValueError(
                f"protected_data must be a DataFrame with the same number of rows as X_test "
                f"({len(X_test)})"
            )
        missing_cols = [
            c for c in self.config.protected_columns if c not in protected_data.columns
        ]
        if missing_cols:
            raise ValueError(
                f"protected_columns {missing_cols} not found in protected_data. "
                f"Available columns: {list(protected_data.columns)}"
            )
        if not (hasattr(model, "predict") or hasattr(model, "forward")
                or hasattr(model, "__call__")):
            raise ValueError(
                "model must have a predict, forward, or __call__ method"
            )
        adapted = adapt_model(model)

        start_time = time.time()
        findings: List[Finding] = []

        # -- HYDRA-32 DAG isolation check (12 CFR 1002.4(a)) ----------------
        dag_isolation_verified: Optional[bool] = None
        dag_protected_in_model: list = []
        if dag is not None:
            try:
                edge_targets = {e.target_id for e in dag.edges}
                for node in dag.nodes.values():
                    if node.is_protected and node.node_id in edge_targets:
                        dag_protected_in_model.append(node.column or node.operation)
                dag_isolation_verified = len(dag_protected_in_model) == 0
            except Exception as exc:
                logger.warning("DAG isolation check failed (non-fatal): %s", exc)

        if dag_isolation_verified is False:
            findings.append(Finding(
                severity=FindingSeverity.CRITICAL,
                category="dag_isolation",
                description=(
                    "Protected attribute(s) [%s] flow into model inputs via the "
                    "HYDRA-32 DAG. Direct use of protected characteristics violates "
                    "12 CFR 1002.4(a)." % ", ".join(dag_protected_in_model)
                ),
                regulation="12 CFR 1002.4(a)",
            ))

        # -- SR 11-7 § 4.1: model identity -----------------------------------
        model_hash = adapted.model_hash()
        training_hash = hashlib.sha256(
            pd.util.hash_pandas_object(X_train).values.tobytes()
        ).hexdigest()
        model_id = ModelIdentity(
            model_hash=model_hash,
            model_version=model_version,
            training_data_hash=training_hash,
        )

        # -- SR 11-7 § 3.2: data quality validation --------------------------
        dq_findings = self._validate_data_quality(X_train, X_test, y_train)
        findings.extend(dq_findings)

        predictions = adapted.predict(X_test)
        probabilities = adapted.predict_proba(X_test)
        if probabilities is None:
            logger.warning("model.predict_proba() unavailable; falling back to zero probabilities")
            probabilities = np.zeros(len(X_test))

        di_analyzer = DisparateImpactAnalyzer(threshold=self.config.four_fifths_threshold)
        di_results = di_analyzer.analyze(
            predictions=predictions,
            protected_data=protected_data,
            protected_columns=self.config.protected_columns,
            scores=probabilities,
            column_hints=self.config.column_hints,
        )

        for di in di_results:
            if di.has_disparate_impact:
                findings.append(Finding(
                    severity=FindingSeverity.CRITICAL,
                    category="disparate_impact",
                    description=(
                        f"Disparate impact detected for {di.protected_attribute}: "
                        f"selection rate ratio ({di.worst_group}/{di.reference_group}) "
                        f"= {di.worst_ratio:.2f}, below {self.config.four_fifths_threshold:.0%} threshold"
                    ),
                    regulation=self._get_regulation_citation("disparate_impact"),
                    details=di.to_dict(),
                ))
            else:
                findings.append(Finding(
                    severity=FindingSeverity.INFO,
                    category="disparate_impact",
                    description=f"No disparate impact for {di.protected_attribute} (ratio: {di.worst_ratio:.2f})",
                    regulation=self._get_regulation_citation("disparate_impact"),
                ))

        # -- intersectional analysis (CFPB 2025, 12 CFR 1002.4(a)) -----------
        intersectional_results: List[IntersectionalResult] = []
        if len(self.config.protected_columns) >= 2:
            intersectional_results = di_analyzer.analyze_intersectional(
                predictions=predictions,
                protected_data=protected_data,
                protected_columns=self.config.protected_columns,
            )
            for ir in intersectional_results:
                if ir.has_disparate_impact:
                    pair_str = " x ".join(ir.attribute_pair)
                    worst_desc = ", ".join(
                        f"{k}={v}" for k, v in ir.worst_group.items()
                    )
                    findings.append(Finding(
                        severity=FindingSeverity.CRITICAL,
                        category="intersectional_disparate_impact",
                        description=(
                            f"Intersectional disparate impact detected for "
                            f"({pair_str}): group ({worst_desc}) has selection "
                            f"rate ratio {ir.worst_ratio:.2f}, below "
                            f"{self.config.four_fifths_threshold:.0%} threshold. "
                            f"Compound discrimination may be invisible to "
                            f"univariate analysis."
                        ),
                        regulation="12 CFR 1002.4(a)",
                        details=ir.to_dict(),
                    ))

        proxy_detector = ProxyDetector(
            correlation_threshold=self.config.proxy_correlation_threshold,
            regulation_citation=self._get_regulation_citation("proxy_discrimination"),
        )
        proxy_results = proxy_detector.detect(
            features=X_test,
            protected_data=protected_data,
            protected_columns=self.config.protected_columns,
        )

        for proxy in proxy_results:
            severity = FindingSeverity.CRITICAL if proxy.is_high_risk else FindingSeverity.WARNING
            findings.append(Finding(
                severity=severity,
                category="proxy_discrimination",
                description=(
                    f"{'CRITICAL: ' if proxy.is_high_risk else ''}"
                    f"Feature '{proxy.feature_name}' correlates {proxy.correlation:.2f} "
                    f"with {proxy.protected_attribute}"
                ),
                regulation=self._get_regulation_citation("proxy_discrimination"),
                details=proxy.to_dict(),
            ))

        lda_candidates = []
        lda_search_summary: Optional[LDASearchSummary] = None
        if self.config.run_lda_search and model_factory and proxy_results:
            searcher = LDASearcher(
                max_auc_loss=self.config.max_auc_loss,
                four_fifths_threshold=self.config.four_fifths_threshold,
            )

            proxy_features = list(set(p.feature_name for p in proxy_results))

            for di in di_results:
                if di.has_disparate_impact:
                    try:
                        from sklearn.metrics import roc_auc_score
                        original_auc = roc_auc_score(y_test, probabilities)

                        candidates = searcher.search(
                            X_train=X_train,
                            y_train=y_train,
                            X_test=X_test,
                            y_test=y_test,
                            protected_test=protected_data,
                            protected_column=di.protected_attribute,
                            proxy_features=proxy_features,
                            model_factory=model_factory,
                            substitute_features=self.config.substitute_features,
                            original_auc=original_auc,
                            original_disparity=di.worst_ratio,
                        )
                        lda_candidates.extend(candidates)
                        lda_search_summary = searcher.last_search_summary

                        passing = [c for c in candidates if c.passes_four_fifths]
                        if passing:
                            best = passing[0]
                            findings.append(Finding(
                                severity=FindingSeverity.INFO,
                                category="lda_found",
                                description=(
                                    f"LDA found: removing {', '.join(best.removed_features)} "
                                    f"improves disparity to {best.candidate_disparity:.2f} "
                                    f"with {best.auc_loss_pct:.1f}% accuracy loss"
                                ),
                                regulation=self._get_regulation_citation("lda"),
                                details=best.to_dict(),
                            ))
                    except Exception as e:
                        logger.warning("LDA search failed: %s", e)

        adverse_actions = []
        if self.config.run_adverse_action:
            aa_kwargs: Dict[str, Any] = {
                "max_reasons": self.config.max_adverse_action_reasons
            }
            if self._framework is not None:
                aa_kwargs["reason_code_library"] = self._framework.reason_code_library
                if self._framework.feature_mapping:
                    aa_kwargs["feature_mapping"] = self._framework.feature_mapping
            generator = AdverseActionGenerator(**aa_kwargs)
            try:
                adverse_actions = generator.generate(
                    model=model,
                    X=X_test,
                    predictions=predictions,
                    probabilities=probabilities,
                )

                denied = [a for a in adverse_actions if a.prediction == 0]
                no_reasons = [a for a in denied if not a.reasons]
                if no_reasons:
                    pct = len(no_reasons) / len(denied) * 100 if denied else 0
                    findings.append(Finding(
                        severity=FindingSeverity.WARNING,
                        category="adverse_action",
                        description=(
                            f"Adverse action reasons insufficient for {pct:.0f}% "
                            f"of denials ({len(no_reasons)} of {len(denied)})"
                        ),
                        regulation=self._get_regulation_citation("adverse_action"),
                    ))

                # CFPB Circular 2023-03: flag low-confidence explanations
                if adverse_actions:
                    sample = adverse_actions[0]
                    method = sample.explanation_method
                    confidence = sample.explanation_confidence

                    if method == "zeros":
                        findings.append(Finding(
                            severity=FindingSeverity.CRITICAL,
                            category="adverse_action",
                            description=(
                                "No feature importance method available. "
                                "Adverse action reasons are not backed by "
                                "model-specific explanations. CFPB Circular "
                                "2023-03 requires accurate, specific reasons."
                            ),
                            regulation="CFPB Circular 2023-03",
                        ))
                    elif method == "feature_importances":
                        findings.append(Finding(
                            severity=FindingSeverity.WARNING,
                            category="adverse_action",
                            description=(
                                "Using global feature importances instead of "
                                "per-applicant SHAP values. Adverse action "
                                "reasons may not reflect individual denial "
                                "factors as required by 12 CFR 1002.9(a)(2)."
                            ),
                            regulation="12 CFR 1002.9(a)(2)",
                        ))
                    elif method == "shap" and confidence < 0.90:
                        findings.append(Finding(
                            severity=FindingSeverity.WARNING,
                            category="adverse_action",
                            description=(
                                f"SHAP explanation fidelity is {confidence:.2f} "
                                f"(below 0.90 threshold). Explanations may not "
                                f"accurately reflect model behaviour. Consider "
                                f"validating with an alternative method."
                            ),
                            regulation="CFPB Circular 2023-03",
                        ))
            except Exception as e:
                logger.warning("Adverse action generation failed: %s", e)

        analysis_time = time.time() - start_time

        # Capture explanation metadata
        explanation_method = "none"
        explanation_confidence = 0.0
        if adverse_actions:
            explanation_method = adverse_actions[0].explanation_method
            explanation_confidence = adverse_actions[0].explanation_confidence

        summary = {
            "total_findings": len(findings),
            "critical": sum(1 for f in findings if f.severity == FindingSeverity.CRITICAL),
            "warnings": sum(1 for f in findings if f.severity == FindingSeverity.WARNING),
            "disparate_impact_detected": any(d.has_disparate_impact for d in di_results),
            "proxy_features_detected": len(proxy_results),
            "lda_candidates_found": len(lda_candidates),
            "lda_passing_found": sum(1 for c in lda_candidates if c.passes_four_fifths),
            "negative_outcomes": sum(1 for a in adverse_actions if a.prediction == 0),
            "explanation_method": explanation_method,
            "explanation_confidence": explanation_confidence,
            "model_hash": model_hash,
            "model_version": model_version,
            "data_quality_issues": len(dq_findings),
            "intersectional_di_detected": any(
                ir.has_disparate_impact for ir in intersectional_results
            ),
            "analysis_time_seconds": analysis_time,
            "dag_isolation_verified": dag_isolation_verified,
            "dag_protected_in_model": dag_protected_in_model,
        }

        report = FairLensReport(
            model_name=model_name,
            timestamp=time.time(),
            config=self.config,
            findings=findings,
            disparate_impact_results=di_results,
            proxy_results=proxy_results,
            lda_candidates=lda_candidates,
            adverse_action_samples=adverse_actions,
            analysis_time_seconds=analysis_time,
            summary=summary,
            lda_search_summary=lda_search_summary,
            intersectional_results=intersectional_results,
            model_identity=model_id,
            data_quality_findings=dq_findings,
        )
        if self._framework:
            report.framework_name = self._framework.name
            report.framework_description = self._framework.description
            report.monitoring_frequency = self._framework.monitoring_frequency
            report.risk_tier = self._framework.risk_tier
            report.threshold_justification = (
                self._framework.threshold_justification
            )

        return report
