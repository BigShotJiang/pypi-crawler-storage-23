"""
Database schema for HYDRA-32 provenance storage.

Optimized for:
- Fast fingerprint lookup (litigation queries)
- Efficient batch inserts (ML pipeline writes)
- Protected data auditing (compliance queries)
- Source lineage tracing (debugging queries)
"""

from typing import Optional
import psycopg2
from psycopg2 import sql


SCHEMA_VERSION = 1


def get_schema_ddl() -> str:
    """
    Returns the complete DDL for HYDRA-32 provenance database.

    Schema design:
    - dag_nodes: Core computation graph (indexed by fingerprint)
    - dag_edges: Parent-child relationships (for traversal)
    - source_registry: Map pair_id to (table, column) names
    - pipeline_metadata: Track pipeline executions for auditing
    """
    return """
-- =============================================================================
-- HYDRA-32 Provenance Database Schema v1
-- =============================================================================

-- Core DAG nodes (operations and source data)
CREATE TABLE IF NOT EXISTS dag_nodes (
    node_id BIGSERIAL PRIMARY KEY,
    fingerprint BIGINT NOT NULL,  -- 32-bit provenance (unsigned, requires BIGINT)
    node_type VARCHAR(20) NOT NULL,  -- SOURCE, BINARY, UNARY, MERGE, etc.
    operation VARCHAR(100) NOT NULL,  -- Operation name or column name

    -- For source nodes
    table_name VARCHAR(255),
    column_name VARCHAR(255),
    pair_id INTEGER,
    is_protected BOOLEAN DEFAULT FALSE,

    -- Metadata
    entity_hash INTEGER,  -- Which rows contributed
    chain_hash INTEGER,   -- Computation path hash
    metadata JSONB,       -- Flexible metadata storage

    -- Auditing
    created_at TIMESTAMP DEFAULT NOW(),
    pipeline_id BIGINT,   -- Link to pipeline execution
    tenant_id VARCHAR(64),  -- Customer/tenant ID (for multi-tenancy)

    -- Constraints
    UNIQUE(fingerprint, pipeline_id, tenant_id)
);

-- DAG edges (parent-child relationships)
CREATE TABLE IF NOT EXISTS dag_edges (
    edge_id BIGSERIAL PRIMARY KEY,
    parent_node_id BIGINT NOT NULL REFERENCES dag_nodes(node_id),
    child_node_id BIGINT NOT NULL REFERENCES dag_nodes(node_id),
    input_position INTEGER DEFAULT 0,  -- 0 for left input, 1 for right (binary ops)

    UNIQUE(parent_node_id, child_node_id, input_position)
);

-- Source registry (pair_id -> table/column mapping)
CREATE TABLE IF NOT EXISTS source_registry (
    pair_id INTEGER PRIMARY KEY,
    table_name VARCHAR(255) NOT NULL,
    column_name VARCHAR(255) NOT NULL,
    is_protected BOOLEAN DEFAULT FALSE,
    registered_at TIMESTAMP DEFAULT NOW(),

    UNIQUE(table_name, column_name)
);

-- Pipeline execution metadata (for auditing)
CREATE TABLE IF NOT EXISTS pipeline_metadata (
    pipeline_id BIGSERIAL PRIMARY KEY,
    pipeline_name VARCHAR(255),
    tenant_id VARCHAR(64),  -- Customer/tenant ID
    started_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP,
    status VARCHAR(20),  -- 'running', 'completed', 'failed'
    config JSONB,        -- Pipeline configuration
    git_commit VARCHAR(40),  -- Git commit hash for reproducibility
    environment JSONB    -- Python version, package versions, etc.
);

-- =============================================================================
-- Indexes for Performance
-- =============================================================================

-- Multi-tenant data isolation (CRITICAL for security)
CREATE INDEX IF NOT EXISTS idx_dag_nodes_tenant
    ON dag_nodes(tenant_id);

-- Fast fingerprint lookup within tenant (litigation queries)
CREATE INDEX IF NOT EXISTS idx_dag_nodes_tenant_fingerprint
    ON dag_nodes(tenant_id, fingerprint);

-- Protected data queries (compliance auditing)
CREATE INDEX IF NOT EXISTS idx_dag_nodes_tenant_protected
    ON dag_nodes(tenant_id, is_protected) WHERE is_protected = TRUE;

-- Source lineage queries (debugging)
CREATE INDEX IF NOT EXISTS idx_dag_nodes_source
    ON dag_nodes(tenant_id, table_name, column_name)
    WHERE node_type = 'SOURCE';

-- Time-based queries (retention policies)
CREATE INDEX IF NOT EXISTS idx_dag_nodes_tenant_created
    ON dag_nodes(tenant_id, created_at);

-- Pipeline-specific queries
CREATE INDEX IF NOT EXISTS idx_dag_nodes_pipeline
    ON dag_nodes(pipeline_id);

-- Tenant pipeline queries
CREATE INDEX IF NOT EXISTS idx_pipeline_metadata_tenant
    ON pipeline_metadata(tenant_id, started_at);

-- Edge traversal performance
CREATE INDEX IF NOT EXISTS idx_dag_edges_parent
    ON dag_edges(parent_node_id);
CREATE INDEX IF NOT EXISTS idx_dag_edges_child
    ON dag_edges(child_node_id);

-- =============================================================================
-- Views for Common Queries
-- =============================================================================

-- All protected sources in the system
CREATE OR REPLACE VIEW protected_sources AS
SELECT DISTINCT table_name, column_name, pair_id
FROM source_registry
WHERE is_protected = TRUE;

-- Recent pipeline executions
CREATE OR REPLACE VIEW recent_pipelines AS
SELECT pipeline_id, pipeline_name, started_at, completed_at, status
FROM pipeline_metadata
ORDER BY started_at DESC
LIMIT 100;

-- =============================================================================
-- Functions for Data Integrity
-- =============================================================================

-- Pipeline results: links each row's output to its provenance DAG
CREATE TABLE IF NOT EXISTS pipeline_results (
    result_id SERIAL PRIMARY KEY,
    pipeline_id INTEGER NOT NULL REFERENCES pipeline_metadata(pipeline_id),
    row_key TEXT NOT NULL,
    output_name TEXT NOT NULL,
    fingerprint BIGINT NOT NULL,
    output_value DOUBLE PRECISION,
    input_hash TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_pipeline_results_row ON pipeline_results(pipeline_id, row_key);
CREATE INDEX IF NOT EXISTS idx_pipeline_results_fingerprint ON pipeline_results(pipeline_id, fingerprint);

CREATE TABLE IF NOT EXISTS row_values (
    value_id BIGSERIAL PRIMARY KEY,
    pipeline_id BIGINT NOT NULL REFERENCES pipeline_metadata(pipeline_id),
    row_index INTEGER NOT NULL,
    fingerprint BIGINT NOT NULL,
    node_operation VARCHAR(100) NOT NULL,
    column_name VARCHAR(255),
    value DOUBLE PRECISION,
    text_value TEXT,
    tenant_id VARCHAR(64),
    created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_row_values_pipeline_row ON row_values(pipeline_id, row_index);
CREATE INDEX IF NOT EXISTS idx_row_values_tenant_pipeline ON row_values(tenant_id, pipeline_id);

-- Automatically update pipeline completion time
CREATE OR REPLACE FUNCTION update_pipeline_completed()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'completed' OR NEW.status = 'failed' THEN
        NEW.completed_at = NOW();
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_pipeline_completed
BEFORE UPDATE ON pipeline_metadata
FOR EACH ROW
EXECUTE FUNCTION update_pipeline_completed();
"""


def init_database(connection_string: str) -> None:
    """
    Initialize the HYDRA-32 provenance database.

    Creates all tables, indexes, and views if they don't exist.

    Args:
        connection_string: PostgreSQL connection string
                          Format: "postgresql://user:pass@host:port/dbname"

    Example:
        init_database("postgresql://localhost/hydra24_provenance")
    """
    conn = psycopg2.connect(connection_string)
    try:
        with conn.cursor() as cur:
            cur.execute(get_schema_ddl())
            conn.commit()
            print(f"✓ HYDRA-32 database initialized (schema v{SCHEMA_VERSION})")
    finally:
        conn.close()


def drop_all_tables(connection_string: str, confirm: bool = False) -> None:
    """
    Drop all HYDRA-32 tables (DANGEROUS - for testing only).

    Args:
        connection_string: PostgreSQL connection string
        confirm: Must be True to actually drop tables

    Raises:
        ValueError: If confirm=False
    """
    if not confirm:
        raise ValueError(
            "Must pass confirm=True to drop tables. This is destructive!"
        )

    conn = psycopg2.connect(connection_string)
    try:
        with conn.cursor() as cur:
            cur.execute("""
                DROP TABLE IF EXISTS pipeline_results CASCADE;
                DROP TABLE IF EXISTS dag_edges CASCADE;
                DROP TABLE IF EXISTS dag_nodes CASCADE;
                DROP TABLE IF EXISTS source_registry CASCADE;
                DROP TABLE IF EXISTS pipeline_metadata CASCADE;
                DROP VIEW IF EXISTS protected_sources CASCADE;
                DROP VIEW IF EXISTS recent_pipelines CASCADE;
            """)
            conn.commit()
            print("⚠ All HYDRA-32 tables dropped")
    finally:
        conn.close()


def get_schema_version(connection_string: str) -> Optional[int]:
    """
    Get the current schema version of the database.

    Returns:
        Schema version number, or None if database not initialized
    """
    conn = psycopg2.connect(connection_string)
    try:
        with conn.cursor() as cur:
            # Check if tables exist
            cur.execute("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables
                    WHERE table_name = 'dag_nodes'
                );
            """)
            exists = cur.fetchone()[0]
            if not exists:
                return None

            # For now, we only have v1
            return SCHEMA_VERSION
    finally:
        conn.close()
