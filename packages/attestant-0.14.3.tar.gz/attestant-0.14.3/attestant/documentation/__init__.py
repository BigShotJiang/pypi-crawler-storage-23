"""
Attestant Documentation Generators: Living compliance docs (Stage 4).

Auto-generates regulatory documentation in SR 11-7, OCC, and EU AI Act formats.
Documentation reflects actual pipeline state and regenerates when models change.

Usage:
    from attestant.documentation import SR117Generator

    generator = SR117Generator()
    report_md = generator.generate(
        model_name="credit_scoring_v2",
        model_version="2.1.0",
        fairness_report=fairness_report,
        dag=computation_dag,
        metadata=metadata,
    )

    with open("model_validation_report.md", "w") as f:
        f.write(report_md)
"""

from .base import BaseDocumentGenerator, DocumentSection
from .sr117_generator import SR117Generator

__all__ = [
    "BaseDocumentGenerator",
    "DocumentSection",
    "SR117Generator",
]
