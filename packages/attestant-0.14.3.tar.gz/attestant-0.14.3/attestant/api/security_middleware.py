"""
Security Middleware for Attestant API Server

Integrates enterprise security features:
- Comprehensive audit logging
- Enhanced API key validation (expiration, IP whitelist)
- IP reputation tracking
- Anomaly detection
"""

import logging
from functools import wraps
from typing import Optional
from flask import request, jsonify, g

logger = logging.getLogger(__name__)


def get_client_ip():
    """Extract client IP from request"""
    if request.headers.get("X-Forwarded-For"):
        return request.headers.get("X-Forwarded-For").split(",")[0].strip()
    return request.remote_addr


def secure_api_endpoint(f):
    """
    Enhanced API endpoint wrapper with security features.

    Applies:
    - Enhanced API key validation (expiration, IP whitelist)
    - Audit logging
    - IP reputation tracking
    - Anomaly detection

    Usage:
        @app.route("/v1/endpoint")
        @secure_api_endpoint
        def my_endpoint():
            tenant_id = g.tenant_id  # Available in request context
            ...
    """

    @wraps(f)
    def decorated(*args, **kwargs):
        from attestant.security.api_keys import validate_api_key_security
        from attestant.security.audit_logger import AuditLogger
        from attestant.security.monitoring import SecurityMonitor

        # Get database connection from Flask g
        from flask import current_app

        db_conn = g.get("db")
        if not db_conn:
            logger.error("No database connection in Flask g")
            return jsonify({"error": "Internal server error"}), 500

        # Extract API key
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing Authorization header"}), 401

        api_key = auth[7:]
        client_ip = get_client_ip()
        user_agent = request.headers.get("User-Agent", "")

        # STEP 1: Enhanced API key validation
        validation_result = validate_api_key_security(api_key, client_ip, db_conn)

        if not validation_result["valid"]:
            # Log failed API call
            audit_logger = AuditLogger(db_conn)
            audit_logger.log_event(
                tenant_id="unknown",
                event_type="api_call",
                event_category="data_access",
                status="failure",
                ip_address=client_ip,
                user_agent=user_agent,
                details={"error": validation_result["error"]},
                severity="warning",
            )

            # Track IP reputation
            monitor = SecurityMonitor(db_conn)
            monitor.update_ip_reputation(client_ip, "blocked")

            return jsonify({"error": validation_result["error"]}), 401

        tenant_id = validation_result["tenant_id"]
        tier = validation_result["tier"]

        # Warn if API key expires soon
        if validation_result.get("expires_soon"):
            days = validation_result.get("days_until_expiry", 0)
            logger.warning(
                f"API key for tenant {tenant_id} expires in {days} days"
            )

        # STEP 2: Anomaly detection
        monitor = SecurityMonitor(db_conn)
        if monitor.detect_suspicious_ip(client_ip):
            logger.warning(f"Suspicious IP {client_ip} accessing {request.endpoint}")

        # STEP 3: Set request context
        g.tenant_id = tenant_id
        g.tier = tier
        g.api_key_id = api_key[:10]
        g.client_ip = client_ip

        # STEP 4: Execute endpoint
        start_time = __import__("time").time()
        try:
            response = f(*args, **kwargs)
            response_time_ms = int((__import__("time").time() - start_time) * 1000)

            # Log successful API call
            audit_logger = AuditLogger(db_conn)
            audit_logger.log_api_call(
                tenant_id=tenant_id,
                api_key_id=api_key[:10],
                endpoint=request.endpoint,
                ip_address=client_ip,
                status_code=200,
                response_time_ms=response_time_ms,
            )

            # Update IP reputation (good request)
            monitor.update_ip_reputation(client_ip, "request")

            return response

        except Exception as exc:
            # Log failed API call
            response_time_ms = int((__import__("time").time() - start_time) * 1000)
            audit_logger = AuditLogger(db_conn)
            audit_logger.log_api_call(
                tenant_id=tenant_id,
                api_key_id=api_key[:10],
                endpoint=request.endpoint,
                ip_address=client_ip,
                status_code=500,
                response_time_ms=response_time_ms,
            )

            logger.error(f"API endpoint error: {exc}", exc_info=True)
            raise

    return decorated


def log_dashboard_event(
    event_type: str,
    action: str,
    resource_type: Optional[str] = None,
    resource_id: Optional[str] = None,
):
    """
    Decorator for dashboard endpoints to log security events.

    Usage:
        @app.route("/admin/users/create")
        @log_dashboard_event("user_management", "create", "user")
        def create_user():
            ...
    """

    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            from attestant.security.audit_logger import AuditLogger

            db_conn = g.get("db")
            if not db_conn:
                return f(*args, **kwargs)

            tenant_id = g.get("tenant_id", "unknown")
            user_id = g.get("user_id")
            client_ip = get_client_ip()

            # Execute endpoint
            response = f(*args, **kwargs)

            # Log after successful execution
            audit_logger = AuditLogger(db_conn)
            audit_logger.log_event(
                tenant_id=tenant_id,
                event_type=event_type,
                event_category="admin",
                status="success",
                user_id=user_id,
                ip_address=client_ip,
                resource_type=resource_type,
                resource_id=resource_id,
                action=action,
                severity="info" if action == "view" else "warning",
            )

            return response

        return decorated

    return decorator
