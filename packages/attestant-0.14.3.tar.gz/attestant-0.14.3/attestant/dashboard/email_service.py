import logging
import os

logger = logging.getLogger(__name__)

EMAIL_ENABLED = os.environ.get("EMAIL_ENABLED", "false").lower() == "true"
SES_FROM_ADDRESS = os.environ.get("SES_FROM_ADDRESS", "noreply@attestant.ai")
AWS_REGION = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")

_ses_client = None


def _get_ses_client():
    global _ses_client
    if _ses_client is None:
        import boto3
        _ses_client = boto3.client("ses", region_name=AWS_REGION)
    return _ses_client


def send_alert_email(to_email: str, alert_title: str, severity: str,
                     description: str, tenant_name: str) -> None:
    if not to_email:
        return
    if not EMAIL_ENABLED:
        logger.info(
            "[EMAIL DISABLED] Would send alert email to %s: [%s] %s",
            to_email, severity.upper(), alert_title
        )
        return
    try:
        ses = _get_ses_client()
        ses.send_email(
            Source=SES_FROM_ADDRESS,
            Destination={"ToAddresses": [to_email]},
            Message={
                "Subject": {"Data": f"[{severity.upper()}] {alert_title} — {tenant_name}"},
                "Body": {
                    "Text": {
                        "Data": (
                            f"Alert from Attestant\n\n"
                            f"Tenant: {tenant_name}\n"
                            f"Severity: {severity.upper()}\n"
                            f"Alert: {alert_title}\n\n"
                            f"{description}\n\n"
                            f"View in dashboard: https://getattestant.com/client"
                        )
                    },
                    "Html": {
                        "Data": (
                            f"<h2>Attestant Alert</h2>"
                            f"<p><strong>Tenant:</strong> {tenant_name}</p>"
                            f"<p><strong>Severity:</strong> {severity.upper()}</p>"
                            f"<p><strong>Alert:</strong> {alert_title}</p>"
                            f"<p>{description}</p>"
                            f"<p><a href='https://getattestant.com/client'>View in dashboard</a></p>"
                        )
                    },
                },
            },
        )
    except Exception as e:
        logger.error("Failed to send alert email to %s: %s", to_email, e)


def send_welcome_email(to_email: str, tenant_name: str, api_key: str) -> None:
    if not to_email:
        return
    if not EMAIL_ENABLED:
        logger.info(
            "[EMAIL DISABLED] Would send welcome email to %s for tenant %s",
            to_email, tenant_name
        )
        return
    try:
        ses = _get_ses_client()
        ses.send_email(
            Source=SES_FROM_ADDRESS,
            Destination={"ToAddresses": [to_email]},
            Message={
                "Subject": {"Data": f"Welcome to Attestant — {tenant_name}"},
                "Body": {
                    "Text": {
                        "Data": (
                            f"Welcome to Attestant!\n\n"
                            f"Your account for {tenant_name} is ready.\n\n"
                            f"Dashboard: https://getattestant.com/client\n"
                            f"API Key: {api_key}\n\n"
                            f"Keep your API key secret. You can rotate it from the dashboard.\n\n"
                            f"Questions? Reply to this email."
                        )
                    },
                    "Html": {
                        "Data": (
                            f"<h2>Welcome to Attestant!</h2>"
                            f"<p>Your account for <strong>{tenant_name}</strong> is ready.</p>"
                            f"<p><a href='https://getattestant.com/client'>Open Dashboard</a></p>"
                            f"<p><strong>API Key:</strong> <code>{api_key}</code></p>"
                            f"<p><small>Keep your API key secret. "
                            f"You can rotate it from the dashboard.</small></p>"
                        )
                    },
                },
            },
        )
    except Exception as e:
        logger.error("Failed to send welcome email to %s: %s", to_email, e)


def send_payment_failed_email(to_email: str, tenant_name: str, invoice_url: str) -> None:
    if not to_email:
        return
    if not EMAIL_ENABLED:
        logger.info(
            "[EMAIL DISABLED] Would send payment failed email to %s for tenant %s",
            to_email, tenant_name
        )
        return
    try:
        ses = _get_ses_client()
        ses.send_email(
            Source=SES_FROM_ADDRESS,
            Destination={"ToAddresses": [to_email]},
            Message={
                "Subject": {"Data": f"Action Required: Payment Failed — {tenant_name}"},
                "Body": {
                    "Text": {
                        "Data": (
                            f"Payment Failed — Action Required\n\n"
                            f"We were unable to process your payment for {tenant_name}.\n\n"
                            f"Please update your payment method to avoid service interruption:\n"
                            f"{invoice_url}\n\n"
                            f"Or visit your billing portal: https://getattestant.com/billing/portal"
                        )
                    },
                    "Html": {
                        "Data": (
                            f"<h2>Payment Failed — Action Required</h2>"
                            f"<p>We were unable to process your payment for "
                            f"<strong>{tenant_name}</strong>.</p>"
                            f"<p>Please update your payment method to avoid "
                            f"service interruption:</p>"
                            f"<p><a href='{invoice_url}'>Pay Invoice</a></p>"
                            f"<p>Or visit your "
                            f"<a href='https://getattestant.com/billing/portal'>billing portal</a>.</p>"
                        )
                    },
                },
            },
        )
    except Exception as e:
        logger.error("Failed to send payment failed email to %s: %s", to_email, e)
