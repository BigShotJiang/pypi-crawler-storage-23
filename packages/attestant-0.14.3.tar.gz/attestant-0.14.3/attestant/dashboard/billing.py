import logging
import os
import uuid
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

USAGE_RATES = {
    "model_validations": 1000,  # $10.00 in cents
    "pipeline_runs":     200,   # $2.00
    "storage_gb":        25,    # $0.25
    "egress_gb":         20,    # $0.20
}

BASE_MONTHLY_CENTS = 19900  # $199.00

_STRIPE_METERED_PRICE_IDS = {
    "base":              os.environ.get("STRIPE_PRICE_BASE_MONTHLY", ""),
    "model_validations": os.environ.get("STRIPE_PRICE_MODEL_VALIDATIONS", ""),
    "pipeline_runs":     os.environ.get("STRIPE_PRICE_PIPELINE_RUNS", ""),
    "storage_gb":        os.environ.get("STRIPE_PRICE_STORAGE_GB", ""),
    "egress_gb":         os.environ.get("STRIPE_PRICE_EGRESS_GB", ""),
}

_STRIPE_PORTAL_CONFIG_ID = os.environ.get("STRIPE_PORTAL_CONFIG_ID", "")


def current_billing_period() -> int:
    now = datetime.now(timezone.utc)
    return now.year * 100 + now.month


def check_limit(store, tenant_id: str, limit_type: str):
    """All plans are metered — no hard caps. Always returns allowed."""
    period = current_billing_period()
    usage = store.get_usage_this_period(tenant_id, period)
    current = usage.get(limit_type, 0)
    return True, current, -1


def record_usage(store, tenant_id: str, event_type: str, quantity: int = 1) -> None:
    period = current_billing_period()
    store.increment_usage(tenant_id, event_type, period, quantity=quantity)
    sub = store.get_subscription(tenant_id)
    customer_id = sub.get("stripe_customer_id", "") if sub else ""
    _fire_stripe_meter_event(tenant_id, event_type, quantity=quantity, stripe_customer_id=customer_id)


def _fire_stripe_meter_event(
    tenant_id: str, event_type: str, quantity: int = 1, stripe_customer_id: str = ""
) -> None:
    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not stripe_key or not stripe_customer_id:
        return
    try:
        import stripe
        stripe.api_key = stripe_key
        idempotency_key = f"{event_type}_{tenant_id}_{uuid.uuid4().hex}"
        stripe.billing.MeterEvent.create(
            event_name=f"attestant_{event_type}",
            payload={"stripe_customer_id": stripe_customer_id, "value": str(quantity)},
            identifier=idempotency_key,
        )
    except Exception as e:
        logger.warning("Stripe meter event failed: %s", e)


def estimate_monthly_bill(store, tenant_id: str) -> dict:
    period = current_billing_period()
    usage = store.get_usage_this_period(tenant_id, period)
    mv  = int(usage.get("model_validations", 0))
    pr  = int(usage.get("pipeline_runs", 0))
    sgb = float(usage.get("storage_gb", 0))
    egb = float(usage.get("egress_gb", 0))
    base_cost = BASE_MONTHLY_CENTS / 100
    mv_cost   = mv  * 10.0
    pr_cost   = pr  * 2.0
    sgb_cost  = sgb * 0.25
    egb_cost  = egb * 0.20
    return {
        "base":              {"label": "Base fee",           "qty": None,  "cost": base_cost},
        "model_validations": {"label": "Model Validations",  "qty": mv,    "cost": mv_cost,  "rate": "$10.00/validation"},
        "pipeline_runs":     {"label": "Pipeline Runs",      "qty": pr,    "cost": pr_cost,  "rate": "$2.00/run"},
        "storage_gb":        {"label": "Storage",            "qty": sgb,   "cost": sgb_cost, "rate": "$0.25/GB"},
        "egress_gb":         {"label": "Egress",             "qty": egb,   "cost": egb_cost, "rate": "$0.20/GB"},
        "total":             round(base_cost + mv_cost + pr_cost + sgb_cost + egb_cost, 2),
        "period":            period,
    }


def get_or_create_stripe_customer(store, tenant_id: str, email: str, company_name: str) -> str:
    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not stripe_key:
        return ""
    sub = store.get_subscription(tenant_id)
    if sub and sub.get("stripe_customer_id"):
        return sub["stripe_customer_id"]
    try:
        import stripe
        stripe.api_key = stripe_key
        customer = stripe.Customer.create(
            email=email,
            name=company_name,
            metadata={"tenant_id": tenant_id},
        )
        store.upsert_subscription(tenant_id, stripe_customer_id=customer["id"])
        return customer["id"]
    except Exception as e:
        logger.error("Failed to create Stripe customer: %s", e)
        return ""


def get_checkout_url(store, tenant_id: str, plan: str, interval: str,
                     email: str, company: str, success_url: str, cancel_url: str) -> str:
    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not stripe_key:
        return success_url
    base_price_id = _STRIPE_METERED_PRICE_IDS.get("base", "")
    if not base_price_id:
        logger.warning("No Stripe base price ID configured (STRIPE_PRICE_BASE_MONTHLY)")
        return success_url
    try:
        import stripe
        stripe.api_key = stripe_key
        customer_id = get_or_create_stripe_customer(store, tenant_id, email, company)
        line_items = [{"price": base_price_id, "quantity": 1}]
        for meter_key in ("model_validations", "pipeline_runs", "storage_gb", "egress_gb"):
            price_id = _STRIPE_METERED_PRICE_IDS.get(meter_key, "")
            if price_id:
                line_items.append({"price": price_id})
        params = {
            "mode": "subscription",
            "line_items": line_items,
            "success_url": success_url,
            "cancel_url": cancel_url,
            "client_reference_id": tenant_id,
        }
        if customer_id:
            params["customer"] = customer_id
        else:
            params["customer_email"] = email
        session = stripe.checkout.Session.create(**params)
        return session["url"]
    except Exception as e:
        logger.error("Stripe checkout session failed: %s", e)
        return success_url


def get_billing_portal_url(store, tenant_id: str, return_url: str) -> str:
    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if not stripe_key:
        return return_url
    sub = store.get_subscription(tenant_id)
    customer_id = sub.get("stripe_customer_id") if sub else None
    if not customer_id:
        return return_url
    try:
        import stripe
        stripe.api_key = stripe_key
        portal_params = {"customer": customer_id, "return_url": return_url}
        if _STRIPE_PORTAL_CONFIG_ID:
            portal_params["configuration"] = _STRIPE_PORTAL_CONFIG_ID
        session = stripe.billing_portal.Session.create(**portal_params)
        return session["url"]
    except Exception as e:
        logger.error("Stripe billing portal failed: %s", e)
        return return_url


def handle_webhook(payload: bytes, sig_header: str, store) -> dict:
    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    webhook_secret = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
    if not stripe_key or not webhook_secret:
        return {"error": "Stripe not configured"}
    try:
        import stripe
        stripe.api_key = stripe_key
        event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
    except Exception as e:
        logger.warning("Stripe webhook validation failed: %s", e)
        return {"error": str(e)}

    event_type = event["type"]
    logger.info("Stripe webhook received: %s", event_type)

    if event_type in ("customer.subscription.created", "customer.subscription.updated"):
        sub_obj = event["data"]["object"]
        customer_id = sub_obj["customer"]
        tenant_id = store.get_tenant_by_stripe_customer(customer_id)
        if tenant_id:
            store.upsert_subscription(
                tenant_id,
                plan="metered",
                status=sub_obj["status"],
                stripe_subscription_id=sub_obj["id"],
                cancel_at_period_end=sub_obj.get("cancel_at_period_end", False),
                current_period_start=datetime.fromtimestamp(
                    sub_obj["current_period_start"], tz=timezone.utc
                ) if sub_obj.get("current_period_start") else None,
                current_period_end=datetime.fromtimestamp(
                    sub_obj["current_period_end"], tz=timezone.utc
                ) if sub_obj.get("current_period_end") else None,
            )

    elif event_type == "customer.subscription.deleted":
        sub_obj = event["data"]["object"]
        customer_id = sub_obj["customer"]
        tenant_id = store.get_tenant_by_stripe_customer(customer_id)
        if tenant_id:
            store.upsert_subscription(tenant_id, plan="starter", status="canceled")

    elif event_type == "invoice.payment_succeeded":
        invoice = event["data"]["object"]
        customer_id = invoice["customer"]
        tenant_id = store.get_tenant_by_stripe_customer(customer_id)
        if tenant_id:
            amount = invoice.get("amount_paid", 0) / 100
            logger.info("Invoice paid: tenant=%s amount=$%.2f", tenant_id, amount)

    elif event_type == "invoice.payment_failed":
        invoice = event["data"]["object"]
        customer_id = invoice["customer"]
        tenant_id = store.get_tenant_by_stripe_customer(customer_id)
        if tenant_id:
            store.insert_alert(tenant_id, {
                "severity": "critical",
                "source": "billing",
                "title": "Payment Failed",
                "description": (
                    f"Invoice payment failed. "
                    f"Please update your payment method to avoid service interruption. "
                    f"Invoice: {invoice.get('hosted_invoice_url', 'N/A')}"
                ),
            })

    return {"received": True, "type": event_type}
