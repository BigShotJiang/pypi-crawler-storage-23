"""Workflow parameter extraction, type resolution, and coercion."""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any, Literal, Union, get_args, get_origin, get_type_hints

from rowbase.errors import ValidationError


class _MissingSentinel:
    """Sentinel for parameters without a default value."""

    _instance: _MissingSentinel | None = None

    def __new__(cls) -> _MissingSentinel:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "MISSING"

    def __bool__(self) -> bool:
        return False


MISSING = _MissingSentinel()


@dataclass
class Param:
    """Attach a description (and optional default) to a pipeline parameter.

    Usage::

        @rowbase.pipeline
        def pipe(
            region: str = Param(default="US", description="Filter by region"),
        ):
            ...
    """

    default: Any = MISSING
    description: str = ""


@dataclass
class ParamSpec:
    """Discovered metadata for a single pipeline parameter."""

    name: str
    param_type: str  # "string", "integer", "float", "boolean", "date", "datetime", "enum"
    default: Any  # MISSING if no default
    required: bool
    description: str = ""
    enum_values: list[str] | None = None


# ---------------------------------------------------------------------------
# Type resolution
# ---------------------------------------------------------------------------

_TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "float",
    bool: "boolean",
    date: "date",
    datetime: "datetime",
}


def _is_optional(annotation: Any) -> tuple[bool, Any]:
    """Check if *annotation* is ``Optional[T]`` (i.e. ``Union[T, None]``).

    Returns ``(True, T)`` if optional, ``(False, annotation)`` otherwise.
    """
    origin = get_origin(annotation)
    if origin is Union:
        args = get_args(annotation)
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1 and len(args) == 2:
            return True, non_none[0]
    return False, annotation


def _unwrap_annotated(annotation: Any) -> tuple[Any, str]:
    """Unwrap ``Annotated[T, "desc", ...]`` → ``(T, description)``.

    Returns the first ``str`` metadata argument as the description.
    If not ``Annotated``, returns ``(annotation, "")``.
    """
    from typing import Annotated

    if get_origin(annotation) is Annotated:
        args = get_args(annotation)
        description = next((m for m in args[1:] if isinstance(m, str)), "")
        return args[0], description
    return annotation, ""


def _resolve_type(annotation: Any) -> tuple[str, list[str] | None, str, bool]:
    """Map a Python type annotation to ``(param_type, enum_values, description, is_optional)``.

    Raises :class:`ValidationError` for unsupported annotations.
    """
    # 1. Unwrap Annotated
    inner, annotated_desc = _unwrap_annotated(annotation)

    # 2. Unwrap Optional
    is_opt, inner = _is_optional(inner)

    # 3. Unwrap Annotated again (in case of Optional[Annotated[T, "desc"]])
    if not annotated_desc:
        inner, annotated_desc = _unwrap_annotated(inner)

    # 4. Check Literal
    if get_origin(inner) is Literal:
        enum_values = [str(v) for v in get_args(inner)]
        return "enum", enum_values, annotated_desc, is_opt

    # 5. Check basic types
    if inner in _TYPE_MAP:
        return _TYPE_MAP[inner], None, annotated_desc, is_opt

    raise ValidationError(
        code="UNSUPPORTED_PARAM_TYPE",
        message=f"Unsupported parameter type: {inner!r}.",
        hint=f"Supported types: {', '.join(t.__name__ for t in _TYPE_MAP)}, Literal, Optional.",
    )


# ---------------------------------------------------------------------------
# Param extraction
# ---------------------------------------------------------------------------


def _extract_params(fn: Any) -> list[ParamSpec]:
    """Inspect *fn*'s signature and return a :class:`ParamSpec` for each typed parameter."""
    sig = inspect.signature(fn)
    # get_type_hints resolves string annotations from `from __future__ import annotations`
    # include_extras=True preserves Annotated metadata
    try:
        resolved_hints = get_type_hints(fn, include_extras=True)
    except NameError as e:
        raise ValidationError(
            code="PARAM_TYPE_RESOLUTION_ERROR",
            message=f"Cannot resolve type hints for {fn.__name__!r}: {e}",
            hint="Ensure all parameter types are importable at module scope.",
        ) from e
    except Exception:
        resolved_hints = {}
    params: list[ParamSpec] = []

    for p in sig.parameters.values():
        annotation = resolved_hints.get(p.name)
        if annotation is None and p.annotation is inspect.Parameter.empty:
            continue
        if annotation is None:
            annotation = p.annotation

        # Determine raw default and whether a Param() wrapper was used
        raw_default = p.default
        param_wrapper: Param | None = None
        if isinstance(raw_default, Param):
            param_wrapper = raw_default
            raw_default = param_wrapper.default

        has_default = raw_default is not inspect.Parameter.empty and raw_default is not MISSING

        # Resolve type info
        param_type, enum_values, annotated_desc, is_opt = _resolve_type(annotation)

        # Description: Param() wins over Annotated
        description = ""
        if param_wrapper and param_wrapper.description:
            description = param_wrapper.description
        elif annotated_desc:
            description = annotated_desc

        # Required: has no default and is not Optional
        required = not has_default and not is_opt

        default = raw_default if has_default else MISSING

        params.append(
            ParamSpec(
                name=p.name,
                param_type=param_type,
                default=default,
                required=required,
                description=description,
                enum_values=enum_values,
            )
        )

    return params


# ---------------------------------------------------------------------------
# Coercion
# ---------------------------------------------------------------------------

_FALSY = frozenset({"false", "0", "no", "off", ""})


def _coerce_param(name: str, value: Any, spec: ParamSpec) -> Any:
    """Coerce a JSON-compatible *value* to the Python type described by *spec*.

    Raises :class:`ValidationError` on type mismatch.
    """
    if value is None:
        return None

    try:
        match spec.param_type:
            case "string":
                return str(value)
            case "integer":
                return int(value)
            case "float":
                return float(value)
            case "boolean":
                if isinstance(value, bool):
                    return value
                if isinstance(value, str):
                    return value.lower() not in _FALSY
                return bool(value)
            case "date":
                if isinstance(value, date) and not isinstance(value, datetime):
                    return value
                return date.fromisoformat(str(value))
            case "datetime":
                if isinstance(value, datetime):
                    return value
                return datetime.fromisoformat(str(value))
            case "enum":
                sv = str(value)
                if spec.enum_values and sv not in spec.enum_values:
                    raise ValidationError(
                        code="INVALID_PARAM_VALUE",
                        message=f"Parameter {name!r} value {sv!r} is not one of {spec.enum_values}.",
                    )
                return sv
    except ValidationError:
        raise
    except Exception as e:
        raise ValidationError(
            code="PARAM_COERCION_ERROR",
            message=f"Cannot coerce parameter {name!r} value {value!r} to {spec.param_type}: {e}",
        ) from e

    raise ValidationError(
        code="UNSUPPORTED_PARAM_TYPE",
        message=f"Unknown param_type {spec.param_type!r} for parameter {name!r}.",
    )


# ---------------------------------------------------------------------------
# Resolution (merge defaults + user overrides)
# ---------------------------------------------------------------------------


def resolve_params(
    param_specs: list[ParamSpec],
    user_params: dict[str, Any] | None,
) -> dict[str, Any]:
    """Merge *user_params* with defaults from *param_specs*, validate, and coerce.

    Returns a dict ready to be passed as ``**kwargs`` to the pipeline generator.
    """
    user_params = user_params or {}
    resolved: dict[str, Any] = {}

    spec_by_name = {s.name: s for s in param_specs}

    # Unknown params
    unknown = set(user_params) - set(spec_by_name)
    if unknown:
        raise ValidationError(
            code="UNKNOWN_PARAMS",
            message=f"Unknown parameters: {sorted(unknown)}.",
            hint=f"Valid parameters: {sorted(spec_by_name)}.",
        )

    for spec in param_specs:
        if spec.name in user_params:
            resolved[spec.name] = _coerce_param(spec.name, user_params[spec.name], spec)
        elif not spec.default is MISSING:
            resolved[spec.name] = spec.default
        elif spec.required:
            raise ValidationError(
                code="MISSING_REQUIRED_PARAM",
                message=f"Required parameter {spec.name!r} was not provided.",
            )
        # Optional with no default and no user value → None
        else:
            resolved[spec.name] = None

    return resolved
