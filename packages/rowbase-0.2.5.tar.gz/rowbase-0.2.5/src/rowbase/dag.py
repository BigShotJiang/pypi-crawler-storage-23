"""DAG construction, validation, and topological sort."""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from rowbase.errors import ValidationError

if TYPE_CHECKING:
    from rowbase._internal.registry import PipelineContext


@dataclass
class DAG:
    """Directed acyclic graph of pipeline sources, datasets, and assets."""

    nodes: list[str] = field(default_factory=list)  # topologically sorted
    edges: list[tuple[str, str]] = field(default_factory=list)  # (from, to)
    source_nodes: set[str] = field(default_factory=set)
    dataset_nodes: set[str] = field(default_factory=set)
    asset_nodes: set[str] = field(default_factory=set)

    @classmethod
    def from_context(cls, ctx: PipelineContext) -> DAG:
        """Build a DAG from a discovered pipeline context.

        Inspects each dataset's and asset's depends_on lists and matches them
        to registered source/dataset/asset names.
        """
        errors = _validate_references(ctx)
        if errors:
            raise errors[0]

        edges: list[tuple[str, str]] = []
        for ds_meta in ctx.datasets.values():
            for dep in ds_meta.depends_on:
                edges.append((dep, ds_meta.name))
        for asset_meta in ctx.assets.values():
            for dep in asset_meta.depends_on:
                edges.append((dep, asset_meta.name))

        source_nodes = set(ctx.sources.keys())
        dataset_nodes = set(ctx.datasets.keys())
        asset_nodes = set(ctx.assets.keys())
        all_nodes = source_nodes | dataset_nodes | asset_nodes

        sorted_nodes = _topological_sort(all_nodes, edges)

        return cls(
            nodes=sorted_nodes,
            edges=edges,
            source_nodes=source_nodes,
            dataset_nodes=dataset_nodes,
            asset_nodes=asset_nodes,
        )

    def validate(self) -> list[ValidationError]:
        """Run all validation checks on the DAG. Returns a list of errors."""
        return []  # Validation happens in from_context; this is for additional checks

    def execution_order(self) -> list[str]:
        """Return dataset and asset names in topological execution order (excludes sources)."""
        return [n for n in self.nodes if n in self.dataset_nodes or n in self.asset_nodes]

    def to_dict(self) -> dict[str, Any]:
        return {
            "nodes": self.nodes,
            "edges": [{"from": f, "to": t} for f, t in self.edges],
            "sources": sorted(self.source_nodes),
            "datasets": sorted(self.dataset_nodes),
            "assets": sorted(self.asset_nodes),
        }


def _validate_references(ctx: PipelineContext) -> list[ValidationError]:
    """Check that all dataset/asset dependencies reference known names."""
    errors: list[ValidationError] = []
    known = ctx.all_names
    asset_names = set(ctx.assets)

    for ds_meta in ctx.datasets.values():
        for dep in ds_meta.depends_on:
            if dep not in known:
                errors.append(
                    ValidationError(
                        code="INVALID_PIPELINE",
                        message=(
                            f"Dataset {ds_meta.name!r} depends on {dep!r}, "
                            f"which is not a registered source or dataset."
                        ),
                        hint=(
                            f"Parameter name {dep!r} in function "
                            f"{ds_meta.fn.__name__}() must match a source() or @dataset name."
                        ),
                    )
                )
            elif dep in asset_names:
                errors.append(
                    ValidationError(
                        code="INVALID_PIPELINE",
                        message=(
                            f"Dataset {ds_meta.name!r} depends on asset {dep!r}. "
                            f"Datasets cannot depend on assets."
                        ),
                        hint="Assets produce binary files, not DataFrames. "
                        "Only other assets can depend on assets.",
                    )
                )

    for asset_meta in ctx.assets.values():
        for dep in asset_meta.depends_on:
            if dep not in known:
                errors.append(
                    ValidationError(
                        code="INVALID_PIPELINE",
                        message=(
                            f"Asset {asset_meta.name!r} depends on {dep!r}, "
                            f"which is not a registered source, dataset, or asset."
                        ),
                        hint=(
                            f"Parameter name {dep!r} in function "
                            f"{asset_meta.fn.__name__}() must match a source(), @dataset, or @asset name."
                        ),
                    )
                )

    return errors


def _topological_sort(nodes: set[str], edges: list[tuple[str, str]]) -> list[str]:
    """Kahn's algorithm for topological sort. Raises on cycles."""
    in_degree: dict[str, int] = defaultdict(int)
    adjacency: dict[str, list[str]] = defaultdict(list)

    for node in nodes:
        in_degree.setdefault(node, 0)

    for src, dst in edges:
        adjacency[src].append(dst)
        in_degree[dst] += 1

    queue: deque[str] = deque(sorted(n for n in nodes if in_degree[n] == 0))
    result: list[str] = []

    while queue:
        node = queue.popleft()
        result.append(node)
        for neighbor in sorted(adjacency[node]):
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if len(result) != len(nodes):
        # Find the nodes involved in the cycle
        remaining = nodes - set(result)
        raise ValidationError(
            code="INVALID_PIPELINE",
            message=f"Pipeline contains a dependency cycle involving: {sorted(remaining)}.",
            hint="Check that dataset dependencies don't form a circular chain.",
        )

    return result
