"""Rowbase API client — deploy pipelines and submit runs to the platform."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import httpx

from rowbase.errors import RowbaseError

DEFAULT_API_URL = "https://api.rowbase.com"
CREDENTIALS_PATH = Path.home() / ".rowbase" / "credentials.json"


def _get_api_url() -> str:
    return os.environ.get("ROWBASE_API_URL", DEFAULT_API_URL)


def _get_api_key() -> str | None:
    key = os.environ.get("ROWBASE_API_KEY")
    if key:
        return key
    if CREDENTIALS_PATH.exists():
        data = json.loads(CREDENTIALS_PATH.read_text())
        return data.get("api_key")
    return None


def save_credentials(api_key: str) -> None:
    """Save API key to ~/.rowbase/credentials.json."""
    CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_PATH.write_text(json.dumps({"api_key": api_key}))
    CREDENTIALS_PATH.chmod(0o600)


def clear_credentials() -> None:
    """Remove stored credentials."""
    if CREDENTIALS_PATH.exists():
        CREDENTIALS_PATH.unlink()


def get_credentials_info() -> dict[str, Any]:
    """Return current auth state for display."""
    api_url = _get_api_url()
    api_key = _get_api_key()
    source = None
    if api_key:
        if os.environ.get("ROWBASE_API_KEY"):
            source = "env (ROWBASE_API_KEY)"
        else:
            source = str(CREDENTIALS_PATH)
    return {
        "authenticated": api_key is not None,
        "api_url": api_url,
        "key_prefix": api_key[:20] + "..." if api_key else None,
        "source": source,
    }


class RowbaseClient:
    """Synchronous HTTP client for the Rowbase API."""

    def __init__(self, api_url: str | None = None, api_key: str | None = None) -> None:
        self.api_url = (api_url or _get_api_url()).rstrip("/")
        self.api_key = api_key or _get_api_key()
        if not self.api_key:
            raise RowbaseError(
                code="AUTH_REQUIRED",
                message="No API key configured",
                hint="Run 'rowbase auth login' or set ROWBASE_API_KEY environment variable.",
            )
        self._client = httpx.Client(
            base_url=f"{self.api_url}/api/v1",
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=300.0,
        )

    def _raise_for_error(self, response: httpx.Response) -> None:
        if response.status_code >= 400:
            try:
                body = response.json()
                msg = body.get("message") or body.get("detail") or str(body)
            except Exception:
                msg = response.text
            raise RowbaseError(
                code="API_ERROR",
                message=f"API error ({response.status_code}): {msg}",
                details={"status_code": response.status_code},
            )

    def list_pipelines(self) -> list[dict[str, Any]]:
        """List all pipelines."""
        resp = self._client.get("/pipelines")
        self._raise_for_error(resp)
        return resp.json()

    def register_pipeline(
        self,
        name: str,
        files: dict[str, str],
        entrypoint: str,
        description: str | None = None,
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register or update a pipeline."""
        payload: dict[str, Any] = {
            "name": name,
            "files": files,
            "entrypoint": entrypoint,
        }
        if description:
            payload["description"] = description
        if tags:
            payload["tags"] = tags
        resp = self._client.post("/pipelines", json=payload)
        self._raise_for_error(resp)
        return resp.json()

    def discover_pipeline(self, pipeline_id: str) -> dict[str, Any]:
        """Get stored pipeline structure (sources, datasets, DAG)."""
        resp = self._client.get(f"/pipelines/{pipeline_id}/discover")
        self._raise_for_error(resp)
        return resp.json()

    def resolve_pipeline_id(self, name: str) -> str:
        """Resolve a pipeline name to its deployed public ID."""
        pipelines = self.list_pipelines()
        for p in pipelines:
            if p["name"] == name:
                return p["public_id"]
        raise RowbaseError(
            code="PIPELINE_NOT_FOUND",
            message=f"No deployed pipeline named '{name}'",
            hint="Run 'rowbase pipeline list' to see deployed pipelines, "
            "or deploy first with 'rowbase pipeline deploy'.",
        )

    def list_runs(self, pipeline_id: str) -> list[dict[str, Any]]:
        """List all runs for a pipeline."""
        resp = self._client.get(f"/pipelines/{pipeline_id}/runs")
        self._raise_for_error(resp)
        return resp.json()

    def submit_run(
        self,
        pipeline_id: str,
        files: dict[str, Path],
    ) -> dict[str, Any]:
        """Submit a pipeline run with input files."""
        file_tuples = []
        source_names = []
        for source_name, file_path in files.items():
            source_names.append(source_name)
            file_tuples.append(("files", (file_path.name, file_path.open("rb"))))

        try:
            resp = self._client.post(
                f"/pipelines/{pipeline_id}/runs",
                files=file_tuples,
                data={"source_names": json.dumps(source_names)},
            )
        finally:
            for _, (_, f) in file_tuples:
                f.close()

        self._raise_for_error(resp)
        return resp.json()

    def get_run(self, pipeline_id: str, run_id: str) -> dict[str, Any]:
        resp = self._client.get(f"/pipelines/{pipeline_id}/runs/{run_id}")
        self._raise_for_error(resp)
        return resp.json()

    def get_dataset_data(self, pipeline_id: str, run_id: str, dataset_name: str) -> dict[str, Any]:
        resp = self._client.get(
            f"/pipelines/{pipeline_id}/runs/{run_id}/datasets/{dataset_name}/data"
        )
        self._raise_for_error(resp)
        return resp.json()

    def get_step_metrics(self, pipeline_id: str, run_id: str) -> list[dict[str, Any]]:
        resp = self._client.get(f"/pipelines/{pipeline_id}/runs/{run_id}/step-metrics")
        self._raise_for_error(resp)
        return resp.json()

    def get_logs(self, pipeline_id: str, run_id: str) -> list[dict[str, Any]]:
        resp = self._client.get(f"/pipelines/{pipeline_id}/runs/{run_id}/logs")
        self._raise_for_error(resp)
        return resp.json()

    def get_dataset_detail(
        self, pipeline_id: str, run_id: str, dataset_name: str
    ) -> dict[str, Any]:
        resp = self._client.get(f"/pipelines/{pipeline_id}/runs/{run_id}/datasets/{dataset_name}")
        self._raise_for_error(resp)
        return resp.json()

    def get_errors(self, pipeline_id: str, run_id: str) -> list[dict[str, Any]]:
        resp = self._client.get(f"/pipelines/{pipeline_id}/runs/{run_id}/errors")
        self._raise_for_error(resp)
        return resp.json()


def collect_pipeline_files(
    pipeline_path: Path, pipelines_dir: Path | None = None
) -> tuple[dict[str, str], str]:
    """Collect pipeline files (entrypoint + siblings + lib/ + configs/) into a dict.

    Collects:
    - All files from *pipelines_dir* (entrypoint + siblings like base.py, __init__.py)
    - ``lib/`` from the project root (auxiliary Python modules)
    - ``configs/`` from the project root (YAML/JSON config files)

    Returns ``(files, entrypoint)`` where *entrypoint* is the relative path of
    the main pipeline file within the files dict, keyed relative to the project
    root (e.g. ``brands/hinkley.py``).

    *pipelines_dir* overrides the pipeline source directory.  Defaults to the
    pipeline file's parent directory.  ``lib/`` and ``configs/`` are resolved
    relative to the project root (found via ``rowbase.yaml``), falling back to
    the parent of *pipelines_dir* when no ``rowbase.yaml`` exists.
    """
    from rowbase.config import find_project_root

    resolved = pipeline_path.resolve()
    pip_dir = pipelines_dir.resolve() if pipelines_dir else resolved.parent

    project_root = find_project_root(pip_dir) or pip_dir.parent

    if not resolved.is_relative_to(project_root):
        project_root = resolved.parent

    entrypoint = str(resolved.relative_to(project_root))

    _collect_suffixes = (".py", ".yaml", ".yml", ".json")
    files: dict[str, str] = {}

    # Collect ALL files from pipelines_dir (brand files, base.py, __init__.py, etc.)
    for file in pip_dir.rglob("*"):
        if file.is_file() and file.suffix in _collect_suffixes:
            if "__pycache__" in file.parts:
                continue
            rel = str(file.relative_to(project_root))
            files[rel] = file.read_text()

    # Ensure entrypoint is always present
    if entrypoint not in files:
        files[entrypoint] = resolved.read_text()

    # Collect lib/ and configs/ from project root (skip if inside pipelines_dir)
    for subdir in ("lib", "configs"):
        scan_dir = project_root / subdir
        if not scan_dir.is_dir():
            continue
        if scan_dir.resolve().is_relative_to(pip_dir):
            continue
        for file in scan_dir.rglob("*"):
            if file.is_file() and file.suffix in _collect_suffixes:
                rel = str(file.relative_to(project_root))
                files[rel] = file.read_text()

    return files, entrypoint
