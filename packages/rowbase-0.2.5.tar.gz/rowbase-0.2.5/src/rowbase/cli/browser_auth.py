"""Browser-based authentication flow for the Rowbase CLI."""

from __future__ import annotations

import http.server
import os
import threading
import urllib.parse
import webbrowser

DEFAULT_FRONTEND_URL = "https://www.rowbase.com"

_SUCCESS_HTML = b"""\
<!DOCTYPE html>
<html>
<head><title>Rowbase CLI</title></head>
<body style="font-family:system-ui,sans-serif;display:flex;justify-content:center;
align-items:center;height:100vh;margin:0;background:#fafafa">
<div style="text-align:center">
<h1 style="font-size:1.25rem;font-weight:600">Authenticated</h1>
<p style="color:#666;font-size:0.875rem">You can close this window and return to the terminal.</p>
</div>
</body>
</html>
"""


def _get_frontend_url() -> str:
    return os.environ.get("ROWBASE_FRONTEND_URL", DEFAULT_FRONTEND_URL)


def browser_login(timeout: float = 120) -> str | None:
    """Open the browser for authentication, return the API key or *None* on timeout/cancel."""
    result: dict[str, str | None] = {"key": None}

    class _Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path == "/callback":
                params = urllib.parse.parse_qs(parsed.query)
                keys = params.get("key", [])
                if keys:
                    result["key"] = keys[0]
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html")
                    self.end_headers()
                    self.wfile.write(_SUCCESS_HTML)
                    threading.Thread(target=self.server.shutdown, daemon=True).start()
                    return

            self.send_response(404)
            self.end_headers()

        def log_message(self, format: str, *args: object) -> None:
            pass

    server = http.server.HTTPServer(("127.0.0.1", 0), _Handler)
    port = server.server_address[1]

    auth_url = f"{_get_frontend_url()}/cli?callback_port={port}"
    if not webbrowser.open(auth_url):
        import typer

        typer.echo(f"Open this URL in your browser:\n  {auth_url}")

    serve_thread = threading.Thread(target=server.serve_forever, daemon=True)
    serve_thread.start()
    serve_thread.join(timeout=timeout)

    if serve_thread.is_alive():
        server.shutdown()
        serve_thread.join()

    return result["key"]
