"""Output formatters for CLI commands."""

from __future__ import annotations

import json
from typing import Any

from rich.console import Console
from rich.table import Table

console = Console()
error_console = Console(stderr=True)


def print_json(data: dict[str, Any]) -> None:
    """Print data as formatted JSON to stdout."""
    print(json.dumps(data, indent=2, default=str))


def print_success(message: str) -> None:
    console.print(f"[green]✓[/green] {message}")


def print_error(message: str) -> None:
    error_console.print(f"[red]✗[/red] {message}")


def print_warning(message: str) -> None:
    console.print(f"[yellow]![/yellow] {message}")


def print_dag_table(
    sources: list[dict[str, Any]],
    datasets: list[dict[str, Any]],
    published: set[str],
    assets: list[dict[str, Any]] | None = None,
) -> None:
    """Print pipeline DAG as a rich table."""
    table = Table(title="Pipeline Graph")
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="green")
    table.add_column("Depends On")
    table.add_column("Published", justify="center")

    for src in sources:
        table.add_row(src["name"], "source", "", "")

    for ds in datasets:
        deps = ", ".join(ds.get("depends_on", []))
        pub = "✓" if ds["name"] in published else ""
        table.add_row(ds["name"], "dataset", deps, pub)

    for asset in assets or []:
        deps = ", ".join(asset.get("depends_on", []))
        table.add_row(asset["name"], "asset", deps, "")

    console.print(table)


def _format_bytes(n: int) -> str:
    """Format byte count as a human-readable string."""
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def _print_captured_output(result: dict[str, Any]) -> None:
    """Print captured stdout, stderr, and log records from dataset and asset functions."""
    has_output = False

    for name, ds in result.get("datasets", {}).items():
        for stream in ("stdout", "stderr"):
            if ds.get(stream):
                if not has_output:
                    console.print("\n[dim]Captured output:[/dim]")
                    has_output = True
                console.print(f"  [cyan]{name}[/cyan] ({stream}):")
                for line in ds[stream].rstrip().splitlines():
                    console.print(f"    {line}")

    for name, asset in result.get("assets", {}).items():
        for stream in ("stdout", "stderr"):
            if asset.get(stream):
                if not has_output:
                    console.print("\n[dim]Captured output:[/dim]")
                    has_output = True
                console.print(f"  [cyan]{name}[/cyan] [dim](asset)[/dim] ({stream}):")
                for line in asset[stream].rstrip().splitlines():
                    console.print(f"    {line}")

    for log in result.get("logs", []):
        if not has_output:
            console.print("\n[dim]Captured output:[/dim]")
            has_output = True
        level_color = {"WARNING": "yellow", "ERROR": "red", "CRITICAL": "red"}.get(
            log["level"], "dim"
        )
        console.print(
            f"  [cyan]{log['dataset']}[/cyan] "
            f"[{level_color}]{log['level']}[/{level_color}]: {log['message']}"
        )


def print_run_result(result: dict[str, Any]) -> None:
    """Print a run result as a rich table."""
    status = result["status"]
    color = "green" if status == "success" else "yellow" if status == "partial" else "red"
    console.print(f"\nRun [bold]{result['run_id']}[/bold] — [{color}]{status}[/{color}]")
    console.print(f"Duration: {result['duration_ms']}ms")

    if result.get("datasets"):
        table = Table(title="Datasets")
        table.add_column("Name", style="cyan")
        table.add_column("Rows", justify="right")
        table.add_column("Columns")

        for name, ds in result["datasets"].items():
            table.add_row(name, str(ds["row_count"]), ", ".join(ds["columns"]))

        console.print(table)

    if result.get("assets"):
        table = Table(title="Assets")
        table.add_column("Name", style="cyan")
        table.add_column("Files", justify="right")
        table.add_column("Size", justify="right")
        table.add_column("Type")

        for name, asset in result["assets"].items():
            size = _format_bytes(asset["total_bytes"])
            table.add_row(name, str(asset["file_count"]), size, asset["content_type"])

        console.print(table)

    _print_captured_output(result)

    if result.get("errors"):
        for err in result["errors"]:
            print_error(f"[{err['code']}] {err['message']}")
            if err.get("hint"):
                console.print(f"  Hint: {err['hint']}")
