"""Comprehensive pipeline validation for pre-deploy checks."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from rowbase.dag import DAG
from rowbase.errors import RowbaseError

if TYPE_CHECKING:
    from rowbase._internal.registry import PipelineContext
    from rowbase.cli.discovery import DiscoveredPipeline
    from rowbase.params import ParamSpec


_SUPPORTED_PARAM_TYPES = frozenset(
    {"string", "integer", "float", "boolean", "date", "datetime", "enum"}
)


@dataclass
class ValidationResult:
    name: str
    valid: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    datasets: list[str] = field(default_factory=list)
    assets: list[str] = field(default_factory=list)
    published: list[str] = field(default_factory=list)
    params: list[ParamSpec] = field(default_factory=list)


def validate_pipeline(discovered: DiscoveredPipeline) -> ValidationResult:
    """Run comprehensive validation checks on a discovered pipeline."""
    errors: list[str] = []
    warnings: list[str] = []

    # 1. Discovery — can we call the pipeline function?
    try:
        spec = discovered.pipeline_fn()
    except RowbaseError as e:
        return ValidationResult(
            name=discovered.name,
            valid=False,
            errors=[f"[{e.code}] {e.message}"],
        )
    except Exception as e:
        return ValidationResult(
            name=discovered.name,
            valid=False,
            errors=[f"Pipeline execution failed: {e}"],
        )

    ctx = spec.context

    # 2. DAG validation (references resolve, no cycles)
    try:
        DAG.from_context(ctx)
    except RowbaseError as e:
        errors.append(f"[{e.code}] {e.message}")

    # 3. Param types are supported
    for p in spec.params:
        if p.param_type not in _SUPPORTED_PARAM_TYPES:
            errors.append(f"Parameter '{p.name}' has unsupported type: {p.param_type}")

    # 4. Published names actually exist in the registry
    for name in ctx.published:
        if name not in ctx.datasets and name not in ctx.assets:
            errors.append(f"Published name '{name}' is not a registered dataset or asset")

    # 5. Dependency chains trace back to a source
    _check_data_chains(ctx, errors)

    return ValidationResult(
        name=spec.name or discovered.name,
        valid=len(errors) == 0,
        errors=errors,
        warnings=warnings,
        sources=sorted(ctx.sources.keys()),
        datasets=sorted(ctx.datasets.keys()),
        assets=sorted(ctx.assets.keys()),
        published=sorted(ctx.published),
        params=spec.params,
    )


def _check_data_chains(ctx: PipelineContext, errors: list[str]) -> None:
    """Verify every dataset with dependencies traces back to a source."""
    source_names = set(ctx.sources.keys())

    def _reaches_source(name: str, visited: set[str]) -> bool:
        if name in source_names:
            return True
        meta = ctx.datasets.get(name) or ctx.assets.get(name)
        if meta is None:
            return False
        if not meta.depends_on:
            return True  # self-created (no dependencies)
        if name in visited:
            return False  # cycle — already caught by DAG validation
        visited.add(name)
        return all(_reaches_source(dep, visited) for dep in meta.depends_on)

    for ds_name, ds_meta in ctx.datasets.items():
        if ds_meta.depends_on and not _reaches_source(ds_name, set()):
            errors.append(f"Dataset '{ds_name}' does not trace back to any source")

    for asset_name, asset_meta in ctx.assets.items():
        if asset_meta.depends_on and not _reaches_source(asset_name, set()):
            errors.append(f"Asset '{asset_name}' does not trace back to any source")
