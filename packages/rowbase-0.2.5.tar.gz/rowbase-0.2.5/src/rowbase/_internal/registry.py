"""Scoped pipeline context registry.

The @pipeline decorator creates a PipelineContext and sets it as the current
context via a ContextVar. source() and @dataset/@asset register into this
context during pipeline discovery.
"""

from __future__ import annotations

import contextvars
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

    from pydantic import BaseModel


@dataclass
class SourceMetadata:
    """Metadata for a registered source."""

    name: str
    columns: list[str] | dict[str, type] | None = None
    description: str = ""
    reader_options: dict[str, Any] | None = None
    optional: bool = False


@dataclass
class DatasetMetadata:
    """Metadata for a registered dataset."""

    name: str
    fn: Callable[..., Any]
    schema: type[BaseModel] | None = None
    on_schema_error: str = "fail"
    description: str = ""
    depends_on: list[str] = field(default_factory=list)
    metadata: bool = True
    primary_key: list[str] | None = None


@dataclass
class AssetMetadata:
    """Metadata for a registered asset (binary file output)."""

    name: str
    fn: Callable[..., Any]
    content_type: str = "application/octet-stream"
    extension: str = ""
    description: str = ""
    depends_on: list[str] = field(default_factory=list)


def resolve_dependency_name(dep: Any) -> str:
    """Extract the dependency name from a SourceHandle, dataset, or asset."""
    from rowbase.source import SourceHandle

    if isinstance(dep, SourceHandle):
        return dep.name
    ds_name = getattr(dep, "_dataset_name", None)
    if ds_name is not None:
        return ds_name
    asset_name = getattr(dep, "_asset_name", None)
    if asset_name is not None:
        return asset_name
    from rowbase.errors import ValidationError

    raise ValidationError(
        code="INVALID_PIPELINE",
        message=f"Invalid data_from value: {dep!r}",
        hint="data_from must contain SourceHandle (from rowbase.source()), "
        "@dataset-decorated functions, or @asset-decorated functions.",
    )


@dataclass
class PipelineContext:
    """Scoped registry for a single pipeline's sources, datasets, and assets."""

    sources: dict[str, SourceMetadata] = field(default_factory=dict)
    datasets: dict[str, DatasetMetadata] = field(default_factory=dict)
    assets: dict[str, AssetMetadata] = field(default_factory=dict)
    published: set[str] = field(default_factory=set)

    def register_source(self, meta: SourceMetadata) -> None:
        self.sources[meta.name] = meta

    def register_dataset(self, meta: DatasetMetadata) -> None:
        self.datasets[meta.name] = meta

    def register_asset(self, meta: AssetMetadata) -> None:
        self.assets[meta.name] = meta

    def mark_published(self, name: str) -> None:
        self.published.add(name)

    @property
    def all_names(self) -> set[str]:
        return set(self.sources) | set(self.datasets) | set(self.assets)


_current_context: contextvars.ContextVar[PipelineContext | None] = contextvars.ContextVar(
    "_current_context", default=None
)


def get_current_context() -> PipelineContext:
    """Get the current pipeline context. Raises if called outside a pipeline function."""
    ctx = _current_context.get()
    if ctx is None:
        raise RuntimeError(
            "source() and @dataset must be called inside a @pipeline-decorated function."
        )
    return ctx


def set_current_context(ctx: PipelineContext | None) -> contextvars.Token[PipelineContext | None]:
    """Set the current pipeline context. Returns a token for resetting."""
    return _current_context.set(ctx)
