"""Tests for @dataset decorator."""

import polars as pl
import pytest

from rowbase._internal.registry import PipelineContext, set_current_context
from rowbase.dataset import dataset
from rowbase.errors import ValidationError
from rowbase.source import source


@pytest.fixture()
def ctx():
    """Provide a PipelineContext with some sources pre-registered."""
    context = PipelineContext()
    token = set_current_context(context)

    yield context
    set_current_context(token.old_value)


class TestDataset:
    def test_basic_dataset(self, ctx):
        orders = source("orders")

        @dataset("cleaned", data_from=orders)
        def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        assert "cleaned" in ctx.datasets
        assert ctx.datasets["cleaned"].name == "cleaned"
        assert ctx.datasets["cleaned"].depends_on == ["orders"]

    def test_multiple_dependencies(self, ctx):
        orders = source("orders")
        customers = source("customers")

        @dataset("merged", data_from=[orders, customers])
        def merged(orders: pl.DataFrame, customers: pl.DataFrame) -> pl.DataFrame:
            return orders

        assert ctx.datasets["merged"].depends_on == ["orders", "customers"]

    def test_dataset_chain(self, ctx):
        orders = source("orders")

        @dataset("cleaned", data_from=orders)
        def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        @dataset("filtered", data_from=cleaned)
        def filtered(cleaned: pl.DataFrame) -> pl.DataFrame:
            return cleaned

        assert ctx.datasets["cleaned"].depends_on == ["orders"]
        assert ctx.datasets["filtered"].depends_on == ["cleaned"]

    def test_self_created_dataset(self, ctx):
        @dataset("generated")
        def generated() -> pl.DataFrame:
            return pl.DataFrame({"id": [1, 2, 3]})

        assert ctx.datasets["generated"].depends_on == []

    def test_schema_stored(self, ctx):
        from pydantic import BaseModel

        class Product(BaseModel):
            sku: str
            price: float

        orders = source("orders")

        @dataset("products", data_from=orders, schema=Product)
        def products(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        assert ctx.datasets["products"].schema is Product

    def test_on_schema_error_stored(self, ctx):
        orders = source("orders")

        @dataset("products", data_from=orders, on_schema_error="skip")
        def products(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        assert ctx.datasets["products"].on_schema_error == "skip"

    def test_description_stored(self, ctx):
        orders = source("orders")

        @dataset("cleaned", data_from=orders, description="Clean the data")
        def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        assert ctx.datasets["cleaned"].description == "Clean the data"

    def test_wrapped_function_callable(self, ctx):
        orders = source("orders")

        @dataset("cleaned", data_from=orders)
        def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
            return orders.with_columns(pl.lit(1).alias("flag"))

        df = pl.DataFrame({"email": ["a@b.com"]})
        result = cleaned(df)
        assert "flag" in result.columns

    def test_wrapped_preserves_original(self, ctx):
        orders = source("orders")

        @dataset("cleaned", data_from=orders)
        def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        assert cleaned.__wrapped__.__name__ == "cleaned"

    def test_dataset_name_attribute(self, ctx):
        orders = source("orders")

        @dataset("cleaned", data_from=orders)
        def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        assert cleaned._dataset_name == "cleaned"

    def test_invalid_name(self, ctx):
        with pytest.raises(ValidationError, match="not a valid Python identifier"):

            @dataset("my dataset")
            def bad() -> pl.DataFrame:
                return pl.DataFrame()

    def test_duplicate_name_with_source(self, ctx):
        source("orders")
        with pytest.raises(ValidationError, match="already registered"):

            @dataset("orders")
            def bad() -> pl.DataFrame:
                return pl.DataFrame()

    def test_duplicate_dataset_name(self, ctx):
        orders = source("orders")

        @dataset("cleaned", data_from=orders)
        def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        with pytest.raises(ValidationError, match="already registered"):

            @dataset("cleaned", data_from=orders)
            def cleaned2(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

    def test_invalid_on_schema_error(self, ctx):
        with pytest.raises(ValidationError, match="Invalid on_schema_error"):

            @dataset("x", on_schema_error="explode")
            def bad() -> pl.DataFrame:
                return pl.DataFrame()

    def test_invalid_data_from_value(self, ctx):
        with pytest.raises(ValidationError, match="Invalid data_from"):

            @dataset("x", data_from="not_a_handle")
            def bad() -> pl.DataFrame:
                return pl.DataFrame()

    def test_outside_pipeline_raises(self):
        set_current_context(None)
        with pytest.raises(RuntimeError, match="inside a @pipeline"):

            @dataset("x")
            def bad() -> pl.DataFrame:
                return pl.DataFrame()

    def test_primary_key_string_normalized_to_list(self, ctx):
        @dataset("out", primary_key="id")
        def out() -> pl.DataFrame:
            return pl.DataFrame()

        assert ctx.datasets["out"].primary_key == ["id"]

    def test_primary_key_list_stored_as_is(self, ctx):
        @dataset("out", primary_key=["org_id", "user_id"])
        def out() -> pl.DataFrame:
            return pl.DataFrame()

        assert ctx.datasets["out"].primary_key == ["org_id", "user_id"]

    def test_primary_key_none_by_default(self, ctx):
        @dataset("out")
        def out() -> pl.DataFrame:
            return pl.DataFrame()

        assert ctx.datasets["out"].primary_key is None
