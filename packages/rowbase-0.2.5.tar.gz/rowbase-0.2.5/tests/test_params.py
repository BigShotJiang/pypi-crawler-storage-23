"""Tests for workflow parameter extraction, type resolution, and coercion."""

from __future__ import annotations

from datetime import date, datetime
from typing import Annotated, Literal, Optional

import pytest

from rowbase.errors import ValidationError
from rowbase.params import (
    MISSING,
    Param,
    ParamSpec,
    _coerce_param,
    _extract_params,
    _resolve_type,
    resolve_params,
)


class TestResolveType:
    def test_str(self):
        pt, enum_vals, desc, is_opt = _resolve_type(str)
        assert pt == "string"
        assert enum_vals is None
        assert desc == ""
        assert is_opt is False

    def test_int(self):
        pt, *_ = _resolve_type(int)
        assert pt == "integer"

    def test_float(self):
        pt, *_ = _resolve_type(float)
        assert pt == "float"

    def test_bool(self):
        pt, *_ = _resolve_type(bool)
        assert pt == "boolean"

    def test_date(self):
        pt, *_ = _resolve_type(date)
        assert pt == "date"

    def test_datetime(self):
        pt, *_ = _resolve_type(datetime)
        assert pt == "datetime"

    def test_literal(self):
        pt, enum_vals, desc, is_opt = _resolve_type(Literal["a", "b", "c"])
        assert pt == "enum"
        assert enum_vals == ["a", "b", "c"]
        assert is_opt is False

    def test_optional_str(self):
        pt, enum_vals, desc, is_opt = _resolve_type(Optional[str])
        assert pt == "string"
        assert is_opt is True

    def test_optional_int(self):
        pt, _, _, is_opt = _resolve_type(Optional[int])
        assert pt == "integer"
        assert is_opt is True

    def test_annotated_str_with_desc(self):
        pt, enum_vals, desc, is_opt = _resolve_type(Annotated[str, "A description"])
        assert pt == "string"
        assert desc == "A description"
        assert is_opt is False

    def test_annotated_optional(self):
        pt, _, desc, is_opt = _resolve_type(Optional[Annotated[str, "Region"]])
        assert pt == "string"
        assert desc == "Region"
        assert is_opt is True

    def test_annotated_wrapping_optional(self):
        pt, _, desc, is_opt = _resolve_type(Annotated[Optional[str], "Region"])
        assert pt == "string"
        assert desc == "Region"
        assert is_opt is True

    def test_annotated_literal(self):
        pt, enum_vals, desc, _ = _resolve_type(Annotated[Literal["x", "y"], "Choose"])
        assert pt == "enum"
        assert enum_vals == ["x", "y"]
        assert desc == "Choose"

    def test_unsupported_type_raises(self):
        with pytest.raises(ValidationError, match="Unsupported parameter type"):
            _resolve_type(list)

    def test_unsupported_complex_type_raises(self):
        with pytest.raises(ValidationError, match="Unsupported parameter type"):
            _resolve_type(dict[str, int])


class TestExtractParams:
    def test_no_params(self):
        def fn():
            pass

        assert _extract_params(fn) == []

    def test_unannotated_params_skipped(self):
        def fn(x, y):
            pass

        assert _extract_params(fn) == []

    def test_basic_types(self):
        def fn(name: str, count: int, rate: float, flag: bool):
            pass

        specs = _extract_params(fn)
        assert len(specs) == 4
        assert specs[0] == ParamSpec("name", "string", MISSING, required=True)
        assert specs[1] == ParamSpec("count", "integer", MISSING, required=True)
        assert specs[2] == ParamSpec("rate", "float", MISSING, required=True)
        assert specs[3] == ParamSpec("flag", "boolean", MISSING, required=True)

    def test_with_defaults(self):
        def fn(region: str = "US", count: int = 10):
            pass

        specs = _extract_params(fn)
        assert specs[0].default == "US"
        assert specs[0].required is False
        assert specs[1].default == 10
        assert specs[1].required is False

    def test_optional_no_default(self):
        def fn(region: Optional[str]):
            pass

        specs = _extract_params(fn)
        assert specs[0].required is False
        assert specs[0].default is MISSING

    def test_optional_with_default(self):
        def fn(region: Optional[str] = "US"):
            pass

        specs = _extract_params(fn)
        assert specs[0].required is False
        assert specs[0].default == "US"

    def test_literal_enum(self):
        def fn(mode: Literal["fast", "slow"] = "fast"):
            pass

        specs = _extract_params(fn)
        assert specs[0].param_type == "enum"
        assert specs[0].enum_values == ["fast", "slow"]
        assert specs[0].default == "fast"

    def test_param_wrapper_with_description(self):
        def fn(region: str = Param(default="US", description="Filter by region")):
            pass

        specs = _extract_params(fn)
        assert specs[0].default == "US"
        assert specs[0].description == "Filter by region"
        assert specs[0].required is False

    def test_param_wrapper_no_default(self):
        def fn(region: str = Param(description="Required region")):
            pass

        specs = _extract_params(fn)
        assert specs[0].required is True
        assert specs[0].description == "Required region"

    def test_annotated_description(self):
        def fn(region: Annotated[str, "Filter by region"] = "US"):
            pass

        specs = _extract_params(fn)
        assert specs[0].description == "Filter by region"
        assert specs[0].default == "US"

    def test_param_description_overrides_annotated(self):
        def fn(
            region: Annotated[str, "From Annotated"] = Param(
                default="US", description="From Param"
            ),
        ):
            pass

        specs = _extract_params(fn)
        assert specs[0].description == "From Param"

    def test_mixed_annotated_and_plain(self):
        def fn(x: int, y: Annotated[str, "Y desc"] = "hello"):
            pass

        specs = _extract_params(fn)
        assert len(specs) == 2
        assert specs[0].description == ""
        assert specs[1].description == "Y desc"

    def test_date_and_datetime(self):
        def fn(start: date, end: datetime):
            pass

        specs = _extract_params(fn)
        assert specs[0].param_type == "date"
        assert specs[1].param_type == "datetime"


class TestCoerceParam:
    def _spec(self, param_type: str, enum_values: list[str] | None = None) -> ParamSpec:
        return ParamSpec("test", param_type, MISSING, required=True, enum_values=enum_values)

    def test_string(self):
        assert _coerce_param("x", "hello", self._spec("string")) == "hello"
        assert _coerce_param("x", 42, self._spec("string")) == "42"

    def test_integer(self):
        assert _coerce_param("x", "42", self._spec("integer")) == 42
        assert _coerce_param("x", 42, self._spec("integer")) == 42

    def test_integer_invalid(self):
        with pytest.raises(ValidationError, match="Cannot coerce"):
            _coerce_param("x", "not_a_number", self._spec("integer"))

    def test_float(self):
        assert _coerce_param("x", "3.14", self._spec("float")) == 3.14
        assert _coerce_param("x", 3, self._spec("float")) == 3.0

    def test_boolean_true(self):
        assert _coerce_param("x", True, self._spec("boolean")) is True
        assert _coerce_param("x", "true", self._spec("boolean")) is True
        assert _coerce_param("x", "yes", self._spec("boolean")) is True
        assert _coerce_param("x", "on", self._spec("boolean")) is True
        assert _coerce_param("x", "1", self._spec("boolean")) is True
        assert _coerce_param("x", 1, self._spec("boolean")) is True

    def test_boolean_false(self):
        assert _coerce_param("x", False, self._spec("boolean")) is False
        assert _coerce_param("x", "false", self._spec("boolean")) is False
        assert _coerce_param("x", "0", self._spec("boolean")) is False
        assert _coerce_param("x", "no", self._spec("boolean")) is False
        assert _coerce_param("x", "off", self._spec("boolean")) is False
        assert _coerce_param("x", "", self._spec("boolean")) is False
        assert _coerce_param("x", 0, self._spec("boolean")) is False

    def test_date_from_string(self):
        result = _coerce_param("x", "2024-03-15", self._spec("date"))
        assert result == date(2024, 3, 15)

    def test_date_passthrough(self):
        d = date(2024, 3, 15)
        assert _coerce_param("x", d, self._spec("date")) is d

    def test_date_invalid(self):
        with pytest.raises(ValidationError, match="Cannot coerce"):
            _coerce_param("x", "not-a-date", self._spec("date"))

    def test_datetime_from_string(self):
        result = _coerce_param("x", "2024-03-15T12:00:00", self._spec("datetime"))
        assert result == datetime(2024, 3, 15, 12, 0, 0)

    def test_datetime_passthrough(self):
        dt = datetime(2024, 3, 15, 12, 0, 0)
        assert _coerce_param("x", dt, self._spec("datetime")) is dt

    def test_enum_valid(self):
        assert _coerce_param("x", "a", self._spec("enum", ["a", "b"])) == "a"

    def test_enum_invalid(self):
        with pytest.raises(ValidationError, match="not one of"):
            _coerce_param("x", "c", self._spec("enum", ["a", "b"]))

    def test_none_passthrough(self):
        assert _coerce_param("x", None, self._spec("string")) is None


class TestResolveParams:
    def test_defaults_used(self):
        specs = [
            ParamSpec("region", "string", "US", required=False),
            ParamSpec("count", "integer", 10, required=False),
        ]
        result = resolve_params(specs, None)
        assert result == {"region": "US", "count": 10}

    def test_overrides_applied(self):
        specs = [
            ParamSpec("region", "string", "US", required=False),
            ParamSpec("count", "integer", 10, required=False),
        ]
        result = resolve_params(specs, {"region": "EU"})
        assert result == {"region": "EU", "count": 10}

    def test_coercion_applied(self):
        specs = [ParamSpec("count", "integer", 10, required=False)]
        result = resolve_params(specs, {"count": "42"})
        assert result == {"count": 42}

    def test_missing_required_raises(self):
        specs = [ParamSpec("region", "string", MISSING, required=True)]
        with pytest.raises(ValidationError, match="Required parameter"):
            resolve_params(specs, {})

    def test_missing_required_with_none_user_params(self):
        specs = [ParamSpec("region", "string", MISSING, required=True)]
        with pytest.raises(ValidationError, match="Required parameter"):
            resolve_params(specs, None)

    def test_unknown_param_raises(self):
        specs = [ParamSpec("region", "string", "US", required=False)]
        with pytest.raises(ValidationError, match="Unknown parameters"):
            resolve_params(specs, {"nonexistent": "value"})

    def test_optional_no_default_gets_none(self):
        specs = [ParamSpec("region", "string", MISSING, required=False)]
        result = resolve_params(specs, {})
        assert result == {"region": None}

    def test_empty_specs_empty_result(self):
        result = resolve_params([], {})
        assert result == {}

    def test_all_required_provided(self):
        specs = [
            ParamSpec("a", "string", MISSING, required=True),
            ParamSpec("b", "integer", MISSING, required=True),
        ]
        result = resolve_params(specs, {"a": "hello", "b": "5"})
        assert result == {"a": "hello", "b": 5}
