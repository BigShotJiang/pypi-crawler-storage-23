"""Tests for @pipeline decorator and discovery."""

from typing import Annotated, Literal, Optional

import polars as pl
import pytest

import rowbase
from rowbase.errors import ValidationError
from rowbase.params import Param
from rowbase.pipeline import PipelineSpec


class TestPipelineDiscovery:
    def test_simple_pipeline(self):
        @rowbase.pipeline
        def my_pipeline():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield cleaned

        spec = my_pipeline()
        assert isinstance(spec, PipelineSpec)
        assert "orders" in spec.context.sources
        assert "cleaned" in spec.context.datasets
        assert "cleaned" in spec.context.published

    def test_pipeline_with_parens(self):
        @rowbase.pipeline()
        def my_pipeline():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield cleaned

        spec = my_pipeline()
        assert "cleaned" in spec.context.published

    def test_pipeline_with_name(self):
        @rowbase.pipeline(name="my_cool_pipeline")
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        assert spec.name == "my_cool_pipeline"

    def test_multiple_sources_and_datasets(self):
        @rowbase.pipeline
        def cdl():
            hinkley_data = rowbase.source("hinkley_data")
            hinkley_prices = rowbase.source("hinkley_prices")
            rosendahl_data = rowbase.source("rosendahl_data")

            @rowbase.dataset("hinkley", data_from=[hinkley_data, hinkley_prices])
            def hinkley(hinkley_data: pl.DataFrame, hinkley_prices: pl.DataFrame) -> pl.DataFrame:
                return hinkley_data

            @rowbase.dataset("rosendahl", data_from=rosendahl_data)
            def rosendahl(rosendahl_data: pl.DataFrame) -> pl.DataFrame:
                return rosendahl_data

            @rowbase.dataset("products", data_from=[hinkley, rosendahl])
            def products(hinkley: pl.DataFrame, rosendahl: pl.DataFrame) -> pl.DataFrame:
                return hinkley

            yield hinkley
            yield rosendahl
            yield products

        spec = cdl()
        assert len(spec.context.sources) == 3
        assert len(spec.context.datasets) == 3
        assert spec.context.published == {"hinkley", "rosendahl", "products"}

    def test_intermediate_datasets_not_published(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            @rowbase.dataset("domestic", data_from=cleaned)
            def domestic(cleaned: pl.DataFrame) -> pl.DataFrame:
                return cleaned

            yield domestic

        spec = pipe()
        assert "cleaned" in spec.context.datasets
        assert "cleaned" not in spec.context.published
        assert "domestic" in spec.context.published

    def test_dataset_bodies_not_called(self):
        """Dataset function bodies should NOT execute during discovery."""
        call_tracker = []

        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                call_tracker.append("cleaned was called")
                return orders

            yield cleaned

        pipe()
        assert call_tracker == []

    def test_yielding_non_dataset_raises(self):
        @rowbase.pipeline
        def pipe():
            rowbase.source("orders")
            yield "not a dataset"

        with pytest.raises(ValidationError, match="not a dataset"):
            pipe()

    def test_pipeline_isolation(self):
        """Two pipeline discoveries should have independent contexts."""

        @rowbase.pipeline
        def pipe_a():
            source_a = rowbase.source("source_a")

            @rowbase.dataset("ds_a", data_from=source_a)
            def ds_a(source_a: pl.DataFrame) -> pl.DataFrame:
                return source_a

            yield ds_a

        @rowbase.pipeline
        def pipe_b():
            source_b = rowbase.source("source_b")

            @rowbase.dataset("ds_b", data_from=source_b)
            def ds_b(source_b: pl.DataFrame) -> pl.DataFrame:
                return source_b

            yield ds_b

        spec_a = pipe_a()
        spec_b = pipe_b()

        assert "source_a" in spec_a.context.sources
        assert "source_a" not in spec_b.context.sources
        assert "source_b" in spec_b.context.sources
        assert "source_b" not in spec_a.context.sources

    def test_pipeline_preserves_wrapped(self):
        @rowbase.pipeline
        def my_pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        assert my_pipe.__wrapped__.__name__ == "my_pipe"

    def test_is_pipeline_flag(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        assert pipe._is_pipeline is True

    def test_self_created_dataset(self):
        @rowbase.pipeline
        def pipe():
            @rowbase.dataset("generated")
            def generated() -> pl.DataFrame:
                return pl.DataFrame({"id": [1, 2, 3]})

            yield generated

        spec = pipe()
        assert spec.context.datasets["generated"].depends_on == []
        assert "generated" in spec.context.published

    def test_yield_asset(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("report", data_from=orders, content_type="text/plain")
            def report(orders: pl.DataFrame) -> bytes:
                return b"hello"

            yield report

        spec = pipe()
        assert "report" in spec.context.assets
        assert "report" in spec.context.published

    def test_yield_mix_of_datasets_and_assets(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            @rowbase.asset("report", data_from=cleaned)
            def report(cleaned: pl.DataFrame) -> bytes:
                return b""

            yield cleaned
            yield report

        spec = pipe()
        assert spec.context.published == {"cleaned", "report"}

    def test_asset_not_published_if_not_yielded(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("internal", data_from=orders)
            def internal(orders: pl.DataFrame) -> bytes:
                return b""

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        assert "internal" in spec.context.assets
        assert "internal" not in spec.context.published
        assert "out" in spec.context.published

    def test_yielding_non_dataset_or_asset_raises(self):
        @rowbase.pipeline
        def pipe():
            rowbase.source("orders")
            yield "not a dataset or asset"

        with pytest.raises(ValidationError, match="not a dataset or asset"):
            pipe()


class TestPipelineParams:
    def test_no_params_backward_compat(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        assert spec.params == []

    def test_discovers_typed_params(self):
        @rowbase.pipeline
        def pipe(region: str = "US", count: int = 10):
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        assert len(spec.params) == 2
        assert spec.params[0].name == "region"
        assert spec.params[0].param_type == "string"
        assert spec.params[0].default == "US"
        assert spec.params[1].name == "count"
        assert spec.params[1].param_type == "integer"
        assert spec.params[1].default == 10

    def test_defaults_captured_in_closures(self):
        @rowbase.pipeline
        def pipe(country: str = "US"):
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("country") == country)

            yield out

        spec = pipe()
        # The discovery ran gen_fn(country="US"), so closures captured "US"
        assert spec.params[0].default == "US"
        assert "orders" in spec.context.sources
        assert "out" in spec.context.datasets

    def test_param_with_description(self):
        @rowbase.pipeline
        def pipe(region: str = Param(default="US", description="Filter by region")):
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        assert spec.params[0].description == "Filter by region"
        assert spec.params[0].default == "US"

    def test_annotated_description(self):
        @rowbase.pipeline
        def pipe(region: Annotated[str, "Filter by region"] = "US"):
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        assert spec.params[0].description == "Filter by region"

    def test_literal_param(self):
        @rowbase.pipeline
        def pipe(mode: Literal["fast", "slow"] = "fast"):
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        assert spec.params[0].param_type == "enum"
        assert spec.params[0].enum_values == ["fast", "slow"]

    def test_optional_param(self):
        @rowbase.pipeline
        def pipe(region: Optional[str] = None):
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        assert spec.params[0].required is False
        assert spec.params[0].default is None

    def test_unsupported_param_type_raises(self):
        @rowbase.pipeline
        def pipe(data: list = []):  # noqa: B006
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        with pytest.raises(ValidationError, match="Unsupported parameter type"):
            pipe()
