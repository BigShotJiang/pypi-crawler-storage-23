"""Tests for the pipeline execution engine."""

from datetime import date, datetime, timezone
from pathlib import Path
from typing import Annotated, Literal

import polars as pl
import pytest

import rowbase
from rowbase.errors import ValidationError
from rowbase.execution import PipelineRunner
from rowbase.params import Param


@pytest.fixture()
def csv_files(tmp_path):
    """Create sample CSV files for testing."""
    orders_path = tmp_path / "orders.csv"
    pl.DataFrame(
        {
            "email": ["a@b.com", "c@d.com", "e@f.com"],
            "total": [10.0, 20.0, 30.0],
            "country": ["US", "MX", "US"],
        }
    ).write_csv(orders_path)

    prices_path = tmp_path / "prices.csv"
    pl.DataFrame(
        {
            "item": ["A", "B"],
            "price": [5.0, 15.0],
        }
    ).write_csv(prices_path)

    return {"orders": orders_path, "prices": prices_path}


class TestPipelineRunner:
    def test_simple_pipeline(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("country") == "US")

            yield cleaned

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert result.complete is True
        assert result.datasets["cleaned"].row_count == 2
        assert result.datasets["cleaned"].columns == [
            "email", "total", "country",
            "_rb_run_id", "_rb_loaded_at", "_rb_dataset_name",
        ]

    def test_dataset_chain(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("country") == "US")

            @rowbase.dataset("totals", data_from=cleaned)
            def totals(cleaned: pl.DataFrame) -> pl.DataFrame:
                return cleaned.select(pl.col("total").sum().alias("grand_total"))

            yield totals

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert result.datasets["totals"].row_count == 1

    def test_fan_out(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("domestic", data_from=orders)
            def domestic(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("country") == "US")

            @rowbase.dataset("international", data_from=orders)
            def international(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("country") != "US")

            yield domestic
            yield international

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert result.datasets["domestic"].row_count == 2
        assert result.datasets["international"].row_count == 1

    def test_multi_source(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")
            prices = rowbase.source("prices")

            @rowbase.dataset("joined", data_from=[orders, prices])
            def joined(orders: pl.DataFrame, prices: pl.DataFrame) -> pl.DataFrame:
                # Simple: take first col from each and concat row counts
                return pl.DataFrame(
                    {
                        "order_count": [orders.shape[0]],
                        "price_count": [prices.shape[0]],
                    }
                )

            yield joined

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, csv_files)

        assert result.status == "success"
        assert result.datasets["joined"].row_count == 1
        assert result.datasets["joined"].columns == [
            "order_count", "price_count",
            "_rb_run_id", "_rb_loaded_at", "_rb_dataset_name",
        ]

    def test_sample_rows(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]}, sample_rows=1)

        assert result.datasets["out"].row_count == 1

    def test_missing_source_input(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {})

        assert result.status == "failed"
        assert any(e.code == "FILE_NOT_FOUND" for e in result.errors)

    def test_dataset_exception_caught(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("bad", data_from=orders)
            def bad(orders: pl.DataFrame) -> pl.DataFrame:
                raise ValueError("something went wrong")

            yield bad

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "failed"
        assert any(e.code == "DATASET_ERROR" for e in result.errors)

    def test_schema_validation_fail(self, csv_files):
        from pydantic import BaseModel

        class Order(BaseModel):
            email: str
            total: float
            country: str
            required_field: str  # This doesn't exist in the data

        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders, schema=Order, on_schema_error="fail")
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "failed"

    def test_schema_validation_skip(self, csv_files):
        from pydantic import BaseModel

        class StrictOrder(BaseModel):
            email: str
            total: float
            country: str

        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders, schema=StrictOrder, on_schema_error="skip")
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert result.datasets["out"].row_count == 3

    def test_step_metrics_recorded(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert len(result.step_metrics) == 1
        assert result.step_metrics[0].dataset == "out"
        assert result.step_metrics[0].output_rows == 3
        assert result.step_metrics[0].input_rows == {"orders": 3}

    def test_write_outputs(self, csv_files, tmp_path):
        output_dir = tmp_path / "output"

        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield cleaned

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]}, output_dir=output_dir)

        assert result.status == "success"
        run_dir = output_dir / result.run_id
        assert (run_dir / "cleaned.parquet").exists()
        assert (run_dir / "run_metadata.json").exists()

    def test_self_created_dataset(self):
        @rowbase.pipeline
        def pipe():
            @rowbase.dataset("generated")
            def generated() -> pl.DataFrame:
                return pl.DataFrame({"id": [1, 2, 3]})

            yield generated

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {})

        assert result.status == "success"
        assert result.datasets["generated"].row_count == 3

    def test_captures_print_output(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                print("hello from dataset")
                print("row count:", orders.shape[0])
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert "hello from dataset" in result.datasets["out"].stdout
        assert "row count: 3" in result.datasets["out"].stdout

    def test_captures_logging_output(self, csv_files):
        import logging

        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                logger = logging.getLogger("test_pipeline")
                logger.warning("something looks off")
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert len(result.logs) >= 1
        assert any("something looks off" in log.message for log in result.logs)
        assert result.logs[0].dataset == "out"
        assert result.logs[0].level == "WARNING"

    def test_captured_output_does_not_leak_to_stdout(self, csv_files, capsys):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                print("this should be captured")
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        runner.run(spec, {"orders": csv_files["orders"]})

        captured = capsys.readouterr()
        assert "this should be captured" not in captured.out

    def test_metadata_columns_injected(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        before = datetime.now(timezone.utc)
        result = runner.run(spec, {"orders": csv_files["orders"]}, run_id="test_run_123")

        df = result.dataframes["out"]
        assert "_rb_run_id" in df.columns
        assert "_rb_loaded_at" in df.columns
        assert "_rb_dataset_name" in df.columns

        assert df["_rb_run_id"][0] == "test_run_123"
        assert df["_rb_dataset_name"][0] == "out"

        loaded_at = df["_rb_loaded_at"][0]
        assert loaded_at >= before
        assert loaded_at <= datetime.now(timezone.utc)

    def test_metadata_opt_out(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders, metadata=False)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        df = result.dataframes["out"]
        assert "_rb_run_id" not in df.columns
        assert "_rb_loaded_at" not in df.columns
        assert "_rb_dataset_name" not in df.columns

    def test_metadata_per_dataset_in_chain(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("step1", data_from=orders)
            def step1(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("country") == "US")

            @rowbase.dataset("step2", data_from=step1)
            def step2(step1: pl.DataFrame) -> pl.DataFrame:
                return step1.select(pl.col("total").sum().alias("grand_total"))

            yield step2

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]}, run_id="chain_run")

        df = result.dataframes["step2"]
        assert df["_rb_run_id"][0] == "chain_run"
        assert df["_rb_dataset_name"][0] == "step2"

    def test_optional_source_missing_input(self, tmp_path):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")
            existing = rowbase.source("existing", optional=True)

            @rowbase.dataset("out", data_from=[orders, existing])
            def out(orders: pl.DataFrame, existing: pl.DataFrame) -> pl.DataFrame:
                return pl.DataFrame({"count": [orders.shape[0]], "existing_count": [existing.shape[0]]})

            yield out

        spec = pipe()
        runner = PipelineRunner()

        orders_path = tmp_path / "orders.csv"
        orders_path.write_text("email,total\na@b.com,10\n")

        result = runner.run(spec, {"orders": orders_path})
        assert result.status == "success"
        assert result.dataframes["out"]["count"][0] == 1
        assert result.dataframes["out"]["existing_count"][0] == 0

    def test_optional_source_file_not_found(self):
        @rowbase.pipeline
        def pipe():
            existing = rowbase.source("existing", optional=True)

            @rowbase.dataset("out", data_from=existing)
            def out(existing: pl.DataFrame) -> pl.DataFrame:
                return pl.DataFrame({"empty": [existing.shape[0] == 0]})

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"existing": Path("/nonexistent/file.csv")})
        assert result.status == "success"
        assert result.dataframes["out"]["empty"][0] is True

    def test_output_format_csv(self, csv_files, tmp_path):
        output_dir = tmp_path / "output"

        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield cleaned

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(
            spec, {"orders": csv_files["orders"]},
            output_dir=output_dir, output_format="csv",
        )

        assert result.status == "success"
        run_dir = output_dir / result.run_id
        assert (run_dir / "cleaned.csv").exists()
        assert not (run_dir / "cleaned.parquet").exists()

    def test_output_format_json(self, csv_files, tmp_path):
        output_dir = tmp_path / "output"

        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(
            spec, {"orders": csv_files["orders"]},
            output_dir=output_dir, output_format="json",
        )

        assert result.status == "success"
        assert (output_dir / result.run_id / "out.json").exists()


class TestAssetExecution:
    def test_single_file_asset(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("report", data_from=orders, content_type="text/plain", extension=".txt")
            def report(orders: pl.DataFrame) -> bytes:
                return f"Rows: {len(orders)}".encode()

            yield report

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert "report" in result.assets
        assert result.assets["report"].file_count == 1
        assert result.assets["report"].content_type == "text/plain"
        assert result.assets["report"].extension == ".txt"
        assert result.asset_data["report"]["report.txt"] == b"Rows: 3"

    def test_multi_file_asset(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("swatches", data_from=orders, content_type="text/plain", extension=".txt")
            def swatches(orders: pl.DataFrame) -> dict[str, bytes]:
                return {"a.txt": b"color_a", "b.txt": b"color_b"}

            yield swatches

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert result.assets["swatches"].file_count == 2
        assert set(result.asset_data["swatches"].keys()) == {"a.txt", "b.txt"}
        assert result.asset_data["swatches"]["a.txt"] == b"color_a"

    def test_asset_depends_on_dataset(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("country") == "US")

            @rowbase.asset("report", data_from=cleaned, content_type="text/plain", extension=".txt")
            def report(cleaned: pl.DataFrame) -> bytes:
                return f"US orders: {len(cleaned)}".encode()

            yield cleaned
            yield report

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert result.datasets["cleaned"].row_count == 2
        assert result.asset_data["report"]["report.txt"] == b"US orders: 2"

    def test_asset_depends_on_asset(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("raw", data_from=orders, extension=".bin")
            def raw(orders: pl.DataFrame) -> bytes:
                return b"raw_data"

            @rowbase.asset("processed", data_from=raw, extension=".bin")
            def processed(raw: bytes) -> bytes:
                return raw + b"_processed"

            yield processed

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert result.asset_data["processed"]["processed.bin"] == b"raw_data_processed"

    def test_asset_bad_return_type(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("bad", data_from=orders)
            def bad(orders: pl.DataFrame) -> bytes:
                return 42  # type: ignore

            yield bad

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "failed"
        assert any(e.code == "ASSET_ERROR" for e in result.errors)

    def test_asset_exception_caught(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("bad", data_from=orders)
            def bad(orders: pl.DataFrame) -> bytes:
                raise ValueError("oops")

            yield bad

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "failed"

    def test_asset_step_metrics(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("report", data_from=orders, extension=".txt")
            def report(orders: pl.DataFrame) -> bytes:
                return b"hello"

            yield report

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        asset_metrics = [m for m in result.step_metrics if m.dataset == "report"]
        assert len(asset_metrics) == 1
        assert asset_metrics[0].output_rows == 1  # 1 file

    def test_asset_captures_stdout(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("report", data_from=orders, extension=".txt")
            def report(orders: pl.DataFrame) -> bytes:
                print("generating report")
                return b"hello"

            yield report

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert "generating report" in result.assets["report"].stdout

    def test_primary_key_stored_on_dataset_result(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders, primary_key="email")
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert result.datasets["out"].primary_key == ["email"]

    def test_primary_key_none_when_not_declared(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.datasets["out"].primary_key is None

    def test_primary_key_single_injects_rb_row_id(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders, primary_key="email")
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]}, run_id="test_run")

        df = result.dataframes["out"]
        assert "_rb_row_id" in df.columns
        assert df["_rb_row_id"].to_list() == ["a@b.com", "c@d.com", "e@f.com"]

    def test_primary_key_composite_injects_rb_row_id(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders, primary_key=["email", "country"])
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        df = result.dataframes["out"]
        assert "_rb_row_id" in df.columns
        assert df["_rb_row_id"].to_list() == ["a@b.com||US", "c@d.com||MX", "e@f.com||US"]

    def test_primary_key_no_rb_row_id_when_not_declared(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        df = result.dataframes["out"]
        assert "_rb_row_id" not in df.columns

    def test_primary_key_missing_column_raises(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders, primary_key="nonexistent_col")
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "failed"
        assert any(
            e.code == "DATASET_ERROR" and "primary_key" in e.message
            for e in result.errors
        )

    def test_primary_key_missing_one_of_composite_raises(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders, primary_key=["email", "missing_col"])
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "failed"
        assert any("missing_col" in e.message for e in result.errors)

    def test_write_outputs_includes_assets(self, csv_files, tmp_path):
        output_dir = tmp_path / "output"

        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            @rowbase.asset("report", data_from=cleaned, extension=".txt")
            def report(cleaned: pl.DataFrame) -> bytes:
                return b"hello"

            yield cleaned
            yield report

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]}, output_dir=output_dir)

        assert result.status == "success"
        run_dir = output_dir / result.run_id
        assert (run_dir / "cleaned.parquet").exists()
        assert (run_dir / "assets" / "report" / "report.txt").exists()
        assert (run_dir / "assets" / "report" / "report.txt").read_bytes() == b"hello"


class TestPipelineRunnerParams:
    def test_params_override_closures(self, csv_files):
        @rowbase.pipeline
        def pipe(country: str = "US"):
            orders = rowbase.source("orders")

            @rowbase.dataset("filtered", data_from=orders)
            def filtered(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("country") == country)

            yield filtered

        spec = pipe()
        runner = PipelineRunner()

        # Default: country="US" -> 2 rows
        result_default = runner.run(spec, {"orders": csv_files["orders"]})
        assert result_default.datasets["filtered"].row_count == 2
        assert result_default.params == {"country": "US"}

        # Override: country="MX" -> 1 row
        result_mx = runner.run(spec, {"orders": csv_files["orders"]}, params={"country": "MX"})
        assert result_mx.datasets["filtered"].row_count == 1
        assert result_mx.params == {"country": "MX"}

    def test_params_without_override_uses_defaults(self, csv_files):
        @rowbase.pipeline
        def pipe(country: str = "US"):
            orders = rowbase.source("orders")

            @rowbase.dataset("filtered", data_from=orders)
            def filtered(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("country") == country)

            yield filtered

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.datasets["filtered"].row_count == 2
        assert result.params == {"country": "US"}

    def test_missing_required_param_raises(self, csv_files):
        @rowbase.pipeline
        def pipe(country: str):
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "failed"
        assert any(e.code == "MISSING_REQUIRED_PARAM" for e in result.errors)

    def test_required_param_provided(self, csv_files):
        @rowbase.pipeline
        def pipe(country: str):
            orders = rowbase.source("orders")

            @rowbase.dataset("filtered", data_from=orders)
            def filtered(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("country") == country)

            yield filtered

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]}, params={"country": "MX"})

        assert result.status == "success"
        assert result.datasets["filtered"].row_count == 1
        assert result.params == {"country": "MX"}

    def test_unknown_param_raises(self, csv_files):
        @rowbase.pipeline
        def pipe(country: str = "US"):
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]}, params={"nonexistent": "val"})

        assert result.status == "failed"
        assert any(e.code == "UNKNOWN_PARAMS" for e in result.errors)

    def test_param_coercion_end_to_end(self, csv_files):
        @rowbase.pipeline
        def pipe(min_total: float = 0.0):
            orders = rowbase.source("orders")

            @rowbase.dataset("filtered", data_from=orders)
            def filtered(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(pl.col("total") > min_total)

            yield filtered

        spec = pipe()
        runner = PipelineRunner()

        # Pass string "15" -- should coerce to float 15.0
        result = runner.run(spec, {"orders": csv_files["orders"]}, params={"min_total": "15"})
        assert result.status == "success"
        assert result.datasets["filtered"].row_count == 2  # 20.0 and 30.0
        assert result.params == {"min_total": 15.0}

    def test_literal_param_execution(self, csv_files):
        @rowbase.pipeline
        def pipe(mode: Literal["upper", "lower"] = "upper"):
            orders = rowbase.source("orders")

            @rowbase.dataset("transformed", data_from=orders)
            def transformed(orders: pl.DataFrame) -> pl.DataFrame:
                if mode == "upper":
                    return orders.with_columns(pl.col("country").str.to_uppercase())
                return orders.with_columns(pl.col("country").str.to_lowercase())

            yield transformed

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]}, params={"mode": "lower"})

        assert result.status == "success"
        df = result.dataframes["transformed"]
        assert df.filter(pl.col("country") == "us").shape[0] == 2

    def test_no_params_pipeline_still_works(self, csv_files):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("out", data_from=orders)
            def out(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield out

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(spec, {"orders": csv_files["orders"]})

        assert result.status == "success"
        assert result.params == {}

    def test_multiple_params(self, csv_files):
        @rowbase.pipeline
        def pipe(
            country: str = Param(default="US", description="Country filter"),
            min_total: float = 0.0,
        ):
            orders = rowbase.source("orders")

            @rowbase.dataset("filtered", data_from=orders)
            def filtered(orders: pl.DataFrame) -> pl.DataFrame:
                return orders.filter(
                    (pl.col("country") == country) & (pl.col("total") > min_total)
                )

            yield filtered

        spec = pipe()
        runner = PipelineRunner()
        result = runner.run(
            spec, {"orders": csv_files["orders"]}, params={"country": "US", "min_total": 15}
        )

        assert result.status == "success"
        assert result.datasets["filtered"].row_count == 1  # only 30.0 US order
        assert result.params == {"country": "US", "min_total": 15.0}
