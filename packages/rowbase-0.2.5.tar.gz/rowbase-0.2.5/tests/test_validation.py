"""Tests for rowbase.cli.validation."""

from __future__ import annotations

from unittest.mock import MagicMock

import polars as pl
import pytest

import rowbase
from rowbase.cli.discovery import DiscoveredPipeline
from rowbase.cli.validation import ValidationResult, validate_pipeline
from rowbase.errors import RowbaseError
from rowbase.params import Param


def _make_discovered(pipeline_fn, name: str = "test") -> DiscoveredPipeline:
    from pathlib import Path

    return DiscoveredPipeline(name=name, path=Path("/fake/test.py"), pipeline_fn=pipeline_fn)


class TestValidatePipelineBasic:
    def test_valid_pipeline(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield cleaned

        result = validate_pipeline(_make_discovered(pipe))
        assert result.valid
        assert result.errors == []
        assert result.sources == ["orders"]
        assert result.datasets == ["cleaned"]
        assert result.published == ["cleaned"]

    def test_pipeline_fn_raises_rowbase_error(self):
        def bad_fn():
            raise RowbaseError(code="BOOM", message="something broke")

        result = validate_pipeline(_make_discovered(bad_fn))
        assert not result.valid
        assert any("BOOM" in e for e in result.errors)

    def test_pipeline_fn_raises_generic_exception(self):
        def bad_fn():
            raise RuntimeError("unexpected crash")

        result = validate_pipeline(_make_discovered(bad_fn))
        assert not result.valid
        assert any("unexpected crash" in e for e in result.errors)

    def test_uses_spec_name_over_discovered_name(self):
        @rowbase.pipeline(name="custom_name")
        def pipe():
            src = rowbase.source("s")

            @rowbase.dataset("d", data_from=src)
            def d(s: pl.DataFrame) -> pl.DataFrame:
                return s

            yield d

        result = validate_pipeline(_make_discovered(pipe, name="fallback"))
        assert result.name == "custom_name"


class TestParamValidation:
    def test_supported_param_types_pass(self):
        @rowbase.pipeline
        def pipe(region: str = "US", count: int = 10):
            src = rowbase.source("s")

            @rowbase.dataset("d", data_from=src)
            def d(s: pl.DataFrame) -> pl.DataFrame:
                return s

            yield d

        result = validate_pipeline(_make_discovered(pipe))
        assert result.valid
        assert len(result.params) == 2

    def test_unsupported_param_type_via_validation(self):
        """Pipeline discovery rejects bad types, so we mock to test validation layer."""
        mock_spec = MagicMock()
        mock_spec.name = "test"
        mock_spec.context.sources = {}
        mock_spec.context.datasets = {}
        mock_spec.context.assets = {}
        mock_spec.context.published = set()

        bad_param = MagicMock()
        bad_param.name = "data"
        bad_param.param_type = "list"
        mock_spec.params = [bad_param]

        result = validate_pipeline(_make_discovered(lambda: mock_spec))
        assert not result.valid
        assert any("unsupported type" in e for e in result.errors)


class TestPublishedNameValidation:
    def test_published_name_not_in_registry(self):
        """A published name that doesn't match any dataset or asset is an error."""
        mock_spec = MagicMock()
        mock_spec.name = "test"
        mock_spec.context.sources = {}
        mock_spec.context.datasets = {}
        mock_spec.context.assets = {}
        mock_spec.context.published = {"ghost"}
        mock_spec.params = []

        result = validate_pipeline(_make_discovered(lambda: mock_spec))
        assert not result.valid
        assert any("ghost" in e for e in result.errors)


class TestDataChainValidation:
    def test_valid_chain_passes(self):
        @rowbase.pipeline
        def pipe():
            src = rowbase.source("raw")

            @rowbase.dataset("step1", data_from=src)
            def step1(raw: pl.DataFrame) -> pl.DataFrame:
                return raw

            @rowbase.dataset("step2", data_from=step1)
            def step2(step1: pl.DataFrame) -> pl.DataFrame:
                return step1

            yield step2

        result = validate_pipeline(_make_discovered(pipe))
        assert result.valid

    def test_self_created_dataset_passes(self):
        @rowbase.pipeline
        def pipe():
            @rowbase.dataset("generated")
            def generated() -> pl.DataFrame:
                return pl.DataFrame({"id": [1]})

            yield generated

        result = validate_pipeline(_make_discovered(pipe))
        assert result.valid

    def test_assets_included_in_result(self):
        @rowbase.pipeline
        def pipe():
            src = rowbase.source("data")

            @rowbase.asset("report", data_from=src, content_type="text/plain")
            def report(data: pl.DataFrame) -> bytes:
                return b"hello"

            yield report

        result = validate_pipeline(_make_discovered(pipe))
        assert result.valid
        assert result.assets == ["report"]
